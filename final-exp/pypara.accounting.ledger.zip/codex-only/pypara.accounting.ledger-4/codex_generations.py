

# Generated at 2022-06-24 00:57:41.486212
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"


# Generated at 2022-06-24 00:57:46.651593
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Define initial balances as a dict:
    initial_balances = {
        Account("Current Assets", "Cash & Bank"): Balance(datetime.date(2019, 8, 1), Quantity(Decimal(1005.25))),
        Account("Current Liabilities", "Accounts Payable"): Balance(
            datetime.date(2019, 8, 1), Quantity(Decimal(1043.00))
        ),
        Account("Current Assets", "Store Supplies"): Balance(datetime.date(2019, 8, 1), Quantity(Decimal(300.00))),
    }

    ## Define journal entries.

# Generated at 2022-06-24 00:57:51.858667
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # arrange
    ledger1 = GeneralLedger(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)), dict())
    ledger2 = GeneralLedger(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)), dict())

    # act
    eq = ledger1 == ledger2

    # assert
    assert(eq)


# Generated at 2022-06-24 00:57:59.478994
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    import datetime as dt
    x = dt.date(2018, 1, 1)
    y = dt.date(2018, 1, 2)
    z = dt.date(2018, 1, 3)
    account1 = Account("Assets", "Cash")
    account2 = Account("Assets", "Equity")
    account3 = Account("Liabilities", "Loan")
    period1 = DateRange("2018-01-01", "2018-01-02")
    period2 = DateRange("2018-01-03", "2018-01-04")
    initial_balances1 = {}
    initial_balances2 = {account1: Balance(x, Quantity(10))}
    initial_balances3 = {account1: Balance(x, Quantity(10)), account2: Balance(y, Quantity(20))}
   

# Generated at 2022-06-24 00:58:03.884676
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..test import Mock
    from .journaling import JournalEntry, PostingAccount, PostingDirection

    abc_account = PostingAccount("12345678", "ABC")
    def_account = PostingAccount("98765432", "DEF")
    period: DateRange = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    debits: List[JournalEntry] = [
        JournalEntry(
            "Entry1",
            datetime.date(2020, 1, 1),
            [
                Posting(deb, Quantity(-500,)),
                Posting(crd, Quantity(500)),
            ],
        )
        for deb, crd in [(abc_account, def_account), (def_account, abc_account)]
    ]

# Generated at 2022-06-24 00:58:06.163019
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # Test case data
    account=Account(1,"account1",False)
    balance=Balance(2020,2)
    posting=Posting()
    entry=LedgerEntry(account,posting,balance)


# Generated at 2022-06-24 00:58:08.524102
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        ...
    assert isinstance(_read_initial_balances, ReadInitialBalances)


# Generated at 2022-06-24 00:58:15.224148
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Define parameters and method stubs
    initial_balances = {}
    journal_entries = {}
    period = DateRange(datetime.date(2020,5,5), datetime.date(2020,6,6))
    # Build the compiled program
    program = compile_general_ledger_program(initial_balances, journal_entries)
    assert program(period) == build_general_ledger(period, journal_entries, initial_balances)

# Generated at 2022-06-24 00:58:24.592731
# Unit test for constructor of class Ledger
def test_Ledger():
    # Interpreter:
    from ..algebraic.models import GeneralLedgerProgram
    from ..algebraic.testing import parse_initial_balances, parse_journal_entries

    # Compile a program.
    program: GeneralLedgerProgram[str] = compile_general_ledger_program(
        parse_initial_balances, parse_journal_entries
    )
    generalledger = program(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))
    cntraccts=general_ledger.ledgers[Account("123")][-1].cntraccts
    assert cntraccts == [Account("237"), Account("299")]
    assert general_ledger.ledgers[Account("123")][-1].description == "Test transaction"

# Generated at 2022-06-24 00:58:28.316657
# Unit test for constructor of class Ledger
def test_Ledger():
    ledger = Ledger(Account('1111', 'Assets', 'Current Accounts'), Balance(datetime.date(2012, 1, 1), Decimal('0')))
    assert ledger.account.number == '1111'
    assert ledger.entries == []


# Generated at 2022-06-24 00:58:37.997216
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger
    """

    from datetime import date
    from decimal import Decimal
    from .sample import cash, expenses, revenues, xfer

    ## Prepare the date range specifying the accounting period:
    period = DateRange(date(2020, 9, 1), date(2020, 9, 30))

    ## Prepare array of journal entries:

# Generated at 2022-06-24 00:58:47.785749
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import AccountType
    from .journaling import Journal, JournalEntry, Posting, ReadJournalEntries
    # Set up test data.
    amount1 = Amount(Decimal('100.00'))
    amount2 = Amount(Decimal('-200.00'))
    account1 = Account('1010', 'Cash', AccountType.asset)
    account2 = Account('1520', 'Accounts Payable', AccountType.liability)
    posting1 = Posting(account1, amount1)
    posting2 = Posting(account2, amount2)
    journal = Journal([posting1, posting2])
    journal_entries = [JournalEntry(journal.date, 1, journal)]
    def read_journal_entries(period):
        return journal_entries

# Generated at 2022-06-24 00:58:54.367397
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Unit test for method __repr__ of class LedgerEntry
    """
    assert eval(repr(LedgerEntry(Ledger(Account(1), Balance(datetime.date(2, 3, 4), Quantity(300))), Posting(JournalEntry(datetime.date(2, 3, 4), 'test'), Account(1), Amount(400), Direction.DEBIT), Quantity(300)))) == LedgerEntry(Ledger(Account(1), Balance(datetime.date(2, 3, 4), Quantity(300))), Posting(JournalEntry(datetime.date(2, 3, 4), 'test'), Account(1), Amount(400), Direction.DEBIT), Quantity(300))


# Generated at 2022-06-24 00:59:01.743634
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    journal = [
        JournalEntry(datetime.date(2020, 3, 1), "journal entry #1"),
        JournalEntry(datetime.date(2020, 1, 1), "journal entry #2"),
        JournalEntry(datetime.date(2020, 6, 30), "journal entry #3"),
    ]
    initial = {
        Account("account #1", "the account #1"): Balance(datetime.date(2019, 12, 31), Decimal("10000.00")),
        Account("account #2", "the account #2"): Balance(datetime.date(2019, 12, 31), Decimal("0.00")),
    }
    gl = build_general_ledger(period, journal, initial)

# Generated at 2022-06-24 00:59:08.195159
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(Account("123"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))))) == "Ledger(Account(code='123'), Balance(since=datetime.date(2018, 1, 1), value=Quantity(Decimal('0'))))"


# Generated at 2022-06-24 00:59:15.944827
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Mock of ReadInitialBalances
    def mock_read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account(number=1, name="Assets"): Balance(end_of_last_period=datetime.date(2018, 1, 1), value=Quantity(0)),
            Account(number=2, name="Liabilities"): Balance(end_of_last_period=datetime.date(2018, 1, 1), value=Quantity(0)),
            Account(number=3, name="Equities"): Balance(end_of_last_period=datetime.date(2018, 1, 1), value=Quantity(0)),
        }

    # Mock of ReadJournalEntries

# Generated at 2022-06-24 00:59:19.489222
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
   period=('2020-01-01','2020-12-31')
   read_initial_balances = read_initial_balances(period)
   read_journal_entries = read_journal_entries(period)
   return

   ## Read journal entries and post each of them:
   journal_entries = read_journal_entries(period)
   return
   ## Build the general ledger and return:
   return build_general_ledger(period, journal_entries, initial_balances)

# Generated at 2022-06-24 00:59:31.407586
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # The account of the Ledger
    account_ledger = Account("Assets", "Property, Plant, and Equipment", "Land")
    # The initial of the Ledger
    initial_ledger = Balance(datetime.datetime.strptime("2018-01-01", "%Y-%m-%d").date(), Quantity(Decimal(1000)))
    # The entries of the Ledger

# Generated at 2022-06-24 00:59:40.475521
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    import getpass
    from ..commons.zeitgeist import year
    from ..infra.sourcing import build_read_journal_entries, build_read_initial_balances, build_read_journal_entry
    from .accounts import account
    from .journaling import build_journal_entry
    try:
        from config import DSN
    except:
        DSN=f'postgres://{getpass.getuser()}'
    frm = year(2020)
    to = year(2020, 12, 31)
    read_journal_entry = build_read_journal_entry(DSN)
    read_journal_entries = build_read_journal_entries(read_journal_entry)
    read_initial_balances = build_read_initial_balances(frm)
    program = compile_general_led

# Generated at 2022-06-24 00:59:48.233524
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    #: Defines a generic type variable.
    _T = TypeVar("_T")
    #: Grouping function.
    group_by = lambda x: {
        "date": x.date.strftime("%Y-%m-%d"),
        "description": x.description,
        "amount": x.amount.quantize(Decimal("0.00")),
        "debit": x.debit,
        "credit": x.credit,
        "counter-accounts": ", ".join(sorted(p.account.code for p in x.posting.journal.postings if p != x.posting)),
    }
    # Initialize ledgers buffer as per available initial balances:
    #ledgers: Dict[Account, Ledger[_T]] = {}
    # Iterate over journal postings and populate ledgers:
   

# Generated at 2022-06-24 00:59:50.613034
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-24 00:59:58.954571
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountCode
    from .journaling import JournalEntry, Posting
    from .commons.zeitgeist import DateRange

    # Define initial balances:
    initial_balances = {
        Account(AccountCode.ASSET, "Cash"): Balance(datetime.date(2019, 12, 1), Quantity(10))
    }

    # Define journal entries:

# Generated at 2022-06-24 01:00:00.586831
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Set up
    ledger = GeneralLedger([])
    
    # When
    assert ledger.entries == []


# Generated at 2022-06-24 01:00:08.653478
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ReadInitialBalances_Mock1(Protocol):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    @dataclass
    class ReadInitialBalances_Mock2(Protocol):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    ReadInitialBalances_Mock1()
    ReadInitialBalances_Mock2()



# Generated at 2022-06-24 01:00:17.862824
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account('asset','cash','cash','USD')
    posting = Posting(
        account,
        Amount(Decimal('1.00')),
        'debit'
    )
    entry = LedgerEntry(
        Ledger(
            account,
            Balance(
                datetime.date.today(),
                Quantity(Decimal('0.00'))
            )
        ),
        posting,
        Quantity(Decimal('1.00'))
    )
    another_entry = LedgerEntry(
        Ledger(
            account,
            Balance(
                datetime.date.today(),
                Quantity(Decimal('0.00'))
            )
        ),
        posting,
        Quantity(Decimal('1.00'))
    )
    assert entry == another_entry

# Generated at 2022-06-24 01:00:26.701874
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    The method GeneralLedger.__repr__() should print the first and last date of the ledger and the number of accounts.
    """
    ## Period and entries
    Jan_1 = datetime.date(2019, 1, 1)
    Jan_31 = datetime.date(2019, 1, 31)
    general_ledger = GeneralLedger(DateRange(Jan_1, Jan_31), {Account('42'): Ledger(Account('42'), Balance(Jan_1, Quantity(Decimal(0))))})
    print(general_ledger)
    assert str(general_ledger) == "<Ledger, period: 2019-01-01 until 2019-01-31, accounts: 1>"


# Generated at 2022-06-24 01:00:27.940170
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass # TODO: Implement test

# Generated at 2022-06-24 01:00:30.442923
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances.__doc__


# Generated at 2022-06-24 01:00:41.679412
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    def _read_initial_balances1(period: DateRange) -> InitialBalances:
        """
        Implementation of algebra which reads and returns initial balances.
        """
        return {}

    def _read_initial_balances2(period: DateRange) -> InitialBalances:
        """
        Implementation of algebra which reads and returns initial balances.
        """
        return {}

    #AssertionError:
    assert _read_initial_balances1(DateRange(datetime.date(2018,1,1),datetime.date(2018,6,30))) == {}
    #AssertionError:
    assert _read_initial_balances2(DateRange(datetime.date(2018,1,1),datetime.date(2018,6,30)))

# Generated at 2022-06-24 01:00:53.679929
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Test for invalid object type for accounting period
    try:
        test_period = 1
        test_ledgers = {}
        GeneralLedger(test_period, test_ledgers)
        raise AssertionError("Invalid object type accepted")
    except AssertionError as e:
        print("AssertionError raised:", e)
    except:
        raise AssertionError("Incorrect exception raised")
    else:
        print("test_GeneralLedger1 passed")

    # Test for invalid object type for ledgers

# Generated at 2022-06-24 01:01:05.120848
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    import unittest.mock as mock
    from ..commons.zeitgeist import DateRange

    read_initial_balances = mock.Mock(ReadInitialBalances)
    read_journal_entries = mock.Mock(ReadJournalEntries)

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert program(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))) == read_initial_balances.return_value

    read_initial_balances.assert_called_once_with(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))

# # Uncomment to run unit tests
# if __name__ == "__main__":
#     import unitt

# Generated at 2022-06-24 01:01:10.891049
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    gl = GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)), {0: "Hi"})
    assert gl.period.since == datetime.date(2020, 1, 1) and gl.period.until == datetime.date(2020, 1, 1)



# Generated at 2022-06-24 01:01:22.793842
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Arrange:
    from .accounts import AccountType
    from .journals import JournalEntry
    from .types import Currency

    from typing import Dict, Iterable

    USD: Currency = Currency("USD")
    initial_balances: Dict[Account, Balance] = {
        Account("Cash", AccountType.Terminal, USD): Balance(datetime.date(2017, 1, 1), Quantity(Decimal(10)))
    }
    journal_entries: Iterable[JournalEntry] = [
        JournalEntry(datetime.date(2017, 1, 1), "Journal Entry 01", [])
    ]

    # Act:

# Generated at 2022-06-24 01:01:33.417307
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..commons.zeitgeist import today
    from .accounts import AccountType

    period = DateRange(datetime.date(2020, 4, 1), datetime.date(2020, 5, 1))
    gl = GeneralLedger(period, {})

    # Test the period
    assert gl.period == period

    # Test the ledger
    profit_account = Account("0101", AccountType.PROFIT)
    b = Balance(period.since, Amount(100.0))
    l = Ledger(profit_account, b)
    gl.ledgers[profit_account] = l
    assert gl.ledgers[profit_account].account == profit_account
    assert gl.ledgers[profit_account].initial == b
    assert gl.ledgers[profit_account].entries == []
    
    # Test add an entry


# Generated at 2022-06-24 01:01:36.458058
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # Initialize the two objects
    a=GeneralLedger([], [])
    b=GeneralLedger([], [])
    assert a==b
    pass



# Generated at 2022-06-24 01:01:46.184652
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .commons.zeitgeist import DateRange

    # Create accounts
    aa = Account('Assets', 'Accounts receivable')
    al = Account('Liabilities', 'Accounts payable')
    ex = Account('Expenses', 'Expenses')

    # Create postings
    p1 = Posting(aa, 100, 'Regular posting')
    p2 = Posting(al, -100, 'Regular posting')
    p3 = Posting(ex, -50, 'Regular posting')

    # Create journals
    j1 = JournalEntry('Regular journal')
    j1.post(p1)
    j1.post(p2)
    j1.post(p3)

    # Initialize period
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 2, 1))

    #

# Generated at 2022-06-24 01:01:55.306463
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # setup
    period = DateRange(datetime.date(2020,1,1),datetime.date(2020,1,31))
    #(self, period: DateRange, journal: Iterable[JournalEntry[_T]], initial: InitialBalances) -> GeneralLedger[_T]
    #(account: Account, value: Quantity) -> Balance
    #(date: datetime.date, description: str) -> JournalEntry
    #(journal: JournalEntry, account: Account, amount: Amount, direction: Direction) -> Posting
    #(self, journal: JournalEntry, postings: Iterable[Posting]) -> None:
    test_journal = []
    test_journal.append(JournalEntry(datetime.date(2020,1,1), "Test Journal Entry 01"))
    test_postings = []

# Generated at 2022-06-24 01:02:03.393879
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    A = Posting('A', 'B', 'C', 'D', datetime.date(2021, 1, 1))
    L = Ledger(A)
    LE = LedgerEntry(L, A, Quantity(Decimal(0)))
    assert LE.ledger == L
    assert LE.posting == A
    assert LE.balance == Quantity(Decimal(0))
    assert LE.date == A.date
    assert LE.description == A.journal.description
    assert LE.amount == A.amount
    assert LE.cntraccts[0] == A.account
    assert LE.is_debit == A.is_debit
    assert LE.is_credit == A.is_credit
    assert LE.debit == A.amount
    assert LE.credit == None


# Generated at 2022-06-24 01:02:06.468355
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    type_ = ReadInitialBalances
    assert type_.__origin__ == Protocol
    assert type_.__args__ == ()
    assert type_.__parameters__ == ()



# Generated at 2022-06-24 01:02:17.723023
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from dataclasses import replace
    from dateutil.parser import parse
    from ..commons.currencies import Currency
    import datetime
    from decimal import Decimal
    from ..commons.baking import Payee
    from ..commons.numbers import Amount

    # Set up a ledger
    ledger = Ledger(Account(1000, "CASH", "CASH"), Balance(parse("2018-12-31"), Decimal(100)))

    # Add the first entry

# Generated at 2022-06-24 01:02:26.297745
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting
    from .accounts import Account

    account1 = Account(10)
    account2 = Account(15)
    balance = Balance(datetime.date(2020, 9, 1), Quantity(3))
    ledger = Ledger(account1, balance)
    assert ledger.entries == []

    posting = Posting(ledger, Journal(description="Test", postings=[Posting(ledger, account2, -1)]))

    return_value = ledger.add(posting)

    assert ledger.entries != []
    assert ledger.entries[0] == return_value
    assert ledger.entries[0].ledger == ledger
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].balance == Quantity(4)

# Generated at 2022-06-24 01:02:28.213135
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import get_today

    ...


# Generated at 2022-06-24 01:02:39.286105
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    from ..commons.algebras import build_algebra_for_read_initial_balances, build_algebra_for_read_journal_entries
    from .accounts import Assets
    from .accounts.misc import Cash
    from .journaling import Journal, Posting, build_posting

    # Provide initial balances as of previous financial period:
    def read_initial_balances(period: DateRange):
        return {Assets: Balance(period.since, Quantity(Decimal("1000.00")))}

    # Provide journal entries for the accounting period:

# Generated at 2022-06-24 01:02:45.170155
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test the method __eq__ of class LedgerEntry.
    """
    # Initialize test variables
    a=LedgerEntry("a", "b", "c")
    b=LedgerEntry("a", "b", "c")
    c=LedgerEntry("x", "y", "z")

    # Assert equality
    assert a.__eq__(b)
    assert not a.__eq__(c)

# Generated at 2022-06-24 01:02:50.431134
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Direction
    
    le = LedgerEntry('ledger', 9999, 'posting', Direction.DEBIT, 12, 'description', 'date')
    assert le.ledger == 'ledger'
    assert le.posting == 9999
    assert le.balance == 12
    # assert le.date == 'date'
    assert le.description == 'description'
    assert le.is_debit == True
    assert le.is_credit == False
    assert le.debit == le.amount
    assert le.credit == None


# Generated at 2022-06-24 01:02:55.294741
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test if method __eq__ of class LedgerEntry works as expected.
    """
    test_subject_1 = LedgerEntry('account1', 'posting1', 'balance1')
    test_subject_2 = LedgerEntry('account2', 'posting2', 'balance2')
    assert test_subject_1.__eq__(test_subject_1)
    assert not test_subject_1.__eq__(test_subject_2)


# Generated at 2022-06-24 01:03:01.191592
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .accounts import Account, AccountGroup

    ## Create a ledger:
    ledger = Ledger(Account(AccountGroup.ASSET, "2001"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))))

    ## Assert ledger are equal (for the same account):
    assert ledger == Ledger(
        Account(AccountGroup.ASSET, "2001"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0)))
    )

    ## Assert ledgers are not equal (for different accounts):
    assert ledger != Ledger(
        Account(AccountGroup.ASSET, "2002"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0)))
    )



# Generated at 2022-06-24 01:03:12.891070
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange("2019-01-01", "2019-01-30")

    initial = {Account("100"): Balance("2019-01-01", Quantity("100")),
               Account("200"): Balance("2019-01-01", Quantity("100")),
               Account("300"): Balance("2019-01-01", Quantity("100"))}

# Generated at 2022-06-24 01:03:18.051323
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
  ledger = Ledger(1, 0)

  journal = JournalEntry()
  journal.append_posting(Posting(1, "2019-01-01", 12))
  posting = journal.postings[0]

  entry = LedgerEntry(ledger, posting, Quantity(decimal.Decimal))

  assert entry.ledger == ledger
  assert entry.posting == posting

# Generated at 2022-06-24 01:03:21.310646
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    class ReadInitialBalances():
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    try:
        ReadInitialBalances()
    except:
        raise


# Generated at 2022-06-24 01:03:29.150197
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import AccountCategory, AccountHeader, AccountType, postable_accounts
    from .journaling import Journal, PostingDirection, compile_book_journal_entry_program
    from .ledgering import GLAccount
    from .persistence import build_memory_repository, MemoryRepository
    from .recording import Record, RecordType
    from .taxing import Tax, TaxType
    from ..commons.context import DIT
    from ..commons.types import Transaction, UUID
    from ..commons.zeitgeist import Period

    ## Initialize business domain model:
    t: Transaction = Transaction(UUID(1), datetime.date(2020, 1, 1), "Test Transaction")
    tt: Transaction = Transaction(UUID(2), datetime.date(2020, 1, 15), "Test Transaction")

# Generated at 2022-06-24 01:03:38.937253
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import datetime

    ## Define journal entries:

# Generated at 2022-06-24 01:03:44.229321
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from .accounts import AccountBalance
    from .accounts.algebra import ReadBalances as ReadAccountBalances
    from .journaling import Journal, Posting, JournalEntry as JournalEntry_
    from .journaling.algebra import ReadJournalEntries as ReadJournalEntries_

    ## Initial balances:
    initial_balances = {
        AccountBalance("a", Quantity(0), datetime.date(2017, 1, 1)): Balance(datetime.date(2017, 1, 1), Quantity(0)),
    }

    ## No journal postings:

# Generated at 2022-06-24 01:03:47.492515
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Arrange
    le1=LedgerEntry(ledger=None,posting=None,balance=None)
    le2=LedgerEntry(ledger=None,posting=None,balance=None)

    # Act
    le1.__eq__(le2)

    # Assert
    pass

# Generated at 2022-06-24 01:03:50.870400
# Unit test for constructor of class Ledger
def test_Ledger():
    # Arrange
    account = Account('1001', 'Cash')
    balance = Balance(datetime.date(2019, 1, 1), Quantity(Decimal('111.1')))

    # Act
    ledger = Ledger(account, balance)

    # Assert
    assert ledger.account == account
    assert ledger.initial == balance
    assert ledger.entries == []



# Generated at 2022-06-24 01:04:02.044163
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict, Protocol, TypeVar
    from datetime import date
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    ## Create the adequate instance of ReadInitialBalances:
    @dataclass
    class _ReadInitialBalancesImplementation(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    ## Define a data value which satisfies the type:
    balance = Balance(date.today(), Quantity(Decimal(100)))
    balances: InitialBalances = {Account(1, 'a'): balance}

    ## Call the method:

# Generated at 2022-06-24 01:04:11.656438
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Initial value of account
    test_account = Account(short="foo", full="bar")

    # Initial value of initial
    test_initial = Balance(datetime.date(2017, 12, 31), Quantity(Decimal(1000)))

    # Initial value of entries
    test_entries = list()
    test_entries.append(LedgerEntry(Ledger(test_account, test_initial), Posting(JournalEntry(), Account()), Quantity(Decimal(1000))))
    test_entries.append(LedgerEntry(Ledger(test_account, test_initial), Posting(JournalEntry(), Account()), Quantity(Decimal(1000))))
    test_entries.append(LedgerEntry(Ledger(test_account, test_initial), Posting(JournalEntry(), Account()), Quantity(Decimal(1000))))

    # Initial value of ledger


# Generated at 2022-06-24 01:04:22.209669
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .mocks import mock_initial_balances, mock_journal_entries
    from .transactions import create_journal_entry

    ## Arrange.
    # Create test data:
    period = DateRange("2018-06-01", "2018-06-30")

    # Create test doubles:
    mock_initial_balances = mock_initial_balances(initial={"101": Balance("2018-05-31", Quantity(Decimal(0)))})

# Generated at 2022-06-24 01:04:27.560997
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from unittest import TestCase, main
    from datetime import date
    from collections import defaultdict
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange, MonthRange
    from .accounts import Account, AccountType
    from .journaling import Journal, JournalEntry, Posting
    from .books import LedgerBook
    from .generic import Balance
    from .ledgers import (
        GeneralLedger,
        GeneralLedgerProgram,
        build_general_ledger,
        compile_general_ledger_program,
    )

    @dataclass
    class _GeneralLedgerProgram(Generic[int]):
        """
        Mock implementation of the general ledger program.
        """

        #: General ledger to return.
        general_ledger: GeneralLed

# Generated at 2022-06-24 01:04:38.022531
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Unit test for constructor of class GeneralLedger
    period = DateRange(since=datetime.date(2020,8,1),until=datetime.date(2020,8,31))
    journal = [JournalEntry(datetime.date(2020,8,1),'Test Journal 1',[Posting(datetime.date(2020,8,1),1,'Test Account 1',8.75)])]
    initial = {'Test Account 1':Balance(datetime.date(2020,8,1),Quantity(8.75))}
    GL = build_general_ledger(period,journal,initial)
    assert isinstance(GL, GeneralLedger)
    assert isinstance(GL.period, DateRange)
    assert isinstance(GL.ledgers, Dict)


# Generated at 2022-06-24 01:04:38.914935
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:04:43.969834
# Unit test for constructor of class Ledger
def test_Ledger():
    ledger = Ledger(Account("Assets"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))))
    assert ledger.account.name == "Assets"
    assert ledger.entries == []
    assert ledger.initial.value == Quantity(Decimal(0))
    assert ledger.initial.date == datetime.date(2018, 1, 1)
    assert ledger.entries == []


# Generated at 2022-06-24 01:04:44.825235
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass  # pragma: no cover


# Generated at 2022-06-24 01:04:50.822026
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange('2020-09-01', '2020-09-20')
    
    j1 = JournalEntry(datetime.date(2020, 9, 3), 'A', 'B', 'Payment for goods sold',
                      (Posting('A', Quantity(Decimal('10.00'))),
                       Posting('B', Quantity(Decimal('-10.00')))))
    j2 = JournalEntry(datetime.date(2020, 9, 10), 'A', 'B', 'Payment for goods sold',
                      (Posting('A', Quantity(Decimal('10.00'))),
                       Posting('B', Quantity(Decimal('-10.00')))))

# Generated at 2022-06-24 01:05:02.802721
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    """
    The purpose of this unit test is to test the constructor of the class LedgerEntry.  The test case makes sure that the
    value of the parameter ledger of the constructed LedgerEntry is the same as the a specified ledger.  Similarly, the
    test case also makes sure that the value of the parameter posting of the constructed LedgerEntry is the same as the
    specified posting.  Finally, the test case makes sure that the value of the parameter balance of the constructed
    LedgerEntry is the same as the specified balance.
    :return: Nothing.
    """
    account = Account('042', "Cash", 'Assets')  # Create a specified Account.
    balance = Balance(datetime.date(2018, 6, 1), Quantity(Decimal(0)))  # Create a specified Balance.
    ledger = Ledger(account, balance)  # Create a specified Ledger

# Generated at 2022-06-24 01:05:13.179587
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Test the interface of the compilation of the general ledger program.
    """
    import unittest
    from .persistence import do_create_tables, do_drop_tables
    from .accounts import ReadAccounts
    from .books import ReadBooks
    from .transactions import ReadTransactions
    from .journaling import ReadJournalEntries
    from .general.persistence import do_create_tables as do_create_general_tables, do_drop_tables as do_drop_general_tables
    from .general.persistence import ReadInitialBalances
    from .test_accounts import test_accounts

    ## Drop and create tables:
    with do_drop_tables() as session:
        pass

    with do_create_tables() as session:
        pass

    ## Drop and create tables:


# Generated at 2022-06-24 01:05:23.436807
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from unittest.mock import MagicMock
    import datetime
    math_timedelta = datetime.timedelta(days=-10)
    math_journal = MagicMock()
    math_journal.date = math_timedelta
    math_posting = MagicMock()
    math_posting.date = math_timedelta
    math_posting.journal = math_journal
    math_ledger = MagicMock()
    math_amount = MagicMock()
    math_balance = MagicMock()
    math_posting.amount = math_amount
    result = LedgerEntry(math_ledger, math_posting, math_balance)

    assert result.ledger is math_ledger
    assert result.posting is math_posting
    assert result.balance is math_balance


# Unit

# Generated at 2022-06-24 01:05:32.481868
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account(code="1", description="Account 1")
    balance = Balance(date=datetime.date(2019, 9, 1), value=1)
    ledger = Ledger(account, balance)
    expected = "Ledger(account=Account(code='1', description='Account 1', category=None, terminal=None, contra=False), initial=Balance(date=datetime.date(2019, 9, 1), value=1), entries=[])"
    assert repr(ledger) == expected, "Expected: '{expected}'\n Received: '{received}'".format(expected=expected, received=repr(ledger))

# Generated at 2022-06-24 01:05:40.739094
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from sys import version_info
    from ..commons import Currency
    from ..journaling import Posting, ReadJournalEntries
    from .accounts import Account, ReadAccounts
    from .books import register_book
    from .journaling import JournalEntry, ReadJournalEntries
    from .reporting import Report, ReportRow, Summarize
    from .general_ledger import GeneralLedger
    from .generic import Balance, Quantity
    from .commons import Period

    ## Initialize the DB engine:
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("sqlite:///:memory:")
    Session = sessionmaker(bind=engine)

    ## Read accounts:
    session = Session()
    read_accounts = ReadAccounts(session)
    _, accounts_map = register_

# Generated at 2022-06-24 01:05:46.138005
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    account = Account.objects.get(pk=9)
    ledger = Ledger(account, Balance('2019-04-01', Quantity(Decimal(0))))
    entry = LedgerEntry(ledger, None, 0)
    result = entry.__repr__()
    assert result == '<LedgerEntry date:None description:None amount:None debit:None credit:None>'


# Generated at 2022-06-24 01:05:46.727798
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    assert True

# Generated at 2022-06-24 01:05:49.179380
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:05:49.722548
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger


# Generated at 2022-06-24 01:05:57.436774
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .ledgers import LedgerEntry
    account1 = Account(0, "account1", False)
    account2 = Account(1, "account2", False)
    account3 = Account(0, "account3", False)
    account4 = Account(3, "account4", False)

    # Ledger entry with same account, but different id and properties
    ledger = LedgerEntry(account1, account2, Decimal(10), Decimal(20))
    ledger2 = LedgerEntry(account3, account4, Decimal(30), Decimal(40))
    assert not ledger._eq(ledger2)

    # Ledger entry with same id and properties, but different account
    account = Account(0, "account", False)

# Generated at 2022-06-24 01:06:04.365588
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class MockInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    @dataclass
    class MockReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return []

    assert compile_general_ledger_program(MockInitialBalances(), MockReadJournalEntries())



# Generated at 2022-06-24 01:06:06.255765
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass

# Generated at 2022-06-24 01:06:10.764872
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    l1 = LedgerEntry(None, None, None)
    l2 = LedgerEntry(None, None, None)
    l3 = LedgerEntry(None, None, None)

    assert l1 == l2
    assert l1 != l3


# Generated at 2022-06-24 01:06:14.938718
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("1", "Account #1", "Assets")
    initial = Balance(datetime.datetime(2020, 9, 5), 0)
    ledger = Ledger(account, initial)
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == []

# Generated at 2022-06-24 01:06:20.747348
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class RequireGeneralLedgerProgram(Protocol):
        """
        Type definition of the program which builds general ledger.
        """

        def __call__(self) -> GeneralLedgerProgram[_T]:
            pass
    # Unit test for constructor of class GeneralLedgerProgram
    def test_GeneralLedgerProgram():
        @dataclass
        class RequireGeneralLedgerProgram(Protocol):
            """
            Type definition of the program which builds general ledger.
            """

            def __call__(self) -> GeneralLedgerProgram[_T]:
                pass

# Generated at 2022-06-24 01:06:21.405970
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    GeneralLedger.__eq__()


# Generated at 2022-06-24 01:06:27.844892
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    a1 = Account("123345")
    a2 = Account("1234")
    j1 = JournalEntry(datetime.date.today(), "Test", [
        Posting(a2, Decimal(25), 1),
        Posting(a1, Decimal(25), -1)]
    )
    l0 = Ledger(a1, Balance(datetime.date.today(), Decimal(0)))
    l1 = l0.add(j1.postings[0])
    assert l1.ledger == l0
    assert l1.posting == j1.postings[0]
    assert l1.balance == 25
    assert l1.date == datetime.date.today()
    assert l1.description == "Test"
    assert l1.amount == 25
    assert l1.cntraccts

# Generated at 2022-06-24 01:06:36.422344
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    a_ledger1 = Ledger(Account(name="A", no="1"), Balance.of(Quantity(10)))
    a_ledger2 = Ledger(Account(name="A", no="1"), Balance.of(Quantity(10)))
    b_ledger = Ledger(Account(name="B", no="1"), Balance.of(Quantity(10)))

    ledgers = {Account(name="A", no="1"): a_ledger1, Account(name="B", no="1"): b_ledger}
    ledgers2 = {Account(name="A", no="1"): a_ledger2, Account(name="B", no="1"): b_ledger}


# Generated at 2022-06-24 01:06:38.095715
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    a = GeneralLedger(1)
    assert a.period == 1
    assert a.ledgers == {}

# Generated at 2022-06-24 01:06:48.333024
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from datetime import date
    from decimal import Decimal
    from operator import attrgetter
    from typing import List
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import LedgerEntry, Ledger, GeneralLedger, ReadInitialBalances, ReadJournalEntries
    from .ledgers.general import compile_general_ledger_program
    # Test data
    # Test accounts:
    _account_a = Account("A", AccountType.ASSET, "Asset account")
    _account_b = Account("B", AccountType.INCOME, "Income account")
    # Test journal entries:

# Generated at 2022-06-24 01:06:51.067994
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    print(Ledger(Account(1, "foo", "bar"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))))

# Generated at 2022-06-24 01:06:57.342217
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    @dataclass
    class Entry:
        pass
    entry = LedgerEntry(Ledger(account="A", initial=Balance('2019-01-01', 0)), Posting(Entry(), 1), 1)
    assert entry.__repr__() == "LedgerEntry(ledger=Ledger(account='A', initial=Balance(date='2019-01-01', value=0)), posting=Posting(journal=Entry(), amount=1), balance=1)"

# Generated at 2022-06-24 01:07:00.915490
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    print(ReadInitialBalances.__doc__)

# test_ReadInitialBalances()


# Generated at 2022-06-24 01:07:08.716303
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    A = Account("A", "A")
    L = Ledger(A, Balance(datetime.date(2018,1,1), Quantity(Decimal(0))))
    assert repr(L) == "Ledger(account=Account(code='A', name='A'), initial=Balance(date=datetime.date(2018, 1, 1), value=0.00))"

    E1 = LedgerEntry(L, Posting(None, A, Decimal(1.1), None), Quantity(Decimal(1.1)))
    E2 = LedgerEntry(L, Posting(None, A, Decimal(2.5), None), Quantity(Decimal(3.6)))
    L.entries.append(E1)
    L.entries.append(E2)

# Generated at 2022-06-24 01:07:16.267977
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """
    Unit test for method __eq__ of class Ledger
    """
    #Balance object
    balance = Balance(datetime.date.today(), Quantity(Decimal(0)))
    #Posting object
    j = JournalEntry(datetime.date.today(), "test_journal_entry")
    p1 = Posting(Account("test_acc1"), Quantity(Decimal(100)), j, Posting.Direction.debit)
    p2 = Posting(Account("test_acc1"), Quantity(Decimal(100)), j, Posting.Direction.credit)
    #Ledger objects
    l1 = Ledger(Account("test_acc1"), balance)
    l1.add(p1)
    l1.add(p2)
    l2 = Ledger(Account("test_acc1"), balance)
    l2

# Generated at 2022-06-24 01:07:18.809892
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    a = LedgerEntry(None, None, None)
    b = LedgerEntry(None, None, None)
    assert (a.__eq__(b))



# Generated at 2022-06-24 01:07:29.541596
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting

    from ..commons.zeitgeist import DateRange
    from .accounts import Account

    from ..commons.numbers import Amount
    from .generic import Balance

    def incr(a: Dict[Account, Balance], k, v):
        a[k] = Balance(k.date, a.get(k, Balance(k.date, 0)).value + v)

    # Compile general ledger program:

# Generated at 2022-06-24 01:07:36.916541
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    import datetime
    from decimal import Decimal
    from operator import attrgetter, itemgetter

    from .accounts import Account, AccountType
    from .commons.numbers import Amount
    from .generic import Debit, Balance
    from .journaling import Journal, Posting, JournalEntry, Direction
    from .mocks import MockAlgebra
    from .readers import JournalEntryReader
    from .types import JournalEntryType

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))


# Generated at 2022-06-24 01:07:40.699218
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert "GeneralLedger"

