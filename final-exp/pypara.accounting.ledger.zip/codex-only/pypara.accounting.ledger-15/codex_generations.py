

# Generated at 2022-06-24 00:57:43.284660
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert str(Ledger(1,2)) == "Ledger(1, 2, [])"


# Generated at 2022-06-24 00:57:52.727503
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    # We need to implement the algebras:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account(1, "A"): Balance(period.since, Quantity(Decimal(500))),
            Account(2, "B"): Balance(period.since, Quantity(Decimal(350))),
            Account(3, "C"): Balance(period.since, Quantity(Decimal(100))),
            Account(4, "D"): Balance(period.since, Quantity(Decimal(50))),
            Account(5, "E"): Balance(period.since, Quantity(Decimal(0))),
        }


# Generated at 2022-06-24 00:58:03.866721
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import today
    from .journaling import AccountBook
    (
        DemoAccountBook,
        demo_accounts,
        demo_period,
        read_initial_balances,
        read_journal_entries,
    ) = AccountBook.from_csv_file(
        "pyacc/tests/fixtures/demo_accounts.csv", "pyacc/tests/fixtures/demo_journal.csv"
    )
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    general_ledger = program(today())
    assert general_ledger.period == demo_period

# Generated at 2022-06-24 00:58:14.972391
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    accounts = [Account.from_string(acc_str) for acc_str in ("Assets:Bank:Checking", "Expenses:Food:Groceries")]
    amount = Amount(1000)

    posting = Posting(accounts[0], accounts[1], amount)
    ledger = Ledger(posting.account, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    entry = LedgerEntry(ledger, posting, Quantity(amount))


# Generated at 2022-06-24 00:58:20.107943
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from ..commons.zeitgeist import yesterday, today

    class JournalEntryStub1:
        def __init__(self, date):
            self.date = date
        def __eq__(self, other):
            return self.date == other.date

    class JournalEntryStub2:
        def __init__(self, date, descr):
            self.date = date
            self.descr = descr
        def __eq__(self, other):
            return self.date == other.date and self.descr == other.descr

    class JournalStub:
        def __init__(self, date, descr):
            self.date = date
            self.descr = descr
        def __eq__(self, other):
            return self.date == other.date and self.descr == other.descr

# Generated at 2022-06-24 00:58:28.775611
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from typing import Dict
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, TerminalAccount
    from .journaling import Entry, Posting, JournalEntry
    from .generic import Balance
    from .types import Asset, Expense, Liability
    from .ledgering import build_general_ledger

    # Prepare the data to test:
    initial_balances: Dict[Account, Balance] = {
        Asset("Equity", "Paid-in Capital"): Balance(datetime.date(1993, 1, 1), Decimal(100)),
        Liability("Long Term Liabilities", "Long Term Notes Payable"): Balance(datetime.date(1993, 1, 1), Decimal(200)),
    }

# Generated at 2022-06-24 00:58:30.705737
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert Ledger(None, None) == Ledger(None, None)

# Generated at 2022-06-24 00:58:33.314805
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest.mock import MagicMock

    mock = MagicMock()
    mock(1)
    mock.assert_called_once_with(1)



# Generated at 2022-06-24 00:58:45.266082
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from . import accounts
    from . import sample_domain

    l = build_general_ledger(
        DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 12, 31)),
        sample_domain.journal_example.get(),
        {
            accounts.Asset.bank_current_account: Balance(datetime.date(2016, 1, 1), Quantity(5000)),
            accounts.Liability.capital_account: Balance(datetime.date(2016, 1, 1), Quantity(10000)),
        },
    )

# Generated at 2022-06-24 00:58:49.072766
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def _read_initial_balances(period):
        return {}

    def _read_journal_entries(period):
        return []

    assert compile_general_ledger_program(_read_initial_balances, _read_journal_entries) == \
        compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

# Generated at 2022-06-24 00:58:55.948762
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    _T = TypeVar("_T")

# Generated at 2022-06-24 00:58:58.960090
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert repr(GeneralLedger(DateRange("2019-01-01", "2019-01-31"), {})) == "GeneralLedger(period=DateRange(since='2019-01-01', until='2019-01-31'), ledgers={})"


# Generated at 2022-06-24 00:59:00.246301
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    pass #TODO

# Generated at 2022-06-24 00:59:10.107381
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """
    from typing import Callable, List

    from ..commons.zeitgeist import Date

    from .accounts import Account

    from .journaling import JournalEntry, Posting

    ## -- Mocks --
    # Mocks the initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        initial_balances: InitialBalances = {}
        initial_balances[Account(code="1000")] = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
        initial_balances[Account(code="2000")] = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
        return initial_balances

    # Mock of a journal entry:

# Generated at 2022-06-24 00:59:17.454217
# Unit test for method add of class Ledger
def test_Ledger_add():
    test = Ledger(Account())
    test.initial = Balance(datetime.date(2019,12,30), Quantity(0))
    test.entries = []
    test.add(Posting(Account(), datetime.date(2019,12,30), Quantity(100), True))
    assert test.entries[-1].posting.amount == 100
    assert test.entries[-1].balance == 100
    test.add(Posting(Account(), datetime.date(2019,12,30), Quantity(100), False))
    assert test.entries[-1].posting.amount == 100
    assert test.entries[-1].balance == 0
    test.add(Posting(Account(), datetime.date(2019,12,31), Quantity(50), True))

# Generated at 2022-06-24 00:59:18.401248
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    raise NotImplementedError()


# Generated at 2022-06-24 00:59:22.963512
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    a = LedgerEntry(2, 'a')
    b = LedgerEntry(2, 'a')
    c = LedgerEntry(2, 'c')
    d = LedgerEntry(3, 'a')

    assert a == b
    assert a != c
    assert a != d


# Generated at 2022-06-24 00:59:34.749145
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import Posting, JournalEntry
    date = DateRange(since=datetime.date(1, 1, 1), until=datetime.date(1, 1, 3))
    initial_balances = {Account("Test"): Balance(date.since, Quantity(Decimal(0)))}
    journal = [JournalEntry(datetime.date(1, 1, 1), "Test", [Posting(Account("Test"), Amount(Decimal(100)), False)])]
    period = DateRange(since=datetime.date(1, 1, 1), until=datetime.date(1, 1, 1))

# Generated at 2022-06-24 00:59:44.488493
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    account1 = Account.get_instance('acc_1')
    account2 = Account.get_instance('acc_2')
    journal1 = JournalEntry('journal1', None, None)
    journal2 = JournalEntry('journal2', None, None)
    posting1 = Posting.debit(account1, journal1, Amount(10))
    posting2 = Posting.debit(account1, journal1, Amount(10))
    posting3 = Posting.debit(account1, journal1, Amount(11))
    posting4 = Posting.debit(account2, journal1, Amount(10))
    posting5 = Posting.debit(account1, journal2, Amount(10))
    posting6 = Posting.credit(account1, journal1, Amount(10))


# Generated at 2022-06-24 00:59:49.947308
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    my_reader_initial_balances: ReadInitialBalances = lambda period: {}
    my_reader_journal_entries: ReadJournalEntries = lambda period: []
    my_program: GeneralLedgerProgram = compile_general_ledger_program(my_reader_initial_balances, my_reader_journal_entries)
    assert(isinstance(my_program, GeneralLedgerProgram))

# Generated at 2022-06-24 00:59:59.424594
# Unit test for method add of class Ledger
def test_Ledger_add():
    #Given
    from ..commons.transactions import (OpeningBalance, Transaction)
    from ..commons.zeitgeist import Date as D
    journal_entry_1 = JournalEntry(
    D(2019,1,1),
    [
        Posting(Account("Cash"), OpeningBalance(D(2019,1,1), 1000), Amount(1000), 1),
        Posting(Account("Taxes Payable"), OpeningBalance(D(2019,1,1), 0), Amount(200), -1),
    ],
    Transaction("Opening Balance"),
    )

# Generated at 2022-06-24 01:00:10.031865
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Importing Posting and Quantity and DateRange
    from datetime import datetime
    from .journaling import Posting
    from .commons.numbers import Quantity, Amount
    from .commons.zeitgeist import DateRange

    # Importing mock's methods patch and call
    from unittest.mock import patch, call
    from datetime import datetime

    # Importing Account from accounts.py
    from .accounts import Account

    # Creating a Ledger for testing method add
    ledger = Ledger(Account("2150"), Balance(datetime.today(), Quantity(50)))

    # Creating a mock instance of Posting
    posting = Posting(datetime.today(), Quantity(30), 1)

    #Mocking get_account_balance
    mock_get_account_balance = patch("ledgers/api.get_account_balance")

# Generated at 2022-06-24 01:00:21.074816
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    initialBalances = InitialBalances(Account("100", "Cash"), Balance(datetime.date(2019, 1, 1), Quantity(100)))
    journal = JournalEntry("1002", datetime.date(2019, 1, 1), "Cash Received", [
        Posting(Account("100", "Cash"), Amount(100), Decimal(1)),
        Posting(Account("300", "Accounts Receivable"), Amount(100), Decimal(-1))
    ])
    general_ledger_instance = GeneralLedger(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1)), {})
    test_general_ledger = build_general_ledger(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1)), journal, initialBalances)
    assert general_

# Generated at 2022-06-24 01:00:24.672359
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    '''
    This method ensures that the ReadInitialBalances class
    '''
    try:
        ri = ReadInitialBalances()
        ri(1)
    except TypeError:
        pass


# Generated at 2022-06-24 01:00:30.981742
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from ..commons.test import (
        DecimalEquals,
        StringEquals
    )

    # First example of equality.
    e1 = LedgerEntry()
    e1.posting = Posting(True, "description", Amount(Decimal(10)), "2019-06-17")
    e1.balance = Quantity(Decimal(200))
    e2 = LedgerEntry()
    e2.posting = Posting(True, "description", Amount(Decimal(10)), "2019-06-17")
    e2.balance = Quantity(Decimal(200))

    assert(e1.__eq__(e2))
    assert(e2.__eq__(e1))
    # First example of inequality.
    e1 = LedgerEntry()

# Generated at 2022-06-24 01:00:43.024628
# Unit test for method add of class Ledger

# Generated at 2022-06-24 01:00:53.892298
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..triple_entry_bookkeeping import (
        initial_balances,
        journal_entries,
    )
    import datetime
    from ..commons.zeitgeist import DateRange
    #pylint: disable=W0612,E1120,E1101
    def _fake_read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("account_1"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
            Account("account_2"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(200))),
        }


# Generated at 2022-06-24 01:01:00.347461
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)), {
        'bank_account': Ledger(Account('bank_account'), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))})

# Generated at 2022-06-24 01:01:06.897177
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from datetime import date
    from .accounts import Account
    from .generic import Balance

    initial_balances = {
        Account("Cash"): Balance(date(2018, 1, 1), Quantity(Decimal(100))),
        Account("Bank"): Balance(date(2018, 1, 1), Quantity(Decimal(500))),
    }
    print("Initial balances:", initial_balances)

# Generated at 2022-06-24 01:01:12.437484
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Tests method __repr__ of class Ledger
    """
    # Set account
    account = Account()
    # Set initial balance
    initial = Balance()
    # Set ledger
    ledger = Ledger(account, initial)
    # Test method
    assert ledger.__repr__() == f"Ledger(account={account}, initial={initial}, entries=[])"

# Generated at 2022-06-24 01:01:13.413691
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"

# Generated at 2022-06-24 01:01:25.027098
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .quantity import Quantity
    from .balance import Balance
    from .accounts import Account
    from .journaling import Posting, JournalEntry

    account = Account("000-1000-2100-0100")
    initial = Balance(datetime.date(2020, 4, 1), Quantity(20))
    post = Posting(-1, account, Decimal('10'))
    journal = JournalEntry(datetime.date(2020, 4, 1), "Test", [post])
    ledger = Ledger(account, initial)

    ledger.add(post)

    entry = LedgerEntry(ledger, post, Quantity(10))

    assert(entry.ledger == ledger)
    assert(entry.posting == post)
    assert(entry.balance == Quantity(10))
    assert(entry.description == "Test")

# Generated at 2022-06-24 01:01:34.024710
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():

    @dataclass
    class Foo:
        pass

    account: Account = Account(code='01', name='Cash', category=None)
    account2: Account = Account(code='02', name='Cash2', category=None)

    journal1 = JournalEntry(date=datetime.datetime(2020, 1, 1), description='Journal1 - 2020-01-01')
    journal2 = JournalEntry(date=datetime.datetime(2020, 1, 2), description='Journal2 - 2020-01-02')

    foo1 = Foo()
    foo2 = Foo()

    posting1 = Posting(journal=journal1, account=account, amount=Amount(123), direction=1)
    posting2 = Posting(journal=journal2, account=account2, amount=Amount(456), direction=1)


# Generated at 2022-06-24 01:01:43.320122
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import typing

    import pytest

    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType, ReadAccounts
    from .journaling import ReadJournalEntries, JournalEntry
    from .posting_rules import PostingRules

    @dataclass
    class AccountBalance:
        account: Account
        balance: Balance

    @dataclass
    class AccountBudget:
        account: Account
        budget: Decimal

    @dataclass
    class AccountInitialBalance:
        account: Account
        balance: Decimal

    @dataclass
    class GeneralLedger(Generic[_T]):
        period: DateRange
        ledgers: Dict[Account, Ledger[_T]]

    @dataclass
    class JournalEntry(_T):
        pass


# Generated at 2022-06-24 01:01:51.005755
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    print("Testing the constructor of class LedgerEntry")
    ledger = Ledg("testingLedger",InitialBal("2017-02-01",Quantity("12.00")))
    j = Journal("2017-02-01","testingJournal")
    j.add("testAccount", Quantity("12.00"))
    entry = LedgerEntry(ledger,j.postings[0],Quantity("24.00"))
    assert entry.ledger == ledger
    assert entry.posting == j.postings[0]
    assert entry.balance == Quantity("24.00")


# Generated at 2022-06-24 01:02:00.034729
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-24 01:02:00.770187
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:02:02.131803
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert Ledger(Account(1), Balance(datetime.date.today(), Quantity(1))).__repr__()

# Generated at 2022-06-24 01:02:12.744088
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import dataclass
    from datetime import date
    from decimal import Decimal
    from typing import Any, Dict

    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting
    from .ledgers import read_initial_balances

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Defines a ledger.
    _LEDGER: Dict[Account, Balance] = {
        Account(1): Balance(date(2016, 12, 31), Decimal(1000)),
        Account(2): Balance(date(2016, 12, 31), Decimal(2000)),
        Account(3): Balance(date(2016, 12, 31), Decimal(3000)),
    }

    #: Defines a test data class.

# Generated at 2022-06-24 01:02:14.544797
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert callable(ReadInitialBalances) # check if ReadInitialBalances is a constructor callable object


# Generated at 2022-06-24 01:02:24.764812
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 01:02:37.296783
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    account_names = ['30000','50000','145400']
    test_postings = [
        Posting(
            date=datetime.date(2019, 4, 24),
            amount=Decimal('77.50'),
            account=account_names[0],
            direction=Debit
        ),
        Posting(
            date=datetime.date(2019, 4, 24),
            amount=Decimal('77.50'),
            account=account_names[1],
            direction=Credit
        ),
        Posting(
            date=datetime.date(2019, 4, 24),
            amount=Decimal('500.00'),
            account=account_names[2],
            direction=Credit
        )
    ]

# Generated at 2022-06-24 01:02:47.711220
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..commons.zeitgeist import date_range
    from ..testdata.asset_test_data import asset_test_data
    from .accounts import AccountType
    from .accounts import TerminalAccount

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        yield from iter(asset_test_data)

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return dict(
            [(TerminalAccount("1000", AccountType.ASSET), Balance(period.since, Quantity(Decimal("1000"))))]
        )

    period = date_range("2020-01-01", "2020-06-30")
    general_ledger = build_general_ledger(period, read_journal_entries(period), read_initial_balances(period))



# Generated at 2022-06-24 01:02:57.917957
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    import unittest
    from dataclasses import asdict
    from .assets import Assets
    from .cash_accounts import CashAccounts
    from .equity_accounts import EquityAccounts
    from .liabilities import Liabilities

    def _build_initial_balances(period: DateRange) -> InitialBalances:
        return {
            EquityAccounts.investments: Balance(period.since, Quantity(Decimal(0))),
            CashAccounts.cash: Balance(period.since, Quantity(Decimal(0))),
            Assets.inventory: Balance(period.since, Quantity(Decimal(0))),
            Liabilities.accounts_payable: Balance(period.since, Quantity(Decimal(0))),
        }


# Generated at 2022-06-24 01:03:09.240570
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .commons.testing import assert_repr
    from .journaling import JournalEntry, Posting
    from .types import Account, Atom
    from .units import Unit
    from .units.testing import release_units
    from .units.testing import register_units

    def _program(period: DateRange) -> GeneralLedger[Atom]:
        ## Get initial balances as of the end of previous financial period:
        initial_balances = {Account("FOO", "FOO"): Balance(period.since, Quantity(Decimal(0)))}

        ## Read journal entries and post each of them:

# Generated at 2022-06-24 01:03:16.484361
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ldg1 = Ledger(Account(1), Balance(datetime.date(2020,1,1),Quantity(1)))
    ldg1.add(Posting(datetime.date(2020,1,1), Account(1), Account(1), Quantity(1), "Description"))
    ldg2 = Ledger(Account(1), Balance(datetime.date(2020,1,2),Quantity(1)))
    ldg2.add(Posting(datetime.date(2020,1,2), Account(1), Account(1), Quantity(1), "Description"))
    assert ldg1.__eq__(ldg2) == False
    ldg2 = Ledger(Account(1), Balance(datetime.date(2020,1,1),Quantity(1)))

# Generated at 2022-06-24 01:03:26.700225
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account, AccountType
    from .generic import Balance, Quantity


# Generated at 2022-06-24 01:03:33.548889
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import TradingDate
    from .accounts import AccountDatabase
    from .codes import account_codes, currency_codes
    from .journaling import Journal

    db = AccountDatabase()

    a = db.account(account_codes.CASH)
    b = db.account(account_codes.EQUITY_SHAREHOLDERS_FUND)
    d = TradingDate(2020, 1, 1)
    e = Journal(d, "Initialize cash.")

    e.post(a, Decimal(100), currency_codes.USD)
    e.post(b, -Decimal(100), currency_codes.USD)

    journal = []
    journal.append(e)


# Generated at 2022-06-24 01:03:43.500055
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import pytest
    from ..books.algebra import ReadBooks

    def mock_read_initial_balances(
        period: DateRange, books: ReadBooks
    ) -> Dict[Account, Balance]:
        return {
            Account("Cash", "Assets"): Balance(period.since, Quantity(Decimal(100)))
        }


# Generated at 2022-06-24 01:03:50.899292
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    a1 = Account(1, "Cash", "Assets")
    a2 = Account(2, "Supplies", "Assets")
    a3 = Account(3, "Debtor", "Accounts receivable")
    a4 = Account(4, "Supplies Expense", "Expenses")
    a5 = Account(5, "Service Revenue", "Revenues")
    posting1 = Posting(a1, True, Decimal(100), "Receipt No. 1")
    posting2 = Posting(a2, True, Decimal(100), "Receipt No. 2")
    posting3 = Posting(a3, True, Decimal(200), "Invoice No. 1")
    posting4 = Posting(a4, False, Decimal(200), "Invoice No. 1")

# Generated at 2022-06-24 01:04:02.097913
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account("A"), Balance(datetime.date(year = 2019, month = 4, day = 4), Quantity(Decimal(0))))

    # Test for first transaction
    journal = JournalEntry(datetime.date(year = 2019, month = 4, day = 4), "TEST", "DEBIT", [Posting("D", Account("A"), Quantity(Decimal(500)))])
    posting = journal.postings[0]
    new_entry = ledger.add(posting)
    assert new_entry.ledger == ledger
    assert new_entry.posting == posting
    assert new_entry.balance == Quantity(Decimal(500))

    # Test for consecutive transactions

# Generated at 2022-06-24 01:04:03.800760
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:04:12.223772
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    class MockPosting:
        def __init__(self, date, amount):
            self.date = date
            self.amount = amount

    class MockLedger:
        def __init__(self, balance):
            self.initial = Balance(balance=balance)
            self.entries = [self]

        def __eq__(self, other):
            return self.initial.value == other.initial.value

        def __ne__(self, other):
            return self.initial.value != other.initial.value

    ledger = MockLedger(balance=1)
    posting = MockPosting(date=datetime.date.today(), amount=1)

    date_other = datetime.date.today() + datetime.timedelta(days=1)
    amount_other = 2

# Generated at 2022-06-24 01:04:20.873047
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .algebras import ReadInitialBalancesAlgebra
    from .models import InitialBalance
    from .setup import from_file
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange

    def test_scenario_1():
        def test_setup():
            # Main
            path = './setup/my_accounting_subsystem'
            system = from_file(path)
            terminal_accounts = ['1001', '1002']
            terminal_accounts_set = frozenset(terminal_accounts)
            # Algebra
            algebra = system.algebras.read_initial_balances
            assert isinstance(algebra, ReadInitialBalancesAlgebra)
            # Operation
           

# Generated at 2022-06-24 01:04:30.474420
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from ..interfaces import ReadInitialBalances, ReadJournalEntries, core
    from ..commons.zeitgeist import DateRange

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        """
        :param period: Accounting period.
        :return: Initial balances for the period.
        """
        return {
            core.Accounts.Equity: Balance(period.since, Quantity(Decimal(1000))),
            core.Accounts.Base: Balance(period.since, Quantity(Decimal(1000))),
            core.Accounts.Cash: Balance(period.since, Quantity(Decimal(1000))),
        }


# Generated at 2022-06-24 01:04:33.933302
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    '''
    Checks the functionality of constructor of class ReadInitialBalances.
    '''
    ## Create an instance of class ReadInitialBalances
    read=ReadInitialBalances()
    assert read   # if no exception raised then test passed


# Generated at 2022-06-24 01:04:40.360702
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(id=1, desc="Test Account")
    initial = Balance(date=datetime.date.today(), value=Quantity(1))
    entries = [LedgerEntry(ledger=None, posting=None, balance=Quantity(1))]
    l = Ledger(account=account, initial=initial, entries=entries)
    assert l.account == account
    assert l.initial == initial
    assert l.entries == entries


# Generated at 2022-06-24 01:04:48.232232
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from datetime import date
    from .journaling import Journal, Posting, JournalEntry, ReadJournalEntries
    from .accounts import Account
    from ..commons.numbers import Amount
    from . import AccountClass, AccountType
    from .systems import AccountSystem

    def read_initial_balances(period : DateRange) -> Dict[Account, Balance]:
        return {
            Account("111111", AccountType(AccountClass.ASSET, 0), AccountClass.ASSET): Balance(period.since, Amount(10)),
            Account("211111", AccountType(AccountClass.ASSET, 1), AccountClass.ASSET): Balance(period.since, Amount(10))
        }

    def read_journal_entries(period: DateRange):
        account_system = AccountSystem()

# Generated at 2022-06-24 01:04:56.257157
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Unit test case for constructor of class Ledger
    """
    # Create an Account object
    account = Account(code="1001", name="Cash")

    # Create a Balance object
    balance = Balance(date=datetime.date(2019, 1, 1), value=Quantity(Decimal(0)))

    # Create a Ledger object
    ledger = Ledger(account, balance)

    # Check the values
    assert ledger.account == account
    assert ledger.initial == balance
    assert ledger.entries == []


# Generated at 2022-06-24 01:04:59.159482
# Unit test for constructor of class Ledger
def test_Ledger():
    t1 = Ledger(Account("t1"),Balance(datetime.date(2020,3,14),Decimal(10)))
    assert t1.account == Account("t1")
    assert t1.initial == Balance(datetime.date(2020,3,14),Decimal(10))
    assert t1.entries == []
    assert t1._last_balance == Decimal(10)


# Generated at 2022-06-24 01:05:10.694808
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Create test data and general ledger
    from ..domain import business as B, commons as C, data
    from ..domain.algebra import algebra
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .general_ledger import GeneralLedger
    from .generic import Balance
    

# Generated at 2022-06-24 01:05:22.530039
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journals import JournalEntry
    from .accounts import Account, is_terminal
    from .commons.zeitgeist import quarter_of, month_of

    ## Create general ledger for the first quarter of 2018:
    open_date = datetime.date(2018, 1, 1)
    close_date = datetime.date(2018, 3, 31)
    period = quarter_of(2018, 1)

    ## Create three journal entries:
    "Example taken from 'QuickBooks 2019 All-in-One For Dummies' by Stephen L. Nelson, page 283"

    ## Opening balances:

# Generated at 2022-06-24 01:05:30.620967
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import now
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    # define test data
    account=Account(code="Ledger-testaccount", name="Ledger-testaccount", accountType=AccountType.EXPENSES,is_terminal=True)
    journal=JournalEntry(date=now(), description="Ledger-test-entry", postings=[Posting(account=account, amount=100, direction=1)])
    initial=Balance(date=now(), value=100)
    ledger=Ledger(account=account,initial=initial)
    posting=journal.postings[0]
    entry=ledger.add(posting)
    assert entry.balance==200
    assert ledger.initial.value==100
    assert ledger.balance()==200

# Generated at 2022-06-24 01:05:40.591044
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    account1 = Account("a", "a", Account.Types.ASSET, True)
    account2 = Account("b", "b", Account.Types.ASSET, True)
    ledger1 = Ledger(account1, Balance(datetime.date(2015, 1, 1), Quantity(10.0)))
    ledger2 = Ledger(account2, Balance(datetime.date(2015, 1, 1), Quantity(10.0)))
    journal = JournalEntry(datetime.date(2015, 1, 1), "descr", [Posting(True, account1, 100.0)])
    posting1 = Posting(True, account1, 100.0)
    posting2 = Posting(True, account2, 100.0)
    balance1 = Quantity(10.0)
    balance2 = Quantity(15.0)
    
    ## Create

# Generated at 2022-06-24 01:05:45.854566
# Unit test for constructor of class Ledger
def test_Ledger():
    Account('110', 'Cash')
    Balance(datetime.date(2019, 6, 1), Quantity(Decimal(1000)))
    entry = Posting(datetime.date(2019, 6, 1), '110', 'Debit', Amount(Decimal(100.0)))
    entry = Ledger('110', 'Cash', Balance(datetime.date(2019, 6, 1), Quantity(Decimal(1000))))
    return entry


if __name__ == "__main__":
    test_Ledger()

# Generated at 2022-06-24 01:05:55.914177
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..ledger.journaling import Journal

    assert (
        repr(
            LedgerEntry(
                Ledger(Account("A"), Balance(datetime.date(2019, 1, 1), Quantity(100))),
                Posting(Account("A"), Amount(100), Journal(datetime.date(2019, 1, 1), "")),
                Quantity(100),
            )
        )
        == "LedgerEntry(ledger=Ledger(account=Account(code='A'),initial=Balance(date=datetime.date(2019, 1, 1),value=Quantity(100))),posting=Posting(account=Account(code='A'),amount=Amount(100),journal=Journal(date=datetime.date(2019, 1, 1),description='')),balance=Quantity(100))"
    )

# Generated at 2022-06-24 01:06:03.937831
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Arrange
    period = DateRange(datetime.date(2019, 2, 1), datetime.date(2019, 2, 28))
    general_ledger = GeneralLedger(period, {})
    read_initial_balances = lambda _: {}
    read_journal_entries = lambda _: []

    # Act
    result = compile_general_ledger_program(read_initial_balances, read_journal_entries)(period)

    # Assert
    assert result == general_ledger

# Generated at 2022-06-24 01:06:12.160980
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    import os, sys
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir))
    from generalledger import GeneralLedger
    from tests.gl_tests import make_gl_ledgers_for_repr_test as make_gl_ledgers
    gl = GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 2, 1)), make_gl_ledgers())

# Generated at 2022-06-24 01:06:20.873934
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from unittest import TestCase
    from .accounts import AccountType

    ## Define test data:
    since = datetime.date(2019, 12, 1)
    until = datetime.date(2020, 1, 31)
    period = DateRange(since, until)

# Generated at 2022-06-24 01:06:31.181402
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from ..modules.accounts.hierarchy import AccountHierarchy
    from ..modules.accounting.metrics import AccountMetrics
    from ..modules.accounting.metrics import JournalMetrics
    from ..modules.accounting.metrics import PostingDirection
    from ..modules.accounting.types import Journal
    from ..modules.accounting.types import Posting
    from ..modules.accounts.types import EquityAccount
    from ..modules.accounts.types import RevenueAccount

    hierarchy = AccountHierarchy(1, "H1", None, 0)
    equity = EquityAccount(1, "Equity", hierarchy)
    revenue = RevenueAccount(1, "Revenue", hierarchy)


# Generated at 2022-06-24 01:06:33.700749
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger


# Generated at 2022-06-24 01:06:42.320128
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # Initialize a dictionary for initial balances.
    test_initial_balances = {
        "aset": Balance(datetime.date(1, 1, 1), Quantity(0)),
        "liability": Balance(datetime.date(1, 1, 1), Quantity(0))
    }
    assert ReadInitialBalances(test_initial_balances) == {
        "aset": Balance(datetime.date(1, 1, 1), Quantity(0)),
        "liability": Balance(datetime.date(1, 1, 1), Quantity(0))
    }


# Generated at 2022-06-24 01:06:50.897884
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from datetime import date
    from .journaling import Journal, Posting
    from .accounting import Account, Balance

    test_date = date(2020,12,2)
    test_account = Account("502000", "Cash")
    test_balance = Balance(test_date, Quantity(1))
    test_posting = Posting(test_account, 1)
    test_journal = Journal("test_Journal",[test_posting],test_date,"test_Journal")

    test_posting2 = Posting(test_account, 1)
    test_journal2 = Journal("test_Journal",[test_posting2],test_date,"test_Journal")

    test_GL1 = GeneralLedger(DateRange(test_date),{test_account: Ledger(test_account,test_balance)})
    test_GL2

# Generated at 2022-06-24 01:06:55.090819
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    #Dummy implementation
    def _read_initial_balances(period: DateRange):
        return {}
    read_initial_balances = _read_initial_balances
    assert isinstance(read_initial_balances, ReadInitialBalances)


# Generated at 2022-06-24 01:07:03.283248
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import Journal, Posting

    ## Define accounts:
    cash = Account("11", "Cash", True)
    accounts_receivable = Account("21", "Accounts Receivable", True)
    sales = Account("41", "Sales", True)
    accounts_payable = Account("52", "Accounts Payable", True)
    cost_of_sales = Account("61", "Cost of Sales", True)

    ## Define initial balances:
    initial_balances = {
        cash: Balance(datetime.date(2019, 1, 1), Quantity(100.00)),
    }

    ## Define journal entries:

# Generated at 2022-06-24 01:07:06.198820
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("1111")
    balance = Balance(datetime.date(2019, 2, 1), Quantity(Decimal(1000)))
    ledger = Ledger(account, balance)
    assert ledger.account.code == "1111"
    assert ledger.initial == balance



# Generated at 2022-06-24 01:07:15.337948
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    test__object = datetime.date(2020, 2, 24)
    test_ledger = Ledger(Account("1010", "Test account", Balance(test__object, Quantity(Decimal(0)))), Balance(test__object, Quantity(Decimal(0))))
    test_posting = Posting(JournalEntry(test__object, "Test journal entry", [Posting(Account("2020", "Test account 2", Balance(test__object, Quantity(Decimal(0)))), Quantity(Decimal(0)), Posting.Direction.CREDIT)]), Account("1010", "Test account", Balance(test__object, Quantity(Decimal(0)))), Quantity(Decimal(0)), Posting.Direction.DEBIT)
    test_balance = Quantity(Decimal(0))

# Generated at 2022-06-24 01:07:20.939099
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateTime
    from .accounts import Cash, Expense
    from .journaling import Journal
    from .types import Zero
    l = Ledger(Cash, Balance(DateTime(2020,1,1), Quantity(Decimal('0'))))
    j = Journal(
        date=DateTime(2020,1,1),
        description='Test journal',
        postings=(
            Posting(
                date=DateTime(2020,1,1),
                account=Cash,
                amount=Amount(Decimal('1000'))
            ),
            Posting(
                date=DateTime(2020,1,1),
                account=Expense,
                amount=Amount(Decimal('1000'))
            )
        ),
        reference=Zero
    )
    posting = j.postings[0]
   

# Generated at 2022-06-24 01:07:31.319209
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import IncomeStatementAccount, journal_entry
    from .journaling import PostingDirection, RealAccount
    from ..commons.zeitgeist import timestamp, DateRange
    # account = Account(RealAccount.CurrentAssets, IncomeStatementAccount.Assets, "Cash")
    # period = DateRange(timestamp("2020-01-01"), timestamp("2020-12-31"))
    # j = journal_entry(
    #     date=period.since,
    #     description="test",
    #     transactions={"Cash": (PostingDirection.Debit, 1000)},
    # )
    # initial = {account: Balance(period.since, Quantity(Decimal(1000)))}
    # ledger = build_general_ledger(period, [j], initial)
    # assert ledger.ledgers[account].entries[0

# Generated at 2022-06-24 01:07:39.117168
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.types import Booking
    from ..commons.zeitgeist import now

    a = Account(1, 'name', 'title', 'code', 'desc')
    b = Balance(now(), Quantity(0))
    l = Ledger(a, b)

    j = Booking(now(), 'tt', '', '', [])
    p = Posting(j, a, '', 1, Quantity(10))
    l.add(p)

    assert isinstance(l, Ledger)
    assert l.entries[0].balance == Quantity(10)

# Generated at 2022-06-24 01:07:45.124660
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from . import accounts
    from .algebra import (
        Algebra,
        balance_on,
        build_algebra,
        build_journal,
        by_account,
        by_account_then_date,
        by_date_then_account,
        junction,
        sort,
    )
    from .domain import make_currency_unit
    from ..commons import Money

    ## Build algebra.
    general_ledger_algebra = build_algebra({
        'initial_balances': by_account >> sort(by_account_then_date),
        'journal_entries': by_account >> sort(by_date_then_account)
    })

    ## Define a reference date.
    date = datetime.date(2020, 8, 29)

    ## Define accounts.