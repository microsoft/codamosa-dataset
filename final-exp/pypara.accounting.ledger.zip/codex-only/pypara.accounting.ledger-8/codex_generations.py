

# Generated at 2022-06-24 00:57:39.838834
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-24 00:57:45.595104
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    def return_initial_balances():
        return {'Account1': Balance(datetime.date(2000, 1, 1), 2), 'Account2': Balance(datetime.date(2000, 1, 1), 5)}

    assert return_initial_balances() == {'Account1': Balance(datetime.date(2000, 1, 1), 2), 'Account2': Balance(datetime.date(2000, 1, 1), 5)}

# Generated at 2022-06-24 00:57:46.693921
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    pass


# Generated at 2022-06-24 00:57:47.075788
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert True == True

# Generated at 2022-06-24 00:57:52.929728
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .accounts import Account

    from .journaling import JournalEntry, Posting, Direction

    from .commons import Quantity, Amount

    account1 = Account(1, "Account 1")
    account2 = Account(2, "Account 2")
    account3 = Account(3, "Account 3")
    account4 = Account(4, "Account 4")

    journal_entry1 = JournalEntry(
        datetime.date(2017, 1, 1),
        [
            Posting(account1, Direction.Debit, Amount(2)),
            Posting(account2, Direction.Credit, Amount(2)),
            Posting(account3, Direction.Credit, Amount(2)),
        ],
    )

# Generated at 2022-06-24 00:58:04.112345
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, TerminalAccount
    from .journals import Journal, ReadJournals

    # Create some accounts:
    a = TerminalAccount("A", "Checking account")
    b = TerminalAccount("B", "Savings account")
    c = TerminalAccount("C", "Credit card")
    d = TerminalAccount("D", "Miscellaneous")

    # Create a journal
    j = Journal(date=datetime.date(2019, 9, 5), description="This is a journal entry")

    # Create some entries
    j.credit(a, Amount(25))
    j.debit(b, Amount(25))
    j.debit(c, Amount(25))
    j.credit(d, Amount(25))


# Generated at 2022-06-24 00:58:15.158313
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount
    from decimal import Decimal
    from ..commons.numbers import Quantity

    generalLedger1=GeneralLedger(DateRange(date(2016, 1, 1), date(2018, 1, 1)), {Account.get_account_by_id('2200'): Ledger(Account.get_account_by_id('2200'), Balance(date(2016, 1, 1), Quantity(Decimal('6000000'))))})


# Generated at 2022-06-24 00:58:19.628660
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Test: Test the bare constructor of GeneralLedger and all its attributes
    #       Test: you can create a GeneralLedger object using the bare constructor
    #       Test: the attributes of the object created are exactly what you passed
    theDate = datetime.date(2018, 1, 1)
    theRange = DateRange(theDate, theDate)
    ledger = GeneralLedger(theRange, {})
    assert ledger.period == theRange
    assert ledger.ledgers == {}


# Generated at 2022-06-24 00:58:20.549836
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass


# Generated at 2022-06-24 00:58:30.088597
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .accounts import Account
    from .journaling import JournalEntry
    from datetime import date

    journal_entries = [
        JournalEntry(
            date(2019, 9, 1),
            "Cash received from customer",
            [
                Posting(Account("110 Cash"), 1000, False),
                Posting(Account("210 Accounts receivable"), -1000, True),
            ],
        ),
    ]

    period = DateRange(date(2019, 8, 1), date(2019, 9, 1))

    initial_balances = {
        Account("110 Cash"): Balance(date(2019, 8, 1), 1000),
        Account("210 Accounts receivable"): Balance(date(2019, 8, 1), 2000),
    }

    general_ledger = build_general_ledger(period, journal_entries, initial_balances)

# Generated at 2022-06-24 00:58:38.561849
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Basic test for method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import from_date, to_date
    from .journaling import JournalEntry, Posting

    ## Assert the method provides a closure.
    class ReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return dict()

    class ReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    program = compile_general_ledger_program(ReadInitialBalances(), ReadJournalEntries())

    ## Test basic:
    program(DateRange(from_date(2019, 1, 1), to_date(2019, 12, 31)))

# Generated at 2022-06-24 00:58:39.688570
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert False

# Generated at 2022-06-24 00:58:49.946423
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Test method add of class Ledger
    """
    from .journaling import Journal, Posting
    from .accounts import Account

    # Create a Ledger
    ledger = Ledger(Account("100"), Balance(datetime.date(2020, 10, 1), Quantity(Decimal(100))))

    # Add a posting to the ledger

# Generated at 2022-06-24 00:58:58.694526
# Unit test for method add of class Ledger
def test_Ledger_add():
    '''
    tests the add method of class Ledger
    '''
    a = Account('a')
    b = Account('b')

    a_posting = Posting(a, 10)
    b_posting = Posting(b, 20)

    a_posting.setDirection(1)
    b_posting.setDirection(-1)

    a_posting.setDate(datetime.date(2020,4,3))

    a_ledger = Ledger(a,Balance(datetime.date(2020,4,2),5))

    a_entry = LedgerEntry(a_ledger,a_posting,5+10)
    a_entry2 = LedgerEntry(a_ledger,b_posting,5+10-20)



# Generated at 2022-06-24 00:59:09.740303
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Imports:
    from unittest.mock import call, MagicMock

    # Locals:
    period = DateRange(since=datetime.date(2016, 6, 1), until=datetime.date(2016, 6, 30))

    read_initial_balances = MagicMock()
    read_initial_balances.return_value = {}
    read_journal_entries = MagicMock()
    read_journal_entries.return_value = []

    compiled_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # perform the test:
    compiled_program(period)

    # verify calls:
    read_initial_balances.assert_has_calls([call(period)])
    read_journal_entries.assert_has_calls

# Generated at 2022-06-24 00:59:14.745336
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    test_posting = Posting(None, None, None, None)
    test_balance = Quantity(None)
    test_ledger = Ledger(None, None)
    test_ledger_entry = LedgerEntry(test_ledger, test_posting, test_balance)
    assert test_ledger_entry.balance == test_balance
    assert test_ledger_entry.ledger == test_ledger
    assert test_ledger_entry.posting == test_posting


# Generated at 2022-06-24 00:59:18.993493
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import LedgerEntry
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting

    print(LedgerEntry)
    print(Account)
    print(Balance)
    print(Posting)
    gl = LedgerEntry(Account, Balance, Posting)
    print(gl)
    return gl

# Generated at 2022-06-24 00:59:30.852069
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import unittest
    import collections
    import datetime as dt

    from money import Money
    from dateutil.tz import tzutc

    
    @dataclass
    class MoneyJournalEntry:
        """
        Provides a journal entry model.
        """

        #: Date of the journal entry.
        date: dt.date

        #: Description of the journal entry.
        description: str

        #: Journal entry postings.
        postings: collections.Iterable["MoneyPosting"]

        @property
        def first_posting(self) -> "MoneyPosting":
            """
            First posting of the journal entry.
            """
            return next(iter(self.postings))

        def __iter__(self):
            return self.postings.__iter__()



# Generated at 2022-06-24 00:59:40.038567
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Test case 1
    ledger1 = Ledger(1, initial=Balance(since=datetime.date.today(), value=10))
    ledger2 = Ledger(1, initial=Balance(since=datetime.date.today(), value=10))
    assert ledger1 == ledger2

    # Test case 2
    ledger1 = Ledger(1, initial=Balance(since=datetime.date.today(), value=10))
    ledger2 = Ledger(1, initial=Balance(since=datetime.date.today(), value=10))
    assert ledger1 != ledger2

    # Test case 3
    ledger1 = Ledger(1, initial=Balance(since=datetime.date.today(), value=10))
    ledger2 = Ledger(1, initial=Balance(since=datetime.date.today(), value=20))
    assert ledger

# Generated at 2022-06-24 00:59:41.013437
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 00:59:51.732244
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..finance.books import books
    from ..finance.journaling import read_journal_entries
    from ..finance.accounting import read_initial_balances, build_trial_balance

    date_range = DateRange(since=datetime.date(2019, 12, 1), until=datetime.date(2019, 12, 31))

    books = books(date_range)
    initial_balances = read_initial_balances(books, date_range)
    journal_entries = read_journal_entries(books, date_range)
    trial_balance = build_trial_balance(books, date_range)

    general_ledger = build_general_ledger(date_range, journal_entries, initial_balances)

    # import pdb; pdb.set_trace()


# Generated at 2022-06-24 01:00:00.029354
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
  date1=datetime.date(2020, 1, 1)
  date2=datetime.date(2020, 1, 31)
  dr=DateRange(date1,date2)
  dict1={'Account1':Balance(date1,Quantity(Decimal(1))),'Account2':Balance(date1,Quantity(Decimal(2))),'Account3':Balance(date1,Quantity(Decimal(3))),'Account4':Balance(date1,Quantity(Decimal(4))),'Account5':Balance(date1,Quantity(Decimal(5)))}

# Generated at 2022-06-24 01:00:06.114680
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from moneyflow.commons.zeitgeist import Datum, DateRange

    @dataclass
    class Entry:
        pass

    @dataclass
    class A:
        pass

    # Create a general ledger
    period = DateRange(Datum(2020, 1, 1), Datum(2020, 12, 31))
    ledgers = {A(): Ledger(A(), Balance(period.since, Quantity(1000000)))}
    ledgers[A()].add(Posting(A(), Entry(), 1, period.since))

    gl = GeneralLedger(period, ledgers)

    # Print the resulting string
    print(gl.__repr__())

    # Result must be a string and can't be None
    assert gl.__repr__() is not None

    # Result must be a string and can't be None
    assert gl

# Generated at 2022-06-24 01:00:12.378948
# Unit test for method add of class Ledger
def test_Ledger_add():
    #account
    account = Account(title="test",parent_account=1,account_type="bank")
    #initial
    balances = Balance(period.since, Quantity(Decimal(0)))
    #ledger
    ledger = Ledger(account, balances)
    entries = []
    
    #Posting
    #Journal
    journal_entry = JournalEntry(date=datetime.date(2020,1,1),description="test",postings=[posting])
    #Posting
    posting = Posting(account=account,amount=5,direction=1)
    entries.append(LedgerEntry(ledger, posting, Quantity(ledger._last_balance + posting.amount * posting.direction.value)))
    
    
    print(entries)
    #assert ledger.entries == entries 
    assert True

# Generated at 2022-06-24 01:00:23.379225
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert (
        repr(
            GeneralLedger(
                DateRange(datetime.date(2017, 1, 2), datetime.date(2017, 12, 31)),
                {
                    Account("10100"): Ledger(
                        Account("10100"), Balance(datetime.date(2017, 1, 1), Quantity(Decimal("100.00")))
                    )
                },
            )
        )
        == "GeneralLedger(period=DateRange(since=datetime.date(2017, 1, 2), until=datetime.date(2017, 12, 31)), ledgers={Account('10100'): Ledger(account=Account('10100'), initial=Balance(date=datetime.date(2017, 1, 1), value=Quantity(Decimal('100.00'))), entries=[])})"
    )

# Generated at 2022-06-24 01:00:25.445606
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger(DateRange(datetime.date.today(),datetime.date.today()), {'Account' : 'Ledger'})

# Generated at 2022-06-24 01:00:31.499267
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account1 = Account("N", "Test Account 1")
    account2 = Account("N", "Test Account 2")
    account3 = Account("L", "Test Account 3")
    account4 = Account("A", "Test Account 1")
    account5 = Account("L", "Test Account 1")
    account6 = Account("L", "Test Account 1")
    account6.parent = account5

    balance1 = Balance(datetime.date(2019, 9, 30), Quantity(1000))
    balance2 = Balance(datetime.date(2019, 9, 30), Quantity(2000))

    ledger1 = Ledger(account1, balance1)
    ledger2 = Ledger(account2, balance1)
    ledger3 = Ledger(account3, balance1)

    ledger4 = Ledger(account4, balance1)
    ledger5 = Ledger

# Generated at 2022-06-24 01:00:43.065564
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ddddd.commons.zeitgeist import Date

    from .accounts import Account, TerminalAccount
    from .journaling import JournalEntry, Posting, Transaction

    ## Initialization
    ledger = Ledger(TerminalAccount(100), Balance(Date(2020, 1, 1), Quantity(0)))
    account = TerminalAccount(101)
    transaction = Transaction(Date(2020, 1, 2), 'test')
    transaction.add(Posting(account, Amount(10), True))
    journal = JournalEntry.from_transaction(transaction)
    posting = journal.postings[0]

    ## add _T
    ledger = Ledger(TerminalAccount(100), Balance(Date(2020, 1, 1), Quantity(0)))
    account = TerminalAccount(101)
    transaction = Transaction(Date(2020, 1, 2), 'test')

# Generated at 2022-06-24 01:00:52.561827
# Unit test for constructor of class Ledger
def test_Ledger():
    # Test the constructor of class Ledger
    acc = Account(1, "acc", "acc", "acc")
    bal = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    entries = [LedgerEntry(None, Posting(acc, "desc", datetime.date(2020, 1, 1), Quantity(Decimal(1))), Quantity(Decimal(1)))]
    ledger = Ledger(acc, bal)
    assert ledger.account == acc
    assert ledger.initial == bal
    assert ledger.entries == []
    assert ledger._last_balance == Decimal(0)


# Generated at 2022-06-24 01:01:02.415304
# Unit test for method add of class Ledger
def test_Ledger_add():
    from . import _account
    a = _account.Account(1, 'ABC', None)
    l = Ledger(a, Balance(datetime.date(2020,1,1), Quantity(0)))
    from .journaling import Direction, Journal
    from .accounts import Account as c
    from .commons.numbers import Amount
    p = Posting(Direction.debit, datetime.date(2020,1,1), c('2', 'DEF', None), Amount(10.0), Journal('1', 'ABC', 'DEF', p))
    l.add(p)
    assert l.entries[0].posting.description == 'ABC'


# Generated at 2022-06-24 01:01:06.669207
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    a = GeneralLedger(
        period=DateRange(since=datetime.date(2020,1,1),until=datetime.date(2020,12,31)),
        ledgers = {'HEI': 2}
    )
    assert a.period.since == datetime.date(2020,1,1)
    assert a.period.until == datetime.date(2020,12,31)
    assert a.ledgers == {'HEI': 2}


# Generated at 2022-06-24 01:01:18.200812
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account(1,"act1",True)
    
    initial = Balance(date=Decimal(20100101),value=Decimal(1))
    initial_copy = Balance(date=Decimal(20100101),value=Decimal(1))
    
    ledger = Ledger(account,initial)
    
    # a Ledger and itself should be equal
    assert ledger == ledger
    
    # a Ledger and a different Ledger should not be equal
    account2 = Account(2,"act_2",False)
    ledger2 = Ledger(account2,initial_copy)
    assert ledger != ledger2
    
    # test for Ledger's account and initial attributes
    ledger.entries = [1,2,3]
    ledger_diff_acc = Ledger(account2,initial)
    ledger_diff_acc.ent

# Generated at 2022-06-24 01:01:29.436680
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    test_posting = Posting(
        Account("Test account"),
        Quantity(Decimal(0)),
        Quantity(Decimal(0)),
        datetime.date(2018, 12, 17),
        True,
        JournalEntry(
            "Test journal entry",
            datetime.date(2018, 12, 17),
            [Posting(
                Account("Test account"),
                Quantity(Decimal(0)),
                Quantity(Decimal(0)),
                datetime.date(2018, 12, 17),
                True,
            )]
        )
    )
    test_ledger = Ledger(test_posting.account, Balance(datetime.date(2018, 12, 17), Quantity(Decimal(0))))

# Generated at 2022-06-24 01:01:36.979245
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Arrange
    class MockPosting(Posting):
        def __init__(self):
            self.account = Account(1, "")
            self.amount = Amount(Decimal(10))
            self.date = datetime.date(2020, 1, 1)
            self.direction = MockDirection()

        def __repr__(self) -> str:
            return ""

    posting = MockPosting()

    class MockLedger:
        def __init__(self):
            self.account = Account(1, "")

        def __repr__(self) -> str:
            return ""

    ledger = MockLedger()

    # Act
    ledger_entry = LedgerEntry(ledger, posting, Quantity(Decimal(10)))

    # Assert

# Generated at 2022-06-24 01:01:39.881043
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-24 01:01:49.940724
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..journaling import create_journal_entry
    from .accounts import AccountTree
    from datetime import date

    journal = create_journal_entry(
        date(2019, 10, 1),
        "Record expense amount of $10,000.00",
        [("Expenses:Operating", 10000.00), ("Assets:Cash", -10000.00)],
    )
    accounts = AccountTree.load("../configuration/accounts.yml")

    initial = {}
    initial[accounts["Assets:Cash"]] = Balance(date(2019, 9, 1), Quantity(Decimal(0)))
    initial[accounts["Expenses:Operating"]] = Balance(date(2019, 9, 1), Quantity(Decimal(0)))


# Generated at 2022-06-24 01:01:52.606963
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    le1 = LedgerEntry(account=None, posting=Posting(date=datetime.date(2018, 1, 1), journal=None, account=None, amount=0,
                                                    direction=None), balance=0)
    le2 = LedgerEntry(account=None, posting=Posting(date=datetime.date(2018, 1, 1), journal=None, account=None, amount=0,
                                                    direction=None), balance=0)
    assert le1 == le2



# Generated at 2022-06-24 01:02:03.224471
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Setup
    from datetime import date
    from ..commons.zeitgeist import FullYear
    from .journaling import JournalEntry, Posting, JournalEntryType

    period = FullYear(2020)
    initial_balances = {
        "0000": Balance(period.since, Quantity(Decimal(0))),
        "1000": Balance(period.since, Quantity(Decimal(1000))),
        "2000": Balance(period.since, Quantity(Decimal(2000))),
    }


# Generated at 2022-06-24 01:02:14.166187
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange

    class MyReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            from .accounts import Account
            from .generic import Balance
            from datetime import date
            from typing import Dict, Optional

            InitialBalances = Dict[Account, Balance]

            return {Account("test"): Balance(date(2000, 1, 1), Quantity(Decimal(0)))}

    myReadInitialBalances = MyReadInitialBalances()
    result = myReadInitialBalances(DateRange(date(2000, 1, 1), date(2000, 1, 1)))
    expected = {Account("test"): Balance(date(2000, 1, 1), Quantity(Decimal(0)))}
    assert result == expected


# Generated at 2022-06-24 01:02:18.653983
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert "LedgerEntry" in LedgerEntry.__repr__.__qualname__
    assert "<ledger>" in LedgerEntry.__repr__.__qualname__
    assert "<posting>" in LedgerEntry.__repr__.__qualname__
    assert "balance=" in LedgerEntry.__repr__.__qualname__

# Generated at 2022-06-24 01:02:24.654990
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Initializing variables
    read_initial_balances = None
    read_journal_entries = None
    # Testing constructor
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    # Testing that program is callable
    output = program()
    # Testing that output is of type GeneralLedger
    if(isinstance(output, GeneralLedger)):
        print("Success")
    else:
        print("Failed")


# Generated at 2022-06-24 01:02:32.159298
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from decimal import Decimal
    from datetime import date
    from typing import Dict, List, Optional, TypeVar
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting, GeneralLedger
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

# Generated at 2022-06-24 01:02:37.697276
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    testL = LedgerEntry(ledger=Ledger, posting=Posting, balance=Balance(date=datetime.datetime, value=Decimal))
    expected = "LedgerEntry(ledger=Ledger, posting=Posting, balance=Balance(date=datetime.datetime, value=Decimal))"
    assert testL.__repr__() == expected


# Generated at 2022-06-24 01:02:39.001307
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-24 01:02:48.227212
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    a1 = Account.get_account('A1')
    a2 = Account.get_account('A2')
    a3 = Account.get_account('A3')

    dt0 = datetime.date(2019, 11, 1)
    dt1 = datetime.date(2019, 12, 1)
    dt2 = datetime.date(2019, 12, 31)
    dt3 = datetime.date(2020, 1, 1)

    p0 = DateRange(dt0, dt2)
    p1 = DateRange(dt1, dt2)

    j0 = JournalEntry(dt0, 'j0', [Posting(a1, -1), Posting(a2, 1)])

# Generated at 2022-06-24 01:02:58.012494
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ledger.read import ReadInitialBalances, ReadJournalEntries
    from ledger.commons import initial_balances, journal_entries
    from ledger.generic import InitialBalances, JournalEntries

    # Define the read initial balances algebra:
    read_initial_balances: ReadInitialBalances = initial_balances()

    # Define the read journal entries algebra:
    read_journal_entries: ReadJournalEntries = journal_entries()

    # Compile the general ledger program:
    program: InitialBalances = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Example:
    period: DateRange = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 1, 31))
    general_ledger: JournalEntries = program(period)

# Generated at 2022-06-24 01:03:09.415626
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import now
    from .accounts import Account, Asset
    from .journaling import AccountingPeriod, Journal

    ## Create a journal:
    journal = Journal(AccountingPeriod.from_date_range(DateRange(now()-datetime.timedelta(days=10), now())))

    ## Add some postings:
    journal.add(
        date=now()-datetime.timedelta(days=7),
        description="Opening balance",
        postings=[
            Posting(Asset(101), Quantity(Decimal(10000.00))),
            Posting(Asset(102), Quantity(Decimal(8000.00))),
            Posting(Asset(103), Quantity(Decimal(5000.00))),
        ],
    )

# Generated at 2022-06-24 01:03:12.486878
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """
    Unit test for method __eq__ of class Ledger
    """
    testLedger = Ledger(Account('testAccount', None), Balance(datetime.datetime(2020, 1, 1), Quantity(10.1)))
    assert testLedger == testLedger

# Generated at 2022-06-24 01:03:23.368904
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Testing method add of class Ledger
    """
    # Testing add entry in empty list
    account = Account(1, 1, "A")
    balance = Balance(datetime.date(2020, 1, 1), Decimal(1000))
    ledger = Ledger(account, balance)

    posting_1 = Posting(1, datetime.date(2020, 1, 1),
                    account, 'debit', Quantity(Decimal(100)))
    entry_1 = LedgerEntry(ledger, posting_1, Quantity(Decimal(1100)))

    ledger.add(posting_1)
    assert ledger.entries[-1].posting == posting_1
    assert ledger.entries[-1].balance == Quantity(Decimal(1100))

    # Testing add entry in non-empty list

# Generated at 2022-06-24 01:03:25.564206
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:03:32.277966
# Unit test for constructor of class Ledger
def test_Ledger():
    from .journaling import Posting
    from .accounts import AccountType
    test_account = Account(1, "test_account", AccountType.ASSET)
    test_posting = Posting(test_account, 1, '1/1/2000')
    test_ledger = Ledger(test_account, Balance(1, 1))
    assert test_ledger.entries == []
    assert test_ledger.initial == Balance(1, 1)
    assert test_ledger.account == test_account
    test_ledger.add(test_posting)
    assert test_ledger.entries[0] == LedgerEntry(test_ledger, test_posting, 2)


# Generated at 2022-06-24 01:03:42.820792
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..accounts.merchandising import account_receivable_ledger
    from ..accounts.merchandising import sales_ledger
    from ..accounts.merchandising import sales_returns_ledger

    #: Accounting period.
    period = DateRange(datetime.date(2020, 9, 1), datetime.date(2020, 9, 30))

    #: Sales account.
    sales_ledger_account = sales_ledger.account

    #: Sales returns account.
    sales_returns_ledger_account = sales_returns_ledger.account

    #: Account receivable account.
    account_receivable_ledger_account = account_receivable_ledger.account

    #: Initial balances.

# Generated at 2022-06-24 01:03:50.244591
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    acct1 = Account(1, True, False)
    post1 = Posting(acct1, False, 1000)
    ledger1 = Ledger(acct1, Balance(1, 0))
    entry = LedgerEntry(ledger1, post1, Quantity(1000))
    assert entry.ledger == ledger1
    assert entry.posting == post1
    assert entry.balance == 1000
    assert entry.date == datetime.date(1, 1, 1)
    assert entry.description == ""
    assert entry.amount == 1000
    assert entry.cntraccts == []
    assert entry.is_debit == True
    assert entry.is_credit == False
    assert entry.debit == 1000
    assert entry.credit == None


# Generated at 2022-06-24 01:03:54.812905
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(Ledger(Account.empty(), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))),
                            Posting(datetime.date(2020, 1, 1), 1, 1, False), Quantity(Decimal(1))))


# Generated at 2022-06-24 01:04:06.239539
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..model.accounting import Account, Balance, ReadInitialBalances as ReadInitialBalancesBase, ReadJournalEntries
    from datetime import date  # type: ignore
    from types import MappingProxyType  # type: ignore
    from unittest import TestCase

    def _program(period: DateRange) -> GeneralLedger[_T]:
        """
        Consumes the opening and closing dates and produces a general ledger.

        :param period: Accounting period.
        :return: A general ledger.
        """
        ## Get initial balances as of the end of previous financial period:
        initial_balances = read_initial_balances(period)

        ## Read journal entries and post each of them:
        journal_entries = read_journal_entries(period)

        ## Build the general ledger and return:

# Generated at 2022-06-24 01:04:13.404196
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    import datetime
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, Posting

    # Account
    a1 = Account("A1", "Asset")
    a2 = Account("A2", "Asset")

    # Posting
    p1 = Posting(Decimal("1.00"), a1)
    p2 = Posting(Decimal("10.00"), a2)

    # Journal
    j1 = Journal("J1", datetime.date.today(), p1)
    j2 = Journal("J2", datetime.date.today(), p2)

    # Initial Balance

# Generated at 2022-06-24 01:04:14.497124
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-24 01:04:23.771493
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Reference a journal entry.
    j1_postings = [Posting("A", Amount(10), 0), Posting("B", Amount(10), 1)]
    j1 = JournalEntry(date=datetime.date(2020, 1, 1), description="Test", postings=j1_postings)

    # Compile the general ledger.
    gen_ledger = build_general_ledger(DateRange(date_from=datetime.date(2020, 1, 1), date_to=datetime.date(2020, 1, 1)),
                                      [j1], {Account.from_string("A"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))})

    # Test the result.
    assert len(gen_ledger.ledgers) == 2

# Generated at 2022-06-24 01:04:24.966804
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-24 01:04:35.720778
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a1 = Account(
        name="Asset.Cash.BofA",
        classification="asset",
        type="bank",
        subtype="checking",
        desc="Bank of America",
    )
    a2 = Account(
        name="Asset.Cash.Chase",
        classification="asset",
        type="bank",
        subtype="checking",
        desc="Chase",
    )
    a3 = Account(
        name="Asset.Cash.Chase",
        classification="asset",
        type="bank",
        subtype="checking",
        desc="Chase",
    )
    b1 = Balance(
        date=datetime.date(2019, 9, 1), value=100,
    )

# Generated at 2022-06-24 01:04:45.331580
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from bkmrk import Transaction, Posting, TransactionJournal
    general_ledger=GeneralLedger(DateRange(datetime.date(2018,1,1),datetime.date(2018,12,31)), \
                                 {Account('Assets', 'A1'): Ledger(Account('Assets', 'A1'), Balance(datetime.date(2018,1,1), Quantity(0, 'Ccy')))})
    bkmrk_journal=TransactionJournal(datetime.date(2018,1,1), 'This is a test')
    bkmrk_journal.add(Transaction(100, datetime.date(2018,1,1),'This is a test transaction'))

# Generated at 2022-06-24 01:04:49.586369
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    #: account: Account
    #: balance: Balance

    account1 = Account("Bill","a")
    account2 = Account("Mary","a")
    balance1 = Balance(account1,5)

    ledgerEntry = LedgerEntry(account1,account2, balance1)

    assert ledgerEntry.ledger == account1
    assert ledgerEntry.posting == account2
    assert ledgerEntry.balance == 5



# Generated at 2022-06-24 01:04:51.034461
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger is not None

# Generated at 2022-06-24 01:04:53.714037
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .journaling import build_journal_program

    read_journal = build_journal_program({}, {})
    read_initial_balances = {}
    read_ledgers = compile_general_ledger_program(read_initial_balances, read_journal)
    read_ledgers(DateRange())



# Generated at 2022-06-24 01:04:54.781003
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass


# Generated at 2022-06-24 01:05:02.445080
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Setup
    ledger1 = Ledger(Account("000"), Balance(datetime.date(2020, 1, 1), Quantity(0)))
    ledger2 = Ledger(Account("000"), Balance(datetime.date(2020, 1, 1), Quantity(0)))
    ledger3 = Ledger(Account("001"), Balance(datetime.date(2020, 1, 1), Quantity(0)))
    # Exercise
    result1 = ledger1 == ledger2
    result2 = ledger2 == ledger3
    # Verify
    assert result1
    assert not result2

# Generated at 2022-06-24 01:05:12.919574
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    '''
    GeneralLedgerProgram.__call__()
    '''
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountGroup
    from .generic import Balance
    from ..commons.zeitgeist import DateRange, today
    import datetime

    # let's use a dummy calendar to make the test more readable:
    _today = today
    _today = datetime.date(2020, 9, 30)
    _today = datetime.date(2020, 8, 1)
    
    def period(days_since: int, days_until: int) -> DateRange:
        return DateRange(since=_today + datetime.timedelta(days=days_since), until=_today + datetime.timedelta(days=days_until))
    
    journal_entry_1 = JournalEntry

# Generated at 2022-06-24 01:05:19.303822
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class _ReadInitialBalances:
        def __call__(self, _: DateRange) -> InitialBalances:
            return {}

    @dataclass
    class _ReadJournalEntries:
        def __call__(self, _: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    compile_general_ledger_program(_ReadInitialBalances(), _ReadJournalEntries())

# Generated at 2022-06-24 01:05:19.901903
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert True

# Generated at 2022-06-24 01:05:22.023083
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Asserts that the method returns a string representation of the object.
    """
    pass



# Generated at 2022-06-24 01:05:23.122672
# Unit test for constructor of class Ledger
def test_Ledger():
    pass


# Generated at 2022-06-24 01:05:24.452828
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True


# Generated at 2022-06-24 01:05:34.881041
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.how.accounts import Account, AccountNumber

    from .accounts import Accounts
    from .journaling import Journal, Posting

    accounts = Accounts()

    accounts.add(Account(AccountNumber(1, 100), 'Debit account', True))
    accounts.add(Account(AccountNumber(1, 200), 'Credit account', False))

    acct1: Account = accounts.acct(AccountNumber(1, 100))
    acct2: Account = accounts.acct(AccountNumber(1, 200))

    ledger = Ledger(acct1, Balance(datetime.date(2018, 1, 1), Quantity(Decimal(5.5))))


# Generated at 2022-06-24 01:05:42.387023
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 01:05:46.227681
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    ReadInitialBalances()

# Generated at 2022-06-24 01:05:49.872439
# Unit test for constructor of class Ledger
def test_Ledger():
    L = Ledger('1', 'john')
    assert L.account == '1'
    assert L.initial == 'john'



# Generated at 2022-06-24 01:05:51.951279
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():

    assert GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2021, 12, 31)), {}) == GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2021, 12, 31)), {})



# Generated at 2022-06-24 01:05:54.388834
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ReadInitialBalances1(ReadInitialBalances):
        pass

    ReadInitialBalances1()


# Generated at 2022-06-24 01:06:03.497282
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    A = Account('A')
    B = Account('B')
    a = Ledger(A, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10))))
    b = Ledger(B, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10))))
    c = Ledger(A, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10))))

    assert a == c
    assert b != c
    assert a != b
    assert a != object()
    assert b != object()
    assert c != object()


# Generated at 2022-06-24 01:06:09.545194
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    #Create a ledger
    ledger = Ledger(account=Account(), initial=Balance(date=datetime.date.today(), value=Decimal(0)))
    #Compare with ledger itself, should be equal
    assert (ledger == ledger)
    #Create another ledger with different attributes, should not be equal
    ledger2 = Ledger(account=Account(), initial=Balance(date=datetime.date.today(), value=Decimal(1)))
    assert (ledger != ledger2)


# Generated at 2022-06-24 01:06:13.687421
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    test_LedgerEntry = LedgerEntry(1,2,3)
    test2_LedgerEntry = LedgerEntry(1,2,3)

    assert (test_LedgerEntry == test2_LedgerEntry) == True
    assert (test_LedgerEntry == 1) == False



# Generated at 2022-06-24 01:06:21.785991
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from dataclasses import dataclass, field
    from decimal import Decimal
    from typing import Dict, Generic, Iterable, List, TypeVar

    # Defines a generic type variable.
    _T = TypeVar("_T")

    @dataclass
    class GeneralLedger(Generic[_T]):
        """
        Provides a general ledger model.
        """

        #: Accounting period.
        period: DateRange

        #: Individual account ledgers of the general ledger.
        ledgers: Dict[Account, Ledger[_T]]

    @dataclass
    class Ledger(Generic[_T]):
        """
        Provides an account ledger model.
        """

        #: Account of the ledger.
        account: Account

        #: Initial balance of the ledger.
        initial: Balance

        #: Ledger entries.
       

# Generated at 2022-06-24 01:06:23.150060
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account = Account("Test")
    posting = Posting(account, 1, {}, datetime.date.today())

# Generated at 2022-06-24 01:06:33.543072
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .test import test_data

    journal = test_data.read_journal_entries(test_data.period)
    initial = test_data.read_initial_balances(test_data.period)
    general_ledger = test_data.build_general_ledger(test_data.period, journal, initial)
    ledger = general_ledger.ledgers[test_data.Account.account_by_number(101)]
    entry = ledger.entries[0]


# Generated at 2022-06-24 01:06:45.168858
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import build_journal_entry
    from .accounts import build_account

    ## Set accounting period:
    period = DateRange.by_month(datetime.date(2018, 6, 1), datetime.date(2018, 6, 30))

    ## Define initial balances for the ledger:
    initial = {build_account(1, "Account 1"): Balance(period.since, Quantity(Decimal(500.00)))}

    ## Create journal entries:

# Generated at 2022-06-24 01:06:49.288634
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    ledgers : Dict[Account, Ledger] = {}
    assert GeneralLedger(period, ledgers)


# Generated at 2022-06-24 01:06:53.587086
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account(code="CARD", name="Credit Card", is_terminal=True)
    initial = Balance(Decimal("10234.00"), datetime.date(2010, 1, 1))
    sut = Ledger(account, initial)
    print(repr(sut))

# Generated at 2022-06-24 01:07:00.076819
# Unit test for constructor of class Ledger
def test_Ledger():
    from .test import accounts, initial_balances, eq_, journal_entries
    eq_(
        Ledger(
            accounts["Asset"],
            initial_balances["Asset"],
        ),
        LedgerEntry(
            "Asset",
            journal_entries["Posting1"],
            Decimal("0.00"),
            "Opening balance",
        ),
        LedgerEntry(
            "Asset",
            journal_entries["Posting1"],
            Decimal("0.00"),
            "Opening balance",
        ),
    )

# Generated at 2022-06-24 01:07:08.086929
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a journal entry:
    journal: JournalEntry = JournalEntry(datetime.date(2020, 10, 1), "Journal 1", [Posting(Account(1), Amount(100))])

    # Create a ledger:
    ledger: Ledger = Ledger(Account(1), Balance(datetime.date(2020, 9, 1), Quantity(0)))

    # Add the posting to the ledger:
    ledger.add(journal.postings[0])

    # Check the ledger entry:
    assert ledger.entries[0].date == datetime.date(2020, 10, 1)
    assert ledger.entries[0].description == "Journal 1"
    assert ledger.entries[0].amount == Amount(100)
    assert ledger.entries[0].cntraccts == []

# Generated at 2022-06-24 01:07:12.587522
# Unit test for constructor of class Ledger
def test_Ledger():
    # Check if the right output is being displayed when correct inputs are given
    account = Account('1', '', 'Testing')
    initial = Balance('2015-01-01', Decimal('0'))
    ledger = Ledger(account, initial)
    assert ledger.initial == initial
    assert ledger.account == account
    assert ledger.entries
    assert ledger._last_balance == initial.value

# Generated at 2022-06-24 01:07:23.733165
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .accounts import Account
    from .journaling import Posting
    from .transactions import Transaction

    class Dummy:
        pass

    # create accounts
    account1 = Account("Assets:Cash")
    account2 = Account("Assets:Investments")
    account3 = Account("Expenses:VAT")
    account4 = Account("Revenues:Sales")
    account5 = Account("Costs:Sales")

    # create postings
    posting1 = Posting(transaction=Transaction("Open Sesame", "...", datetime.date(2019, 12, 31)), account=account1, amount=Decimal(1))
    posting2 = Posting(transaction=Transaction("Open Sesame", "...", datetime.date(2019, 12, 31)), account=account2, amount=Decimal(2))
    posting3 = Posting

# Generated at 2022-06-24 01:07:32.102353
# Unit test for constructor of class Ledger
def test_Ledger():
    # Creates some test data
    account = Account("1111", "bar", True, None)
    initial = Balance(datetime.date(2020, 2, 10), Quantity(Decimal(10)))
    posting = Posting(JournalEntry(datetime.date(2020, 2, 10),
                                   Amount(Decimal(10)),
                                   "Hello"), account, None, None)

    # Create an instance of Ledger
    l = Ledger(account, initial)

    # Test the add method
    l.add(posting)
    assert l.entries[0].balance == Quantity(Decimal(20))
    assert l.entries[0].posting.journal.description == "Hello"



# Generated at 2022-06-24 01:07:41.751908
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .journaling import Journal, Posting, Direction
    from .accounts import Account
    from .generic import Balance
    from .journaling import build_journal, add_posting
    # Initialize
    journal = build_journal("Test Journal", "Test Description")
    posting = add_posting(journal, Direction.CR, Account("A"), Amount(120000), DateTime(2012, 12, 12))
    initial_balances = {}
    period = DateRange(DateTime(2012, 12, 12), DateTime(2012, 12, 12))
    ledger = Ledger(Account("A"), Balance(DateTime(2012, 12, 12), Quantity(120000)))
    ledger_entry = LedgerEntry(ledger, posting, Quantity(120000))
    # Testing