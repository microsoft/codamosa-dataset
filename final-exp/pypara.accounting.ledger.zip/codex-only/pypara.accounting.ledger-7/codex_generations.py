

# Generated at 2022-06-24 00:57:47.628819
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account = Account('General', 'Cash')
    def test_account():
        assert account == Account('General', 'Cash')
        assert account != Account('General', 'Cash1')
        assert account != Account('General1', 'Cash')
    test_account()
    date = datetime.date(2020, 1, 1)
    debit = None
    credit = Decimal(100)
    posting = Posting(account, date, debit, credit)
    ledger = Ledger(account, Balance(datetime.date(2019, 12, 31), Decimal(0)))
    ledger_entry = LedgerEntry(ledger, posting, Decimal(100))


# Generated at 2022-06-24 00:57:55.352970
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry1 = LedgerEntry(Ledger(Account('Expense',1),Balance(datetime.date.today(), Quantity(Decimal(0)))), Posting(Account('Expense',1), Amount(Decimal(0)), 'debit'), Quantity(Decimal(0)))
    entry2 = LedgerEntry(Ledger(Account('Expense',1),Balance(datetime.date.today(), Quantity(Decimal(0)))), Posting(Account('Expense',1), Amount(Decimal(0)), 'debit'), Quantity(Decimal(0)))
    assert (entry1 == entry2) == True


# Generated at 2022-06-24 00:58:05.872432
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import datetime
    period = DateRange(since = datetime(2017, 1, 1),until = datetime(2018, 1, 1))
    journal = {
        JournalEntry(
            datetime(2017, 1, 1),
            "Journal Entry 1",
            [
                Posting(Account("Liabilities:A"), 1, "Posting 1"),
                Posting(Account("Equity:B"), 1, "Posting 1"),
            ],
        ),
        JournalEntry(
            datetime(2018, 1, 1),
            "Journal Entry 2",
            [
                Posting(Account("Liabilities:A"), 1, "Posting 2"),
                Posting(Account("Equity:B"), 1, "Posting 2"),
            ],
        ),
    }

# Generated at 2022-06-24 00:58:13.813149
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRanges
    from ..journaling import JournalEntry, Posting
    from ..journaling.algebra import write_posting

    #: Define the accounting period:
    period = DateRanges.this_year()

    #: Define initial balances:
    initial = {"1010": Balance(period.since, Quantity(Decimal(1000)))}

    #: Define a test journal entry with two postings:
    journal = JournalEntry(
        period.until, "Test Journal Entry", [
            Posting(period.until, "1010", Quantity(10), "Cred"),
            Posting(period.until, "2020", Quantity(10), "Deb"),
        ]
    )

    #: Run the test:
    ledger = build_general_ledger(period, [journal], initial)

   

# Generated at 2022-06-24 00:58:15.596188
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Ledger(4,5)
    b = Ledger(4,5)
    c = Ledger(4,6)
    assert a == b
    assert a != c


# Generated at 2022-06-24 00:58:25.191269
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for the build_general_ledger function.
    """
    from datetime import date
    from ..commons.numbers import Amount
    from .accounts import Account, AccountCategories, AccountTypes
    from .journaling import Journal
    period = DateRange(date(2019, 6, 1), date(2019, 6, 30))

# Generated at 2022-06-24 00:58:33.806063
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledger_entry_1 = LedgerEntry(Ledger(Account("test"), Balance(datetime.date(2020, 5, 28), Quantity(Decimal(100)))),
                                 Posting(datetime.date(2020, 5, 28), Account("test"), Account("test"), Amount(Decimal(100)), 1,
                                         JournalEntry(datetime.date(2020, 5, 28), "test",
                                                      [Posting(datetime.date(2020, 5, 28), Account("test"), Account("test"), Amount(Decimal(100)), 1, "test")])),
                                 Quantity(Decimal(100)))


# Generated at 2022-06-24 00:58:37.296290
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .in_memory import ReadJournalEntriesInMemory
    assert GeneralLedgerProgram == compile_general_ledger_program(ReadInitialBalances, ReadJournalEntriesInMemory)

# Generated at 2022-06-24 00:58:46.911611
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """Unit test for method __repr__ of class LedgerEntry."""
    # Defines a datetime.date instance.
    date = datetime.date.today()

    # Defines a journal entry.
    journal_entry = JournalEntry(
        date, "Test"
    )

    # Defines a posting instance.
    posting = Posting(
        journal_entry, True, Account("1111"), Amount(Decimal("100.00"))
    )

    # Defines a ledger entry model.
    ledger_entry = LedgerEntry(
        Ledger(Account("1111"), Balance(date, Quantity(Decimal(0)))), posting
    )

    # Check that the ledger entry matches its string representation.
    assert ledger_entry == eval(repr(ledger_entry))


# Generated at 2022-06-24 00:58:54.619297
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    import doudiz

    def read_initial_balances(period: DateRange) -> InitialBalances:
        initial_balances = dict()

        account = Account(account_number='500', account_name='Cash')
        initial_balance = Balance(period.since, Quantity(Decimal(0)))
        initial_balances[account] = initial_balance

        return initial_balances

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        journal_entries = []

        j1 = JournalEntry()
        j1.date = period.since
        j1.description = 'First journal'
        j2 = JournalEntry()
        j2.date = period.since
        j2.description = 'Second journal'
        journal_entries = [j1, j2]

        return

# Generated at 2022-06-24 00:59:01.862589
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, Journal

    #Initialize class Account
    checking_account = Account("Checking")
    other_account = Account("Other")

    #Initialize class Journal
    journal = Journal("Paycheck", "2018-01-01", "Paycheck")

    #Initialize class Posting
    posting = Posting(checking_account, 1000, journal, "Debit")

    #Initialize class Ledger
    ledger = Ledger(checking_account, Balance("2018-01-01", Quantity(Decimal(0))))

    #Initialize class LedgerEntry
    entry = LedgerEntry(ledger, posting, 1000)
    
    #Check if entry is equal to:
    #LedgerEntry(Ledger(Account('Checking'), Balance('2018-01-01', Quantity(Dec

# Generated at 2022-06-24 00:59:10.753505
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("1011", "", "")
    initial = Balance(datetime.date(2000,1,1), Quantity(Decimal(100)))
    L = Ledger(account,initial)
    print(L.account)
    print(L.initial)
    print(L.entries)
    assert L._last_balance == L.initial.value, "constructor on Ledger.py failed"
    assert len(L.entries) == 0, "constructor on Ledger.py failed"
    assert L.account.number == "1011", "constructor on Ledger.py failed"
    assert L.initial.value == Decimal(100), "constructor on Ledger.py failed"
    

# Generated at 2022-06-24 00:59:11.599739
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # TODO
    return True

# Generated at 2022-06-24 00:59:19.215370
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    acc1 = Account(code='1', title='One')
    acc2 = Account(code='2', title='Two')
    acc3 = Account(code='3', title='Three')
    bal1 = Balance(date=datetime.date(2017, 1, 1), value=Quantity(Decimal(1)))
    bal2 = Balance(date=datetime.date(2017, 2, 1), value=Quantity(Decimal(2)))
    bal3 = Balance(date=datetime.date(2017, 3, 1), value=Quantity(Decimal(3)))
    posting1 = Posting(date=datetime.date(2017, 1, 1), account=acc1, amount=Amount(Decimal(1.1)), direction='credit')

# Generated at 2022-06-24 00:59:31.118599
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    _T = TypeVar("_T")
    read_journal_entries = lambda period: (
        JournalEntry(
            "JE-00001", datetime.date(2020, 5, 15), "Payment of staff salaries", [Posting("A-00002", 100.00, "D")]
        ),
    )
    read_initial_balances = lambda period: {Account("A-00002"): Balance(datetime.date(2020, 5, 1), Quantity(100.00))}
    gl_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    gl = gl_program(DateRange(since=datetime.date(2020, 5, 1), until=datetime.date(2020, 5, 31)))

# Generated at 2022-06-24 00:59:40.253600
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import create_journal_entry
    from datetime import date
    accounts = {'A': 'root', 'B': 'root', 'C': 'root'}
    initial_balances = {'A': Balance(date(2018,6,1), Quantity(Decimal(0))), 'B': Balance(date(2018,6,1), Quantity(Decimal(0))), 'C': Balance(date(2018,6,1), Quantity(Decimal(0)))}

# Generated at 2022-06-24 00:59:51.143357
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .accounts import AccountType, Account, Asset, Liability, Expense, Revenue, Equity

    # create accounts
    asset = Asset(name="Current Assets", category="Current Assets", number=1000)
    loan = Liability(name="Loans Payable", category="Long Term Liabilities", number=2100)
    equipment = Asset(name="Equipment", category="Fixed Assets", number=3000)
    depreciation = Expense(name="Depreciation", category="Operating Expenses", number=7000)
    revenue = Revenue(name="Sales", category="Sales", number=4000)
    equity = Equity(name="Retained Earnings", category="Stockholders' Equity", number=3000)

    # create journal entries
    # create first journal entry

# Generated at 2022-06-24 00:59:59.437410
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..domain import unit_test_config
    from ..domain.loaders import LoadAccounts, LoadBalances, LoadJournalEntries

    # Set up algebra implementations:
    unit_test_accounts = LoadAccounts(unit_test_config.accounts_path)
    unit_test_journal = LoadJournalEntries(unit_test_config.book_path)
    unit_test_balances = LoadBalances(unit_test_config.balances_path)

    # Compile the program:
    unit_test_program = compile_general_ledger_program(unit_test_balances, unit_test_journal)

    # Execute the program:
    unit_test_period = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 2, 1))
    unit_test_gl = unit_

# Generated at 2022-06-24 01:00:06.338562
# Unit test for constructor of class Ledger
def test_Ledger():
    # Given
    account = Account("Assets")
    date = datetime.date(2020, 1, 2)
    balance = Balance(date, Quantity(-1.0))

    # When
    ledger = Ledger(account, balance)

    # Then
    assert ledger.account == account
    assert ledger.initial == balance
    assert ledger.entries == []



# Generated at 2022-06-24 01:00:14.743685
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # test for constructor
    # create a LedgerEntry instance
    LE = LedgerEntry()
    # check the type
    assert type(LE) is LedgerEntry
    # check public fields
    assert hasattr(LE, 'posting')
    assert hasattr(LE, 'ledger')
    assert hasattr(LE, 'balance')
    # check readonly fields
    assert not hasattr(LE, 'posting.__set__')
    assert not hasattr(LE, 'ledger.__set__')
    assert not hasattr(LE, 'balance.__set__')
    # check private fields
    assert not hasattr(LE, '__date')
    assert not hasattr(LE, '__description')
    assert not hasattr(LE, '__amount')
    assert not hasattr(LE, '__cntraccts')

# Generated at 2022-06-24 01:00:17.090529
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram(): 
    assert(compile_general_ledger_program(read_initial_balances,read_journal_entries) is not None)

# Generated at 2022-06-24 01:00:26.977278
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    ## Define a journal entry first
    from .journaling import Posting, JournalEntry
    import datetime
    from .accounts import Account
    account1 = Account(number=1, name="customer_account")
    account2 = Account(number=2, name="cash_account")
    account3 = Account(number=3, name="expense_account")
    account4 = Account(number=4, name="bank_account")

    posting1 = Posting(account=account1,amount=100,direction=-1)

    posting2 = Posting(account=account2,amount=1000,direction=1)
    posting3 = Posting(account=account3,amount=500,direction=-1)
    posting4 = Posting(account=account4,amount=500,direction=1)


# Generated at 2022-06-24 01:00:35.563378
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # GIVEN a GeneralLedgerProgram
    def read_initial_balances(period):
        initial = {
            Account(
                'Assets:Bank:DBS',
                'Bank: DBS Current Account'
            ): Balance(
                datetime.date(2019, 1, 1),
                Quantity(1000)
            )
        }
        return initial


# Generated at 2022-06-24 01:00:44.374860
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account1 = Account('A1')
    account2 = Account('A2')
    balance1 = Balance(datetime.date(2000,1,1), Quantity(Decimal(0)))
    balance2 = Balance(datetime.date(2000,1,1), Quantity(Decimal(1)))
    balance3 = Balance(datetime.date(2019,1,1), Quantity(Decimal(0)))
    balance4 = Balance(datetime.date(2019,1,1), Quantity(Decimal(1)))
    posting1 = Posting(Decimal(0))
    posting2 = Posting(Decimal(1))
    posting3 = Posting(Decimal(-1))
    posting4 = Posting(Decimal(0))
    ledger1 = Ledger(account1, balance1)
    ledger2 = Ledger(account2, balance2)

# Generated at 2022-06-24 01:00:54.073920
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    ledger = Ledger(
        Account(
            id=5000,
            number="5000",
            name="Bank",
            terminal=True,
            consolidated=False,
            is_debit=True,
        ),
        Balance(
            date=datetime.date(2018, 1, 1),
            value=Decimal(1000)
        )
    )
    assert ledger.__repr__() == "Ledger(id=5000, number='5000', name='Bank', terminal=True, consolidated=False, is_debit=True, initial=Balance(date=datetime(2018, 1, 1), value=Decimal('1000')))"

# Generated at 2022-06-24 01:01:01.250987
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..demo_ledger.domain import DemoLedger

    ledger = DemoLedger.unit_test_ledger()
    from ..demo_ledger.process import build_ledger_entry

    test_ledger_entry = build_ledger_entry(ledger[0])
    test_ledger_entry.__dict__ == ledger[0].__dict__

# Generated at 2022-06-24 01:01:05.736953
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ReadInitialBalancesClass(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    ReadInitialBalancesClass(ReadInitialBalancesClass())


# Generated at 2022-06-24 01:01:12.382846
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    general_ledger = GeneralLedger(
        DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31)),
        {},
    )
    assert general_ledger.__repr__() == "GeneralLedger(period=DateRange(since=datetime.date(2017, 1, 1), until=datetime.date(2017, 12, 31)), ledgers={})"


# Generated at 2022-06-24 01:01:24.201339
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry

    # test _program() with empty initial balances
    period = DateRange(datetime.date(2020, 4, 1), datetime.date(2020, 6, 30))
    read_initial_balances = lambda period: dict()
    read_journal_entries = lambda period: [JournalEntry(datetime.date(2020, 5, 1), "10000", [Posting(None, None, None)])]
    test_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    test_result = test_program(period)
    assert isinstance(test_result, GeneralLedger)
    assert len(test_result.ledgers) == 1

# Generated at 2022-06-24 01:01:33.874313
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # test with no entries
    from ..accounts.models import Account
    from ..commons.zeitgeist import DateRange
    from .journaling.models import JournalEntry
    from ..libs.identities.models import Identity
    from .accounts import Balance

    account = Account(
        code="000001",
        name="Testing __repr__ of class Ledger",
        description="Description of testing __repr__ of class Ledger",
        is_summary=False
    )

    initial = Balance(period=DateRange.today, value=0)
    ledger = Ledger(
        account=account,
        initial=initial
    )
    assert ledger.__repr__() == "Ledger(account={0}, initial={1}, entries=[])".format(account, initial)

    # test with 1 entry

# Generated at 2022-06-24 01:01:34.669826
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass # TODO


# Generated at 2022-06-24 01:01:43.709590
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    def get_ledgers1():
        initial_balances = dict()
        initial_balances[Account("1")] = Balance(datetime.date(2020, 1, 1), Decimal(100))
        initial_balances[Account("2")] = Balance(datetime.date(2020, 1, 1), Decimal(200))
        initial_balances[Account("3")] = Balance(datetime.date(2020, 1, 1), Decimal(300))
        initial_balances[Account("4")] = Balance(datetime.date(2020, 1, 1), Decimal(400))
        initial_balances[Account("5")] = Balance(datetime.date(2020, 1, 1), Decimal(500))

# Generated at 2022-06-24 01:01:53.714741
# Unit test for constructor of class Ledger
def test_Ledger():
    ledger1 = Ledger(account=Account(acct_id='100', description='Account', acct_type=1), initial=Balance(value=Quantity(Decimal(0)), date=datetime.date(2020, 1, 1)))
    assert ledger1.account.acct_id == '100'
    assert ledger1.account.description == 'Account'
    assert ledger1.account.acct_type == 1
    assert ledger1.initial.value == Quantity(Decimal(0))
    assert ledger1.initial.date == datetime.date(2020, 1, 1)

    ledger2 = Ledger(account=Account(acct_id='200', description='TestAccount', acct_type=0), initial=Balance(value=Quantity(Decimal(1)), date=datetime.date(2020, 2, 1)))

# Generated at 2022-06-24 01:02:03.300507
# Unit test for constructor of class Ledger
def test_Ledger():
    account1 = Account('1', 'a1', 'desc1', True)
    account2 = Account('2', 'a2', 'desc2', True)
    balance1 = Balance(datetime.date(2020, 1, 15), 12.34)
    balance2 = Balance(datetime.date(2020, 1, 15), 1.2)
    balance3 = Balance(datetime.date(2020, 1, 15), 2.1)
    balance4 = Balance(datetime.date(2020, 1, 15), 9.3)

    ledger_account1_balance1 = Ledger(account1, balance1)
    assert ledger_account1_balance1.account == account1
    assert ledger_account1_balance1.initial == balance1
    assert ledger_account1_balance1.entries == []


# Generated at 2022-06-24 01:02:03.868945
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass

# Generated at 2022-06-24 01:02:08.689429
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert(repr(Ledger(Account('assets.cash'), Balance(datetime.date.today(), Quantity(Decimal(10)))))) == "Ledger(account=Account(name='assets.cash'), initial=Balance(date=datetime.date(2020, 6, 19), value=Quantity(value=Decimal('10'))), entries=[])"


# Generated at 2022-06-24 01:02:18.932587
# Unit test for constructor of class Ledger
def test_Ledger():
    # Initialize an example account, balance, and direction
    account = Account('A1', 'Account 1')
    initial = Balance(2019, Quantity(Decimal(100.0)))
    posting = Posting(1, 2, 1, '2019-01-01', account, Amount(Decimal(10.0)), 1)

    # Create an instance of the Ledger
    ledger = Ledger(account, initial)

    # Add the posting to the ledger
    ledger.add(posting)
    assert ledger.initial.since == initial.since
    assert ledger.initial.value == initial.value
    assert ledger.account == account
    assert ledger.entries[0].balance == Quantity(Decimal(110.0))


# Generated at 2022-06-24 01:02:21.563683
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    general_ledger = build_general_ledger(DateRange(datetime.date(2019,12,1), datetime.date(2019,12,31)), [], {})
    assert general_ledger.__repr__() == "GeneralLedger(period=DateRange(since=datetime.date(2019, 12, 1), until=datetime.date(2019, 12, 31)), ledgers={})"


# Generated at 2022-06-24 01:02:30.762777
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from .journaling import Posting, JournalEntry

    # Fixture
    def _read_initial_balances(period: DateRange) -> InitialBalances:

        from ..commons.zeitgeist import DateTime

        return {
            Account("21101"): Balance(
                date=DateTime(2013, 12, 31),
                value=Quantity(Decimal("20150.00")),
            ),
            Account("21102"): Balance(
                date=DateTime(2013, 12, 31),
                value=Quantity(Decimal("9400.00")),
            ),
        }

    def _read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:

        from .accounts import Account
        from .journaling import Journal, Posting, Transaction, JournalEntry

        # Fixture

# Generated at 2022-06-24 01:02:42.111869
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():

    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    #
    #   General ledger:
    #   account1    1.00 +
    #   account2    1.00 -
    #
    account1 = Account("Assets:Cash")
    account2 = Account("Liability:Loan")
    balance1 = Balance(datetime.date(2020, 1, 1), Quantity(Decimal("1.00")))
    balance2 = Balance(datetime.date(2020, 1, 1), Quantity(Decimal("1.00")))
    posting = Posting(account1, Amount(Decimal("1.00")), +1)
    posting_reverse = Posting(account2, Amount(Decimal("1.00")), -1)

# Generated at 2022-06-24 01:02:52.385253
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    xs = [
        JournalEntry(
            date=datetime.date(2020, 5, 1),
            description="Test JE",
            postings=[
                Posting(Account("1000"), Amount(Decimal(100)), debit=True),
                Posting(Account("2000"), Amount(Decimal(100)), debit=False),
            ],
        ),
    ]

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("1000"): Balance(period.since, Amount(Decimal(1000)))}

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        yield from xs

    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

# Generated at 2022-06-24 01:02:59.616267
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
	a = Account(1, 'SA')
	j = JournalEntry(1, 'Description', datetime.date(2020, 1, 2))
	p = Posting(j, a, 10)
	b = Balance(j.date, 10)
	l = Ledger(a, b)
	l.add(p)
	assert l.entries[0].date == datetime.date(2020, 1, 2)
	assert l.entries[0].description == 'Description'
	assert l.entries[0].balance == 20
	assert l.entries[0].is_debit == True
	assert l.entries[0].is_credit == False
	assert l.entries[0].debit == 10
	assert l.entries[0].credit == None

# Generated at 2022-06-24 01:03:11.465863
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account, AccountType
    from .generic import Balance

# Generated at 2022-06-24 01:03:22.100424
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Happy case unit test.

    :return: None
    """
    ## Prepare a test journal:
    journal = [
        JournalEntry(datetime.date(2020, 1, 1), "Transaction 1", [
            Posting(Account("1"), Amount(10), Direction.DEBIT),
            Posting(Account("2"), Amount(10), Direction.CREDIT)
        ]),
        JournalEntry(datetime.date(2020, 1, 2), "Transaction 2", [
            Posting(Account("3"), Amount(25), Direction.DEBIT),
            Posting(Account("4"), Amount(25), Direction.CREDIT)
        ])
    ]

    ## Prepare initial balances:

# Generated at 2022-06-24 01:03:29.462681
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for:
        method __call__ of class GeneralLedgerProgram
    """

    from unittest.mock import Mock

    # Mock the dependencies:
    mock_read_initial_balances = Mock(ReadInitialBalances)
    mock_read_journal_entries = Mock(ReadJournalEntries)

    # Compile the program:
    program = compile_general_ledger_program(
        mock_read_initial_balances,
        mock_read_journal_entries,
    )

    # Set up the mock calls:
    mock_read_initial_balances.return_value = {}
    mock_read_journal_entries.return_value = iter([])

    assert program(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))) is not None

# Generated at 2022-06-24 01:03:35.975597
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account("bank", "Cash", None, None, None)
    initial = Balance(datetime.date(2019,12,31), Quantity(Decimal(100)))
    ledger = Ledger(account, initial)
    assert ledger.__repr__() == "Ledger(account='bank:Cash', initial=Balance(date=datetime.date(2019,12,31), value=Decimal('100')))"


# Generated at 2022-06-24 01:03:41.318355
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    n = LedgerEntry(object,"2019-01-01",1,"Test",1,1)
    assert n.__repr__() == "LedgerEntry(ledger=<object object at 0x7f59a577a1c0>, posting=2019-01-01, cntraccts=[1], description=Test, amount=1, debit=1, credit=None)"


# Generated at 2022-06-24 01:03:48.214763
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from pystratum_backend.StratumStyle import StratumStyle
    from .accounts import AccountType, create_account
    from .journaling import Journal, PostingDirection
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .accounting import build_accounting_program
    from .read_journal_entries.ReadJournalEntriesByParams import ReadJournalEntriesByParams
    from .initial_balances.ReadInitialBalancesByParams import ReadInitialBalancesByParams
    from .initial_balances.ReadInitialBalancesByParams.ExtractInitialBalance\
        import ExtractInitialBalance
    from .initial_balances.ReadInitialBalancesByParams.ExtractOpeningBalance\
        import ExtractOpeningBalance

# Generated at 2022-06-24 01:03:59.063632
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    entry = LedgerEntry(Ledger(Account("444444"), Balance(datetime.date(2018, 1, 1), Quantity(0))),
        Posting(Account("444444"), datetime.date(2018, 1, 20), Quantity(100)), Quantity(100))
    assert entry.__repr__() == "LedgerEntry(ledger=Ledger(account=Account(code='444444'), initial=Balance(date=datetime.date(2018, 1, 1), value=Quantity(0))), posting=Posting(account=Account(code='444444'), date=datetime.date(2018, 1, 20), amount=Quantity(100)), balance=Quantity(100))"

# Generated at 2022-06-24 01:04:04.159524
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account("1", "test")
    l = Ledger(a, Balance(datetime.date(2020, 1, 1), Quantity(1)))
    assert l.account == a
    assert l.initial.value == Quantity(1)
    assert l.entries.__len__() == 0


# Generated at 2022-06-24 01:04:14.739529
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import JournalEntry

    initial = {
        Account("Assets", "Cash"): Balance(
            datetime.date(2019, 6, 30),
            Quantity(Decimal("15000.25"))
        )
    }

# Generated at 2022-06-24 01:04:21.449849
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from decimal import Decimal
    from datetime import date
    from .accounts import AccountType, RootAccount
    from .commons import Balance
    from .journaling import Transaction, Debit, Credit


# Generated at 2022-06-24 01:04:23.213397
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger1 = Ledger('account1', 'account1', 1, 1)
    ledger2 = Ledger('account1', 'account1', 1, 1)
    assert ledger1 == ledger2


# Generated at 2022-06-24 01:04:34.289037
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    test_object = Ledger('foo',Balance(datetime.datetime(2017, 3, 29, 0, 0),Decimal(0)))
    test_object1 = Ledger('foo',Balance(datetime.datetime(2017, 3, 29, 0, 0),Decimal(0)))
    test_object2 = Ledger('bar',Balance(datetime.datetime(2017, 3, 29, 0, 0),Decimal(0)))
    test_object3 = Ledger('foo',Balance(datetime.datetime(2017, 3, 29, 0, 1),Decimal(0)))
    test_object4 = Ledger('foo',Balance(datetime.datetime(2017, 3, 29, 0, 0),Decimal(1)))
    assert test_object == test_object1
    assert test_object != test_object2
    assert test

# Generated at 2022-06-24 01:04:42.653232
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Setup
    LE1 = LedgerEntry(Ledger(Account("20-30-40"), Balance(datetime.date(2020, 12, 20), Quantity(Decimal(0)))),
                      Posting(Account("10-20-30"), datetime.date(2020, 12, 20), "Test of LedgerEntry __eq__()",
                              Quantity(Decimal(100))),
                      Quantity(Decimal(100)))
    LE2 = LedgerEntry(Ledger(Account("20-30-40"), Balance(datetime.date(2020, 12, 20), Quantity(Decimal(0)))),
                      Posting(Account("10-20-30"), datetime.date(2020, 12, 20), "Test of LedgerEntry __eq__()",
                              Quantity(Decimal(100))),
                      Quantity(Decimal(100)))

    # Exercise

# Generated at 2022-06-24 01:04:44.981386
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    foo = LedgerEntry("Foo", "Bar", 1)
    zoo = LedgerEntry("Zoo", "Bar", 1)
    assert foo == zoo

# Generated at 2022-06-24 01:04:46.612715
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    """
    Test the constructor of ReadInitialBalances class.
    """
    assert(True)


# Generated at 2022-06-24 01:04:53.693199
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from ..commons import zeitgeist
    from .accounts import Accounts
    from .journaling import Journal, PostingDirection, Value

    accounts = Accounts()
    assets = accounts.create_terminal("assets")
    capital = accounts.create_terminal("capital")
    sales = accounts.create_terminal("sales")
    journal = Journal()

    def transaction(date, description, balance, dr_account, cr_account, cr_amount):
        journal.add(zeitgeist.Date(date), description, [
            Posting(assets, PostingDirection.DEBIT, Value(balance)),
            Posting(capital, PostingDirection.CREDIT, Value(cr_amount))
        ])

# Generated at 2022-06-24 01:04:54.361100
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert True

# Generated at 2022-06-24 01:05:06.726932
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-24 01:05:14.285870
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import account_factory
    from .journaling import journal_factory

    ## Define some test accounts:
    accts = [
        account_factory("100", "Cash"),
        account_factory("200", "Accounts Receivable"),
        account_factory("300", "Accounts Payable"),
        account_factory("400", "Equipment"),
        account_factory("500", "Sales"),
        account_factory("600", "Service Costs"),
        account_factory("700", "Salaries Payable"),
        account_factory("800", "Banking Fees"),
    ]

    ## Define test journals:

# Generated at 2022-06-24 01:05:19.735578
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Tests method __repr__ of class Ledger.
    """
    ledger: Ledger[str] = Ledger(Account(name="Current Assets"), Balance(datetime.date(2019, 12, 31), Quantity(Decimal(0))))
    assert repr(ledger) == "Ledger(account=Account(name=Current Assets, code=None), initial=Balance(date=2019-12-31, value=0.00000000), entries=[])"

# Generated at 2022-06-24 01:05:21.049958
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances()



# Generated at 2022-06-24 01:05:22.942526
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    def test_balance():
        return None
    assert test_balance() == None


# Generated at 2022-06-24 01:05:24.681604
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    assert  compile_general_ledger_program(None, None) != None

# Generated at 2022-06-24 01:05:35.024063
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit-test this function
    """
    from ..commons.algebra import Function
    from ..commons.zeitgeist import Interval
    from ..journaling import Journal, JournalEntryId, ledger_algebra

    # Set-up period
    period = Interval("Jan-21", "Feb-21")

    # Set-up initial balances
    initial_balances = {Account("111111"): Balance("Dec-21", Quantity(Decimal(110)))}

    # Set-up journal
    def _journal_entry(entry_id: JournalEntryId) -> JournalEntry:
        account_a = Account("111111")
        account_b = Account("222222")

# Generated at 2022-06-24 01:05:36.149355
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    lo = LedgerEntry(None,None,None)
    assert lo

# Generated at 2022-06-24 01:05:43.808708
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    date1 = datetime.date(2018, 4, 1)
    date2 = datetime.date(2018, 4, 2)
    date3 = datetime.date(2018, 4, 3)
    date4 = datetime.date(2018, 4, 4)
    date5 = datetime.date(2018, 4, 5)
    date6 = datetime.date(2018, 4, 6)
    date7 = datetime.date(2018, 4, 7)
    date8 = datetime.date(2018, 4, 8)
    date9 = datetime.date(2018, 4, 9)

    a = Account('120000', 'Cash')
    b = Account('200000', 'Accounts Receivable')

    a.add_child(b)


# Generated at 2022-06-24 01:05:50.572077
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import RootAccount

    ## Mocks:
    assert read_initial_balances(period) == {RootAccount: Balance(since=period.since, value=Quantity(Decimal(0)))}

    assert read_journal_entries(period) == [
        JournalEntry(
            date=datetime.date(2020, 1, 1),
            description="First entry",
            postings=[Posting(date=datetime.date(2020, 1, 1), account=RootAccount, amount=Amount(Decimal(100)))],
        )
    ]

    ## Compile program and run:
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-24 01:05:56.872143
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # test obj type
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    entries = [JournalEntry(datetime.date(2020, 1, 1), "Buy", "XXX", [Posting("Expense", Decimal("10"))])]
    initial_balances = {Account("Cash", "XXX"): Balance(datetime.date(2020, 1, 1), Decimal("1234"))}
    general_ledger = build_general_ledger(period, entries, initial_balances)
    assert isinstance(general_ledger.__repr__(), str)


# Generated at 2022-06-24 01:06:06.668525
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .money import Currency

    ledger = Ledger(Account("1010"), Balance(datetime.date.today(), 0))
    journal = Journal(datetime.date.today(), "Test journal")
    posting = Posting(journal, Account("1000"), Currency("TRY"), 10, "Test posting")
    entry = LedgerEntry(ledger, posting, 1)

    assert entry.date == datetime.date.today()
    assert entry.description == "Test journal"
    assert entry.amount == Currency("TRY")(10)
    assert entry.debit == Currency("TRY")(10)
    assert entry.credit == None
    assert entry.is_debit
    assert not entry.is_credit


# Generated at 2022-06-24 01:06:17.320663
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """
    Test for Ledger.__eq__()
    """
    from .accounts import Account

    # Test for when 'other' is not a Ledger
    ledger_a = Ledger(
        account=Account(
            code='1020',
            name='Cash'
        ),
        initial=Balance(
            date=datetime.date(2019, 12, 31),
            value=Decimal('0')
        )
    )
    assert ledger_a != 10
    assert ledger_a == ledger_a
    assert ledger_a != None

    # Test for when 'other' is a Ledger with a different account

# Generated at 2022-06-24 01:06:19.530274
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    a = LedgerEntry(None, None, None)
    a2 = LedgerEntry(None, None, None)
    assert a == a2


# Generated at 2022-06-24 01:06:26.579906
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the function compile_general_ledger_program
    """
    from ..accounting.algebras import AccountingAlgebra
    from ..factories import make_ledger_builder, make_ledger_builder_config
    from .. import LedgerEntry as _LedgerEntry
    from datetime import date as _date
    from unittest.mock import PropertyMock, patch
    from decimal import Decimal

    class MockReadInitialBalances:
        """
        Mocks the algebra ReadInitialBalances.
        """

        def __call__(self, period):
            return {'AccountA': Balance('2018-01-01', Decimal(0)),
                    'AccountB': Balance('2018-01-01', Decimal(0)),
                    'AccountE': Balance('2018-01-01', Decimal(0))}

   

# Generated at 2022-06-24 01:06:35.423151
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger
    """
    from datetime import date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance, Quantity
    from .ledgering import LedgerEntry

    a1 = Account('1000')
    a2 = Account('2000')
    a3 = Account('3000')

    j = Journal(date(2017, 8, 8), 'test', [Posting(a1, Direction.Debit, Quantity(10)),
                                           Posting(a2, Direction.Credit, Quantity(10))])
    l = Ledger(a1, Balance(date(2017, 8, 8), Quantity(0)))
    l.add(j.postings[0])

# Generated at 2022-06-24 01:06:46.346660
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from tests.bracket.domain.test_accounts import test_accounts
    from tests.bracket.domain.test_journaling import test_journal

    a = test_accounts()
    j = test_journal()

    ib = {a["A"]: Balance(j["SO"].date, j["SO"].amount), a["B"]: Balance(j["SO"].date, j["SO"].amount)}
    g = GeneralLedger(DateRange(j["SO"].date, j["SO"].date), ib)

    assert len(g.ledgers) == 2
    assert a["A"] in g.ledgers
    assert g.ledgers[a["A"]].account == a["A"]
    assert g.ledgers[a["A"]].initial.date == ib[a["A"]].date
    assert g

# Generated at 2022-06-24 01:06:57.831317
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    account1 = Account('Assets', 'Current Assets', 'Accounts Receivable')
    account2 = Account('Assets', 'Current Assets', 'Cash')
    date = datetime.date(2018, 1, 1)

# Generated at 2022-06-24 01:07:04.753814
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    dates = [
        datetime.date(year=2020, month=1, day=1),
        datetime.date(year=2020, month=1, day=2),
        datetime.date(year=2020, month=2, day=1),
        datetime.date(year=2020, month=2, day=2),
    ]

    def get_date(index):
        return dates[index]

    gl1 = GeneralLedger(DateRange(get_date(0), get_date(1)), {})
    gl2 = GeneralLedger(DateRange(get_date(0), get_date(1)), {})
    gl3 = GeneralLedger(DateRange(get_date(1), get_date(2)), {})
    assert gl1 == gl2
    assert gl2 == gl1

# Generated at 2022-06-24 01:07:09.806569
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class Test(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    test = Test()
    assert test


# Generated at 2022-06-24 01:07:17.646446
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Create Account object
    account = Account('00001', 'Cash')
    # Create Balance object
    balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))

    # Create Ledger object
    ledger = Ledger(account, balance)

    # Test method __repr__
    assert repr(ledger) == '<Ledger account={0}>'.format(repr(account))


# Generated at 2022-06-24 01:07:22.544420
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    '''
    Ensures data class Ledger behaves correctly with __eq__
    '''
    account = Account('Brandenburger Tor', '0105')
    initial = Balance(datetime(2020, 1, 1), Quantity(Decimal(5)))
    posting1 = Posting(datetime(2020, 1, 1), Quantity.debit(Decimal(-4)), journal1, account)
    posting2 = Posting(datetime(2020, 2, 1), Quantity.credit(Decimal(5)), journal2, account)
    entry1 = LedgerEntry(ledgers['account'], posting1, Quantity(Decimal(1)))
    entry2 = LedgerEntry(ledgers['account'], posting2, Quantity(Decimal(6)))
    ledgers1 = Ledger(account, initial, [entry1])

# Generated at 2022-06-24 01:07:32.427486
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Define types:
    ReadInitialBalances = Callable[[DateRange], InitialBalances]
    ReadJournalEntries = Callable[[DateRange], Iterable[JournalEntry]]
    GeneralLedgerProgram = Callable[[DateRange], GeneralLedger]

    # Define sample input and output:
    args0 = DateRange(datetime.date(2009, 1, 1), datetime.date(2009, 12, 31))
    args1 = DateRange(datetime.date(2010, 1, 1), datetime.date(2010, 12, 31))
    args2 = DateRange(datetime.date(2011, 1, 1), datetime.date(2011, 12, 31))
    ib0 = dict()
    ib1 = dict()
    je0 = list()
    je1 = list()
    # je2 = list()
    gl0

# Generated at 2022-06-24 01:07:39.155755
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    print("Testing method __repr__ of class Ledger")
    date = datetime.date(2020, 1, 10)

    posting = Posting(date, "Test", Quantity(100), 1)

    entry = LedgerEntry(posting, Quantity(100))

    assert repr(entry) == "LedgerEntry(posting=<Posting(date=2020-01-10, description=Test, amount=100.00, direction=1)>, balance=100.00)"

