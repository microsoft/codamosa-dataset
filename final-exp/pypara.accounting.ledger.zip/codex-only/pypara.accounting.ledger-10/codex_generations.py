

# Generated at 2022-06-24 00:57:44.085125
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    posting = Posting(None, Account(None, "A"), Decimal(1), Account(None, None))
    le = LedgerEntry(None, posting, Amount(Decimal(1)))
    assert repr(le) == "LedgerEntry(ledger=None, posting=Posting(journal=None, account=Account(book='A', number=None), amount=Decimal('1'), direction=None), balance=Amount(value=Decimal('1')))"

# Generated at 2022-06-24 00:57:44.519971
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ReadInitialBalances()

# Generated at 2022-06-24 00:57:55.366925
# Unit test for method add of class Ledger
def test_Ledger_add():
    from dataclasses import dataclass
    from decimal import Decimal
    from unittest.mock import Mock
    from ..commons.numbers import Amount, Quantity
    @dataclass
    class JournalEntry():
        @property
        def value(self):
            return Decimal()
    class Account():
        def __init__(self, value):
            self.value = value

    # Mock of the account
    mock_account = Account(value = "mock")

    # Mock of the journal entry
    mock_journal_entry = JournalEntry()

    # Mock of the direction
    mock_direction = Mock()

    # Mock of the posting
    mock_posting = Mock()

    # Mock of the amount
    mock_amount = Quantity(Decimal())

    # Mock of the balance
    mock_balance = Mock()

    #

# Generated at 2022-06-24 00:58:01.218592
# Unit test for method __repr__ of class LedgerEntry

# Generated at 2022-06-24 00:58:09.489060
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(1,'Assets')
    l = Ledger(account,Balance(datetime.date(2020,1,1),Quantity(Decimal(0))))
    assert l.account.id == account.id
    assert l.account.name == account.name
    assert l.initial.date == datetime.date(2020,1,1)
    assert l.initial.value == Quantity(Decimal(0))
    assert l.entries == []


# Generated at 2022-06-24 00:58:18.353626
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Given the function will be tested:
    from .journaling import Journal, Posting
    from .accounts import Account

    ## Initialize accounts
    account_1 = Account(1, "Account 1", "Cost of goods sold")
    account_2 = Account(2, "Account 2", "Depreciation")
    account_3 = Account(3, "Account 3", "Revenue")

    ## Initialize some journal entries:
    journal_1 = Journal(
        1,
        datetime.date(2019, 12, 1),
        "Invoice 1",
        [
            Posting(account_3, Decimal("1000"), +1, 1),
            Posting(account_1, Decimal("500"), -1, 1),
        ],
    )


# Generated at 2022-06-24 00:58:20.434727
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances



# Generated at 2022-06-24 00:58:29.985359
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Test data
    mock_period = DateRange(datetime.date(2007, 1, 1), datetime.date(2007, 12, 31))

# Generated at 2022-06-24 00:58:38.732503
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    a = LedgerEntry("ledger", "posting", "balance")
    assert a.ledger == "ledger"
    assert a.posting == "posting"
    assert a.balance == "balance"
    assert a.date == "a.posting.date"
    assert a.description == "a.posting.journal.description"
    assert a.amount == "a.posting.amount"
    assert a.cntraccts == "[p.account for p in a.posting.journal.postings if p.direction != a.posting.direction]"
    assert a.is_debit == "a.posting.is_debit"
    assert a.is_credit == "a.posting.is_credit"
    assert a.debit == "a.amount if a.is_debit else None"

# Generated at 2022-06-24 00:58:49.408410
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger
    """
    from ..commons.zeitgeist import hours_since
    from .accounts import Account, terminal_account
    from .posting import debit, credit, Posting
    from .journaling import JournalEntry

    now = datetime.datetime.now()

    TEST_SR_2210 = terminal_account("SR-2210")
    TEST_SR_3100 = terminal_account("SR-3100")
    TEST_SR_2110 = terminal_account("SR-2110")
    TEST_SR_1110 = terminal_account("SR-1110")

    opening_balance = terminal_account("SR-1110")
    closing_balance = terminal_account("SR-2210")


# Generated at 2022-06-24 00:58:50.592565
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False


# Generated at 2022-06-24 00:58:51.387845
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 00:58:59.691114
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from src.commons.numbers import Amount, Quantity
    from src.journaling.journaling import Journal, JournalEntry, Posting, T
    from src.ledgering.accounts import Account
    from src.ledgering.generic import Balance
    from src.util import time_now

    # Define fixture
    account = Account(1000, "Asset", "Cash")
    balance = Balance(time_now(), Quantity(Decimal(0)))
    entry = LedgerEntry(
        Ledger(account, balance),
        Posting(
            JournalEntry(Journal(time_now(), False, "Sale of inventory", "Asset"), [T], "Sale of inventory"),
            Account(1000, "Asset", "Cash"),
            Amount(Decimal(100)),
        ),
        Quantity(Decimal(100)),
    )

    # Test


# Generated at 2022-06-24 00:59:09.782460
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from ..commons.zeitgeist import DateRange
    from .commons import AnonymousPosting

    read_initial_balances = lambda period: {Account("1"): Balance(period.since, Quantity(Decimal(0)))}
    read_journal_entries = lambda period: [
        AnonymousPosting.of(period.since, Quantity(Decimal(10))),
        AnonymousPosting.of(period.since, Quantity(Decimal(20))),
    ]

    glp = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    period = DateRange(0,0)
    assert glp(period).ledgers[Account("1")].entries[0].balance == Quantity(Decimal(10))

# Generated at 2022-06-24 00:59:10.343919
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-24 00:59:18.948076
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from datetime import date
    from dataclasses import dataclass

    @dataclass
    class Account:
        pass

    @dataclass
    class Journal:
        date: date

    @dataclass
    class Posting:
        account: Account
        journal: Journal
        amount: int

    @dataclass
    class Ledger:
        pass

    @dataclass
    class LedgerEntry:
        ledger: Ledger
        posting: Posting
        balance: int

    account = Account()
    journal = Journal(date(2020, 7, 16))
    posting = Posting(account, journal, 0)
    ledger = Ledger()
    ledger_entry = LedgerEntry(ledger, posting, 0)
    print(ledger_entry.__repr__())

# Generated at 2022-06-24 00:59:30.809009
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    import datetime
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity

    a1 = Account('a1', AccountType.ASSET, '', '')
    a2 = Account('a2', AccountType.LIABILITY, '', '')
    a3 = Account('a3', AccountType.EXPENSE, '', '')
    a4 = Account('a4', AccountType.EQUITY, '', '')
    a5 = Account('a5', AccountType.INCOME, '', '')
    accounts = [
        a1, a2, a3, a4, a5
    ]


# Generated at 2022-06-24 00:59:35.229599
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances(
        period=DateRange(since=date(2017, 1, 1), until=date(2017, 12, 31))
    ) == {Account("Assets", "Cash"): Balance(date(2017, 1, 1), Quantity(Decimal("25000")))}


# Generated at 2022-06-24 00:59:42.501106
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    account1 = Account(code='1234', name='cash on hand')
    account2 = Account(code='9012', name='cash on bank')
    post = Posting(account=account1, direction='debit', amount=Decimal(1.50))
    post.journal = JournalEntry(date=datetime(2018, 12, 2), description='Lunch to A')
    ledger = Ledger(account=account2, initial=Decimal(100.00))
    entry = LedgerEntry(ledger=ledger, posting=post, balance=Decimal(101.50))

# Generated at 2022-06-24 00:59:46.378012
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    """
    pass

# Generated at 2022-06-24 00:59:57.035274
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.numbers import Amount
    from .accounts import Account, AccountMaster, TerminalAccount
    from .journaling import Journal, Posting

    # Create temporary AccountMaster:
    account_master = AccountMaster("TestAccountMaster")

    # Define opening balances:
    initial_balances = {
        TerminalAccount(account_master, 0, "00000"): Balance(datetime.date(2020, 1, 1), Quantity(1)),
        TerminalAccount(account_master, 0, "00001"): Balance(datetime.date(2020, 1, 1), Quantity(2)),
    }

    # Define journal entries:

# Generated at 2022-06-24 01:00:03.150430
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():

    # Create a Balance object
    balance1 = Balance(datetime.datetime(2020, 1, 1), Quantity(Decimal(10.1)))
    # Create an Account object
    account1 = Account(number="0000", name="Account", terminal=True)
    # Create a Ledger object
    ledger1 = Ledger(account=account1, initial=balance1)

    # Create a Balance object
    balance2 = Balance(datetime.datetime(2020, 1, 1), Quantity(Decimal(10.1)))
    # Create an Account object
    account2 = Account(number="0000", name="Account", terminal=True)
    # Create a Ledger object
    ledger2 = Ledger(account=account2, initial=balance2)

    # Perform test
    assert ledger1 == ledger2



# Generated at 2022-06-24 01:00:04.095223
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass

# Generated at 2022-06-24 01:00:08.698451
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    """
    Test if object is properly instantiated
    """
    value = GeneralLedger('Period', 'Ledgers')
    assert value.period == 'Period'
    assert value.ledgers == 'Ledgers'


# Generated at 2022-06-24 01:00:18.272593
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """

    # Define a test period:
    test_period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    # Define a test account:
    test_account = Account(1234, "Assets")

    # Define an initial balance for the above account:
    test_initial_balance = Balance(test_period.since, Quantity(Decimal(0)))

    # Define a test ledger entry:
    test_ledger_entry = LedgerEntry(
        test_account, Posting(test_period.since, test_account, Direction.debit(), Quantity(Decimal(100))), Quantity(Decimal(100))
    )

    # Define a test general ledger:
    test

# Generated at 2022-06-24 01:00:27.730697
# Unit test for constructor of class Ledger
def test_Ledger():
    # Test 1: Lot of entries
    test_account = Account('test acc')
    test_balance = Balance(datetime.date(2020, 10, 1), Decimal('100'))
    test_journal = JournalEntry(
        test_account,
        datetime.date(2020, 10, 2),
        'Test Journal Entry'
    )
    test_posting1 = Posting(
        test_journal,
        test_account,
        Decimal('10'),
    )
    test_posting2 = Posting(
        test_journal,
        test_account,
        Decimal('10'),
    )
    test_posting3 = Posting(
        test_journal,
        test_account,
        Decimal('10'),
    )

# Generated at 2022-06-24 01:00:30.239236
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    testee=LedgerEntry(None,None,None)
    assert testee == testee


# Generated at 2022-06-24 01:00:36.324942
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():

    from .accounts import Account, TransactionAccount, EquityAccount

    # Declare accounts:
    a_asset = TransactionAccount("Asset")
    a_equity = EquityAccount("Equity")

    # Declare ledger entries:
    le1 = LedgerEntry(Ledger(a_asset, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))), None, Quantity(Decimal(10)))
    le2 = LedgerEntry(Ledger(a_asset, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))), None, Quantity(Decimal(10)))
    le3 = LedgerEntry(Ledger(a_asset, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))), None, Quantity(Decimal(0)))

# Generated at 2022-06-24 01:00:45.325066
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    l = Ledger(Account(AccountType.EXPENSE, "An account"), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0))))
    l_same = Ledger(Account(AccountType.EXPENSE, "An account"), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0))))
    l_diff_account = Ledger(Account(AccountType.EXPENSE, "Another account"), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0))))
    l_diff_initial = Ledger(Account(AccountType.EXPENSE, "An account"), Balance(datetime.date(2000, 1, 2), Quantity(Decimal(0))))
    assert l == l_same
    assert l != l_diff_account
    assert l != l_diff_initial



# Generated at 2022-06-24 01:00:54.483904
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .journaling import Journal, Posting, Direction
    from .accounts import Account, AccountType

    from .generic import Balance, Quantity

    balance = Balance(date = datetime.date(2020,6,30), value = Quantity(10))
    account = Account(name = 'An', number = 30, type = AccountType.ASSET)
    direction = Direction.DEBIT
    journal = Journal(date = datetime.date(2020,6,30), description = 'desc')
    posting = Posting(account = account, journal = journal, direction = direction, amount = Quantity(10))
    ledger = Ledger(account = account, initial = balance)
    entry = LedgerEntry(ledger = ledger, posting = posting, balance = Quantity(10))

# Generated at 2022-06-24 01:00:59.670894
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def read_initial_balances(period):
        return {10: Balance(period.since, Quantity(Decimal(0)))}

    def read_journal_entries(period):
        return iter([JournalEntry([Posting(10, 1, Decimal(100))], "", None, period.since)])

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    general_ledger = program(DateRange(period.since, period.until))
    assert len(general_ledger.ledgers) == 1
    assert 10 in general_ledger.ledgers
    assert general_ledger.ledgers[10].account == 10
    assert general_ledger.ledgers[10].initial == Balance(period.since, Quantity(Decimal(0)))

# Generated at 2022-06-24 01:01:10.477594
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from moneyed import PLN, Money
    from datetime import date

    from accounting.journaling import Journal, JournalEntry, Posting, Direction

    account = Account('1.1.1.', 'Spolka', 'Pierwszy opis')
    initial = Balance(date(2019, 1, 1), Money(Decimal(0), PLN))
    entry = Posting(Direction.Debit, Money(Decimal(150), PLN), JournalEntry(date(2020, 2, 2), 'Opis drugi', Journal('1', 'Opis jednego')))

    l = Ledger(account, initial)
    l.add(entry)


# Generated at 2022-06-24 01:01:22.414461
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import (
        Posting,
        JournalEntry,
        JournalEntryType,
        JournalEntryDirection,
        JournalEntryItem,
        journal_entry,
        JournalEntryItemType,
    )
    from .revenues import RentalIncomeType
    from .commons.zeitgeist import financial_year, Date

    ## Define some unit test data:

# Generated at 2022-06-24 01:01:33.127073
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .__test_journaling import build_journal_entries, DummyJournalRepository

    repository = DummyJournalRepository()

    journal = build_journal_entries(repository)

    initial_balances = {a: Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))) for a in journal.terminal_accounts}

    gl = compile_general_ledger_program(
        read_initial_balances=lambda p: {
            k: initial_balances[k] for k in initial_balances if initial_balances[k].date < p.since
        },
        read_journal_entries=lambda p: (j for j in journal.entries if p.period.since <= j.date <= p.period.until),
    )


# Generated at 2022-06-24 01:01:43.225028
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    ledger = Ledger(Account(123, "name", Description("description",)), Balance(datetime.date(2020, 3, 1), Quantity(0)))
    entry = LedgerEntry(ledger, Posting(datetime.date(2020, 3, 1),
                                        Journal(datetime.date(2020, 3, 1), "desc", [Posting(datetime.date(2020, 3, 1),
                                                                                             Account(1234, "name",
                                                                                                     Description("description",)),
                                                                                             Amount(10))]),
                                        ledger.account, Amount(10)), Quantity(10))

# Generated at 2022-06-24 01:01:53.316052
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _AccountStorage(Generic[_T]):
        accounts: Dict[Account, Balance]

        # def __init__(self, accounts: Dict[Account, Balance]):
        #     self.accounts = accounts

        def __call__(self, period: DateRange) -> InitialBalances:
            return dict(self.accounts)


# Generated at 2022-06-24 01:02:02.125927
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    _T=Account
    account=Account(code="t", description="t")
    initial=Balance(since=datetime.date(2019,1,1), value=Quantity(Decimal(1.0)))
    entries=[]
    ledger=Ledger(account=account, initial=initial, entries=entries)
    assert str(ledger) == "Ledger(account=Account(code='t', description='t'), initial=Balance(since=datetime.datetime(2019, 1, 1, 0, 0), ending=datetime.datetime(2019, 1, 1, 0, 0), value=1), entries=[])"


# Generated at 2022-06-24 01:02:12.743639
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .commons.zeitgeist import DateRange

    # Setup
    account = Account(AccountType.Asset, 2, 'Bank', None)
    initial_balance = Balance(datetime.date(2009, 1, 1), Quantity(Decimal(10)))
    period = DateRange(datetime.date(2009, 1, 1), datetime.date(2009, 12, 31))
    journal = JournalEntry(datetime.date(2009, 1, 1), 'Debit', [Posting(account, False, Quantity(Decimal(1)))])
    initial_balances = {account: initial_balance}
    ledger = Ledger(account, initial_balance)

    # Exercise
    ledger.add(journal.postings[0])

    # Verify


# Generated at 2022-06-24 01:02:21.242800
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, Asset, Expense, Liability
    from .journaling import JournalEntry, Posting, UnitOfAccount
    from .ledgering import GeneralLedgerProgram

    # Define a read journal entries algebra implementation:
    ## Note: This will never exist, since this is just for illustration purposes.

# Generated at 2022-06-24 01:02:29.874995
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    obj1=LedgerEntry(1,2,3)
    obj2=LedgerEntry(1,2,3)
    assert obj1==obj2
    assert not obj1==None
    assert not obj1==0
    obj1=LedgerEntry(1,2,3)
    obj2=LedgerEntry(2,2,3)
    assert not obj1==obj2
    obj1=LedgerEntry(1,2,3)
    obj2=LedgerEntry(1,3,3)
    assert not obj1==obj2
    obj1=LedgerEntry(1,2,3)
    obj2=LedgerEntry(1,2,4)
    assert not obj1==obj2


# Generated at 2022-06-24 01:02:40.837249
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, BankAccount, IncomeAccount
    from .journaling import JournalEntry, Posting
    import datetime
    # Creating the bank account with its initial balance
    ledger = Ledger(BankAccount("100", "BANK", "BANK"), Balance(datetime.date(2019, 12, 31), Quantity(0)))
    # Creating the income account with its initial balance
    ledger_2 = Ledger(IncomeAccount("400", "INCOME", "INCOME"), Balance(datetime.date(2019, 12, 31), Quantity(0)))
    
    # Creating a bunch of ledger entries
    posting = Posting("001", "2019-01-01", ledger.account, ledger_2.account, Quantity(1000))
    entry = LedgerEntry(ledger, posting, 0)

# Generated at 2022-06-24 01:02:49.166400
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .commons import read_accounting_period, read_initial_balances, read_journal_entries

    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    accounting_period = read_accounting_period()
    gl = general_ledger_program(accounting_period)
    assert gl is not None
    assert gl.ledgers is not None
    assert len(gl.ledgers) == 15
    assert gl.ledgers["GK101"].entries is not None

# Generated at 2022-06-24 01:02:58.814447
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import AccountType

    from .journaling import Journal, Posting, create_journal_entry

    from .testlib import assert_equals, assert_not_equals
    from .testlib.entities import create_balances, create_posting_data
    from .testlib.types import FakeJournalEntries, FakeBalances

    ## Mocks.
    @FakeBalances
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return create_balances(period.since, period.until)


# Generated at 2022-06-24 01:03:05.551417
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class _TestReadInitialBalances(ReadInitialBalances):
        a: int

        def __call__(self, period: DateRange) -> InitialBalances:
            return {self.a: self.a}

    # Constructor
    read_initial_balances = _TestReadInitialBalances(1)

    # Test method
    assert read_initial_balances(1) == {1: 1}


# Generated at 2022-06-24 01:03:16.396975
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .fixtures.journaling import journal_entries
    from .fixtures.accounting import initial_balances_factory

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    gl = build_general_ledger(period, journal_entries, initial_balances_factory())


# Generated at 2022-06-24 01:03:23.144571
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    acc = Account(1,'asset', 'current assets', 'cash')
    val = Quantity(Decimal(1))
    bal = Balance(datetime.date(2019, 12, 4), val)
    l = Ledger(acc, bal)
    assert repr(l) == '<Ledger account=<Account id=1 name=cash classification=current assets type=asset> initial=<Balance date=2019-12-04 value=1> entries=[]>'


# Generated at 2022-06-24 01:03:32.224858
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ## Initialize
    # First Ledger
    accountA = Account(number="A001", name="AccountA")
    initialA = Balance(datetime.datetime(2020,1,1,0,0,0), Decimal(0))
    entryA = LedgerEntry(None, None, Decimal(0))
    ledgerA = Ledger(accountA, initialA)
    ledgerA.entries.append(entryA)

    # Second Ledger
    accountB = Account(number="A001", name="AccountA")
    initialB = Balance(datetime.datetime(2020,1,1,0,0,0), Decimal(0))
    entryB = LedgerEntry(None, None, Decimal(0))
    ledgerB = Ledger(accountB, initialB)

# Generated at 2022-06-24 01:03:42.751492
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    #Journal = journal.Journal
    #Posting = posting.Posting
    #Transaction = transaction.Transaction
    #TransactionType = transaction_types.TransactionType
    #TransactionDirection = transaction_types.TransactionDirection
    from .accounts import AccountType

    a = Account("Business", AccountType.ASSET, None, None)
    b = Account("Capital", AccountType.EQUITY, None, None)
    c = Account("Cash", AccountType.ASSET, None, None)
    d = Account("Cost of Goods Sold", AccountType.EXPENSE, None, None)
    e = Account("Inventory", AccountType.ASSET, None, None)
    f = Account("Sales", AccountType.REVENUE, None, None)


# Generated at 2022-06-24 01:03:47.118556
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("Expenses:Lunch")
    initial_balance = Balance(datetime.date(2020, 8, 12), Quantity(Decimal(0)))
    exp = Ledger(account, initial_balance, [])
    assert exp.account == account
    assert exp.initial == initial_balance
    assert exp.entries == []
    assert exp._last_balance == initial_balance.value


# Generated at 2022-06-24 01:03:52.414535
# Unit test for function build_general_ledger
def test_build_general_ledger():
    Cash = Account("110", "CASH", True)
    Sales = Account("400", "SALES", True)
    Bank = Account("111", "BANK", True)
    AR = Account("411", "ACCOUNTS RECIEVABLE", True)
    initial_balances = {
        Cash: Balance(datetime.date(2019, 12, 1), Quantity(1000)),
        Bank: Balance(datetime.date(2019, 12, 1), Quantity(2000)),
        AR: Balance(datetime.date(2019, 12, 1), Quantity(1000)),
    }
    JournalEntry = dataclasses.make_dataclass(
        "JournalEntry", [("date", datetime.date), ("description", str), ("postings", List[Posting])]
    )

# Generated at 2022-06-24 01:04:04.164526
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Tests the constructor with a concrete implementation of the
    algebra to prove that it consumes the implementation and produces a program.
    """

    # Concrete implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A1"): Balance(datetime.date(2000, 1, 1), Quantity(1.0))}

    def read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:
        return [
            JournalEntry(
                datetime.date(2000, 1, 1),
                "description 1",
                [
                    Posting(Account("A1"), Quantity(0.5), 1),
                    Posting(Account("A2"), Quantity(0.5), -1),
                ],
            )
        ]

    # Expected value of

# Generated at 2022-06-24 01:04:10.888562
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # Test variables
    begin_date = datetime.datetime(2020, 7, 1)
    end_date = datetime.datetime(2020, 7, 31)
    account = Account(name="Assets", code="100.000")
    balance = Balance(begin_date, Quantity(100))
    initial_balances = {account: balance}

    # Test the constructor
    read_initial_balances = ReadInitialBalances()
    assert read_initial_balances.__call__(DateRange(begin_date, end_date)) == initial_balances



# Generated at 2022-06-24 01:04:20.794546
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for function __call__ of class GeneralLedgerProgram.
    """
    ## Define a set of accounts:

# Generated at 2022-06-24 01:04:24.290265
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    This function checks whether the constructor of class Ledger works
    """
    from ..commons.numbers import Quantity

    account = "A"
    initial = Quantity(Decimal("2"))
    testLedger = Ledger(account=account, initial=initial)
    assert account == testLedger.account, "account is incorrect"
    assert initial == testLedger.initial, "initial is incorrect"



# Generated at 2022-06-24 01:04:27.408984
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    _instance = ReadInitialBalances.__new__(ReadInitialBalances)
    assert isinstance(_instance, ReadInitialBalances)


# Generated at 2022-06-24 01:04:38.227860
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Prepare some test data:
    account = Account(code="1010", name="Cash")
    posting = Posting(
        account=account,
        amount=Decimal(123.45),
        direction=Posting.DR,
        journal=JournalEntry(
            date=datetime.date(2020, 2, 25),
            description="Lorem ipsum dolor sit amet",
            postings=[posting],
        ),
    )

    ## Create an empty ledger for the test account:
    ledger = Ledger(account, Balance(datetime.date(2020, 1, 1), Decimal(0)))

    ## Apply the posting to the ledger and assert that the resulting ledger entry is as expected:
    entry = ledger.add(posting)
    assert entry

# Generated at 2022-06-24 01:04:46.106784
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Prepare
    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, Posting
    from . import commons as c

    account = Account("A")
    ledger = Ledger(account, Balance(c.date(2019, 10, 10), Quantity(Decimal(0))))
    journal = Journal(c.date(2019, 10, 1), "J", [Posting(account, Amount(Decimal(1000)), c.Debit)])
    posting = journal.postings[0]
    # Execute
    entry = ledger.add(posting)
    # Verify
    assert posting == entry.posting
    assert Quantity(Decimal(1000)) == entry.balance
    assert ledger == entry.ledger


# Generated at 2022-06-24 01:04:53.368727
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..journaling import journal_entry, posting
    from ..accounts import account

    def test(opening, posting_amount, expected_amount):
        opening_balance = Balance(date(2020, 6, 1), Quantity(Decimal(opening)))
        date1 = date(2020, 6, 1)
        date2 = date(2020, 6, 2)
        date3 = date(2020, 6, 3)
        date4 = date(2020, 6, 4)
        date5 = date(2020, 6, 5)
        opening_posting = posting(date1, account("expenses", "bank charges"), Decimal(-10), "opening account")
        posting_1 = posting(date2, account("income", "dividends"), Decimal(posting_amount), "dividends")
        posting_2 = posting

# Generated at 2022-06-24 01:05:05.660982
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from unittest.mock import MagicMock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Quantity
    from .initial_balances import InitialBalances
    from .journaling import JournalEntry, Posting

    # Define test cases:

# Generated at 2022-06-24 01:05:10.166819
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .algebras.datastore import load_ledger_entries as load_ledger_entries

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 2, 1))
    initial_balances: InitialBalances = load_ledger_entries(period.since)

    # assert initial_balances is not None
    assert initial_balances is not None
    assert initial_balances.get(Account("101")) is not None

# Generated at 2022-06-24 01:05:13.706722
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # The repr of class Ledger should return the name of the account
    account = Account('asset', 'bank', 'Cash')
    initial = Balance(Decimal.Zero)
    ledger = Ledger(account, initial)
    assert ledger.__repr__() == 'Cash'


# Generated at 2022-06-24 01:05:19.334308
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
        This function tests the build_general_ledger function
    """
    # First test case
    # Assumptions:
    # First ever entry in the ledger

    # Initial ledger accounts
    initial = {"TOTALASSETS": Balance(datetime.date(2020, 1, 1), Quantity(100))}
    # Initial journal entry
    journal = [JournalEntry(
        date=datetime.date(2020, 1, 2),
        description="My First journal entry",
        postings=[Posting(account="CASH", amount=1000, direction=Credit),
                  Posting(account="TOTALASSETS", amount=1000, direction=Debit)])]
    # Accounting period
    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 2, 1))

    # Expected outcome

# Generated at 2022-06-24 01:05:28.941371
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import journal_entry, posting
    from .algebra import initial_balance
    from ..commons.zeitgeist import date_range, since, until

    period = date_range(since(2019, 1, 1), until(2019, 12, 31))

    def read_initial_balances(p: DateRange) -> InitialBalances:
        return {
            initial_balance(period, "CASH", "ASSETS", "0", "0"): Balance(period.since, Decimal(0)),
            initial_balance(period, "REVENUE", "INCOME", "0", "0"): Balance(period.since, Decimal(0)),
            initial_balance(period, "RETAINED EARNINGS", "EQUITY", "0", "0"): Balance(period.since, Decimal(0)),
        }

# Generated at 2022-06-24 01:05:36.511398
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account('11009',"konto1","asset",'terminal',1)
    ledger = Ledger(account,Balance(datetime.date(2020,1,1),300))

    account2 = Account('11009',"konto1","asset",'terminal',1)
    ledger2 = Ledger(account2,Balance(datetime.date(2020,1,1),300))


    assert(ledger == ledger2)



# Generated at 2022-06-24 01:05:37.556784
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:05:45.458313
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from ..categories.accounts.domain.models import AccountCategory, AccountType
    from ..categories.accounts.domain.services import create_account_category
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .ledgering import Ledger, build_general_ledger

    # Create an expense account category.
    expense_account_category: AccountCategory = create_account_category(AccountCategory, AccountType.EXPENSE)
    expense_account: Account = expense_account_category.create_account("Expenses", "Expenses")

    # Create a journal entry.

# Generated at 2022-06-24 01:05:53.835154
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(0, 0, 0, 0, '0000', 'test-account')
    date = datetime.date(2018, 4, 11)
    initial = Balance(date, Quantity(Decimal(0)))
    ledgers = Ledger(account, initial)
    assert isinstance(ledgers.account, Account)
    assert ledgers.account == account
    assert isinstance(ledgers.initial, Balance)
    assert ledgers.initial == initial
    assert isinstance(ledgers.entries, list)
    assert ledgers.entries == []


# Generated at 2022-06-24 01:06:05.005157
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .journaling import JournalEntry
    from .accounts import Account
    from .commons.numbers import Amount
    acc = Account(code="01.23.45", title="Test Account")
    from . import accounts as data
    data.__accounts__[acc] = acc
    je = JournalEntry(
        date=datetime.date(2018, 10, 11),
        description="Test Journal Entry",
        postings=[
            Posting(date=datetime.date(2018, 10, 11), account=acc, amount=Amount(10)),
            Posting(date=datetime.date(2018, 10, 11), account=acc, amount=Amount(-10))
        ]
    )

# Generated at 2022-06-24 01:06:10.344840
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_ledger = Ledger(Account(1), Balance(datetime.date(2019, 10, 21), Quantity(Decimal(100))))
    test_posting = Posting(datetime.date(2019, 10, 22), Account(2), Account(1), Quantity(Decimal(100)))
    test_entry = test_ledger.add(test_posting)
    assert test_entry.posting == test_posting
    assert test_entry.balance == Quantity(Decimal(200))


# Generated at 2022-06-24 01:06:19.741193
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from decimal import Decimal
    from typing import Generator
    from .accounts import Account, debit_account, credit_account
    from .journaling import JournalEntry, Posting
    from .reports import Balance
    from .utils import date_range

    # Fake values for unit tests:
    fake_period = date_range(datetime.date(2016, 1, 1), datetime.date(2016, 4, 1))
    fake_initial_balances = {Account("0000"): Balance(fake_period.since, Quantity(Decimal(0)))}

# Generated at 2022-06-24 01:06:22.194698
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    LedgerEntry should give a human-readable string representation of its attributes.
    """
    assert str(LedgerEntry(None, None, None)) == "LedgerEntry(ledger=None, posting=None, balance=None)"


# Generated at 2022-06-24 01:06:32.856783
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
  from ..commons.period import build_period
  from ..commons.zeitgeist import str_to_date
  from .accounts import build_account
  from .journaling import Posting, JournalEntry
  period_str = "2019-01-01/2019-12-31"
  period = build_period(period_str)
  tomita = build_account("000005")
  arita = build_account("000002")
  bank_of_tokyo = build_account("000001")
  posting1 = Posting(tomita, str_to_date("2019-01-01"), 100, "Sales to Arita")
  posting2 = Posting(arita, str_to_date("2019-01-01"), -100, "Sales to Arita")

# Generated at 2022-06-24 01:06:40.493608
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .algebra import balance, journal
    from .journaling import debit, credit, journal_entry

    GL_ACCOUNT = Account("GL")
    BANK_ACCOUNT = Account("BANK")
    FEE_INCOME = Account("FEE_INCOME")
    BANK_FEE_EXPENSE = Account("BANK_FEE_EXPENSE")

    def read_initial_balances(period: DateRange) -> InitialBalances:
        if period.since == datetime.date(2019, 1, 1) and period.until == datetime.date(2019, 1, 31):
            return {GL_ACCOUNT: balance(GL_ACCOUNT, datetime.date(2018, 12, 31), Decimal(10000))}
        else:
            raise RuntimeError("Unexpected period")


# Generated at 2022-06-24 01:06:45.075258
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert repr(GeneralLedger(DateRange(datetime.date(2019, 3, 1), datetime.date(2019, 3, 31)),{})) == "GeneralLedger(period=DateRange(since=datetime.date(2019, 3, 1), until=datetime.date(2019, 3, 31)), ledgers={})"

# Generated at 2022-06-24 01:06:45.996270
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ##TODO
    pass

# Generated at 2022-06-24 01:06:46.653651
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass

# Generated at 2022-06-24 01:06:57.993927
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Declare variables:
    A = Account("Assets:Current Assets:Cash")
    B = Account("Assets:Current Assets:Cash")
    C = Account("Assets:Current Assets:Cash")
    D = Account("Assets:Current Assets:Checking")
    E = Account("Assets:Current Assets:Checking")
    F = Account("Assets:Current Assets:Checking")
    G = Account("Assets:Current Assets:Savings")
    H = Account("Assets:Current Assets:Savings")
    I = Account("Assets:Current Assets:Savings")
    J = Account("Assets:Current Assets:Cash, Checking, and Savings")
    K = Account("Assets:Current Assets:Cash, Checking, and Savings")
    L = Account("Assets:Current Assets:Cash, Checking, and Savings")

# Generated at 2022-06-24 01:07:00.718801
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledgers = Ledger(1, Balance(1, Quantity(Decimal(0))))
    posting = Posting(1, 1, 'debit', 1, 1)
    entry = ledgers.add(posting)
    assert entry.amount == 1

# Generated at 2022-06-24 01:07:01.502493
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-24 01:07:06.648408
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    print("Test method __eq__ of class Ledger")
    ledger = Ledger('Account', 'Balance')
    assert(ledger == Ledger('Account', 'Balance'))
    assert(ledger == ledger)
    assert(ledger != Ledger('Account', 'Balance1'))
    assert(ledger != Ledger('Account1', 'Balance'))
    assert(ledger != Ledger('Account1', 'Balance1'))
    assert(ledger != None)

test_Ledger___eq__()


# Generated at 2022-06-24 01:07:09.814494
# Unit test for constructor of class Ledger
def test_Ledger():
    from .accounts import AccountType, Account

    acc = Account(
        code="0100",
        title="Cash",
        type=AccountType.Terminal)
    bal = Quantity(Decimal(0))
    entries = []
    ledger = Ledger(acc, bal, entries)
    assert ledger.account.code == "0100"
    assert ledger.entries == []


# Generated at 2022-06-24 01:07:22.236049
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Set variables
    date = datetime.date(2018, 10, 1)
    account = Account(
        code="1400",
        name="Accounts Receivable",
        classification="Asset",
        normal_balance="Debit",
        description="Accounts Receivable",
    )
    posting_amount = Amount(10.00)
    posting_direction = Direction(1)
    posting_journal = JournalEntry(date, "Debit Customer", [
        Posting(account, posting_amount, posting_direction),
        Posting(Account(
            "1111",
            "Sales",
            "Income",
            "Credit",
            "Sales",
        ), -posting_amount, posting_direction),
    ])
    posting = Posting(account, posting_amount, posting_direction, posting_journal)

# Generated at 2022-06-24 01:07:23.671824
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:07:32.027028
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Create two ledger entries
    entry = LedgerEntry(ledger=None, posting=Posting(journal=None, account=None, amount=None, direction=None), balance=Decimal('10'))
    entry2 = LedgerEntry(ledger=None, posting=Posting(journal=None, account=None, amount=None, direction=None), balance=Decimal('10'))
    # Set two ledgers as per the two entries
    ledger = Ledger(account=None, initial=None, entries=[entry])
    ledger2 = Ledger(account=None, initial=None, entries=[entry2])
    # Test __eq__ method of Ledger
    assert ledger.__eq__(ledger2) == True


# Generated at 2022-06-24 01:07:41.691675
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Test data
    _period = DateRange(datetime.date(2018, 12, 1), datetime.date(2018, 12, 31))
    _journal_entry_1 = JournalEntry(_period.since, "Test1", Posting(Quantity(Decimal(100)), "Test2"),
                                    Posting(Quantity(Decimal(100)), "Test3"))
    _journal_entry_2 = JournalEntry(_period.since, "Test4", Posting(Quantity(Decimal(200)), "Test5"),
                                    Posting(Quantity(Decimal(200)), "Test6"))
    _journal_entries = [_journal_entry_1, _journal_entry_2]
    _initial = InitialBalances()

    # Perform test
    _ledgers = build_general_ledger(_period, _journal_entries, _initial).ledgers