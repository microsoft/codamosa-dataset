

# Generated at 2022-06-24 00:57:47.725607
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # Set up for test
    from ledger.accounts import Account
    acct = Account("acct1")
    from ledger.journaling.model import Posting
    from ledger.journaling.model import Journal
    from ledger.commons.numbers import Amount
    from ledger.commons.numbers import Quantity
    from ledger.commons.zeitgeist import DateRange
    from datetime import date
    p = Posting(date.today(), 1, Journal("test", "test", []))
    b = Quantity(3.2, 3)
    l = Ledger(acct, Balance(date.today(), b))

    # Unit test
    le = LedgerEntry(l, p, Quantity(2.1, 3))
    assert le.ledger.account == acct
    assert le.posting.date == date.today()
   

# Generated at 2022-06-24 00:57:57.177434
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from .journaling import JournalEntry, Posting, Transaction

    # Test data
    period = DateRange(since=datetime.date(2016, 1, 1), until=datetime.date(2016, 12, 31))
    trn1 = Transaction(date=datetime.date(2016, 8, 1), description="Description", postings=(
        Posting(account=1, description="Description", amount=Amount(3.45)),
        Posting(account=2, description="Description", amount=Amount(-3.45)),
    ))
    trn2 = Transaction(date=datetime.date(2016, 8, 1), description="Description", postings=(
        Posting(account=1, description="Description", amount=Amount(3.45)),
        Posting(account=2, description="Description", amount=Amount(-3.45)),
    ))
    gl_

# Generated at 2022-06-24 00:58:06.549884
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .accounts import Account, AccountType, TerminalAccount
    from datetime import datetime
    from .journaling import Journal, JournalEntry
    from .commons import Direction, Debit, Credit
    from .generic import Quantity, Amount, Balance
    from .commons.zeitgeist import DateRange
    import datetime
    from decimal import Decimal
    from typing import Dict, List
    from decimal import Decimal
    from .journaling import Posting, JournalEntry
    from .accounts import Account, TerminalAccount
    from .general_ledger import Ledger, GeneralLedger
    from .generic import Balance, Quantity

# Generated at 2022-06-24 00:58:15.340578
# Unit test for method add of class Ledger
def test_Ledger_add():
    a = Account('1206', 'Long Term Liabilities')
    b = Balance(Decimal(100), Decimal(100))
    c = Ledger(a, b)
    d = JournalEntry('1', '', '', '', '', '', '', [])
    e = Posting(d, '1', a, Decimal('-300'), '', Decimal('300'))
    f = c.add(e)
    assert f.balance == Decimal('-200')


# Generated at 2022-06-24 00:58:25.574530
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Setup
    account1 = Account(
        "4000000",
        "Cash",
        1,
        "ACTIVO",
        True,
        True,
        False,
        False,
        False,
        None,
        None,
    )
    account2 = Account(
        "3000000",
        "Debtors",
        1,
        "ACTIVO",
        False,
        False,
        False,
        False,
        False,
        None,
        None,
    )
    direction = None

# Generated at 2022-06-24 00:58:33.473809
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():

    from .journaling import JournalEntry

    from .messages import PostingError
    from .messages import ValidationError
    from .validation import PeriodValidator, PostingValidator

    from .accounts import Account
    from .accounts import TerminalAccount
    from .accounts import Asset
    from .accounts import Expense
    from .accounts import Liability
    from .accounts import Equity
    from .accounts import Income
    from .accounts import Sales

    from ..commons.communications import ReportingServer
    from ..commons.communications import ReportingError

    from ..commons.dates import DateNotInValidRangeError
    from ..commons.dates import DateOutOfRangeError

    from ..commons.zeitgeist import DateRange
    from ..commons.zeitgeist import FinPeriod

    from ..commons.numbers import Currency

# Generated at 2022-06-24 00:58:39.064994
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Test when the 2 ledgers are equal
    ledger = Ledger(Account("1000"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(20))))
    ledger.add(Posting('2018-12-10', '1000', Quantity(Decimal(10)), True))
    ledger.add(Posting('2018-12-15', '1000', Quantity(Decimal(5)), False))
    ledger2 = Ledger(Account("1000"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(20))))
    ledger2.add(Posting('2018-12-10', '1000', Quantity(Decimal(10)), True))
    ledger2.add(Posting('2018-12-15', '1000', Quantity(Decimal(5)), False))
    assert ledger == ledger2
    # Test when the 2 ledgers

# Generated at 2022-06-24 00:58:43.390110
# Unit test for constructor of class Ledger
def test_Ledger():
    assert Ledger(Account('Assets', 'Cash'), Balance(datetime.datetime.now(), Quantity(Decimal(0))))


# Generated at 2022-06-24 00:58:44.284552
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 00:58:46.605957
# Unit test for constructor of class Ledger
def test_Ledger():
    l = Ledger("1", Balance("01-01-2019", Quantity(Decimal(100))))
    assert l.account == "1"
    assert l.initial.value == Quantity(Decimal(100))

# Generated at 2022-06-24 00:58:55.296993
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from cihub.accounting.accounts import create_account_hierarchy
    from cihub.accounting.journaling import build_journal

    # Build account hierarchy:

# Generated at 2022-06-24 00:59:06.226452
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Unit test for method __repr__ of class GeneralLedger
    """
    period = DateRange(datetime.date(2018, 9, 1), datetime.date(2019, 2, 28))
    initial_balances = {
        Account(['1010', '1011']) : Balance(
            datetime.date(2018, 9, 1),
            Quantity(Decimal('100'))
        )
    }

# Generated at 2022-06-24 00:59:15.608259
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from datetime import date

    from .accounts import Account, TerminalAccount

    from .generic import Balance

    from .journaling import Journal, JournalEntry, Posting

    from .ledgers import GeneralLedger

    from .commons import zeitgeist

    period = zeitgeist.DateRange(date(2018, 1, 1), date(2018, 12, 31))

    initial = {
        TerminalAccount.receivables_general: Balance(date(2018, 1, 1), Quantity(100)),
        TerminalAccount.payables_general: Balance(date(2018, 1, 1), Quantity(200)),
    }


# Generated at 2022-06-24 00:59:19.030728
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account(200121, 'Konto 1-2-2')
    b = Balance(datetime.date.today(), Quantity(Decimal(0)))
    l = Ledger(a, b)
    assert l.account == a
    assert l.initial == b
    assert l.entries == []



# Generated at 2022-06-24 00:59:20.697555
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    assert getattr(compile_general_ledger_program(ReadInitialBalances, ReadJournalEntries), '__call__')

# Generated at 2022-06-24 00:59:22.041171
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # TODO
    pass

# Generated at 2022-06-24 00:59:26.069062
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class Foo(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    Foo()


# Generated at 2022-06-24 00:59:36.278054
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..books.accounts import Asset, Equity
    from ..books.journaling import Journal, Posting
    from ..books.tables import AccountTable, BalanceTable, JournalTable, PostingTable

    ## Setup the SUT:
    #: Account table:
    accounts = AccountTable(
        Asset("Cash", "Cash"), Asset("Bank", "Bank"), Equity("Equity", "Capital"),
    )

    #: Journal table:
    journals = JournalTable(Journal("Opening", "Opening balances"))

    #: Balance table:
    balances = BalanceTable(Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))

    #: Posting table:
    entries = PostingTable(Posting(accounts.get("Cash"), Quantity(Decimal(1)), journals.get("Opening"), 1))

    #: Ledger:


# Generated at 2022-06-24 00:59:40.472631
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account('001')
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(50)))
    ledger = Ledger(account, initial)
    assert(str(ledger) == "Ledger(account=Account('001'), initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(Decimal('50'))))")


# Generated at 2022-06-24 00:59:43.463311
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("Test")
    initial = Balance(datetime.date(2020,1,1), 10)
    entries = []
    ledgertest = Ledger(account, initial, entries)
    assert ledgertest.account == account
    assert ledgertest.initial == initial
    assert ledgertest.entries == entries
    assert ledgertest._last_balance == 10


# Generated at 2022-06-24 00:59:51.371564
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    test method __repr__ of class Ledger
    """
    test_account = "Test Account"
    test_initial_balance = Balance("Test initial balance", Quantity("Test quantity"))
    test_entries = ["Test entries"]
    test_result = f"Ledger(account={test_account}, initial={test_initial_balance}, entries={test_entries})"

    # set up
    ledger1 = Ledger(test_account, test_initial_balance, test_entries)

    # assert
    assert test_result == ledger1.__repr__()



# Generated at 2022-06-24 00:59:57.662983
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger1=Ledger(Account(number=89),Balance(date=datetime.date(2020,1,1),value=Quantity(Decimal(0))))
    ledger2=Ledger(Account(number=89),Balance(date=datetime.date(2020,1,1),value=Quantity(Decimal(0))))
    ledger3=Ledger(Account(number=99),Balance(date=datetime.date(2020,1,1),value=Quantity(Decimal(0))))
    assert ledger1==ledger2
    assert ledger1!=ledger3


# Generated at 2022-06-24 01:00:06.450265
# Unit test for method add of class Ledger

# Generated at 2022-06-24 01:00:12.168443
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    #  General ledger program:
    def _program(period: DateRange) -> GeneralLedger[_T]:
        return GeneralLedger(period, {})

    ## Unit test:
    assert _program(DateRange(datetime.date(1999, 1, 1), datetime.date(1999, 12, 31))) == GeneralLedger(
        DateRange(datetime.date(1999, 1, 1), datetime.date(1999, 12, 31)), {}
    )
    assert _program(DateRange(datetime.date(1999, 1, 1), datetime.date(1999, 1, 1))) == GeneralLedger(
        DateRange(datetime.date(1999, 1, 1), datetime.date(1999, 1, 1)), {}
    )

# Generated at 2022-06-24 01:00:15.425324
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    """
    Test suite for constructor of class LedgerEntry
    """
    # Import Posting
    from .journaling import Posting

    # Import Account
    from .accounts import Account
    pass

# Generated at 2022-06-24 01:00:25.851467
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .accounts import AccountLine, AccountType

    # Set up data
    account1 = Account(AccountLine(1, 0), AccountType.ASSET, "Cash")
    account2 = Account(AccountLine(1, 1), AccountType.ASSET, "Cash")
    account3 = Account(AccountLine(1, 0), AccountType.ASSET, "Cash")

    ledger1 = Ledger(account1, Balance(datetime.datetime.now(), Quantity(1)))
    ledger2 = Ledger(account2, Balance(datetime.datetime.now(), Quantity(1)))
    ledger3 = Ledger(account1, Balance(datetime.datetime.now(), Quantity(1)))

    posting1 = Posting(account1, Quantity(20), False, datetime.datetime.now(), "Test journal 1")

# Generated at 2022-06-24 01:00:28.010303
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry1 = LedgerEntry(None, Posting(None, 1, 0), 1)
    assert entry1 == entry1
    entry2 = LedgerEntry(None, Posting(None, 1, 0), 1)
    assert entry1 == entry2


# Generated at 2022-06-24 01:00:38.770783
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from .accounts import Account, AccountType
    from .generic import Balance

    @dataclass
    class Stub:
        balances: Dict[Account, Balance]

        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return self.balances

    initial = Stub({Account(AccountType.ASSET, "101-00001"): Balance(date(2018, 4, 1), Quantity(Decimal(1000)))})
    assert initial(DateRange(date(2018, 4, 1), date(2018, 4, 1))) == {
        Account(AccountType.ASSET, "101-00001"): Balance(date(2018, 4, 1), Quantity(Decimal(1000)))
    }

# Generated at 2022-06-24 01:00:49.062700
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..books.journaling import ReadJournalEntries
    from .accounts import ReadAccounts, ReadAccountTypes
    from .ledgers.initial_balances import ReadInitialBalances

    ## Create a context manager:
    with ReadAccounts(), ReadAccountTypes(), ReadJournalEntries(), ReadInitialBalances() as (read_accounts, read_account_types, read_journal_entries, read_initial_balances):
        ## Compile the ledger building program:
        build_ledger = compile_general_ledger_program(read_initial_balances, read_journal_entries)

        ## Build the ledger:
        ledger: GeneralLedger[int] = build_ledger(DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31)))

        ## Check the results:
        assert ledger.period

# Generated at 2022-06-24 01:00:58.234987
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger.
    """
    class Journal:
        pass

    class Posting:
        def __init__(self, amount: Amount, direction: int):
            self.amount = amount
            self.direction = direction
            self.journal = Journal()

    class Ledger:
        def __init__(self, initial_value: Decimal):
            self.initial_value = initial_value
            self.current_value = initial_value
            self.entries = list()

        def add(self, amount: Amount, direction: int):
            self.current_value += amount * direction
            self.entries.append(amount)

        def entry(self, index: int) -> Amount:
            return self.entries[index]

    ledger = Ledger(0)

# Generated at 2022-06-24 01:01:06.374468
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Setup:
    # Create a mock class PostingMock that is a subclass of Posting to be used in the tests.
    # PostingMock has two properties, amount and direction
    # amount in PostingMock is an Amount() and direction is a Direction()
    # The methods associated with PostingMock are __init__, __repr__ and __str__
    from .journaling import Posting, Direction
    from ..commons.numbers import Amount
    class PostingMock(_T):
        def __init__(self, amount, direction):
            self.amount = Amount(amount)
            self.direction = Direction(direction)

# Generated at 2022-06-24 01:01:17.865516
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    ## Since we'll be re-using general ledger construction code from this module, we need to make sure that
    ## the unit test environment has all the required variables initializes as expected.
    assert ReadInitialBalances is ReadInitialBalances
    assert ReadJournalEntries is ReadJournalEntries
    assert GeneralLedger is GeneralLedger
    assert (
        GeneralLedgerProgram is GeneralLedgerProgram
    )  # For the compiler to know the type of the variable 'program'

    ## External dependencies:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        accounts = [Account("A", "1"), Account("L", "1")]
        return {a: Balance(period.since, Quantity(Decimal(800))) for a in accounts}


# Generated at 2022-06-24 01:01:29.230973
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    p1 = Posting(period.since, 'Account#1', Amount(100))
    p2 = Posting(period.since, 'Account#2', Amount(200))
    journal1 = JournalEntry(period.since, 'JournalEntry#1', 'Description#1', [p1, p2])
    journal2 = JournalEntry(period.since, 'JournalEntry#2', 'Description#2', [p2, p1])
    initial_balances = {'Account#1': Balance(period.since, Quantity(0)), 'Account#2': Balance(period.since, Quantity(0))}
    general_ledger = build_general_ledger(period, [journal1], initial_balances)
    assert general_

# Generated at 2022-06-24 01:01:30.811981
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    #pylint: disable=pointless-statement
    ReadInitialBalances


# Generated at 2022-06-24 01:01:33.322153
# Unit test for constructor of class Ledger
def test_Ledger():
    instance_ledger = Ledger(Account(1), Balance(datetime.datetime.now().date(), Quantity(Decimal(0))))
    assert isinstance(instance_ledger, Ledger)


# Generated at 2022-06-24 01:01:34.132175
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__(): assert False, "Not yet implemented"


# Generated at 2022-06-24 01:01:36.140573
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert LedgerEntry([], "", "", "", "") == LedgerEntry([], "", "", "", "")

# Generated at 2022-06-24 01:01:45.769696
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    #Create a list of GeneralLedgers to test assert
    list_GeneralLedger = []
    # New GeneralLedger with empty list of ledgers
    a_GeneralLedger = GeneralLedger(DateRange(datetime.date(2020, 3, 1), datetime.date(2020, 3, 15)),{})
    list_GeneralLedger.append(a_GeneralLedger)
    # New GeneralLedger with empty list of ledgers
    b_GeneralLedger = GeneralLedger(DateRange(datetime.date(2020, 3, 1), datetime.date(2020, 3, 15)),{})
    list_GeneralLedger.append(b_GeneralLedger)
    # New GeneralLedger with empty list of ledgers

# Generated at 2022-06-24 01:01:50.276101
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Unit test for constructor of class Ledger
    :return:
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    import random
    random.seed(12345)

    # Generate random account and balance
    acc = Account(random.randint(1,1000))
    bal = Balance(DateRange.today(), random.randint(1,1000))
    # Generate random list of postings for ledger entry
    postings = [Posting(JournalEntry(random.randint(1,1000)), acc, random.randint(1,1000)) for i in range(random.randint(1,10))]

    # Build a ledger with initial balance and its entries

# Generated at 2022-06-24 01:01:58.156985
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import yesterday, today, tomorrow

    from .accounts import Account, account_builder

    from .journaling import Posting, PostingGroup, create_journal_entry

    a1 = account_builder("A1", account_type=Account.Type.Asset)
    a2 = account_builder("A2", account_type=Account.Type.Asset)
    a3 = account_builder("A3", account_type=Account.Type.Asset)
    a4 = account_builder("A4", account_type=Account.Type.Asset)

    i1 = account_builder("I1", account_type=Account.Type.Income)
    e1 = account_builder("E1", account_type=Account.Type.Expense)


# Generated at 2022-06-24 01:02:00.119704
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
  GeneralLedgerProgram()

# Generated at 2022-06-24 01:02:02.909299
# Unit test for constructor of class Ledger
def test_Ledger():
    accountA = Account("accountA")
    assert Ledger(accountA, Balance(datetime.date(1980,1,1), Quantity(100))) == Ledger(accountA, Balance(datetime.date(1980,1,1), Quantity(100)))


# Generated at 2022-06-24 01:02:13.744082
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..entities import Account

    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    class JournalEntryMock(Iterable[Posting]):
        def __init__(self, date: datetime.date, d: Account, c: Account, amount: Amount) -> None:
            self.date = date
            self.postings = [Posting(date, d, amount), Posting(date, c, amount)]

        def __iter__(self):
            return iter(self.postings)


# Generated at 2022-06-24 01:02:24.121684
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """
    import datetime, decimal
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange

    from .accounts import Account
    from .journaling import JournalEntry
    from .journaling.algebra import compile_journal_entry_program

    ## Initial balances:
    initial_balances = {
        Account(1000): Balance(datetime.date(2019,1,1), Quantity(Decimal(100))),
        Account(1001): Balance(datetime.date(2019,1,1), Quantity(Decimal(0)))
    }

    ## Journal entries:

# Generated at 2022-06-24 01:02:25.495089
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # TODO: Implement me.
    pass


# Generated at 2022-06-24 01:02:30.407291
# Unit test for constructor of class Ledger
def test_Ledger():
    from .journaling import Journal, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Quantity
    from ..commons.zeitgeist import Date
    print(Ledger(Account('123'), Balance(Date(1,1,1), Quantity(2))))


# Generated at 2022-06-24 01:02:35.242068
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account(123, "Checking")
    b = Balance(datetime.date(2015, 1, 1), Quantity(Decimal(100.00)))
    c = Ledger(a, b)
    assert c.account == a
    assert c.initial == b
    assert c.entries == []


# Generated at 2022-06-24 01:02:35.718069
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-24 01:02:47.562932
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    # Unit test implementation of ReadInitialBalances algebra
    def _read_initial_balances(period):
        return {
            Account.new_terminal_account("1000"): Balance(period.since, Quantity(Decimal(1000)))
        }

    # Unit test implementation of GeneralLedgerProgram algebra
    def _read_journal_entries(period):
        return [
            JournalEntry(
                datetime.date(2018, 4, 1),
                "Journal entry 1",
                [
                    Posting(Account.new_terminal_account("1000"), Decimal(100), +1),
                    Posting(Account.new_terminal_account("2000"), Decimal(100), -1),
                ],
            )
        ]

    ## Compile the program

# Generated at 2022-06-24 01:02:54.415675
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # arrange
    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 3, 31))

# Generated at 2022-06-24 01:03:00.185267
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Unit test for constructor of class GeneralLedgerProgram.
    """
    def read_initial_balances(period: DateRange) -> InitialBalances:
        """
        Implementation of the function which reads and returns initial balances.
        """
        raise NotImplementedError

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        """
        Implementation of the function which reads and returns journal entries.
        """
        raise NotImplementedError

    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    
    assert general_ledger_program is not None

# Generated at 2022-06-24 01:03:00.845630
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-24 01:03:12.407992
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons import zeitgeist, currencies
    from ..commons.numbers import Amount
    from .accounts import Account
    from .journaling import Journal, JournalEntry, Posting
    from .ledgers import build_general_ledger

    ## Create some accounts to play with:
    current_assets = Account("1110")
    cash = Account("1120")
    current_liabilities = Account("2110")

    ## Set the accounting period:
    period = zeitgeist.DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 3, 31))

    ## Create some journal entries:
    journal = []

# Generated at 2022-06-24 01:03:13.590166
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:03:24.541454
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    day01: datetime.date
    day02: datetime.date
    day03: datetime.date
    day04: datetime.date
    day05: datetime.date
    day06: datetime.date
    day07: datetime.date
    day08: datetime.date
    day09: datetime.date
    day10: datetime.date
    day11: datetime.date
    day12: datetime.date
    day13: datetime.date
    day14: datetime.date
    day15: datetime.date
    day16: datetime.date
    day17: datetime.date
    day18: datetime.date
    day19: datetime.date
    day20: datetime.date
    day21: datetime.date
    day22: datetime.date
   