

# Generated at 2022-06-24 00:57:47.088396
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Setup
    ledger = Ledger(account=Account("A"), initial=Balance(date=datetime.date(2019, 3, 31), value=Quantity(Decimal(100.00))))
    posting = Posting(journal=JournalEntry(date=datetime.date(2019, 4, 1), description="Test"), account=Account("A"), direction=1, amount=Amount(Decimal(10.00)))
    entry = LedgerEntry(ledger=ledger, posting=posting, balance=Quantity(Decimal(110.00)))
    
    # WHEN
    result = entry.__repr__()
    
    # THEN
    assert result == f"LedgerEntry(ledger={ledger}, posting={posting}, balance={Quantity(Decimal(110.00))})"


# Generated at 2022-06-24 00:57:56.723733
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from os.path import dirname, join
    from ..commons.zeitgeist import Date, Period
    from .accounts import Account, AccountTable
    from .journaling import JournalEntry, Posting, ReadJournalEntries, ReadJournalEntriesFromCSV
    from .preparing import ReadInitialBalancesFromCSV, compile_general_ledger_program

    ## Compile the target program:
    read_accounts = AccountTable.from_csv(join(dirname(__file__), "data", "accounts.csv"))
    read_initial_balances = ReadInitialBalancesFromCSV(read_accounts, join(dirname(__file__), "data", "balances.csv"))

# Generated at 2022-06-24 00:58:06.392791
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries, add_journal_entry
    from .posting import read_posting
    from .accounts import Account, read_account

    @dataclass
    class InitialBalance:
        account: Account
        balance: Balance

    class ReadInitialBalances2(Protocol):
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            pass

    @dataclass
    class TestReadInitBalances:
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            if period.until == datetime.date(2019, 1, 1):
                return {}
            return {Account("Assets", "Cash"): Balance(period.until, Quantity(500))}


# Generated at 2022-06-24 00:58:07.376430
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"


# Generated at 2022-06-24 00:58:14.683779
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    zero = Quantity(0)
    one = Quantity(1)
    two = Quantity(2)
    three = Quantity(3)
    positive = Balance(datetime.date(2020, 1, 1), one)
    negative = Balance(datetime.date(2020, 1, 1), -one)
    zero_balance = Balance(datetime.date(2020, 1, 1), zero)
    positive_entry = LedgerEntry(Ledger(Account(1), positive), Posting(1, one, datetime.date(2020, 1, 1), 1), one)
    negative_entry = LedgerEntry(Ledger(Account(1), negative), Posting(1, -one, datetime.date(2020, 1, 1), 1), zero)

# Generated at 2022-06-24 00:58:17.544138
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests GeneralLedgerProgram.__call__
    """
    ## As we cannot test this method because we do not have dependable implementations of all algebra algebras,
    ## we just test if the program is callable and that is all.
    assert callable(compile_general_ledger_program(None, None))


# Test for method __init__ of class GeneralLedger

# Generated at 2022-06-24 00:58:25.126031
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Empty ledgers
    ledgers: Dict[Account, Ledger[_T]] = {}
    # Initialize the period

# Generated at 2022-06-24 00:58:33.753964
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import Journal


# Generated at 2022-06-24 00:58:45.304259
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests for the unit method __call__ of the class GeneralLedgerProgram.
    """
    from .examples import (
        build_example_accounts,
        build_example_initial_balances,
        build_example_journal_entries,
        build_example_period,
    )
    from .interpreters.in_memory_interpreter import InMemoryInterpreter

    ## Define the period:
    period = build_example_period()

    ## Define the accounts:
    accounts = build_example_accounts()

    ## Define the initial balances:
    initial_balances = build_example_initial_balances(period, accounts)

    ## Define the journal entries:
    journal_entries = build_example_journal_entries(period, accounts)

    ## Build the interpreter:
    interpreter

# Generated at 2022-06-24 00:58:52.461126
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Journal
    from .journaling import Posting
    from .journaling import JournalEntry
    from .accounts import Account

    ## Create the account:
    PENSION_HELD_BY_OMO = Account(
        "12000-00-000004-000-000-000-0000",
        "Pension held by Omo",
        "Total value of pension held by Omo as of 31-Dec-9999.",
        "Asset",
        True,
        True,
    )

    #: Create the posting:
    posting = Posting(
        PENSION_HELD_BY_OMO, datetime.date(2020,1,1), Quantity(Decimal(5000))
    )

    ## Create a journal entry based on the posting:

# Generated at 2022-06-24 00:59:00.607075
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger
    """
    
    from ..commons.zeitgeist import parse_date

    def _initial(period: DateRange) -> InitialBalances:
        return {
            "1010": Balance(parse_date("2019-01-01"), Quantity(Decimal(1000))),
            "1020": Balance(parse_date("2019-01-01"), Quantity(Decimal(1000))),
            "2010": Balance(parse_date("2019-01-01"), Quantity(Decimal(1000))),
        }

    def _journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        from .journaling import Journal, Posting
        from .accounts import Account

# Generated at 2022-06-24 00:59:06.140847
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class _ReadInitialBalances(ReadInitialBalances):

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    assert issubclass(_ReadInitialBalances, ReadInitialBalances)


# Generated at 2022-06-24 00:59:11.062176
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry1 = LedgerEntry(None, Posting(None, None, Amount(100, 'CAD'), True), Quantity(100))
    entry2 = LedgerEntry(None, Posting(None, None, Amount(100, 'CAD'), True), Quantity(100))
    assert entry1 == entry2


# Generated at 2022-06-24 00:59:18.178941
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AssetAccount, LiabilityAccount
    import pytest
    
    @dataclass
    class Service(_T):
        """
        A dummy service definition.
        """

        code: str
        qty: Quantity

    @dataclass
    class ResourceAccount(AssetAccount):
        """
        Defines a resource account.
        """

    @dataclass
    class RevenueAccount(LiabilityAccount):
        """
        Defines a revenue account.
        """

    @dataclass
    class ExpenseAccount(LiabilityAccount):
        """
        Defines an expense account.
        """

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("1110", "Cash"): Balance(period.since, Quantity(Decimal(2000)))}


# Generated at 2022-06-24 00:59:30.054818
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests compile_general_ledger_program function.
    """
    from alchy import Manager
    from .accounts import AccountManager
    from .journaling import JournalEntryManager, PostingManager

    # Initialize sqlalchemy engine and session configuration.
    manager = Manager()

    # Initialize account manager.
    account_manager = AccountManager(manager)

    # Initialize journal entry manager.
    journal_entry_manager = JournalEntryManager(manager)

    # Initialize posting manager.
    posting_manager = PostingManager(manager)

    # Compile program.
    read_initial_balances = account_manager.read_initial_balances
    read_journal_entries = journal_entry_manager.read_journal_entries

# Generated at 2022-06-24 00:59:39.383008
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    #: Arrange
    account = Account(1, "Assets", "Cash", None)
    posting_date = datetime.date(2018, 1, 1)
    transaction_desc = "Initial investment"
    posting_account = Account(2, "Liabilities", "Equity", None)
    posting_amount = Amount(Decimal(5000))
    posting_direction = 1
    amount = Amount(Decimal(5000))
    posting = Posting(posting_date, transaction_desc, posting_account, posting_amount, posting_direction)
    balance = Balance(posting_date, amount)
    ledger = Ledger(account, balance)

    #: Act
    ledger_entry = LedgerEntry(ledger, posting, balance)

    #: Assert
    assert ledger_entry.ledger == ledger
    assert ledger_entry.post

# Generated at 2022-06-24 00:59:40.103297
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-24 00:59:51.114979
# Unit test for function build_general_ledger
def test_build_general_ledger():
    #########################
    #### Provided data:
    ########################
    ## Accounting period:
    period = DateRange(datetime.date(2020, 3, 1), datetime.date(2020, 5, 31))

    ## Journal entries:

# Generated at 2022-06-24 00:59:59.403217
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import unittest
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounting.repositories import (
        read_initial_balances,
        read_journal_entries,
    )
    from .accounting.typeclasses import JournalAlgebra
    from .journaling.typeclasses import JournalEntryAlgebra

    class MockJournalAlgebra(JournalAlgebra):
        def read_journal(self, period: DateRange) -> Iterable[JournalEntry]:
            pass  # pragma: no cover

        def add_journal(self, journal: JournalEntry) -> JournalEntry:
            pass  # pragma: no cover

    classMockJournalEntryAlgebra = JournalEntryAlgebra


# Generated at 2022-06-24 01:00:04.501147
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    class TestJournalEntry:
        def __init__(self, date, description):
            self.date = date
            self.description = description

    class TestPosting:
        def __init__(self, journal, account, amount, direction):
            self.journal = journal
            self.account = account
            self.amount = amount
            self.direction = direction

    class TestAccount:
        def __init__(self, code):
            self.code = code

    class TestDateRange:
        def __init__(self, since, until):
            self.since = since
            self.until = until

        def __eq__(self, other):
            return self.since == other.since and self.until == other.until

    class TestQuantity:
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-24 01:00:14.127615
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from . import (
        LedgerAccount,
        UnitOfWork,
        accounts,
        build_unit_of_work,
        get_account,
        get_initial_balances,
        journal,
    )
    from .journaling import PostingRecord, add_journal_entry

    ## Create an in-memory unit of work and get its implementation.
    uow, uowi = build_unit_of_work()
    assert isinstance(uow, UnitOfWork)

    ## Register accounts:

# Generated at 2022-06-24 01:00:23.128017
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger1 = Ledger(account=Account(code='01', name='Retained Earnings'), initial=Balance(date=datetime.datetime.now(), value=Decimal(0)))
    ledger2 = Ledger(account=Account(code='01', name='Retained Earnings'), initial=Balance(date=datetime.datetime.now(), value=Decimal(0)))
    ledger3 = Ledger(account=Account(code='01', name='Retained Earnings'), initial=Balance(date=datetime.datetime.now(), value=Decimal(1)))
    assert ledger1 == ledger2
    assert ledger1 != ledger3


# Generated at 2022-06-24 01:00:30.819722
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():

    period = DateRange(datetime.datetime(2020, 1, 4), datetime.datetime(2020, 1, 10))
    
    # test data
    initial_balances = {Account("Asset", "Cash", "VND"): Balance(datetime.datetime(2019, 12, 1), Quantity(Decimal(100000))),
                        Account("Asset", "Current Asset", "VND"): Balance(datetime.datetime(2019, 12, 1), Quantity(Decimal(200000)))}

    journal_entries_build = []

# Generated at 2022-06-24 01:00:32.130079
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests and demonstrates the :py:func:`compile_general_ledger_program` function.
    """

# EOF

# Generated at 2022-06-24 01:00:39.638303
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class _Test:
        period: DateRange

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def _read_journal_entries(period: DateRange) -> List[JournalEntry[_Test]]:
        return []

    assert compile_general_ledger_program(_read_initial_balances, _read_journal_entries)(_Test(period=DateRange(since = datetime.date(2019, 1, 1), until = datetime.date(2019, 12, 31))))

# Generated at 2022-06-24 01:00:40.515260
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-24 01:00:46.457056
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Define test data:
    opening_date = period.since
    closing_date = period.until
    prior_period = DateRange(
        datetime.date(opening_date.year - 1, opening_date.month, opening_date.day),
        datetime.date(closing_date.year - 1, closing_date.month, closing_date.day),
    )

    # Define initial balances:

# Generated at 2022-06-24 01:00:57.148068
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # Build general ledger and add two accounts
    general_ledger = GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2021, 12, 31)), {})
    general_ledger.ledgers[Account(id='foo', name='Foo', type='revenue')] = Ledger(Account(id='foo', name='Foo', type='revenue'), Balance(datetime.date(2020, 1, 1), Quantity(Decimal('0'))), [])
    general_ledger.ledgers[Account(id='bar', name='Bar', type='expense')] = Ledger(Account(id='bar', name='Bar', type='expense'), Balance(datetime.date(2021, 12, 31), Quantity(Decimal('0'))), [])

    # Create a second general ledger and add

# Generated at 2022-06-24 01:01:05.908201
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # Create the ledger
    @dataclass
    class Ledger2:
        account: int
        initial: int
        entries: list=0

    # Create the journal
    @dataclass
    class Journal2:
        description: str
        postings: list

    # Create the posting
    @dataclass
    class Posting2:
        account: int
        amount: int
        direction: int

    # Create a journal
    journal = JournalEntry(
        description='Test Journal',
        postings=[
            Posting2(account=1, amount=20, direction=1),
            Posting2(account=2, amount=20, direction=1)
        ]
    )

    # Create a ledger:
    ledger = Ledger2(account=1, initial=100)

    # test the entries are added up properly.
   

# Generated at 2022-06-24 01:01:17.417689
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():

    # This subsection creates a dictionary of accounts for the initial balance
    # The key is each account and the value is the balance for that account.
    # The keys of the dictionary are strings, but the account numbers are integers.
    def read_balances():
        account_balances = {}
        account_balances['112'] = 1013.45
        account_balances['434'] = 3231.35

        return account_balances

    # The dictionary for the initial balance is assigned to the variable initial_balances
    # The function read_balances is called
    initial_balances = read_balances()

    # This subsection creates a dictionary of accounts to be used as test values
    # The key is each account and the value is the balance for that account.
    # The keys of the dictionary are strings, but the account numbers are integers.

# Generated at 2022-06-24 01:01:17.978988
# Unit test for constructor of class Ledger
def test_Ledger():
    pass


# Generated at 2022-06-24 01:01:29.313712
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 01:01:36.157688
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Declare variables
    a = "Ledger('a', initial=Balance(date='2020-01-01', value=Decimal('0')))",
    b = "Debit(Account('a'), date='2020-01-02', amount=Decimal('1'))",
    c = "LedgerEntry(ledger=Ledger('a', initial=Balance(date='2020-01-01', value=Decimal('0'))), posting=Debit(Account('a'), date='2020-01-02', amount=Decimal('1')), balance=Decimal('1'))"
    # Execute code
    obj = LedgerEntry(ledger = eval(a), posting = eval(b), balance = eval(c))
    # Check conditions
    assert obj.__repr__() == c


# Generated at 2022-06-24 01:01:45.821375
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import CreditAccount, DebitAccount, GenericAccount, TerminalAccount

    from ..commons.zeitgeist import FiscalYear

    from .journaling import JournalEntry, Posting

    ## Define accounts:
    a = GenericAccount("A")
    b = DebitAccount("B")
    c = CreditAccount("C")
    d = TerminalAccount("D")

    ## Define journal entries:

# Generated at 2022-06-24 01:01:48.443588
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    ## Get initial balances as of the end of previous financial period:
    initial_balances = read_initial_balances(period)

    ## Read journal entries and post each of them:
    journal_entries = read_journal_entries(period)

    ## Build the general ledger and return:
    assert build_general_ledger(period, journal_entries, initial_balances) == None


# Generated at 2022-06-24 01:01:54.609111
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import JournalEntry

    journal = JournalEntry("test description", datetime.date.today(), "CAD")
    journal.post("a", 20)
    journal.post("a", 20)

    ledger = Ledger("a", Balance(datetime.date.today(), Quantity(0)))
    ledger.add(journal.postings[0])
    assert ledger.entries[0].balance == Quantity(20)
    ledger.add(journal.postings[1])
    assert ledger.entries[1].balance == Quantity(40)

# Generated at 2022-06-24 01:02:01.027758
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account
    from .journaling import Posting, JournalEntry
    from .accounts.read_accounts import read_accounts
    from .journaling.read_journal_entries import read_journal_entries
    from .journaling.read_journals import read_journals
    from .journals.read_transactions import read_transactions

    @dataclass
    class JournalTransaction:
        ledger_account: Account
        amount: Decimal
        date: datetime.date

    @dataclass
    class Journal:
        journal_entries: List[JournalTransaction]
        date: datetime.date


# Generated at 2022-06-24 01:02:10.821774
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    @dataclass
    class _T:
        id: str

    period = DateRange("2018-01-01", "2018-12-31")

    account = Account("100000", "Cash")
    initial = Balance("2018-01-01", Quantity(100))

    posting = Posting(_T("7237"), "2018-01-01", account, Quantity(100), True)


# Generated at 2022-06-24 01:02:22.017777
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from python_cup import cup
    from .journaling import ReadJournalEntries, compile_journal_entry_reader

    date_from = datetime.date(2018, 1, 1)
    date_to = datetime.date(2018, 1, 31)
    period = DateRange(date_from, date_to)

    initial_balances = {
        Account(3010): Balance(period.since, Quantity(Decimal(0))),
        Account(1050): Balance(period.since, Quantity(Decimal(0))),
        Account(1100): Balance(period.since, Quantity(Decimal(23.45))),
    }

    @dataclass
    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances:
            return initial_balances


# Generated at 2022-06-24 01:02:24.908039
# Unit test for constructor of class Ledger
def test_Ledger():
    l = Ledger("Account1", None, None, None)
    assert l.account == "Account1"
    assert l.entries == None
    assert l.initial == None

# Generated at 2022-06-24 01:02:27.125833
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .__main__ import read_journal_entries, read_initial_balances
    glp = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert glp is not None
    assert glp.__call__

# Generated at 2022-06-24 01:02:33.986522
# Unit test for method add of class Ledger
def test_Ledger_add():
    Ledger1 = Ledger(Account('1000'),Balance(datetime.date(2019,5,5),Quantity(Decimal(1))))
    Ledger2 = Ledger(Account('1000'),Balance(datetime.date(2019,5,5),Quantity(Decimal(1))))
    Ledger2.add(Posting(Account('1000'),Quantity(Decimal(1)),1))
    assert len(Ledger1.entries) + 1 == len(Ledger2.entries)

# Generated at 2022-06-24 01:02:41.647590
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Balance
    from .journaling import Credit, Debit, Journal, Posting
    from .accountants import ReadInitialBalances, ReadJournalEntries
    period = DateRange(date(2018, 1, 1), date(2019, 1, 1))

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("001", "Cash on Hand", AccountType.Asset, 0): Balance(period.since, Quantity(Decimal("100.00"))),
            Account("002", "Accounts Receivable", AccountType.Asset, 0): Balance(period.since, Quantity(Decimal("100.00"))),
        }

   

# Generated at 2022-06-24 01:02:52.306196
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from dataclasses import asdict

    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    from .accounts import AccountType
    from .bookkeeping import JournalEntry

    # Define the accounting period:
    period = DateRange(datetime.date(2017, 4, 1), datetime.date(2017, 4, 30))

    # Define journal entries to post:

# Generated at 2022-06-24 01:02:55.020450
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    r1 = ReadInitialBalances()
    r2 = ReadInitialBalances()
    
    assert isinstance(r1, ReadInitialBalances)
    assert isinstance(r2, ReadInitialBalances)
    

# Generated at 2022-06-24 01:03:01.389624
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import datetime as dt
    from .ledger import ReadInitialBalances
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Decimal, Amount
    from ..commons.accounting import Account, AccountType
    from ..commons import journaling as jr
    # General ledger program
    initial_balances: Dict[Account, jr.Balance] = {Account(AccountType.ASSET, 1): jr.Balance(dt.date(2020, 1, 1), Amount(Decimal(0)))}
    def _program(period: DateRange) -> jr.InitialBalances:
        """
        Consumes the opening and closing dates and produces a general ledger.

        :param period: Accounting period.
        :return: A general ledger.
        """
        ## Get initial balances as of the end of previous

# Generated at 2022-06-24 01:03:02.347598
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass

# Generated at 2022-06-24 01:03:13.581032
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from datetime import date
    from ..commons.zeitgeist import Datetime
    from .journaling import Journal, JournalEntry

    ## Account
    account = Account(code="1", name="Account")
    ## Journal
    journal = Journal(datetime=Datetime(date=date(2019,1,1)), description="Journal")
    ## Posting
    posting = Posting(journal=journal, account=account, amount=Amount(magnitude=10), direction="debit")

    ## LedgerEntry
    ledger_entry = LedgerEntry(ledger=None, posting=posting, balance=0)
    assert ledger_entry == ledger_entry
    assert not ledger_entry == 1
    assert not ledger_entry == "1"
    assert not ledger_entry == None
    assert not ledger_entry == True

# Generated at 2022-06-24 01:03:19.401032
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(Account(None, None, None, '1000'), Balance(datetime.datetime(2020, 11, 30), Quantity(Decimal(1234))))) == f'Ledger(account=Account(type=None, subtype=None, number=1000, description=None), initial=Balance(date=datetime.date(2020, 11, 30), value=Quantity(1234.00)))'


# Generated at 2022-06-24 01:03:28.181932
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from ..commons.zeitgeist import DateRange

    # A Posting
    account = Account(code="1234", name="Account 1234")
    amount = Decimal(100)
    direction = Posting.Direction.DEBIT
    journal = JournalEntry(date="2020-01-01", description="Journal Entry #1")
    posting = Posting(account=account, amount=amount, direction=direction, journal=journal)

    # A Balance
    date = "2020-01-01"
    value = Decimal(100)
    balance = Balance(date=date, value=value)

    # A Ledger
    ledger = Ledger(account=account, initial=balance)

    # Check Ledger characteristics
    assert ledger

# Generated at 2022-06-24 01:03:39.089011
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    import sys
    # Setup test data
    period = DateRange(datetime.date(2018, 12, 1), datetime.date(2019, 5, 1),)
    ledgers = {Account(code="1110", name="Cash",), Ledger(Account(code="1110", name="Cash",), Balance(datetime.date(2018, 12, 1), Quantity(Decimal(0))))}
    # Perform the test
    test = GeneralLedger(period, ledgers)
    actualResult = test.__repr__()

# Generated at 2022-06-24 01:03:43.222311
# Unit test for constructor of class Ledger

# Generated at 2022-06-24 01:03:44.852763
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Test the constructor of class Ledger
    """
    return True


# Generated at 2022-06-24 01:03:51.778648
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .accounts import Account, Accounts, Balance
    from .journaling import JournalEntry, Posting, JournalEntries

    ## Define accounts and initial balances:
    accounts = Accounts(
        [
            Account(accnum="10000", name="Cash"),
            Account(accnum="20000", name="Accounts receivable"),
            Account(accnum="30000", name="Inventory"),
            Account(accnum="40000", name="Fixed assets"),
            Account(accnum="50000", name="Accounts payable"),
            Account(accnum="60000", name="Utilities payable"),
            Account(accnum="80000", name="Accumulated amortization"),
            Account(accnum="90000", name="Retained earnings"),
        ]
    )


# Generated at 2022-06-24 01:03:53.335507
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # TO DO
    assert True == True


# Generated at 2022-06-24 01:04:05.022785
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    date1 = datetime.date(2014, 1, 1)
    date2 = datetime.date(2014, 1, 2)
    a1 = Account("A1")
    a2 = Account("A2")
    b1 = Balance(date1, Quantity(Decimal(10)))
    b2 = Balance(date2, Quantity(Decimal(0)))
    j1 = JournalEntry(date1, "j1", (Posting(a1, Quantity(Decimal(2))), Posting(a2, Quantity(Decimal(2)))))
    j2 = JournalEntry(date2, "j2", (Posting(a1, Quantity(Decimal(5))), Posting(a2, Quantity(Decimal(5)))))
    journal_entries = (j1, j2)

# Generated at 2022-06-24 01:04:12.838041
# Unit test for constructor of class GeneralLedger

# Generated at 2022-06-24 01:04:21.852003
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger(None, Balance(None, None))
    l.initial = Balance(None, Quantity(1))
    l.add(Posting(None, None, None, None, None))
    assert l.entries[0].balance == Quantity(1)
    l.add(Posting(None, None, None, None, Quantity(1)))
    assert l.entries[1].balance == Quantity(2)
    l.add(Posting(None, None, None, None, Quantity(-1)))
    assert l.entries[2].balance == Quantity(1)
    assert l.initial == Balance(None, Quantity(1))

# Generated at 2022-06-24 01:04:24.864384
# Unit test for constructor of class Ledger
def test_Ledger():
    # Setup
    account = Account(code=1, name="Cash", terminal=True)
    initial = Balance(date=datetime.date(2019, 1, 1), value=Decimal(0)) 
    # Exercise
    ledger = Ledger(account=account, initial=initial)
    # Verify
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == []


# Generated at 2022-06-24 01:04:32.407551
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account1 = Account("a1", 2, AccountType.TERMINAL)
    balance1 = Balance("2020-01-01", Quantity(-100))
    ledger1 = Ledger(account1, balance1)
    assert ledger1.__repr__() == """Ledger(
    account=Account(id='a1', level=2, type=<AccountType.TERMINAL: 1>),
    initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(-100))
)"""



# Generated at 2022-06-24 01:04:32.758699
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert 1 == 1

# Generated at 2022-06-24 01:04:41.717930
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    test_a = LedgerEntry(1, 1, 1)
    test_b = LedgerEntry(2, 2, 2)
    test_c = LedgerEntry(1, 1, 1)
    test_d = LedgerEntry(1, 1, 2)
    test_e = LedgerEntry(1, 2, 1)
    test_f = LedgerEntry(2, 1, 1)
    # Eq test
    assert test_a == test_c
    assert not test_a == test_b
    assert not test_a == test_d
    assert not test_a == test_e
    assert not test_a == test_f
    return True


# Generated at 2022-06-24 01:04:48.616803
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ReadInitialBalancesImpl(ReadInitialBalances):
        balances: InitialBalances = field(default_factory=dict)

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    ReadInitialBalancesImpl(dict(foo=Balance(datetime.date.today(), 1)))



# Generated at 2022-06-24 01:04:55.577683
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    class MockReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    class MockReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    p = compile_general_ledger_program(MockReadInitialBalances(), MockReadJournalEntries())

    assert p is not None

# Generated at 2022-06-24 01:05:07.708389
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from .journaling import JournalEntry
    from .journaling import Posting

    ####################################################################################################################
    ## Set up:

    from .accounts import Account
    from .generic import Balance
    from .journaling import Postings

    # Set up opening balances as per the following example:
    #   - create an Account object to represent each account
    #   - create a Balance object to represent the opening balance


# Generated at 2022-06-24 01:05:14.765546
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from rip.journaling.algebras import ReadJournalEntriesT
    from rip.journaling import Posting
    from rip.journaling.services import JournalingService
    from rip.accounts import Account, TransactionType

    @dataclass
    class FakeReadJournalEntries(ReadJournalEntriesT[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            # Read journal entries and post each of them:
            journal_entries = JournalingService.read_postings(period)
            return journal_entries


# Generated at 2022-06-24 01:05:20.017564
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Ledger(Account(1, 'b', 'b'), Balance(datetime.date(2020,1,1), Quantity(Decimal(0))))
    b = Ledger(Account(1, 'b', 'b'), Balance(datetime.date(2020,1,1), Quantity(Decimal(0))))
    if a == b:
        print("Equal!")
    else:
        print("Not Equal!")


# Generated at 2022-06-24 01:05:29.451633
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from datetime import date
    from journaling import JournalEntry, Posting, Direction, Account
    from accounts import TrialBalance
    # Create an account to be associated with a JournalEntry
    account1 = Account('1')
    # Build the JournalEntry
    journalEntry1 = JournalEntry(
        date=date(2020, 1, 1),
        description='first JournalEntry',
        postings=[
            Posting(
                account=account1,
                direction=Direction.DEBIT,
                amount=Decimal(3000)
            )
        ]
    )
    # Create a ledger
    account = Account('11')
    balance = Quantity(Decimal(0))
    ledger1 = Ledger(account, Balance(date(2020, 1, 1), balance))
    # Create the ledgerEntry
    posting = accounting1.postings[0]
    ledger

# Generated at 2022-06-24 01:05:36.432335
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    import time
    import datetime
    from openpyxl import Workbook
    wb=Workbook()
    ws=wb.active
    ws.append(['201','10','1000','100','1','2019-01-01','','','','','','','','',''])
    ws.append(['202','10','1000','100','2','2019-02-01','','','','','','','','',''])
    ws.append(['203','10','1000','100','3','2019-03-01','','','','','','','','',''])
    ws.append(['301','10','1000','100','4','2019-04-01','','','','','','','','',''])

# Generated at 2022-06-24 01:05:43.548763
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account("UnitTest",""), Balance(datetime.datetime.today().date(), Quantity(Decimal(0))))
    entry = ledger.add(Posting(Account("UnitTest",""),Amount(Decimal(1)),0,datetime.datetime.today().date()))
    assert entry.amount == Amount(Decimal(1))
    assert ledger.entries[0].amount == Amount(Decimal(1))

# Generated at 2022-06-24 01:05:55.504050
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the function compile_general_ledger_program.
    """

    from ..commons.intervals import intervals
    from .algebras.interpreters import get_journal_postings_from_data, get_journal_postings_from_journal_entries, \
        get_initial_balances_from_data

    ## Read initial balances as of the end of previous period:

# Generated at 2022-06-24 01:06:02.496519
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account()
    balance = Balance(datetime.date(2020, 1, 1), Quantity(0))
    ledger = Ledger(account, balance)
    assert isinstance(ledger.account, Account)
    assert isinstance(ledger.initial, Balance)
    assert isinstance(ledger.entries, list)
    assert hasattr(ledger, '_last_balance')



# Generated at 2022-06-24 01:06:11.177150
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    test_period = DateRange(datetime.date.fromisoformat('2020-01-01'),datetime.date.fromisoformat('2020-01-31'))
    test_journal_entries = [JournalEntry(datetime.date.fromisoformat('2020-01-01'), 'testjournaldescription', [Posting(Account(100100, 'testaccountdescription'), 1, 100)])]
    test_initial_balances = {Account(100100, 'testaccountdescription'): Balance(datetime.date.fromisoformat('2020-01-01'), Decimal(42))}
    test_object1 = build_general_ledger(test_period, test_journal_entries, test_initial_balances)

# Generated at 2022-06-24 01:06:14.938233
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Given
    self = Ledger(account = None, initial = None)
    # When 
    get_repr = self.__repr__()
    # Then
    assert get_repr == '<Ledger(account=None, initial=None)>'

# Generated at 2022-06-24 01:06:22.070676
# Unit test for constructor of class Ledger
def test_Ledger():
    test_account = Account(1, "Assets", "Current Assets", "Cash")
    test_balance = Balance(datetime.date(2020, 2, 1), Quantity(Decimal(1000)))
    test_ledger = Ledger(test_account, test_balance)
    assert test_ledger.account == test_account
    assert test_ledger.initial == test_balance
    assert test_ledger.entries == []
    import pytest
    with pytest.raises(TypeError):
        test_ledger = Ledger(test_account, test_balance, test_balance)
    with pytest.raises(TypeError):
        test_ledger = Ledger(test_account)


# Generated at 2022-06-24 01:06:32.407914
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from ..commons.zeitgeist import date
    from .journaling import Journal, Posting
    from .accounts import AccountCode, TerminalAccount



# Generated at 2022-06-24 01:06:34.871597
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    le1 = LedgerEntry(None, None,None)
    le2 = LedgerEntry(None, None, None)
    assert le1 == le2


# Generated at 2022-06-24 01:06:45.956884
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    ## Define the accounting period, construct initial balances and journal entries needed for building a general ledger:
    period = DateRange(datetime.date(2020, 9, 1), datetime.date(2020, 9, 30))
    initial = {Account("Assets/Cash"): Balance(datetime.date(2020, 8, 31), Quantity(Decimal(0)))}
    journal_entries = [
        JournalEntry(
            datetime.date(2020, 9, 15),
            "Opening balance",
            Posting(Account("Assets/Cash"), Quantity(Decimal(100.0)), "debit"),
        )
    ]

    ## Define algebra implementations which provide the expected initial balances and journal entries:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return initial


# Generated at 2022-06-24 01:06:57.389521
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from datetime import datetime
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    # Create a first account to use for ledger
    account_first = Account('FirstAccount')
    ledger1 = Ledger(account_first, Balance(datetime.strptime('2016-01-01', '%Y-%m-%d'), Quantity(Decimal(10))))
    ledger2 = Ledger(account_first, Balance(datetime.strptime('2016-01-01', '%Y-%m-%d'), Quantity(Decimal(10))))
    assert ledger1.__eq__(ledger2) == True
    # Create a second account to use for ledger
    account_second = Account('SecondAccount')

# Generated at 2022-06-24 01:06:59.980282
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert True

# Generated at 2022-06-24 01:07:06.009069
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Run unit test for function compile_general_ledger_program.
    """

    @dataclass
    class State:
        """
        State model for the test.
        """

        period: DateRange
        initial_balances: InitialBalances
        journal_entries: List[JournalEntry]

    ## Fixture of the module to test:
    from ..commons.algebraic import (
        Algebraic,
        Implementation,
        Model,
        Var,
    )

    ## Define test models and algebra:
    read_initial_balances = Algebraic(Implementation("read_initial_balances", str), {"period": Model(DateRange)})


# Generated at 2022-06-24 01:07:15.338932
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry
    from .commons import Account, Balance
    from dataclasses import dataclass
    from decimal import Decimal
    from .accounts import Account
    
    # Test Case 1:
    ## Example 1:
    ## date, description, account, credit, debit, balance
    ## 1/1/2018, Cash, 100, 0, 0, 0
    ## 1/1/2018, Shoe inventory, 200, 0, 0, 0
    ## 1/1/2018, Opening balance entry, 100, 5000, 0, 5000
    ## 1/1/2018, Opening balance entry, 200, 12000, 0, 12000
    ## 1/1/2018, Sales, 100, 0, 4000, 1000
    ## 1/1/2018, Purchases, 100, 4000, 0, 5000
    ## 1/1/2018, Purch

# Generated at 2022-06-24 01:07:18.822795
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    ### Create a GeneralLedger instance
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    gl = GeneralLedger(period, {})
    ### Assert
    assert repr(gl) == "GeneralLedger(period=DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 1, 31)), ledgers={})"


# Generated at 2022-06-24 01:07:24.128819
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    period = DateRange(since=datetime.date(2018, 4, 1), until=datetime.date(2018, 4, 30))
    l1 = build_general_ledger(period, (), {})
    l2 = build_general_ledger(period, (), {})
    assert l1 == l2
    assert l1 != 1


# Generated at 2022-06-24 01:07:29.800404
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("ASSETS-BANK","bank account","BANK")
    initial_balance = Quantity(Decimal(1000))
    ledger = Ledger(account,initial_balance)
    assert ledger.account.code == "ASSETS-BANK"
    assert ledger.account.description == "bank account"
    assert ledger.account.category == "BANK"
    assert ledger.initial.value == Decimal(1000)


# Generated at 2022-06-24 01:07:31.988523
# Unit test for constructor of class Ledger
def test_Ledger():
    assert Ledger(Account("1", "first"),  Balance(datetime.date(2019, 1, 31), Quantity(Decimal("1500")))).entries==[]


# Generated at 2022-06-24 01:07:41.663117
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry
    from .postings import Posting
    from .read_journal_entries import read_journal_entries
    
    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 12, 31))
    
    a = Account(symbol='10100', desc='Cash and Cash Equivalents')
    b = Account(symbol='10200', desc='Short-term Investments')
    c = Account(symbol='10500', desc='Short-term Loans')
    d = Account(symbol='10600', desc='Accounts Receivable')
    e = Account(symbol='10700', desc='Inventories')