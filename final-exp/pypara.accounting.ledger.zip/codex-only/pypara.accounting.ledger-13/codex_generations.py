

# Generated at 2022-06-24 00:57:46.484914
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ReadInitialBalancesImp(ReadInitialBalances):
        def __call__(self, period):
            return {
                Account("Assets", "Cash") : Balance(period.since, Quantity(Decimal(100))),
                Account("Assets", "Other") : Balance(period.since, Quantity(Decimal(200))),
                Account("Assets", "Goodwill") : Balance(period.since, Quantity(Decimal(300))),
                Account("Liabilities", "Accounts Payable"): Balance(period.since, Quantity(Decimal(400)))
            }

    # Period
    period = DateRange(datetime.date(2019,1,1), datetime.date(2019,2,2))
    r = ReadInitialBalancesImp()

# Generated at 2022-06-24 00:57:52.223107
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(name = "A", description="A")
    balance = Balance(date=2, value=2)
    ledger = Ledger(account=account, initial=balance)
    journal = JournalEntry(date=1, description="A", postings=[
        Posting(account=Account(name="A"), amount=5, direction=1),
        Posting(account=Account(name="B"), amount=5, direction=-1)
    ])
    posting = journal.postings[0]
    ledger_entry = ledger.add(posting)
    assert ledger_entry.date==1
    assert ledger_entry.description=="A"
    assert ledger_entry.amount==5
    assert ledger_entry.posting==posting
    assert ledger_entry.ledger==ledger
    assert ledger_entry.balance==7
    assert ledger

# Generated at 2022-06-24 00:58:03.280225
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Checks if the method __repr__ of class LedgerEntry returns string with instance name, address and attributes.
    """
    ## Given a LedgerEntry with account number, date, credit, debit, balance and description
    account_number = "000001"
    date = datetime.date(2019, 12, 31)
    credit = Amount(Decimal(10.00))
    debit = Amount(Decimal(0.00))
    balance = Quantity(Decimal(10.00))
    description = "LedgerEntry - Testing."
    posting = Posting(account_number, date, debit, credit)
    ledger = Ledger(account_number, Balance(datetime.date(2010, 1, 1), Quantity(Decimal(0.00))))
    entry = LedgerEntry(ledger, posting, balance)
    ## When I use the method

# Generated at 2022-06-24 00:58:14.315077
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    import datetime
    from oledger.accounts import Account
    from oledger.commons.numbers import Quantity
    from oledger.journaling import Journal, Posting

    # Test data
    today = datetime.date.today()
    period = DateRange(today, today)
    journal = list()
    initial = dict()

    asset = Account.__new__(Account)
    asset.__init__("asset")
    liability = Account.__new__(Account)
    liability.__new__(Account)
    liability.__init__("liability")

    post1 = Posting.__new__(Posting)
    post1.__init__(asset, Quantity(10))
    post2 = Posting.__new__(Posting)

# Generated at 2022-06-24 00:58:17.236520
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    read_initial_balances = lambda period: {"A":Balance(period.since, Quantity(Decimal(0))), "B":Balance(period.since, Quantity(Decimal(0)))}
    read_journal_entries = lambda period: [JournalEntry([]), JournalEntry([])]
    assert compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-24 00:58:28.210473
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..algebra.interfaces import InitialBalances, ReadInitialBalances, ReadJournalEntries

    from .commons import build_algebra

    from ..commons.zeitgeist import DateRange

    from ..commons.numbers import Amount, Quantity

    from .accounts import Account

    from .journaling import JournalEntry, Posting

    from .generic import Balance

    from .ledgers import GeneralLedger, GeneralLedgerProgram, build_general_ledger, compile_general_ledger_program

    ##
    ## Custom algebra
    ##

    #: Custom algebra
    algebra = build_algebra(
        (ReadInitialBalances, InitialBalances),
        (
            ReadJournalEntries,
            JournalEntry,
        ),  # define algebra and types it exposes
    )

    #: Initial balances.
    initial_balances: Initial

# Generated at 2022-06-24 00:58:33.357342
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():

    GeneralLedger(DateRange(datetime.date(2018, 1, 1),datetime.date(2018, 12, 31)),{
        Account(code='123', name='MyAccount'): Ledger(Account(code='123', name='MyAccount'), Balance(datetime.date(2018, 1, 1),Quantity(0)))
        }
    )

# Generated at 2022-06-24 00:58:43.295593
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    '''
    Test for method __repr__ of class LedgerEntry
    '''
    ledger = Ledger(Account("Test Account"), Balance(None, Quantity(Decimal(0))))
    journal = JournalEntry.create(datetime.date(2020, 1, 1))
    posting = Posting.create(journal, Account("Test Account"), Quantity(Decimal(1)), None)
    result = LedgerEntry(ledger, posting, Quantity(Decimal(1))).__repr__()
    assert result == "<LedgerEntry: 1.00 (account=Test Account, date=2020-01-01)>"


# Generated at 2022-06-24 00:58:44.446094
# Unit test for constructor of class Ledger
def test_Ledger():
    assert True

if __name__ == '__main__':
    test_Ledger()

# Generated at 2022-06-24 00:58:45.253264
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 00:58:51.424605
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    acc = Account("10100", "Cash")
    acc2 = Account("10101", "Cash")
    b1 = Balance("01/01/2020", Quantity(100))
    b2 = Balance("01/01/2021", Quantity(100))
    l1 = Ledger(acc,b1)
    l2 = Ledger(acc,b1)
    l3 = Ledger(acc,b2)
    l4 = Ledger(acc2,b1)
    assert l1 == l2
    assert l1 != l3
    assert l1 != l4


# Generated at 2022-06-24 00:58:59.724062
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.generic import JournalEntry, Posting
    from ..journaling.accounting import Account
    from ..journaling.quantities import Quantity

    from ..commons.zeitgeist import Date

    from .journaling import Posting

    from . import compile_general_ledger_program, build_general_ledger

    ## Read initial balances and journal entries from in-memory objects:
    from .memory import read_initial_balances, read_journal_entries

    ## Compile general ledger program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Running the program produces the general ledger:
    ledger = program(Date.range(Date(2018, 1, 1), Date(2018, 12, 31)))

    ## Balance of account A01 as of period end:

# Generated at 2022-06-24 00:59:09.812688
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    import os

    from .accounts import Account, AccountType, AccountScheme
    from .journaling import JournalEntry, Posting
    from .numbers import Amount


    def _mk_account(code):
        return Account(code, code, "", AccountType.Assets, AccountScheme())


    def _mk_posting(account, amount):
        return Posting(
            account=account,
            amount=Amount(amount),
            date=datetime.date(2019, 1, 1),
            journal=JournalEntry(date=datetime.date(2019, 1, 1), description=""),
        )
    
    account_a = _mk_account("A")
    account_b = _mk_account("B")
    account_c = _mk_account("C")
    # initial_balances = {account_a:

# Generated at 2022-06-24 00:59:13.745508
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger_1 = Ledger(Account('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'),Balance(datetime.date(1,1,1),Quantity(Decimal(0))))
    ledger_2 = Ledger(Account('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'),Balance(datetime.date(1,1,1),Quantity(Decimal(0))))
    assert ledger_1.__eq__(ledger_2) == True

# Generated at 2022-06-24 00:59:16.042431
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    e = LedgerEntry(None, Posting(None, None, None), None)
    r = repr(e)
    assert r == "LedgerEntry(ledger=None, posting=None, balance=None)"

# Generated at 2022-06-24 00:59:21.184097
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():    
    a1 = Account("1")
    a2 = Account("2")
    p1 = Posting(a1, 1, datetime.date(2020, 1, 1))
    p2 = Posting(a1, 2, datetime.date(2020, 1, 2))
    p3 = Posting(a2, 2, datetime.date(2020, 1, 1))
    l1 = Ledger(a1, Balance(datetime.date(2020, 1, 1), 1))
    l2 = Ledger(a1, Balance(datetime.date(2020, 1, 1), 1))
    l3 = Ledger(a2, Balance(datetime.date(2020, 1, 1), 1))
    l4 = Ledger(a1, Balance(datetime.date(2020, 1, 2), 1))

# Generated at 2022-06-24 00:59:33.167823
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    ledger = Ledger(Account('Ledger'), Balance(datetime.date(2020, 7, 1), Quantity(Decimal(0))))
    posting = Posting(DebitCredit.debit, Account('Account'), Amount(Decimal(100.50)))
    balance = Quantity(Decimal(0.50))
    entry = LedgerEntry(ledger, posting, balance)
    assert (str(entry) == "LedgerEntry(ledger=Ledger(account=Account('Ledger'), initial=Balance(date=datetime.date(2020, 7, 1), value=Quantity(Decimal('0')))), posting=Posting(direction=DebitCredit.debit, account=Account('Account'), amount=Amount(Decimal('100.50'))), balance=Quantity(Decimal('0.50')))")



# Generated at 2022-06-24 00:59:36.004968
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account.INDIRECT_COSTS
    initial_balance = Balance(datetime.date(2017, 11, 12), Quantity(Decimal(12345)))
    ledger = Ledger(account, initial_balance)

    assert ledger.account == account
    assert ledger.initial == initial_balance


# Generated at 2022-06-24 00:59:36.411820
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-24 00:59:37.220464
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert(ReadInitialBalances.__doc__ != None)


# Generated at 2022-06-24 00:59:43.269042
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Ledger(Account("UNITTEST1"), Balance(datetime.date(2020, 1, 1), Quantity(1)))

    # First test, both Ledger's are equal
    b = Ledger(Account("UNITTEST1"), Balance(datetime.date(2020, 1, 1), Quantity(1)))
    assert a == b

    # Second test, one Ledger is different
    c = Ledger(Account("UNITTEST1"), Balance(datetime.date(2020, 1, 2), Quantity(1)))
    assert not a == c

    # Third test, both Ledger's are different
    d = Ledger(Account("UNITTEST2"), Balance(datetime.date(2020, 1, 2), Quantity(2)))
    assert not a == d

# Generated at 2022-06-24 00:59:52.734773
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Cash, Revenue
    from .generic import Direction, Journal, Posting, ReadJournalEntries
    from .journaling.local import ReadJournalEntries as LocalReadJournalEntries
    from .journaling.memory import MemoryJournal
    from .journaling.memory import MemoryJournalEntry

    from . import __version__
    from .commons.numbers import Amount, Quantity

    class MockReadInitialBalances():
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Cash: Balance(period.since, Quantity(Decimal("12000.00"))),
                Revenue: Balance(period.since, Quantity(Decimal("0.00"))),
            }

    time_now = datetime.datetime.now()
    time_previous = datetime.datetime.now() - datetime.tim

# Generated at 2022-06-24 01:00:00.889140
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Cash
    from .journaling import create_journal_entry

    initial_balances = {
        Cash: Balance(datetime.date(2000, 12, 31), Quantity(Decimal(100))),
    }


# Generated at 2022-06-24 01:00:09.938285
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..models.accounts import Account
    from ..models.journaling import Journal
    from ..models.journaling.journaling import Posting
    from .accounting_period import AccountingPeriod
    from .accounts import AccountType, AccountDdl
    from .journaling import Posting, JournalEntry
    from .general_ledger import LedgerEntry, Ledger, GeneralLedger
    from .ledger_entry_type import LedgerEntryType
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity

    # create opening balance
    balance = Balance(date=AccountingPeriod.end_of_previous_period(datetime.date.today()), value=Quantity(3))
    # create account

# Generated at 2022-06-24 01:00:20.928965
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.business import Business
    from ..commons.events import TimeMachine
    from ..commons.identity import Identity
    from .accounts import Account, AccountType
    from .journaling import Journal, JournalEntry, Posting, PostingDirection

    ## This is the test business:
    business = Business(
        Identity(name="Foo"),
        "The test business",
        TimeMachine(datetime.datetime(2019, 1, 1)),
    )

    ## Assets account:
    a_assets = Account(business, AccountType.ASSET, "Assets")
    a_cash = Account(business, AccountType.ASSET, "Cash")
    a_inventory = Account(business, AccountType.ASSET, "Inventory")

    ## Liabilities account:

# Generated at 2022-06-24 01:00:28.688220
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    period = DateRange(datetime.date(2020, 3, 1), datetime.date(2020, 3, 31))
    acc1 = Account(1, "acc1", "acc1")
    acc2 = Account(2, "acc2", "acc2")
    acc3 = Account(3, "acc3", "acc3")
    bal1 = Balance(datetime.date(2020, 3, 1), Quantity(Decimal(100.00)))
    bal2 = Balance(datetime.date(2020, 3, 1), Quantity(Decimal(200.00)))
    bal3 = Balance(datetime.date(2020, 3, 1), Quantity(Decimal(300.00)))

    led1 = Ledger(acc1, bal1)
    led2 = Ledger(acc2, bal2)

# Generated at 2022-06-24 01:00:39.760151
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from pytest import approx
    from pytest import raises
    from pytest import warns
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from ..commons.zeitgeist import DateRange

    # An account ledger:
    def read_initial_balances():
        return {}

    # A journal entry reader:

# Generated at 2022-06-24 01:00:41.584850
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from .initial_balances import ReadInitialBalances



# Generated at 2022-06-24 01:00:48.178562
# Unit test for constructor of class Ledger
def test_Ledger():
    ## construct an account
    account = Account("123456")
    ## define initial balance and entries
    initial = Balance(datetime.datetime(2018,9,1), 100)
    entries = [1,2,3]
    ## Initialize the ledger
    ledger = Ledger(account, initial, entries)
    ## check if initialization is successful
    assert(ledger.account == account)
    assert(ledger.initial == initial)
    assert(ledger.entries == entries)

# Generated at 2022-06-24 01:00:54.109057
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # arrange
    account=Account("1", "test")
    balance = Balance("2", 3)
    entry = LedgerEntry("4", "5", 6)

    # act
    ledger = Ledger(account, balance)
    ledger.add(entry)
    print("ledger.__repr__(): " + ledger.__repr__())


# Generated at 2022-06-24 01:01:05.564748
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    amount_types = [
        int,
        float
    ]

# Generated at 2022-06-24 01:01:17.364151
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests whether function compile_general_ledger_program works as expected.
    """
    from .accounts import AccountType

    from .journaling import build_journal_entry

    ## Little mock-up for the algebra:
    def _mock_read_initial_balances(period: DateRange) -> InitialBalances:
        """
        Reads initial balances.
        """
        return {Account("101", AccountType.EXPENSE): Balance(period.since, Quantity(100)), Account("701", AccountType.ASSET): Balance(period.since, Quantity(-100))}

    def _mock_read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        """
        Reads journal entries.
        """

# Generated at 2022-06-24 01:01:22.018375
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Instanciate a ledger entry
    entry = LedgerEntry(Ledger('test', Balance('test', Quantity(Decimal(0)))), Posting('test'), Quantity(Decimal(0)))
    # Call the __repr__ method
    entry.__repr__()
    pass

# Generated at 2022-06-24 01:01:30.591036
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    @dataclass
    class MockReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    @dataclass
    class MockReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            yield JournalEntry([])

    glp = compile_general_ledger_program(
        MockReadInitialBalances(), MockReadJournalEntries()
    )
    result = glp(DateRange(since=datetime.date(2020, 7, 1), until=datetime.date(2020, 7, 2)))
    assert isinstance(result, GeneralLedger)

# Generated at 2022-06-24 01:01:38.074538
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    l1 = Ledger(Account("a1"), Balance(datetime.date(2020, 1, 1), Decimal("1")))
    l2 = Ledger(Account("a2"), Balance(datetime.date(2020, 1, 1), Decimal("1")))
    l3 = Ledger(Account("a1"), Balance(datetime.date(2020, 1, 1), Decimal("1")))
    l4 = Ledger(Account("a1"), Balance(datetime.date(2020, 1, 1), Decimal("2")))
    assert l1 == l3, "Ledger comparison does not work"
    assert l1 != l2, "Ledger comparison does not work"
    assert l1 != l4, "Ledger comparison does not work"
    


# Generated at 2022-06-24 01:01:48.513643
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class Program:
        read_initial_balances: ReadInitialBalances
        read_journal_entries: ReadJournalEntries[_T]

        def __call__(self, period: DateRange) -> GeneralLedger[_T]:
            ## Get initial balances as of the end of previous financial period:
            initial_balances = self.read_initial_balances(period)

            ## Read journal entries and post each of them:
            journal_entries = self.read_journal_entries(period)

            ## Build the general ledger and return:
            return build_general_ledger(period, journal_entries, initial_balances)

    a = Program(read_initial_balances = lambda x: print("hello"), read_journal_entries = lambda x: print("world"))

# Generated at 2022-06-24 01:01:51.005480
# Unit test for constructor of class Ledger
def test_Ledger():
	a = Ledger(1,2)
	assert a.account == 1
	assert a.initial == 2
	assert a.entries == []


# Generated at 2022-06-24 01:01:51.926525
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass


# Generated at 2022-06-24 01:01:52.822399
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    led = None

    assert(repr(led) == 'None')

# Generated at 2022-06-24 01:02:01.787102
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    #create object
    class object1(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass 
    
    #create object
    class object2(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    #create objects of type ReadInitialBalances
    o1=object1()
    o2=object2()
    assert isinstance(o1, ReadInitialBalances)
    assert isinstance(o2, ReadInitialBalances)
    
# Constructor for class GeneralLedgerProgram

# Generated at 2022-06-24 01:02:07.237511
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account1 = Account("1")
    account2 = Account("2")
    account3 = Account("3")

    journal1 = JournalEntry()
    journal1.post(account1, 100)
    journal1.post(account2, -100)

    journal2 = JournalEntry()
    journal2.post(account3, 200)
    journal2.post(account2, -200)

    posting1 = journal1.postings[0]
    posting2 = journal1.postings[1]
    posting3 = journal2.postings[0]
    posting4 = journal2.postings[1]
    ledger1 = Ledger(account1, Balance(datetime.date(2019,1,1),0))
    ledger2 = Ledger(account2, Balance(datetime.date(2019,1,1),-100))
   

# Generated at 2022-06-24 01:02:15.424559
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger = Ledger(account=Account(account_id=0, description="", category=0), initial=Balance(date='2020-12-31', value=0))
    ledger_same = Ledger(account=Account(account_id=0, description="", category=0), initial=Balance(date='2020-12-31', value=0))
    assert ledger == ledger_same
    ledger_diff = Ledger(account=Account(account_id=1, description="", category=0), initial=Balance(date='2020-12-31', value=0))
    assert ledger != ledger_diff


# Generated at 2022-06-24 01:02:25.429026
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Set up
    from .accounts import Account
    from .journaling import Journal, Posting, Side
    from .generic import Balance
    # account
    A1 = Account(1, "A", 1, False)
    # initial balance
    Balance1 = Balance(datetime.date(2020,1,1), Quantity(Decimal(1000)))
    # ledger
    L = Ledger(A1, Balance1)
    # journal
    J = Journal([], datetime.date(2020,2,2), "")
    # postings
    P1 = Posting(A1, datetime.date(2020,2,2), J, Quantity(Decimal(500)), Side.debit)
    # Expectations
    LedgerEntry1 = LedgerEntry(L, P1, Quantity(1500))
    # Add posting to the ledger
    LE

# Generated at 2022-06-24 01:02:32.658113
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, Debit

    class ReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("Assets", "Cash - USD"): Balance(period.since, Decimal(1000)),
                Account("Assets", "Cash - EUR"): Balance(period.since, Decimal(2000)),
            }


# Generated at 2022-06-24 01:02:41.466066
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Unit tests for method __eq__ of class LedgerEntry.
    """
    ## Set up Arrange and Act sections.
    sut = LedgerEntry(Ledger(Account(1), Balance(datetime.datetime.now(), Decimal(0))),
                      Posting(datetime.datetime.now(), Account(1), Account(2), Decimal(0)), Decimal(0))
    other_ledger_entry_1 = LedgerEntry(Ledger(Account(2), Balance(datetime.datetime.now(), Decimal(0))),
                                       Posting(datetime.datetime.now(), Account(1), Account(2), Decimal(0)), Decimal(0))

# Generated at 2022-06-24 01:02:49.350595
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account("4000", "Aktiva Lancar")
    initial = Balance(datetime.date(2019, 2, 1), Quantity(Decimal("2000000.00")))
    journal = JournalEntry(datetime.date(2019, 2, 1), "Journal Entry 1", [Posting(account, Amount("1200000.00"), "Debit")])
    entries = [LedgerEntry(Ledger(account, initial), Posting(account, Amount("1200000.00"), "Debit"), Quantity(Decimal("2000000.00")))]
    ledger = Ledger(account, initial, entries)


# Generated at 2022-06-24 01:02:56.339199
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    a = Account(name="Assets")
    b = Balance(date=DateRange(since="2019-01-01", until="2019-12-31"), value=Decimal(10))
    l = Ledger(a, b)
    assert repr(l) == 'Ledger(account=Account(name="Assets", code=None), initial=Balance(date=DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 12, 31)), value=Decimal("10")), entries=[])'

# Generated at 2022-06-24 01:03:07.888116
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(code="101", name="Bank", is_terminal=True)
    entry1 = JournalEntry(date=datetime.date(20000101), description="test", postings=[Posting(None, account, amount=Decimal(250), direction="c")])
    entry2 = JournalEntry(date=datetime.date(20000201), description="test", postings=[Posting(None, account, amount=Decimal(350), direction="d")])
    initial_balances = {account: Balance(entry1.date, Quantity(Decimal(0)))}
    list_entries = [entry1, entry2]
    period = DateRange(entry1.date, entry2.date)
    gl = build_general_ledger(period, list_entries, initial_balances)
    assert gl.ledgers[account].entries

# Generated at 2022-06-24 01:03:12.036016
# Unit test for constructor of class Ledger
def test_Ledger():
    p = Posting(1, 2, 3, 4, 5)
    b = Balance(6, 7)
    ledger = Ledger(p, b)

    assert ledger.account == p
    assert ledger.initial == b
    assert ledger.entries == []


# Generated at 2022-06-24 01:03:22.915268
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..commons.numbers import Amount
    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, Posting
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    @dataclass
    class T(ReadJournalEntries[Decimal]):

        def __call__(self, period: DateRange) -> Iterator[JournalEntry[Decimal]]:
            yield Journal("", [Posting(Account("100"), Decimal("100")), Posting(Account("200"), Decimal("-100"))])

    x = compile_general_ledger_program(
        ReadInitialBalances(lambda x: {}),
        T(None)
    )
    x = x(DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31)))
   

# Generated at 2022-06-24 01:03:23.736039
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:03:26.129422
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Tests :py:meth:`accounting.general_ledger.models.Ledger.__repr__` method of class :py:class:`Ledger`.
    """
    pass
    #TODO(Developer): A unit test for method __repr__ of class Ledger was not found. Implement the test method.

# Generated at 2022-06-24 01:03:33.216492
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    LedgerEntry1 = LedgerEntry(Ledger(Account(10, '', ''), Balance(datetime.date.today(), Quantity(10))), Posting(JournalEntry(datetime.date.today(), 'Test', [Posting(Account(10, '', ''), Quantity(10))]), Account(10, '', ''), Quantity(10)), Quantity(10))
    LedgerEntry2 = LedgerEntry(Ledger(Account(10, '', ''), Balance(datetime.date.today(), Quantity(10))), Posting(JournalEntry(datetime.date.today(), 'Test', [Posting(Account(10, '', ''), Quantity(10))]), Account(10, '', ''), Quantity(10)), Quantity(10))

# Generated at 2022-06-24 01:03:43.433045
# Unit test for constructor of class Ledger
def test_Ledger():
    @dataclass
    class Ledger(Generic[_T]):
        """
        Provides an account ledger model.
        """

        #: Account of the ledger.
        account: Account

        #: Initial balance of the ledger.
        initial: Balance

        #: Ledger entries.
        entries: List[LedgerEntry[_T]] = field(default_factory=list, init=False)

        @property
        def _last_balance(self) -> Quantity:
            """
            Returns the last balance.
            """
            try:
                return self.entries[-1].balance
            except IndexError:
                return self.initial.value


# Generated at 2022-06-24 01:03:49.479023
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances = lambda x : {1 : Balance(datetime.datetime.now(), Quantity(0))}
    read_journal_entries = lambda x : [JournalEntry(datetime.datetime.now(), "Test", [Posting(1, Quantity(50), 1)])]
    glp = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    assert glp(DateRange(datetime.datetime.now(), datetime.datetime.now())).ledgers[1].entries[0].balance == Quantity(50)

# Generated at 2022-06-24 01:04:00.799587
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """
    Tests the :py:func:`Ledger` class.
    """
    from ..domain.accounts import AccountNotFoundError
    from ..domain.accounts.entities import Accounts
    from ..domain.ledger import BuildGeneralLedger
    from ..domain.ledger.entities import GeneralLedger
    from ..infrastructure.accounts import read_accounts
    from ..infrastructure.ledger import build_general_ledger

    ## Read the accounts:
    accounts = read_accounts("scripts/accounts.csv")

    ## Build a ledger builder:
    builder = build_general_ledger(accounts, [])

    ## Build the general ledger for the period:
    print(builder(date_range))

    ## Test:
    AccountNotFoundError("whatever")


# Generated at 2022-06-24 01:04:02.045570
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-24 01:04:07.022907
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    ## Import the class.
    from sknano.structures import GeneralLedgerProgram

    ## Create the program.
    program: GeneralLedgerProgram[_T] = GeneralLedgerProgram()

    ## Check that we have an instance.
    assert isinstance(program, GeneralLedgerProgram)

    ## Check that we have a callable.
    assert callable(program)

# Generated at 2022-06-24 01:04:13.744694
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .accounts import Account
    from .journaling import Posting
    from .generic import Balance
    from . import journals
    from . import ledgers
    from . import readers
    from . import formats
    from . import registries
    from . import transactions
    from . import transactors
    from .journaling import Journal
    from .registries import JournalRegistry
    from .sets import AccountSet
    from .sets import AccountSetType
    from .sets import AccountSetMode
    # Create an account
    def _account1(name: str) -> Account:
        return Account(AccountSetType.ASSETS, AccountSetMode.INCREASE, name)
    account1 = _account1('cash')
    # Create a ledger

# Generated at 2022-06-24 01:04:22.992817
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    posting = Posting(None, datetime.datetime.today(), 2, Decimal(100))
    ledger = Ledger(None, None)
    ledger_entry = LedgerEntry(ledger, posting, 2)
    assert ledger_entry.ledger.__doc__ == 'Provides an account ledger model.'
    assert ledger_entry.posting.__doc__ == 'Provides a posting model.'
    assert ledger_entry.balance == 2
    assert ledger_entry.date == datetime.datetime.today()
    assert ledger_entry.is_debit == True
    assert ledger_entry.is_credit == False
    assert ledger_entry.debit == Decimal(100)
    assert ledger_entry.credit == None


# Generated at 2022-06-24 01:04:23.732142
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    pass
    #TODO


# Generated at 2022-06-24 01:04:34.900140
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from datetime import date
    from ..methods.usage import test_data, run_test_data
    from .generic import Balance
    from .journaling import JournalEntry, Journal, Posting
    from .accounts import Account

    def _test_GeneralLedger___repr__(
        date_since, date_until, account, balance, journal_date, debit, credit, description, account_counter
    ):
        ## Iterate over accounts:
        ledgers = {
            Account(account): Ledger(
                Account(account),
                Balance(
                    date_since,
                    Decimal(balance),
                ),
            )
        }

        ## Create general ledger:
        general_ledger = GeneralLedger(
            DateRange(
                date_since,
                date_until,
            ),
            ledgers,
        )



# Generated at 2022-06-24 01:04:44.213849
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import Account
    ledger = Ledger(Account('100'), Balance(datetime.date(2020, 1, 1), Quantity(100)))
    entry = LedgerEntry(ledger, Posting(datetime.date(2020, 3, 2), Account('100'), Amount(Decimal(25))))
    assert entry.__repr__() == """LedgerEntry(ledger=Ledger(account=Account(code='100'), initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(value=Decimal('100')))), posting=Posting(date=datetime.date(2020, 3, 2), account=Account(code='100'), amount=Amount(value=Decimal('25'))), balance=Quantity(value=Decimal('125')))"""

# Generated at 2022-06-24 01:04:52.687709
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import ReadJournalEntries
    from .accounts import Account, ReadInitialBalances

    ## Define parameters:
    period = DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2018, 12, 31))
    opening_balance = Balance(period.since, Quantity(Decimal(1_000)))

    ## Define algebras:
    read_initial_balances = ReadInitialBalances({Account("A1"): opening_balance})
    read_journal_entries = ReadJournalEntries()

    ## Compile program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Run the program:
    general_ledger = program(period)

    ## Check results:

# Generated at 2022-06-24 01:04:58.125763
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Constructor of class ReadInitialBalances
    def current_initial_balances(period: DateRange) -> InitialBalances:
        initial_balances = {
            Account('demo', 'demo', '1001'): Balance(period.since, Quantity(Decimal(0.00)))
        }
        return initial_balances

    # Constructor of class ReadJournalEntries

# Generated at 2022-06-24 01:05:09.953107
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import TerminalAccount
    from .journaling import Posting
    from .utils.factories import create_journal_from_postings, create_posting, create_journal_and_posting
    from .utils.numbers import random_decimal
    from .commons.zeitgeist import date_range

    # Some test accounts:
    a1 = TerminalAccount("a1")
    a2 = TerminalAccount("a2")
    a3 = TerminalAccount("a3")

    # Some test opening and closing dates:
    since = datetime.date(2020, 1, 1)
    until = datetime.date(2020, 12, 31)

    # Accounting period:
    period = date_range(since, until)

    # Initial balances:

# Generated at 2022-06-24 01:05:20.396349
# Unit test for method __repr__ of class LedgerEntry

# Generated at 2022-06-24 01:05:23.538859
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    ## Create a ledger entry:
    entry = LedgerEntry(None, None, None)
    ## Check that the representation is indeed the expected one:
    assert repr(entry) == "LedgerEntry(None, None, None)"



# Generated at 2022-06-24 01:05:28.091053
# Unit test for constructor of class Ledger
def test_Ledger():
    # Create test account
    account = Account("Test", "")

    # Create test initial balance
    initial = Balance(datetime.date(2019, 1, 1), 0)

    # Initialize a test Ledger instance
    ledger = Ledger(account, initial)

    # Verify properties of the test Ledger
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == []


# Generated at 2022-06-24 01:05:34.623474
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from .accounts import Account, AccountType

    @dataclass
    class CompiledReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    initial_balances = CompiledReadInitialBalances()
    assert initial_balances is not None



# Generated at 2022-06-24 01:05:45.065093
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Define the accounting period:
    period = DateRange.from_dates(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Define the initial balances:

# Generated at 2022-06-24 01:05:55.680342
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Unit test for method __eq__ of class LedgerEntry.
    """
    # Set up ledger entry 1
    ledger = Ledger(Account("1"), Balance(datetime.date(2020, 2, 1), Quantity(Decimal(0))))
    posting = Posting(
        datetime.date(2020, 2, 1),
        JournalEntry(
            datetime.date(2020, 2, 1), "Description", [Posting(datetime.date(2020, 2, 1), ledger.account, Amount(1))]
        ),
        ledger.account,
        Amount(2),
    )
    balance = Quantity(Decimal(0))
    ledger_entry_1 = LedgerEntry(ledger, posting, balance)
    # Set up ledger entry 2

# Generated at 2022-06-24 01:06:06.304384
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    acc = Account("myAccount", "myDescription")
    amount = Amount(Decimal(10.00))
    direction = Quantity(Decimal(1))
    posting = Posting(acc, amount, direction)
    balance = Quantity(Decimal(10.00))
    ledger = Ledger(acc, balance)
    entry = LedgerEntry(ledger, posting, balance)
    assert entry.date == posting.date
    assert entry.description == posting.description
    assert entry.amount == posting.amount
    assert entry.cntraccts == posting.cntraccts
    assert entry.is_debit == posting.is_debit
    assert entry.is_credit == posting.is_credit
    assert entry.debit == posting.debit
    assert entry.credit == posting.credit
    assert entry.ledger == ledger
   

# Generated at 2022-06-24 01:06:08.931042
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-24 01:06:18.676959
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import build_journal_entry
    from .accounts import AccountCode, build_account


# Generated at 2022-06-24 01:06:25.917296
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class Balance(Generic[_T]):
        date: datetime.date
        value: Optional[_T]

    @dataclass
    class InitialBalances(Dict[Account, Balance]):
        pass

    @dataclass
    class DummyReadInitialBalances(ReadInitialBalances):
        balances: InitialBalances

        def __call__(self, period: DateRange):
            return self.balances

    def test_read_initial_balances():
        read_initial_balances = DummyReadInitialBalances(InitialBalances({Account("123456789"): Balance(datetime.date(2019, 1, 1), 100)}))

# Generated at 2022-06-24 01:06:31.004709
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    def _f():
        return Ledger(Account('1000'), Balance(datetime.date(2020, 1, 1), Quantity(100)))
  
    r = repr(_f())
    assert r == "Ledger(account=Account('1000'), initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(100)))"

# Generated at 2022-06-24 01:06:40.374469
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import AccountType, Account
    from .journaling import Posting, Journal, JournalEntry
    from .generic import AccountDirection

    posting = Posting(date = datetime.date.today(), description = "Posting description", amount = 20)
    ledger = Ledger(Account(AccountType.ASSET, "Cash"), Balance(datetime.date.today(), 1))
    entry = LedgerEntry(ledger, posting, 9)

    assert entry.date == posting.date
    assert entry.description == posting.description
    assert entry.amount == posting.amount
    assert entry.balance == Quantity(9)

    # Check the debit and credit properties
    posting = Posting(date = datetime.date.today(), description = "Posting description", account_direction = AccountDirection.DEBIT, amount = 20)
    entry = LedgerEntry

# Generated at 2022-06-24 01:06:41.596514
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    assert(LedgerEntry == type(LedgerEntry))

# Generated at 2022-06-24 01:06:50.572384
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Tests method __repr__ of class GeneralLedger.
    """
    # Import required modules
    import pytest
    from datetime import date
    from swiftsmith.journaling import Posting, JournalEntry
    from swiftsmith.accounts import Account, AccountType
    from swiftsmith.commons.zeitgeist import DateRange
    from .general import GeneralLedger

    # Create a general ledger instance

# Generated at 2022-06-24 01:06:53.586286
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # TODO: Test if the method __eq__ returns the correct value when given an
    #       instance of GeneralLedger as argument.
    assert False == True

# Generated at 2022-06-24 01:06:59.105292
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account=Account(1,"Assets")
    initial=Balance(datetime.date(2019,11,11),1)
    entries=[]
    ledger=Ledger(account,initial,entries)
    assert repr(ledger)=="Ledger(account=Account(id=1, name='Assets'), initial=Balance(date=datetime.date(2019, 11, 11), value=Decimal('1')), entries=[])"

# Generated at 2022-06-24 01:07:05.515316
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .journaling import build_journal_entry, JournalEntryType

    from .accounts import AccountType, build_account

    cash_account = build_account(AccountType.ASSET, "CASH", "Cash")
    owner_equity_account = build_account(AccountType.EQUITY, "OWNER_EQUITY", "Owner's Equity")
    commodity_account = build_account(AccountType.EXPENSE, "COMMODITY", "Commodity")

    journal_1 = build_journal_entry(1, "Journal #1", JournalEntryType.GENERAL)

    journal_1.post(commodity_account, 100, "Payment for commodity.")
    journal_1.post(cash_account, -100, "Payment for commodity.")


# Generated at 2022-06-24 01:07:13.375146
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    """
    Unit test for constructor of LedgerEntry
    """
    ledger = Ledger(Account(1234, "GL"), Balance.of(Decimal(1234)),[])
    posting = Posting(Account(4321, "GL"), Decimal(1), datetime.date(2020, 1, 1), "Unit Test Posting",None,None)
    entry = LedgerEntry(ledger, posting, Decimal(1))
    assert entry.debit == Decimal(1)
    assert entry.credit == None


# Generated at 2022-06-24 01:07:14.521855
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:07:18.093028
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger({
        "account": "account",
        "entries": "entries",
        "initial": "initial",
        "ledgers": "ledgers",
        "period": "period"
    })


# Generated at 2022-06-24 01:07:24.872109
# Unit test for constructor of class Ledger
def test_Ledger():
    pass
    #
    # print("Test constructor of class Ledger:")
    #
    # acc = Account.get(code='5')
    # i = Balance(datetime.date(2020, 5, 26), Quantity(Decimal(1000)))
    #
    # print("Test 1:")
    # x = Ledger(acc, i)
    # print(x.__dict__)
    #
    # print("Done testing constructor of class Ledger!")


# Generated at 2022-06-24 01:07:30.105516
# Unit test for constructor of class Ledger
def test_Ledger():
    account : Account = Account("MyLedgerTest", "Test for creating a Ledger", "Test")
    balance : Balance = Balance(datetime.date(2017,1,1), Quantity(Decimal(10)))
    LedgerEntry = Ledger(account, balance)
    assert LedgerEntry.account == account
    assert LedgerEntry.initial == balance
    assert LedgerEntry.entries == []


# Generated at 2022-06-24 01:07:35.941614
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("account", "myaccount")
    journal = JournalEntry(datetime.date(2010, 1, 1), "My Journal Entry")
    posting = Posting(account, journal, Amount(Decimal(100)))
    ledger = Ledger(account, Balance(datetime.date(2010, 1, 1), Quantity(Decimal(0))))
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(100))
    #self.assertEquals(Quantity(Decimal(200)), ledger.entries[2].balance)


# Generated at 2022-06-24 01:07:43.329575
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Tests method __repr__ of class GeneralLedger.
    """
    from datetime import date
    from unittest import TestCase, main

    from .accounts import Account as A
    from .journaling import JournalEntry as JE, Posting as P
