

# Generated at 2022-06-24 00:57:40.711799
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True



# Generated at 2022-06-24 00:57:46.218546
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    assert GeneralLedger(DateRange(1,1),{})==GeneralLedger(DateRange(1,1),{})
    assert not (GeneralLedger(DateRange(2,2),{})==GeneralLedger(DateRange(1,1),{}))
    assert not (GeneralLedger(DateRange(2,2),{1:Ledger(1,Balance(2,2))})==GeneralLedger(DateRange(1,1),{}))
    assert not (GeneralLedger(DateRange(1,1),{})==GeneralLedger(DateRange(1,1),{1:Ledger(1,Balance(2,2))}))

# Generated at 2022-06-24 00:57:56.333594
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    t_GeneralLedger = GeneralLedger[object]
    t_InitialBalances = InitialBalances
    t_Ledger = Ledger[object]
    t_LedgerEntry = LedgerEntry[object]
    t_Account = Account
    t_DateRange = DateRange
    t_Balance = Balance
    t_Quantity = Quantity
    t_Posting = Posting[object]
    t_JournalEntry = JournalEntry[object]

    gl1_period = t_DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 12, 31))
    gl1_ledger1 = t_Ledger(t_Account("1000"), t_Balance(datetime.date(2000, 1, 1), t_Quantity(1)))

# Generated at 2022-06-24 00:58:02.986843
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    ## Creates a general ledger program:
    from .algebra import ReadInitialBalancesAlgebra, ReadJournalEntriesAlgebra
    program = compile_general_ledger_program(ReadInitialBalancesAlgebra(), ReadJournalEntriesAlgebra())
    assert program(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31)))

# Generated at 2022-06-24 00:58:07.886550
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from . import accounts, journaling
    from .commons import zeitgeist
    from .ledger import read_ledger_initial_balances
    from .journaling import journal_posting

    ## Initialize a ledger-building program:
    program = compile_general_ledger_program(  # TODO: Replace by a more real implementation of read_initial_balances.
        read_ledger_initial_balances,
        journaling.journal_postings,
    )

    ## Test:
    ## Define the period:
    period = zeitgeist.DateRange.from_string("2019-02-01", "2019-02-28")
    ## Build general ledger:
    general_ledger = program(period)
    ## Test:
    assert general_ledger.period == period

    ## Test:
    ## Define the

# Generated at 2022-06-24 00:58:10.421629
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass



# Generated at 2022-06-24 00:58:15.341702
# Unit test for constructor of class Ledger
def test_Ledger():
    acc = Account(name="A1", balance_type=BalanceType.credit)
    l = Ledger(acc, Balance(datetime.date(1,1,1), Quantity(Decimal(0))))
    assert l.account == acc
    assert l.initial == Balance(datetime.date(1,1,1), Quantity(Decimal(0)))
    assert l.entries == []


# Generated at 2022-06-24 00:58:24.691975
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():

    from .journaling import build_journal_entry

    ## Test data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    entry1 = build_journal_entry(
        datetime.date(2019, 1, 1), "Opening balances as of 1/1/2019", [("A001", 1000, None), ("A002", 2000, None)]
    )
    entry2 = build_journal_entry(
        datetime.date(2019, 1, 2), "Purchase of assets", [("A001", -500, "A003"), ("A003", 1500, None)]
    )
    entries = [entry1, entry2]

# Generated at 2022-06-24 00:58:33.455755
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import Posting
    from .posts import Post
    from .dates import DateRange

    # Create test values.
    lines = []
    lines.append("1/1/2019")
    lines.append("C100")
    lines.append("C101")
    lines.append("")
    lines.append("1")
    lines.append("2")
    lines.append("C102")
    lines.append("C103")
    lines.append("")
    lines.append("3")
    lines.append("4")


    # Create test objects.
    account_one = Account("C100")
    account_two = Account("C101")
    account_three = Account("C102")

# Generated at 2022-06-24 00:58:40.355238
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from numbers import Number
    from ..stockkeeping.accounting.accounts import Account, AccountType
    from ..stockkeeping.accounting.journaling import JournalEntry
    from ..stockkeeping.accounting.units import as_quantity
    from ..stockkeeping.accounting.transactions import Transaction, TransactionType
    from ..stockkeeping.accounting.journaling import Posting, Journal, JournalType


    a1 = Account('1000', AccountType.ASSET)
    a2 = Account('2000', AccountType.LIABILITY)
    a3 = Account('3000', AccountType.EQUITY)
    a4 = Account('4000', AccountType.REVENUE)
    a5 = Account('5000', AccountType.EXPENSE)
    a6 = Account('6000', AccountType.ASSET)



# Generated at 2022-06-24 00:58:50.745619
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import read_journal_entries, Posting, JournalEntry
    L = Ledger(Account("A", "a"), Balance(Date(1,1,1960), Quantity(0)))
    L.add(Posting(JournalEntry(Date(1,1,1960), "a"), Account("A", "a"), Quantity(0), 1))
    L.add(Posting(JournalEntry(Date(1,1,1960), "b"), Account("A", "a"), Quantity(1), 1))
    L.add(Posting(JournalEntry(Date(1,1,1960), "c"), Account("A", "a"), Quantity(2), 1))

# Generated at 2022-06-24 00:58:54.426153
# Unit test for constructor of class Ledger
def test_Ledger():
    # Create a Ledger instance with a balance
    acct = Account("Open account")
    bal = Balance(datetime.datetime(2018,6,22), Quantity(35))
    ledger = Ledger(acct, bal)
    assert ledger.account == acct
    assert ledger.initial == bal
    assert ledger.entries == []
    assert ledger._last_balance == Quantity(35)


# Generated at 2022-06-24 00:58:56.087478
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Unit test for constructor of class GeneralLedgerProgram
    """
    pass

# Generated at 2022-06-24 00:59:01.141082
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """
    ## Mock a read initial balances algebra and make it return the following initial balances:
    read_initial_balances = lambda period: {"101": Balance(datetime.date(2020, 1, 1), Decimal(10)), "102": Balance(datetime.date(2020, 1, 1), Decimal(20))}

    ## Mock a read journal entries algebra and make it return the following journal entries:
    read_journal_entries = lambda period: [JournalEntry(date=datetime.date(2020, 1, 1), description="", postings=[Posting("101", Decimal(5), False), Posting("102", Decimal(5), True)])]

    ## Compile a general ledger program:

# Generated at 2022-06-24 00:59:05.314599
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Instantiating a Ledger
    ledger = Ledger(account=Account("assets",["current","accounts","receivable"]), initial=Balance(datetime.date(2019, 9, 1), Quantity(100)))
    # Instantiating a Posting
    posting = Posting("debit", datetime.date(2019, 10, 3), Amount(100.0), Account("assets",["cash"]), Account("expenses",["interest"]))
    # Adding the Posting to the Ledger
    ledgerEntry = ledger.add(posting)
    # Testing if the attributes of the LedgerEntry inserted into the Ledger have the correct values
    # Testing if the date of the Posting is equal to the date of the LedgerEntry
    assert(ledgerEntry.date == posting.date)
    # Testing if the amount of the Posting is equal to the amount of

# Generated at 2022-06-24 00:59:09.559163
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    x = GeneralLedger
    y = build_general_ledger
    z = compile_general_ledger_program
    assert x
    assert y
    assert z

# Generated at 2022-06-24 00:59:10.102402
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-24 00:59:19.121982
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class Unit:
        id: int

    @dataclass
    class MockJournalEntry:
        account: Account
        balance: Balance

    @dataclass
    class MockReadJournalEntries:
        calls: int

        def __call__(self, period: DateRange) -> Iterable[MockJournalEntry]:
            self.calls = self.calls + 1
            return []

    @dataclass
    class MockReadInitialBalances:
        calls: int

        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            self.calls = self.calls + 1
            return {}

    mockReadJournalEntries = MockReadJournalEntries(calls=0)
    mockReadInitialBalances = MockReadInitialBalances(calls=0)
    generalLed

# Generated at 2022-06-24 00:59:30.980431
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    from ..services.journaling import AccountingLedger, AccountingLedgerService, JournalingService
    from ..services.accounting_period import AccountingPeriod, AccountingPeriodService

    from datetime import date

    # Read initial balances
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        period_start = date(2020, 6, 1)
        period_end = date(2020, 6, 30)
        initial_balances = {Account("CASH"): Balance(date(2020, 5, 31), Quantity(100)),
                            Account("REVENUE"): Balance(date(2020, 5, 31), Quantity(100)),
                            Account("EXPENSE"): Balance(date(2020, 5, 31), Quantity(-100))}
        return initial_balances

    # Read journal entries

# Generated at 2022-06-24 00:59:33.214287
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Assert:
    # Check number of return values.
    assert False



# Generated at 2022-06-24 00:59:40.325699
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    import datetime
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry
    read_journal_entries = []
    program = compile_general_ledger_program(read_journal_entries)
    assert program.__name__ == '_program'
    assert program.__doc__ == """
    Consumes the opening and closing dates and produces a general ledger.

    :param period: Accounting period.
    :return: A general ledger.
    """
    assert isinstance(read_journal_entries, List)

# Generated at 2022-06-24 00:59:49.597640
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Construct GeneralLedgerProgram
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {}
    
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return {}
    glp = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    
    # Test for method __call__
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    assert isinstance(glp(period), GeneralLedger)

# Generated at 2022-06-24 00:59:59.037285
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import datetime

    from ..commons.zeitgeist import DateRange
    from .accounts import Account, Asset, Liability

    from ..commons.numbers import Amount, Quantity

    from .generic import Balance

    from ..commons.types import read_line

    from .components import book_source

    ## Get test case data:
    lines = read_line("/home/mohsen/phd/std/std-ledger/test/testcases/initial-balances.txt")

    ## Build the book source and read initial balances:
    source = book_source(lines)
    read_initial_balances = source.read_initial_balances()

    ## Get the period of interest:
    period = DateRange(datetime.date(2018, 4, 1), datetime.date(2018, 6, 30))

    ## Read

# Generated at 2022-06-24 01:00:05.470977
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test the equality test of :py:class:`LedgerEntry`.
    """
    # Create a ledger entry
    ledger = Ledger(Account("1"), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0))))
    posting = Posting(datetime.date(2019, 1, 1), journal=JournalEntry(datetime.date(2019, 1, 1), "test"), direction=DEBIT,
                      account=Account("1"), amount=Amount(Decimal(100)))
    balance = Quantity(Decimal(100))
    le = LedgerEntry(ledger, posting, balance)

    # Initialize ledger and posting
    new_ledger = Ledger(Account("1"), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0))))

# Generated at 2022-06-24 01:00:06.765708
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert False, 'Test Not Implemented'


# Generated at 2022-06-24 01:00:16.600950
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
   Tests function compile_general_ledger_program
   :return:
   """
    print('Testing compile_general_ledger_program')

    # Tests the function compile_general_ledger_program with input values:
    # period=DateRange(since=parse_date('2020-01-01'), until=parse_date('2020-12-31')),
    # initial_balances= {
    #     'Assets.Cash': Balance(date=parse_date('2020-01-01'), value=Decimal('100.00')),
    #     'Equity.Capital': Balance(date=parse_date('2020-01-01'), value=Decimal('100.00'))
    # }


    # Declare required values

# Generated at 2022-06-24 01:00:21.120465
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Given
    A1 = Account(1)
    entry = LedgerEntry(None, Posting(A1, Quantity(1), None,None), Quantity(1))
    assert repr(entry) is not None


# Generated at 2022-06-24 01:00:22.074211
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances is not None


# Generated at 2022-06-24 01:00:29.388090
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Assemble test data
    current_date = datetime.datetime.now().date()
    previous_date = current_date - datetime.timedelta(days=365)

# Generated at 2022-06-24 01:00:40.048973
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class _Dummy:
        #: Account of the ledger.
        account: Account

        #: Initial balance of the ledger.
        initial: Balance
    class _DummyInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account.of('A1', 'Test Account 1'), Balance(_Dummy(Account.of('A1', 'Test Account 1'), Balance(datetime.date(2020, 1, 1), Quantity(0))))
            }

# Generated at 2022-06-24 01:00:49.936075
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test __eq__ function of the LedgerEntry class.
    """
    from .accounts import AccountSchema
    from .journaling import JournalEntrySchema, PostingSchema
    from ..commons.types import Quantity, Amount
    from ..commons.zeitgeist import DateRange
    from ..commons.junk import is_close_to, as_dict

    account_schema = AccountSchema()
    posting_schema = PostingSchema()
    journal_schema = JournalEntrySchema()
    general_ledger_schema = GeneralLedger(DateRange(), {})
    ledger = Ledger(account=account_schema, initial=Balance(as_of=general_ledger_schema.period.since, value=Quantity(0)))
    posting = posting_schema
    ledger_entry = Ledger

# Generated at 2022-06-24 01:00:53.693700
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledgers_list1 = []
    ledgers_list2 = []
    ledgers_list3 = []
    ledgers_list4 = []
    ledgers_list1.append(Ledger(Account("1000"), Balance(datetime.date(2020, 1, 1), Quantity(100))))
    ledgers_list1.append(Ledger(Account("1000"), Balance(datetime.date(2020, 1, 1), Quantity(100))))
    ledgers_list1.append(Ledger(Account("1002"), Balance(datetime.date(2020, 1, 1), Quantity(100))))
    ledgers_list1.append(Ledger(Account("1003"), Balance(datetime.date(2020, 1, 1), Quantity(100))))

# Generated at 2022-06-24 01:00:54.189070
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass

# Generated at 2022-06-24 01:01:03.546724
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # (ledger, posting, balance) is a global variable to test the equality of LedgerEntry
    # LedgerEntry(ledger, posting, balance) is an instance of LedgerEntry
    # (ledger, posting, balance) is not an instance of LedgerEntry

    # Test return 0 when two ledger entries are equal
    assert LedgerEntry(ledger, posting, balance) == LedgerEntry(ledger, posting, balance)
    # Test return 1 when the ledger entries are different
    assert LedgerEntry(ledger, posting, balance) != (ledger, posting, balance)

# Generated at 2022-06-24 01:01:13.709173
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange('2019-01-01', '2019-12-31')
    journal = JournalEntry([Posting('A1', '2019-01-05', 500), Posting('A2', '2019-01-05', 500)], '500 to A1')
    initial = {'A1': Balance('2019-01-01', 1000)}
    ledger = build_general_ledger(period, journal, initial)
    assert ledger != None # Check that a general ledger was created.
    assert ledger.ledgers['A1'] != None # Check that a ledger for A1 account was created.
    assert ledger.ledgers['A1'].entries[0].balance == 1500 # Check that the balance in the ledger for A1 has been updated.

# Generated at 2022-06-24 01:01:17.150982
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert Ledger(None, Balance('', 0)) == Ledger(None, Balance('', 0))
    assert not Ledger(None, Balance('', 0)) == Ledger(None, Balance('', 1))


# Generated at 2022-06-24 01:01:28.694299
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 1))
    account = Account(
        code="code",
        group="group",
        name="name",
        description="description",
        shortname="shortname",
        path="path",
        category="category",
        parent=None
    )
    posting = Posting(
        date=datetime.date(2019, 1, 1),
        amount=Amount(10),
        direction="direction",
        account=account,
        journal=None
    )
    balance = Balance(
        date=datetime.date(2019, 1, 1),
        value=Quantity(10)
    )

# Generated at 2022-06-24 01:01:35.851379
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # Setup
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 2, 28))
    accounts = [Account("A", "", ""), Account("B", "", "")]
    entries = [Posting(account=accounts[0], amount=Amount(1), direction=1, journal=JournalEntry(datetime.date(2020, 1, 1), "", []))]
    initial = dict(zip(accounts, [Balance(datetime.date(2019, 12, 31), Quantity(1))]))
    ledgers = dict(zip(accounts, [Ledger(accounts[0], initial[accounts[0]], entries)]))

    # Exercise
    actual = GeneralLedger(period, ledgers)

    # Verify

# Generated at 2022-06-24 01:01:40.472937
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert Ledger(Account(1), Balance(2000,0)) == Ledger(Account(1), Balance(2000,0))
    assert Ledger(Account(1), Balance(2000,0)) != Ledger(Account(2), Balance(2000,0))
    assert Ledger(Account(1), Balance(2000,0)) != Ledger(Account(1), Balance(2001,0))


# Generated at 2022-06-24 01:01:50.639154
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date, timedelta
    from .accounts import Account, TerminalAccount

    @dataclass
    class ExecutableInitialBalances(ReadInitialBalances):
        """
        Type of functions which reads and returns initial balances.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                TerminalAccount("101", "Cash and bank deposits"): Balance(date(2019, 10, 27), Quantity(Decimal(1000))),
                TerminalAccount("102", "Petty cash"): Balance(date(2019, 10, 27), Quantity(Decimal(5000))),
            }


# Generated at 2022-06-24 01:01:51.146504
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ReadInitialBalances()

# Generated at 2022-06-24 01:01:53.429678
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """

    """
    No test for this method... for now at least.
    """
    pass

# Generated at 2022-06-24 01:02:02.369037
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests function compile_general_ledger_program.
    """

    ## Create a toy implementation of algebra:
    @dataclass
    class AlgebraImpl:
        pass

    ## Build a function which consumes accounting period:
    program = compile_general_ledger_program(AlgebraImpl(), AlgebraImpl())

    ## An accounting period.
    period = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31))

    ## Compile the program and provide the period:
    general_ledger = program(period)

    ## Should be a GeneralLedger instance:
    assert isinstance(general_ledger, GeneralLedger)

# Generated at 2022-06-24 01:02:13.040682
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    d1 = datetime.date(2017, 1, 1)
    d2 = datetime.date(2017, 2, 1)
    period = DateRange(d1, d2)
    account1 = Account('Cash', 1)
    account2 = Account('Sales', 2)
    account3 = Account('Cost of Sales', 3)
    account4 = Account('Accounts Receivable', 4)
    account5 = Account('Accounts Payable', 5)

# Generated at 2022-06-24 01:02:23.576620
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from ..test.test_fixtures import period, initial_balances, journal_entries, ledger_entries
    from operator import eq
    assert (
        GeneralLedger(period, {a: Ledger(a, initial_balances[a], ledger_entries[a]) for a in initial_balances})
        == GeneralLedger(period, {a: Ledger(a, initial_balances[a], ledger_entries[a]) for a in initial_balances})
    )

# Generated at 2022-06-24 01:02:29.785162
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    test_account = Account(1234)
    test_initial = Balance(datetime.date(2019,1,1), Decimal(2345))
    test_entries = [LedgerEntry(Ledger(test_account,test_initial), Posting(JournalEntry(datetime.date(2019,1,1), "test_journal_entry"),test_account,Decimal(2345)),Decimal(2345))]
    test_ledger = Ledger(test_account,test_initial)
    test_ledger.entries = test_entries

# Generated at 2022-06-24 01:02:33.085597
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ReadInitialBalancesStub:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    ReadInitialBalancesStub()

# Generated at 2022-06-24 01:02:39.096682
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    date = datetime.date.today()
    acc = Account(123, 'account', 'Account', None, None, None, None)
    posting = Posting(None, acc, Amount(10), None)
    entry = LedgerEntry(None, posting, None)
    assert str(entry) == "LedgerEntry(posting=Posting(date=None, account=Account(code=123, name='account', " \
                         "description='Account', type=None, currency=None, state=None, parent=None), " \
                         "amount=Amount(value='10'), direction=None), balance=None)"


# Generated at 2022-06-24 01:02:48.342990
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from nose.tools import assert_equal

    LedgerEntry(
        ledgers={'123': 'cred', '234': 'deb'},
        posting= {
            'date': datetime.date(2019, 12, 31),
            'journal': {'description': 'New Year!', 'postings': [
                {
                    'amount': 1,
                    'account': '123',
                    'direction': 'deb'
                },
                {
                    'amount': 1,
                    'account': '234',
                    'direction': 'deb'
                },
            ]},
            'account': '234',
            'amount': 1,
            'direction': 'deb'
        },
        balance = 1)

# Generated at 2022-06-24 01:02:48.820558
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    pass

# Generated at 2022-06-24 01:02:49.503223
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    pass


# Generated at 2022-06-24 01:02:54.950073
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Initialize test case
    account = Account("Assets", "Cash")
    ledger = Ledger(account, Balance(datetime.date(2018, 1, 1), Quantity(Decimal('0'))))
    posting = Posting(Decimal("100"), datetime.date(2018, 1, 1), "Test transaction", account, "+")
    
    ## Execute method
    result = ledger.add(posting)

    ## Check result
    assert len(ledger.entries) == 1
    assert result == ledger.entries[0]
    assert result.ledger == ledger
    assert result.posting == posting
    assert result.balance == Quantity(Decimal("100"))
    assert result.date == datetime.date(2018, 1, 1)
    assert result.description == "Test transaction"

# Generated at 2022-06-24 01:03:01.341489
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 01:03:12.983453
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .ledger import build_general_ledger
    from .journaling import JournalEntry, Posting

    def test_case_1():
        ## Prepare test data:
        period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 1, 31))
        initial = {
            Account(code=10000, name="Cash", is_terminal=True): Balance(date=period.since, value=Decimal(10000))
        }


# Generated at 2022-06-24 01:03:23.614989
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import datetime
    from decimal import Decimal
    from typing import Optional
    from unittest import TestCase
    from dataclasses import dataclass
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from ..commons.numbers import Quantity

    @dataclass
    class AccountA(Account):
        #: Balance:
        balance: Optional[Balance] = None

    @dataclass
    class AccountB(Account):
        #: Balance:
        balance: Optional[Balance] = None

    @dataclass
    class AccountC(Account):
        #: Balance:
        balance: Optional[Balance] = None

    #: Sample initial balances:

# Generated at 2022-06-24 01:03:26.672044
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    class I(ReadInitialBalances):
        def __call__(self, period):
            return {}
    return I()


# Generated at 2022-06-24 01:03:38.336351
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import journal_entry as je, posting
    from .accounts import account as a, terminal_account as ta
    import datetime
    from  dataclasses import asdict
    from zeitgeist import DateRange

    period = DateRange(since=datetime.date(2016,1,1),until=datetime.date(2016,2,1))
    je1 = je(
        datetime.date(2016,1,3),
        'Payment for ABRAZZ-1111',
        [
            posting(datetime.date(2016,1,3),ta('7111', 'Cash in bank'),100),
            posting(datetime.date(2016,1,3),ta('2111', 'Accounts receivable'),-100)
        ]
    )

# Generated at 2022-06-24 01:03:46.053991
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, T
    from .journaling import JournalEntry, Posting

    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {Account(T.EQ, "101"): Balance(period.since, Decimal(0))}


# Generated at 2022-06-24 01:03:51.700168
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .journaling import Journal, Postings, Transaction

    debit = Posting(Account("Assets"), Amount(5), Transaction("Small journal entry", [], Date(2018, 1, 2)))
    credit = Posting(Account("Liabilites"), Amount(5), Transaction("Small journal entry", [], Date(2018, 1, 2)))

    entry = LedgerEntry(
        None,
        debit,
        Quantity(0),
    )

    entry_copy = LedgerEntry(
        None,
        debit,
        Quantity(0),
    )

    entry_unequal_posting = LedgerEntry(
        None,
        credit,
        Quantity(0),
    )

    assert entry == entry_copy
    assert entry != entry_unequal_posting
    assert not (entry != entry_copy)

# Generated at 2022-06-24 01:03:54.192462
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    GeneralLedger(DateRange(datetime.date(2019, 3, 31), datetime.date(2019, 6, 30)), Dict())


# Generated at 2022-06-24 01:04:05.678753
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():

    def read_initial_balances(initial_balances: InitialBalances, period: DateRange):
        return initial_balances

    def read_journal_entries(journal_entries: Iterable[JournalEntry], period: DateRange):
        return journal_entries

    compiled_general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert compiled_general_ledger_program

    # Test case 1:
    initial_balances = {}
    journal_entries = []

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 2, 1))
    compiled_general_ledger_program(period)

    # Test case 2:

# Generated at 2022-06-24 01:04:16.480110
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ... import deeplift, liftinaction
    from ..general import general

    # Read initial balances
    read_initial_balances = deeplift.read_initial_balances(liftinaction.get_initial_balances)

    # Read journal entries
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return liftinaction.read_journal_entries(
            liftinaction.get_journal_entries(),
            liftinaction.get_journal_transformation_fn(),
            period.since,
            period.until
        )

    # Compile general ledger program
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Test with the program

# Generated at 2022-06-24 01:04:22.558669
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType, AccountKind
    from .accounts import AccountCode, AccountName
    from .accounts import AccountNature
    from .commons.zeitgeist import DateRange, DateFactory

    ## Prepare:
    dt = DateFactory()
    period = DateRange(dt.since(year=2019, month=1, day=1), dt.until(year=2019, month=12, day=31))

# Generated at 2022-06-24 01:04:25.061545
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account()
    t = datetime.datetime.now()
    p = Posting(
        account=a,
        date=t,
        amount=100,
        direction=Direction.CREDIT)
    j = {p}
    l = Ledger(a, j)
    assert l.account == a
    assert l.initial == j

# Generated at 2022-06-24 01:04:34.865240
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    journal = [JournalEntry(datetime.date(2019,1,1), 'JE1', 'Manual', [Posting(datetime.date(2019,1,1),'JE1','L1','Manual','CHF',1000,1000)])]
    balances = {'L1': Balance(datetime.date(2019,1,1), Quantity(Decimal(1000)))}
    general_ledger = build_general_ledger(DateRange(since=datetime.date(2019,1,1),until=datetime.date(2019,1,1)), journal, balances)
    a = general_ledger.ledgers['L1'].entries[0].balance == Quantity(Decimal(1000))
    return a

# Generated at 2022-06-24 01:04:35.452552
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-24 01:04:39.520602
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account ("100", "Jane Doe", True)
    balance_currency = 'usd'
    balance = Balance(Decimal(1000), balance_currency)
    ledger = Ledger(account, balance)
    assert ledger.account == account
    assert ledger.initial == balance



# Generated at 2022-06-24 01:04:44.256392
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class Stub:
        """Stub" class for testing."""
        pass
    period = DateRange(datetime.date(2019,1,1), datetime.date(2019,12,31))
    g = GeneralLedger(period, {})
    assert compile_general_ledger_program(lambda x: {}, lambda x: [Stub()])(period) == g

# Generated at 2022-06-24 01:04:46.276835
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Compile and run a general ledger program.
    """
    pass


if __name__ == "__main__":
    test_compile_general_ledger_program()

# Generated at 2022-06-24 01:04:49.346071
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2020, 4, 11),datetime.date(2020, 4, 24))
    journal = []
    initial = {}
    general_ledger = GeneralLedger(period, journal, initial)
    assert general_ledger is not None


# Generated at 2022-06-24 01:05:01.514878
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    ##
    class Obj:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    ##

# Generated at 2022-06-24 01:05:11.028447
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class Program:
        ledger: GeneralLedger
        def __call__(self, period: DateRange) -> GeneralLedger:
            return self.ledger
    pr = Program(GeneralLedger(DateRange(datetime.date(2020, 4, 1), datetime.date(2020, 4, 30)),
                               {Account("000000", "My account"): Ledger(Account("000000", "My account"), Balance(datetime.date(2020, 4, 1), Quantity(Decimal(0)))),
                                Account("000001", "My account"): Ledger(Account("000001", "My account"), Balance(datetime.date(2020, 4, 1), Quantity(Decimal(0))))}))
    gp = compile_general_ledger_program(pr, pr)

# Generated at 2022-06-24 01:05:18.054112
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from decimal import Decimal
    from typing import Iterator
    from ..commons.zeitgeist import DateRangeFactory
    from .journaling import JournalEntryImplementation, JournalEntry, Posting, Transaction
    from ..commons.numbers import Quantity

    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        ## For this test we have no initial balances, return empty dictionary:
        return {}

    def read_journal_entries(_period: DateRange) -> Iterator[JournalEntry]:
        ## Create individual transactions:
        trx1 = Transaction(1, "Test", datetime.date(2018, 1, 1), [
            Posting(1, "A", Quantity(Decimal(10))),
            Posting(2, "B", Quantity(Decimal(10))),
        ])



# Generated at 2022-06-24 01:05:28.496545
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Test the add method of class Ledger.
    :return:
    """
    ledger_Test = Ledger(Account(1, "Test", "Test"), Balance(datetime.date.today(), Quantity(5)))
    posting_Test = Posting(JournalEntry(datetime.date.today(), "Test", [Account(1, "Test", "Test")]),
                           Account(1, "Test", "Test"), Quantity(5))
    entry_test = LedgerEntry(ledger_Test, posting_Test, Quantity(5))
    ledger_Test.add(posting_Test)
    assert ledger_Test.entries[-1].account == entry_test.account
    assert ledger_Test.entries[-1].posting == entry_test.posting
    assert ledger_Test.entries[-1].balance == entry_

# Generated at 2022-06-24 01:05:39.817559
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    import datetime
    from ..commons.numbers import Amount, Quantity
    from .journals import Journal
    from .accounts import Account, AccountType
    from .relationships import Relationship

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Defines a ledger entry model.
    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity

        @property
        def date(self) -> datetime.date:
            """
            Date of the ledger entry.
            """
            return

# Generated at 2022-06-24 01:05:40.893472
# Unit test for constructor of class ReadInitialBalances

# Generated at 2022-06-24 01:05:41.994510
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    """
    Unit test for constructor of class LedgerEntry
    """
    pass

# Generated at 2022-06-24 01:05:48.826438
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Asserts that the method __eq__ of class LedgerEntry returns
    True if the objects are identical and False otherwise

    """
    account = Account('1000')
    entry1 = LedgerEntry(account,Posting(account,Decimal('10.0'),datetime.date(2020,3,3)),Decimal('20.0'))
    entry2 = LedgerEntry(account,Posting(account,Decimal('10.0'),datetime.date(2020,3,3)),Decimal('20.0'))
    assert entry1 == entry2 is True
    entry3 = LedgerEntry(account,Posting(account,Decimal('10.0'),datetime.date(2020,3,3)),Decimal('30.0'))
    assert entry1 == entry3 is False



# Generated at 2022-06-24 01:05:53.498351
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # Initialize the test variables
    period = DateRange(since='2019-01-01', until='2019-01-30')

    readIB = ReadInitialBalances()
    initialBalances = readIB.__call__(period)
    print(initialBalances)


if __name__ == "__main__":
    test_ReadInitialBalances()

# Generated at 2022-06-24 01:05:54.128576
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-24 01:05:57.574180
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Setup
    l=LedgerEntry(ledger=1,posting=2,balance=3)
    assert repr(l)=='LedgerEntry(ledger=1, posting=2, balance=3)'
    return True


# Generated at 2022-06-24 01:06:07.193852
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Import:
    from datetime import date, timedelta
    from decimal import Decimal
    from typing import Iterable, List
    from ..commons import zeitgeist
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import JournalEntry, Journal, Posting
    from .generic import Balance
    from .core import Ledger, GeneralLedger
    from .core import build_general_ledger
    from .core import LedgerEntry

    ## Alias:
    from ..commons.selftest import assert_raises

    ## Test case #1:

# Generated at 2022-06-24 01:06:08.990707
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances()


# Generated at 2022-06-24 01:06:18.716333
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    actual_result_1 = Ledger("test_account", Balance("test_date", Decimal("1.1"))) == \
                      Ledger("test_account", Balance("test_date", Decimal("1.1")))
    actual_result_2 = Ledger("test_account", Balance("test_date", Decimal("1.1"))) == \
                      Ledger("account_test", Balance("test_date", Decimal("1.1")))
    actual_result_3 = Ledger("test_account", Balance("test_date", Decimal("1.1"))) == \
                      Ledger("account_test", Balance("date_test", Decimal("1.1")))
    assert actual_result_1 is True
    assert actual_result_2 is False
    assert actual_result_3 is False


# Generated at 2022-06-24 01:06:25.943553
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledger1 = Ledger(1, 1, 1)
    ledger2 = Ledger(2, 2, 2)
    entry1 = LedgerEntry(ledger1, 1, 1)
    entry2 = LedgerEntry(ledger1, 1, 2)
    entry3 = LedgerEntry(ledger2, 2, 1)
    entry4 = LedgerEntry(ledger1, 2, 1)
    assert entry1.__eq__(entry2) == False
    assert entry1.__eq__(entry3) == False
    assert entry1.__eq__(entry4) == False
    assert entry2.__eq__(entry3) == False
    assert entry2.__eq__(entry1) == False
    assert entry2.__eq__(entry4) == False

# Generated at 2022-06-24 01:06:35.137438
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-24 01:06:46.155365
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from .accounts import Account, Category, TerminalAccount
    from .numbers import Amount


# Generated at 2022-06-24 01:06:57.613131
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from dataclasses import dataclass
    from types import FunctionType
    from .accounts import Account
    from .generic import Balance

    @dataclass
    class _MockAlgebra(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return { Account("0") : Balance(date(2019, 1, 1), Quantity(123)),
                     Account("1") : Balance(date(2019, 1, 1), Quantity(456)) }

    assert isinstance(ReadInitialBalances, FunctionType)
    mock = _MockAlgebra()
    assert isinstance(mock, ReadInitialBalances)
    assert read_initial_balances.__annotations__ == { 'return' : InitialBalances }

# Generated at 2022-06-24 01:07:03.182805
# Unit test for constructor of class Ledger
def test_Ledger():
    print("Testing constructor of class Ledger ...", end="")
    x = Ledger(Account(0, '', '', False), Balance(datetime.date(2011, 1, 1), Quantity(Decimal(0))))
    assert isinstance(x, Ledger)
    print("Passed!")



# Generated at 2022-06-24 01:07:07.267516
# Unit test for method add of class Ledger
def test_Ledger_add():
    assert Ledger(Account("1000000"), Balance()).add(Posting(JournalEntry(), Account("1000000"), Decimal(1))).balance == Decimal(1)
    assert Ledger(Account("1000000"), Balance()).add(Posting(JournalEntry(), Account("1000000"), Decimal(0.5))).balance == Decimal(0.5)
    assert Ledger(Account("1000000"), Balance()).add(Posting(JournalEntry(), Account("1000000"), Decimal(0))).balance == Decimal(0)
    assert Ledger(Account("1000000"), Balance()).add(Posting(JournalEntry(), Account("1000000"), Decimal(-1))).balance == Decimal(-1)
    assert Ledger(Account("1000000"), Balance()).add(Posting(JournalEntry(), Account("1000000"), Decimal(-0.5))).balance

# Generated at 2022-06-24 01:07:12.981083
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """

    import datetime
    from decimal import Decimal
    from typing import Dict, Optional

    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .transactions import Transaction

    #: Initial balances:
    initial_balances: Dict[Account, Balance] = {
        Account("1010"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal("100"))),
        Account("2010"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal("100"))),
    }

    #: Journal entries:

# Generated at 2022-06-24 01:07:23.865492
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Given
    from moneyed import GBP, USD
    from datetime import date
    from ledger.entities import Account
    from ledger.entities import Posting
    from ledger.entities import JournalEntry
    dictAcct = {'Cash': Account('Cash', 'Asset', 'Current Assets'), 'Suppliers': Account('Suppliers', 'Liability', 'Current Liabilities'), 'Expenses': Account('Expenses', 'Expense', 'Cost of Sales'), 'Accounts Payable': Account('Accounts Payable', 'Liability', 'Current Liabilities'), 'Equity': Account('Equity', 'Equity', 'Stockholders Equity')}
    dictPost = {'Cash': Posting(dictAcct['Cash'], USD(100)),
                'Suppliers': Posting(dictAcct['Suppliers'], USD(100))}
    dict

# Generated at 2022-06-24 01:07:24.539845
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-24 01:07:29.085749
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1))
    journal = []
    initial = {}

    # Should call build_general_ledger and return a GeneralLedger object
    assert isinstance(build_general_ledger(period, journal, initial), GeneralLedger[_T])


# Generated at 2022-06-24 01:07:39.465402
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    a = Account("1100")
    j = JournalEntry()
    p1 = Posting(a, Amount(1), j)
    p2 = Posting(a, Amount(2), j)
    le1 = LedgerEntry(None, p1, Quantity(Decimal(1)))
    le2 = LedgerEntry(None, p2, Quantity(Decimal(2)))
    assert(le1.__repr__() == "LedgerEntry(posting=Posting(account=Account(number='1100'), amount=Amount(value='1'), direction=Debit), balance=Quantity(value='1'))")
    assert(le2.__repr__() == "LedgerEntry(posting=Posting(account=Account(number='1100'), amount=Amount(value='2'), direction=Debit), balance=Quantity(value='2'))")


# Generated at 2022-06-24 01:07:40.946479
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass
