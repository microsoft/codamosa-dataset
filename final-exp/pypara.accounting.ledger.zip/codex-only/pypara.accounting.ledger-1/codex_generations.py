

# Generated at 2022-06-24 00:57:47.989648
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    l = Ledger(Account(1), Balance(datetime.date(2020, 1, 1), 10))
    assert repr(l) == f"""\
Ledger(
    account=Account(
        id=1,
    ),
    initial=Balance(
        date=datetime.date(
            2020,
            1,
            1,
        ),
        value=Quantity(
            value=10,
        ),
    ),
    entries=[\
],
)"""

# Generated at 2022-06-24 00:57:57.379073
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Tests the constructor of the class GeneralLedgerProgram
    """
    import datetime

    def read_initial_balances(period: DateRange) -> InitialBalances:
        initial_balances = {'Nishan': Balance(period.since, Quantity(Decimal(0)))}
        return initial_balances


# Generated at 2022-06-24 00:58:02.209318
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from datetime import date
    from ..commons.types import AccountingPeriod
    from ..date import Interval

    period = AccountingPeriod(date(2020, 1, 20), date(2020, 2, 10))
    interval = Interval(date(2020, 1, 5), date(2020, 1, 20))

    ledger1 = GeneralLedger(period, {})
    ledger2 = GeneralLedger(period, Ledger(Account(1, Account.Type.EXPENSE), Balance(interval, Quantity(10))))

    assert ledger1 != None
    assert ledger1 == ledger1
    assert ledger1 != ledger2

# Generated at 2022-06-24 00:58:08.564417
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    now = datetime.datetime.now()
    since = now.date()
    until = since + datetime.timedelta(days=30)

    assert isinstance(ReadInitialBalances.__call__(ReadInitialBalances, DateRange(since, until)), InitialBalances)


# Generated at 2022-06-24 00:58:13.455082
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    Unit test for method __eq__ of class GeneralLedger
    """
    # Expected values
    expected_GeneralLedger = GeneralLedger(
        period = 'period',
        ledgers = 'ledgers'
    )
    # Computed values
    actual_GeneralLedger = GeneralLedger(
        period = 'period',
        ledgers = 'ledgers'
    )
    # Check if computed value is equal to expected value
    assert expected_GeneralLedger == actual_GeneralLedger


# Generated at 2022-06-24 00:58:18.988549
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Compiles the general ledger program and runs it to see if it works.
    """

    ## Define the input:
    initial_balances = {
        Account("Cash", "101-1-100"): Balance(datetime.date(2020, 1, 1), Quantity(1.00)),
        Account("Equity", "101-1-110"): Balance(datetime.date(2020, 1, 1), Quantity(-1.00)),
    }

    ## Compile the program:
    program = compile_general_ledger_program(
        lambda _: initial_balances, lambda _: [JournalEntry(datetime.date(2020, 1, 1), "Test journal entry")]
    )

    ## Run the program:

# Generated at 2022-06-24 00:58:20.483860
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-24 00:58:24.504990
# Unit test for constructor of class Ledger
def test_Ledger():
    Account = "ACCOUNT1"
    balance = Balance(account=Account, date="01-01-2019", value=0)
    ledger = Ledger[str](account=Account, initial=balance)
    assert ledger.account == Account
    assert ledger.initial == balance
    assert ledger.entries == []

# Generated at 2022-06-24 00:58:30.339003
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    test = compile_general_ledger_program(ReadInitialBalances, ReadJournalEntries)
    assert test is not None
    def _s(s1: DateRange) -> InitialBalances:
        return InitialBalances
    def _t(s2: DateRange) -> GeneralLedger:
        return GeneralLedger
    assert test(_t) is not None


# Generated at 2022-06-24 00:58:36.405239
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account = "test"
    l = Ledger(account,Amount(10))
    date = datetime.date.today()
    p = Posting(account, date, Amount(2), Direction.DEBIT)
    print(p)
    print(l)
    le = LedgerEntry(l,p)
    assert le.posting.direction == Direction.DEBIT
    assert le.balance == Amount(12)
    assert le.date == date
    assert le.account == account
test_LedgerEntry()

# Generated at 2022-06-24 00:58:46.641072
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import AccountType
    from .commons import Currency
    from .journaling import DEBIT, CREDIT, What, Journal

    initial_balances = {
        Account("A/R", AccountType.ASSET): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(1000))),
        Account("A/P", AccountType.LIABILITY): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(-500))),
    }

# Generated at 2022-06-24 00:58:47.132493
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass

# Generated at 2022-06-24 00:58:54.481109
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class Mock:
        def __init__(self) -> None:
            self.called = False

        def __call__(self, period: DateRange) -> InitialBalances:
            self.called = True
            self.period = period

    mock = Mock()
    assert not mock.called
    assert not hasattr(mock, "period")

    ReadInitialBalances.__call__(mock, DateRange(datetime.date(1995, 1, 1), datetime.date(1995, 12, 31)))
    assert mock.called
    assert mock.period == DateRange(datetime.date(1995, 1, 1), datetime.date(1995, 12, 31))


# Generated at 2022-06-24 00:58:55.345141
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    l = Ledger(None, None)
    assert l == l


# Generated at 2022-06-24 00:59:02.229846
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger_a = Ledger(
        account=Account(code="4010", name="Accounts Payable"),
        initial=Balance(
            date=datetime.date(2020, 1, 1),
            value=Amount(Decimal(10), currency="IDR")
        )
    )

# Generated at 2022-06-24 00:59:11.274859
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    acc1 = Account("10001","Cash on hand")
    acc2 = Account("10001","Cash on hand")
    acc3 = Account("10002","Cash in bank")
    bal1 = Balance(datetime.date(2010,11,21),Decimal("100.00"))
    bal2 = Balance(datetime.date(2010,11,21),Decimal("100.00"))
    bal3 = Balance(datetime.date(2010,11,21),Decimal("200.00"))
    j1 = JournalEntry(datetime.date(2010,11,21),"First entry",[Posting(acc1,Decimal("100.00")),Posting(acc3,Decimal("-100.00"))])

# Generated at 2022-06-24 00:59:18.337437
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..accounting.accounts import AccountType
    from ..accounting.ledgers import Ledger, LedgerEntry
    from ..journaling.journaling import JournalEntry, Posting
    from ..journaling.journals import JournalType, JournalSubType
    from numbers import Quantity
    from decimal import Decimal
    from ..commons.currencies import Currency
    from datetime import date
    account = Account("1234", AccountType.Asset, Currency("EUR"))
    initial_balance = Quantity(Decimal(100))
    ledger = Ledger(account, initial_balance)
    journal_entry1 = JournalEntry("test", JournalType.IncomeExpense, JournalSubType.Revenue, Currency("EUR"), date(2019,11,24))
    posting1 = Posting(account, journal_entry1, Quantity(Decimal(50)))
    ledger

# Generated at 2022-06-24 00:59:24.154496
# Unit test for constructor of class Ledger
def test_Ledger():
    A = Account("A")
    le1 = Ledger(A,Balance(datetime.date(2018,4,4),Quantity(Decimal(20))))
    assert le1.account == A
    assert le1.initial == Balance(datetime.date(2018,4,4),Quantity(Decimal(20)))
    assert le1.entries == []
    assert le1._last_balance == 20


# Generated at 2022-06-24 00:59:35.747639
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import unittest
    from .accounts import Account

    from .journaling import Journal, Posting

    from . import ledger_algebra_interpreters as algs

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("1000"): Balance(period.since, Quantity(500))}

    def _read_journal_entries(period: DateRange) -> Iterable[Journal]:
        return [Journal(datetime.date(2019, 4, 30), "Entry 1", [Posting(Account("2050"), Quantity(300), +1)])]


# Generated at 2022-06-24 00:59:40.593114
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..accounting.accounts import Account

    account = Account("ACCT")
    posting = Posting(
        DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 10))
    )
    balance = Quantity(Decimal(0))

    le = LedgerEntry(account, posting, balance)
    assert le.account == account
    assert le.posting == posting
    assert le.balance == balance


# Generated at 2022-06-24 00:59:47.133032
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("test")
    initial = Balance(datetime.date(2020, 9, 25), Quantity(Decimal(0)))
    test_ledger = Ledger(account, initial)
    assert test_ledger.account == account
    assert test_ledger.initial == initial
    assert test_ledger.entries == []

# Generated at 2022-06-24 00:59:58.275953
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..ledger.journaling import create_journal_entry
    from ..ledger.accounts import create_account

    ## Create and configure the account `1000':
    account_1000 = create_account("1000", "Operational Revenue", "Revenue")
    account_1000.set_currency("USD")
    account_1000.set_type("Revenue")

    ## Create and configure the account `2000':
    account_2000 = create_account("2000", "Operational Expense", "Expense")
    account_2000.set_currency("USD")
    account_2000.set_type("Expense")

    ## Create the journal entry:

# Generated at 2022-06-24 01:00:01.038793
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """Unit test for method __eq__ of class LedgerEntry"""
    assert LedgerEntry(None, None, None) == LedgerEntry(None, None, None)
    assert LedgerEntry(None, None, None) == (None, None, None)

# Generated at 2022-06-24 01:00:01.784806
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ReadInitialBalances()


# Generated at 2022-06-24 01:00:06.644442
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(Account("AAAA"), Balance(datetime.date(2019, 1, 2), Decimal(1000)))) == "Ledger(Account('AAAA'), Balance(datetime.date(2019, 1, 2), Decimal('1000')))"

# Generated at 2022-06-24 01:00:16.601775
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .algebras import asset_accounts, equity_accounts
    from .journaling import journal_entry, read_journal_entries

    ## Prepare the program:
    compile_general_ledger_program(
        ## TODO: Implement initial balance reader.
        lambda _: {a: Balance(datetime.date(2020, 1, 1), Quantity(100)) for a in asset_accounts},
        read_journal_entries([
            journal_entry(
                datetime.date(2020, 1, 1),
                "Debtors", "Cash", 10000,
                "Invoice #123: Nuts and Bolts",
            ),
        ]),
    )(
        DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 2, 1)),
    )

# Generated at 2022-06-24 01:00:26.701783
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """Simple unit test for function build_general_ledger."""
    from datetime import date
    from antinex_utils.accounting.journaling import Journal
    from antinex_utils.accounting.accounts import Account

    ## Build test journal entries:
    j1 = Journal(date(2020, 1, 1), description="Test transaction 1")
    j1.post(Account.bank, 100)
    j1.post(Account.equity, -100)
    j2 = Journal(date(2020, 2, 1), description="Test transaction 2")
    j2.post(Account.bank, 200)
    j2.post(Account.equity, -200)

    ## Build initial balances:
    initial = {Account.bank: Balance(date(2020, 1, 1), Quantity(Decimal(0)))}

    ## Build test

# Generated at 2022-06-24 01:00:35.400380
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Set up
    ledger = Ledger(account=Account("0001"), initial=Balance(date=datetime.date(2019,9,9), value=Quantity(Decimal(0))))
    posting = Posting(account=Account("0001"), amount=Amount(Decimal(0)), direction=1, journal="print(\"Hello World!\")")
    entry = LedgerEntry(ledger=ledger, posting=posting, balance=Quantity(Decimal(0)))
    # Exercise
    actual = str(entry)
    # Verify

# Generated at 2022-06-24 01:00:40.212832
# Unit test for constructor of class Ledger
def test_Ledger():

    # create new account
    account = Account("Test account")
    # create a new balance
    balance = Balance(datetime.date.today(), Quantity(Decimal(0)))
    # construct new ledger
    ledger = Ledger(account, balance)
    print("Ledger is built")
    assert ledger is not None



# Generated at 2022-06-24 01:00:46.436660
# Unit test for method add of class Ledger
def test_Ledger_add():
    class JournalEntry:
        def __init__(self,date,postings):
            self.date = date
            self.postings = postings
        def __iter__(self):
            for posting in self.postings:
                yield posting

    class Posting:
        def __init__(self,account,amount,direction):
            self.account = account
            self.amount = amount
            self.direction = direction
        @property
        def is_debit(self):
            return self.direction == "D"
        @property
        def is_credit(self):
            return self.direction == "C"

    class Balance:
        def __init__(self,date,value):
            self.date = date
            self.value = value
        @property
        def value(self):
            return self._value

# Generated at 2022-06-24 01:00:48.049731
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():

    assert(True)


# Generated at 2022-06-24 01:00:57.618151
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    acct1 = Account(code='0001', number='0001', name='Cash')
    bal1 = Balance(date=datetime.date(2020, 1, 1), value=1000)
    acct2 = Account(code='0002', number='0002', name='Receivables')
    bal2 = Balance(date=datetime.date(2020, 1, 1), value=2000)

    ledger1 = Ledger(acct1, bal1)
    ledger1.add(Posting(date=datetime.date(2020, 2, 1), journal=JournalEntry(description="Hello1", postings=[Posting(account=acct1, amount=100, direction=Direction.Debit)])))

# Generated at 2022-06-24 01:01:00.767316
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    a = Account(1, 'owner')
    b = Balance(1, 1)
    l = Ledger(a, b)
    assert l.__repr__() == f'<{l.__class__.__name__}: {a}>'

# Generated at 2022-06-24 01:01:10.540530
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from datetime import date
    from decimal import Decimal

    from .accounts import Account
    from .generic import Amount, Balance, Quantity

    # Create test data for class Ledger
    test_account = Account(code='00001', name='Test Account')
    test_initial_balance = Balance(date(2020, 1, 1), Quantity(Decimal(1)))
    test_entries = [
        LedgerEntry(None, None, Quantity(Decimal(1))),
        LedgerEntry(None, None, Quantity(Decimal(2))),
    ]

    # Create an instance of class Ledger
    instance = Ledger(account=test_account, initial=test_initial_balance, entries=test_entries)

    # Test method __eq__ of class Ledger
    assert(instance == instance)
    assert(instance != None)



# Generated at 2022-06-24 01:01:22.468473
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from tests.commons import TestableReadJournalEntries, TestableReadInitialBalances

    ## Define accounting period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define closing balances:
    closing_balances = {
        Account("A", "Assets"),
        Account("L", "Liabilities"),
        Account("E", "Equity"),
        Account("R", "Revenues"),
        Account("C", "Cost & Expenses"),
        Account("I", "Income Tax Expense"),
    }

    ## Define test general ledger program:
    program = compile_general_ledger_program(
        TestableReadInitialBalances(closing_balances), TestableReadJournalEntries(period, closing_balances)
    )

   

# Generated at 2022-06-24 01:01:28.072364
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    Period =  datetime.date(2018,1,1)
    Ledger = {"account A": 20, "account B": 60}
    a = GeneralLedger(Period, Ledger)
    assert (a.ledgers is Ledger) and (a.period is Period)


# Generated at 2022-06-24 01:01:32.447426
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry({'ledger': 'ledger', 'posting': 'posting', 'balance': 'balance'})) ==\
           "LedgerEntry(ledger='ledger', posting='posting', balance='balance')"


# Generated at 2022-06-24 01:01:39.664408
# Unit test for constructor of class Ledger
def test_Ledger():
    class JournalEntry:
        def __init__(self, self1,self2,self3):
            self.id = self1
            self.description = self2
            self.account = self3
            self.postings = [Posting(self3,self3,self3,self3)]
    class Account:
        def __init__(self,self1,self2):
            self.id = self1
            self.name = self2
    class Posting:
        def __init__(self, self1,self2,self3,self4):
            self.account = self1
            self.journal = self2
            self.amount = self3
            self.direction = self4
    class Balance:
        def __init(self,self1,self2):
            self.asof = self1

# Generated at 2022-06-24 01:01:48.620681
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # declare test input and expected output
    posting = Posting(
        account = Account("Expenses:Food:Markets"),
        amount = Decimal("1.00"),
        journal = JournalEntry(
            date = datetime.date(2020,9,1),
            description = "Test transaction",
            postings = [
                Posting(
                    account = Account("Assets:Cash"),
                    amount = Decimal("-1.00")
                )
            ]
        )
    )

    ledger = Ledger(
        account = Account("Expenses:Food:Markets"),
        initial = Balance(
            date = datetime.date(2020,9,1),
            value = Decimal("-1.00")
        )
    )

    balance = Decimal("-2.00")


# Generated at 2022-06-24 01:01:52.531076
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test for method __eq__ of class LedgerEntry
    """
    ## Arrange
    ledger_entry = LedgerEntry(1,2,3)

    ## Act
    result = ledger_entry == ledger_entry

    ## Assert
    assert type(result) == bool


# Generated at 2022-06-24 01:01:55.700356
# Unit test for constructor of class Ledger
def test_Ledger():
    assert True

# Generated at 2022-06-24 01:02:03.522966
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    gl = GeneralLedger(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)),{Account.fromstring('1010'):Ledger(Account.fromstring('1010'),Balance(datetime.date(2018, 4, 4),Quantity(Decimal(0))))})
    assert LedgerEntry(gl.ledgers[Account.fromstring('1010')],Posting(datetime.date(2018, 1, 1),datetime.date(2018, 1, 1),Account.fromstring('1000'),Quantity(Decimal('100.00')),True),Quantity(Decimal('100.00'))).__repr__() == 'LedgerEntry(account=1010, date=2018-01-01, balance=100.00, amount=100.00, is_debit=True)'


# Generated at 2022-06-24 01:02:14.544797
# Unit test for method add of class Ledger
def test_Ledger_add():
    account1 = Account("1")
    initial_balance1 = Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0)))
    ledger1 = Ledger(account1, initial_balance1)
    assert ledger1.account == Account("1")
    assert ledger1.initial == Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0)))
    assert ledger1.entries == []
    journal_entry1 = JournalEntry(datetime.date(2000, 1, 1), "First journal entry", [
        Posting(account1, datetime.date(2000, 1, 1), Quantity(Decimal(10)), False, False),
        Posting(account1, datetime.date(2000, 1, 1), Quantity(Decimal(0)), False, True)
    ])

# Generated at 2022-06-24 01:02:20.815411
# Unit test for constructor of class Ledger
def test_Ledger():
    LedgerTester = Ledger(Account('1020', 'Cash'), Balance(datetime.date(2020, 4, 30), Quantity(12.00)))
    assert LedgerTester.account == Account('1020', 'Cash')
    assert LedgerTester.initial == Balance(datetime.date(2020, 4, 30), Quantity(12.00))
    assert LedgerTester.entries == []



# Generated at 2022-06-24 01:02:30.697694
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account
    from .commons.numbers import Quantity
    from .journaling import JournalEntry, Posting, Transaction

    # test data
    t1 = Transaction('test txn 1')
    t1.posting('a/1', '1')
    t1.posting('a/2', '-1')

    t2 = Transaction('test txn 2')
    t2.posting('a/2', '1')
    t2.posting('a/1', '-1')

    t3 = Transaction('test txn 3')
    t3.posting('a/1', '1.5')

    t4 = Transaction('test txn 4')

# Generated at 2022-06-24 01:02:39.323569
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Mock for the period
    period = DateRange(
        since=datetime.date(year=2018, month=1, day=1),
        until=datetime.date(year=2018, month=2, day=1),
    )

    # Mock for the journal
    journal = []

    # Mock for the initial balances
    initial_balances = {}

    # Execute the general ledger with parameter period, journal and initial_balances
    func = build_general_ledger(period, journal, initial_balances)

    # Assert that class GeneralLedger is the owner of func
    assert isinstance(func, GeneralLedger)
    return

# Generated at 2022-06-24 01:02:44.890865
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Unit test for constructor of class Ledger
    """
    A = Account(1, "test")
    B = Balance(datetime.date(2018, 1, 1), Amount(0))
    L = Ledger(A, B)
    print(L)
    assert L.account == A
    assert L.initial == B
    assert L._last_balance == B.value


# Generated at 2022-06-24 01:02:52.183716
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():

    class Journal:
        def __init__(self, date, description, postings):
            self._date = date
            self._description = description
            self._postings = postings

        @property
        def date(self):
            return self._date

        @date.setter
        def date(self, value):
            self._date = value

        @property
        def description(self):
            return self._description

        @description.setter
        def description(self, value):
            self._description = value

        @property
        def postings(self):
            return self._postings

        @postings.setter
        def postings(self, value):
            self._postings = value

    class JournalEntry:
        pass


# Generated at 2022-06-24 01:02:57.382988
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 8, 30))

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return []

    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    program(period)

# Generated at 2022-06-24 01:03:08.594046
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert Ledger(Account('a', 1), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0)))) == \
        Ledger(Account('a', 1), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0))))
    assert Ledger(Account('a', 1), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0)))) != \
        Ledger(Account('a', 2), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0))))
    assert Ledger(Account('a', 1), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0)))) != \
        Ledger(Account('a', 1), Balance(datetime.date(2000, 1, 2), Quantity(Decimal(0))))
    assert Ledger

# Generated at 2022-06-24 01:03:15.987058
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries, build_journal_entry, compile_post_journal_entry_program
    from .accounts import Account, ReadAccounts, build_account
    from .commons.zeitgeist import DateRange
    from datetime import date
    import io
    import json
    import sys
    import uuid

    #: Standard stream for input
    stdin = sys.stdin
    #: Standard stream for output
    stdout = sys.stdout

    class JournalEntryCreated(Exception):
        def __init__(self, journal_id, journal_entry):
            self.journal_id = journal_id
            self.journal_entry = journal_entry

    def read_journal_entries(period: DateRange) -> JournalEntry:
        """
        Reads all journal entries within the given accounting period.
        """

# Generated at 2022-06-24 01:03:16.650327
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-24 01:03:26.766586
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Instance creation

# Generated at 2022-06-24 01:03:28.161266
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    pass

# Generated at 2022-06-24 01:03:31.958479
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Arrange
    le1 = LedgerEntry(None, None, None)
    le2 = LedgerEntry(None, None, None)

    # Act
    are_equal = le1.__eq__(le2)

    # Assert
    assert are_equal

# Generated at 2022-06-24 01:03:42.380812
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Mock some objects
    ledger0 = Ledger(
        account = Account(
            number = '000',
            title = 'Cash'
        ),
        initial = Balance(
            date = datetime.date(2020, 1, 1),
            value = Quantity(Decimal(0))
        )
    )
    posting_01 = Posting(
        account = Account(
            number = '000',
            title = 'Cash'
        ),
        amount = Amount(Decimal(100)),
        direction = 1
    )
    posting_02 = Posting(
        account = Account(
            number = '001',
            title = 'Accounts receivable'
        ),
        amount = Amount(Decimal(-100)),
        direction = 1
    )

# Generated at 2022-06-24 01:03:50.129904
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from decimal import Decimal

    from tempus.commons.zeitgeist import Date

    from tempus.journaling import JournalEntry, Posting

    le1 = LedgerEntry(None, Posting(JournalEntry(Date(2018, 11, 8), "", None, None, None), None, Decimal(0), None, None, False), Quantity(Decimal("0")))

    le2 = LedgerEntry(None, Posting(JournalEntry(Date(2018, 11, 8), "", None, None, None), None, Decimal(0), None, None, False), Quantity(Decimal("0")))

    assert (le1 == le2)


# Generated at 2022-06-24 01:04:01.311692
# Unit test for function build_general_ledger
def test_build_general_ledger():

    from ..commons.zeitgeist import DateRange

    from .journaling import Posting

    from .accounts import Account, AccountType, SubsidiaryAccountType

    from .fixtures import journal_entries

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    initial_balances = {
        Account(AccountType.Assets, SubsidiaryAccountType.Cash): Balance(period.since, Quantity(Decimal(100_000)))
    }

    general_ledger = build_general_ledger(period, journal_entries, initial_balances)

    assert general_ledger.period == period


# Generated at 2022-06-24 01:04:09.040198
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    @dataclass
    class _Posting(Posting[_T]):
        amount: Quantity
        date: datetime.date

    @dataclass
    class _Ledger(Ledger[_T]):
        initial: Balance

    posting = _Posting(amount=Quantity(1234), date=datetime.date(2018, 11, 15))
    ledger = _Ledger(initial=Balance(datetime.date(2018, 11, 15), Quantity(100)))
    entry = LedgerEntry(ledger, posting, Quantity(100 + 1234))
    return posting, ledger, entry



# Generated at 2022-06-24 01:04:18.809717
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():

    from .accounts import Account
    from .journaling import Txn, JournalEntry

    #: Accounting period.
    period = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2))

    #: Initial balances:
    initial = {
        Account("1111", "Goods"): Balance(
            datetime.date(2017, 1, 1), Quantity(Decimal("3.14159265"))
        ),
        Account("2222", "Cash"): Balance(
            datetime.date(2017, 1, 1), Quantity(Decimal("2.71828"))
        ),
    }

    #: Produces a general ledger:

# Generated at 2022-06-24 01:04:25.803319
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Journal, Posting
    from .units import Unit
    ledger = Ledger(1, Balance(1, 1))
    p = Posting(1, 1, 1)
    l = LedgerEntry(ledger, p, 1)
    assert l.ledger == ledger
    assert l.posting == p
    assert l.balance.value == 1
    assert l.date == 1
    assert l.description == 1
    assert l.amount.value == 1
    assert l.cntraccts == [1]
    assert l.is_debit == True
    assert l.is_credit == False
    assert l.debit.value == 1
    assert l.credit == None
    

# Generated at 2022-06-24 01:04:36.062415
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from datetime import date
    from decimal import Decimal
    from accounting.entities.journaling import JournalEntry
    from accounting.entities.accounts import Account, SubAccount

    _period: DateRange = DateRange(
        since=date(2018, 1, 1),
        until=date(2018, 1, 31)
    )
    _account: Account = Account(code=10, name="Account", description="Account description")
    _subaccount: SubAccount = SubAccount(account=_account, code=40, name="Subaccount", description="Subaccount description")
    _initial_balance: Balance = Balance(
        date=date(2018, 1, 1),
        value=Quantity(value=Decimal(0.00))
    )

# Generated at 2022-06-24 01:04:45.562570
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from accounting.application.models import Account
    from accounting.application.journaling import Posting
    from accounting.application.commons.numbers import Amount, Quantity
    from accounting.application.importing import Ledger
    from accounting.application.ledgers import LedgerEntry

    # Create an account object
    account = Account('TEST-L-C')
    # Create an amount object
    amount = Amount(1234)
    # Create a direction object
    direction = Direction.debit
    # Create a date object
    date = datetime.date(2018, 3, 1)
    # Create a journal entry object
    journal_entry = JournalEntry('Test Journal Entry', date)
    # Create a posting object
    posting = Posting(journal_entry, account, amount, direction)
    # Create a ledger object

# Generated at 2022-06-24 01:04:51.213008
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import Posting
    from .generic import Balance

    a1 = Account("a1", "A1")
    p1 = Posting(a1, Amount(Decimal(100)), Balance(datetime.datetime.now(), Quantity(Decimal(100))))
    l1 = Ledger(a1, Balance(datetime.datetime.now(), Quantity(Decimal(100))))
    le1 = LedgerEntry(l1, p1, Quantity(Decimal(200)))

    assert le1.date == p1.date
    assert le1.amount == p1.amount
    assert le1.balance == Quantity(Decimal(200))
    assert le1.is_debit
    assert le1.is_credit == False
    assert le1.debit == le1.amount
    assert le

# Generated at 2022-06-24 01:05:03.251014
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Unit test for method __repr__ of class LedgerEntry
    """
    # Given
    ledger = Ledger(Account(1), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0))))
    posting = Posting(ledger, datetime.date(2020, 8, 11), Amount(Decimal(10.0)))
    ledger_entry: LedgerEntry = LedgerEntry(ledger, posting, Quantity(Decimal(10.0)))
    expected_string = "<LedgerEntry: posting: <Posting: ledger: <Ledger: account: <Account: 1>, initial: <Balance: date: 2000-01-01, value: 0>, entries: []>, date: 2020-08-11, amount: $10.00>, balance: $10.00>"

    # When

# Generated at 2022-06-24 01:05:06.569806
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
  #create 2 GeneralLedger objects
  gl1 = GeneralLedger("period1", "ledgers1")
  gl2 = GeneralLedger("period2", "ledgers2")
  
  return gl1 == gl2

# Generated at 2022-06-24 01:05:13.645280
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounting import Account, Direction, Terminal
    from .journaling import JournalEntry, Posting
    import cmd

    # Begin definitions.
    # ==================
    period = DateRange(date.today(), date.today())

# Generated at 2022-06-24 01:05:17.139238
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances.__name__ == "ReadInitialBalances"
    assert ReadInitialBalances.__qualname__ == "ReadInitialBalances"


# Generated at 2022-06-24 01:05:20.298339
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    test_ReadInitialBalances.test_ReadInitialBalances.__doc__


# Generated at 2022-06-24 01:05:25.909130
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Test parameters
    period = DateRange(since=datetime.date(2020, 8, 1), until=datetime.date(2020, 8, 31))
    ledgerA = Ledger(Account(code="A", name="A"), Balance(date=datetime.date(2020, 8, 1), value=Decimal(500)))
    ledgerB = Ledger(Account(code="B", name="B"), Balance(date=datetime.date(2020, 8, 1), value=Decimal(500)))
    ledgers = {Account(code="A", name="A"): ledgerA, Account(code="B", name="B"): ledgerB}
    # Create an object for testing purposes
    testledger = GeneralLedger(period, ledgers)
    # Test
    assert testledger.period == period

# Generated at 2022-06-24 01:05:35.106540
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .journaling import Journal
    from .ledgering import read_open_book_initial_balances, OpenBook

    open_book = OpenBook()

    date1 = datetime.date(2019,5,5)
    date2 = datetime.date(2019,5,2)
    date3 = datetime.date(2019,5,3)
    date4 = datetime.date(2019,5,4)

    period = DateRange(date1, date1)

    period2 = DateRange(date2, date2)
    period3 = DateRange(date3, date3)
    period4 = DateRange(date4, date4)
    

# Generated at 2022-06-24 01:05:39.385019
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    """
    Unit test for constructor of class LedgerEntry
    """
    assert LedgerEntry(12345, 54321, 5622) == LedgerEntry(12345, 54321, 5622)


# Generated at 2022-06-24 01:05:49.556543
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Book, Journal, Posting
    from .accounts import AccountNum, Account

    book = Book('Test')
    journal = Journal(book.register('J1', 'Test journal 1'), ['Description'])

    ledger1 = Ledger(Account(AccountNum('100'), 'Account 1', 'description'), Balance('2020-01-01', 100))
    ledger2 = Ledger(Account(AccountNum('200'), 'Account 2', 'description'), Balance('2020-01-01', 200))

    #test 1
    posting = Posting(journal.register(1, 'Descr 1', '2020-01-01'), Account(AccountNum('100'), 'Account 1', 'description'), -100)

# Generated at 2022-06-24 01:05:50.312897
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert issubclass(ReadInitialBalances, Protocol)


# Generated at 2022-06-24 01:05:54.373138
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    l = Ledger(Account.from_number('01.00.01'), Balance(datetime.date(2018, 1, 1), Quantity(100)))
    e = LedgerEntry(l, Posting(Account.from_number('01.00.01'), datetime.date(2018, 1, 1), Amount(100), True), Quantity(100))
    assert repr(e) == 'LedgerEntry(ledger=Ledger(account=Account(number=01.00.01), initial=Balance(date=2018-01-01, value=100)), posting=Posting(account=Account(number=01.00.01), date=2018-01-01, amount=100, debit=True), balance=100)'


# Generated at 2022-06-24 01:05:56.597155
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert eval(repr(LedgerEntry(None, None, None))) == LedgerEntry(None, None, None)

# Generated at 2022-06-24 01:06:06.719175
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # given
    account1 = Account(iso_code_num='111', description='Test Account')
    account2 = Account(iso_code_num='222', description='Test Account2')

    # and
    balance1 = Balance(date=datetime.date(2019, 1, 1), value=Quantity(Decimal(1)))
    balance2 = Balance(date=datetime.date(2019, 1, 1), value=Quantity(Decimal(2)))

    # and
    ledger1 = Ledger(account=account1, initial=balance1)

# Generated at 2022-06-24 01:06:13.928390
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Setup
    import decimal
    import datetime
    entry = LedgerEntry(
        ledger = None,
        posting = Posting(date = datetime.date(2018,1,1), account = Account("000", "test"), description = "test", amount = Amount(decimal.Decimal("1.00")), direction = Posting.Direction.Debit),
        balance = 0
    )
    # Execute
    result = entry == entry
    # Assert
    assert result == True


# Generated at 2022-06-24 01:06:22.245093
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..testcase import FunctionalTestCase
    from .test_journaling import build_journal_program

    ## Define account ledger.
    @dataclass
    class AccountLedger:
        ## Account.
        account: Account

        ## Quantity.
        quantity: Quantity

    ## Define the environment:
    class Environment:
        def __init__(self, period: DateRange):
            self.period = period
            self.ledgers = []

        @property
        def previous_period(self) -> DateRange:
            return self.period.move(-1)

        def add(self, account: Account, quantity: Quantity) -> None:
            self.ledgers.append(AccountLedger(account, quantity))

    ## Build the program.
    journal_program = build_journal_program(Environment)
    program = compile_general_led

# Generated at 2022-06-24 01:06:32.904456
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger
    """
    from ..commons.zeitgeist import date
    #import sys
    #sys.path.append('../')
    #from commons.zeitgeist import date
    
    # The following is example data for testing the Ledger class method add

# Generated at 2022-06-24 01:06:33.848521
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-24 01:06:40.501721
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledger_entry1 = LedgerEntry(ledger=0, posting=0, balance=0)
    ledger_entry2 = LedgerEntry(ledger=0, posting=1, balance=0)
    ledger_entry3 = LedgerEntry(ledger=0, posting=0, balance=0)

    assert ledger_entry1.__eq__(ledger_entry3)
    assert not ledger_entry1.__eq__(ledger_entry2)

# Generated at 2022-06-24 01:06:49.956293
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..journaling.algebras import JournalEntry, load_journal_entries, Posting
    from ..accounting.algebras import Account, Balance, InitialBalance, load_initial_balances
    import datetime
    from decimal import Decimal
    # 1. Calling __call__ with a period, a journal and some initial balances:
    period = DateRange(datetime.date(2020, 8, 1), datetime.date(2020, 9, 1))

# Generated at 2022-06-24 01:06:51.757359
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Tests the __repr__ method of the LedgerEntry class.
    """
    pass


# Generated at 2022-06-24 01:07:01.365208
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.journal import Journal
    from ..journaling.interfaces import JournalReader
    from ..journaling.algebras import read_journal

    class JournalReaderMock(JournalReader[_T]):
        def __init__(self, *entries):
            self.entries = entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return self.entries

    # Build an example journal:
    journal = Journal([
        JournalEntry(datetime.date(2020, month, 1), "Example journal entry", [
            Posting(datetime.date(2020, month, 1), Account("Assets:Cash"), Direction.Debit, Amount(5), Quantity(5))
        ])
        for month in range(1, 4)
    ])

    # Build the program:


# Generated at 2022-06-24 01:07:07.070109
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Tests the __eq__ method of the LedgerEntry class.
    """
    # Test data:

# Generated at 2022-06-24 01:07:12.833429
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    ###############
    ### TESTING CONSTRUCTOR
    ###############
    period = DateRange(datetime.date(2000, 1, 1), datetime.date(2020, 1, 1))
    account_A = Account(0, "Spending A")
    account_B = Account(1, "Spending B")
    account_C = Account(2, "Income C")
    account_D = Account(3, "Income D")

    balance_A = Balance(period.since, Quantity(Decimal(1000.00)))
    balance_B = Balance(period.since, Quantity(Decimal(2000.00)))
    balance_C = Balance(period.since, Quantity(Decimal(3000.00)))
    balance_D = Balance(period.since, Quantity(Decimal(4000.00)))

    initial = InitialBalances

# Generated at 2022-06-24 01:07:23.773733
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    test_period = DateRange(datetime.date(2020, 1, 2), datetime.date(2020, 2, 3))
    test_ledgers = {Account("a2345"): Ledger(Account("a2345"), Balance(datetime.date(2020, 1, 3), Quantity(Decimal("-23.7"))))}

    test_general_ledger = GeneralLedger(test_period, test_ledgers)
    assert test_general_ledger.ledgers["a2345"].account.name == "a2345"
    assert test_general_ledger.ledgers["a2345"].initial.date == datetime.date(2020, 1, 3)
    assert test_general_ledger.ledgers["a2345"].initial.value == Quantity(Decimal("-23.7"))


# Generated at 2022-06-24 01:07:32.995332
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    xy_act1_date1 = datetime.date.today()
    xy_act1_date2 = datetime.date.today()
    xy_act1_date3 = datetime.date.today()
    period = DateRange(xy_act1_date1, xy_act1_date3)
    journal_entry1 = JournalEntry(xy_act1_date1, [Posting(Account("xy-act-1"), Amount(10)), Posting(Account("xy-act-2"), Amount(10))])
    journal_entry2 = JournalEntry(xy_act1_date2, [Posting(Account("xy-act-1"), Amount(10)), Posting(Account("xy-act-3"), Amount(10))])
    journal = [journal_entry1, journal_entry2]

# Generated at 2022-06-24 01:07:42.101498
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from decimal import Decimal
    from datetime import datetime

    ## A list used to store all the journal entries
    list_journal = []
    ## A dictionary used to store all the account and its initial balance
    init_bal = {}
    ## A dictionary used to store all the account and its final balance
    final_bal = {}
    ## A date range used to create a date range object that is used by other functions
    date_range = DateRange(
        since = datetime(2018, 1, 1, 6),
        until = datetime(2019, 1, 1, 12),
    )

    ## Create a JournalEntry object for the first journal entry