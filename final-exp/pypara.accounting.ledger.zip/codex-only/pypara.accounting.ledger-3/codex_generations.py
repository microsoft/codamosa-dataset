

# Generated at 2022-06-24 00:57:44.635876
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    now = datetime.date(2020, 9, 27)
    assert (ReadInitialBalances().__call__(DateRange(datetime.date(2020, 9, 1), datetime.date(2020, 11, 30)))) == ({})
    assert (
        ReadInitialBalances().__call__(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 11, 30)))
    ) == ({Account(str(now)): Balance(datetime.date(2020, 9, 27), Quantity(Decimal(0)))})


# Generated at 2022-06-24 00:57:45.508608
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-24 00:57:54.415217
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import Account
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict, Generic, Iterable, List, Optional, Protocol

    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    @dataclass
    class Ledger:
        account: Account
        initial: Balance
        entries: List[LedgerEntry] = field(default_factory=list, init=False)

        @property
        def _last_balance(self) -> Quantity:
            """
            Returns the last balance.
            """
            return self.initial.value#not necessary


# Generated at 2022-06-24 00:58:03.280496
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("1")
    initial = Balance(datetime.date(2018,12,28),Decimal(100))
    entries = []
    ledger = Ledger(account,initial)
    journ = JournalEntry(datetime.date(2018,12,28),"",[])
    entry = LedgerEntry(ledger,journ.postings[0],initial.value)
    ledger.entries.append(entry)
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == entries


# Generated at 2022-06-24 00:58:13.168644
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    import datetime
    from typing import Dict
    from ledger.accounts import Account, Asset
    from ledger.generic import Balance, LedgerEntry, Ledger
    from ledger.journaling import Direction, Journal, JournalEntry, Posting, Transaction
    from ledger.commons.numbers import Amount, Quantity

    account = Account("Test Account")
    ledger = Ledger(account, Balance(datetime.date.today(), Quantity(Decimal(0))))
    journal = Journal("Test Journal", [Transaction("Credit", Amount(Decimal(1)))])
    posting = Posting(
        datetime.date.today(),
        journal,
        account,
        Direction.CREDIT,
        Amount(Decimal(1)),
    )
    ledger_entry = LedgerEntry(ledger, posting, Quantity(Decimal(1)))
    assert ledger_entry.__

# Generated at 2022-06-24 00:58:16.008401
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass


# Generated at 2022-06-24 00:58:22.670026
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Create an account
    a = Account(account_number=1, description="Cash")
    ## Create a ledger
    l = Ledger(account=a, initial=Balance(date=datetime.date(2020,6,15), value=Quantity(Decimal(0))))
    ## Create a journal
    j = JournalEntry(date=datetime.date(2020,6,16), description="blabla")
    ## Create a posting
    p = Posting(amount=Amount(Decimal(5)), direction='DEBIT', account=a, journal=j)
    ## Add the posting to the ledger
    l.add(p)
    ## Assert the date of the posting is the date of the journal entry
    assert(l.entries[0].date == datetime.date(2020,6,16))
    ## Assert the description of the posting

# Generated at 2022-06-24 00:58:28.590082
# Unit test for constructor of class Ledger
def test_Ledger():
    currency = 'USD'
    account = Account(1, 'Account 1', currency)
    date = datetime.date.today()
    value = 100.0
    initial = Balance(date, Quantity(value, currency))
    lg = Ledger(account, initial)
    assert (account.id == 1)
    assert (account.name == 'Account 1')
    assert (lg.account.currency == currency)
    assert (lg.account == account)
    assert (lg.initial == initial)
    assert (lg.entries == [])



# Generated at 2022-06-24 00:58:38.172271
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from given_when_then import when, given
    import pytest

    @given("a ledger of accounts")
    def when_we_call_the_repr_method(context):
        import datetime
        from decimal import Decimal
        from ..commons.numbers import Amount, Quantity
        from ..commons.types import empty_on_undefined
        from ..commons.zeitgeist import DateRange
        from ..entities.accounts import Account
        from ..entities.journaling import JournalEntry, Posting
        from .journaling import Journal
        from ..repositories.accounts import Accounts
        from .accounts import AccountCategory
        from .generic import Balance
        from .ledgering import Ledger, LedgerEntry
        from . import ledgering

        #: Defines the period for which the balances are being queried.


# Generated at 2022-06-24 00:58:44.064196
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Test the attribute posting
    ledger = Ledger(Account("1234"), Balance(datetime.date.today(), Quantity(Decimal('0'))))

    posting = Posting("0001", datetime.date.today(), "1st posting", Account("1234"), Account("2345"),
                      Quantity(Decimal("0")), Quantity(Decimal("1000")), "Note")

    entry = LedgerEntry(ledger, posting, Quantity(Decimal("10000")))

    assert entry == entry  # True

    posting_new = Posting("0001", datetime.date.today(), "1st posting", Account("1234"), Account("2345"),
                          Quantity(Decimal("0")), Quantity(Decimal("1000")), "Note")

    entry_new = LedgerEntry(ledger, posting_new, Quantity(Decimal("10000")))

   

# Generated at 2022-06-24 00:58:50.878374
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("A", "A"): Balance(period.since, Amount(0))}

    assert compile_general_ledger_program(
        _ReadInitialBalancesImpl(), lambda period: [JournalEntry(1)]
    )(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1)))  # Test: 1



# Generated at 2022-06-24 00:58:57.097902
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # Setup
    t = GeneralLedger(DateRange(datetime.date(2020, 5, 1), datetime.date(2020, 7, 31)), {})
    t1 = GeneralLedger(DateRange(datetime.date(2020, 5, 1), datetime.date(2020, 7, 31)), {})
    t2 = GeneralLedger(DateRange(datetime.date(2020, 5, 2), datetime.date(2020, 7, 31)), {})

    # Test
    assert t is not t1
    assert t == t1
    assert t != t2



# Generated at 2022-06-24 00:59:03.781229
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from .algebras import ReadInitialBalances
    from .config import Config
    from .interfaces import Persistence
    from .persistence import PersistenceFactory

    # Access configuration for local storage:
    #config = Config(source="local")
    #config = PersistenceFactory.from_config(config)
    #read_initial_balances = config.get_read_initial_balances()
    reading = ReadInitialBalances()
    print (reading)

# Generated at 2022-06-24 00:59:14.545752
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    balance0 = Quantity(Decimal(4))
    balance1 = Quantity(Decimal(5))
    posting0 = Posting(datetime.date(2020, 5, 1), Account(code = "A"), Quantity(Decimal(2)))
    posting1 = Posting(datetime.date(2020, 5, 1), Account(code = "B"), Quantity(Decimal(3)))
    ledger0 = Ledger(Account(code = "A/B"), Balance(datetime.date(2020, 4, 25), Quantity(Decimal(0))))
    ledger1 = Ledger(Account(code = "A/C"), Balance(datetime.date(2020, 4, 25), Quantity(Decimal(0))))
    ledger_entry0 = LedgerEntry(ledger0, posting0, balance0)

# Generated at 2022-06-24 00:59:20.076342
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    d1 = datetime.date(2018,1,1)
    d2 = datetime.date(2018,12,31)
    assert GeneralLedger(
        DateRange(since=d1, until=d2),
        {
            Account('A1'): Ledger(
                Account('A1'),
                Balance(d1, Quantity(1))
            )
        }
    ).__repr__() == "GeneralLedger(DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2018, 12, 31)), {Account('A1'): Ledger(account=Account('A1'), initial=Balance(date=datetime.date(2018, 1, 1), value=Quantity(1)), entries=[])})"

# Generated at 2022-06-24 00:59:21.885248
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    print(GeneralLedger.__repr__)

# Generated at 2022-06-24 00:59:33.807146
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():

    from .journaling import Journal
    from .accounts import Account, ACCOUNT_TYPE

    # Create account
    acc_num = 101
    acc_val = 100
    acc_type = ACCOUNT_TYPE.ASSET
    account = Account(acc_num, acc_val, acc_type)
    # Create journal
    date = datetime.date.today()
    desc = "Test"
    entries = [(account, 150)]
    journal = Journal(date, desc, entries)
    # Create posting
    posting = Posting(account, journal, +150)
    # Create ledger
    initial = Balance(datetime.date.today(), Quantity(1000))
    ledger = Ledger(account, initial)
    # Create ledgerEntry
    ledgerEntry = LedgerEntry(ledger, posting, Quantity(1000))
    # Create account
    acc_

# Generated at 2022-06-24 00:59:34.392591
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    ...

# Generated at 2022-06-24 00:59:41.255106
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    ledgers = [Ledger(Account(1), Balance(datetime.date.today(), Quantity(Decimal(32)))),
               Ledger(Account(2), Balance(datetime.date.today(), Quantity(Decimal(33)))), ]
    period = DateRange(datetime.date.today(), datetime.date.today())
    gl = GeneralLedger(period, {ledgers[0].account: ledgers[0], ledgers[1].account: ledgers[1]})
    print(gl)

# Generated at 2022-06-24 00:59:51.954598
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class MyTypes:
        initial_balances: InitialBalances
        journal_entries: List[JournalEntry]
        expected_general_ledger: GeneralLedger


# Generated at 2022-06-24 01:00:00.200227
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.test.factories import account_factory, balance_factory, journal_entry_factory, posting_factory
    from ..commons.zeitgeist import date_range

    # 1. Create some terminal accounts:
    assets = account_factory("Assets", terminal=True)
    liabilities = account_factory("Liabilities", terminal=True)
    equity = account_factory("Equity", terminal=True)
    revenue = account_factory("Revenue", terminal=True)

    # 2. Create a list of test dates:
    dates = [datetime.date(2018, 6, i) for i in range(1, 31)] + [datetime.date(2018, 7, 1)]

    # 3. Create a list of test postings:

# Generated at 2022-06-24 01:00:11.066005
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Initialize buffer with initial balances:
    initial_balances = {
        "10100": Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))),
        "30200": Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))),
    }

    ## Initialize buffer with entries of the journal:

# Generated at 2022-06-24 01:00:19.231279
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():

    # Create an instance of GeneralLedger by passing period, dict, list
    g = GeneralLedger("1", {'a': [1, 2, 3]}, [1, 2, 3])

    # Check if g is an instance of GeneralLedger
    assert isinstance(g, GeneralLedger)

    # Check if g.period is the same value as passed
    assert g.period == "1"
    assert 'a' in g.ledgers
    assert g.ledgers == {'a': [1, 2, 3]}
    assert g.entries == [1, 2, 3]



# Generated at 2022-06-24 01:00:26.370125
# Unit test for method add of class Ledger
def test_Ledger_add():
    posting = Posting(Account("Test", "A", "A"), datetime.date(2020, 1, 1), Decimal("100"), Direction.debit)
    ledger = Ledger(Account("Test", "A", "A"), Balance(datetime.date(2020, 1, 1), Decimal("0")))
    ledger.add(posting)
    assert ledger.entries[0].balance == Decimal("100")

# Generated at 2022-06-24 01:00:32.843430
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from dataclasses import asdict

    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import build_journal_entry, build_posting

    # -- Test data:

# Generated at 2022-06-24 01:00:43.413938
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .journaling import Posting, JournalEntry
    from .accounts import Account
    from .generic import Balance

    period = DateRange(datetime.date(2017, 1, 1), datetime.date(2018, 12, 31))

    account_a = Account("A")
    account_b = Account("B")
    account_c = Account("C")
    account_d = Account("D")

    opening_balances = {
        account_c: Balance(datetime.date(2017, 1, 1), Quantity(Decimal("10.00")))
    }

    journal_a = JournalEntry("Opening balance.", datetime.date(2017, 1, 1))
    journal_a.post(account_c, Quantity(Decimal("10.00")))


# Generated at 2022-06-24 01:00:47.963553
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    class ReadInitialBalances_Mock():
        def __call__(self, period):
            return {}
    class ReadJournalEntries_Mock():
        def __call__(self, period):
            return []
    assert compile_general_ledger_program(ReadInitialBalances_Mock(), ReadJournalEntries_Mock())

# Generated at 2022-06-24 01:00:55.778477
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Given a general ledger program
    program = compile_general_ledger_program(lambda period: {}, lambda period: [])
    # When I call the program with given period
    result = program(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)))
    # Then it should return a general ledger for the given period
    assert isinstance(result, GeneralLedger)
    assert result.period == DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

# Generated at 2022-06-24 01:01:05.807822
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # test 1: no accounting period and no journal entries
    # test 1.1: Test when ledger entry is not equal to another ledger entry
    le1 = LedgerEntry(None, Posting(None, True, None, None, False), None)
    le2 = LedgerEntry(None, Posting(None, True, None, None, True), None)
    assert le1 != le2
    # test 1.2: Test when ledger entry is equal to another ledger entry
    le1 = LedgerEntry(None, Posting(None, True, None, None, True), None)
    le2 = LedgerEntry(None, Posting(None, True, None, None, True), None)
    assert le1 == le2
    # test 2: given accounting period and no journal entries
    # test 2.1: Test when ledger entry is not equal to another

# Generated at 2022-06-24 01:01:14.504056
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..books.journaling import Journal, Posting, ReadJournal
    from .policies import AccountPolicy, ReadAccountPolicy
    from .terminal import Terminal
    from .runbook import Runbook
    runbook = Runbook()
    j = Journal(datetime.date(2018, 1, 1), "test of ledgerentry")
    j.insert(Posting(runbook.current_assets.cash, 100, 'test'))
    ledEntry = LedgerEntry(runbook.current_assets, j.postings[0], 100)
    print(ledEntry)
    assert isinstance(ledEntry, LedgerEntry)
    assert ledEntry.account == runbook.current_assets
    assert ledEntry.posting == Posting(runbook.current_assets.cash, 100, 'test')
    assert ledEntry.balance == 100
    assert led

# Generated at 2022-06-24 01:01:17.475548
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
   a = LedgerEntry('a', 'b', 'c')
   b = LedgerEntry('a', 'b', 'c')
   assert a == b

# Generated at 2022-06-24 01:01:28.937892
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-24 01:01:31.901450
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ReadInitialBalances_Impl(Protocol):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    ReadInitialBalances_Impl()

# Generated at 2022-06-24 01:01:36.565433
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import date
    from .accounts import AccountID, AccountType
    from .commons import AccountBalance
    from .transactions import read_initial_balances

    initial_account = AccountID(1234, AccountType.TERMINAL)
    initial_balance = AccountBalance(initial_account, date(2020, 3), Quantity(Decimal(100)))
    initial_balances = {initial_account: initial_balance}

    assert read_initial_balances(date(2020, 4), initial_balances) == {initial_account: initial_balance}
    assert read_initial_balances(date(2020, 2), initial_balances) == {}

# Generated at 2022-06-24 01:01:46.337142
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print("\n", "*" * 100, end="\n\n")
    print("Unit test for function build_general_ledger", end="\n\n")
    print("*" * 100, "\n")
    # Define the general ledger accounting period
    period = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31))
    # Define the initial account balances
    initial_balance_cash = Balance(datetime.date(2017, 1 , 1), Quantity(Decimal(0.0)))
    initial_balance_prepayments = Balance(datetime.date(2017, 1 , 1), Quantity(Decimal(0.0)))
    initial_balance_interest_income = Balance(datetime.date(2017, 1 , 1), Quantity(Decimal(0.0)))
    initial_

# Generated at 2022-06-24 01:01:50.546399
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger = Ledger(Account("101"), Balance(datetime.date(2019, 8, 1), Quantity(Decimal(0))))
    ledger2 = Ledger(Account("101"), Balance(datetime.date(2019, 8, 1), Quantity(Decimal(0))))
    assert(ledger == ledger2)


# Generated at 2022-06-24 01:01:58.155136
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    """ This Unit test tests the constructor of class LedgerEntry.
    """
    #: Ledger the entry belongs to.
    ledger: "Ledger[_T]"
    ledger = Ledger(Account("Test"), Balance(datetime.date.today(), Decimal(1)))

    #: Posting of the ledger entry.
    posting: Posting[_T]
    posting = Posting(JournalEntry("Test", [Posting(Account("Test"), Amount("200.00"), "TEST")], datetime.date.today()), Account("Test"), Amount("200.00"), "TEST")

    #: Balance of the ledger entry.
    balance: Quantity
    balance = Quantity("400.00")

    # Test the constructor of class LedgerEntry
    test_object = LedgerEntry(ledger, posting, balance)


# Generated at 2022-06-24 01:02:08.606314
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange

    @dataclass
    class Journal:
        date: datetime.date
        description: str
        postings: List[str]

    @dataclass
    class Entry:
        account: str
        amount: Decimal
        debit: bool
        description: str

    @dataclass
    class Balance:
        value: Decimal


# Generated at 2022-06-24 01:02:13.829914
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    ledgr = Ledger(Account("4140"), Balance(datetime.date(2019, 12, 31), Quantity(Decimal(0))))
    assert ledgr.__repr__(), 'Ledger(account=Account(number="4140"), initial=Balance(date=datetime.date(2019, 12, 31), value=Quantity(0)))'

# Generated at 2022-06-24 01:02:14.818043
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert True



# Generated at 2022-06-24 01:02:24.979528
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Posting, Journal
    from .accounts import Account, AccountType
    from .currency import Currency
    from . import GenericPayable, GenericReceivable
    from datetime import date
    from decimal import Decimal
    # Create postings
    asset, revenue, expense, equity, liab = (Account(AccountType(i), Currency.USD) for i in range(5))
    posting1 = Posting(asset, date(2019, 1, 20), Journal('Test journal 1', [posting1]), 1, GenericPayable)
    posting2 = Posting(expense, date(2019, 1, 23), Journal('Test journal 2', [posting2]), Decimal('200.50'), 
        GenericPayable)

# Generated at 2022-06-24 01:02:37.291048
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from datetime import date
    from datetime import timedelta
    from .accounts import Account
    from .accounts import Accounting
    _accounting = Accounting(["Assets", "Liabilities", "Income", "Expenses"])
    _accounting.add_account("Assets", "Cash", Account.Type.ASSET)
    _period = DateRange(date.today(), date.today() + timedelta(days=365))
    _journal = [
        JournalEntry(date.today(), "Deposited cash", [
            Posting(_accounting.get_account("Assets", "Cash"), Account.Direction.DEBIT, Decimal(100))
        ])
    ]
    _initial_balances = {"Assets:Cash": Balance(date.today(), Decimal(100))}

# Generated at 2022-06-24 01:02:42.205641
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Unit test for method __repr__ of class LedgerEntry
    """
    account = Account('100100', '100100', 'Cash at sight')
    balance = Balance(datetime.date(2020, 1, 1), Quantity(500))
    journal = JournalEntry(datetime.date(2020, 1, 1), 'Journal entry', 'Journal entry')
    posting = Posting(account, journal, Direction.Debit, Quantity(500))
    ledger = Ledger(account, balance)
    entry = LedgerEntry(ledger, posting, Quantity(500))

# Generated at 2022-06-24 01:02:44.121724
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:02:52.817175
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Invokes the compiler and executes the program.
    """

    ## A journal entry for the period:
    @dataclass
    class DummyJournalEntry:
        """
        A mock journal entry.
        """

        date: datetime.date
        description: str
        postings: List[Posting]

    ## A  mock algebra for initial balances:
    def _read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        """
        Read initial balances as of the end of previous financial period.

        :param period: Accounting period.
        :return: A dictionary of :py:class:`Balance` instances.
        """

# Generated at 2022-06-24 01:02:59.860329
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..domain import journaling
    from ..commons.numbers import Quantity, Amount
    from ..commons.zeitgeist import Date
    from .accounts import Account

    L = Ledger(Account("1250"),Balance(Date(2017,1,1),Quantity(50)))

    E = LedgerEntry(L, Posting(journaling.Journal(Date(2017,1,1), "Lorem"), Account("1250"), Amount(100), journaling.Debit), Quantity(250))

    assert E.is_debit
    assert not E.is_credit
    assert E.debit == Amount(100)
    assert E.credit is None
    assert E.balance == Quantity(250)
    assert E.date == Date(2017,1,1)


# Generated at 2022-06-24 01:03:11.512900
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account('main account'), Balance(datetime.date(2020,6,1), Quantity(Decimal('0'))))
    entry = LedgerEntry(ledger, Posting(1, datetime.date(2020,6,1), Account('main account'), Amount(Decimal('1')), False, False), Quantity(Decimal('1')))

    ledger.add(Posting(1, datetime.date(2020,6,1), Account('main account'), Amount(Decimal('1')), False, False))

    assert ledger.entries[0].balance == entry.balance
    assert ledger.entries[0].date == entry.date
    assert ledger.entries[0].description == entry.description
    assert ledger.entries[0].amount == entry.amount

# Generated at 2022-06-24 01:03:20.635696
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    account=Account('Dummy account 1')
    initial=Balance(datetime.datetime.now(), Decimal(100))
    ledger=Ledger(account,initial)
    posting=Posting(account,Decimal(100),datetime.datetime.now(),'Dummy posting')
    entry=ledger.add(posting)
    ledgers_build={account:ledger}
    period=DateRange(datetime.datetime.now(),datetime.datetime.now())
    general_ledger=GeneralLedger(period,ledgers_build)
    assert period==general_ledger.period
    assert {account:ledger}==general_ledger.ledgers

# Generated at 2022-06-24 01:03:28.878502
# Unit test for constructor of class LedgerEntry

# Generated at 2022-06-24 01:03:38.934918
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from plyer import GeneralLedgerProgram
    from plyer.models.accounts import Account
    from plyer.models.journaling import Journal, Posting, Transaction
    from plyer.models.parties import Party


# Generated at 2022-06-24 01:03:44.116090
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account(name="Cash", num="1010", cats = ["Asset"], term=True)
    initial = Balance(date=datetime.date(2017, 1, 1), value=Quantity(Decimal(1000)))
    ledger = Ledger(account, initial)
    assert repr(ledger) == "Ledger(account=Account(name='Cash', num='1010', cats=['Asset'], term=True), initial=Balance(date=datetime.date(2017, 1, 1), value=Quantity(Decimal('1000'))))"


# Generated at 2022-06-24 01:03:51.270030
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Tests the method __repr__
    """

    # Builds the expected object

# Generated at 2022-06-24 01:04:02.465227
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .algebra import ReadInitialBalances, ReadJournalEntries
    from .journaling import ReadJournalEntries as ReadJournalEntries_journaling
    from .ledgers import ReadInitialBalances as ReadInitialBalances_ledger
    # Test cases
    # Input: read_initial_balances, read_journal_entries
    # Output: The function which consumes opening and closing dates and produces a general ledger
    ReadInitialBalances = ReadInitialBalances_ledger.db_read_initial_balances()
    ReadJournalEntries = ReadJournalEntries_journaling.db_read_journal_entries()
    GeneralLedgerProgram = compile_general_ledger_program(ReadInitialBalances, ReadJournalEntries)
    if (isinstance(GeneralLedgerProgram, function)):
        return 0
    else:
        return 1


# Generated at 2022-06-24 01:04:05.294874
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import Account
    a = Account()
    b = Balance(123)
    c = Ledger(a, b)
    print(c)

# Generated at 2022-06-24 01:04:06.900962
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    test1 = Ledger(None, None)
    assert repr(test1) == "Ledger(None, None)"

# Generated at 2022-06-24 01:04:17.473331
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .._test.fixtures import accounts
    from .._test.fixtures import balance
    from .accounts import AccountType

    read_InitialBalances = lambda p: {accounts.expenses.entertainment:balance.entertainment}

    period = DateRange(
        since = date.min,
        until = date.max
    )

    initial_balances = read_InitialBalances(period)

    assert isinstance(initial_balances, InitialBalances)
    assert isinstance(initial_balances, dict)

    assert accounts.expenses.entertainment in initial_balances
    assert isinstance(initial_balances[accounts.expenses.entertainment], Balance)
    assert accounts.expenses.entertainment.name == "Entertainment"
   

# Generated at 2022-06-24 01:04:18.364759
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ReadInitialBalances()


# Generated at 2022-06-24 01:04:26.066539
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.test_support.test_case import TestCase
    import pytest

    @dataclass
    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account(1): Balance(period.until, Quantity(1))}

    @dataclass
    class ReadJournalEntriesImpl(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return [JournalEntry(_T(), period.since, "Test"), JournalEntry(_T(), period.since, "Test")]

    ## We wrap everything in a test case class so that we have some context in the report:
    class _TestCase(TestCase):
        def setUp(self):
            self.read

# Generated at 2022-06-24 01:04:36.643681
# Unit test for constructor of class GeneralLedger

# Generated at 2022-06-24 01:04:45.825725
# Unit test for method __repr__ of class Ledger

# Generated at 2022-06-24 01:04:49.210700
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("4111020000", "description")
    initial = Balance(datetime.date.today(), Quantity(Decimal(3.14159)))
    ledger = Ledger(account, initial)
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == []


# Generated at 2022-06-24 01:05:01.341430
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from custom_test_helper_functions import _assert_class_and_instance_equality, _assert_class_not_instance_equality
    from .journaling import Journal
    from .commons.symbol import Symbol
    from .commons.zeitgeist import Date

    # setup:
    #  create journal 1
    symbol_1 = Symbol(1)
    description_1 = "test"
    date_1 = Date(2015, 1, 1)
    transactions_1 = []
    #  create journal 2
    symbol_2 = Symbol(2)
    description_2 = "test"
    date_2 = Date(2015, 1, 2)
    transactions_2 = []
    #  create journal 1
    journal_1 = Journal(symbol_1, description_1, date_1, transactions_1)
    journal_

# Generated at 2022-06-24 01:05:11.029983
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():

    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))

# Generated at 2022-06-24 01:05:18.030270
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Define a dummy algebra.
    class Algebra(ReadInitialBalances, ReadJournalEntries[None]):

        # Read initial balances.
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

        # Read journal entries.
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return []

    # Compile the program.
    program = compile_general_ledger_program(Algebra(), Algebra())

    # Run the program.
    result = program(
        DateRange(datetime.datetime(datetime.date.today().year, 1, 1, 0, 0, 0), datetime.datetime.today())
    )

    # Check the result type.

# Generated at 2022-06-24 01:05:28.495987
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-24 01:05:38.064280
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import Account
    from .generic import Balance
    account = Account.from_string("1000")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(0))
    ledger = Ledger(account, initial)
    assert repr(ledger) == "Ledger(account=Account(code=1000, description='1000'), initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(0)))}"
    assert str(ledger) == "Ledger(account=Account(code=1000, description='1000'), initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(0)))"

# Generated at 2022-06-24 01:05:42.031959
# Unit test for constructor of class Ledger
def test_Ledger():
    # test: create Ledger object
    test_account = Account('101', 'Cash', 'Accounts')
    test_initial = Balance('2019-10-01', 100)
    test_ledger = Ledger(test_account, test_initial)
    assert test_ledger.account == test_account
    assert test_ledger.initial == test_initial
    assert test_ledger.entries == []


# Generated at 2022-06-24 01:05:43.174184
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    pass
    # assert GeneralLedger([]) == []

# Generated at 2022-06-24 01:05:51.425560
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(1, "A", Account.Type.balance_sheet, Account.Subtype.current_assets)
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    entries = []
    ledger = Ledger(account, initial)
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == entries


# Generated at 2022-06-24 01:06:02.900505
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-24 01:06:08.755491
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    """
    Test that the constructor of class GeneralLedger works
    """
    period = DateRange(datetime.date(2000, 1, 1), datetime.date(2001, 1, 1))
    ledgers = {}
    new_general_ledger = GeneralLedger(period, ledgers)
    assert new_general_ledger.period == period
    assert new_general_ledger.ledgers == ledgers


# Generated at 2022-06-24 01:06:18.792916
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Unit test for method __repr__ of class LedgerEntry
    """
    # Setup
    ledger = Ledger(Account('0000'), Balance(datetime.date(2020, 1, 1), Decimal(0.0)))
    posting = Posting(ledger, datetime.date(2020, 1, 1), 'a', Decimal(100.0), 1)
    ledger_entry = LedgerEntry(ledger, posting)

    # Exercise
    value = str(ledger_entry)

    # Verify

# Generated at 2022-06-24 01:06:25.968461
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .setup import _setup_accounts, _setup_journal_entries
    from .journaling import setup_journal_entries

# Generated at 2022-06-24 01:06:30.206177
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Arrange
    account = Account("A")
    ledger = Ledger(account, Balance(datetime.date(2021, 1, 1), Quantity(Decimal(1))))
    expected = "Ledger(account=A, initial=Balance(date=2021-01-01, value=Quantity(1)))";
    # Act
    actual = repr(ledger)
    # Assert
    assert actual == expected



# Generated at 2022-06-24 01:06:33.265999
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    pass

# Generated at 2022-06-24 01:06:44.793889
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from ..commons.access_layer import describe
    from .access_layer import ReadJournalEntries

    from .journaling import ReadJournalingEngagement

    from .accounts import Account, AccountType, ReadAccounts

    from .generic import Balance, BalanceSheet, Book, BookKeeping

    from .journaling import JournalEntry, Posting, ReadJournalEntries

    from .accounts import Account, AccountType, ReadAccounts

    from .generic import Balance

    from . import trial_balance as tb

    from .commons.access_layer import describe

    #
    #
    #
    def read_accounts(book: BookKeeping) -> ReadAccounts:
        #
        # Read accounts (TrialBalance)
        return tb.read_accounts(book)

    #
    #
    #

# Generated at 2022-06-24 01:06:45.402223
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__(): ...



# Generated at 2022-06-24 01:06:50.710730
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date.today(), datetime.date.today())
    journal = [JournalEntry(datetime.date.today(), Decimal(100), "Description")]
    initial = {Account("1"): Balance(datetime.date.today(), Decimal(200))}
    GeneralLedger(period, journal, initial)

# Generated at 2022-06-24 01:07:00.608120
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    gl1 = GeneralLedger(DateRange(datetime.date(2005, 1, 1), datetime.date(2005, 3, 31)), {})
    gl2 = GeneralLedger(DateRange(datetime.date(2005, 1, 1), datetime.date(2005, 3, 31)), {"a":Ledger(1, 2)})
    gl3 = GeneralLedger(DateRange(datetime.date(2005, 1, 1), datetime.date(2005, 3, 31)), {"b":Ledger(3, 4)})
    gl4 = GeneralLedger(DateRange(datetime.date(2005, 1, 1), datetime.date(2005, 3, 31)), {"a":Ledger(1, 4)})

    assert gl1 == gl1
    assert gl2 == gl2
    assert gl3 == gl3
    assert gl4

# Generated at 2022-06-24 01:07:02.098171
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert hasattr(ReadInitialBalances, "__call__")


# Generated at 2022-06-24 01:07:13.515142
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test method __call__ of class GeneralLedgerProgram.
    """

    ## Arrange

    ## Create initial balances:
    initial = {
        Account.incoming_taxes: Balance(date=datetime.date(2019, 1, 1), value=Quantity(Decimal(0))),
        Account.cost_of_sales: Balance(date=datetime.date(2019, 1, 1), value=Quantity(Decimal(0))),
    }


# Generated at 2022-06-24 01:07:24.533966
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from _test_commons import to_absolute_path
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from ..journaling.accounts import Account, AccountType
    from ..journaling.algebras import read_journal_entries, ReadJournalEntries
    from .accounts import Account, ReadInitialBalances, TerminalAccount, Balance
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Prepare test data.
    ## Account types:
    asset = AccountType("001", "Assets")
    liability = AccountType("002", "Liabilities")
    equity = AccountType("003", "Equity")
    ## Accounts:

# Generated at 2022-06-24 01:07:27.407596
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Get initial balances as of the end of previous financial period:
    initial_balances = read_initial_balances(period)

    # Read journal entries and post each of them:
    journal_entries = read_journal_entries(period)

    # Build the general ledger and return:
    build_general_ledger(period, journal_entries, initial_balances)



# Generated at 2022-06-24 01:07:27.947152
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:07:36.164314
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account()
    initial = Balance(datetime.date(2020, 7, 1), Decimal(0))
    entries = [LedgerEntry(None, Posting(account, datetime.date(2020, 7, 1), Decimal(10)), Decimal(10))]

    ledger = Ledger(account, initial, entries)

# Generated at 2022-06-24 01:07:43.455638
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    journal = JournalEntry(postings=[
        Posting(account=Account(code="123", name="Account 1", kind="B"), amount=Amount(currency="USD", value=Decimal(100)), direction="CREDIT")
    ])
    initial = Balance(date=datetime.date.today(), value=Decimal(100))
    ledger = Ledger(account=Account(code="123", name="Account 1", kind="B"), initial=initial)
    posting = Posting(account=Account(code="123", name="Account 1", kind="B"), amount=Amount(currency="USD", value=Decimal(100)), direction="CREDIT")
    ledger_entry = LedgerEntry(ledger, posting, posting.amount) 

    assert ledger_entry.date == posting.date
    assert ledger_entry.description == posting.journal.description
    assert ledger_