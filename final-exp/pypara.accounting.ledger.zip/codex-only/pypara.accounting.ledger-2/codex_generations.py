

# Generated at 2022-06-24 00:57:43.126171
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    def assert_method_sut(read_initial_balances: ReadInitialBalances):
        period = DateRange(datetime.date(2019, 7, 1), datetime.date(2019, 12, 31))
        assert read_initial_balances(period) == {}
    return assert_method_sut


# Generated at 2022-06-24 00:57:53.795116
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .journaling import JournalEntries, Postings, Journals, Journal

    account1 = Account(code='1110', balance_side=Balance.Side.DEBIT)
    account2 = Account(code='1120', balance_side=Balance.Side.CREDIT)

    posting1 = Posting(
        date=datetime.date.today(),
        account=account1,
        amount=Amount(Decimal(1000)),
        direction=Posting.Direction.CREDIT)

    posting2 = Posting(
        date=datetime.date.today(),
        account=account2,
        amount=Amount(Decimal(500)),
        direction=Posting.Direction.CREDIT)


# Generated at 2022-06-24 00:58:00.313398
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .journaling import User, PostingDirection, Journal, Posting

    account = Account(
        '789',
        'accident',
        'accident account',
        'An account to keep track of all financial transactions related to accident',
        'account',
        Account.Type.TERMINAL,
    )
    posting = Posting('p1', DateRange(datetime.date(2018, 3, 1)), Journal('j1', '', User('user1')), account, 
                      PostingDirection.DEBIT, Amount(1000, Currency.USD), 'a1', 'p1')
    ledger = Ledger(account, Balance(datetime.date(2017, 1, 1), Quantity(Decimal(0))))
    ledger_entry = LedgerEntry(ledger, posting, Quantity(0))

    assert ledger_entry.__repr

# Generated at 2022-06-24 00:58:11.262327
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
        import dataclasses
        import dateutil
        from dataclasses import dataclass
        from datetime import date, datetime
        import math
        import pytest
        from ..commons.numbers import Amount

        ## Define useful types.
        @dataclass
        class Program:
            initial_balances: Dict[str, Dict[str, Amount]]
            journal_entries: Dict[str, Dict[str, Amount]]

            def __call__(self, period:str) -> Dict[str, Dict[str, Amount]]:
                if period == "initial_balances":
                    return {account: {tag: Amount(quantity) for tag, quantity in tags.items()} for account, tags in self.initial_balances.items()}
                elif period == "journal_entries":
                    return

# Generated at 2022-06-24 00:58:22.237891
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    A = 10
    B = 15
    C = 20
    D = 25
    E = 30
    ledger = LedgerEntry('ledger', 'posting', 'balance')
    account = 'account'
    initial = Balance('date', 'value')
    posting1 = Posting(account=account, date=A, journal=None, amount=Amount(B))
    posting2 = Posting(account=account, date=C, journal=None, amount=Amount(D))
    posting3 = Posting(account=account, date=E, journal=None, amount=Amount(A))
    posting4 = Posting(account=account, date=E, journal=None, amount=Amount(A))

    ledger1 = Ledger(account=account, initial=initial)
    ledger1.add(posting1)

# Generated at 2022-06-24 00:58:32.688777
# Unit test for method add of class Ledger
def test_Ledger_add():
    #Act
    account = Account(0, 'Test Account', True)
    account_1 = Account(1, 'Cont Account 1', True)
    account_2 = Account(2, 'Cont. Account 2', True)
    account_3 = Account(3, 'Cont. Account 3', True)
    initial_balances = {}
    initial_balances[account] = Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0.0)))
    initial_balances[account_1] = Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0.0)))
    initial_balances[account_2] = Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0.0)))

# Generated at 2022-06-24 00:58:38.545416
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Declare a ledger that contains an account
    account = Account(1, '1110', 'Cash')

# Generated at 2022-06-24 00:58:45.253069
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account=Account('3010','dummy-account',1)
    first=Ledger(account,Balance(datetime.date(year=2018,month=12,day=1),Decimal(0)))

    second = Ledger(account,Balance(datetime.date(year=2018,month=12,day=1),Decimal(0)))

    assert first==second


# Generated at 2022-06-24 00:58:53.154514
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Unit test for method __repr__ of class LedgerEntry.
    """
    from datetime import date
    from decimal import Decimal
    from pytest import raises
    from re import compile as regex

    ## Package instance to test method __repr__:
    d = date(2016, 10, 29)
    l = Ledger(Account('1110'), Balance(d, Quantity(Decimal('10'))))
    l.add(Posting(d, Account('1110'), Decimal('-12'), True))
    l.add(Posting(d, Account('1110'), Decimal('-12'), True))
    l.add(Posting(d, Account('1110'), Decimal('-12'), True))

    ## Execute method __repr__ of  ledger and check result:

# Generated at 2022-06-24 00:58:54.054867
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass


# Generated at 2022-06-24 00:59:01.559339
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    accounts = {
        Account("Cash"),
        Account("Petty Cash"),
        Account("Bill Receivables"),
    }
    period = DateRange("2017-01-01", "2017-01-31")
    journal = [
        JournalEntry("2017-01-01", "Cash", [
            Posting("Cash", 100, "Dr"),
            Posting("Petty Cash", 100, "Cr")
        ]),
        JournalEntry("2017-01-01", "Bill Receivables", [
            Posting("Cash", 100, "Cr"),
            Posting("Bill Receivables", 100, "Dr")
        ])
    ]


# Generated at 2022-06-24 00:59:09.066716
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Initilize account ledger
    account = Account(account_number=1,
                        account_name='Cash Account',
                        currency='CNY',
                        account_category='Cash Assets',
                        terminal_account=False)
    
    balance = Balance(date=datetime.date.today(), value=1)
    
    ledger = Ledger[int](account, balance)
    ledger.add(Posting(date=datetime.date.today(), journal=JournalEntry(description='Lend the cash',
                        postings=[Posting(account=account, amount=1, direction=Debit)])))
    ledgers = {account: ledger}
    
    # Initialize account ledger
    period = DateRange(since=datetime.date.today() - datetime.timedelta(days=10),
                       until=datetime.date.today())
   

# Generated at 2022-06-24 00:59:16.693586
# Unit test for method add of class Ledger
def test_Ledger_add():
    journalEntry = JournalEntry("Test Journal entry","Test Journal")
    postingMode = journalEntry.post("Test account",Decimal("1000.00"))
    posting = postingMode.debit()
    assert isinstance(posting, Posting)
    assert repr(posting)=="Posting(date=datetime.date(2020, 1, 21), description='Test Journal entry', account=Account(code='Test account', description='Test account'), amount=Decimal('1000.00'), direction=Debit)"
    balance= Balance("2020-01-21",Quantity(Decimal("0")))
    ledger= Ledger("Test account",balance)
    assert isinstance(ledger, Ledger)

# Generated at 2022-06-24 00:59:23.211749
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class FakeReadInitialBalances(ReadInitialBalances):
        """
        This class implements ReadInitialBalances and provides a fake __call__ method.
        """
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    fake_read_initial_balances = FakeReadInitialBalances()
    assert isinstance(fake_read_initial_balances, ReadInitialBalances) == True
    assert callable(fake_read_initial_balances) == True


# Generated at 2022-06-24 00:59:34.921401
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .tests.mocks.accounts import read_initial_balances, read_journal_entries

    pgm = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    gl = pgm(DateRange.since(2000, 1, 1).until(2000, 2, 1))

    assert gl.ledgers[101].entries[0].balance == Decimal(100)  # Opening balance.
    assert gl.ledgers[101].entries[1].balance == Decimal(200)  # Transaction: Cash -> Main Account.
    assert gl.ledgers[101].entries[2].balance == Decimal(100)  # Transaction: Main Account -> Asset.
    assert len(gl.ledgers[101].entries) == 3

# Generated at 2022-06-24 00:59:35.836440
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 00:59:37.454945
# Unit test for constructor of class Ledger
def test_Ledger():
    '''
    Test constructor of Ledger
    '''
    assert Ledger(Account(1), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))



# Generated at 2022-06-24 00:59:41.896709
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Given
    subject = Ledger(Account(1, "name"), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0))))
    # When
    actual = f"{subject}"
    # Then
    assert actual == "Ledger(account=Account(id=1, name='name'), initial=Balance(date=datetime.date(2000, 1, 1), value=Decimal('0')))"

# Generated at 2022-06-24 00:59:42.997178
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert GeneralLedgerProgram.__call__ is GeneralLedgerProgram.__call__

# Generated at 2022-06-24 00:59:52.713704
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # arrange
    period = DateRange(datetime.date(2020, 9, 16), datetime.date(2020, 9, 16))

# Generated at 2022-06-24 00:59:58.999459
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    read_initial_balances = read_journal_entries = not_implemented
    p = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert p(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))) is not None

# Generated at 2022-06-24 01:00:07.795472
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    def glob():
        x = {'sys': {'modules': {}}}
        x['sys']['modules']['__main__'] = x
        return x
    import sys
    glob = glob()
    sys.modules.clear()
    sys.modules.update(glob['sys']['modules'])
    class _mock_ReadInitialBalances:
        def __call__(self, period):
            return {Account(1): Balance(datetime.date(2020, 1, 1), Decimal(100))}
    glob['_mock_ReadInitialBalances'] = _mock_ReadInitialBalances

# Generated at 2022-06-24 01:00:15.143175
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Define a mock journal:
    class MockJournalEntry:
        def __init__(self, date: datetime.date, description: str, accounts: Dict[Account, Amount]):
            self.date = date
            self.description = description
            self.postings = [Posting(date, a, d, Account("USD")) for a, d in accounts.items()]


# Generated at 2022-06-24 01:00:25.607121
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # A generic type variable
    _X = TypeVar("_X")

    # An implementation of the algebra which reads journal entries.
    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_X]]:
        # A generic type variable
        _T = TypeVar("_T")

        # A journal entry model.
        @dataclass
        class _JournalEntry(_T):
            #: Unique journal entry identifier.
            id: int

            #: Description of the journal entry.
            description: str

            #: Date of the journal entry.
            date: datetime.date

            #: The journal entry postings.
            postings: List[Posting[_T]] = field(default_factory=list)


# Generated at 2022-06-24 01:00:31.612736
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..fundamentals.journaling import Journal
    from ..identity import AccountId
    from ..identity.numbers import AccountNumber

    from .accounts import AccountCategory, AccountClass, AccountType
    
    dr_account = Account(AccountId(1), AccountNumber(100), "Dr. Account", AccountCategory(AccountClass.Assets), AccountType.General, None)
    cr_account = Account(AccountId(2), AccountNumber(200), "Cr. Account", AccountCategory(AccountClass.Assets), AccountType.General, None)
    
    initial_balances = {dr_account: Balance(since = datetime.date(2019, 5, 1), value = Decimal(10))}
    

# Generated at 2022-06-24 01:00:43.103522
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from .accounts import Account, AccountType, AssetAccount
    from .journaling import Journal, Posting, AccountRef, Currency, LedgerRef
    from .ledgers import Ledger, Balance
    from .reporting import VolumeSpecification

    assert GeneralLedger(
        DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 3, 1)),
        {},
    ) == GeneralLedger(
        DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 3, 1)),
        {},
    )

# Generated at 2022-06-24 01:00:52.845781
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account

    class MockAlgebra:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account(1): Balance(period.since, Quantity(10)), Account(2): Balance(period.since, Quantity(20))}

    algebra = MockAlgebra()

    balance = algebra(DateRange(datetime.date(2020,1,1), datetime.date(2020,12,31)))

    assert balance == {Account(1): Balance(datetime.date(2020,1,1), Quantity(10)), Account(2): Balance(datetime.date(2020,1,1), Quantity(20))}


# Generated at 2022-06-24 01:01:04.093937
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    class TestLedgerEntry(LedgerEntry):
        # Unit test for method __init__ of class LedgerEntry
        def test__init__():
            ledger = Ledger(account=Account("derivatives"), initial=Balance(Quantity(1000.50)))
            posting = Posting(journal=JournalEntry(description="journal entries", postings=[], date=datetime.date(2020, 8, 6), id=1), direction=Direction. debt, amount=Quantity(500.50), account=Account("equity"))
            le = TestLedgerEntry(ledger=ledger, posting=posting, balance=Quantity(500.50))
            assert le.__init__() == le
        # Unit test for method __repr__ of class LedgerEntry

# Generated at 2022-06-24 01:01:14.295560
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Define some dummy data:
    date_range = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define an algebra implementation which returns dummy initial balances:
    def read_initial_balances(_) -> InitialBalances:
        return {
            "1-0000": Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
            "1-1001": Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
        }

    ## Define an algebra implementation which returns dummy journal entries:

# Generated at 2022-06-24 01:01:17.182737
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Ledger(Account("an account"), Balance(datetime.date(2020, 7, 1), Quantity("1")))
    b = Ledger(Account("an account"), Balance(datetime.date(2020, 7, 1), Quantity("1")))
    assert a == b


# Generated at 2022-06-24 01:01:23.167560
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("450-00001-0001", "Work in Progress", True, True)
    balance = Balance(datetime.date(2019, 6, 30), Quantity(Decimal(100000)))
    ledger = Ledger(account, balance)
    assert ledger.account == account
    assert ledger.initial == balance
    assert ledger.entries == []


# Generated at 2022-06-24 01:01:33.647582
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    import pytest
    from .accounts import Account
    from .journaling import Journal, JournalEntry, Posting
    from .accounting import Ledger, build_general_ledger, compile_general_ledger_program
    from typing import List
    from datetime import date
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    # dummy Impl of ReadJournalEntries

    class ReadJournalEntriesImpl:
        def __init__(self, journals:List[JournalEntry]):
            self.journals = journals

        def __call__(self, period: DateRange) -> List[JournalEntry]:
            return self.journals

    # dummy Impl of ReadInitialBalances


# Generated at 2022-06-24 01:01:37.883809
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry1 = LedgerEntry(ledger=1, posting=1, balance=1)
    entry2 = LedgerEntry(ledger=1, posting=1, balance=1)
    assert entry1 == entry2, "ledger entries not equal"


# Generated at 2022-06-24 01:01:43.788064
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test.
    """
    import pytest
    from .ledgers import read_initial_balances, read_journal_entries, read_ledgers
    from .journaling import assemble_journal_entries, post_journal_entries
    from .accounts import AccountScheme
    from . import journal_entries
    from . import accounts

    ## Build account scheme:
    account_scheme = AccountScheme(accounts.accounts)

    ## Build journal entries:
    journal = list(journal_entries.JOURNAL_ENTRIES)

    ## Build general ledger and assigned ledger:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-24 01:01:45.072084
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:01:54.535565
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    #Create objects
    account1 = Account("Acc1", "Account1", None, True)
    account2 = Account("Acc2", "Account2", None, True)
    period = DateRange(datetime.date(2018,1,1), datetime.date(2018,1,31))
    entry1 = LedgerEntry(account1, Posting(account1, Quantity(1, "DKK"), ""), Quantity(1))
    entry2 = LedgerEntry(account2, Posting(account2, Quantity(1, "DKK"), ""), Quantity(1))
    ledger1 = Ledger(account1, Balance(datetime.date(2018,1,1), Quantity(1, "DKK")), [entry1])

# Generated at 2022-06-24 01:01:55.842380
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert LedgerEntry(None, None, None) == LedgerEntry(None, None, None)



# Generated at 2022-06-24 01:01:59.776282
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}
    opening_balances = ReadInitialBalancesImpl().__call__(" ".split(" "))
    assert opening_balances == {}


# Generated at 2022-06-24 01:02:00.288679
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass

# Generated at 2022-06-24 01:02:01.326971
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # Define a GeneralLedger object
    pass


# Generated at 2022-06-24 01:02:04.035796
# Unit test for constructor of class Ledger
def test_Ledger():
  account = Account("001","Cash")
  balance = Balance("2020-01-01",100)
  ledger = Ledger(account,balance)
  assert len(ledger.entries) == 0
  assert ledger.initial == balance


# Generated at 2022-06-24 01:02:05.669781
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    GeneralLedger


# Generated at 2022-06-24 01:02:06.951133
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test method __call__ of class GeneralLedgerProgram.
    """
    return

# Generated at 2022-06-24 01:02:18.229732
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    journal_entry1 = JournalEntry("dépenses avec obligation de reprise", datetime.date(2017, 1, 8), Decimal(15000),
                                  "dépenses de représentation")
    p1 = journal_entry1.post(account=61200, direction="debit")
    p2 = journal_entry1.post(account=31200, direction='credit')
    assert p1.journal.postings == [p1, p2]
    assert p2.journal.postings == [p1, p2]

    journal_entry2 = JournalEntry("dépenses avec obligation de reprise", datetime.date(2017, 1, 8), Decimal(15000),
                                  "dépenses de représentation")

# Generated at 2022-06-24 01:02:24.910812
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .accounting import Posting1, JournalEntry1, postings
    le = LedgerEntry(1,2,3)
    le2 = LedgerEntry(1,2,3)
    le3 = LedgerEntry(1,2,3)
    assert (le == le) == True
    assert (le == le2) == True
    assert (le == le3) == True
    assert (le == None) == False
    assert (le == 1) == False
    assert (le == '1') == False
    assert (le == [le]) == False


# Generated at 2022-06-24 01:02:36.961256
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import make_date

    @dataclass
    class StubReadInitialBalances(ReadInitialBalances):
        value: Dict[Account, Balance]

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.value

    test_input: DateRange = DateRange(date1=datetime.date(2020, 1, 1), date2=datetime.date(2020, 2, 1))
    test_output: InitialBalances = {
        Account("123"): Balance(make_date(2020, 1, 1), Quantity(Decimal(1)))
    }

    stub: ReadInitialBalances = StubReadInitialBalances(test_output)
    assert stub(test_input) is test_output

# Generated at 2022-06-24 01:02:47.676037
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():

    from .journaling import Journal
    from .nomenclature import Direction, Transaction

    direction = Direction("DR")
    journal = Journal("J", "", date=datetime.datetime.now(), entries=[Transaction("T", "", direction, Amount("23.45"))])
    posting = Posting("A", journal, direction, Amount("12.34"))
    balance = Quantity("23.45")
    ledger = Ledger("A", Balance("", Quantity("0")))
    entry = LedgerEntry(ledger, posting, balance)


# Generated at 2022-06-24 01:02:57.883352
# Unit test for method __repr__ of class LedgerEntry

# Generated at 2022-06-24 01:03:09.188849
# Unit test for constructor of class GeneralLedger

# Generated at 2022-06-24 01:03:16.456354
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    """
    Test compile_general_ledger_program function
    """

    ## Build the general ledger:

# Generated at 2022-06-24 01:03:25.510140
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # setup
    period = DateRange(since=datetime.date.min, until=datetime.date.max)
    ledgers = {
        Account(no=10000, desc="Assets"),
        Account(no=10100, desc="Assets > Cash"),
    }

    # when
    generalLedger = GeneralLedger(period, ledgers)

    # then
    assert str(generalLedger) == "GeneralLedger(period=Period{since=0001-01-01, until=9999-12-31}, ledgers={Account(no=10000, desc='Assets'), Account(no=10100, desc='Assets > Cash')})"


# Generated at 2022-06-24 01:03:28.867859
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class _TestJournalEntry(JournalEntry):
        pass

    def create_general_ledger(period: DateRange) -> GeneralLedger[_TestJournalEntry]:
        return GeneralLedger(period, [])

    program = compile_general_ledger_program(lambda period: {}, lambda period: [])
    assert program(DateRange()) == create_general_ledger(DateRange())

# Generated at 2022-06-24 01:03:38.934637
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Create a mock of class ReadInitialBalances, which returns a dictionary of initial balances.
    import unittest.mock as mock
    read_initial_balances = mock.Mock(spec_set=ReadInitialBalances)
    read_initial_balances.return_value = {
        "assets:cash": Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))),
        "expenses:rent": Balance(datetime.date(2020, 1, 1), Quantity(100)),
        "revenue:interest": Balance(datetime.date(2020, 1, 1), Quantity(0)),
    }

    # Create a mock of class ReadJournalEntries, which returns a list of journal entries.
    read_journal_entries = mock.Mock(spec_set=ReadJournalEntries)
    read_journal_

# Generated at 2022-06-24 01:03:46.584932
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import AccountGroup, Account
    from .journaling import JournalEntry, Posting
    from .casts import DummyCast

    a = Account("a", "A", AccountGroup.ASSET, [])
    b = Account("b", "B", AccountGroup.ASSET, [])
    p = Posting(a, 100, True)
    je = JournalEntry(datetime.datetime(2019, 1, 1), "Test", [p])
    l = Ledger(a, Balance(datetime.date(2019, 1, 1), 0))
    le = LedgerEntry(l, p, 100)
    assert str(le) == f"<LedgerEntry(account={a}, date=2019-01-01, amount=<Quantity(value=100)>, balance=<Quantity(value=100)>)"
    le.posting

# Generated at 2022-06-24 01:03:58.128889
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import build_journal

    initial_balances = {
        Account("10101000", "Bank Account"): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(150000))),
        Account("10201000", "Equity"): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0))),
    }


# Generated at 2022-06-24 01:04:08.591540
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from datetime import date
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .transactions import Transaction

    ## Prepare the start and end dates for the period for which the general ledger is going to be generated.
    psd = date(2018, 1, 1)
    ped = date(2018, 12, 31)

    ## Prepare the opening and closing balances for the individual accounts.
    initial_balances = {Account.get_named("A"), Account.get_named("E"), Account.get_named("I")}

    ## Prepare the journal entries, i.e. the transactions, which are to appear on the general ledger.
    transaction_a = Transaction("Transaction A", date(2018, 1, 1))
    transaction_a.add_posting(Posting(Account.get_named("A"), Amount(100)))


# Generated at 2022-06-24 01:04:18.596782
# Unit test for method __repr__ of class LedgerEntry

# Generated at 2022-06-24 01:04:21.892243
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ConcreteReadInitialBalances(ReadInitialBalances):
        """
        Concrete implementation of ReadInitialBalances.
        """

        def __call__(self, period):
            pass

    _ = ConcreteReadInitialBalances

# Generated at 2022-06-24 01:04:26.216351
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Set up the objects for test
    account = Account('account')
    ledger = Ledger(account, Balance(datetime.date(2020,3,31),Quantity(Decimal(0))))
    posting = Posting(datetime.date(2020,2,1), account, Decimal(1000), True, 'test', 'Test posting')
    ledger_entry = LedgerEntry(ledger, posting, Quantity(Decimal(1000)))
    other_ledger_entry = LedgerEntry(ledger, posting, Quantity(Decimal(1000)))

    # Test the method
    assert ledger_entry == other_ledger_entry

# Generated at 2022-06-24 01:04:30.758146
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from ..commons.zeitgeist import now

    from .accounts import Asset, Expense, Equity, Liability

    from .generic import Balance
    ## Input data
    period = DateRange.closed(now().replace(year = 2019, month = 1, day = 1), now().replace(year = 2019, month = 12, day = 12))

# Generated at 2022-06-24 01:04:34.173393
# Unit test for constructor of class Ledger
def test_Ledger():
    account = "01.101"
    balance = Quantity(Decimal(0))
    ledgers = Ledger(account, balance)
    assert "01.101" == ledgers.account and Quantity(Decimal(0)) == ledgers.initial

# Generated at 2022-06-24 01:04:42.653536
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ledger.accounts import Account
    from ledger.journaling import Posting

    # Creates test data
    journal_entry = JournalEntry(
        date=datetime.date(year=2020, month=3, day=1),
        description="Consulting Services",
        postings=[
            Posting(account=Account("Assets", "Cash", "Operating"), amount=1000, direction=Credit),
            Posting(account=Account("Income", "Revenue", "Consulting"), amount=1000, direction=Debit),
        ],
    )

    initial_account_balance = Balance(date=datetime.date(year=2019, month=12, day=31), quantity=1000)

    general_ledger = Ledger(account=Account("Assets", "Cash", "Operating"), initial=initial_account_balance)
    general

# Generated at 2022-06-24 01:04:45.829664
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-24 01:04:55.377772
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    j1 = JournalEntry(
        datetime.date(2018, 1, 1),
        "Sale of Widget A",
        [
            Posting(datetime.date(2018, 1, 1), Decimal("1000"), Account("4001"), Quantity(Decimal("1000"))),
            Posting(datetime.date(2018, 1, 1), Decimal("1000"), Account("5101"), Quantity(Decimal("-1000"))),
        ],
    )

# Generated at 2022-06-24 01:05:04.427367
# Unit test for function build_general_ledger
def test_build_general_ledger():

    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journaling import (
        Journal,
        JournalEntry,
        Posting,
        Direction,
        Debit,
        Credit,
        build_journal,
        compile_journal,
        journal_to_postings,
    )


# Generated at 2022-06-24 01:05:13.337317
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # Given
    posting = Posting(datetime.datetime.now().date(), Account('Test'), Amount(Decimal(0)), Quantity(Decimal(0)))
    ledger = Ledger(Account('Ledger'), Balance(datetime.datetime.now().date(), Quantity(Decimal(0))))

    # When
    ledger_entry = LedgerEntry(ledger, posting, Quantity(Decimal(0)))

    # Then
    assert ledger_entry.ledger == ledger
    assert ledger_entry.posting == posting
    assert ledger_entry.balance == Quantity(Decimal(0))
    assert ledger_entry.date == posting.date
    assert ledger_entry.description == posting.journal.description
    assert ledger_entry.amount == posting.amount

# Generated at 2022-06-24 01:05:14.318343
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    print("test_LedgerEntry")
    assert LedgerEntry(None, None, None)

# Generated at 2022-06-24 01:05:15.005380
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-24 01:05:24.053938
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Journal

    assert build_general_ledger(
        DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2)),
        (Journal(datetime.date(2020, 1, 1), "J1", (), ()) for _ in range(2)),
        {},
    ).ledgers == {}


# Generated at 2022-06-24 01:05:29.505747
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    """
    Example for the creation of a class ReadInitialBalances
    """
    from .accounts import read_final_balances
    from .commons.time import date_range

    read_initial_balances = ReadInitialBalances()
    read_initial_balances = read_final_balances
    period = date_range("2020-01-01", "2020-12-31")

    __test_ReadInitialBalances = read_initial_balances(period)
    __test_ReadInitialBalances.values()


# Generated at 2022-06-24 01:05:35.881425
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting
    from .commons.numbers import Amount, Quantity
    
    account = Account("1234", "Test", terminal=True)
    initial_balance = Balance("2018-01-01", Quantity(0))
    journal_entry = Journal("2018-01-01", "Test", [Posting("2018-01-01", account, Amount(10))])

    ledger = Ledger(account, initial_balance)
    ledger.add(journal_entry.postings[0])

    assert len(ledger.entries) == 1
    assert ledger.entries[0].balance == initial_balance.value + journal_entry.postings[0].amount * journal_entry.postings[0].direction.value

# Generated at 2022-06-24 01:05:43.365182
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():

  # 1st test case: two different objects
  def test_case_one():
    @dataclass
    class Ledger(Generic[_T]):
        #: Account of the ledger.
        account: Account
        #: Initial balance of the ledger.
        initial: Balance
        #: Ledger entries.
        entries: List[LedgerEntry[_T]] = field(default_factory=list, init=False)

    @dataclass
    class Account:
        """
        Provides an account model.
        """

        #: Code of the account.
        code: str

        #: Name of the account.
        name: str

        def __eq__(self, other: "Account") -> bool:
            return self.code == other.code and self.name == other.name


# Generated at 2022-06-24 01:05:46.271205
# Unit test for method add of class Ledger
def test_Ledger_add():
    Ledger = build_general_ledger()
    assert(Ledger)

# Generated at 2022-06-24 01:05:51.106245
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account(code="123", name="Name")
    initial_balances = {}
    entries = []
    l = Ledger(account, initial_balances, entries)
    assert eval(l.__repr__()) == l

# Generated at 2022-06-24 01:05:57.549725
# Unit test for constructor of class Ledger
def test_Ledger():
    test_dict = {}

# Generated at 2022-06-24 01:06:03.818228
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account("Machines")
    b = Balance(date=datetime.date.today(), value=Quantity(Decimal(150000)))
    newLedger = Ledger(a, b)
    if newLedger.account == a and newLedger.initial == b and newLedger.entries == []:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:06:12.064700
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    import pytest
    from ..journals.algebra import ReadJournalEntries, read_journal_entries
    from ..accounts.algebra import ReadInitialBalances, read_initial_balances
    

    @pytest.fixture
    def gl(journal_entries):
        return compile_general_ledger_program(
            read_initial_balances(journal_entries), read_journal_entries(journal_entries)
        )

    @pytest.fixture
    def period(journal_entries):
        return DateRange(journal_entries[0].date, journal_entries[-1].date)

    def test_it_should_build_general_ledger(period, gl):
        # Exercise
        gl = gl(period)
        # Verify
        assert isinstance(gl, GeneralLedger)

# Generated at 2022-06-24 01:06:20.813498
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_posting = Posting(
        entry_date=datetime.date(2020, 4, 17),
        debit=Account("3000"),
        debit_comment="Dummy description",
        debit_currency="EUR",
        debit_value=Decimal("11"),
        credit=Account("3200"),
        credit_comment="Dummy description",
        credit_currency="EUR",
        credit_value=Decimal("11"),
    )

    test_ledger = Ledger(
        Account("3000"),
        Balance(datetime.date(2020, 4, 16), Quantity(Decimal("0"))),
    )

    test_ledger_entry = LedgerEntry(
        test_ledger,
        test_posting,
        Quantity(Decimal("11")),
    )


# Generated at 2022-06-24 01:06:23.184386
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    entry = LedgerEntry(None, None, None)
    assert entry.__repr__() == 'LedgerEntry(ledger=None, posting=None, balance=None)'

# Generated at 2022-06-24 01:06:33.577516
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..commons.zeitgeist import date_range
    from .accounts import Account
    from .journaling import Journal
    from .journaling.algebra import memory_journal
    test_account = Account(1, "test account", True)
    test_period = date_range("2018-01-01", "2018-12-31")
    initial_balances = {test_account: Balance(test_period.since, 0)}
    journal_entries = memory_journal()
    journal = Journal(datetime.datetime(2018,1,1),"test journal")
    journal_entries.add(journal)
    read_initial_balances = journal_entries.read_initial_balances(initial_balances)
    read_journal_entries = journal_entries.read_journal_entries(test_period)
   

# Generated at 2022-06-24 01:06:45.215215
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .test.test_doubles import journal_entry_to_read_journal_entries
    from .test.test_doubles import zero_balance_to_read_initial_balances
    from .test.values import sample_period
    from ..commons.test.values import sample_journal_entry
    from ..commons.zeitgeist import date_range

    ## Prepare test double for initial balances:
    read_initial_balances = zero_balance_to_read_initial_balances()

    ## Prepare test double for journal entries:
    read_journal_entries = journal_entry_to_read_journal_entries(sample_journal_entry())

    ## Build the program
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Run the program and check

# Generated at 2022-06-24 01:06:47.561855
# Unit test for constructor of class Ledger
def test_Ledger():
    assert Ledger(Account("USD", "Cash"), Balance(datetime.date.today(), Quantity(99999)))


# Generated at 2022-06-24 01:06:58.621989
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():

    def read_initial_balances(period: DateRange) -> InitialBalances:
        """
        Algebra implementation which reads initial balances.

        :param period: Accounting period.
        :return: Initial balances.
        """
        return {}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        """
        Algebra implementation which reads journal entries.

        :param period: Accounting period.
        :return: Journal entries.
        """
        return []

    def program(period: DateRange) -> GeneralLedger[_T]:
        """
        Consumes the opening and closing dates and produces a general ledger.

        :param period: Accounting period.
        :return: A general ledger.
        """
        ## Get initial balances as of the end of previous financial period:
        initial_balances = read_initial

# Generated at 2022-06-24 01:07:02.347860
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert "GeneralLedger(period=DateRange(since=datetime.date(2019, 4, 1), until=datetime.date(2019, 4, 30))," in repr(GeneralLedger(period=DateRange(since=datetime.date(2019, 4, 1), until=datetime.date(2019, 4, 30)), ledgers = {}))


# Generated at 2022-06-24 01:07:04.156680
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class TestReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    TestReadInitialBalances()


# Generated at 2022-06-24 01:07:04.558662
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True

# Generated at 2022-06-24 01:07:15.230417
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    ## Test data:
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount

    import datetime
    from decimal import Decimal

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 8, 31))

# Generated at 2022-06-24 01:07:15.900446
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    assert compile_general_ledger_program != 0

# Generated at 2022-06-24 01:07:26.867025
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    ## Create mock for Period
    class Period: pass

    ## Create mock for Ledger
    class Ledger: pass

    ## Create mock for Account
    class Account: 
        @classmethod
        def __eq__(self,other):
            return True

    ## Create mock for Balance
    class Balance: pass

    ## Create mock for GeneralLedgerProgram
    class GeneralLedgerProgram: pass

    ## Create mock for ReadInitialBalances
    class ReadInitialBalances: pass

    ## Create mock for ReadJournalEntries
    class ReadJournalEntries: pass

    ## Create mock for GeneralLedger
    class GeneralLedger:
        @classmethod
        def __eq__(self,other):
            return True

    ## Create mock for Decimal
    class Decimal: pass

    ## Create mock for Quantity

# Generated at 2022-06-24 01:07:31.714694
# Unit test for constructor of class Ledger
def test_Ledger():
    AccountType = ['ASSET','LIABILITY','EQUITY','INCOME','EXPENSE','COST OF SALES','BANK','PAYABLE','RECEIVABLE','PAID','RECEIVED','SHAREHOLDERS','CASH']
    account = Account('account', AccountType[0])
    balance = Balance('balance',1000)
    ledger = Ledger(account, balance, None)
    assert ledger.entries == []

# Generated at 2022-06-24 01:07:41.475726
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import random
    import secrets
    import string
    import unittest

    from .journaling import JournalEntry as ModelJournalEntry
    from .journaling import Posting as ModelPosting
    from .accounts import Account as ModelAccount
    from .commons.numbers import Amount as ModelAmount
    from .commons.numbers import Quantity as ModelQuantity
    from .commons.zeitgeist import DateRange as ModelDateRange
    from . import ledger_program

    class MockInitialBalances(ledger_program.ReadInitialBalances):
        def __call__(self, period: ModelDateRange):
            initial_balances = list()
            for _ in range(random.randint(1, 100)):
                account = secrets.token_hex(16)