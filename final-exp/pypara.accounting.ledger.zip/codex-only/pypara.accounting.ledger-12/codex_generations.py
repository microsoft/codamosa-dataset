

# Generated at 2022-06-24 00:57:48.505456
# Unit test for method add of class Ledger
def test_Ledger_add():
    account1 = Account('Test', '1234567890', 'Assets')
    balance = Balance(datetime.date(2019, 1, 2), Decimal(5000))
    ledger1 = Ledger(account1, balance)
    journal1 = JournalEntry(datetime.date(2019,1,1), 'Test')
    posting1 = Posting(journal1, datetime.date(2019,1,1), account1, Decimal(4000), 'Debit')
    assert ledger1.add(posting1) == LedgerEntry(ledger1, posting1, Decimal(9000))
    posting2 = Posting(journal1, datetime.date(2019,1,2), account1, Decimal(3000), 'Credit')

# Generated at 2022-06-24 00:57:49.114223
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
	pass

# Generated at 2022-06-24 00:57:55.466883
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    acc = Account(name = "acc", typ = "liability")
    bal = Balance(date = datetime.date(2019, 1, 1), value = Decimal("100"))
    # Create two ledgers with different descriptions but same account and initial.
    ledger1 = Ledger(account = acc, initial = bal)
    ledger2 = Ledger(account = acc, initial = bal)

    # Check if the two ledgers are equal.
    if not ledger1 == ledger2:
        raise AssertionError()


# Generated at 2022-06-24 00:57:56.294967
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 00:58:01.739992
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # set the values
    ledger = Ledger(account='asset', initial=Balance(date=datetime.date(2020, 1, 1), value=Decimal(1)))
    posting = Posting(journal=JournalEntry(
        date=datetime.date(2020, 1, 1), description='expenses',
        postings=[Posting(account=Account('expenses'), amount=Decimal(1), direction='expenses'),
                  Posting(account='asset', amount=Decimal(1), direction='asset')]))
    balance = Quantity(Decimal(1))
    ledger_entry_1 = LedgerEntry(ledger=ledger, posting=posting, balance=balance)
    ledger_entry_2 = LedgerEntry(ledger=ledger, posting=posting, balance=balance)

    # Test
    assert ledger_entry_

# Generated at 2022-06-24 00:58:13.027015
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ## Setup the test
    from datetime import date

    @dataclass
    class Dummy_ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account(code="101"): Balance(date=date(2020, 12, 31), value=Decimal("100")),
                Account(code="102"): Balance(date=date(2020, 12, 31), value=Decimal("0")),
            }


# Generated at 2022-06-24 00:58:13.471193
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True

# Generated at 2022-06-24 00:58:20.534918
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, Group
    from .commons import Direction
    from .journaling import Journal, JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .types import Debit, Credit

    ## Create test data.

    #: Accounting period.
    period = DateRange("2017-01-01", "2017-12-31")

    #: Test journal.
    journal = [
        Journal(
            description="Test description",
            postings=[
                Posting(Direction.debit, Debit("+1.23"), Account("1000", Group.assets, "Cash in hand")),
                Posting(Direction.credit, Credit("-1.23"), Account("4000", Group.liabilities, "Accounts payable")),
            ],
        )
    ]

    #: Initial balances.
    initial_balances

# Generated at 2022-06-24 00:58:30.088954
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    ledger1 = GeneralLedger(DateRange('2017-01-01', '2017-12-31'), {})
    ledger1.ledgers = {
        '012': Ledger('012', Balance('2017-01-01', Decimal('0'))),
        '021': Ledger('021', Balance('2017-01-01', Decimal('0'))),
        '030': Ledger('030', Balance('2017-01-01', Decimal('0'))),
    }

# Generated at 2022-06-24 00:58:38.786572
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # create 3 Account
    account1 = Account ('acc1', 'Account1 ', None, True)
    account2 = Account ('acc2', 'Account2 ', None, True)
    account3 = Account ('acc3', 'Account3 ', None, True)
    # create 1 posting in journal entry
    posting1 = Posting(account1, True, Decimal(10))
    journal_entry1 = JournalEntry('Je1', 'JournalEntry1', datetime.date(2019,1,1),
                             [posting1])
    # create ledger
    ledger1 = Ledger(account1, Balance(datetime.date(2018,1,1), Decimal(5)))
    ledger1.add(posting1)
    # create a LedgerEntry
    entry = LedgerEntry(ledger1, posting1, Quantity(Decimal(15)))


# Generated at 2022-06-24 00:58:39.682912
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-24 00:58:49.989463
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    print("Test GeneralLedger.__eq__()")
    import datetime
    from decimal import Decimal
    from typing import Optional
    from ..commons.numbers import Amount

    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .mock_algebras import MockAlgebras
    from .transactions import Transaction

    journal_entries = None
    first_period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 31))
    second_period = DateRange(datetime.date(2019, 2, 1), datetime.date(2019, 2, 28))
    read_journal_entries = MockAlgebras.read_journal_entries_factory

# Generated at 2022-06-24 00:58:58.731725
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    ## This toy example illustrates the use of :py:class:`GeneralLedgerProgram` type.
    ## It does not involve any actual production code.
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        pass

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    program = compile_general_ledger_program(read_initial_balances=_read_initial_balances,
                                             read_journal_entries=_read_journal_entries)
    transaction_type = None  # type: _T
    assert isinstance(program(period=DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))),
                      GeneralLedger[transaction_type])

# Generated at 2022-06-24 00:59:00.663297
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    print("ReadInitialBalances")
    assert ReadInitialBalances



# Generated at 2022-06-24 00:59:10.488029
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal as D
    from ..commons.zeitgeist import Period
    from .accounts import Account as A
    from .journaling import (
        JournalEntry as JE,
        Posting as P,
    )
    from .generic import (
        Balance as B,
        Description,
        Quantity as Q,
    )
    cash_account = A.create_asset_account(1, 'Cash')
    asset_account = A.create_asset_account(2, 'Boat')
    liability_account = A.create_liability_account(5, 'Loan')
    revenue_account = A.create_revenue_account(7, 'Interest')
    expense_account = A.create_expense_account(9, 'Insurance')

# Generated at 2022-06-24 00:59:17.739745
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from collections import namedtuple
    from dataclasses import FrozenInstanceError
    from typing import Type

    from .accounts import AccountType
    from .journaling import Posting, PostingType

    ## Define a type alias for the subtype we're going to use to test the function.
    _T = Type(Posting, [AccountType, PostingType])

    ## Define initial balances algebra:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account(1, "A1", AccountType.ASSET): Balance(period.since, Quantity(Decimal(1000))),
                Account(2, "A2", AccountType.ASSET): Balance(period.since, Quantity(Decimal(2000)))}

    ## Define journal entries algebra:

# Generated at 2022-06-24 00:59:29.546768
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 00:59:33.623216
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    print(Ledger(
        account=Account(
            number=1,
            desc="Cash in Hand"),
        initial=Balance(
            start=datetime.date(2020, 1, 1),
            value=Quantity(Decimal(100))
        ),
        entries=[]
    ))

# Generated at 2022-06-24 00:59:39.159507
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class FakeReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    @dataclass
    class FakeReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    def test_compile_general_ledger_program():
        compile_general_ledger_program(FakeReadInitialBalances(), FakeReadJournalEntries())

# Generated at 2022-06-24 00:59:50.299535
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    print("Unit test for constructor of class GeneralLedger()")
    print("- In class GeneralLedger() : the period is 20191010 ~ 20191020")
    print("- In class GeneralLedger() : the account number is 201-001")
    print("- In class GeneralLedger() : the entry is a instance of class LedgerEntry()")
    print("- In class GeneralLedger() : the ledgers is a dict[Account, Ledger[_T]]")

    period = DateRange(datetime.datetime(2019, 10, 10), datetime.datetime(2019, 10, 20))

# Generated at 2022-06-24 00:59:59.839743
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.numbers import Amount
    from .accounts import Account
    from .journaling import Transaction
    from .generic import AmountDirection
    from . import generic as gen
    import datetime
    account = gen.Account("test", gen.AccountType.Assets)
    initial = gen.Balance(datetime.date(2000, 1, 1), Amount(1))
    transaction = Transaction("Test", datetime.date(2000, 1, 1))
    transaction.add(AmountDirection.Debit, account, Amount(1))
    transaction.add(AmountDirection.Credit, gen.Account("test2", gen.AccountType.Assets), Amount(1))
    posting = transaction.postings[0]
    ledger = gen.Ledger(account, initial)
    entry = ledger.add(posting)
    assert entry.led

# Generated at 2022-06-24 01:00:05.988259
# Unit test for method __call__ of class ReadInitialBalances

# Generated at 2022-06-24 01:00:14.712626
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import Account, Assets, Equity

    assert repr(LedgerEntry(Ledger(Account(Assets), Balance(datetime.date(2019, 1, 1), 1)), None, 2)) == \
           "LedgerEntry(ledger=Ledger(account=Account(name='Assets'), initial=Balance(date=datetime.date(2019, 1, 1), value=Decimal('1'))), posting=None, balance=Decimal('2'))"

# Generated at 2022-06-24 01:00:25.356653
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledg_entry1 = LedgerEntry(Ledger(Account(123), Balance(datetime.date.today(), Quantity(Decimal(0)))), Posting(JournalEntry(datetime.date.today(), '', Amount(Decimal(10)), [Account(5), Account(6)]), Account(123), Amount(Decimal(10)), False, False), Quantity(Decimal(10)))
    ledg_entry2 = LedgerEntry(Ledger(Account(123), Balance(datetime.date.today(), Quantity(Decimal(0)))), Posting(JournalEntry(datetime.date.today(), '', Amount(Decimal(10)), [Account(5), Account(6)]), Account(123), Amount(Decimal(10)), False, False), Quantity(Decimal(10)))

    assert(ledg_entry1 == ledg_entry2)

# Generated at 2022-06-24 01:00:29.905148
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Test data
    class _AlgebraImpl(
        ReadJournalEntries[_T], ReadInitialBalances
    ):  # type:ignore # TODO: PEP-561
        # This is just a mock to get it to pass
        pass

    # Call function
    rv = compile_general_ledger_program(_AlgebraImpl(), _AlgebraImpl())

    # Assert return value type
    assert isinstance(rv, GeneralLedgerProgram)



# Generated at 2022-06-24 01:00:32.556902
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    test_obj1 = Ledger(Account(1),Balance(datetime.date.today(), Quantity(Decimal(0))))
    test_obj2 = Ledger(Account(1),Balance(datetime.date.today(), Quantity(Decimal(0))))
    
    assert test_obj1 == test_obj2
    

# Generated at 2022-06-24 01:00:43.219527
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit tests for function compile_general_ledger_program.
    """
    ## Test case 1: empty initial balances
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def read_journal_entries(period: DateRange) -> List[JournalEntry[None]]:
        return []

    expected = GeneralLedger(
        period=DateRange(since=datetime.date(year=2000, month=1, day=1), until=datetime.date(year=2000, month=12, day=31)),
        ledgers={},
    )

# Generated at 2022-06-24 01:00:54.366559
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    account1 = Account("Assets", "Current Assets")
    account2 = Account("Assets", "Fixed Assets")
    account3 = Account("Liabilities", "Current Liabilities")
    amount1 = amount2 = Amount(Decimal("100.00"))
    amount3 = Amount(Decimal("200.00"))
    balance1 = Quantity(Decimal("2000.00"))
    balance2 = Quantity(Decimal("3000.00"))
    date1 = date2 = date3 = date4 = datetime.date(2020, 1, 1)
    date5 = datetime.date(2020, 1, 2)
    description1 = description2 = "Description"
    description3 = "Description Three"
    direction1 = direction2 = direction3 = direction4 = direction5 = direction6 = direction7 = direction8 = direction9 = direction10 = direction11 = direction12

# Generated at 2022-06-24 01:01:03.710945
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    class ReadInitialBalancesMock:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    class ReadJournalEntriesMock:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    read_initial_balances = ReadInitialBalancesMock()
    read_journal_entries = ReadJournalEntriesMock()

    result = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert callable(result)

# Generated at 2022-06-24 01:01:14.274920
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Setup
    from .accounts import AccountType
    from .journaling import Journal, Posting

    account = Account(type=AccountType.ASSET, number=1, name="Cash & Bank")
    date = datetime.date(2020, 9, 1)
    description = "Credit from X"
    credit = Amount(100)
    debit = None
    journal = Journal(date=date, description=description)
    journal.add(account=account, amount=credit)
    posting = journal.postings[0]

    ledger = Ledger(account=account, initial=Balance(date, Quantity(Decimal(0))))
    ledger.entries.append(LedgerEntry(ledger=ledger, posting=posting, balance=Quantity(Decimal(100))))


# Generated at 2022-06-24 01:01:15.621874
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # If a = Ledger
    a = Ledger
    # Then assert that repr(a) returns 'Ledger(account=All Accounts, entries=[])'
    assert repr(a) == 'Ledger(account=All Accounts, entries=[])'

# Generated at 2022-06-24 01:01:17.071704
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    le1 = LedgerEntry()
    le2 = LedgerEntry()
    assert le1 == le2

# Generated at 2022-06-24 01:01:28.599609
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    import pytest
    from ..commons.zeitgeist import TimePoint
    from .journaling import Journal
    from .accounts import AccountType, AccountIdentifier
    from .generic import Direction
    from .values import KV


# Generated at 2022-06-24 01:01:33.823377
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    GeneralLedger = compile_general_ledger_program(lambda x: dict(), lambda x: list())
    assert repr(GeneralLedger(DateRange.from_date(datetime.date(year=2001, month=1, day=1)), dict())) == "GeneralLedger(period=DateRange(since=datetime.date(2001, 1, 1), until=datetime.date(2001, 1, 1)), ledgers={})"
    #
    #

# Generated at 2022-06-24 01:01:40.304964
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    This method tests the __repr__ method of the LedgerEntry class.
    """
    ledger = Ledger(Account('Dummy account', {'dummy_field' : 'dummy_value'}), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0))))
    journal = JournalEntry(datetime.date(2019, 1, 1), 'Dummy journal description')
    posting = Posting(journal, ledger.account, Amount(Decimal(0)))
    entry = LedgerEntry(ledger, posting, Quantity(Decimal(0)))
    assert repr(entry) == "<LedgerEntry account=Dummy account, date=2019-01-01, description=Dummy journal description, amount=0.0000, balance=0.0000>"

# Generated at 2022-06-24 01:01:40.765408
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass

# Generated at 2022-06-24 01:01:49.379026
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
      # GeneralLedger
      from decimal import Decimal
      from datetime import date
      from .accounts import Account
      from .accounts import AccountType
      from .journaling import JournalEntry
      from .journaling import Posting
      a1 = Account('A1', AccountType.ASSET, 'Account one')
      a2 = Account('A2', AccountType.ASSET, 'Account two')
      a3 = Account('A3', AccountType.ASSET, 'Account three')
      a4 = Account('A4', AccountType.ASSET, 'Account four')
      a5 = Account('A5', AccountType.ASSET, 'Account five')
      a6 = Account('A6', AccountType.LIABILITY, 'Account six')
      a7 = Account('A7', AccountType.LIABILITY, 'Account seven')
      a

# Generated at 2022-06-24 01:01:53.830751
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import CashAccount

    account = CashAccount("assets")
    for i in range(1,10):
        posting = Posting(account, i, i+1, "test_description")
        ledger = Ledger(account, Balance(0, 0))
        entry = LedgerEntry(ledger, posting, "blabal")
        assert entry.date == i


# Generated at 2022-06-24 01:02:00.437588
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import NON_TERMINAL_ACCOUNT
    from .accounts import TerminalAccount
    from .commons.zeitgeist import Period
    from .generic import Balance
    import datetime
    # initial balances
    initial_balances = {TerminalAccount("1"): Balance(datetime.date(2001, 1, 1), 1), TerminalAccount("2"): Balance(datetime.date(2001, 1, 1), 2)}
    # period
    period = Period(from_date=datetime.date(2000, 1, 1), to_date=datetime.date(2000, 12, 31))
    # result
    result = {TerminalAccount("1"): Balance(datetime.date(2001, 1, 1), 1), TerminalAccount("2"): Balance(datetime.date(2001, 1, 1), 2)}
    # assert

# Generated at 2022-06-24 01:02:01.505478
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    entry = LedgerEntry(None, None, None)
    assert True

# Generated at 2022-06-24 01:02:04.252668
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledger = Ledger()
    posting = Posting()
    amount = Amount()
    ledger_entry = LedgerEntry(ledger, posting, amount)
    assert ledger_entry.__eq__(ledger_entry) == True


# Generated at 2022-06-24 01:02:15.179253
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from .journaling import ReadJournalEntries
    from .accounts import Account, read_accounts
    from . import commondb
    import datetime
    from decimal import Decimal
    from typing import Dict
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Quantity

    def read_initial_balances(period: DateRange):
        return {
            read_accounts('Cash', 'Assets'): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
        }

    # Unit test for constructor of class ReadJournalEntries
    def test_ReadJournalEntries():
        import datetime
        from decimal import Decimal
        from typing import Generator, List
        from .accounts import Account, read_accounts
        from .commons import Reference

# Generated at 2022-06-24 01:02:25.259308
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..bookkeeping.accounts import Account
    from ..bookkeeping.journaling import Journal, JournalEntry, Posting
    from .accounts import TerminalAccount
    from .ledgers import Ledger, LedgerEntry
    from decimal import Decimal
    from datetime import date
    from dateutil import relativedelta
    import sys
    import os
    #sys.path.append(os.path.dirname(__file__) + '/../')
    #from main import Amount, Quantity

    # Initialize terminal accounts
    client = TerminalAccount("Client")
    cash = TerminalAccount("Cash")
    # Initialize ledger
    led = Ledger(cash, Balance(date.today(), Quantity(0)))
    # Initialize post
    p = Posting(date.today(), client, Quantity(Decimal(123.45)))

    # Constructor
    le

# Generated at 2022-06-24 01:02:34.451207
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    #initialize variables
    acct = Account(name='AccountName', number='0000')
    balance = Balance(value=Decimal(10), date=datetime.date(2020,1,1))
    ledger = Ledger(account=acct, initial=balance)
    #pass variables to the method and assert it
    test_ledger = ledger.__repr__()
    assert test_ledger == "Ledger(account=Account(name='AccountName', number='0000'), initial=Balance(date=datetime.date(2020, 1, 1), value=10), entries=[])"



# Generated at 2022-06-24 01:02:41.780142
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Program to build a general ledger:
    program: GeneralLedgerProgram[int] = compile_general_ledger_program(
        lambda period: {Account("ASSET.CASH"): Balance(period.since, Quantity(Decimal(100)))}, lambda period: []
    )

    ## Describe the general ledger:
    gl = program(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))

    ## Check structure:
    assert len(gl.ledgers) == 1
    assert gl.ledgers["ASSET.CASH"].initial.value == Decimal(100) and gl.ledgers["ASSET.CASH"].initial.date == datetime.date(2019, 1, 1)
    assert len(gl.ledgers["ASSET.CASH"].entries) == 0



# Generated at 2022-06-24 01:02:44.807968
# Unit test for constructor of class Ledger
def test_Ledger():

    # Create Account and Balance models
    a = Account("101")
    b = Balance("2020-12-31", "123.45")

    # Create a Ledger instance
    l = Ledger(a,b)

    # Test attributes of the object
    assert l.account.number == "101"
    assert str(l.initial.date) == "2020-12-31"
    assert l.initial.value == 123.45



# Generated at 2022-06-24 01:02:47.815703
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():

    # test
    assert( isinstance(compile_general_ledger_program, GeneralLedgerProgram) )


# Generated at 2022-06-24 01:02:57.982948
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from ..commons.zeitgeist import DateRange
    from datetime import date

    account1 = Account("10000", "Cash", AccountType.ASSET)
    account2 = Account("20000", "Account Receivable", AccountType.ASSET)
    account3 = Account("30000", "Account Payable", AccountType.LIABILITY)
    account4 = Account("50000", "Revenue", AccountType.INCOME)
    account5 = Account("60000", "Expense", AccountType.EXPENSE)
    account6 = Account("70000", "Owner's Equity", AccountType.EQUITY)

    posting1 = Posting(account1, Decimal(10000), "Debit")
    posting2 = posting1.reverse()
    posting

# Generated at 2022-06-24 01:03:09.342685
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from dataclasses import make_dataclass
    from .accounts import Account
    from .generic import Balance

    # Create account
    account = Account("Assets", "Current Assets", "Cash")

    # Create balance with 0 amount
    balance = Balance(datetime.date(2019, 1, 1), 0)

    # Create correct ledger
    correct_led = Ledger(account, balance)

    # Create incorrect ledger
    # Different accounts
    account2 = Account("Liabilities", "Current Liabilities", "Account Payable")
    incorrect_led2 = Ledger(account2, balance)

    # Different balance.date
    balance2 = Balance(datetime.date(2018, 1, 1), 0)
    incorrect_led3 = Ledger(account, balance2)

    # Different balance.amount

# Generated at 2022-06-24 01:03:09.858576
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    pass

# Generated at 2022-06-24 01:03:20.583854
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from decimal import Decimal
    from math import isclose
    
    from .accounts import Account, RootAccountType
    from .journaling import JournalEntry, Posting
    
    ## Dummy data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-24 01:03:26.488837
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    @dataclass
    class ReadJournalEntriesImpl:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return []

    program = compile_general_ledger_program(ReadInitialBalancesImpl(), ReadJournalEntriesImpl())
    assert callable(program)



# Generated at 2022-06-24 01:03:38.169513
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("ASSETS")
    balance = Balance(datetime.date(2019, 10, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, balance)
    assert ledger.account == Account("ASSETS")
    assert ledger.initial == Balance(datetime.date(2019, 10, 1), Quantity(Decimal(0)))
    assert ledger.entries == []

    # Unit test for add() function in class Ledger
    def test_Ledger_add():
        account = Account("ASSETS")
        balance = Balance(datetime.date(2019, 10, 1), Quantity(Decimal(0)))
        journal = JournalEntry(datetime.date(2019, 10, 1), "Test")
        posting_1 = Posting(journal, account, Quantity(10))

# Generated at 2022-06-24 01:03:45.776046
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # test when two entries have the same posting and balance
    l1 = Ledger(None, None)
    l2 = Ledger(None, None)
    p1 = Posting(None, None, None)
    p2 = Posting(None, None, None)
    b1 = Quantity(Decimal(12.3))
    b2 = Quantity(Decimal(12.3))
    assert LedgerEntry(l1, p1, b1) == LedgerEntry(l2, p2, b2)
    assert LedgerEntry(l2, p2, b2) == LedgerEntry(l1, p1, b1)

    # test when two entries have the same posting and different balance
    b1 = Quantity(Decimal(12.3))
    b2 = Quantity(Decimal(56.7))
    assert Ledger

# Generated at 2022-06-24 01:03:51.552898
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from decimal import Decimal
    assert str(GeneralLedger(DateRange(datetime.date(2020,1,1),datetime.date(2020,12,31)), {Account('a'): Ledger(Account('a'),Balance(datetime.date(2020,1,1),Decimal(0)))})) == "GeneralLedger(period=DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31)), ledgers={Account(code='a', name='a'): Ledger(account=Account(code='a', name='a'), initial=Balance(date=datetime.date(2020, 1, 1), value=Decimal('0')), entries=[])})"

# Generated at 2022-06-24 01:04:00.124751
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:
        return []

    prog = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    general_ledger = prog(period)
    assert general_ledger is not None
    assert len(general_ledger.ledgers) == 0

# Generated at 2022-06-24 01:04:00.654112
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ReadInitialBalances.__call__


# Generated at 2022-06-24 01:04:07.731416
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    l1 = Ledger(Account("Account 1"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    l2 = Ledger(Account("Account 2"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    l3 = Ledger(Account("Account 1"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    assert l1 != l2
    assert l1 == l3


# Generated at 2022-06-24 01:04:12.778974
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Tests the behavior of method __eq__ of class LedgerEntry
    """
    # Test with equal entries
    assert LedgerEntry(None, None, None) == LedgerEntry(None, None, None)
    # Test with unequal entries
    assert LedgerEntry(None, None, None) != LedgerEntry(None, None, None)

# Generated at 2022-06-24 01:04:19.152831
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    ledger = Ledger(Account(1, 0), Balance(datetime.date(2018, 1, 1), Quantity(0)))
    de = datetime.date(2018, 1, 1)
    je = JournalEntry(de, 0, "", True, [])
    p = Posting(de, je, Account(1, 0), Amount(0), Quantity(0), True, 1)
    le = LedgerEntry(ledger, p, Quantity(0))
    assert le.description == ""
    assert le.balance == 0


# Generated at 2022-06-24 01:04:26.535532
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class _DummyInitialBalancesAlgebra:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1111", "Cash", "1120"): Balance(period.since, Quantity(Decimal(0))),
                Account("1112", "Accounts receivable", "1120"): Balance(period.since, Quantity(Decimal(0))),
            }


# Generated at 2022-06-24 01:04:36.643368
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    gl = GeneralLedger(DateRange(Date(2017,9,1), Date(2018,8,31)), {'1100': 1100, '1200': 1200, '2100': 2300, '3200': 2300, '5210': 2300})
    assert(gl.period.since ==  Date(2017, 9, 1))
    assert(gl.period.until ==  Date(2018, 8, 31))
    assert(gl.ledgers['1100'].account ==  1100)
    assert(gl.ledgers['1200'].account ==  1200)
    assert(gl.ledgers['2100'].account ==  2100)
    assert(gl.ledgers['3200'].account ==  3200)
    assert(gl.ledgers['5210'].account ==  5210)

# Generated at 2022-06-24 01:04:44.297611
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Initial balance:
    init_bal = {Account("a"): Balance(datetime.date.min, Quantity(Decimal(1)))}
    # Journal entries:
    posts = [
        Posting(Account("a"), datetime.date.min, Quantity(Decimal(1)), 0),
    ]
    journ = [JournalEntry(posts, "")]
    # Program:
    program = compile_general_ledger_program(
        lambda _: init_bal,
        lambda _: journ,
    )
    # Run the program:
    print(program(DateRange(datetime.date.min, datetime.date.max)))

# Generated at 2022-06-24 01:04:48.702753
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    #
    # Test that method __repr__ returns a string that can be evalued to a LedgerEntry object
    #

    # Create a Ledger class instance
    account = Account(code='0000', name='Entry Account')
    initial_balance = Balance(date='2019-01-01', value=Quantity(Decimal(10)))
    ledger = Ledger(account=account, initial=initial_balance)
    
    # Create a Posting class instance

# Generated at 2022-06-24 01:04:51.010921
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert repr(GeneralLedger(None, None)) == "GeneralLedger(period=None, ledgers=None)"

# Generated at 2022-06-24 01:05:03.031863
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from datetime import date
    from .accounts import Accounts, AccountGroup, AccountHierarchy
    from .accounts import construct_accounts_hierarchy, construct_book_of_records, get_accounts_lookup as get_accounts_lookup
    from .journaling import construct_journaling_program, JournalEntry, Posting
    from .books import BookOfRecords, Record, RecordType
    import json

    group1_acct_numbers = ["1100", "1200"]    # list of account numbers in the group
    group2_acct_numbers = ["2100", "2200"]
    group3_acct_numbers = ["3100", "3200"]
    group4_acct_numbers = ["4100", "4200"]

# Generated at 2022-06-24 01:05:08.473403
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    try:
        ReadInitialBalances.__abstractmethods__.remove("__call__")
    except KeyError:
        pass

    class A(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    a = A()
    assert isinstance(a, ReadInitialBalances)



# Generated at 2022-06-24 01:05:10.270692
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of GeneralLedgerProgram.
    """
    pass



# Generated at 2022-06-24 01:05:14.071433
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    def read_initial_balances(period):
        pass
    def read_journal_entries(period):
        pass
    compiled = compile_general_ledger_program(
        read_initial_balances,
        read_journal_entries,
    )
    assert callable(compiled)

# Generated at 2022-06-24 01:05:19.054329
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Preparation
    # For all intents and purposes, the following line should be equivalent to:
    #   a = Account("Purchases")
    #   b = Balance(datetime.date(2029,1,1),Quantity(Decimal(1234)))
    #   l = Ledger(a,b)
    l1 = Ledger(Account("Purchases"), Balance(datetime.date(2029, 1, 1), Quantity(Decimal(1234))))
    # Execution
    l2 = Ledger(Account("Purchases"), Balance(datetime.date(2029, 1, 1), Quantity(Decimal(1234))))
    # Verification
    assert l1 == l2


# Generated at 2022-06-24 01:05:23.801434
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Arrange
    import dataclasses
    from .accounts import AccountNumber

    from .commons.numbers import Amount
    from .journaling import JournalEntry, Posting, ReadJournalEntries


    @dataclasses.dataclass
    class _Cache:
        initial_balances = None
        period = None
        journal = None
        general_ledger = None

    cache = _Cache()

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        cache.period = period
        return cache.journal

    def read_initial_balances(period: DateRange) -> InitialBalances:
        cache.period = period
        return cache.initial_balances


# Generated at 2022-06-24 01:05:27.382242
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    le_1 = LedgerEntry(None, None, None)
    le_2 = LedgerEntry(None, None, None)
    le_3 = LedgerEntry(None, None, None)
    assert le_1 == le_2
    assert le_1 == le_3


# Generated at 2022-06-24 01:05:28.776534
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:05:33.492527
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert ReadInitialBalances.__call__.__doc__ == 'Type of functions which reads and returns initial balances.\n\n'


# Generated at 2022-06-24 01:05:44.432465
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
  """
  Unit test case for method __eq__ of class Ledger. It tests following cases:
  1. Equal two ledgers.
  2. Unequal two ledgers.
  """
  account_1 = Account(name="Cash")
  account_2 = Account(name="Cash", number="111")
  account_3 = Account(name="Cash", number="112")
  account_4 = Account(name="Cash", number="111", group="Assets")
  account_5 = Account(number="111", group="Assets")
  account_6 = Account(name="Cash", number="112", group="Assets")
  account_7 = Account(name="Accounts Receivable", number="112", group="Equity")
  account_8 = Account(name="Fixtures and Fittings", number="112", group="Equity")



# Generated at 2022-06-24 01:05:55.645884
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_entry = LedgerEntry(Ledger(Account("test"), Balance()), Posting(1), 1)
    test_account = Account("test")
    test_account_2 = Account("test2")
    test_journal = test_entry.posting.journal
    test_journal.postings = [Posting(test_account, test_journal), Posting(test_account_2, test_journal)]
    test_journal.direction = 0

    # test_Leedger has direction 0, positive accounting
    assert test_entry.is_debit == True
    assert test_entry.is_credit == False

    # test_Leedger has direction 0, negative accounting
    test_journal.direction = 1
    assert test_entry.is_debit == False
    assert test_entry.is_credit == True


# Generated at 2022-06-24 01:06:06.269700
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import pytest

    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting


# Generated at 2022-06-24 01:06:17.124431
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .accounts import Account
    from .journaling import Journal, Posting, Transaction
    from .valuation import Balance, BaseValue

    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    journal = [Transaction(1, datetime.date(2018, 1, 1), "Entry 1", [Posting(True, 1, Account(1203), BaseValue(0, -1))])]
    initial = {Account(1203): Balance(datetime.date(2018, 1, 1), Quantity(0))}
    assert GeneralLedger(period, initial).ledgers
    assert GeneralLedger(period, journal).entries
    assert GeneralLedger(period, initial).ledgers
    assert GeneralLedger(period, journal).entries
    assert GeneralLedger(period, initial).led

# Generated at 2022-06-24 01:06:24.855319
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Create a JournalEntry
    j_e = JournalEntry(1,"test_journal_entry")
    # Create a Posting
    posting = Posting("Credit", j_e, 0, datetime.date(2020,1,1))
    posting2 = Posting("Debit", j_e, 0, datetime.date(2020,1,1))
    # Create a Balance
    balance = Balance(datetime.date(2020,1,1),0)
    # Create a LedgerEntry
    ledger_entry = LedgerEntry(1, posting, balance)
    # Create a Ledger
    ledger = Ledger("1", balance)
    # Create a GeneralLedger
    period = DateRange(datetime.date(2020,1,1), datetime.date(2020,1,1))

# Generated at 2022-06-24 01:06:32.447231
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from datetime import date
    ledger = Ledger(Account('Test'), Balance(date(2020, 1, 1), Quantity(10)))
    assert ledger == Ledger(Account('Test'), Balance(date(2020, 1, 1), Quantity(10)))
    assert ledger != Ledger(Account('Test'), Balance(date(2020, 2, 1), Quantity(10)))
    assert ledger != Ledger(Account('Dummy'), Balance(date(2020, 1, 1), Quantity(10)))
    assert ledger != Ledger(Account('Test'), Balance(date(2020, 1, 1), Quantity(5)))


# Generated at 2022-06-24 01:06:33.087879
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:06:44.607508
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .accounts import (
        AccountFactory,
        CashFlowAccount,
        DualEntryAccount,
        FinancialStatementAccount,
        IncomeStatementAccount,
        StatementOfStockholdersEquityAccount,
    )
    from .journaling import JournalEntry, Posting

    assert repr(GeneralLedger(None, {})) == """GeneralLedger(period=None, ledgers={})"""

    a1 = AccountFactory.build(
        CashFlowAccount, "Wages & salary", classes=[], parent=None, has_children=False, is_parent=False
    )

# Generated at 2022-06-24 01:06:55.387989
# Unit test for constructor of class Ledger
def test_Ledger():
    class JournalEntry(Protocol[_T]):
        date = datetime.date(2019,2,2)
        def __call__(self, period: DateRange) -> GeneralLedger[_T]:
            pass

    my_account = Account(account_name="My_Acc")
    my_balance = Balance(period=datetime.date(2019,2,2), value= Quantity(Decimal(10)))
    my_ledger = Ledger(account=my_account, initial=my_balance)

    assert type(my_ledger.account) is Account
    assert my_ledger.account == my_account
    assert my_ledger.initial == my_balance
    assert len(my_ledger.entries) == 0
    assert my_ledger._last_balance == my_balance.value
    

# Generated at 2022-06-24 01:07:03.456099
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from dataclasses import dataclass, field

    from .accounts import Account
    from .journaling import Journal, JournalEntry, Posting

    @dataclass
    class CurrentAccount(Account["CurrentAccount"]):
        pass

    @dataclass
    class Current(CurrentAccount):
        pass

    @dataclass
    class Cash(CurrentAccount):
        pass

    @dataclass
    class Sale(Journal["Sale"]):
        description: str = "Sale"

    @dataclass
    class SaleEntry(JournalEntry["Sale", "CurrentAccount"]):
        journal: Sale

    @dataclass
    class Receipt(Journal["Receipt"]):
        description: str = "Receipt"


# Generated at 2022-06-24 01:07:14.522838
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests that the general ledger is built correctly.
    """
    from .accounts import has_at_least_one_account
    from .accounts import is_terminal
    from .accounts import read_accounts
    from .journaling import build_journal_entry
    from .journaling import build_journal_posting
    from .journaling import read_journal_entries
    from datetime import date

    # Test data:
    jdate = date(2020, 1, 1)
    accounts = {
        "101": Account("101", "Cash", is_terminal, has_at_least_one_account, 0),
        "102": Account("102", "Sales", is_terminal, has_at_least_one_account, 0),
    }

# Generated at 2022-06-24 01:07:25.480392
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # "type" is private in Python so we have to use an workaround to test the private member
    class_ = LedgerEntry
    name = "_LedgerEntry__repr"
    try:
        repr_ = getattr(class_, name)
    except AttributeError:
        raise AttributeError(f"type object '{class_.__name__}' has no attribute '{name}'")
    assert callable(repr_)

    # We can call the __repr__ method from here
    ledger = Ledger(Account(name="test"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal())))

# Generated at 2022-06-24 01:07:33.882373
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    assert GeneralLedger(DateRange(datetime.date(2020,1,1),datetime.date(2020,12,31))
                        ,Dict[Account, Ledger[Decimal]]()) == GeneralLedger(DateRange(datetime.date(2020,1,1),datetime.date(2020,12,31))
                        ,Dict[Account, Ledger[Decimal]]())
    assert GeneralLedger(DateRange(datetime.date(2020,1,1),datetime.date(2020,12,31))
                        ,Dict[Account, Ledger[Decimal]]()) != GeneralLedger(DateRange(datetime.date(2020,1,1),datetime.date(2020,12,30))
                        ,Dict[Account, Ledger[Decimal]]())

# Generated at 2022-06-24 01:07:42.614615
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    ## Arrange
    from odin.accounting.journaling import Journal, Posting

    account = Account(code=1, name="A")
    journal = Journal(date=datetime.date(2018, 9, 1), description="Journal 1.")
    posting = Posting(direction=Posting.Direction.DEBIT, account=account, amount=Decimal(1))
    journal.postings.append(posting)
    ledger = Ledger(account=Account(code=1, name="A"), initial=Balance(datetime.date(2018, 9, 1), Decimal(0)))
    entry = LedgerEntry(ledger, posting)
    expected_result = "LedgerEntry(debit=1, credit=None, account=Account(code=1, name='A'), date=2018-09-01, description='Journal 1.')"

   