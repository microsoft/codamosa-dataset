

# Generated at 2022-06-24 00:57:39.409856
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    pass

# Generated at 2022-06-24 00:57:49.873041
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    test_Ledger1 = Ledger(Account('111','111','111','111','Y','Y','Y','N','N','N','N','N','1111'), Balance(datetime.date(2018, 5, 21), Quantity(Decimal(0))))
    test_Ledger2 = Ledger(Account('111','111','111','111','Y','Y','Y','N','N','N','N','N','1111'), Balance(datetime.date(2018, 5, 21), Quantity(Decimal(0))))
    test_Ledger3 = Ledger(Account('222','222','222','222','Y','Y','Y','N','N','N','N','N','2222'), Balance(datetime.date(2018, 5, 21), Quantity(Decimal(0))))
    assert test_Ledger1 == test_Ledger2
    assert test_Ledger1

# Generated at 2022-06-24 00:57:58.394517
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Testing attribute 'date'
    ledger = Ledger(account=Account(name="Test", parent=None, children=None), initial=Balance(date=datetime.date.today(), value=Decimal(1)))
    date = datetime.date(2020, 1, 1)
    posting = Posting(date=date, journal=JournalEntry(date=date, description="Test", postings=[Posting(date=date, journal=JournalEntry(date=date, description="Test", postings=[]), account=Account(name="Test", parent=None, children=None), amount=Decimal(1), direction=PostingDirection.DEBIT)]), account=Account(name="Test", parent=None, children=None), amount=Decimal(1), direction=PostingDirection.DEBIT)
    balance = 1

# Generated at 2022-06-24 00:58:03.962994
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Test case for function
    :func:`compile_general_ledger_program`.

    :return: Nothing.
    """
    from .accounts import AccountType

    accounts = {
        "Assets:Cash": Account("Assets:Cash", AccountType(1)),
        "Income": Account("Income", AccountType(2)),
        "Liability:AccountsPayable": Account("Liability:AccountsPayable", AccountType(1)),
        "Expenses:VehicleExpense": Account("Expenses:VehicleExpense", AccountType(1)),
    }


# Generated at 2022-06-24 00:58:15.047536
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .journaling import Journal
    from .journaling import LedgerEntryDirection
    from .journaling import Posting

    # Journal instance
    newJournalInstance = Journal(
        date=datetime.date(2019, 4, 30),
        description="deposit in a savings account",
        postings=[
            Posting(
                account="Assets:Bank:Checking",
                amount=Amount(Decimal("100.00")),
                direction=LedgerEntryDirection.DEBIT,
            ),
            Posting(
                account="Income:Savings",
                amount=Amount(Decimal("100.00")),
                direction=LedgerEntryDirection.CREDIT,
            ),

        ],
    )

    # Posting instance

# Generated at 2022-06-24 00:58:24.564204
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    #Dummy values
    ledger = Ledger(Account('123','A'),Balance(datetime.date.fromisoformat('2020-01-01'), Quantity(1)))
    posting = Posting(Account('123','A'),Quantity(1),1,JournalEntry(['2020-01-01','Hola'],['2020-01-01','Hola']))
    balance = Quantity(1)
    #Constructor
    ledgerEntry = LedgerEntry(ledger,posting,balance)
    #Assertions
    assert ledgerEntry.ledger == Ledger(Account('123','A'),Balance(datetime.date.fromisoformat('2020-01-01'), Quantity(1)))
    assert ledgerEntry.posting == posting
    assert ledgerEntry.balance == balance

# Generated at 2022-06-24 00:58:33.382950
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    '''
    g.__eq__(h) -> g == h
    '''
    # 17.1
    #   g = h = GeneralLedger(
    #       DateRange(date(2017, 1, 1), date(2017, 12, 31)),
    #       {
    #           Account(account.AccountType.ASSET, 'Cash'): Ledger(
    #               Account(account.AccountType.ASSET, 'Cash'),
    #               Balance(date(2016, 12, 31), Decimal('1000'))),
    #           Account(account.AccountType.ASSET, 'Checking'): Ledger(
    #               Account(account.AccountType.ASSET, 'Checking'),
    #               Balance(date(2016, 12, 31), Decimal('0'))),
    #           Account(account.AccountType.ASS

# Generated at 2022-06-24 00:58:43.296905
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2))
    #journal = JournalEntry('', datetime.date(2020, 1, 1), '', '', Decimal(10), True)
    initial = {Account('acc1'): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))}
    gl = GeneralLedger(period,initial)

    assert(gl.period == period)
    assert(gl.ledgers == initial)
    # not sure how to test add function
    # assert(gl.add(journal) == )

# Generated at 2022-06-24 00:58:51.550088
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("Test")
    initial = Balance(datetime.date.today(), Quantity(Decimal(0)))
    posting = Posting(direction = 1, date = datetime.date.today(), journal = JournalEntry(), account = account, amount = Quantity(Decimal(0)))
    entries = [LedgerEntry(Ledger(account, initial), posting, Quantity(Decimal(0)))]
    ledger = Ledger(account, initial, entries)
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == entries
    assert ledger._last_balance == Quantity(Decimal(0))
    posting2 = Posting(direction = 1, date = datetime.date.today(), journal = JournalEntry(), account = account, amount = Quantity(Decimal(0)))
    assert ledger.add(posting2) == LedgerEntry

# Generated at 2022-06-24 00:58:52.412631
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    entry = LedgerEntry

# Generated at 2022-06-24 00:59:00.548827
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    TEST_PERIOD = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31))
    TEST_LEDGER_ENTRIES = [LedgerEntry(Ledger(Account("1111"), Balance(TEST_PERIOD.since, Quantity(0))), Posting(JournalEntry(TEST_PERIOD, "Description"), Account("2222"), Amount(Decimal(0)), Quantity(0)))]
    TEST_LEDGERS = {Account("1111"): Ledger(Account("1111"), Balance(TEST_PERIOD.since, Quantity(0)), TEST_LEDGER_ENTRIES)}
    TEST_GENERAL_LEDGER = GeneralLedger(TEST_PERIOD, TEST_LEDGERS)
    assert TEST_GENERAL_LEDGER.period == TEST_PERIOD
    assert TEST_

# Generated at 2022-06-24 00:59:10.395630
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """

    ## Mock implementation of algebra:
    import unittest.mock as mock

    ## Create a mock object for the algebra:
    read_journal_entries = mock.Mock(spec=ReadJournalEntries)
    read_journal_entries.return_value = [[]]
    read_initial_balances = mock.Mock(spec=ReadInitialBalances)
    read_initial_balances.return_value = {}

    ## Compile the program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Call the program with mock opening and closing dates:
    opening_date = mock.Mock(spec=datetime.date)

# Generated at 2022-06-24 00:59:17.685481
# Unit test for method __eq__ of class Ledger

# Generated at 2022-06-24 00:59:21.572925
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    ledger = Ledger(Account('A-1'), Balance(datetime.date.today(), Quantity(Decimal(0))), [])
    assert 'Ledger' in ledger.__repr__()
    assert 'A-1' in ledger.__repr__()


# Generated at 2022-06-24 00:59:33.531861
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import journal_entry, Posting


# Generated at 2022-06-24 00:59:36.909934
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ## Test if ReadInitialBalances is a subtype of Protocol
    assert issubclass(ReadInitialBalances,Protocol)
    ## Test if the __call__ method is present in the class
    assert ReadInitialBalances.__call__.__objclass__ is ReadInitialBalances


# Generated at 2022-06-24 00:59:40.930666
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    _ = compile_general_ledger_program(lambda period: dict(), lambda period: [])

# Generated at 2022-06-24 00:59:48.355560
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import _cash, _accounts_receivable, _accounts_payable, make_journal
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .accounts import Account

    ## Prepare some data for the test:
    period = DateRange("2020-01-01", "2020-01-31")

    opening_balance_cash = Balance("2020-01-31", Quantity(Decimal("100.00")))
    opening_balance_ar = Balance("2020-01-31", Quantity(Decimal("0.00")))
    opening_balance_ap = Balance("2020-01-31", Quantity(Decimal("0.00")))


# Generated at 2022-06-24 00:59:57.154747
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    ## Holds the test journal.
    journal = Journal(
        date=datetime.date(2020, 4, 13),
        description="Test journal entry",
        postings=[
            Posting(
                account=Account("10", "A.1"),
                amount=Amount("12.34"),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account("20", "A.2"),
                amount=Amount("12.34"),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )

    ## Holds the test ledger entry.

# Generated at 2022-06-24 01:00:06.049641
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import JournalEntry
    from .accounts import Asset, Equity
    from .commons.numbers import Amount
    from .accounting_period import AccountingPeriod
    from .generic import Balance
    from .generic import BalanceAccount, BalanceEntry
    from .generic import Transaction, TransactionAccount, TransactionEntry
    from .general_ledger import build_general_ledger
    from .general_ledger import Ledger
    from datetime import date

    date_today = date.today()
    date_today_max = date(date_today.year, date_today.month, date_today.day)

    acct = Asset("Cash")
    acct2 = Equity("Retained Earnings")
    acct3 = Asset("Accounts Receivable")

# Generated at 2022-06-24 01:00:07.813449
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    L = Ledger(Account("A"), Balance(datetime.date.today(), Quantity(Decimal(0))))

    expected = "Ledger(Account('A'), Balance(date=datetime.date(2020, 7, 28), value=Quantity(Decimal('0'))))"
    assert L.__repr__() == expected

# Generated at 2022-06-24 01:00:17.245143
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2020, 4, 1), datetime.date(2020, 4, 30))
    journal = JournalEntry(datetime.date(2020,4,2), "test", [Posting(Account(1, "debit"), Quantity(1, "here"))])
    initial_balances = {Account(1, "debit"): Balance(datetime.date(2020, 3, 31), Quantity(3, "here"))}

    general_ledger = build_general_ledger(period, iter(journal), initial_balances)
    assert(general_ledger.period == period)
    assert(len(general_ledger.ledgers) == 1)

    for account, ledger in general_ledger.ledgers.items():
        assert(account == Account(1, "debit"))

# Generated at 2022-06-24 01:00:20.928480
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    a=LedgerEntry(1,2,3)
    assert str(a)=="LedgerEntry(ledger=1, posting=2, balance=3)"

# Generated at 2022-06-24 01:00:22.703099
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    pass


# Generated at 2022-06-24 01:00:30.531442
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from datetime import date
    from ..commons.neat import neat
    from .accounts import NonPerformingAsset
    from .journaling import Journal, JournalEntry, Posting, ReadJournalEntries
    from .commons import Amount
    @dataclass
    class JournalEntryMock(JournalEntry[NonPerformingAsset]):
        date: date = date(2019, 1, 1)
        description: str = "Description"
        postings: List[Posting[NonPerformingAsset]] = field(
            default_factory=lambda: [
                Posting(Account.CustomerAccounts, Direction.DEBIT, Amount(100.00), NonPerformingAsset(2)),
                Posting(Account.CustomerAccounts, Direction.CREDIT, Amount(100.00)),
            ]
        )



# Generated at 2022-06-24 01:00:36.446857
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from .journaling import ReadJournalEntries
    from .accounts import AccountType
    from .accounts import Vat

    class MockReadInitialBalances:
        def __init__(self):
            pass
        def __call__(self, period: DateRange) -> InitialBalances:
            return {AccountType.assets: Balance(period.since, Amount(0, Vat.exempt))}

    class MockReadJournalEntries(ReadJournalEntries[_T]):
        def __init__(self):
            pass
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    ## Test
    read_initial_balances = MockReadInitialBalances()
    read_journal_entries = MockReadJournalEntries()

# Generated at 2022-06-24 01:00:37.160159
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:00:46.351130
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ## Create two ledger entries with different fields:
    entry1 = LedgerEntry(None, None, None)
    entry2 = LedgerEntry(None, None, None)

    ## Check that two ledger entries are equal
    assert entry1 == entry1 and entry1 == entry2 and entry2 == entry1 and entry2 == entry2

    ## Set a field of the second ledger
    entry2.amount = "Test"

    ## Check that two ledger entries are not equal
    assert entry1 != entry2 and entry2 != entry1

    ## Set the first ledger entry field to the same value than second one
    entry1.amount = "Test"

    ## Check that two ledger entries are equal
    assert entry1 == entry2 and entry2 == entry1


# Generated at 2022-06-24 01:00:50.280043
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(Account(["TEST"]), Balance(datetime.date(2017,1,1), Quantity(Decimal(0))))) == "Ledger(account=[TEST], initial=Balance(date=2017-01-01, value=0.0))"


# Generated at 2022-06-24 01:00:57.142479
# Unit test for constructor of class Ledger
def test_Ledger():
    from ..fixtures import books as fixtures
    from .journaling import Posting, JournalEntry, PostingType

    from datetime import date

    from .accounts import Account

    assert isinstance(fixtures.book, Ledger) == True

    for i in fixtures.book.entries:
        assert isinstance(i, LedgerEntry) == True

    assert isinstance(fixtures.book.entries[0], LedgerEntry) == True

    assert isinstance(fixtures.book.account, Account) == True
    assert isinstance(fixtures.book.initial, Balance) == True

    assert fixtures.book.initial.value == Decimal(0)
    assert fixtures.book.initial.date == date(2018, 1, 1)

    assert isinstance(fixtures.book.entries[0].ledger, Ledger) == True
   

# Generated at 2022-06-24 01:01:06.182729
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from bookkeeper import journaling
    from bookkeeper.domain import accounts

    # Setup the aggregate root callbacks:
    read_initial_balances = lambda period: {}
    read_journal_entries = lambda period: ()

    # Compile the program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Execute the program:
    dated_range = DateRange(datetime.date(2001, 1, 1), datetime.date(2001, 12, 31))
    general_ledger = program(dated_range)

    # Perform assertions:
    assert isinstance(general_ledger, GeneralLedger)
    assert general_ledger.period == dated_range
    assert len(general_ledger.ledgers) == 0



# Generated at 2022-06-24 01:01:17.250325
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    LedgerEntry.__repr__(self) must work correctly.
    """
    input_data_1 = datetime.date, Account, Amount, Quantity

    input_data_2 = input_data_1(2019, 1, 1), Account("a"), Amount(100), Quantity(100)
    exp_output_1 = "LedgerEntry(ledger={input_data_2[0]}, posting={input_data_2[1]}, balance={input_data_2[2]}"\
        .format(input_data_2=input_data_2)
    assert LedgerEntry(input_data_2[0], input_data_2[1], input_data_2[2]).__repr__() == exp_output_1


# Generated at 2022-06-24 01:01:28.742556
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, compile_journal_entry_program
    from .taxonomy import Taxonomy, compile_taxonomy_program

    when = datetime.date(2019, 4, 1)


# Generated at 2022-06-24 01:01:33.448531
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry1 = LedgerEntry(Ledger(Account(1), Balance(Decimal(1))), Posting(Account(1), Decimal(1), Decimal(1)), Decimal(1))
    entry2 = LedgerEntry(Ledger(Account(1), Balance(Decimal(1))), Posting(Account(1), Decimal(1), Decimal(1)), Decimal(1))

    assert entry1 == entry2

# Generated at 2022-06-24 01:01:41.113369
# Unit test for method add of class Ledger
def test_Ledger_add():

    Posting_1 = Posting(Account("a"), Decimal("100.00"), "D")
    Ledger_1 = Ledger(Account("a"), Balance("a", Decimal("0")))
    Ledger_1.add(Posting_1)
    assert Ledger_1.entries[0].balance == Decimal("100.00")

    Posting_2 = Posting(Account("a"), Decimal("-100.00"), "C")
    Ledger_2 = Ledger(Account("a"), Balance("a", Decimal("0")))
    Ledger_2.add(Posting_2)
    assert Ledger_2.entries[0].balance == Decimal("-100.00")

    Posting_3 = Posting(Account("a"), Decimal("100.00"), "D")
    Posting_4

# Generated at 2022-06-24 01:01:43.705777
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert "GeneralLedger(period=DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2018, 12, 31)), ledgers={})"==repr(GeneralLedger(DateRange(datetime.date(2018,1,1),datetime.date(2018,12,31)),{}))


# Generated at 2022-06-24 01:01:53.714164
# Unit test for method add of class Ledger
def test_Ledger_add():
    posting1 = Posting('123', Decimal(300))
    posting2 = Posting('456', Decimal(600))
    account1 = Account('123', 'ABC', Decimal(100))
    account2 = Account('456', 'ABC', Decimal(100))
    account3 = Account('789', 'DEF', Decimal(100))
    account4 = Account('098', 'DEF', Decimal(100))
    account5 = Account('123', 'DEF', Decimal(100))
    account6 = Account('456', 'DEF', Decimal(100))
    balance1 = Balance(datetime.date(2020, 1, 1), Decimal(100))
    balance2 = Balance(datetime.date(2020, 1, 1), Decimal(200))
    ledger1 = Ledger(account1, balance1)
    ledger2 = Ledger

# Generated at 2022-06-24 01:01:58.043192
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .commons.test_utils import assert_equal

    # The constructor of LedgerEntry should be able to be called without error
    assert True


# Generated at 2022-06-24 01:02:00.124871
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert True is True

# Generated at 2022-06-24 01:02:02.020936
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    l1 = LedgerEntry('l', 'p', 'b')
    assert(str(l1) == "LedgerEntry(ledger='l', posting='p', balance='b')")

# Generated at 2022-06-24 01:02:12.595383
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import random
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .commons.numbers import RandomAmount, RandomQuantity
    from .general_ledger import GeneralLedger, InitialBalances

    ## Generate random opening and closing dates and compute period:
    opening_date = random.choice(range(1, 28))
    closing_date = opening_date + random.choice(range(1, 28))
    period = DateRange(datetime.date(2017, 4, opening_date), datetime.date(2017, 4, closing_date))

    ## Generate random initial balances as of end of previous financial period:
    init_balances: InitialBalances = {}
   

# Generated at 2022-06-24 01:02:23.207747
# Unit test for method add of class Ledger
def test_Ledger_add():
    account= Account("100100", "Cuentas por cobrar", "B")
    bookingDate = datetime.datetime.strptime('31/03/2019', '%d/%m/%Y')
    description = "JE #1"
    amount = 1000
    direction = Direction.DEBIT
    posting= Posting(bookingDate, description, account, amount, direction)
    iBalanceBookingDate= datetime.datetime.strptime('31/01/2019', '%d/%m/%Y')
    initialBalance= Balance(iBalanceBookingDate, 0)
    ledger= Ledger(account, initialBalance)
    expectedEntry= LedgerEntry(ledger, posting, 1000)
    expectedEntry.ledger = ledger
    result= ledger.add(posting)
    assert result == expectedEntry

#

# Generated at 2022-06-24 01:02:29.030007
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # GIVEN a GeneralLedger instance
    g = GeneralLedger(DateRange(datetime.date.today(), datetime.date.today()), dict())

    # THEN g has a type GeneralLedger, and period as a variable of type datetime.date, and accounts as a variable of type dict
    assert isinstance(g, GeneralLedger)
    assert type(g.period) == DateRange
    assert type(g.ledgers) == dict


# Generated at 2022-06-24 01:02:32.300882
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    def test_function(test_period : DateRange) -> GeneralLedger:
        return GeneralLedger(test_period, {})
    test_instance = GeneralLedgerProgram(test_function)
    assert isinstance(test_instance, GeneralLedgerProgram)

# Generated at 2022-06-24 01:02:34.929861
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:02:42.681756
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class _ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            assert period.since == datetime.datetime(year=2020, month=1, day=1, hour=0, minute=0, second=0)
            assert period.until == datetime.datetime(year=2020, month=12, day=31, hour=0, minute=0, second=0)

# Generated at 2022-06-24 01:02:52.721282
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():

    # Defining instance of ReadJournalEntries as post_journal_entries
    class post_journal_entries(ReadJournalEntries):
        def __call__(self, period: DateRange)->JournalEntry:
            pass
    
    # Defining instance of ReadInitialBalances as read_opening_balances
    class read_opening_balances(ReadInitialBalances):
        def __call__(self, period: DateRange)->InitialBalances:
            pass
    
    # Defining instance of DateRange as period
    class period(DateRange):
        def __init__(self, since: datetime, until: datetime):
            self.since = since
            self.until = until
    
    # Instantiating objects and calling object of GeneralLedgerProgram
    journal_entries = post_journal_entries()
    initial_

# Generated at 2022-06-24 01:02:59.996398
# Unit test for function build_general_ledger
def test_build_general_ledger():
    
    from datetime import date
    from ..commons.types import Date, Amount, Quantity
    from .accounts import Account, AccountType, XeroAccount
    from .journaling import Entry
    from .general_ledger.tests.test_journaling import test_add_entry
    from .general_ledger.tests.test_journaling import test_get_journal_entries

    # Initialize account manager
    from .accounts import AccountManager
    account_manager = AccountManager(None)

    
    # Create a sample of accounts
    account_manager.set_account(XeroAccount(id="TEST", name="Test account", account_type=AccountType.EXPENSE))
    account_manager.set_account(XeroAccount(id="TEST1", name="Test account amount", account_type=AccountType.EXPENSE))
   

# Generated at 2022-06-24 01:03:11.606231
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    import datetime
    from dataclasses import dataclass, field
    from decimal import Decimal
    from typing import Dict, Generic, Iterable, List, Optional, Protocol, TypeVar
    
    #: Defines a generic type variable.
    _T = TypeVar("_T")
    
    #: Initial balances:
    InitialBalances = Dict[Account, Balance]
    
    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """
    
        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"
    
        #: Posting of the ledger entry.
        posting: Posting[_T]
    
        #: Balance of the ledger entry.
        balance: Quantity
    

# Generated at 2022-06-24 01:03:19.097543
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..banking.journaling import Posting
    fr = Posting(None, "FR", None, None, None)
    from .accounts import Account
    from .generic import Balance, Quantity
    from .ledgers import LedgerEntry
    from datetime import date
    acc = Account("100010", "Cash", None)
    bal = Balance(date.today(), Quantity(100))
    le = LedgerEntry(Ledger(acc, bal), fr, Quantity(100))

    assert le.__repr__() == "LedgerEntry(fr, 100)"

# Generated at 2022-06-24 01:03:23.050116
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert(len(read_initial_balances(period)) == 0)

# Generated at 2022-06-24 01:03:30.982520
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    entry = LedgerEntry(Ledger(Account.ASSET, Balance(datetime.date(2020,1,1), Quantity(Decimal(0)))), Posting(Decimal(1000), datetime.date(2020,1,1)), Quantity(0))
    if entry.date != datetime.date(2020, 1, 1):
        assert False
    if entry.amount != Decimal(1000):
        assert False
    if entry.cntraccts[0] != Account.LIABILITY:
        assert False
    if entry.debit != None:
        assert False
    if entry.credit != Decimal(1000):
        assert False
    return True

# Generated at 2022-06-24 01:03:35.591149
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    import datetime 
    period = DateRange(datetime.date(2020,1,1), datetime.date(2020,6,30))
    journal_entries = []
    initial_balances = []
    result = build_general_ledger(period,journal_entries,initial_balances)
    assert (result.period == period and result.ledgers == {})

# Generated at 2022-06-24 01:03:41.546490
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    """Test for constructor of class ReadInitialBalances"""
    name = "read_initial_balances"
    test_obj = ReadInitialBalances()
    assert hasattr(test_obj, '__call__'), "Class '{0}' should have a '__call__' method".format(name)
    assert callable(getattr(test_obj, '__call__')), "Method '{0}' should be callable".format('__call__')


# Generated at 2022-06-24 01:03:48.369144
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from . import accounts

    ## Program implementation:
    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        yield JournalEntry(accounts.Bank, [], period.since, "Deposit")

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {accounts.Bank: Balance(period.since, Quantity(Decimal(1000)))}

    ## Build the general ledger program:
    glp = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    
    ## Build the general ledger:
    gl1 = glp(DateRange(period.since, period.until))

    ## Build the general ledger once more
    gl2 = glp(DateRange(period.since, period.until))

   

# Generated at 2022-06-24 01:03:55.009160
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Setup Dependencies
    read_initial_balances = ReadInitialBalances
    read_journal_entries = ReadJournalEntries
    # Execute SUT
    generalLedgerProgram = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    # Validate Results
    assert(generalLedgerProgram is GeneralLedgerProgram)

# Generated at 2022-06-24 01:04:04.527870
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Setup
    ledger = Ledger(None, None)
    posting = Posting(None, None, None, None)
    balance = None
    sut = LedgerEntry(ledger, posting, balance)

    # Test
    sut.__eq__(None)
    sut.__eq__(sut)
    sut.__eq__(LedgerEntry(ledger, posting, balance))
    sut.__eq__(LedgerEntry(ledger, posting, balance + Decimal(1)))
    sut.__eq__(LedgerEntry(ledger, posting, posting.amount * posting.direction.value))


# Generated at 2022-06-24 01:04:06.575328
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # Type: ReadInitialBalances
    # Constructor: ReadInitialBalances()
    ReadInitialBalances()


# Generated at 2022-06-24 01:04:14.208379
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    """Unit test for constructor of class GeneralLedger"""
    period = DateRange(datetime.date(2018,12,1), datetime.date(2018,12,30))
    accounts = [Account(a) for a in ['A1', 'A2']]
    initial = {a: Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))) for a in accounts}
    ledgers = {a: build_ledger(a, initial[a]) for a in accounts}
    return GeneralLedger(period, ledgers)


# Generated at 2022-06-24 01:04:18.843835
# Unit test for constructor of class Ledger
def test_Ledger():
    #Create Account object
    a = Account("123456789")
    #Create Balance object
    b = Balance(datetime.date.today(),Decimal(10))
    #Create Ledger object
    c = Ledger(a,b)
    #Test Ledger constructor
    assert c.account==a and c.initial==b and c.entries==[]


# Generated at 2022-06-24 01:04:26.421708
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function :py:func:`build_general_ledger`.
    """
    ## Import dependencies:
    from ..commons.zeitgeist import DateRange

    ## Import test accounts:
    from ..physics.accounts import cash_in_hand
    from ..physics.accounts import sales_revenue
    from ..physics.accounts import sales_returns

    ## Define accounting period:
    period = DateRange(datetime.date(2018, 12, 31), datetime.date(2019, 12, 31))

    ## Define initial balances:
    initial = {cash_in_hand: Balance(period.since, Decimal(100000))}

    ## Populate the journal with a journal entry:

# Generated at 2022-06-24 01:04:27.148397
# Unit test for constructor of class Ledger
def test_Ledger():
    assert 1 == 1

# Generated at 2022-06-24 01:04:37.762006
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Journal
    from ..commons import zeitgeist

    # Initialization
    # FIXME: add custom test data
    account_1 = Account("A001", "Cash")
    account_2 = Account("A002", "Cash Equivalents")
    account_3 = Account("A003", "Accounts Receivable")
    account_4 = Account("A004", "Notes Receivable")
    account_5 = Account("A005", "Inventory")
    account_6 = Account("A006", "Prepaid Expenses")
    account_7 = Account("A007", "Property Plant and Equipment")
    account_8 = Account("A008", "Accumulated Depreciation")
    account_9 = Account("A009", "Intangible Assets")
    account_10 = Account("A010", "Investments")
    account_11

# Generated at 2022-06-24 01:04:45.784566
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Ledger(account = "1000", initial = {'date': datetime.date, 'value': Quantity(10.00)}, entries = [])
    b = Ledger(account = "1000", initial = {'date': datetime.date, 'value': Quantity(10.00)}, entries = [])
    c = Ledger(account = "1000", initial = {'date': datetime.date, 'value': Quantity(10.00)}, entries = [{'_posting': {'date': datetime.date, 'journal': {'description': 'DescriptionTest'}, 'account': '1000', 'amount': Decimal('10.00')}, 'balance': Quantity(10.00)}])

    assert a==b
    assert a!=c


# Generated at 2022-06-24 01:04:47.127615
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import JournalEntry
    pass

# Generated at 2022-06-24 01:04:56.180768
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    print("Test general ledger program")
    #
    # DRIVERS
    #
    class ReadBalancesFromRepository(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {"Repository": Balance(period.since, Quantity(100))}

    class ReadJournalEntriesFromRepository(ReadJournalEntries):

        def __init__(self, journal_entries):
            # print("ReadJournalEntriesFromRepository")
            self.journal_entries = journal_entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            # print("ReadJournalEntriesFromRepository.__call__")
            return self.journal_entries

    #
    # BUSINESS
    #
    # Create journal entries

# Generated at 2022-06-24 01:05:04.480702
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-24 01:05:07.752082
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    entry = LedgerEntry()
    assert entry.ledger == ""
    assert entry.posting ==""
    assert entry.balance ==""


# Generated at 2022-06-24 01:05:16.125703
# Unit test for method add of class Ledger
def test_Ledger_add():
    LA = Account(12, "LA", "Level 1 A")
    LA_initial_balances = Balance(datetime.date(2020, 11, 30), Quantity(100))
    LA_ledger = Ledger(LA, LA_initial_balances)
    directions = [-1, 1]
    for d in directions:
        for a in [500, -500]:
            J = JournalEntry(datetime.date(2020, 11, 30), str(LA.description) + ": Entry" )
            J.add_posting(Posting(LA, Amount(a), d))
            LA_ledger.add(J.postings[0])
            e = LA_ledger.entries[-1]
            assert e.account == LA
            assert e.direction == d
            assert e.amount == Amount(a)
            assert e

# Generated at 2022-06-24 01:05:28.320345
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 01:05:39.644233
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import read_journal_entries, read_initial_balances
    from .testdata import get_journal
    from ..commons.zeitgeist import now
    from ..commons.numbers import zero_balance, open_balance

    ## Compile the GLP:
    glp = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Get the journal:
    journal = get_journal()

    ## Fake the period of interest:
    period = DateRange(now() - datetime.timedelta(days=14), now())

    ## Get initial balances as of the end of previous financial period:
    initial_balances = read_initial_balances(period)

    ## Open the GL:

# Generated at 2022-06-24 01:05:49.576820
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class ReadInitialBalances_:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    @dataclass
    class ReadJournalEntries_:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass

    @dataclass
    class BuildGeneralLedger_:
        def __call__(self, period: DateRange, journal: Iterable[JournalEntry], initial: InitialBalances) -> GeneralLedger[_T]:
            pass

    ###
    ReadInitialBalances_()
    ReadJournalEntries_()
    BuildGeneralLedger_()
    ###

    program_ = compile_general_ledger_program(ReadInitialBalances_(), ReadJournalEntries_())

    @dataclass
    class Period_:
        since

# Generated at 2022-06-24 01:05:51.380885
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2018, 11, 1), datetime.date(2019, 1, 31))
    journal = []
    initial = {}
    gl = build_general_ledger(period, journal, initial)
    assert gl.period == period
    assert gl.ledgers == {}


# Generated at 2022-06-24 01:05:58.249955
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .charts import Chart, ReadChart
    from .accounts import AccountType, AccountClass, Account
    from .journaling import Posting, Journal, Post
    from .generic import Balance
    from .accounts import AccountType, AccountClass, Account, ReadAccounts, ReadAccountBalance
    from .journaling import ReadJournalEntries


# Generated at 2022-06-24 01:06:02.222174
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert isinstance(GeneralLedger(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)), dict()), GeneralLedger)



# Generated at 2022-06-24 01:06:06.289046
# Unit test for constructor of class Ledger
def test_Ledger():
    ledger = Ledger(Account(1, "Acc1"), Balance(datetime.date(2020, 1, 1), Quantity(50)))
    assert ledger.account.id == 1
    assert ledger.initial.account.id == 1

# Generated at 2022-06-24 01:06:07.146550
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-24 01:06:13.153303
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Create a GeneralLedger and check that all the properties are the desired values
    dates = DateRange(datetime.date(2019,1,1), datetime.date(2019,1,31))
    ledgers = {}
    assert GeneralLedger(dates,ledgers).period == dates
    assert GeneralLedger(dates,ledgers).ledgers == ledgers
    print("GeneralLedger constructor passed")


# Generated at 2022-06-24 01:06:14.581044
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ## Instantiate
    obj = ReadInitialBalances()
    print(obj)

# Generated at 2022-06-24 01:06:15.102942
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-24 01:06:23.046998
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..books.cashbooks import CashJournalEntry, CashPosting
    from ..books.ledgerbooks import LedgerAccount
    lb1 = LedgerAccount("1000", "Cash at Bank")
    le1 = CashJournalEntry("2019-07-01", "2019-07-31", "Opening Balance")
    p1 = CashPosting("1000", le1, "Dr", 1000)
    l1 = Ledger(lb1, Balance("2019-06-30", 0))
    le = LedgerEntry(l1, p1, 1000)
    assert le.ledger == l1
    assert le.posting == p1
    assert le.balance == 1000
    assert le.date.strftime("%Y-%m-%d") == '2019-07-01'
    assert le.description == "Opening Balance"

# Generated at 2022-06-24 01:06:30.789116
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert Ledger(1,"a") == Ledger(1,"a")
    assert Ledger(1,"a") != Ledger(2,"a")
    assert Ledger(1,"a") != Ledger(1,"b")
    assert Ledger(1,"a") != Ledger(2,"b")
    assert Ledger(1,1) == Ledger(1,1)
    # it should not compares the entries of two ledgers
    assert Ledger(1,1,["a", "b"]) == Ledger(1,1,["c", "d"])


# Generated at 2022-06-24 01:06:40.374896
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from datetime import date
    from decimal import Decimal
    from pycoingecko import CoinGeckoAPI
    from pycoingecko.util import TypedDict

    # Define aliases:
    Account = str
    Amount = Decimal
    Balance = TypedDict("Balance", {"date": date, "value": Amount}, total=False)
    Detail = str
    Direction = int
    Quantity = int
    JournalID = str
    InstrumentID = str
    PortfolioID = str
    PositionID = str
    PostingID = str

# Generated at 2022-06-24 01:06:42.674685
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    read_initial_balances = ReadInitialBalances()
    read_journal_entries = ReadJournalEntries()

    assert compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-24 01:06:49.017189
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Read the Journal entries,initial balances,date range and all account values
    read_journal_entries(period,all_accounts)
    read_initial_balances(period)

# Generated at 2022-06-24 01:06:52.543111
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    assert GeneralLedger(None, None) == GeneralLedger(None, None)
    assert not (GeneralLedger(None, None) == None)
    assert not (GeneralLedger(None, None) == 1)


# Generated at 2022-06-24 01:06:55.749337
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():

    pass


# Generated at 2022-06-24 01:07:03.683218
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    Test method __eq__ of class GeneralLedger
    """
    # Test whether two ledger objects are equal when their account is not equal
    assert build_general_ledger(DateRange(datetime.date(2020,2,2),
                                          datetime.date(2020,3,3)),[],{Account("test_acc") : Balance(datetime.date(2020,1,1), Quantity(Decimal(0)))}) == \
           build_general_ledger(DateRange(datetime.date(2020,2,2),
                                          datetime.date(2020,3,3)),[],{Account("test_acc") : Balance(datetime.date(2020,1,1), Quantity(Decimal(0)))})
    # Test whether two ledger objects are equal when their account is equal

# Generated at 2022-06-24 01:07:05.156912
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """


# Generated at 2022-06-24 01:07:15.284151
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    assert GeneralLedger(DateRange(), {}) == GeneralLedger(DateRange(), {})
    assert GeneralLedger(DateRange(), {}) != GeneralLedger(DateRange(datetime.date(2018, 1, 1),datetime.date(2018, 3, 28)), {})
    assert GeneralLedger(DateRange(), {Account("123456") : Ledger(Account("123456"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(10))))}) != GeneralLedger(DateRange(), {})
    assert GeneralLedger(DateRange(), {}) == GeneralLedger(DateRange(), {Account("123456") : Ledger(Account("123456"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(10))))})

# Generated at 2022-06-24 01:07:20.195135
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Unit test for method __repr__ of class LedgerEntry.
    """
    account = Account("1110")
    ledger = Ledger(account, Balance(datetime.date(2019, 12, 31), Quantity(0)))
    entry = LedgerEntry(
        ledger, Posting(datetime.date(2020, 1, 31), JournalEntry(["test"]), account, Quantity(0), False), Quantity(0),
    )
    assert repr(entry) == "LedgerEntry(date=2020-01-31, description='test', debit=Decimal('0'), credit=Decimal('0'))"

## Unit test for method __repr__ of class Ledger

# Generated at 2022-06-24 01:07:30.667734
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 01:07:40.985032
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from datetime import date
    from ..accounts.universe import Universe
    from .journaling import JournalEntry

    # Decimal contexts
    unrounded = Decimal('1.223') ## Decimal('1.22299999999999999876626539767121791839599609375')
    rounded = Decimal('1.23')

    # General ledger
    period = DateRange(date(2015, 12, 1), date(2015, 12, 31))
    journal = [JournalEntry(date(2015, 12, 1), Decimal(1.2), Account.ASSETS_BANK_ACCOUNTS_CURRENT_ASSETS, 'Test Journal Entry', [])]
    initial = {Account.ASSETS_BANK_ACCOUNTS_CURRENT_ASSETS: Balance(date(2015, 11, 30), unrounded)}
    general_ledger