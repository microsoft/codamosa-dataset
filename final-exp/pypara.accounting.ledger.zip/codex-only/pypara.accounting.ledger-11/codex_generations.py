

# Generated at 2022-06-24 00:57:43.612973
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    a = GeneralLedger(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)), {1: None})
    b = GeneralLedger(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)), {1: None})
    assert a == b


# Generated at 2022-06-24 00:57:54.068182
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import compile_journal_program

    journal_program = compile_journal_program()

    initial_balances = {Account("A0"): Balance(datetime.date(2020, 1, 1), Quantity(0)),
                        Account("A1"): Balance(datetime.date(2020, 1, 1), Quantity(0))
                        }

# Generated at 2022-06-24 00:58:03.349327
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account, AccountName
    from .journaling import JournalEntry, Journal, Posting, Direction, Amount

    account = Account(AccountName("Cash"))
    journal = Journal("TestJournalEntry")
    posting = Posting(journal, account, Direction.DEBIT, Amount(10))
    initial_balance = Balance(datetime.date(2019, 1, 1), Quantity(20))
    entry = LedgerEntry(Ledger(account, initial_balance), posting, posting.amount)

    assert entry.posting.account == account
    assert entry.balance == posting.amount


# Generated at 2022-06-24 00:58:14.395085
# Unit test for constructor of class GeneralLedger

# Generated at 2022-06-24 00:58:15.056839
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # My code
    pass

# Generated at 2022-06-24 00:58:24.451874
# Unit test for method add of class Ledger
def test_Ledger_add():
	# Test data 1
	# Test account
	accountName = 'Test Account'
	testAccount = Account(accountName, 'Test account')
	# Test initial balance
	testBalance = Balance('2019-01-01', 100)
	# Test ledger
	testLedger = Ledger(testAccount, testBalance)
	# Test journal entry
	description = 'A test journal entry'
	journalEntry = JournalEntry(description)
	# Test posting
	posting = Posting(journalEntry, 'Test account', '2019-01-01', -100, 'Test program', 'Test transaction')
	testLedger.add(posting)
	assert(testLedger.entries[0].posting == posting)
	assert(testLedger.entries[0].balance == 100)

# Generated at 2022-06-24 00:58:27.518419
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger = Ledger(Account("GPL","Activo"),Balance(datetime.date.today(), Amount(20)))
    expected = Ledger(Account("GPL", "Activo"), Balance(datetime.date.today(), Amount(20)))
    assert ledger == expected


# Generated at 2022-06-24 00:58:37.666915
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 00:58:47.675238
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgerview.types import AccountLedger  # special on purpose

    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

# Generated at 2022-06-24 00:58:53.957890
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest.mock import MagicMock

    alg = MagicMock(spec=ReadInitialBalances)
    alg.return_value = {
        1: Balance(date(2018, 1, 1), Decimal(0)),
        2: Balance(date(2018, 1, 1), Decimal(0)),
        3: Balance(date(2018, 1, 1), Decimal(0)),
    }
    alg(date(2018, 1, 1))
    alg.assert_called_once_with(date(2018, 1, 1))


# Generated at 2022-06-24 00:58:54.864659
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 00:59:01.996358
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from ..journaling.mem import InMemoryJournalEntryRepository

    journal_repo= InMemoryJournalEntryRepository()
    journal_repo.register(JournalEntry([Posting(DateRange(datetime.date(2020,5,5), datetime.date(2020,5,5)), '', '', '', Amount(Decimal(10.0)))]))
    journal_repo.register(JournalEntry([Posting(DateRange(datetime.date(2020,5,10), datetime.date(2020,5,10)), '', '', '', Amount(Decimal(10.0)))]))

# Generated at 2022-06-24 00:59:06.064910
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert compile_general_ledger_program(lambda *_: {}, lambda *_: [])

# Generated at 2022-06-24 00:59:15.469356
# Unit test for method __eq__ of class Ledger

# Generated at 2022-06-24 00:59:26.555270
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # type: () -> None
    import copy
    import random, string
    
    # Case 1:
    account = Account("1")
    initial = Balance(datetime.date(2019, 1, 1), Quantity(Decimal(1)))
    entries = [
        LedgerEntry(account, Posting(datetime.date(2019, 1, 1), Quantity(Decimal(2))), Quantity(Decimal(3))),
        LedgerEntry(account, Posting(datetime.date(2019, 1, 1), Quantity(Decimal(4))), Quantity(Decimal(5))),
    ]
    obj = Ledger(account, initial)
    obj.entries = copy.deepcopy(entries)

    # obj equals to itself
    assert obj == obj

    # obj equals to a new instance with same properties
    assert obj == Ledger

# Generated at 2022-06-24 00:59:36.701522
# Unit test for method __call__ of class ReadInitialBalances

# Generated at 2022-06-24 00:59:47.041269
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account1 = Account('Assets', 'Cash', 'Cash at the bank')
    amount1 = Amount(500, 0)
    account2 = Account('Revenue', 'Service Revenue', 'Service Revenue')
    amount2 = Amount(500, 0)
    description1 = 'Deposit'
    posting1 = Posting(account1, amount1, description1, False)
    posting2 = Posting(account2, amount2, description1, False)
    journal1 = JournalEntry(posting1, posting2)
    journal2 = JournalEntry(posting2, posting1)
    date1 = datetime.date.today()
    date2 = datetime.date.today()
    ledger1 = Ledger(account1, Balance(date1, amount1))
    posting1.journal = journal1

# Generated at 2022-06-24 00:59:50.565449
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass


# Generated at 2022-06-24 00:59:53.984145
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class _ReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            print("read initial balances for", period)
            return {}
    read_initial_balances = _ReadInitialBalances()
    return read_initial_balances


# Generated at 2022-06-24 00:59:58.825526
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("Test Account")
    opening = Balance(date=datetime.date(2019, 1, 1), value=Quantity(Decimal(100)))
    entries = []
    ledger = Ledger(account, opening, entries)
    assert ledger
    assert ledger.account == account
    assert ledger.entries == []

# Generated at 2022-06-24 01:00:00.282674
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert(repr(GeneralLedger(None, None)) == "GeneralLedger(period=None, ledgers={})")



# Generated at 2022-06-24 01:00:11.064944
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from io import StringIO

    from ..commons.zeitgeist import DateRange

    from .accounts import AccountCode

    from .trialmaker import TrialMaker

    ## Create buffer and write trial balances as of 2018-12-31:
    buff = StringIO()
    print(
        "AccountCode,AccountType,AccountName,InitialDate,InitialBalance,FinalDate,FinalBalance",
        file=buff,
    )

# Generated at 2022-06-24 01:00:22.459680
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Unit test for constructor of class GeneralLedgerProgram
    """
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return initial_balances

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return journal_entries

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    initial_balances = {Account("A"): Balance(datetime.date(2018, 12, 31), Quantity(Decimal(1)))}

# Generated at 2022-06-24 01:00:30.413941
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Asset
    from .journaling import Journal, Debit, Credit, Posting
    from .generic import Balance
    from datetime import date
    ledger = Ledger(Asset("AnAsset", []), Balance(date(2020, 4, 1), Quantity(0)))
    journal = Journal([Posting(date(2020, 5, 1), Debit("AnAsset",100)), Posting(date(2020, 5, 1), Credit("AnExpense",100))])
    ledger.add(Posting(date(2020, 5, 1), Debit("AnAsset",100)))
    assert ledger.entries[0]._last_balance == 0
    assert ledger.entries[0].date == date(2020, 5, 1)
    assert ledger.entries[0].is_debit == True
    assert ledger.entries[0].is_

# Generated at 2022-06-24 01:00:30.988000
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__(): pass

# Generated at 2022-06-24 01:00:38.247044
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    test_account = Account(account_type='Assets', currency='USD')
    test_balance = Balance(date= datetime.date(2020, 1, 1), value = 1.0)
    test_ledger_1 = Ledger(account = test_account, initial = test_balance)
    test_ledger_2 = Ledger(account = test_account, initial = test_balance)
    assert test_ledger_1 == test_ledger_2

# Generated at 2022-06-24 01:00:48.529646
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class ReadBalances:
        pass

    @dataclass
    class ReadJournal:
        pass

    from dataclasses_jsonschema import ValidationError
    from .journaling import JournalEntry, Posting

    import pytest

    period = DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2019, 1, 1))
    balances = {"101": Balance(period.since, Quantity(Decimal("101.00")))}
    journal = [JournalEntry("101.00", [Posting("101", "101.00", 1)])]

# Generated at 2022-06-24 01:00:54.109313
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    def f1(x1):
        return 1
    def f2(x2):
        return 2
    _compile_general_ledger_program = compile_general_ledger_program(f1,f2)
    assert _compile_general_ledger_program(1)==1

# Generated at 2022-06-24 01:01:05.565036
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 01:01:17.364721
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Journal, Posting
    from .accounts import Account

    j = Journal("Test")
    a = Account("Test")
    p = Posting(a, j, Decimal("1.0"), "debit")
    l = Ledger(a, Balance(datetime.datetime.now(), Quantity(Decimal("0"))))
    le = LedgerEntry(l, p, Quantity(Decimal("1.0")))

    assert le.debit == Decimal("1.0")
    assert le.credit == None
    assert le.amount == Decimal("1.0")
    assert le.is_debit
    assert not le.is_credit
    assert le.date == p.date
    assert le.ledger == l
    assert le.posting == p

# Generated at 2022-06-24 01:01:18.766453
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:01:19.908203
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass



# Generated at 2022-06-24 01:01:26.566835
# Unit test for constructor of class Ledger
def test_Ledger():
    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, Posting
    from datetime import date
    from decimal import Decimal

    a = Account("1234","Assets","Test")
    b = Balance(date.today, Quantity(Decimal(1)))
    l = Ledger[str](a,b)
    l.add(Posting(a,Journal("1234","Test","Test")))
    return l



# Generated at 2022-06-24 01:01:30.378819
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Given
    test_LedgerEntry = LedgerEntry(0,0,0)
    test_LedgerEntry2 = LedgerEntry(0,0,0)

    # When
    result = test_LedgerEntry.__eq__(test_LedgerEntry2)

    # Then
    assert result == True
    
    

# Generated at 2022-06-24 01:01:36.724994
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ##########################
    # Unit test for function build_general_ledger

    from dataclasses import dataclass, field
    from datetime import date
    import decimal
    from typing import Dict, List, Optional
    from unittest import TestCase
    from collections import namedtuple


    from financial_accounting.commons.numbers import Amount, Quantity

    from financial_accounting.ledgers.accounts import Account, TerminalAccount

    from financial_accounting.ledgers.journaling import Journal, Posting

    from financial_accounting.ledgers.generic import Balance

    @dataclass
    class ReadInitialBalancesMock(object):
        """
        Read initial balances mock.
        """

        def __init__(self):
            self.count = 0
            self.dates = list()

# Generated at 2022-06-24 01:01:43.179967
# Unit test for method add of class Ledger
def test_Ledger_add():
    Account1 = Account('11', '1')
    Account2 = Account('22', '1')
    Account3 = Account('33', '1')
    Account4 = Account('44', '1')
    Account5 = Account('55', '1')
    Account6 = Account('66', '1')
    Account7 = Account('77', '1')
    Account8 = Account('88', '1')
    Account9 = Account('99', '1')
    Account10 = Account('100', '1')

    """
    Test case 1
    """
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(Account1, initial)
    posting1 = Posting(datetime.date(2020, 1, 2), Account1, 1, Quantity(Decimal(10)))
   

# Generated at 2022-06-24 01:01:48.591547
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(Account(1000), Balance(datetime.date(2019, 1, 1), Quantity(1)))) == \
    "Ledger(account=Account(number=1000, name='<unnamed>'), initial=Balance(account=Account(number=1000, name='<unnamed>'), date=datetime.date(2019, 1, 1), value=1))"


# Generated at 2022-06-24 01:01:56.866209
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Create instances of LedgerEntry to test
    # Change the below according to the __init__ parameters of the class
    account1 = Account(number=1, name="account1", account_type="Expense")
    balance1 = Balance(quantity=Decimal(1.11))
    amount1 = Amount(Decimal(1.11))
    posting1 = Posting(account=account1, amount=amount1, direction=Direction.Debit)
    ledger1 = Ledger(account=account1, initial=balance1)
    ledger_entry1 = LedgerEntry(ledger=ledger1, posting=posting1, balance=balance1.value)
    ledger_entry2 = LedgerEntry(ledger=ledger1, posting=posting1, balance=Decimal(2.22))

# Generated at 2022-06-24 01:02:08.472226
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Setup
    ledger = Ledger(Account("TEST-ACCOUNT"), Balance(datetime.date.today(), Decimal("123.45")))
    posting = Posting("TEST-JOURNAL", ledger.account, datetime.date.today(), Decimal("123.45"))
    entry = LedgerEntry(ledger, posting, Decimal("123.45"))

    # Test
    # Check if base case is equal
    assert entry == entry
    # Check if None is not equal
    assert entry != None
    # Check if two LedgerEntry instances are equal
    assert entry == LedgerEntry(ledger, posting, Decimal("123.45"))
    # Verify if LedgerEntry instance is not equal if list of ledger entries is different
    assert entry != LedgerEntry(ledger, posting, Decimal("534.32"))
    #

# Generated at 2022-06-24 01:02:14.074525
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # It should return properly formatted string
    assert (
        repr(Ledger(account=Account("1234"), initial=Balance(date=datetime.date(2020, 1, 1),value=Decimal(100),)))
        == "Ledger(account=Account('1234'), initial=Balance(date=datetime.date(2020, 1, 1), value=Decimal('100')))"
    )

# Generated at 2022-06-24 01:02:24.391595
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..commons.journaling import Journal
    from datetime import date
    from .accounts import Account, AccountType, create_account

    entry_1 = LedgerEntry(Ledger(Account(AccountType.ASSETS, 'Cash'), Balance(date(2020, 1, 1), Quantity(Decimal(0)))), Posting(Journal('transaction', date(2020, 1, 1))), Quantity(Decimal(10)))
    entry_2 = LedgerEntry(Ledger(Account(AccountType.ASSETS, 'Cash'), Balance(date(2020, 1, 1), Quantity(Decimal(0)))), Posting(Journal('transaction', date(2020, 1, 1))), Quantity(Decimal(10)))


# Generated at 2022-06-24 01:02:27.055923
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class TestInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("a") : Balance(period.since, Quantity(0))}


# Generated at 2022-06-24 01:02:30.601632
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(account=Account(symbol="1010", name="Bank"),initial=Balance(date=datetime.date(2020,1,1), value=Quantity(Decimal(10))))) == '<Ledger>'

# Generated at 2022-06-24 01:02:42.022896
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(account=Account('a', name='Test Account'), initial=Balance(datetime.date(2020, 1, 1), Quantity(0)))
    posting = Posting(datetime.date(2020, 2, 1), Quantity(5), Account('a', name='Test Account'), Account('b', name='Test Account'))
    ledgerentry = ledger.add(posting)
    assert ledgerentry.balance == Quantity(5)
    assert ledgerentry.posting == posting
    assert ledgerentry.ledger == ledger
    assert ledgerentry.date == posting.date
    assert ledgerentry.description == posting.journal.description
    assert ledgerentry.amount == posting.amount
    assert ledgerentry.cntraccts[0] == posting.journal.postings[1].account
    assert ledgerentry.is_debit
    assert ledgerentry.is_

# Generated at 2022-06-24 01:02:47.847025
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("account", "title")
    balance = Balance("balance", "date", "value")
    l = Ledger(account, balance)
    assert l.account == account
    assert l.initial.value == balance.value

# Generated at 2022-06-24 01:02:49.151875
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # TODO: Implement test using objects passed to compile_general_ledger_program
    return

# Generated at 2022-06-24 01:02:49.605736
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass

# Generated at 2022-06-24 01:02:55.002346
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def _read_initial_balances() -> InitialBalances:
        return {
            "1111": Balance(datetime.date(2020, 1, 1), Quantity(Decimal(1))),
            "2222": Balance(datetime.date(2020, 1, 1), Quantity(Decimal(2))),
        }


# Generated at 2022-06-24 01:03:01.114126
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from decimal import Decimal
    import pytest
    from .accounts import BankAccount
    from .journaling import Journal

    # Test data
    accounts: Dict[Account, Balance] = {
        BankAccount("Cash", "Assets"): Balance(date(2019, 12, 31), Decimal(10_000))
    }

    # Test mocking
    def _read_initial_balances(period):
        return accounts

    def _read_journal_entries(period):
        return [Journal(date(2020, 1, 1), "Test Journal").post(1, BankAccount("Cash", "Assets"))]

    # Compile program and execute test
    glp = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

# Generated at 2022-06-24 01:03:07.888420
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    dummy_ledger = 'dummy_ledger'
    dummy_posting = 'dummy_posting'
    dummy_balance = 'dummy_balance'
    ledger = LedgerEntry(dummy_ledger, dummy_posting, dummy_balance)
    assert ledger.__repr__() == \
        "LedgerEntry(ledger='dummy_ledger', posting='dummy_posting', balance='dummy_balance')"

# Generated at 2022-06-24 01:03:15.391303
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . import unittest

# Generated at 2022-06-24 01:03:16.057563
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-24 01:03:17.635038
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from . import ReadInitialBalances
    return ReadInitialBalances()
    

# Generated at 2022-06-24 01:03:26.797988
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    read_initial_balances = lambda x: {"A": Balance(x.since, Decimal(100))}
    read_journal_entries = lambda x: [
        JournalEntry(
            x.since,
            "Journal 1",
            [
                Posting(x.since, "A", Decimal(2.5), "B", Decimal(2.5)),
                Posting(x.since, "B", Decimal(2.5), "A", Decimal(2.5)),
            ],
        )
    ]

    compile_general_ledger_program(read_initial_balances, read_journal_entries)(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1)))

# Generated at 2022-06-24 01:03:31.178886
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange("2020-01-01", "2020-04-30")
    journal = []
    initial = {}
    general_ledger = build_general_ledger(period, journal, initial)
    assert general_ledger.period == period
    assert general_ledger.ledgers == {}


# Generated at 2022-06-24 01:03:41.280732
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest import TestCase
    from datetime import date
    from collections import defaultdict
    from typing import Dict

    from ..commons.zeitgeist import DateRange

    from .accounts import Account
    from .generic import Balance
    from .journaling import Direction, Posting, JournalEntry


# Generated at 2022-06-24 01:03:49.048687
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():

    # Defining test inputs
    entry = LedgerEntry(Ledger(Account('1'), Balance(datetime.date(2019, 4, 12), Quantity(Decimal(1000.00)))), Posting(JournalEntry(datetime.date(2019, 4, 13), 'test', [Posting(Account('1'), Quantity(Decimal(100.00))), Posting(Account('2'), Quantity(Decimal(-100.00)))]), Account('1'), Quantity(Decimal(100.00)), +1, 'test'), Quantity(Decimal(1100.00)))

    # Call method under test
    retVal = entry.__repr__()

    # Assert output

# Generated at 2022-06-24 01:03:54.048322
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    #Arrange
    posting = Posting(datetime.date(2016, 6, 21), False, Quantity(Decimal(100)), 'Repair')
    posting2 = Posting(datetime.date(2016, 6, 21), False, Quantity(Decimal(100)), 'Repair')
    posting3 = Posting(datetime.date(2016, 6, 21), True, Quantity(Decimal(100)), 'Repair')
    ledger = Ledger('12345', Balance(datetime.date(2016,6,1), Quantity(Decimal(1000))))
    ledger.add(posting)
    entry = LedgerEntry(ledger, posting, Quantity(Decimal(2000)))
    #Act
    actual = (entry == posting)
    #Assert
    assert actual == False

# Generated at 2022-06-24 01:03:56.297509
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Equals operator with equal objects
    assert LedgerEntry(None, None, None) == LedgerEntry(None, None, None)


# Generated at 2022-06-24 01:04:07.425448
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from ..bookkeeper.journaling import Posting
    from doctest import testmod
    from .accounts import Account, AccountType, Asset, Equity, Liability


# Generated at 2022-06-24 01:04:14.963262
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .accounts import AccountType

    read_initial_balances = lambda period: {Account("A", AccountType.TERMINAL): Balance(period.since, Amount(Decimal(1)))}

    assert read_initial_balances(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))) == {Account("A", AccountType.TERMINAL): Balance(datetime.date(2019, 1, 1), Amount(Decimal(1)))}


# Generated at 2022-06-24 01:04:18.272300
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Test 1:
    l = Ledger(Account('100', 'John'), Balance(datetime.date(2020, 1, 1), Quantity(10)))
    assert l.__repr__() == "Ledger(account='100', initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(10)))"

# Generated at 2022-06-24 01:04:18.987493
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:04:25.840932
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("000001", "Cash", True)
    test_initial_balance = Balance("2019-01-01", Quantity(Decimal("100.00")))
    test_ledger_entry = LedgerEntry("000001", Posting("01/01/2019", "Journal Entry 01", Quantity(Decimal("50.00"))), Quantity(Decimal("150.00")))
    test_ledger = Ledger(account, test_initial_balance, test_ledger_entry)
    assert test_ledger.account == account
    assert test_ledger.initial == test_initial_balance
    assert test_ledger.entries == test_ledger_entry
    assert test_ledger._last_balance == Quantity(Decimal("150.00"))
    

# Generated at 2022-06-24 01:04:29.161381
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert str(Ledger('Account', 'Initial')) == "Ledger(account='Account', initial='Initial', entries=[(0, 0)])"


# Generated at 2022-06-24 01:04:39.235868
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    ## Mocks:
    @dataclass
    class MockInitialBalances:
        """
        Provides a mock for initial balances.
        """

        #: Accounting period.
        period: DateRange

        #: Initial balances dictionary.
        initial_balances: InitialBalances

        def __call__(self, period: DateRange) -> InitialBalances:
            """
            Returns the initial balances dictionary.
            """
            return self.initial_balances

    @dataclass
    class MockJournalEntries:
        """
        Provides a mock for journal entries.
        """

        #: Accounting period.
        period: DateRange

        #: Journal entries list.
        journal_entries: List[JournalEntry[_T]]


# Generated at 2022-06-24 01:04:43.569064
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("1234", "Sales", "1234")
    initial = Balance(datetime.date(2020,1,1), Quantity(Decimal(0)))
    entries = list()
    l = Ledger(account, initial, entries)
    assert l.account == account
    assert l.initial == initial
    assert l.entries == entries


# Generated at 2022-06-24 01:04:46.838263
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account("1010", "Assets")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal("10")))
    ledger1 = Ledger(account, initial)
    ledger2 = Ledger(account, initial)
    assert ledger1 == ledger2


# Generated at 2022-06-24 01:04:56.160743
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # Initializing objects.
    a1 = Account(code="a1", name="a1")
    a2 = Account(code="a2", name="a2")
    j1 = JournalEntry("j1", balance="", description="j1")
    j2 = JournalEntry("j2", balance="", description="j2")
    j3 = JournalEntry("j3", balance="", description="j3")
    j4 = JournalEntry("j4", balance="", description="j4")
    j5 = JournalEntry("j5", balance="", description="j5")
    p1 = Posting(j1, a1, "", "", 1, 0)
    p2 = Posting(j2, a1, "", "", 2, 0)

# Generated at 2022-06-24 01:05:00.418958
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    example_1 = LedgerEntry(1, 2, 3)
    assert example_1.ledger == 1
    assert example_1.posting == 2
    assert example_1.balance == 3
    assert isinstance(example_1.balance, Quantity)

# Generated at 2022-06-24 01:05:11.556280
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import build_journal_entry
    from .transactions import build_receipt, build_sales_invoice

    from .accounts import ACCT_CASH_IN_HAND, ACCT_CREDITORS, ACCT_REVENUE, ACCT_TRADE_DEBTORS

    from ..commons.zeitgeist import DateRangeFactory, now


# Generated at 2022-06-24 01:05:13.924171
# Unit test for constructor of class Ledger
def test_Ledger():
    assert Ledger(None, None) == Ledger(None, None)

# Generated at 2022-06-24 01:05:19.983773
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..algebra.generic import ReadBalance

    class Algebra(ReadBalance):
        @staticmethod
        def get_balance(period: DateRange) -> Decimal:
            return Decimal(1)

    program = compile_general_ledger_program(Algebra.get_balance, Algebra.get_balance)
    gl = program(DateRange(datetime.date(2012,1,1), datetime.date(2012,1,31)))
    assert gl.initial == Decimal(1)

# Generated at 2022-06-24 01:05:29.418828
# Unit test for constructor of class LedgerEntry

# Generated at 2022-06-24 01:05:40.502076
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..algebra.posting import GetInitialBalances, RecordJournalEntry
    from ..commons.zeitgeist import Date
    from .accounts import Account, AssetAccount, ExpenseAccount, LiabilityAccount
    from .journaling import Journal, Posting

    read_initial_balances = GetInitialBalances()
    read_journal_entries = RecordJournalEntry().as_journal_entries()
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Define the accounts and open them:
    a = Account("A", Account.AccountType.ASSET)
    b = Account("B", Account.AccountType.LIABILITY)
    c = Account("C", Account.AccountType.EXPENSE)
    d = Account("D", Account.AccountType.INCOME)
   

# Generated at 2022-06-24 01:05:48.502441
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Arrange
    posting = Posting(DateRange(datetime.date(2020, 4, 15), datetime.date(2020, 4, 15)), 1, Decimal(1), "Test", Decimal(2), 1)
    ledger = Ledger(Account(1), Balance(datetime.date(2020, 4, 15), Decimal(0)))
    # Act
    entry = ledger.add(posting)
    # Assert
    assert entry.posting == posting
    assert entry.balance == Decimal(1)
    assert entry.ledger == ledger
    assert ledger.entries[0] == entry



# Generated at 2022-06-24 01:05:49.872580
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    assert issubclass(GeneralLedgerProgram, Protocol)
    return True

# Generated at 2022-06-24 01:05:52.983753
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger
    """

    a = Ledger(None, None)
    a.add(None)
    assert(a.entries[0].balance > 0)


# Generated at 2022-06-24 01:06:04.477979
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    testAccount = Account(name="Test", number=1234, kind="Expense")
    testBalance = Balance(date=datetime.date(2020, 4, 15), value=1)
    testJournalEntry = JournalEntry(period=DateRange(since=datetime.date(2020, 4, 15), until=datetime.date(2020, 4, 15)), description="Testing Journal Entry")
    testPosting = Posting(journal_entry=testJournalEntry, account=testAccount, amount=1)
    testLedger = Ledger(account=testAccount, initial=Balance(date=datetime.date(2020, 4, 15), value=0))

    # Test GeneralLedger(...)
    testLedgerEntry = LedgerEntry(ledger=testLedger, posting=testPosting, balance=1)

    assert testLedgerEntry.date == dat

# Generated at 2022-06-24 01:06:12.272094
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    period = DateRange(date(2017, 1, 1), date(2017, 3, 31))

# Generated at 2022-06-24 01:06:13.736500
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances.__doc__ is not None


# Generated at 2022-06-24 01:06:21.814345
# Unit test for function build_general_ledger
def test_build_general_ledger():

    from ..commons.zeitgeist import Date
    from . import accounts
    from .journaling import Journal
    from .companies import Company
    from .currencies import Currency

    from collections import namedtuple
    from decimal import Decimal

    company = Company("Test Company", Currency("TST"))
    asset = accounts.build_func_account("Assets", 21000, "Assets", company)
    bank = accounts.build_func_account("Bank", 21010, "Assets", company, parent=asset)
    bank_usd = accounts.build_leaf_account("USD", 21100, "Cash", company, parent=bank)
    bank_eur = accounts.build_leaf_account("EUR", 21200, "Cash", company, parent=bank)

# Generated at 2022-06-24 01:06:28.632713
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(0, "asset")
    initial_balance = Balance(datetime.date(2020, 1, 31), Quantity(Decimal(1000)))
    
    ledger = Ledger(account, initial_balance)
    journal = JournalEntry(datetime.date(2020, 2, 1), "description", '')
    posting1 = Posting(journal, account, Quantity(Decimal(100)), '')
    
    assert ledger.add(posting1).balance == 1100
    assert ledger.add(posting1).balance == 1200

# Generated at 2022-06-24 01:06:37.234459
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account("1110","AARON")
    b = Balance("20/02/2020",50)
    l1 = Ledger(a,b)
    l2 = Ledger(a,b,[])

    assert l1.account == l2.account
    assert l1.initial == l2.initial
    assert l1.entries == l2.entries

    assert l1.account == a
    assert l1.initial == b
    assert l1.entries == []



# Generated at 2022-06-24 01:06:38.165427
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert Ledger.__repr__


# Generated at 2022-06-24 01:06:41.477055
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
  entry1 = LedgerEntry(None, Posting(None, None, None, None), None)
  entry2 = LedgerEntry(None, Posting(None, None, None, None), None)

  assert(entry1 == entry2)

# Generated at 2022-06-24 01:06:50.492902
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account

    # Create an account.
    account = Account(1, "test account", True)

    # Create a Balance.
    balance = Balance(datetime.date(2020, 12, 31), Quantity(1))

    # Create the ledger.
    ledger = Ledger(account, balance)

    # Create a journal entry.
    from ..commons.zeitgeist import now
    from .journaling import Journal, Posting

    journal = Journal(now(), "test journal", [])

    posting = Posting(journal, account, Quantity(1), "")

    # Entry are created from posting to the ledger
    entry = ledger.add(posting)

    # Check that the ledger contain exactly one entry.
    assert ledger.entries.__len__() == 1

    # Check that the date of the ledger entry is the journal date

# Generated at 2022-06-24 01:07:00.437684
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from datetime import date
    from ..commons.numbers import Decimal
    from .accounts import Account, AccountType
    from .journaling import JournalEntry

    # Setup
    period = DateRange(date(2016, 1, 1), date(2016, 12, 31))
    read_initial_balances = lambda p: {
        Account("01000"): Balance(date(2015, 12, 31), Decimal(1000))
    }
    read_journal_entries = lambda p: [
        JournalEntry(
            date(2016, 1, 1), "Plan de cuentas",
            [Posting(Account("01000", AccountType.ASSET), Decimal(1000), "Cargo"),
             Posting(Account("10000", AccountType.CAPITAL), Decimal(1000), "Abono")]
        ),
    ]
   

# Generated at 2022-06-24 01:07:08.393136
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..business.accounts import Client, Income, OfficeSupplies, WagesPayable
    from ..business.usecases.journaling import SalesJournal, PurchasesJournal
    from ..business.usecases.journaling import AccountsPayableJournal, AccountsReceivableJournal
    from ..business.usecases.journaling import GeneralJournal, GeneralLedgerProgram, ReadInitialBalances, GeneralLedger
    from ..commons.zeitgeist import Date, DateRange

    from .accounts import Account

    # Set initial balances:

# Generated at 2022-06-24 01:07:12.860915
# Unit test for constructor of class Ledger
def test_Ledger():
    serial_number=3
    account = Account(serial_number)
    pro_balance = Balance(date=datetime.date(2020, 4, 30), value=Decimal(30))
    ledger = Ledger(account, pro_balance)

    assert ledger.account == account
    assert ledger.initial == pro_balance
    assert ledger.entries == []


# Generated at 2022-06-24 01:07:23.773802
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..commons.zeitgeist import today
    from .accounts import Account, AccountType
    from .journaling import Journal, JournalEntry, Posting, Unit
    from .inventory import InventoryItem

    InventoryItem(
        "testItem", "testItem", Unit.EA, Decimal(105), Decimal(5), Decimal(100), Decimal(20), Decimal(15), Decimal(10)
    )

    test_account = Account("testAccount1", AccountType.ASSET)


# Generated at 2022-06-24 01:07:32.994123
# Unit test for function build_general_ledger
def test_build_general_ledger():
    def _assert_equal(r: LedgerEntry, e: LedgerEntry):
        assert r.balance == e.balance

    from decimal import Decimal
    import pytest

    from ..commons.numbers import Amount
    from .accounts import Account, RootAccount
    from .journaling import Journal

    account_food = Account(RootAccount, "food")
    account_soft = Account(RootAccount, "soft")
    account_grocery = Account(account_food, "grocery")
    account_soda = Account(account_soft, "soda")
    journal_grocery = Journal(0, datetime.date(2020, 8, 1), "grocery", [Posting(account_grocery, Amount(Decimal(300)))])

# Generated at 2022-06-24 01:07:42.101788
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import Date, DateRange
    from .accounts import Account, read_accounts
    from .journaling import Journal, Posting, JournalEntry, read_journal_entries
    from .documents import Document, DocumentEntry
    from .transactions import Transaction
    from .records import Record
    from .trivial import trivial_initial_balances, trivial_journal_entries

    # Prepare the test data:
    account_chart = read_accounts(trivial_account_chart)
    initial_balances = trivial_initial_balances()
    journal = trivial_journal_entries()

    # Compile the program:
    program = compile_general_ledger_program(initial_balances, journal)

    # Run the program: