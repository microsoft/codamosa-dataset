

# Generated at 2022-06-26 00:31:04.682539
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Expecting to fail; uncommenting this would result in a TypeError:
    # result = compile_general_ledger_program()(datetime.datetime.now())
    pass


# Generated at 2022-06-26 00:31:09.751395
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    account_0 = module_0.Account()
    general_ledger_program_0 = compile_general_ledger_program()
    general_ledger_0 = general_ledger_program_0
    assert general_ledger_0 == general_ledger_0
    assert general_ledger_0 is general_ledger_0

# Generated at 2022-06-26 00:31:16.084870
# Unit test for method add of class Ledger
def test_Ledger_add():
    initial = Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0)))
    journal_entry_0 = JournalEntry(datetime.date(2019, 1, 1), '', [Posting(module_0.Account(), Quantity(Decimal(0)), None)])
    entry = Ledger(module_0.Account(), initial).add(journal_entry_0.postings[0])
    assert entry.amount == Quantity(Decimal(0))
    assert entry.balance == Quantity(Decimal(0))


# Generated at 2022-06-26 00:31:25.864545
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = module_0.Account()
    Balance_0 = Balance()
    Ledger_0 = Ledger(account_0, Balance_0, list())
    Posting_0 = Posting(account_0, Decimal(0))
    Ledger_0.add(Posting_0)
        # AssertionError: LedgerEntry(ledger=Ledger(account=<pypara.accounting.accounts.Account object at 0x000001F2E946E808>, initial=Balance(date=datetime.date(1, 1, 1), value=0), entries=[]), posting=Posting(account=<pypara.accounting.accounts.Account object at 0x000001F2E946E808>, amount=Decimal('0')), balance=0) != LedgerEntry(ledger=Ledger(

# Generated at 2022-06-26 00:31:30.194635
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Example of a Test Case
    account_0 = module_0.Account()
    journal_entry_0 = JournalEntry({'0': account_0})
    period_0 = DateRange('2015-01-01', '2015-01-01')
    initial_0 = {account_0: Balance(period_0, Quantity(0))}


# Generated at 2022-06-26 00:31:40.456407
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import pytest
    from pypara.accounting.accounts import Account, Filter, Node
    from pypara.accounting.ledgering.generic import Balance, BalanceType
    from pypara.accounting.ledgering.journaling import Identifier, Journal, JournalEntry, Posting, Direction
    from pypara.commons.numbers import Amount, Quantity
    from pypara.commons.zeitgeist import DateRange

    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        initial_balances: Dict[Account, Balance] = {}
        initial_balances[account_0] = Balance(period.since, Quantity(0))
        return initial_balances

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        yield journal_entry

# Generated at 2022-06-26 00:31:49.850986
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import datetime

    balance_0 = Balance(datetime.date(1, 1, 1), Quantity(Decimal('0.000000000000000000')))
    account_0 = module_0.Account()
    read_initial_balances_0 = lambda arg_0:  {account_0: balance_0}
    read_journal_entries_0 = lambda arg_0:  []
    general_ledger_program_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    from ..commons.zeitgeist import since, until
    general_ledger_0 = general_ledger_program_0(since(datetime.date(1, 1, 1)) | until(datetime.date(1, 1, 1)))

# Generated at 2022-06-26 00:31:50.870200
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_case_0()

# Generated at 2022-06-26 00:31:55.175735
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class Class0:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    obj_0 = Class0()
    period_0 = DateRange(date(2020, 1, 1), date(2020, 12, 1))
    value_0 = obj_0.__call__(period_0)
    return locals()


# Generated at 2022-06-26 00:32:05.467156
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import pypara.accounting.journaling as module_0
    import datetime as module_1
    import pypara.commons.numbers as module_2
    import pypara.commons.zeitgeist as module_3

    dt_0 = module_1.datetime.date(2000,1,1)
    dt_1 = module_1.datetime.date(1999,12,1)
    dt_2 = module_1.datetime.date(1999,1,1)
    period_0 = module_3.DateRange(dt_0,dt_0)
    balance_0 = module_2.Balance(dt_1,module_2.Quantity(0))
    account_0 = module_0.Account()
    amount_0 = module_2.Amount(0)
    amount_1

# Generated at 2022-06-26 00:32:13.786249
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    iterable_0 = None
    dict_0 = {}
    var_0 = compile_general_ledger_program(dict_0, iterable_0)
    var_0(date_range_0)

# Generated at 2022-06-26 00:32:17.160708
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Tests for the case where __call__ will raise an exception.
    assert ReadInitialBalances.__call__() # exception expected
    # Tests for the case where __call__ will return a value.
    assert ReadInitialBalances.__call__() # exception expected

import pypara.accounting as module_1


# Generated at 2022-06-26 00:32:27.313815
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass
from typing import Iterable, Dict
import pypara.commons.numbers as module_0
import pypara.accounting.accounts as module_1
import pypara.accounting.journaling as module_2
_T = None

import pypara.accounting.generic as module_0
from typing import Dict, Optional
import pypara.accounting.journaling as module_0
_T = None
from typing import List
import pypara.commons.numbers as module_0
import datetime
from typing import Generic
import pypara.commons.zeitgeist as module_0
from dataclasses import dataclass, field
from typing import List


# Generated at 2022-06-26 00:32:34.827240
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = object()
    balance_0 = object()
    ledger_0 = Ledger(account_0, balance_0)
    posting_0 = object()
    var_1 = ledger_0.entries
    ledger_0.add(posting_0)
    var_0 = ledger_0.entries

    try:
        assert var_0 is not var_1
    except AssertionError:
        print("Test #0 failed")


# Generated at 2022-06-26 00:32:38.866905
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    iterable_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_0)

# Generated at 2022-06-26 00:32:41.761019
# Unit test for method add of class Ledger
def test_Ledger_add():
    period_0 = None
    journal_0 = None
    initial_0 = None
    var_1 = build_general_ledger(period_0, journal_0, initial_0)
    var_2 = var_1.ledgers
    var_3 = list(var_2.values())
    var_4 = 0
    var_5 = var_3[var_4]
    posting_0 = None
    var_6 = var_5.add(posting_0)
    var_7 = var_6.debit
    var_8 = var_6.credit


# Generated at 2022-06-26 00:32:43.677097
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Arguments:
    posting = None

    # Logic:
    pass
    return None


# Generated at 2022-06-26 00:32:49.028783
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def read_initial_balances(arg_0: DateRange) -> InitialBalances:
        pass
    def read_journal_entries(arg_0: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    var_0 = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    var_1 = None
    var_0(var_1)


# Generated at 2022-06-26 00:32:54.151776
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Initialization of mock object
    obj = ReadInitialBalances()
    # Initialization of test variables
    var_1 = module_0.DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 1))
    # Invoke method
    var_0 = obj(var_1)
    # Check result
    assert isinstance(var_0, dict)


# Generated at 2022-06-26 00:33:01.090545
# Unit test for method add of class Ledger
def test_Ledger_add():
    _T = TypeVar("_T")
    account_0 = Account(str(''), str(''))
    balance_0 = Balance(datetime.date(2020, 1, 1), Quantity(Decimal('0')))
    ledger_0 = Ledger(_T, account_0, balance_0)

    import pypara.journaling as module_0
    account_0 = Account(str(''), str(''))
    amount_0 = Amount(Decimal('0'))
    direction_0 = module_0.Direction.DEBIT
    journal_0 = JournalEntry(_T, datetime.date(2020, 1, 1), str(''))
    posting_0 = Posting(_T, account_0, amount_0, direction_0, journal_0)

# Generated at 2022-06-26 00:33:06.661683
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = DateRange(0, 0)
    var_1 = InitialBalances()
    var_2 = test_case_0()
    var_3 = DateRange(0, 0)
    var_4 = InitialBalances()
    var_5 = test_case_0()
    var_6 = DateRange(0, 0)
    var_7 = InitialBalances()
    var_8 = test_case_0()


# Generated at 2022-06-26 00:33:09.347771
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert compile_general_ledger_program(lambda var_0: var_0, lambda var_0: var_0)

# Generated at 2022-06-26 00:33:18.165023
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from dockerenv import Program
    from .accounts import Account, AccountType

    # arrange
    var_0: datetime.date = datetime.date(1998, 12, 12)
    var_1: datetime.date = datetime.date(1998, 12, 12)
    var_2 = (var_0, var_1)
    var_3: AccountType = object()
    var_4: str = "A.C.A. Account"
    var_5: Account = Account(var_3, var_4)
    var_6: Decimal = Decimal(0)
    var_7: datetime.date = datetime.date(1998, 12, 12)
    var_8: Balance = Balance(var_7, var_6)

# Generated at 2022-06-26 00:33:19.014004
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:33:20.334425
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    GeneralLedgerProgram.__call__(None, None)

# Generated at 2022-06-26 00:33:20.859427
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:33:28.904902
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry as _JournalEntry
    from .journaling import Posting as _Posting
    from .accounts import Account as _Account
    from .commons.zeitgeist import DateRange as _DateRange
    import datetime as _datetime
    _program = compile_general_ledger_program(test_case_0, test_case_0)
    _sut = _program
    var_0 = _DateRange(
        _datetime.date(2019, 12, 21), _datetime.date(2019, 12, 31),
    )
    _return_value = _sut(var_0)


# Generated at 2022-06-26 00:33:33.137880
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## String representation:
    assert str(build_general_ledger(None, None, None)) == "<GeneralLedger object>"

    ## Call without parameters:
    build_general_ledger(None, None, None)

    ## Call with parameters:
    build_general_ledger(None, None, None)


# Generated at 2022-06-26 00:33:34.696130
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances()
    var_1 = var_0.__call__()


# Generated at 2022-06-26 00:33:42.086601
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from hamcrest import assert_that, is_, has_property
    from collections import namedtuple
    from pytest import raises
    from .accounts import AccountType

    #---------------------------------------------------------------------------
    def test_case_0():
        class d_var_0(ReadInitialBalances):
            pass

        var_0 = object()
        class d_var_1(ReadJournalEntries[d_var_0]):
            pass

        var_1 = compile_general_ledger_program(d_var_0(), d_var_1())


# Generated at 2022-06-26 00:33:57.180642
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def f_0(
        period: DateRange
    ) -> InitialBalances:
        pass

    def f_1(
        period: DateRange
    ) -> Iterable[JournalEntry[object]]:
        pass

    var_3 = compile_general_ledger_program(f_0, f_1)


# Generated at 2022-06-26 00:33:58.509593
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ReadInitialBalances.__call__(object, object)


# Generated at 2022-06-26 00:34:01.463536
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """Method __call__ of class ReadInitialBalances"""
    obj = ReadInitialBalances()
    var_0 = obj(var_0)


# Generated at 2022-06-26 00:34:02.395161
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:34:08.367052
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    try:
        # Test case 0:
        print("Test case 0:", end="")

        # Function body:
        var_0 = object()
        var_1 = object()
        var_2 = compile_general_ledger_program(var_0, var_1)
        var_3 = var_2(var_1)

        # Output variables:
        print("Function body:", var_3)

        # Unit test result:
        assert True == True
        print("Ok.")
    except AssertionError as e:
        print("Failure:", e)
        raise e

# Generated at 2022-06-26 00:34:11.528492
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def read_initial_balances():
        pass
    def read_journal_entries():
        pass
    def program(arg_0):
        pass
    assert compile_general_ledger_program(read_initial_balances, read_journal_entries) == program

# Generated at 2022-06-26 00:34:20.685894
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = object()
    var_3 = object()
    var_4 = object()
    var_5 = object()
    var_6 = object()
    var_1 = build_general_ledger(var_0, var_0, var_0)
    var_2 = var_1.period
    var_7 = var_1.ledgers
    var_8 = var_7[var_3]
    var_9 = var_8.initial
    var_10 = var_9.date
    var_11 = var_9.value
    var_12 = var_8.entries
    var_13 = var_12[0]
    var_14 = var_13.ledger
    var_15 = var_13.posting
    var_16 = var_13.balance

# Generated at 2022-06-26 00:34:24.304107
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = object()
    ledger_0 = Ledger(var_0, var_0)
    var_1 = ledger_0.add(var_0)
    assert var_1 is not None


# Generated at 2022-06-26 00:34:26.798035
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = DateRange()
    var_1 = ReadInitialBalances()
    var_2 = var_1(var_0)
    return var_2


# Generated at 2022-06-26 00:34:27.702353
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    test_case_0()

# Generated at 2022-06-26 00:34:43.183521
# Unit test for function build_general_ledger
def test_build_general_ledger(): 
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = object()
    var_4 = object()
    var_5 = object()
    var_6 = object()
    var_7 = object()
    var_8 = object()
    var_9 = object()
    var_10 = object()
    var_11 = object()
    var_12 = object()
    var_13 = object()
    var_14 = object()
    var_15 = object()
    var_16 = object()
    var_17 = object()

    var_18 = build_general_ledger(var_0,var_1,var_2)
    var_19 = build_general_ledger(var_3,var_4,var_5)
    var_20

# Generated at 2022-06-26 00:34:53.218098
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime
    from decimal import Decimal
    from zeitgeist.datastore.models.accounts import Account

    # Pre-configure our test variables
    opening_date = datetime.date(2019, 1, 1)
    closing_date = datetime.date(2019, 12, 31)
    terminal_accounts = [Account(x) for x in range(1, 11)]
    initial_balances = {account: Balance(opening_date, Quantity(Decimal(0))) for account in terminal_accounts}

# Generated at 2022-06-26 00:34:58.450655
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = object()
    var_1 = object()
    var_2 = object()
    ledger_0 = Ledger(var_0, var_1)
    var_3 = ledger_0.add(var_2)
    assert var_3.posting == var_2
    assert var_3.balance == var_1.value + var_2.amount * var_2.direction.value


# Generated at 2022-06-26 00:34:59.356194
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

# Generated at 2022-06-26 00:35:04.716358
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 1))
    var_1 = test_ReadInitialBalances___call__.read_initial_balances(var_0)


# Generated at 2022-06-26 00:35:09.560077
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        pass

    def _read_journal_entries(period: DateRange) -> JournalEntry:
        pass

    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    assert isinstance(program, GeneralLedgerProgram)

# Generated at 2022-06-26 00:35:20.231955
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Verifies that the type annotation of function compile_general_ledger_program is correct.
    """
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[object]]:
        return []

    _compiled_program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    _result = _compiled_program(DateRange(datetime.date.today(), datetime.date.today()))

# Generated at 2022-06-26 00:35:25.389585
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_1 = None
    var_4 = None
    var_2 = {var_4: var_1}
    var_3 = None
    var_1 = build_general_ledger(var_3, var_4, var_2)


# Generated at 2022-06-26 00:35:28.129479
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test = compile_general_ledger_program(lambda period: {}, lambda period: [])
    test(DateRange(datetime.date.today(), datetime.date.today()))

# Generated at 2022-06-26 00:35:28.989872
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-26 00:35:39.155883
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(object(), object())
    result = var_0(object())
    assert isinstance(result, GeneralLedger)


# Generated at 2022-06-26 00:35:41.767316
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = object()
    var_1 = object()
    test_ReadInitialBalances___call__.prototype(var_0, var_1)



# Generated at 2022-06-26 00:35:46.986608
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    date_0 = datetime.date(year=2019, month=12, day=31)
    var_0 = DateRange(date_0, date_0)

    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = var_1.__call__(var_0)

# Generated at 2022-06-26 00:35:49.556062
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = object()
    var_1 = ReadInitialBalances.__call__(var_0, var_0)


# Generated at 2022-06-26 00:35:53.464536
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_2 = DateRange(var_0, var_0)
    var_3 = object()
    var_4 = object()
    var_5 = build_general_ledger(var_2, var_3, var_4)
    pass


# Generated at 2022-06-26 00:35:56.404614
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    period = object()
    db = object()
    impl = compile_general_ledger_program(db.read_initial_balances, db.read_journal_entries)
    result = impl(period)



# Generated at 2022-06-26 00:35:57.871570
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Test with good input.
    pass  # TODO: implement your test here


# Generated at 2022-06-26 00:35:59.279585
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # TODO: implement
    # test_compile_general_ledger_program()
    pass

# Generated at 2022-06-26 00:36:03.143625
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = object()
    ledger_0 = Ledger(var_0, var_0)
    var_1 = ledger_0.add(var_0)
    var_0 = object()
    var_1 = ledger_0.add(var_0)


# Generated at 2022-06-26 00:36:10.527630
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Setup arguments for test_case_0
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = object()
    var_4 = object()
    var_5 = object()
    var_6 = object()

    # Execute test_case_0
    var_7 = build_general_ledger(var_4, var_3, var_0)

    # Validate test_case_0
    assert isinstance(var_7, GeneralLedger)

    # Execute test_case_1
    test_case_1(var_1, var_2)


# Generated at 2022-06-26 00:36:26.580266
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = datetime.datetime.today()
    var_1 = build_general_ledger(var_0, var_0, var_0)
    var_2 = var_1.period
    var_3 = var_1.ledgers


# Generated at 2022-06-26 00:36:28.159371
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    run_test(ReadInitialBalances.__call__, [object(), object()], object())


# Generated at 2022-06-26 00:36:37.118050
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import (create_journal, post_journal)

    @post_journal.register
    def _(accounts):
        def _(journal):
            ledger = Ledger(accounts[0], Balance(datetime.date(2020, 1, 1), Quantity(0)))
            for posting in journal.postings:
                ledger.add(posting)
            return ledger

        return _

    var_0 = object()
    var_1 = object()
    var_1 = compile_general_ledger_program(var_0, var_1)
    var_2 = create_journal(list())
    var_2 = var_1(var_2)

# Generated at 2022-06-26 00:36:37.974496
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...


# Generated at 2022-06-26 00:36:42.523473
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _ReadInitialBalances(ReadInitialBalances):
        pass

    var_0 = _ReadInitialBalances()
    var_1 = datetime.date(2019, 1, 1)
    var_2 = datetime.date(2019, 1, 31)
    var_3 = DateRange(var_1, var_2)
    var_4 = var_0.__call__(var_3)


# Generated at 2022-06-26 00:36:43.999314
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert type(build_general_ledger(object(), object(), object())) is GeneralLedger


# Generated at 2022-06-26 00:36:48.631383
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import typing
    import unittest
    import datetime
    import decimal
    import accounts_model
    import journal_model

    def mock_read_journal_entries(arg_0: accounts_model.DateRange) -> typing.Iterable[journal_model.JournalEntry[object]]:
        return typing.List[journal_model.JournalEntry[object]]([journal_model.JournalEntry(datetime.date(1, 1, 1), "", typing.List[journal_model.Posting[object]]([journal_model.Posting(journal_model.Direction.DEBIT, var_6, ""), journal_model.Posting(journal_model.Direction.CREDIT, var_7, "")]))])


# Generated at 2022-06-26 00:36:50.109203
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_0 = compile_general_ledger_program(ReadInitialBalances, ReadJournalEntries)

# Generated at 2022-06-26 00:36:53.649876
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    _program:GeneralLedgerProgram(_T) = compile_general_ledger_program(lambda period: dict(), lambda period: dict())
    _program(DateRange(datetime.date.today(), datetime.date.today()))

# Generated at 2022-06-26 00:36:56.716246
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    obj = ReadInitialBalances()
    ret = obj(DateRange(datetime.date(2019, 9, 1), datetime.date(2019, 10, 1)))
    assert ret == dict()  # This test requires a constant returned value, or a mocked version which returns the constant.


# Generated at 2022-06-26 00:37:49.987682
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_0 = object()
    t = compile_general_ledger_program(var_0, var_0)
    assert type(t) is GeneralLedgerProgram
    assert t(var_0) is not None


# Generated at 2022-06-26 00:38:04.040035
# Unit test for function build_general_ledger
def test_build_general_ledger():

    # Case 0
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = object()
    var_4 = object()
    var_5 = object()
    var_6 = object()
    var_7 = object()

    var_8 = build_general_ledger(var_3, var_4, var_5)
    assert isinstance(var_8, GeneralLedger)
    assert var_8.period == var_3
    # assert var_8.ledgers == var_4
    assert isinstance(var_8, GeneralLedger)
    assert var_8.period == var_3
    # assert var_8.ledgers == var_4

    # Case 1
    var_0 = object()
    var_1 = object()
    var_2

# Generated at 2022-06-26 00:38:09.224226
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # No docstring
    # The body of method __call__ is empty
    class ReadInitialBalances_:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    var_0 = ReadInitialBalances_()
    var_1 = var_0.__call__(var_0)


# Generated at 2022-06-26 00:38:12.623389
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class ReadInitialBalances:
        def __call__(self, var_0: DateRange) -> InitialBalances:
            assert isinstance(var_0, DateRange)
            return {}

    var_0 = ReadInitialBalances()
    var_0.__call__(var_0)


# Generated at 2022-06-26 00:38:15.543884
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = object()
    ledger_0 = Ledger(var_0, var_0)
    var_1 = object()
    var_2 = ledger_0.add(var_1)
    assert var_2.posting is var_1


# Generated at 2022-06-26 00:38:21.901135
# Unit test for function build_general_ledger
def test_build_general_ledger():  # unit test for function build_general_ledger
    ## Initiate datetime objects
    period_date_since = datetime.datetime(2005, 1, 1, 0, 0)
    period_date_until = datetime.datetime(2005, 1, 10, 0, 0)
    journal_date = datetime.datetime(2005, 1, 3, 0, 0)

    ## Initiate test data
    period = DateRange(period_date_since, period_date_until)
    journal = JournalEntry(journal_date, "Test", [])

# Generated at 2022-06-26 00:38:22.826501
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert True


# Generated at 2022-06-26 00:38:27.885629
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        from io import StringIO

        from .accounts import Account
        from .journaling import JournalEntry

        # Initialization
        general_ledger_program_0 = GeneralLedgerProgram()

        # Invocation
        result = general_ledger_program_0()

    except Exception as e:
        print('Caught exception: ', repr(e))



# Generated at 2022-06-26 00:38:33.670916
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = object() # type: TypeVar
    var_3 = readjournalentries(var_0)
    var_4 = datetime.date(1, 1, 1)
    var_5 = datetime.date(1, 1, 1)
    var_6 = object()
    var_7 = object()
    var_2 = GeneralLedger(var_4, var_5, var_6, var_7)
    var_1 = GeneralLedgerProgram()
    var_8 = var_1(var_2)

# Generated at 2022-06-26 00:38:41.589120
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = object()
    var_4 = object()
    var_5 = object()
    var_6 = object()
    var_7 = object()
    var_8 = object()
    var_9 = object()
    var_10 = object()
    var_11 = object()
    var_12 = object()
    var_13 = object()
    var_14 = object()
    var_15 = object()
    var_16 = object()
    var_17 = object()
    var_18 = object()
    var_19 = object()
    var_20 = object()
    var_21 = object()
    var_22 = object()
    var_23 = object()
    var_24 = object()

# Generated at 2022-06-26 00:40:12.124838
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert False  # Cannot be tested, since the function is of type GeneralLedgerProgram


# Generated at 2022-06-26 00:40:12.951917
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = test_case_0()

# Generated at 2022-06-26 00:40:13.870752
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    GeneralLedgerProgram.__call__(object(), object())


# Generated at 2022-06-26 00:40:15.212494
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # test_Case_0
    var_0 = object()
    ledger_0 = GeneralLedger(var_0, var_0)

# Generated at 2022-06-26 00:40:22.542190
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Test if the function returns a GeneralLedgerProgram instance
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    # Test if the function returns a ReadJournalEntries instance
    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return []

    actual_0 = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    assert isinstance(actual_0, GeneralLedgerProgram)
    # Test if the function returns a GeneralLedger instance
    actual_1 = actual_0(DateRange.from_string("2019-01-01", "2019-01-31"))
    assert isinstance(actual_1, GeneralLedger)

# Generated at 2022-06-26 00:40:25.191062
# Unit test for function build_general_ledger
def test_build_general_ledger():
    key = ('key%03d' % i for i in range(3))
    initial = {k: Balance(k, i) for i, k in enumerate(key)}
    period = DateRange('period')
    _ = build_general_ledger(period, [], initial)
    assert True


# Generated at 2022-06-26 00:40:31.020139
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = object()
    ledger_0 = Ledger(var_0, var_0)
    ledger_0.entries.append(LedgerEntry(ledger_0, var_0, var_0))
    ledger_0.entries.append(LedgerEntry(ledger_0, var_0, var_0))
    ledger_0.entries.append(LedgerEntry(ledger_0, var_0, var_0))
    ledger_0.entries.append(LedgerEntry(ledger_0, var_0, var_0))
    ledger_0.entries.append(LedgerEntry(ledger_0, var_0, var_0))
    ledger_0.entries.append(LedgerEntry(ledger_0, var_0, var_0))
    ledger_0.ent

# Generated at 2022-06-26 00:40:35.879477
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry
    from .model import Posting
    var_0 = Account("100", "Test account", "", "", "", "", "", "")
    var_1 = Account("200", "Test account", "", "", "", "", "", "")
    var_2 = JournalEntry("J1", datetime.date(2018, 12, 2), "", [Posting(var_0, 1, 10), Posting(var_1, -1, 10)])
    var_3 = JournalEntry("J1", datetime.date(2018, 12, 2), "", [Posting(var_0, 1, 10), Posting(var_1, -1, 10)])

# Generated at 2022-06-26 00:40:36.727708
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert callable(build_general_ledger)

# Generated at 2022-06-26 00:40:37.762387
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Ledger(var_0, var_0)
    var_1 = var_0.add(var_0)