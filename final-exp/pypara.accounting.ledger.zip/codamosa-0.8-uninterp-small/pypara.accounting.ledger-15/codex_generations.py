

# Generated at 2022-06-26 00:31:11.191909
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = Account()
    account_1 = Account()
    balance_0 = Balance(date_0, Quantity(Decimal(0)))
    entry_0 = LedgerEntry(ledger_0, posting_0, Quantity(Decimal(0)))
    ledger_0 = Ledger(account_0, balance_0)
    journal_entry_0 = JournalEntry(date_0, str(), tuple())
    direction_0 = Direction()
    amount_0 = Amount(Decimal(0))
    posting_0 = Posting(account_1, direction_0, amount_0, journal_entry_0)

    entry_0 = ledger_0.add(posting_0)


# Generated at 2022-06-26 00:31:11.764676
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
  pass


# Generated at 2022-06-26 00:31:14.783278
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    Input0 = module_0.date()
    __return__ = module_0.date()
    __result__ = Input0.__call__(__return__)
    assert type(__result__) == module_0.date


# Generated at 2022-06-26 00:31:24.774682
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Prepare data:
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    account = Account(id="A", name="A", acc_type=0)
    initial = Balance(date=module_0.date(), value=0)
    ledger = Ledger(account=account, initial=initial)
    journal_entry = JournalEntry(
        id="N",
        description="N",
        date=module_0.date(),
        postings=[Posting(account=account, amount=1, direction=1)],
    )
    posting = journal_entry.postings[0]
    ## Execute method:
    ledger_entry = ledger.add(posting=posting)
    ## Assert results:
    assert ledger_entry.ledger == ledger
    assert ledger_entry.posting == posting
   

# Generated at 2022-06-26 00:31:34.914872
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .commons import Accounts, PostingDirection, ReadJournalEntries, Journal as Journal___2
    from .journaling import Posting as Posting___1
    from .accounts import Account as Account___0
    from .journaling import JournalEntry as JournalEntry___0
    from .journaling import Posting as Posting___0
    def read_initial_balances(arg_0: module_0.date) -> InitialBalances:
        var_0 = InitialBalances(dict())
        return var_0
    def read_journal_entries(arg_0: module_0.date) -> Iterable[JournalEntry___0]:
        var_1 = Account___0('150-1000')
        var_2 = PostingDirection.Debit()
        var_3 = Account___0('160-1000')
        var_4 = Posting

# Generated at 2022-06-26 00:31:37.904864
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    build_general_ledger = compile_general_ledger_program(lambda period: {}, lambda period: [])
    general_ledger_0 = build_general_ledger(None)
    assert general_ledger_0



# Generated at 2022-06-26 00:31:39.120541
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True

import datetime as module_1


# Generated at 2022-06-26 00:31:49.394944
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Generate test data
    account_0 = Account("Revenue", "")
    initial_0 = Balance(date_0, Quantity(Decimal("50.00")))
    posting_0 = Posting(1, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", Quantity("0"))
    # Construct the object to test
    ledger_0 = Ledger(account_0, initial_0)
    # Invoke the method to test
    ledger_entry_0 = ledger_0.add(posting_0)
    # Check the result
    assert ledger_entry_0.description == posting_0.description
    assert ledger_entry_0.posting == posting_0
    assert ledger_entry_

# Generated at 2022-06-26 00:31:53.065021
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()
    period_0 = DateRange()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 00:32:03.581247
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry
    from .commons.typing import Transaction

    initial_balance_accounts = {
        Account("Test"),
        Account("Other Account")
    }

    program = compile_general_ledger_program(
        lambda period: {a: Balance(period.since, Quantity(Decimal(0))) for a in initial_balance_accounts},
        lambda period: [],
    )

    ledger = program(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)))

    assert ledger.period == DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    assert set(ledger.ledgers.keys()) == initial_balance_accounts

# Generated at 2022-06-26 00:32:14.662752
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    dict_0 = {}
    var_0 = compile_general_ledger_program(date_range_0, dict_0)(date_range_0)

# Generated at 2022-06-26 00:32:15.493405
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass



# Generated at 2022-06-26 00:32:20.017778
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    date_range_1 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, date_range_1, dict_0)


# Generated at 2022-06-26 00:32:26.227383
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    date_range_0 = DateRange(datetime.date(2018, 12, 31), datetime.date(2019, 12, 31))
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, date_range_0, dict_0)
    assert var_0 == GeneralLedger(date_range_0, {})

# Generated at 2022-06-26 00:32:37.503821
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    date_range_1 = DateRange(date_range_0, date_range_0)
    date_range_2 = DateRange(date_range_0, date_range_0)
    date_range_3 = DateRange(date_range_0, date_range_0)
    date_range_4 = DateRange(date_range_3, date_range_3)
    quantity_0 = Quantity.zero()
    quantity_1 = Quantity.zero()
    quantity_2 = Quantity.zero()
    quantity_3 = Decimal('0')
    amount_0 = Amount.zero()
    amount_1 = Amount.zero()
    amount_2 = Amount.zero()
    amount_3 = Amount.zero()
    amount_4 = Amount.zero()

# Generated at 2022-06-26 00:32:40.324741
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert hasattr(GeneralLedgerProgram, '__call__')
    assert callable(GeneralLedgerProgram.__call__)


# Generated at 2022-06-26 00:32:42.324421
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def function0(arg0):
        pass

    def function1(arg0):
        pass

    function1(function0)

# Generated at 2022-06-26 00:32:44.074454
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    test_case_0()


# Generated at 2022-06-26 00:32:45.331120
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert compile_general_ledger_program()



# Generated at 2022-06-26 00:32:48.148468
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    dict_0 = {}
    assert compile_general_ledger_program(dict_0, date_range_0)(date_range_0)


# Generated at 2022-06-26 00:32:56.839298
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    var_0 = ReadInitialBalances.__call__(date_range_0)


# Generated at 2022-06-26 00:33:10.443557
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## We need to define algebra for reading initial balances and journal entries:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("111110", "Cash in Bank"): Balance(period.since, Decimal(2000)),
            Account("115500", "Retained Earnings"): Balance(period.since, Decimal(0)),
        }


# Generated at 2022-06-26 00:33:18.667090
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Setup
    account_0 = Account(None)
    balance_0 = Balance(None, None)
    ledger_0 = Ledger(account_0, balance_0)
    account_0 = Account(None)
    amount_0 = None
    direction_0 = None
    description_0 = None
    posting_0 = Posting(account_0, amount_0, direction_0, description_0)
    account_0 = Account(None)
    value_0 = None
    balance_0 = Balance(None, value_0)
    initial_balance_0 = balance_0
    account_0 = Account(None)
    value_0 = None
    balance_0 = Balance(None, value_0)
    initial_balance_1 = balance_0
    date_0 = None
    date_1 = None
    date

# Generated at 2022-06-26 00:33:24.044892
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    date_range_1 = None
    date_range_2 = None
    date_range_3 = None
    entry_0 = Ledger(date_range_0, date_range_1)
    entry_1 = entry_0.add(date_range_2)
    entry_2 = entry_1.add(date_range_3)


# Generated at 2022-06-26 00:33:26.241124
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_1 = build_general_ledger(None, None, {})
    print(var_1)



# Generated at 2022-06-26 00:33:33.949359
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Method __call__ of class GeneralLedgerProgram
    """
    # Case 0
    d = datetime.date(2019, 11, 1)
    # should be equivalent to
    # d = datetime.datetime(2019, 11, 1)
    # or
    # d = datetime.datetime(2019, 11, 1, 0, 0, 0)
    d_range_0 = DateRange(since=d, until=d)
    dict_0 = {}
    func_0 = compile_general_ledger_program(d, d)
    var_0 = func_0(d_range_0)


# Generated at 2022-06-26 00:33:43.698837
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from journal import Journal
    from accounts import Account, Expense, CommonStock, Revenues


# Generated at 2022-06-26 00:33:48.355914
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    general_ledger_0 = GeneralLedger(date_range_0, date_range_0)
    posting_0 = None
    ledger_entry_0 = general_ledger_0.ledgers.values().__iter__().__next__().add(posting_0)


# Generated at 2022-06-26 00:33:52.835049
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    rj = ReadJournalEntries()
    rj = ReadJournalEntries()
    rb = ReadInitialBalances()
    var_0 = compile_general_ledger_program(rb, rj)
    date_range_0 = None
    var_1 = var_0(date_range_0)


# Generated at 2022-06-26 00:33:59.716505
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = Account()
    balance_0 = Balance()
    ledger_0 = Ledger(account_0, balance_0)
    account_1 = Account()
    journal_1 = JournalEntry()
    posting_0 = Posting(account_0, account_1, journal_1)
    posting_0.value = Quantity(Decimal('1.00'))
    posting_0.direction = None

    ledger_entry_0 = ledger_0.add(posting_0)
    assert ledger_entry_0.description == 'description'


# Generated at 2022-06-26 00:34:09.754372
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    date_range_1 = None
    body_0 = lambda date_range_2 = date_range_1: build_general_ledger(date_range_0, date_range_0, dict_0)
    dict_0 = {}
    var_0 = compile_general_ledger_program(body_0, body_0)(date_range_0)
    assert var_0 is not None


# Generated at 2022-06-26 00:34:18.639529
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Some test data:
    period = DateRange(datetime.date(2020, 3, 1), datetime.date(2020, 3, 31))
    initial_balances = {
        Account("1000"): Balance(datetime.date(2020, 2, 29), Quantity(Decimal(500))),
        Account("1100"): Balance(datetime.date(2020, 2, 29), Quantity(Decimal(800))),
    }

# Generated at 2022-06-26 00:34:21.163425
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    dict_0 = {}
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)
    var_0(dict_0)


# Generated at 2022-06-26 00:34:22.906561
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    param_0 = None
    ReadInitialBalances.__call__(param_0)


# Generated at 2022-06-26 00:34:25.052533
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_compile_general_ledger_program_0()


# Generated at 2022-06-26 00:34:27.156935
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    var_0 = ReadInitialBalances.__call__(date_range_0)


# Generated at 2022-06-26 00:34:30.044910
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Test code:
    var_0 = Ledger(None, None, None)
    var_1 = Posting(None, None, None, None)
    var_2 = var_0.add(var_1)


# Generated at 2022-06-26 00:34:31.816124
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert(test_case_0())

test_cases = [
    test_build_general_ledger,
]



# Generated at 2022-06-26 00:34:32.606200
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:34:38.886936
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_1 = None
    account_1 = None
    account_2 = None
    quantity_1 = None
    direction_1 = None
    amount_2 = None
    journal_1 = None
    posting_1 = Posting(date_1, account_1, direction_1, amount_2, journal_1)
    balance_1 = Balance(date_1, quantity_1)
    ledger_1 = Ledger(account_2, balance_1)
    var_1 = ledger_1.add(posting_1)


# Generated at 2022-06-26 00:34:47.747427
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_2 = {}
    var_3 = build_general_ledger(var_2, var_2, var_2)



# Generated at 2022-06-26 00:34:50.357371
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = {}
    var_1 = test_ReadInitialBalances()
    var_2 = var_1.__call__(var_0)


# Generated at 2022-06-26 00:34:59.701256
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .journaling import Date, Journal, JournalEntry, Posting, Transaction

    def read_initial_balances(period):
        return {Account("A1"): Balance(Date(2019, 1, 1), Quantity(100))}


    def read_journal_entries(period):
        return [JournalEntry(Journal("J1", [], Date(2019, 2, 1)),
                             [Posting(Account("A1"), Transaction("T1"), 1, Quantity(100))])]


    # pylint: disable=unused-variable
    var_0 = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    var_1 = var_0(var_0)
    var_2 = var_1.ledgers[Account("A1")].initial

# Generated at 2022-06-26 00:35:05.385254
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests :py:function:`compile_general_ledger_program`.
    """
    ## Check if the function can be used as a type constructor:
    assert compile_general_ledger_program(test_case_0, test_case_0)

# Generated at 2022-06-26 00:35:06.210273
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_1 = compile_general_ledger_program()

# Generated at 2022-06-26 00:35:09.326175
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Setup
    instance = Ledger(Account(), Balance())

    # Test
    instance.add(var_0)
    assert var_0 == instance.entries[-1]


# Generated at 2022-06-26 00:35:17.848704
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account

    from .journaling import JournalEntry, Posting, Transaction

    posting: Posting[Transaction] = Posting(Transaction(), Account(), Amount(0), True)
    ledger: Ledger[Transaction] = Ledger(Account(), Balance(None, 0))
    assert posting.amount == 0
    assert ledger.add(posting).amount == 0


# Generated at 2022-06-26 00:35:20.341372
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = build_general_ledger(var_0, var_0, var_0)
    var_1 = read_initial_balances(var_0)

# Generated at 2022-06-26 00:35:21.358355
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # ...
    return


# Generated at 2022-06-26 00:35:24.913680
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)


# Generated at 2022-06-26 00:35:45.468578
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Test of method add of class Ledger
    """
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)
    var_2 = var_1.ledgers
    var_3 = var_2.items()
    var_4 = next(var_3)
    var_5 = var_4[0]
    var_6 = var_4[1]
    var_7 = var_6.add(var_0)


# Generated at 2022-06-26 00:35:51.678191
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances()
    try:
        var_0.__call__()
        assert False, "Expected AttributeError but no exception raised"
    except AttributeError as e:
        assert True
    except Exception as e:
        assert False, "Expected AttributeError but different exception raised"


# Generated at 2022-06-26 00:35:54.660344
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    param_0 = {}
    param_1 = {}
    test_case_compile_general_ledger_program = compile_general_ledger_program(param_0, param_1)


# Generated at 2022-06-26 00:35:58.085729
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = {}
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = test_case_0()
    var_3 = {var_0: var_0, var_1: var_1, var_2: var_2}

# Generated at 2022-06-26 00:36:02.246760
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_2 = Ledger(Account("123456789"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    var_3 = Posting(Account("123456789"), Quantity(Decimal(0)))
    var_2.add(var_3)


# Generated at 2022-06-26 00:36:08.061736
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import dataclass, field
    from typing import Dict
    import datetime
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    # Set up object to call the method on:
    var_0 = ReadInitialBalances()
    # Call the method:
    var_1 = var_0(var_0)
    assert isinstance(var_1, Dict)


# Generated at 2022-06-26 00:36:10.681663
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_2 = {}
    var_0 = compile_general_ledger_program(var_2, var_2)
    var_1 = var_0({})

# Generated at 2022-06-26 00:36:13.052619
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    obj = compile_general_ledger_program(test_GeneralLedgerProgram___call__, test_GeneralLedgerProgram___call__)
    assert obj(test_case_0())

# Generated at 2022-06-26 00:36:21.946070
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Ledger(account="Foo", initial=Balance(
        date=datetime.date(2018, 1, 1), value=Quantity(Decimal(0))
    ))
    var_1 = Posting(
        account="Foo",
        amount=Amount(Decimal(0)),
        direction=1,
        journal=JournalEntry(
            date=datetime.date(2018, 1, 1),
            description="Foo",
            postings=[Posting(
                account="Bar",
                amount=Amount(Decimal(0)),
                direction=1,
            )]
        )
    )
    var_2 = var_0.add(var_1)
    assert hasattr(var_2, "ledger")
    assert hasattr(var_2, "posting")

# Generated at 2022-06-26 00:36:31.342888
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from hypothesis import given
    from hypothesis.strategies import builds
    from hypothesis.strategies import dates
    from hypothesis.strategies import dictionaries
    from hypothesis.strategies import fixed_dictionaries
    from hypothesis.strategies import lists
    from hypothesis.strategies import sampled_from
    from hypothesis.strategies import text
    from hypothesis.strategies import tuples
    from hypothesis.strategies import uuids
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting
    from .journaling import build_journal_entry
    from .journaling import build_posting
    from .journaling.algebras import ReadJournalEntries


# Generated at 2022-06-26 00:37:06.857769
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)


# Generated at 2022-06-26 00:37:10.162841
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Setup
    protocol_0 = Protocol()
    protocol_1 = Protocol()
    var_0 = compile_general_ledger_program(protocol_0, protocol_1)
    ## Assert

if __name__ == "__main__":
    test_case_0()
    test_compile_general_ledger_program()

# Generated at 2022-06-26 00:37:11.793491
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = DateRange()
    var_1 = ReadInitialBalances.__call__(var_0)


# Generated at 2022-06-26 00:37:14.044306
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)
    assert (var_1 is not None)


# Generated at 2022-06-26 00:37:25.831461
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Configure the mock for ReadInitialBalances.__call__
    read_initial_balances___call___mock = Mock(wraps=read_initial_balances.__call__)

    # Configure the call to ReadInitialBalances.__call__
    read_initial_balances___call___mock.return_value = var_0

    # Test case configuration
    var_0 = {}
    period = var_0

    # Perform the test
    result = read_initial_balances.__call__(period)

    # Check test results
    read_initial_balances___call___mock.assert_called_once_with(period)
    assert result == var_0


# Generated at 2022-06-26 00:37:28.758621
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    var_1 = Ledger(var_0, var_0)
    var_2 = var_1.add(var_0)


# Generated at 2022-06-26 00:37:33.454050
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = {}
    var_1 = compile_general_ledger_program(var_0, var_0)

    var_2 = {}
    var_1.__call__(var_2)


# Generated at 2022-06-26 00:37:36.347862
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = {}
    var_1 = Ledger(var_0, var_0)
    var_2 = var_1.add(var_0)

# Generated at 2022-06-26 00:37:36.871067
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:37:43.727076
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_2 = ReadInitialBalances()
    var_3 = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    var_2(var_3)



# Generated at 2022-06-26 00:38:11.721765
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_1 = {}
    var_0 = ReadInitialBalances()
    var_0.__call__(var_0)


# Generated at 2022-06-26 00:38:14.104652
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_2 = {}
    var_3 = test_ReadInitialBalances_class(var_2, var_2)
    var_3.__call__(var_2)


# Generated at 2022-06-26 00:38:16.286841
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances()
    var_1 = DateRange(None, None)
    var_2 = var_0.__call__(var_1)



# Generated at 2022-06-26 00:38:18.440060
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    var_1 = Ledger(var_0, var_0)
    var_2 = var_1.add(var_0)


# Generated at 2022-06-26 00:38:26.496967
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .commons.types import Money
    from .journaling import Posting, Journal, Direction
    from .accounts import Account

    ledger = Ledger(Account(0, "Account"), Balance(datetime.date(2013, 1, 1), Quantity(Decimal("100"))))
    posting = Posting(Journal("Journal", "Description", datetime.date(2014, 1, 1), [Posting(0, Direction.DEBIT, Money("10.00"))]), Account(0, "Account"), Direction.CREDIT, Money("10.00"))

    result = ledger.add(posting)

    assert result == LedgerEntry(ledger, posting, Quantity(Decimal(90)))


# Generated at 2022-06-26 00:38:28.285323
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)

# Generated at 2022-06-26 00:38:36.481221
# Unit test for function build_general_ledger
def test_build_general_ledger():

    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)
    assert isinstance(var_1, GeneralLedger)
    assert isinstance(var_1.period, DateRange)
    assert isinstance(var_1.ledgers, Dict[Account, Ledger])
    assert isinstance(var_1.ledgers[var_0], Ledger)
    assert isinstance(var_1.ledgers[var_0].account, Account)
    assert isinstance(var_1.ledgers[var_0].initial, Balance)
    assert isinstance(var_1.ledgers[var_0].entries, List[LedgerEntry])
    assert isinstance(var_1.ledgers[var_0].entries[var_0], LedgerEntry)
   

# Generated at 2022-06-26 00:38:45.257287
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    ## Arrange:
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    period = DateRange(datetime.date(2019, 4, 1), datetime.date(2019, 5, 31))

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [
            JournalEntry(datetime.date(2019, 4, 25), "", "Client revenue", [
                Posting(Account("11800"), 0),
                Posting(Account("11802"), 7000),
            ]),
        ]

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Act:

# Generated at 2022-06-26 00:38:47.709070
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = build_general_ledger(None, None, None)
    var_1 = Ledger(None, None, var_0.entries)
    var_2 = var_1.add(None)


# Generated at 2022-06-26 00:38:49.217010
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:40:09.610042
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ## Initialize unit test:
    from dataclasses import InitVar
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance
    from .types import RawType

    ## Initialize expected values:
    expected_0 = {Account('0', RawType()): Balance(None, Decimal(0))}

    ## Execute code under test:
    obj_0 = BuildInitialBalancesDummy()
    actual_0 = obj_0(None)

    ## Verify results:
    assert expected_0 == actual_0


# Generated at 2022-06-26 00:40:11.578001
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)
    assert isinstance(var_1, GeneralLedger) is True

# Generated at 2022-06-26 00:40:13.832373
# Unit test for function build_general_ledger
def test_build_general_ledger():

    ## Test case 0:
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)
    assert var_1 is not None


# Generated at 2022-06-26 00:40:17.122152
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def var_16(var_17):
        pass
    var_14 = compile_general_ledger_program(var_16, var_16)
    var_18 = var_14(var_16)
    assert isinstance(var_18, GeneralLedger)

# Generated at 2022-06-26 00:40:19.517956
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def test_0():
        var_0 = compile_general_ledger_program(lambda var_0: var_0, lambda var_0: var_0)
        assert callable(var_0)

    test_0()
    pass



# Generated at 2022-06-26 00:40:22.091063
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = {}
    var_1 = ReadInitialBalances
    var_2 = var_1()
    var_3 = var_2()
    var_4 = var_3 == var_0
    return var_4


# Generated at 2022-06-26 00:40:23.928272
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_1 = compile_general_ledger_program(test_case_0, test_case_0)
    var_2 = var_1.__call__(test_case_0)


# Generated at 2022-06-26 00:40:24.730367
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert test_case_0() is None


# Generated at 2022-06-26 00:40:26.301112
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create object instance
    var_1 = Ledger(var_0, var_0)

    # Add and validate
    var_1.add(var_0)



# Generated at 2022-06-26 00:40:27.182206
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_compile_general_ledger_program_0()
