

# Generated at 2022-06-26 00:31:11.538577
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_account = Account("TEST")
    test_balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))
    test_journal = JournalEntry(
        date=datetime.date(2020, 1, 1), description="Test Journal", postings=[Posting(test_account, 1, test_balance)]
    )
    test_ledger = Ledger("TEST", test_balance)
    test_ledger.add(test_journal.postings[0])
    assert test_ledger.entries[0].account == test_account
    assert test_ledger.entries[0].date == datetime.date(2020, 1, 1)
    assert test_ledger.entries[0].description == "Test Journal"
    assert test_ledger.entries[0].amount == 1
   

# Generated at 2022-06-26 00:31:15.275382
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Initialize the Ledger
    ledger_0 = Ledger()
    # Add an entry to the ledger
    new_ledger_entry = ledger_0.add()
    # Check if the ledger has the new entry
    assert new_ledger_entry in ledger_0.entries



# Generated at 2022-06-26 00:31:19.346142
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_program = compile_general_ledger_program(ReadInitialBalances(), ReadJournalEntries())
    _ = test_program(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))
    assert callable(test_program)

# Generated at 2022-06-26 00:31:27.722888
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_account = Account("2")
    test_initial_balance = Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0)))
    test_ledger = Ledger(test_account, test_initial_balance)

    test_date = datetime.date(2019, 1, 1)
    test_cntracct = Account("1")
    test_amount = Amount(Decimal(100.0))
    test_posting = Posting(test_date, test_cntracct, test_amount)

    test_ledger_entry = test_ledger.add(test_posting)

    if (test_ledger_entry.balance == Quantity(Decimal(100.0))):
        print("Unit test for method add of class Ledger: PASSED")

# Generated at 2022-06-26 00:31:37.301133
# Unit test for method add of class Ledger
def test_Ledger_add():
    acct0 = Account(name='CSH', number=1)
    acct1 = Account(name='RSA', number=2)
    acct2 = Account(name='PPE', number=3)
    acct3 = Account(name='REV', number=4)
    acct4 = Account(name='COS', number=5)
    acct5 = Account(name='TAX', number=6)
    acct6 = Account(name='EQY', number=7)
    acct7 = Account(name='CGS', number=8)
    acct8 = Account(name='CRP', number=9)
    acct9 = Account(name='ACM', number=10)
    acct10 = Account(name='ACR', number=11)

# Generated at 2022-06-26 00:31:38.190065
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:31:41.398185
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class_0 = ReadInitialBalances()
    period_0 = DateRange
    InitialBalances_0 = class_0.__call__(period_0)


# Generated at 2022-06-26 00:31:50.777776
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from cheapskate.model.accounting.accounts import account
    from cheapskate.model.accounting.journal import journal_entry
    from cheapskate.model.accounting.transactions import transaction
    from cheapskate.model.ledgers import build_general_ledger
    from cheapskate.model.transactions import debit, credit

    # Two entries of the same date (a journal should be free of these!)
    opening = transaction(
        "Opening balances",
        debit(account(1), "Cash", Decimal(100.00)),
        credit(account(2), "Bills Receivable", Decimal(100.00)),
    )

# Generated at 2022-06-26 00:31:51.108019
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert False == False

# Generated at 2022-06-26 00:32:01.176942
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from os.path import join
    from ..journaling.utils import load_journal_from_file
    from .accounts import Account, AccountType

    # Initial balances:
    initial_balances = {
        Account(AccountType(1), '1110', 'Cash'),
        Account(AccountType(1), '1130', 'Bank'),
        Account(AccountType(1), '5100', 'Accounts Payable'),
        Account(AccountType(1), '5110', 'Accounts Payable - Trade'),
        Account(AccountType(1), '5120', 'Accounts Payable - Other'),
        Account(AccountType(1), '5310', 'Income Tax Payable')
    }

    # Load journal from file:
    path = join(__file__, "../../tests/journal_201806.json")
    journal = load

# Generated at 2022-06-26 00:32:13.988529
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:32:14.865610
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True


# Generated at 2022-06-26 00:32:17.190614
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True # TODO: implement your test here



# Generated at 2022-06-26 00:32:25.861818
# Unit test for function build_general_ledger
def test_build_general_ledger():
    
    period = DateRange(datetime.date(2020, 10, 1), datetime.date(2020, 10, 31))
    # Journal entries.

# Generated at 2022-06-26 00:32:27.402261
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    period_0 = None
    var_0 = ReadInitialBalances.__call__(period_0)


# Generated at 2022-06-26 00:32:38.742119
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import dataclasses
    import datetime

    from decimal import Decimal

    from .accounts import Account, AccountType

    @dataclasses.dataclass(frozen=True)
    class Journal0:
        date: datetime.date
        description: str
        postings: List[Posting]
        notes: List[str]

    @dataclasses.dataclass(frozen=True)
    class Posting0:
        account: Account
        amount: Decimal
        sign: int
        tags: List[str]

    from .journaling import journal, posting

    @journal('2016-01-01', description='Description 0')
    def journal_0():
        posting(AccountType.asset, '1001', Decimal('100.00'))

# Generated at 2022-06-26 00:32:44.515442
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = DateRange(datetime.date(2006, 1, 1), datetime.date(2006, 1, 31))
    var_1(var_2)


# Generated at 2022-06-26 00:32:45.081919
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:32:48.572938
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period_0 = None
    journal_0 = None
    initial_0 = None
    var_0 = build_general_ledger(period_0, journal_0, initial_0)
    assert isinstance(var_0, GeneralLedger)


# Generated at 2022-06-26 00:32:51.808967
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_build_general_ledger_1()
    test_build_general_ledger_2()
    test_build_general_ledger_3()
    test_build_general_ledger_4()
    return


# Generated at 2022-06-26 00:33:12.341908
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Posting(datetime.date(2019, 12, 31), 'X0', 'X1')
    var_1 = Ledger(Account('X2'), Balance(datetime.date(2019, 12, 31), Quantity(Decimal(0))))
    var_2 = var_1.add(var_0)
    assert (var_2.posting) == (var_0)
    assert (var_2.balance) == (Quantity(Decimal(0)))

# Generated at 2022-06-26 00:33:15.643789
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test parameters:
    var_0 = None
    # Test cases:
    var_1 = None
    var_2 = compile_general_ledger_program(var_1, var_1)
    var_2(var_0)



# Generated at 2022-06-26 00:33:17.929040
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = None
    var_2 = test_case_0()
    var_3 = var_2(read_initial_balances_0)


# Generated at 2022-06-26 00:33:24.133124
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Local variable declarations
    arg_posting = None
    actual_returned_value = None
    expected_returned_value = None

    # Test code
    arg_posting = None
    led = Ledger(None, None)
    actual_returned_value = led.add(arg_posting)
    expected_returned_value = led.entries[-1]
    assert actual_returned_value == expected_returned_value


# Generated at 2022-06-26 00:33:29.896386
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    general_ledger_program_0: GeneralLedgerProgram[_T]
    general_ledger_program_0 = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    return general_ledger_program_0

if __name__ == "__main__":
    print("[+] Testing module " + __file__)

    test_case_0()

    print("[+] All unit tests passed.")

# Generated at 2022-06-26 00:33:35.354854
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import dataclass
    from typing import Dict, TypeVar
    from .accounts import Account
    from .generic import Balance
    from .periods import Period
    from .zeitgeist import DateRange
    @dataclass
    class ReadInitialBalances_0(ReadInitialBalances):
        def __call__(self, arg_0: DateRange) -> Dict[Account, Balance]:
            pass
    test_case_0()


# Generated at 2022-06-26 00:33:36.908760
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    x = ReadInitialBalances()
    period = None
    x(period)
    assert None == None


# Generated at 2022-06-26 00:33:46.746677
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Testing {Ledger.add()}

    # Setup:
    ledger = Ledger(Account(1), Balance(datetime.date(1, 1, 1), Quantity(10)))

    # Exercise:
    result = ledger.add(Posting(JournalEntry(datetime.date(1, 1, 2), "Foo", [Quantity(2)]), Quantity(2), Account(1)))

    # Verify
    assert result.ledger == ledger
    assert result.posting.journal.date == datetime.date(1, 1, 2)
    assert result.posting.journal.description == "Foo"
    assert result.posting.journal.postings[0].joy.amount == Quantity(2)
    assert result.posting.joy.account == Account(1)
    assert result.posting.joy.amount == Quantity(2)


# Generated at 2022-06-26 00:33:57.049825
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Load program used for testing.
    from accounting.actors.test.test_actor_ledgers import prog_build_general_ledger_0, prog_build_general_ledger_1, prog_build_general_ledger_2, prog_build_general_ledger_3, prog_build_general_ledger_4, prog_build_general_ledger_5, prog_build_general_ledger_6, prog_build_general_ledger_7, prog_build_general_ledger_8, prog_build_general_ledger_9, prog_build_general_ledger_10, prog_build_general_ledger_11, prog_build_general_ledger_12, prog_build_general_ledger_13, prog_build_general_ledger_14, prog_build_general_ledger_

# Generated at 2022-06-26 00:33:59.441475
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Initialize
    args = None
    obj = None

    # Invoke method
    result = obj.__call__(args)

    # Check result
    assert result != None

# Generated at 2022-06-26 00:34:07.307133
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert None == compile_general_ledger_program(None, None)

# Generated at 2022-06-26 00:34:09.886536
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_2 = compile_general_ledger_program(None, None)
    var_3 = var_2()

# Generated at 2022-06-26 00:34:13.049253
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_3 = None
    var_1(var_3)


# Generated at 2022-06-26 00:34:15.698464
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print("Unit test for build_general_ledger")
    period = None
    journal = None
    initial = None
    obj = build_general_ledger(period, journal, initial)
    return False


# Generated at 2022-06-26 00:34:25.910566
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from butterfree.pipeline import read_table
    from butterfree.clients import spark_client
    from pyspark.sql import types as t
    
    # Prepare the data source:
    data = [
        (date(2019, 12, 31), 1, 2.34),
        (date(2019, 12, 31), 2, 3.45),
    ]
    source = spark_client.create_dataframe(data, schema=t.StructType([
        t.StructField("since", t.DateType(), nullable=False),
        t.StructField("account_id", t.IntegerType(), nullable=False),
        t.StructField("balance", t.DoubleType(), nullable=False)
    ]))
    source.createOrReplaceTempView("initial_balances")
    


# Generated at 2022-06-26 00:34:29.064111
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Initial
    obj = []
    d = DateRange(datetime.date(1900, 1, 1), datetime.date(1900, 1, 1))

    # Action
    result = obj(d)

    # Assert
    return (result)

# Generated at 2022-06-26 00:34:32.427189
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import _MISSING_TYPE
    _imp = None
    _SELF_TYPE = None
    try:
        assert _imp.__call__(_SELF_TYPE, _MISSING_TYPE) is _MISSING_TYPE
    except AttributeError:
        pass


# Generated at 2022-06-26 00:34:38.286315
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    global read_initial_balances_0, var_0

    ## Mock configuration:
    var_0 = None

    ## Invoke the target method:
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = var_1.__call__(
        period=var_0,
    )

    ## Assertions:


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 00:34:38.932202
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-26 00:34:42.164635
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)

# vim: et:ts=4:sw=4:ft=python:

# Generated at 2022-06-26 00:34:55.977593
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():  # noqa
    pass



# Generated at 2022-06-26 00:35:00.549009
# Unit test for function build_general_ledger
def test_build_general_ledger():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    var_3 = build_general_ledger(var_2, var_3, var_3)


# Generated at 2022-06-26 00:35:09.904319
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import create_money, create_journal, post
    from .accounts import create_account
    from .accounts import Asset, Liability, Cash

    # Test case 0 covers the general case:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2019, 12, 31))
    initial_balance = Balance(period.since, Quantity(0))
    ledger_a = Ledger(create_account(Asset, "Cash", Cash, "Petty Cash"), initial_balance)
    ledger_b = Ledger(create_account(Liability, "Accounts receivable", Cash, "Payments"), initial_balance)


# Generated at 2022-06-26 00:35:19.023175
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    try:
        var_1(var_2)
    except AssertionError as var_3:
        var_4 = var_3.args[0]
        pass
    else:
        raise Exception


# Generated at 2022-06-26 00:35:23.975840
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Setup
    var_0 = compile_general_ledger_program(None, None)
    var_1 = None
    # Exercise
    var_2 = var_0(var_1)
    # Verify
    assert var_2 is None


# Generated at 2022-06-26 00:35:36.701487
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime
    from decimal import Decimal
    from fiscal.entities.accounts import Account
    from fiscal.entities.general_ledger import build_general_ledger
    from fiscal.entities.journaling import JournalEntry, Posting
    from fiscal.entities.commons.numbers import Amount, Quantity

    # Expected:
    period = DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 12, 31))
    journal1 = JournalEntry(
        datetime.date(2000, 1, 1),
        "J1",
        [Posting(Account(10, "A1", True), Amount(Decimal(1000))), Posting(Account(30, "A3", False), Amount(Decimal(1000)))],
    )

# Generated at 2022-06-26 00:35:40.509450
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_inital_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_inital_balances_0, var_0)
    var_2 = None
    var_1(var_2)


# Generated at 2022-06-26 00:35:44.237189
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_obj = Ledger(None, None)
    posting = None
    expected = LedgerEntry(None, None, None)
    actual = test_obj.add(posting)
    assert actual == expected, f"actual: {actual}, expected: {expected}"


# Generated at 2022-06-26 00:35:48.197817
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Nothing to test yet.
    pass

# Generated at 2022-06-26 00:35:52.242823
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ReadInitialBalances = ReadInitialBalances
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    retval = ReadInitialBalances.__call__(period)
    assert(isinstance(retval, InitialBalances))


# Generated at 2022-06-26 00:36:14.295292
# Unit test for method add of class Ledger
def test_Ledger_add():
    from datetime import date
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, Transaction
    t = Transaction('2018-01-15', 'Test1')
    
    p1 = Posting(t, Account('1300.10'), Quantity(100))
    p2 = Posting(t, Account('1300.25'), Quantity(100), True)
    
    l = Ledger(Account('1300.20'), Balance(date(2018, 1, 1), Quantity(10000)))
    l.add(p1)
    l.add(p2)
    
    assert l.entries[0].balance == Quantity(10100)
    assert l.entries[1].balance == Quantity(10000)

# Generated at 2022-06-26 00:36:15.874608
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_2 = None
    var_3 = var_2.__call__()
    assert var_3 is None

# Generated at 2022-06-26 00:36:25.114120
# Unit test for function build_general_ledger
def test_build_general_ledger():
    today = datetime.date.today()
    tomorrow = today + datetime.timedelta(days=1)
    period = DateRange(today, tomorrow)

    expected_ledger_a = Ledger(
        Account('A'),
        Balance(today, Quantity(Decimal(0))),
        [
            LedgerEntry(ledger=expected_ledger_a, posting=var_0, balance=Quantity(Decimal('10.12'))),
            LedgerEntry(ledger=expected_ledger_a, posting=var_1, balance=Quantity(Decimal('10.12'))),
        ]
    )

# Generated at 2022-06-26 00:36:28.573797
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    assert callable(var_1), f"Expected a function, got {type(var_1)}"

# Generated at 2022-06-26 00:36:33.314184
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    var_3 = var_1(var_2)

test_case_0()

# Generated at 2022-06-26 00:36:34.182192
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-26 00:36:38.713594
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    assert isinstance(var_1, GeneralLedgerProgram)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 00:36:41.950636
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange(since=datetime.date(2016, 1, 1), until=datetime.date(2016, 12, 31))
    var_0 = read_initial_balances_0(period_0)


# Generated at 2022-06-26 00:36:50.109773
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Initialize period.
    period = DateRange(since=datetime.date(2000, 1, 1), until=datetime.date(2000, 12, 31))

    ## Initialize general ledger buffers:
    initial_balances = {  # type: InitialBalances
        Account(code="CASH"): Balance(period.since, Quantity(10000)),
        Account(code="SUPPLIES"): Balance(period.since, Quantity(5000)),
        Account(code="EQUITY"): Balance(period.since, Quantity(0)),
    }

# Generated at 2022-06-26 00:36:51.080435
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:37:43.149664
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    var_1(var_2)


# Generated at 2022-06-26 00:37:47.215231
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_journal_entries_0 = None
    period_0 = None
    var_0 = compile_general_ledger_program(read_journal_entries_0, period_0)
    period = None
    var_1 = var_0(period)

# Generated at 2022-06-26 00:37:48.367877
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()


# Generated at 2022-06-26 00:37:49.074447
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-26 00:37:57.883215
# Unit test for function build_general_ledger
def test_build_general_ledger():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    var_3 = build_general_ledger(var_2, var_0, var_1)


# Generated at 2022-06-26 00:38:03.257800
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    mock = ReadInitialBalancesMock(DateRange(datetime.date(2018, 12, 31), datetime.date(2018, 12, 31)))
    mock.__call__(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))
    mock.__call__(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))


# Generated at 2022-06-26 00:38:04.116642
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_case_0()


# Generated at 2022-06-26 00:38:05.285869
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    obj_0 = test_case_0()


# Generated at 2022-06-26 00:38:08.821667
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = None
    var_1 = None
    var_0 = read_initial_balances_0(var_1)


# Generated at 2022-06-26 00:38:16.931924
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import from_date, to_date
    from ..journaling.journaling import AccountingPeriod

    # Setup:
    read_initial_balances_1 = None
    var_2 = None
    var_3 = compile_general_ledger_program(read_initial_balances_1, var_2)
    var_4 = AccountingPeriod('I', from_date('2019-01-01'), to_date('2019-12-31'))
    var_5 = None
    var_6 = {'c': ('2019-12-31', 1)}
    var_7 = None
    var_8 = {'b': ('2019-12-31', 0)}
    var_9 = None
    var_10 = {'a': ('2019-12-31', 0)}

# Generated at 2022-06-26 00:39:07.607761
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # case 0
    # Here, we are only testing that the call is possible.
    test_case_0();

# Generated at 2022-06-26 00:39:09.493085
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    read_initial_balances_0 = ReadInitialBalances()
    read_initial_balances___call____0 = read_initial_balances_0.__call__(date_range_0)


# Generated at 2022-06-26 00:39:10.951088
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)(date_range_0)

# Generated at 2022-06-26 00:39:16.505223
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account
    from .commons.algebras import Piped
    from .commons.zeitgeist import Date
    from .journaling import JournalEntry
    from .ledgering import build_general_ledger


    #: Defines an account type variable.
    _A = TypeVar("_A", bound=Account)

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Quantity]

    #: Read initial balances:
    ReadInitialBalances = Callable[[DateRange], InitialBalances]

    #: Read journal entries:
    ReadJournalEntries = Callable[[DateRange], Iterable[JournalEntry[_T]]]

    #: Provides an account ledger model.

# Generated at 2022-06-26 00:39:22.329415
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .commons.algebras import read_initial_balances, read_journal_entries
    from .commons.interpreters import sqlite_testing_interpreter
    from .commons.zeitgeist import DateRange

    _i = sqlite_testing_interpreter

    _i.execute('''
    CREATE TABLE IF NOT EXISTS initial_balances (
        account_id INTEGER NOT NULL,
        value REAL NOT NULL,
        period_end TEXT NOT NULL
    )
    ''')

    _i.execute('''
    CREATE TABLE IF NOT EXISTS journal_entries (
        id INTEGER PRIMARY KEY,
        description TEXT NOT NULL,
        datestamp TEXT NOT NULL
    )
    ''')


# Generated at 2022-06-26 00:39:24.406457
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    ReadInitialBalances_0 = compile_general_ledger_program(ReadInitialBalances_0, None)
    ReadInitialBalances_0.__call__(date_range_0)


# Generated at 2022-06-26 00:39:27.406778
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    dict_0 = {}
    read_initial_balances_0 = None
    read_journal_entries_0 = None
    var_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 00:39:31.330273
# Unit test for function build_general_ledger
def test_build_general_ledger():
    account_0 = Account(None)
    balance_0 = Balance(account_0, None)
    dict_0 = {}
    dict_0[account_0] = balance_0
    int_0 = 0
    int_1 = 1
    str_0 = ""
    tuple_0 = (int_0, int_1, str_0)
    var_0 = build_general_ledger(tuple_0, dict_0, dict_0)


# Generated at 2022-06-26 00:39:37.581151
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = DateRange(datetime.date(1, 1, 1), datetime.date(2, 1, 1))
    list_0 = [JournalEntry(datetime.date(1, 1, 1), '', [Posting('', datetime.date(1, 1, 1), Decimal('1'), None)])]
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, list_0, dict_0)
    var_1 = build_general_ledger(date_range_0, list_0, dict_0)
    assert var_0 == var_1
    date_range_1 = DateRange(datetime.date(2, 1, 1), datetime.date(3, 1, 1))

# Generated at 2022-06-26 00:39:40.878553
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert callable(compile_general_ledger_program)
    date_range_1 = None
    dict_1 = {}
    dict_2 = {}
    var_1 = compile_general_ledger_program(dict_1, dict_2)
    assert callable(var_1)
    var_2 = var_1(date_range_1)