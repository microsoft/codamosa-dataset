

# Generated at 2022-06-26 00:31:02.603340
# Unit test for function build_general_ledger
def test_build_general_ledger():
    account_0 = test_case_0()
    period_0 = DateRange()
    journal_0 = List[JournalEntry[_T]]
    initial_0 = Dict[Account, Balance]
    test_build_general_ledger_0 = build_general_ledger(period_0, journal_0, initial_0)


# Generated at 2022-06-26 00:31:05.187764
# Unit test for method add of class Ledger
def test_Ledger_add():
    __test_Ledger = Ledger()
    type_1 = Posting()
    __actual = __test_Ledger.add(type_1)
    assert type(__actual) == LedgerEntry


# Generated at 2022-06-26 00:31:06.587865
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

# Generated at 2022-06-26 00:31:11.891214
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Define arguments:
    period_0 = test_case_0()
    journal_0 = test_case_0()
    initial_0 = test_case_0()
    ## Invoke the function and check the result
    result_0 = build_general_ledger(period_0, journal_0, initial_0)
    assert isinstance(result_0, GeneralLedger)


# Generated at 2022-06-26 00:31:12.805184
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()

# Generated at 2022-06-26 00:31:20.083071
# Unit test for function build_general_ledger
def test_build_general_ledger():
    account_0 = module_0.Account()
    journal_0 = [None]
    initial_0 = {account_0: None}
    period_0 = DateRange(since=None, until=None)
    function_0 = build_general_ledger(period_0, journal_0, initial_0)
    ledger_0 = function_0.ledgers.get(account_0)
    assert ledger_0.account == account_0
    assert ledger_0.initial == initial_0.get(account_0)
    assert ledger_0.entries == []


# Generated at 2022-06-26 00:31:23.935357
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Test case 0
    ledger_0 = Ledger(account_0,Balance(1,1))
    entry_0 = ledger_0.add(Posting(date=1,amount=1,direction=1,journal=Journal(debit=1,credit=1,description=1,postings=1)))


# Generated at 2022-06-26 00:31:30.131932
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = module_0.Account()
    quantity_0 = Quantity(Decimal(0))
    balance_0 = Balance(datetime.date(2020, 3, 13), quantity_0)
    ledger_0 = Ledger(account_0, balance_0)
    account_1 = module_0.Account()
    quantity_1 = Quantity(Decimal(0))
    account_2 = module_0.Account()
    quantity_2 = Quantity(Decimal(0))
    amount_0 = Amount(Decimal('3E'))
    direction_0 = module_0.Direction.DEBIT
    posting_0 = Posting(account_1, quantity_1, direction_0, datetime.date(2019, 3, 23), amount_0)

# Generated at 2022-06-26 00:31:32.328230
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True == True
    # TODO: Should be replaced with a proper test.
    # test_case_0()



# Generated at 2022-06-26 00:31:38.423772
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Test type hint for the method add,
    # the purpose of this test is to make sure that type hint is checked by mypy.
    account_0 = module_0.Account()
    ledger_0 = Ledger(account_0, Balance(datetime.date.today(), Decimal(0)))
    assert isinstance(ledger_0.add(Posting(datetime.date.today(), Decimal(0), module_0.Account(), module_0.Account())), LedgerEntry)


# Generated at 2022-06-26 00:31:46.775486
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(read_initial_balances_0, list_0)
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)

# Generated at 2022-06-26 00:31:55.006187
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_var = datetime.date.fromisoformat("2000-01-01")


    from .accounts import Account
    account_var = Account("test")


    amount_var = Amount("1")
    direction_var = Posting.Direction.debit


    from .journaling import Journal
    journal_var = Journal("test", "test", date_var, [Posting(account_var, amount_var, direction_var)])


    ledger_obj = Ledger(account_var,Balance(date_var,Quantity("0")))
    posting_var = Posting(account_var, amount_var, direction_var)

    assert isinstance(ledger_obj.add(posting_var), LedgerEntry)


# Generated at 2022-06-26 00:32:04.054593
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    list_0 = [read_initial_balances_0, read_initial_balances_0, read_initial_balances_0]
    var_0 = compile_general_ledger_program(read_initial_balances_0, list_0)
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    list_1 = [var_0, var_0, var_0]
    var_2 = compile_general_ledger_program(var_0, list_1)
    var_3 = compile_general_ledger_program(var_2, list_1)

# Generated at 2022-06-26 00:32:04.900163
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()

# Generated at 2022-06-26 00:32:14.034444
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Test Case #0:
    read_initial_balances_0 = None
    list_0 = [read_initial_balances_0, read_initial_balances_0, read_initial_balances_0]
    var_0 = compile_general_ledger_program(read_initial_balances_0, list_0)
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)

    # Test Case #1:
    build_general_ledger(None, [None, None, None, None], {None: None})
    # Test Case #2:
    build_general_ledger(None, [None, None, None, None], {None: None})
    # Test Case #3:

# Generated at 2022-06-26 00:32:16.104636
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = None
    period_0 = None
    assert read_initial_balances_0(period_0) == None



# Generated at 2022-06-26 00:32:24.064731
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    list_0 = [read_initial_balances_0, read_initial_balances_0, read_initial_balances_0]
    var_0 = compile_general_ledger_program(read_initial_balances_0, list_0)
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)


# Generated at 2022-06-26 00:32:30.104779
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = compile_general_ledger_program(compile_general_ledger_program, test_case_0)
    date_range_0 = DateRange(datetime.date(2, 1, 1), datetime.date(2, 1, 2))
    str_0 = read_initial_balances_0.__call__(date_range_0)


# Generated at 2022-06-26 00:32:41.304904
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import AccountCategory

    read_initial_balances_0 = None

    ## Create the initial balance for the account to be used for the test.
    initial = {
        Account(AccountCategory.ASSET, "2080", "Test Account"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))
    }

    ## Create journal entries for the test:

# Generated at 2022-06-26 00:32:44.819992
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Input argument for method:
    period_0 = None
    ## Output argument for method:
    result_0 = None
    ## Unit test for method __call__:
    print(period_0)
    print(result_0)


# Generated at 2022-06-26 00:32:57.764517
# Unit test for function build_general_ledger
def test_build_general_ledger():
    initial_balances_0 = {}
    initial_balances_0[Account(66)] = Balance(datetime.date(2, 2, 1), Quantity(1.0))
    initial_balances_0[Account(66)] = Balance(datetime.date(1, 2, 1), Quantity(6.0))
    initial_balances_0[Account(66)] = Balance(datetime.date(1, 1, 1), Quantity(5.0))
    initial_balances_0[Account(66)] = Balance(datetime.date(0, 1, 1), Quantity(4.0))
    initial_balances_0[Account(66)] = Balance(datetime.date(0, 2, 1), Quantity(3.0))

# Generated at 2022-06-26 00:33:10.491811
# Unit test for function build_general_ledger
def test_build_general_ledger():
    read_initial_balances_0 = None
    list_0 = [read_initial_balances_0, read_initial_balances_0, read_initial_balances_0]
    var_0 = compile_general_ledger_program(read_initial_balances_0, list_0)
    date_range_0 = DateRange(datetime.date(2017, 10, 1), datetime.date(2018, 1, 1))
    var_1 = build_general_ledger(date_range_0, list_0, read_initial_balances_0)
    list_1 = []
    assert var_1 == GeneralLedger(date_range_0, {})

# Generated at 2022-06-26 00:33:17.737550
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = [ReadInitialBalances, ReadInitialBalances]
    for i_0 in var_0:
        var_0 = [ReadInitialBalances, ReadInitialBalances]
        for i_1 in var_0:
            try:
                var_0 = [ReadInitialBalances, ReadInitialBalances]
                for i_2 in var_0:
                    i_0 = ReadInitialBalances
                    i_1 = ReadInitialBalances
                    i_2 = ReadInitialBalances
                    var_0 = compile_general_ledger_program(i_0, i_1)
            except Exception:
                pass


# Generated at 2022-06-26 00:33:19.089950
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # TODO: Implement unit test: test_ReadInitialBalances___call__
    assert False

# Generated at 2022-06-26 00:33:25.223941
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Initialize:
    a = [0]

    ## Create the account ledger and a journal entry:
    l = Ledger(None, Balance(None, a[0]))
    je = JournalEntry(None, None, None)

    ## Create the posting and add it to the ledger:
    p = Posting(je, None, a[0])
    le = l.add(p)

    # assert le.balance.value == a[0] + a[0]


# Generated at 2022-06-26 00:33:26.242470
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass



# Generated at 2022-06-26 00:33:34.612307
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test method __call__ of class GeneralLedgerProgram
    """
    e_0 = read_initial_balances_0
    e_1 = list_0
    e_2 = compile_general_ledger_program(e_0, e_1)
    f_0 = read_initial_balances_0
    f_1 = e_2
    f_2 = compile_general_ledger_program(f_0, f_1)
    f_3 = DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 2))
    f_4 = f_2.__call__(f_3)
    f_5 = type(f_4)

# Generated at 2022-06-26 00:33:35.810718
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = None



# Generated at 2022-06-26 00:33:40.025267
# Unit test for method add of class Ledger
def test_Ledger_add():
    # getinstance:
    ledger_0 = Ledger('ledger_0')
    # getattribute:
    # getattr:
    posting_0 = Posting(ledger_0, 'posting_0')
    ledger_0.add(posting_0)


# Generated at 2022-06-26 00:33:42.429175
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = None
    period_0 = None
    var_0 = read_initial_balances_0(period_0)


# Generated at 2022-06-26 00:33:53.132836
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Test case for __call__ of class ReadInitialBalances
    """
    var_0 = {}
    var_1 = ReadInitialBalances.__call__(var_0, var_0)


# Generated at 2022-06-26 00:33:54.711114
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    obj = ReadInitialBalances()
    assert isinstance(obj.__call__(), InitialBalances)


# Generated at 2022-06-26 00:34:04.479452
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from dataclasses import dataclass
    from typing import Dict, Iterable, List, Optional
    from .accounts import Account
    from .journaling import (
        DateRange,
        JournalEntry,
        Posting,
        PostingDirection,
        Quantity,
        build_journal,
        journal_prefix,
    )
    from .generic import Balance
    @dataclass
    class Journal(_Journal[None]):
        pass
    @dataclass
    class LedgerEntry(Generic[None]):
        pass
    @dataclass
    class Ledger(_Ledger[None]):
        pass
    @dataclass
    class GeneralLedger(_GeneralLedger[None]):
        pass
    var_2 = DateRange(2020, 1, 1, 2020, 12, 31)

# Generated at 2022-06-26 00:34:06.258130
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)


# Generated at 2022-06-26 00:34:10.540969
# Unit test for function build_general_ledger
def test_build_general_ledger():
    
    # Setup the inputs:
    var_0 = {} # type: DateRange
    var_1 = [var_0] # type: Iterable[JournalEntry[_T]]
    var_2 = var_0 # type: InitialBalances
    
    # Perform the test:
    var_3 = build_general_ledger(var_0, var_1, var_2)
    
    # Verify the results:
    assert False


# Generated at 2022-06-26 00:34:12.771839
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = test_case_0()
    var_0.entries = []
    var_1 = var_0.add(var_0)



# Generated at 2022-06-26 00:34:15.014534
# Unit test for function build_general_ledger
def test_build_general_ledger():

    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)
    return var_1



# Generated at 2022-06-26 00:34:15.948330
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:34:26.146830
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting, Transaction
    from .transactions import TransactionHandler
    from .transactions.assets import AssetJournal, DepositCash, DisposeAsset, ReceiveAsset

    var_0 = AssetJournal()
    var_1 = datetime.date.fromisoformat('2020-01-01')
    var_2 = Transaction('2020-01-01', 'Receive $100 from the customer', var_0.receive_from_customer(100))
    var_3 = TransactionHandler()
    var_3.post_transaction(var_2)
    var_4 = GeneralLedger(var_1, var_0, var_3, var_0)

# Generated at 2022-06-26 00:34:28.295792
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)

# Generated at 2022-06-26 00:34:43.386018
# Unit test for method add of class Ledger
def test_Ledger_add():
    assert True

# Generated at 2022-06-26 00:34:50.599918
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    # Setup test inputs:
    dt_0 = {'since':datetime.datetime(2019, 1, 1),'until':datetime.datetime(2019, 12, 31)}
    dt_1 = {'since':datetime.datetime(2019, 1, 1),'until':datetime.datetime(2019, 12, 31)}

    # Call function to be tested:
    var_0 = compile_general_ledger_program(dt_0, dt_1)

    # Assert expected outputs:
    assert callable(var_0)

# Generated at 2022-06-26 00:34:52.991042
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)
    var_1 = var_0.__call__(test_case_0)

# Generated at 2022-06-26 00:34:54.363171
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def test(read_journal_entries, read_initial_balances):
        assert True
    test(None, None)


# Generated at 2022-06-26 00:34:56.517380
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances()
    var_1 = DateRange()
    var_2 = var_0.__call__(var_1)


# Generated at 2022-06-26 00:35:07.851409
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Import dependencies:
    from .journaling import CreateJournalEntry, CreatePosting, CreateJournal

    ## Define compile function to keep things short:
    def _compile(a, b) -> GeneralLedgerProgram[_T]:
        return compile_general_ledger_program(a, b)

    ## Create test inputs:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-26 00:35:21.214321
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = {
        "account": "account",
        "initial": Ledger.Balance,
        "entries": [],
    }
    var_1 = {}
    var_2 = "posting"
    var_3 = Ledger.add(var_1, var_2)
    var_4 = "balance"
    var_5 = "amount"
    var_6 = "account"
    var_7 = "description"
    var_8 = "entry"
    var_9 = [var_8]
    var_10 = "date"
    var_11 = "entries"
    var_12 = "ledger"
    var_13 = "posting"
    var_14 = "is_debit"
    var_15 = "debit"
    var_16 = "credit"
   

# Generated at 2022-06-26 00:35:23.835539
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert callable(compile_general_ledger_program)


# Generated at 2022-06-26 00:35:27.691233
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = {}
    var_1 = test_ReadInitialBalances___call__()
    var_2 = ReadInitialBalances.__call__(var_1, var_0)



# Generated at 2022-06-26 00:35:38.182963
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import datetime
    var_0 = datetime.date(2019, 3, 29)
    var_1 = datetime.date(2020, 3, 28)
    var_2 = datetime.date(2020, 4, 1)
    var_3 = datetime.date(2020, 5, 1)
    var_4 = {}
    var_5 = {}
    var_6 = build_general_ledger(var_1, var_4, var_5)
    var_7 = compile_general_ledger_program(var_4, var_5)
    var_8 = var_7(var_1)
    var_9 = var_7(var_0)

# Generated at 2022-06-26 00:36:33.019822
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .generic import ReadInitialBalances, ReadJournalEntries, build_general_ledger
    from .journaling import Journal, JournalEntry, Posting
    from .accounts import Account, AccountKind

    # Setup
    var_0 = []
    var_1 = Account(AccountKind.ASSET, "", "", 0, "")
    var_2 = Journal([], var_0)
    var_3 = JournalEntry(var_2, var_0, var_0)
    var_4 = Account(AccountKind.ASSET, "", "", 0, "")
    var_5 = Posting(var_4, var_0, var_0)
    var_6 = Journal([], var_0)
    var_7 = JournalEntry(var_6, var_0, var_0)

# Generated at 2022-06-26 00:36:35.876781
# Unit test for function build_general_ledger
def test_build_general_ledger():
    for _ in range(1000):
        var_0 = {}
        var_1 = build_general_ledger(var_0, var_0, var_0)



# Generated at 2022-06-26 00:36:43.942488
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Compile the program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Run the program and collect the result:
    result = program(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)))

    ## Check the result:
    assert result.ledgers[Account("10100")].initial.value == Decimal(1000)
    assert result.ledgers[Account("10100")].entries[0].balance == Decimal(3200)
    assert result.ledgers[Account("10200")].initial.value == Decimal(2000)
    assert result.ledgers[Account("10200")].entries[0].balance == Decimal(2600)

# Generated at 2022-06-26 00:36:53.338867
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    var_0 = {
        Account('3010', 'PURCHASES'): Balance(datetime.date(2014, 2, 5), Quantity(0)),
    }

# Generated at 2022-06-26 00:36:55.091156
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_1 = {}
    var_2 = build_general_ledger(var_1, var_1, var_1)


# Generated at 2022-06-26 00:36:56.217488
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # The method is tested via test_case_0
    pass


# Generated at 2022-06-26 00:36:58.416183
# Unit test for function build_general_ledger
def test_build_general_ledger():
    a = build_general_ledger(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 1, 1)), [], {})


# Generated at 2022-06-26 00:37:03.611441
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests that a general ledger program can be compiled.
    """
    ## Instantiating a class from the GeneralLedgerProgram protocol.
    class _GeneralLedgerProgram(_T):
        def __call__(self, period: DateRange) -> GeneralLedger[_T]:
            pass  # pragma: no cover

    _program: GeneralLedgerProgram[_T] = compile_general_ledger_program(_GeneralLedgerProgram(), _GeneralLedgerProgram())
    assert _program

""" Disabled content
"""

# Generated at 2022-06-26 00:37:08.503232
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Taken from test case 0 of compile_general_ledger_program:
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)
    var_2 = compile_general_ledger_program(var_0, var_0);
    var_3 = var_2(var_0);
    assert(var_1 == var_3)



# Generated at 2022-06-26 00:37:11.340445
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = var_1 = var_2 = None
    assert build_general_ledger(var_0, var_1, var_2) is None


if __name__ == "__main__":
    test_case_0()
    test_build_general_ledger()

# Generated at 2022-06-26 00:38:13.437185
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program()
    var_1 = var_0(var_0, var_0)
    var_2 = var_1(var_0)


# Generated at 2022-06-26 00:38:20.602958
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert (
        compile_general_ledger_program(lambda period: {}, lambda period: {}, None)
        .__call__(None)
        .__class__.__name__
        == "GeneralLedger"
    )
    assert (
        compile_general_ledger_program(test_case_0, lambda period: {}, None)
        .__call__(None)
        .__class__.__name__
        == "GeneralLedger"
    )
    assert (
        compile_general_ledger_program(lambda period: {}, test_case_0, None)
        .__call__(None)
        .__class__.__name__
        == "GeneralLedger"
    )

# Generated at 2022-06-26 00:38:22.274310
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = test_ReadInitialBalances___call__.var_0
    var_1 = var_0()


# Generated at 2022-06-26 00:38:29.205647
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print('Testing function build_general_ledger')
    # [('build_general_ledger', (None,), {'period': None, 'journal': None, 'initial': None})]
    test_build_general_ledger_generator = test_case_0()
    test_build_general_ledger_solution = GeneralLedger(None, {})
    for (x, y) in zip(test_build_general_ledger_generator, test_build_general_ledger_solution.__dict__.items()):
        assert x == y


# Generated at 2022-06-26 00:38:32.082886
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests that compile_general_ledger_program returns a function object.
    """
    assert callable(compile_general_ledger_program(test_case_0,test_case_0))


# Generated at 2022-06-26 00:38:35.489780
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """Unit test for method __call__ of class ReadInitialBalances"""
    passed = False
    try:
        var_0 = ReadInitialBalances()
        var_0.__call__(var_0)
        passed = True
    except:
        passed = False
    assert passed


# Generated at 2022-06-26 00:38:44.230987
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest import mock
    from unittest.mock import Mock
    from .accounts import Account


    @dataclass
    class _MyReadInitialBalances(ReadInitialBalances):

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    m = mock.Mock(spec=_MyReadInitialBalances)

    var_0 = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    var_1 = Account("_")
    var_2 = Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0)))
    var_3 = InitialBalances({var_1: var_2})
    var_4 = Mock(return_value=var_3)
    var_5 = var_4()

# Generated at 2022-06-26 00:38:52.369332
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from hypothesis import given
    from hypothesis.strategies import SearchStrategy
    from ..accounts.models import Account
    from ..journaling.models import JournalEntry
    from .accounts import Balance
    from .journaling import Posting
    import dataclasses
    import datetime

    # Strategy for generating instances of class 'Balance' (test case 0).
    balance_strategy_0 = dataclasses.make_dataclass(
        'Balance_test_case_0',
        (
            ( 'account', SearchStrategy(Account) ),
            ( 'value', SearchStrategy(Decimal) ),
            ( 'date', SearchStrategy(datetime.date) ),
        ),
    )
    # Strategy for generating instances of class 'GeneralLedger' (test case 0).

# Generated at 2022-06-26 00:38:53.289993
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:38:54.876558
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = {var_0: var_0}
    return var_1
