

# Generated at 2022-06-26 00:31:15.275863
# Unit test for method add of class Ledger
def test_Ledger_add():
    class MockJournalEntry(JournalEntry):
        pass

    class MockPosting(Posting):
        pass

    l = Ledger(Account(1000, "Assets", None, None), Balance(datetime.date(1999,1,1), Quantity(Decimal(0))))

# Generated at 2022-06-26 00:31:17.642094
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    general_ledger_program = None
    period = None
    general_ledger_program___call__ = general_ledger_program.__call__(period)


# Generated at 2022-06-26 00:31:26.965114
# Unit test for method add of class Ledger
def test_Ledger_add():
    @dataclass
    class Account(object):
        name: str
        number: int

    @dataclass
    class Thing(object):
        a: str

    @dataclass
    class Posting(object):
        thing: Thing
        account: Account
        amount: Amount
        date: datetime.date
        direction: int

    @dataclass
    class JournalEntry(object):
        description: str
        date: datetime.date
        postings: List[Posting]

    @dataclass
    class Balance(object):
        date: datetime.date
        value: Quantity

    @dataclass
    class Ledger(object):
        account: Account
        initial: Balance
        entries: List[Posting] = field(default_factory=list, init=False)


# Generated at 2022-06-26 00:31:27.620835
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-26 00:31:37.164251
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from dataclasses import replace
    from datetime import date
    from decimal import Decimal
    from typing import Any
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account

    # test target:
    from .ledgering import GeneralLedger, InitialBalances, Ledger, GeneralLedgerProgram

    # test case:
    # - given:
    #     * a read initial balances function
    #     * a read journal entries function
    #     * an accounting period
    # - when:
    #     * invoking a general ledger program with the given parameters
    # - then:
    #     * a general ledger is returned, with accounts and ledgers as per read journal entries function

    # define test parameters:
    read_initial_balances_0

# Generated at 2022-06-26 00:31:42.454465
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger(Account(Number=1), Balance(Date=1, Value=Quantity(Decimal(1))))
    p = Posting(Direction=Direction.Debit, Amount=Quantity(Decimal(1)), Journal=JournalEntry(Date=1, Description="First"))
    le = l.add(p)
    assert le.balance == 2
    assert le.balance == 2

# Generated at 2022-06-26 00:31:46.818556
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange.parse('2018-06-01/2018-06-30')
    actual_0 = read_initial_balances_0(period_0)
    actual_1 = type(actual_0) is dict
    assert actual_1 is True


# Generated at 2022-06-26 00:31:47.387877
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-26 00:31:48.319573
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:31:52.686834
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_8 = ReadInitialBalances()
    date_range_9 = DateRange(datetime.date(1973, 9, 9), datetime.date(2021, 1, 5))
    initial_balances_10 = read_initial_balances_8.__call__(date_range_9)
    assert initial_balances_10 == dict()

# Generated at 2022-06-26 00:32:00.114744
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    var_0 = ReadInitialBalances()
    var_1 = var_0(date_range_0)


# Generated at 2022-06-26 00:32:04.861445
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    iterable_0 = None
    dict_0 = {}
    function_0 = compile_general_ledger_program(dict_0, iterable_0)
    var_0 = function_0(date_range_0)

# Generated at 2022-06-26 00:32:07.511354
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    var_0 = ReadInitialBalances()(date_range_0)


# Generated at 2022-06-26 00:32:09.255221
# Unit test for method add of class Ledger
def test_Ledger_add():
    obj_0 = None
    var_0 = obj_0.add(None)


# Generated at 2022-06-26 00:32:16.721866
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_cases = [
        # (expected, period, journal, initial)
        (None, None, None, None)
    ]

    for i, (expected, period, journal, initial) in enumerate(test_cases):
        with it('test case {}'.format(i)):
            assert expected == build_general_ledger(period, journal, initial)

import pypara.commons.numbers as module_0
import pypara.journaling as module_1
from dataclasses import dataclass
from decimal import Decimal
from typing import List, TypeVar

#: Defines a generic type variable.
_T = TypeVar("_T")


# Generated at 2022-06-26 00:32:17.674163
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-26 00:32:26.406884
# Unit test for method add of class Ledger
def test_Ledger_add():
  date_0 = datetime.date(2020, 10, 20)
  quantity_0 = pypara.commons.numbers.Quantity(Decimal('-13.93'))
  balance_0 = pypara.accounting.generic.Balance(date_0, quantity_0)
  account_0 = pypara.accounting.accounts.Account(123456, 'Some Account', 'SOMETHING', 'SOMETHING', 'SOMETHING')
  ledger_0 = pypara.accounting.ledgers.Ledger(account_0, balance_0)
  date_1 = datetime.date(2020, 10, 20)
  date_2 = datetime.date(2020, 10, 20)
  date_range_0 = module_0.DateRange(date_1, date_2)
  account_

# Generated at 2022-06-26 00:32:28.124391
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = module_0.DateRange(None, None)
    test_case_0()

# Generated at 2022-06-26 00:32:40.141696
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_0 = datetime.date(1960, 12, 11)
    date_1 = datetime.date(1961, 12, 11)
    date_range_0 = module_0.DateRange(date_0, date_1)
    decimal_0 = Decimal('6.40')
    balance_0 = Balance(date_0, Quantity(decimal_0))
    account_0 = Account('', '', '', '')
    ledger_0 = Ledger(account_0, balance_0)
    amount_0 = Amount(decimal_0)
    direction_0 = None
    date_2 = datetime.date(1957, 12, 11)
    journal_0 = JournalEntry(date_2, '', [])
    account_1 = Account('', '', '', '')
    posting_0 = Posting

# Generated at 2022-06-26 00:32:40.745632
# Unit test for function build_general_ledger
def test_build_general_ledger():
    return None


# Generated at 2022-06-26 00:32:53.949411
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    obj = compile_general_ledger_program(test_case_0, test_case_0)
    obj.__call__(test_case_0())

test_GeneralLedgerProgram___call__()

# Generated at 2022-06-26 00:32:54.527494
# Unit test for function compile_general_ledger_program

# Generated at 2022-06-26 00:32:55.405877
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()

# Generated at 2022-06-26 00:33:01.423408
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Posting

    # Setup
    account_0 = None  # type: Account
    balance_0 = Balance(date_0, Quantity(Decimal('0')))
    var_0 = Ledger(account_0, balance_0)  # type: Ledger[None]
    journal_0 = None  # type: JournalEntry[None]
    account_1 = None  # type: Account
    direction_0 = None  # type: Direction
    amount_0 = Amount(Decimal('0'))
    var_1 = Posting(journal_0, account_1, direction_0, amount_0)  # type: Posting[None]

    # Invocation
    var_0.add(var_1)

# Generated at 2022-06-26 00:33:02.396507
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert False


import pypara.commons.zeitgeist as module_0


# Generated at 2022-06-26 00:33:03.730748
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    callable_0 = 0
    callable_1 = 0
    var_0 = compile_general_ledger_program(callable_0, callable_1)

# Generated at 2022-06-26 00:33:16.104316
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from pypara.commons.zeitgeist import DateRange
    from pypara.accounting.journaling import JournalEntry, Posting, Transaction,  build_journal_entry,  compile_journaling_program
    from pypara.accounting.accounts import Account

    ## Some housekeeping:
    def _build_posting(account: Account, amount: Amount, date: datetime.date = datetime.date.today()) -> Posting[int]:
        transaction = Transaction()
        return build_journal_entry(amount, account, date=date, transaction=transaction)

    ## Build a transaction, a journal entry and post it:

# Generated at 2022-06-26 00:33:17.428903
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()

import pypara.commons.numbers as module_1


# Generated at 2022-06-26 00:33:27.460442
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    class _ReadInitialBalances():
        def __call__(self, period: module_0.DateRange) -> dict:
            return {}
    read_initial_balances_0 = _ReadInitialBalances()
    class _ReadJournalEntries():
        def __call__(self, period: module_0.DateRange) -> list:
            return []
    read_journal_entries_0 = _ReadJournalEntries()
    function_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    var_0 = function_0(date_range_0)
    assert var_0 is not None


# Generated at 2022-06-26 00:33:30.906999
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    var_0 = ReadInitialBalances.__call__(ReadInitialBalances, date_range_0)


# Generated at 2022-06-26 00:33:44.063712
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:33:44.901237
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:33:46.412556
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    instance_0 = GeneralLedgerProgram()
    assert instance_0.__call__(date_range_0) is None


# Generated at 2022-06-26 00:33:52.238898
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    read_journal_entries_0 = None
    var_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    var_0(date_range_0)

# Generated at 2022-06-26 00:33:55.324237
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    arg_0 = ReadInitialBalances.__call__(date_range_0)
    pass



# Generated at 2022-06-26 00:34:02.047070
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import pypara.commons.zeitgeist as module_0
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    class MockProxy_1:
        def __call__(self, period: module_0.DateRange) -> dict:
            assert period == date_range_0

            return dict()
    mock_proxy_1 = MockProxy_1()

    mock_proxy_1(date_range_0)


# Generated at 2022-06-26 00:34:09.488119
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Define test data.
    date_range_0 = module_0.DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31))
    journal_entries: List[JournalEntry[None]] = []
    initial_balances: Dict[Account, Balance] = {}
    ## Execute the program:
    var_0 = build_general_ledger(date_range_0, journal_entries, initial_balances)
    ## Validate the results:
    assert var_0.period == date_range_0
    assert var_0.ledgers == {}
    ## Define test data.
    date_range_0 = module_0.DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31))

# Generated at 2022-06-26 00:34:10.307196
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

# Generated at 2022-06-26 00:34:11.209228
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()

# Generated at 2022-06-26 00:34:16.507214
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    iterable_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_0)

    for key in var_0.ledgers:
        var_1 = var_0.ledgers[key]
        var_2 = var_1.add(None)

# Generated at 2022-06-26 00:34:43.104409
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    var_0 = GeneralLedgerProgram___call__(date_range_0)


# Generated at 2022-06-26 00:34:44.854584
# Unit test for function build_general_ledger
def test_build_general_ledger():
    try:
        test_case_0()
    except Exception:
        assert False

import pypara.journaling as module_1


# Generated at 2022-06-26 00:34:50.183007
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = datetime.date(year=1, month=1, day=1)
    date_range_0 = module_0.DateRange(date_0, date_0)
    funct_0 = compile_general_ledger_program()
    var_0 = funct_0(date_range_0)


# Generated at 2022-06-26 00:34:59.519055
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import pypara.commons.numbers as var_0
    from typing import Dict
    from typing import List
    from typing import Optional
    import pypara.domain.accounts as var_1
    from pypara.domain.accounts import Account, Balance
    def function_0(x: DateRange) -> Dict[Account, Balance]:
        return {}
    import datetime as var_2
    from typing import Iterable
    from typing import cast
    from pypara.domain.journaling import JournalEntry
    def function_1(x: DateRange) -> Iterable[JournalEntry]:
        return []
    var_1 = compile_general_ledger_program(function_0, function_1)
    var_2 = var_2.date(2019, 10, 3)
    var_3 = var_2.date

# Generated at 2022-06-26 00:35:06.677643
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    read_journal_entries_0 = None
    var_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    var_1 = var_0(date_range_0)


# Generated at 2022-06-26 00:35:13.900411
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    iterable_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_0)

# Generated at 2022-06-26 00:35:18.039276
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(account=Account('asset.cash'), initial=Balance(date=datetime.date(2017, 1, 1), value=Quantity(20)))
    posting = Posting(account=Account('asset.cash'), amount=Amount(1), direction=Decimal(1), journal=JournalEntry(description='Description', date=datetime.date(2017, 1, 2)))
    result = ledger.add(posting=posting)
    assert(isinstance(result, LedgerEntry))
    assert(result.account == 'asset.cash')
    assert(result.amount == Amount(1))
    assert(result.date == datetime.date(2017, 1, 2))
    assert(result.description == 'Description')
    assert(result.debit == Amount(1))
    assert(result.credit == None)

# Unit

# Generated at 2022-06-26 00:35:24.077019
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    posting_0 = None
    var_1 = Ledger(None, Balance(date_range_0.since, Quantity(Decimal(0))))
    ledger_entry_0 = var_1.add(posting_0)


# Generated at 2022-06-26 00:35:28.034862
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # TODO: build unit test
    pass

import pypara.journaling.accounts as module_1
import pypara.journaling.journaling as module_2
import pypara.journaling.journaling as module_3

# Generated at 2022-06-26 00:35:39.406854
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_0 = datetime.date.today()
    date_1 = datetime.date.today()
    date_2 = datetime.date.today()
    date_range_0 = module_0.DateRange(date_0, date_1)
    direction_0 = 0
    var_0 = Balance(date_2, direction_0)
    account_0 = Account()
    var_1 = Ledger(account_0, var_0)
    var_2 = Decimal(0)
    var_3 = Quantity(var_2)
    direction_1 = 0
    var_4 = Posting(direction_1, var_3, date_0)
    var_1.add(var_4)


# Generated at 2022-06-26 00:36:28.651075
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass



# Generated at 2022-06-26 00:36:38.944318
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = module_0.DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 1))
    list_0 = []
    dict_0 = {}
    function_0 = ReadInitialBalances()
    function_0.__call__ = lambda arg_0: dict_0
    test_case_0()
    var_0 = build_general_ledger(date_range_0, list_0, dict_0)
    function_0 = ReadJournalEntries()
    function_0.__call__ = lambda arg_0: list_0
    function_0 = ReadInitialBalances()
    function_0.__call__ = lambda arg_0: dict_0
    var_1 = test_case_0()
    assert var_0 == var_1


# Generated at 2022-06-26 00:36:41.914087
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    param_call_0 = ReadInitialBalances()
    var_return = param_call_0.__call__(date_range_0)


# Generated at 2022-06-26 00:36:43.812032
# Unit test for method add of class Ledger
def test_Ledger_add():
    print("\n>>> Ledger.add")
    ledger_0 = Ledger(None, None)
    posting_0 = None
    ledger_0.add(posting_0)


# Generated at 2022-06-26 00:36:48.472366
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_0 = datetime.date(2020, 3, 24)
    date_1 = datetime.date(2020, 3, 24)
    date_range_0 = module_0.DateRange(date_0, date_1)
    iterable_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_0)
    from .accounts import Account
    account_0 = Account('A')
    from .generic import Balance
    balance_0 = Balance(None, None)
    ledger_0 = Ledger(account_0, balance_0)
    from .journaling import Posting
    posting_0 = Posting(None, None, None)
    var_1 = ledger_0.add(posting_0)

# Generated at 2022-06-26 00:36:57.694010
# Unit test for method add of class Ledger
def test_Ledger_add():
    date = None
    date_range = DateRange(date, date)
    journal = None
    initial = {}
    general_ledger = build_general_ledger(date_range, journal, initial)
    unit = general_ledger.ledgers
    assert len(unit) > 0
    for a in unit.values():
        assert a.account is not None
        assert a.initial is not None
        assert type(a.entries) is list
        posting = None
        result = a.add(posting)
        assert type(result) is LedgerEntry
        assert result.ledger is a
        assert result.posting is posting
        assert type(result.balance) is Quantity
        assert result.date == posting.date
        assert result.description == posting.journal.description
        assert result.amount == posting.amount

# Generated at 2022-06-26 00:37:05.486379
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import pypara.ledgers.journaling as module_0

    def _read_initial_balances(period):
        assert period is DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
        return {}

    def _read_journal_entries(period):
        assert period is DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
        return []

    compile_general_ledger_program(_read_initial_balances, _read_journal_entries)()(
        DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    )

# Generated at 2022-06-26 00:37:09.700057
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    iterable_0 = None
    dict_0 = {}
    read_journal_entries_0 = None
    program_0 = compile_general_ledger_program(dict_0, read_journal_entries_0)
    var_0 = program_0.__call__(date_range_0)

# Generated at 2022-06-26 00:37:21.470488
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Variables used in test
    date_0 = datetime.date(2019, 4, 2)
    str_0 = "description"
    journal_entry_0 = JournalEntry(date_0, str_0)
    list_0 = []
    journal_entry_0.postings = list_0
    str_1 = "account"
    int_0 = 0
    account_0 = Account(str_1, int_0)
    int_1 = 0
    posting_0 = Posting(journal_entry_0, account_0, int_1)
    date_1 = datetime.date(2019, 4, 3)
    balance_0 = Balance(date_1, Quantity(0))
    account_1 = account_0
    ledger_0 = Ledger(account_1, balance_0)
    date_2

# Generated at 2022-06-26 00:37:27.182192
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, None, dict_0)
    callable_0 = None
    var_1 = var_0.ledgers.values()
    var_2 = next(iter(var_1))
    var_3 = var_2.add(callable_0)


# Generated at 2022-06-26 00:38:26.533598
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = '\n>>> read_initial_balances'
    str_1 = '\n>>> period'
    str_2 = '\n>>> general_ledger'
    str_3 = '\n>>> read_initial_balances'
    str_4 = '\n>>> read_journal_entries'
    var_00 = compile_general_ledger_program(str_0, str_1)
    var_01 = var_00(str_2)
    var_02 = var_01(str_3)
    test_case_0()
    return

# Generated at 2022-06-26 00:38:28.285077
# Unit test for method add of class Ledger
def test_Ledger_add():
    print('Testing Ledger.add method:')
    test_case_0()
    print('Method Ledger.add tested successfully.')


# Generated at 2022-06-26 00:38:29.170239
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:38:29.975688
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_case_0()


# Generated at 2022-06-26 00:38:30.941761
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:38:32.481946
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_1 = compile_general_ledger_program(datetime.date, str)


# Generated at 2022-06-26 00:38:34.844122
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    general_ledger_program_0 = compile_general_ledger_program(None, None)
    int_0 = general_ledger_program_0()
    general_ledger_program_0.__call__()

# Generated at 2022-06-26 00:38:38.158923
# Unit test for method add of class Ledger
def test_Ledger_add():
    print(test_case_0.__doc__)
    try:
        test_case_0()
    except Exception as e:
        print(f'FAIL: test_case_0 failed with exception {e}')
    else:
        print(f'PASS: test_case_0')


# Generated at 2022-06-26 00:38:38.970532
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_case_0()


# Generated at 2022-06-26 00:38:39.738346
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...

