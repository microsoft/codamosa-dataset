

# Generated at 2022-06-26 00:31:11.013924
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger(Account(1), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))))
    posting_1 = Posting(JournalEntry(datetime.date(2018, 1, 2), 'test', [1, 2], [3, 4]), Account(1), 1, Decimal(100))
    new_l = l.add(posting_1)
    assert len(new_l.entries) == 1
    assert new_l.entries[0].posting == posting_1
    assert new_l.entries[0].balance == Quantity(Decimal(100))
    posting_2 = Posting(JournalEntry(datetime.date(2018, 1, 2), 'test', [1, 2], [3, 4]), Account(1), -1, Decimal(50))

# Generated at 2022-06-26 00:31:14.029649
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange()
    initial_balances_0 = read_initial_balances_0(period_0)
    print(str(initial_balances_0))



# Generated at 2022-06-26 00:31:20.417404
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Given
    period = DateRange(datetime.date(2015, 1, 1), datetime.date(2015, 12, 31))
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()

    # When
    program = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)

    # Then
    assert program is not None
    assert callable(program)

# Generated at 2022-06-26 00:31:21.309774
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-26 00:31:22.186076
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

# Generated at 2022-06-26 00:31:23.582416
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True  # This is not a good test, just a placeholder!


# Generated at 2022-06-26 00:31:29.991055
# Unit test for method add of class Ledger
def test_Ledger_add():
    journal_entry = JournalEntry()
    journal_entry.postings.append(Posting(Account("101001"), Amount(100), 1))
    journal_entry.postings.append(Posting(Account("101011"), Amount(100), 1))
    journal_entry.postings.append(Posting(Account("102001"), Amount(100), 1))
    journal_entry.postings.append(Posting(Account("102011"), Amount(100), 1))
    journal_entry.postings.append(Posting(Account("103001"), Amount(100), 1))
    l = Ledger(Account('101001'), Balance(datetime.date(2000,1,1), 0, 1))
    print(l.add(journal_entry.postings[0]))
    print(l.add(journal_entry.postings[1]))

# Generated at 2022-06-26 00:31:31.124263
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-26 00:31:31.711063
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-26 00:31:35.115199
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create test objects
    ledger = Ledger(amount_0, initial_0)
    # Invoke the method being tested
    ledger.add(posting_0)
    # Check that result is as expected
    assert ledger == expected_0



# Generated at 2022-06-26 00:31:41.399433
# Unit test for function build_general_ledger
def test_build_general_ledger():
    TestCase0 = test_case_0()
    return



# Generated at 2022-06-26 00:31:50.818806
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.test_utils import run_test_function
    from .algebra import ReadJournalEntries
    from .generic import Balance
    from .journaling import JournalEntry
    from .repositories import ReadInitialBalances
    from datetime import date, timedelta

    # Accounting period:
    period = DateRange(date(2020, 1, 1), date.today())

    # A sample list of journal entries:
    journal_entries = {
        JournalEntry(
            date=date.today(),
            description="An awesome journal entry",
            postings=[
                Posting.debit(account="1110", amount=Decimal(100)),
                Posting.credit(account="2220", amount=Decimal(100)),
            ],
        )
    }

    # Initial balances:

# Generated at 2022-06-26 00:32:00.823787
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import abc
    from dataclasses import dataclass
    from typing import Dict, List, TypeVar
    from uuid import UUID
    from .accounts import Account
    from .journaling import JournalEntry

    T = TypeVar("T")

    @dataclass
    class InitialBalance:
        date: datetime.date
        account: Account
        amount: Decimal

    @dataclass
    class ReadInitialBalances:
        def __call__(self, period: DateRange):
            return {
                a: Balance(b.date, Quantity(b.amount))
                for b in self.initial_balances
                if b.date == period.since
            }

        initial_balances: List[InitialBalance] = field(default_factory=list)


# Generated at 2022-06-26 00:32:05.751811
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = DateRange('h', 'wT+`')
    var_0 = {'3z!*': 'Jd@='}
    # Test the constructor
    read_initial_balances_0 = ReadInitialBalances()
    # Test the method
    var_1 = read_initial_balances_0(date_range_0)
    assert var_1 == var_0


# Generated at 2022-06-26 00:32:09.584483
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import mock
    # Setup test values.
    period = mock.MagicMock()
    journal = mock.MagicMock()
    initial = mock.MagicMock()

    # Perform the test steps:
    var_0 = build_general_ledger(period, journal, initial)


# Generated at 2022-06-26 00:32:17.666980
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = "This is a test."
    str_1 = "This is a test."
    str_2 = "This is a test."
    str_3 = "This is a test."
    date_range_0 = None
    str_4 = "This is a test."
    date_range_1 = None
    dict_0 = {}
    dict_1 = {}
    var_0 = datetime.date(year=int(), month=int(), day=int())
    var_1 = Ledger(str_0, var_0)
    var_2 = JournalEntry(str_1)
    var_3 = Account.from_str(str_2)
    var_4 = Account.from_str(str_3)

# Generated at 2022-06-26 00:32:21.147090
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'doY}7='
    date_range_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, str_0, dict_0)


# Generated at 2022-06-26 00:32:27.392852
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'doY}7='
    date_range_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, str_0, dict_0)
    assert isinstance(var_0, GeneralLedger)
    result = var_0.add(str_0)
    assert isinstance(result, LedgerEntry)


# Generated at 2022-06-26 00:32:38.741227
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Aliases for functions / types
    init = InitialBalances
    entry = JournalEntry
    posting = Posting
    led = build_general_ledger
    # Date range specification
    date_range_0 = DateRange(None, None)
    date_range_1 = DateRange(datetime.date(1, 1, 1), datetime.date(9999, 12, 31))
    # Initial balance specification
    init_balances_0 = init({})
    init_balances_1 = init({Account('R 12345'): Balance(datetime.date(2000, 1, 1), Quantity(1000))})

# Generated at 2022-06-26 00:32:49.158481
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = '__main__'
    str_1 = 'test_Ledger_add_0'
    str_2 = 'test_Ledger_add'
    str_3 = 'setup'
    str_4 = '{1}'
    str_5 = '{2}'
    str_6 = 'bookkeeper'
    str_7 = 'accounts'
    str_8 = '{4}'
    str_9 = '{5}'
    str_10 = 'journaling'
    str_11 = '{7}'
    str_12 = '{8}'
    str_13 = 'journal_entries'
    str_14 = '{10}'
    str_15 = '{11}'
    str_16 = 'decimal'
    str_17 = 'Decimal'

# Generated at 2022-06-26 00:32:54.473193
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Ledger(None, None)
    str_0 = 'w[P;o'
    var_1 = var_0.add(str_0)


# Generated at 2022-06-26 00:32:58.145729
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'YQ'
    str_1 = 'Tx'
    general_ledger_program_0 = compile_general_ledger_program(str_0, str_1)
    date_range_0 = None
    var_0 = general_ledger_program_0(date_range_0)


# Generated at 2022-06-26 00:33:01.150145
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'doY}7='
    date_range_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, str_0, dict_0)


# Generated at 2022-06-26 00:33:09.041703
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'BdN#'
    date_range_0 = None
    dict_0 = get_initial_balances_of_accounts(str_0, date_range_0)


# Generated at 2022-06-26 00:33:12.647774
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'doY}7='
    date_range_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, str_0, dict_0)


# Generated at 2022-06-26 00:33:16.228868
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    obj = compile_general_ledger_program()
    obj.__call__()



# Generated at 2022-06-26 00:33:20.777199
# Unit test for method add of class Ledger
def test_Ledger_add():
    # ------------------------------------------------------------------------------------------------------------------
    # Setup test cases

    ledger = Ledger[str](None, None)
    posting = Posting[str](None, None, None, None)

    # ------------------------------------------------------------------------------------------------------------------
    # Execute logic under test

    result = ledger.add(posting)

    # ------------------------------------------------------------------------------------------------------------------
    # Assert expected results

    assert(result == None)


# Generated at 2022-06-26 00:33:30.778536
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = ''
    date_range_0 = None
    date_range_1 = None
    date_range_2 = None
    str_1 = ''
    date_range_3 = None
    list_0 = []
    str_2 = 'IkF-;'
    list_1 = []
    tuple_0 = (list_0, list_1)
    list_2 = []
    str_3 = '0i@FA}-:Q'
    str_4 = 'y]X.@'
    str_5 = ''
    int_0 = 0
    str_6 = '-A'
    str_7 = '+[o'
    str_8 = ''
    str_9 = '*J'
    str_10 = ''
    str_11 = '5%5U'


# Generated at 2022-06-26 00:33:34.787890
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'doY}7='
    date_range_0 = None
    dict_0 = {}
    var_0 = Ledger(str_0, date_range_0, dict_0)
    var_0.entries = []
    var_0.initial = None
    var_1 = var_0.add(str_0)

# Generated at 2022-06-26 00:33:35.644370
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True


# Generated at 2022-06-26 00:33:41.875487
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    str_0 = ''
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, str_0, dict_0)



# Generated at 2022-06-26 00:33:48.210953
# Unit test for method add of class Ledger
def test_Ledger_add():
    list_0 = []
    balance_0 = Balance(date_range_0=None, quantity_0=None)
    ledger_0 = Ledger(account_0=str_0, initial_0=balance_0, entries_0=list_0)
    posting_0 = Posting(date_0=None, journal_0=None, account_0=str_0, amount_0=None, direction_0=None)
    var_0 = ledger_0.add(posting_0)


# Generated at 2022-06-26 00:33:49.430578
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert callable(build_general_ledger)


# Generated at 2022-06-26 00:33:59.208139
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'fgTe6U'
    date_range_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, str_0, dict_0)
    var_0 = var_0.ledgers
    list_0 = []
    var_1 = list(var_0.values())[0]
    var_1 = var_1.entries
    var_1 = var_1[0]
    list_0.append(var_1)
    var_1 = list(var_0.values())[0]
    var_1 = var_1.entries
    var_1 = var_1[1]
    list_0.append(var_1)
    var_0 = var_0.entries[0]
    assert str_

# Generated at 2022-06-26 00:34:03.094059
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print('Start test_build_general_ledger')
    test_case_0()
    print('End test_build_general_ledger')

import types
from .accounts import Account, AccountType
from .journaling import JournalEntry, Posting, Transaction



# Generated at 2022-06-26 00:34:06.222291
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = 'doY}7='
    date_range_0 = DateRange(0, 1)
    dict_0 = {}
    GeneralLedger = build_general_ledger(date_range_0, str_0, dict_0)


# Generated at 2022-06-26 00:34:09.012044
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Test case 0 :
    try:
        test_case_0()
    except (Exception) as e:
        print(f"Test case 0 failed: {e}")
    else:
        print("Test case 0 passed")

# Functions to set up test data

# Generated at 2022-06-26 00:34:11.775342
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'doY}7='
    date_range_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, str_0, dict_0)


# Generated at 2022-06-26 00:34:20.947209
# Unit test for method add of class Ledger
def test_Ledger_add(): 
    account_0 = Account('*', 'a', 'b')
    balance_0 = Balance(datetime.date(2017, 10, 10), Quantity(Decimal(10)))
    ledger_0 = Ledger(account_0, balance_0)
    account_1 = Account('*', 'c', 'd')
    amount_0 = Amount('0')
    journal_0 = JournalEntry(datetime.date(2009, 6, 9))
    journal_0.post(account_1, amount_0)
    direction_0 = Direction.DEBIT
    posting_0 = Posting(journal_0, account_1, amount_0, direction_0)
    var_0 = ledger_0.add(posting_0)
    assert var_0.ledger == ledger_0
    assert var_0.posting.amount == amount

# Generated at 2022-06-26 00:34:30.838914
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    str_0 = '\\knLfjGw\\'
    date_range_1 = None
    str_1 = '\\knLfjGw\\'
    date_range_2 = None
    str_2 = '\\knLfjGw\\'
    post_arg_0 = [date_range_0, str_0, date_range_1, str_1, date_range_2, str_2]
    date_range_3 = None
    str_3 = '\\knLfjGw\\'
    post_arg_1 = [date_range_3, str_3]
    test_case_0 = compile_general_ledger_program(post_arg_0, post_arg_1)
    test_case_0(None)

#

# Generated at 2022-06-26 00:34:34.226715
# Unit test for method add of class Ledger
def test_Ledger_add():
	pass


# Generated at 2022-06-26 00:34:35.169575
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

# Generated at 2022-06-26 00:34:36.161897
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True


# Generated at 2022-06-26 00:34:38.937095
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances = test_case_0()
    read_journal_entries = test_case_0()
    _program(read_initial_balances, read_journal_entries)


# Generated at 2022-06-26 00:34:39.785432
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()

# Generated at 2022-06-26 00:34:41.764765
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Call the unit test:
    test_case_0()

if __name__ == '__main__':
    test_build_general_ledger()

# Generated at 2022-06-26 00:34:44.858452
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'do}7='
    var_0 = {}
    var_1 = build_general_ledger(str_0, str_0, var_0)
    str_2 = 'do}7='
    var_1.add(str_2)


# Generated at 2022-06-26 00:34:48.827053
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Declarations
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)
    # Invocation
    var_0.__call__('do}7=')

# Generated at 2022-06-26 00:34:51.426585
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'do}7='
    var_0 = {}
    var_1 = build_general_ledger(str_0, str_0, var_0)


# Generated at 2022-06-26 00:34:56.326197
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Tests whether the compile_general_ledger_program function returns the expected result
    # Test 1
    str_0 = 'do}7='
    var_0 = {}
    var_1 = compile_general_ledger_program(str_0, str_0) 
    assert var_1 == var_0, 'unit test #1 failed: expected value was {}, but got {}'.format(var_0, var_1)


# Generated at 2022-06-26 00:35:10.148412
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        var_1 = GeneralLedgerProgram()
        var_2 = test_GeneralLedgerProgram___call__.var_1
        var_3 = test_GeneralLedgerProgram___call__.var_2
        var_4 = var_1(var_2, var_3)
    except Exception as var_5:
        var_6 = get_exception()
        var_7 = format_exception()
        var_8 = str(var_6)
        assert False


# Generated at 2022-06-26 00:35:16.554294
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'do}7='
    var_1 = ReadInitialBalances()
    str_0 = var_1(str_0)


# Generated at 2022-06-26 00:35:18.805045
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'iX'
    var_0 = ReadInitialBalances()
    var_0.__call__(str_0)


# Generated at 2022-06-26 00:35:25.920480
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = '~'
    var_0 = {'g_closing_date': str_0, 'g_opening_date': str_0}
    str_1 = ':n'
    var_1 = compile_general_ledger_program(var_0, str_1)
    str_2 = '`'
    var_2 = var_1(str_2)
    assert var_1(str_2) != var_2



# Generated at 2022-06-26 00:35:27.702988
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert compile_general_ledger_program(str, str) is not None


# Generated at 2022-06-26 00:35:30.589490
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = build_general_ledger('do}7=', 'do}7=', {})
    assert isinstance(var_0, GeneralLedger)


# Generated at 2022-06-26 00:35:31.666606
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass # TODO


# Generated at 2022-06-26 00:35:33.734098
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    try:
        assert False
    except:
        pass
    try:
        assert False
    except:
        pass


# Generated at 2022-06-26 00:35:36.431465
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Set up variables
    pass



# Generated at 2022-06-26 00:35:47.294647
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = 'do}7='
    var_0 = {}
    var_1 = build_general_ledger(str_0, str_0, var_0)
    str_1 = 'do}7='
    var_2 = {}
    var_3 = build_general_ledger(str_1, str_1, var_2)
    str_2 = 'do}7='
    var_4 = {}
    var_5 = build_general_ledger(str_2, str_2, var_4)
    str_3 = 'do}7='
    var_6 = {}
    var_7 = build_general_ledger(str_3, str_3, var_6)
    str_4 = 'do}7='
    var_8 = {}
    var_9 = build_general_

# Generated at 2022-06-26 00:35:57.574842
# Unit test for method add of class Ledger
def test_Ledger_add():
    assert (test_case_0() == None)

# Generated at 2022-06-26 00:35:59.598638
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'do}7='
    var_0 = {}
    var_1 = build_general_ledger(str_0, str_0, var_0)

# Generated at 2022-06-26 00:36:05.964458
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'do}7='
    var_0 = {}
    var_1 = build_general_ledger(str_0, str_0, var_0)
    str_1 = 'do}7='
    str_2 = 'do}7='
    var_2 = Ledger(str_1, str_2)
    var_3 = Posting(str_0, str_1)
    var_4 = var_2.add(var_3)


# Generated at 2022-06-26 00:36:08.766253
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

RUN_TESTS = False
if RUN_TESTS:
    test_GeneralLedgerProgram___call__()
else:
    print("Tests not run.")

# Generated at 2022-06-26 00:36:18.026135
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = datetime.date(2018, 1, 1)
    var_1 = datetime.date(2018, 1, 2)
    var_2 = datetime.date(2018, 1, 3)
    var_3 = datetime.date(2018, 1, 4)

# Generated at 2022-06-26 00:36:21.459430
# Unit test for method add of class Ledger
def test_Ledger_add():
    a = LedgerEntry(Ledger(1, 2, 3), 4, 5)
    b = Ledger(1, 2, [a])
    c = b.add(4)
    assert c == a
    assert b.entries[2] == c
    assert b._last_balance == 5


# Generated at 2022-06-26 00:36:23.874576
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = {}
    var_0 = build_general_ledger(str_0, str_0, str_0)
    test_case_0()


# Generated at 2022-06-26 00:36:28.691309
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print(test_case_0.__name__)
    try:
        assert(test_case_0() == None)
    except AssertionError as e:
        print(e)
        print("TEST FAILED : function build_general_ledger")
        return False
    print("TEST SUCCESSFUL : function build_general_ledger")
    return True

test_build_general_ledger()


# Generated at 2022-06-26 00:36:31.699391
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Test empty ledger, should work.
    ledger_0 = Ledger(Quantity(Decimal(0)))
    ledger_0.add(Quantity(Decimal(0)))

# Generated at 2022-06-26 00:36:41.115936
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'do}7='
    var_0 = {}
    var_1 = build_general_ledger(str_0, str_0, var_0)

    str_0 = 'B!@S5'
    var_0 = {'1': var_1, '0': '*69Xt'}
    var_0[0] = '`*1R^'
    var_0[1] = '@9Xb8'
    var_0[2] = '=s'
    var_0[3] = '+&^I9'
    var_0[4] = '@!<-I'
    var_0[5] = '&z0'
    var_0[6] = ''
    var_0[7] = ''

# Generated at 2022-06-26 00:36:53.844384
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = {}
    var_1 = ReadInitialBalances()
    var_1 = var_1(var_0)


# Generated at 2022-06-26 00:36:55.913100
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = {}
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = var_1(var_0)

# Generated at 2022-06-26 00:37:01.642928
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import unittest
    global ReadInitialBalances
    ReadInitialBalances = unittest.mock.create_autospec(ReadInitialBalances, spec_set=True)()
    global ReadJournalEntries
    ReadJournalEntries = unittest.mock.create_autospec(ReadJournalEntries, spec_set=True)()
    global test_case_0
    from types import FunctionType
    test_case_0 = FunctionType(test_case_0.__code__, {})
    test_case_0()

# Generated at 2022-06-26 00:37:03.052651
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert build_general_ledger(var_0, var_0, var_0) is None


# Generated at 2022-06-26 00:37:05.446389
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)


# Generated at 2022-06-26 00:37:07.118228
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert compile_general_ledger_program(test_case_0, test_case_0) == test_case_0

# Generated at 2022-06-26 00:37:08.966989
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_2 = {}
    var_3 = {}
    var_4 = build_general_ledger(var_2, var_3, var_3)


# Generated at 2022-06-26 00:37:20.459076
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from datetime import datetime as ts
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import List, Dict
    from ledger.accounts import Account
    from ledger.entity.journaling import JournalEntry, Posting
    from ledger.entity.ledgering import GeneralLedger, build_general_ledger, GeneralLedgerProgram, compile_general_ledger_program
    from ledger.infrastructure.mem.journaling import read_journal_entries
    from ledger.infrastructure.mem.ledgering import read_initial_balances

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the

# Generated at 2022-06-26 00:37:21.758571
# Unit test for method __call__ of class ReadInitialBalances

# Generated at 2022-06-26 00:37:23.358547
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert type(build_general_ledger(datetime.datetime.today(), set(), {})) is GeneralLedger


# Generated at 2022-06-26 00:37:49.941452
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_2 = {}
    var_3 = {}
    _program = compile_general_ledger_program(var_2, var_3)
    var_4 = {}
    var_5 = _program(var_4)


if __name__ == "__main__":
    test_case_0()
    test_GeneralLedgerProgram___call__()

# Generated at 2022-06-26 00:37:58.471611
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Ledger(None, None, None)
    var_1 = Posting(datetime.datetime.today(), None, None, None)
    var_2 = var_0.add(var_1)
    assert isinstance(var_2, LedgerEntry)


# Generated at 2022-06-26 00:38:00.155566
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print("Testing function: build_general_ledger")
    test_case_0()


# Generated at 2022-06-26 00:38:01.971840
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test for for case: []
    test_GeneralLedgerProgram___call___case_0()



# Generated at 2022-06-26 00:38:04.000889
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = {}
    var_2 = build_general_ledger(var_0, var_1, var_1)

# Generated at 2022-06-26 00:38:05.779918
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)


# Generated at 2022-06-26 00:38:09.332998
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)
    var_1 = var_0(test_case_0)

# Generated at 2022-06-26 00:38:12.015452
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)
    var_1 = var_0(test_case_0)
    assert var_1 is not None


# Generated at 2022-06-26 00:38:14.689002
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = {
        Account("10102"): Balance("2019-01-01", Quantity("0")),
        Account("10100"): Balance("2019-01-01", Quantity("2")),
    }



# Generated at 2022-06-26 00:38:16.249085
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    try:
        raise RuntimeError
    except RuntimeError:
        print('RuntimeError')


# Generated at 2022-06-26 00:38:37.600482
# Unit test for function build_general_ledger
def test_build_general_ledger():  # noqa: D103
    assert True

# Generated at 2022-06-26 00:38:39.009478
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)

# Generated at 2022-06-26 00:38:45.006006
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range = DateRange(date(2018, 1, 1), date(2018, 12, 31))
    initial_balance = Balance(date_range.since, Quantity(Decimal(0.0)))
    initial_balances_dict = {Account("A1"): initial_balance, Account("A2"): initial_balance}
    reader = lambda date_range: initial_balances_dict

    # Assert reader returned expected result.
    assert reader(date_range) == initial_balances_dict



# Generated at 2022-06-26 00:38:53.225487
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = {}
    var_1 = {}
    var_2 = build_general_ledger(var_0, var_0, var_0)
    assert type(var_2) == GeneralLedger
    assert type(var_2.period) == None
    assert type(var_2.ledgers) == dict
    assert set(var_2.ledgers.keys()) == set()
    var_2 = build_general_ledger(var_0, var_0, var_1)
    assert type(var_2) == GeneralLedger
    assert type(var_2.period) == None
    assert type(var_2.ledgers) == dict
    assert set(var_2.ledgers.keys()) == set()
    assert type(var_2.ledgers) == dict

# Generated at 2022-06-26 00:38:56.827953
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date

    var_0 = DateRange(date(2000,1,1), date(2000,12,31))
    var_1 = {}
    test_ReadInitialBalances___call__.__globals__['var_0'], test_ReadInitialBalances___call__.__globals__['var_1']['ReadInitialBalances'].__call__(var_0)


# Generated at 2022-06-26 00:39:02.805083
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from bisect import bisect_left
    from datetime import date
    from decimal import Decimal
    from itertools import chain
    from typing import Iterator, Mapping, MutableMapping, Tuple
    from unittest import TestCase
    from uuid import uuid4
    from varsnap import Snapshot
    from .accounts import Account, AccountType, IsAccount
    from .accounting import AccountingPeriod
    from .commons.numbers import Amount, Quantity
    from .journaling import Journal, JournalEntry, Posting, PostingType

    @dataclass
    class JournalEntryRef(Generic[_T]):
        journal: Journal[_T]
        amount: Amount

    @dataclass
    class BalanceRef(Generic[_T]):
        date: date
        value: Quantity


# Generated at 2022-06-26 00:39:08.285065
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_Ledger = Ledger(1, 2)
    test_Ledger.entries = []
    test_Ledger.initial = 1

    # Test 0
    test_Ledger.add(3)
    assert test_Ledger.entries == []
    assert test_Ledger.initial == 1
    assert test_Ledger.ledger == 1

    # Test 1
    test_Ledger.add(4)
    assert test_Ledger.entries == []
    assert test_Ledger.initial == 1
    assert test_Ledger.ledger == 1

    # Test 2
    test_Ledger.add(5)
    assert test_Ledger.entries == []
    assert test_Ledger.initial == 1
    assert test_Ledger.ledger == 1

    # Test 3

# Generated at 2022-06-26 00:39:09.528401
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print("test_build_general_ledger")
    test_case_0()

# Run unit tests
test_build_general_ledger()

# Generated at 2022-06-26 00:39:10.965522
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Test case 0
    var_0 = {}
    var_1 = build_general_ledger(var_0, var_0, var_0)


# Generated at 2022-06-26 00:39:12.198447
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_2 = {}
    var_3 = var_2.__call__(var_2)
