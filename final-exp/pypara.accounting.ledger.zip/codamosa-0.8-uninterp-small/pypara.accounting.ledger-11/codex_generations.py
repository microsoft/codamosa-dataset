

# Generated at 2022-06-26 00:31:01.652214
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    exception_0 = None
    try:
        test_case_0()
    except Exception as exception_1:
        exception_0 = exception_1
    assert isinstance(exception_0, ValueError)

import pypara.accounting.journaling as module_1


# Generated at 2022-06-26 00:31:11.717265
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import datetime
    from typing import List, Dict
    from decimal import Decimal
    from dataclasses import dataclass
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    # TODO: Modify test case to match implementation in: src/pypara/accounting/ledgers/general.py

    @dataclass
    class ReadInitialBalances:
        def __call__(self, period: datetime.date) -> Dict[module_0.Account, module_0.Balance]:
            return {}

    @dataclass
    class ReadJournalEntries:
        def __call__(self, period: datetime.date) -> List[JournalEntry]:
            return []

    read_initial_balances = ReadInitialBalances()
    read_journal_entries = ReadJournalEntries()


# Generated at 2022-06-26 00:31:21.564317
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = module_0.Account()
    account_1 = module_0.Account()
    date_0 = datetime.date(1, 1, 1)
    date_1 = datetime.date(2, 2, 2)
    balance_0 = Balance(date_0, Amount(Decimal('1')))
    balance_1 = Balance(date_1, Quantity(Decimal('1')))
    ledger_0 = Ledger(account_0, balance_0)
    journal_entry_0 = JournalEntry(date_1, "", [Posting(account_1, Amount(Decimal('1')), 1)])
    posting_0 = Posting(account_0, Amount(Decimal('1')), -1)
    posting_1 = Posting(account_1, Amount(Decimal('1')), 1)
   

# Generated at 2022-06-26 00:31:29.030341
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import pytest

    account_0 = build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()
    assert account_0 == build_general_ledger()

# Generated at 2022-06-26 00:31:30.310005
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 00:31:35.671327
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = module_0.Account()
    posting_0 = module_1.Posting(Quantity('1'), Quantity('1'), Quantity('1'), Quantity('1'), Quantity('1'))
    ledger_0 = module_2.Ledger(account_0, Balance(Quantity('1'), Quantity('1')))
    module_2.Ledger.add(ledger_0, posting_0)


# Generated at 2022-06-26 00:31:45.590307
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Optional, Tuple
    from ...commons.zeitgeist import Period
    from ...commons import Quantity
    from ..journaling import JournalEntry

    period = Period(since=date(2020, 1, 1), until=date(2020, 1, 31))

    class JournalEntry_0(JournalEntry):
        def __init__(self):
            self.date = date(2020, 1, 1)

        def get_postings(self):
            class Posting_0:
                def __init__(self):
                    self.account = Account()
                    self.direction = Quantity(Decimal(0))
                    self.amount = Amount(Decimal(0))


# Generated at 2022-06-26 00:31:53.551209
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    account_0 = module_0.Account()
    period_0 = DateRange()
    program_0 = compile_general_ledger_program(ReadInitialBalances(), ReadJournalEntries())
    general_ledger_0 = program_0(period_0)

    ## Assert the return value is of type GeneralLedger
    assert isinstance(general_ledger_0, GeneralLedger)

    ## Assert that the period attribute of general_ledger_0 is equal to period_0
    assert general_ledger_0.period == period_0

    ## Assert that the ledgers attribute of general_ledger_0 is of type Dict
    assert isinstance(general_ledger_0.ledgers, Dict)


# Generated at 2022-06-26 00:32:00.261291
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    _T_0 = TypeVar("_T")
    ReadInitialBalances_0 = ReadInitialBalances
    ReadJournalEntries_0 = ReadJournalEntries[_T_0]
    obj_0 = compile_general_ledger_program(ReadInitialBalances_0, ReadJournalEntries_0)
    def test_0() -> 'no return':
        period_0 = DateRange()
        obj_0(period_0)
    test_0()


# Generated at 2022-06-26 00:32:09.213030
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from pypara.accounting.algebras.general_ledger import ReadInitialBalances
    from pypara.commons.numbers import Amount
    from pypara.commons.zeitgeist import DateRange
    from pypara.examples.accounting import (
        account_0,
        balance_0_0,
        balance_0_1,
        initial_balances_0,
    )
    ReadInitialBalances_0 = ReadInitialBalances()
    DateRange_0 = DateRange(date(2017, 1, 1), date(2017, 12, 31))
    result_0 = ReadInitialBalances_0(DateRange_0)
    assert result_0 == initial_balances_0


# Generated at 2022-06-26 00:32:17.446028
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    account_0 = module_0.Account()
    read_initial_balances_0 = lambda period: {}
    read_journal_entries_0 = lambda period: []
    program_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    period_0 = DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 1))
    assert isinstance(program_0(period_0), GeneralLedger)

# Generated at 2022-06-26 00:32:28.055630
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = module_0.Account()
    period_0 = DateRange(datetime.date(1950, 1, 1), datetime.date(1951, 1, 1))
    quantity_0 = Quantity(Decimal(0))
    balance_0 = Balance(datetime.date(1950, 1, 1), quantity_0)
    ledger_0 = Ledger(account_0, balance_0)
    journal_entry_0 = JournalEntry([], "", datetime.date(1950, 1, 2))
    direction_0 = module_0.Direction.debit
    amount_0 = Amount(Decimal(0))
    posting_0 = Posting(journal_entry_0, account_0, direction_0, amount_0)
    ledger_entry_0 = ledger_0.add(posting_0)

# Generated at 2022-06-26 00:32:34.779634
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Test cases:
    ## Test case 0:
    account_0 = Account()
    period_0 = DateRange(since=None, until=None)
    journal_0 = None
    initial_0 = None
    try:
        build_general_ledger(period=period_0, journal=journal_0, initial=initial_0)
    except:
        pass
    assert True


# Generated at 2022-06-26 00:32:40.737960
# Unit test for method add of class Ledger
def test_Ledger_add():
    journal_0 = Journal()
    account_0 = module_0.Account()
    balance_0 = Balance()
    ledger_0 = Ledger(account_0, balance_0)
    posting_0 = journal_0.posting(account_0, datetime.date(1, 1, 1), "", "", "")
    ledger_entry_0 = ledger_0.add(posting_0)


# Generated at 2022-06-26 00:32:49.568057
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    print("starting test case: test_ReadInitialBalances___call__")
    from typing import Dict

    from ..commons.numbers import Amount

    from .accounts import Account

    from .generic import Balance

    from .test_data import account_0, account_1, accounts, initial_balances

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return initial_balances

    read_initial_balances = read_initial_balances
    period = DateRange(datetime.date(2001, 1, 1), datetime.date(2001, 12, 31))
    initial_balances_0 = read_initial_balances(period)
    assert initial_balances_0 == initial_balances


# Generated at 2022-06-26 00:32:51.809475
# Unit test for method add of class Ledger
def test_Ledger_add():
    Ledger_0 = Ledger()
    posting_0 = Posting()
    Ledger_1 = Ledger_0.add(posting_0)

# Generated at 2022-06-26 00:32:56.801480
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the call operator method __call__ of class GeneralLedgerProgram.
    """
    tester: GeneralLedgerProgram = compile_general_ledger_program(
        lambda period: {},
        lambda period: [],
    )

    tester(DateRange(
        since=datetime.date(2020, 1, 1),
        until=datetime.date(2020, 1, 31),
    ))


# Generated at 2022-06-26 00:33:10.398689
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Define mock for ReadInitialBalances
    class ReadInitialBalancesMock(ReadInitialBalances):
        def __init__(self, func_0):
            self.func_0 = func_0
        def __call__(self, period: DateRange):
            return self.func_0(period)
    # Initialize mock for ReadInitialBalances
    read_initial_balances_mock = ReadInitialBalancesMock(lambda period: InitialBalances())
    # Define mock for ReadJournalEntries
    class ReadJournalEntriesMock(ReadJournalEntries):
        def __init__(self, func_0):
            self.func_0 = func_0
        def __call__(self, period: DateRange):
            return self.func_0(period)
    # Initialize mock for ReadJournalEntries
   

# Generated at 2022-06-26 00:33:11.430455
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass



# Generated at 2022-06-26 00:33:19.145113
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from pypara.accounting.accounts import Account
    from pypara.accounting.general_ledger import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from pypara.accounting.journaling import JournalEntry, Posting, Quantity
    from pypara.commons.numbers import Amount
    from pypara.commons.zeitgeist import DateRange
    import datetime
    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))
    journal = [JournalEntry(date=datetime.date(2020, 1, 1), description='JournalEntry', postings=[Posting(account=Account(), amount=Amount(quantity=Quantity(value=Decimal('1'))))])]
    initial = {}
    assert GeneralLed

# Generated at 2022-06-26 00:33:34.078631
# Unit test for function build_general_ledger
def test_build_general_ledger():

    ## Given
    #: Accounting period.
    period = DateRange(since=datetime.date(year=2020, month=2, day=1), until=datetime.date(year=2020, month=2, day=28))

    #: Available journal entries.

# Generated at 2022-06-26 00:33:43.818826
# Unit test for method add of class Ledger
def test_Ledger_add():
    list_0 = [None, None, None]
    account_0 = module_1.Account(*list_0)
    amount_0 = module_2.Amount(*list_0)
    journal_0 = module_1.Journal(amount_0, *list_0)
    var_0 = module_2.date(*list_0)
    posting_0 = module_1.Posting(account_0, journal_0, amount_0, var_0, *list_0)
    date_0 = module_2.date(*list_0)
    quantity_0 = module_2.Quantity(*list_0)
    balance_0 = module_3.Balance(date_0, quantity_0)
    ledger_0 = Ledger(account_0, balance_0)
    ledger_0.add(posting_0)



# Generated at 2022-06-26 00:33:49.051455
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)
    list_0 = [dict_0, var_0, dict_0]
    account_0 = module_1.Account(*list_0)
    account_1 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    balance_0 = module_3.Balance(date_0, date_0)
    ledger_0 = Ledger(account_1, balance_0)
    var_1 = ledger_0.__eq__(account_0)
    account_2 = module_1.Account()
    var_2 = None

# Generated at 2022-06-26 00:33:58.852961
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    iterable_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_0)
    list_0 = [iterable_0, var_0, dict_0]
    account_0 = module_1.Account(*list_0)
    account_1 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    balance_0 = module_3.Balance(date_0, date_0)
    ledger_0 = Ledger(account_1, balance_0)
    var_1 = ledger_0.__eq__(account_0)
    account_2 = module_1.Account()
    var_2 = None

# Generated at 2022-06-26 00:34:07.759101
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Initialization of the unit test procedure:
    date_range_0 = None
    iterable_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_0)
    list_0 = [iterable_0, var_0, dict_0]
    account_0 = module_1.Account(*list_0)
    account_1 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    balance_0 = module_3.Balance(date_0, date_0)
    ledger_0 = Ledger(account_1, balance_0)
    var_1 = ledger_0.__eq__(account_0)
    account_2 = module_1.Account()
   

# Generated at 2022-06-26 00:34:16.565865
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    iterable_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_0)
    list_0 = [iterable_0, var_0, dict_0]
    account_0 = module_1.Account(*list_0)
    account_1 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    balance_0 = module_3.Balance(date_0, date_0)
    ledger_0 = Ledger(account_1, balance_0)
    var_1 = ledger_0.__eq__(account_0)
    account_2 = module_1.Account()
    var_2 = None

# Generated at 2022-06-26 00:34:26.988148
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Define and initialize objects of type ReadInitialBalances:
    def read_initial_balances_0():
        date_range_0 = None
        var_0 = None
        return var_0
    read_initial_balances_0 = read_initial_balances_0()

    # Define and initialize objects of type ReadJournalEntries:
    def read_journal_entries_0():
        date_range_0 = None
        var_0 = None
        return var_0
    read_journal_entries_0 = read_journal_entries_0()

    # Invoke function:
    var_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    # Check return type
    assert isinstance(var_0, GeneralLedgerProgram)


# Generated at 2022-06-26 00:34:35.505457
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Construct fixture
    date_range_0 = None
    iterable_0 = None
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_0)
    list_0 = [iterable_0, var_0, dict_0]
    account_0 = module_1.Account(*list_0)
    account_1 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    balance_0 = module_3.Balance(date_0, date_0)
    ledger_0 = Ledger(account_1, balance_0)
    account_2 = module_1.Account()
    var_1 = None

# Generated at 2022-06-26 00:34:44.278293
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    iterable_0 = None
    dict_0 = {}
    build_general_ledger(date_range_0, iterable_0, dict_0)
    list_0 = [iterable_0, dict_0, dict_0]
    account_0 = module_1.Account(*list_0)
    account_1 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    balance_0 = module_3.Balance(date_0, date_0)
    ledger_0 = Ledger(account_1, balance_0)
    posting_0 = None
    var_0 = ledger_0.add(posting_0)
    account_2 = module_1.Account()
    var_1 = None
    dict_

# Generated at 2022-06-26 00:34:50.571371
# Unit test for method add of class Ledger
def test_Ledger_add():
    list_0 = [None, None]
    account_0 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    balance_0 = module_3.Balance(date_0, date_0)
    ledger_0 = Ledger(account_0, balance_0)
    var_0 = None
    var_1 = ledger_0.add(var_0)


# Generated at 2022-06-26 00:35:07.361668
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..model import ledger
    from ..model import journal

    def _read_initial_balances(period):
        return {Account("Sales"): Balance(period.since, Quantity(Decimal(1000)))}

    def _read(period):
        return [
            journal.JournalEntry(
                None, None, [Posting(Account("Sales"), Quantity(Decimal(1000)), ledger.Debit)]
            )
        ]

    program = compile_general_ledger_program(_read_initial_balances, _read)


# Generated at 2022-06-26 00:35:09.927414
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Instantiate an uninitialized instance of class Ledger
    var_2 = Ledger(None, None)
    # Instantiate an uninitialized instance of class Posting
    var_3 = Posting(None, None, None)
    # Call method add of class Ledger
    var_4 = var_2.add(var_3)


# Generated at 2022-06-26 00:35:16.696741
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Invoke __call__ on instances of ReadInitialBalances.
    """
    # Test with explicit cases:
    var_0 = {}
    test_case_0()



# Generated at 2022-06-26 00:35:18.598928
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert compile_general_ledger_program(test_case_0, test_case_0)() == test_case_0()

# Generated at 2022-06-26 00:35:25.390024
# Unit test for method add of class Ledger
def test_Ledger_add():
    import random
    import pytest
    from ..commons.types import PositiveInteger
    ledger = Ledger('test account', Balance(datetime.date(2020, 4, 8), Quantity(50)))
    posting = Posting('test account', datetime.date(2020, 4, 8), PositiveInteger(random.randint(1, 100)))
    ledger.add(posting)
    assert ledger.entries[0].balance == Quantity(posting.amount + 50)

# Generated at 2022-06-26 00:35:27.773910
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = {}
    var_1 = ReadInitialBalances.__call__(var_0, var_0)


# Generated at 2022-06-26 00:35:30.705123
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert isinstance(GeneralLedgerProgram.__call__, Callable)
    
    # Call the method under test
    GeneralLedgerProgram.__call__()


# Generated at 2022-06-26 00:35:42.598538
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from fints.ledger.accounts import Account, AccountType

    account_1 = Account(1, "1000", AccountType.ASSET)
    balance_1 = Balance(date(2020, 6, 7), Quantity(100.00))
    account_2 = Account(2, "1100", AccountType.ASSET)
    balance_2 = Balance(date(2020, 6, 7), Quantity(50.00))
    period_1 = DateRange(date(2020, 1, 1), date(2020, 12, 31))

    class ReadInitialBalances_Impl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            assert period == period_1
            return {account_1: balance_1, account_2: balance_2}

    instance_1 = ReadInitial

# Generated at 2022-06-26 00:35:47.025447
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Compute result
    result = compile_general_ledger_program(test_case_0, test_case_0)()

    # Check result
    assert isinstance(result, GeneralLedger)
    assert result.period == {}
    assert result.ledgers == {}



# Generated at 2022-06-26 00:35:49.569635
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ## Trivial test:
    assert isinstance(test_ReadInitialBalances___call__.__wrapped__(), InitialBalances)


# Generated at 2022-06-26 00:36:03.293623
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = {"1": Balance("2", Quantity("3"))}
    var_1 = ReadInitialBalances()
    var_1.__call__(var_0)


# Generated at 2022-06-26 00:36:12.434307
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from typing import Callable
    from zaimcsvconverter.accounts import Account
    from zaimcsvconverter.balance_sheet import InitialBalances
    from zaimcsvconverter.commons import Amount, DateRange, Quantity
    from zaimcsvconverter.journaling import JournalEntry, Posting
    from zaimcsvconverter.ledgers import GeneralLedger, GeneralLedgerProgram, build_general_ledger

    ## Create a test case which returns empty balances:
    def _test_case_0_empty_balances() -> Dict[Account, InitialBalances]:
        return {}

    ## Create a test case which returns an empty list of journal entries:
    def _test_case_0_empty_journal() -> List[JournalEntry]:
        return []

    ## Compile a program as per

# Generated at 2022-06-26 00:36:21.420826
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from typing import Dict, List
    from datetime import date, timedelta

    class ReadInitialBalancesMock:
        def __init__(self, initial_balances: dict):
            self._initial_balances = initial_balances

        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return self._initial_balances

    class ReadJournalEntriesMock:
        def __init__(self, journal_entries: List[JournalEntry[int]]):
            self._journal_entries = journal_entries

        def __call__(self, period: DateRange) -> List[JournalEntry[int]]:
            return self._journal_entries


# Generated at 2022-06-26 00:36:23.876464
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(var_0, var_0)
    var_0 = var_0(var_0)


# Generated at 2022-06-26 00:36:24.472705
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:36:25.007097
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-26 00:36:25.960548
# Unit test for function build_general_ledger
def test_build_general_ledger():

    test_case_0()

# Generated at 2022-06-26 00:36:28.424315
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = {}
    var_1 = compile_general_ledger_program(test_case_0, test_case_0)
    var_2 = var_1(var_0)



# Generated at 2022-06-26 00:36:31.739244
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = {}
    var_1 = {}
    var_2 = Ledger(var_0, var_1)
    var_3 = {}
    var_2.add(var_3)


# Generated at 2022-06-26 00:36:38.220974
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    class MockedReadInitialBalances(ReadInitialBalances):

        def __call__(self, arg_0: DateRange) -> InitialBalances:
            return test_ReadInitialBalances___call__._result(arg_0)

    test_case_0()
    test_ReadInitialBalances___call__._result = None
    var_2 = MockedReadInitialBalances()
    var_3 = var_2(var_0)
    assert var_3 == var_0


# Generated at 2022-06-26 00:36:54.870297
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    print("Testing compile_general_ledger_program")

# Generated at 2022-06-26 00:36:57.027257
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_1(var_0)

# Generated at 2022-06-26 00:36:58.561805
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        raise ValueError('The test case failed to compile')
    except: pass


# Generated at 2022-06-26 00:36:59.667714
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Ledger(None, None)
    var_0.add(None)

# Generated at 2022-06-26 00:37:00.897063
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass  # TODO: implement your test here.


# Generated at 2022-06-26 00:37:03.610410
# Unit test for function build_general_ledger
def test_build_general_ledger():
    x1 = DateRange()
    x2 = JournalEntry()
    x3 = InitialBalances()
    x4 = build_general_ledger(x1, x2, x3)
    x5 = balance_sheet()


# Generated at 2022-06-26 00:37:06.596955
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    program = compile_general_ledger_program(lambda x: {}, lambda x: [])
    ledger = program((datetime.date(2020, 10, 1), datetime.date(2020, 10, 31)))

# Generated at 2022-06-26 00:37:09.998841
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test: Method without parameters
    # Configuration:
    # var_0 = {}
    # var_1 = build_general_ledger(var_0, var_0, var_0)
    # Call:
    # var_2 = test_case_0()
    # Check:
    assert True # TODO: Implement your test here



# Generated at 2022-06-26 00:37:11.898286
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances
    var_1 = var_1.__call__
    var_1(var_0)


# Generated at 2022-06-26 00:37:19.184125
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    mock_callable_var = {}
    mock_callable_var.__call__ = {}
    test_var = ReadInitialBalances()
    test_var = ReadInitialBalances.__call__(test_var, mock_callable_var)
    test_var = ReadInitialBalances.__call__(test_var, mock_callable_var)


# Generated at 2022-06-26 00:37:41.918611
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def local_read_initial_balances(period):
        pass

    def local_read_journal_entries(period):
        pass

    assert compile_general_ledger_program(local_read_initial_balances, local_read_journal_entries)


if __name__ == "__main__":
    print("*" * 120)
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)
    print("*" * 120)
    #import unittest
    # unittest.main(exit=False, verbosity=2)
    test_case_0()

# Generated at 2022-06-26 00:37:43.435568
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert callable(build_general_ledger)


# Generated at 2022-06-26 00:37:47.768418
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    # Test case 0:
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)
    assert var_0(test_case_0) == build_general_ledger(test_case_0, test_case_0, test_case_0)

# Generated at 2022-06-26 00:37:48.777484
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    test_case_0()


# Generated at 2022-06-26 00:37:49.748775
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Test that method __call__ works as expected:
    pass



# Generated at 2022-06-26 00:37:58.630416
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-26 00:38:08.952509
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    # Test cases
    # Function Pointer
    class _TestCase:

        def __init__(self, name: str = ""):
            self._name = name

        def __str__(self) -> str:
            return self.name

        @property
        def name(self) -> str:
            return self._name

    # Test suite
    class _TestSuite:

        def __init__(self):
            self._cases = []

        def __iter__(self) -> "_TestSuite":
            self._n = 0
            return self

        def __next__(self) -> _TestCase:
            if self._n < len(self._cases):
                result = self._cases[self._n]
                self._n += 1
                return result

            raise StopIteration


# Generated at 2022-06-26 00:38:17.071883
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from . import algebras as algebras
    from . import algebra as algebra
    from . import models as models

    def _dummy_read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def _dummy_read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    dummy_read_initial_balances = algebras.ReadInitialBalances(algebra.decode, _dummy_read_initial_balances)
    dummy_read_journal_entries = algebras.ReadJournalEntries(models.JournalEntry, algebra.decode, _dummy_read_initial_balances)

# Generated at 2022-06-26 00:38:21.953025
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test method __call__ of class GeneralLedgerProgram
    """
    # Define variables:
    var_0 = compile_general_ledger_program({}, {})
    var_1 = var_0(var_0)

if __name__ == "__main__":
    # Execute only if run as a script
    test_case_0()
    test_GeneralLedgerProgram___call__()

# Generated at 2022-06-26 00:38:22.573225
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:38:36.810722
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert True



# Generated at 2022-06-26 00:38:38.860688
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_2 = GeneralLedgerProgram()
    var_3 = test_case_0()
    var_4 = var_2.__call__(var_3)


# Generated at 2022-06-26 00:38:44.241373
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    global read_initial_balances
    global read_journal_entries
    global general_ledger_program
    read_initial_balances = datetime.date
    read_journal_entries = datetime.date
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    var_0 = {}
    var_1 = general_ledger_program(var_0)

# Generated at 2022-06-26 00:38:46.461767
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import test.test_ledgers_suppl_ledgers as testmod
    from test.test_ledgers_suppl_ledgers import test_build_general_ledger as func

    func(build_general_ledger)

# Generated at 2022-06-26 00:38:49.078822
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = {}
    var_0 = {}
    var_1 = {}
    var_2 = test_case_0()
    assert var_2 == var_1

# Generated at 2022-06-26 00:38:56.332317
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Asset
    from .accounts import Expense
    from .accounts import Expenses
    from .accounts import Liability
    from .accounts import Revenue
    from .accounts import Revenues
    from .area import Area
    from .chart import Chart
    from .commons.zeitgeist import DateTime
    from .journaling import Journal
    from .journaling import Posting
    import datetime
    import decimal
    import unittest
    from decimal import Decimal

    var_0 = datetime.date(2017, 7, 3)
    var_1 = datetime.date(2017, 7, 9)
    var_2 = DateTime(datetime.datetime(2017, 7, 10, 12))
    var_3 = DateTime(datetime.datetime(2017, 7, 10, 12))


# Generated at 2022-06-26 00:38:56.997122
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Do Nothing
    pass


# Generated at 2022-06-26 00:39:01.166149
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger_0 = Ledger(Account("name_0", "type_0", "code_0"), Balance(datetime.date(2019, 4, 13), Quantity(Decimal(87.67860161728284))))
    var_0 = Posting(Account("name_1", "type_1", "code_1"), 1, datetime.date(2019, 4, 13), Quantity(Decimal(44.28020110882645)))
    var_1 = ledger_0.add(var_0)
    assert ledger_0 is not None

# Generated at 2022-06-26 00:39:02.534789
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # var_0 = compile_general_ledger_program(var_0, var_0)
    assert(True)


# Generated at 2022-06-26 00:39:03.144135
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()


# Generated at 2022-06-26 00:39:43.952983
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Test case 0
    var_0: DateRange = None
    var_1: Iterable[JournalEntry[_T]] = None
    var_2: InitialBalances = None

    test_case_0()

# Generated at 2022-06-26 00:39:45.614858
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """
    test_case_0()



# Generated at 2022-06-26 00:39:47.766393
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances(lambda period: {})
    var_1 = DateRange()
    var_2 = var_0(var_1)


# Generated at 2022-06-26 00:39:52.590601
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.journaling import Journal
    j = Journal(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1)), "X", None)
    p = j.post(Account("101"), Decimal(10))
    l = Ledger(p.account, Balance(datetime.date(2019, 1, 1), Quantity(Decimal(10))))
    assert l.add(p) == LedgerEntry(l, p, Quantity(Decimal(20)))

# Generated at 2022-06-26 00:39:53.295491
# Unit test for method add of class Ledger
def test_Ledger_add():
    # TODO
    pass

# Generated at 2022-06-26 00:39:53.942084
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert __call__


# Generated at 2022-06-26 00:39:54.370860
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True



# Generated at 2022-06-26 00:39:56.938042
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_0 = compile_general_ledger_program(read_initial_balances=test_case_0,
                                           read_journal_entries=test_case_0)


if __name__ == "__main__":
    test_compile_general_ledger_program()


# vim: et:ts=4:sw=4

# Generated at 2022-06-26 00:40:01.050403
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Quantity, Amount
    test_0 = compile_general_ledger_program(lambda a: {}, lambda a: [])
    var_0 = test_0(DateRange(Decimal('2014'), Decimal('2015')))


# Generated at 2022-06-26 00:40:03.073668
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a new instance of class Ledger
    var_0 = Ledger(None, None)
    # Invoke method add of class Ledger
    var_1 = var_0.add(None)
    # Check that the return value is correct
    assert var_1 == LedgerEntry(var_0, None, None)
