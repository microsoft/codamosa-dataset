

# Generated at 2022-06-26 00:31:13.893122
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Defining ledger account and inital balance
    acc1=Account('1110')
    initial=Balance(Decimal(0),Decimal(0))
    ledger=Ledger(acc1,initial)

    # Debit entries
    journal1=JournalEntry('j1', Decimal(1), 'first', Decimal(100), Decimal(0), Posting.DEBIT)
    ledger.add(journal1.postings[0])
    assert ledger.entries[0].amount==Decimal(100)

    journal2=JournalEntry('j2', Decimal(2), 'second', Decimal(200), Decimal(0), Posting.DEBIT)
    ledger.add(journal2.postings[0])
    assert ledger.entries[1].amount==Decimal(200)

    # Credit entries

# Generated at 2022-06-26 00:31:15.552057
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    print("test_compile_general_ledger_program")

# Unit tests for function build_general_ledger

# Generated at 2022-06-26 00:31:20.502027
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange(datetime.date(2008, 4, 1), datetime.date(2008, 4, 30))
    initial_balances = read_initial_balances_0(period_0)
    assert initial_balances == {}


# Generated at 2022-06-26 00:31:25.577871
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances = ReadInitialBalances()
    read_journal_entries = ReadJournalEntries()
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    pass

if __name__ == "__main__":
    #import doctest

    #doctest.testmod()
    test_compile_general_ledger_program()

# Generated at 2022-06-26 00:31:32.327991
# Unit test for method add of class Ledger
def test_Ledger_add():
    index = 0
    account = Account('1000')
    balance = Balance(datetime.date(2020, 6, 1), 1000)
    ledger = Ledger(account, balance)
    posting = Posting(direction=1, account='1000', amount=1000, date=datetime.date(2020, 6, 1), journal=JournalEntry(description='description', postings=[posting]))
    expected_entry = LedgerEntry(ledger, posting, 2000)
    entry = ledger.add(posting)
    assert entry == expected_entry


# Generated at 2022-06-26 00:31:42.497395
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Method __call__ of class GeneralLedgerProgram
    """
# Placeholder for test implementation
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()
    try:
        compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    except NotImplementedError:
        pass
# Placeholder for test implementation
    read_initial_balances_1 = ReadInitialBalances()
    read_journal_entries_1 = ReadJournalEntries()
    try:
        compile_general_ledger_program(read_initial_balances_1, read_journal_entries_1)
    except NotImplementedError:
        pass
# Placeholder for test implementation
    read_initial_bal

# Generated at 2022-06-26 00:31:44.508575
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    read_initial_balances_0()


# Generated at 2022-06-26 00:31:52.961587
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    print("Testing compile_general_ledger_program")
    read_initial_balances_0: ReadInitialBalances = lambda *args: {}
    read_journal_entries_0: ReadJournalEntries[_T] = lambda *args: []

    general_ledger_program_0: GeneralLedgerProgram[_T] = compile_general_ledger_program(
        read_initial_balances_0, read_journal_entries_0
    )
    period_0: DateRange = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    general_ledger_0: GeneralLedger[_T] = general_ledger_program_0(period_0)


# Generated at 2022-06-26 00:31:57.702356
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange(datetime.date(2016, 9, 21), datetime.date(2016, 12, 8))
    assert read_initial_balances_0(period_0) == {Account(): Balance(datetime.date(2016, 9, 21), Quantity(Decimal()))}


# Generated at 2022-06-26 00:32:07.734699
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## The posting
    posting_0 = Posting(
        Posting.Direction.CREDIT,
        Account("001", "Cash"),
        JournalEntry(19000101, "Opening Balance"),
        Decimal(1000.00),
    )

    ## Initial balances
    initial_balances_0 = InitialBalances()
    initial_balances_0[posting_0.account] = Balance(19000101, Quantity(posting_0.amount * Decimal(-1)))

    ## The ledger
    ledger_0 = Ledger(posting_0.account, initial_balances_0[posting_0.account])

    ## Adding the posting:
    ledger_entry_0 = ledger_0.add(posting_0)

    ## The ledger entry has balance of -1000

# Generated at 2022-06-26 00:32:19.024646
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    a = compile_general_ledger_program(ReadInitialBalances(), ReadJournalEntries())
    b = GeneralLedgerProgram()
    assert a == b

# Generated at 2022-06-26 00:32:25.438835
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()
    period_0 = DateRange()
    assert compile_general_ledger_program(
        read_initial_balances_0, read_journal_entries_0,
    )(period_0) == GeneralLedger(period_0, {})

# Generated at 2022-06-26 00:32:36.646058
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """Test case 0: No initial balances"""
    read_initial_balances_0 = ReadInitialBalances()
    read_initial_balances_0()
    # General ledger building program:
    read_journal_entries_0 = ReadJournalEntries()
    build_general_ledger_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    # General ledger as of today:
    general_ledger_0 = build_general_ledger_0(DateRange.since_today())
    # Validate the general ledger:
    # ...

    """Test case 1: With initial balances"""
    read_initial_balances_1 = ReadInitialBalances()
    # General ledger building program:
    read_journal_entries_1 = ReadJournalEntries()
   

# Generated at 2022-06-26 00:32:46.353760
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("A1010")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    entries = []
    ledger = Ledger(account, initial, entries)
    journal = JournalEntry()
    posting = Posting(journal, account, "A1", 1, datetime.date(2020, 1, 1))

    ledger.add(posting)

    assert ledger.add(posting).amount == Amount(1)
    assert ledger.add(posting).is_debit == True
    assert ledger.add(posting).is_credit == False
    assert ledger.add(posting).debit == Amount(1)
    assert ledger.add(posting).credit == None


# Generated at 2022-06-26 00:32:53.022715
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    A, B = Account("A"), Account("B")
    initial_balances_0, journal_entries_0 = InitialBalances(), [JournalEntry(datetime.date(2018, 9, 1), "J1", [], [])]
    construct_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    general_ledger_0 = construct_0(DateRange(datetime.date(2018, 9, 1), datetime.date(2018, 9, 1)))

# Generated at 2022-06-26 00:32:55.516853
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()
    result_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    assert callable(result_0)



# Generated at 2022-06-26 00:32:59.469697
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange(since=datetime.date(year=1970, month=1, day=1), until=datetime.date(year=1970, month=1, day=1))
    initial_balances_0 = read_initial_balances_0(period_0)
    test_case_0()


# Generated at 2022-06-26 00:33:01.069786
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    pass

# Generated at 2022-06-26 00:33:06.095988
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_account_0 = Account("test_account_0", False)
    test_value_1 = 100
    test_account_0.accountId = test_value_1
    test_balance_0 = Balance(datetime.date(2018, 1, 1), test_value_1)
    test_ledger_0 = Ledger(test_account_0, test_balance_0)
    test_direction_0 = 1
    test_amount_0 = 100
    test_journal_0 = JournalEntry(datetime.date(2018, 1, 1), "test_journal_0")
    test_value_0 = Posting(test_account_0, test_amount_0, test_direction_0, test_journal_0)

# Generated at 2022-06-26 00:33:07.810689
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    __test_function(compile_general_ledger_program)



# Generated at 2022-06-26 00:33:23.266404
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()
    period_0 = DateRange()
    _function_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    assert isinstance(_function_0(period_0), GeneralLedger)

# Generated at 2022-06-26 00:33:25.039611
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    obj = ReadInitialBalances()
    assert obj.__call__() is None


# Generated at 2022-06-26 00:33:26.001701
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    raise NotImplementedError()


# Generated at 2022-06-26 00:33:35.406594
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account
    from .generic import Balance
    @dataclass
    class _ReadInitialBalances(ReadInitialBalances):
        pass
    _ReadInitialBalances()
    read_initial_balances = _ReadInitialBalances()
    @dataclass
    class _DateRange(DateRange):
        pass
    period = _DateRange()
    def __call__(period: DateRange) -> InitialBalances:
        period = period
        import typing
        assert isinstance(period, DateRange)
        return typing.cast(InitialBalances, {})
    read_initial_balances.__call__ = __call__
    def __call__(period: DateRange) -> InitialBalances:
        period = period

# Generated at 2022-06-26 00:33:42.133611
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journals import read_journal_entries

    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = read_journal_entries()

    general_ledger_program_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    assert callable(general_ledger_program_0)


##
# Tests below should be migrated to journaling tests.
##


# Generated at 2022-06-26 00:33:48.471877
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
        read_initial_balances = ReadInitialBalances()
        read_journal_entries = ReadJournalEntries()
        general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
        result = general_ledger_program(period)
        assert result is not None
    except Exception:
        assert False


# Generated at 2022-06-26 00:33:52.579332
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances = ReadInitialBalances()
    period = DateRange(since=Date(day=1, month=1, year=1), until=Date(day=1, month=1, year=1))
    initial_balances = read_initial_balances(period)


# Generated at 2022-06-26 00:33:57.306435
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange(datetime.date(year=2018, month=6, day=11), datetime.date(year=2023, month=1, day=17))
    assert type(read_initial_balances_0(period_0)) == dict
    return None


# Generated at 2022-06-26 00:34:06.452250
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Tests ``add`` method of class Ledger.
    """
    from .accounts import Account, AccountType

    ## Create a ledger:
    ledger = Ledger(Account("Account 0", AccountType.ASSET), Balance("2001-01-01", Quantity(99)))

    ## Create a journal entry:
    je = JournalEntry(
        "Journal Entry 0",
        datetime.date(2001, 1, 2),
        [Posting(0, 100, Account("Account 0", AccountType.ASSET), Account("Account 1", AccountType.ASSET)),],
    )

    ## Add to the ledger:
    entry = ledger.add(je.postings[0])

    ## Assert results:
    assert hasattr(ledger, "entries")
    assert isinstance(ledger.entries, list)
    assert entry.balance

# Generated at 2022-06-26 00:34:07.109808
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass



# Generated at 2022-06-26 00:34:21.284241
# Unit test for method add of class Ledger
def test_Ledger_add():
    test = Ledger(None, None)
    test.add("posting")
    assert test.entries == [LedgerEntry(None, 'posting', Quantity(0))], "bad"


# Generated at 2022-06-26 00:34:26.822165
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    period = DateRange("2019-01", "2019-12")
    read_initial_balances_0 = None
    general_ledger_program_0 = None
    var_0 = compile_general_ledger_program(read_initial_balances_0, general_ledger_program_0)
    general_ledger_0 = var_0(period)

# Generated at 2022-06-26 00:34:35.268424
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # 12
    initial_balances: InitialBalances
    initial_balances['a'].value = '0.2345'
    initial_balances['b'].value = '0.2345'

    # 13
    journal: Iterable[JournalEntry]
    journal.append(JournalEntry("j1", '2014-10-01', ["sa", "sb"]))
    journal.append(JournalEntry("j2", '2015-10-01', ["sb", "sc"]))

    # 14
    period = DateRange()
    period.since = '2014-10-01'
    period.until = '2015-10-31'

    # 15
    general_ledger: GeneralLedger
    general_ledger = build_general_ledger(period, journal, initial_balances)

# Generated at 2022-06-26 00:34:44.133406
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = Account()
    Balance_0 = Balance(date=datetime.date(2020, 1, 1), value=Quantity(Decimal(0)))
    ledger_0 = Ledger(account=account_0, initial=Balance_0)
    account_1 = Account()
    amount_0 = Amount(Decimal(0))
    direction_0 = Posting.Direction.DEBIT
    journal_0 = JournalEntry(date=datetime.date(2020, 1, 1), description="Posting description.", id="1")
    posting_0 = Posting(account=account_1, amount=amount_0, direction=direction_0, journal=journal_0)
    ledger_entry_0 = ledger_0.add(posting=posting_0)


if __name__ == "__main__":
    test_case_0

# Generated at 2022-06-26 00:34:54.079557
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(account=Account(name='Current Assets'), initial=Balance(date=None, value=Quantity(amount=Decimal(0))))
    balance = ledger.initial.value
    newLedger = Ledger(account=Account(name='Current Assets'), initial=Balance(date=None, value=Quantity(amount=Decimal(0))))
    newLedger.add(posting=Posting(account=Account(name='Current Assets'), amount=Amount(Decimal(69)), journal=JournalEntry(date=datetime.date(2020, 8, 29), description='Journal entry description', postings=[Posting(account=Account(name='Current Assets'), amount=Amount(Decimal(69)), journal=JournalEntry(date=datetime.date(2020, 8, 29), description='Journal entry description', postings=[]))])))
    assert ledger.initial == newLedger

# Generated at 2022-06-26 00:34:58.421348
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger_instance_0 = Ledger(Account.of('521'), Balance.of('0'))
    var_0 = ledger_instance_0.add(Posting.of(Amount.of('0'), Account.of('521'), Direction.debit))
    assert var_0.balance == '0'


# Generated at 2022-06-26 00:35:03.156650
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period_0 = None
    journal_0 = None
    initial_0 = None
    var_0 = build_general_ledger(period_0, journal_0, initial_0)


# Generated at 2022-06-26 00:35:07.276252
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Invocation 1:
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries(JournalEntry)
    var_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    assert isinstance(var_0, GeneralLedgerProgram)

# Generated at 2022-06-26 00:35:16.652610
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    period_0 = None
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = None
    general_ledger_program_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    general_ledger_program_0.__call__(period_0)


# Generated at 2022-06-26 00:35:26.805141
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    account = Account(code="4100", fullname="Travel costs")
    initial_balance = Balance(datetime.date(2017, 12, 31), Quantity(Decimal(0)))
    journal_entry = JournalEntry(
        datetime.date(2018, 1, 2),
        description="Hotel room in Los Angeles.",
        postings=[Posting(account, Quantity(Decimal(100)))],
    )

    # Initializing a Ledger
    ledger_0 = Ledger(account, initial_balance)
    ledger_1 = Ledger(account, initial_balance)

    # Calling method add
    ledger_0.add(journal_entry.postings[0])

    assert ledger_0.account == ledger_1.account

# Generated at 2022-06-26 00:35:40.823188
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange(None, None)
    var_0 = read_initial_balances_0(period_0)


# Generated at 2022-06-26 00:35:42.030854
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:35:50.270621
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Initialize variables:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

# Generated at 2022-06-26 00:35:59.237091
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-26 00:36:08.809340
# Unit test for method add of class Ledger
def test_Ledger_add():
    read_initial_balances_0 = None
    general_ledger_program_0 = None
    var_0 = compile_general_ledger_program(read_initial_balances_0, general_ledger_program_0)
    account_0 = Account('\u05d3\u05de\u05d9\u05dc\u05d5\u05ea \u05dc\u05d7\u05d1\u05e8')
    var_1 = Decimal('1.36E-4')
    decimal_0 = Decimal('12.5')
    decimal_1 = Decimal('3.200')
    decimal_2 = Decimal('1E-2')
    decimal_3 = Decimal('3.200')
    decimal_4 = Decimal('1E-2')
    decimal_5

# Generated at 2022-06-26 00:36:09.854873
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True


# Generated at 2022-06-26 00:36:14.145628
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger_0 = Ledger(42, [])
    ledger_0.add(3)
    assert ledger_0.read() == [3]
    ledger_0.add(4)
    assert ledger_0.read() == [3, 4]
    ledger_0.add(5)
    assert ledger_0.read() == [3, 4, 5]


# Generated at 2022-06-26 00:36:23.380754
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.numbers import Amount, Quantity
    from .accounting import ReadChartOfAccounts
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import InitialBalances, LedgerEntry, Ledger, build_general_ledger, compile_general_ledger_program, test_case_0
    def read_initial_balances_0(period):
        return InitialBalances()
    general_ledger_program_0 = compile_general_ledger_program(read_initial_balances_0, ReadJournalEntries())
    var_0 = None
    def read_initial_balances_1(period):
        return read_initial_balances_0(period)

# Generated at 2022-06-26 00:36:32.977274
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from dtcc.journaling import JournalEntry, Posting
    from dtcc.accounts import Account
    from dtcc.commons import to_quantity
    from dtcc.general_ledger import build_general_ledger
    from dtcc.commons.zeitgeist import DateRange

# Generated at 2022-06-26 00:36:38.050963
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period_0 = DateRange(datetime.date(2031, 6, 14), datetime.date(2709, 5, 10))
    journal_0 = Iterable[JournalEntry[_T]]
    initial_0 = InitialBalances
    var_0 = build_general_ledger(period_0, journal_0, initial_0)
    assert var_0 == GeneralLedger[_T]



# Generated at 2022-06-26 00:37:01.643066
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert False



# Generated at 2022-06-26 00:37:03.633469
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    obj_0 = ReadInitialBalances()
    period_0 = DateRange(0, 0)
    var_0 = obj_0(period_0)

# Generated at 2022-06-26 00:37:09.166512
# Unit test for method add of class Ledger
def test_Ledger_add():

    # construct attributes:
    account = Account("account")
    initial = Balance("initial", Quantity("initial-value"))
    entries = []

    # instantiate object:
    obj = Ledger(account, initial, entries)

    # test calls method with valid parameters and assert it is correctly implemented:
    posting = JournalEntry("journal", "description", "date", "amount", "currency")
    output = obj.add(posting)
    assert True

    # test calls method with invalid parameters and assert that ValueError is raised:
    pass

# Generated at 2022-06-26 00:37:11.951512
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    rr = ReadInitialBalances()
    period_0 = DateRange(datetime.date(2020, 11, 1), datetime.date(2020, 11, 30))
    result_0 = rr.__call__(period_0)
    assert result_0 is None


# Generated at 2022-06-26 00:37:19.304496
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_2 = None
    general_ledger_program_1 = None
    var_1 = compile_general_ledger_program(read_initial_balances_2, general_ledger_program_1)
    period_0 = None
    var_2 = var_1(period_0)
    assert var_2 == None


# Generated at 2022-06-26 00:37:22.790853
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    general_ledger_program_0 = None
    var_0 = compile_general_ledger_program(read_initial_balances_0, general_ledger_program_0)
    var_0.__call__()

# Generated at 2022-06-26 00:37:31.655489
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    period = DateRange(datetime.date(year=2020, month=1, day=1), datetime.date(year=2020, month=3, day=31))

# Generated at 2022-06-26 00:37:44.599616
# Unit test for function build_general_ledger
def test_build_general_ledger():
    opening = datetime.date(2020, 1, 1)
    closing = datetime.date(2020, 6, 30)
    period = DateRange(since=opening, until=closing)


# Generated at 2022-06-26 00:37:48.267432
# Unit test for function build_general_ledger
def test_build_general_ledger():
    read_initial_balances = ReadInitialBalances()
    read_journal_entries = ReadJournalEntries()
    var_0 = compile_general_ledger_program(read_initial_balances, read_journal_entries)


# Generated at 2022-06-26 00:37:55.365700
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    general_ledger_program_0 = None
    general_ledger_1 = GeneralLedgerProgram___call__(read_initial_balances_0, general_ledger_program_0)

# Generated at 2022-06-26 00:38:35.070974
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    var_0 = ReadInitialBalances.__call__(date_range_0)


# Generated at 2022-06-26 00:38:36.729741
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    var_0 = ReadInitialBalances.__call__(date_range_0)


# Generated at 2022-06-26 00:38:38.258335
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    param_0 = None
    var_0 = GeneralLedgerProgram.__call__(param_0)


# Generated at 2022-06-26 00:38:46.826477
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def _mock_of_ReadInitialBalances__call__(period):
        assert type(period) is DateRange
        return {}


    mock_of_ReadInitialBalances = ReadInitialBalances()
    mock_of_ReadInitialBalances.__call__ = _mock_of_ReadInitialBalances__call__
    mock_of_ReadInitialBalances.__call__.__annotations__ = {"return": InitialBalances, "period": DateRange}
    def _mock_of_ReadJournalEntries__call__(period):
        assert type(period) is DateRange
        return set()


    mock_of_ReadJournalEntries = ReadJournalEntries()
    mock_of_ReadJournalEntries.__call__ = _mock_of_ReadJournalEntries__call__
    mock_of_ReadJournalEntries

# Generated at 2022-06-26 00:38:52.761037
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    dict_0 = {}
    set_0 = set()
    def method_0(self, arg_0: DateRange) -> InitialBalances:
        return dict_0
    def method_1(self, arg_0: DateRange) -> Iterable[JournalEntry[_T]]:
        return set_0
    var_0 = compile_general_ledger_program(method_0, method_1)
    assert type(var_0.__call__(date_range_0)) == GeneralLedger

# Generated at 2022-06-26 00:38:53.801395
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert callable(compile_general_ledger_program)


# Generated at 2022-06-26 00:38:55.372298
# Unit test for method add of class Ledger
def test_Ledger_add():
    obj = Ledger(None, None)
    posting_0 = None
    var_0 = obj.add(posting_0)



# Generated at 2022-06-26 00:38:57.231231
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    set_0 = set()
    dict_0 = {}
    assert build_general_ledger(date_range_0, set_0, dict_0) is None


# Generated at 2022-06-26 00:38:58.807106
# Unit test for function compile_general_ledger_program

# Generated at 2022-06-26 00:38:59.225054
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-26 00:39:31.652851
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    ledgers = GeneralLedgerProgram(ledgers)
    __call__(ledgers, date_range_0)


# Generated at 2022-06-26 00:39:34.061863
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Test method add of class Ledger
    """
    e = Ledger()
    e.entries = []
    e.initial = 0
    assert e.entries == []
    e.add(3)
    assert e.entries == [3]

# Generated at 2022-06-26 00:39:35.880943
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    program_0 = compile_general_ledger_program(None, None)
    date_range_0 = None
    var_0 = program_0(date_range_0)


# Generated at 2022-06-26 00:39:37.399861
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    var_0 = ReadInitialBalances.__call__(date_range_0)


# Generated at 2022-06-26 00:39:45.056305
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    set_0 = set()
    dict_0 = {}
    var_0 = build_general_ledger(date_range_0, set_0, dict_0)

# Generated at 2022-06-26 00:39:46.336858
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Calling the method
    ReadInitialBalances___call__()

    # Asserting the result
    assert True



# Generated at 2022-06-26 00:39:49.321933
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    instance_0 = compile_general_ledger_program(test_case_0, test_case_0)
    instance_0.__call__(date_range_0)


# Generated at 2022-06-26 00:39:55.671162
# Unit test for method add of class Ledger
def test_Ledger_add():
    date1 = datetime.date(1, 1, 1)
    date2 = datetime.date(2, 2, 2)
    j1 = JournalEntry(date1, "j1", "some description")
    j2 = JournalEntry(date2, "j2", "some description")
    p1 = Posting(j1, 1, 1000, 0, True, False)
    p2 = Posting(j2, 1, 2000, 0, True, False)
    ledger = Ledger(1, Balance(1000, 1000))
    ledger.add(p1)
    ledger.add(p2)
    assert ledger.entries[0].date == date1
    assert ledger.entries[0].balance == 2000
    assert ledger.entries[0].posting == p1
    assert ledger.entries[1].date == date

# Generated at 2022-06-26 00:40:03.150126
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Initialization.
    journal_entries_1 = {JournalEntry(datetime.date(2020, 1, 1), 'DEBIT', 'DEBIT', 'DEBIT', 'DEBIT', 'DEBIT', 'DEBIT', 'DEBIT', 'DEBIT')}
    journal_entries_2 = {JournalEntry(datetime.date(2020, 1, 1), 'FIRST', 'FIRST', 'FIRST', 'FIRST', 'FIRST', 'FIRST', 'FIRST', 'FIRST')}
    journal_entries_3 = {JournalEntry(datetime.date(2020, 1, 1), 'RUNNER', 'RUNNER', 'RUNNER', 'RUNNER', 'RUNNER', 'RUNNER', 'RUNNER', 'RUNNER')}

# Generated at 2022-06-26 00:40:08.907379
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = DateRange(datetime.date(year=2020, month=1, day=1), datetime.date(year=2020, month=12, day=31))
    set_0 = {JournalEntry("description", [Posting("account_1", Decimal("30"), 1), Posting("account_2", Decimal("-30"), -1)])}
    dict_0 = {"account_1": Balance(datetime.date(year=2020, month=1, day=1), Decimal("0"))}
    var_0 = build_general_ledger(date_range_0, set_0, dict_0)
    assert var_0.period == DateRange(datetime.date(year=2020, month=1, day=1), datetime.date(year=2020, month=12, day=31))


# Generated at 2022-06-26 00:40:42.285868
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    do_assert_ = ReadInitialBalances()
    var_0 = None
    var_1 = do_assert_.__call__(var_0)


# Generated at 2022-06-26 00:40:46.431740
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Method add
    ## Case 0
    var_0 = None
    ledger_0 = Ledger(var_0, var_0)
    var_1 = ledger_0.add(var_0)

# Generated at 2022-06-26 00:40:52.581182
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict, Iterable, Optional, TypeVar
    from unittest import TestCase
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    _T = TypeVar("_T")
    @dataclass
    class LedgerEntry(Generic[_T]):
        ledger: "Ledger[_T]"
        posting: Posting[_T]
        balance: Quantity
        @property
        def date(self) -> datetime.date:
            return self.posting.date
        @property
        def description(self) -> str:
            return self.posting.journal.description