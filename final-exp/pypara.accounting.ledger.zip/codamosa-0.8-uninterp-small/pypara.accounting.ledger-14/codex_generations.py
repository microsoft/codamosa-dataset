

# Generated at 2022-06-26 00:31:02.721400
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True


read_journal_entries_0 = ReadJournalEntries()


# Generated at 2022-06-26 00:31:12.763582
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import Posting, JournalEntry, read_journal_entries
    from .generic import Balance
    from .read_journal_entries import read_journal_entries
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from . import journal_entries as je

    """ 
    This unit test is used to confirm that a general ledger can be created by receiveing opening balances, closing dates, 
    and the iterator to read the journal entries.
    """
    period = DateRange(date(2019, 7, 1), date(2019, 7, 31))

# Generated at 2022-06-26 00:31:18.513061
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Input data
    date_range = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 2))
    # Expected result
    expected: InitialBalances = {}
    # Run test
    actual: InitialBalances = read_initial_balances_0.__call__(date_range=date_range)
    # Check results
    assert actual == expected



# Generated at 2022-06-26 00:31:27.233673
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .test_utility import make_journal_entry

    ## Set up a GeneralLedgerProgram instance:
    read_initial_balances_0 = ReadInitialBalances()

    @dataclass
    class JournalEntryList(Generic[_T]):
        journal_entries: List[JournalEntry[_T]]


# Generated at 2022-06-26 00:31:36.791357
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from gluetool.test.test_journaling import build_journal_entry, build_posting
    # Mock:

# Generated at 2022-06-26 00:31:39.034626
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_journal_entries_0 = ReadJournalEntries()
    compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)

# Generated at 2022-06-26 00:31:40.822403
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass



# Generated at 2022-06-26 00:31:41.847468
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ReadInitialBalances.__call__()


# Generated at 2022-06-26 00:31:46.946581
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange(datetime.date(1976, 11, 27), datetime.date(1942, 6, 9), )
    initial_balances_0 = InitialBalances(account, balance, )
    ReadInitialBalances.__call__(period_0)
    assert initial_balances_0 == initial_balances_0


# Generated at 2022-06-26 00:31:54.855797
# Unit test for method add of class Ledger
def test_Ledger_add():
    testledger = Ledger(101, Balance(datetime.date, Quantity(Decimal(0))))
    posting = Posting(101, Quantity(Decimal(100)), datetime.date)
    testledger.add(posting)
    assert testledger.entries == [LedgerEntry(testledger, posting, Quantity(Decimal(100)))]
    posting2 = Posting(101, Quantity(Decimal(200)), datetime.date)
    testledger.add(posting2)
    assert testledger.entries == [
        LedgerEntry(testledger, posting, Quantity(Decimal(100))),
        LedgerEntry(testledger, posting2, Quantity(Decimal(300))),
    ]

# Generated at 2022-06-26 00:32:00.782240
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert False

# Generated at 2022-06-26 00:32:10.179388
# Unit test for method add of class Ledger

# Generated at 2022-06-26 00:32:12.443607
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # get general ledger for financial year 2020.
    var_0 = None
    var_1 = GeneralLedgerProgram(var_0).__call__(var_0)

# Generated at 2022-06-26 00:32:15.380941
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    period_0: DateRange = None
    read_initial_balances_0 = None
    var_0 = None
    var_1 = read_initial_balances_0.__call__(period_0)


# Generated at 2022-06-26 00:32:18.875463
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = None
    var_1 = None
    var_2 = build_general_ledger(var_0, var_1, var_2)

# Generated at 2022-06-26 00:32:23.748606
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    var_1 = Ledger(var_0, var_0)
    var_2 = Posting(var_0, var_0, var_0)
    var_1.add(var_2)


# Generated at 2022-06-26 00:32:27.302852
# Unit test for method add of class Ledger
def test_Ledger_add():
    var = None
    var_0 = Ledger(var, var)
    var_1 = Posting(var, var)
    var_0.add(var_1)

# Unit tests for method is_debit of class LedgerEntry

# Generated at 2022-06-26 00:32:28.375776
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    test_case_0()

# Generated at 2022-06-26 00:32:32.843164
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = DateRange()
    var_1(var_2)

# Generated at 2022-06-26 00:32:37.241269
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    period_0 = None
    var_1(period_0)

# Generated at 2022-06-26 00:32:49.448489
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Setup
    account = Account('NewAccount', 'NewAccount', 'NewAccount', 'NewAccount', 'NewAccount')
    initial = Balance('NewBalance', 'NewBalance', 'NewBalance', 'NewBalance', 'NewBalance')
    var_0 = Ledger(account, initial)
    posting = Posting('NewPosting', 'NewPosting', 'NewPosting', 'NewPosting', 'NewPosting')
    # Invoke method
    result = var_0.add(posting)
    # Check result
    assert not None, 'Return value of method Ledger.add is None'
    assert True, 'Return value of method Ledger.add is correct'
    assert type(result) == LedgerEntry, 'Return value of method Ledger.add is of type LedgerEntry'


# Generated at 2022-06-26 00:32:58.352768
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from . import journals
    from .accounts import Account, AccountCategory, AccountTree
    from .journaling import BusinessEvent, JournalEntry
    from .types import Quantity
    from .util import AccountReference

    local = AccountCategory("Local")
    foreign = AccountCategory("Foreign")
    assets = AccountCategory("Assets", [local, foreign])
    liabilities = AccountCategory("Liabilities", [local, foreign])
    equities = AccountCategory("Equities")
    expense = AccountCategory("Expense")


# Generated at 2022-06-26 00:33:00.021155
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # ...
    # Execute function under test
    # ...

    # Validate results
    pass


# Generated at 2022-06-26 00:33:06.033118
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances.__call__(var_0, )


# Generated at 2022-06-26 00:33:16.787093
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date

    from .accounts import Account, AccountType, AccountSubtype
    from .journaling import BuildJournalEntry, BuildPosting, JournalEntry, PostingDirection

    # Define test data:
    opening_balance_date = date(2019, 1, 1)

    acct_101 = Account(101, AccountType.ASSET, AccountSubtype.CASH)
    acct_201 = Account(201, AccountType.LIABILITY, AccountSubtype.ACCOUNTS_PAYABLE)
    acct_401 = Account(401, AccountType.REVENUE, AccountSubtype.SALES)


# Generated at 2022-06-26 00:33:20.112428
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = None  # FIXME: get some real object
    period_0 = None  # FIXME: get some real object
    var_0 = read_initial_balances_0.__call__(period_0)


# Generated at 2022-06-26 00:33:22.737400
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Tests :py:func:`ReadInitialBalances.__call__`.
    """
    var_2 = None
    var_3 = ReadInitialBalances.__call__(var_2)



# Generated at 2022-06-26 00:33:26.620801
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Test initialization
    period_0 = DateRange(None, None)
    journal_0 = None
    initial_0 = {}
    assert isinstance(build_general_ledger(period_0, journal_0, initial_0), GeneralLedger)


# Generated at 2022-06-26 00:33:28.902817
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances()
    var_1 = DateRange()
    var_0.__call__(var_1)


# Generated at 2022-06-26 00:33:32.450574
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    var_1(var_2)

# Generated at 2022-06-26 00:33:48.859150
# Unit test for method add of class Ledger
def test_Ledger_add():
    print("Testing method add at class Ledger...")
    account_0 = Account(name = "account", classification = AccountClassification.ASSET)
    initial_0 = Balance(date = datetime.date(2000, 1, 1), value = Quantity(Decimal('0')))
    postings_0 = [Posting(journal = JournalEntry(description = "description", date = datetime.date(2000, 2, 1), postings = [Posting(account = Account(name = "account", classification = AccountClassification.ASSET), direction = Direction.DEBIT, amount = Quantity(Decimal('0')))]), direction = Direction.DEBIT, amount = Quantity(Decimal('0')))]
    entries_0 = []
    ledger_0 = Ledger(account = account_0, initial = initial_0, entries = entries_0)

# Generated at 2022-06-26 00:33:55.182082
# Unit test for function build_general_ledger
def test_build_general_ledger():

    # Test 1:
    period_0 = DateRange(datetime.date(1, 1, 1), datetime.date(2, 2, 2))
    journal_0 = None
    initial_0 = {Account(1): Balance(datetime.date(1, 1, 1), Quantity(Decimal(1)))}
    _build_general_ledger_0 = build_general_ledger(period_0, journal_0, initial_0)
    _build_general_ledger_0


# Generated at 2022-06-26 00:33:58.161525
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)


# Generated at 2022-06-26 00:34:01.810900
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = None
    var_2 = DateRange(datetime.date(1, 1, 1), datetime.date(9999, 12, 31))
    var_3 = read_initial_balances_0(var_2)

# Generated at 2022-06-26 00:34:09.322329
# Unit test for function compile_general_ledger_program

# Generated at 2022-06-26 00:34:11.128705
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_2 = None
    var_3 = test_case_0().read_initial_balances__0(var_2)


# Generated at 2022-06-26 00:34:20.304839
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    general_ledger_program_0 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    general_ledger_0 = general_ledger_program_0(var_2)
    ledgers_0 = general_ledger_0.ledgers
    for account_0, ledger_0 in ledgers_0.items():
        var_3 = ledger_0.entries
        for ledger_entry_0 in var_3:
            var_4 = ledger_entry_0.date
            var_5 = ledger_entry_0.description
            var_6 = ledger_entry_0.cntraccts
            var_7 = ledger_entry_0.is_debit


# Generated at 2022-06-26 00:34:22.386536
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_1 = None
    read_initial_balances_1.__call__()


# Generated at 2022-06-26 00:34:26.509022
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    assert var_1 is not None

test_case_0()

# Generated at 2022-06-26 00:34:27.499937
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    subject = ReadInitialBalances()



# Generated at 2022-06-26 00:34:41.845280
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-26 00:34:43.339093
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Test if building a general ledger works.
    """
    return 0



# Generated at 2022-06-26 00:34:44.158915
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_case_0()

# Generated at 2022-06-26 00:34:54.080239
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    
    var_0 = DateRange("2001-09-20", "2002-09-20")
    var_1 = Decimal("500")

    def read_initial_balances(period):
        return {Account("101"): Balance(var_0.since, Quantity(var_1))}

    read_initial_balances_0 = read_initial_balances
    var_2 = None
    var_3 = compile_general_ledger_program(read_initial_balances_0, var_2)
    assert isinstance(var_3(var_0), GeneralLedger)
    assert var_3(var_0).period == var_0

# Generated at 2022-06-26 00:35:05.800048
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Setup test data
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

# Generated at 2022-06-26 00:35:06.564402
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-26 00:35:07.621716
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:35:14.934921
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    obj_0 = compile_general_ledger_program(None, var_0)
    def method_under_test(arg_0):
        return obj_0(arg_0)
    var_1 = None
    assert method_under_test(var_1) is not None

# Generated at 2022-06-26 00:35:20.189123
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Test fixture
    read_initial_balances = lambda period: {}
    read_journal_entries = lambda period: []
    # Perform the test
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    # Perform the verifications
    assert isinstance(general_ledger_program, callable)

# Generated at 2022-06-26 00:35:32.396115
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    for _ in range(25):
        # Prepare:
        var_0 = JournalEntry(date(2018, 10, 15), "The first journal entry", [Posting(Account(101),  Decimal(0), ""), Posting(Account(611),  Decimal(0), "")])
        var_1 = JournalEntry(date(2018, 10, 15), "The second journal entry", [Posting(Account(101),  Decimal(0), ""), Posting(Account(611),  Decimal(0), "")])
        var_2 = var_1
        var_3 = var_1
        var_4 = var_1
        __expect__ = None

        # Execute:

# Generated at 2022-06-26 00:36:02.134483
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)

    assert var_1(1.0) == None

# Generated at 2022-06-26 00:36:06.685422
# Unit test for method add of class Ledger
def test_Ledger_add():
  ledg = Ledger(Account(1),Balance(BalanceType.OPEN,0))
  entry= LedgerEntry(ledg,Posting(datetime.datetime.now(),Account(2),Account(1),BalanceType.OPEN,0),0)
  ledg.add(entry)
  assert ledg.entries[0]==entry
  print("test_Ledger_add Pass")


# Generated at 2022-06-26 00:36:09.650768
# Unit test for function build_general_ledger
def test_build_general_ledger():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = build_general_ledger(var_0, read_initial_balances_0, var_0)

# Generated at 2022-06-26 00:36:12.544775
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Test 1:
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = build_general_ledger(var_0, var_1, var_2)


# Generated at 2022-06-26 00:36:21.547663
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.algebras import get_read_journal_entries
    from ..commons.types import JournalEvent
    from .algebras import get_read_initial_balances
    from .journaling import journal_events
    from .types import AccountTypeCode, AccountType, ParentAccount, Account, AccountFilter

    ## Create a ledger:

# Generated at 2022-06-26 00:36:30.909647
# Unit test for method add of class Ledger

# Generated at 2022-06-26 00:36:31.776450
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-26 00:36:37.367213
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 1))
    var_3 = var_1(var_2)

# Generated at 2022-06-26 00:36:45.247750
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print("Test: 'build_general_ledger'")

    ## Arrange:

    ##- Fakes:
    class FakeJournalEntry0(JournalEntry):
        def __init__(self, description, *postings):
            super().__init__(description, *postings)


# Generated at 2022-06-26 00:36:48.869907
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances.__call__
    var_0 = None
    var_1 = read_initial_balances_0(var_0)
    var_2 = InitialBalances
    assert type(var_1) is var_2


# Generated at 2022-06-26 00:37:39.900000
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False


# Generated at 2022-06-26 00:37:42.068623
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    try:
        test_case_0()
    except Exception as ex:
        print("Exception occurred while testing function compile_general_ledger_program")
        print("Exception: ", ex)
        assert False
    print("test_compile_general_ledger_program: Success!")


# Run the test.
test_compile_general_ledger_program()

# Output format:
# test_compile_general_ledger_program: Success!

# Generated at 2022-06-26 00:37:47.692800
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_journal_entries_1 = None
    period_0 = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    read_initial_balances_1 = None
    var_2 = compile_general_ledger_program(read_initial_balances_1, read_journal_entries_1)
    var_3 = var_2(period_0)

# Generated at 2022-06-26 00:37:50.065479
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances
    var_1 = var_0()
    var_2 = var_1.__call__(None)
    assert var_2 is None



# Generated at 2022-06-26 00:37:58.318358
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    var_1(var_2)

# Generated at 2022-06-26 00:38:01.657724
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    var_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, var_0)
    var_2 = None
    var_1(var_2)


# Generated at 2022-06-26 00:38:02.683281
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from mock import Mock
    Mock()

# Generated at 2022-06-26 00:38:09.576887
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(None, None)
    var_1 = datetime.date(year=2020, month=8, day=19)
    var_1 = datetime.date(year=2020, month=8, day=19)
    var_2 = datetime.date(year=2020, month=8, day=19)
    var_3 = DateRange(since=var_1, until=var_2)
    var_4 = var_0(var_3)

# Generated at 2022-06-26 00:38:11.389713
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    __call__0 = None
    var_0 = ReadInitialBalances()
    var_0.__call__(__call__0)


# Generated at 2022-06-26 00:38:12.208854
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()
