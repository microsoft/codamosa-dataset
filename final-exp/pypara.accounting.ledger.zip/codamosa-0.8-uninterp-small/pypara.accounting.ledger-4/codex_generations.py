

# Generated at 2022-06-26 00:31:10.227276
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account(0), Balance(period.since, Quantity(Decimal(0))))
    posting = Posting(account, period.since, Decimal(0))
    expected = LedgerEntry(ledger, posting, Quantity(Decimal(0)))
    actual = ledger.add(posting)
    assert actual == expected


# Generated at 2022-06-26 00:31:14.344785
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange(datetime.date(2200, 9, 4), datetime.date(2200, 9, 19))
    initial_balances_0 = read_initial_balances_0(period_0)
    print(initial_balances_0)


# Generated at 2022-06-26 00:31:24.334533
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import datetime
    import unittest
    from src.bank.commons.zeitgeist import DateRange

    from src.bank.accounting.accounts import Asset, Liability, Equity
    from src.bank.accounting.journaling import JournalEntry, Posting
    from src.bank.accounting.generic import Balance

    from src.bank.accounting.ledgers import build_general_ledger, Ledger, LedgerEntry

    def _build_program():
        initial_balances = {Asset: Balance(datetime(2019, 12, 31), Quantity(Decimal(10.00))),}

        def _read_initial_balance(period: DateRange) -> dict:
            return initial_balances


# Generated at 2022-06-26 00:31:28.545258
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(None, Balance(None, Quantity(Decimal("0"))))
    posting = Posting(None, None, Amount(Decimal("100")))
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal("100"))

# Generated at 2022-06-26 00:31:31.484168
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances = ReadInitialBalances()
    read_journal_entries = ReadJournalEntries()
    compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-26 00:31:38.304990
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    _period = DateRange(datetime.date(2019, 11, 1), datetime.date(2019, 11, 30))
    expected = {
        Account(2000000): Balance(datetime.date(2019, 10, 31), Quantity(Decimal("100.00"))),
        Account(3000000): Balance(datetime.date(2019, 10, 31), Quantity(Decimal("200.00"))),
    }
    actual = read_initial_balances_0(_period)
    assert actual == expected


read_journal_entries_0 = ReadJournalEntries()


# Generated at 2022-06-26 00:31:40.363583
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert False #print(build_general_ledger)


# Generated at 2022-06-26 00:31:40.959020
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass

# Generated at 2022-06-26 00:31:46.469607
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    args = []
    retval = None
    func_name = read_initial_balances_0.__call__.__name__
    args_str = f"{func_name}({','.join(map(str, args))})"
    assert retval == None, f"{args_str} should return {retval} but returned {None}"
    print(f"Test for function {args_str} passed!")


# Generated at 2022-06-26 00:31:47.383961
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-26 00:32:05.388313
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = '6:8'
    str_1 = '3:a'
    str_2 = 'COA.Node'
    list_0 = []
    set_0 = {str_0, str_2, str_1, str_0}
    date_range_0 = None
    var_0 = ReadInitialBalances()
    var_0.__class__.__qualname__ = list_0
    var_0.__call__(date_range_0)
    balance_0 = Balance(date_range_0, set_0)
    set_1 = set_0
    set_2 = {balance_0}
    list_1 = []
    str_3 = '2:b'
    account_0 = Account(set_1, str_3)
    set_3 = set_2


# Generated at 2022-06-26 00:32:10.090412
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def function_0(argument_0: DateRange):
        pass
    def function_1(argument_0: DateRange):
        pass

    var_0 = compile_general_ledger_program(function_0, function_1)

if __name__ == "__main__":
    test_case_0()
    test_compile_general_ledger_program()

# Generated at 2022-06-26 00:32:17.815379
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import datetime
    from nomadic.commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting
    from .coa import ChartOfAccounts

    ## Prepare the COA:

# Generated at 2022-06-26 00:32:28.205111
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    date_range_1 = var_0
    iterable_1 = None
    dict_2 = {str_0: var_0, str_1: var_0}
    var_1 = build_general_ledger(date_range_1, iterable_1, dict_2)
    # Function execution
    compile_general_ledger_program(var_0, var_1)

# Generated at 2022-06-26 00:32:40.237723
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    print('Test case 0')
    str_0 = 'COA.Node'
    str_1 = 'Account'
    str_2 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0}
    func_0 = compile_general_ledger_program(dict_0, dict_0)
    print(func_0)
    print(type(func_0))
    print('Test case 1')
    str_3 = 'COA.Node'
    str_4 = 'Account'
    str_5 = '3:c'
    dict_1 = {str_5: str_5, str_3: str_5, str_4: str_5}

# Generated at 2022-06-26 00:32:47.760599
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = DateRange(datetime.date(2156, 1, 20), datetime.date(2127, 8, 17))
    journal_entry_0 = JournalEntry([Posting(1, 2, 1)], datetime.date(2123, 4, 2))
    feed_0 = [journal_entry_0]
    initial_balances_0 = {Account('COA.Node'): Balance(datetime.date(2121, 6, 9), 5)}
    var_0 = build_general_ledger(date_range_0, feed_0, initial_balances_0)


# Generated at 2022-06-26 00:32:56.839842
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    var_1 = copy.deepcopy(var_0)
    var_2 = var_1.ledgers
    var_3 = var_1.ledgers.keys()
    var_4 = var_2.get(var_3[0])
    var_5 = var_4.account
    var_6 = var_4.initial
    id(var_5)

# Generated at 2022-06-26 00:33:01.193367
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)


# Generated at 2022-06-26 00:33:06.198634
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'A'
    str_1 = 'C'
    decimal_0 = Decimal('0')
    date_0 = datetime.date(1,1,1)
    amount_0 = Amount('10.00')
    amount_1 = Amount('-10.00')
    date_1 = datetime.date(1,1,1)
    date_2 = datetime.date(1,1,1)
    date_3 = datetime.date(1,1,1)
    # test.json
    str_2 = 'test'
    account_0 = Account(str_2)
    balance_0 = Balance(date_0, decimal_0)
    ledger_0 = Ledger(account_0, balance_0)
    string_0 = ''

# Generated at 2022-06-26 00:33:14.764727
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)

if __name__ == '__main__':
    test_case_0()
    test_GeneralLedgerProgram___call__()

# Generated at 2022-06-26 00:33:29.473156
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    build_general_ledger(date_range_0, iterable_0, dict_1)


# Generated at 2022-06-26 00:33:38.461239
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    str_2 = 'COA.Node'
    str_3 = '3:c'
    dict_2 = {str_2: str_2, str_3: str_2, str_2: str_2}
    date_range_1 = None
    iterable_1 = None
    dict_3 = None

# Generated at 2022-06-26 00:33:40.309101
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()

# Generated at 2022-06-26 00:33:41.960277
# Unit test for method add of class Ledger
def test_Ledger_add():
    obj = None
    var_0 = obj.add(posting=None)



# Generated at 2022-06-26 00:33:46.580090
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # AssertionError: Expected <class 'ledger.general.GeneralLedgerProgram[str]'>, received <class 'function'>
    # assert type(compile_general_ledger_program) == <class 'ledger.general.GeneralLedgerProgram[str]'>, "Expected <class 'ledger.general.GeneralLedgerProgram[str]'>, received {type(compile_general_ledger_program)}"
    pass

# Generated at 2022-06-26 00:33:52.077314
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    var_0 = ReadInitialBalances()
    date_range_0 = None
    var_1 = var_0(date_range_0)


# Generated at 2022-06-26 00:33:57.554730
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)


# Generated at 2022-06-26 00:33:58.465224
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:34:04.373187
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = compile_general_ledger_program(dict_0, dict_1)
    var_0(date_range_0)


# Generated at 2022-06-26 00:34:10.814032
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Initialization
    str_0 = "p7z{@KL-V7:2+d.3"
    dataclass_0 = None
    dataclass_1 = None
    dataclass_2 = None
    list_0 = [dataclass_0, dataclass_1, dataclass_2, dataclass_1, dataclass_2, dataclass_2]
    str_1 = "q;L-I9)9,tGcSR_n"
    dictionary_0 = {str_0: list_0, str_1: list_0, str_0: list_0}
    str_2 = "e-Yg?_GHO,C>W8j9"
    int_0 = -5

# Generated at 2022-06-26 00:34:30.526869
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test for method __call__ of class GeneralLedgerProgram
    pass

# Generated at 2022-06-26 00:34:39.288364
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    var_1 = test_case_0()
    var_1 = compile_general_ledger_program(var_0, var_1)
    var_2 = test_case_0()
    var_2 = compile_general_ledger_program(var_0, var_1)
    var_3 = test_case_0()
    var_3 = compile_general_ledger

# Generated at 2022-06-26 00:34:43.536942
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    var_0 = ReadInitialBalances.__call__(dict_0, date_range_0)


# Generated at 2022-06-26 00:34:44.677096
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print(test_case_0())
    
# main function to run the test cases

# Generated at 2022-06-26 00:34:52.223227
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    iterable_0 = None
    dict_1 = {str(i): str(i) for i in range(2)}
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    assert any(dict_1)
    assert var_0 != dict_1
    assert var_0.ledgers == dict_1
    assert var_0.ledgers is not dict_1

# Test for function test_read_initial_balances

# Generated at 2022-06-26 00:34:55.065623
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)


# Generated at 2022-06-26 00:34:57.093269
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    instance = ReadInitialBalances()
    assert isinstance(instance.__call__(date_range_0), InitialBalances)


# Generated at 2022-06-26 00:35:08.296840
# Unit test for function build_general_ledger
def test_build_general_ledger():

    # Assigning mock values to variables.
    str_0 = 'COA.Node.GeneralLedger'
    date_0 = None
    date_0 = date_0
    date_1 = date_0
    date_range_0 = DateRange(date_0, date_1)
    balance_0 = Balance(date_0, Quantity(Decimal(0)))
    ledger_0 = Ledger(str_0, balance_0)
    str_1 = 'Ledger'
    str_2 = 'Ledger'
    dict_0 = {str_1: ledger_0, str_2: ledger_0}
    str_3 = 'GeneralLedger'
    str_4 = 'GeneralLedger'
    dict_1 = {str_3: str_0, str_4: str_0}

# Generated at 2022-06-26 00:35:16.873369
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances_0 = "("
    read_journal_entries_0 = None
    var_0 = compile_general_ledger_program(
        read_initial_balances_0, read_journal_entries_0
    )
    date_range_0 = None
    var_1 = var_0(date_range_0)


# Generated at 2022-06-26 00:35:19.115170
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries
    from .accounts import ReadInitialBalances

    print(compile_general_ledger_program(ReadInitialBalances(), ReadJournalEntries()))

# Generated at 2022-06-26 00:35:48.324479
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    account_0 = None
    balance_0 = Balance(datetime.datetime(2019, 12, 30, 13, 21, 55, 136320), Decimal('0'))
    ledger_0 = Ledger(account_0, balance_0)
    posting_0 = None
    ledger_0.add(posting_0)


# Generated at 2022-06-26 00:35:50.308741
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    var_0 = ReadInitialBalances.__call__(date_range_0)


# Generated at 2022-06-26 00:35:55.653252
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    build_general_ledger(date_range_0, iterable_0, dict_1)

# Generated at 2022-06-26 00:36:04.621462
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    func_0 = compile_general_ledger_program(dict_0, dict_0)
    var_1 = func_0(date_range_0)
    var_2 = func_0(date_range_0)
    var_3 = func_0(date_range_0)
    var_4 = func_0(date_range_0)
    var_5 = func

# Generated at 2022-06-26 00:36:12.545777
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    dict_2 = {var_0: var_0}
    
    try:
        var_1 = var_0.__call__()
    except:
        pass
    else:
        if var_1 != dict_2:
            raise AssertionError


# Generated at 2022-06-26 00:36:19.860028
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    posting_0 = None
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    ledger_0 = None
    ledger_0 = Ledger(dict_0, var_0)
    ledger_0.add(posting_0)


# Generated at 2022-06-26 00:36:26.037471
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_build_general_ledger_0()
    test_build_general_ledger_1()
    test_build_general_ledger_2()
    test_build_general_ledger_3()
    test_build_general_ledger_4()
    test_build_general_ledger_5()
    test_build_general_ledger_6()
    test_build_general_ledger_7()
    test_build_general_ledger_8()
    test_build_general_ledger_9()



# Generated at 2022-06-26 00:36:31.621292
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)


# Generated at 2022-06-26 00:36:36.519322
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_1 = 'c'
    str_0 = 'COA.Node'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    ReadInitialBalances.__call__(dict_0, date_range_0)


# Generated at 2022-06-26 00:36:39.996114
# Unit test for function build_general_ledger
def test_build_general_ledger():
    try:
        assert callable(build_general_ledger)
    except AssertionError as e:
        print(e)
        print('Function build_general_ledger does not exist!')
        sys.exit(1)

    print('Unit test for function build_general_ledger passed!')


# Generated at 2022-06-26 00:37:43.599574
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    str_2 = 'Node'
    str_3 = '3:c'
    dict_2 = {str_2: str_2, str_3: str_2, str_2: str_2}
    date_range_1 = DateRange(str_3, str_3)
    iterable_1 = None
    dict_3 = None
    var_1 = build_general_ledger

# Generated at 2022-06-26 00:37:49.338828
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = GeneralLedger(date_range_0, dict_1)
    var_1 = GeneralLedgerProgram(None, None)
    var_1.__call__(var_0)

# Generated at 2022-06-26 00:37:59.122133
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)

# Generated at 2022-06-26 00:38:09.462635
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    account_0 = Account(str_1)
    date_0 = datetime.date(int_0, int_0, int_0)
    date_1 = datetime.date(int_0, int_0, int_0)
    date_range_0 = DateRange(date_0, date_1)
    journa_entry_0 = None
    postin_0 = Posting(account_0, journa_entry_0, date_range_0, int_1)
    ledger_0 = Ledger(account_0, date_range_0, postin_0)
   

# Generated at 2022-06-26 00:38:15.544503
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    func_0 = compile_general_ledger_program(func_0, func_0)
    var_1 = func_0(date_range_0)


# Generated at 2022-06-26 00:38:21.889873
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)
    list_0 = [dict_1]
    list_1 = [dict_0]
    list_2 = []
    var_1 = Ledger(list_2, list_2)
    list_3 = [dict_0]
    list_4 = [dict_1]
    list_5 = []
    var_2 = Ledger(list_5, list_5)
   

# Generated at 2022-06-26 00:38:26.678549
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    var_0 = dict_0
    var_1 = var_0


# Generated at 2022-06-26 00:38:34.890848
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period_0 = DateRange(datetime.date(2002, 5, 16), datetime.date(1973, 4, 9))
    period_1 = DateRange(datetime.date(2024, 4, 21), datetime.date(2023, 10, 11))
    period_2 = DateRange(datetime.date(2028, 4, 11), datetime.date(2024, 9, 5))
    period_3 = DateRange(datetime.date(2030, 10, 12), datetime.date(2024, 7, 30))
    period_4 = DateRange(datetime.date(2028, 8, 9), datetime.date(2024, 2, 5))
    period_5 = DateRange(datetime.date(2023, 7, 3), datetime.date(2023, 11, 30))
    period_

# Generated at 2022-06-26 00:38:36.881672
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test method __call__ of class GeneralLedgerProgram.
    """
    # TODO: implement test.
    assert True is True



# Generated at 2022-06-26 00:38:41.976363
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'COA.Node'
    str_1 = '3:c'
    dict_0 = {str_0: str_0, str_1: str_0, str_0: str_0}
    date_range_0 = None
    iterable_0 = None
    dict_1 = None
    var_0 = build_general_ledger(date_range_0, iterable_0, dict_1)

## Unit test for method __call__ of class ReadJournalEntries