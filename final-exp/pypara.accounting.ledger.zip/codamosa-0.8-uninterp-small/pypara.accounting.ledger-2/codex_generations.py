

# Generated at 2022-06-26 00:31:02.845830
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-26 00:31:06.745077
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_1 = ReadInitialBalances()
    period_2 = DateRange('2000-01-01', '2000-01-01')
    assert isinstance(read_initial_balances_1.__call__(period_2), InitialBalances)



# Generated at 2022-06-26 00:31:11.334937
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    t = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    assert isinstance(t, GeneralLedgerProgram)
    assert isinstance(t(period_0), GeneralLedger)
    assert isinstance(t(period_0), GeneralLedger)


# Generated at 2022-06-26 00:31:11.899536
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-26 00:31:14.209616
# Unit test for function build_general_ledger
def test_build_general_ledger():
    print(build_general_ledger(DateRange(datetime.date(2000, 4, 1), datetime.date(2000, 6, 30)), [], {}))


# Generated at 2022-06-26 00:31:24.213822
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))
    journal = [
        JournalEntry(
            date=datetime.date(2020, 1, 1),
            description="Initial balances",
            postings=[Posting(direction=debit, account=Account(code="11001", subaccount=""), amount=Decimal(1000))],
        ),
        JournalEntry(
            date=datetime.date(2020, 2, 1),
            description="Credit 10.00",
            postings=[Posting(direction=credit, account=Account(code="11001", subaccount=""), amount=Decimal(10))],
        ),
    ]

# Generated at 2022-06-26 00:31:32.646050
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("cash")
    post = Posting(account, 1, datetime.date(2018, 1, 1))
    ledger = Ledger(account, Balance(datetime.date(2017, 12, 31), Quantity(5)))
    ledger.add(post)
    assert ledger.entries[0].amount == 1
    assert ledger.entries[0].balance == 6
    post2 = Posting(account, -1, datetime.date(2018, 1, 1))
    ledger.add(post2)
    assert ledger.entries[1].amount == -1
    assert ledger.entries[1].balance == 5
    

# Generated at 2022-06-26 00:31:33.228609
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-26 00:31:36.232965
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    raise NotImplementedError  # Implement this method.


## PROGRAM ENTRY POINT ##

if __name__ == "__main__":
    raise NotImplementedError  # Implement this program.


# EOF

# Generated at 2022-06-26 00:31:37.122799
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-26 00:31:44.726969
# Unit test for method add of class Ledger
def test_Ledger_add():
    led = Ledger('1', '2')
    led.add('3')
    assert led.entries[0].balance == '2', led.entries[0].balance

# Generated at 2022-06-26 00:31:45.678346
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_case_0()


# Generated at 2022-06-26 00:31:54.856484
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Set values
    period = DateRange(datetime.date(2014, 1, 1), datetime.date(2014, 1, 31))

# Generated at 2022-06-26 00:31:55.754781
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    test_case_0()


# Generated at 2022-06-26 00:32:01.020412
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    list_0 = [var_0, var_0, var_0, var_0]
    read_initial_balances_1 = ReadInitialBalances(*list_0)
    var_1 = None
    var_2 = read_initial_balances_1(var_1)


# Generated at 2022-06-26 00:32:02.360431
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Procedure to test method add of class Ledger
    pass


# Generated at 2022-06-26 00:32:11.561382
# Unit test for method add of class Ledger
def test_Ledger_add():
    list_0 = [None, ]
    list_1 = list(list_0)
    list_2 = [None, ]
    list_3 = list(list_2)
    list_4 = [None, ]
    list_5 = list(list_4)
    list_6 = [None, ]
    list_7 = list(list_6)
    list_8 = [None, ]
    list_9 = list(list_8)
    list_10 = [None, ]
    list_11 = list(list_10)
    list_12 = [None, ]
    list_13 = list(list_12)
    list_14 = [None, ]
    list_15 = list(list_14)
    list_16 = [None, ]
    list_17 = list(list_16)
   

# Generated at 2022-06-26 00:32:16.385049
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_2 = None
    var_2 = None
    var_3 = compile_general_ledger_program(read_initial_balances_2, var_2)
    var_4 = Decimal('0E+1')
    var_5 = GeneralLedger({var_4}, {})
    var_6 = var_3.__call__({var_4})
    assert var_6 == var_5


# Generated at 2022-06-26 00:32:27.448083
# Unit test for method add of class Ledger
def test_Ledger_add():
    input_0 = Amount
    var_0 = Account
    var_1 = Balance
    input_1 = Ledger(var_0, var_1)
    var_2 = Account
    var_3 = Amount
    var_4 = datetime.date
    var_5 = str
    var_6 = str
    input_2 = Posting(var_2, var_3, var_4, var_5, var_6, Direction.debit)
    input_3 = input_1.add(input_2)
    assert input_3.amount == input_2.amount
    assert input_3.ledger == input_1
    assert input_3.date == input_2.date
    assert input_3.posting == input_2


# Generated at 2022-06-26 00:32:28.632372
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ...


# Generated at 2022-06-26 00:32:42.585099
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'A~'
    str_1 = 'on~'
    date_0 = datetime.date(2017, 1, 1)
    date_1 = datetime.date(2017, 1, 2)
    date_2 = datetime.date(2017, 1, 3)
    var_0 = build_general_ledger(DateRange(date_0, date_1), [str_1], {str_0: str_0})


if __name__ == "__main__":
    test_case_0()
    test_GeneralLedgerProgram___call__()

# Generated at 2022-06-26 00:32:45.042755
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances()
    var_1 = DateRange()
    var_0(var_1)


# Generated at 2022-06-26 00:32:47.847303
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    alg_0 = compile_general_ledger_program(test_case_0, test_case_0)
    var_0 = alg_0(test_case_0)


# Generated at 2022-06-26 00:32:49.405946
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # TODO: Write unit test for method __call__ of class ReadInitialBalances
    ...


# Generated at 2022-06-26 00:32:50.088614
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-26 00:32:53.428795
# Unit test for function build_general_ledger
def test_build_general_ledger():
    _0: InitialBalances = {}
    _1: DateRange = DateRange(None, None)
    _2: Iterable[JournalEntry[_T]] = []
    build_general_ledger(_1, _2, _0)


# Generated at 2022-06-26 00:33:00.645416
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = 'A~'
    str_1 = 'B~'
    str_2 = 'C~'
    ledger_0 = Ledger(str_0, str_2)
    general_ledger_0 = GeneralLedger(str_1, str_0)
    var_0 = build_general_ledger(str_1, str_1, str_2)
    assert var_0 == general_ledger_0
    assert var_0 != str_2

    var_0 = build_general_ledger(str_1, str_1, str_1)
    assert var_0 == general_ledger_0
    assert var_0 != str_1

    var_0 = build_general_ledger(str_1, str_2, str_1)
    assert var_0 == general_ledger

# Generated at 2022-06-26 00:33:06.342153
# Unit test for function build_general_ledger
def test_build_general_ledger():
    build_general_ledger(str_0, str_0, str_0)


# Generated at 2022-06-26 00:33:07.403016
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()



# Generated at 2022-06-26 00:33:16.216665
# Unit test for method add of class Ledger
def test_Ledger_add():
    # General Ledger
    #str_0 = 'A~'
    #ledger_0 = Ledger(str_0, str_0)
    #var_0 = ledger_0.add(str_0)

    # General Ledger
    str_0 = 'B~'
    ledger_0 = Ledger(str_0, str_0)
    var_0 = ledger_0.add(str_0)

    # General Ledger
    str_0 = 'A~'
    ledger_0 = Ledger(str_0, str_0)
    var_0 = ledger_0.add(str_0)


# Generated at 2022-06-26 00:33:30.864885
# Unit test for function build_general_ledger

# Generated at 2022-06-26 00:33:33.520472
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'A~'
    ledger_0 = Ledger(str_0, str_0)
    var_0 = ledger_0.add(str_0)


# Generated at 2022-06-26 00:33:43.272376
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = Account('A')
    ledger_0 = Ledger(account_0, account_0)
    journal_entry_0 = JournalEntry(account_0, account_0, account_0)
    posting_0 = Posting(account_0, account_0, account_0)
    posting_1 = Posting(account_0, account_0, account_0)
    posting_2 = Posting(account_0, account_0, account_0)
    posting_3 = Posting(account_0, account_0, account_0)
    #TODO: ledger_0.add(journal_entry_0)
    #TODO: ledger_0.add(posting_0)
    #TODO: ledger_0.add(posting_1)
    #TODO: ledger_0.

# Generated at 2022-06-26 00:33:44.745575
# Unit test for function compile_general_ledger_program

# Generated at 2022-06-26 00:33:49.471607
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_4 = 'A~'
    str_5 = 'A~'
    dict_0 = dict()
    dict_0[str_5] = str_4
    var_1 = ReadInitialBalances.__call__(dict_0)
    var_1 = type(var_1)
    assert var_1 is dict

# Generated at 2022-06-26 00:33:52.237791
# Unit test for function build_general_ledger
def test_build_general_ledger():
    initial_balances = {}
    journal_entries = []
    period = None
    build_general_ledger(period,journal_entries,initial_balances)

# Generated at 2022-06-26 00:33:54.167073
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'A~'
    var_0 = GeneralLedger(str_0, str_0)


# Generated at 2022-06-26 00:33:58.303484
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Variable declarations
    var_0: GeneralLedgerProgram[Quantity]
    var_1: GeneralLedger[Quantity]

    # Test case declaration
    var_0 = compile_general_ledger_program(str_0, str_1)
    var_1 = var_0(str_0)

# Generated at 2022-06-26 00:33:59.196080
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_case_0()

# Generated at 2022-06-26 00:34:08.030813
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def _read_initial_balances(arg_0: DateRange) -> InitialBalances:
        """
        Reads initial balances.

        :param arg_0: Accounting period.
        :return: Initial balances.
        """
        return {}

    def _read_journal_entries(arg_0: DateRange) -> Iterable[JournalEntry[str]]:
        """
        Reads journal entries.

        :param arg_0: Accounting period.
        :return: Journal entries.
        """
        return ()

    str_0 = 'A~'
    var_0 = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    ledger_0 = Ledger(str_0, str_0)
    var_1 = ledger_0.add(str_0)
    var_

# Generated at 2022-06-26 00:34:19.757745
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from . import accounts
    from .journaling import JournalEntry, Posting
    from .types import AccountingPeriod, Date, DateRange, Quantity
    from dataclasses import dataclass
    from typing import Dict, TypeVar
    import datetime

# Generated at 2022-06-26 00:34:29.670277
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ledger_0 = Ledger('A', Balance(Decimal('0'), Decimal('0'), Decimal('0'), Decimal('0')))
    transaction_0 = JournalEntry('', '', Decimal('0'), Decimal('0'), Decimal('0'), Decimal('0'))
    transaction_0.postings.append(Posting('2019-07-01', 'A', Decimal('6'), Decimal('2')))
    transaction_0.postings.append(Posting('2019-07-01', 'B', Decimal('6'), Decimal('2')))
    transaction_0.postings.append(Posting('2019-07-01', 'C', Decimal('6'), Decimal('2')))

# Generated at 2022-06-26 00:34:38.366537
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class_1 = ReadInitialBalances
    var_0 = test_case_0()
    class_0 = GeneralLedgerProgram
    var_1 = class_0.__call__(class_1)
    var_2 = test_case_0()
    var_3 = var_1.__call__(var_2)
    var_4 = test_case_0()
    var_5 = var_3.__call__(var_4, var_2)
    var_6 = test_case_0()
    var_7 = var_5.__call__(var_6)
    var_6 = test_case_0()
    var_5 = var_5.__call__(var_6)
    var_6 = test_case_0()

# Generated at 2022-06-26 00:34:39.986070
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    arg_0 = GeneralLedgerProgram.__call__
    test_case_0()



# Generated at 2022-06-26 00:34:40.859301
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True == True



# Generated at 2022-06-26 00:34:45.352633
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Test if method __call__ of class ReadInitialBalances always return true.
    """
    class ReadInitialBalances_Protocol_Imp(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return InitialBalances('A~')

    ReadInitialBalances_Protocol_Imp.__call__('A~')

    return True


# Generated at 2022-06-26 00:34:47.647684
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert False, "Unit tests for method '__call__' not implemented."


# Generated at 2022-06-26 00:34:48.874321
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_case_0()

# Generated at 2022-06-26 00:34:49.771953
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    test_case_0()


# Generated at 2022-06-26 00:34:59.108879
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test for __call__
    """
    str_0 = 'test'
    is_instance_0 = isinstance(str_0, GeneralLedgerProgram)
    assert bool(is_instance_0)
    compiler = compile_general_ledger_program(test_case_0, test_case_0)
    compiled_program = compiler(test_case_0)
    is_instance_0 = isinstance(compiled_program, GeneralLedgerProgram)
    assert bool(is_instance_0)
    is_instance_0 = isinstance(test_case_0, GeneralLedgerProgram)
    assert bool(is_instance_0)
    is_instance_0 = isinstance(test_case_0, GeneralLedgerProgram)
    assert bool(is_instance_0)
    return_value_0 = compiled_

# Generated at 2022-06-26 00:35:05.354861
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

# Generated at 2022-06-26 00:35:09.095111
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'A~'
    period_0 = DateRange(str_0)
    var_0 = ReadInitialBalances.__call__(period_0)
    var_0 = str.__lt__(str_0, period_0)


# Generated at 2022-06-26 00:35:16.913642
# Unit test for method add of class Ledger
def test_Ledger_add():
    unit_test_Ledger_add = Ledger("a", "b").add("c")
    # test case 0
    str_0 = 'A~'
    ledger_0 = Ledger(str_0, str_0)
    var_0 = ledger_0.add(str_0)



# Generated at 2022-06-26 00:35:17.807789
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_case_0()

# Generated at 2022-06-26 00:35:24.540235
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    def read_initial_balances(period: DateRange) -> InitialBalances:
        pass
    
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    result = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    return result



# Generated at 2022-06-26 00:35:26.763550
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = build_general_ledger('y', 'l', 'u')


# Generated at 2022-06-26 00:35:38.839322
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .journaling import Transaction
    from .ledger import Ledger, build_general_ledger

    ## Create an account ledger:
    ledger = Ledger('A~', Balance(DateRange(since=datetime.date(2020,1,1), until=datetime.date(2020,1,1)), Quantity(0)))

    ## Add a transaction:
    ledger.add(Transaction(datetime.date(2020,1,1), '1st Journal Entry', [
        Posting(datetime.date(2020,1,1), Account('A~'), -100),
        Posting(datetime.date(2020,1,1), Account('B~'), 100),
    ]).postings[0])



# Generated at 2022-06-26 00:35:46.186142
# Unit test for method add of class Ledger
def test_Ledger_add():
    try:
        test_case_0()
    except Exception as e:
        if isinstance(e, NotImplementedError):
            print('Method add not implemented yet')
        else:
            print('Exception raised while testing method add of class Ledger')
            print(type(e).__name__ + ': ' + str(e))
    else:
        print('Method add of class Ledger tested successfully')

if __name__ == "__main__":
    test_Ledger_add()

# Generated at 2022-06-26 00:35:56.772390
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    str_0 = 'A~'
    str_1 = 'B~'
    str_2 = 'B~'
    str_3 = 'B~'
    str_4 = 'B~'
    str_5 = 'C~'
    str_6 = 'C~'
    str_7 = 'C~'
    str_8 = 'C~'
    str_9 = 'C~'
    str_10 = 'C~'
    str_11 = 'D~'
    str_12 = 'D~'
    str_13 = 'D~'
    str_14 = 'D~'
    str_15 = 'D~'
    str_16 = 'D~'
    str_17 = 'D~'
    str_18 = 'D~'
    str_19 = 'D~'

# Generated at 2022-06-26 00:35:57.661765
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-26 00:36:10.982993
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    str_0 = 'A~'
    ledger_0 = Ledger(str_0, str_0)
    var_0 = ledger_0.add(str_0)


# Generated at 2022-06-26 00:36:13.426688
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Consumes the opening and closing dates and produces a general ledger.

    :param period: Accounting period.
    :return: A general ledger.
    """
    pass

# Generated at 2022-06-26 00:36:22.574994
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    result = compile_general_ledger_program()
    from dataclasses import dataclass, field
    from typing import Optional, TypeVar
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import GeneralLedger, InitialBalances, ReadInitialBalances, build_general_ledger, compile_general_ledger_program
    @dataclass
    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    @dataclass
    class _ReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> List[JournalEntry[_T]]:
            pass
    read_initial_balances = _ReadInitialBalances()

# Generated at 2022-06-26 00:36:25.037463
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_case_0()

general_ledger = compile_general_ledger_program

if __name__ == '__main__':
    test_compile_general_ledger_program()

# Generated at 2022-06-26 00:36:26.262613
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test case 0:
    """
    test_case_0()

# Generated at 2022-06-26 00:36:31.222982
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    str_0 = 'A~'
    str_1 = 'A~'
    str_2 = 'A~'
    var_0 = build_general_ledger(str_0, str_0, str_0)
    var_1 = compile_general_ledger_program(str_0, str_0)
    var_2 = var_1(str_0)

# Generated at 2022-06-26 00:36:34.413037
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        GeneralLedgerProgram.__call__(str)
    except TypeError as e:
        assert str(e) == "'GeneralLedgerProgram' object is not callable"
    else:
        assert False



# Generated at 2022-06-26 00:36:41.730916
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = 'A~'
    ledger_0 = Ledger(str_0, str_0)
    var_0 = ledger_0.add(str_0)
    date_range_0 = DateRange(str_0, str_0)
    journal_0 = [str_0]
    initial_0 = {}
    output_0 = build_general_ledger(date_range_0, journal_0, initial_0)
    assert isinstance(output_0, GeneralLedger)
    assert isinstance(output_0.period, DateRange)
    assert isinstance(output_0.ledgers, dict)


# Generated at 2022-06-26 00:36:42.523848
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-26 00:36:45.428348
# Unit test for method add of class Ledger
def test_Ledger_add():
    print("test_Ledger_add")
    ledger = Ledger("A", "B")
    entry = ledger.add("C")
    assert entry
    assert isinstance(entry, LedgerEntry)
    assert entry.posting == "C"
    assert entry.ledger == ledger
    assert entry.balance == Quantity(Decimal(0))


# Generated at 2022-06-26 00:37:10.312410
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import dataclass, field
    from decimal import Decimal
    from typing import Any, Dict, Field, TypeVar, Union
    t_0 = TypeVar('t_0')
    t_1 = TypeVar('t_1')
    t_2 = TypeVar('t_2')
    t_3 = TypeVar('t_3', bound='ReadInitialBalances___call__.Compatible')
    t_4 = TypeVar('t_4', bound='ReadInitialBalances___call__.Dummy')
    class ReadInitialBalances___call__(Protocol[t_3]):
        def __call__(self, period: 'ReadInitialBalances___call__.Dummy', *, optional0: 'ReadInitialBalances___call__.Compatible') -> 'ReadInitialBalances___call__.Compatible': ...


# Generated at 2022-06-26 00:37:22.169660
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    execute_compile_general_ledger_program = \
        compile_general_ledger_program(
            read_initial_balances=lambda period: \
                dict({'a': Balance(period.since,
                                   Quantity(Decimal(1.1)))}),
            read_journal_entries=lambda period:
                [JournalEntry(date=period.since,
                              description='test',
                              postings=[Posting(direction=Direction.DEBIT,
                                                account='a',
                                                amount=Amount(Decimal(1.1)))])])

    date_minimum = datetime.date(2019, 9, 1)
    date_maximum = datetime.date(2019, 9, 30)

# Generated at 2022-06-26 00:37:22.950079
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-26 00:37:31.581659
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import ReadJournalEntries
    from .accounts import ReadInitialBalances
    period = DateRange(date_from=datetime.date(1900, 1, 1), date_to=datetime.date(1900, 12, 31))
    read_journal_entries = ReadJournalEntries(JournalEntry)
    read_initial_balances = ReadInitialBalances(InitialBalances)
    gl_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    general_ledger = gl_program(period)
    assert general_ledger.period == DateRange(date_from=datetime.date(1900, 1, 1), date_to=datetime.date(1900, 12, 31))
    assert general_ledger.ledgers == {}

# Generated at 2022-06-26 00:37:33.769998
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'A'
    ledger_0 = Ledger(str_0, str_0)
    var_0 = ledger_0.add(str_0)


# Generated at 2022-06-26 00:37:47.748540
# Unit test for function build_general_ledger
def test_build_general_ledger():
    dt_0 = datetime.datetime.today()
    dt_1 = datetime.datetime.today()
    dt_2 = datetime.datetime.today()
    dt_3 = datetime.datetime.today()
    period_0 = DateRange(dt_0, dt_1)
    journal_0 = [str_0]
    initial_0 = {str_0 : str_1}
    result_0 = build_general_ledger(period_0, journal_0, initial_0)
    assert (result_0) == 0, "build_general_ledger returned %s, expected %s" % (result_0, 0)
    result_0 = build_general_ledger(period_0, journal_0, initial_0)

# Generated at 2022-06-26 00:37:48.749316
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True


# Generated at 2022-06-26 00:38:02.433698
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from hypothesis import given, assume
    from hypothesis.strategies import integers
    from datetime import date
    from decimal import Decimal
    from ..commons import numbers
    def __assertion_axiom_0(f_1: date, b_1: int):
        f_2 = date.today()
        f_3 = date.today()
        as_1 = f_1
        bs_1 = b_1
        as_2 = f_2
        bs_2 = f_3
        assume(as_1 <= as_2)
        assume(bs_1 <= bs_1)
        assume(as_2 <= bs_2)
        assume(bs_1 <= bs_2)
        assume(as_2 >= as_1)
        assume(bs_2 >= bs_1)
       

# Generated at 2022-06-26 00:38:07.261414
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    date_range_0 = DateRange(datetime.date(2009, 1, 1),datetime.date(2010, 2, 3))
    general_ledger_0 = compile_general_ledger_program(date_range_0,date_range_0,date_range_0)
    assert type(general_ledger_0) == GeneralLedgerProgram


# Generated at 2022-06-26 00:38:10.198631
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Call function
    assert compile_general_ledger_program(
        read_initial_balances = None,
        read_journal_entries = None,
    )


# Generated at 2022-06-26 00:38:34.320039
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_1 = ReadInitialBalances()
    var_2 = DateRange()
    var_3 = var_1(var_2)


# Generated at 2022-06-26 00:38:35.455741
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    GeneralLedgerProgram.__call__
    # Test method(s)



# Generated at 2022-06-26 00:38:37.561969
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = "1"
    ledger_0 = Ledger(str_0, str_0)
    ledger_0.add(str_0)



# Generated at 2022-06-26 00:38:38.367851
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-26 00:38:40.017850
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    test_case_0()


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 00:38:41.030465
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False # Add your test here


# Generated at 2022-06-26 00:38:42.086882
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = GeneralLedgerProgram.__call__()


# Generated at 2022-06-26 00:38:51.195900
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## This function tests the build_general_ledger function by feeding it
    ## suitably prepared inputs and checking the output.

    # Test with no arguments
    try:
        build_general_ledger()
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"

    # Test initial balances
    ib = {'a': Balance(1, 2), 'b': Balance(3, 4), 'c': Balance(5, 6)}

    # Test with no entries
    general_ledger = build_general_ledger(DateRange(0, 0), ib)

    assert general_ledger.period == DateRange(0, 0)
    for account, balance in ib.items():
        ledger = general_ledger.ledgers[account]
        assert ledger.balance == balance

    # Test with two entries
   

# Generated at 2022-06-26 00:38:52.234321
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert compile_general_ledger_program(test_case_0)


# Generated at 2022-06-26 00:38:58.808987
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Setup
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 30))
    journal = [1, 2, 3]
    initial = {"A": {"balance": 1, "date": datetime.date(2020, 1, 1)}}

    # Exercise
    actual = build_general_ledger(period, journal, initial)

    # Verify

# Generated at 2022-06-26 00:39:32.944852
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger_0 = Ledger()
    ledger_0.add(str())



# Generated at 2022-06-26 00:39:33.849399
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # TODO: Implement it

    pass


# Generated at 2022-06-26 00:39:35.428874
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    # Execute tested method
    var_0 = ReadInitialBalances()

    # Assertion to verify that expected result is correct
    assert var_0 == None


# Generated at 2022-06-26 00:39:37.885669
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'A~'
    ledger_0 = Ledger(str_0, str_0)
    var_0 = ledger_0.add(str_0)
    # var_0: LedgerEntry[str] = A~


# Generated at 2022-06-26 00:39:40.240895
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period = 'period'
    journal = 'journal'
    initial = 'initial'
    var_0 = build_general_ledger(period, journal, initial)
    assert isinstance(var_0, GeneralLedger)


# Generated at 2022-06-26 00:39:40.680803
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True

# Generated at 2022-06-26 00:39:43.715876
# Unit test for method add of class Ledger
def test_Ledger_add():
    str_0 = 'A~'
    ledger_0 = Ledger(str_0, str_0)
    var_1 = ledger_0.add(str_0)
    assert (var_1 == var_1)

# Generated at 2022-06-26 00:39:44.466957
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-26 00:39:45.243413
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

# Generated at 2022-06-26 00:39:52.768638
# Unit test for function build_general_ledger
def test_build_general_ledger():
    str_0 = '192.168.15.10'
    date_0 = datetime.date(1, 1, 1)
    date_1 = datetime.date(1, 1, 1)
    list_0 = [str_0]
    tuple_0 = (str_0, list_0)
    tuple_1 = (str_0, list_0)
    tuple_2 = (str_0, list_0)
    list_1 = [tuple_0, tuple_1, tuple_2]
    ledger_0 = Ledger(str_0, str_0)
    var_0 = build_general_ledger(str_0, list_1, str_0)
    var_1 = build_general_ledger(list_1, list_0, date_0)
    var_2 = build_