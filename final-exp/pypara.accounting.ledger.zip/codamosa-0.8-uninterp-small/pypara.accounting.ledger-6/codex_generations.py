

# Generated at 2022-06-26 00:31:03.641314
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_journal_entries_0 = ReadJournalEntries()
    read_initial_balances_0 = ReadInitialBalances()
    period_0 = DateRange()
    general_ledger_program_0 = compile_general_ledger_program(
        read_initial_balances_0,
        read_journal_entries_0,
    )
    general_ledger_0 = general_ledger_program_0(period_0)

# Generated at 2022-06-26 00:31:05.947789
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances = ReadInitialBalances()
    period = None
    read_initial_balances.__call__(period)


# Generated at 2022-06-26 00:31:14.614522
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import JournalEntry
    from .accounts import Account

    this = Ledger(Account('test'), Balance(datetime.date(2020, 1, 1), Quantity(0)))

    for _ in range(100):
        this.add(JournalEntry(datetime.date(2020, 1, 1), 'test', [Posting(Account('test0'), 'debit', Quantity(10))]).postings[0])

    # Test entry count
    if len(this.entries) != 100:
        raise Exception('Ledger.add failed test 1')

    # Test balance
    if this.entries[-1].balance != Quantity(1000):
        raise Exception('Ledger.add failed test 2')
        

# Generated at 2022-06-26 00:31:20.973634
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()
    program_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    period_0 = DateRange()
    general_ledger_0 = program_0(period_0)
    test_obj = GeneralLedgerProgram()
    test_obj(period_0)

# Generated at 2022-06-26 00:31:27.291065
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    print("test_GeneralLedgerProgram___call__")
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()
    general_ledger_program_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    period_0 = DateRange(DateRange.DATE_ZERO, DateRange.DATE_MAX)
    general_ledger_0 = general_ledger_program_0(period_0)
    print(general_ledger_0)


# Generated at 2022-06-26 00:31:35.842780
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # arrange
    period: DateRange = DateRange.of("2020-01-01", "2020-12-31")
    read_initial_balances_0: ReadInitialBalances = ReadInitialBalances()
    read_journal_entries_0: ReadJournalEntries[_T] = ReadJournalEntries()
    target: GeneralLedgerProgram[_T] = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    expected_value: GeneralLedger[_T] = GeneralLedger(period, {})
    # act
    actual_value: GeneralLedger[_T] = target(period)
    # assert
    assert actual_value == expected_value

# Generated at 2022-06-26 00:31:45.764903
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import AccountId
    from .generic import Balance
    from .journaling import Posting
    from .money import Money
    from ..commons.zeitgeist import DateRange, date

    # Define the date range:
    period = DateRange(date(2018, 1, 1), date(2018, 1, 2))

    # Define initial balances:
    initial_balances = {
        AccountId("0001", "Foo Account"): Balance(period.since, Money(1000, "USD")),
        AccountId("0002", "Bar Account"): Balance(period.since, Money(2000, "USD")),
    }

    # Define journal entries:

# Generated at 2022-06-26 00:31:54.931486
# Unit test for method add of class Ledger
def test_Ledger_add():
    print("testing method add of class Ledger")

    # Case where debit is added to an empty ledger
    account_0 = Account()
    balance_0 = Balance(datetime.date(2, 2, 2), Quantity(Decimal(0)))
    ledger_0 = Ledger(account_0, balance_0)
    journal_0 = JournalEntry(datetime.date(1, 1, 1), "", "")
    posting_0 = Posting(account_0, journal_0, Quantity(Decimal(42)), 1)
    entry_0 = ledger_0.add(posting_0)

    assert ledger_0.account == account_0
    assert ledger_0.initial == balance_0
    assert len(ledger_0.entries) == 1
    assert ledger_0.entries[0] == entry_0


# Generated at 2022-06-26 00:32:05.264025
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create an account for testing
    account = Account(
        "Testing",
        "Testing",
        currency="KES",
        is_terminal=True,
        is_liquid=True,
        is_balance_sheet_account=True,
    )

    # Create a balance for testing
    initial = Balance(datetime.date(2019, 12, 1), Quantity(Decimal(150)))
    # Create a ledger for testing
    ledger = Ledger(account, initial)

    # Create a journal entry for testing
    journal_entry = JournalEntry(
        date=datetime.date(2019, 12, 31),
        description="Testing",
        currency="KES",
        postings=[
            Posting(account, Amount(Decimal(150)), 0),
        ]
    )

    # Test LedgerEntry.date property
    assert ledger

# Generated at 2022-06-26 00:32:12.319015
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account('10'), Balance(datetime.date(2019, 1, 1), Decimal(1000)))
    posting = Posting(JournalEntry(datetime.date(2019, 1, 1),
                                   "This is transaction 1",
                                   [
                                       Posting(Account('10'), Decimal(100), 1),
                                       Posting(Account('20'), Decimal(100), -1)
                                   ]
                                   ))
    entry = ledger.add(posting)
    assert entry.balance == Decimal(1100)
    assert ledger.entries[0].balance == Decimal(1100)


# Generated at 2022-06-26 00:32:24.842446
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-26 00:32:25.654053
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:32:26.884198
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()

# Generated at 2022-06-26 00:32:38.171940
# Unit test for method add of class Ledger
def test_Ledger_add():
    journal_0 = JournalEntry.build(date=datetime.date.today(), description="Description 1", postings=[])
    journal_1 = JournalEntry.build(date=datetime.date.today(), description="Description 2", postings=[])
    account_0 = Account(code=1, name="Account 0", descr="Account 0 Description",
                        acct_type=AccountType.Customer, is_header=False, has_children=False)
    account_1 = Account(code=2, name="Account 1", descr="Account 1 Description", acct_type=AccountType.Supplier,
                        is_header=True, has_children=True)
    balance_0 = Balance(date=datetime.date.today(), value=Quantity(1))
    ledger_0 = Ledger(account=account_0, initial=balance_0)

    posting

# Generated at 2022-06-26 00:32:42.465098
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances = ReadInitialBalances()
    read_journal_entries = ReadJournalEntries()

    glp = compile_general_ledger_program(read_initial_balances,read_journal_entries)
    gl = glp(period)
    return True

# Generated at 2022-06-26 00:32:48.530224
# Unit test for method add of class Ledger
def test_Ledger_add():
    initialBal = Balance(datetime.date(2016, 1, 1), Decimal(25))
    acc = Account()
    led = Ledger(acc, initialBal)
    date = datetime.date(2016, 1, 5)
    j = JournalEntry(date, "description", [Posting(Decimal(100), acc, "debit"), Posting(Decimal(100), acc, "credit")])
    assert led.add(j.postings[0]) == led.entries[0]

# Generated at 2022-06-26 00:32:49.123722
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True



# Generated at 2022-06-26 00:32:58.026104
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def test_case_1():
        """
        Consumes opening and closing dates and produces a general ledger.

        :param period: Accounting period.
        :return: A general ledger.
        """
        period = DateRange(datetime.date(2018, 1, 31), datetime.date(2018, 2, 28))
        initial_balances = read_initial_balances(period)
        journal_entries = read_journal_entries(period)
        return build_general_ledger(period, journal_entries, initial_balances)
    read_initial_balances_1 = ReadInitialBalances()
    read_journal_entries_1 = ReadJournalEntries()
    compile_general_ledger_program(read_initial_balances_1, read_journal_entries_1)

# Generated at 2022-06-26 00:33:12.797502
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import AssetAccount, EquityAccount, LiabilityAccount
    from .journals import Journal, Posting, JournalEntry

    adelina = AssetAccount("1000", "bank", "adelina", "current")
    miki = LiabilityAccount("2000", "bank", "miki", "current")
    dorot = EquityAccount("3000", "bank", "dorot", "capital")
    initial_balances = {adelina: Balance(datetime.date(2020, 1, 1), Amount(25)),
                        miki: Balance(datetime.date(2020, 1, 1), Amount(0)),
                        dorot: Balance(datetime.date(2020, 1, 1), Amount(0))}
   

# Generated at 2022-06-26 00:33:18.560187
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_ledger = Ledger('test_account', 2)
    test_posting = Posting('test_journal1', 'test_account', 1, 'debit')
    test_entry = test_ledger.add(test_posting)
    assert test_entry == LedgerEntry(test_ledger, test_posting, 3)

# Generated at 2022-06-26 00:33:41.350157
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    test_case_0()

# Generated at 2022-06-26 00:33:48.725576
# Unit test for method add of class Ledger
def test_Ledger_add():
    journal_entry_0 = None
    posting_0 = None
    account_0 = None
    amount_0 = None
    amount_1 = None
    balance_0 = None
    date_0 = None
    date_1 = None
    date_range_0 = module_0.DateRange(date_0, date_1)
    ledger_0 = Ledger(account_0, balance_0)
    assert ledger_0.entries == []
    ledger_0.add(posting_0)
    assert ledger_0.entries[0].posting == posting_0


# Generated at 2022-06-26 00:33:54.542809
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    account_0 = None
    balance_0 = None
    dict_0 = {account_0: balance_0, account_0: balance_0, account_0: balance_0, account_0: balance_0}
    var_0 = build_general_ledger(date_range_0, date_0, dict_0)


# Generated at 2022-06-26 00:33:55.712877
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Test arguments:
    pass



# Generated at 2022-06-26 00:33:56.347066
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:33:57.282528
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-26 00:34:06.451635
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from dataclasses import dataclass, field
    from decimal import Decimal
    from typing import List, Generic, TypeVar, Dict
    import datetime
    
    _T = TypeVar("_T")
    
    @dataclass
    class GeneralLedger(Generic[_T]):
        period: 'module_0.DateRange'
        ledgers: 'Dict[module_1.Account, module_2.Ledger[_T]]'
    
    @dataclass
    class LedgerEntry(Generic[_T]):
        ledger: 'module_2.Ledger[_T]'
        posting: 'module_1.Posting[_T]'
        balance: 'module_3.Quantity'
    

# Generated at 2022-06-26 00:34:10.856978
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    account_0 = None
    balance_0 = None
    dict_0 = {account_0: balance_0, account_0: balance_0, account_0: balance_0, account_0: balance_0}
    var_0 = build_general_ledger(date_range_0, date_0, dict_0)

# Generated at 2022-06-26 00:34:14.080887
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .commons.algebras import ReadInitialBalancesAlgebra, ReadJournalEntriesAlgebra
    algebra = ReadInitialBalancesAlgebra()
    algebra_0 = ReadJournalEntriesAlgebra()
    var_0 = compile_general_ledger_program(algebra, algebra_0)

# Generated at 2022-06-26 00:34:19.873762
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    account_0 = None
    balance_0 = None
    dict_0 = {account_0: balance_0, account_0: balance_0, account_0: balance_0, account_0: balance_0}
    var_1 = build_general_ledger(date_range_0, date_0, dict_0)


# Generated at 2022-06-26 00:34:30.877534
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Test function definition.
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    account_0 = None
    balance_0 = None
    dict_0 = {account_0: balance_0, account_0: balance_0, account_0: balance_0, account_0: balance_0}
    test_case_0()

# Generated at 2022-06-26 00:34:36.500759
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    @dataclass
    class ReadJournalEntriesImpl(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    fn = compile_general_ledger_program(ReadInitialBalancesImpl, ReadJournalEntriesImpl)


# Generated at 2022-06-26 00:34:42.285406
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    balance_0 = None
    dict_0 = {date_range_0: balance_0, date_range_0: balance_0, date_range_0: balance_0, date_range_0: balance_0}
    var_2 = compile_general_ledger_program(dict_0, dict_0)
    var_1 = var_2(date_range_0)

# Generated at 2022-06-26 00:34:48.780717
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    account_0 = None
    balance_0 = None
    dict_0 = {account_0: balance_0, account_0: balance_0, account_0: balance_0, account_0: balance_0}
    var_0 = compile_general_ledger_program(date_0, dict_0)
    var_0(date_range_0)

# Generated at 2022-06-26 00:34:52.580365
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    account_0, balance_0 = None, None
    dict_0 = {account_0: balance_0}
    var_1 = dict_0
    var_1 = dict_0
    var_1 = dict_0
    var_1 = dict_0
    assert var_1 is dict_0


# Generated at 2022-06-26 00:34:54.359435
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    assert_equal(GeneralLedgerProgram(date_0).__call__(), None,
        message="Expected 'None'")

# Generated at 2022-06-26 00:35:05.982784
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    account_0 = None
    balance_0 = None
    balance_1 = None
    balance_2 = None
    balance_3 = None
    balance_4 = None
    balance_5 = None
    balance_6 = None
    balance_7 = None
    date_0 = None
    date_1 = None
    date_10 = None
    date_11 = None
    date_12 = None
    date_13 = None
    date_14 = None
    date_15 = None
    date_16 = None
    date_17 = None
    date_2 = None
    date_3 = None
    date_4 = None
    date_5 = None
    date_6 = None
    date_7 = None
    date_8 = None
    date_9 = None
    date_range_0 = module_0

# Generated at 2022-06-26 00:35:19.478272
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    account_0 = None
    balance_0 = None
    dict_0 = {account_0: balance_0, account_0: balance_0, account_0: balance_0, account_0: balance_0}
    var_0 = read_initial_balances(date_range_0)
    var_1 = build_general_ledger(date_range_0, date_0, dict_0)
    var_2 = compile_general_ledger_program(var_0, date_0)
    var_2(date_range_0)
    try:
        var_2(date_range_0)
    except TypeError:
        pass


# Generated at 2022-06-26 00:35:24.395455
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = None
    posting_0 = None
    ledger_0 = Ledger(account_0, None)
    ledger_1 = ledger_0
    ledger_0.add(posting_0)
    assert ledger_1 == ledger_0


# Generated at 2022-06-26 00:35:29.204428
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = module_0.DateRange(date_0, date_0)
    param_0 = None
    param_1 = None
    func_0 = compile_general_ledger_program(param_0, param_1)
    var_0 = func_0(date_range_0)

# Generated at 2022-06-26 00:35:37.785066
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert compile_general_ledger_program(test_case_0,test_case_0)


# Generated at 2022-06-26 00:35:47.064320
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Ledger(Account, Balance)
    var_1 = JournalEntry(datetime.date(2004, 1, 1), "", [Posting(Account, datetime.date(2004, 1, 1), Account, Amount)])
    var_2 = var_0.add(var_1.postings[0])
    assert var_2.posting == var_1.postings[0] and (var_2.posting.amount * var_2.posting.direction.value).quantize() == Quantity.zero() and var_2.balance == Quantity.zero()

if __name__ == "__main__":
    test_case_0()
    test_Ledger_add()

# Generated at 2022-06-26 00:35:49.556929
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Test for the method __call__ of class ReadInitialBalances
    ReadInitialBalances.__call__.__annotations__


# Generated at 2022-06-26 00:35:53.106526
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    ledger_0 = Ledger(var_0, var_0)
    try:
        ledger_0.add(var_0)
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-26 00:35:55.728794
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    try:
        var_10 = ReadInitialBalances()
    except:
        pass
    else:
        var_9 = var_10(var_0)
    assert var_0 != var_9


# Generated at 2022-06-26 00:36:02.364292
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_2 = Amount(Decimal(0))
    var_3 = Balance(None, Quantity(Decimal(0)))
    var_4 = InitialBalances()
    var_5 = ReadInitialBalances()
    var_6 = ReadJournalEntries(var_2)
    var_7 = GeneralLedgerProgram(var_5, var_6)
    var_8 = DateRange(var_5, var_6)
    var_9 = GeneralLedgerProgram(var_5, var_6)
    var_9.__call__(var_8)


# Generated at 2022-06-26 00:36:11.297018
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from dataclasses import dataclass
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    @dataclass
    class _DerivedJournalEntry(JournalEntry):
        @property
        def description(self) -> str:
            return "no description"
        def __iter__(self) -> Iterable[Posting]:
            yield from []
    @dataclass
    class _DerivedPosting(Posting):
        @property
        def amount(self) -> Amount:
            return Amount.ZERO
        @property
        def description(self) -> str:
            return "no description"

# Generated at 2022-06-26 00:36:11.836630
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True

# Generated at 2022-06-26 00:36:14.266321
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    ledger_0 = Ledger(var_0, var_0)
    var_1 = ledger_0.add(var_0)

# Generated at 2022-06-26 00:36:18.964110
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    GeneralLedgerProgram___call___0 = compile_general_ledger_program(read_initial_balances=None,
                                                                     read_journal_entries=None)
    GeneralLedgerProgram___call___1 = GeneralLedgerProgram___call___0(period=None)
    var_2 = GeneralLedgerProgram___call___1
    test_case_0()

# Generated at 2022-06-26 00:36:34.417491
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = DateRange()
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = build_general_ledger(var_0, var_1, var_2)
    assert isinstance(var_4, GeneralLedger)


# Generated at 2022-06-26 00:36:42.873366
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # instance initialization
    read_initial_balances_0 = ReadInitialBalances()
    read_journal_entries_0 = ReadJournalEntries()
    var_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    period_0 = DateRange(var_0, var_0)
    # returns: GeneralLedger
    try:
        var_1 = var_0.__call__(period_0)
    except Exception as var_2:
        var_3 = None

    # prints: GeneralLedger
    print(var_1)

## Execute this file to run the tests it contains.
if __name__ == "__main__":
    from .testing import execute

    execute(globals())

# Generated at 2022-06-26 00:36:51.179875
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from dataclasses import dataclass
    from typing import Dict, List, Optional, Protocol, TypeVar

    import datetime

    from decimal import Decimal

    _T = TypeVar("_T")


    #: Defines a generic type variable.
    _T = TypeVar("_T")


    #: Initial balances:
    InitialBalances = Dict[Account, Balance]


    @dataclass
    class LedgerEntry(Generic[_T]):
        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"
        #: Posting of the ledger entry.
        posting: Posting[_T]
        #: Balance of the ledger entry.
        balance: Quantity
        @property
        def date(self) -> datetime.date:
            pass



# Generated at 2022-06-26 00:36:53.338383
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert build_general_ledger(None, None, None) is None


# Generated at 2022-06-26 00:36:54.754945
# Unit test for method add of class Ledger
def test_Ledger_add():
    var = None
    ledger = Ledger(var, var)
    entry = ledger.add(var)

# Generated at 2022-06-26 00:36:56.216684
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_1 = ReadInitialBalances()
    var_2 = DateRange()


# Generated at 2022-06-26 00:36:58.708807
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    DateRange_0 = DateRange(Decimal('1'), Decimal('2'))
    InitialBalances_0 = ReadInitialBalances.__call__(DateRange_0)


# Generated at 2022-06-26 00:37:00.823546
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    ledger_0 = Ledger(var_0, var_0)
    var_1 = ledger_0.add(var_0)


# Generated at 2022-06-26 00:37:09.132617
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .alyx import AccountTransaction, Transaction, TransactionPosting
    from .commons.numbers import Amount
    from .journaling import JournalEntryType, PostingDirection
    from .money import Currency

    # Preparations:
    ledger_account_1 = Account("1234")
    ledger_account_2 = Account("1235")
    initial_balances = {
        ledger_account_1: Balance(datetime.date(2020, 1, 1), Amount(Currency.USD, Decimal(10))),
        ledger_account_2: Balance(datetime.date(2020, 1, 1), Amount(Currency.USD, Decimal(20))),
    }

# Generated at 2022-06-26 00:37:11.058564
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_523 = None
    var_523 = Ledger(var_523, var_523)
    var_524 = None
    var_525 = var_523.add(var_524)

# Generated at 2022-06-26 00:37:45.002151
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = read_initial_balances(var_0)
    var_1 = read_journal_entries(var_0)
    var_2 = compile_general_ledger_program(var_0, var_1)
    var_3 = var_2.__call__(var_0)

# Generated at 2022-06-26 00:37:49.702576
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Create a GeneralLedgerProgram instance
    var_0 = compile_general_ledger_program(0, 0)
    # Assert that var_0 is callable
    assert isinstance(var_0, GeneralLedgerProgram)
    # Create a GeneralLedger instance
    var_1 = var_0(0)
    assert isinstance(var_1, GeneralLedger)
    test_case_0()

# Generated at 2022-06-26 00:37:56.900630
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = var_1(var_0)

# Generated at 2022-06-26 00:37:59.579921
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(test_case_0, test_case_0)
    var_1 = var_0(test_case_0)


# Generated at 2022-06-26 00:38:00.725216
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = None


# Generated at 2022-06-26 00:38:02.958661
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances.__call__(var_0, var_0)


# Generated at 2022-06-26 00:38:09.174123
# Unit test for method add of class Ledger
def test_Ledger_add():
    first_arg = ledger_0 = Ledger(var_0, var_0)
    second_arg = var_0
    actual_return_value = ledger_0.add(var_0)
    actual_result = actual_return_value == var_1
    message = "Expected: " + str(var_1) + ", Actual: " + str(actual_return_value)
    assert actual_result, message



# Generated at 2022-06-26 00:38:10.947917
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    var_0 = compile_general_ledger_program(None,None)
    var_1 = var_0(None)


# Generated at 2022-06-26 00:38:11.834085
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()

# Generated at 2022-06-26 00:38:16.474970
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Define objects:
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None

    ## Define program:
    def program():
        var_0 = DateRange(var_0, var_1)
        var_2 = build_general_ledger(var_0, var_3, var_4)
        return var_2

    ## Run test:
    program()


# Generated at 2022-06-26 00:39:12.305167
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances.__call__(None, None)
    assert var_0 == None


# Generated at 2022-06-26 00:39:17.709391
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-26 00:39:18.757011
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    period = None
    read_initial_balances = None
    read_initial_balances(period)


# Generated at 2022-06-26 00:39:20.188651
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    ledger_0 = Ledger(var_0, var_0)
    var_1 = ledger_0.add(var_0)


# Generated at 2022-06-26 00:39:21.551625
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    compile_general_ledger_program(
        lambda period: {},
        lambda period: [],
    )

# Generated at 2022-06-26 00:39:23.278977
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ### BEGIN TESTS
    var_0 = None
    var_1 = None
    build_general_ledger(var_0, var_1, var_1)
    ### END TESTS



# Generated at 2022-06-26 00:39:29.659184
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from decimal import Decimal
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Direction
    from .accounts import TermAccount, AssetAccount, ExpenseAccount, IncomeAccount, Symbol, AccountType
    from typing import Dict, List
    var_0 = date(2020, 8, 15)
    var_1 = date(2020, 8, 16)
    var_2 = date(2020, 8, 17)
    var_3 = date(2020, 8, 18)
    var_4 = date(2020, 8, 19)
    var_5 = date(2020, 8, 20)
    var_6 = date(2020, 8, 21)
    var_7 = Decimal('20000.00')
    var_8 = Decimal('-5000.00')
    var

# Generated at 2022-06-26 00:39:31.154949
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances.__call__(var_0, var_0)


# Generated at 2022-06-26 00:39:31.823574
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True


# Generated at 2022-06-26 00:39:32.559541
# Unit test for method add of class Ledger
def test_Ledger_add():
    assert test_case_0() == None

# Generated at 2022-06-26 00:40:43.935763
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = GeneralLedgerProgram(var_0, var_0)
    var_2 = compile_general_ledger_program(var_0, var_0)
    var_3 = var_1(var_0)
    var_4 = var_2(var_0)
    assert var_3 == var_4


# Generated at 2022-06-26 00:40:47.726379
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Local variable declarations
    var_0 = ReadInitialBalances()
    var_1 = DateRange(var_0, var_0)

    # Call method __call__ of class ReadInitialBalances
    var_2 = var_0.__call__(var_1)


# Generated at 2022-06-26 00:40:51.243595
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return None

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return None

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    def accounting_period() -> DateRange:
        return None

    general_ledger = program(accounting_period())