

# Generated at 2022-06-26 00:31:08.798856
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("00001", "Account1")
    initial_balance = Balance(datetime.date.today(), Quantity(Decimal("0.0")))
    post = Posting(datetime.date.today(), "description", Account("00002", "Account2"), Quantity(Decimal("10.0")))
    ledger = Ledger(account, initial_balance)
    ledger.add(post)
    assert ledger.entries[0].balance == Quantity(Decimal("10.0"))


# Generated at 2022-06-26 00:31:18.673531
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Test case data
    """
    period = DateRange(datetime.date(2015, 1, 1), datetime.date(2015, 3, 31))

    journal_entry_0 = JournalEntry(
        date=datetime.date(2015, 1, 1),
        description="Payroll",
        postings=[
            Posting(account=Account.of('Cash'), amount=Decimal(2300), direction=PostingDirection.CREDIT),
            Posting(account=Account.of('Payroll'), amount=Decimal(2300), direction=PostingDirection.DEBIT),
        ],
    )


# Generated at 2022-06-26 00:31:23.032522
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from moneyonchain.manager import ConnectionManager
    import logging
    import logging.config

    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S')
    logging.getLogger('asyncio').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    # logging.getLogger('websockets').setLevel(logging.WARNING)
    logging.getLogger('aiohttp').setLevel(logging.WARNING)

    logging.config.fileConfig('logging.conf')
    logger = logging.getLogger('simpleLogger')

   

# Generated at 2022-06-26 00:31:23.637125
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-26 00:31:28.717504
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = Account("code_0", "name_0")
    initial_0 = Balance(datetime.date.today(), Quantity(Decimal(100)))
    ledger_0 = Ledger(account_0, initial_0)
    account_1 = Account("code_1", "name_1")
    posting_0 = Posting(account_1, datetime.date.today(), Direction.DEBIT, Quantity(Decimal(100)))
    ledger_entry_0 = ledger_0.add(posting_0)
    assert ledger_entry_0.balance == Quantity(Decimal(200))

# Generated at 2022-06-26 00:31:38.187454
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import date, date_range
    from .accounts import IncomeStatement, Liabilities
    from .journaling import PostingDirection, journal_entry
    from ..commons.numbers import Amount, Quantity

    def mk_initial(account: Account) -> Balance:
        return Balance(date(2020, 1, 1), Quantity(Decimal(0)))

    journal = [
        journal_entry(
            description="Test",
            postings=[
                Posting(IncomeStatement.CostOfSales, Amount("100.00"), PostingDirection.Debit),
                Posting(Liabilities.AccountsPayable, Amount("100.00"), PostingDirection.Credit),
            ],
        )
    ]


# Generated at 2022-06-26 00:31:43.206741
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    try:
        result = read_initial_balances_0.__call__(DateRange)
    except Exception as exception:
        print(exception)

test_ReadInitialBalances___call__()


test_case_1 = compile_general_ledger_program(read_initial_balances_0, ReadJournalEntries)


# Generated at 2022-06-26 00:31:52.452549
# Unit test for method add of class Ledger
def test_Ledger_add():
    # create a Ledger instance
    ledger_0 = Ledger(Account("1110"), Balance("2020-09-01", 0))
    # create journal entry
    e0= JournalEntry("2020-09-01", "journal entry")
    # add a posting to the journal entry
    e0.add("1100", 2000, "debit")
    # create a posting entry
    posting_0 = Posting("2020-09-01", "1100", e0)
    # add a posting to the ledger instance
    ledger_entry_0 = ledger_0.add(posting_0)
    # check the name of the instance
    print(ledger_entry_0.ledger)
    # check the amount of the instance
    print(ledger_entry_0.amount)
    # check the balance of the instance

# Generated at 2022-06-26 00:31:57.520495
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries, compile_journal_program

    read_initial_balances: ReadInitialBalances = lambda period: {
        Account("000000", "Cash/Bank account"): Balance(datetime.date(2017, 1, 1), Quantity(Decimal(0)))
    }
    read_journal_entries: ReadJournalEntries = compile_journal_program(lambda period: [])
    general_ledger_program: GeneralLedgerProgram = compile_general_ledger_program(
        read_initial_balances, read_journal_entries
    )

    general_ledger = general_ledger_program(DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)))

# Generated at 2022-06-26 00:32:01.932070
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    read_initial_balances_0 = ReadInitialBalances()
    assert read_initial_balances_0.__call__(DateRange(datetime.date(2020, 1, 1), datetime.date(2021, 1, 1))) is None


# Generated at 2022-06-26 00:32:16.584966
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Case 0
    read_initial_balances_0 = None
    read_journal_entries_0 = None
    var_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    print(f'var_0 = {var_0}')


if __name__ == "__main__":
    test_build_general_ledger()

# Generated at 2022-06-26 00:32:23.151685
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    read_journal_entries_0 = None
    var_1 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    date_range_0 = None
    var_1(date_range_0)



# Generated at 2022-06-26 00:32:35.364394
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = DateRange(datetime.datetime(2018, 1, 1), datetime.datetime(2018, 12, 31))

# Generated at 2022-06-26 00:32:45.758876
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account

    from .commons.zeitgeist import DateRange

    from .journaling import JournalEntry, Posting

    from .accounts import Account

    from .commons.numbers import Amount

    from .commons.zeitgeist import DateRange

    from .journaling import JournalEntry, Posting

    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return dict()

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[object]]:
        from .commons.zeitgeist import DateRange

        from .commons.numbers import Amount

        from .accounts import Account

        from .journaling import JournalEntry, Posting

        return dict()


# Generated at 2022-06-26 00:32:49.568245
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances = None
    read_journal_entries = None
    var_1 = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    date_range_0 = None
    var_2 = var_1(date_range_0)

# Generated at 2022-06-26 00:32:58.466864
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import datetime
    from dataclasses_json import load, dataclass_json
    from .accounts import Account, AccountType

    ## Prepare a test journal:

# Generated at 2022-06-26 00:33:13.633836
# Unit test for method add of class Ledger
def test_Ledger_add():
    import datetime
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict, List, Optional

    #: Defines a generic type variable.
    _T = None

    @dataclass
    class GeneralLedger(Generic[_T]):
        """
        Provides a general ledger model.
        """

        #: Accounting period.
        period: datetime.date

        #: Individual account ledgers of the general ledger.
        ledgers: Dict[None, Ledger[_T]]

    @dataclass
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the journal entry.
        date: datetime.date

        #: Description of the journal entry.
        description: str

        #: Postings of the journal entry.

# Generated at 2022-06-26 00:33:17.356591
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    ## Test cases when opening date after closing date
    opening_date_0 = datetime.date.fromordinal(1)
    closing_date_0 = datetime.date.fromordinal(1)
    date_range_0 = DateRange(opening_date_0, closing_date_0)
    dict_0 = {Account("Account 1"): Balance(opening_date_0, Quantity(Decimal(0)))}
    result_0 = compile_general_ledger_program(lambda period_0: dict_0, lambda period_0: {})(date_range_0)
    assert result_0 == GeneralLedger(date_range_0, {}), "Test of the function compile_general_ledger_program failed"

    ## Test case when there are no initial balances

# Generated at 2022-06-26 00:33:22.266087
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    dict_0 = None
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)
    var_0.ledgers.__setitem__("", Ledger("", Balance("", Quantity(""))))
    var_0.ledgers.__getitem__("").add("")


# Generated at 2022-06-26 00:33:28.204408
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = None
    balance_0 = Balance(None, None)
    var_0 = Ledger(account_0, balance_0)
    account_1 = None
    direction_1 = None
    quantity_1 = None
    var_1 = Posting(None, account_1, direction_1, quantity_1)
    var_2 = var_0.add(var_1)
    assert isinstance(var_2, LedgerEntry)

# Generated at 2022-06-26 00:33:38.721734
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    account_0 = None
    balance_0 = None
    ledger_0 = Ledger(account_0, balance_0)
    posting_0 = None
    ledger_0.add(posting_0)


# Generated at 2022-06-26 00:33:40.073133
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:33:41.296216
# Unit test for function build_general_ledger
def test_build_general_ledger():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise e


# Generated at 2022-06-26 00:33:43.230084
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_0 = ReadInitialBalances.__call__(ReadInitialBalances)


# Generated at 2022-06-26 00:33:43.784753
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-26 00:33:48.086065
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_1 = Amount(0)
    var_2 = Amount(0)
    var_3 = Amount(0)
    var_4 = Amount(0)
    var_5 = Quantity(0)
    var_6 = Balance(var_5)
    var_7 = Account("0")
    var_8 = Ledger(var_7,var_6,dict_0)
    var_9 = Posting(var_8,var_4,var_3,var_2,var_1,var_1)
    var_10 = var_8.add(var_9)


# Generated at 2022-06-26 00:33:50.583751
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    dict_0 = None
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)



# Generated at 2022-06-26 00:33:52.749866
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()

test_case_1 = None
test_case_2 = None
test_case_3 = None


# Generated at 2022-06-26 00:34:02.668834
# Unit test for method add of class Ledger
def test_Ledger_add():
    account1 = Account(acctnum="1020304", description="Cash")
    account2 = Account(acctnum="2000", description="Wages")
    balance = Balance(datetime.date(year=2020, month=1, day=1), Quantity(Decimal(1000)))

    journal_entry = JournalEntry(
        date=datetime.date(year=2020, month=2, day=1),
        description="Wages for January 2020",
        postings=[
            Posting(account1, Amount(Decimal(3500)), True),
            Posting(account2, Amount(Decimal(3500)), True),
        ],
    )
    journal_entry.postings[0].journal = journal_entry
    journal_entry.postings[1].journal = journal_entry

    ledger = Ledger(account1, balance)
    ledger

# Generated at 2022-06-26 00:34:09.048026
# Unit test for method add of class Ledger
def test_Ledger_add():
    cnt_0 = Ledger(Account('EUR'), Balance(datetime.datetime.now(), Quantity(Decimal(0))))
    obj_0 = LedgerEntry(cnt_0, Posting(JournalEntry(datetime.datetime.now(), 'Przychody'), Account('EUR'), Amount(Decimal(0)), 'Przychody', 'Przychody'), Quantity(Decimal(0)))
    cnt_0.add(Posting(JournalEntry(datetime.datetime.now(), 'Przychody'), Account('EUR'), Amount(Decimal(0)), 'Przychody', 'Przychody'))
    print(cnt_0)


# Generated at 2022-06-26 00:34:15.737890
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True


# Generated at 2022-06-26 00:34:25.939209
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import unittest
    #
    # We use the following type alias to make the type signatures easier to read:
    #
    from typing import Callable, Dict
    #
    # The test function will be of the following type:
    Type = Callable[[Dict[Account, Balance]], GeneralLedger[None]]
    #
    # We start by setting up a test:
    #
    def test(func: Type) -> None:
        #
        # We need to add a few lines of boilerplate to make the code a bit more readable:
        #
        import dataclasses
        import zeitgeist
        #
        # The test case itself:
        #
        @dataclasses.dataclass
        class Case:
            pre: Dict[Account, Balance]
            post: GeneralLedger[None]
        #


# Generated at 2022-06-26 00:34:27.028785
# Unit test for function build_general_ledger
def test_build_general_ledger():
    test_case_0()



# Generated at 2022-06-26 00:34:29.266882
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Assert raises TypeError for unhandled type for argument 0
    with pytest.raises(TypeError):
        ReadInitialBalances.__call__(None, None)



# Generated at 2022-06-26 00:34:32.002030
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Input
    items_0 = None
    input_0 = None
    # Output
    output_0 = compile_general_ledger_program(items_0, input_0)
    assert output_0 is not None


# Generated at 2022-06-26 00:34:34.145992
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    dict_0 = None
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)



# Generated at 2022-06-26 00:34:43.104663
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    date_range_0 = None
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture
    # Setup fixture


# Generated at 2022-06-26 00:34:44.543737
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(lambda x: None, lambda x: None)

# Generated at 2022-06-26 00:34:48.352858
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    dict_0 = None
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)
    assert var_0 is not None


# Generated at 2022-06-26 00:34:50.641581
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    dict_0 = None
    var_0 = ReadInitialBalances.__call__(date_range_0)


# Generated at 2022-06-26 00:35:06.748040
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances_0 = None
    read_journal_entries_0 = None
    var_0 = compile_general_ledger_program(read_initial_balances_0, read_journal_entries_0)
    date_range_0 = None
    var_1 = var_0(date_range_0)

# Generated at 2022-06-26 00:35:09.917957
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    dict_0 = None
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)


# Generated at 2022-06-26 00:35:18.385819
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        date_range_0 = None
        var_0 = GeneralLedgerProgram.__call__(date_range_0)
        print("PASS")
    except Exception as e:
        print("FAIL", e.message)

if __name__ == "__main__":
    test_case_0()
    test_GeneralLedgerProgram___call__()

# Generated at 2022-06-26 00:35:27.810772
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = DateRange(date(year=2020, month=7, day=9), date(year=2020, month=7, day=9))
    account_0 = Account(name='Assets')
    balance_0 = Balance(date_range_0.since, Quantity(Decimal(0)))
    # Constructor call
    ledger_0 = Ledger(account_0, balance_0)
    account_1 = Account('Income')
    account_2 = Account('Equipment')
    account_3 = Account('Assets')
    account_4 = Account('Employee')
    account_5 = Account('Equipment')
    account_6 = Account('Income')
    amount_0 = Amount(Decimal(1))
    amount_1 = Amount(Decimal(0))

# Generated at 2022-06-26 00:35:31.189182
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    dict_0 = None
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)


# Generated at 2022-06-26 00:35:43.045618
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = Account(None, None, None)
    balance_0 = Balance(None, Quantity(Decimal(0)))
    ledger_0 = Ledger(account_0, balance_0)
    journal_0 = JournalEntry(date_0, str_0, [posting_0])
    date_0 = date.today()
    quantity_0 = Quantity(Decimal(0))
    str_0 = str()
    posting_0 = Posting(journal_0, EnumDirection.Debit, account_0, amount_0)
    str_1 = str()
    account_1 = Account(str_1, str_1, str_1)
    amount_0 = Amount(quantity_0, str_0)
    ledger_0.add(posting_0)


# Generated at 2022-06-26 00:35:46.748556
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    dict_0 = None
    var_0 = ReadInitialBalances()
    var_0.__call__(date_range_0)


# Generated at 2022-06-26 00:35:56.807191
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import create_journal_entry

    ## Setup:
    read_initial_balances = lambda period: {}
    read_journal_entries = lambda period: [
        create_journal_entry("2018-02-01", "1", 1, 5),
        create_journal_entry("2018-02-02", "2", 2, 10),
        create_journal_entry("2018-02-03", "3", 3, 15),
        create_journal_entry("2018-02-04", "4", 4, 20),
        create_journal_entry("2018-02-05", "5", 5, 25),
    ]

    ## Test:
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    general_ledger = general_ledger_

# Generated at 2022-06-26 00:36:05.864131
# Unit test for method __call__ of class ReadInitialBalances

# Generated at 2022-06-26 00:36:07.015221
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_GeneralLedgerProgram___call__(date_range_0)


# Generated at 2022-06-26 00:36:33.985285
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    function_0 = None
    function_1 = None
    var_0 = GeneralLedgerProgram(function_0, function_1)
    date_range_0 = None
    var_1 = var_0(date_range_0)


# Generated at 2022-06-26 00:36:36.876095
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    dict_0 = None
    var_0 = ReadInitialBalances.__call__(ReadInitialBalances, date_range_0)


# Generated at 2022-06-26 00:36:40.969379
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_0 = None
    balance_0 = None
    ledger_0 = Ledger(account_0, balance_0)
    ledger_0.entries.append(ledger_0)
    ledger_0.entries.append(ledger_0)
    posting_0 = None
    ledger_0.add(posting_0)


# Generated at 2022-06-26 00:36:43.326239
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    dict_0 = None
    var_1 = ReadInitialBalances()
    var_2 = var_1.__call__(date_range_0)


# Generated at 2022-06-26 00:36:44.931931
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Call of parent method __init__ of class ReadInitialBalances
    obj = ReadInitialBalances()
    assert obj is not None


# Generated at 2022-06-26 00:36:48.214832
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test case data
    date_range_0 = None
    # No exception should be raised
    GeneralLedgerProgram___call__ = compile_general_ledger_program(dict, dict)
    var_0 = GeneralLedgerProgram___call__(date_range_0)

# Generated at 2022-06-26 00:36:50.004787
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_1 = Ledger(None, None)
    var_2 = var_1.add(None)


# Generated at 2022-06-26 00:36:53.884227
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    dict_0 = None
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)
    assert isinstance(var_0, GeneralLedger)


# Generated at 2022-06-26 00:36:54.730046
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True == True


# Generated at 2022-06-26 00:36:56.179437
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert isinstance(__call__(dict_0, dict_0), GeneralLedger)


# Generated at 2022-06-26 00:37:54.173005
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    print(compile_general_ledger_program)


# Generated at 2022-06-26 00:37:58.121275
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_range_0 = None
    var_0 = GeneralLedgerProgram()
    try:
        var_0(date_range_0)
    except NameError:
        var_0('start')


# Generated at 2022-06-26 00:38:01.097854
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Unit test for method __call__ of class ReadInitialBalances
    obj_0: ReadInitialBalances = None
    var_0: DateRange = None
    var_1 = obj_0(var_0)



# Generated at 2022-06-26 00:38:09.924115
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from zeep import Client
    from zeep.transports import Transport
    from zeep.wsse.username import UsernameToken

    transport = Transport(http_auth=('a', 'b'))
    client = Client('https://url-goes-here.svc?wsdl',
                    transport=transport, wsse=UsernameToken('a', 'b'))

    result_value = None
    soap_response = client.service.CoinGetAll(Language='en-US', CoinID=0)
    if isinstance(soap_response, dict):
        result_value = soap_response['GetAllResult']

    assert result_value is not None

# Generated at 2022-06-26 00:38:12.320309
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    dict_0 = None
    var_0 = build_general_ledger(date_range_0, dict_0, dict_0)



# Generated at 2022-06-26 00:38:19.856028
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Test case with different type arguments:
    date_range_0 = DateRange(datetime.date(year=1, month=1, day=1), datetime.date(year=1, month=1, day=1))
    list_0 = list()
    dict_0 = dict()
    var_0 = build_general_ledger(date_range_0, list_0, dict_0)

    # Test case with different type arguments:
    date_range_0 = DateRange(datetime.date(year=1, month=1, day=1), datetime.date(year=1, month=1, day=1))
    list_0 = list()
    dict_0 = dict()
    var_0 = build_general_ledger.__code__.co_varnames


# Generated at 2022-06-26 00:38:21.814901
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    var_0 = ReadInitialBalances()
    var_1 = var_0.__call__(date_range_0)


# Generated at 2022-06-26 00:38:22.422745
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-26 00:38:31.549277
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def _test_compile_general_ledger_program(
        read_initial_balances: ReadInitialBalances,
        read_journal_entries: ReadJournalEntries[_T],
    ) -> GeneralLedgerProgram[_T]:  # lgtm [py/unused-local-variable]
        return compile_general_ledger_program(read_initial_balances, read_journal_entries)

    def _test_compile_general_ledger_program(
        read_initial_balances: ReadInitialBalances,
        read_journal_entries: ReadJournalEntries[_T],
    ) -> GeneralLedgerProgram[_T]:  # lgtm [py/unused-local-variable]
        return compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-26 00:38:39.667612
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    date_range_0 = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    date_range_1 = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 6, 30))
    date_range_2 = DateRange(datetime.date(2020, 7, 1), datetime.date(2020, 12, 31))

    dict_0 = {}
    dict_0["account"] = None
    dict_0["account_description"] = "Cash"
    dict_0["amount"] = Decimal("10")
    dict_0["balance"] = Balance(datetime.date(2020, 1, 1), Decimal("10"))
    dict_0["direction"] = 1