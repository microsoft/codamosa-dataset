

# Generated at 2022-06-26 00:31:04.286097
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_0 = module_0.date()

    balance_0 = Balance(date_0, Quantity(Decimal(0)))

    ledger_0 = Ledger(Account(0), balance_0)

    posting_0 = Posting(date_0, Amount(Decimal(0)), JournalEntry(date_0, '', [], []), 1)

    ledger_0.add(posting_0)

    assert posting_0 == posting_0

    assert posting_0 == posting_0


# Generated at 2022-06-26 00:31:09.310200
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # TODO: Test the case where the test_case_0 has the following values:
    #   date_0 = datetime.date()
    #   date_0 = datetime.date()

    # Arrange
    # Act
    # Assert
    assert True == True # TODO: implement your test here


# Generated at 2022-06-26 00:31:19.104041
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest import mock
    import datetime
    from .commons.zeitgeist import DateRange
    from .ledgers import ReadInitialBalances
    from .accounts import TerminalAccount, AccountType
    from .generic import Balance
    from dataclasses import dataclass
    date_31, date_30, date_29 = (datetime.date(), datetime.date(2018, 1, 1), datetime.date(2018, 2, 1))
    period_0 = DateRange(date_31, date_30)
    @dataclass
    class AccountModel:
        type: AccountType
    terminal_account_0 = TerminalAccount(name='account_0', type=AccountType.assets, model=AccountModel(type=AccountType.debit))

# Generated at 2022-06-26 00:31:23.171607
# Unit test for method add of class Ledger
def test_Ledger_add():
    random_0 = random.randrange(0, 1000)
    random_1 = random.randrange(0, 1000)
    random_2 = random.randrange(0, 1000)
    random_3 = random.randrange(0, 1000)
    random_4 = random.randrange(0, 1000)
    random_5 = random.randrange(0, 1000)
    random_6 = random.randrange(0, 1000)
    random_7 = random.randrange(0, 1000)
    random_8 = random.randrange(0, 1000)
    random_9 = random.randrange(0, 1000)
    random_10 = random.randrange(0, 1000)
    random_11 = random.randrange(0, 1000)
    random_12 = random.randrange(0, 1000)
    random_13

# Generated at 2022-06-26 00:31:24.853352
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test for method __call__ of class GeneralLedgerProgram
    assert True


import decimal as module_1


# Generated at 2022-06-26 00:31:35.002692
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, Credit, Debit, LedgerAccount
    from .journaling import Journal, Posting, JournalEntry
    from .ledgers import InitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedger
    from datetime import datetime
    from decimal import Decimal

    ## Define some sample data:

    ## Initial balances:

# Generated at 2022-06-26 00:31:37.301364
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    period = None

    # Call without error
    program = compile_general_ledger_program(None, None)
    general_ledger = program(period)



# Generated at 2022-06-26 00:31:43.333814
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_0 = module_0.date()
    test_0 = Ledger(Account(), Balance(date_0, Quantity(Decimal(0))))
    test_1 = Posting(Account(), Quantity(Decimal(0)), Direction.DEBIT, PostingCategory.ADJUSTMENT, Journal(date_0, Direction.DEBIT, "string"))
    test_0.add(test_1)

    assert 1 == 1


# Generated at 2022-06-26 00:31:52.565754
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting
    from .generic import Amount
    from .generic import Quantity
    from .commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting
    from .commons.zeitgeist import DateRange
    from .general_ledgers import GeneralLedger
    from .general_ledgers import AccountLedger
    from .general_ledgers import LedgerEntry
    from .general_ledgers import LedgerEntry
    from .general_ledgers import LedgerEntry
    from .general_ledgers import LedgerEntry
    from .general_ledgers import LedgerEntry
    from .general_ledgers import LedgerEntry

# Generated at 2022-06-26 00:31:53.727899
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    #
    # _program(period: DateRange) -> GeneralLedger[_T]:
    #
    pass

# Generated at 2022-06-26 00:32:01.024097
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-26 00:32:10.400267
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    opening_date = datetime.date(year=2017, month=7, day=1)
    closing_date = datetime.date(year=2017, month=9, day=30)
    opening_balance = Balance(opening_date, Quantity(Decimal(100)))
    closing_balance = Balance(closing_date, Quantity(Decimal(80)))
    period = DateRange(opening_date, closing_date)

    def read_initial_balances(d: DateRange) -> InitialBalances:
        return {
            Account(account=None, name="Initial balance", currency="EUR", is_terminal=True): opening_balance,
            Account(account=None, name="Final balance", currency="EUR", is_terminal=True): closing_balance,
        }

# Generated at 2022-06-26 00:32:10.946794
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-26 00:32:13.206874
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = None
    var_1(var_2)

# Generated at 2022-06-26 00:32:14.445643
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Verify that reads initial balances and journal entries implementations and returns a general ledger program.
    """

    ## Verify that a compilation of dummy algebra implementations works.
    test_case_0()

# Generated at 2022-06-26 00:32:19.935677
# Unit test for function build_general_ledger
def test_build_general_ledger():

    # FIXME: Full test case

    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = build_general_ledger(var_0, var_1, var_2)

    pass


# Generated at 2022-06-26 00:32:29.636325
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import Direction, Journal, Posting
    from .journaling import JournalEntry as JournalEntry_
    from .journaling import Posting as Posting_
    from .journaling import Direction as Direction_
    from .journaling import Journal as Journal_
    from .journaling import Account as Account_
    from .journaling import Amount as Amount_
    from .journaling import Quantity as Quantity_
    from .generic import Balance as Balance_
    from . import generic as generic_
    from .generic import Balance as Balance_
    from .journaling import JournalEntry as JournalEntry_
    from .journaling import Direction as Direction_
    from .journaling import Journal as Journal_
    from .journaling import Account as Account_
    from .journaling import Amount as Amount

# Generated at 2022-06-26 00:32:35.544594
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 6, 30))
    var_3 = var_1(var_2)
    assert isinstance(var_3, GeneralLedger)


# Generated at 2022-06-26 00:32:41.601134
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Ledger(Account('Assets', 'Cash'), Balance(datetime.date(2018, 1, 1), Quantity(Decimal('100.00'))))
    var_1 = var_0.add(Posting(JournalEntry(datetime.date(2018, 1, 2), 'Description', [Posting(Account('Assets', 'Cash'), Decimal('100.00'))]), Account('Assets', 'Cash'), Decimal('100.00')))

# Generated at 2022-06-26 00:32:51.433193
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from model.accounts import Accounts, Account
    from model.journaling import JournalEntry, Posting
    from model.commons.zeitgeist import DateRange

    period = DateRange(datetime.date(2019, 8, 1), datetime.date(2019, 8, 31))
    #accounts = Accounts()
    accounts = Accounts()
    earnings = Account(accounts, "Earnings")
    sales = Account(accounts, "Sales")
    expenses = Account(accounts, "Expenses")
    salaries = Account(accounts, "Salaries")


# Generated at 2022-06-26 00:33:07.219038
# Unit test for method add of class Ledger
def test_Ledger_add():
    a = Account("Test Account")
    l = Ledger(a, Balance(None, Quantity(Decimal(0))))
    p = Posting(None, a, None, None)
    le = LedgerEntry(l, p, None)
    assert le.ledger is l
    assert le.posting is p
    assert le.balance is None


# Generated at 2022-06-26 00:33:17.478384
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .generic import Balance
    import datetime
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict, TypeVar
    var_2 = TypeVar("var_2")
    var_3 = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    var_4 = Balance(datetime.date(2019, 12, 31), Decimal("0"))
    var_5 = Dict[Account, Balance]
    var_6 = Dict[str, Balance]
    var_7 = TypeVar("var_7")
    var_8 = Decimal("0")

# Generated at 2022-06-26 00:33:20.932583
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test case 0
    var_2 = None
    var_0 = compile_general_ledger_program(var_2, var_2)
    var_3 = None
    var_0(var_3)


# Generated at 2022-06-26 00:33:21.878045
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True


# Generated at 2022-06-26 00:33:31.889501
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from rflx.expression import INTEGRITY, verified
    from rflx.identifier import ID
    from rflx.model import Message, Module
    from rflx.pyrflx.expression import PyExpression
    from rflx.pyrflx.message import PyMessage
    from rflx.pyrflx.module import PyModule

    module = PyModule(Module(ID("accounting"), [], []))
    transaction = PyMessage(Message(ID("transaction"), [], [], [], INTEGRITY, False))
    module.add(transaction)
    transaction.add(
        "description", PyExpression(transaction.model["description"], "description", str, verified(str))
    )

# Generated at 2022-06-26 00:33:32.791038
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert compile_general_ledger_program() is not None

# Generated at 2022-06-26 00:33:35.032332
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_2 = Ledger(None, None)
    var_3 = []
    var_2.entries = var_3
    pass



# Generated at 2022-06-26 00:33:35.893834
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-26 00:33:40.908934
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_2 = None
    var_3 = compile_general_ledger_program(var_2, var_2)
    var_4 = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    var_5 = None
    var_6 = var_3(var_4)


# Generated at 2022-06-26 00:33:50.626985
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..accounting.journaling import build_journal_entry, Posting as _Posting # type: ignore
    from ..accounting.commons import Balance as _Balance

    _account_1 = None
    _account_2 = None
    _account_3 = None
    _account_4 = None
    _account_5 = None
    _account_6 = None
    _account_7 = None
    _account_8 = None
    _account_9 = None

    _initial_0 = None
    _initial_1 = None
    _initial_2 = None
    _initial_3 = None
    _initial_4 = None
    _initial_5 = None
    _initial_6 = None
    _initial_7 = None
    _initial_8 = None
    _initial_9 = _Balance(0)

    _account

# Generated at 2022-06-26 00:34:06.548281
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances.__call__(var_0, var_0)


# Generated at 2022-06-26 00:34:10.041949
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = ""
    var_3 = var_1(var_2)
    assert isinstance(var_3, GeneralLedger)
    assert var_3.period == var_2


# Generated at 2022-06-26 00:34:12.606489
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert callable(compile_general_ledger_program)
    # var_0 = None
    # var_1 = compile_general_ledger_program(var_0, var_0)

# Generated at 2022-06-26 00:34:13.203124
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-26 00:34:17.593145
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = 0
    var_1 = None
    var_2 = compile_general_ledger_program(var_1, var_1)(var_0)
    var_3 = None

    # Call function to test return:
    assert var_3 == build_general_ledger(var_0, var_1, var_1)


# Generated at 2022-06-26 00:34:19.919035
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances.__call__(var_0, None)


# Generated at 2022-06-26 00:34:25.939771
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Initialize test objects
    var_0 = None
    var_1 = Ledger(var_0, var_0)
    var_2 = None
    var_3 = var_1.add(var_2)

    ## Assert statements
    assert type(var_3) == LedgerEntry
    assert type(var_3.balance) == Quantity
    assert var_3.balance.value == Decimal(0.0)


# Generated at 2022-06-26 00:34:27.373215
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_0.__call__()


# Generated at 2022-06-26 00:34:35.883218
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(None, None)
    posting = None
    entry = ledger.add(posting)
    if entry is None or not isinstance(entry, LedgerEntry):
        raise AssertionError("entry should be an instance of LedgerEntry")
    ledger = Ledger(None, None)
    posting = None
    entry = ledger.add(posting)
    if entry is None or not isinstance(entry, LedgerEntry):
        raise AssertionError("entry should be an instance of LedgerEntry")
    ledger = Ledger(None, None)
    posting = None
    entry = ledger.add(posting)
    if entry is None or not isinstance(entry, LedgerEntry):
        raise AssertionError("entry should be an instance of LedgerEntry")
    ledger = Ledger(None, None)
    posting

# Generated at 2022-06-26 00:34:44.278912
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account.from_data(id='1234', name='My account', code='1234', type='A')
    balance = Balance('2019-01-01', Quantity(Decimal(0)))
    ledger = Ledger(account, balance)
    entry = ledger.add(Posting(account, DateRange(since='2019-01-01', until='2019-01-01'), Amount(Decimal(15.5)), 'Debit'))
    assert entry.balance == Quantity(Decimal(15.5))
    entry = ledger.add(Posting(account, DateRange(since='2019-01-01', until='2019-01-01'), Amount(Decimal(12.4)), 'Credit'))
    assert entry.balance == Quantity(Decimal(3.1))
test_Ledger_add()

# Generated at 2022-06-26 00:35:09.713405
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import account_balance_service, AccountBalanceService
    from .journaling import journal_entry_service, JournalEntryService
    from .resources import read_data
    from .typing import Transaction
    from ..commons.context import execution_context
    from ..commons.paradigms import Service, service_registry

    ## First, we need to set up the execution context:
    context = execution_context()
    context.service_registry = service_registry()
    context.service_registry.register(Service(AccountBalanceService, account_balance_service))
    context.service_registry.register(Service(JournalEntryService, journal_entry_service))

    ## Next, we need to prepare the data:

# Generated at 2022-06-26 00:35:24.390345
# Unit test for function build_general_ledger
def test_build_general_ledger():
    class mockReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            initial_balances = {}
            return initial_balances

    class mockReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            journal_entries = []
            return journal_entries

    obj_0 = mockReadInitialBalances()
    obj_1 = mockReadJournalEntries()
    var_0 = compile_general_ledger_program(obj_0, obj_1)
    obj_2 = DateRange(datetime.datetime.now(), datetime.datetime.now())
    var_1 = var_0(obj_2)
    print(isinstance(var_1, GeneralLedger))

# Generated at 2022-06-26 00:35:27.109427
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from book_keeping.adapters import ReadInitialBalancesFromConfig
    # Unit test for method __call__ of class GeneralLedgerProgram
    pass



# Generated at 2022-06-26 00:35:39.210943
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = None
    var_3 = var_1(var_2)
    print("Testing function compile_general_ledger_program")
    print("\tCalling function GeneralLedgerProgram.__call__")
    print("\t\tTesting return type GeneralLedger")
    print("\t\t\tPreviewing object: ", var_3)
    print("\t\t\tReturn type: ", type(var_3))
    print("\t\t\tExpected type: ", GeneralLedger)
    var_4 = None
    print("\t\t\tRequired value: ", var_4)

# Generated at 2022-06-26 00:35:41.920941
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    return (var_1)


# Generated at 2022-06-26 00:35:43.986193
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    test_case_0()


if __name__ == "__main__":
    test_GeneralLedgerProgram___call__()

# Generated at 2022-06-26 00:35:51.179484
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange

    from .accounts import Account
    from .commons import Balance
    from .journaling import Credit, Debit, JournalEntry, Posting

    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

# Generated at 2022-06-26 00:35:58.273527
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # TemplateTypeVar lets you override the type parameters
    # of a class or a function. Here we override the return type
    # of the build_general_ledger:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    journal: Iterable[JournalEntry[_T]] = [JournalEntry(datetime.date(2020, 1, 1), "", [])]
    initial: InitialBalances = {}
    result = build_general_ledger(period, journal, initial)
    assert isinstance(result, GeneralLedger[_T])



# Generated at 2022-06-26 00:36:07.444303
# Unit test for function build_general_ledger
def test_build_general_ledger():
    def test_build_general_ledger_0():
        from buchschloss.models import (
            GeneralLedger,
            Account,
            AccountType,
            Balance,
            DateRange,
            JournalEntry,
            Posting,
            Quantity,
        )
        from buchschloss.services import build_general_ledger
        from buchschloss.services.algebra import build_journal_entry_0

        ## Define a journal:

# Generated at 2022-06-26 00:36:16.401177
# Unit test for method add of class Ledger
def test_Ledger_add():
    import datetime
    from decimal import Decimal

    from pyglet_ledger.accounting.accounts import Account
    from pyglet_ledger.accounting.journals import Journal, PostingDirection
    from pyglet_ledger.accounting.journaling import JournalEntry


    posting = JournalEntry(
        Journal(
            datetime.date(2000, 1, 1),
            "First entry",
            Posting(Account("Assets", "Current assets", "Cash", "Euro"), PostingDirection.DEBIT, Amount(Decimal(100)))
        )
    ).postings[0]

    ledger = Ledger(
        Account("Assets", "Current assets", "Cash", "Euro"),
        Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0)))
    )


# Generated at 2022-06-26 00:36:48.102404
# Unit test for method add of class Ledger
def test_Ledger_add():
    # setup
    import datetime

    from ..commons.numbers import Amount
    from .journaling import Direction, Journal, Posting
    from .accounting import Account

    var_0 = Account("10/000")
    from .generic import Balance
    var_1 = Balance(datetime.date(year=1830, month=1, day=1), Amount(Amount(int=0)))
    var_2 = Ledger(var_0, var_1)
    var_3 = Journal(datetime.date(year=1830, month=1, day=1), "")
    var_4 = Posting(var_3, var_0, Direction.DEBIT, Amount(Amount(int=0)))
    var_5 = var_2.add(var_4)
    # assertions

# Generated at 2022-06-26 00:36:56.753944
# Unit test for method add of class Ledger
def test_Ledger_add():

    class JournalEntryStub:
        date = '2020-01-01'
        description = 'Test entry'
        amount = 50
        is_debit = True
        direction = 'Debit'

    class PostingStub:
        account = 'Test account'
        journal = JournalEntryStub
        amount = 50
        is_debit = True
        direction = 'Debit'

    class LedgerStub:
        account = 'Test account'
        initial = Balance(Decimal('0'))
        entries = []

    assert LedgerStub.initial.value == Decimal('0')
    assert LedgerStub.add(PostingStub) is not None
    assert LedgerStub.entries is not None


# Generated at 2022-06-26 00:36:59.496431
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    arg_0 = None
    class_0 = compile_general_ledger_program(None, None)
    var_0 = class_0(arg_0)
    var_1 = None
    var_2 = var_0(var_1)

# Generated at 2022-06-26 00:37:01.297044
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_0 = ReadInitialBalances.__call__(var_0, None)


# Generated at 2022-06-26 00:37:03.125675
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)


# Generated at 2022-06-26 00:37:03.916616
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test Case 0:
    test_case_0()

# Generated at 2022-06-26 00:37:06.909051
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    def _ReadInitialBalances___call__(self):
        pass

test_ReadInitialBalances___call__.__annotations__ = {'return': InitialBalances, 'self': ReadInitialBalances}


# Generated at 2022-06-26 00:37:08.746911
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = DateRange()
    var_1 = ReadInitialBalances()
    var_2 = var_1.__call__(var_0)


# Generated at 2022-06-26 00:37:10.440655
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = test_case_0()
    var_2 = var_1(var_0)


# Generated at 2022-06-26 00:37:12.755818
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_0 = var_0()
    var_1 = test_ReadInitialBalances___call____object_16()
    var_2 = var_0(var_1)


# Generated at 2022-06-26 00:38:13.474836
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRanges

    from .accounts import Account, Accounts
    from .journaling import open_journal, post_journal

    # Create test account.
    account = Account(Accounts.Equity, "Test account")

    # Create a journal entry for credit posting.
    journal_0 = open_journal(
        datetime.date(year=2017, month=1, day=1), "Test debit", "Debit", None, None, Datum=None
    )
    credit_posting_0 = post_journal(journal_0, account, Amount(10), None)

    # Create a journal entry for credit posting.

# Generated at 2022-06-26 00:38:13.998921
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ...

# Generated at 2022-06-26 00:38:16.775215
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    program = compile_general_ledger_program(None, None)
    period = DateRange("2020-01-01", "2020-12-31")
    actual = program(period)
    assert actual == GeneralLedger(period, {})

# Generated at 2022-06-26 00:38:19.631472
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = Ledger(None, None)
    var_1 = var_0.add(None)

    assert var_1 is not None


# Generated at 2022-06-26 00:38:21.402542
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = DateRange()
    var_0.__call__(var_1)


# Generated at 2022-06-26 00:38:30.568541
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import read_journal
    from .accounts import Account, AccountType
    from .generic import Balance


# Generated at 2022-06-26 00:38:32.374144
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    try:
        _ReadInitialBalances___call__()
    except:
        print("Exception raised.")
        raise

# Generated at 2022-06-26 00:38:36.042802
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances()
    var_1 = DateRange(datetime.date(2021, 1, 1), datetime.date(2021, 12, 31))
    var_2 = {}
    var_3 = var_0.__call__(var_1)
    assert isinstance(var_3, InitialBalances)

# Generated at 2022-06-26 00:38:37.856886
# Unit test for method add of class Ledger
def test_Ledger_add():
  var_0 = Ledger(str(), str())
  var_1 = str()
  var_0.add(var_1)

# Generated at 2022-06-26 00:38:40.403003
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = compile_general_ledger_program(None, None)
    var_1 = var_0(None)
    var_2 = var_1.__class__
    assert var_2 == GeneralLedger


# Generated at 2022-06-26 00:39:54.772241
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # TODO: move this method to some general class and make it common for all protocols
    _T = TypeVar('_T')
    class StubReadInitialBalances(Generic[_T]):
        def __call__(self, arg0: DateRange) -> InitialBalances:
            self._args = {}
            self._args["arg0"] = arg0
            return {}
    var_0 = StubReadInitialBalances()
    test_ReadInitialBalances___call___arg0 = None
    test_ReadInitialBalances___call___var_0_ret = var_0(test_ReadInitialBalances___call___arg0)
    test_ReadInitialBalances___call___var_0_ret_ref = None
    assert test_ReadInitialBalances___call___var_0_ret == test_ReadInitialBalances___call__

# Generated at 2022-06-26 00:39:56.883800
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # none ----> none
    var_0 = None
    var_1 = var_0
    var_2 = var_1
    # none ----> none
    var_0 = None
    var_1 = var_0
    var_2 = var_1


# Generated at 2022-06-26 00:39:58.893859
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = None
    var_3 = var_1(var_2)

# Generated at 2022-06-26 00:39:59.455318
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## TODO!
    pass


# Generated at 2022-06-26 00:40:00.035886
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True


# Generated at 2022-06-26 00:40:01.156637
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    obj = ReadInitialBalances()
    try:
        obj.__call__()
    except NotImplementedError:
        pass


# Generated at 2022-06-26 00:40:04.695106
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_2 = None
    var_3 = compile_general_ledger_program(var_2, var_2)
    try:
        var_4 = None  # type: DateRange
        var_3.__call__(var_4)
    except NotImplementedError:
        print("GeneralLedgerProgram.__call__() method not implemented yet.")
    else:
        raise AssertionError("GeneralLedgerProgram.__call__() method did not raise NotImplementedError.")

# Generated at 2022-06-26 00:40:06.383820
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = None
    var_1(var_2)



# Generated at 2022-06-26 00:40:09.143887
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    obj_0 = ReadInitialBalances()
    assert hasattr(obj_0.__call__, "__call__")
    func_0 = obj_0.__call__
    callab_0 = callable
    assert callab_0(func_0)
    assert isinstance(func_0(), InitialBalances)


# Generated at 2022-06-26 00:40:10.877917
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = test_ReadInitialBalances___call__.im_self
    var_2 = var_1.__call__(var_0)
