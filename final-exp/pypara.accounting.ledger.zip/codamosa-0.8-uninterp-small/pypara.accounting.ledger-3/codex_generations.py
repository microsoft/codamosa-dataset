

# Generated at 2022-06-26 00:31:03.805240
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Set up mock objects.
    journal_0 = []
    initial_0 = {}
    period_0 = pypara.commons.zeitgeist.DateRange(datetime.date(1, 1, 1), datetime.date(2, 3, 4))
    # Call function under test.
    result_0 = build_general_ledger(period_0, journal_0, initial_0)
    # Check the result.
    assert result_0 is not None


# Generated at 2022-06-26 00:31:05.733437
# Unit test for method add of class Ledger

# Generated at 2022-06-26 00:31:07.710690
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    float_0 = -633.35
    account_0 = module_0.Account()


# Generated at 2022-06-26 00:31:11.148072
# Unit test for method add of class Ledger
def test_Ledger_add():
    balance_0 = Balance()
    account_0 = module_0.Account()
    ledger_0 = Ledger()
    posting_0 = Posting()
    ledger_0.add(posting_0)


# Generated at 2022-06-26 00:31:12.763806
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    float_1 = -633.35
    account_0 = module_0.Account()


# Generated at 2022-06-26 00:31:13.340609
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-26 00:31:14.959880
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## TODO: Implement unit test
    pass

import pypara.accounting.journaling as module_1


# Generated at 2022-06-26 00:31:15.908986
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass



# Generated at 2022-06-26 00:31:25.688374
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date as date_0
    from pypara.commons.numbers import Amount as Amount_0, Quantity as Quantity_0
    from pypara.accounting.accounts import Account as Account_0
    from pypara.accounting.journaling import Direction as Direction_0, Posting as Posting_0
    from pypara.accounting.journaling import JournalEntry as JournalEntry_0, generic_entry
    from pypara.accounting.generic import Balance as Balance_0
    from pypara.commons.zeitgeist import DateRange as DateRange_0
    period_0 = DateRange_0(date_0(2020, 1, 1), date_0(2021, 1, 1))

# Generated at 2022-06-26 00:31:35.497199
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import pypara.accounting.accounts as module_0
    import pypara.accounting.journaling as module_1
    import pypara.commons.zeitgeist as module_2
    account_0 = module_0.Account()
    str_0 = 'i'
    str_1 = 'd'
    quantity_0 = module_0.Quantity()
    date_range_0 = module_2.DateRange(0, 0)
    date_range_1 = module_2.DateRange(0, 0)
    date_range_2 = module_2.DateRange(0, 0)
    date_range_3 = module_2.DateRange(0, 0)
    def function_0():
        return float_0

# Generated at 2022-06-26 00:31:50.287248
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    date_range_0 = None
    read_initial_balances_0 = None
    str_0 = 'k`Wgu]2+Iw#X'
    var_0 = compile_general_ledger_program(read_initial_balances_0, str_0)
    read_initial_balances_1 = ReadInitialBalances()
    dict_0 = read_initial_balances_1.__call__(date_range_0)
    dict_1 = read_initial_balances_1.__call__(date_range_0)
    str_1 = None
    list_0 = [str_0, dict_0]
    account_0 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    str_2 = ')G-o'

# Generated at 2022-06-26 00:32:00.157036
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    read_initial_balances_0 = None
    str_0 = 'k`Wgu]2+Iw#X'
    var_0 = compile_general_ledger_program(read_initial_balances_0, str_0)
    read_initial_balances_1 = ReadInitialBalances()
    dict_0 = read_initial_balances_1.__call__(date_range_0)
    dict_1 = read_initial_balances_1.__call__(date_range_0)
    str_1 = None
    list_0 = [str_0, dict_0]
    account_0 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    str_2 = ')G-o'

# Generated at 2022-06-26 00:32:09.421692
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = DateRange(None, None)
    read_initial_balances_0 = ReadInitialBalances()
    str_0 = 'k`Wgu]2+Iw#X'
    var_0 = compile_general_ledger_program(read_initial_balances_0, str_0)
    read_initial_balances_1 = ReadInitialBalances()
    dict_0 = read_initial_balances_1.__call__(date_range_0)
    dict_1 = read_initial_balances_1.__call__(date_range_0)
    str_1 = None
    list_0 = [str_0, dict_0]
    account_0 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
   

# Generated at 2022-06-26 00:32:17.599088
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = DateRange(datetime.date(2000, 2, 5), datetime.date(2001, 11, 9))
    read_initial_balances_0 = ReadInitialBalances()
    str_0 = 'bSBk]4'
    var_0 = compile_general_ledger_program(read_initial_balances_0, str_0)
    read_initial_balances_1 = None
    dict_0 = read_initial_balances_1.__call__(date_range_0)
    dict_1 = read_initial_balances_1.__call__(date_range_0)
    str_1 = None
    list_0 = [str_0, dict_0]
    account_0 = module_1.Account(*list_0)

# Generated at 2022-06-26 00:32:28.140228
# Unit test for method add of class Ledger
def test_Ledger_add():
    date_range_0 = None
    read_initial_balances_0 = None
    str_0 = 'k`Wgu]2+Iw#X'
    var_0 = compile_general_ledger_program(read_initial_balances_0, str_0)
    read_initial_balances_1 = ReadInitialBalances()
    dict_0 = read_initial_balances_1.__call__(date_range_0)
    dict_1 = read_initial_balances_1.__call__(date_range_0)
    str_1 = None
    list_0 = [str_0, dict_0]
    account_0 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    str_2 = ')G-o'

# Generated at 2022-06-26 00:32:31.887918
# Unit test for method add of class Ledger
def test_Ledger_add():
    try:
        ledger_0 = Ledger(None, None)
        posting_0 = None
        ledger_0.add(posting_0)
    except:
        print("Exception raised")


# Generated at 2022-06-26 00:32:42.901284
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import pytest
    import datetime as module_2
    import pypara.accounting.accounts as module_1

    ###
    # Test case:
    # - One journal entry with two postings and a description.
    # - Two terminal accounts with initial balances.
    #
    # Expected result:
    # - Two general ledger entries with same description, etc.
    #
    # Got result:
    # - OK.
    ###

    # Set up the account IDs:
    list_0 = ['k`Wgu]2+Iw#X', '1', '2', '3']
    account_0 = module_1.Account(*list_0)
    account_1 = module_1.Account(*list_0)
    account_2 = module_1.Account(*list_0)

    # Create the date range:


# Generated at 2022-06-26 00:32:49.241336
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    date_0 = None
    date_range_0 = None
    read_initial_balances_0 = None
    str_0 = 'k`Wgu]2+Iw#X'
    var_0 = compile_general_ledger_program(read_initial_balances_0, str_0)
    general_ledger_0 = var_0.__call__(date_range_0)
    var_1 = general_ledger_0.__eq__(date_0)


# Generated at 2022-06-26 00:32:58.154155
# Unit test for function build_general_ledger
def test_build_general_ledger():
    date_range_0 = None
    read_initial_balances_0 = None
    str_0 = 'k`Wgu]2+Iw#X'
    var_0 = compile_general_ledger_program(read_initial_balances_0, str_0)
    read_initial_balances_1 = ReadInitialBalances()
    dict_0 = read_initial_balances_1.__call__(date_range_0)
    dict_1 = read_initial_balances_1.__call__(date_range_0)
    str_1 = None
    list_0 = [str_0, dict_0]
    account_0 = module_1.Account(*list_0)
    date_0 = module_2.date(*list_0)
    str_2 = ')G-o'

# Generated at 2022-06-26 00:33:13.014874
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    module_0 = compile_general_ledger_program('E', '}')
    read_initial_balances_0 = ReadInitialBalances()
    str_0 = None
    list_0 = [str_0, str_0]
    dict_0 = {str_0: str_0, str_0: str_0}
    date_range_0 = DateRange(str_0, '', '', '', '', [], [])
    journal_entry_0 = JournalEntry(dict_0, date_range_0, '', '', *list_0)
    str_1 = 'H\u0007^'
    list_1 = [read_initial_balances_0, str_1, journal_entry_0]
    str_2 = '_#AAoI'

# Generated at 2022-06-26 00:33:28.194274
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # It is expected that the function would return a GeneralLedger instance in the following test case.

    from . import arithmetics, accounts
    from .journaling import Journal, Posting

    # The accounting period (test case 0):
    from_0 = arithmetics.Date(2020, arithmetics.Month.JANUARY, 1)
    to_0 = arithmetics.Date(2020, arithmetics.Month.DECEMBER, 31)

    period_0 = arithmetics.DateRange(from_0, to_0)

    # Accounts (test case 0):
    account_0 = accounts.Account('Account0', accounts.AccountType.ASSETS)
    account_1 = accounts.Account('Account1', accounts.AccountType.ASSETS)

    # Journal entries (test case 0):

# Generated at 2022-06-26 00:33:31.087882
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = var_1(var_0)


# Generated at 2022-06-26 00:33:32.705885
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Assert __call__(self, period: DateRange) -> InitialBalances
    assert True


# Generated at 2022-06-26 00:33:36.582147
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    period = DateRange(datetime.date(2000, 1, 1), datetime.date(2020, 12, 31))
    var_0 = compile_general_ledger_program(None, None)
    var_0(period)
    var_1 = compile_general_ledger_program(None, None)
    var_2 = var_1(period)

# Generated at 2022-06-26 00:33:41.289809
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period = DateRange.since(datetime.date(2020, 1, 1))
    initial = {}
    journal_entry = JournalEntry.none()
    general_ledger = build_general_ledger(period, [journal_entry], initial)
    assert general_ledger is not None


# Generated at 2022-06-26 00:33:42.625918
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Create a mock implementation of the algebra ReadInitialBalances:
    mock_read_initial_balances = Mock([], [InitialBalances], {})
    test_case_0()



# Generated at 2022-06-26 00:33:45.102218
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger_1 = Ledger(None, None)
    result_bool = ledger_1.add(None) == None
    if not result_bool:
        raise TypeError("bad result type")


# Generated at 2022-06-26 00:33:55.332687
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, TerminalAccount
    from .journaling import Posting, JournalEntry
    from .serializers import Serializer
    from .serializers.base import SerializerRegistry
    from .serializers.csv import CSVSerializer
    from .serializers.json import JSONSerializer
    from .serializers.yaml import YAMLSerializer
    from .storage import FileStorage

    from datetime import date

    from dataclasses import dataclass
    from fractions import Fraction
    from typing import Optional
    from decimal import Decimal

    serializers = SerializerRegistry()
    serializers["csv"] = CSVSerializer
    serializers["json"] = JSONSerializer
    serializers["yaml"] = YAMLSerializer

    serializer = Serializer(serializers)
    storage = FileStorage(serializer)


# Generated at 2022-06-26 00:33:57.598814
# Unit test for method add of class Ledger
def test_Ledger_add():
    """Method adds a new ledger entry.
    """
    ## Verify if the test case is ok.
    assert test_case_0()



# Generated at 2022-06-26 00:33:59.540306
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = None
    var_1 = build_general_ledger(var_0, var_0, var_0)


# Generated at 2022-06-26 00:34:04.992923
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_2: GeneralLedger[None]
    pass



# Generated at 2022-06-26 00:34:05.868411
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Tests the add method of class Ledger

    :return: Nothing.
    """
    pass


# Generated at 2022-06-26 00:34:07.599758
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = var_1(var_0)


# Generated at 2022-06-26 00:34:16.292609
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Import for testing:
    from datetime import date
    from decimal import Decimal
    from ..accounts import Account
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting, Transaction

    ## Define test case:
    period = DateRange(since = date(year = 2019, month = 1, day = 1), until = date(year = 2020, month = 1, day = 1))

# Generated at 2022-06-26 00:34:21.031428
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from . import entriesspec
    from .algebras import build_journal_entry_algebras
    assert compile_general_ledger_program(*build_journal_entry_algebras(entriesspec.journal_entries)).__name__ == "<lambda>",\
        "compile_general_ledger_program must return a lambda instance."

# Generated at 2022-06-26 00:34:30.877469
# Unit test for method add of class Ledger
def test_Ledger_add():
    date1 = datetime.date(2020,9,18)
    posting1 = Posting(date1, "200", 2)
    posting2 = Posting(date1, "200", 2, direction=Posting.Direction.DEBIT)
    posting3 = Posting(date1, "200", 2, direction=Posting.Direction.CREDIT)
    posting4 = Posting(date1, "200", 0)
    posting5 = Posting(date1, "200", 0, direction=Posting.Direction.DEBIT)
    posting6 = Posting(date1, "200", 0, direction=Posting.Direction.CREDIT)
    account_ledger = Ledger("Account", Balance(date1, 0))
    balance1 = Quantity("2")
    balance2 = Quantity("0")

    date3 = datetime

# Generated at 2022-06-26 00:34:31.919213
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)


# Generated at 2022-06-26 00:34:34.384077
# Unit test for function build_general_ledger
def test_build_general_ledger():
    for _i in range(100):
        var_0 = None
        var_1 = build_general_ledger(var_0, var_0, var_0)
        assert var_1 is not None

# Generated at 2022-06-26 00:34:37.130622
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = var_1(var_0)



# Generated at 2022-06-26 00:34:39.210739
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_0 = ReadInitialBalances
    var_0.__call__()



# Generated at 2022-06-26 00:34:49.221535
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = None
    var_1 = build_general_ledger(var_0, var_0, var_0)


# Generated at 2022-06-26 00:34:55.565543
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .commons.numbers import Quantity
    from .journaling import Journal, Posting, PostingDirection

    j = Journal(datetime.date(2020, 9, 16), "The First Journal Entry")
    p1 = Posting(j, PostingDirection.Debit, Quantity(100))
    p2 = Posting(j, PostingDirection.Credit, Quantity(100))

    ledger = Ledger(p1.account, Balance(p1.date, Quantity(200)))
    ledger.add(p1)
    ledger.add(p2)



# Generated at 2022-06-26 00:35:02.829155
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = DateRange(0, 2020, DateRange.MONTH)
    var_1 = [
        JournalEntry(0, "{}", [Posting(0, 1, 2, 3, 4)])
    ]
    var_2 = {}
    var_3 = build_general_ledger(var_0, var_1, var_2)
    assert isinstance(var_3, GeneralLedger)



# Generated at 2022-06-26 00:35:06.246745
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    obj = ReadInitialBalances()
    arg_0 = None
    ret_val = obj.__call__(arg_0)
    assert ret_val is None



# Generated at 2022-06-26 00:35:09.369748
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_2 = None
    var_3 = compile_general_ledger_program(var_2, var_2)
    var_4 = test_case_0()

test_GeneralLedgerProgram___call__()

# Generated at 2022-06-26 00:35:16.100005
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = None
    var_1 = build_general_ledger(var_0, var_0, var_0)
    var_2 = ""
    #assert var_1.__doc__ == var_2

# Generated at 2022-06-26 00:35:26.608109
# Unit test for function build_general_ledger
def test_build_general_ledger():

    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    from .journaling import JournalEntry

    from .numbers import Amount

    var_0 = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 31))
    var_1 = []
    var_2 = {}
    var_3 = build_general_ledger(var_0, var_1, var_2)
    assert var_3 == GeneralLedger(var_0, var_2)
    var_4 = [var_1]
    var_5 = build_general_ledger(var_0, var_4, var_2)
    assert var_5 == GeneralLedger(var_0, var_2)
    var_6 = Account("2110", "BANK")
    var

# Generated at 2022-06-26 00:35:28.618075
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances.__call__(var_0, var_0)


# Generated at 2022-06-26 00:35:32.597295
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Setup and exercise.
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    # Verify.
    var_2 = var_1(var_0)
    return

# Generated at 2022-06-26 00:35:37.982830
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    x_0 = ReadInitialBalances()
    x_1 = ReadJournalEntries()
    x_5 = compile_general_ledger_program(x_0, x_1)
    test_case_0()
    return


test_case_0()

# Generated at 2022-06-26 00:35:56.736505
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from . import algebra as alg
    from . import instances as inst
    from .accounts import Asset, Equity, Liability
    from datetime import date

    ## Compile the program:
    _program = compile_general_ledger_program(alg.read_initial_balances, alg.read_journal_entries)

    ## Call the program:
    _program(inst.create_financial_year(2015))

    ## Check that the function returns a GeneralLedger
    assert isinstance(_program(inst.create_financial_year(2015)), GeneralLedger)

    ## Check that the initial balances have been added to the general ledger
    assert _program(inst.create_financial_year(2015)).ledgers[Liability("Accounts Receivable")].initial.value == 0

    ## Check that the journal entries have been posted

# Generated at 2022-06-26 00:36:05.828964
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Set up parameters
    var_0 = Amount(Decimal('19.200'))
    var_1 = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 2))
    var_2 = Quantity(Decimal('0'))
    var_3 = Quantity(Decimal('4'))
    var_4 = JournalEntry(datetime.date(2019, 1, 1), 'Example journal entry 0.')
    var_5 = JournalEntry(datetime.date(2019, 1, 1), 'Example journal entry 1.')
    var_6 = JournalEntry(datetime.date(2019, 1, 1), 'Example journal entry 2.')
    var_7 = Account(1060, 'Cost of Goods Sold', True)
    var_8 = Account(100, 'Bank', True)
    var_

# Generated at 2022-06-26 00:36:14.813292
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Create arguments for call to method __call__ of class GeneralLedgerProgram:
    var_0 = None

    # Call method __call__ of class GeneralLedgerProgram with arguments:
    #var_1: GeneralLedgerProgram
    var_1 = compile_general_ledger_program(var_0, var_0)

    # Unit test for method __call__ of class GeneralLedger
    def test_GeneralLedger___call__():
        # Create arguments for call to method __call__ of class GeneralLedger:
        var_0 = None

        # Create an instance of class GeneralLedger:
        var_1 = GeneralLedger(var_0, var_0)

        # Call method __call__ of class GeneralLedger with arguments:
        var_2 = var_1.__call__(var_0)

    # Unit test for method

# Generated at 2022-06-26 00:36:24.059747
# Unit test for method add of class Ledger
def test_Ledger_add():
    balance_0 = Balance(datetime.date(2020, 12, 10), Quantity(Decimal('0.1')))
    balance_1 = Balance(datetime.date(2020, 12, 10), Quantity(Decimal('0.1')))
    date_0 = datetime.date(2020, 12, 9)
    ledger_0 = Ledger(Account('Dummy'), balance_0)
    posting_0 = Posting(None, Account('Dummy'), datetime.date(2020, 12, 9), Amount(Decimal('0.1')), 1)
    entry_0 = LedgerEntry(ledger_0, posting_0, Quantity(Decimal('0.1')))
    ledger_1 = Ledger(Account('Dummy'), balance_1)

# Generated at 2022-06-26 00:36:25.729485
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    pass



# Generated at 2022-06-26 00:36:28.198682
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_1 = var_1(var_0)


# Generated at 2022-06-26 00:36:34.237342
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    print("Starting unit test for GeneralLedgerProgram___call__ at " + str(datetime.datetime.now()))
    try:
        assert test_case_0()
    except AssertionError:
        print("Test case 0 failed at " + str(datetime.datetime.now()))
        return
    print("Unit test for GeneralLedgerProgram___call__ completed successfully at " + str(datetime.datetime.now()))

# Generated at 2022-06-26 00:36:36.207285
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert callable(build_general_ledger)



# Generated at 2022-06-26 00:36:37.357831
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Just to silence the unused variable warning.
    _ = ReadInitialBalances.__call__

# Generated at 2022-06-26 00:36:39.211352
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    var_0 = compile_general_ledger_program(var_0, var_0)
    var_1 = var_0(var_1)

# Generated at 2022-06-26 00:36:59.122184
# Unit test for function build_general_ledger

# Generated at 2022-06-26 00:37:00.932817
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances.__call__(var_0, var_0)


# Generated at 2022-06-26 00:37:01.849083
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ReadInitialBalances.__call__([])

# Generated at 2022-06-26 00:37:07.150190
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    import datetime
    from decimal import Decimal
    from typing import Dict

    from typing_inspect import get_origin, get_args, is_union_type

    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .ledgers import InitialBalances, Ledger, LedgerEntry, ReadInitialBalances

    # Test Case 0
    # Test Case 0
    # Test Case 0
    # Test Case 0
    # Test Case 0




# Generated at 2022-06-26 00:37:09.631090
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_2 = None
    var_3 = None
    var_4 = Ledger(var_2, var_3)
    var_5 = None
    var_6 = var_4.add(var_5)


# Generated at 2022-06-26 00:37:11.828143
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances.__call__.__annotations__
    var_2 = test_case_0()
    # assert var_1 == var_2


# Generated at 2022-06-26 00:37:14.590177
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Assume
    input_0 = compile_general_ledger_program(test_case_0, test_case_0)
    # Action
    var_0 = input_0(test_case_0)
    # Assert
    assert var_0 is None


# Generated at 2022-06-26 00:37:20.284704
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)


# Generated at 2022-06-26 00:37:22.791541
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def test_case_1():
        var_0 = None
        var_1 = compile_general_ledger_program(var_0, var_0)
        var_1(var_0)



# Generated at 2022-06-26 00:37:25.506257
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = None
    var_1 = ReadInitialBalances()
    var_2 = var_1.__call__(var_0)


# Generated at 2022-06-26 00:37:56.846891
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_2 = None
    var_3 = Ledger(var_2, var_2)
    assert var_3.add(var_2) is not None


# Generated at 2022-06-26 00:37:58.396064
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        pass
    except:
        raise AssertionError('An exception has been raised')


# Generated at 2022-06-26 00:37:59.199987
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert (False) is None


# Generated at 2022-06-26 00:38:09.461962
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import dummy_journal
    from .accounts import dummy_accounts
    from .numbers import balance

    from datetime import date

    var_0 = (
        date(2020, 1, 1),
        date(2020, 12, 31),
    )

# Generated at 2022-06-26 00:38:11.834719
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = None
    var_1 = build_general_ledger(var_0, var_0, var_0)
    assert isinstance(var_1, GeneralLedger)



# Generated at 2022-06-26 00:38:16.476378
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from importlib import reload

    # Reload module:
    reload(__import__('perspective.general_ledger'))
    from . import general_ledger as target

    # Set up mocks:
    period = type('', (), {})
    journal = type('', (), {})
    initial = type('', (), {})

    # Execute the function:
    target.build_general_ledger(period, journal, initial)


# Generated at 2022-06-26 00:38:19.286616
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Test case 0:
    var_0 = None
    var_1 = build_general_ledger(var_0, var_0, var_0)
    assert var_1.period == var_0
    assert var_1.ledgers == var_0


# Generated at 2022-06-26 00:38:22.405557
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = None
    var_1 = build_general_ledger(var_0, var_0, var_0)
    assert(var_1 == None)



if __name__ == "__main__":
    test_build_general_ledger()

# Generated at 2022-06-26 00:38:25.571466
# Unit test for function build_general_ledger
def test_build_general_ledger():
    var_0 = None
    var_1 = build_general_ledger(var_0, var_0, var_0)
    assert var_1 == None


# Generated at 2022-06-26 00:38:31.130136
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    var_1 = Ledger(var_0, var_0)
    var_2 = var_1.add(var_0)

test_case_0.__annotations__ = {'return': 'GeneralLedger', 'var_0': 'DateRange', 'var_1': 'InitialBalances'}
test_Ledger_add.__annotations__ = {'var_0': 'Posting', 'var_1': 'Account', 'var_2': 'Quantity', 'return': 'LedgerEntry'}

# Generated at 2022-06-26 00:39:28.030650
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = Ledger(var_0, var_1)
    var_4 = var_3.add(var_2)


# Generated at 2022-06-26 00:39:29.387547
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ## Inputs:
    _ = None
    period = None
    ## Expect:
    assert _ == None


# Generated at 2022-06-26 00:39:35.684066
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_7 = Ledger(Account("123"), Balance(datetime.date(2020,1,1), Quantity(Decimal(0))))
    var_8 = JournalEntry(datetime.date(2020,1,1), "", [Posting(Account("123"), datetime.date(2020,1,1), Quantity(Decimal(1))), Posting(Account("234"), datetime.date(2020,1,1), Quantity(Decimal(1)))])
    var_9 = var_8.postings[0]
    var_10 = var_7.add(var_9)
    var_11 = var_10.posting
    var_12 = var_11.account
    assert var_12.name == "123"
    var_13 = var_10.posting
    var_14 = var_13.date

# Generated at 2022-06-26 00:39:42.277765
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.zeitgeist import DateRange

    from .journaling import Journal, Posting, JournalEntry

    from .accounts import (
        Account,
        BankAccount,
        CashAccount,
        CurrentAssetsAccount,
        ExpenseAccount,
        FixedAssetsAccount,
        IncomeAccount,
        LongTermLiabilitiesAccount,
        OwnerAccount,
        ShortTermLiabilitiesAccount,
        StockAccount,
    )


# Generated at 2022-06-26 00:39:45.431896
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    var_0 = None
    var_1 = compile_general_ledger_program(var_0, var_0)
    var_2 = None
    var_3 = var_1(var_2)

# Generated at 2022-06-26 00:39:48.152676
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    # Call method __call__ of class ReadInitialBalances with parameters var_2, var_3
    var_2 = None
    var_3 = None
    var_4 = var_1.__call__(var_2, var_3)

# Generated at 2022-06-26 00:39:50.155345
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_2 = Ledger(None, None)
    var_3 = Posting(None, None)
    var_4 = var_2.add(var_3)

# Generated at 2022-06-26 00:39:53.972643
# Unit test for method add of class Ledger
def test_Ledger_add():
    var_1 = Amount(10.0)
    var_2 = Quantity(10.0)
    var_3 = Posting(var_1, "debit", "test")
    var_4 = Ledger("AC-101", Balance(datetime.date(2020, 1, 1), var_2))
    var_5 = var_4.add(var_3)
    assert var_5.balance == Quantity(20.0)



# Generated at 2022-06-26 00:39:59.188442
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import account_number

    from .journaling import entry_number

    from .journaling import position_debit

    from .journaling import position_credit

    from .journaling import journal_entry

    from .journaling import post_journal_entry

    from .journaling import posting

    from .journaling import debit_posting

    from .journaling import credit_posting

    from .commons.zeitgeist import date_range

    from .commons.numbers import quantity

    from .commons.numbers import amount

    from .commons.numbers import sign

    from .generic import balance

    var_0 = post_journal_entry(None, None)
    var_1 = journal_entry(var_0, None, None)

# Generated at 2022-06-26 00:40:00.907921
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    var_0 = ReadInitialBalances()

    @dataclass
    class _Dummy0:
        pass

    var_1 = _Dummy0()

    var_0.__call__(var_1)
