

# Generated at 2022-06-18 02:31:11.273986
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting

    # Define a dummy algebra implementation:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A1"): Balance(period.since, Quantity(Decimal(100))),
            Account("A2"): Balance(period.since, Quantity(Decimal(200))),
        }


# Generated at 2022-06-18 02:31:20.668154
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import date
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Define some accounts:
    a1 = Account("A1")
    a2 = Account("A2")
    a3 = Account("A3")

    ## Define some initial balances:
    initial_balances = {a1: Balance(date(2020, 1, 1), Quantity(Decimal(100))), a2: Balance(date(2020, 1, 1), Quantity(Decimal(200)))}

    ## Define some journal entries:
    j1 = JournalEntry(date(2020, 1, 1), "J1", [Posting(a1, Quantity(Decimal(10))), Posting(a2, Quantity(Decimal(-10)))])

# Generated at 2022-06-18 02:31:26.690266
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import JournalEntry, Posting, Direction
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    date = Date(2020, 1, 1)
    description = "Cash received from sale of goods"
    amount = Amount(Decimal(100))
    direction = Direction.Debit

# Generated at 2022-06-18 02:31:27.632498
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:37.801567
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1110", "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account("1120", "Bank"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
            }


# Generated at 2022-06-18 02:31:46.003331
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Test data
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
    journal = [
        JournalEntry(
            date=date(2020, 1, 1),
            description="Test journal entry",
            postings=[
                Posting(Account("1010"), Amount(Decimal(100))),
                Posting(Account("1020"), Amount(Decimal(-100))),
            ],
        )
    ]

# Generated at 2022-06-18 02:31:55.005060
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType
    from .generic import Balance
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .general_ledger import GeneralLedger, Ledger, LedgerEntry

    # Define a dummy read initial balances algebra implementation:

# Generated at 2022-06-18 02:32:04.892606
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, read_journal_entries
    from .generic import Balance

    ## Define a period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define some accounts:
    a = Account("A")
    b = Account("B")
    c = Account("C")
    d = Account("D")

    ## Define some initial balances:
    initial_balances = {a: Balance(period.since, Quantity(Decimal(1000))), b: Balance(period.since, Quantity(Decimal(2000)))}

    ## Define some journal entries:

# Generated at 2022-06-18 02:32:15.653182
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:32:26.708653
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger
    from .ledgers import compile_general_ledger_program
    from .ledgers import Ledger, LedgerEntry
    from .ledgers import InitialBalances
    from .ledgers import ReadInitialBalances
    from .ledgers import ReadJournalEntries
    from datetime import date
    from typing import Dict, Iterable
    import unittest


# Generated at 2022-06-18 02:32:38.005014
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection

    # Create a ledger
    ledger = Ledger(Account("1", AccountType.ASSET), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test journal")

    # Create a posting
    posting = Posting(journal, Account("1", AccountType.ASSET), PostingDirection.DEBIT, Quantity(Decimal(100)))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting

# Generated at 2022-06-18 02:32:39.005649
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:50.561422
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from ..commons.types import Direction

    # Create a ledger
    account = Account("A", "A", "A")
    initial = Balance(date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting

# Generated at 2022-06-18 02:33:01.568847
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons.numbers import Amount, Quantity

    # Create a ledger
    account = Account(1, "Test Account")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2020, 1, 1), "Test Journal")
    posting = Posting(journal, account, Amount(Decimal(100)), True)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the entry
    assert entry.ledger == ledger
    assert entry.posting

# Generated at 2022-06-18 02:33:11.167568
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a mock implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020"): Balance(period.since, Quantity(Decimal(200))),
        }

    # Define a mock implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:33:21.766357
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:33:31.489312
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import ReadJournalEntries, ReadInitialBalances

    # Define the algebra implementations:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A1"): Balance(period.since, Quantity(Decimal(10))),
            Account("A2"): Balance(period.since, Quantity(Decimal(20))),
        }


# Generated at 2022-06-18 02:33:37.584314
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(
        date=Date(2020, 1, 1),
        description="Cash received from customer",
        postings=[
            Posting(account=Account("Assets", "Cash"), direction=Direction.DEBIT, amount=Amount(Decimal(100))),
            Posting(account=Account("Revenue", "Sales"), direction=Direction.CREDIT, amount=Amount(Decimal(100))),
        ],
    )

    # Add a posting to the

# Generated at 2022-06-18 02:33:45.768167
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a test account:
    account = Account("Test Account", AccountType.ASSET)

    ## Define a test transaction:
    transaction = Transaction(
        date=datetime.date(2019, 1, 1),
        description="Test Transaction",
        postings=[
            Posting(account=account, amount=Amount(Decimal(100)), direction=Posting.Direction.DEBIT),
            Posting(account=account, amount=Amount(Decimal(100)), direction=Posting.Direction.CREDIT),
        ],
    )

    ## Define a test journal entry:

# Generated at 2022-06-18 02:33:50.258335
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, account, Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:33:57.192884
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:07.243132
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedger
    from .journaling import ReadJournalEntries

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:34:16.709510
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger
    from .types import TransactionType

    ## Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:34:28.614128
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, AccountType, ReadAccounts
    from .generic import Balance, ReadInitialBalances
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .commons.types import Currency
    from .commons.exchange import ExchangeRate
    from .commons.exchange import ReadExchangeRates
    from .commons.exchange import ExchangeRateType
    from .commons.exchange import ExchangeRateDirection
    from .commons.exchange import ExchangeRateSource
    from .commons.exchange import ExchangeRateTarget
    from .commons.exchange import ExchangeRateDate
    from .commons.exchange import ExchangeRateValue
    from .commons.exchange import ExchangeRateProvider


# Generated at 2022-06-18 02:34:29.509288
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:41.050184
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    ## Define a dummy implementation of the algebra:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A1"): Balance(period.since, Quantity(Decimal(100))),
            Account("A2"): Balance(period.since, Quantity(Decimal(200))),
        }

    ## Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:34:50.222761
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .generic import Balance
    from .commons import Direction

    # Initialize test data
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:34:59.871706
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:35:10.885550
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .generic import Balance

    # Define some accounts:
    cash = Account("Cash", AccountType.ASSET)
    sales = Account("Sales", AccountType.REVENUE)
    costs = Account("Costs", AccountType.EXPENSE)
    tax = Account("Tax", AccountType.EXPENSE)
    equity = Account("Equity", AccountType.EQUITY)

    # Define some transactions:
    t1 = Transaction("Sale", datetime.date(2019, 1, 1), [Posting(cash, Amount(100)), Posting(sales, Amount(100))])

# Generated at 2022-06-18 02:35:21.027654
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Initial balances:
    initial_balances = {
        Account("1010"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
        Account("1020"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
        Account("1030"): Balance(date(2019, 1, 1), Quantity(Decimal(300))),
    }

    # Journal entries:

# Generated at 2022-06-18 02:35:37.094478
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:35:47.956484
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import Transaction
    from .units import Unit
    from .values import Value

    ## Define some accounts:
    cash = Account(AccountType.ASSET, "Cash")
    sales = Account(AccountType.REVENUE, "Sales")
    sales_tax = Account(AccountType.LIABILITY, "Sales Tax")
    inventory = Account(AccountType.ASSET, "Inventory")
    cost_of_goods_sold = Account(AccountType.EXPENSE, "Cost of Goods Sold")

    ## Define some initial balances:
    initial_balances = {cash: Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))}

    ## Def

# Generated at 2022-06-18 02:35:55.985692
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:36:07.212682
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry
    from .generic import Balance
    from .ledgers import build_general_ledger, Ledger, LedgerEntry

    # Test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:36:16.253931
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedger
    from .journaling import ReadJournalEntries

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:36:26.523830
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a mock implementation of the algebra:
    def _read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
        }


# Generated at 2022-06-18 02:36:35.026783
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import build_general_ledger, Ledger, LedgerEntry, GeneralLedger
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from datetime import date
    from decimal import Decimal
    import pytest
    from typing import Dict, Iterable, List, Optional, Protocol, TypeVar
    from dataclasses import dataclass, field
    _T = TypeVar("_T")
    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """
        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"
        #:

# Generated at 2022-06-18 02:36:43.591113
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(100)))
    ledger = Ledger(account, initial)

    # Create a posting
    date = Date(2019, 1, 1)
    journal = Journal(date, "Test")
    posting = Posting(journal, account, Amount(Decimal(100)), True)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(200))

# Generated at 2022-06-18 02:36:52.824965
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .general_ledger import GeneralLedger, GeneralLedgerProgram, build_general_ledger, compile_general_ledger_program
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from datetime import datetime
    from decimal import Decimal
    from typing import Dict, List, Optional
    import pytest

    # Defines a generic type variable.
    _T = TypeVar("_T")

    # Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Initial balances:

# Generated at 2022-06-18 02:37:02.885912
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1"): Balance(period.since, Quantity(Decimal(0))),
            Account("2"): Balance(period.since, Quantity(Decimal(0))),
            Account("3"): Balance(period.since, Quantity(Decimal(0))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:37:49.408857
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(100)))

    # Add posting to ledger
    ledger.add(posting)

    # Check if posting was added to ledger
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].balance == Quantity(Decimal(100))


# Generated at 2022-06-18 02:37:56.668603
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a test account:
    account = Account("Test Account", AccountType.ASSET)

    # Define a test posting:
    posting = Posting(account, Amount(Decimal(100)), Quantity(Decimal(100)))

    # Define a test journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", [posting])

    # Define a test period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))

    # Define a test initial balance:

# Generated at 2022-06-18 02:38:04.582483
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances.
    initial_balances = {
        Account("10100", "Cash"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(100))),
        Account("10200", "Bank"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(200))),
    }

    #: Journal entries.

# Generated at 2022-06-18 02:38:14.719471
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    ## Create a ledger:
    ledger = Ledger(Account("A"), Balance(Date(2019, 1, 1), Quantity(0)))

    ## Create a journal:
    journal = Journal(Date(2019, 1, 1), "Test")

    ## Create a posting:
    posting = Posting(journal, Account("A"), Amount(100))

    ## Add the posting to the ledger:
    entry = ledger.add(posting)

    ## Check the ledger entry:
    assert entry.balance == Quantity(100)
    assert entry.amount == Amount(100)
    assert entry.is_debit
    assert not entry.is_credit
    assert entry.debit == Amount(100)
    assert entry.credit is None

# Generated at 2022-06-18 02:38:26.977340
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger

    # Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account("Assets:Cash"), amount=Decimal("100.00"), direction=Posting.Direction.DEBIT),
            Posting(account=Account("Income:Sales"), amount=Decimal("100.00"), direction=Posting.Direction.CREDIT),
        ],
    )

    # Define a general ledger:

# Generated at 2022-06-18 02:38:28.098661
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:38.835697
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of ReadInitialBalances
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A1"): Balance(period.since, Quantity(Decimal(100))),
            Account("A2"): Balance(period.since, Quantity(Decimal(200))),
        }

    # Define a dummy implementation of ReadJournalEntries

# Generated at 2022-06-18 02:38:45.608458
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import ReadInitialBalances, GeneralLedgerProgram, build_general_ledger, compile_general_ledger_program
    from .types import Transaction
    from .units import Unit
    from .users import User

    # Define a test transaction type:
    class TestTransaction(Transaction):
        pass

    # Define a test unit:
    class TestUnit(Unit):
        pass

    # Define a test user:
    class TestUser(User):
        pass

    # Define a test

# Generated at 2022-06-18 02:38:53.887256
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting

    ## Create a ledger:
    ledger = Ledger(Account(AccountType.ASSET, "A"), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    ## Create a journal:
    journal = Journal(Date(2020, 1, 1), "Test")

    ## Create a posting:
    posting = Posting(journal, Account(AccountType.ASSET, "A"), Quantity(Decimal(100)))

    ## Add the posting to the ledger:
    entry = ledger.add(posting)

    ## Check the ledger entry:
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:39:02.899503
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define some accounts:
    a1 = Account("A1")
    a2 = Account("A2")
    a3 = Account("A3")
    a4 = Account("A4")
    a5 = Account("A5")

    ## Define some initial balances:
    initial_balances = {a1: Balance(period.since, Quantity(Decimal(100))), a2: Balance(period.since, Quantity(Decimal(200)))}

    ## Define some journal entries:
    journal_ent

# Generated at 2022-06-18 02:40:26.785400
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import build_journal_entry, Posting, ReadJournalEntries
    from .accounts import Account, AccountType, AccountClass, AccountSubclass, AccountGroup, AccountCategory


# Generated at 2022-06-18 02:40:36.296983
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class TestReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("1020", "Bank"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
            }

    read_initial_balances = TestReadInitialBalances()

# Generated at 2022-06-18 02:40:44.336165
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Journal entries:
    JournalEntries = List[JournalEntry[_T]]

    #: Read initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("100"): Balance(period.since, Quantity(Decimal(100))),
            Account("200"): Balance(period.since, Quantity(Decimal(200))),
        }

    #: Read journal entries:

# Generated at 2022-06-18 02:40:51.987764
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import date_range
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, read_journal_entries
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, InitialBalances, Ledger, LedgerEntry
    from .types import Transaction

    # Define a transaction type:
    class Transaction(Transaction):
        pass

    # Define a transaction: