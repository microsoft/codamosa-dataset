

# Generated at 2022-06-18 02:31:14.563684
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass
    class JournalEntry1(JournalEntry):
        """
        A journal entry.
        """

        #: Description of the journal entry.
        description: str

        #: Postings of the journal entry.
        postings: List[Posting]

    # Define a posting:
    @dataclass
    class Posting1(Posting):
        """
        A posting.
        """

        #: Account of the posting.
        account: Account

        #: Amount of the posting.
        amount: Amount

# Generated at 2022-06-18 02:31:22.992446
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, ReadJournalEntries
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .commons.algebra import Algebra
    from .commons.algebra import AlgebraicFunction
    from .commons.algebra import AlgebraicOperation
    from .commons.algebra import AlgebraicProgram
    from .commons.algebra import AlgebraicType
    from .commons.algebra import AlgebraicTypeConstructor
    from .commons.algebra import AlgebraicTypeDeconstructor
    from .commons.algebra import AlgebraicTypeMember
    from .commons.algebra import AlgebraicTypeOperator

# Generated at 2022-06-18 02:31:30.959594
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .numbers import Amount, Quantity

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:31:40.107898
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define initial balances:

# Generated at 2022-06-18 02:31:48.365485
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program

    ## Define a test account:
    account = Account("Test")

    ## Define a test period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define a test initial balance:
    initial_balance = Balance(period.since, Quantity(Decimal(0)))

    ## Define a test journal entry:

# Generated at 2022-06-18 02:31:55.275762
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger, compile_general_ledger_program

    # Define a dummy read initial balances algebra.
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
            Account("C"): Balance(period.since, Quantity(Decimal(300))),
        }

    # Define a dummy read journal entries algebra.

# Generated at 2022-06-18 02:32:05.084394
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry

    # Define the accounting period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    # Define the initial balances:

# Generated at 2022-06-18 02:32:15.817000
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from ..journaling.models import JournalEntry
    from ..journaling.types import Posting
    from .accounts import Account
    from .algebra import ReadInitialBalances
    from .generic import Balance
    from .journaling import Posting
    from .types import GeneralLedger, Ledger, LedgerEntry
    from .utils import compile_general_ledger_program

    # Define a dummy implementation of the algebra:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}


# Generated at 2022-06-18 02:32:16.590121
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:27.666076
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020"): Balance(period.since, Quantity(Decimal(200))),
            Account("1030"): Balance(period.since, Quantity(Decimal(300))),
        }


# Generated at 2022-06-18 02:32:39.122651
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry
    from .types import Transaction

    ## Define a transaction type:
    class Transaction(Transaction):
        pass

    ## Define a read initial balances algebra:

# Generated at 2022-06-18 02:32:50.639120
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(200))),
        }


# Generated at 2022-06-18 02:33:01.682596
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram
    from .types import Balance, DateRange, Quantity

    ## Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:33:11.230936
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a ledger
    account = Account("A", "A")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    # Create a posting
    date = datetime.date(2020, 1, 1)
    amount = Amount(Decimal(100))
    journal = JournalEntry(date, "J", [Posting(date, amount, account)])
    posting = journal.postings[0]
    # Add the posting to the ledger
    entry = ledger.add(posting)
    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100))
    assert entry.date == date
    assert entry.description == "J"

# Generated at 2022-06-18 02:33:18.996231
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("Assets", "Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account("Assets", "Accounts receivable"): Balance(period.since, Quantity(Decimal(200))),
            Account("Liabilities", "Accounts payable"): Balance(period.since, Quantity(Decimal(300))),
            Account("Equity", "Retained earnings"): Balance(period.since, Quantity(Decimal(400))),
        }

    # Define a dummy implementation of

# Generated at 2022-06-18 02:33:29.217371
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    #: Initial balances as of the end of previous financial period:

# Generated at 2022-06-18 02:33:37.018167
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting, Direction
    from .accounts import Account
    from .generic import Balance

    account = Account("Test Account")
    initial = Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    journal = Journal(datetime.date(2019, 1, 1), "Test Journal")
    posting = Posting(journal, account, Direction.DEBIT, Quantity(Decimal(100)))
    ledger.add(posting)
    assert ledger.entries[0].balance == Quantity(Decimal(100))
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].ledger == ledger
    assert ledger.entries[0].date == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 02:33:45.501087
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:33:55.638672
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons import DateRange

    # Define the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}


# Generated at 2022-06-18 02:33:56.467495
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:03.512962
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:14.234415
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account(code="1000", name="Cash"): Balance(period.since, Quantity(Decimal(1000))),
            Account(code="2000", name="Accounts Receivable"): Balance(period.since, Quantity(Decimal(2000))),
            Account(code="3000", name="Inventory"): Balance(period.since, Quantity(Decimal(3000))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:34:26.859568
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction

    # Define a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test transaction",
        postings=[
            Posting(
                account=Account(code="1010", name="Cash", type=AccountType.ASSET),
                amount=Decimal("100.00"),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account(code="1020", name="Bank", type=AccountType.ASSET),
                amount=Decimal("100.00"),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )

    # Define a

# Generated at 2022-06-18 02:34:34.730491
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Balance, Quantity
    from .accounts import Account
    from .generic import Balance

    @dataclass
    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return {
                Account("A1"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("A2"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
            }


# Generated at 2022-06-18 02:34:46.153937
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a test account:
    account = Account("Test", AccountType.ASSET)

    ## Define a test initial balance:
    initial_balance = Balance(DateRange.since(datetime.date(2019, 1, 1)), Quantity(Decimal(100)))

    ## Define a test journal entry:

# Generated at 2022-06-18 02:34:53.601316
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .generic import Balance

    # Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    initial_balances = {
        Account("1010"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(100))),
        Account("1020"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(200))),
    }

# Generated at 2022-06-18 02:35:01.999461
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, PostingDirection

    ## Create a ledger:
    ledger = Ledger(Account("1010", "Cash"), Balance(Date(2020, 1, 1), Quantity(Decimal(100))))

    ## Create a journal:
    journal = Journal(Date(2020, 1, 1), "Test journal")

    ## Create a posting:
    posting = Posting(journal, Account("1010", "Cash"), PostingDirection.DEBIT, Quantity(Decimal(10)))

    ## Add the posting to the ledger:
    ledger.add(posting)

    ## Check the ledger entry:
    assert ledger.entries[0].balance == Quantity(Decimal(110))


# Generated at 2022-06-18 02:35:02.880042
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:35:12.035574
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .types import Transaction

    ## Define a dummy transaction:
    transaction = Transaction("Dummy transaction")

    ## Define a dummy account:
    account = Account("Dummy account")

    ## Define a dummy initial balance:
    initial_balance = Quantity(Decimal(0))

    ## Define a dummy journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Dummy journal entry", [Posting(transaction, account, Amount(Decimal(1)))])

    ## Define a dummy period:

# Generated at 2022-06-18 02:35:21.506284
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a new account
    account = Account("1", "Test Account")
    # Create a new ledger
    ledger = Ledger(account, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    # Create a new posting
    posting = Posting(datetime.date(2020, 1, 1), Quantity(Decimal(100)), account)
    # Add the posting to the ledger
    ledger.add(posting)
    # Check if the ledger has one entry
    assert len(ledger.entries) == 1
    # Check if the ledger has the correct balance
    assert ledger.entries[0].balance == Quantity(Decimal(100))
    # Create a new posting
    posting = Posting(datetime.date(2020, 1, 1), Quantity(Decimal(100)), account)
    # Add the posting

# Generated at 2022-06-18 02:35:42.133357
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    @dataclass
    class TestReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010"): Balance(date(2020, 1, 1), Quantity(Decimal("100.00"))),
                Account("1020"): Balance(date(2020, 1, 1), Quantity(Decimal("200.00"))),
            }


# Generated at 2022-06-18 02:35:52.622984
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:35:59.661925
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting, JournalEntry
    from .ledgers import ReadInitialBalances, build_general_ledger, GeneralLedger

    # Define a test account:
    account = Account("Test Account")

    # Define a test initial balance:
    initial_balance = Balance(date(2020, 1, 1), Quantity(Decimal(100)))

    # Define a test period:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

    # Define a test posting:

# Generated at 2022-06-18 02:36:09.961727
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances, build_general_ledger, compile_general_ledger_program
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account
    from .generic import Balance
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal
   

# Generated at 2022-06-18 02:36:20.116763
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a ledger
    account = Account("Test Account")
    initial = Balance(Date(2020, 1, 1), Quantity(0))
    ledger = Ledger(account, initial)

    # Create a posting
    date = Date(2020, 1, 1)
    journal = Journal(date, "Test Journal")
    direction = Direction.DEBIT
    amount = Amount(1)
    posting = Posting(journal, account, direction, amount)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger
    assert ledger.entries[0].date == date
    assert ledger.entries[0].description == "Test Journal"

# Generated at 2022-06-18 02:36:29.012623
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a test implementation of the algebra:
    class TestReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(0))),
                Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(0))),
            }

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:36:39.959609
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define the test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:36:47.327019
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, InitialBalances, Ledger

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define initial balances:

# Generated at 2022-06-18 02:36:56.955606
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:37:05.541237
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [
            JournalEntry(
                period.since,
                "Dummy",
                [
                    Posting(Account("A"), period.since, Quantity(Decimal(100)), "Dummy"),
                    Posting(Account("B"), period.since, Quantity(Decimal(100)), "Dummy"),
                ],
            )
        ]

    ## Compile the program:


# Generated at 2022-06-18 02:37:49.621142
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define test data
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))
    account = Account("1010", "Cash")
    initial_balance = Balance(date(2018, 12, 31), Quantity(Decimal(100)))
    journal_entry = JournalEntry(date(2019, 1, 1), "Cash deposit", [
        Posting(account, Quantity(Decimal(100)), True),
        Posting(Account("1020", "Bank"), Quantity(Decimal(100)), False),
    ])

    # Define test implementation

# Generated at 2022-06-18 02:37:56.817860
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger
    from .journaling import ReadJournalEntries
    from .ledgers import GeneralLedgerProgram

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:38:04.630969
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:38:14.763213
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry
    from .journaling import ReadJournalEntries
    from .accounts import ReadAccounts
    from .generic import ReadBalances
    from .ledgers import ReadInitialBalances
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType

# Generated at 2022-06-18 02:38:26.983832
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, read_initial_balances

    ## Define a program which builds a general ledger.
    program = compile_general_ledger_program(read_initial_balances, ReadJournalEntries)

    ## Define a period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Build a general ledger.
    general_ledger = program(period)

    ## Verify the general ledger.
    assert isinstance(general_ledger, GeneralLedger)
    assert general_ledger.period == period

# Generated at 2022-06-18 02:38:38.183691
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a program which builds a general ledger:
    def _program(period: DateRange) -> GeneralLedger[str]:
        ## Get initial balances as of the end of previous financial period:
        initial_balances = {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
            Account("C"): Balance(period.since, Quantity(Decimal(300))),
            Account("D"): Balance(period.since, Quantity(Decimal(400))),
        }

        ## Read journal entries and post each of them:

# Generated at 2022-06-18 02:38:39.407398
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:45.632484
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a ledger
    ledger = Ledger(Account("A"), Balance(Date(2019, 1, 1), Quantity(Decimal(0))))

    # Create a posting
    posting = Posting(Journal(Date(2019, 1, 1), "Test", [Posting(Account("A"), Direction.Debit, Quantity(Decimal(1)))]),
                      Account("A"), Direction.Debit, Quantity(Decimal(1)))

    # Add the posting to the ledger
    ledger_entry = ledger.add(posting)

    # Check the ledger entry
    assert ledger_entry.ledger == ledger
    assert ledger_entry.posting == posting
    assert ledger_entry.balance == Quantity(Decimal(1))

# Generated at 2022-06-18 02:38:46.521588
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:47.951627
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    pass

# Generated at 2022-06-18 02:40:07.429303
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(100)), 1)

    # Add the posting to the ledger
    ledger_entry = ledger.add(posting)

    # Check the ledger entry
    assert ledger_entry.ledger == ledger
    assert ledger_entry.posting == posting

# Generated at 2022-06-18 02:40:16.235790
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("TestAccount")
    initial = Balance(Date(2020, 1, 1), Quantity(0))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(Journal("TestJournal", Date(2020, 1, 1), "TestDescription"), account, Quantity(100), True)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entries
    assert len(ledger.entries) == 1
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].balance == Quantity(100)


# Generated at 2022-06-18 02:40:21.577079
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance

    class ReadInitialBalancesMock(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(1000))),
                Account("1020", "Bank"): Balance(date(2020, 1, 1), Quantity(Decimal(2000))),
            }


# Generated at 2022-06-18 02:40:28.030040
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import GeneralLedger, Ledger, LedgerEntry, ReadInitialBalances, build_general_ledger, compile_general_ledger_program
    from .types import Transaction
    from .units import Unit

    # Define a dummy transaction type:
    class DummyTransaction(Transaction):
        pass

    # Define a dummy unit type:
    class DummyUnit(Unit):
        pass

    # Define a dummy read journal entries algebra:

# Generated at 2022-06-18 02:40:37.607694
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("1020", "Bank"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
            }


# Generated at 2022-06-18 02:40:45.446804
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    #: Initial balances:

# Generated at 2022-06-18 02:40:51.691849
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .numbers import Amount, Quantity

    ## Define a test transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test transaction",
        postings=[
            Posting(Account(AccountType.ASSET, "Cash"), Amount(100)),
            Posting(Account(AccountType.EXPENSE, "Rent"), Amount(-100)),
        ],
    )

    ## Build a general ledger:

# Generated at 2022-06-18 02:41:00.405476
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2019, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(1)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entry
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].balance == Quantity(Decimal(1))
