

# Generated at 2022-06-18 02:31:07.656334
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedgerProgram, GeneralLedger
    from .transactions import Transaction

    # Define a stub implementation of the algebra:

# Generated at 2022-06-18 02:31:15.707831
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from .journaling import JournalEntry, Posting, Journal
    from .accounts import Account, AccountType

    # Define accounts
    a1 = Account(1, "Cash", AccountType.ASSET)
    a2 = Account(2, "Accounts Receivable", AccountType.ASSET)
    a3 = Account(3, "Inventory", AccountType.ASSET)
    a4 = Account(4, "Accounts Payable", AccountType.LIABILITY)
    a5 = Account(5, "Common Stock", AccountType.EQUITY)
    a6 = Account(6, "Retained Earnings", AccountType.EQUITY)
    a7 = Account(7, "Sales", AccountType.REVENUE)

# Generated at 2022-06-18 02:31:16.595011
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:17.507476
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:24.843168
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from datetime import date

    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:31:31.981525
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .commons.types import Transaction

    # Define a transaction type:
    class Transaction(Transaction):
        pass

    # Define a read journal entries algebra:
    class ReadJournalEntries(ReadJournalEntries[Transaction]):
        def __init__(self, journal_entries: List[JournalEntry[Transaction]]):
            self.journal_entries = journal_entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[Transaction]]:
            return self.journal_entries

    # Define a read initial balances algebra:

# Generated at 2022-06-18 02:31:32.943632
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:34.539186
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:44.564478
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:31:53.488240
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import ReadInitialBalances, GeneralLedgerProgram, build_general_ledger
    from .ledgers import compile_general_ledger_program

    # Define a dummy implementation of ReadInitialBalances

# Generated at 2022-06-18 02:32:07.498283
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry, build_general_ledger
    from .accounting import compile_general_ledger_program

    # Initialize the accounts
    a = Account("A")
    b = Account("B")
    c = Account("C")
    d = Account("D")
    e = Account("E")
    f = Account("F")
    g = Account("G")
    h = Account("H")
    i = Account("I")
    j = Account("J")
    k = Account("K")
    l = Account("L")
    m = Account("M")
    n = Account("N")
    o = Account

# Generated at 2022-06-18 02:32:16.639670
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .journaling import Posting
    from .accounts import AccountType
    from .accounts import AccountDirection
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountSubGroup
    from .accounts import AccountSubSubGroup
    from .accounts import AccountSubSubSubGroup
    from .accounts import AccountSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSub

# Generated at 2022-06-18 02:32:27.700445
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .journaling import Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .journaling import Posting
    from .accounts import Account
    from .generic import Balance

# Generated at 2022-06-18 02:32:36.369843
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .ledgers import Ledger, LedgerEntry
    from .ledgers import build_general_ledger
    from .ledgers import compile_general_ledger_program
    from .ledgers import GeneralLedger
    from .ledgers import InitialBalances
    from .ledgers import ReadInitialBalances
    from .ledgers import ReadJournalEntries
    from .ledgers import GeneralLedgerProgram
    from .ledgers import Ledger
    from .ledgers import LedgerEntry
    from .ledgers import build_general_ledger
    from .ledgers import compile_general_ledger

# Generated at 2022-06-18 02:32:44.601208
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .money import Money
    from .quantity import Quantity
    from .zeitgeist import Date
    from ..commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import Ledger, build_general_ledger, GeneralLedger
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account
    from .money import Money
    from .quantity import Quantity
    from .zeitgeist import Date
    from ..commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import Ledger, build_general_ledger, GeneralLedger
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account

# Generated at 2022-06-18 02:32:53.469618
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .generic import Balance

    # Define a date range:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Define accounts:
    cash = Account("Cash")
    revenue = Account("Revenue")
    expenses = Account("Expenses")

    # Define initial balances:
    initial_balances = {cash: Balance(period.since, Quantity(Decimal(100)))}

    # Define journal entries:

# Generated at 2022-06-18 02:33:03.489816
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger
    from .types import Balance, DateRange, Quantity

    ## Define test data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:33:11.921560
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, InitialBalances, LedgerEntry, Ledger
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    initial_balances = {
        Account("100"): Balance(period.since, Quantity(Decimal(0))),
        Account("200"): Balance(period.since, Quantity(Decimal(0))),
        Account("300"): Balance(period.since, Quantity(Decimal(0))),
    }

# Generated at 2022-06-18 02:33:22.559443
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:33:32.281070
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2019, 1, 1), Quantity(Decimal(1000))),
                Account("1020", "Bank"): Balance(date(2019, 1, 1), Quantity(Decimal(2000))),
            }


# Generated at 2022-06-18 02:33:56.495858
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Define a test period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define test accounts:
    a1 = Account("A1")
    a2 = Account("A2")
    a3 = Account("A3")
    a4 = Account("A4")

    ## Define test journal entries:
    j1 = JournalEntry(datetime.date(2019, 1, 1), "J1", [Posting(a1, 1), Posting(a2, -1)])

# Generated at 2022-06-18 02:34:06.431742
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    ## Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:34:16.231125
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a function which returns initial balances.

# Generated at 2022-06-18 02:34:28.075000
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a mock implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020"): Balance(period.since, Quantity(Decimal(200))),
        }

    # Define a mock implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:34:35.529472
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances.
    initial_balances = {
        Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(1000))),
        Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(2000))),
    }

    #: Journal entries.

# Generated at 2022-06-18 02:34:41.313476
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting, ReadJournalEntries
    from .accounts import Account, AccountType
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .commons.types import Direction
    from .commons.types import Currency
    from .commons.types import Unit
    from .commons.types import UnitType
    from .commons.types import UnitPrefix
    from .commons.types import UnitSystem
    from .commons.types import UnitCategory
    from .commons.types import UnitConversion
    from .commons.types import UnitConversionTable
    from .commons.types import UnitConversionTableEntry
    from .commons.types import UnitConversionTableEntryType
    from .commons.types import UnitCon

# Generated at 2022-06-18 02:34:50.320845
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances.
    initial_balances = {
        Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(100))),
        Account("1020", "Accounts receivable"): Balance(period.since, Quantity(Decimal(200))),
        Account("1030", "Inventory"): Balance(period.since, Quantity(Decimal(300))),
    }

    #: Journal entries.

# Generated at 2022-06-18 02:34:59.871878
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry
    from .types import TransactionType
    from ..commons.zeitgeist import DateRange
    from decimal import Decimal
    from typing import Dict, Iterable, List, Optional, TypeVar
    from unittest import TestCase
    from unittest.mock import MagicMock, patch

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.

# Generated at 2022-06-18 02:35:10.912751
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance


# Generated at 2022-06-18 02:35:21.027268
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a test account:
    account = Account("Test", AccountType.ASSET)

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(account, Amount(100), Quantity(100)),
            Posting(account, Amount(100), Quantity(-100)),
        ],
    )

    # Define a test initial balance:
    initial_balance = {account: Quantity(100)}

    # Define a test period:

# Generated at 2022-06-18 02:35:54.461214
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A", "Assets"): Balance(period.since, Quantity(Decimal(100))),
            Account("L", "Liabilities"): Balance(period.since, Quantity(Decimal(200))),
            Account("E", "Equity"): Balance(period.since, Quantity(Decimal(300))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:36:05.135964
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Initialize test data
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:36:14.395252
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .journaling import Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .journaling import Posting
    from .accounts import Account
    from .generic import Balance

# Generated at 2022-06-18 02:36:24.833283
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy read_initial_balances algebra implementation:

# Generated at 2022-06-18 02:36:25.723397
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:33.316938
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the function compile_general_ledger_program.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    ## Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:36:38.714021
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount
    from .commons.zeitgeist import DateRange
    from .commons.types import Direction
    from .commons.types import AccountType
    from .commons.types import BalanceType
    from .commons.types import QuantityType
    from .commons.types import AmountType
    from .commons.types import JournalEntryType
    from .commons.types import PostingType
    from .commons.types import LedgerEntryType
    from .commons.types import LedgerType
    from .commons.types import GeneralLedgerType
    from .commons.types import ReadInitialBalancesType
    from .commons.types import GeneralLedgerProgramType

# Generated at 2022-06-18 02:36:46.861755
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:36:56.549220
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry

    ## Define the accounting period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define initial balances:

# Generated at 2022-06-18 02:37:05.395074
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:37:50.208492
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .general_ledger import GeneralLedger, Ledger, LedgerEntry
    from .general_ledger import compile_general_ledger_program
    from .general_ledger import build_general_ledger
    from .general_ledger import InitialBalances
    from .journaling import ReadJournalEntries
    from .generic import ReadInitialBalances
    from datetime import date
    import unittest

    # Define a dummy implementation of ReadJournalEntries

# Generated at 2022-06-18 02:38:00.225991
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define the period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))

    ## Define the initial balances:

# Generated at 2022-06-18 02:38:01.106187
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:12.000066
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting, ReadJournalEntries
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from . import accounts, journaling, generic, commons
    import datetime
    from decimal import Decimal
    from typing import Dict, List, Optional, Iterable
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from . import accounts, journaling, generic, commons
    import datetime
    from decimal import Decimal
    from typing import Dict, List, Optional, Iterable

# Generated at 2022-06-18 02:38:19.696635
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a dummy implementation of the algebra:
    class DummyReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("A", "A", "A", "A"): Balance(date(2019, 1, 1), Decimal(1)),
                Account("B", "B", "B", "B"): Balance(date(2019, 1, 1), Decimal(2)),
                Account("C", "C", "C", "C"): Balance(date(2019, 1, 1), Decimal(3)),
            }

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:38:20.253656
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:21.444422
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:29.729891
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import Balance, DateRange, Quantity

    # Define a dummy read_initial_balances function:

# Generated at 2022-06-18 02:38:39.192051
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .types import Transaction

    ## Define a transaction type:
    class Transaction(Transaction):
        pass

    ## Define a read initial balances algebra:

# Generated at 2022-06-18 02:38:45.631464
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a test account
    account = Account(1, 'Test Account')
    # Create a test balance
    balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    # Create a test ledger
    ledger = Ledger(account, balance)
    # Create a test journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), 'Test Journal Entry')
    # Create a test posting
    posting = Posting(journal, account, Amount(Decimal(100)))
    # Add the posting to the ledger
    entry = ledger.add(posting)
    # Check that the balance of the ledger entry is correct
    assert entry.balance == Quantity(Decimal(100))
    # Check that the balance of the ledger is correct
    assert ledger._last_balance == Quantity(Decimal(100))
