

# Generated at 2022-06-18 02:31:06.433558
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    # Define the accounting period:
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

    # Define the initial balances:
    initial_balances = {
        Account("1110", "Cash"): Balance(period.since, Quantity(Decimal(100))),
        Account("1120", "Bank"): Balance(period.since, Quantity(Decimal(200))),
    }

    # Define the journal entries:

# Generated at 2022-06-18 02:31:15.039929
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType

    # Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(Account("1000", AccountType.ASSET), Amount(Decimal("100.00")), "debit"),
            Posting(Account("2000", AccountType.LIABILITY), Amount(Decimal("100.00")), "credit"),
        ],
    )

    # Define a read journal entries algebra implementation:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [journal_entry]

    # Define a read initial balances algebra implementation:

# Generated at 2022-06-18 02:31:23.253756
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import AccountCode, AccountName, Amount, Balance, Date, Quantity

    ## Define some accounts:
    a1 = Account(AccountCode("101"), AccountName("Cash"), AccountType.ASSET)
    a2 = Account(AccountCode("201"), AccountName("Accounts Receivable"), AccountType.ASSET)
    a3 = Account(AccountCode("301"), AccountName("Inventory"), AccountType.ASSET)
    a4 = Account(AccountCode("401"), AccountName("Prepaid Expenses"), AccountType.ASSET)
    a5 = Account(AccountCode("501"), AccountName("Land"), AccountType.ASSET)

# Generated at 2022-06-18 02:31:31.152964
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction, TransactionType
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from datetime import date

    # Create a transaction
    transaction = Transaction(
        TransactionType.SALE,
        date(2020, 1, 1),
        "Sale of goods",
        [
            Posting(Account(AccountType.ASSET, "Cash"), Amount(100), TransactionType.SALE),
            Posting(Account(AccountType.REVENUE, "Sales"), Amount(100), TransactionType.SALE),
        ],
    )

    # Create a journal entry
    journal_entry = JournalEntry(transaction)

    # Create a list of journal entries
    journal_

# Generated at 2022-06-18 02:31:40.283252
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:31:48.601848
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry
    from .commons import Direction
    from decimal import Decimal
    from datetime import date
    from dataclasses import dataclass, field
    from typing import Dict, Generic, Iterable, List, Optional, Protocol, TypeVar

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.

# Generated at 2022-06-18 02:31:55.475210
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define the algebra implementations:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}


# Generated at 2022-06-18 02:31:56.713631
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:05.935743
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

# Generated at 2022-06-18 02:32:15.945836
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, ReadInitialBalances, ReadJournalEntries
    from .types import Transaction

    ## Define a dummy transaction type:
    class DummyTransaction(Transaction):
        def __init__(self, id: int):
            self.id = id

    ## Define a dummy read initial balances algebra:

# Generated at 2022-06-18 02:32:30.601986
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:32:39.085482
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .journaling import ReadJournalEntries
    from .ledgers import ReadInitialBalances
    from datetime import date
    from typing import Dict, Iterable, List, Optional, TypeVar
    from unittest.mock import Mock

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.

# Generated at 2022-06-18 02:32:50.637870
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .ledgering import build_general_ledger

    # Define a period
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

    # Define initial balances

# Generated at 2022-06-18 02:33:01.683933
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances as of the end of previous financial period:

# Generated at 2022-06-18 02:33:02.623613
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:33:10.509612
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a journal
    journal = Journal(Date(2019, 1, 1), "Test journal")

    # Create a posting
    posting = Posting(journal, Direction.DEBIT, Account(1), Amount(100))

    # Create a ledger
    ledger = Ledger(Account(1), Balance(Date(2019, 1, 1), Quantity(0)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the result
    assert ledger.entries[0].balance == Quantity(100)

# Generated at 2022-06-18 02:33:11.333733
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:33:19.065315
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .algebras import ReadJournalEntries, ReadInitialBalances
    from .algebras.journaling import ReadJournalEntriesImpl
    from .algebras.generic import ReadInitialBalancesImpl

    ## Define a journal entry:

# Generated at 2022-06-18 02:33:29.282993
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .algebra import ReadInitialBalances

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("1010"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:33:37.064614
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("1234", "Test Account")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting

# Generated at 2022-06-18 02:33:57.043918
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program
    from .types import Balance, DateRange, Quantity
    from datetime import date
    from decimal import Decimal
    from typing import Dict

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:34:07.082696
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    # Define a dummy journal entry:
    @dataclass
    class DummyJournalEntry(JournalEntry):
        """
        Dummy journal entry.
        """

        #: Description of the journal entry.
        description: str

        #: Date of the journal entry.
        date: datetime.date

        #: Postings of the journal entry.
        postings: List[Posting]

    # Define a dummy posting:

# Generated at 2022-06-18 02:34:16.605195
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances as of the end of previous financial period:

# Generated at 2022-06-18 02:34:28.470395
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2020, 1, 1), "Cash received")
    posting = Posting(journal, account, Quantity(Decimal(100)), "debit")

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting

# Generated at 2022-06-18 02:34:35.858011
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange

    # Define the accounting period
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    # Define the journal entries

# Generated at 2022-06-18 02:34:46.435715
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance

    # Create a ledger
    account = Account(1, "TestAccount")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "TestJournal")

    # Create a posting
    posting = Posting(journal, account, Direction.DEBIT, Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check if the ledger has the posting
    assert ledger.entries[0].posting == posting


# Generated at 2022-06-18 02:34:53.742219
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgering import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgering import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances


# Generated at 2022-06-18 02:35:02.260918
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Cash deposit")

    # Create a posting
    posting = Posting(journal, account, Amount(Decimal(100)), True)

    # Add the posting to the ledger
    ledger_entry = ledger.add(posting)

    # Check the ledger entry
    assert ledger_entry.ledger == ledger
    assert ledger_entry.posting == posting
    assert ledger_entry.balance == Quantity(Decimal(100))
   

# Generated at 2022-06-18 02:35:11.712863
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger
    from .commons import Direction
    from decimal import Decimal

    # Create a journal entry
    journal = Journal(Date(2020, 1, 1), "Test journal")
    journal.add(Posting(Account("1000"), Decimal(100), Direction.Debit))
    journal.add(Posting(Account("2000"), Decimal(100), Direction.Credit))

    # Create a ledger
    ledger = Ledger(Account("1000"), Balance(Date(2020, 1, 1), Decimal(0)))

    # Add the journal entry to the ledger
    ledger.add(journal.postings[0])

    # Test the balance of the ledger
    assert ledger

# Generated at 2022-06-18 02:35:21.409329
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a function which reads initial balances:

# Generated at 2022-06-18 02:35:45.626192
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:35:51.058159
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity


# Generated at 2022-06-18 02:35:58.480215
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    # Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}


# Generated at 2022-06-18 02:36:08.764939
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .ledgering import Ledger, LedgerEntry, build_general_ledger, GeneralLedger
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .ledgering import Ledger, LedgerEntry, build_general_ledger, GeneralLedger
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity

# Generated at 2022-06-18 02:36:09.484604
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:10.050975
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:20.213331
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:36:21.207367
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:29.870087
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("Test Account")
    initial = Balance(Date(2018, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal("Test Journal", Date(2018, 1, 1), "Test Description")
    posting = Posting(journal, account, Direction.DEBIT, Quantity(Decimal(100)))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting

# Generated at 2022-06-18 02:36:36.687855
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:37:50.245629
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(1000))),
                Account("1020", "Bank"): Balance(date(2020, 1, 1), Quantity(Decimal(2000))),
            }

    read_initial_balances = ReadInitialBalancesImpl()

# Generated at 2022-06-18 02:38:00.270974
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances:

# Generated at 2022-06-18 02:38:10.539560
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry

    # Define a journal entry:
    journal_entry = JournalEntry(
        date(2020, 1, 1),
        "Test journal entry",
        [
            Posting(Account("A"), Amount(Decimal(100)), "Debit"),
            Posting(Account("B"), Amount(Decimal(100)), "Credit"),
        ],
    )

    # Define initial balances:

# Generated at 2022-06-18 02:38:18.744484
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity


# Generated at 2022-06-18 02:38:28.630872
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import Balance, Quantity

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:38:38.865739
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance


# Generated at 2022-06-18 02:38:45.610288
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:38:53.916381
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry
    from .journaling import ReadJournalEntries
    from .generic import ReadInitialBalances
    from .commons.zeitgeist import DateRange
    from datetime import date
    from typing import Dict, List
    from decimal import Decimal
    from unittest import TestCase


# Generated at 2022-06-18 02:38:58.905123
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:39:07.899376
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting

    ## Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account(code="1010", name="Cash"): Balance(period.since, Quantity(Decimal(1000))),
            Account(code="1020", name="Bank"): Balance(period.since, Quantity(Decimal(2000))),
        }

    ## Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:40:13.212958
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import Direction
    from .ledgers import build_general_ledger, LedgerEntry, Ledger

    # Define a journal entry

# Generated at 2022-06-18 02:40:18.410144
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgering import GeneralLedger, Ledger, ReadInitialBalances, build_general_ledger, compile_general_ledger_program
    from .reporting import Report, ReportLine, ReportLineType, ReportType, compile_report_program
    from .taxing import Tax, TaxType
    from .transacting import Transaction, TransactionType
    from .warehousing import Item, ItemType, Warehouse, WarehouseItem, WarehouseItemType, WarehouseType
    from .working import Worker, WorkerType
    from .working import compile_

# Generated at 2022-06-18 02:40:25.662609
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:40:35.579569
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection

    # Create a ledger
    account = Account("1", "Cash", AccountType.ASSET)
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(datetime.date(2020, 1, 1), "Test")
    posting = Posting(journal, account, PostingDirection.DEBIT, Amount(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger
    assert ledger.account == account
    assert ledger.initial == initial
    assert len(ledger.entries) == 1

# Generated at 2022-06-18 02:40:43.446936
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .accounts import Account
    from .journaling import JournalEntry, Post

# Generated at 2022-06-18 02:40:50.304724
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))