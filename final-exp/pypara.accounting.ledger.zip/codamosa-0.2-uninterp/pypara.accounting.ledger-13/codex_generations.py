

# Generated at 2022-06-18 02:31:06.367433
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a ledger
    ledger = Ledger(Account("1"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test")
    # Create a posting
    posting = Posting(journal_entry, Account("1"), Amount(Decimal(100)), 1)
    # Add the posting to the ledger
    ledger.add(posting)
    # Check if the ledger entry is added to the ledger
    assert ledger.entries[0].posting.account == Account("1")
    assert ledger.entries[0].posting.amount == Amount(Decimal(100))
    assert ledger.entries[0].posting.direction == 1

# Generated at 2022-06-18 02:31:12.778142
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a ledger
    ledger = Ledger(Account("1234"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    # Create a posting
    posting = Posting(datetime.date(2020, 1, 1), Account("1234"), Account("4321"), Quantity(Decimal(100)))
    # Add the posting to the ledger
    ledger.add(posting)
    # Check that the ledger has one entry
    assert len(ledger.entries) == 1
    # Check that the balance of the ledger is 100
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:31:22.184437
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a ledger
    account = Account(code="123", name="Test Account")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    # Create a posting
    posting = Posting(account, datetime.date(2020, 1, 1), Quantity(Decimal(100)), "Test Journal")
    # Add the posting to the ledger
    ledger.add(posting)
    # Check the ledger entry
    assert ledger.entries[0].balance == Quantity(Decimal(100))
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].ledger == ledger
    assert ledger.entries[0].date == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 02:31:30.739293
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances.

# Generated at 2022-06-18 02:31:39.967670
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import AccountType
    from .journaling import Journal, Posting, PostingDirection

    # Create a ledger
    account = Account("1", "Test", AccountType.ASSET)
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, account, PostingDirection.DEBIT, Quantity(Decimal(10)))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity

# Generated at 2022-06-18 02:31:48.271737
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry
    from .ledgering import build_general_ledger
    from .ledgering import compile_general_ledger_program
    from .journaling import ReadJournalEntries
    from .ledgering import ReadInitialBalances
    from .journaling import compile_journal_entry_program
    from .journaling import compile_posting_program
    from .journaling import compile_journal_program
    from .journaling import compile_journal_entry_program
    from .journaling import compile_posting_program
    from .journaling import compile_journal_program
    from .journaling import compile_journal_entry_program


# Generated at 2022-06-18 02:31:53.121703
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    ## Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    ## Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:32:03.273450
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account
    from .generic import Balance

    @dataclass
    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return {
                Account("A", "A"): Balance(date(2020, 1, 1), Decimal(100)),
                Account("B", "B"): Balance(date(2020, 1, 1), Decimal(200)),
            }


# Generated at 2022-06-18 02:32:14.489063
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class TestReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1", "Cash"): Balance(date(2020, 1, 1), Decimal(100)),
                Account("2", "Accounts Receivable"): Balance(date(2020, 1, 1), Decimal(200)),
                Account("3", "Inventory"): Balance(date(2020, 1, 1), Decimal(300)),
            }


# Generated at 2022-06-18 02:32:25.344773
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .ledgers import Ledger, LedgerEntry
    from .ledgers import build_general_ledger, compile_general_ledger_program
    from .ledgers import GeneralLedger, GeneralLedgerProgram
    from .ledgers import InitialBalances, ReadInitialBalances
    from .ledgers import ReadJournalEntries
    from .commons.zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Optional, Iterable
    from .journaling import JournalEntry, Posting
    from .accounts import Account
   

# Generated at 2022-06-18 02:32:43.468571
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, Transaction
    from .journaling.algebra import ReadJournalEntries
    from .journaling.algebra.memory import read_journal_entries
    from .journaling.algebra.memory import read_journal_entries_from_journal
    from .journaling.algebra.memory import read_journal_entries_from_transactions
    from .journaling.algebra.memory import read_journal_entries_from_postings
    from .journaling.algebra.memory import read_journal_entries_from_journal_entries
    from .journaling.algebra.memory import read_journal_entries_from_journal_entries_and_postings
    from .journaling.algebra.memory import read_journal_entries_from_

# Generated at 2022-06-18 02:32:52.929878
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import read_initial_balances, read_journal_entries

    ## Define a dummy journal entry:
    @dataclass
    class DummyJournalEntry(JournalEntry):
        pass

    ## Define a dummy posting:
    @dataclass
    class DummyPosting(Posting):
        pass

    ## Define a dummy account:
    @dataclass
    class DummyAccount(Account):
        pass

    ## Define a dummy balance:
    @dataclass
    class DummyBalance(Balance):
        pass

    ## Define a dummy initial balance:

# Generated at 2022-06-18 02:32:58.171833
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    account = Account("1234")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(Journal(Date(2020, 1, 1), "Test"), account, Quantity(Decimal(100)), 1)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100))
    assert entry.date == Date(2020, 1, 1)
    assert entry.description == "Test"


# Generated at 2022-06-18 02:33:08.917437
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program

    ## Define test data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:33:19.765674
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Create a journal entry
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(
                account=Account("1010", "Cash"),
                amount=Decimal(100),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account("1020", "Accounts Receivable"),
                amount=Decimal(100),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )

    # Create a period

# Generated at 2022-06-18 02:33:21.921560
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    pass

# Generated at 2022-06-18 02:33:31.632643
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    # Import packages:
    import datetime
    from decimal import Decimal
    from typing import Dict, List
    from unittest import TestCase, mock
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import (
        GeneralLedger,
        GeneralLedgerProgram,
        InitialBalances,
        Ledger,
        LedgerEntry,
        ReadInitialBalances,
        ReadJournalEntries,
        build_general_ledger,
        compile_general_ledger_program,
    )

    # Define test case class:

# Generated at 2022-06-18 02:33:37.648567
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection

    account = Account("Assets", "Cash", AccountType.ASSET)
    journal = Journal(Date(2020, 1, 1), "Opening balance", [Posting(account, PostingDirection.DEBIT, Amount(100))])
    posting = journal.postings[0]
    ledger = Ledger(account, Balance(Date(2020, 1, 1), Quantity(Decimal(0))))
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(100))
    assert ledger.entries[0] == entry
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:33:45.791136
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry

    # Create a ledger
    account = Account("1")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Direction.DEBIT, Quantity(Decimal(100)))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting

# Generated at 2022-06-18 02:33:51.599362
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import ReadJournalEntries
    from .ledgers import GeneralLedger, InitialBalances, ReadInitialBalances, build_general_ledger, compile_general_ledger_program
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account
    from .generic import Balance
    from .ledgers import GeneralLedger, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances, build_general_ledger, compile_general_ledger_program
    from .journaling import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:34:07.578520
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, build_journal_entry

    # Define a date range:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    # Define accounts:
    cash = Account("Cash", AccountType.ASSET)
    revenue = Account("Revenue", AccountType.REVENUE)
    expenses = Account("Expenses", AccountType.EXPENSE)

    # Define initial balances:
    initial_balances = {cash: Balance(period.since, Quantity(Decimal(1000)))}

    # Define journal entries:

# Generated at 2022-06-18 02:34:16.952015
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Direction

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test")
    # Create a posting
    posting = Posting(journal, Account(1), Direction.DEBIT, Amount(100))
    # Create a ledger
    ledger = Ledger(Account(1), Balance(Date(2020, 1, 1), Quantity(0)))
    # Add the posting to the ledger
    entry = ledger.add(posting)
    # Check the date of the entry
    assert entry.date == Date(2020, 1, 1)
    # Check the description of the entry
    assert entry.description

# Generated at 2022-06-18 02:34:28.743366
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity

# Generated at 2022-06-18 02:34:36.043763
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import build_journal_entry
    from .accounts import Account, AccountType

    # Define initial balances:
    initial_balances = {
        Account(AccountType.ASSET, "Cash"): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(100))),
        Account(AccountType.ASSET, "Accounts receivable"): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(200))),
        Account(AccountType.LIABILITY, "Accounts payable"): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(300))),
        Account(AccountType.EQUITY, "Capital"): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(400))),
    }

    # Define journal entries:
    journal

# Generated at 2022-06-18 02:34:46.953598
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry

    ## Define test data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    initial_balances = {
        Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(1000))),
        Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(2000))),
    }

# Generated at 2022-06-18 02:34:58.324673
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy read initial balances algebra:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A1"): Balance(period.since, Quantity(Decimal(100))),
            Account("A2"): Balance(period.since, Quantity(Decimal(200))),
        }

    ## Define a dummy read journal entries algebra:

# Generated at 2022-06-18 02:35:09.674354
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a ledger for account 'A' with initial balance of 0
    account = Account('A')
    initial = Balance(Date(2020, 1, 1), Quantity(0))
    ledger = Ledger(account, initial)

    # Create a journal entry with a debit posting to account 'A'
    journal = Journal(Date(2020, 1, 1), 'Test')
    journal.add(Posting(Direction.DEBIT, account, Quantity(100)))

    # Add the posting to the ledger
    ledger.add(journal.postings[0])

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(100)

    # Create a journal entry with a credit posting to account

# Generated at 2022-06-18 02:35:20.756864
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry, ReadInitialBalances

    ## Define a mock implementation of ReadInitialBalances:

# Generated at 2022-06-18 02:35:27.993802
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    # Define a mock implementation of ReadInitialBalances

# Generated at 2022-06-18 02:35:33.834531
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, InitialBalances, Ledger, LedgerEntry
    from .types import TransactionType

    # Define a dummy read_initial_balances algebra implementation:

# Generated at 2022-06-18 02:35:54.133764
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Setup
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    period = DateRange(date(2020, 1, 1), date(2020, 1, 31))

# Generated at 2022-06-18 02:36:04.737064
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance


# Generated at 2022-06-18 02:36:14.014426
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    ## Import modules under test:
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from .accounts import Account
    from .algebra import ReadInitialBalances
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, GeneralLedgerProgram, build_general_ledger, compile_general_ledger_program

    ## Define a dummy implementation of the algebra:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
        }

# Generated at 2022-06-18 02:36:24.359017
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define the test data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:36:32.352477
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction

    # Create a journal entry

# Generated at 2022-06-18 02:36:43.351450
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances.

# Generated at 2022-06-18 02:36:52.540166
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {Account(AccountType.ASSET, "1010"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:37:02.607616
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test transaction",
        postings=[
            Posting(Account(AccountType.ASSET, "Cash"), Amount(100)),
            Posting(Account(AccountType.EXPENSE, "Salaries"), Amount(-100)),
        ],
    )

    ## Define a journal entry:

# Generated at 2022-06-18 02:37:07.850062
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account("Assets", "Cash"), amount=Decimal(100), direction=Posting.Direction.DEBIT),
            Posting(account=Account("Expenses", "Rent"), amount=Decimal(100), direction=Posting.Direction.CREDIT),
        ],
    )

    ## Define initial balances:

# Generated at 2022-06-18 02:37:14.442085
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance

# Generated at 2022-06-18 02:37:51.466729
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:38:01.632962
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:38:13.239749
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy read initial balances function:

# Generated at 2022-06-18 02:38:24.962894
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    ## Import dependencies:
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List
    from .accounts import Account
    from .commons import Direction
    from .journaling import JournalEntry, Posting

    ## Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:38:26.003533
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"


# Generated at 2022-06-18 02:38:31.773558
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances, ReadJournalEntries

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
       

# Generated at 2022-06-18 02:38:34.243682
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:44.097382
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define the initial balances:

# Generated at 2022-06-18 02:38:52.561603
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define initial balances:
    initial_balances = {
        Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(1000))),
        Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(2000))),
    }

    ## Define journal entries:

# Generated at 2022-06-18 02:38:53.197066
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False


# Generated at 2022-06-18 02:39:58.140835
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger

    # Define a test period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Define test accounts:
    a = Account("A")
    b = Account("B")
    c = Account("C")
    d = Account("D")

    # Define test initial balances:
    initial_balances = {a: Balance(period.since, Quantity(Decimal(1000))), b: Balance(period.since, Quantity(Decimal(2000)))}

    # Define test journal entries:

# Generated at 2022-06-18 02:40:09.125763
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Initial balances:
    JournalEntries = List[JournalEntry[_T]]

    #: Initial balances:
    ReadInitialBalances = Callable[[DateRange], InitialBalances]

    #: Initial balances:
    ReadJournalEntries = Callable[[DateRange], JournalEntries]

    #: Initial balances:
    GeneralLedgerProgram = Callable[[DateRange], GeneralLedger[_T]]

    #: Initial balances:

# Generated at 2022-06-18 02:40:18.620716
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .generic import Balance

    # Define a journal entry:
    journal_entry = build_journal_entry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(Account("Assets", "Cash"), Amount(100), "Debit"),
            Posting(Account("Income", "Sales"), Amount(100), "Credit"),
        ],
    )

    # Define initial balances:

# Generated at 2022-06-18 02:40:25.849259
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .types import Debit, Credit
    from .units import Unit
    from .values import Value

    ## Create a dummy account:
    account = Account("Dummy", AccountType.ASSET)

    ## Create a dummy transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Dummy transaction",
        postings=[
            Posting(account, Debit, Value(Unit(Decimal(100), "USD"), Decimal(1))),
            Posting(account, Credit, Value(Unit(Decimal(100), "USD"), Decimal(1))),
        ],
    )

    ## Create a dummy journal entry:

# Generated at 2022-06-18 02:40:35.615603
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy initial balances reader:
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {Account(AccountType.ASSET, "1010", "Cash"): Balance(period.since, Quantity(Decimal(0)))}

    ## Define a dummy journal entries reader:

# Generated at 2022-06-18 02:40:43.173106
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    ledger = Ledger(Account("1"), Balance(Date(2018, 1, 1), Quantity(Decimal(0))))
    journal = Journal(Date(2018, 1, 1), "Test")
    journal.add(Posting(Account("1"), Amount(Decimal(100))))
    journal.add(Posting(Account("2"), Amount(Decimal(100))))
    ledger.add(journal.postings[0])
    assert ledger.entries[0].balance == Quantity(Decimal(100))
    ledger.add(journal.postings[1])
    assert ledger.entries[1].balance == Quantity(Decimal(0))


# Generated at 2022-06-18 02:40:50.174181
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .ledgers import build_general_ledger
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define the accounts:
    a1 = Account("A1", AccountType.ASSET)
    a2 = Account("A2", AccountType.ASSET)
    a3 = Account("A3", AccountType.ASSET)
    a4 = Account("A4", AccountType.ASSET)
    a5 = Account