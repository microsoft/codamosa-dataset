

# Generated at 2022-06-18 02:31:06.967593
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance

# Generated at 2022-06-18 02:31:07.995904
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:16.000910
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List

    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:31:23.949431
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import ReadJournalEntries, ReadInitialBalances

    ## Define a dummy read_initial_balances algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020"): Balance(period.since, Quantity(Decimal(200))),
        }

    ## Define a dummy read_journal_entries algebra:

# Generated at 2022-06-18 02:31:31.487440
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries
    from .accounts import Account, AccountType, ReadAccounts
    from .accounts import ReadInitialBalances
    from .journaling import JournalEntry
    from .journaling import Posting
    from .journaling import PostingDirection
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType
    from .journaling import PostingType

# Generated at 2022-06-18 02:31:40.340479
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a dummy implementation of ReadInitialBalances
    class DummyReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy implementation of ReadJournalEntries

# Generated at 2022-06-18 02:31:48.591943
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance

# Generated at 2022-06-18 02:31:55.474495
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(1000)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2019, 1, 2), "Purchase", [
        Posting(account, Direction.DEBIT, Quantity(Decimal(100))),
        Posting(Account(2, "Inventory"), Direction.CREDIT, Quantity(Decimal(100)))
    ])

    # Add a posting to the ledger
    posting = journal.postings[0]
    ledger.add(posting)

    # Assert the ledger entry
   

# Generated at 2022-06-18 02:31:56.713749
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True


# Generated at 2022-06-18 02:32:05.952275
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("1010", "Cash")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting

# Generated at 2022-06-18 02:32:17.623293
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import JournalEntry, Posting, Direction
    from .generic import Balance
    from .ledgering import LedgerEntry, Ledger, GeneralLedger

    ## Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:32:28.167550
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from typing import List
    from unittest import TestCase, mock
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, ReadInitialBalances, ReadJournalEntries

    class TestCase(TestCase):
        def test_GeneralLedgerProgram___call__(self):
            # Arrange:
            period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:32:36.636524
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests :py:meth:`GeneralLedgerProgram.__call__`.
    """
    from datetime import date
    from decimal import Decimal
    from typing import Callable
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a mock implementation of the algebra:
    read_initial_balances: Callable[[DateRange], Dict[Account, Balance]] = Mock()
    read_journal_entries: Callable[[DateRange], Iterable[JournalEntry]] = Mock()

    ## Define the accounting period:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

    ## Define the initial

# Generated at 2022-06-18 02:32:44.636075
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import List
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.

# Generated at 2022-06-18 02:32:53.481404
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a mock implementation of ReadInitialBalances
    class MockReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account(code="1010", name="Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(1000))),
                Account(code="1020", name="Bank"): Balance(date(2020, 1, 1), Quantity(Decimal(2000))),
                Account(code="1030", name="Inventory"): Balance(date(2020, 1, 1), Quantity(Decimal(3000))),
            }

    # Define a mock implementation of ReadJournalEntries

# Generated at 2022-06-18 02:33:03.488704
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedgerProgram

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:33:11.921852
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, InitialBalances, Ledger, LedgerEntry

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
            Account("C"): Balance(period.since, Quantity(Decimal(300))),
        }

    # Def

# Generated at 2022-06-18 02:33:20.794439
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(
                account=Account(code="1010", name="Cash"),
                amount=Decimal(100),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account(code="1020", name="Bank"),
                amount=Decimal(100),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )

    ## Define initial balances:

# Generated at 2022-06-18 02:33:30.587845
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define the accounting period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    # Define the initial balances:

# Generated at 2022-06-18 02:33:36.835616
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, Transaction
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define the initial balances:

# Generated at 2022-06-18 02:33:55.395349
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances, build_general_ledger, compile_general_ledger_program
    from .types import Transaction

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]


# Generated at 2022-06-18 02:34:05.040407
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .accounting import ReadInitialBalances, ReadJournalEntries

    ## Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:34:09.801777
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction
    from .commons.types import Direction

# Generated at 2022-06-18 02:34:17.761638
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    # Define test data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    initial_balances = {
        Account("1110"): Balance(period.since, Quantity(Decimal(0))),
        Account("1120"): Balance(period.since, Quantity(Decimal(0))),
        Account("1130"): Balance(period.since, Quantity(Decimal(0))),
    }

# Generated at 2022-06-18 02:34:19.065798
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:29.893575
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances.
    initial_balances = {
        Account("1010"): Balance(period.since, Quantity(Decimal(0))),
        Account("1020"): Balance(period.since, Quantity(Decimal(0))),
        Account("1030"): Balance(period.since, Quantity(Decimal(0))),
    }

    #: Journal entries.

# Generated at 2022-06-18 02:34:41.407117
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a program which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    ## Define a program which reads journal entries:

# Generated at 2022-06-18 02:34:50.354061
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .journaling import ReadJournalEntries
    from .commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .journaling import ReadJournalEntries
    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, Posting
    from .commons.numbers import Amount, Quantity

# Generated at 2022-06-18 02:34:59.871384
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    # Create a ledger
    account = Account("Assets")
    initial = Balance(DateRange.since(datetime.date(2020, 1, 1)), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = Journal(datetime.date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Amount(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entry
    assert ledger.entries[0].balance == Quantity(Decimal(100))
    assert ledger.entries[0].post

# Generated at 2022-06-18 02:35:10.885446
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a test period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define test accounts:
    a1 = Account("A1")
    a2 = Account("A2")
    a3 = Account("A3")

    ## Define test initial balances:
    initial_balances = {a1: Balance(period.since, Quantity(Decimal(100))), a2: Balance(period.since, Quantity(Decimal(200)))}

    ## Define test journal entries:

# Generated at 2022-06-18 02:35:32.744243
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType
    from .generic import Balance
    from ..commons.zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal

    # Define the accounting period:
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

    # Define the initial balances:

# Generated at 2022-06-18 02:35:42.300470
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, account, Quantity(Decimal(10)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entries
    assert len(ledger.entries) == 1
    assert ledger.entries[0].balance == Quantity(Decimal(10))


# Generated at 2022-06-18 02:35:52.861784
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, ReadAccounts
    from .accounts import AccountType, AccountClass
    from .accounts import Account, ReadAccounts
    from .accounts import AccountType, AccountClass
    from .accounts import Account, ReadAccounts
    from .accounts import AccountType, AccountClass
    from .accounts import Account, ReadAccounts
    from .accounts import AccountType, AccountClass
    from .accounts import Account, ReadAccounts
    from .accounts import AccountType, AccountClass
    from .accounts import Account, ReadAccounts
    from .accounts import AccountType, AccountClass
    from .accounts import Account, ReadAccounts
    from .accounts import AccountType, AccountClass
    from .accounts import Account, ReadAccounts

# Generated at 2022-06-18 02:35:59.733611
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Initial balances:

# Generated at 2022-06-18 02:36:00.675076
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:10.888977
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Callable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program

    class Test(TestCase):
        def setUp(self):
            self.period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:36:21.198842
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(datetime.date(2020, 1, 1), Quantity(Decimal(100)), Account("Assets", "Cash"), Account("Income", "Sales"))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entries
    assert ledger.entries[0].balance == Quantity(Decimal(100))
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].ledger == ledger
    assert ledger.entries[0].date == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 02:36:27.582501
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Read initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    #: Read journal entries:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    #: Compile general ledger program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    #: Run the program:

# Generated at 2022-06-18 02:36:36.864016
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Direction
    from datetime import date
    from decimal import Decimal
    from typing import List, Dict
    from .commons import Quantity
    from .commons import Amount

    # Initialize a ledger
    account = Account(code="101", name="Cash")
    initial = Balance(date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Initialize a posting
    journal = Journal(date(2020, 1, 1), "Deposit", [Posting(account, Direction.CREDIT, Amount(Decimal(100)))])

# Generated at 2022-06-18 02:36:46.214432
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:37:41.460078
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection
    from .generic import Balance

    # Create a journal entry
    journal = Journal(datetime.date(2020, 1, 1), "Test journal entry")
    journal.add(PostingDirection.DEBIT, Account(AccountType.ASSET, "Cash", "Cash"), Amount(100))
    journal.add(PostingDirection.CREDIT, Account(AccountType.ASSET, "Cash", "Cash"), Amount(100))

    # Create a ledger
    ledger = Ledger(Account(AccountType.ASSET, "Cash", "Cash"), Balance(datetime.date(2020, 1, 1), Quantity(0)))

    # Add the journal entry to the ledger
    ledger.add(journal.postings[0])

    # Check the balance

# Generated at 2022-06-18 02:37:51.056780
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances.
    initial_balances = {
        Account("10100"): Balance(datetime.date(2018, 12, 31), Quantity(Decimal(100))),
        Account("10200"): Balance(datetime.date(2018, 12, 31), Quantity(Decimal(200))),
    }

    #: Journal entries.

# Generated at 2022-06-18 02:37:52.082975
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:01.951391
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger, Ledger, LedgerEntry

    ## Define the accounting period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    ## Define the journal entries:

# Generated at 2022-06-18 02:38:13.568618
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Direction

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    account = Account("1010", "Cash")
    initial = Balance(period.since, Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    journal = JournalEntry(datetime.date(2019, 1, 1), "Cash deposit", [Posting(account, Direction.DEBIT, Quantity(Decimal(1000)))])
    posting = journal.postings[0]
    entry = ledger.add(posting)
    assert entry.posting

# Generated at 2022-06-18 02:38:20.212522
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, Ledger
    from .generic import Balance

    ## Define a dummy read initial balances algebra implementation:
    def _read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {Account("A"): Balance(period.since, Quantity(Decimal(10)))}

    ## Define a dummy read journal entries algebra implementation:

# Generated at 2022-06-18 02:38:29.128248
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:38:38.979551
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Read initial balances algebra:
    class ReadInitialBalances(Protocol):
        """
        Type of functions which reads and returns initial balances.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    #: Read journal entries algebra:
    class ReadJournalEntries(Protocol[_T]):
        """
        Type of functions which reads and returns journal entries.
        """



# Generated at 2022-06-18 02:38:47.765061
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(Journal("J", Date(2019, 1, 1), "D"), account, Quantity(Decimal(1)), 1)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the result
    assert entry.date == Date(2019, 1, 1)
    assert entry.description == "D"
    assert entry.amount == Quantity(Decimal(1))
    assert entry.cntraccts == []

# Generated at 2022-06-18 02:38:55.589856
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import ReadInitialBalances, ReadJournalEntries

    ## Define a dummy implementation of the algebra:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}


# Generated at 2022-06-18 02:40:16.306693
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define some accounts:
    a = Account("A")
    b = Account("B")
    c = Account("C")
    d = Account("D")

    ## Define some journal entries:
    j1 = JournalEntry(datetime.date(2019, 1, 1), "J1", [Posting(a, 100), Posting(b, -100)])
    j2 = JournalEntry(datetime.date(2019, 1, 2), "J2", [Posting(b, 100), Posting(c, -100)])

# Generated at 2022-06-18 02:40:21.641410
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a dummy implementation of the algebra.

# Generated at 2022-06-18 02:40:28.083739
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:40:29.422721
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:40:38.372745
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeGroup

    # Define a transaction type:
    transaction_type = TransactionType(
        code="TEST",
        name="Test Transaction Type",
        category=TransactionTypeCategory.ASSET,
        group=TransactionTypeGroup.CASH,
    )

    # Define a transaction:

# Generated at 2022-06-18 02:40:46.763925
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, build_journal_entry

    ## Define a sample account:
    account = Account("A", AccountType.ASSET)

    ## Define a sample initial balance:
    initial_balance = Balance(DateRange.since(datetime.date(2020, 1, 1)), Quantity(Decimal(100)))

    ## Define a sample journal entry:
    journal_entry = build_journal_entry(
        datetime.date(2020, 1, 2),
        "Sample journal entry",
        [
            Posting(account, Quantity(Decimal(1)), True),
            Posting(account, Quantity(Decimal(1)), False),
        ],
    )

    ## Define a sample period:
   

# Generated at 2022-06-18 02:40:52.183585
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program
    from .commons.zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Iterable, List, Optional, TypeVar
    from .commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program
    from .commons.zeitgeist import DateRange