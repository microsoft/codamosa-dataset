

# Generated at 2022-06-18 02:31:11.906773
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import Date, DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction

    ## Define accounts:
    a1 = Account("A1", AccountType.ASSET, "Cash")
    a2 = Account("A2", AccountType.ASSET, "Inventory")
    a3 = Account("A3", AccountType.ASSET, "Accounts Receivable")
    a4 = Account("A4", AccountType.ASSET, "Prepaid Expenses")
    a5 = Account("A5", AccountType.ASSET, "Equipment")
    a6 = Account("A6", AccountType.ASSET, "Accumulated Depreciation")
    a7 = Account("A7", AccountType.LIABILITY, "Accounts Payable")
    a8

# Generated at 2022-06-18 02:31:21.309582
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Reads initial balances.

# Generated at 2022-06-18 02:31:27.041473
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger
    from datetime import date
    from decimal import Decimal
    period = DateRange(date(2020, 1, 1), date(2020, 1, 31))

# Generated at 2022-06-18 02:31:33.121186
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction

    ## Define test data:
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

# Generated at 2022-06-18 02:31:43.848010
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import Ledger, build_general_ledger, compile_general_ledger_program, GeneralLedger
    from .algebras import read_initial_balances, read_journal_entries
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    journal = [JournalEntry(datetime.date(2020, 1, 1), "Test", [Posting(Account("Assets", "Cash"), Amount(100), True)])]

# Generated at 2022-06-18 02:31:52.613878
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:32:02.811801
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a test account:
    test_account = Account(
        name="Test Account",
        code="TEST",
        type=AccountType.ASSET,
        description="Test account",
        category="Test",
        subcategory="Test",
    )

    ## Define a test journal entry:

# Generated at 2022-06-18 02:32:14.303969
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a journal entry
    je = JournalEntry(
        date=datetime.date(2018, 1, 1),
        description="Test",
        postings=[
            Posting(account=Account("1010", "Cash"), amount=Decimal("100")),
            Posting(account=Account("1020", "Accounts Receivable"), amount=Decimal("-100")),
        ],
    )

    # Define initial balances

# Generated at 2022-06-18 02:32:19.379453
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:32:29.236483
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:32:35.995385
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:44.415311
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}


# Generated at 2022-06-18 02:32:53.304459
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, Ledger, LedgerEntry, ReadInitialBalances
    from .numbers import Amount, Quantity

    # Define a mock implementation of ReadInitialBalances
    class MockReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account(1, "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account(2, "Accounts Receivable"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
            }

    # Define a mock implementation of ReadJournalEnt

# Generated at 2022-06-18 02:32:58.468324
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction

    ## Initialize the accounting period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    ## Initialize the initial balances:

# Generated at 2022-06-18 02:33:05.353945
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances, compile_general_ledger_program
    from .taxonomies import Taxonomy
    from .taxonomies.taxonomy import TaxonomyNode
    from .taxonomies.taxonomy_builder import TaxonomyBuilder
    from .taxonomies.taxonomy_builder import TaxonomyBuilder
    from .taxonomies.taxonomy_builder import TaxonomyBuilder
    from .taxonomies.taxonomy_builder import TaxonomyBuilder
    from .taxonomies.taxonomy_builder import TaxonomyBuilder
    from .taxonomies.taxonomy_builder import TaxonomyBuilder

# Generated at 2022-06-18 02:33:13.712430
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import GeneralLedger, Ledger, LedgerEntry

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Defines a ledger entry model.
    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]



# Generated at 2022-06-18 02:33:23.243626
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account(code="1010", name="Cash"), amount=Decimal(100)),
            Posting(account=Account(code="1020", name="Bank"), amount=Decimal(100)),
        ],
    )

    # Define initial balances:

# Generated at 2022-06-18 02:33:32.896959
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.test_utils import assert_equal

    # Define a journal entry:

# Generated at 2022-06-18 02:33:43.185006
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger
    from datetime import date
    from decimal import Decimal
    from typing import List

    # Initialize the journal entries

# Generated at 2022-06-18 02:33:47.504267
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("A", "A"): Balance(date(2019, 1, 1), Decimal(100))}

    assert _ReadInitialBalances()(DateRange(date(2019, 1, 1), date(2019, 1, 31))) == {
        Account("A", "A"): Balance(date(2019, 1, 1), Decimal(100))
    }


# Generated at 2022-06-18 02:34:17.587164
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from ..journaling.models import JournalEntry
    from .accounts import Account
    from .algebra import ReadInitialBalances
    from .models import Balance
    from .programs import compile_general_ledger_program

    ## Define a dummy implementation of the algebra:
    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}


# Generated at 2022-06-18 02:34:28.916384
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import ReadJournalEntries, ReadInitialBalances

    # Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020"): Balance(period.since, Quantity(Decimal(200))),
        }


# Generated at 2022-06-18 02:34:36.162930
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, JournalEntry
    from .generic import Balance
    from .commons.numbers import Amount, Quantity

    ## Create a journal entry:
    journal = Journal(
        date(2020, 1, 1),
        "Test journal entry",
        [
            Posting(Account(AccountType.ASSET, "Cash"), Amount(100), "Debit"),
            Posting(Account(AccountType.EXPENSE, "Expenses"), Amount(100), "Credit"),
        ],
    )

    ## Create a journal entry:

# Generated at 2022-06-18 02:34:46.997747
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import ReadJournalEntries, ReadInitialBalances

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(0))),
            Account("1020"): Balance(period.since, Quantity(Decimal(0))),
            Account("1030"): Balance(period.since, Quantity(Decimal(0))),
            Account("1040"): Balance(period.since, Quantity(Decimal(0))),
        }


# Generated at 2022-06-18 02:34:58.361834
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
            Account("C"): Balance(period.since, Quantity(Decimal(300))),
        }


# Generated at 2022-06-18 02:35:09.711823
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances
    from .ledgers import build_general_ledger, GeneralLedger
    from .ledgers import compile_general_ledger_program, GeneralLedgerProgram
    from .ledgers import ReadJournalEntries
    from .ledgers import Ledger
    from .ledgers import LedgerEntry

    # Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:35:20.757073
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(1000))),
            Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(2000))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:35:27.971687
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance

    @dataclass
    class TestReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account("2"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
            }


# Generated at 2022-06-18 02:35:33.811525
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Reads initial balances:

# Generated at 2022-06-18 02:35:44.035827
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:36:17.205876
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:36:24.789168
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    account = Account("1", "Test Account")
    journal = Journal(Date(2020, 1, 1), "Test Journal")
    posting = Posting(journal, account, Amount(100))
    balance = Balance(Date(2020, 1, 1), Quantity(100))
    ledger = Ledger(account, balance)
    ledger.add(posting)
    assert ledger.entries[0].balance == Quantity(200)

# Generated at 2022-06-18 02:36:32.695010
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, ReadInitialBalances, ReadJournalEntries

    # Defines a mock implementation of the algebra which reads initial balances.

# Generated at 2022-06-18 02:36:43.567618
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries
    from .accounts import Account, AccountType
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, AccountType
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, AccountType
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .journaling import JournalEntry, Posting, ReadJournalEntries

# Generated at 2022-06-18 02:36:52.783334
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from .accounts import Account, AccountType, AccountCategory
    from .journaling import JournalEntry, Posting, Direction
    from .generic import Balance
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from ..commons.types import Unit

    ## Define a test account:
    account = Account("Test", AccountType.ASSET, AccountCategory.CURRENT_ASSET)

    ## Define a test journal entry:

# Generated at 2022-06-18 02:37:02.895270
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:37:07.999068
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a test period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Define some test accounts:
    a = Account("A")
    b = Account("B")
    c = Account("C")

    # Define some test initial balances:
    initial_balances = {a: Balance(period.since, Quantity(Decimal(100))), b: Balance(period.since, Quantity(Decimal(200)))}

    # Define some test journal entries:

# Generated at 2022-06-18 02:37:14.463352
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance

    @dataclass
    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2019, 1, 1), Quantity(Decimal(1000))),
                Account("1020", "Bank"): Balance(date(2019, 1, 1), Quantity(Decimal(2000))),
            }


# Generated at 2022-06-18 02:37:24.321525
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    # Define a dummy read initial balances function:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy read journal entries function:

# Generated at 2022-06-18 02:37:35.244737
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances
    from .types import Transaction

    # Define a dummy implementation of the algebra:
    class DummyReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2019, 1, 1), Decimal(100)),
                Account("1020", "Accounts Receivable"): Balance(date(2019, 1, 1), Decimal(200)),
                Account("1030", "Inventory"): Balance(date(2019, 1, 1), Decimal(300)),
            }

    # Define a

# Generated at 2022-06-18 02:38:31.523581
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, Ledger, LedgerEntry

    ## Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2018, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(Account("Assets", "Cash"), Quantity(Decimal(100))),
            Posting(Account("Expenses", "Test"), Quantity(Decimal(-100))),
        ],
    )

    ## Define initial balances:

# Generated at 2022-06-18 02:38:40.436026
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a mock implementation of ReadInitialBalances

# Generated at 2022-06-18 02:38:49.661369
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a test journal entry:
    journal_entry = JournalEntry(
        date=date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account(code="1000", name="Cash"), amount=Amount(100), direction=1),
            Posting(account=Account(code="2000", name="Accounts receivable"), amount=Amount(100), direction=-1),
        ],
    )

    ## Define a test initial balance:
    initial_balance = Balance(date=date(2019, 12, 31), value=Amount(100))

   

# Generated at 2022-06-18 02:38:56.613628
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry

    # Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
    initial_balances = {
        Account("1010"): Balance(date(2019, 12, 31), Amount(100)),
        Account("1020"): Balance(date(2019, 12, 31), Amount(200)),
    }

# Generated at 2022-06-18 02:39:07.093422
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import Date
    from .accounts import AccountType
    from .journaling import Journal, Posting, JournalEntry
    from .generic import Balance
    from .ledgering import build_general_ledger
    from datetime import date
    from decimal import Decimal
    from typing import List, Dict
    from collections import namedtuple

    # Define a journal entry
    JournalEntry = namedtuple('JournalEntry', ['date', 'description', 'postings'])

    # Define a posting
    Posting = namedtuple('Posting', ['account', 'amount', 'direction'])

    # Define a balance
    Balance = namedtuple('Balance', ['date', 'value'])

    # Define a general ledger

# Generated at 2022-06-18 02:39:15.154957
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, LedgerEntry, Ledger
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange
    from datetime import date
    from typing import Dict, Iterable, List, Optional
    from unittest import TestCase
    from unittest.mock import MagicMock, Mock, call, patch

    class TestCase(TestCase):
        def setUp(self):
            self.read_initial_balances = MagicMock()
            self.read_journal_entries = MagicMock()

# Generated at 2022-06-18 02:39:23.973058
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .ledgers import build_general_ledger
    from .ledgers import compile_general_ledger_program
    from .ledgers import GeneralLedger
    from .ledgers import Ledger
    from .ledgers import LedgerEntry
    from .ledgers import InitialBalances
    from .ledgers import ReadInitialBalances
    from .ledgers import ReadJournalEntries
    from .ledgers import GeneralLedgerProgram
    from datetime import date
    from typing import Dict, Iterable, List, Optional
    from unittest import TestCase


# Generated at 2022-06-18 02:39:28.102556
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .types import Balance, DateRange, Quantity
    from .zeitgeist import DateRange

    # Define a test account:
    account = Account(AccountType.ASSET, "Test Account", "Test Account")

    # Define a test period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    # Define a test initial balance:
    initial_balance = Balance(period.since, Quantity(Decimal(0)))

    # Define a test journal entry:

# Generated at 2022-06-18 02:39:28.796847
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:39:33.545210
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, Ledger, LedgerEntry, ReadInitialBalances, ReadJournalEntries
    from .types import Transaction
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Iterable, List
    from unittest import TestCase


# Generated at 2022-06-18 02:40:45.446591
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(100)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2019, 1, 2), "Test journal")

    # Create a posting
    posting = Posting(journal, account, Amount(Decimal(10)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entries
    assert len(ledger.entries) == 1
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].balance == Quantity(Decimal(110))

# Generated at 2022-06-18 02:40:51.691529
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    # Define a stub for reading initial balances: