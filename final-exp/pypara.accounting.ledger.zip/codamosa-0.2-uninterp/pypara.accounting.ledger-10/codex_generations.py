

# Generated at 2022-06-18 02:31:01.929205
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-18 02:31:02.958553
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:04.683502
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:13.088859
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from typing import List
    from unittest.mock import Mock
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgering import GeneralLedger, GeneralLedgerProgram, build_general_ledger, compile_general_ledger_program
    from .types import Transaction

    # Define a mock transaction type:
    class MockTransaction(Transaction):
        def __init__(self, id: str):
            self.id = id

    # Define a mock read initial balances algebra:

# Generated at 2022-06-18 02:31:22.324767
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting
    from .accounts import Account

    # Create a ledger
    ledger = Ledger(Account("1"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))

    # Create a journal
    journal = Journal(datetime.date(2020, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, Account("1"), Quantity(Decimal(10)), True)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(10))

    # Create a new posting
    posting = Posting(journal, Account("1"), Quantity(Decimal(10)), True)

    # Add the posting to the ledger

# Generated at 2022-06-18 02:31:30.769432
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:31:39.973420
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .ledgers import LedgerEntry, Ledger, GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .commons.algebra import Algebra
    from .commons.algebra import AlgebraicFunction, AlgebraicOperation
    from .commons.algebra import AlgebraicStructure, AlgebraicStructureElement
    from .commons.algebra import AlgebraicStructureElementType
    from .commons.algebra import AlgebraicStructureType
    from .commons.algebra import AlgebraicStructureTypeElement
    from .commons.algebra import Al

# Generated at 2022-06-18 02:31:48.216680
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:31:53.081667
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(1, "Test Account")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal")
    posting = Posting(journal, account, Amount(Decimal(100)), True)
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(100))
    assert ledger.entries[0].balance == Quantity(Decimal(100))
    assert ledger.entries[0].posting.journal.description == "Test Journal"
    assert ledger.entries[0].posting.journal.date == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 02:32:03.231680
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .accounts import Account
    from .journaling import JournalEntry, Posting, Direction

    # Define test data:
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

# Generated at 2022-06-18 02:32:16.233169
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a stub implementation of ReadInitialBalances
    class StubReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1"): Balance(date(2019, 1, 1), Decimal(100)),
                Account("2"): Balance(date(2019, 1, 1), Decimal(200)),
            }

    # Define a stub implementation of ReadJournalEntries

# Generated at 2022-06-18 02:32:27.367344
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, read_journal_entries

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:32:36.240736
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .generic import Balance
    from .commons import Direction

    # Define test data:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

# Generated at 2022-06-18 02:32:44.589378
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a test implementation of ReadInitialBalances

# Generated at 2022-06-18 02:32:53.443370
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:33:03.427342
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import Direction

    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    journal = [
        JournalEntry(
            datetime.date(2018, 1, 1),
            "Test Journal Entry",
            [
                Posting(Account("A"), Direction.DEBIT, Decimal(100)),
                Posting(Account("B"), Direction.CREDIT, Decimal(100)),
            ],
        )
    ]
    initial = {Account("A"): Balance(datetime.date(2017, 12, 31), Decimal(0))}


# Generated at 2022-06-18 02:33:11.855248
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a test account:
    account = Account("Test Account")

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2019, 1, 1),
        description="Test Journal Entry",
        postings=[
            Posting(account, Amount(Decimal(100)), True),
            Posting(account, Amount(Decimal(100)), False),
        ],
    )

    # Define a test initial balance:
    initial_balance = Balance(datetime.date(2018, 12, 31), Quantity(Decimal(0)))

    # Define a test period:

# Generated at 2022-06-18 02:33:12.390995
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-18 02:33:21.277553
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, AccountType, AccountCategory
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from . import general_ledger
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:33:31.067032
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("1010", "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(100)), Posting.Direction.DEBIT)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:33:46.682900
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import Ledger, build_general_ledger
    from .journaling import JournalEntry
    from .commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .journaling import Journal, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance

# Generated at 2022-06-18 02:33:56.165953
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    ## Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:34:05.984479
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: All available journal entries.

# Generated at 2022-06-18 02:34:15.915991
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:34:27.772209
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Arrange
    mock = Mock(spec=ReadInitialBalances)
    mock.__call__.return_value = {
        Account("A", "A", "A"): Balance(date(2020, 1, 1), Quantity(Decimal(1))),
        Account("B", "B", "B"): Balance(date(2020, 1, 1), Quantity(Decimal(2))),
    }
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

    # Act
    result = mock.__call__(period)

    # Assert

# Generated at 2022-06-18 02:34:35.352038
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Test data
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))
    initial_balances = {
        Account("1010", "Cash"): Balance(date(2018, 12, 31), Quantity(Decimal(100))),
        Account("1020", "Bank"): Balance(date(2018, 12, 31), Quantity(Decimal(200))),
    }

    # Test implementation
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return initial_balances

    # Test
    assert read_initial_balances(period) == initial_balances


# Generated at 2022-06-18 02:34:46.583408
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a mock implementation of ReadInitialBalances
    class MockReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account("1020", "Bank"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
            }

    # Define a mock implementation of ReadJournalEntries

# Generated at 2022-06-18 02:34:57.802114
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    account = Account("1")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    account = Account("2")
    amount = Amount(Decimal(10))
    date = Date(2020, 1, 1)
    journal = Journal(date, "Test")
    posting = Posting(account, amount, journal)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger
    assert ledger.account == Account("1")
    assert ledger.initial == Balance(Date(2020, 1, 1), Quantity(Decimal(0)))

# Generated at 2022-06-18 02:35:09.238032
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger

    ## Define a dummy read initial balances algebra implementation:
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    ## Define a dummy read journal entries algebra implementation:

# Generated at 2022-06-18 02:35:20.614566
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A", "A"): Balance(period.since, Quantity(Decimal(10))),
            Account("B", "B"): Balance(period.since, Quantity(Decimal(20))),
            Account("C", "C"): Balance(period.since, Quantity(Decimal(30))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:35:46.512270
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .journaling import Posting
    from .commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .journaling import JournalEntry
    from .journaling import Posting
    from .commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .journaling import JournalEntry
    from .journaling import Posting
    from .commons.zeitgeist import Date

# Generated at 2022-06-18 02:35:55.138491
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry

    # Define a sample journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Sample journal entry",
        postings=[
            Posting(account=Account("1110"), amount=Decimal(100), direction=Posting.Direction.DEBIT),
            Posting(account=Account("1120"), amount=Decimal(100), direction=Posting.Direction.CREDIT),
        ],
    )

    # Define a sample initial balance:
    initial_balance

# Generated at 2022-06-18 02:36:01.235407
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import AccountId, AccountName, Amount, Balance, Date, Quantity

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:36:11.640583
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .algebras import ReadJournalEntries, ReadInitialBalances

    # Define a journal entry:

# Generated at 2022-06-18 02:36:21.761808
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
    initial_balances = {
        Account("1010"): Balance(date(2019, 12, 31), Quantity(Decimal(100))),
        Account("1020"): Balance(date(2019, 12, 31), Quantity(Decimal(200))),
        Account("1030"): Balance(date(2019, 12, 31), Quantity(Decimal(300))),
    }

# Generated at 2022-06-18 02:36:29.127758
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2019, 1, 1), "Cash received")
    posting = Posting(journal, account, Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entry
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:36:40.122263
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, PostingDirection

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Cash deposit", [
        Posting(account, PostingDirection.DEBIT, Quantity(Decimal(100))),
        Posting(Account("Liabilities", "Bank"), PostingDirection.CREDIT, Quantity(Decimal(100)))
    ])

    # Add a posting to the ledger
    posting = journal.postings[0]
    entry = ledger.add(posting)

    # Test

# Generated at 2022-06-18 02:36:48.998775
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance


# Generated at 2022-06-18 02:36:53.831698
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:37:03.531727
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, ReadInitialBalances, ReadJournalEntries
    from .commons.test_utils import assert_equal

    # Define a simple algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {}

    # Define a simple algebra which reads journal entries:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return []

    # Compile the program:
    program: GeneralLedgerProgram = compile_general_ledger_program

# Generated at 2022-06-18 02:37:39.217929
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:37:40.425720
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:37:50.244363
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import Ledger, build_general_ledger, GeneralLedger
    from .journaling import JournalEntry
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Iterable
    import unittest

    # Test data
    account = Account("1", "Test Account", AccountType.ASSET)
    initial = Balance(date(2019, 1, 1), Quantity(Decimal(0)))
    period = DateRange(date(2019, 1, 1), date(2019, 1, 31))

# Generated at 2022-06-18 02:38:00.270175
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy read_initial_balances function

# Generated at 2022-06-18 02:38:00.753142
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:11.432869
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:38:19.340655
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances
    from .ledgers import build_general_ledger
    from .ledgers import compile_general_ledger_program
    from .ledgers import GeneralLedger
    from .ledgers import GeneralLedgerProgram
    from .ledgers import InitialBalances
    from .ledgers import Ledger
    from .ledgers import LedgerEntry
    from .ledgers import ReadJournalEntries

    # Define a mock implementation of the algebra:

# Generated at 2022-06-18 02:38:28.693200
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:38:38.895025
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import GeneralLedger, Ledger, LedgerEntry

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity

# Generated at 2022-06-18 02:38:45.609949
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a read initial balances algebra:

# Generated at 2022-06-18 02:39:58.129435
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance


# Generated at 2022-06-18 02:40:09.125353
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Test data
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:40:18.620734
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Initial balances:
    initial_balances = {
        Account("1010"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
        Account("1020"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
        Account("1030"): Balance(date(2020, 1, 1), Quantity(Decimal(300))),
    }

    # Journal entries:

# Generated at 2022-06-18 02:40:25.878164
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Optional, TypeVar
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import GeneralLedger, Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program
    from .types import Direction
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance

# Generated at 2022-06-18 02:40:35.613838
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a test account:
    account = Account("Test", AccountType.ASSET)

    ## Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(account=account, amount=Amount(100), direction=Posting.Direction.DEBIT),
            Posting(account=account, amount=Amount(100), direction=Posting.Direction.CREDIT),
        ],
    )

    ## Define a test initial balance:

# Generated at 2022-06-18 02:40:43.448179
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    @dataclass
    class ReadInitialBalancesMock:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1000"): Balance(period.since, Quantity(Decimal(100))),
                Account("2000"): Balance(period.since, Quantity(Decimal(200))),
                Account("3000"): Balance(period.since, Quantity(Decimal(300))),
            }


# Generated at 2022-06-18 02:40:44.368483
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:40:52.008613
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a test account:
    account = Account("Test", AccountType.ASSET)

    # Define a test initial balance:
    initial_balance = Quantity(Decimal(100))

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(account, Amount(Decimal(100)), Quantity(Decimal(100))),
            Posting(account, Amount(Decimal(100)), Quantity(Decimal(100))),
        ],
    )

    # Def