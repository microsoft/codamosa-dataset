

# Generated at 2022-06-18 02:31:15.521233
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a mock implementation of ReadInitialBalances
    class MockReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("101", "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account("102", "Accounts Receivable"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
                Account("103", "Inventory"): Balance(date(2020, 1, 1), Quantity(Decimal(300))),
            }

    # Define a mock implementation of ReadJournalEntries

# Generated at 2022-06-18 02:31:23.615195
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account(1, "Test Account")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(
        Journal(Date(2020, 1, 1), "Test Journal"),
        account,
        Quantity(Decimal(100)),
        1,
    )

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100))
    assert entry

# Generated at 2022-06-18 02:31:31.317653
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from typing import List
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial

# Generated at 2022-06-18 02:31:40.310283
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    # Test data
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:31:48.406687
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    account = Account("1010", "Cash")
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    initial = Balance(period.since, Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    posting = Posting(datetime.date(2020, 1, 1), account, Quantity(Decimal(100)), "Cash received")
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(100))
    posting = Posting(datetime.date(2020, 1, 1), account, Quantity(Decimal(100)), "Cash received")

# Generated at 2022-06-18 02:31:55.376794
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test journal")

    # Create a posting
    posting = Posting(journal, Account("Test account"), Direction.DEBIT, Amount(100))

    # Create a ledger
    ledger = Ledger(Account("Test account"), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))

    # Check the date of the ledger entry
    assert entry.date == Date(2020, 1, 1)

    # Check the description

# Generated at 2022-06-18 02:32:05.176141
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry

    ## Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:32:15.817361
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Type of functions which reads and returns initial balances.
    ReadInitialBalances = Callable[[DateRange], InitialBalances]

    #: Type of functions which reads and returns journal entries.
    ReadJournalEntries = Callable[[DateRange], Iterable[JournalEntry[_T]]]

    #: Type definition of the program which builds general ledger.
    GeneralLedgerProgram = Callable[[DateRange], GeneralLedger[_T]]

    #: Type of functions which reads and returns initial balances.
   

# Generated at 2022-06-18 02:32:26.907333
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(200))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:32:35.969106
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import date
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction

    ## Define accounts:
    cash = Account("Cash", AccountType.ASSET)
    sales = Account("Sales", AccountType.INCOME)
    cost_of_sales = Account("Cost of Sales", AccountType.EXPENSE)
    inventory = Account("Inventory", AccountType.ASSET)
    accounts_payable = Account("Accounts Payable", AccountType.LIABILITY)
    accounts_receivable = Account("Accounts Receivable", AccountType.ASSET)

    ## Define initial balances:

# Generated at 2022-06-18 02:32:53.015555
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from ..journaling import JournalEntry, Posting
    from ..accounts import Account
    from ..commons.numbers import Amount, Quantity
    from ..commons.types import Date, Description, Reference

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity


# Generated at 2022-06-18 02:33:03.245826
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Create a journal entry
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(
                account=Account("Assets", "Cash"),
                amount=Amount(Decimal(100)),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account("Expenses", "Rent"),
                amount=Amount(Decimal(100)),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )

    # Create a period

# Generated at 2022-06-18 02:33:11.610815
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a test account
    account = Account("Test Account")
    # Create a test ledger
    ledger = Ledger(account, Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    # Create a test journal
    journal = JournalEntry(datetime.date(2020, 1, 2), "Test Journal", [Posting(account, Amount(Decimal(100)), True)])
    # Create a test posting
    posting = journal.postings[0]
    # Add the posting to the ledger
    entry = ledger.add(posting)
    # Check the date of the ledger entry
    assert entry.date == datetime.date(2020, 1, 2)
    # Check the description of the ledger entry
    assert entry.description == "Test Journal"
    # Check the amount of the ledger entry
    assert entry.amount

# Generated at 2022-06-18 02:33:12.186666
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-18 02:33:21.029950
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a ledger
    account = Account("1010", "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Payment", [Posting(account, Direction.DEBIT, Quantity(Decimal(100)))])

    # Add the journal to the ledger
    ledger.add(journal.postings[0])

    # Check the ledger entries
    assert len(ledger.entries) == 1
    assert ledger.entries[0].posting == journal.postings[0]

# Generated at 2022-06-18 02:33:30.827829
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    initial_balances = {
        Account("100"): Balance(period.since, Quantity(Decimal(100))),
        Account("200"): Balance(period.since, Quantity(Decimal(200))),
        Account("300"): Balance(period.since, Quantity(Decimal(300))),
    }

# Generated at 2022-06-18 02:33:36.000966
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    account = Account("1")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2019, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(10)))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the result
    assert entry.balance == Quantity(Decimal(10))

# Generated at 2022-06-18 02:33:36.843891
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:33:45.403519
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry

    # Create a ledger
    account = Account(1, "Test Account")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(100)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test Journal")

    # Create a posting
    posting = Posting(journal, account, Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entry
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].balance

# Generated at 2022-06-18 02:33:47.000839
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:11.601289
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a mock implementation of the algebra:
    class MockReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("A"): Balance(date(2019, 1, 1), Decimal(100)), Account("B"): Balance(date(2019, 1, 1), Decimal(200))}

    # Define a mock implementation of the algebra:
    class MockReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            from .journaling import Journal, Posting
            from .accounts import Account
           

# Generated at 2022-06-18 02:34:18.179768
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .generic import Balance

    #: Accounting period.
    period = DateRange(Date(2019, 1, 1), Date(2019, 12, 31))

    #: Initial balances.

# Generated at 2022-06-18 02:34:29.339874
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .generic import Balance
    from .commons import Direction

    ## Define accounts:
    a1 = Account("A1", AccountType.ASSET)
    a2 = Account("A2", AccountType.ASSET)
    a3 = Account("A3", AccountType.ASSET)
    a4 = Account("A4", AccountType.ASSET)
    a5 = Account("A5", AccountType.ASSET)
    a6 = Account("A6", AccountType.ASSET)
    a7 = Account("A7", AccountType.ASSET)
    a8 = Account("A8", AccountType.ASSET)

# Generated at 2022-06-18 02:34:40.853609
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy read initial balances algebra:

# Generated at 2022-06-18 02:34:50.079124
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:34:59.871176
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from dataclasses import asdict

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=date(2019, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account(code="1000", name="Cash"), amount=Decimal(100)),
            Posting(account=Account(code="2000", name="Accounts Receivable"), amount=Decimal(100)),
        ],
    )

    # Define a test initial balances:
   

# Generated at 2022-06-18 02:35:10.897056
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances.

# Generated at 2022-06-18 02:35:21.027284
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances:
    initial_balances = {
        Account("1110", "Cash"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
        Account("1120", "Bank"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(200))),
    }

# Generated at 2022-06-18 02:35:28.411083
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2019, 1, 1), "Test", [Posting(account, Direction.Debit, Quantity(Decimal(100)))])
    posting = journal.postings[0]

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger

# Generated at 2022-06-18 02:35:38.213989
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity


# Generated at 2022-06-18 02:36:25.378263
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances
    from .commons import ReadJournalEntries, ReadInitialBalances

# Generated at 2022-06-18 02:36:32.394848
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Amount, Quantity
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Amount, Quantity
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Amount, Quantity
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Amount

# Generated at 2022-06-18 02:36:43.385525
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a test implementation of the algebra:
    class TestReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(1000))),
                Account("1020", "Bank"): Balance(date(2020, 1, 1), Quantity(Decimal(2000))),
            }

    # Define a test date range:

# Generated at 2022-06-18 02:36:52.539721
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import ReadJournalEntries
    from .ledgers import ReadInitialBalances, GeneralLedgerProgram, build_general_ledger

    # Define a dummy implementation of ReadInitialBalances

# Generated at 2022-06-18 02:36:53.391951
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:37:03.342413
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy read_initial_balances function:

# Generated at 2022-06-18 02:37:12.112831
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define a journal entry:
    entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account(code="1000", name="Cash"), amount=Decimal(100), direction=Posting.Debit),
            Posting(account=Account(code="2000", name="Accounts receivable"), amount=Decimal(100), direction=Posting.Credit),
        ],
    )

    # Define initial balances:

# Generated at 2022-06-18 02:37:22.467529
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import InitialBalances, ReadInitialBalances

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Read initial balances:
    ReadInitialBalances = Callable[[DateRange], InitialBalances]

    #: Read journal entries:
    ReadJournalEntries = Callable[[DateRange], Iterable[JournalEntry[_T]]]

    #: General ledger program:
    GeneralLedgerProgram = Callable[[DateRange], GeneralLedger[_T]]

    #: Test data:

# Generated at 2022-06-18 02:37:24.076841
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:37:34.979586
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, read_initial_balances, read_journal_entries

    ## Define the accounting period:
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

    ## Define the initial balances:

# Generated at 2022-06-18 02:38:16.023696
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .accounts import Account, AccountType
    from .generic import Balance
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from datetime import date
    import datetime
    from decimal import Decimal
    from typing import Dict, List, Optional, TypeVar
    from dataclasses import dataclass, field
    from typing import Generic, Iterable, List, Optional, Protocol, TypeVar
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, AccountType

# Generated at 2022-06-18 02:38:27.908259
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType

    ## Define a dummy read initial balances algebra:

# Generated at 2022-06-18 02:38:38.751561
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .types import Transaction

    ## Define a transaction type:
    class MyTransaction(Transaction):
        pass

    ## Define a read initial balances algebra implementation:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    ## Define a read journal entries algebra implementation:

# Generated at 2022-06-18 02:38:45.610226
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction
    from .generic import Balance
    from .ledgers import build_general_ledger
    from .commons import Currency

    ## Define a date range:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define accounts:
    a1 = Account("A1", AccountType.ASSET, Currency.USD)
    a2 = Account("A2", AccountType.ASSET, Currency.USD)
    a3 = Account("A3", AccountType.ASSET, Currency.USD)
    a4 = Account("A4", AccountType.ASSET, Currency.USD)

# Generated at 2022-06-18 02:38:50.475459
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a function which returns initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010", "Cash in Bank"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
            Account("1020", "Cash in Hand"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
        }

    # Define a function which returns journal entries:
    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return []

    # Compile the program:
    program = compile_general_led

# Generated at 2022-06-18 02:38:57.096738
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, Transaction

    ## Define accounts:
    a1 = Account("A1", AccountType.ASSET)
    a2 = Account("A2", AccountType.ASSET)
    a3 = Account("A3", AccountType.ASSET)
    a4 = Account("A4", AccountType.ASSET)
    a5 = Account("A5", AccountType.ASSET)
    a6 = Account("A6", AccountType.ASSET)
    a7 = Account("A7", AccountType.ASSET)
    a8 = Account("A8", AccountType.ASSET)
    a9 = Account("A9", AccountType.ASSET)

# Generated at 2022-06-18 02:39:07.132371
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    date = Date(2019, 1, 1)
    journal = Journal(date, "Test")
    posting = Posting(journal, account, Direction.DEBIT, Quantity(Decimal(10)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger
    assert ledger.account == account
    assert ledger.initial == initial
    assert len(ledger.entries) == 1
    assert ledger.entries[0].ledger == ledger
   

# Generated at 2022-06-18 02:39:15.155782
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:39:23.936039
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account
    from .generic import Balance

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:39:30.610217
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    ## Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:40:44.191438
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import Direction

    ## Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2019, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account("Assets", "Cash"), direction=Direction.DEBIT, amount=Decimal(100)),
            Posting(account=Account("Expenses", "Rent"), direction=Direction.CREDIT, amount=Decimal(100)),
        ],
    )

    ## Define initial balances:

# Generated at 2022-06-18 02:40:51.968092
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))