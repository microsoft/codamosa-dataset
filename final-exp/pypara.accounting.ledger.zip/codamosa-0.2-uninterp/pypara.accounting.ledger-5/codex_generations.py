

# Generated at 2022-06-18 02:31:07.308786
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .ledgers import compile_general_ledger_program, ReadInitialBalances, ReadJournalEntries
    from .commons.test import assert_equal

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:31:15.561405
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgering import build_general_ledger, compile_general_ledger_program, GeneralLedger, Ledger, LedgerEntry
    from .journaling import ReadJournalEntries
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting
    from .ledgering import Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program, GeneralLedger
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .accounts import Account
   

# Generated at 2022-06-18 02:31:23.643969
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger, LedgerEntry

    ## Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:31:30.270739
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Create a journal entry
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(
                account=Account(code="101", name="Cash"),
                amount=Decimal(100),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account(code="201", name="Accounts receivable"),
                amount=Decimal(100),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )

    # Create a journal
    journal = [journal_entry]

    # Create initial

# Generated at 2022-06-18 02:31:39.755609
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:31:40.770207
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:49.001614
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedgerProgram
    # Define the test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:31:55.775823
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("Test")
    initial = Balance(DateRange.since(datetime.date(2020, 1, 1)), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(1)), True)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting

# Generated at 2022-06-18 02:32:05.444154
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity

# Generated at 2022-06-18 02:32:11.358321
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a mock implementation of ReadInitialBalances
    class MockReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("1020"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
            }

    # Define a mock implementation of ReadJournalEntries

# Generated at 2022-06-18 02:32:27.700925
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import Ledger, build_general_ledger, compile_general_ledger_program
    from ..commons.zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal

    # Define the account
    account = Account("10100", "Cash")

    # Define the initial balance
    initial = Balance(date(2019, 1, 1), Quantity(Decimal(0)))

    # Define the ledger
    ledger = Ledger(account, initial)

    # Define the posting
    posting = Posting(account, date(2019, 1, 1), Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)



# Generated at 2022-06-18 02:32:36.368637
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    initial_balances = {
        Account("1010", "Cash"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(100))),
        Account("1020", "Bank"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(200))),
    }

# Generated at 2022-06-18 02:32:44.589291
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, InitialBalances, Ledger
    from .types import Transaction
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Optional, TypeVar
    from unittest import TestCase
    from unittest.mock import Mock, call

    _T = TypeVar("_T")

    class ReadInitialBalancesMock(Mock):
        def __call__(self, period: DateRange) -> InitialBalances:
            return self.return_value

    class ReadJournalEntriesMock(Mock):
        def __call__(self, period: DateRange) -> List[JournalEntry[_T]]:
            return

# Generated at 2022-06-18 02:32:53.443924
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, ReadInitialBalances, ReadJournalEntries

    # Define a test account:
    account = Account("Test Account")

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        postings=[
            Posting(account, Amount(Decimal(100)), True),
            Posting(account, Amount(Decimal(100)), False),
        ],
    )

    # Define a test initial balance:

# Generated at 2022-06-18 02:32:55.505197
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:33:03.980890
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the function compile_general_ledger_program.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy read_initial_balances algebra implementation:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(200))),
        }

    ## Define a dummy read_journal_entries algebra implementation:

# Generated at 2022-06-18 02:33:05.678824
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:33:13.935319
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program

    ## Define the period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define the initial balances:
    initial_balances = {
        Account("1010"): Balance(period.since, Quantity(Decimal(1000))),
        Account("1020"): Balance(period.since, Quantity(Decimal(2000))),
        Account("1030"): Balance(period.since, Quantity(Decimal(3000))),
    }

    ## Define the journal entries:
    journal_entries

# Generated at 2022-06-18 02:33:22.694541
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    ledger = Ledger(Account("A"), Balance(Date(1, 1, 1), Quantity(Decimal(0))))

    # Create a posting
    posting = Posting(Journal(Date(1, 1, 1), "Test"), Account("A"), Amount(Decimal(10)), 1)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(10))
    assert entry.date == Date(1, 1, 1)
   

# Generated at 2022-06-18 02:33:30.974412
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("A")
    initial = Balance(datetime.date(2020,1,1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    posting = Posting(datetime.date(2020,1,1), Quantity(Decimal(100)), account, 1)
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(100))
    posting = Posting(datetime.date(2020,1,1), Quantity(Decimal(100)), account, -1)
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(0))


# Generated at 2022-06-18 02:33:46.977546
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import ReadJournalEntries, ReadInitialBalances

    # Define a test account:
    account = Account("Test Account")

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        postings=[
            Posting(account=account, amount=Decimal(100), direction=Posting.Direction.DEBIT),
            Posting(account=account, amount=Decimal(100), direction=Posting.Direction.CREDIT),
        ],
    )

# Generated at 2022-06-18 02:33:56.426836
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a test implementation of ReadInitialBalances
    class TestReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("A1"): Balance(date(2018, 1, 1), Quantity(Decimal(100))),
                Account("A2"): Balance(date(2018, 1, 1), Quantity(Decimal(200))),
            }

    # Define a test implementation of ReadJournalEntries
    class TestReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            from .journaling import JournalEntry, Posting, Journal



# Generated at 2022-06-18 02:33:57.274924
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:07.322489
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Defines a protocol for reading initial balances.
    class ReadInitialBalances(Protocol):
        """
        Type of functions which reads and returns initial balances.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    #: Defines a protocol for reading journal entries.

# Generated at 2022-06-18 02:34:16.760516
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define a journal entry
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(account=Account("A"), amount=Amount(Decimal(100)), direction=1),
            Posting(account=Account("B"), amount=Amount(Decimal(100)), direction=1),
        ],
    )

    # Define a ledger
    ledger = Ledger(account=Account("A"), initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(Decimal(0))))

    # Add the journal entry to the ledger
    ledger.add(journal_entry.postings[0])

# Generated at 2022-06-18 02:34:28.618726
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = Journal(Date(2020, 1, 1), "Deposit")
    journal.add(Posting(account, Quantity(Decimal(100)), True))
    journal.add(Posting(Account(2, "Bank"), Quantity(Decimal(100)), False))

    # Add the journal entry to the ledger
    entry = ledger.add(journal.postings[0])

    # Check the

# Generated at 2022-06-18 02:34:29.105202
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:36.287712
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.types import Date

    ## Define the initial balances:

# Generated at 2022-06-18 02:34:47.081189
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:34:58.043737
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create posting
    journal = Journal(Date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(100)))

    # Add posting to ledger
    ledger.add(posting)

    # Check if posting was added
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].balance == Quantity(Decimal(100))


# Generated at 2022-06-18 02:35:39.462004
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:35:50.106653
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    from .journaling import build_journal_entry
    from .accounts import Account, AccountType, AccountCategory

    # Define a dummy read_initial_balances function

# Generated at 2022-06-18 02:36:00.309484
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from ..journaling.journaling import JournalEntry, Posting
    from ..journaling.accounts import Account
    from ..journaling.generic import Balance
    from ..journaling.journaling import JournalEntry, Posting
    from ..journaling.accounts import Account
    from ..journaling.generic import Balance
    from ..journaling.journaling import JournalEntry, Posting
    from ..journaling.accounts import Account
    from ..journaling.generic import Balance
    from ..journaling.journaling import JournalEntry, Posting
    from ..journaling.accounts import Account
    from ..journaling.generic import Balance
    from ..journaling.journaling import JournalEntry, Posting
    from ..journaling.accounts import Account
    from ..journaling.generic import Balance

# Generated at 2022-06-18 02:36:10.565654
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:36:20.877726
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:36:29.612465
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a journal entry
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account(code="1000", name="Cash"), amount=Amount(Decimal(100)), direction=1),
            Posting(account=Account(code="2000", name="Accounts Receivable"), amount=Amount(Decimal(100)), direction=-1),
        ],
    )

    # Define initial balances

# Generated at 2022-06-18 02:36:40.278857
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger

    # Define the period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    # Define the initial balances:
    initial_balances = {
        Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(1000))),
        Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(2000))),
    }

    # Define the journal entries:

# Generated at 2022-06-18 02:36:47.462942
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Read initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1000"): Balance(period.since, Quantity(Decimal(100))),
            Account("2000"): Balance(period.since, Quantity(Decimal(200))),
        }

    #: Read journal entries:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return

# Generated at 2022-06-18 02:36:57.069924
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a journal entry
    journal = Journal(Date(2020, 1, 1), "Test journal entry")
    journal.add(Posting(Account("Assets:Cash"), Direction.DEBIT, Amount(100)))
    journal.add(Posting(Account("Expenses:Food"), Direction.CREDIT, Amount(100)))

    # Create a ledger
    ledger = Ledger(Account("Assets:Cash"), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    # Add the journal entry to the ledger
    ledger.add(journal.postings[0])

    # Check the ledger entry
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:37:05.625217
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons.numbers import Amount, Quantity
    from datetime import date
    from decimal import Decimal

    # Create a ledger
    account = Account(1, "Test Account", "Test Account")
    initial = Balance(date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting

# Generated at 2022-06-18 02:38:45.054082
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:38:53.521836
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, \
        InitialBalances, Ledger, LedgerEntry, ReadInitialBalances

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:38:58.696228
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger
    """
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("A1", "Account 1")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(datetime.date(2020, 1, 1), "Journal 1")
    posting = Posting(journal, account, Amount(Decimal(10)), 1)

    # Add the posting to the ledger

# Generated at 2022-06-18 02:39:07.747118
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Setup
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances
    from .ledgers import build_general_ledger
    from .ledgers import compile_general_ledger_program
    from .ledgers import GeneralLedger
    from .ledgers import Ledger
    from .ledgers import LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Iterable, List
    from unittest import TestCase
    from unittest.mock import MagicMock
    from unittest.mock import patch

    # Setup:

# Generated at 2022-06-18 02:39:15.171778
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .algebra import ReadInitialBalances, ReadJournalEntries

    # Define a dummy implementation of ReadInitialBalances:

# Generated at 2022-06-18 02:39:23.973070
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Set up the mock:
    mock = Mock(spec=ReadInitialBalances)
    mock.__call__.return_value = {
        Account("1"): Balance(date(2019, 1, 1), Decimal(100)),
        Account("2"): Balance(date(2019, 1, 1), Decimal(200)),
    }

    # Call the method:
    result = mock(DateRange(date(2019, 1, 1), date(2019, 12, 31)))

    # Assert the result:

# Generated at 2022-06-18 02:39:30.656356
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Direction

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", [Posting(account, Direction.DEBIT, Quantity(Decimal(100)))])
    posting = journal.postings[0]

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
   

# Generated at 2022-06-18 02:39:38.433625
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    ledger = Ledger(Account("100"), Balance(Date(2019, 1, 1), Quantity(Decimal(0))))

    # Create a journal
    journal = Journal(Date(2019, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, Account("100"), Amount(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))

    # Create a second posting
    posting = Posting(journal, Account("100"), Amount(Decimal(-50)))

    # Add the second posting to the ledger
    ledger

# Generated at 2022-06-18 02:39:47.130380
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a dummy implementation of ReadInitialBalances
    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("A1"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("A2"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
            }

    # Define a dummy implementation of ReadJournalEntries

# Generated at 2022-06-18 02:39:51.112129
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:40:59.138123
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    ledger = Ledger(Account("A"), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, Account("A"), Quantity(Decimal(10)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(10))