

# Generated at 2022-06-18 02:31:02.529776
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:12.204481
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
    initial_balances = {
        Account("1010", "Cash"): Balance(date(2019, 12, 31), Quantity(Decimal(1000))),
        Account("1020", "Bank"): Balance(date(2019, 12, 31), Quantity(Decimal(2000))),
    }

    # Define test implementation:

# Generated at 2022-06-18 02:31:21.660290
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    # Create a journal
    journal = Journal(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(
                account=Account(code="1010", name="Cash"),
                amount=Amount(Decimal(100)),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account(code="1020", name="Accounts Receivable"),
                amount=Amount(Decimal(100)),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )

    # Create a ledger
   

# Generated at 2022-06-18 02:31:27.272207
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries
    from .accounts import Account, AccountType, ReadAccounts
    from .accounts import ReadAccountBalances
    from .accounts import build_account_balances
    from .accounts import build_accounts
    from .journaling import build_journal_entries
    from .journaling import JournalEntry
    from .journaling import Posting
    from .journaling import Transaction
    from .journaling import TransactionType
    from .journaling import build_transactions
    from .journaling import ReadTransactions
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount
    from .commons.numbers import Quantity
    from .commons.numbers import Currency
    from .commons.numbers import Unit
    from .commons.numbers import Rate
   

# Generated at 2022-06-18 02:31:37.766225
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a ledger
    account = Account("Test")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(datetime.date(2020, 1, 1), Quantity(Decimal(100)), account)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check if the ledger entry was added
    assert ledger.entries[0].balance == Quantity(Decimal(100))

    # Create a second posting
    posting = Posting(datetime.date(2020, 1, 2), Quantity(Decimal(200)), account)

    # Add the second posting to the ledger
    ledger.add(posting)

    # Check if the ledger entry was added

# Generated at 2022-06-18 02:31:45.968484
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Optional, TypeVar
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Optional, TypeVar
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import Date

# Generated at 2022-06-18 02:31:51.755295
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, Ledger, LedgerEntry

    # Define test data
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

# Generated at 2022-06-18 02:32:02.118249
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction

    # Create a ledger
    account = Account("Test account", AccountType.ASSET)
    initial = Balance(Date(2018, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(Direction.DEBIT, Quantity(Decimal(100)), Date(2018, 1, 1), JournalEntry("Test journal entry"))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].ledger

# Generated at 2022-06-18 02:32:08.899536
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """

    # Define a test function which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(0))),
            Account("1020"): Balance(period.since, Quantity(Decimal(0))),
            Account("1030"): Balance(period.since, Quantity(Decimal(0))),
        }

    # Define a test function which reads journal entries:

# Generated at 2022-06-18 02:32:17.226646
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest import TestCase, mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class Test(TestCase):
        def test_it(self):
            # Arrange:
            period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:32:30.111189
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a test journal:

# Generated at 2022-06-18 02:32:37.856673
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a journal entry:
    entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(account=Account("A"), amount=Amount(100), direction=Posting.Direction.DEBIT),
            Posting(account=Account("B"), amount=Amount(100), direction=Posting.Direction.CREDIT),
        ],
    )

    ## Define initial balances:
    initial_balances = {Account("A"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(0)))}

    ## Build the general ledger:

# Generated at 2022-06-18 02:32:45.161605
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .generic import Balance

    ## Define the accounting period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define initial balances:

# Generated at 2022-06-18 02:32:53.782236
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting

    ## Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:33:03.526478
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .ledgers import Ledger, LedgerEntry
    from .generic import Balance
    from .accounts import Account
    from .journaling import Journal, Posting
    from .ledgers import Ledger, LedgerEntry
    from .generic import Balance
    from .accounts import Account
    from .journaling import Journal, Posting
    from .ledgers import Ledger, LedgerEntry
    from .generic import Balance
    from .accounts import Account
    from .journaling import Journal, Posting
    from .ledgers import Ledger, LedgerEntry
    from .generic import Balance
    from .accounts import Account
    from .journaling import Journal, Posting
    from .ledgers import Ledger, LedgerEntry

# Generated at 2022-06-18 02:33:11.954633
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import Ledger, build_general_ledger, compile_general_ledger_program
    from ..commons.zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Iterable, List, Optional, TypeVar
    import datetime
    from dataclasses import dataclass, field
    from typing import Dict, Generic, Iterable, List, Optional, TypeVar
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger, build_general_ledger, compile

# Generated at 2022-06-18 02:33:20.834352
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:33:27.373088
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define a journal entry:
    entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(account=Account("1010", "Cash"), amount=Amount(Decimal(100)), direction=Posting.Direction.DEBIT),
            Posting(account=Account("1020", "Bank"), amount=Amount(Decimal(100)), direction=Posting.Direction.CREDIT),
        ],
    )

    # Define a read journal entries algebra:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [entry]

    # Define a read initial balances algebra:

# Generated at 2022-06-18 02:33:35.236473
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance

    # Create a ledger
    account = Account("1", "Test account")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test journal")

    # Create a posting
    posting = Posting(journal, account, Direction.Debit, Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))


# Generated at 2022-06-18 02:33:44.461696
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Journal, Posting, JournalEntry
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .ledgers import build_general_ledger, Ledger, LedgerEntry, GeneralLedger
    from datetime import date

    # Define accounts:

# Generated at 2022-06-18 02:34:04.803108
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    ## Create a ledger:
    ledger = Ledger(Account("Assets", "Cash"), Balance(Date(2019, 1, 1), Quantity(Decimal(0))))

    ## Create a journal:
    journal = Journal(Date(2019, 1, 1), "Cash deposit", [Posting(Direction.Debit, Account("Assets", "Cash"), Quantity(Decimal(100)))])

    ## Add the journal to the ledger:
    entry = ledger.add(journal.postings[0])

    ## Check the ledger entry:
    assert entry.date == journal.date
    assert entry.description == journal.description
    assert entry.amount == journal.postings[0].amount
    assert entry.cntracct

# Generated at 2022-06-18 02:34:09.647716
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection

    # Create a ledger
    account = Account(AccountType.ASSET, "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, account, PostingDirection.DEBIT, Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))

    # Create a second posting

# Generated at 2022-06-18 02:34:17.703005
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    ## Create a ledger:
    ledger = Ledger(Account("A"), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    ## Create a journal:
    journal = Journal(Date(2020, 1, 1), "Test")

    ## Create a posting:
    posting = Posting(journal, Account("A"), Amount(Decimal(100)))

    ## Add the posting to the ledger:
    entry = ledger.add(posting)

    ## Check the ledger entry:
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100))

    ## Create another posting:
    posting = Posting(journal, Account("A"), Amount(Decimal(200)))

    ## Add

# Generated at 2022-06-18 02:34:28.999212
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """
    ## Mock initial balances:
    initial_balances = {
        Account("1110"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
        Account("1120"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(200))),
    }

    ## Mock journal entries:

# Generated at 2022-06-18 02:34:36.222774
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Define a dummy read initial balances algebra implementation:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("Assets", "Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account("Assets", "Accounts Receivable"): Balance(period.since, Quantity(Decimal(200))),
            Account("Liabilities", "Accounts Payable"): Balance(period.since, Quantity(Decimal(300))),
            Account("Equity", "Capital"): Balance(period.since, Quantity(Decimal(400))),
        }

    ## Define a dummy read journal entries algebra implementation:

# Generated at 2022-06-18 02:34:47.039178
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Setup
    mock = Mock(spec=ReadInitialBalances)

# Generated at 2022-06-18 02:34:58.361077
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a ledger
    ledger = Ledger(Account('1234'), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), 'test', [Posting(Account('1234'), Amount(Decimal(100))), Posting(Account('4321'), Amount(Decimal(100)))])
    # Create a posting
    posting = Posting(Account('1234'), Amount(Decimal(100)))
    # Add the posting to the ledger
    ledger.add(posting)
    # Check that the ledger has one entry
    assert len(ledger.entries) == 1
    # Check that the ledger entry has the correct balance
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Unit

# Generated at 2022-06-18 02:35:08.238631
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create an account
    account = Account("1", "Cash")

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, account, Amount(100), True)

    # Create a ledger
    ledger = Ledger(account, Balance(Date(2020, 1, 1), Quantity(0)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(100)

# Generated at 2022-06-18 02:35:19.894815
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account(1, "Cash", AccountType.ASSET)
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(1, Date(2019, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))

    # Add another posting to the ledger
    posting = Posting

# Generated at 2022-06-18 02:35:28.030121
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import compile_journal_entries_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program
    from .accounts import compile_accounts_program

# Generated at 2022-06-18 02:35:44.733553
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:35:54.020328
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    # Define a dummy implementation of ReadInitialBalances:
    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("1020", "Accounts Receivable"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
                Account("1030", "Inventory"): Balance(date(2019, 1, 1), Quantity(Decimal(300))),
            }



# Generated at 2022-06-18 02:36:04.614440
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    initial_balances = {
        Account("1010", "Cash"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(100))),
        Account("1020", "Bank"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(200))),
    }

# Generated at 2022-06-18 02:36:05.574202
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:14.691911
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    initial = {Account("1.1.1"): Balance(period.since, Quantity(Decimal(0)))}
    journal = [
        JournalEntry(
            period.since,
            "Test",
            [
                Posting(Account("1.1.1"), Quantity(Decimal(100)), period.since),
                Posting(Account("1.1.2"), Quantity(Decimal(100)), period.since),
            ],
        )
    ]

    gl = build_general_ledger(period, journal, initial)


# Generated at 2022-06-18 02:36:25.209035
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List
    from ..commons.numbers import Amount, Quantity

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry

# Generated at 2022-06-18 02:36:32.978652
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, read_journal_entries

    # Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Define the initial balances:

# Generated at 2022-06-18 02:36:43.592015
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a test period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define some test accounts:
    a1 = Account(1, "A1", "Account 1")
    a2 = Account(2, "A2", "Account 2")
    a3 = Account(3, "A3", "Account 3")
    a4 = Account(4, "A4", "Account 4")

    ## Define some test initial balances:

# Generated at 2022-06-18 02:36:52.824493
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger

    # Define a date range:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Define initial balances:

# Generated at 2022-06-18 02:37:02.884065
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Iterable
    from unittest import TestCase


# Generated at 2022-06-18 02:37:50.752993
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange
    from . import ledger

    ## Define a test account:
    account = Account(AccountType.ASSET, "Test Account", "TEST", "TEST")

    ## Define a test journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", [
        Posting(account, Amount(Decimal(100)), ledger.Debit),
        Posting(account, Amount(Decimal(100)), ledger.Credit),
    ])

    ## Define a test initial balance:
    initial_balance = ledger.Balance(datetime.date(2019, 12, 31), Quantity(Decimal(0)))

    ## Def

# Generated at 2022-06-18 02:38:00.869189
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    # Define a test implementation of the algebra:
    class TestReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("1020", "Bank"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
            }

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:38:01.611353
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:13.195022
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a dummy implementation of the algebra:
    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash in Bank"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("1020", "Cash on Hand"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
            }

    # Define a dummy journal entry:

# Generated at 2022-06-18 02:38:20.003075
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances:

# Generated at 2022-06-18 02:38:29.050826
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry
    from .types import Transaction

    # Define a transaction type:
    class Transaction(Transaction):
        pass

    # Define a program:

# Generated at 2022-06-18 02:38:38.981530
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    initial_balances = {
        Account("1000"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(100))),
        Account("2000"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(200))),
    }

# Generated at 2022-06-18 02:38:47.802981
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Define a journal entry

# Generated at 2022-06-18 02:38:55.585589
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    # Define a dummy implementation of ReadInitialBalances

# Generated at 2022-06-18 02:39:05.274405
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define some accounts:
    cash = Account("Cash", "Assets")
    revenue = Account("Revenue", "Income")
    expenses = Account("Expenses", "Expenses")

    ## Define some initial balances:
    initial_balances = {
        cash: Balance(DateRange.since(datetime.date(2018, 1, 1)), Quantity(Decimal(100))),
        revenue: Balance(DateRange.since(datetime.date(2018, 1, 1)), Quantity(Decimal(0))),
        expenses: Balance(DateRange.since(datetime.date(2018, 1, 1)), Quantity(Decimal(0))),
    }

    ## Def

# Generated at 2022-06-18 02:40:22.481186
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection

    # Create a ledger
    ledger = Ledger(Account("1", AccountType.ASSET), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    # Create a posting
    posting = Posting(
        Journal(Date(2020, 1, 1), "Test", [Posting(Account("2", AccountType.ASSET), PostingDirection.CREDIT, Quantity(Decimal(100)))]),
        Account("1", AccountType.ASSET),
        PostingDirection.DEBIT,
        Quantity(Decimal(100)),
    )

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger


# Generated at 2022-06-18 02:40:31.689074
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}


# Generated at 2022-06-18 02:40:39.439132
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Amount, Quantity


# Generated at 2022-06-18 02:40:47.721828
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import AccountType

    # Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(Account(AccountType.ASSET, "Cash"), Amount(100)),
            Posting(Account(AccountType.EXPENSE, "Salaries"), Amount(100)),
        ],
    )

    # Define initial balances:

# Generated at 2022-06-18 02:40:53.575787
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, LedgerEntry, Ledger
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Iterable, List
    from unittest import TestCase

    # Defines a stub implementation of the algebra which reads initial balances.