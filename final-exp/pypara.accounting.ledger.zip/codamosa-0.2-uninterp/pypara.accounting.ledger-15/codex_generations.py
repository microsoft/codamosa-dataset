

# Generated at 2022-06-18 02:31:10.826817
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances.
    initial = {
        Account("101", "Cash"): Balance(period.since, Quantity(Decimal(1000))),
        Account("102", "Accounts Receivable"): Balance(period.since, Quantity(Decimal(2000))),
        Account("103", "Inventory"): Balance(period.since, Quantity(Decimal(3000))),
    }

    #: Journal entries.

# Generated at 2022-06-18 02:31:20.213765
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import Transaction
    from ..commons.zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances as of the end of previous financial period:

# Generated at 2022-06-18 02:31:24.744353
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy read initial balances implementation:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("101", "Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account("102", "Accounts Receivable"): Balance(period.since, Quantity(Decimal(200))),
            Account("103", "Inventory"): Balance(period.since, Quantity(Decimal(300))),
        }

    # Define a dummy read journal entries implementation:

# Generated at 2022-06-18 02:31:31.758089
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Create a ledger
    account = Account("A")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    date = datetime.date(2020, 1, 1)
    journal = JournalEntry(date, "Description")
    amount = Amount(Decimal(100))
    posting = Posting(journal, account, amount)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:31:40.424095
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(Date(2020, 1, 1), "Journal")
    posting = Posting(journal, account, Quantity(Decimal(1)))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(1))

# Generated at 2022-06-18 02:31:47.287352
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a ledger
    ledger = Ledger(Account("A"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    # Create a posting
    posting = Posting(datetime.date(2020, 1, 1), Account("A"), Quantity(Decimal(100)))
    # Add the posting to the ledger
    ledger.add(posting)
    # Check if the ledger has the posting
    assert ledger.entries[0].posting == posting
    # Check if the balance of the ledger is correct
    assert ledger.entries[0].balance == Quantity(Decimal(100))


# Generated at 2022-06-18 02:31:56.756789
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    ## Define a dummy read initial balances algebra implementation:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    ## Define a dummy read journal entries algebra implementation:

# Generated at 2022-06-18 02:32:05.971345
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:32:15.973544
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry

    # Create a journal entry
    journal_entry = JournalEntry(
        date(2020, 1, 1),
        "Test journal entry",
        [
            Posting(Direction.DEBIT, Amount(Decimal(100)), Account(AccountType.ASSET, "Cash")),
            Posting(Direction.CREDIT, Amount(Decimal(100)), Account(AccountType.ASSET, "Cash")),
        ],
    )

   

# Generated at 2022-06-18 02:32:27.101253
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(0))),
            Account("1020"): Balance(period.since, Quantity(Decimal(0))),
            Account("1030"): Balance(period.since, Quantity(Decimal(0))),
            Account("1040"): Balance(period.since, Quantity(Decimal(0))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:32:32.302691
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:38.846796
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest.mock import Mock
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .generic import Balance

    # Arrange
    mock = Mock(spec=ReadInitialBalances)
    mock.__call__.return_value = {Account("A"): Balance(date(2020, 1, 1), Quantity(Decimal(0)))}
    period = DateRange(date(2020, 1, 1), date(2020, 1, 31))

    # Act
    result = mock.__call__(period)

    # Assert
    assert result == {Account("A"): Balance(date(2020, 1, 1), Quantity(Decimal(0)))}



# Generated at 2022-06-18 02:32:41.051569
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:51.322162
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries
    from .accounts import ReadInitialBalances
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting
    from .generic import Quantity
    from .commons.numbers import Amount
    from .journaling import Direction
    from .journaling import Journal
    from .journaling import Posting
    from .journaling import Direction
    from .journaling import Journal
    from .journaling import Posting
    from .journaling import Direction
    from .journaling import Journal
    from .journaling import Posting
    from .journaling import Direction
    from .journaling import Journal
    from .journaling import Posting
    from .journaling import Direction

# Generated at 2022-06-18 02:33:02.249875
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .generic import Quantity
    from .commons.numbers import Amount

    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:33:11.622869
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(200))),
        }


# Generated at 2022-06-18 02:33:19.388417
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import AccountType, Account
    from .journaling import JournalEntry, Posting, Direction
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity

    # Create a sample journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Sample journal entry",
        postings=[
            Posting(Direction.DEBIT, Account(AccountType.ASSET, "1010"), Amount(Decimal(1000))),
            Posting(Direction.CREDIT, Account(AccountType.LIABILITY, "2010"), Amount(Decimal(1000))),
        ],
    )

    # Create a sample initial balance:

# Generated at 2022-06-18 02:33:30.184052
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:33:36.581911
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgering import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedgerProgram, GeneralLedger
    from .reporting import ReadJournalEntries
    from .typing import JournalEntryType
    from .unit_testing import JournalEntryTypeStub, ReadJournalEntriesStub
    from .utilities import read_journal_entries_from_csv

    # Define a stub for ReadInitialBalances

# Generated at 2022-06-18 02:33:44.691606
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test journal")
    # Create a posting
    posting = Posting(journal, Account(AccountType.ASSET, "Cash"), Amount(100), 1)
    # Create a ledger
    ledger = Ledger(Account(AccountType.ASSET, "Cash"), Balance(Date(2020, 1, 1), Quantity(0)))
    # Add the posting to the ledger
    ledger.add(posting)
    # Check the balance
    assert ledger.entries[0].balance == Quantity(100)

# Generated at 2022-06-18 02:33:53.643137
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:00.818952
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction

    account = Account(AccountType.ASSET, "A", "A")
    ledger = Ledger(account, Balance(Date(2020, 1, 1), Quantity(Decimal(0))))
    journal = JournalEntry(Date(2020, 1, 1), "J", [Posting(account, Direction.DEBIT, Quantity(Decimal(100)))])
    posting = journal.postings[0]
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(100))
    assert entry.amount == Quantity(Decimal(100))
    assert entry.debit == Quantity(Decimal(100))
    assert entry.credit == None
    assert entry.is_debit

# Generated at 2022-06-18 02:34:11.997197
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a program which builds a general ledger:

# Generated at 2022-06-18 02:34:23.999489
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, Ledger, LedgerEntry

    ## Define test data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    initial_balances = {
        Account("1110", "Cash"): Balance(period.since, Quantity(Decimal(1000))),
        Account("1120", "Bank"): Balance(period.since, Quantity(Decimal(2000))),
    }

# Generated at 2022-06-18 02:34:33.190140
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance

    # Create a ledger
    account = Account(1, "Test Account", "Test Account", None)
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(
        Journal(Date(2020, 1, 1), "Test Journal", "Test Journal", [], []),
        account,
        Direction.DEBIT,
        Amount(Decimal(100)),
    )

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger

# Generated at 2022-06-18 02:34:44.553983
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define the accounting period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    # Define initial balances:

# Generated at 2022-06-18 02:34:52.527615
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest.mock import MagicMock
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Arrange
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
    account = Account("1010", "Cash")
    balance = Balance(date(2020, 1, 1), Quantity(Decimal(100)))
    initial_balances = {account: balance}
    read_initial_balances = MagicMock(spec=ReadInitialBalances)
    read_initial_balances.__call__.return_value = initial_balances

    # Act
    result = read_initial_balances(period)

    #

# Generated at 2022-06-18 02:35:01.498836
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .ledgers import GeneralLedger, Ledger, LedgerEntry
    from datetime import date
    from typing import Dict, List
    from decimal import Decimal

    # Define the initial balances:

# Generated at 2022-06-18 02:35:11.218074
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    ## Import modules under test:
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, GeneralLedgerProgram, build_general_ledger, compile_general_ledger_program

    ## Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:35:21.175426
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, Ledger, LedgerEntry
    from .books import Book
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, Ledger, LedgerEntry
    from .books import Book
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_

# Generated at 2022-06-18 02:36:07.842022
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    # Define a mock implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {
            Account("1010", "Cash"): Balance(date(2020, 1, 1), Decimal(100)),
            Account("1020", "Accounts Receivable"): Balance(date(2020, 1, 1), Decimal(200)),
        }

    # Define a mock implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:36:17.218638
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, read_journal_entries

    ## Define the accounting period:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

    ## Define the initial balances:

# Generated at 2022-06-18 02:36:27.158148
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, PostingDirection

    #: Accounting period.
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

    #: Initial balances.

# Generated at 2022-06-18 02:36:34.715953
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .commons import ReadInitialBalances, ReadJournalEntries
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Iterable, List
    from unittest.mock import MagicMock

    # Define a test period:
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

    # Define a test account:
    account = Account("Assets", "Current Assets", "Cash")

    # Define a test initial balance:

# Generated at 2022-06-18 02:36:44.182731
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest import TestCase
    from unittest.mock import Mock, call

    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class Test(TestCase):
        def test(self):
            # Arrange
            period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
            read_initial_balances = Mock(spec=ReadInitialBalances)

# Generated at 2022-06-18 02:36:53.272172
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import LedgerEntry

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:37:03.318401
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

    #: Initial balances as of the end of previous financial period.

# Generated at 2022-06-18 02:37:12.112925
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from pytest import raises
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    # Define a mock implementation of ReadInitialBalances
    class MockReadInitialBalances(ReadInitialBalances):
        def __init__(self, initial_balances):
            self.initial_balances = initial_balances

        def __call__(self, period):
            return self.initial_balances

    # Define a mock implementation of ReadJournalEntries
    class MockReadJournalEntries(ReadJournalEntries):
        def __init__(self, journal_entries):
            self.journal_entries = journal_entries

        def __call__(self, period):
            return self.journal_entries

    # Def

# Generated at 2022-06-18 02:37:22.447200
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .ledgers import GeneralLedger, Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(Account("1010", "Cash"), Amount(100), Posting.Direction.DEBIT),
            Posting(Account("1020", "Accounts Receivable"), Amount(100), Posting.Direction.CREDIT),
        ],
    )

    # Define a test

# Generated at 2022-06-18 02:37:28.743264
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    account = Account("1.1.1")
    journal = Journal(Date(2020, 1, 1), "Test")
    posting = Posting(account, Decimal(100), journal)
    initial = Balance(Date(2020, 1, 1), Decimal(0))
    ledger = Ledger(account, initial)
    ledger.add(posting)
    assert ledger.entries[0].balance == Decimal(100)
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].ledger == ledger
    assert ledger.entries[0].date == Date(2020, 1, 1)

# Generated at 2022-06-18 02:38:16.360936
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a test period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define test journal entries:

# Generated at 2022-06-18 02:38:28.009089
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction

    # Create accounts
    a1 = Account(1, AccountType.ASSET, "Cash")
    a2 = Account(2, AccountType.ASSET, "Accounts Receivable")
    a3 = Account(3, AccountType.LIABILITY, "Accounts Payable")
    a4 = Account(4, AccountType.EQUITY, "Retained Earnings")
    a5 = Account(5, AccountType.REVENUE, "Sales")
    a6 = Account(6, AccountType.EXPENSE, "Cost of Goods Sold")

    # Create journal entries
    j1 = JournalEntry(date(2020, 1, 1), "Cash received from customers")

# Generated at 2022-06-18 02:38:38.834882
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction

    ## Define a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test transaction",
        postings=[
            Posting(account=Account(code="101", name="Cash", type=AccountType.ASSET), amount=Decimal("100")),
            Posting(account=Account(code="201", name="Revenue", type=AccountType.REVENUE), amount=Decimal("-100")),
        ],
    )

    ## Define a journal entry:

# Generated at 2022-06-18 02:38:45.610605
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry
    from .commons import Direction

    # Create a ledger
    ledger = Ledger(Account("A"), Balance(Date(2019, 1, 1), Quantity(0)))

    # Create a posting
    posting = Posting(Journal(Date(2019, 1, 1), "Test"), Account("A"), Direction.DEBIT, Quantity(100))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entry
    assert ledger.entries[0].balance == Quantity(100)
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].ledger == ledger


# Generated at 2022-06-18 02:38:50.476070
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction, TransactionType

    ## Define accounts:
    cash = Account("Cash", AccountType.ASSET)
    accounts_receivable = Account("Accounts Receivable", AccountType.ASSET)
    sales = Account("Sales", AccountType.REVENUE)
    accounts_payable = Account("Accounts Payable", AccountType.LIABILITY)
    purchases = Account("Purchases", AccountType.EXPENSE)

    ## Define transactions:
    sale = Transaction(TransactionType.SALE, "Sale of goods")
    purchase = Transaction(TransactionType.PURCHASE, "Purchase of goods")

    ## Define journal entries:

# Generated at 2022-06-18 02:38:57.106213
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances as of the end of previous financial period:

# Generated at 2022-06-18 02:39:07.133316
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .types import AccountId, AccountName, Amount, Balance, Date, Quantity

    ## Define test data:
    period = DateRange(Date(2020, 1, 1), Date(2020, 12, 31))
    initial_balances = {
        Account(AccountId("1"), AccountName("Cash"), AccountType.ASSET): Balance(Date(2020, 1, 1), Quantity(100)),
        Account(AccountId("2"), AccountName("Equity"), AccountType.EQUITY): Balance(Date(2020, 1, 1), Quantity(0)),
    }

# Generated at 2022-06-18 02:39:08.476690
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:39:15.695301
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, Ledger, LedgerEntry

    # Define a test account:
    account = Account("1234", "Test Account")

    # Define a test initial balance:
    initial_balance = Balance(datetime.date(2019, 1, 1), Quantity(Decimal(100)))

    # Define a test journal entry:
    journal_entry = JournalEntry(
        datetime.date(2019, 1, 2), "Test Journal Entry", [Posting(account, Quantity(Decimal(10)), True)]
    )

    # Define a test period:
    period = Date

# Generated at 2022-06-18 02:39:24.629788
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account(code="1100", name="Cash"), amount=Amount(Decimal(100)), direction=1),
            Posting(account=Account(code="1200", name="Accounts receivable"), amount=Amount(Decimal(100)), direction=-1),
        ],
    )

    # Define initial balances: