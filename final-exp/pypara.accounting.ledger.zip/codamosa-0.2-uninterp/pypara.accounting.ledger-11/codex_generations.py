

# Generated at 2022-06-18 02:31:10.404009
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, ReadInitialBalances, ReadJournalEntries
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Iterable
    from unittest import TestCase


# Generated at 2022-06-18 02:31:20.052495
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances as of the end of previous financial period.

# Generated at 2022-06-18 02:31:26.347294
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import Ledger, build_general_ledger, compile_general_ledger_program
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from datetime import date
    import pytest

    # Define a journal entry:

# Generated at 2022-06-18 02:31:27.315135
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:37.801018
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from ..journaling.model import JournalEntry, Posting
    from ..journaling.repository import InMemoryJournalEntryRepository
    from ..journaling.service import JournalEntryService
    from .accounts import Account, AccountType
    from .algebra import ReadInitialBalances
    from .model import Balance
    from .repository import InMemoryAccountRepository
    from .service import AccountService

    ## Create account service:
    account_repo = InMemoryAccountRepository()
    account_service = AccountService(account_repo)

    ## Create journal entry service:
    journal_repo = InMemoryJournalEntryRepository()
    journal_service = JournalEntryService(journal_repo)

    ## Create accounts:
    account

# Generated at 2022-06-18 02:31:46.001201
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection

    ## Create a ledger for an asset account:
    ledger = Ledger(Account("A", AccountType.ASSET), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    ## Add a debit posting:
    posting = Posting(
        Journal(Date(2020, 1, 1), "Debit posting", [Posting(Account("A", AccountType.ASSET), PostingDirection.DEBIT, Quantity(Decimal(100)))]),
        Account("A", AccountType.ASSET),
        PostingDirection.DEBIT,
        Quantity(Decimal(100)),
    )
    entry = ledger.add(posting)
    assert entry.balance == Quantity

# Generated at 2022-06-18 02:31:51.802653
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020"): Balance(period.since, Quantity(Decimal(200))),
        }


# Generated at 2022-06-18 02:32:02.119940
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the ReadInitialBalances algebra:

# Generated at 2022-06-18 02:32:08.899571
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, ReadAccounts
    from .accounting import AccountingPeriod, ReadAccountingPeriods
    from .books import Book, ReadBooks
    from .companies import Company, ReadCompanies
    from .currencies import Currency, ReadCurrencies
    from .fiscal import FiscalYear, ReadFiscalYears
    from .generic import Balance
    from .ledgers import Ledger, ReadLedgers
    from .numbers import Amount, Quantity
    from .periods import Period, ReadPeriods
    from .users import User, ReadUsers
    from .zeitgeist import DateRange
    from .commons.algebra import Algebra
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

# Generated at 2022-06-18 02:32:13.657601
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, PostingDirection

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = Journal(Date(2020, 1, 1), "Test", [Posting(account, PostingDirection.DEBIT, Quantity(Decimal(100)))])

    # Add the journal entry to the ledger
    ledger.add(journal.postings[0])

    # Check the result
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:32:29.758629
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from ..journaling.models import JournalEntry, Posting
    from ..journaling.types import JournalEntryId
    from .accounts import Account, AccountType
    from .generic import Balance
    from .journaling import ReadJournalEntries
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry

    ## Define a journal entry:

# Generated at 2022-06-18 02:32:37.753014
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:32:44.698936
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = Journal(Date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(100)), 1)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the balance of the ledger
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:32:53.518768
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import JournalEntry, Posting, Direction

    # Create a ledger
    account = Account(1, "Test Account")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(Direction.DEBIT, Date(2019, 1, 1), Quantity(Decimal(100)), JournalEntry(1, "Test Journal"))

    # Add the posting to the ledger
    ledger_entry = ledger.add(posting)

    # Check the ledger entry
    assert ledger_entry.ledger == ledger
    assert ledger_entry.posting == posting
    assert ledger_entry.balance == Quantity(Decimal(100))
    assert ledger_entry

# Generated at 2022-06-18 02:33:03.525457
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger
    from .ledgering import compile_general_ledger_program
    from .ledgering import GeneralLedger
    from .ledgering import GeneralLedgerProgram
    from .ledgering import InitialBalances
    from .ledgering import Ledger
    from .ledgering import LedgerEntry
    from .ledgering import ReadInitialBalances
    from .ledgering import ReadJournalEntries
    from .ledgering import test_ReadInitialBalances___call__
    from .ledgering import test_ReadJournalEntries___call__
    from .ledgering import test_build_general_

# Generated at 2022-06-18 02:33:11.954890
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance

    # Create a ledger
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-18 02:33:13.506078
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:33:23.224524
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(
                account=Account(code="1010", name="Cash"),
                amount=Amount(Decimal(100)),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account(code="1020", name="Bank"),
                amount=Amount(Decimal(100)),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )



# Generated at 2022-06-18 02:33:32.863540
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    initial = {
        Account("1110"): Balance(period.since, Quantity(Decimal(100))),
        Account("1120"): Balance(period.since, Quantity(Decimal(200))),
    }

# Generated at 2022-06-18 02:33:38.184064
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, read_journal_entries

    # Define a date range:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Define a journal entry:

# Generated at 2022-06-18 02:33:57.869319
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020"): Balance(period.since, Quantity(Decimal(200))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:33:58.859885
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:09.538861
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(
        datetime.date(2020, 1, 1),
        Account("Assets", "Cash"),
        Account("Expenses", "Rent"),
        Quantity(Decimal(100)),
        "Rent payment",
    )

    # Add the posting to the ledger
    ledger.add(posting)

    # Create a ledger entry
    ledger

# Generated at 2022-06-18 02:34:17.640020
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:34:28.958886
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import ReadInitialBalances

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Type of functions which reads and returns initial balances.
    ReadInitialBalances = Callable[[DateRange], InitialBalances]

    #: Test data.

# Generated at 2022-06-18 02:34:29.850948
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:41.141841
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.types import Direction
    from .commons.types import TransactionType
    from .commons.types import TransactionStatus
    from .commons.types import TransactionNature
    from .commons.types import TransactionMethod
    from .commons.types import TransactionSource
    from .commons.types import TransactionClass
    from .commons.types import TransactionPhase
    from .commons.types import TransactionStage
    from .commons.types import TransactionScope
    from .commons.types import TransactionRole
    from .commons.types import TransactionParty
    from .commons.types import TransactionParty

# Generated at 2022-06-18 02:34:50.254927
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, GeneralLedgerProgram
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Iterable
    from unittest import TestCase

    class TestReadInitialBalances:
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return {
                Account("1"): Balance(date(2020, 1, 1), Decimal(100)),
                Account("2"): Balance(date(2020, 1, 1), Decimal(200)),
            }


# Generated at 2022-06-18 02:34:51.426604
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"


# Generated at 2022-06-18 02:35:00.749394
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account(AccountType.ASSET, "Cash"): Balance(period.since, Quantity(Decimal(100)))}


# Generated at 2022-06-18 02:35:42.428896
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting, ReadJournalEntries
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .general_ledger import build_general_ledger, Ledger, LedgerEntry, GeneralLedger

    # Create a journal:
    journal = Journal(
        date=datetime.date(2020, 1, 1),
        description="Test journal",
        postings=[
            Posting(account=Account(code="1010", name="Cash"), amount=Amount(Decimal(100))),
            Posting(account=Account(code="1020", name="Bank"), amount=Amount(Decimal(-100))),
        ],
    )

    # Create a ledger:

# Generated at 2022-06-18 02:35:53.052997
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define the accounting period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    # Define initial balances:
    initial_balances = {
        Account("1010"): Balance(period.since, Quantity(Decimal(1000))),
        Account("1020"): Balance(period.since, Quantity(Decimal(2000))),
        Account("1030"): Balance(period.since, Quantity(Decimal(3000))),
    }

    # Define journal entries:

# Generated at 2022-06-18 02:35:53.942159
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:04.575029
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedgerProgram

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1110", "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
            Account("1120", "Bank"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:36:13.669871
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, JournalEntry
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance

    ## Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:36:24.065496
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange

    from .accounts import Account
    from .generic import Balance

    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("A1"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account("A2"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
            }

    read_initial_balances = ReadInitialBalancesImpl()

# Generated at 2022-06-18 02:36:32.064196
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from unittest import TestCase
    from unittest.mock import Mock, call, patch
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange
    from .ledgers import (
        GeneralLedger,
        GeneralLedgerProgram,
        InitialBalances,
        Ledger,
        LedgerEntry,
        ReadInitialBalances,
        ReadJournalEntries,
        build_general_ledger,
        compile_general_ledger_program,
    )

    # Define test data:
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
    initial_balances

# Generated at 2022-06-18 02:36:43.068932
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from ..journaling.models import JournalEntry
    from .accounts import Account
    from .algebra import ReadInitialBalances
    from .models import Balance

    #: Initial balances:
    initial_balances = {
        Account("1.1.1"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
        Account("1.1.2"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(200))),
    }

    #: Journal entries:

# Generated at 2022-06-18 02:36:52.132816
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from datetime import date

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:37:02.201132
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, Ledger, LedgerEntry

    ## Define a period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define initial balances:
    initial_balances = {
        Account("1000"): Balance(period.since, Quantity(Decimal(0))),
        Account("2000"): Balance(period.since, Quantity(Decimal(0))),
    }

    ## Define journal entries:

# Generated at 2022-06-18 02:37:41.346717
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    @dataclass
    class ReadInitialBalancesMock:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}


# Generated at 2022-06-18 02:37:50.899129
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
            Account("C"): Balance(period.since, Quantity(Decimal(300))),
        }


# Generated at 2022-06-18 02:38:01.025578
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry

    # Create a ledger
    account = Account("1010", "Cash")
    initial = Balance(DateRange.since(datetime.date(2019, 1, 1)), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = JournalEntry(datetime.date(2019, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, account, Quantity(Decimal(100)))

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entry
    assert ledger.entries[0].post

# Generated at 2022-06-18 02:38:11.921108
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgering import build_general_ledger, Ledger, LedgerEntry
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from datetime import date
    from typing import Dict, List, Optional
    from decimal import Decimal
    import unittest

    class TestLedger(unittest.TestCase):
        def test_add(self):
            # Arrange
            account = Account(1, "Cash", AccountType.ASSET)
            initial = Balance(date(2020, 1, 1), Quantity(Decimal(0)))
            ledger = Ledger(account, initial)

# Generated at 2022-06-18 02:38:19.673255
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy read_initial_balances algebra implementation:

# Generated at 2022-06-18 02:38:28.891948
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances.

# Generated at 2022-06-18 02:38:38.954487
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances
    from .types import Transaction

    # Define a transaction type:
    class Transaction(Transaction):
        pass

    # Define a read initial balances algebra:

# Generated at 2022-06-18 02:38:45.607954
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import ReadInitialBalances

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:38:53.886100
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account(code="101", name="Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account(code="201", name="Accounts Receivable"): Balance(period.since, Quantity(Decimal(200))),
            Account(code="301", name="Inventory"): Balance(period.since, Quantity(Decimal(300))),
        }

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:39:02.863025
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define the accounting period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    ## Define initial balances:

# Generated at 2022-06-18 02:40:18.262473
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction

    # Define accounts:
    a1 = Account("A1", AccountType.ASSET)
    a2 = Account("A2", AccountType.ASSET)
    a3 = Account("A3", AccountType.ASSET)
    a4 = Account("A4", AccountType.ASSET)
    a5 = Account("A5", AccountType.ASSET)
    a6 = Account("A6", AccountType.ASSET)
    a7 = Account("A7", AccountType.ASSET)
    a8 = Account("A8", AccountType.ASSET)
    a9 = Account("A9", AccountType.ASSET)

# Generated at 2022-06-18 02:40:25.502766
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances, ReadJournalEntries

    # Define a test implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(1000))),
            Account("1020"): Balance(period.since, Quantity(Decimal(2000))),
            Account("1030"): Balance(period.since, Quantity(Decimal(3000))),
        }

    # Def

# Generated at 2022-06-18 02:40:35.580416
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    class _Test(TestCase):
        def test_ok(self):
            # Arrange
            period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
            mock = Mock(spec=ReadInitialBalances)
            mock.__call__.return_value = {
                Account("1010"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account("1020"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
            }

            # Act

# Generated at 2022-06-18 02:40:43.446656
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances:
    initial_balances = {
        Account("1010"): Balance(period.since, Quantity(Decimal(0))),
        Account("1020"): Balance(period.since, Quantity(Decimal(0))),
        Account("1030"): Balance(period.since, Quantity(Decimal(0))),
    }

    #: All available journal entries.

# Generated at 2022-06-18 02:40:50.303949
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection

    # Create a journal