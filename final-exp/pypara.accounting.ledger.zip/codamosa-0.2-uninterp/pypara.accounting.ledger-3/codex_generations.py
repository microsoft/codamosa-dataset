

# Generated at 2022-06-18 02:31:08.395080
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    @dataclass
    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2019, 1, 1), Quantity(Decimal(100))),
                Account("1020", "Bank"): Balance(date(2019, 1, 1), Quantity(Decimal(200))),
            }


# Generated at 2022-06-18 02:31:16.267843
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from datetime import date
    from decimal import Decimal
    from typing import Callable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program

    class Test(TestCase):
        """
        Unit test for method __call__ of class GeneralLedgerProgram
        """

        def test_GeneralLedgerProgram___call__(self):
            """
            Unit test for method __call__ of class GeneralLedgerProgram
            """

# Generated at 2022-06-18 02:31:24.086283
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:31:31.581104
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from ..commons.zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal

    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:31:40.395755
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .ledgers import GeneralLedger, Ledger, LedgerEntry
    from datetime import date
    from typing import Dict, Iterable
    from decimal import Decimal
    from unittest.mock import Mock

    # Define a mock implementation of the algebra ReadInitialBalances:

# Generated at 2022-06-18 02:31:41.043530
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:31:49.237253
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [
            JournalEntry(
                date=period.since,
                description="Dummy journal entry",
                postings=[
                    Posting(Account("A"), Quantity(Decimal(100)), "Dummy posting"),
                    Posting(Account("B"), Quantity(Decimal(100)), "Dummy posting"),
                ],
            )
        ]

    # Compile the program:


# Generated at 2022-06-18 02:31:59.075278
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a test account:
    account = Account("Test Account", AccountType.ASSET)

    ## Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        postings=[
            Posting(account, Amount(Decimal(100)), Quantity(Decimal(100))),
            Posting(account, Amount(Decimal(100)), Quantity(Decimal(100))),
        ],
    )

    ## Define a test initial balance:
    initial_balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))



# Generated at 2022-06-18 02:32:03.923901
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.

# Generated at 2022-06-18 02:32:14.815677
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a test account:
    account = Account("TEST", "Test account")

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account, Decimal(100), "Test debit"),
            Posting(account, Decimal(100), "Test credit"),
        ],
    )

    # Define a test initial balance:
    initial_balance = Balance(datetime.date(2020, 1, 1), Decimal(0))

    # Define a test period:

# Generated at 2022-06-18 02:32:18.001726
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:19.126114
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:20.135846
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:29.774644
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram

    # Define a test account:
    account = Account("Test Account")

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        postings=[
            Posting(account, Amount(100), "Debit"),
            Posting(account, Amount(100), "Credit"),
        ],
    )

    # Define a test initial balance:

# Generated at 2022-06-18 02:32:37.778182
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger
    from .types import Transaction

    ## Define a transaction type:
    class MyTransaction(Transaction):
        pass

    ## Define a read initial balances algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(1000)))}

    ## Define a read journal entries algebra:

# Generated at 2022-06-18 02:32:38.926023
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:50.599223
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, Ledger, LedgerEntry

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define the initial balances:
    initial_balances = {
        Account("101", "Cash"): Balance(period.since, Quantity(Decimal(100))),
        Account("201", "Accounts Receivable"): Balance(period.since, Quantity(Decimal(200))),
        Account("301", "Inventory"): Balance(period.since, Quantity(Decimal(300))),
    }

    ## Define the

# Generated at 2022-06-18 02:33:01.647372
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Read initial balances:

# Generated at 2022-06-18 02:33:11.230736
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, ReadInitialBalances, ReadJournalEntries
    from .types import Balance, DateRange, Quantity
    from datetime import date
    from decimal import Decimal
    from typing import Dict, Iterable, List, Optional
    from unittest import TestCase

    # Define a stub for ReadInitialBalances
    class StubReadInitialBalances(ReadInitialBalances):
        def __init__(self, initial_balances: Dict[Account, Balance]):
            self.initial_balances = initial_balances

        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return self.initial_balances

# Generated at 2022-06-18 02:33:18.963834
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting

    ## Define a test account:
    account = Account("Test", AccountType.ASSET)

    ## Define a test initial balance:
    initial_balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))

    ## Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        postings=[
            Posting(account, Quantity(Decimal(1)), "Test"),
            Posting(account, Quantity(Decimal(-1)), "Test"),
        ],
    )

    ## Define a test period:

# Generated at 2022-06-18 02:33:33.292222
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import ReadInitialBalances, GeneralLedgerProgram, build_general_ledger, compile_general_ledger_program

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Read initial balances:

# Generated at 2022-06-18 02:33:43.620490
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy read_initial_balances algebra implementation:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020"): Balance(period.since, Quantity(Decimal(200))),
            Account("1030"): Balance(period.since, Quantity(Decimal(300))),
        }

    # Define a dummy read_journal_entries algebra implementation:

# Generated at 2022-06-18 02:33:53.828235
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(Journal(Date(2020, 1, 1), ""), account, Amount(Decimal(1)), 1)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the result
    assert ledger.entries[0].balance == Quantity(Decimal(1))

# Generated at 2022-06-18 02:34:00.929352
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, Ledger, LedgerEntry, ReadInitialBalances, ReadJournalEntries
    from .types import Transaction

    # Define a dummy transaction type:
    class DummyTransaction(Transaction):
        def __init__(self, id: str):
            self.id = id

    # Define a dummy read initial balances algebra:

# Generated at 2022-06-18 02:34:12.086108
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    # Define a dummy implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:34:13.338451
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:25.029102
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy implementation of the algebra which reads journal entries:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [
            JournalEntry(
                date=datetime.date(2020, 1, 1),
                description="First journal entry",
                postings=[Posting(Account("A"), Amount(Decimal(100)), True)],
            )
        ]

    # Compile the program:

# Generated at 2022-06-18 02:34:33.906572
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgering import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedger, LedgerEntry, Ledger, GeneralLedgerProgram, InitialBalances
    from .journaling import ReadJournalEntries
    from .accounting import Accountant
    from .accounting import AccountantAlgebra
    from .accounting import AccountantProgram
    from .accounting import compile_accountant_program
    from .accounting import test_AccountantProgram___call__
    from .accounting import test_

# Generated at 2022-06-18 02:34:45.415291
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import build_general_ledger
    from datetime import date
    from decimal import Decimal
    from typing import Iterable
    from unittest import TestCase


# Generated at 2022-06-18 02:34:53.120518
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.numbers import Amount, Quantity

# Generated at 2022-06-18 02:35:12.440861
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import Balance, DateRange, GeneralLedger, InitialBalances, Ledger, LedgerEntry

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A", AccountType.ASSET): Balance(period.since, Quantity(Decimal(100))),
            Account("B", AccountType.ASSET): Balance(period.since, Quantity(Decimal(200))),
            Account("C", AccountType.ASSET): Balance(period.since, Quantity(Decimal(300))),
        }


# Generated at 2022-06-18 02:35:21.717378
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry

    # Define a test account:
    account = Account(code="1000", name="Cash")

    # Define a test journal entry:

# Generated at 2022-06-18 02:35:28.614427
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import Direction

    # Initialize the period
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Initialize the journal

# Generated at 2022-06-18 02:35:37.570324
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = Journal(Date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(100)), True)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the ledger entry
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:35:48.505898
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Initial balances:

# Generated at 2022-06-18 02:35:56.416185
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Initial balances
    initial_balances = {
        Account(1, "Cash"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
        Account(2, "Accounts Receivable"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(200))),
        Account(3, "Inventory"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(300))),
        Account(4, "Accounts Payable"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(400))),
    }

    # Journal entries

# Generated at 2022-06-18 02:36:07.645007
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define a dummy implementation of the algebra which reads initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    # Define a dummy implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:36:16.654496
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .ledgering import Ledger, LedgerEntry, build_general_ledger, GeneralLedger
    from .journaling import Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journaling import Journal, JournalEntry
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry, build_general_ledger, GeneralLedger
    from .journaling import Posting
    from .accounts import Account
    from .commons.numbers import Amount

# Generated at 2022-06-18 02:36:18.545784
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram
    """
    pass

# Generated at 2022-06-18 02:36:28.022216
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account
    from .ledgers import Ledger, LedgerEntry, GeneralLedger, GeneralLedgerProgram, InitialBalances, build_general_ledger, compile_general_ledger_program
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .commons.numbers import Amount, Quantity

# Generated at 2022-06-18 02:37:04.123986
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define the algebra:

# Generated at 2022-06-18 02:37:12.324699
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances as of the end of previous financial period:

# Generated at 2022-06-18 02:37:22.974625
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.zeitgeist import DateRange

    # Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
        }


# Generated at 2022-06-18 02:37:28.785122
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Balance, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances
    from .ledgers import build_general_ledger
    from .ledgers import compile_general_ledger_program
    from .ledgers import read_journal_entries
    from .ledgers import read_initial_balances

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Reads initial balances.

# Generated at 2022-06-18 02:37:38.936207
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program
    from .algebras import ReadInitialBalances, ReadJournalEntries

    # Define a test account:
    account = Account(code="1000", name="Cash")

    # Define a test initial balance:
    initial_balance = Balance(date=datetime.date(2019, 1, 1), value=Quantity(Decimal(100)))

    # Define a test journal entry:

# Generated at 2022-06-18 02:37:49.244583
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a test account:
    account = Account("Test", AccountType.ASSET, None)

    # Define a test posting:
    posting = Posting(account, Amount(Decimal(100)), True)

    # Define a test journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test", [posting])

    # Define a test initial balance:
    initial_balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))

    # Define a test ledger

# Generated at 2022-06-18 02:37:56.546881
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    ## Import dependencies:
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    ## Define test data:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    initial_balances = {
        Account("1010"): Balance(period.since, Quantity(Decimal(0))),
        Account("1020"): Balance(period.since, Quantity(Decimal(0))),
        Account("1030"): Balance(period.since, Quantity(Decimal(0))),
    }

# Generated at 2022-06-18 02:38:03.954614
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .generic import Balance

    @dataclass
    class MockReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("A", "A"): Balance(period.since, Quantity(Decimal(0)))}

    assert MockReadInitialBalances()(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))) == {
        Account("A", "A"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    }


# Generated at 2022-06-18 02:38:14.312733
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a mock implementation of the algebra which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("1010"): Balance(period.since, Quantity(Decimal(100)))}

    # Define a mock implementation of the algebra which reads journal entries:

# Generated at 2022-06-18 02:38:26.681176
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from . import accounts
    from . import journaling
    from . import generic
    from . import commons
    from . import ledger
    import datetime
    import decimal
    import typing
    import pytest
    import hypothesis
    import hypothesis.strategies
    import hypothesis.extra.datetime
    import hypothesis.extra.decimal
    import hypothesis.extra.typing
    import hypothesis.extra.numpy
    import hypothesis.extra.pandas
    import hypothesis.extra.pandas.columns
    import hypothesis.extra.pandas.series
    import hypothesis.extra.pandas.dataframes
   

# Generated at 2022-06-18 02:39:31.899760
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, Direction
    from .generic import Balance
    from .ledgers import build_general_ledger, LedgerEntry
    from .commons.numbers import Amount, Quantity

    # Define test data
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:39:39.073584
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:39:47.696173
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    ## Create a ledger:
    ledger = Ledger(Account("Assets:Cash"), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    ## Create a journal:
    journal = Journal(Date(2020, 1, 1), "Cash deposit")

    ## Create a posting:
    posting = Posting(journal, Account("Assets:Cash"), Direction.DEBIT, Amount(Decimal(100)))

    ## Add the posting to the ledger:
    entry = ledger.add(posting)

    ## Check the entry:
    assert entry.date == Date(2020, 1, 1)
    assert entry.description == "Cash deposit"
    assert entry.amount == Amount(Decimal(100))


# Generated at 2022-06-18 02:39:55.469376
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import AccountTypeEnum
    from .units import Unit
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from ..commons.types import Date, DateTime
    from ..commons.utils import date_range_from_dates

    # Create a general ledger program:

# Generated at 2022-06-18 02:39:57.124626
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:40:07.949544
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import TransactionType

    ## Define a mock implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:40:16.611807
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a test period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define a test journal:

# Generated at 2022-06-18 02:40:17.430202
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:40:22.481681
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange
    from . import accounts, journaling, numbers, zeitgeist

    # Define a test account:
    account = Account(
        code="101",
        name="Cash",
        type=AccountType.ASSET,
        description="Cash on hand and in bank",
        parent=None,
    )

    # Define a test journal entry:

# Generated at 2022-06-18 02:40:28.742213
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from ..journaling.journaling import JournalEntry, Posting
    from ..accounts.accounts import Account
    from ..commons.numbers import Amount, Quantity
    from ..commons.types import Date
    from ..commons.enums import Direction
    from .generic import Balance
    from .accounts import AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .accounts import AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .accounts import AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .accounts import AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .accounts import Account