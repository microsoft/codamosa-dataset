

# Generated at 2022-06-18 02:31:08.888388
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Read initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(100))),
            Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(200))),
        }

    #: Read journal entries:

# Generated at 2022-06-18 02:31:16.612070
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:31:22.806870
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from datetime import date

    # Define some accounts:
    a_cash = Account("Cash", AccountType.ASSET)
    a_sales = Account("Sales", AccountType.REVENUE)
    a_cogs = Account("Cost of Goods Sold", AccountType.EXPENSE)
    a_inventory = Account("Inventory", AccountType.ASSET)

    # Define some journal entries:

# Generated at 2022-06-18 02:31:30.851998
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry, ReadInitialBalances

    # Define a ledger
    ledger = Ledger(Account("1"), Balance(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)), Quantity(Decimal(0))))

    # Define a posting
    posting = Posting(Account("1"), datetime.date(2020, 1, 1), Quantity(Decimal(100)))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the entry

# Generated at 2022-06-18 02:31:40.054259
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define test data:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:31:48.314271
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from datetime import date
    from decimal import Decimal
    from typing import List

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity


# Generated at 2022-06-18 02:31:53.154531
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a test account:
    account = Account(AccountType.ASSET, "Test Account")

    # Define a test journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account, Amount(100), Quantity(100)),
            Posting(account, Amount(100), Quantity(100)),
        ],
    )

    # Define a test period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1))

    # Define a test initial balance:
   

# Generated at 2022-06-18 02:32:03.314783
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define initial balances:

# Generated at 2022-06-18 02:32:14.497750
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram
    from .types import Amount, Balance, Quantity

    # Define a dummy read_initial_balances algebra implementation:
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    # Define a dummy read_journal_entries algebra implementation:

# Generated at 2022-06-18 02:32:15.218969
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:19.649703
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:32:29.415535
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry
    from .journaling import ReadJournalEntries
    from .ledgers import ReadInitialBalances, compile_general_ledger_program
    from datetime import date
    from typing import Dict, Iterable, List, Optional, TypeVar
    from typing_extensions import Protocol
    from unittest import TestCase

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Journal entries:


# Generated at 2022-06-18 02:32:37.540904
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import ReadInitialBalances, GeneralLedgerProgram, build_general_ledger, compile_general_ledger_program
    from .types import Transaction

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(date(2019, 1, 1), date(2019, 12, 31))

    #: Initial balances:
    initial

# Generated at 2022-06-18 02:32:45.092117
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return [
            JournalEntry(
                date=period.since,
                description="Test",
                postings=[
                    Posting(Account("A"), Quantity(Decimal(1)), "Dr"),
                    Posting(Account("B"), Quantity(Decimal(1)), "Cr"),
                ],
            )
        ]

    ## Compile the

# Generated at 2022-06-18 02:32:53.749656
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import ReadInitialBalances, ReadJournalEntries

    # Define initial balances:
    initial_balances = {
        Account("A", "A"): Balance(DateRange.since(2020, 1, 1).until, Quantity(Decimal(100))),
        Account("B", "B"): Balance(DateRange.since(2020, 1, 1).until, Quantity(Decimal(200))),
    }

    # Define journal entries:

# Generated at 2022-06-18 02:33:03.526587
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = Journal(Date(2020, 1, 1), "Test")
    posting = Posting(journal, account, Quantity(Decimal(100)), True)

    # Add the journal entry to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting

# Generated at 2022-06-18 02:33:11.986982
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType

    # Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(
                account=Account(code="1000", name="Cash", type=AccountType.ASSET),
                amount=Amount(Decimal(100)),
                direction=Posting.Direction.DEBIT,
            ),
            Posting(
                account=Account(code="2000", name="Sales", type=AccountType.REVENUE),
                amount=Amount(Decimal(100)),
                direction=Posting.Direction.CREDIT,
            ),
        ],
    )

    # Define initial balances:

# Generated at 2022-06-18 02:33:20.873968
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, ReadJournalEntries
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .commons.types import Currency

    # Create a journal

# Generated at 2022-06-18 02:33:30.625629
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Define a mock implementation of ReadInitialBalances

# Generated at 2022-06-18 02:33:36.842358
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a stub for read_initial_balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A1"): Balance(period.since, Quantity(Decimal(100))),
            Account("A2"): Balance(period.since, Quantity(Decimal(200))),
        }

    # Define a stub for read_journal_entries:

# Generated at 2022-06-18 02:33:56.839815
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy initial balance:
    initial_balances = {Account("A"): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0)))}

    ## Define a dummy journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2019, 1, 1),
        description="Dummy journal entry",
        postings=[Posting(Account("A"), Amount(Decimal(100)))],
    )

    ## Define a dummy period:
    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 1))

    ## Define a dummy read initial

# Generated at 2022-06-18 02:34:06.922319
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.types import Direction

    # Create a ledger
    ledger = Ledger(Account("A"), Balance(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)), Quantity(Decimal(0))))

    # Create a posting
    posting = Posting(Journal("J", datetime.date(2020, 1, 1), "J"), Account("A"), Amount(Decimal(100)), Direction.DEBIT)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry

# Generated at 2022-06-18 02:34:16.506340
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgering import ReadInitialBalances

    # Define a test implementation of the algebra:
    class TestReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account("1020", "Bank"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
            }

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:34:18.077527
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:29.254280
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from ..commons.accounts import Account
    from ..commons.journaling import JournalEntry, Posting, Direction
    from ..commons.generic import Balance

    ## Define test data:
    period = DateRange(date(2018, 1, 1), date(2018, 12, 31))

# Generated at 2022-06-18 02:34:30.144151
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:41.735868
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgering import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, read_initial_balances, read_journal_entries

    # Define a dummy implementation of the algebra:
    def _read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {Account("1010"): Balance(date(2019, 1, 1), Decimal(0))}

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:34:50.579079
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from .commons import Direction

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    date = datetime.date(2020, 1, 1)
    description = "Cash received from customer"
    journal = JournalEntry(date, description)
    amount = Amount(Decimal(100))
    direction = Direction.DEBIT
    posting = Posting(journal, account, amount, direction)

    # Add the posting to the ledger
   

# Generated at 2022-06-18 02:34:59.931220
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    @dataclass
    class _ReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(100))),
                Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(200))),
            }


# Generated at 2022-06-18 02:35:00.843497
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True


# Generated at 2022-06-18 02:35:22.986007
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy implementation of the algebra which reads initial balances.
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(100)))}

    # Define a dummy implementation of the algebra which reads journal entries.

# Generated at 2022-06-18 02:35:30.458876
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, LedgerEntry
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:35:40.081924
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, compile_general_ledger_program, ReadInitialBalances, ReadJournalEntries

    # Define a dummy implementation of ReadInitialBalances:

# Generated at 2022-06-18 02:35:50.694430
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List
    from .ledgering import build_general_ledger, Ledger, LedgerEntry, GeneralLedger

    # Define a test journal

# Generated at 2022-06-18 02:35:58.159352
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("1")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    posting = Posting(datetime.date(2020, 1, 1), Quantity(Decimal(100)), account)
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(100))
    posting = Posting(datetime.date(2020, 1, 1), Quantity(Decimal(200)), account)
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(300))
    posting = Posting(datetime.date(2020, 1, 1), Quantity(Decimal(-100)), account)
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(200))


# Generated at 2022-06-18 02:36:08.496719
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define the initial balances:

# Generated at 2022-06-18 02:36:18.064216
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance
    from .accounting import build_journal_entry
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account(1, "Cash")
    initial = Balance(Date(2019, 1, 1), Quantity(Decimal(100)))
    ledger = Ledger(account, initial)

    # Create a journal entry
    journal = Journal(Date(2019, 1, 1), "Cash deposit")
    journal.add(Posting(account, Direction.DEBIT, Quantity(Decimal(100))))
    journal_entry = build_journal_entry(journal)

    # Create a posting
    posting = journal_entry.postings[0]

    # Add the

# Generated at 2022-06-18 02:36:27.672619
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account("1010", "Cash"), amount=Amount(100), direction=Posting.Direction.DEBIT),
            Posting(account=Account("1020", "Accounts receivable"), amount=Amount(100), direction=Posting.Direction.CREDIT),
        ],
    )

    # Define initial balances:

# Generated at 2022-06-18 02:36:37.024482
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:36:46.293059
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import read_initial_balances, read_journal_entries

    # Define a dummy journal entry:

# Generated at 2022-06-18 02:37:27.389607
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, ReadInitialBalances, ReadJournalEntries
    from .commons.numbers import Amount, Quantity
    from datetime import date
    from typing import Dict, Iterable
    from unittest import TestCase


# Generated at 2022-06-18 02:37:38.840566
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy read initial balances algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
            Account("C"): Balance(period.since, Quantity(Decimal(300))),
        }

    # Define a dummy read journal entries algebra:

# Generated at 2022-06-18 02:37:49.087999
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance


# Generated at 2022-06-18 02:37:56.535906
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a test implementation of the algebra:
    class TestReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return {
                Account("1110"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
                Account("1120"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
            }

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:38:04.498096
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting, JournalEntry, ReadJournalEntries

    # Define a mock implementation of the algebra:
    class MockReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010", "Cash"): Balance(period.since, Quantity(Decimal(100))),
                Account("1020", "Bank"): Balance(period.since, Quantity(Decimal(200))),
            }

    # Define a mock implementation of the algebra:

# Generated at 2022-06-18 02:38:05.513354
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:38:15.480222
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry, ReadInitialBalances, ReadJournalEntries
    from .types import Transaction

    # Define a transaction type:
    class Transaction(Transaction):
        pass

    # Define a read initial balances algebra implementation:

# Generated at 2022-06-18 02:38:27.501922
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances.
    initial = {
        Account("10100", "Cash"): Balance(datetime.date(2018, 12, 31), Quantity(Decimal(1000))),
        Account("10200", "Bank"): Balance(datetime.date(2018, 12, 31), Quantity(Decimal(2000))),
    }

    #: Journal entries.

# Generated at 2022-06-18 02:38:29.830129
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"


# Generated at 2022-06-18 02:38:39.247592
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, InitialBalances, Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program
    from .journaling import ReadJournalEntries
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, InitialBalances, Ledger, LedgerEntry, build_general_ledger, compile_general_ledger_program
    from .journaling import ReadJournalEntries


# Generated at 2022-06-18 02:40:07.216325
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A"): Balance(period.since, Quantity(Decimal(0)))}


# Generated at 2022-06-18 02:40:16.041607
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Define a mock implementation of the algebra:
    class MockAlgebra:
        def __init__(self, initial_balances, journal_entries):
            self.initial_balances = initial_balances
            self.journal_entries = journal_entries

        def read_initial_balances(self, period):
            return self.initial_balances

        def read_journal_entries(self, period):
            return self.journal_entries

    # Create a mock algebra instance:

# Generated at 2022-06-18 02:40:16.888119
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:40:22.461723
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .accounts import AccountType
    from .journaling import Journal, Posting, JournalEntry
    from .generic import Balance

    # Define accounts
    a1 = Account("A1", AccountType.ASSET)
    a2 = Account("A2", AccountType.ASSET)
    a3 = Account("A3", AccountType.ASSET)
    a4 = Account("A4", AccountType.ASSET)
    a5 = Account("A5", AccountType.ASSET)
    a6 = Account("A6", AccountType.ASSET)
    a7 = Account("A7", AccountType.ASSET)
    a8 = Account("A8", AccountType.ASSET)
    a9 = Account("A9", AccountType.ASSET)

# Generated at 2022-06-18 02:40:31.689778
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, InitialBalances

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define initial balances:

# Generated at 2022-06-18 02:40:39.439585
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons import Direction
    from .ledgers import build_general_ledger
    from datetime import date

    ## Define accounts:
    a1 = Account("A1", AccountType.ASSET)
    a2 = Account("A2", AccountType.ASSET)
    a3 = Account("A3", AccountType.ASSET)
    a4 = Account("A4", AccountType.ASSET)
    a5 = Account("A5", AccountType.ASSET)
    a6 = Account("A6", AccountType.ASSET)
    a7 = Account("A7", AccountType.ASSET)

# Generated at 2022-06-18 02:40:47.752453
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedgerProgram, compile_general_ledger_program

    ## Define a function which reads initial balances:

# Generated at 2022-06-18 02:40:53.599622
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger
    from .types import Direction

    ## Create a dummy implementation of the algebra which reads initial balances: