

# Generated at 2022-06-18 02:31:12.495007
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction

    ## Build a journal entry:

# Generated at 2022-06-18 02:31:20.381109
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting

    # Create a ledger
    ledger = Ledger(Account("101"), Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test", [Posting(Account("101"), Quantity(Decimal(100)), True)])

    # Add the journal to the ledger
    ledger.add(journal.postings[0])

    # Check the balance
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-18 02:31:26.533498
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a mock implementation of the algebra:

# Generated at 2022-06-18 02:31:32.683849
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    # Define a dummy implementation of the algebra which reads initial balances:

# Generated at 2022-06-18 02:31:43.498728
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a new ledger
    ledger = Ledger(Account("A"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    # Create a new posting
    posting = Posting(Account("A"), datetime.date(2020, 1, 1), Quantity(Decimal(1)))
    # Add the posting to the ledger
    ledger.add(posting)
    # Check if the balance of the ledger is 1
    assert ledger.entries[0].balance == Quantity(Decimal(1))
    # Create a new posting
    posting = Posting(Account("A"), datetime.date(2020, 1, 1), Quantity(Decimal(1)))
    # Add the posting to the ledger
    ledger.add(posting)
    # Check if the balance of the ledger is 2
    assert ledger.entries[1].balance

# Generated at 2022-06-18 02:31:50.266715
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account(1, 'Cash')
    initial = Balance(datetime.date(2020, 1, 1), Quantity(0))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = Journal(datetime.date(2020, 1, 1), 'Test')
    posting = Posting(journal, account, Quantity(100), 1)

    # Add the posting to the ledger
    ledger.add(posting)

    # Check the result
    assert ledger.entries[0].balance == Quantity(100)


# Generated at 2022-06-18 02:32:01.041565
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a dummy implementation of the algebra:

# Generated at 2022-06-18 02:32:08.302978
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define the period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    # Define initial balances:

# Generated at 2022-06-18 02:32:17.001477
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))

# Generated at 2022-06-18 02:32:27.735512
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction

    # Create a ledger
    account = Account("1", "Test account")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test journal")

    # Create a posting
    posting = Posting(journal, account, Direction.CREDIT, Quantity(Decimal(1)))

    # Add the posting to the ledger
    ledger_entry = ledger.add(posting)

    # Check the ledger entry
    assert ledger_entry.ledger == ledger
    assert ledger_entry.posting == posting

# Generated at 2022-06-18 02:32:39.044974
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    # Create a ledger
    account = Account("Test Account")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    posting = Posting(Journal(Date(2020, 1, 1), "Test Journal", [posting]), account, Quantity(Decimal(100)))

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100))
    assert entry.date == Date(2020, 1, 1)


# Generated at 2022-06-18 02:32:50.600622
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account, AccountType

    ## Define a mock implementation of the algebra:

# Generated at 2022-06-18 02:33:01.611205
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import GeneralLedger

    ## Define a dummy read initial balances algebra implementation:

# Generated at 2022-06-18 02:33:11.198659
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a posting
    date = Date(2020, 1, 1)
    journal = Journal(date, "Test")
    posting = Posting(journal, account, Direction.DEBIT, Quantity(Decimal(10)))

    # Add the posting to the ledger
    ledger_entry = ledger.add(posting)

    # Check the ledger entry
    assert isinstance(ledger_entry, LedgerEntry)
    assert ledger_entry.ledger == ledger


# Generated at 2022-06-18 02:33:18.927975
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance

    # Arrange
    mock = Mock(spec=ReadInitialBalances)
    mock.__call__.return_value = {
        Account("1010"): Balance(date(2019, 1, 1), Quantity(Decimal(0))),
        Account("1020"): Balance(date(2019, 1, 1), Quantity(Decimal(0))),
    }
    sut = mock

    # Act
    result = sut(DateRange(date(2019, 1, 1), date(2019, 12, 31)))

    # Assert

# Generated at 2022-06-18 02:33:29.171491
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance

    a = Account("A")
    b = Account("B")
    c = Account("C")
    d = Account("D")
    e = Account("E")

    j1 = Journal(datetime.date(2020, 1, 1), "J1", [Posting(a, Decimal(100), "D"), Posting(b, Decimal(100), "C")])
    j2 = Journal(datetime.date(2020, 1, 2), "J2", [Posting(a, Decimal(100), "D"), Posting(c, Decimal(100), "C")])

# Generated at 2022-06-18 02:33:36.361406
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import datetime
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program, GeneralLedger, LedgerEntry
    from .transactions import Transaction

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances as of the

# Generated at 2022-06-18 02:33:45.149918
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

    #: Initial balances:

# Generated at 2022-06-18 02:33:50.019527
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define test data
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-18 02:33:58.421542
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import ReadInitialBalances

    # Define a test implementation of the algebra:

# Generated at 2022-06-18 02:34:12.936792
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, ReadJournalEntries
    from .ledgers import Ledger, build_general_ledger, compile_general_ledger_program
    from .types import Transaction

    # Define a transaction type:
    class Sale(Transaction):
        pass

    # Define a journal entry reader:

# Generated at 2022-06-18 02:34:24.727376
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Amount, Quantity

    # Initialize ledger
    account = Account("Assets", "Cash")
    initial = Balance(date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Initialize posting
    journal = JournalEntry(date(2020, 1, 1), "Payment", [])
    posting = Posting(journal, account, Amount(Decimal(100)), True)

    # Add posting to ledger
    entry = ledger.add(posting)

    # Check ledger entry
    assert entry.led

# Generated at 2022-06-18 02:34:33.679406
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from ..commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date

    # Create a ledger
    account = Account("Assets", "Cash")
    initial = Balance(date(2020, 1, 1), Quantity(Decimal(100)))
    ledger = Ledger(account, initial)

    # Create a posting
    journal = JournalEntry(date(2020, 1, 2), "Test")
    posting = Posting(journal, account, Quantity(Decimal(10)), True)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the balance of the ledger

# Generated at 2022-06-18 02:34:45.140034
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: Initial balances for terminal accounts, if any.
    initial_balances = {Account("1110"): Balance(period.since, Quantity(Decimal(0)))}

    #: All available journal entries.
    journal_entries = [JournalEntry(datetime.date(2020, 1, 1), "Test", [Posting(Account("1110"), Amount(Decimal(100)), True)])]

    #: Builds a general ledger.

# Generated at 2022-06-18 02:34:46.200774
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:34:53.625316
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry, build_general_ledger
    from .commons.numbers import Amount, Quantity
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Optional, TypeVar
    from dataclasses import dataclass, field
    from typing import Generic, Iterable, List, Optional, Protocol, TypeVar
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgering import Ledger

# Generated at 2022-06-18 02:35:02.235879
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Define a period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    ## Define some accounts:
    a1 = Account("A1", "Account 1")
    a2 = Account("A2", "Account 2")
    a3 = Account("A3", "Account 3")
    a4 = Account("A4", "Account 4")

    ## Define some journal entries:
    j1 = JournalEntry(datetime.date(2020, 1, 1), "Journal 1", [Posting(a1, 100), Posting(a2, -100)])

# Generated at 2022-06-18 02:35:11.714050
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from ..commons.zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal
    from typing import List
    from unittest.mock import Mock

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Read initial balances:
    ReadInitialBalances = Callable[[DateRange], InitialBalances]

    #: Read journal entries:
    ReadJournalEntries = Callable[[DateRange], List[JournalEntry[_T]]]

    #: General ledger program:
    GeneralLedgerProgram = Callable[[DateRange], GeneralLedger[_T]]

    #: Accounting period

# Generated at 2022-06-18 02:35:21.388083
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting

    #: Defines a test account.
    account = Account("Test Account", AccountType.ASSET)

    #: Defines a test journal entry.
    journal = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal",
        postings=[
            Posting(account, Amount(Decimal(100)), "Debit"),
            Posting(account, Amount(Decimal(100)), "Credit"),
        ],
    )

    #: Defines a test period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1))

    #: Defines initial balances.
    initial_balances

# Generated at 2022-06-18 02:35:28.828188
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import compile_journal_entries_program
    from .accounts import compile_accounts_program
    from .accounts import compile_initial_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program
    from .accounts import compile_account_balances_program

# Generated at 2022-06-18 02:35:53.254942
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import DateRange

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    journal = [
        JournalEntry(
            datetime.date(2020, 1, 1),
            "Test Journal Entry",
            [
                Posting(Account("Assets", "Cash"), 1, "Test Posting"),
                Posting(Account("Liabilities", "Accounts Payable"), -1, "Test Posting"),
            ],
        )
    ]
    initial = {Account("Assets", "Cash"): Balance(datetime.date(2020, 1, 1), 0)}

# Generated at 2022-06-18 02:36:00.015020
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Define a dummy implementation of the algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A"): Balance(period.since, Quantity(Decimal(100))),
            Account("B"): Balance(period.since, Quantity(Decimal(200))),
            Account("C"): Balance(period.since, Quantity(Decimal(300))),
        }


# Generated at 2022-06-18 02:36:10.327653
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances.

# Generated at 2022-06-18 02:36:11.165533
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:21.482131
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance


# Generated at 2022-06-18 02:36:30.083591
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    ## Define a function which reads initial balances:

# Generated at 2022-06-18 02:36:36.812259
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Direction

    ## Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(Direction.DEBIT, Account(AccountType.ASSET, "1000"), Amount(Decimal(100))),
            Posting(Direction.CREDIT, Account(AccountType.ASSET, "2000"), Amount(Decimal(100))),
        ],
    )

    ## Build a general ledger:

# Generated at 2022-06-18 02:36:46.159706
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange
    from ..commons.zeitgeist import Date

    ## Define test data:
    period = DateRange(Date(2020, 1, 1), Date(2020, 12, 31))

# Generated at 2022-06-18 02:36:47.461349
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-18 02:36:57.058497
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Journal, Posting, JournalEntry
    from .accounts import Account, AccountType

    ## Define accounts:
    cash = Account("Cash", AccountType.ASSET)
    accounts_receivable = Account("Accounts Receivable", AccountType.ASSET)
    sales = Account("Sales", AccountType.REVENUE)
    accounts_payable = Account("Accounts Payable", AccountType.LIABILITY)
    purchases = Account("Purchases", AccountType.EXPENSE)
    inventory = Account("Inventory", AccountType.ASSET)
    cost_of_goods_sold = Account("Cost of Goods Sold", AccountType.EXPENSE)

    ## Define initial balances:

# Generated at 2022-06-18 02:37:39.020737
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Accounting period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    #: Initial balances.

# Generated at 2022-06-18 02:37:49.361449
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry
    from datetime import date
    from decimal import Decimal
    from typing import List
    account = Account(1, "Test Account")
    initial = Balance(date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    posting = Posting(JournalEntry(date(2020, 1, 1), "Test Journal Entry"), account, Quantity(Decimal(100)), True)
    entry = ledger.add(posting)
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100))
    assert entry.date == date(2020, 1, 1)
    assert entry

# Generated at 2022-06-18 02:37:56.670378
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, GeneralLedgerProgram, InitialBalances, Ledger, LedgerEntry
    from .journaling import ReadJournalEntries
    from .generic import ReadInitialBalances

    # Define a mock implementation of the algebra which reads initial balances.

# Generated at 2022-06-18 02:38:04.563394
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, compile_general_ledger_program, GeneralLedger, GeneralLedgerProgram, Ledger, LedgerEntry, ReadInitialBalances, ReadJournalEntries
    from .numbers import Amount, Quantity
    from .zeitgeist import DateRange
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List, Optional
    from unittest import TestCase


# Generated at 2022-06-18 02:38:14.677492
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection

    # Create a journal entry
    journal = Journal(Date(2020, 1, 1), "Test journal entry")
    journal.add(Posting(Account(AccountType.ASSET, "1000"), PostingDirection.DEBIT, Amount(100)))
    journal.add(Posting(Account(AccountType.LIABILITY, "2000"), PostingDirection.CREDIT, Amount(100)))

    # Create a ledger
    ledger = Ledger(Account(AccountType.ASSET, "1000"), Balance(Date(2020, 1, 1), Quantity(0)))

    # Add the journal entry to the ledger
    ledger.add(journal.postings[0])

    # Check the balance of the ledger

# Generated at 2022-06-18 02:38:26.978003
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # Define a dummy read_initial_balances function:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(0))),
            Account("1020"): Balance(period.since, Quantity(Decimal(0))),
        }

    # Define a dummy read_journal_entries function:

# Generated at 2022-06-18 02:38:32.260377
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting, Direction
    from .generic import Balance
    from .ledgering import Ledger, LedgerEntry
    from .accounting import Accounting

    ## Create an accounting instance:
    accounting = Accounting()

    ## Create a ledger:
    ledger = Ledger(accounting.accounts.assets.cash, Balance(Date(2020, 1, 1), Quantity(Decimal(0))))

    ## Create a journal entry:
    journal = Journal(Date(2020, 1, 1), "Test journal entry", [Posting(Direction.DEBIT, accounting.accounts.assets.cash, Quantity(Decimal(100)))])

    ## Add the journal entry to the ledger:
    ledger.add(journal.postings[0])

    ## Check the

# Generated at 2022-06-18 02:38:40.526093
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .generic import Balance

    # Define a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        postings=[
            Posting(account=Account("Assets", "Cash"), amount=Amount(100)),
            Posting(account=Account("Income", "Sales"), amount=Amount(100)),
        ],
    )

    # Define a read journal entries algebra:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [journal_entry]

    # Define an initial balances algebra:

# Generated at 2022-06-18 02:38:49.774179
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .ledgers import build_general_ledger, GeneralLedger, Ledger, LedgerEntry

    # Define a journal entry:

# Generated at 2022-06-18 02:38:56.661943
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import Date
    from .accounts import Account
    from .journaling import Journal, Posting
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    # Create a ledger
    account = Account("A")
    initial = Balance(Date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)

    # Create a journal
    journal = Journal(Date(2020, 1, 1), "Test")

    # Create a posting
    posting = Posting(journal, account, Quantity(Decimal(1)), 1)

    # Add the posting to the ledger
    entry = ledger.add(posting)

    # Check the result
    assert entry.ledger == ledger
    assert entry.posting == posting

# Generated at 2022-06-18 02:41:01.042093
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .ledgers import GeneralLedger, build_general_ledger, compile_general_ledger_program, GeneralLedgerProgram
    from .types import Transaction

    # Define a test transaction:
    class TestTransaction(Transaction):
        def __init__(self, name: str):
            self.name = name

    # Define a test account:
    class TestAccount(Account):
        def __init__(self, name: str):
            self.name = name

    # Define a test journal entry: