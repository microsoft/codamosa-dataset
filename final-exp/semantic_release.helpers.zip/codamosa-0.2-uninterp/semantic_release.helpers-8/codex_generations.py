

# Generated at 2022-06-18 03:04:02.163911
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
   

# Generated at 2022-06-18 03:04:09.842217
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Decorate function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:04:17.584144
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10
    assert session.hooks == {}

    session = build_requests_session(retry=False)
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.total == 0
    assert session.hooks == {}

    session = build_requests_session(retry=5)
    assert session.adapters["http://"].max_retries.total == 5
    assert session.adapters["https://"].max_retries.total == 5
    assert session.hooks == {}

    session = build_requests_session

# Generated at 2022-06-18 03:04:25.498130
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert isinstance(session, Session)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}



# Generated at 2022-06-18 03:04:33.858339
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the log
    stream.seek(0)

# Generated at 2022-06-18 03:04:43.956716
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    # Create stream handler and set its level to debug
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)

    # Create formatter
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # Add formatter to stream_handler
    stream_handler.setFormatter(formatter)

    # Add stream_handler to logger
    logger.addHandler(stream_handler)

    # Create a StringIO object
    string_io = StringIO()
    sys.stdout = string_io

    # Create LoggedFunction

# Generated at 2022-06-18 03:04:52.407204
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:05:01.863695
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:05:09.584378
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:05:18.708128
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(True)
    assert isinstance(session, Session)

# Generated at 2022-06-18 03:05:31.312345
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:05:41.849716
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=1):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    logged_test_function(1, 2, 3)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:05:49.972107
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Unit test

# Generated at 2022-06-18 03:05:59.826395
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    # Create a stream handler to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to decorate
    @logged_function
    def test_function(a, b, c=None, d=None):
        return a + b + c + d

    # Call the function
    test_function(1, 2, 3, 4)

    # Check the output
    assert stream.getvalue()

# Generated at 2022-06-18 03:06:09.403538
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_function(a, b, c=1):
                return a + b + c

            self.assertEqual(test_function(1, 2, 3), 6)
            self.assertEqual(test_function(1, 2), 4)

    unittest.main()

# Generated at 2022-06-18 03:06:19.736411
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:06:27.981858
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import patch

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logged_function = LoggedFunction(logger)
            @logged_function
            def test_function(a, b, c=1, d=2):
                return a + b + c + d
            with patch.object(logger, "debug") as mock_debug:
                test_function(1, 2, 3, 4)
                mock_debug.assert_called_once_with("test_function(1, 2, c=3, d=4)")
                mock_debug.reset_mock()
                test_function(1, 2, d=4)
                mock_

# Generated at 2022-06-18 03:06:37.707968
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2, 3)

    # Check the log

# Generated at 2022-06-18 03:06:47.433383
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            def func():
                pass

            logged_func = self.logged_function(func)
            logged_func()
            self.logger.debug.assert_called_once_with("func()")

        def test_logged_function_with_arguments(self):
            def func(a, b, c):
                pass

            logged_func = self.logged_function(func)

# Generated at 2022-06-18 03:06:54.011048
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None, d=None):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2, 3, 4)

    # Check the output
    assert stream.getvalue()

# Generated at 2022-06-18 03:07:05.890259
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Capture stdout
    stdout = sys.stdout
    sys.stdout = StringIO()

    # Create logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define function to decorate
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    test_function(1, 2)

    # Check output
    assert sys.stdout.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Restore stdout
    sys.stdout = stdout

# Generated at 2022-06-18 03:07:14.771519
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def foo(a, b, c=3):
        return a + b + c

    foo(1, 2)
    assert stream.getvalue() == "foo(1, 2, c=3)\nfoo -> 6\n"

    stream.truncate(0)
    stream.seek(0)
    foo(1, 2, c=4)
    assert stream.getvalue() == "foo(1, 2, c=4)\nfoo -> 7\n"

    stream.truncate(0)
   

# Generated at 2022-06-18 03:07:20.243900
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_func = LoggedFunction(logger)

    # Create a function to be decorated
    def func(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_func(func)

    # Call the decorated function
    func(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:07:30.669318
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=3)

# Generated at 2022-06-18 03:07:41.102425
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.stream.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def add(a, b):
                return a + b

            add(1, 2)
           

# Generated at 2022-06-18 03:07:51.686535
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Create function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    with redirect_stdout(stream):
        test_function(1, 2, 3)

    # Check output

# Generated at 2022-06-18 03:07:56.757497
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the LoggedFunction instance
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged

# Generated at 2022-06-18 03:08:06.312665
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Define a function
    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    # Call the function
    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, c=4)
        test_func(1, 2, c=4, d=5)

    # Check the output
    assert stream

# Generated at 2022-06-18 03:08:15.607194
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Define a function to be decorated
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the decorated function
    test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:08:20.739854
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_

# Generated at 2022-06-18 03:08:29.304619
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=0)

# Generated at 2022-06-18 03:08:39.700501
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call

    logger = Mock()

    def test_function(a, b, c=None):
        return a + b + c

    logged_function = LoggedFunction(logger)
    logged_test_function = logged_function(test_function)

    with patch("logging.Logger.debug") as mock_debug:
        logged_test_function(1, 2, 3)
        mock_debug.assert_has_calls(
            [
                call("test_function(1, 2, 3)"),
                call("test_function -> 6"),
            ]
        )

    with patch("logging.Logger.debug") as mock_debug:
        logged_test_function(1, 2)


# Generated at 2022-06-18 03:08:47.261681
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=1):
        return a + b + c

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=1)\ntest_func -> 4\n"

# Generated at 2022-06-18 03:08:54.639145
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger = logging.getLogger("test")
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

        def tearDown(self):
            self.logger.removeHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def add(a, b):
                return a + b

            add(1, 2)

# Generated at 2022-06-18 03:09:02.095719
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, 3)
        test_func(1, 2, c=3)
        test_func(1, b=2, c=3)
        test_func(a=1, b=2, c=3)


# Generated at 2022-06-18 03:09:11.251240
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

    stream.truncate(0)
    test_func(1, 2, c=5)

# Generated at 2022-06-18 03:09:18.296706
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=True)
    assert session.mounts["http://"][0].max_retries.total == 10
    assert session.mounts["https://"][0].max_retries.total == 10
    session = build_requests_session(retry=False)
    assert session.mounts == {}
    session = build_requests_session(retry=Retry(total=5))
    assert session.mounts["http://"][0].max_retries.total == 5
    assert session.mounts["https://"][0].max_retries.total == 5
    session = build_requests_session(retry=5)
    assert session.mounts["http://"][0].max_retries.total == 5

# Generated at 2022-06-18 03:09:28.291720
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    test_function(1, 2)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:09:36.361835
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define function to decorate
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    result = test_function(1, 2, 3)

    # Check result
    assert result == 6

    # Check log output

# Generated at 2022-06-18 03:09:44.783733
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_function(a, b, c=1):
                return a + b + c

            self.assertEqual(test_function(1, 2, 3), 6)
            self.assertEqual(test_function(1, 2), 4)

    unittest.main()



# Generated at 2022-06-18 03:10:04.047937
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the LoggedFunction
    logged_test_function = logged_function(test_function)
    logged_test_function(1, 2, 3)
    logged_test_function(1, 2)

# Generated at 2022-06-18 03:10:13.914592
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.stream.close()


# Generated at 2022-06-18 03:10:19.957548
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_func(a, b, c="c"):
                return a + b + c

            test_func(1, 2)
            test_func(1, 2, c="3")

    unittest.main()

# Generated at 2022-06-18 03:10:27.102343
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to wrap
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:10:37.344788
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:10:45.659610
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert isinstance(session, Session)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}



# Generated at 2022-06-18 03:10:54.092085
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import patch

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + c

            with patch("sys.stdout", new=io.StringIO()) as fake_out:
                test_function(1, 2, 3)

# Generated at 2022-06-18 03:11:02.664822
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create test function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call test function
    test_function(1, 2)

    # Check output
    stream.seek(0)
    output = stream.read()

# Generated at 2022-06-18 03:11:11.255165
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Clean up
    logger.removeHandler(handler)
   

# Generated at 2022-06-18 03:11:19.289636
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:11:37.203975
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger()
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(unittest.mock.Mock())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def test_func():
                return "test_result"

            self.assertEqual(test_func(), "test_result")

# Generated at 2022-06-18 03:11:46.775032
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            with unittest.mock.patch("logging.Logger.debug") as mock_debug:
                @self.logged_function
                def test_func():
                    pass

                test_func()
                mock_debug.assert_any_call("test_func()")

# Generated at 2022-06-18 03:11:53.841210
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    # Create a handler to write to a buffer
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function to wrap
    @LoggedFunction(logger)
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Clean

# Generated at 2022-06-18 03:12:04.084310
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=1):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output
    stream.seek(0)
    output = stream.read()

# Generated at 2022-06-18 03:12:11.999765
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:12:22.225669
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:12:30.923130
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Decorate a function
    @logged_function
    def test_function(a, b, c=1, d=2):
        return a + b + c + d

    # Call the function
    test_function(1, 2, 3, 4)

    # Check the log output

# Generated at 2022-06-18 03:12:40.966639
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger()
    handler = logging.StreamHandler(StringIO())
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2)

# Generated at 2022-06-18 03:12:50.054005
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            # Create a logger
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            # Create a logged function
            @LoggedFunction(logger)
            def test_function(a, b, c=3, d=4):
                return a + b + c + d

            # Call function
            test_function(1, 2)

            # Check output
            output = stream.getvalue()
            self.assertEqual

# Generated at 2022-06-18 03:12:56.745569
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

    stream.truncate(0)
    test_func(1, 2, d=5)

# Generated at 2022-06-18 03:13:21.783147
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Create function to decorate
    @logged_function
    def test_function(a, b, c=1):
        return a + b + c

    # Call function
    with redirect_stdout(stream):
        result = test_function(1, 2, 3)

    # Check result
    assert result == 6

    # Check output
    assert stream.getvalue

# Generated at 2022-06-18 03:13:33.439501
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @LoggedFunction(logging.getLogger("test"))
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        test_func(1, 2)

# Generated at 2022-06-18 03:13:41.086966
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3, d=4)\ntest_function -> 10\n"

# Generated at 2022-06-18 03:13:51.529615
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters