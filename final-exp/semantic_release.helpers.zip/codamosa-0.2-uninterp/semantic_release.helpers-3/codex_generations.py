

# Generated at 2022-06-18 03:03:50.101553
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

# Generated at 2022-06-18 03:03:59.229976
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:04:07.455778
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import io

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            # Create a logger
            logger = logging.getLogger("test_logger")
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            logger.addHandler(handler)

            # Create a LoggedFunction
            logged_function = LoggedFunction(logger)

            # Create a function to wrap
            def test_function(a, b, c=3):
                return a + b + c

            # Wrap the function
            logged_test_function = logged_function(test_function)

            # Call the wrapped function
            result = logged_test_function(1, 2)

            # Check

# Generated at 2022-06-18 03:04:15.579173
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=True)
    assert session.hooks == {}
    assert session.adapters != {}
    session = build_requests_session(retry=Retry())
    assert session.hooks == {}
    assert session.adapters != {}
    session = build_requests_

# Generated at 2022-06-18 03:04:23.759917
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_func(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)
            @LoggedFunction(logger)
            def test_func(a, b, c=1):
                return a + b + c
            test_func(1, 2, c=3)
            self.assertEqual(stream.getvalue(), "test_func(1, 2, c=3)\n")
            stream.truncate(0)
            test_func

# Generated at 2022-06-18 03:04:32.618305
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test_function_result"

            self.assertEqual(test_function(), "test_function_result")


# Generated at 2022-06-18 03:04:42.994080
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}

# Generated at 2022-06-18 03:04:52.079407
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Decorate a function
    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    # Call the function
    add(1, 2)

    # Check the output
    handler.flush()
    assert stream.getvalue() == "add(1, 2)\nadd -> 3\n"

    # Clean up
    logger.removeHandler(handler)
    handler.close()
    stream.close()



# Generated at 2022-06-18 03:05:01.609072
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output

# Generated at 2022-06-18 03:05:09.369368
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function with no arguments
    @logged_function
    def test_function():
        return "test"

    with redirect_stdout(stream):
        result = test_function()
    assert result == "test"
    assert stream.getvalue() == "test_function()\ntest_function -> test\n"

    # Test function with arguments

# Generated at 2022-06-18 03:05:21.365598
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def test_function():
                return "test_result"

            result = test_function()
            self.assertEqual(result, "test_result")


# Generated at 2022-06-18 03:05:31.055331
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10


# Generated at 2022-06-18 03:05:41.571191
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest
    from unittest.mock import patch

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test"

            with patch("sys.stdout", new=sys.stdout) as mock_stdout:
                test_function()

# Generated at 2022-06-18 03:05:48.975913
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the log
    stream.seek(0)


# Generated at 2022-06-18 03:05:59.117332
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 0
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 0
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)

# Generated at 2022-06-18 03:06:09.096910
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + (c or 0)

            self.assertEqual(test_function(1, 2, 3), 6)
            self.assertEqual(test_function(1, 2), 3)

    unittest.main()

# Generated at 2022-06-18 03:06:19.353885
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.capture = io.StringIO()
            self.handler = logging.StreamHandler(self.capture)
            self.logger = logging.getLogger("test")
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

        def tearDown(self):
            self.logger.removeHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3):
                return a + b + c

            test_func(1, 2)

# Generated at 2022-06-18 03:06:27.491577
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, 2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:06:37.330510
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 1
    assert len(session.hooks["response"]) == 1

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 0

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert len(session.adapters) == 0
    assert len(session.hooks) == 1
    assert len(session.hooks["response"]) == 1

    session = build_requests_session(retry=3)

# Generated at 2022-06-18 03:06:47.075184
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_

# Generated at 2022-06-18 03:07:04.577313
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    f = io.StringIO()
    with redirect_stdout(f):
        result = test_func(1, 2)
        assert result == 6

# Generated at 2022-06-18 03:07:13.172050
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            self.assertEqual(test_function(1, 2), 6)
            self.assertEqual(test_function(1, 2, c=4), 7)

    unittest.main()

# Generated at 2022-06-18 03:07:19.821574
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries == Retry()
    assert session.adapters["https://"].max_retries == Retry()

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:07:30.329657
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout
    from unittest import TestCase

    class LoggedFunctionTest(TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            logged_function = LoggedFunction(logger)

            @logged_function
            def test_function(a, b, c=None):
                return a + b + c

            with redirect_stdout(StringIO()) as out:
                test_function(1, 2, 3)
                test_function(1, 2)
                test_function(1, 2, c=3)
                test_function(1, 2, c=3, d=4)


# Generated at 2022-06-18 03:07:40.709105
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=1):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    result = logged_test_function(1, 2, c=3)

    # Check the result
    assert result == 6

    # Check the log
    log_output = stream

# Generated at 2022-06-18 03:07:51.439970
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            def func():
                pass

            self.logged_function(func)()
            self.logger.debug.assert_called_with("func()")

        def test_logged_function_with_args(self):
            def func(a, b, c):
                pass

            self.logged_function(func)(1, 2, 3)

# Generated at 2022-06-18 03:07:56.603030
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)
    test_function(1, 2)
    test_function(1, 2, c=3)
    test_function(1, 2, c=None)
    test_function(1, 2, c="")
    test_function(1, 2, c=" ")

# Generated at 2022-06-18 03:08:06.301457
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Create function to decorate
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    with redirect_stdout(stream):
        result = test_function(1, 2)

    # Check output

# Generated at 2022-06-18 03:08:14.690138
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a logged function
    @LoggedFunction(logger)
    def test_function(a, b, c=None):
        return a + b + c

    # Call the logged function
    test_function(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:08:24.717492
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch
    import logging

    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    with patch.object(logger, "debug") as mock_debug:
        test_func(1, 2, 3, 4)
        mock_debug.assert_called_with("test_func(1, 2, c=3, d=4)")
        mock_debug.reset_mock()
        test_func(1, 2)

# Generated at 2022-06-18 03:08:41.862635
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Test the function
    test_function(1, 2, 3)
    test_function(1, 2)
    test_function(1, b=2, c=3)
    test_function(1, b=2)

# Generated at 2022-06-18 03:08:51.059225
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function

# Generated at 2022-06-18 03:08:59.599989
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the log

# Generated at 2022-06-18 03:09:08.966003
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to wrap
    @logged_function
    def test_function(x, y, z=1):
        return x + y + z

    # Call the function
    test_function(1, 2, z=3)

    # Check the output

# Generated at 2022-06-18 03:09:16.450760
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert session.hooks == {}

    session = build_requests_session(retry=True)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"].max_retries, Retry)

    session = build_requests_session(retry=Retry())
    assert isinstance(session, Session)
    assert session.hooks == {}

# Generated at 2022-06-18 03:09:26.538912
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Define function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    with redirect_stdout(stream):
        result = test_function(1, 2, 3)

    # Check result
    assert result == 6

    # Check log

# Generated at 2022-06-18 03:09:31.346177
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call function
    with redirect_stdout(stream):
        result = test_function(1, 2, d=5)

    # Check result
    assert result == 11

    # Check log

# Generated at 2022-06-18 03:09:39.117610
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function to be logged
    @LoggedFunction(logger)
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the log output
    assert stream.getvalue() == "test_function(1, 2, c=3, d=4)\n"

    # Call the function again

# Generated at 2022-06-18 03:09:47.793981
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3, d=4):
                return a + b + c + d


# Generated at 2022-06-18 03:09:54.405065
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_LoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test"

            self.assertEqual(test_function(), "test")


# Generated at 2022-06-18 03:10:18.657576
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=None, d=None):
        return a + b + c + d

    # Test function call
    with redirect_stdout(stream):
        result = test_function(1, 2, 3, 4)
    assert result == 10

# Generated at 2022-06-18 03:10:25.759890
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_func(a, b, c=1, d=2):
                return a + b + c + d

            self.assertEqual(test_func(1, 2, 3, 4), 10)
            self.assertEqual(test_func(1, 2, d=4), 9)
            self.assertEqual(test_func(1, 2), 6)

    unittest.main()

# Generated at 2022-06-18 03:10:33.761695
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            logger = logging.getLogger("test_LoggedFunction___call__")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler(sys.stdout))

            @LoggedFunction(logger)
            def add(x, y):
                return x + y

            self.assertEqual(add(1, 2), 3)

    unittest.main()

# Generated at 2022-06-18 03:10:40.112597
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    import logging
    import io
    import sys
    from contextlib import redirect_stdout
    from unittest import TestCase
    from unittest.mock import patch

    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)
            self.logged_function = LoggedFunction(self.logger)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()

# Generated at 2022-06-18 03:10:47.130280
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def foo(a, b, c=1):
        return a + b + c

    foo(1, 2)
    foo(1, 2, 3)
    foo(1, 2, c=3)
    foo(1, b=2, c=3)
    foo(a=1, b=2, c=3)


# Generated at 2022-06-18 03:10:55.435545
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

    stream.truncate(0)
    test_func(1, 2, d=5)

# Generated at 2022-06-18 03:11:02.827414
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:11:11.414268
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger and set its level to DEBUG
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a stream handler and set its level to DEBUG
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)

    # Create a formatter and add it to the stream handler
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    stream_handler.setFormatter(formatter)

    # Add the stream handler to the logger
    logger.addHandler(stream_handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function to

# Generated at 2022-06-18 03:11:19.766118
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=1):
        return a + b + c

    test_func(1, 2, 3)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

    stream.truncate(0)
    stream.seek(0)
    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2)\ntest_func -> 4\n"

    stream.truncate

# Generated at 2022-06-18 03:11:29.690092
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2)


# Generated at 2022-06-18 03:11:53.290890
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2)\ntest_func -> 3\n"

    stream.truncate(0)
    stream.seek(0)
    test_func(1, 2, 3)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 3\n"

    stream.truncate(0)


# Generated at 2022-06-18 03:12:02.244933
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            @LoggedFunction(logger)
            def test_function(a, b, c=None):
                return a + b + c if c else a + b

            self.assertEqual(test_function(1, 2), 3)
            self.assertEqual(test_function(1, 2, 3), 6)

    unittest.main()

# Generated at 2022-06-18 03:12:10.444471
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)
    test_function(1, 2, c=4)

    # Check the output

# Generated at 2022-06-18 03:12:14.864341
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Capture output
    output = io.StringIO()
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(output))

    # Test function
    @LoggedFunction(logger)
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    output.seek(0)
    assert output.read() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:12:23.769551
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

    stream.truncate(0)
    test_func(1, 2, d=5)

# Generated at 2022-06-18 03:12:32.211412
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:12:42.591403
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @LoggedFunction(logging.getLogger("test"))
    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    @contextmanager
    def capture_log():
        stream = StringIO()
        handler = logging.StreamHandler(stream)
        logging.getLogger("test").addHandler(handler)
        try:
            yield stream
        finally:
            logging.getLogger("test").removeHandler(handler)

    with capture_log() as stream:
        test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=1, d=2)\ntest_func -> 6\n"


# Generated at 2022-06-18 03:12:51.837898
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def func(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_func = logged_function(func)

    # Call the function
    logged_func(1, 2)
    logged_func(1, 2, 3)
    logged_func(1, 2, 3, 4)
   

# Generated at 2022-06-18 03:13:02.022576
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a logged function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the logged function
    result = test_function(1, 2)
    assert result == 6

    # Check the output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    #

# Generated at 2022-06-18 03:13:09.124863
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_func(a, b, c=None):
                return a + b + c

            self.assertEqual(test_func(1, 2, 3), 6)
            self.assertEqual(test_func(1, 2), 3)

# Generated at 2022-06-18 03:13:48.618829
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.stream.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3, d=4):
                return a + b + c