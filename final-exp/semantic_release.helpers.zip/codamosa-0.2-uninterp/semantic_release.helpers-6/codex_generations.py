

# Generated at 2022-06-18 03:04:02.873229
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3):
                return a + b + c

            self.assertEqual(test_func(1, 2), 6)
            self.assertEqual(test_func(1, 2, c=4), 7)

    unittest.main()


if __name__ == "__main__":
    test_Log

# Generated at 2022-06-18 03:04:10.714197
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Capture stdout
    stdout = sys.stdout
    sys.stdout = io.StringIO()

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to log
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    assert sys.stdout.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Restore stdout
    sys.stdout = stdout

# Generated at 2022-06-18 03:04:17.678464
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, 2, c=3)
            test_function(1, b=2, c=3)
            test_function(a=1, b=2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:04:23.759975
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    @logged_function
    def test_function(a, b, c=None, d=None):
        return a + b + c + d

    test_function(1, 2, 3, 4)
    logger.debug.assert_has_calls(
        [
            call("test_function(1, 2, 3, 4)"),
            call("test_function -> 10"),
        ]
    )

# Generated at 2022-06-18 03:04:32.617025
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=Retry(total=1))

# Generated at 2022-06-18 03:04:40.437108
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    session = build_requests_session(retry=Retry())
    assert isinstance(session, Session)
    session = build_requests_session(retry=3)
    assert isinstance(session, Session)
    try:
        session = build_requests_session(retry=3.14)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-18 03:04:50.012644
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}

# Generated at 2022-06-18 03:04:59.324301
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to log
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    test_function(1, 2)

    # Check output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Clean up
   

# Generated at 2022-06-18 03:05:06.911006
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:05:15.994188
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create logged function
    @LoggedFunction(logger)
    def test_function(a, b, c=None):
        return a + b + c

    # Call logged function
    test_function(1, 2, 3)

    # Check output
    stream.seek(0)
    output = stream.read()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Call logged function with no return value
    test

# Generated at 2022-06-18 03:05:28.666168
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries

# Generated at 2022-06-18 03:05:32.210136
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=1):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, c=3)

# Generated at 2022-06-18 03:05:38.011141
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2, 3)
        test_func(1, 2)
        test_func(1, 2, c=3)


# Generated at 2022-06-18 03:05:45.191194
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    with redirect_stdout(stream):
        test_function(1, 2)
        test_function(1, 2, 3)
        test_function(1, 2, c=3)
        test

# Generated at 2022-06-18 03:05:51.434263
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue().strip() == "test_function(1, 2, c=3)"



# Generated at 2022-06-18 03:06:00.683243
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert len(session.adapters["http://"].max_retries.total) == 10
    assert len(session.adapters["https://"].max_retries.total) == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert len(session.adapters["http://"].max_retries.total) == 10
    assert len(session.adapters["https://"].max_retries.total) == 10

    session = build_requests_session(retry=False)

# Generated at 2022-06-18 03:06:06.713537
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    stream.seek(0)
    assert stream.read() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Clean up
    logger.removeHandler(handler)


# Generated at 2022-06-18 03:06:16.881934
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to test
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:06:26.962526
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Setup logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Define function to be logged
    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    # Call function
    test_func(1, 2, c=3)

    # Check output
    stream.seek(0)
    assert stream.read() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

# Generated at 2022-06-18 03:06:36.630936
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_without_args(self):
            def func():
                return 1

            logged_func = self.logged_function(func)
            result = logged_func()
            self.assertEqual(result, 1)
            self.logger.debug.assert_any_call("func()")
            self.logger.debug.assert_any_call("func -> 1")


# Generated at 2022-06-18 03:06:49.353028
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:06:55.700003
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=3)

# Generated at 2022-06-18 03:07:04.833557
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)

# Generated at 2022-06-18 03:07:11.682995
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_function(a, b, c=None):
                return a + b

            test_function(1, 2)
            test_function(1, 2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:07:18.836271
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    logger = Mock()
    logged_func = LoggedFunction(logger)
    def func(a, b, c=1, d=2):
        return a + b + c + d
    logged_func(func)(1, 2)
    logger.debug.assert_called_once_with("func(1, 2, c=1, d=2)")
    logger.debug.reset_mock()
    logged_func(func)(1, 2, 3, 4)
    logger.debug.assert_called_once_with("func(1, 2, c=3, d=4)")
    logger.debug.reset_mock()
    logged_func(func)(1, 2, d=3)

# Generated at 2022-06-18 03:07:29.195465
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be decorated
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    result = logged_test_function(1, 2)

    # Check the result
    assert result == 10



# Generated at 2022-06-18 03:07:34.776016
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    class TestLogger:
        def __init__(self):
            self.log_stream = StringIO()
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.log_stream))

        def get_log(self):
            return self.log_stream.getvalue()

    def test_func(a, b, c=None):
        return a + b + (c or 0)

    test_logger = TestLogger()
    logged_func = LoggedFunction(test_logger.logger)(test_func)
    logged_func(1, 2, 3)

# Generated at 2022-06-18 03:07:44.288219
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_func = LoggedFunction(logger)

    # Define a function
    def func(a, b, c=3):
        return a + b + c

    # Call the function
    logged_func(func)(1, 2)

    # Check the output
    assert stream.getvalue() == "func(1, 2, c=3)\nfunc -> 6\n"



# Generated at 2022-06-18 03:07:49.658427
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define function to be logged
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call function
    test_function(1, 2)

    # Check output

# Generated at 2022-06-18 03:07:55.379963
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}
    assert session.adapters != {}

    session = build_requ

# Generated at 2022-06-18 03:08:14.096205
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock
    from unittest.mock import patch

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def foo(a, b, c, d=None):
        return a + b + c

    foo(1, 2, 3)
    foo(a=1, b=2, c=3)
    foo(1, 2, 3, d=4)
    foo(1, 2, c=3, d=4)
    foo(1, b=2, c=3, d=4)
    foo(a=1, b=2, c=3, d=4)

    # Test for exception
   

# Generated at 2022-06-18 03:08:24.032571
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:08:32.404479
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3, d=4)\ntest_function -> 10\n"

# Generated at 2022-06-18 03:08:42.471956
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:08:47.823865
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Test function call
    with redirect_stdout(stream):
        test_function(1, 2, c=3)

# Generated at 2022-06-18 03:08:55.044911
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

    stream.truncate(0)
    test_func(1, 2, c=4)

# Generated at 2022-06-18 03:09:01.716850
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_function(a, b, c=3):
                return a + b + c

            self.assertEqual(test_function(1, 2), 6)

    unittest.main()

# Generated at 2022-06-18 03:09:10.858393
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(unittest.mock.Mock())

        def test_logged_func_no_args(self):
            @LoggedFunction(self.logger)
            def test_func():
                return "test_result"

            result = test_func()
            self.assertEqual(result, "test_result")

# Generated at 2022-06-18 03:09:14.333638
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    with redirect_stdout(stream):
        test_function(1, 2)
        test_function(1, 2, c=4)

    assert stream.getvalue() == "test_function(1, 2)\ntest_function -> 6\ntest_function(1, 2, c=4)\ntest_function -> 7\n"

# Generated at 2022-06-18 03:09:18.531692
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_function(a, b, c=1, d=2):
        return a + b + c + d

    test_function(1, 2, d=3)

# Generated at 2022-06-18 03:09:46.558776
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger and a stream to capture its output
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to be wrapped
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:09:52.749968
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logger")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            logged_function = LoggedFunction(logger)

            @logged_function
            def test_function(a, b, c=3, d=4):
                return a + b + c + d

            self.assertEqual(test_function(1, 2), 10)
            self.assertEqual(test_function(1, 2, d=5), 11)

    unittest.main()

# Generated at 2022-06-18 03:09:57.358539
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=1):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function

# Generated at 2022-06-18 03:10:05.496086
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = Mock(logging.Logger)
            logged_function = LoggedFunction(logger)

            def function(a, b, c=3):
                return a + b + c

            logged_function(function)(1, 2)
            logger.debug.assert_called_with("function(1, 2, c=3)")
            logger.debug.assert_called_with("function -> 6")

    unittest.main()

# Generated at 2022-06-18 03:10:15.587663
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the LoggedFunction
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:10:22.287427
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture log output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the log output
    assert stream.getvalue() == "test_function(1, 2)\ntest_function -> 6\n"

    # Clean up
   

# Generated at 2022-06-18 03:10:32.243188
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest import TestCase

    logger = Mock()
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None):
        pass

    logged_function(test_function)(1, 2, 3)
    logger.debug.assert_called_once_with(
        "test_function(1, 2, c=3)"
    )

    logger.reset_mock()
    logged_function(test_function)(1, 2)
    logger.debug.assert_called_once_with(
        "test_function(1, 2)"
    )

    logger.reset_mock()
    logged_function(test_function)(1, 2, c=3)

# Generated at 2022-06-18 03:10:41.366560
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    result = logged_test_function(1, 2, c=3)

    # Check the result
    assert result == 6

    # Check the log

# Generated at 2022-06-18 03:10:47.683949
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=1):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:10:56.009291
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=1):
        return a + b + c

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=1)\ntest_func -> 4\n"

    stream.truncate(0)
    stream.seek(0)
    test_func(1, 2, c=3)

# Generated at 2022-06-18 03:11:46.710888
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2, c=3, d=4)

# Generated at 2022-06-18 03:11:53.781261
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Wrap the function with LoggedFunction
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    assert stream.getvalue

# Generated at 2022-06-18 03:12:03.943813
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the LoggedFunction
    logged_function(test_function)(1, 2)
    logged_function(test_function)(1, 2, 3)
    logged_function(test_function)(1, 2, c=3)

    # Check the output
    output = stream.getvalue

# Generated at 2022-06-18 03:12:11.898695
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @LoggedFunction(logging.getLogger())
    def test_func(a, b, c=3):
        return a + b + c

    @contextmanager
    def capture_logging(logger):
        stream = StringIO()
        handler = logging.StreamHandler(stream)
        logger.addHandler(handler)
        try:
            yield stream
        finally:
            logger.removeHandler(handler)

    with capture_logging(logging.getLogger()) as stream:
        test_func(1, 2)
        assert stream.getvalue() == "test_func(1, 2, c=3)\n"


# Generated at 2022-06-18 03:12:22.110057
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    # Call the function
    test_func(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:12:30.795208
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:12:40.779452
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_func(a, b, c=3):
        return a + b + c

    # Call the function
    test_func(1, 2)

    # Check the output
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

    # Clean up


# Generated at 2022-06-18 03:12:49.874468
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:12:55.793644
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_function(arg1, arg2, kwarg1=None, kwarg2=None):
                return arg1 + arg2 + kwarg1 + kwarg2

            test_function(1, 2, kwarg1=3, kwarg2=4)

    unittest.main()

# Generated at 2022-06-18 03:13:05.609638
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2, c=3)

    # Check the log