

# Generated at 2022-06-18 03:04:00.831785
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = StringIO()
            handler = logging.StreamHandler(self.stream)
            handler.setLevel(logging.DEBUG)
            self.logger.addHandler(handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3):
                return a + b + c

            test_func(1, 2)

# Generated at 2022-06-18 03:04:06.587300
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=True)
    assert session.hooks == {}
    assert session.adapters != {}
    session = build_requests_session(retry=3)
    assert session.hooks == {}
    assert session.adapters != {}

# Generated at 2022-06-18 03:04:14.778026
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())

        def test_logged_func(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=1, d=2):
                return a + b + c + d

            self.assertEqual(test_func(1, 2, 3, 4), 10)
            self.assertEqual(test_func(1, 2, d=3), 7)
            self.assertEqual(test_func(1, 2), 6)


# Generated at 2022-06-18 03:04:23.523715
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_func(self):
            logger = logging.getLogger("test_logged_func")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            @LoggedFunction(logger)
            def test_func(a, b, c=1):
                return a + b + c
            test_func(1, 2, 3)
            test_func(1, 2)
            test_func(1, 2, c=3)
            test_func(1, 2, c=3, d=4)
            test_func(1, 2, d=4)

    unittest.main()

# Generated at 2022-06-18 03:04:29.363731
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.capturedOutput = io.StringIO()
            sys.stdout = self.capturedOutput

        def tearDown(self):
            sys.stdout = sys.__stdout__

        def test_logged_func_1(self):
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_func(a, b, c=3):
                return a + b + c

            test_func(1, 2)

# Generated at 2022-06-18 03:04:36.393867
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a decorator
    logged_function = LoggedFunction(logger)

    # Decorate a function
    @logged_function
    def test_function(arg1, arg2, kwarg1=None, kwarg2=None):
        return arg1 + arg2 + kwarg1 + kwarg2

    # Call the decorated function
    test_function(1, 2, kwarg1=3, kwarg2=4)

    # Check

# Generated at 2022-06-18 03:04:46.508323
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:04:55.049971
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def func(a, b, c=1, d=2):
        return a + b + c + d

    # Decorate the function
    logged_func = logged_function(func)

    # Call the function
    result = logged_func(1, 2, 3, 4)

    # Check the result
    assert result == 10

    # Check the log
    assert stream

# Generated at 2022-06-18 03:05:04.123709
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger()
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.stream.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
           

# Generated at 2022-06-18 03:05:08.568674
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    logger = DummyLogger()
    logged_func = LoggedFunction(logger)(test_func)
    assert logged_func(1, 2, 3, 4) == 10
    assert logger.logs == [
        "test_func(1, 2, c=3, d=4)",
        "test_func -> 10",
    ]

# Generated at 2022-06-18 03:05:21.125188
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_func(1, 2)

    # Check the output

# Generated at 2022-06-18 03:05:30.800241
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None, d=None):
        pass

    logged_function(test_function)(1, 2)
    logger.debug.assert_has_calls(
        [
            call("test_function(1, 2)"),
            call("test_function -> None"),
        ]
    )

    logged_function(test_function)(1, 2, 3, 4)
    logger.debug.assert_has_calls(
        [
            call("test_function(1, 2, 3, 4)"),
            call("test_function -> None"),
        ]
    )


# Generated at 2022-06-18 03:05:41.306982
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test"

            self.assertEqual(test_function(), "test")


# Generated at 2022-06-18 03:05:48.720194
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger and set its level to DEBUG
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    # Create a handler for the logger
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)

    # Create a formatter for the handler
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to be decorated
    def func(a, b, c=None):
        return a + b

# Generated at 2022-06-18 03:05:58.833291
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    logger = MagicMock()
    logged_function = LoggedFunction(logger)

    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    test_function(1, 2, 3)
    logger.debug.assert_called_with("test_function(1, 2, c=3)")
    logger.debug.assert_called_with("test_function -> 6")

    test_function(1, 2)
    logger.debug.assert_called_with("test_function(1, 2)")
    logger.debug.assert_called_with("test_function -> 3")

    test_function(1, 2, c=3)
    logger.debug.assert_

# Generated at 2022-06-18 03:06:09.097955
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.stream.close()


# Generated at 2022-06-18 03:06:19.353524
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the log output

# Generated at 2022-06-18 03:06:27.954904
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Create test function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call test function
    test_function(1, 2, c=3)

    # Check output
    stream.seek(0)

# Generated at 2022-06-18 03:06:37.681712
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=3)

# Generated at 2022-06-18 03:06:45.640476
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def add(a, b):
                return a + b

            self.assertEqual(add(1, 2), 3)

    unittest.main()


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-18 03:06:54.222886
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)

    unittest.main()

# Generated at 2022-06-18 03:07:00.234667
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to wrap
    def test_function(a, b, c=None):
        return a + b + c

    # Wrap the function
    wrapped_function = logged_function(test_function)

    # Call the wrapped function
    with redirect_stdout(stream):
        wrapped_function(1, 2, 3)

    # Check

# Generated at 2022-06-18 03:07:10.844770
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:07:16.845509
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = Mock(logging.Logger)
            logged_function = LoggedFunction(logger)

            def test_function(a, b, c=3):
                return a + b + c

            logged_test_function = logged_function(test_function)
            logged_test_function(1, 2)

            logger.debug.assert_called_once_with(
                "test_function(1, 2, c=3) -> 6"
            )

    unittest.main()

# Generated at 2022-06-18 03:07:25.507662
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.log_stream = StringIO()
            self.logger.addHandler(logging.StreamHandler(self.log_stream))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def test_function():
                return "test"

            test_function()
            self.assertEqual(self.log_stream.getvalue(), "test_function()\ntest_function -> test\n")


# Generated at 2022-06-18 03:07:33.643007
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2, c=3, d=4)
    test_func(1, 2, d=4, c=3)

# Generated at 2022-06-18 03:07:43.638747
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)

# Generated at 2022-06-18 03:07:49.077928
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest
    from io import StringIO

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = StringIO()
            handler = logging.StreamHandler(self.stream)
            handler.setLevel(logging.DEBUG)
            self.logger.addHandler(handler)

        def tearDown(self):
            self.logger.handlers = []

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            test_function(1, 2)

# Generated at 2022-06-18 03:07:55.193185
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=Retry(total=5))

# Generated at 2022-06-18 03:07:59.757149
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import io
    import sys

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            @LoggedFunction(logger)
            def test_function(a, b, c=None):
                return a + b + (c or 0)

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, 2, c=3)

# Generated at 2022-06-18 03:08:13.913464
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    test_function(1, 2)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:08:23.897095
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function to test
    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    result = test_func(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

    # Check the result

# Generated at 2022-06-18 03:08:28.311157
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.stream.close()


# Generated at 2022-06-18 03:08:38.426752
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_func(a, b, c=None):
        return a + b + c

    # Call the function
    logged_function(test_func)(1, 2, 3)

    # Check the log
    assert stream.getvalue() == "test_func(1, 2, 3)\ntest_func -> 6\n"

# Generated at 2022-06-18 03:08:47.880944
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function with no arguments
    @logged_function
    def test_function_no_args():
        return "no args"

    with redirect_stdout(stream):
        result = test_function_no_args()
    assert result == "no args"

# Generated at 2022-06-18 03:08:55.090182
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}

# Generated at 2022-06-18 03:09:02.121100
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def test_logged_function(self):
            # Create a logger and a StringIO to capture its output
            logger = logging.getLogger("test_logger")
            logger.setLevel(logging.DEBUG)
            log_stream = StringIO()
            handler = logging.StreamHandler(log_stream)
            logger.addHandler(handler)

            # Decorate a function
            @LoggedFunction(logger)
            def test_function(a, b, c=3):
                return a + b + c

            # Call the function
            test_function(1, 2)

            # Check the output

# Generated at 2022-06-18 03:09:11.287968
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=None):
        return a + b

    # Test function call
    with redirect_stdout(stream):
        test_function(1, 2, c=3)
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 3\n"

# Generated at 2022-06-18 03:09:18.301183
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to decorate
    @logged_function
    def test_function(a, b, c=1):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:09:28.291192
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert session.adapters["http://"].max_retries.total == 10
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"].max_retries, Retry)
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}

# Generated at 2022-06-18 03:09:44.692959
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    @LoggedFunction(logger)
    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    test_func(1, 2, 3, 4)
    test_func(1, 2, d=3)
    test_func(1, 2)

# Generated at 2022-06-18 03:09:52.215433
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=Retry())
    assert session.hooks == {}
    assert session.adapters != {}
    session = build_requests_session(retry=3)
    assert session.hooks == {}
    assert session.adapters != {}
    session = build_requests_session(raise_for_status=True, retry=False)
    assert session.hooks

# Generated at 2022-06-18 03:10:02.937299
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Define a function to be decorated
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check that the logger output is correct

# Generated at 2022-06-18 03:10:08.743264
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create test function
    def test_function(a, b, c=None, d=None):
        return a + b + c + d

    # Call LoggedFunction
    logged_test_function = logged_function(test_function)

    # Call logged test function
    logged_test_function(1, 2, 3, 4)

    # Check output

# Generated at 2022-06-18 03:10:18.325253
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            # Create a logger
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            logger.propagate = False

            # Create a stream to capture output
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            # Create a function to test
            @LoggedFunction(logger)
            def test_function(a, b, c=None):
                return a + b

            # Call the function
            result = test_function(1, 2, c=3)

            # Check

# Generated at 2022-06-18 03:10:25.957724
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = sys.stdout
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3):
                return a + b + c

            test_func(1, 2)


# Generated at 2022-06-18 03:10:36.586320
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import MagicMock
    from unittest.mock import ANY
    from unittest.mock import PropertyMock
    from unittest.mock import mock_open
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import create_autospec
    from unittest.mock import NonCallableMock
    from unittest.mock import NonCallableMagicMock
    from unittest.mock import MagicProxy
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    from unittest.mock import patch

# Generated at 2022-06-18 03:10:45.077548
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output

# Generated at 2022-06-18 03:10:53.561325
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.stream.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=1):
                return a + b + c

            test_function(1, 2)
            self.assertE

# Generated at 2022-06-18 03:11:00.522078
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    logger.propagate = False

    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    test_function(1, 2)
    test_function(1, 2, 3)
    test_function(1, 2, c=3)
    test_function(1, 2, c=4)
    test_function(1, b=2, c=4)
    test_function(a=1, b=2, c=4)



# Generated at 2022-06-18 03:11:33.474063
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be decorated
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the decorated function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:11:38.556021
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\n"

# Generated at 2022-06-18 03:11:47.594107
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def func(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_func = logged_function(func)

    # Call the function
    logged_func(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:11:48.658881
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)

# Generated at 2022-06-18 03:11:54.757875
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = unittest.mock.Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args_and_no_return_value(self):
            def test_function():
                pass

            self.logged_function(test_function)()
            self.logger.debug.assert_called_once_with("test_function()")

        def test_logged_function_with_args_and_no_return_value(self):
            def test_function(a, b, c):
                pass

            self.logged

# Generated at 2022-06-18 03:12:04.486593
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_func_no_args_no_return(self):
            @LoggedFunction(self.logger)
            def func():
                pass

            func()

        def test_logged_func_args_no_return(self):
            @LoggedFunction(self.logger)
            def func(a, b, c):
                pass

            func(1, 2, 3)


# Generated at 2022-06-18 03:12:09.051039
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.log_stream = io.StringIO()
            self.log_handler = logging.StreamHandler(self.log_stream)
            self.log_handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.log_handler)

        def tearDown(self):
            self.logger.removeHandler(self.log_handler)
            self.log_handler.close()
            self.log_stream.close()


# Generated at 2022-06-18 03:12:14.595267
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Define a function
    @LoggedFunction(logger)
    def test_function(a, b, c=1):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:12:23.499187
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the output
    stream.seek(0)
    assert stream.read() == "test_function(1, 2, c=3, d=4)\ntest_function -> 10\n"

# Generated at 2022-06-18 03:12:31.957117
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=3)

# Generated at 2022-06-18 03:13:23.372337
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create test function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call test function
    result = test_function(1, 2)

    # Check result
    assert result == 10

    # Check output
    output = stream.getvalue()

# Generated at 2022-06-18 03:13:33.588429
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.log_handler = logging.StreamHandler(io.StringIO())
            self.log_handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.log_handler)

        def tearDown(self):
            self.logger.removeHandler(self.log_handler)


# Generated at 2022-06-18 03:13:41.166889
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test"

            self.assertEqual(test_function(), "test")


# Generated at 2022-06-18 03:13:51.565691
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters