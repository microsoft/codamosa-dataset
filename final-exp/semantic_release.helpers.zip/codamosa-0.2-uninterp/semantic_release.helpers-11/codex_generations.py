

# Generated at 2022-06-18 03:04:03.589401
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a test function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the test function
    logged_test_function = logged_function(test_function)

    # Call the test function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:04:11.194127
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    log_stream = StringIO()
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(log_stream))

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to decorate
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    assert (
        log_stream.getvalue()
        == "test_function(1, 2, c=3)\ntest_function -> 6\n"
    )



# Generated at 2022-06-18 03:04:18.242294
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=Retry(total=3))

# Generated at 2022-06-18 03:04:26.193588
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def func(a, b, c=None):
                return a + b + c

            self.assertEqual(func(1, 2, 3), 6)
            self.assertEqual(func(1, 2), 3)

# Generated at 2022-06-18 03:04:34.368518
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=Retry(total=3))

# Generated at 2022-06-18 03:04:45.065070
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

    stream.truncate(0)
    test_func(1, 2, c=5)

# Generated at 2022-06-18 03:04:53.421194
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=1):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:05:02.845666
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a handler to capture output
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\n"

    # Call the

# Generated at 2022-06-18 03:05:10.328041
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger with a StringIO handler
    log_stream = StringIO()
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(log_stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a test function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the test function
    test_function(1, 2)

    # Check the log output
    log_output = log_stream.getvalue()

# Generated at 2022-06-18 03:05:19.545313
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def test_func(a, b=1, c=2):
        return a + b + c

    with captured_output() as (out, err):
        logger = logging.getLogger("test_logger")
        logger.setLevel(logging.DEBUG)
       

# Generated at 2022-06-18 03:05:31.315052
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call
    from unittest.mock import patch
    from unittest.mock import sentinel

    logger = Mock()
    logged_function = LoggedFunction(logger)

    @logged_function
    def test_function(a, b, c=None):
        return sentinel.result

    # Test with no arguments
    test_function()
    logger.debug.assert_called_once_with("test_function()")

    # Test with positional arguments
    logger.reset_mock()
    test_function(1, 2, 3)
    logger.debug.assert_called_once_with("test_function(1, 2, 3)")

    # Test with keyword arguments
    logger.reset_mock()

# Generated at 2022-06-18 03:05:41.850669
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = Mock()
            logged_function = LoggedFunction(logger)
            function = Mock(return_value=1)
            logged_function(function)(1, 2, 3, a=4, b=5, c=6)
            logger.debug.assert_called_with(
                "function(1, 2, 3, a=4, b=5, c=6)"
            )
            function.assert_called_with(1, 2, 3, a=4, b=5, c=6)
            logger.debug.assert_called_with("function -> 1")


# Generated at 2022-06-18 03:05:49.346138
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    logged_func = LoggedFunction(logger)(test_func)

    # Test with no arguments
    logged_func()
    # Test with positional arguments
    logged_func(1, 2)
    # Test with keyword arguments
    logged_func(1, 2, c=3, d=4)
    # Test with positional and keyword arguments
    logged_func(1, 2, 3, 4)

    # Test with positional and keyword arguments

# Generated at 2022-06-18 03:05:59.387960
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b

    # Call the LoggedFunction
    logged_function(test_function)(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 3\n"

# Generated at 2022-06-18 03:06:04.016447
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, c=3)
    test_func(1, b=2, c=3)
    test_func(a=1, b=2, c=3)

# Generated at 2022-06-18 03:06:10.841171
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function with no arguments
    @logged_function
    def test_function_no_arguments():
        return "test_function_no_arguments"

    # Capture output
    f = io.StringIO()

# Generated at 2022-06-18 03:06:20.056352
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            self.assertEqual(test_function(1, 2), 6)
            self.assertEqual(test_function(1, 2, c=4), 7)

    unittest.main()

# Generated at 2022-06-18 03:06:28.075385
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

    stream.truncate(0)
    stream.seek(0)
    test_func(1, 2, d=5)

# Generated at 2022-06-18 03:06:37.733412
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=None):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:06:47.439043
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test_result"

            with unittest.mock.patch("logging.Logger.debug") as mock_debug:
                result = test_function()
                mock_debug.assert_any_call("test_function()")

# Generated at 2022-06-18 03:06:56.866139
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    def test_func(a, b, c=None):
        return a + b + c

    logger = Logger()
    logged_func = LoggedFunction(logger)(test_func)
    assert logged_func(1, 2, 3) == 6
    assert logged_func(1, 2) == 3
    assert logged_func(1, 2, c=3) == 6
    assert logged_func(1, 2, c=3, d=4) == 6
    assert logged_func.__name__ == "test_func"

# Generated at 2022-06-18 03:07:05.841474
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:07:14.474640
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    # Define a function to decorate
    @LoggedFunction(logger)
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:07:18.742320
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    test_func(1, 2, 3)
    test_func(1, 2)
    test_func(1, 2, c=3)
    test_func(1, 2, c=3, d=4)



# Generated at 2022-06-18 03:07:29.072319
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output

# Generated at 2022-06-18 03:07:34.721660
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_logs(logger):
        """
        Capture logs from a logger.
        :param logger: Logger to capture logs from.
        :return: StringIO instance containing captured logs.
        """
        stream = StringIO()
        handler = logging.StreamHandler(stream)
        logger.addHandler(handler)
        try:
            yield stream
        finally:
            logger.removeHandler(handler)

    def test_func(a, b, c=None):
        return a + b + c

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logged_func = LoggedFunction(logger)(test_func)

# Generated at 2022-06-18 03:07:44.529611
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Capture stdout
    stdout = sys.stdout
    sys.stdout = io.StringIO()

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)
    test_function(1, 2)
    test_function(1, 2, c=3)

    # Restore stdout
    sys.stdout = stdout

    # Check output

# Generated at 2022-06-18 03:07:53.586536
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=None):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Capture stdout
    f = io.StringIO()
    with redirect_stdout(f):
        # Call the logged function
        result = logged_test_function(1, 2, c=3)

    #

# Generated at 2022-06-18 03:08:03.565553
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.log_stream = io.StringIO()
            self.log_handler = logging.StreamHandler(self.log_stream)
            self.logger.addHandler(self.log_handler)

        def tearDown(self):
            self.logger.removeHandler(self.log_handler)
            self.log_stream.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + c

# Generated at 2022-06-18 03:08:10.294558
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test_function(1, 2, 3)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:08:23.791387
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler(sys.stdout))
            logged_function = LoggedFunction(logger)

            @logged_function
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, 2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:08:32.238331
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    result = logged_test_function(1, 2)

    # Check the result
    assert result == 6

    # Check the log


# Generated at 2022-06-18 03:08:42.318249
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Capture output
    captured_output = io.StringIO()
    sys.stdout = captured_output

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # Decorate function
    logged_function = LoggedFunction(logger)
    decorated_function = logged_function(test_function)

    # Call function
    decorated_function(1, 2, d=5)

    # Check output

# Generated at 2022-06-18 03:08:51.418401
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger which writes to a string
    output = StringIO()
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(output))

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to decorate
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    result = test_function(1, 2, c=3)

    # Check the output
    assert output.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Check the result
    assert result == 6

# Generated at 2022-06-18 03:08:59.893511
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Call the LoggedFunction
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:09:09.223299
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:09:16.636792
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2, 3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:09:26.824257
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a logged function
    @LoggedFunction(logger)
    def test(a, b, c=3):
        return a + b + c

    # Call the logged function
    test(1, 2)

    # Check the output
    assert stream.getvalue() == "test(1, 2, c=3)\ntest -> 6\n"

    # Clean up
    logger.removeHandler(handler)
    stream.close()
    del sys.modules[__name__]

# Generated at 2022-06-18 03:09:31.721177
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    test_func(1, 2, 3, 4)
    test_func(1, 2, d=3)
    test_func(1, 2)

# Generated at 2022-06-18 03:09:39.522991
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, c=4)
        test_func(1, 2, c=4, d=5)


# Generated at 2022-06-18 03:09:59.705621
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    logger = Mock(logging.Logger)
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=1, d=2):
        return a + b + c + d

    logged_test_function = logged_function(test_function)
    assert logged_test_function(1, 2) == 6
    logger.debug.assert_called_with("test_function(1, 2, c=1, d=2)")
    logger.debug.assert_called_with("test_function -> 6")

    logger.reset_mock()
    assert logged_test_function(1, 2, 3, 4) == 10

# Generated at 2022-06-18 03:10:07.216280
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Decorate a function
    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    # Call the function
    test_func(1, 2, c=3)

    # Check the output
    stream.seek(0)
    assert stream.read().strip() == "test_func(1, 2, c=3) -> 6"



# Generated at 2022-06-18 03:10:15.972770
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b

    test_func(1, 2)
    test_func(1, 2, c=3)
    assert stream.getvalue() == "test_func(1, 2)\ntest_func -> 3\ntest_func(1, 2, c=3)\ntest_func -> 3\n"

# Generated at 2022-06-18 03:10:24.014623
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to decorate
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the decorated function
    test_function(1, 2)

    # Check the output
    stream.seek(0)
    output = stream.read()

# Generated at 2022-06-18 03:10:33.760856
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, 2, c=3)
            test_function(1, 2, c=3, d=4)

    unittest.main()

# Generated at 2022-06-18 03:10:40.123750
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            def func():
                pass

            self.logged_function(func)()
            self.logger.debug.assert_called_once_with("func()")

        def test_logged_function_with_positional_arguments(self):
            def func(a, b, c):
                pass

            self.logged_function(func)(1, 2, 3)
            self.logger.debug.assert_called_once

# Generated at 2022-06-18 03:10:43.923411
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logger.propagate = False

        def test_logged_function(self):
            def test_function(a, b, c=None):
                return a + b + c

            with unittest.mock.patch("logging.Logger.debug") as mock_debug:
                logged_function = LoggedFunction(self.logger)(test_function)
                logged_function(1, 2, 3)
                mock_debug.assert_

# Generated at 2022-06-18 03:10:53.485310
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Create a stream to capture output
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function to test
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    with redirect_stdout(stream):
        test_function(1, 2)
        test_function(1, 2, c=4)

# Generated at 2022-06-18 03:11:00.918927
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    assert test_func(1, 2) == 10
    assert test_func(1, 2, 5) == 13
    assert test_func(1, 2, d=5) == 11
    assert test_func(1, 2, 5, 6) == 15
    assert test_func(1, 2, c=5, d=6) == 14
    assert test_func(1, 2, d=6, c=5) == 14

# Generated at 2022-06-18 03:11:09.160361
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest import TestCase

    logger = Mock()
    logged_function = LoggedFunction(logger)

    def test_function(arg1, arg2, kwarg1=None, kwarg2=None):
        return arg1 + arg2 + kwarg1 + kwarg2

    logged_test_function = logged_function(test_function)

    # Test with no arguments
    logged_test_function()
    logger.debug.assert_called_once_with("test_function()")

    # Test with arguments
    logger.reset_mock()
    logged_test_function(1, 2, kwarg1=3, kwarg2=4)

# Generated at 2022-06-18 03:11:29.653433
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function

# Generated at 2022-06-18 03:11:36.405028
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a logged function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:11:45.811110
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=Retry(total=5))

# Generated at 2022-06-18 03:11:53.290764
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call function
    test_function(1, 2)

    # Check output
    output = stream.getvalue()

# Generated at 2022-06-18 03:12:03.539004
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

# Generated at 2022-06-18 03:12:11.559775
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function to be logged
    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    # Call the function
    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, 3)
        test_func(1, 2, c=3)
        test_func(1, 2, c=4)

# Generated at 2022-06-18 03:12:21.778762
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Decorate a function
    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    # Call the function
    test_func(1, 2)

    # Check the output

# Generated at 2022-06-18 03:12:25.986306
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = Mock(logging.Logger)
            logged_function = LoggedFunction(logger)
            function = Mock()
            function.__name__ = "function"
            logged_function(function)(1, 2, 3, a=4, b=5, c=6)
            logger.debug.assert_called_once_with(
                "function(1, 2, 3, a=4, b=5, c=6)"
            )
            function.assert_called_once_with(1, 2, 3, a=4, b=5, c=6)
            logger.debug.reset_mock()

# Generated at 2022-06-18 03:12:34.704645
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    result = test_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:12:38.046272
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.log_stream = io.StringIO()
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.log_stream))

        def test_logged_func(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3):
                return a + b + c

            test_func(1, 2)

# Generated at 2022-06-18 03:13:06.315077
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:13:15.922042
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    logger = Mock(logging.Logger)
    logged_function = LoggedFunction(logger)
    func = logged_function(lambda x: x)
    func(1)
    logger.debug.assert_called_with("<lambda>(1)")
    func(1, 2)
    logger.debug.assert_called_with("<lambda>(1, 2)")
    func(1, 2, 3)
    logger.debug.assert_called_with("<lambda>(1, 2, 3)")
    func(1, 2, 3, a=4)
    logger.debug.assert_called_with("<lambda>(1, 2, 3, a=4)")
    func(1, 2, 3, a=4, b=5)

# Generated at 2022-06-18 03:13:23.120612
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_func(a, b, c=None):
        return a + b + c

    # Create a logged function
    logged_test_func = logged_function(test_func)

    # Call the logged function
    logged_test_func(1, 2, 3)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:13:33.550007
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call function
    with redirect_stdout(stream):
        test_function(1, 2)
        test_function(1, 2, 3)
        test_function(1, 2, 3, 4)

# Generated at 2022-06-18 03:13:40.612693
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2, c=3)
    test_func(1, 2, c=3, d=4)


# Generated at 2022-06-18 03:13:51.494075
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
   