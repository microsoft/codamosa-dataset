

# Generated at 2022-06-18 03:03:59.223015
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=1):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, c=3)

# Generated at 2022-06-18 03:04:07.421433
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import io

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3):
                return a + b + c

            test_func(1, 2)

# Generated at 2022-06-18 03:04:15.555977
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def foo():
                return "bar"

            self.assertEqual(foo(), "bar")

        def test_logged_function_with_args(self):
            @self.logged_function
            def foo(a, b, c):
                return a + b + c


# Generated at 2022-06-18 03:04:23.759988
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    class TestLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    def test_func(a, b, c=3):
        return a + b + c

    logger = TestLogger()
    logged_func = LoggedFunction(logger)(test_func)
    assert logged_func(1, 2) == 6
    assert logger.logs == [
        "test_func(1, 2, c=3)",
        "test_func -> 6",
    ]

    logger = TestLogger()
    logged_func = LoggedFunction(logger)(test_func)
    assert logged_func(1, 2, c=4) == 7
    assert logger.logs

# Generated at 2022-06-18 03:04:29.522869
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_function(a, b, c=1):
                return a + b + c

            self.assertEqual(test_function(1, 2, 3), 6)
            self.assertEqual(test_function(1, 2), 4)

# Generated at 2022-06-18 03:04:36.310673
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    def test_func(a, b, c=3):
        return a + b + c

    # Create logger and capture output
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Decorate function
    logged_func = LoggedFunction(logger)(test_func)

    # Call function
    with redirect_stdout(stream):
        logged_func(1, 2)

    # Check output
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

# Generated at 2022-06-18 03:04:46.392195
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_func(a, b, c=3, d=4):
                return a + b + c + d

            with unittest.mock.patch("builtins.print") as mock_print:
                result = test_func(1, 2)
                mock_print.assert_

# Generated at 2022-06-18 03:04:54.928660
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = StringIO()
            handler = logging.StreamHandler(self.stream)
            handler.setLevel(logging.DEBUG)
            self.logger.addHandler(handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3):
                return a + b + c

            test_func(1, 2)

# Generated at 2022-06-18 03:05:04.039744
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import patch

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logged_function = LoggedFunction(logger)

            @logged_function
            def test_function(a, b, c=3):
                return a + b + c

            with patch.object(logger, "debug") as mock_debug:
                result = test_function(1, 2)
                self.assertEqual(result, 6)
                mock_debug.assert_any_call("test_function(1, 2, c=3)")
                mock_debug.assert_any_call("test_function -> 6")



# Generated at 2022-06-18 03:05:09.339122
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Create function to be decorated
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)
    test_function

# Generated at 2022-06-18 03:05:20.801313
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Capture stdout
    stdout = sys.stdout
    sys.stdout = io.StringIO()

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # Decorate function
    @LoggedFunction(logger)
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call function
    test_function(1, 2)

    # Check output
    output = sys.stdout.getvalue()
    assert output == "test_function(1, 2, c=3, d=4)\ntest_function -> 10\n"

    # Restore stdout
    sys.std

# Generated at 2022-06-18 03:05:29.849508
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert session.adapters == {}
    session = build_requests_session(retry=True)
    assert session.adapters != {}
    session = build_requests_session(retry=Retry())
    assert session.adapters != {}
    session = build_requests_session(retry=Retry(total=5))
    assert session.adapters != {}
    try:
        session = build_requests_session(retry=5.0)
        assert False
    except ValueError:
        assert True
    try:
        session = build_requests_session(retry="5")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-18 03:05:35.520258
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to decorate
    @logged_function
    def f(a, b, c=3):
        return a + b + c

    # Call the decorated function
    f(1, 2)

    # Check the output

# Generated at 2022-06-18 03:05:44.666405
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.log_stream = io.StringIO()
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.log_stream))

        def test_logged_function_with_no_args(self):
            @LoggedFunction(self.logger)
            def foo():
                return "bar"

            foo()
            self.assertEqual(self.log_stream.getvalue(), "foo()\nfoo -> bar\n")


# Generated at 2022-06-18 03:05:51.456876
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    result = logged_test_function(1, 2)

    # Check the result
    assert result == 10

    # Check the log
    log = stream.getvalue()

# Generated at 2022-06-18 03:06:00.681972
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=None):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:06:09.603615
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the LoggedFunction
    logged_func = logged_function(func)
    result = logged_func(1, 2, d=5)

    # Check the result
    assert result == 11

    # Check the log
    stream.seek(0)

# Generated at 2022-06-18 03:06:19.886301
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    logged

# Generated at 2022-06-18 03:06:27.980917
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Define a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_function = LoggedFunction(logger)(test_function)

    # Call the function
    logged_function(1, 2, 3)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:06:36.764168
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_func(self):
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            @LoggedFunction(logger)
            def test_func(a, b, c=1):
                return a + b + c
            test_func(1, 2, c=3)
            test_func(1, 2)
            test_func(1, 2, 3)
            test_func(1, 2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:06:49.168742
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest.mock import Mock

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    def test_func(a, b, c=None):
        return a + b + c

    logged_func = LoggedFunction(logger)(test_func)
    logged_func(1, 2, 3)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

    stream.seek(0)
    stream.truncate()
    logged_func(1, 2)
    assert stream.getvalue

# Generated at 2022-06-18 03:06:55.512784
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a handler for the logger
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(arg1, arg2, kwarg1=None, kwarg2=None):
        return "test"

    # Call the function

# Generated at 2022-06-18 03:07:04.539762
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:07:13.717493
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test_function_result"

            self.assertEqual(test_function(), "test_function_result")


# Generated at 2022-06-18 03:07:19.646538
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    from io import StringIO

    # Create a logger and redirect stdout to a StringIO object
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to test
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check that the output is as expected

# Generated at 2022-06-18 03:07:30.186401
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks["response"] == [lambda r, *args, **kwargs: r.raise_for_status()]
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(False)
    assert "response" not in session.hooks
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks["response"] == [lambda r, *args, **kwargs: r.raise_for_status()]

# Generated at 2022-06-18 03:07:40.570231
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.stream.close()


# Generated at 2022-06-18 03:07:51.019752
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler(sys.stdout))

            @LoggedFunction(logger)
            def test_function(a, b, c=1, d=2):
                return a + b + c + d

            test_function(1, 2, 3, 4)
            test_function(1, 2, c=3, d=4)
            test_function(1, 2, d=4, c=3)
            test_function(1, 2)

    unittest.main()

# Generated at 2022-06-18 03:07:59.413425
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=1):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, c=3)
    test_func(1, b=2, c=3)
    test_func(a=1, b=2, c=3)

# Generated at 2022-06-18 03:08:08.044548
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logger")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            logged_function = LoggedFunction(logger)

            @logged_function
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, b=2)
            test_function(a=1, b=2)
            test_function(a=1, b=2, c=3)

    unittest.main()



# Generated at 2022-06-18 03:08:26.241474
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.log_stream = io.StringIO()
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.log_stream))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + (c or 0)

            test_function(1, 2, 3)

# Generated at 2022-06-18 03:08:34.833482
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a function to wrap
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\n"

    # Call the function again

# Generated at 2022-06-18 03:08:44.825465
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:08:50.228935
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def func(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_func = logged_function(func)

    # Call the function
    logged_func(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:08:59.372980
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)
    test_function(1, 2)
    test_function(1, 2, c=3)

    # Check output

# Generated at 2022-06-18 03:09:08.928186
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logged_function")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_function(a, b, c=None):
                return a + b + c

            self.assertEqual(test_function(1, 2, 3), 6)
            self.assertEqual(test_function(1, 2), 3)

# Generated at 2022-06-18 03:09:15.855436
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger()
            self.logger.level = logging.DEBUG
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + (c or 0)

            self.assertEqual(test_function(1, 2), 3)
            self.assertEqual(test_function(1, 2, 3), 6)

    unittest.main()

# Generated at 2022-06-18 03:09:25.423122
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import create_autospec
    from unittest.mock import PropertyMock
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import Mock
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT

# Generated at 2022-06-18 03:09:33.826208
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=None):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test_function(1, 2, 3)

    # Check the output
    stream_handler.flush()
    stream_

# Generated at 2022-06-18 03:09:42.330691
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a StringIO object
    string_io = StringIO()

    # Get the logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a handler that writes to the StringIO object
    handler = logging.StreamHandler(string_io)
    handler.setLevel(logging.DEBUG)

    # Create a formatter and add it to the handler
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Create a LoggedFunction object
    logged_function = LoggedFunction(logger)

    # Define a function

# Generated at 2022-06-18 03:10:07.999422
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())

        def test_LoggedFunction___call__(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=1):
                return a + b + c

            test_func(1, 2, c=3)
            test_func(1, 2)
            test_func(1, 2, 3)

    unittest.main()

# Generated at 2022-06-18 03:10:17.682436
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test

# Generated at 2022-06-18 03:10:23.270739
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(arg1, arg2, kwarg1=None, kwarg2=None):
        return arg1 + arg2 + kwarg1 + kwarg2

    test_func(1, 2, kwarg1=3, kwarg2=4)
    assert stream.getvalue() == "test_func(1, 2, kwarg1=3, kwarg2=4)\ntest_func -> 10\n"

# Generated at 2022-06-18 03:10:33.802762
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:10:40.153217
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}
    assert session.adapters != {}

    session = build_requests_session(retry=3)
    assert session.hooks == {}
    assert session.adapters != {}

    retry = Retry()
   

# Generated at 2022-06-18 03:10:43.938028
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    log_stream = io.StringIO()
    handler = logging.StreamHandler(log_stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the log
    log_stream.seek(0)
    log_output = log_stream.read()

# Generated at 2022-06-18 03:10:53.496393
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger with a StringIO handler
    log_stream = io.StringIO()
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(log_stream))

    # Create a LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Define a function to be decorated
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    log_output = log_stream.getvalue()
    assert "test_function(1, 2, c=3)" in log_output
    assert "test_function -> 6" in log_

# Generated at 2022-06-18 03:11:00.919891
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def test_function():
                pass

            test_function()

        def test_logged_function_with_args(self):
            @self.logged_function
            def test_function(arg1, arg2):
                pass

            test_function(1, 2)



# Generated at 2022-06-18 03:11:09.188444
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, c=3)
    test_func(1, b=2, c=3)
    test_func(a=1, b=2, c=3)

# Generated at 2022-06-18 03:11:17.567935
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Create test function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Test function
    with redirect_stdout(stream):
        assert test_function(1, 2) == 6

# Generated at 2022-06-18 03:12:08.875244
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout
    from unittest import TestCase

    class LoggedFunctionTest(TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            logger.addHandler(handler)

            @LoggedFunction(logger)
            def test_function(a, b, c=3):
                return a + b + c

            test_function(1, 2)
            test_function(1, 2, c=4)
            test_function(1, 2, 3)
            test_function(1, 2, 3, 4)


# Generated at 2022-06-18 03:12:14.819052
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logger")
            logger.setLevel(logging.DEBUG)
            stream = StringIO()
            handler = logging.StreamHandler(stream)
            logger.addHandler(handler)
            @LoggedFunction(logger)
            def test_func(a, b, c=3):
                return a + b + c
            with redirect_stdout(stream):
                test_func(1, 2)
                test_func(1, 2, 3)
                test_func(1, 2, c=3)

# Generated at 2022-06-18 03:12:23.695567
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def f():
                return "result"

            self.assertEqual(f(), "result")

        def test_logged_function_with_positional_arguments(self):
            @self.logged_function
            def f(a, b, c):
                return

# Generated at 2022-06-18 03:12:32.119115
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    def test_function(a, b, c=3):
        return a + b + c

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Decorate the function
    logged_function = LoggedFunction(logger)
    logged_test_function = logged_function(test_function)

    # Call the function
    result = logged_test_function(1, 2)

    # Check the result
    assert result == 6

    # Check the log
    log_output = stream.getvalue()

# Generated at 2022-06-18 03:12:42.486636
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2, 3)
        test_func(1, 2)
        test_func(1, b=2, c=3)


# Generated at 2022-06-18 03:12:51.736614
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def test_function():
                return "test_result"

            self.assertEqual(test_function(), "test_result")


# Generated at 2022-06-18 03:13:02.021749
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True, retry=False)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:13:09.122959
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            # Create a logger
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            # Create a LoggedFunction instance
            logged_function = LoggedFunction(logger)

            # Create a function
            def func(a, b, c=3):
                return a + b + c

            # Call the function
            result = logged_function(func)(1, 2)

            # Check the result

# Generated at 2022-06-18 03:13:18.051894
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Decorate function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    test_function(1, 2)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:13:24.133863
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to wrap
    def test_function(a, b, c=3):
        return a + b + c

    # Wrap the function
    wrapped_function = logged_function(test_function)

    # Call the wrapped function
    wrapped_function(1, 2)

    # Check the output
    output = stream.getvalue()