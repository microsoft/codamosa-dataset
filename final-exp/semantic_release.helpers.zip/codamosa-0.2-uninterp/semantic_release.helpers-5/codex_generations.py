

# Generated at 2022-06-18 03:04:01.593391
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:04:09.345244
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:04:17.583810
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger and a stream to capture output
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Define a function to decorate
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    result = test_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert "test_function(1, 2, c=3)" in output
    assert "test_function -> 6" in output
    assert result == 6



# Generated at 2022-06-18 03:04:25.498159
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, 3)
        test_func(1, 2, 3, 4)
        test_func(1, 2, d=4)

# Generated at 2022-06-18 03:04:30.611738
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:04:40.515679
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    logged_test_func = logged_function(test_func)
    result = logged_test_func(1, 2)

    # Check the result
    assert result == 10

    # Check the log
    log = stream.getvalue

# Generated at 2022-06-18 03:04:50.072449
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    with redirect_stdout(stream):
        assert test_function(1, 2) == 6

# Generated at 2022-06-18 03:04:59.400534
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:05:06.979264
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:05:15.389596
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            self.assertEqual(test_function(1, 2), 6)
            self.assertEqual(test_function(1, 2, c=4), 7)

    unittest.main()

# Generated at 2022-06-18 03:05:30.618013
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert session.adapters == {}
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

    session = build_requests_session(retry=True)
    assert session.adapters != {}
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

    session = build_requests_session(retry=Retry(total=3))
    assert session.adapters != {}
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

    session = build_requests_session(retry=3)
    assert session.adapters != {}
   

# Generated at 2022-06-18 03:05:41.228894
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:05:48.646877
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def foo():
                return "bar"

            self.assertEqual(foo(), "bar")

        def test_logged_function_with_args(self):
            @self.logged_function
            def foo(a, b):
                return a + b


# Generated at 2022-06-18 03:05:57.431824
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)

            @LoggedFunction(logger)
            def test_function(a, b, c=3):
                return a + b + c

            test_function(1, 2)
            test_function(1, 2, 3)
            test_function(1, 2, c=3)

    unittest.main()


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-18 03:06:08.002258
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger with a StringIO handler
    stream = StringIO()
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Test function
    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    # Call function
    test_func(1, 2)

    # Check output
    assert stream.getvalue() == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

# Generated at 2022-06-18 03:06:17.666831
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_

# Generated at 2022-06-18 03:06:27.257205
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + (c or 0)

    test_func(1, 2, 3)
    test_func(1, 2)
    test_func(1, 2, c=3)
    test_func(1, 2, c=None)
    test_func(1, 2, c=0)
    test_func(1, 2, c=False)


# Generated at 2022-06-18 03:06:37.025444
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.stream.close()


# Generated at 2022-06-18 03:06:46.614476
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    @LoggedFunction(logging.getLogger("test"))
    def test_func(a, b, c=None):
        return a + b + c

    with captured_output() as (out, err):
        test_func(1, 2, 3)

# Generated at 2022-06-18 03:06:53.308606
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:07:08.962939
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_logging(logger):
        stream = StringIO()
        handler = logging.StreamHandler(stream)
        logger.addHandler(handler)
        try:
            yield stream
        finally:
            logger.removeHandler(handler)

    def test_func(a, b, c=3):
        return a + b + c

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logged_func = LoggedFunction(logger)(test_func)

    with capture_logging(logger) as stream:
        assert logged_func(1, 2) == 6
        assert logged_func(1, 2, 3) == 6

# Generated at 2022-06-18 03:07:16.412608
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger with a StringIO handler
    log_stream = io.StringIO()
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(log_stream))

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the log output
    log_output = log_stream.getvalue()

# Generated at 2022-06-18 03:07:25.167495
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:07:33.450565
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import patch

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logged_function = LoggedFunction(self.logger)

        @patch("logging.Logger.debug")
        def test_logged_function(self, mock_debug):
            @self.logged_function
            def test_func(a, b, c=3):
                return a + b + c

            test_func(1, 2)

# Generated at 2022-06-18 03:07:42.540320
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3, d=4):
                return a + b + c + d

            self.assertEqual(test_function(1, 2), 10)
            self.assertEqual(test_function(1, 2, d=5), 11)

    unittest.main()

# Generated at 2022-06-18 03:07:48.319142
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Call LoggedFunction
    logged_function(test_function)(1, 2)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:07:54.993715
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b

    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, 3)
        test_func(a=1, b=2, c=3)


# Generated at 2022-06-18 03:08:04.429833
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:08:10.741404
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to be logged
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    logged_function(test_function)(1, 2, 3)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:08:20.932025
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output

# Generated at 2022-06-18 03:08:40.464494
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import io
    import sys

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_return(self):
            @self.logged_function
            def test_function(a, b, c=3):
                pass

            test_function(1, 2)

# Generated at 2022-06-18 03:08:50.311759
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to test
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    test_function(1, 2)

    # Check output
    stream.seek(0)
    assert stream.read() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:08:56.060613
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.stream.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return

# Generated at 2022-06-18 03:09:02.512876
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a decorator
    decorator = LoggedFunction(logger)

    # Create a function
    @decorator
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    result = test_function(1, 2)

    # Check the output
    assert result == 6
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:09:11.532791
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    class Logger:
        def __init__(self):
            self.log = io.StringIO()
            self.handler = logging.StreamHandler(self.log)
            self.logger = logging.getLogger("test")
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

        def get_log(self):
            return self.log.getvalue()

    def test_func(a, b, c=None):
        return a + b + c

    logger = Logger()
    logged_func = LoggedFunction(logger.logger)(test_func)
    assert logged_func(1, 2, 3) == 6

# Generated at 2022-06-18 03:09:18.709133
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def func():
                return "result"

            self.assertEqual(func(), "result")


# Generated at 2022-06-18 03:09:27.205238
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            @LoggedFunction(logger)
            def test_func(a, b, c=3):
                return a + b + c
            self.assertEqual(test_func(1, 2), 6)
            self.assertEqual(test_func(1, 2, c=4), 7)

    unittest.main()

# Generated at 2022-06-18 03:09:35.206516
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a stream for logging
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a function to decorate
    @LoggedFunction(logger)
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:09:43.627620
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(StringIO()))

    @LoggedFunction(logger)
    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2)
    test_func(1, 2, d=4, c=3)
    test_func(1, 2, c=3)
    test_func(1, 2, 3)
    test_func(1, 2, 3, d=4)

# Generated at 2022-06-18 03:09:51.024969
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:10:18.907536
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    test_function(1, 2)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:10:26.313642
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the LoggedFunction
    logged_function(test_function)(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\n"



# Generated at 2022-06-18 03:10:36.839942
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=1):
        return a + b + c

    # Decorate the function
    decorated_function = logged_function(test_function)

    # Call the function
    decorated_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:10:45.343807
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)

# Generated at 2022-06-18 03:10:53.669201
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(unittest.mock.Mock())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            def test_function():
                pass

            logged_function = self.logged_function(test_function)
            logged_function()
            self.logger.debug.assert_called_once_with("test_function()")


# Generated at 2022-06-18 03:11:00.965577
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            test_function(1, 2, c=4)

# Generated at 2022-06-18 03:11:09.216459
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import logging
    import time
    import pytest
    from requests.exceptions import HTTPError

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def test_func(session, url):
        return session.get(url)

    # test raise_for_status=True
    session = build_requests_session(raise_for_status=True)
    with pytest.raises(HTTPError):
        test_func(session, "http://httpbin.org/status/404")

    # test retry=True
    session = build_requests_session(retry=True)

# Generated at 2022-06-18 03:11:17.600048
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:11:25.418739
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=1, d=2):
        return a + b + c + d

    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2)
    test_func(1, 2, d=4, c=3)



# Generated at 2022-06-18 03:11:30.305520
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function with no arguments
    @logged_function
    def test_function_no_args():
        return "test_function_no_args"

    # Call function
    test_function_no_args()

    # Check output
    assert stream.getvalue() == "test_function_no_args()\ntest_function_no_args -> test_function_no_args\n"

    # Reset stream
    stream.seek(0)
   

# Generated at 2022-06-18 03:12:24.940041
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest
    from unittest.mock import patch

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            handler = logging.StreamHandler(sys.stdout)
            logger.addHandler(handler)

            @LoggedFunction(logger)
            def test_function(a, b, c=1):
                return a + b + c

            with patch("sys.stdout", new=sys.stdout):
                test_function(1, 2, 3)
                test_function(1, 2)
                test_function(1, 2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:12:32.825311
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_func(1, 2)

    # Check the output
    stream.seek(0)
    output = stream.read()
    assert output == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"

# Generated at 2022-06-18 03:12:43.245980
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create test function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call test function
    result = test_function(1, 2)

    # Check output
    assert result == 10

# Generated at 2022-06-18 03:12:52.455218
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:13:02.233956
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    log_stream = StringIO()
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(log_stream))

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to decorate
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output
    assert log_stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:13:09.234387
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger()
            self.logger.setLevel(logging.DEBUG)
            self.log_stream = io.StringIO()
            self.log_handler = logging.StreamHandler(self.log_stream)
            self.logger.addHandler(self.log_handler)

        def tearDown(self):
            self.logger.removeHandler(self.log_handler)
            self.log_handler.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def add(a, b):
                return a + b

            add(1, 2)
           

# Generated at 2022-06-18 03:13:19.201392
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=True)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10
    session = build_requests_session(retry=False)
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.total == 0
    session = build_requests_session(retry=3)
    assert session.adapters["http://"].max_retries.total == 3
    assert session.adapters["https://"].max_retries.total == 3
    retry = Retry(total=5)
    session = build_requests_session(retry=retry)

# Generated at 2022-06-18 03:13:28.826403
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to be logged
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    with redirect_stdout(stream):
        test_function(1, 2, 3)

    # Check output

# Generated at 2022-06-18 03:13:39.125335
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_func = LoggedFunction(logger)

    # Create a function to be logged
    def func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    logged_func(func)(1, 2)

    # Check the output

# Generated at 2022-06-18 03:13:49.161841
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue