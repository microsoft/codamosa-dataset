

# Generated at 2022-06-18 03:04:03.556127
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def my_function(a, b, c=3):
        return a + b + c

    # Call the function
    my_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output == "my_function(1, 2, c=3)\nmy_function -> 6\n"

    #

# Generated at 2022-06-18 03:04:11.454704
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}

# Generated at 2022-06-18 03:04:18.214717
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2, c=3, d=4)
    test_func(1, 2, c=3, d=4, e=5)


# Generated at 2022-06-18 03:04:26.133020
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:04:30.995810
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:04:41.006615
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Create function to decorate
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output

# Generated at 2022-06-18 03:04:50.541539
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger for testing
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to test
    def test_function(a, b, c=None):
        return a + b + c

    # Test the function
    logged_test_function = logged_function(test_function)
    logged_test_function(1, 2, c=3)

    # Check the output

# Generated at 2022-06-18 03:04:59.872414
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters.keys() == {"http://", "https://"}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert session.adapters["http://"].max_retries.total == 3
    assert session.adapters["http://"].max_retries.connect == 3
    assert session.adapters["http://"].max_retries.read == 3
    assert session.adapters["http://"].max_retries.status == 3
    assert session.adapters["http://"].max_retries.status_forcelist == [500, 502, 503, 504]

# Generated at 2022-06-18 03:05:05.921523
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    logger = Mock(logging.Logger)
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None):
        pass

    logged_function(test_function)(1, 2)
    logger.debug.assert_called_with("test_function(1, 2)")

    logged_function(test_function)(1, 2, c=3)
    logger.debug.assert_called_with("test_function(1, 2, c=3)")

    logged_function(test_function)(1, 2, c=3)
    logger.debug.assert_called_with("test_function(1, 2, c=3)")

    logged_function(test_function)(1, 2, c=3)

# Generated at 2022-06-18 03:05:14.255284
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Define function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    test_function(1, 2)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:05:26.246907
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.total == 0

    session = build_requests_session(retry=5)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 5
    assert session.adapters["https://"].max_retries.total == 5

    session = build_requests_session

# Generated at 2022-06-18 03:05:33.789080
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import io

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Capture stdout
    stdout = sys.stdout
    sys.stdout = io.StringIO()

    # Call the function
    test_function(1, 2)

    # Restore stdout
    output = sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = stdout

    #

# Generated at 2022-06-18 03:05:42.015459
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, 2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:05:49.530238
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b=None):
        return a + b

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    result = logged_test_function(1, 2)

    # Check the result
    assert result == 3

    # Check the log

# Generated at 2022-06-18 03:05:59.542701
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test"

            self.assertEqual(test_function(), "test")


# Generated at 2022-06-18 03:06:09.380514
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    test_function(1, 2)
    test_function(1, 2, 3)
    test_function(1, 2, 3, 4)
    test_function(1, 2, d=4)
    test_function(1, 2, c=3, d=4)
    test_function(1, 2, d=4, c=3)
    test_function(a=1, b=2, c=3, d=4)

# Generated at 2022-06-18 03:06:19.703266
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:06:27.981645
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.captured_output = io.StringIO()
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.captured_output))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3, d=4):
                return a + b + c + d

            test_func(1, 2)

# Generated at 2022-06-18 03:06:37.708079
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:06:47.440015
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b=2, c=3):
        return a + b + c

    # Call the function
    test_function(1, c=4)

    # Check the log
    stream.seek(0)
    assert stream.read() == "test_function(1, 2, c=4)\ntest_function -> 6\n"

    # Clean up

# Generated at 2022-06-18 03:07:00.853742
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    class TestLogger:
        def __init__(self):
            self.log = StringIO()
            self.logger = logging.getLogger("TestLogger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.log))

        def get_log(self):
            return self.log.getvalue()

    def test_func(a, b, c="c", d="d"):
        return a + b + c + d

    test_logger = TestLogger()
    logged_func = LoggedFunction(test_logger.logger)(test_func)
    assert logged_func(1, 2, d="4") == "12c4"

# Generated at 2022-06-18 03:07:11.439284
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:07:18.825749
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    def f(x, y, z=3):
        return x + y + z

    # Decorate the function
    logged_f = logged_function(f)

    # Call the function
    logged_f(1, 2)

    # Check the output

# Generated at 2022-06-18 03:07:29.195789
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Capture stdout
    stdout = sys.stdout
    sys.stdout = io.StringIO()

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    assert sys.stdout.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Restore stdout

# Generated at 2022-06-18 03:07:33.352887
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, c=4)
    test_func(1, 2, c=4, d=5)



# Generated at 2022-06-18 03:07:43.383851
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    result = logged_test_function(1, 2, d=5)

    # Check the result
    assert result == 11

    #

# Generated at 2022-06-18 03:07:52.740906
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the log

# Generated at 2022-06-18 03:08:03.063352
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_func(self):
            logger = logging.getLogger("test_logged_func")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            @LoggedFunction(logger)
            def test_func(a, b, c=3, d=4):
                return a + b + c + d
            self.assertEqual(test_func(1, 2), 10)
            self.assertEqual(test_func(1, 2, d=5), 11)
            self.assertEqual(test_func(1, 2, c=6), 13)

# Generated at 2022-06-18 03:08:09.983122
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def func():
                pass

            func()

        def test_logged_function_with_args(self):
            @self.logged_function
            def func(a, b, c):
                pass

            func(1, 2, 3)


# Generated at 2022-06-18 03:08:20.888145
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, c=3)
    test_func(1, b=2, c=3)
    test_func(a=1, b=2, c=3)


# Generated at 2022-06-18 03:08:41.392697
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def test_logged_function(self):
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            @LoggedFunction(logger)
            def test_function(a, b, c=3):
                return a + b + c

            test_function(1, 2)
            test_function(1, 2, c=4)
            test_function(1, 2, c=4, d=5)


# Generated at 2022-06-18 03:08:50.707287
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    test_function(1, 2)
    test_function(1, 2, c=4)
    test_function(1, 2, c=4, d=5)


# Generated at 2022-06-18 03:08:59.438930
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def foo(a, b, c=3):
        return a + b + c

    foo(1, 2)
    assert stream.getvalue() == "foo(1, 2, c=3)\nfoo -> 6\n"

    stream.truncate(0)
    stream.seek(0)
    foo(1, 2, c=4)
   

# Generated at 2022-06-18 03:09:08.963501
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    with redirect_stdout(StringIO()):
        test_func(1, 2, 3)
        test_func(1, 2)
        test_func(1, 2, c=3)
        test_func(1, 2, c=3, d=4)


# Generated at 2022-06-18 03:09:16.441511
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger to capture output
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to wrap
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:09:26.497115
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock
    from unittest.mock import patch

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    with patch("logging.Logger.debug") as mock_debug:
        func = Mock()
        func.__name__ = "test_func"
        logged_func = LoggedFunction(logger)(func)
        logged_func(1, 2, 3, a=4, b=5, c=6)
        mock_debug.assert_called_with(
            "test_func(1, 2, 3, a=4, b=5, c=6)"
        )
        func.assert_called_with(1, 2, 3, a=4, b=5, c=6)

# Generated at 2022-06-18 03:09:30.053898
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)

            @LoggedFunction(logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, 2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:09:37.765816
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"
    stream.truncate(0)

# Generated at 2022-06-18 03:09:46.558485
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)

# Generated at 2022-06-18 03:09:53.208379
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to be logged
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:10:21.581983
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    from io import StringIO

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Capture stdout
    stdout = sys.stdout
    sys.stdout = StringIO()

    # Call the logged function
    result = logged_test_function(1, 2)

    # Restore stdout
    sys.stdout = stdout

# Generated at 2022-06-18 03:10:27.613782
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert isinstance(session, Session)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}



# Generated at 2022-06-18 03:10:35.022823
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    @LoggedFunction(logger)
    def test_func(a, b, c=1):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(a=1, b=2)
    test_func(a=1, b=2, c=3)

# Generated at 2022-06-18 03:10:44.253066
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    # Call the function
    test_func(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:10:53.484917
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:11:00.893446
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:11:09.160815
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}

# Generated at 2022-06-18 03:11:17.566472
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    logged_test_function(1, 2)

    # Check the log output

# Generated at 2022-06-18 03:11:27.174714
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger and a stream to capture output
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a function to wrap
    def test_function(a, b, c=3):
        return a + b + c

    # Wrap the function
    wrapped_function = LoggedFunction(logger)(test_function)

    # Call the function
    wrapped_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Call the function with keyword arguments

# Generated at 2022-06-18 03:11:36.019109
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def test_func(a, b, c=None):
        return a + b + (c or 0)

    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    logger.handlers = []
   

# Generated at 2022-06-18 03:12:32.269670
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2, 3)
        test_func(1, 2)
        test_func(1, 2, c=3)


# Generated at 2022-06-18 03:12:42.657413
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.log_stream = io.StringIO()
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.handler = logging.StreamHandler(self.log_stream)
            self.logger.addHandler(self.handler)
            self.logged_function = LoggedFunction(self.logger)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.log_stream.close()


# Generated at 2022-06-18 03:12:51.905373
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Set up a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    result = test_function(1, 2)

    # Check the result
    assert result == 6

    # Check the log output
    log_output = stream.getvalue()
    assert "test_function(1, 2, c=3)" in log_output

# Generated at 2022-06-18 03:13:02.062287
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    def test_func(a, b, c=3):
        return a + b + c

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    logged_func = LoggedFunction(logger)(test_func)
    logged_func(1, 2)
    logged_func(1, 2, c=4)
    with redirect_stdout(stream):
        logged_func(1, 2, c=4)
    assert stream.getvalue() == "test_func(1, 2)\ntest_func(1, 2, c=4)\n"

# Generated at 2022-06-18 03:13:09.143004
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Define a function to be decorated
    @logged_function
    def func(a, b, c=3):
        return a + b + c

    # Call the function
    func(1, 2)

    # Check the output
    stream.seek(0)


# Generated at 2022-06-18 03:13:19.126709
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None):
        pass

    logged_function(test_function)(1, 2)
    logger.debug.assert_has_calls(
        [call("test_function(1, 2)"), call("test_function -> None")]
    )

    logged_function(test_function)(1, 2, 3)
    logger.debug.assert_has_calls(
        [
            call("test_function(1, 2, 3)"),
            call("test_function -> None"),
            call("test_function(1, 2)"),
            call("test_function -> None"),
        ]
    )

    logged

# Generated at 2022-06-18 03:13:28.793689
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:13:39.097762
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}
    assert session.adapters != {}

    session = build_requ

# Generated at 2022-06-18 03:13:49.163830
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.total == 0

    session = build_requ