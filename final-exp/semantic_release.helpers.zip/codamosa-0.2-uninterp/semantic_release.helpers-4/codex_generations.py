

# Generated at 2022-06-18 03:03:59.900984
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = Mock(logging.Logger)
            logged_function = LoggedFunction(logger)
            func = Mock()
            func.__name__ = "func"
            logged_func = logged_function(func)
            logged_func(1, 2, 3, a=4, b=5, c=6)
            logger.debug.assert_called_once_with(
                "func(1, 2, 3, a=4, b=5, c=6)"
            )
            func.assert_called_once_with(1, 2, 3, a=4, b=5, c=6)
            logger.debug

# Generated at 2022-06-18 03:04:07.597502
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}
    session = build_requests_session(False, False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(False, True)
    assert session.hooks == {}
    assert session.adapters != {}
    session = build_requests_session(False, 5)
    assert session.hook

# Generated at 2022-06-18 03:04:15.660570
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

    stream.truncate(0)
    test_func(1, 2, c=4)

# Generated at 2022-06-18 03:04:23.827122
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def func(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_func = logged_function(func)

    # Call the function
    result = logged_func(1, 2)

    # Check the result
    assert result == 6

    # Check the log
    log = stream.getvalue()

# Generated at 2022-06-18 03:04:32.651943
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    class TestLogger:
        def __init__(self):
            self.log_output = io.StringIO()
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.log_output))

        def get_log(self):
            return self.log_output.getvalue()

    def test_func(a, b, c=None):
        return a + b

    test_logger = TestLogger()
    logged_func = LoggedFunction(test_logger.logger)(test_func)
    assert logged_func(1, 2) == 3

# Generated at 2022-06-18 03:04:42.991291
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=1):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:04:52.080178
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert isinstance(session, Session)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert session.adapters == {}



# Generated at 2022-06-18 03:05:01.608356
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test with a function with no arguments
    @logged_function
    def test_function_no_arguments():
        return "test_function_no_arguments"

    test_function_no_arguments()

# Generated at 2022-06-18 03:05:08.830211
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            self.assertEqual(test_function(1, 2), 6)
            self.assertEqual(test_function(1, 2, c=4), 7)

    unittest.main()

# Generated at 2022-06-18 03:05:17.735785
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger = logging.getLogger("test")
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)

# Generated at 2022-06-18 03:05:30.688393
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    with redirect_stdout(stream):
        assert test_function(1, 2) == 10
        assert test_function(1, 2, d=5) == 11
        assert test_function(1, 2, 3, 4) == 10
        assert test_function(1, 2, 3, 4, 5) == 15

# Generated at 2022-06-18 03:05:41.306485
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            @LoggedFunction(logger)
            def test_func(a, b, c=3):
                return a + b + c
            self.assertEqual(test_func(1, 2), 6)
            self.assertEqual(test_func(1, 2, 3), 6)
            self.assertEqual(test_func(1, 2, c=3), 6)
            self.assertEqual(test_func(1, 2, c=4), 7)

    unittest.main()

# Generated at 2022-06-18 03:05:48.719220
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:05:58.224869
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b=2):
        return a + b

    # Call the function
    test_function(1, b=3)

    # Check the output
    output = stream.getvalue()
    assert output == "test_function(1, b=3)\ntest_function -> 4\n"

# Generated at 2022-06-18 03:06:07.660182
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=1):
                return a + b + c

            result = test_function(1, 2, 3)
            self.assertEqual(result, 6)

    unittest.main()

# Generated at 2022-06-18 03:06:13.606682
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_function(a, b, c=1):
                return a + b + c

            test_function(1, 2, c=3)

    unittest.main()

# Generated at 2022-06-18 03:06:21.647739
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            def func():
                pass

            self.logged_function(func)()
            self.logger.debug.assert_called_with("func()")

        def test_logged_function_with_args(self):
            def func(a, b, c):
                pass

            self.logged_function(func)(1, 2, 3)

# Generated at 2022-06-18 03:06:28.815456
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, 3)
        test_func(1, 2, c=3)
        test_func(a=1, b=2, c=3)
        test_func(a=1, b=2)


# Generated at 2022-06-18 03:06:37.792715
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.log_stream = io.StringIO()
            self.log_handler = logging.StreamHandler(self.log_stream)
            self.log_handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.log_handler)

        def tearDown(self):
            self.logger.removeHandler(self.log_handler)
            self.log_handler.close()
            self.log_stream.close()


# Generated at 2022-06-18 03:06:47.434173
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

    stream.truncate(0)
    stream.seek(0)
    test_func(1, 2, c=4)

# Generated at 2022-06-18 03:06:57.495021
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:07:06.612628
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger and a stream to capture its output
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a function to wrap
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function and check the output
    test_function(1, 2)
    assert stream.getvalue() == "test_function(1, 2, c=3)\n"

    # Call the function with keyword arguments and check the output
    test_function(1, 2, c=4)
    assert stream.getvalue()

# Generated at 2022-06-18 03:07:15.316633
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.capture = io.StringIO()
            self.handler = logging.StreamHandler(self.capture)
            self.logger = logging.getLogger("test")
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

        def tearDown(self):
            self.logger.removeHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3, d=4):
                return a + b + c + d

            result = test_func(1, 2)

# Generated at 2022-06-18 03:07:20.501296
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    logger = Mock()
    logged_func = LoggedFunction(logger)(lambda x, y: x + y)
    logged_func(1, 2)
    logger.debug.assert_called_once_with("<lambda>(1, 2)")
    logger.debug.reset_mock()
    logged_func(1, y=2)
    logger.debug.assert_called_once_with("<lambda>(1, y=2)")
    logger.debug.reset_mock()
    logged_func(1, 2, 3)
    logger.debug.assert_called_once_with("<lambda>(1, 2, 3)")
    logger.debug.reset_mock()
    logged_func(1, 2, 3, 4)
    logger.debug.assert_called_once

# Generated at 2022-06-18 03:07:30.804697
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=1):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, 3)
        test_func(1, 2, c=3)
        test_func(1, 2, c=3, d=4)


# Generated at 2022-06-18 03:07:41.216882
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to be logged
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call function
    test_function(1, 2)

    # Check output

# Generated at 2022-06-18 03:07:51.341597
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define function
    def test_function(a, b, c=3):
        return a + b + c

    # Call LoggedFunction
    logged_function(test_function)(1, 2)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:07:56.561672
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to test
    def test_function(a, b, c=1, d=2):
        return a + b + c + d

    # Call the LoggedFunction
    logged_test_function = logged_function(test_function)
    assert logged_test_function(1, 2) == 6

# Generated at 2022-06-18 03:08:06.301701
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=None):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:08:15.564940
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, 3)
        test_func(1, 2, 3, 4)
        test_func(1, 2, d=4)
        test_func(1, 2, c=3, d=4)

    assert stream.getvalue()

# Generated at 2022-06-18 03:08:25.677893
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.NullHandler())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args_and_no_return(self):
            @self.logged_function
            def test_function():
                pass

            with unittest.mock.patch.object(self.logger, "debug") as mock_debug:
                test_function()
                mock_debug.assert_called_once_with("test_function()")

# Generated at 2022-06-18 03:08:34.138016
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)
    assert session.hooks["response"] == [lambda r, *args, **kwargs: r.raise_for_status()]
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False, retry=True)
    assert "response" not in session.hooks
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)


# Generated at 2022-06-18 03:08:44.242815
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class LoggedFunctionTestCase(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("LoggedFunctionTestCase")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def func(a, b, c=None):
                return a + b + c

            self.assertEqual(func(1, 2, 3), 6)
            self.assertEqual(func(1, 2), 3)
            self.assertEqual(func(1, 2, c=3), 6)

# Generated at 2022-06-18 03:08:49.497885
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_func = logged_function(test_func)

    # Call the function
    logged_test_func(1, 2)

    # Check the output
    stream.seek(0)
    output = stream

# Generated at 2022-06-18 03:08:58.570175
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function with no arguments
    @logged_function
    def test_function():
        return "test"

    with redirect_stdout(stream):
        assert test_function() == "test"
    assert stream.getvalue() == "test_function()\ntest_function -> test\n"

    # Test function with arguments

# Generated at 2022-06-18 03:09:08.826980
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:09:16.269132
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    f = StringIO()
    with redirect_stdout(f):
        test_func(1, 2)
        test_func(1, 2, 3, 4)
        test_func(1, 2, d=4)
        test_func(1, 2, c=3)
        test_

# Generated at 2022-06-18 03:09:26.246581
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=None, d=None):
        return a + b + c + d

    # Call the function
    test_function(1, 2, 3, 4)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:09:31.028782
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=Retry(total=5))

# Generated at 2022-06-18 03:09:38.730907
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock as mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = mock.MagicMock(spec=logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test_result"

            self.assertEqual(test_function(), "test_result")
            self.logger.debug.assert_called_once_with(
                "test_function() -> test_result"
            )


# Generated at 2022-06-18 03:10:00.203112
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:10:07.680336
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters
    session = build_requests_session(retry=3)

# Generated at 2022-06-18 03:10:17.511058
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def func(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_func = logged_function(func)

    # Call the function
    logged_func(1, 2)

    # Check the output
    assert stream.getvalue() == "func(1, 2, c=3)\nfunc -> 6\n"



# Generated at 2022-06-18 03:10:23.147939
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10


# Generated at 2022-06-18 03:10:33.613779
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    logger = TestLogger()
    logged_func = LoggedFunction(logger)(test_func)
    assert logged_func(1, 2) == 10
    assert logged_func(1, 2, d=5) == 11
    assert logged_func(1, 2, c=6, d=7) == 17
    assert logged_func(1, 2, c=6) == 14
    assert logged_func(1, 2, d=7) == 13

# Generated at 2022-06-18 03:10:42.644390
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:10:48.229931
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    logger = Mock(spec=logging.Logger)
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None):
        return a + b + (c or 0)

    logged_test_function = logged_function(test_function)
    assert logged_test_function(1, 2) == 3
    logger.debug.assert_called_once_with("test_function(1, 2)")
    logger.debug.reset_mock()
    assert logged_test_function(1, 2, 3) == 6
    logger.debug.assert_called_once_with("test_function(1, 2, c=3)")
    logger.debug.reset_mock()

# Generated at 2022-06-18 03:10:56.594306
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test"

            self.assertEqual(test_function(), "test")


# Generated at 2022-06-18 03:11:02.407329
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    log_stream = io.StringIO()
    handler = logging.StreamHandler(log_stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function to decorate
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    logged_test_function(1, 2)

    # Check the log output
    log_stream.seek(0)

# Generated at 2022-06-18 03:11:11.025247
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a handler to write to a string buffer
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:11:45.639424
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate function
    logged_test_function = logged_function(test_function)

    # Call function
    result = logged_test_function(1, 2)

    # Check result
    assert result == 6

    # Check logging
    stream.seek(0)
    assert stream

# Generated at 2022-06-18 03:11:53.158392
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    test_func(1, 2, 3)
    test_func(1, 2)
    test_func(1, 2, c=3)
    test_func(1, 2, c=3, d=4)
    test_func(1, 2, c=3, d=4, e=5)
    test_func(1, 2, c=3, d=4, e=5, f=6)

# Generated at 2022-06-18 03:12:03.540954
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert "test_function(1, 2, c=3)" in output

# Generated at 2022-06-18 03:12:11.596948
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    def func(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_func = logged_function(func)

    # Call the function
    logged_func(1, 2)

    # Check the output


# Generated at 2022-06-18 03:12:21.809076
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)



# Generated at 2022-06-18 03:12:26.011547
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    class TestLogger:
        def __init__(self):
            self.log_stream = StringIO()
            self.log_handler = logging.StreamHandler(self.log_stream)
            self.logger = logging.getLogger("test_logger")
            self.logger.addHandler(self.log_handler)
            self.logger.setLevel(logging.DEBUG)

        def get_log(self):
            return self.log_stream.getvalue()

    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_logger = TestLogger()
    logged_func = LoggedFunction(test_logger.logger)(test_func)

# Generated at 2022-06-18 03:12:34.748547
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=3)

# Generated at 2022-06-18 03:12:45.192078
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)
    assert session.hooks["response"][0] == (
        lambda r, *args, **kwargs: r.raise_for_status()
    )
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False, retry=False)
    assert "response" not in session.hooks
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(raise_for_status=True, retry=3)

# Generated at 2022-06-18 03:12:50.511799
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Define a function to be logged
    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    # Call the function
    test_func(1, 2)

    # Check the output
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"



# Generated at 2022-06-18 03:12:57.067617
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:13:51.312261
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=5)