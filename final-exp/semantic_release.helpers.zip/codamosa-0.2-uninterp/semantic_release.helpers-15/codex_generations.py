

# Generated at 2022-06-18 03:04:01.144591
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def add(x, y):
        return x + y

    # Call the function
    add(1, 2)

    # Check the output
    stream.seek(0)
    assert stream.read() == "add(1, 2)\nadd -> 3\n"



# Generated at 2022-06-18 03:04:08.567088
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest import TestCase
    from unittest import main

    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.logger = Mock()
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            def func():
                return "result"

            logged_func = self.logged_function(func)
            result = logged_func()
            self.assertEqual(result, "result")
            self.logger.debug.assert_called_once_with("func()")
            self.logger.debug.assert_any_call("func -> result")


# Generated at 2022-06-18 03:04:15.712350
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_function(a, b, c=1):
        return a + b + c

    test_function(1, 2)
    test_function(1, 2, 3)
    test_function(1, 2, c=3)
    test_function(1, b=2, c=3)
    test_function(a=1, b=2, c=3)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-18 03:04:23.794912
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

    stream.seek(0)
    stream.truncate(0)

    test_func(1, 2, c=4)
    assert stream.getvalue() == "test_func(1, 2, c=4)\ntest_func -> 7\n"



# Generated at 2022-06-18 03:04:32.652647
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the log
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:04:42.991667
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Create a handler to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function to decorate
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    decorated_function = logged_function(test_function)

    # Call the function
    result = decorated_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:04:52.080270
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    logger = Mock(spec=logging.Logger)
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None):
        pass

    logged_function(test_function)(1, 2)
    logger.debug.assert_called_once_with(
        "test_function(1, 2, c=None)"
    )

    logger.reset_mock()
    logged_function(test_function)(1, 2, 3)
    logger.debug.assert_called_once_with(
        "test_function(1, 2, c=3)"
    )

    logger.reset_mock()
    logged_function(test_function)(1, 2, c=3)
    logger.debug.assert_called_once

# Generated at 2022-06-18 03:05:01.608403
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, c=4)
    test_func(1, 2, c=4, d=5)


# Generated at 2022-06-18 03:05:08.490005
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class LoggedFunctionTest(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=None):
                return a + b + c

            result = test_func(1, 2, 3)
            self.assertEqual(result, 6)

    unittest.main()



# Generated at 2022-06-18 03:05:17.148456
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_func(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=3):
                return a + b + c

            self.assertEqual(test_func(1, 2), 6)
            self.assertEqual(test_func(1, 2, 3), 6)
            self.assertEqual(test_func(1, 2, c=3), 6)

   

# Generated at 2022-06-18 03:05:29.154022
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the LoggedFunction
    logged_test_function = logged_function(test_function)
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:05:35.049219
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger with a StringIO handler
    log_stream = StringIO()
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(log_stream))

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2, d=5)

    # Check the log output

# Generated at 2022-06-18 03:05:44.159007
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            self.assertEqual(test_function(1, 2), 6)
            self.assertEqual(test_function(1, 2, c=4), 7)

    unittest.main()

# Generated at 2022-06-18 03:05:51.132803
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test with a function that returns None
    @logged_function
    def test_function_1(a, b, c=3):
        pass

    test_function_1(1, 2)
    assert stream.getvalue() == "test_function_1(1, 2, c=3)\n"
    stream.truncate(0)
    test_function_1(1, 2, c=4)

# Generated at 2022-06-18 03:06:00.218206
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:06:09.224662
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_func(a, b, c=1):
                return a + b + c

            self.assertEqual(test_func(1, 2, 3), 6)

    unittest.main()

# Generated at 2022-06-18 03:06:19.536196
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:06:27.955033
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.handler = logging.StreamHandler(sys.stdout)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            self.assertEqual(test_function(1, 2), 6)

# Generated at 2022-06-18 03:06:37.707141
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test_result"

            with unittest.mock.patch("sys.stdout", new=unittest.mock.StringIO()) as mock_stdout:
                test_function()

# Generated at 2022-06-18 03:06:46.577738
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function(self):
            @self.logged_function
            def test_function(a, b, c=3):
                return a + b + c

            self.assertEqual(test_function(1, 2), 6)

    unittest.main()

# Generated at 2022-06-18 03:06:55.855234
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    log = logging.getLogger("test_LoggedFunction___call__")
    log.setLevel(logging.DEBUG)
    log.propagate = False
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    log.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(log)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output

# Generated at 2022-06-18 03:07:05.037983
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.total == 0

    session = build_requests_session(retry=5)
    assert session.adapters["http://"].max_retries.total == 5
    assert session.adapters["https://"].max_retries.total == 5

    retry = Retry(total=5, backoff_factor=0.1)

# Generated at 2022-06-18 03:07:14.077258
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create function to be logged
    @LoggedFunction(logger)
    def test_function(a, b=2, c="three"):
        return a + b + len(c)

    # Call function
    with redirect_stdout(stream):
        result = test_function(1, c="four")

    # Check result
    assert result == 8

    # Check logging output

# Generated at 2022-06-18 03:07:19.872336
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import contextmanager

    @LoggedFunction(logging.getLogger("test"))
    def foo(a, b=2, c=3):
        return a + b + c

    @contextmanager
    def capture_stdout():
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    with capture_stdout() as stdout:
        foo(1)
        assert stdout.getvalue().strip() == "foo(1, b=2, c=3) -> 6"

    with capture_stdout() as stdout:
        foo(1, c=4)
        assert stdout.getvalue().strip()

# Generated at 2022-06-18 03:07:30.390038
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function
    def func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the LoggedFunction instance with the function
    logged_func = logged_function(func)

    # Call the logged function
    logged_func(1, 2)

    # Check the output

# Generated at 2022-06-18 03:07:40.497659
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger to capture output
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Define a function to decorate
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:07:51.245085
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_func(self):
            # Create logger
            logger = logging.getLogger("test_logged_func")
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            # Create logged function
            @LoggedFunction(logger)
            def test_func(a, b, c=3):
                return a + b + c

            # Call logged function
            result = test_func(1, 2)
            self.assertEqual(result, 6)

            # Check logger output
            output = stream

# Generated at 2022-06-18 03:07:56.561198
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:08:06.302012
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.handler = logging.StreamHandler(sys.stdout)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)
            test_function(1, 2)
            test_function(1, 2, c=3)
            test

# Generated at 2022-06-18 03:08:15.565770
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(Mock())

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2, c=3)
    test_func(1, 2, c=3, d=4)
    test_func(1, 2, 3, d=4)


# Generated at 2022-06-18 03:08:27.808258
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, 3)

    # Check the output

# Generated at 2022-06-18 03:08:34.097126
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None, d=None):
        pass

    logged_function(test_function)(1, 2, d=4)
    logger.debug.assert_has_calls(
        [
            call("test_function(1, 2, d=4)"),
            call("test_function -> None"),
        ]
    )



# Generated at 2022-06-18 03:08:44.207201
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)
    output = stream

# Generated at 2022-06-18 03:08:50.272420
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, c=3)



# Generated at 2022-06-18 03:08:56.044452
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    class Logger:
        def __init__(self):
            self.log_stream = StringIO()
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.log_stream))

        def get_log(self):
            return self.log_stream.getvalue()

    def test_func(a, b, c=None):
        return a + b + c

    logger = Logger()
    logged_func = LoggedFunction(logger.logger)(test_func)
    logged_func(1, 2, 3)

# Generated at 2022-06-18 03:09:02.512872
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            # Setup
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            # Exercise
            @LoggedFunction(logger)
            def test_func(a, b, c=1):
                return a + b + c

            test_func(1, 2, 3)

            # Verify

# Generated at 2022-06-18 03:09:11.531743
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def my_function(a, b, c=None):
        return a + b + c

    # Call the function
    my_function(1, 2, 3)

    # Check the output
    assert stream.getvalue() == "test:DEBUG:my_function(1, 2, c=3)\n"



# Generated at 2022-06-18 03:09:18.443989
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            def test_function():
                pass

            self.logged_function(test_function)()
            self.logger.debug.assert_called_once_with("test_function()")

        def test_logged_function_with_positional_arguments(self):
            def test_function(a, b):
                pass

            self.logged_function(test_function)(1, 2)
            self.logger.debug

# Generated at 2022-06-18 03:09:28.444180
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    logged_function(test_function)(1, 2)

    # Check the output

# Generated at 2022-06-18 03:09:36.524805
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call

    # Arrange
    logger = Mock()
    logged_function = LoggedFunction(logger)
    func = Mock()
    args = (1, 2)
    kwargs = {"a": 3, "b": 4}
    expected_result = "result"
    func.return_value = expected_result

    # Act
    result = logged_function(func)(*args, **kwargs)

    # Assert
    assert result == expected_result
    func.assert_called_once_with(*args, **kwargs)

# Generated at 2022-06-18 03:09:49.052886
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Define a function to decorate
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:09:55.317205
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None):
        pass

    logged_function(test_function)(1, 2)
    logger.debug.assert_has_calls(
        [
            call("test_function(1, 2)"),
            call("test_function -> None"),
        ]
    )

    logged_function(test_function)(1, 2, 3)
    logger.debug.assert_has_calls(
        [
            call("test_function(1, 2, c=3)"),
            call("test_function -> None"),
        ]
    )

    logged_function(test_function)(1, 2, c=3)

# Generated at 2022-06-18 03:10:06.114582
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logged_function_with_no_arguments(self):
            @LoggedFunction(self.logger)
            def test_function():
                return "test"

            self.assertEqual(test_function(), "test")

        def test_logged_function_with_positional_arguments(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c):
                return "test"

           

# Generated at 2022-06-18 03:10:16.944265
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest
    from unittest.mock import patch

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_no_args(self):
            @self.logged_function
            def test_func():
                pass

            with patch("sys.stdout", new=io.StringIO()) as fake_out:
                test_func()
                self.assertEqual(fake_out.getvalue(), "test_func()\n")

# Generated at 2022-06-18 03:10:24.973513
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def test_function():
                return "test_result"

            self.assertEqual(test_function(), "test_result")


# Generated at 2022-06-18 03:10:35.839400
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import io
    from contextlib import redirect_stdout

    class LoggedFunctionTest(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            f = LoggedFunction(logger)

            @f
            def test_func(a, b, c=None):
                return a + b + c

            with io.StringIO() as buf, redirect_stdout(buf):
                test_func(1, 2, 3)
                self.assertEqual(buf.getvalue(), "test_func(1, 2, c=3)\n")
                test_func(1, 2)
                self.assertE

# Generated at 2022-06-18 03:10:44.489003
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:10:53.524332
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call logged function
    logged_test_function(1, 2)

    # Check output
    stream.seek(0)

# Generated at 2022-06-18 03:11:00.942565
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            def func():
                pass

            logged_func = self.logged_function(func)
            logged_func()
            self.logger.debug.assert_called_once_with("func()")

        def test_logged_function_with_arguments(self):
            def func(a, b, c):
                pass

            logged_func = self.logged_function(func)

# Generated at 2022-06-18 03:11:09.188565
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_LoggedFunction___call__")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            @self.logged_function
            def test_function():
                return "test"

            self.assertEqual(test_function(), "test")


# Generated at 2022-06-18 03:11:23.843147
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}

# Generated at 2022-06-18 03:11:32.164518
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:11:38.413406
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    func(1, 2)

    # Check the output

# Generated at 2022-06-18 03:11:47.457098
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=Retry(total=5))
    assert session.hooks == {}

# Generated at 2022-06-18 03:11:54.050114
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    test_function(1, 2, 3)
    test_function(1, 2)
    test_function(1, 2, c=3)
    test_function(1, 2, c=3, d=4)

# Generated at 2022-06-18 03:12:04.352462
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a decorator
    logged_function = LoggedFunction(logger)

    # Create a function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:12:12.181699
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    result = test_function(1, 2)

    # Check the result
    assert result == 6

    # Check the log

# Generated at 2022-06-18 03:12:22.224775
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function

# Generated at 2022-06-18 03:12:30.922689
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2

# Generated at 2022-06-18 03:12:40.968007
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.log_stream = io.StringIO()
            self.log_handler = logging.StreamHandler(self.log_stream)
            self.logger.addHandler(self.log_handler)

        def tearDown(self):
            self.logger.removeHandler(self.log_handler)
            self.log_handler.close()
            self.log_stream.close()


# Generated at 2022-06-18 03:12:51.145916
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:12:57.189102
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + (c or 0)

    test_func(1, 2, 3)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

    stream.truncate(0)
    stream.seek(0)
    test_func(1, 2)

# Generated at 2022-06-18 03:13:06.567303
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Decorate function
    @logged_function
    def test_function(arg1, arg2, kwarg1=None, kwarg2=None):
        return arg1 + arg2 + kwarg1 + kwarg2

    # Call function
    test_function(1, 2, kwarg1=3, kwarg2=4)

    # Check output
    stream.seek(0)

# Generated at 2022-06-18 03:13:16.466447
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert len(session.hooks["response"]) == 1
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries.total == 10

# Generated at 2022-06-18 03:13:23.349840
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    stream.seek(0)

# Generated at 2022-06-18 03:13:33.586579
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Define a function
    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_func(1, 2)

    # Check the output
    stream.seek(0)
    assert stream.read() == "test_func(1, 2, c=3, d=4)\ntest_func -> 10\n"



# Generated at 2022-06-18 03:13:41.166319
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:13:51.565704
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest.mock import patch

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the log output