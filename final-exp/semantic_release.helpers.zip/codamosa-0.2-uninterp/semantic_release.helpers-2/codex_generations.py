

# Generated at 2022-06-18 03:03:59.902034
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Create function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    with redirect_stdout(stream):
        result = test_function(1, 2, c=3)

    # Check result
    assert result == 6

    # Check log output
    log_output = stream

# Generated at 2022-06-18 03:04:05.920899
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    stream.seek(0)
    output = stream.read()

# Generated at 2022-06-18 03:04:13.910489
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger which writes to a string
    output = StringIO()
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(output))

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    result = test_function(1, 2)

    # Check the output
    assert output.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Check the result
    assert result == 6

# Generated at 2022-06-18 03:04:22.903773
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    test_function(1, 2)
    test_function(1, 2, c=4)
    test_function(a=1, b=2)
    test_function(a=1, b=2, c=4)
    test_function(1, b=2)
    test_function(1, b=2, c=4)


# Generated at 2022-06-18 03:04:29.150957
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    stream.seek(0)
    output = stream.read()

# Generated at 2022-06-18 03:04:36.339389
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:04:46.434577
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to decorate
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:04:54.958395
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=True)
    assert session.hooks == {}
    assert session.adapters != {}

    session = build_requ

# Generated at 2022-06-18 03:05:04.116090
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler(sys.stdout))

            @LoggedFunction(logger)
            def test_func(a, b, c=3, d=4):
                return a + b + c + d

            test_func(1, 2)
            test_func(1, 2, 3)
            test_func(1, 2, 3, 4)
            test_func(1, 2, d=4)
            test_func(1, 2, c=3, d=4)

    unittest.main()

# Generated at 2022-06-18 03:05:09.338251
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=1, d=2):
        return a + b + c + d

    # Call the LoggedFunction
    logged_test_function = logged_function(test_function)
    result = logged_test_function(1, 2, 3, 4)

    # Check the result
    assert result == 10

    # Check the log

# Generated at 2022-06-18 03:05:24.397808
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Capture output
    output = io.StringIO()
    handler = logging.StreamHandler(output)
    logger = logging.getLogger("test")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call function
    result = test_function(1, 2)

    # Check output
    output.seek(0)
    assert output.read() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Check result
    assert result == 6

# Generated at 2022-06-18 03:05:32.370497
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=Retry(total=5))

# Generated at 2022-06-18 03:05:37.586997
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            handler = logging.StreamHandler(sys.stdout)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            @LoggedFunction(logger)
            def test_func(a, b, c=1):
                return a + b + c

            test_func(1, 2)
            test_func(1, 2, 3)

    unittest.main()

# Generated at 2022-06-18 03:05:44.948995
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be logged
    def test_function(a, b, c=3):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function
    logged_test_function(1, 2)

    # Check the output
    stream.seek(0)
    output = stream.read()
   

# Generated at 2022-06-18 03:05:51.611685
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:06:00.682716
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Define a function to be logged
    @logged_function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the log
    stream.seek(0)

# Generated at 2022-06-18 03:06:04.775846
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a logged function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the logged function
    test_function(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:06:11.129621
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a test function
    @logged_function
    def test_function(a, b, c=1, d=2):
        return a + b + c + d

    # Call the test function
    test_function(1, 2, d=3)

    # Check the output

# Generated at 2022-06-18 03:06:20.625179
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.handler = logging.StreamHandler(sys.stdout)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=3):
                return a + b + c

            test_function(1, 2)
            test_function(1, 2, c=4)

    unittest.main()

# Generated at 2022-06-18 03:06:28.380163
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to decorate
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    with redirect_stdout(stream):
        result = test_function(1, 2)

    # Check the output

# Generated at 2022-06-18 03:06:48.188669
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def func(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    result = logged_function(func)(1, 2)

    # Check the result
    assert result == 10

    # Check the log

# Generated at 2022-06-18 03:06:55.226577
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-18 03:07:01.042209
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)

# Generated at 2022-06-18 03:07:11.613128
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_arguments(self):
            @self.logged_function
            def test_function():
                return "test"

            self.assertEqual(test_function(), "test")


# Generated at 2022-06-18 03:07:18.216089
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function


# Generated at 2022-06-18 03:07:28.392899
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            def func():
                pass

            self.logged_function(func)()
            self.logger.debug.assert_called_with("func()")

        def test_logged_function_with_args(self):
            def func(a, b, c):
                pass

            self.logged_function(func)(1, 2, 3)

# Generated at 2022-06-18 03:07:34.442179
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test_logger")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args_and_no_return_value(self):
            @self.logged_function
            def func():
                pass

            func()

        def test_logged_function_with_args_and_no_return_value(self):
            @self.logged_function
            def func(a, b, c):
                pass


# Generated at 2022-06-18 03:07:44.290426
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"



# Generated at 2022-06-18 03:07:48.703092
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=None, d=None):
        return a + b + c + d

    logged_function(test_function)(1, 2, 3, 4)
    logger.debug.assert_has_calls(
        [
            call(
                "test_function(1, 2, 3, 4)"
            ),
            call(
                "test_function -> 10"
            ),
        ]
    )



# Generated at 2022-06-18 03:07:55.106693
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a handler to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function to test
    @LoggedFunction(logger)
    def test_function(a, b, c=None):
        return a + b

    # Call the function
    test_function(1, 2)
    test_function(1, 2, c=3)

    # Check the output

# Generated at 2022-06-18 03:08:16.749516
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Decorate function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check log output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"

   

# Generated at 2022-06-18 03:08:25.725725
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Decorate function
    @logged_function
    def test_function(a, b, c=None):
        return a + b + c

    # Call function
    test_function(1, 2, 3)

    # Check output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\n"

    # Call function
    test_function

# Generated at 2022-06-18 03:08:33.560450
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b, c=None):
        return a + b + c

    # Call the function
    test_function(1, 2, c=3)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:08:43.067005
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function
    @LoggedFunction(logger)
    def test_function(a, b, c=3):
        return a + b + c

    # Call the function
    test_function(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"

# Generated at 2022-06-18 03:08:52.005953
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.log_stream = StringIO()
            self.log_handler = logging.StreamHandler(self.log_stream)
            self.logger.addHandler(self.log_handler)

        def tearDown(self):
            self.logger.removeHandler(self.log_handler)
            self.log_stream.close()

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_func(a, b, c=None):
                return a + b + c

           

# Generated at 2022-06-18 03:09:00.408415
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the LoggedFunction
    logged_function(test_function)(1, 2)

    # Check the output
    output = stream.getvalue()
    assert output == "test_function(1, 2, c=3)\ntest_function -> 6\n"


# Unit

# Generated at 2022-06-18 03:09:09.416140
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2)
        test_func(1, 2, c=4)
        test_func(1, 2, 3)
        test_func(1, 2, 3, 4)


# Generated at 2022-06-18 03:09:16.795305
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=3)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)

# Generated at 2022-06-18 03:09:27.020997
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the LoggedFunction
    logged_test_function = logged_function(test_function)
    result = logged_test_function(1, 2)

    # Check the result
    assert result == 10

    # Check the log


# Generated at 2022-06-18 03:09:31.758872
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_no_args(self):
            @self.logged_function
            def test_func():
                return "test_result"

            self.assertEqual(test_func(), "test_result")

        def test_args(self):
            @self.logged_function
            def test_func(arg1, arg2):
                return "test_result"


# Generated at 2022-06-18 03:10:06.332487
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function
    def test_function(a, b, c=3):
        return a + b + c

    # Create a logged function
    logged_test_function = logged_function(test_function)

    # Call the logged function

# Generated at 2022-06-18 03:10:17.240950
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test_logged_function")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            @LoggedFunction(logger)
            def test_function(a, b, c=3, d=4):
                return a + b + c + d

            test_function(1, 2)
            test_function(1, 2, 3)
            test_function(1, 2, 3, 4)
            test_function(1, 2, d=4)
            test_function(1, 2, c=3, d=4)

# Generated at 2022-06-18 03:10:25.197256
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))
            self.logged_function = LoggedFunction(self.logger)

        def test_log_function_name_and_arguments(self):
            @self.logged_function
            def test_function(arg1, arg2, kwarg1=1, kwarg2=2):
                pass

            test_function(1, 2, kwarg1=3, kwarg2=4)


# Generated at 2022-06-18 03:10:34.533023
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    class TestLogger(logging.Logger):
        def __init__(self, name):
            super().__init__(name)
            self.output = StringIO()

        def debug(self, msg, *args, **kwargs):
            print(msg, file=self.output)

    logger = TestLogger("test")
    logged_func = LoggedFunction(logger)(lambda x, y: x + y)
    logged_func(1, 2)
    assert logger.output.getvalue() == "test_LoggedFunction___call__(1, 2)\ntest_LoggedFunction___call__ -> 3\n"

# Generated at 2022-06-18 03:10:41.777917
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import MagicMock

    logger = MagicMock(logging.Logger)
    logged_function = LoggedFunction(logger)
    def test_function(a, b, c=3, d=4):
        return a + b + c + d
    logged_test_function = logged_function(test_function)
    assert logged_test_function(1, 2) == 10
    logger.debug.assert_called_with("test_function(1, 2, c=3, d=4)")
    logger.debug.assert_called_with("test_function -> 10")

# Generated at 2022-06-18 03:10:47.874852
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function_with_no_arguments(self):
            logger = logging.getLogger("test_logger")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.NullHandler())

            @LoggedFunction(logger)
            def test_function():
                return "test_result"

            with unittest.mock.patch("logging.Logger.debug") as mock_debug:
                result = test_function()

# Generated at 2022-06-18 03:10:54.626524
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    test_func(1, 2, c=3)
    assert stream.getvalue() == "test_func(1, 2, c=3)\ntest_func -> 6\n"

# Generated at 2022-06-18 03:11:02.698114
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + c

    with redirect_stdout(stream):
        test_func(1, 2, 3)
        test_func(1, 2)
        test_func(1, 2, c=3)
        test_func(1, 2, c=None)

# Generated at 2022-06-18 03:11:09.625725
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    def func(a, b, c=None):
        pass

    logged_func = logged_function(func)
    logged_func(1, 2)
    logged_func(1, 2, 3)
    logged_func(1, 2, c=3)

    logger.debug.assert_has_calls(
        [
            call("func(1, 2)"),
            call("func(1, 2, 3)"),
            call("func(1, 2, c=3)"),
        ]
    )

# Generated at 2022-06-18 03:11:17.941107
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, 3, 4)
    test_func(1, 2, d=4)
    test_func(1, 2, c=3, d=4)
    test_func(1, 2, d=4, c=3)
    test_func(a=1, b=2, c=3, d=4)
    test_func

# Generated at 2022-06-18 03:12:22.307056
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())

            def test_func(a, b, c=1, d=2):
                return a + b + c + d

            logged_func = LoggedFunction(logger)(test_func)
            self.assertEqual(logged_func(1, 2, 3, 4), 10)
            self.assertEqual(logged_func(1, 2, d=4), 9)
            self.assertEqual(logged_func(1, 2), 6)

    unittest.main

# Generated at 2022-06-18 03:12:31.008470
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create decorator
    logged_function = LoggedFunction(logger)

    # Test function
    @logged_function
    def test_function(a, b, c=3):
        return a + b + c

    # Test function call
    with redirect_stdout(stream):
        result = test_function(1, 2)
    assert result == 6

# Generated at 2022-06-18 03:12:41.049460
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger and set its level to DEBUG
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    # Create a stream handler and set its level to DEBUG
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)

    # Create a formatter and add it to the stream handler
    formatter = logging.Formatter("%(message)s")
    stream_handler.setFormatter(formatter)

    # Add the stream handler to the logger
    logger.addHandler(stream_handler)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a function

# Generated at 2022-06-18 03:12:50.156910
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a test function
    def test_function(a, b, c=3):
        return a + b + c

    # Call the test function
    logged_function(test_function)(1, 2)

    # Check the output
    assert stream.getvalue() == "test_function(1, 2, c=3)\ntest_function -> 6\n"

    # Clean up
    logger.remove

# Generated at 2022-06-18 03:12:56.818673
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock(logging.Logger)
            self.logged_function = LoggedFunction(self.logger)

        def test_logged_function_with_no_args(self):
            def func():
                return "result"

            logged_func = self.logged_function(func)
            result = logged_func()

            self.logger.debug.assert_any_call("func()")
            self.logger.debug.assert_any_call("func -> result")
            self.assertEqual(result, "result")


# Generated at 2022-06-18 03:13:06.344441
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Define a function
    def test_function(a, b, c=3):
        return a + b + c

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:13:15.955865
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.log_stream = StringIO()
            self.logger = logging.getLogger("test")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(self.log_stream))

        def test_logged_function(self):
            @LoggedFunction(self.logger)
            def test_function(a, b, c=None):
                return a + b + c

            test_function(1, 2, 3)

# Generated at 2022-06-18 03:13:23.121485
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    class LoggedFunctionTest(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            logger.addHandler(handler)
            @LoggedFunction(logger)
            def test_function(a, b, c=3):
                return a + b + c
            test_function(1, 2)
            self.assertEqual(stream.getvalue().strip(), "test_function(1, 2, c=3)")
            stream.truncate(0)

# Generated at 2022-06-18 03:13:33.551779
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create a function to be decorated
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Decorate the function
    logged_test_function = logged_function(test_function)

    # Call the decorated function
    logged_test_function(1, 2)

    # Check the output
    output = stream.getvalue()

# Generated at 2022-06-18 03:13:41.149226
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Create a logger
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    # Create a stream to capture output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a function to wrap
    @LoggedFunction(logger)
    def test_function(a, b, c=3, d=4):
        return a + b + c + d

    # Call the function
    test_function(1, 2)

    # Check the output
    stream.seek(0)
    output = stream.read()