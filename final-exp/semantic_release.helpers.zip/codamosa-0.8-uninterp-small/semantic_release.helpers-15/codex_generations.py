

# Generated at 2022-06-26 01:15:26.393952
# Unit test for function build_requests_session
def test_build_requests_session():
    # Given
    retry = True

    # When
    obj = build_requests_session(retry)

    # Then
    assert isinstance(obj, Session)

# Generated at 2022-06-26 01:15:28.817552
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('test_LoggedFunction')
    logger.setLevel(logging.DEBUG)
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 01:15:30.901617
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 01:15:33.988565
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    lf = LoggedFunction(logger=logging.basicConfig(level=logging.DEBUG))
    lf(test_case_0)

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:15:34.870422
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()



# Generated at 2022-06-26 01:15:44.352658
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from types import FunctionType
    from unittest.mock import MagicMock
    from logging import Logger
    from functools import wraps
    from unittest.mock import call

    # Initialize mock objects templates
    function = FunctionType(code=None, globals={}, name="function", argdefs=(), closure=None)
    logger = Logger("logger")
    args = ("1", "2")
    kwargs = {"k1":"v1", "k2":"v2"}

    # Configure mock objects
    function_1 = function
    function_1.__name__ = "function"
    logger_1 = logger
    logger_1.debug.return_value = None
    function_2 = function
    function_2.__name__ = "function"
    kwargs_1 = kwargs

# Generated at 2022-06-26 01:15:47.737096
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s %(name)-12s %(levelname)-8s %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    test_LoggedFunction___call___obj = LoggedFunction(logger)
    test_LoggedFunction___call___obj(test_case_0)

# Generated at 2022-06-26 01:15:53.485050
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    bool_0 = 0
    bool_1 = 0
    bool_2 = 1
    bool_3 = 1
    bool_4 = 0

    def func_0(*args):
        bool_3 = bool_2
        if bool_0:
            bool_3 = bool_1
        return bool_3

    var_0 = LoggedFunction(None)
    func_1 = var_0(func_0)
    var_1 = func_1(bool_4, bool_1, bool_3)
    assert var_1 == bool_2


test_LoggedFunction___call__()

# Generated at 2022-06-26 01:15:56.389409
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    assert __call__(LoggedFunction(), test_case_0) == var_0
    assert 0


# Generated at 2022-06-26 01:16:07.492720
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == requests.Session
    assert type(build_requests_session(retry=False)) == requests.Session
    assert type(build_requests_session(retry=Retry(total=0))) == requests.Session
    assert type(build_requests_session(retry=True)) == requests.Session
    assert type(build_requests_session(retry=0)) == requests.Session
    assert type(build_requests_session(retry=1)) == requests.Session
    assert type(build_requests_session(retry=2)) == requests.Session
    assert type(build_requests_session(retry=3)) == requests.Session


# Generated at 2022-06-26 01:16:16.379805
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    logged_function_0 = LoggedFunction()
    # Act
    actual_result = logged_function_0(test_case_0)
    # Assert
    expected_result = functools.partial(test_case_0)
    assert actual_result == expected_result



# Generated at 2022-06-26 01:16:29.674087
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from ...data_structure.linked_list import LinkedList
    from ...data_structure.binary_tree import BinaryTree
    from ...algorithm.graph.simple_graph import SimpleGraph

    # Test of function
    def test():
        @logged_function_0.__call__
        def foo(a, b, c, *args, **kwargs):
            return a, b, c, args, kwargs

        return foo

    # Generate a logger
    import logging

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    # Generate a handler which redirect log to stdout
    import sys

    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setLevel(logging.DEBUG)

# Generated at 2022-06-26 01:16:36.284699
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # ********* Begin ********* #
    # Declare variables with actual values
    logger = None

    # Call method to be tested
    actual_result = LoggedFunction.__call__(logger)

    # Declare expected result
    expected_result = logged_function_0

    # Compare expected result with actual result
    assert actual_result == expected_result
    # ********* End ********* #

# Generated at 2022-06-26 01:16:49.794309
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    class Test_LoggedFunction(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            def logged_func(*args, **kwargs):
                # Call function
                import logging
                result = logging.debug(
                    "{function}({args}{kwargs})".format(
                        function="logged_func",
                        args=", ".join([format_arg(x) for x in args]),
                        kwargs="".join(
                            [f", {k}={format_arg(v)}" for k, v in kwargs.items()]
                        ),
                    )
                )
                # Log result
                if result is not None:
                    result = logging.debug(f"{result} -> {result}")
                return result
            import unittest.mock


# Generated at 2022-06-26 01:16:50.388831
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-26 01:17:00.331205
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert len(session.adapters) == 2
    adapter = session.adapters["http://"]
    assert adapter.max_retries.total == Retry().total
    session = build_requests_session(raise_for_status=True)
    assert len(session.hooks["response"]) == 1
    assert session.hooks["response"][0].__name__ == "raise_for_status"
    session = build_requests_session(retry=False)
    assert len(session.adapters) == 0
    with pytest.raises(ValueError):
        build_requests_session(retry=3.4)
    session = build_requests_session(retry=Retry(10))
    assert session.adapters

# Generated at 2022-06-26 01:17:10.910565
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Prepare dummies
    func0 = ...  # type: ignore
    args0 = ...  # type: ignore
    kwargs0 = ...  # type: ignore
    result0 = ...  # type: ignore

    # Prepare stream for debug output
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger = logging.getLogger("testLogger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Init LoggedFunction
    logged_function0 = LoggedFunction(logger)

    # Call __call__
    func1 = logged_function0.__call__(func0)

    # Get debug output
    string = stream.getvalue()
    string

    # Call logged_func with arguments
    result1 = func1

# Generated at 2022-06-26 01:17:12.930947
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:17:14.090920
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


# Generated at 2022-06-26 01:17:17.589431
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = None
    logged_function = LoggedFunction(logger)
    func = None
    # test
    try:
        logged_function(func)
        assert False
    except TypeError:
        assert True
    pass



# Generated at 2022-06-26 01:17:23.035265
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    s = Session()
    def func(*args, **kwargs):
        pass
    
    f = LoggedFunction(s)
    f = f(func)

# Generated at 2022-06-26 01:17:27.368902
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test_LoggedFunction___call__")
    def test_func(a, b):
        return a + b
    logged_func = LoggedFunction(logger)(test_func)
    assert logged_func(1, 2) == 3


# Generated at 2022-06-26 01:17:41.559895
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger
    import logging
    import unittest.mock as mock
    
    logger_0 = Logger("abcdef")
    with mock.patch("logging.Logger.debug") as mock_debug:
        logged_function_1 = LoggedFunction(logger_0)
        def some_func_0(*args, **kwargs):
            return "abcd"
        logged_func_0 = logged_function_1(some_func_0)
        logged_func_0("abcd", "efgh", "ijkl", mnop="ijkl", qrst="uvwx")

# Generated at 2022-06-26 01:17:52.053660
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from .api import AmortizationSchedule
    from .api import Loan
    from .api import LoanPayment
    from .api import LoanTerm

    import logging
    import math
    import numbers
    import random
    import requests
    import unittest

    try:
        import mock
    except ImportError:
        print('Could not load "mock" module')

    class LoggedFunction_UnitTest(unittest.TestCase):
        """Unit tests for LoggedFunction class."""
        @classmethod
        def setUpClass(cls):

            class MockRequest(object):
                pass
            MockRequest.raise_for_status = mock.MagicMock()

            class MockResponse(object):
                def __init__(self, ret):
                    self.ret = ret
                def json(self):
                    return self.ret


# Generated at 2022-06-26 01:17:53.313420
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()).__name__ == "Session"

# Generated at 2022-06-26 01:17:54.289587
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()

# Generated at 2022-06-26 01:18:01.852962
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session()
    assert build_requests_session(retry=False)
    assert build_requests_session(retry=Retry())
    assert build_requests_session(retry=5)
    assert build_requests_session(raise_for_status=False)
    assert build_requests_session(raise_for_status=False, retry=False)
    assert build_requests_session(raise_for_status=False, retry=Retry())
    assert build_requests_session(raise_for_status=False, retry=5)



# Generated at 2022-06-26 01:18:10.110692
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test case for method __call__ of class LoggedFunction.
    """
    logger = logging.getLogger()
    logger.disabled = True
    handler = logging.FileHandler(filename="log.txt")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Instantiating an object
    logged_function = LoggedFunction(logger)
    assert type(logged_function) == LoggedFunction
    # Calling object
    logger.disabled = False
    test_call(logged_function)
    logger.disabled = True


# Generated at 2022-06-26 01:18:15.171349
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import requests
    from mlchain.base import logger

    logger.setLevel('DEBUG')
    logged_session = LoggedFunction(logger)(build_requests_session)
    test_url = f'http://localhost:5000/ping'
    resp = logged_session(test_url)
    assert resp.content == b'pong'
    assert resp.status_code == 200


# Generated at 2022-06-26 01:18:16.320377
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()



# Generated at 2022-06-26 01:18:29.648547
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class test_logger:
        def __init__(self):
            self.logged_msgs = []

        def debug(self, msg):
            self.logged_msgs.append(msg)

    logger = test_logger()
    logged_func = LoggedFunction(logger)(test_case_0)
    logged_func()
    assert logger.logged_msgs == [
        "test_case_0()",
        "test_case_0() -> None",
    ]

# Generated at 2022-06-26 01:18:30.900567
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


# Generated at 2022-06-26 01:18:34.353164
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func():
        pass

    @LoggedFunction(logger=logging.getLogger())
    def f():
        pass

    assert func() is None
    assert f() is None

# Generated at 2022-06-26 01:18:41.930227
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # The input arguments are logged before the function is called, and the
    # return value is logged once it has completed.

    # Decorator which adds debug logging to a function.

    # logger to send output to.
    logger = type('', (), {})()

    # create LoggedFunction instance with logger as parameter
    logged_function = LoggedFunction(logger)

    # input test_func with two parameters
    def test_func(one, two):
        # The input arguments are logged before the function is called
        assert one == 1
        assert two == 2
        # return value is logged once it has completed.
        return 'hello'

    # create logged_func
    logged_func = logged_function(test_func)

    # call logged_func
    result = logged_func(1, 2)

    # assert the result

# Generated at 2022-06-26 01:18:55.180843
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def _call_0():
        func_0 = (lambda : 1)
        func_0()
        func_0()
    def _call_1():
        func_1 = (lambda arg_0: arg_0)
        func_1(1)
        func_1(1)
    def _call_2():
        func_2 = (lambda arg_0=1: arg_0)
        func_2()
        func_2()
    def _call_3():
        func_3 = (lambda arg_0, arg_1: arg_0 + arg_1)
        func_3(1, 2)
        func_3(1, 2)
    def _call_4():
        func_4 = (lambda arg_0, arg_1=1: arg_0 + arg_1)
        func_4

# Generated at 2022-06-26 01:19:05.880101
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    import logging
    function_0 = build_requests_session
    function_1 = build_requests_session

    with patch(
        "sys.stdout", new=StringIO()
    ) as fake_out, patch(
        "requests.Session.__init___org",
        new_callable=create_autospec(function_0),
    ) as mock_requestsSession___init__, patch(
        "requests.Session.close",
        new_callable=create_autospec(function_1),
    ) as mock_requestsSession_close, patch(
        "logging.getLogger", new=create_autospec(logging.getLogger)
    ) as mock_logging_getLogger:
        from logging import DEBUG
        from logging import Logger

# Generated at 2022-06-26 01:19:06.694185
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()

# Generated at 2022-06-26 01:19:16.723676
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    r = session_0.get("https://www.google.com")
    assert r.status_code == 200

    session_1 = build_requests_session(raise_for_status=True, retry=1)
    r = session_1.get("https://www.google.com")
    assert r.status_code == 200

    session_2 = build_requests_session(raise_for_status=True, retry=True)
    r = session_2.get("https://www.google.com")
    assert r.status_code == 200

    session_3 = build_requests_session(raise_for_status=True, retry=False)
    r = session_3.get("https://www.google.com")
    assert r.status_

# Generated at 2022-06-26 01:19:27.476036
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pswd_manager.models.google import get_google_auth
    from pswd_manager.api.google_sheets import get_google_sheet_data
    from pswd_manager.secret.google_sheets import google_sheets_creds
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)

    logging.basicConfig()

    logger.debug("test_LoggedFunction___call__ started")

    auth = get_google_auth(**google_sheets_creds)

    get_google_sheet_data = LoggedFunction(logger)(get_google_sheet_data)


# Generated at 2022-06-26 01:19:35.167949
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    @LoggedFunction(logger)
    def test_function(argument_0, argument_1):
        pass
    test_function("argument_0", "argument_1")


if __name__ == "__main__":
    logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    logging.getLogger("").setLevel(logging.DEBUG)
    # test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:19:50.505093
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    :type session: requests.sessions.Session
    :type headers: dict
    """

    # Initialized object
    session = build_requests_session()
    headers = {"headers": "header"}
    logged_function = LoggedFunction(logging.getLogger())

    # Call method
    result = logged_function(login)(session, headers)

    # Test result
    assert (result == ())


if __name__ == "__main__":

    logging.basicConfig(level=0)

    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:19:58.954258
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from logging import DEBUG
    from logging import INFO

    class LoggedFunctionTester:
        def __init__(self):
            self.logger = getLogger('LoggedFunctionTester')
            self.logger.setLevel(DEBUG)

        @LoggedFunction(logger=getLogger('LoggedFunctionTester'))
        def method_0(self, arg1):
            print(f'arg1: {arg1}')
            return 0

        @LoggedFunction(logger=getLogger('LoggedFunctionTester'))
        def method_1(self, arg1, arg2):
            print(f'arg1: {arg1}\narg2: {arg1}')
            return 0


# Generated at 2022-06-26 01:20:09.103707
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import tempfile
    import logging
    from contextlib import contextmanager

    @contextmanager
    def setup_logger(name, level=logging.DEBUG):
        logger = logging.getLogger(name)
        logger.setLevel(level)
        handler = logging.FileHandler(f'{tempfile.gettempdir()}/test_logger.log')
        handler.setLevel(level)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

        try:
            yield logger
        finally:
            handlers = logger.handlers[:]
            for handler in handlers:
                handler.close()
                logger.removeHandler(handler)


# Generated at 2022-06-26 01:20:14.580601
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    f = lambda x: x * 2
    lf = LoggedFunction(logging.getLogger("test"))
    f_logged = lf(f)
    assert f_logged(4) == 8
    assert f_logged.__name__ == "f"


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
    logger = logging.getLogger(__name__)

    # test_LoggedFunction___call__()

# Generated at 2022-06-26 01:20:20.782548
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def logged_func():
        return
    # Test case 0
    test_logger = logging.getLogger("test_logger")
    logged_func = LoggedFunction(logger = test_logger)(logged_func)
    assert logged_func() == None


# Generated at 2022-06-26 01:20:31.213576
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    def func(a, b, c, d, e=0, f=0):
        return a + b * c + d * e * f
    
    logger = logging.getLogger()
    log_func = LoggedFunction(logger)(func)

    result_1 = log_func(1, 2, 3, 4)
    result_2 = log_func(10, 20, 30, 40)
    result_3 = log_func(100, 200, 300, 400, f=1)
    result_4 = log_func(1000, 2000, 3000, 4000, e=1)
    result_5 = log_func(10000, 20000, 30000, 40000, e=1, f=1)

# Generated at 2022-06-26 01:20:37.883838
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    lf = LoggedFunction(logging.getLogger(__name__))

    @lf
    def func(*args, **kwargs):
        return {"args": args, "kwargs": kwargs}

    ret = func(1, 2, a=3, b=4)
    print(ret)



# Generated at 2022-06-26 01:20:41.126630
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    f = lambda x, y: x + y
    f = LoggedFunction("test_logger")(f)
    assert f(1, 2) == 3



# Generated at 2022-06-26 01:20:44.356190
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    obj = LoggedFunction(logger)
    func = obj.__call__(func)
    assert func(arg1, arg2, kwarg1=const1, kwarg2=const2) == None


# Generated at 2022-06-26 01:20:53.048655
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=logging.getLogger(__name__))
    def func():
        pass

    func()
    test_case_0()


if __name__ == "__main__":
    pytest.main([__file__, "-s"])

# Generated at 2022-06-26 01:21:11.862126
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    print("Test test_LoggedFunction___call__()")
    print("#1")
    import logging

    log = logging.Logger("test_LoggedFunction___call__")
    hdlr = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    hdlr.setFormatter(formatter)
    log.addHandler(hdlr)
    log.setLevel(logging.DEBUG)

    def logged_func_0(*args, **kwargs):
        print(1)

    logged_func_0 = LoggedFunction(log)(logged_func_0)
    logged_func_0()
    print()


# Generated at 2022-06-26 01:21:20.278927
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from .test import captured_output
    from .test import LoggerStub
    from .test import assert_string_equal
    import logging
    import types

    logger = LoggerStub()
    decorator = LoggedFunction(logger=logger)
    assert_string_equal(name=logger.name, string="stub", message="")

    @decorator
    def test_function0(x):
        return x

    x = 3
    with captured_output() as (out, err):
        result = test_function0(x=x)
    assert_string_equal(
        name=result, string=f"{x}", message="The result of test_function0(3) should be 3"
    )
    # Unit test for method format_arg

# Generated at 2022-06-26 01:21:24.526846
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.Logger(name='logger-test')
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    logged_function = LoggedFunction(logger)
    test_case_0()
    logger.removeHandler(logger.handlers[0])

# Unit tests for method build_requests_session

# Generated at 2022-06-26 01:21:29.559674
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(print)
    def test_func(x, y=1):
        return x + y

    assert "test_func" == test_func.__name__
    test_func(1, y=2)
    test_func(x=3, y=4)
    test_func(x=5)
    test_func(6)

# Generated at 2022-06-26 01:21:39.192993
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=None)
    def test_0(arg_0, arg_1, arg_2, arg_3=None, arg_4=None, arg_5=None, arg_6=None):
        pass

    def test_1(arg_0, arg_1, arg_2, arg_3=None, arg_4=None, arg_5=None, arg_6=None):
        pass

    test_1 = LoggedFunction(logger=None)(test_1)
    test_0(arg_0=0, arg_1=1, arg_2=2, arg_3=3)
    test_1(arg_0=0, arg_1=1, arg_2=2, arg_3=3)

# Generated at 2022-06-26 01:21:44.201308
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger

    logger_0 = getLogger(__name__, "method __call__ of class LoggedFunction")

    @LoggedFunction(logger_0)
    def method_0(arg_0):
        return arg_0

    method_0("str_0")

if __name__ == "__main__":
    test_case_0()

    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:21:54.758093
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from inspect import Signature, Parameter
    from samtranslator.public.sdk.resource import PSEUDOPARAMETERS

    @LoggedFunction(logger=None)
    def method_1(arg1, arg2: int, arg3: str = "test_value"):
        pass

    expected_signature = Signature(
        [
            Parameter("arg1", Parameter.POSITIONAL_OR_KEYWORD),
            Parameter("arg2", Parameter.POSITIONAL_OR_KEYWORD, annotation=int),
            Parameter("arg3", Parameter.POSITIONAL_OR_KEYWORD, default="test_value"),
        ]
    )
    assert method_1.__signature__ == expected_signature, "Invalid signature"

# Generated at 2022-06-26 01:22:04.702838
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_cases = [
        ({"logger": None}, {}),
        ({"logger": None}, {"func": None})
    ]
    for kwargs, args in test_cases:
        try:
            obj = LoggedFunction(**kwargs)
            obj.__call__(*args)
            print(f"{obj.__class__.__name__}.__call__({args}, {kwargs}) called successfully.")
        except Exception as e:
            print(f"{obj.__class__.__name__}.__call__({args}, {kwargs}) raised exception: {type(e).__name__}: {e}")



# Generated at 2022-06-26 01:22:12.794217
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from unittest.mock import Mock

    def function_1(arg1: str, arg2: int):
        print(f"Calling function_1({arg1}, {arg2})")

    def function_2(arg1: str, arg2: int):
        return "test"

    logger = getLogger("test")
    logger.debug = Mock()
    decorator = LoggedFunction(logger)
    wrapped_1 = decorator(function_1)
    wrapped_2 = decorator(function_2)

    wrapped_1("x", 2)
    wrapped_2("x", 3)

# Generated at 2022-06-26 01:22:15.566580
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    def foo():
        return 1
    logged_foo = LoggedFunction(logger)(foo)
    result = logged_foo()
    assert result == 1
    assert hasattr(logged_foo, '__name__') == True

# Generated at 2022-06-26 01:22:48.791826
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    logger_file_handler = logging.FileHandler("test_LoggedFunction___call__.log")
    logger_file_handler.setLevel(logging.INFO)

    logger_console_handler = logging.StreamHandler()
    logger_console_handler.setLevel(logging.DEBUG)

    logger.addHandler(logger_file_handler)
    logger.addHandler(logger_console_handler)
    logged_function = LoggedFunction(logger)

    @logged_function
    def foo(x, y=3):
        return x + y

    foo(1, 2)
    foo(1, y=2)
    foo(x=1, y=2)



# Generated at 2022-06-26 01:22:51.566572
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from unittest.mock import Mock

    @LoggedFunction(getLogger("test"))
    def test_func(*args, **kwargs):
        return Mock()

    test_func("a", "b c d")
    test_func("a", kwargs="c")


# Generated at 2022-06-26 01:22:57.239675
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = my.logging.Logger()
    decorator = my.logging.LoggedFunction(logger)
    def test_func_0(*args):
        return args[0]
    wrapped_func = decorator(test_func_0)
    result = wrapped_func(10)
    logger.close()
    assert len(logger.logged_lines) == 2
    assert logger.logged_lines[0].endswith('test_func_0(10)')
    assert logger.logged_lines[1].endswith('test_func_0 -> 10')


# Generated at 2022-06-26 01:23:06.091092
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("a")
    session_0 = build_requests_session(retry=False)
    session_0.hooks = None
    LoggedFunction_instance_0 = LoggedFunction(logger)
    http_adapters_HTTPAdapter_instance_0 = HTTPAdapter()
    http_adapters_HTTPAdapter_instance_0.max_retries = Retry(5)
    session_0.mount('http://', http_adapters_HTTPAdapter_instance_0)
    session_0.mount('https://', http_adapters_HTTPAdapter_instance_0)
    LoggedFunction_instance_0(session_0.get)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:23:11.375300
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Testing when self.logger of class LoggedFunction is not None
    logger = logging.getLogger("unit-test")
    logger.disabled = True
    log_test = LoggedFunction(logger)
    func = functools.partial(test_case_0, "parameter_1")
    logged_func = log_test.__call__(func)
    logged_func()


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:23:20.625581
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class GenerateString:
        def __init__(self, logger):
            self.logger = logger

        @LoggedFunction(logger)
        def generate_string(self, required_string, decision, choice):
            self.logger.debug("in generate_string method")
            return_string = "this is not the string I want... so I am discarding it"
            if decision and choice:
                return_string = "this is the string I want"
                self.logger.debug(f"in generate_string method - {return_string}")
            return return_string

    string_generator = GenerateString(logger)
    # Case 1
    # test if all required parameters are passed and decision is True

# Generated at 2022-06-26 01:23:23.938335
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from app.logging import logger
    logged_function = LoggedFunction(logger)
    def foo(a,b):
        print(a+b)
        print(a-b)
    logged_foo = logged_function(foo)
    logged_foo(3,4)
    pass

# Generated at 2022-06-26 01:23:32.938489
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test 1
    session = build_requests_session()
    assert session.hooks == None
    assert type(session.adapters.get("http://")) == Retry
    assert len(session.adapters.get("http://").max_retries.retry_method_whitelist) == 32
    # Test 2
    session = build_requests_session(False, 2)
    assert session.hooks == None
    assert type(session.adapters.get("http://")) == Retry
    assert session.adapters.get("http://").total == 2
    # Test 3
    session = build_requests_session(False, Retry(2, max_jitter=5))
    assert session.hooks == None
    assert type(session.adapters.get("http://")) == Retry
    assert session.ad

# Generated at 2022-06-26 01:23:34.645022
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:23:37.000572
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger)
    def func():
        return 1
    # Everything should worked
    assert func() == 1
    # Make sure the unit test run correctly
    assert True == True



# Generated at 2022-06-26 01:24:01.598862
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from loguru import logger
    obj = LoggedFunction(logger)
    obj(test_case_0)

# Generated at 2022-06-26 01:24:07.651770
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger, CRITICAL

    # Test without logger
    no_logger_function = LoggedFunction(None)
    result = no_logger_function.__call__(test_case_0)()
    assert result is None

    # Test with logger
    logger = Logger(__name__, level=CRITICAL)
    logged_function = LoggedFunction(logger)
    logged_function.__call__(test_case_0)()


if __name__ == "__main__":
    import pytest

    pytest.main(["-v", __file__])

# Generated at 2022-06-26 01:24:14.640884
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import logging.handlers
    import unittest

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.handlers.SysLogHandler(address='/dev/log')
    logger.addHandler(handler)
    
    class LoggedFunctionDecoratorTestCase(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            @LoggedFunction(logger)
            def test_0(a, b=0, c=None):
                return a + b

            test_0(1, b=3, d=5)
            self.assertEqual(len(logger.handlers), 1)
            self.assertEqual(logger.handlers[0].level, logging.DEBUG)

# Generated at 2022-06-26 01:24:18.136665
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # input
    logger_0 = logging.getLogger()
    test_case_0.func_globals['logged_func'] = LoggedFunction(logger_0)(test_case_0)

    # expect
    exp_ret = None

    # execution
    ret = test_case_0()

    # assert
    assert exp_ret == ret

# Generated at 2022-06-26 01:24:20.961152
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def logged_func(args):
        return args

    test_0 = LoggedFunction("")(logged_func)
    test_0("")
    test_0("a")
    test_0("ab")

# Generated at 2022-06-26 01:24:26.328544
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session(raise_for_status=False)
    session_1 = build_requests_session(retry=False)
    session_2 = build_requests_session()
    session_3 = build_requests_session(retry=Retry(total=10, method_whitelist=['GET']))

if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-26 01:24:28.889087
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = Logger()
    logged_function_0 = LoggedFunction(logger_0)
    actual_returned_value_0 = logged_function_0.__call__(None)

# Generated at 2022-06-26 01:24:36.777318
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Constructing mocks
    mock_logger = Mock()
    mock_func = Mock()
    mock_func.__name__ = "mock_func"

    # Calling the target
    result = LoggedFunction(mock_logger)(mock_func)(1, "two", var=3)

    # Asserting expected calls
    mock_func.assert_called_once_with(1, "two", var=3)
    mock_logger.debug.assert_any_call("mock_func(1, 'two', var=3)")
    mock_logger.debug.assert_any_call("mock_func -> None")
    assert result is None

# Generated at 2022-06-26 01:24:38.784234
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


if __name__ == "__main__":
    # Unit test for method __call__ of class LoggedFunction
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:24:51.949031
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import tempfile
    import logging
    import time
    from contextlib import contextmanager

    @contextmanager
    def redirected(filename):
        with tempfile.TemporaryFile(mode="w+") as stderr:
            old_stderr = sys.stderr
            sys.stderr = stderr
            try:
                yield stderr
            finally:
                sys.stderr = old_stderr

    @LoggedFunction(logger=logging.getLogger("logger"))
    def func_0(*args, **kwargs):
        print("Hello world")

    @LoggedFunction(logger=logging.getLogger("logger"))
    def func_1(arg_0, arg_1=2):
        print("Hello world")
