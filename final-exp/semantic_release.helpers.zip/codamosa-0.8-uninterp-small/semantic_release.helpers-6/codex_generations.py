

# Generated at 2022-06-26 01:15:36.584069
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        build_requests_session("Wrong type for parameter raise_for_status: expected 'bool' but received 'str'")
        assert False # Wrong type for parameter raise_for_status: expected 'bool' but received 'str'
    except ValueError as e:
        assert e.args[0] == "Wrong type for parameter raise_for_status: expected 'bool' but received 'str'"


# Generated at 2022-06-26 01:15:37.722352
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    LoggedFunction.__call__(test_case_0)


# Generated at 2022-06-26 01:15:46.161066
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    bytes_0 = b'd\xba\xda\x84c \x0c\x0b\xaf\x90\xdaT\xa8\xaa\xcaF\xdc'
    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    int_0 = int()
    test_LoggedFunction___call___0 = LoggedFunction(str_0)
    def logged_func(*args, **kwargs):
        str_2 = str()
        str_3 = str()
        str_4 = str()
        str_2 = 'test-test'
        str_3 = tuple(args)

# Generated at 2022-06-26 01:15:54.010239
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    bytes_0 = b'\xd1\xfe\x90\x8b\xab\xfc\xc7\xbb\x8b\xe4\xda\xe7\xcd\xef\xdc\xbd'
    LoggedFunction_0 = LoggedFunction(bytes_0)
    str_0 = 'e\x8b\xab\xfc\xc7\xbb\x8b\xe4\xda\xe7\xcd\xef\xdc\xbd;\xea\xdc\xb8'

# Generated at 2022-06-26 01:15:58.517175
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    bytes_0 = b'oVl\xd9\xeb\x9b~;6\xea\xdc\xb8N28\x16\x80'
    logged_function_0 = LoggedFunction(bytes_0)


# Generated at 2022-06-26 01:16:10.244198
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    bytes_0 = b'mZ\xc7J\x9d\x9c\xd3\xca\xcc\xac\xaa\xc5\xd4,\x1d\x8b\xef\xfaU1\xef\xfaU1+\xef\xfaU1\xef\xfaU1\xef\xfaU1\xef\xfaU1\xef\xfaU1\xef\xfaU1'

# Generated at 2022-06-26 01:16:14.814623
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    bytes_0 = b'oVl\xd9\xeb\x9b~;6\xea\xdc\xb8N28\x16\x80'
    logged_function_0 = LoggedFunction(bytes_0)


# Generated at 2022-06-26 01:16:19.317577
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        assert not callable(build_requests_session()), "requests.Session is not callable"
    except:
        print("[-] build_requests_session raises an exception")



# Generated at 2022-06-26 01:16:21.629980
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create instance of class LoggedFunction
    logged_function = LoggedFunction()
    assert logged_function


# Generated at 2022-06-26 01:16:27.670668
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    print("Testing method __call__ of class LoggedFunction")

    bytes_0 = b'\x0b\x8b\xc7\xda\x17\x15\xe4\x14\xb4\xfd5\xc1\x9e\xab'
    logged_function_0 = LoggedFunction(bytes_0)

    test_case_0()


# Generated at 2022-06-26 01:16:43.932935
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Mock()
    func = Mock()
    args = [1, 2, 3]
    kwargs = {'a': 'foo', 'b': 'bar'}
    result = 5
    func.__name__ = 'test'
    func.return_value = result

    decorated_func = LoggedFunction(logger)(func)
    decorated_func(*args, **kwargs)

    logger.debug.assert_called_once_with(
        "test(1, 2, 3, a='foo', b='bar')"
    )
    calls = [call(args, kwargs)]
    func.assert_has_calls(calls)
    logger.debug.assert_called_once_with('test -> 5')


# Generated at 2022-06-26 01:16:54.879801
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    logging.basicConfig(format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s')

    lf = LoggedFunction(logger)

    @lf
    def test_func_0(bytes_0):
        return bytes_0


# Generated at 2022-06-26 01:16:58.052376
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('test')
    func = LoggedFunction(logger)
    def func_0():
        return 'a'
    assert func(func_0)() == 'a'


# Generated at 2022-06-26 01:17:00.419012
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    log = logger.Log()
    fun = LoggedFunction(logger=log)
    if fun is not None:
        fun.__call__( bytes_0 )

# Generated at 2022-06-26 01:17:08.300950
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
#    bytes_0 = b'mZ\xc7J\x9d\x9c\xd3\xca\xcc\xac\xaa\xc5\xd4,\x1d\x8b\xef\xfaU1\xef\xfaU1+\xef\xfaU1\xef\xfaU1\xef\xfaU1\xef\xfaU1\xef\xfaU1\xef\xfaU1'
    # TODO: Implement unit test.
    pass



# Generated at 2022-06-26 01:17:18.592495
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    method_test_cases = [[["test_log_function_test_case_0"], [{}]]]

# Generated at 2022-06-26 01:17:27.650392
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from neomodel import config
    from neotime import DateTime
    from neotime import Duration

    # NOTE: The following import is required for unit tests!
    from neo.Core.TX.Transaction import Transaction, TransactionOutput

    config.DATABASE_URL = 'bolt://neo4:neo4j@127.0.0.1:7687'

    from datetime import datetime
    from datetime import timezone

    from neomodel import StringProperty, StructuredNode, UniqueIdProperty, config, EmailProperty, \
        IntegerProperty, FloatProperty, DateTimeProperty, BooleanProperty, RelationshipTo, RelationshipFrom, \
        Relationship
    import pytz
    from neomodel import db
    import neotime
    import neotime


# Generated at 2022-06-26 01:17:34.848939
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    logger = None
    obj = LoggedFunction(logger)
    func = test_case_0
    # Act
    result = obj.__call__(func)
    # Assert
    assert result.__doc__ == func.__doc__

# Generated at 2022-06-26 01:17:44.828701
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Import the class to be tested
    from tqapi.utils import LoggedFunction

    # Instantiate an object of the class to be tested
    logger = None
    logged_function_obj = LoggedFunction(logger=logger)

    @logged_function_obj
    def test_func_0(param_0):
        """
        Description: This is a test function
        
        :param param_0: This is the first param
        
        :return: This is the return value
        """
        return locals()

    # Invoke method __call__ of class LoggedFunction with appropriate parameters
    assert test_func_0(param_0=1) == {'param_0': 1}


# Generated at 2022-06-26 01:17:54.426161
# Unit test for function build_requests_session
def test_build_requests_session():

    # Check that default arguments are used for Session object
    output = build_requests_session()

# Generated at 2022-06-26 01:18:01.556189
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        build_requests_session(True, True)
        build_requests_session(True, False)
        build_requests_session(True, 12)
        build_requests_session(True, Retry())
    except:
        return False
    return True


# Generated at 2022-06-26 01:18:12.592030
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test on instance method of class
    # Test case 0
    bool_0 = True
    logger_0 = logging.Logger(None)
    # LoggedFunction
    logged_function_0 = LoggedFunction(logger_0)
    assert logged_function_0 is not None
    # method LoggedFunction.__call__
    self_0 = logged_function_0
    func_0 = None
    args_0 = ()
    kwargs_0 = {
        "session": None,
    }
    # str
    format_arg_0 = format_arg(4)
    assert format_arg_0 is not None
    assert format_arg_0 == "4"
    # str
    format_arg_1 = format_arg("")
    assert format_arg_1 is not None

# Generated at 2022-06-26 01:18:19.805605
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func_0 = test_case_0
    bool_1 = True
    session_0 = build_requests_session(bool_1)
    bool_1 = True
    session_0 = build_requests_session(bool_1)
    bool_2 = True
    session_0 = build_requests_session(bool_2)
    bool_1 = True
    session_0 = build_requests_session(bool_1)
    bool_2 = True
    session_0 = build_requests_session(bool_2)
    bool_1 = True
    session_0 = build_requests_session(bool_1)
    bool_1 = True
    session_0 = build_requests_session(bool_1)
    bool_2 = True

# Generated at 2022-06-26 01:18:21.401514
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    bool_0 = True
    build_requests_session(bool_0)

# Generated at 2022-06-26 01:18:23.770257
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test with default parameters
    test_case_0()

    # Test with non boolean type parameter
    try:
        build_requests_session(3)
    except:
        pass

# Generated at 2022-06-26 01:18:38.511289
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def function_0(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7, arg_8, arg_9):
        assert arg_0 == 1
        assert arg_1 == 's'
        assert arg_2 == True
        assert arg_3 == 's'
        assert arg_4 == 's'
        assert arg_5 == 's'
        assert arg_6 == 's'
        assert arg_7 == 's'
        assert arg_8 == 's'
        assert arg_9 == 's'
        return function_0.__name__
    function_0.__name__ = "function_0"
    logger_0 = logging.getLogger("my_logger_0")
    handler_0 = logging.StreamHandler()
   

# Generated at 2022-06-26 01:18:42.624178
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
  logger_0 = logging.getLogger()
  loggedfunction_0 = LoggedFunction(logger_0)
  loggedfunction_0.__call__(test_case_0)

# Generated at 2022-06-26 01:18:44.333028
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()
# TEST test_LoggedFunction___call__
# END TEST


# Generated at 2022-06-26 01:18:45.232665
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = None
    test_case_0()

# Generated at 2022-06-26 01:18:46.905054
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    lf = LoggedFunction()
    lf.__call__()

# Generated at 2022-06-26 01:19:05.057456
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger('test_LoggedFunction___call__')
    logger_0.level = logging.DEBUG
    ch_0 = logging.StreamHandler()
    logFormatter_0 = logging.Formatter('%(asctime)s %(name)s %(levelname)s %(message)s')
    ch_0.setFormatter(logFormatter_0)
    logger_0.addHandler(ch_0)
    logged_function_0 = LoggedFunction(logger_0)
    def logged_function_0_function(x_0):
        total_0 = 0
        for value_0 in x_0:
            total_0 += value_0
        return total_0
    logged_function_0_function = logged_function_0(logged_function_0_function)
   

# Generated at 2022-06-26 01:19:11.060033
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger(__name__)
    logged_function_0 = LoggedFunction(logger_0)
    assert logged_function_0.logger == logger_0
    def func_0():
        return 0
    logged_func_0 = logged_function_0(func_0)
    assert logged_func_0() == 0
    def func_1(arg_0, arg_1):
        return arg_0 + arg_1
    logged_func_1 = logged_function_0(func_1)
    assert logged_func_1(1, 2) == 3

# Generated at 2022-06-26 01:19:14.308214
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    boolean_0 = True
    logger_0 = Logger("logger_0",)
    logged_function_0 = LoggedFunction(logger_0)
    test_case_0()

# Generated at 2022-06-26 01:19:21.876821
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    local_0 = type('str_0',(),{})
    local_0.__str__ = lambda self: 'LoggedFunction.__call__'
    local_1 = type('str_1',(),{})
    local_1.__str__ = lambda self: 'LoggedFunction has no attribute named __call__'
    LoggedFunction.__call__ = lambda self: local_0()
    bool_0 = bool()
    bool_0 = True
    try:
        LoggedFunction(bool_0)
    except Exception:
        pass
    else:
        raise Exception(local_1())


# Generated at 2022-06-26 01:19:31.575498
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import functools
    from typing import Callable, Tuple

    logger_0 = logging.getLogger("asdf")
    logger_0.setLevel(1)
    logger_0.addHandler(logging.StreamHandler(sys.stdout))

    def functools_wraps(func_0: Callable[..., Tuple[None]]) -> Callable[..., Tuple[None]]:
        return func_0

    class class_0:
        pass

    class_0.__call__ = lambda *args_0: None
    class_0.__name__ = str()
    class_0.__qualname__ = str()

    def function_0(*args_0: float, **kwargs_0: float) -> str:
        return str()

    functools_

# Generated at 2022-06-26 01:19:35.026079
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func_0 = build_requests_session
    logger_0 = logging.getLogger("")
    f_0 = LoggedFunction(logger_0)
    f_1 = f_0(func_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 01:19:41.010644
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction___call__(unittest.TestCase):
        def setUp(self):
            self.logger_0 = logging.getLogger()

        def test_0(self):
            lf_0 = LoggedFunction(self.logger_0)

            def func_0(*args, **kwargs):
                pass

            lf_0(func_0)

# Generated at 2022-06-26 01:19:43.923541
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:19:47.501918
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger()
    loggedfunction_0 = LoggedFunction(logger_0)
    def function_1():
        return 0
    logged_func_0 = loggedfunction_0(function_1)
    assert logged_func_0() == 0


# Generated at 2022-06-26 01:19:51.436051
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger()
    loggedFunction_0 = LoggedFunction(logger_0)
    session_0 = build_requests_session(True)
    loggedFunction_0(session_0)


# Generated at 2022-06-26 01:20:11.090942
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger('test_logger_0')
    logger_0.setLevel(logging.DEBUG)
    test_logged_function_0 = LoggedFunction(logger_0)

# Generated at 2022-06-26 01:20:27.313907
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setting up test
    logger_0 = Mock()
    logged_function_0 = LoggedFunction(logger_0)
    func_0 = Mock()
    args_0 = (Mock(), Mock())
    kwargs_0 = {'arg_1': Mock()}
    response_0 = Mock()
    # Setting up mock
    func_0.__name__ = 'function_0'
    response_0.__str__.return_value = 'str_0'

    # Testing
    @logged_function_0
    def function_0(*args, **kwargs):
        return response_0
    function_0(*args_0, **kwargs_0)

    # Asserting mock calls

# Generated at 2022-06-26 01:20:32.151364
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Init the class instance
    logger_0 = logging.getLogger("sudo")
    logged_function_0 = LoggedFunction(logger_0)

    # Test params
    func_0 = test_case_0
    args_0 = []
    kwargs_0 = {}

    # Test body
    logged_func_0 = logged_function_0.__call__(func_0)

    # Test the method
    logged_func_0(*args_0, **kwargs_0)

# Generated at 2022-06-26 01:20:38.920447
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    try:
        test_case_0()
    except Exception as e:
        msg = "This method __call__ of class LoggedFunction raised an exception: "
        msg += str(e)
        assert True == False, msg
    else:
        assert True == True

# run all test cases

# Generated at 2022-06-26 01:20:45.431734
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    string_0 = "function"
    string_1 = "args"
    string_2 = "kwargs"
    string_3 = "function()(args, kwargs)"
    string_4 = "function -> result"
    def func():
        return
    logger_0 = logging.getLogger()
    loggedfunction_0 = LoggedFunction(logger_0)
    func_0 = loggedfunction_0.__call__(func)
    func_0()

# Generated at 2022-06-26 01:20:51.376308
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()


if __name__ == "__main__":
    import sys

    test_case_0()

# Generated at 2022-06-26 01:21:05.093941
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry
    from requests.exceptions import RequestException
    from requests.packages.urllib3.connectionpool import HTTPConnectionPool
    from requests.packages.urllib3.connectionpool import HTTPSConnectionPool
    from requests.exceptions import ConnectionError
    from requests.exceptions import TooManyRedirects
    from requests.exceptions import Timeout
    from requests.exceptions import RetryError
    from requests import Session
    import logging
    import requests
    logger_0 = logging.getLogger("test_LoggedFunction.__call__")
    logger_0.critical("Critical message")
    logger_0.error("Error message")
    logger_0.warning("Warning message")
    logger_0.info("Info message")


# Generated at 2022-06-26 01:21:11.017598
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=None)
    def method_0():
        pass
    method_1 = LoggedFunction(logger=None).__call__(method_0)
    method_2 = LoggedFunction(logger=None).__call__(method_1)

# Generated at 2022-06-26 01:21:14.897316
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger()
    loggedFunction_0 = LoggedFunction(logger_0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 01:21:17.724748
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func_0 = test_case_0
    l_func_0 = LoggedFunction(logging.getLogger('logger'))
    assert func_0 == l_func_0.__call__(func_0)



# Generated at 2022-06-26 01:21:44.240715
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger("abc")
    function_0 = LoggedFunction(logger_0)
    function_1 = test_case_0
    function_2 = function_0(function_1)
    # AssertionError
    try:
        assert function_2
    except AssertionError as e:
        print("AssertionError")
    if __name__ == '__main__':
        print(function_1.__name__)
        function_2()

# Generated at 2022-06-26 01:21:45.137061
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:21:48.768170
# Unit test for function build_requests_session
def test_build_requests_session():
    assert (
        test_case_0() == Session()
    ), "Failed to create a request session when raise_for_status is set to True"
    return "Passed"


if __name__ == "__main__":
    print(test_build_requests_session())

# Generated at 2022-06-26 01:21:55.699990
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from abc import ABC, abstractmethod
    from typing import List, Optional, Set

    class MockLogger:
        def debug(self, msg):
            pass

    def function_0(*args, **kwargs):
        pass

    logger_0 = MockLogger()
    logged_func_0 = LoggedFunction(logger_0)
    logged_func_1 = logged_func_0(function_0)
    logged_func_1()


# Generated at 2022-06-26 01:21:57.633161
# Unit test for function build_requests_session
def test_build_requests_session():
    # Check with positive test case 0
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-26 01:22:09.315672
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger("logger_0")
    logged_function_0 = LoggedFunction(logger_0)
    class_0 = type(
        "class_0", 
        (object,), 
        {
            "func_0": logged_function_0(lambda : None), 
            "func_1": logged_function_0(lambda i: i)
        }
    )
    def func_0():
        class_0.func_0()
        class_0.func_1(0)
    func_0()
    def func_1(i):
        return i + 1
    print("[TEST] method __call__ of class LoggedFunction : " + str(logged_function_0(func_1)(0)))


# Generated at 2022-06-26 01:22:17.300548
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.Logger
    logged_function_0 = LoggedFunction(logger_0)
    func_0 = build_requests_session
    logged_func_0 = logged_function_0(func_0)
    logger_0.debug.assert_called()
    logged_func_0()
    func_0.assert_called()
    logger_0.debug.assert_called()
    logger_0.debug.assert_called()


# Generated at 2022-06-26 01:22:19.526107
# Unit test for function build_requests_session
def test_build_requests_session():
    result = build_requests_session(True)
    assert(result != None)


# Generated at 2022-06-26 01:22:23.278153
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Assert decodeing json input into dict
    json_dict = {'a': 'b', 'b': 100, 'c': "s"}
    assert str(build_requests_session(json_dict)) == '<requests.sessions.Session object at 0x7fbc881b8518>'

# Generated at 2022-06-26 01:22:26.690706
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger()
    logged_function_0 = LoggedFunction(logger_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 01:23:12.570260
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.Logger("logger_0", logging.DEBUG)
    loggedfunction_0 = LoggedFunction(logger_0)
    func_0 = lambda : 0
    logged_func_0 = loggedfunction_0(func_0)


# Generated at 2022-06-26 01:23:13.527679
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    assert True # TODO: implement your test here

# Generated at 2022-06-26 01:23:17.851400
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import requests

    a_session = build_requests_session()
    a_url = "https://httpbin.org/anything"
    r = a_session.get(a_url)
    print(r)
    r.raise_for_status()
    print(r.status_code)
    print(r.text)


import unittest


# Generated at 2022-06-26 01:23:20.377225
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    print("testing LoggedFunction.__call__")
    try:
        test_case_0()
    except:
        print("unexpected error")
        return



# Generated at 2022-06-26 01:23:27.228928
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    boolean_0 = True
    boolean_1 = False
    def method_0(boolean_0, boolean_1):
        return boolean_0 or boolean_1

    # Test with default arguments
    method_1 = LoggedFunction(logger=None)(method_0)
    assert method_1(boolean_0, boolean_1) == (boolean_0 or boolean_1)

    # Test with another arguments
    method_2 = LoggedFunction(logger=None)(method_0)
    assert method_2(boolean_1, boolean_0) == (boolean_1 or boolean_0)


# Generated at 2022-06-26 01:23:36.089420
# Unit test for function build_requests_session
def test_build_requests_session():
    assert str(type(build_requests_session(True, True))) == "<class 'requests.sessions.Session'>"
    assert str(type(build_requests_session(False, False))) == "<class 'requests.sessions.Session'>"
    assert str(type(build_requests_session(True, 4))) == "<class 'requests.sessions.Session'>"
    assert str(type(build_requests_session(False, 4))) == "<class 'requests.sessions.Session'>"
    assert str(type(build_requests_session(True, Retry()))) == "<class 'requests.sessions.Session'>"
    assert str(type(build_requests_session(False, Retry()))) == "<class 'requests.sessions.Session'>"


# Generated at 2022-06-26 01:23:44.392096
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    class Test:
        def function_0(self, arg_0, arg_1):
            data_0 = self
            data_1 = arg_0
            data_2 = arg_1
            return 5
    def function_0(arg_0, arg_1):
        data_0 = arg_0
        data_1 = arg_1
        return 5

    class DummyLogger:
        def debug(self, string):
            data_0 = string

    dummy_logger = DummyLogger()
    test_0 = Test()
    test_1 = Test()
    logged_function = LoggedFunction(dummy_logger)

    # Act
    logged_function_0 = logged_function(function_0)
    logged_function_1 = logged_function(Test.function_0)

   

# Generated at 2022-06-26 01:23:45.430696
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


# Generated at 2022-06-26 01:23:46.298607
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    obj_0 = LoggedFunction("")
    obj_0.__call__(test_case_0)

# Generated at 2022-06-26 01:23:49.667078
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    def foo(x):
        return x + 1

    dec = LoggedFunction(logging.getLogger())
    foo_dec = dec(foo)
    assert foo_dec(2) == 3
    assert foo_dec.__name__ == "foo"



# Generated at 2022-06-26 01:24:43.470580
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger(__name__)
    loggedfunction_0 = LoggedFunction(logger_0)
    func_0 = test_case_0
    logged_func = loggedfunction_0.__call__(func_0)
    logged_func()

# Generated at 2022-06-26 01:24:54.756604
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger('test', 'test')
    loggedFunction_0 = LoggedFunction(logger_0)
    test_case_1.__wrapped__ = loggedFunction_0(test_case_1)
    test_case_1()
    test_case_2.__wrapped__ = loggedFunction_0(test_case_2)
    test_case_2(1, 2)
    test_case_3.__wrapped__ = loggedFunction_0(test_case_3)
    test_case_3(1, 2, 3)
    test_case_4.__wrapped__ = loggedFunction_0(test_case_4)
    test_case_4(1, 2, 3, 4)

# Generated at 2022-06-26 01:24:58.510491
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = Logger()
    logger_0.set_level(DEBUG)
    logged_function_0 = LoggedFunction(logger_0)
    class_0 = 'b31d1e99-2ce2-4b2e-b57e-8f5072763c73'
    def function_0(* args, **kwargs):
        pass
    logged_function_0(function_0)


# Generated at 2022-06-26 01:25:11.331410
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    try:
        import logging
        import requests
    except Exception:
        return

    class Logger:
        def debug(self, msg):
            print(msg)

    class Test:
        def __init__(self):
            self.logger = Logger()

        @LoggedFunction(self.logger)
        def method_0(self, bool_0, bool_1, bool_2, bool_3, bool_4, bool_5, bool_6, bool_7, bool_8, bool_9):
            return bool_0 and bool_1 and bool_2 and bool_3 and bool_4 and bool_5 and bool_6 and bool_7 and bool_8 and bool_9

    test_0 = Test()

# Generated at 2022-06-26 01:25:21.596284
# Unit test for function build_requests_session
def test_build_requests_session():
    bool_0 = False
    int_0 = 2
    session_0 = build_requests_session(bool_0, int_0)
    assert session_0.__class__.__name__ == 'Session'.encode('utf-8').decode('utf-8')
    assert type(session_0._hooks) == dict
    assert session_0.headers['User-Agent'].encode('utf-8').decode('utf-8') == 'python-requests/2.24.0'.encode('utf-8').decode('utf-8')
    assert type(session_0.mounts) == dict

    session_1 = build_requests_session(bool_0)
    assert session_1.__class__.__name__ == 'Session'.encode('utf-8').decode('utf-8')


# Generated at 2022-06-26 01:25:28.140908
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    try:
        func_0 = test_case_0
        bool_0 = True
        logger_0 = build_requests_session(bool_0)
        logged_func_0 = LoggedFunction(logger_0)
        logged_func_0(func_0)
    except:
        raise
