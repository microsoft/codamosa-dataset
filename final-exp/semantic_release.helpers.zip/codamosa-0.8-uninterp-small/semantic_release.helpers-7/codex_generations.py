

# Generated at 2022-06-26 01:15:32.283568
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import inspect
    import logging
    import requests

    # Call function __call__ of class LoggedFunction with
    # arguments:
    #    func: instance of class requests.sessions.Session
    @LoggedFunction(logging.getLogger())
    def some_func(func, *args, **kwargs):
        return func(*args, **kwargs)
    
    # Call function _send of class requests.sessions.Session with
    # arguments:
    #    requests.sessions.Request: instance of class requests.sessions.Request
    #    **kwargs: 
    #        hooks: {}
    #        verify: True
    #        cert: None

# Generated at 2022-06-26 01:15:37.102368
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def f():
        pass

    def g():
        return
    f_decorated = LoggedFunction(logging.getLogger())(f)
    g_decorated = LoggedFunction(logging.getLogger())(g)
    f_decorated()
    g_decorated()



# Generated at 2022-06-26 01:15:45.555687
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    # logger.diable(logging.INFO)
    test_logger = Logger()
    test_logger.setLevel(logging.DEBUG)
    test_logger.addHandler(ch)
    test_logger.debug('test_logger')
    x = LoggedFunction(test_logger)
    test_case_0()
    test_logger.debug('test_logger')



# Generated at 2022-06-26 01:15:49.963294
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=getLogger("LoggedFunctionTest"))
    def func_0(arg_0):
        """
        This is func_0 with doc
        """
        return arg_0 * 2

    func_0.__name__ = "func_0"

    func_0(1)
    func_0(2)
    func_0(3)

# Generated at 2022-06-26 01:15:57.959598
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger()

    @LoggedFunction(logger)
    def logged():
        print('>>> test_LoggedFunction___call__')
        print('<<<')

    logged()


if __name__ == '__main__':
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:16:09.757594
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock, patch
    from logging import DEBUG
    from .LoggedFunction import LoggedFunction

    logger = Mock()
    logger_patch = patch("debug_utils.LoggedFunction.logger", logger)
    logger_patch.start()

    def foo_func(input_1, input_2:int, input_3:str) -> int:
        return input_1 + input_2

    logged_func = LoggedFunction(logger)
    logged_func_foo_func = logged_func(foo_func)

    input_1 = 1
    input_2 = 2
    input_3 = "input_3_value"
    foo_func_output = foo_func(input_1, input_2, input_3)

# Generated at 2022-06-26 01:16:14.853763
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    ba_logger = logging.Logger("test")

    @LoggedFunction(ba_logger)
    def test_func(arg1: str, arg2: int):
        return f"{arg1}{arg2}"

    test_func("blah", 123)



# Generated at 2022-06-26 01:16:23.750061
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import requests
    import unittest

    @LoggedFunction(logger=logging.getLogger(__name__))
    def func_0(a, b=2, *c, **d):
        return a

    @LoggedFunction(logger=logging.getLogger(__name__))
    def func_1(a, b=2, *c, **d):
        return (a, b, c, d)

    class Test_LoggedFunction___call__(unittest.TestCase):
        def test_case_0(self):
            self.assertEqual(func_0(1), 1)

        def test_case_1(self):
            self.assertEqual(func_0(2), 2)

        def test_case_2(self):
            self.assertE

# Generated at 2022-06-26 01:16:31.897243
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MagicMock()
    def call_function(function, *args, **kwargs):
        logged_function = LoggedFunction(logger)(function)
        logged_function(*args, **kwargs)

    # test case: normal call
    # test method
    @LoggedFunction(logger)
    def func_0(x):
        pass
    func_0(1)
    logger.debug.assert_called_once_with("func_0(1)")

    # test method: method with no arguments
    @LoggedFunction(logger)
    def func_1():
        pass
    func_1()
    logger.debug.assert_called_with("func_1()")

    # test method: method with positional argument and keyword argument

# Generated at 2022-06-26 01:16:36.720269
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = buildLogger()
    deco = LoggedFunction(logger)
    def func(arg1, arg2, arg3=3, arg4="4"):
        return arg4
    func_wraped = deco(func)
    func_wraped(1, 2)
    func_wraped(1, 2, 4, "5")
# test_LoggedFunction___call__()


if __name__ == "__main__":
    from configurator import Configurator
    from util import buildLogger

    configurator = Configurator()
    logger = buildLogger(configurator)

    test_case_0()

# Generated at 2022-06-26 01:16:41.872169
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup test case and call target method
    logger = logging.getLogger()
    logged_function = LoggedFunction(logger)
    logged_test_case = logged_function(test_case_0)
    logged_test_case()

# Generated at 2022-06-26 01:16:52.532102
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Initial 
    logger_0 = Logger.getLogger("test.test_loggedfunction")
    logged_function_0 = LoggedFunction(logger_0)

    # Test return value of function with no return value
    @logged_function_0
    def func_no_return():
        print("function with no return value")
       
    result = func_no_return()
    assert(result == None)

    # Test return value of function with return value 
    @logged_function_0
    def func_with_return():
        print("function with no return value")
        return 100

    result = func_with_return()
    assert(result == 100)


# Generated at 2022-06-26 01:16:56.291546
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def f(val: int) -> int:
        return val+1

    lf = LoggedFunction()

    lf.__call__(f)(1)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:17:00.783528
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func(a, b, c=None):
        print(a, b, c)

    logger = Mock()
    lf = LoggedFunction(logger)
    logged_func = lf(func)
    a = 1
    b = "a"
    c = True
    logged_func(a, b, c=c)
    logger.debug.assert_called_once_with(
        f"func({a}, '{b}', c={c})"
    )

# Generated at 2022-06-26 01:17:11.344510
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # create a mocked logger
    mock_logger = Mock()
    # and a LoggedFunction instance
    logged_func = LoggedFunction(mock_logger)
    # define a dummy function
    def dummy_func(*args, **kwargs):
        return args, kwargs
    # wrap it with LoggedFunction
    dummy_func = logged_func(dummy_func)
    # test passing no args and kwargs
    dummy_func()
    mock_logger.debug.assert_called_with(
        "dummy_func()"
    )
    # test passing args
    dummy_func(1, 2, 3)
    mock_logger.debug.assert_any_call(
        "dummy_func(1, 2, 3)"
    )
    # test passing kwargs

# Generated at 2022-06-26 01:17:13.888463
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Arrange
    logger = logging.getLogger()
    wrapper = LoggedFunction(logger)

# Generated at 2022-06-26 01:17:16.145349
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    session_0 = build_requests_session(raise_for_status=True)

# Generated at 2022-06-26 01:17:23.571048
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger

    logger = getLogger("test_logger")
    logger.info("Test class LoggedFunction starts.")
    @LoggedFunction(logger)
    def test_func_0(arg0: int, arg1: str,
                    arg2: int = 8, arg3: str = "test_str_3") -> str:
        return f"{arg1}_{arg2}_{arg3}"
    result = test_func_0(0, "test_str_1")
    assert result == "test_str_1_8_test_str_3"

# Generated at 2022-06-26 01:17:31.951223
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks['response'] != []
    assert session.adapters['http://'].max_retries.total != 0
    assert session.adapters['https://'].max_retries.total != 0
    session = build_requests_session(False)
    assert session.hooks['response'] == []
    session = build_requests_session(retry=False)
    assert session.adapters['http://'].max_retries.total == 0
    assert session.adapters['https://'].max_retries.total == 0
    session = build_requests_session(retry=1)
    assert session.adapters['http://'].max_retries.total == 1

# Generated at 2022-06-26 01:17:33.889617
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__ + ".test_LoggedFunction___call__")
    session_0 = build_requests_session()
    session_0.get("https://httpbin.org/status/200")
    logger.debug("End of test test_LoggedFunction___call__")


# Generated at 2022-06-26 01:17:41.598985
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        session = build_requests_session()
        session.get("http://www.baidu.com")
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 01:17:52.053662
# Unit test for function build_requests_session
def test_build_requests_session():
    # When raise_for_status is True, expect an instance of Session with one hook in it
    session_0 = build_requests_session(raise_for_status = True)
    assert isinstance(session_0, Session)
    assert len(session_0.hooks) == 1
    assert len(session_0.hooks['response']) == 1

    # When raise_for_status is False, expect an instance of Session with no hook in it
    session_1 = build_requests_session(raise_for_status = False)
    assert isinstance(session_1, Session)
    assert len(session_1.hooks) == 0

    # When retry is a bool value, expect that the Session invocation of mount()
    # is invoked twice, once for 'http://' and once for 'https://'

# Generated at 2022-06-26 01:17:58.782594
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Case 0
    session_0 = build_requests_session()
    session_1 = build_requests_session(raise_for_status=False, retry=False)
    session_2 = build_requests_session(raise_for_status=False, retry=False)
    session_3 = build_requests_session(raise_for_status=False, retry=1)
    session_4 = build_requests_session(raise_for_status=False, retry=1)
    session_5 = build_requests_session(raise_for_status=False, retry=1)
    session_6 = build_requests_session(raise_for_status=False, retry=Retry())

# Generated at 2022-06-26 01:18:09.731352
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from contextlib import redirect_stdout

    # Define target
    def my_function(a, b=0, *args, **kwargs):
        return a + b + sum(args) + sum(list(kwargs.values()))

    # Test
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    logged_function = LoggedFunction(logger)
    logged = logged_function(my_function)
    with redirect_stdout(None):
        result = logged(1, 2, 3, 4, named=5)
    assert result == 1 + 2 + 3 + 4 + 5
    assert result == my_function(1, 2, 3, 4, named=5)
    result = logged(0)

# Generated at 2022-06-26 01:18:10.664370
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    print("in __call__")



# Generated at 2022-06-26 01:18:18.439107
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    mocker = Mocker()
    mock_objects = mocker.mock()
    logger = mock_objects.get('logger')
    session_0 = build_requests_session()
    session_0.hooks = {'response': [lambda r, *args, **kwargs: r.raise_for_status()]}
    mocked_functions = [build_requests_session, Session]

    logger.debug(ANY())
    logger.debug(ANY())
    with mocker:
        # Tested function
        logged_func_0 = LoggedFunction(
            logger
        )(session_0.hooks['response'][0])

    mocked_functions.reverse()
    mock_objects.verify()



# Generated at 2022-06-26 01:18:20.616064
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.headers == {'User-Agent': 'python-requests/' + requests.__version__}


# Generated at 2022-06-26 01:18:35.265431
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    # Create logged decorator
    logger_decorator = LoggedFunction(logger)

    # Decorate function with logger decorator
    @logger_decorator
    def test_function(param_1, param_2):
        print(f"Test function called with {param_1} and {param_2}")

    # Call function and check output
    test_function("test_param_1", "test_param_2")

# Generated at 2022-06-26 01:18:42.321896
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func_0 = lambda x: x
    logger_0 = 0
    logged_function_0 = LoggedFunction(logger_0)
    logged_function___call___0 = logged_function_0(func_0)
    logged_function___call___0(0, 0, 0)


test_case_0()
test_LoggedFunction___call__()

# Generated at 2022-06-26 01:18:44.408751
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    def func_0(*args, **kwargs):
        return args, kwargs

    logged_func_0 = LoggedFunction



# Generated at 2022-06-26 01:19:02.286227
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest.mock as mock
    log = mock.Mock(spec=logging.Logger)
    logger = LoggedFunction(log)
    logger.__call__(
        lambda one, two, three=1, four=2: one + two + three + four
    )(1, 2, 3, 4)
    log.debug.assert_called_with(
        "function_name(1, 2, three=3, four=4)"
    )


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:19:08.749091
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def f(a, b, c=1, *args, **kwargs):
        return 1

    # setup
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    logged_function = LoggedFunction(logger)
    logged_f = logged_function(f)

    # test
    assert logged_f(0, 1, 2, 3, 4, d=5, e=6) == 1
    assert logged_f(0, 1, 2, 3, 4, d=5, e=6) == 1

# Generated at 2022-06-26 01:19:15.806388
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import functools

    logger = logging.getLogger("test_session_0")
    # set logger level as DEBUG
    logger.setLevel(logging.DEBUG)
    # add stream handler to print logs
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logged_function = LoggedFunction(logger)
    logged_func = logged_function(test_case_0)

    logged_func()

test_LoggedFunction___call__()

# Generated at 2022-06-26 01:19:22.723118
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = mock.Mock()
    test_object = LoggedFunction(logger_0)
    func_0 = mock.Mock()
    # Call method under test
    returned_value = test_object(func_0)

    # Test returned value
    def test_func(*args, **kwargs):
        return test_object.logger.debug(mock.sentinel.arg_0)
    assert returned_value == test_func
    assert test_func.__name__ == func_0.__name__


# Generated at 2022-06-26 01:19:26.849131
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Initialize the arguments
    logger = object()
    func = object()

    # Call method __call__
    result = LoggedFunction(logger).__call__(func)

    assert result == logged_func
    assert logged_func.__wrapped__ == func



# Generated at 2022-06-26 01:19:35.456375
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    import nose

    from nose.tools import eq_
    from nose.tools import ok_

    from common_tests.utils import execute_test
    from utils import LoggedFunction

    class MockLogger:
        def __init__(self):
            self.debug_calls = []

        def debug(self, value):
            self.debug_calls.append(value)

    # Test 1: function with return value
    def function_1a(arg1):
        return "Test 1"

    def function_1b(arg1, arg2):
        return "Test 2"


# Generated at 2022-06-26 01:19:40.034434
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    f = LoggedFunction(logging.getLogger("test"))
    # The following 2 calls do the same thing
    # The main purpose of the first call is to test whether a string should be treated as a true value
    f("https://www.liyingjia.cn")("https://www.liyingjia.cn")

# Generated at 2022-06-26 01:19:46.334754
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger(__name__)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 01:19:55.962799
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from requests.exceptions import HTTPError
    from requests.adapters import HTTPAdapter

    session = build_requests_session(True)
    for hook in session.hooks['response']:
        assert hook == HTTPError.raise_for_status

    session = build_requests_session(False)
    assert session.hooks['response'] == []

    session = build_requests_session(retry=False)
    assert type(session.get_adapter("http://")) == HTTPAdapter
    assert type(session.get_adapter("https://")) == HTTPAdapter

    session = build_requests_session(retry=True)
    assert type(session.get_adapter("http://")) == HTTPAdapter
    assert type(session.get_adapter("https://")) == HTTPAdapter

    session = build_requ

# Generated at 2022-06-26 01:20:05.356824
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from time import time

    def f(a, b, c=1, d=2):
        return a + b + c + d


    # test case 0: normal case
    logger_0 = logging.getLogger("logger_0")
    logger_0.setLevel(logging.DEBUG)
    logger_0.handlers.clear()
    ch_0 = logging.StreamHandler()
    ch_0.setLevel(logging.DEBUG)
    formatter_0 = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    ch_0.setFormatter(formatter_0)
    logger_0.addHandler(ch_0)

    g_0 = LoggedFunction(logger_0)
    h_0

# Generated at 2022-06-26 01:20:24.748624
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_logger")
    function_decorator = LoggedFunction(logger)

    # Test default
    @function_decorator
    def foo(a, b, c=1, d=2):
        return a + b + c + d

    result = foo(1, 2, 3, 4)
    assert result == 10
    assert foo(1, 2, d=4) == 8

    # Test with one argument, two keywords arguments
    @function_decorator
    def _test_1(a, b=2, c=3):
        return a * b * c
    assert _test_1(2) == 12
    assert _test_1(3, b=3, c=5) == 45

# Generated at 2022-06-26 01:20:28.495923
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    a = LoggedFunction(logger=logging.getLogger())


# Generated at 2022-06-26 01:20:31.002228
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import basicConfig, DEBUG

    basicConfig(level=DEBUG)

    @LoggedFunction(logger)
    def test_func(a, b):
        return a + b

    test_func(1, 2)

# Generated at 2022-06-26 01:20:32.765196
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()



# Generated at 2022-06-26 01:20:41.057995
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import pytest
    from unittest.mock import patch

    from .logger_function import LoggedFunction

    @LoggedFunction(logger=None)
    def test_function(key: str):
        pass

    with patch("logging.Logger.debug") as mock_debug:
        test_function("value")
        mock_debug.assert_called_once_with("test_function('value')")

# Generated at 2022-06-26 01:20:48.353812
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)

    # Arrange
    # @LoggedFunction(logger)
    # def test_function(a, b=2, c=3):
    #     return "test"

    # test_function(1, c=4)

    # Assert


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s %(name)s[%(lineno)d] %(levelname)s: %(message)s",
    )
    # test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:21:03.206929
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from ucc.dbi import db

    session_1 = build_requests_session(retry=False)
    logger_1 = logging.getLogger(__name__)

    logged_function_1 = LoggedFunction(logger_1)
    logged_function_1(session_1.get)
    session_1.get.assert_called_with(
        "http://www.baidu.com", hooks={"response": [db._raise_for_status]}
    )

    session_2 = build_requests_session(retry=0)
    logger_2 = logging.getLogger(__name__)

    logged_function_2 = LoggedFunction(logger_2)
    logged_function_2(session_2.get)
    response_2 = session_2.get.return_value
    session

# Generated at 2022-06-26 01:21:14.820794
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    def fake_func(a, b, c):
        return a + b + c

    logger = FakeLogger()
    logged_func = LoggedFunction(logger)(fake_func)
    fake_result = logged_func(1, 2, 3)
    assert fake_result == 6
    assert logger.logs[0] == "fake_func(1, 2, 3)"
    assert logger.logs[1] == "fake_func -> 6"


if __name__ == "__main__":
    pass

# Generated at 2022-06-26 01:21:21.623417
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Logger to send messages to
    logger = logging.getLogger("TestLogger")
    logger.setLevel(logging.DEBUG)

    # Create handler and set level to debug
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)

    # Add the logger and handler to the logger
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def my_function(a, b, c=3, d="a"):
        return a + b

    my_function(1, 2)
    my_function(1, 2, d="b")
    my_function(1, 2, d="b", c=4)



# Generated at 2022-06-26 01:21:22.132748
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-26 01:21:43.877559
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    # Setup logger
    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # Define test function
    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    # Call test function
    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, c=4)

    # Test function instance
    assert isinstance(test_func, LoggedFunction)

    # Test function attributes
    assert hasattr(test_func, "logger")
    assert test_func.logger == logger

    # Test original function attributes

# Generated at 2022-06-26 01:21:54.453976
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    format_arg_0 = LoggedFunction.__call__
    http_adapter_0 = HTTPAdapter()
    format_arg_0 = LoggedFunction.__call__
    retry_0 = functools.partial(Retry, total=2, connect=None, read=None, redirect=None, status=None)
    session_1 = build_requests_session(retry=retry_0, raise_for_status=True)
    format_arg_0 = LoggedFunction.__call__
    retry_0 = functools.partial(Retry, total=1, connect=None, read=None, redirect=None, status=None)
    session_2 = build_requests_session(retry=retry_0, raise_for_status=True)
    format

# Generated at 2022-06-26 01:22:06.450868
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from dero.data.downloader import _build_requests_session
    from dero.data.downloader import LoggedFunction
    from dero.data.downloader import _build_requests_session as _build_requests_session_orig
    import dero.data.downloader
    session_0 = _build_requests_session()
    print(type(session_0))
    assert (session_0 is None) == False
    dero.data.downloader._build_requests_session = LoggedFunction(logging.getLogger(__name__))(dero.data.downloader._build_requests_session_orig)
    session_0 = _build_requests_session()
    assert (session_0 is None) == False
    print(type(session_0))
    dero.data.downloader._

# Generated at 2022-06-26 01:22:15.361937
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import inspect
    import logging
    from pandas import DataFrame
    from pandas.io.parsers import TextFileReader
    import re


# Generated at 2022-06-26 01:22:20.668169
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    @LoggedFunction(logger=None)
    def func_0(arg_0, arg_1='s', arg_2=None):
        return 's'


    assert_equal(func_0(arg_0=None, arg_2=None), 's')

    assert_equal(func_0(arg_0=None), 's')

    assert_equal(func_0(), 's')


if __name__ == '__main__':
    from nose.tools import assert_equal

    session_0 = build_requests_session()

    # Unit test for method __call__ of class LoggedFunction
    def func_0(arg_0, arg_1='s', arg_2=None):
        return 's'



# Generated at 2022-06-26 01:22:24.525540
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test when raise_for_status = True and retry = True
    def func_0(a: str, b: str) -> str:
        return a + b
    lf = LoggedFunction(logger)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:22:30.995012
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class _Logger(object):

        _logged_called = False

        def debug(self, args):
            self._logged_called = True

    logger_0 = _Logger()
    logged_func_0 = LoggedFunction(logger_0)
    
    def func_0(value):
        return value

    logged_func_0(func_0)()
    assert logger_0._logged_called

# Generated at 2022-06-26 01:22:32.598914
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()


# Generated at 2022-06-26 01:22:45.361838
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def mock_logged_func(param_0, *args, **kwargs):
        pass

    class MockLogger:
        def __init__(self):
            self.debug = Mock()

    mock_logger = MockLogger()
    mock_logged_function = LoggedFunction(mock_logger)

    mock_logged_function.__call__(mock_logged_func)("test", 12, x="test2")
    mock_logger.debug.assert_called_once_with("mock_logged_func('test', 12, x='test2')")
    mock_logger.debug.reset_mock()

    mock_logged_function.__call__(mock_logged_func)("test", "test2", "test3")
    mock_logger.debug.assert_

# Generated at 2022-06-26 01:22:50.782855
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func_0(arg_1: str, arg_2: int, arg_3: None):
        """
        Test function.
        :param arg_1: int
        :param arg_2: dict
        :param arg_3: str
        :return: None
        """
        pass

    logger_0 = LoggedFunction(print)
    result_0 = logger_0(test_func_0)
    assert result_0.__name__ == "test_func_0"



# Generated at 2022-06-26 01:23:23.046401
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from typing import Any
    from typing import Any


    def logged_func(this,  x: str, y: int, z: bool) -> Any:
        return 0
    assert logged_func.__name__ == "logged_func"
    assert logged_func("x", "y", 0, 0) == 0
    assert logged_func("x", "y", 0, 0) == 0
    assert logged_func("x", "y", 0, 0) == 0
    assert logged_func("x", "y", 0, 0) == 0
    assert logged_func("x", "y", 0, 0) == 0
    assert logged_func("x", "y", 0, 0) == 0
    assert logged_func("x", "y", 0, 0) == 0

# Generated at 2022-06-26 01:23:27.831961
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func_0(param_0, param_1):
        return param_0, param_1

    logger_0 = LoggedFunction(logging.getLogger('LoggedFunction.__call__'))
    func_0_decorated = logger_0(func_0)
    assert func_0_decorated("param_0", "param_1") == ("param_0", "param_1")

# Generated at 2022-06-26 01:23:35.108697
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger()
    logged_function_0 = LoggedFunction(logger_0)
    logged_function_0(test_case_0)
    class function_0:
        def __init__(self):
            self.__name__ = '__init__'
        def __call__(self, *args, **kwargs):
            pass
    type_0 = type(function_0())
    type_1 = function_0
    function_1 = logged_function_0(function_0)
    assert type(function_1) == type_0
    assert type(function_1()) == type_1


# Generated at 2022-06-26 01:23:37.370532
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    method = build_requests_session().__call__
    decorator = LoggedFunction(logger=Logger("build_requests_session"))
    decorated_method = decorator(method)
    decorated_method()

# Generated at 2022-06-26 01:23:38.134014
# Unit test for function build_requests_session
def test_build_requests_session():
    test_case_0()

# Generated at 2022-06-26 01:23:43.751993
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create a mock logger
    logger_0 = Mock()

    # Call LoggedFunction(logger_0)
    logged_func_0 = LoggedFunction(logger_0)

    # Call logged_func_0(a)
    a_0 = "https://openlibrary.org/search.json?q="

    logger_0.debug.assert_not_called()

    assert logged_func_0(a_0) == a_0
    logger_0.debug.assert_called()


# Generated at 2022-06-26 01:23:52.372023
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Setup the logger
    logger_0 = logging.getLogger(__name__)
    logger_0.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    ch.setFormatter(formatter)
    logger_0.addHandler(ch)

    # Time to test!
    @LoggedFunction(logger_0)
    def add(x: int, y: int) -> int:
        return x + y

    # Calls
    add(1, 2)
    add(1, 2, 3)
    print("Test Passed!")

# Generated at 2022-06-26 01:23:58.309177
# Unit test for function build_requests_session
def test_build_requests_session():
    session_1 = build_requests_session()
    session_2 = build_requests_session(raise_for_status=False)
    session_3 = build_requests_session(retry=False)
    session_4 = build_requests_session(retry=4)
    session_5 = build_requests_session(retry=Retry())


if __name__ == "__main__":
    test_case_0()
    test_build_requests_session()

# Generated at 2022-06-26 01:24:05.764378
# Unit test for function build_requests_session
def test_build_requests_session():
    # use default setting
    session_0 = build_requests_session()
    assert isinstance(session_0, Session)
    assert session_0.max_retries == Retry()
    assert session_0.get('http://www.baidu.com')

    # use default setting with raise_for_status
    session_1 = build_requests_session(raise_for_status=True)
    assert isinstance(session_1, Session)
    assert session_1.hooks['response'][0].__name__ == 'raise_for_status'
    assert session_1.max_retries == Retry()
    assert session_1.get('http://www.baidu.com')

    # use default setting with raise_for_status and retry

# Generated at 2022-06-26 01:24:12.978227
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_1 = build_requests_session()
    # 下面打印一个数字
    # 9
    print(session_1)
    # 下面是打印一个函数
    # <bound method Session.request of <requests.sessions.Session object at 0x10d1e7438>>
    print(session_1.request)

    # session_1.request函数的名字是 request
    # 此时的logged_func的名字是 request
    # 因此下面的打印是：request(session: 0x10d1e7438, method='request')
    # 这样打印出来的

# Generated at 2022-06-26 01:25:14.282317
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    if __name__ == "__main__":
        """
        __call__(<self: LoggedFunction>, <func: function>, <args: tuple>, <kwargs: dict>) -> <LoggedFunction.__call__: <function logged_func>>

        This is a builtin Python method, and is documented here:
        https://docs.python.org/3/library/functions.html#functools.wraps
        """
        @LoggedFunction(logger = logging.getLogger(__name__))
        def test_case_0(arg_0):
            return arg_0

        test_case_0(5)

# Generated at 2022-06-26 01:25:23.817481
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Mock log
    class Log():
        class Debug():
            def __call__(self, args):
                print("Debug:", args)

        debug = Debug()

    # Patch the method
    class PatchedLoggedFunction():
        def __call__(self, *args):
            if type(args[0]) == LoggedFunction:
                return LoggedFunction(*args)
            else:
                return lambda *args: True

    with patch("functools.wraps", return_value=True), patch(
        "pylog.loggedfunction.LoggedFunction", PatchedLoggedFunction()
    ):
        # Test debug
        test_case_0()