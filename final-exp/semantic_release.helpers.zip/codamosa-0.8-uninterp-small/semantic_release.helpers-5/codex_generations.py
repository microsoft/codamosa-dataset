

# Generated at 2022-06-26 01:15:28.390517
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction("logger")
    def logged_func(x, y):
        return x + y

    logged_func(1, 2)


# Generated at 2022-06-26 01:15:29.906485
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = LoggedFunction(None)
    func_0 = logger_0.__call__()
    func_0()

# Generated at 2022-06-26 01:15:32.393248
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    # Check that session is properly started and no error occurs.
    @LoggedFunction(None)
    def test():
        pass

    test()



# Generated at 2022-06-26 01:15:36.924117
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Instance Logged Function
    logger_0 = logging.getLogger(__name__)
    logged_function_0 = LoggedFunction(logger_0)

    # Call the method
    logged_function_0.__call__(build_requests_session)


# Generated at 2022-06-26 01:15:38.342450
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test case 0
    # Calling test function for test case 0
    test_case_0()

# Generated at 2022-06-26 01:15:39.183564
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # This is a stub
    return


# Generated at 2022-06-26 01:15:46.654933
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    obj_0 = LoggedFunction("")
    def fun_0(arg_0, arg_1):
        pass
    fun_0("", "")
    obj_0(fun_0)


asm = []

with open("asm.csv", "r") as f:
    for cnt, l in enumerate(f):
        print(cnt, l)
        asm.append(l)


s = """
",&gt;+&lt;-[&gt;+&lt;-]&gt;[&gt;+&lt;-]&lt;+
"""

for a in s.split("\n"):
    print("'" + a.replace(" ", "") + "'")

# Generated at 2022-06-26 01:15:51.926967
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    There is a list of requirements for this method:
    
    :param logger: Logger to send output to.
    """
    # Ensure an exception is thrown when the wrong type is given.
    # Raise the exception.
    try:
        def test_case_0():
            test_case_var_0 = LoggedFunction(None)
            func_0 = test_case_var_0(None)
    except TypeError:
        pass


# Generated at 2022-06-26 01:15:54.688923
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create logger
    logger_1 = logging.getLogger()

    # Create instance of LoggedFunction
    logged_function_1 = LoggedFunction(logger_1)

    # Run method __call__
    result_1 = logged_function_1.__call__(test_case_0)
    assert result_1 is None



# Generated at 2022-06-26 01:16:08.441237
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = []
    test_0 = LoggedFunction(logger_0)
    logger_1 = []
    test_1 = LoggedFunction(logger_1)
    assert  test_1.__call__(lambda x: x)(1) == 1
    assert logger_1 == ['']
    test_2 = LoggedFunction(logger_1)
    assert test_2.__call__(lambda x: x)(True) == True
    assert logger_1 == ['']
    test_3 = LoggedFunction(logger_1)
    assert test_3.__call__(lambda x: x)(False) == False
    assert logger_1 == ['']
    test_4 = LoggedFunction(logger_1)
    assert test_4.__call__(lambda x: x)(None) == None
    assert logger_

# Generated at 2022-06-26 01:16:13.112652
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:16:15.916097
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    test_case_0()


# Main program

# Generated at 2022-06-26 01:16:21.075326
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()

    def func_0(args, kwargs):
        return args, kwargs

    logged_func = LoggedFunction(logger)(func_0)
    assert logged_func  # suppress pytest warning
    # assert logging.getLogger().debug.called



# Generated at 2022-06-26 01:16:28.964874
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # get logger
    logger = logging.getLogger('example_0')

    # create decorator
    logged_function_0 = LoggedFunction(logger)

    # create test function
    # function func_0(str_0) -> str_0
    @logged_function_0
    def func_0(str_0):
        return str_0

    # call function
    value = func_0('cs=cc')

    # check result
    assert value == 'cs=cc'
    assert logger.debug.call_count == 1


# Generated at 2022-06-26 01:16:30.078387
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 01:16:34.229188
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    result = ""

    logger = LoggedFunction(result)

    result = str(logger)

    if result == logger:
        return True
    else:
        return False



# Generated at 2022-06-26 01:16:37.444001
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session
    assert hasattr(session, 'session')
    assert hasattr(session, '_adapter')
    assert hasattr(session, '_hooks')


# Generated at 2022-06-26 01:16:46.213148
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    str_0 = 'cs=cc'
    var_0 = format_arg(str_0)
    obj_0 = LoggedFunction(var_0)
    obj_1 = obj_0.__call__(var_0)
    obj_1
    obj_1.__name__
    obj_1.__call__(var_0, var_0)



# Generated at 2022-06-26 01:16:57.090055
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    str_0 = "cs=cc, name=cc"
    logger = lambda x:str_0
    class LoggedFunctionMock:
        def __init__(self, logger=None):
            self.logger = logger
        def __call__(self, func):
            @functools.wraps(func)
            def logged_func(*args, **kwargs):
                self.logger.debug(
                    "{function}({args}{kwargs})".format(
                        function=func.__name__,
                        args=", ".join([format_arg(x) for x in args]),
                        kwargs="".join(
                            [f", {k}={format_arg(v)}" for k, v in kwargs.items()]
                        ),
                    )
                )

# Generated at 2022-06-26 01:17:07.230203
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    str_0 = 'cs=cc'
    str_1 = 'ds=dd'
    func_0 = format_arg
    func_0_0 = LoggedFunction.__call__(LoggedFunction, func_0)
    int_0 = 1
    int_1 = 1
    float_0 = float
    float_0_0 = LoggedFunction.__call__(LoggedFunction, float_0)
    float_1 = float
    float_1_0 = LoggedFunction.__call__(LoggedFunction, float_1)
    float_2 = float
    float_2_0 = LoggedFunction.__call__(LoggedFunction, float_2)
    float_3 = float
    float_3_0 = LoggedFunction.__call__(LoggedFunction, float_3)
    str_2 = 'es=ee'


# Generated at 2022-06-26 01:17:22.281255
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session
    assert type(build_requests_session(retry=False)) == Session
    assert type(build_requests_session(retry=1)) == Session
    assert type(build_requests_session(retry=Retry())) == Session
    assert type(build_requests_session(retry=True)) == Session
    assert type(build_requests_session(retry=2)) == Session
    assert type(build_requests_session(retry=False)) == Session
    assert type(build_requests_session(retry=False)) == Session
    assert type(build_requests_session(retry=1)) == Session
    assert type(build_requests_session(retry=Retry())) == Session



# Generated at 2022-06-26 01:17:28.398379
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('test_LoggedFunction___call__')
    def func_0(arg1, arg2, kwarg1=None, kwarg2=None):
        pass
    wrapped_function = LoggedFunction(logger)(func_0)
    wrapped_function(1)
    wrapped_function(1, 2)
    wrapped_function(1, 2, kwarg1=3, kwarg2=4)

if __name__ == '__main__':
    # Simple test
    test_case_0()
    # Unit test
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:35.833779
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test")
    lg_fnc = LoggedFunction(logger)
    @lg_fnc
    def test_fn(p1, p2):
        return p1 * p2
    var_1 = test_fn(2, 3)

# Generated at 2022-06-26 01:17:37.204731
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:17:47.816216
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    logging.basicConfig(level=logging.DEBUG)
    logger = logging

    class Mock:
        def __init__(self):
            pass

    def mock_func():
        pass

    def mock_func_0(a):
        pass

    def mock_func_1(a):
        return 1

    def mock_func_2(a, b):
        pass

    def mock_func_3(a, b):
        return 1

    def mock_func_4(a, b, c):
        pass

    def mock_func_5(a, b, c):
        return 1

    def mock_func_6(a, b, c, d):
        pass

    def mock_func_7(a, b, c, d):
        return 1


# Generated at 2022-06-26 01:17:48.792064
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:17:53.022169
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Use the decorator to wrap the function
    @LoggedFunction(logging.getLogger(__name__))
    def add(x, y):
        return x + y

    # Call the function and check that the result is correct
    assert add(1, 2) == 3



# Generated at 2022-06-26 01:17:54.169385
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session_0 = build_requests_session()


# Generated at 2022-06-26 01:17:56.991005
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        session = build_requests_session(False, 3)
        print("build_requests_session() passed unit test.")
    except:
        print("build_requests_session() failed unit test.")


# Generated at 2022-06-26 01:17:58.155396
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # pass
    test_case_0()

# Generated at 2022-06-26 01:18:11.726390
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Logger('test_LoggedFunction')
    log_decorator = LoggedFunction(logger)

    @log_decorator
    def test_case_1(param1, param2=None):
        test_case_0()
        var_1 = param1
        var_2 = param2
        return var_1
    
    test_case_1('dd', 'eef')

# Generated at 2022-06-26 01:18:14.031085
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    obj_0 = LoggedFunction(None)
    obj_0.logger = None
    test_case_0()



# Generated at 2022-06-26 01:18:16.641661
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def logged_func():
        return None
    assert not callable(logged_func)
    assert hasattr(logged_func, "__qualname__")
    assert hasattr(logged_func, "__wrapped__")


# Generated at 2022-06-26 01:18:20.743062
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("my-logger")
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logged_function = LoggedFunction(logger)
    func = lambda s, e=None: {'s': s, 'e': e}
    logged_func = logged_function(func)
    logged_func('test', e=None)
    logged_func('test', e=True)

# Generated at 2022-06-26 01:18:23.222587
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Given
    logger = logging.getLogger(__name__)
    logged = LoggedFunction(logger)
    test_case_0()
    assert True

# Generated at 2022-06-26 01:18:35.628430
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from typing import Union

    from tests.log_fixture import log, log_file
    from logging import DEBUG
    import logging

    with log_file.open() as f:
        log_content = f.read()

    # Testing valid case
    with log.atLevel(DEBUG):
        _logged_func = LoggedFunction(log)
        logged_func = _logged_func(test_case_0)
        logged_func()
        assert log_content == '''DEBUG:root:test_case_0('cs=cc')
DEBUG:root:test_case_0 -> None
'''

# Generated at 2022-06-26 01:18:40.309044
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    test_logged = LoggedFunction(logger)
    def fake_func():
        pass
    test_logged(fake_func)

# Generated at 2022-06-26 01:18:44.620684
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logged_function = LoggedFunction(logger)
    def func(arg_0):
        return arg_0
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 01:18:57.958973
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logged_function_obj = LoggedFunction(logger)

    # Test function format_arg
    test_case_0()

    # Test function build_requests_session
    build_requests_session(True, Retry())

    # Test function __call__ of class LoggedFunction
    def test_function(a, b, *args, c=None):
        return a + b + sum(args) + (c or 0)

    test_function = logged_function_obj(test_function)
    result = test_function(1, 2, 3)
    assert result == 6
    result = test_function(1, 2, 3, c=10)
    assert result == 16
    result = test_function(1, 2, 3, c=10, d=30)
    assert result == 16

# Generated at 2022-06-26 01:19:01.699526
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # case 0
    logger = base.getLogger(__name__)
    lf = LoggedFunction(logger)
    lf(test_case_0)

# Generated at 2022-06-26 01:19:19.750938
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    session.get('https://www.yahoo.com')


# Generated at 2022-06-26 01:19:21.113224
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()



# Generated at 2022-06-26 01:19:23.391528
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Call method __call__ of LoggedFunction with parameters: func=test_case_0
    test_LoggedFunction___call__(func=test_case_0)


# Generated at 2022-06-26 01:19:25.408584
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    str_0 = 'cs=cc'
    var_0 = format_arg(str_0)
    assert var_0 == "'cs=cc'"

# Generated at 2022-06-26 01:19:27.826050
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    str_0 = 'test string'
    format_arg_0 = format_arg(str_0)


# Generated at 2022-06-26 01:19:30.738423
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    var_0 = LoggedFunction
    var_1 = functools.wraps(var_0)
    var_2 = var_1(var_1)
    var_3 = format_arg(var_2)



# Generated at 2022-06-26 01:19:32.481176
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = None
    lf = LoggedFunction(logger)
    func = test_case_0
    lf.__call__(func)


# Generated at 2022-06-26 01:19:33.327779
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:19:44.293195
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction
    """
    str_0 = 'cs=cc'
    var_0 = format_arg(str_0)
    def test_func_0(arg_0):
        var_0 = arg_0
        return var_0
    obj_0 = LoggedFunction(None)
    test_LoggedFunction___call__var_1 = obj_0.__call__(test_func_0)
    # TEST CASE
    # Declare a variable called test_LoggedFunction___call__var_0 with value var_0
    # Call method __call__ of object obj_0 with arguments test_LoggedFunction___call__var_0
    result_0 = test_LoggedFunction___call__var_1(var_0)
    assert result_0 == str_0


# Unit

# Generated at 2022-06-26 01:19:50.998888
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    temp = LoggedFunction(logger)
    str_0 = 'cs=cc'
    var_0 = format_arg(str_0)
    func()

    x = 1
    y = 2
    z = 3
    kwargs = {"x": x, "y": y, "z": z}
    for key, value in kwargs.items():
        var_1 = format_arg(value)

    temp.__call__(func)(x, y, z)

# Generated at 2022-06-26 01:20:19.390374
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test case 0
    str_0 = 'cs=cc'
    var_0 = format_arg(str_0)

# Generated at 2022-06-26 01:20:31.097711
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Creating a mock logger object
    mock_Logger = unittest.mock.MagicMock(logging.Logger)
    # Creating mock logger object
    class mock_Logger_instance:
        def debug(self, *args, **kwargs):
            return

    mock_Logger.__new__ = unittest.mock.MagicMock(name='__new__')
    mock_Logger.__new__.return_value = mock_Logger_instance()
    logger = mock_Logger()

    # Get an instance of LoggedFunction
    instance = LoggedFunction(logger)


    # calling instance.__call__(test_case_0)
    # test_case_0()
    # assert_true(unittest.mock.call(instance.logger.debug('test_case_0(''

# Generated at 2022-06-26 01:20:44.618661
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    obj_0 = LoggedFunction.__new__(LoggedFunction)
    var_0 = ['logger']
    obj_1 = functools.update_wrapper.__new__(functools.update_wrapper)
    obj_2 = functools.update_wrapper(obj_1, LoggedFunction.__call__.func_globals['__builtins__']['logged_func'])
    var_0.append(obj_2)
    obj_3 = functools.update_wrapper(obj_1, LoggedFunction.__call__.func_globals['__builtins__']['logged_func'])
    obj_4 = LoggedFunction.__call__.func_globals['__builtins__']['logged_func']

# Generated at 2022-06-26 01:20:49.469526
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


# Generated at 2022-06-26 01:20:51.375802
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    obj = LoggedFunction(log)
    test_case_0()



# Generated at 2022-06-26 01:21:05.094274
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from copy import copy
    from copy import deepcopy
    from unittest.mock import MagicMock
    from unittest.mock import call

    import labs.logging_helpers as logging_helpers

    # Create empty mock logger
    mock_logger = MagicMock()

    # Create LoggedFunction instance
    logged_func = logging_helpers.LoggedFunction(mock_logger)

    # Create example function
    def example_func(arg_0, kwarg_0=None, kwarg_1=True):
        return arg_0 + kwarg_0 + kwarg_1

    # Call LoggedFunction with example function
    result = logged_func(example_func)

    # Call using required arguments
    result(1, 2)
    # Check that logger was called correctly

# Generated at 2022-06-26 01:21:09.238947
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('Test')
    lf = LoggedFunction(logger)
    lf.__call__(test_case_0)

# Generated at 2022-06-26 01:21:13.532947
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    x31 = LoggedFunction('__main__.logger')
    test_case_0()

test_fn_dict = {
    'test_LoggedFunction___call__' : test_LoggedFunction___call__,
}


# Generated at 2022-06-26 01:21:15.980105
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from ipdb import set_trace; set_trace()
    # Arrange
    # dummy_logger = logging.getLogger(__name__)
    # logged_func = LoggedFunction(dummy_logger)

    # Act
    # logged_func(test_case_0)

    # Assert
    # assert isinstance(result, bool)
    pass


# Generated at 2022-06-26 01:21:16.822158
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test case #0
    test_case_0()

# Generated at 2022-06-26 01:22:09.355543
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # test_case_0
    obj_0 = LoggedFunction(object())
    obj_1 = obj_0.__call__(test_case_0)
    assert obj_1 is not None
    obj_2 = obj_1()
    assert obj_2 is None

# Generated at 2022-06-26 01:22:12.468703
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    method = LoggedFunction(logger)
    a = (function, arg_a, arg_b, arg_c, arg_d, arg_e)
    method(a)


# Generated at 2022-06-26 01:22:18.214343
# Unit test for function build_requests_session
def test_build_requests_session():
    assert(build_requests_session())


# Generated at 2022-06-26 01:22:21.407830
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger
    
    # Create instance
    logger = Logger('logger')
    logged_func_instance = LoggedFunction(logger)
    
    # Call method
    logged_func_instance(test_case_0)

# Generated at 2022-06-26 01:22:24.881904
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = TestLogger()
    lf_0 = LoggedFunction(logger_0)

    @lf_0
    def func_0(arg_0, arg_1):
        return arg_0 + arg_1

    func_0(1, 1)


# Generated at 2022-06-26 01:22:26.383804
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:22:28.746384
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    unit_test_LoggedFunction___call__(format_arg, 'test_case_0')


# Generated at 2022-06-26 01:22:36.217933
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    #
    # Test Case 0:
    #
    # Test Case Description:
    #
    # Log function name and arguments, call function, log result.
    #
    # Invoke function 'format_arg' with a string argument.
    #
    # assert format_arg(var_0) == test_case_0_expected_value
    #
    test_case_0()

# Generated at 2022-06-26 01:22:46.543918
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = getLogger()
    logger.setLevel(INFO)
    handler = StreamHandler()
    handler.setFormatter(Formatter("%(message)s"))
    logger.addHandler(handler)
    logger.propagate = False

    def test_method(arg_0, arg_1=None):
        return arg_0 + arg_1

    logged_func = LoggedFunction(logger)(test_method)
    # test_method
    logged_func('test', '_method')
    logged_func('test_method', '_method')
    logged_func('test_method')
    logged_func('test_method', arg_1='_method')
    logged_func(arg_0='test_method', arg_1='_method')
    logged_func(arg_0='test_method')
    logged_func

# Generated at 2022-06-26 01:22:48.232839
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    str_0 = 'cs=cc'
    var_0 = format_arg(str_0)

# Generated at 2022-06-26 01:24:41.440331
# Unit test for method __call__ of class LoggedFunction

# Generated at 2022-06-26 01:24:45.795683
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction

    Expected result: format_arg() returns a string

    """
    str_0 = 'cs=cc'
    var_0 = format_arg(str_0)

    print(var_0)
    assert var_0 == "'cs=cc'"

# Generated at 2022-06-26 01:24:56.730292
# Unit test for function build_requests_session
def test_build_requests_session():
    # Mock the request.session.get
    @mock.patch('requests.sessions.Session.get')
    def _test_build_requests_session(mock_get, raise_for_status=True, retry=True):
        mock_get.return_value.raise_for_status.return_value = True
        mock_get.return_value.status_code = 200

        session = build_requests_session(raise_for_status, retry)

        # If raise_for_status is True, then the response should have raise for status hooked
        if raise_for_status:
            session.get('mock_url')
            assert mock_get.return_value.raise_for_status.call_count == 1

        # If retry is True, then the response should have a Retry object

# Generated at 2022-06-26 01:25:03.472539
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logging.basicConfig(
        format='%(asctime)s,%(msecs)d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
        datefmt='%Y-%m-%d:%H:%M:%S',
        level=logging.DEBUG,
    )
    logger = logging.getLogger(__name__)
    test_case_0()

# Generated at 2022-06-26 01:25:07.287407
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:25:10.244001
# Unit test for function build_requests_session
def test_build_requests_session():
    print('Testing function build_requests_session...')
    ses = build_requests_session()
    print(ses)
    assert isinstance(ses, Session)
    ses.close()



# Generated at 2022-06-26 01:25:19.810639
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.propagate = False

    # Test case 0
    # test that the logger will print out the same string as the format_arg
    case_0 = format_arg(test_case_0.__name__)
    print("testcase 0: " + case_0)
    logger.debug(case_0)

    # Test case 1
    # test that the logger will print out the correct format after being decorated
    case_1 = LoggedFunction(logger)

# Generated at 2022-06-26 01:25:27.524866
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    decorator = LoggedFunction(logger)

    @decorator
    def f_0(in_0, in_1=1, in_2=2, in_3=3):
        x = in_0 + in_1 + in_2 + in_3
        print(x)
        return x

    @decorator
    def f_1(in_0=1, in_1=2, in_2=3, in_3=4):
        x = in_0 + in_1 + in_2 + in_3
        print(x)
        return x
