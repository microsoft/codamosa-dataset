

# Generated at 2022-06-26 01:15:28.090387
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test case 0
    print("Start test case 0")
    test_case_0()
    print("End test case 0\n")

test_LoggedFunction___call__()

# Generated at 2022-06-26 01:15:32.177511
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = -1639.3
    logged_function_0 = LoggedFunction(float_0)
    try:
        logged_function_0.__call__(test_case_0)
    except TypeError as e:
        print("Exception: " + str(e))
    else:
        print("No Exception")


# Generated at 2022-06-26 01:15:36.996163
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = -1639.3
    logged_function_0 = LoggedFunction(float_0)
    value_0 = [1]
    value_1 = logged_function_0(list.__add__, value_0)
    assert value_1 == [1]


# Generated at 2022-06-26 01:15:38.945511
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = -1639.3
    logged_function_0 = LoggedFunction(float_0)
    func = lambda: None
    result_0 = logged_function_0(func)
    assert result_0.__name__ == func.__name__


# Generated at 2022-06-26 01:15:44.275422
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test with an arbitrary object for attribute logger
    logging = logging
    logger = logging.getLogger()
    logged_function_0 = LoggedFunction(logger)
    func = test_case_0
    logged_func = logged_function_0.__call__(func)
    # pytest.raises(AssertionError, logged_function_0)
    assert callable(logged_func)
    assert logged_func.__name__ == "test_case_0"
    assert logged_func.__module__ == "conftest"
    assert logged_func.__doc__ == None

# Generated at 2022-06-26 01:15:46.569668
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, True)
    assert session != None



# Generated at 2022-06-26 01:15:50.676878
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import requests.adapters

    def test_RequestsSession_0():
        float_0 = -29.5
        session_0 = build_requests_session(True, True)
        assert isinstance(session_0, requests.Session), "RequestsSession_0"

    test_RequestsSession_0()




# Generated at 2022-06-26 01:15:51.736105
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()



# Generated at 2022-06-26 01:15:57.025603
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = -1639.3
    logged_function_0 = LoggedFunction(float_0)
    float_1 = -1639.3
    logged_function_1 = LoggedFunction(float_1)
    float_2 = -1639.3
    logged_function_2 = LoggedFunction(float_2)

    @logged_function_0
    def foo(a, b, c, d=4, e: str = "5"):
        return a + b + c + d + e

    @logged_function_1
    @logged_function_2
    def bar(a, b, c, d=4, e: str = "5"):
        return a + b + c + d + e

    foo("1", "2", "3")
    bar("1", "2", "3")


# Generated at 2022-06-26 01:16:09.006358
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = 0.00184783
    float_1 = -0.00184783
    float_2 = 0.00184783
    float_3 = -0.00184783
    float_4 = -0.00184783
    float_5 = -0.00184783
    float_6 = 0.00184783
    float_7 = 0.00184783
    float_8 = -0.00184783
    float_9 = 0.00184783
    float_10 = -0.00184783
    float_11 = 0.00184783
    str_0 = "test"
    str_1 = "test"
    str_2 = "test"
    str_3 = "test"
    str_4 = "test"
    str_5

# Generated at 2022-06-26 01:16:19.828609
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = -1639.3
    logged_function_0 = LoggedFunction(float_0)
    str_0 = 'xyzztzqxrn'
    def function_0(* args, ** kwargs):
        return str_0
    function_1 = logged_function_0(function_0)
    assert function_1() == 'xyzztzqxrn'

# Generated at 2022-06-26 01:16:25.519459
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = -1639.3
    logged_function_0 = LoggedFunction(float_0)
    logged_function_1 = logged_function_0.__call__(logged_function_0)
    assert logged_function_1.__name__ == 'test_LoggedFunction___call__'


# Generated at 2022-06-26 01:16:32.892246
# Unit test for function build_requests_session
def test_build_requests_session():
    # Check the case of raise_for_status=True and retry=True
    session = build_requests_session(raise_for_status=True, retry=True)

# Generated at 2022-06-26 01:16:37.247335
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_0(self):
            test_case_0()
            
    suite = unittest.TestSuite()
    suite.addTest(TestLoggedFunction("test_0"))
    unittest.TextTestRunner().run(suite)

# Generated at 2022-06-26 01:16:37.975353
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session()


# Generated at 2022-06-26 01:16:45.052344
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Check if function returns the correct value when handling an exception
    assert test_case_0() == None


# Generated at 2022-06-26 01:16:51.245715
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = -1639.3
    logged_function_0 = LoggedFunction(float_0)

    @logged_function_0
    def func_0(arg_0, arg_1):
        return arg_0 + arg_1

    # This will print:
    # func_0(-1, 2)
    # func_0 -> 1
    print(func_0(-1, 2))

# Generated at 2022-06-26 01:16:52.438173
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()


# Generated at 2022-06-26 01:16:56.890673
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    float_0 = 0.0
    logged_function_0 = LoggedFunction(float_0)
    float_1 = float()
    float_2 = float()
    float_3 = float_1 * float_2
    LoggedFunction___call___0(logged_function_0, float_3)


# Generated at 2022-06-26 01:17:06.050459
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Should return a function which logs its call to the logger
    def test_function(a, b):
        # Dummy function
        pass
    logger = Mock()
    logged_function = LoggedFunction(logger)
    logged_test_function = logged_function(test_function)
    logged_test_function("Hello", "world")
    assert logger.debug.call_count == 2
    assert "test_function('Hello', 'world')" in logger.debug.call_args_list[0][0][0]
    assert "test_function -> None" in logger.debug.call_args_list[1][0][0]

if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:20.820353
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()

# Generated at 2022-06-26 01:17:29.006800
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test for method ``__call__`` of class ``LoggedFunction``
    """
    # NOTE: This unit test requires that response.raise_for_status() is called, so we are providing an argument to
    # build_request_session()
    test_session = build_requests_session(raise_for_status=True)
    # Create logger
    logger = logging.getLogger(__name__)
    # Add logger handler
    logger.addHandler(logging.StreamHandler(stream=sys.stdout))
    # Set logger level
    logger.setLevel(logging.DEBUG)
    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)
    # Wrap the function in the LoggedFunction
    _get = logged_function(_get)
    # Call the wrapped get() method

# Generated at 2022-06-26 01:17:35.765541
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = LoggedFunction(logging.Logger(__name__))


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:45.709926
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    def test_func0(*args, **kwargs):
        print(f"{args} {kwargs}")

    class TestLoggedFunction(unittest.TestCase):
        def test_0(self):
            logger = logging.getLogger("TestLoggedFunction.test_0")
            logger.setLevel(logging.DEBUG)
            logged_func = LoggedFunction(logger)(test_func0)
            logged_func(1, 2, 3, **{'name': 'joe', 'age': 18})
            self.assertEqual(1, 1)

    unittest.main()


test_case_0()
test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:54.131906
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    assert type(session_0) == Session
    session_0 = build_requests_session(False)
    assert type(session_0) == Session
    session_0 = build_requests_session(retry=False)
    assert type(session_0) == Session
    session_0 = build_requests_session(retry=5)
    assert type(session_0) == Session
    session_0 = build_requests_session(retry=Retry())
    assert type(session_0) == Session
    session_0 = build_requests_session(raise_for_status=False)
    assert type(session_0) == Session


# Generated at 2022-06-26 01:18:00.558626
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    '''Test LoggedFunction.__call__'''

    logger_0 = logging.getLogger(__name__)
    test_case_0()

    test_logger_0 = logging.Logger(__name__, logging.INFO)
    @LoggedFunction(test_logger_0)
    def test_func_0(arg1, keyword_arg1=0):
        return arg1 + keyword_arg1
    assert test_func_0(1, keyword_arg1=3) == 4


# Generated at 2022-06-26 01:18:05.883283
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    @LoggedFunction(logger=None)
    def func_0():
        pass

    @LoggedFunction(logger=None)
    def func_1(a, b, c):
        pass

    @LoggedFunction(logger=None)
    def func_2(a, b, c, d=4):
        return d


# Generated at 2022-06-26 01:18:14.489981
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from sys import stdout

    logger = getLogger(__name__)
    logger.setLevel(10)
    logger.addHandler(StreamHandler(stream=stdout))

    # Test case 0
    def test_case_0():
        session_0 = build_requests_session()



if __name__ == "__main__":
    from logging import getLogger
    from sys import stdout

    logger = getLogger(__name__)
    logger.setLevel(10)
    logger.addHandler(StreamHandler(stream=stdout))

    # Test case 0
    test_case_0()

# Generated at 2022-06-26 01:18:22.055227
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    # Arrange
    import logging

    from unittest import mock

    logger = logging.getLogger("PythonUtilsTest")
    logger.setLevel(logging.DEBUG)
    test_case = LoggedFunction(logger)

    class Target:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        @test_case
        def test_func(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            return tuple([self.args, self.kwargs])

    # Act
    target = Target()

# Generated at 2022-06-26 01:18:36.416889
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_mock = MagicMock()
    func_mock = MagicMock()
    logged_func = LoggedFunction(logger_mock)(func_mock)
    logged_func(1, 2, 3, a=4, b=5, c=6)
    logger_mock.debug.assert_called_with(
        f"{logged_func.__name__}(1, 2, 3, a=4, b=5, c=6)"
    )
    func_mock.assert_called_with(1, 2, 3, a=4, b=5, c=6)
    logger_mock.debug.assert_called_with(f"{logged_func.__name__} -> None")

    func_return = MagicMock()
    func_mock.return_value = func

# Generated at 2022-06-26 01:18:50.610387
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test data for list args
    args_0 = [1, 2, 3]
    # Test data for dict kwargs
    kwargs_0 = {'a': 'a', 'b': 'b', 'c': 'c'}
    # SUT
    logger = logging.getLogger()
    mocked_logger = MagicMock()
    logger.debug = mocked_logger
    logged_function = LoggedFunction(logger)

    # Exercise
    logged_func = logged_function(build_requests_session)
    logged_func(args_0, **kwargs_0)

    # Verify
    mocked_logger.assert_called_once_with(
        "build_requests_session('1', '2', '3', a='a', b='b', c='c')"
    )
    #

# Generated at 2022-06-26 01:18:58.298448
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from ..Logger import Logger

    logger_0 = Logger("logger_0", {"general": {"log_level": "debug"}})
    logger = getLogger("logger_0")
    logged_function_0 = LoggedFunction(logger)
    session_0 = build_requests_session()

# Generated at 2022-06-26 01:19:06.202326
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def debug(self, msg):
            print(msg)

    logger = DummyLogger()
    logged_function = LoggedFunction(logger)

    @logged_function
    def func_0(x):
        print(x)

    func_0(1)
    func_0(1, 2, 3)
    func_0(x=1, y=2)
    func_0(x=1, y=2, z=3)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 01:19:12.171713
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)
    @LoggedFunction(logger)
    def test_method(a, b, c=3):
        return a+b+c
    result = test_method(1, 2)
    assert result == 6
    logger.removeHandler(stream_handler)

# Generated at 2022-06-26 01:19:14.517637
# Unit test for function build_requests_session
def test_build_requests_session():

    session = build_requests_session(retry=1)
    print(type(session))



# Generated at 2022-06-26 01:19:24.088019
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class fake_func:
        __name__ = 'fake_func'
        def __call__(self): pass
    class fake_logger:
        def debug(self, msg):
            print(msg)

    class fake_arg:
        def __str__(self):
            return 'fake_arg'

    class fake_kwarg:
        def __str__(self):
            return 'fake_kwarg'

    fake_func_obj = fake_func()
    fake_logger_0 = fake_logger()
    fake_arg_0 = fake_arg()
    fake_kwarg_0 = fake_kwarg()
    fake_args_tuple = (fake_arg_0,)
    fake_kwargs_dict = {'fake_kwarg_key': fake_kwarg_0}

    logged_func_

# Generated at 2022-06-26 01:19:30.617068
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    session_0.proxies = {
        "http": "http://127.0.0.1:8080",
        "https": "http://127.0.0.1:8080",
    }
    session_0.verify = False
    response = session_0.get("https://github.com/")
    assert response.text.find("https://github.com") > 0

# Generated at 2022-06-26 01:19:37.921360
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging
    import requests

    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def my_func(a, b, c):
        return a * b * c

    my_func(3, 6, 9)
    my_func(a=3, b=6, c=9)
    my_func(3, b=6, c=9)
    my_func(3, b=6, c=9)



# Generated at 2022-06-26 01:19:41.231659
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from hcm.common.logging_util import get_logger
    import logging
    logger = get_logger(logging.DEBUG, __name__)
    LoggedFunction_instance = LoggedFunction(logger)
    LoggedFunction_instance.__call__(test_case_0)

# Generated at 2022-06-26 01:19:51.351521
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import unittest.mock
    logger = unittest.mock.Mock()

    def func(*args, **kwargs):
        pass

    logged_func = LoggedFunction(logger).__call__(func)

    logged_func()
    logger.debug.assert_called_with("func()")

    logged_func('hello', a=1)
    logger.debug.assert_called_with("func(hello, a='1')")

    logged_func(1, 2, a=3, b=4)
    logger.debug.assert_called_with("func(1, 2, a='3', b='4')")


# Generated at 2022-06-26 01:20:05.897722
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pathlib import Path
    from logging import DEBUG, getLogger, FileHandler

    from .logging import LEVEL_NAMES
    from .logging import create_logger

    log_folder = Path(".logs")
    if not log_folder.exists(): 
        log_folder.mkdir()
    log_file = log_folder / "test_LoggedFunction___call__.log"
    if log_file.exists():
        log_file.unlink()
    log_file.touch()
    logger = getLogger("test")
    logger.setLevel(DEBUG)
    file_hanlder = FileHandler(log_file)
    logger.addHandler(file_hanlder)
    create_logger(level=DEBUG)
    logged_function = LoggedFunction(logger=logger)

# Generated at 2022-06-26 01:20:14.446223
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # 1. Create a logger,
    logger_0 = logging.getLogger(__name__)

    # 2. Create a LoggedFunction,
    loggedfunction_0 = LoggedFunction(logger_0)

    @loggedfunction_0
    def func_0(a, b, c, d=4, e=5):
        return (a, b, c, d, e)

    # 3. Invoke the __call__ of LoggedFunction,
    func_1 = loggedfunction_0.__call__(func_0)

    # 4. Invoke func,
    func_1(1, 2, 3)
    func_1(1, 2, 3,d=4)
    func_1(1, 2, 3,d=4, e=5)
    func_1(1, 2, 3, 4, 5)

# Generated at 2022-06-26 01:20:29.488353
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test case 0: session_0 = build_requests_session()
    session_0 = build_requests_session(raise_for_status=True, retry=True)
    assert (
        isinstance(session_0, Session)
    ), "In test case 0, session_0 should be instance of Session."

    # Test case 1: session_1 = build_requests_session(raise_for_status=True, retry=Retry(total=2))
    session_1 = build_requests_session(raise_for_status=True, retry=Retry(total=2))
    assert (
        isinstance(session_1, Session)
    ), "In test case 1, session_1 should be instance of Session."

# Generated at 2022-06-26 01:20:42.500768
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from datetime import datetime
    from requests import get
    from requests.adapters import HTTPAdapter
    from requests.exceptions import RetryError
    from requests.packages.urllib3.util.retry import Retry
    from sys import stderr
    from unittest.mock import patch
    from urllib3.util.retry import RetryError

    @LoggedFunction(logger=logging.getLogger("TestLogger"))
    def add(a, b):
        return a + b

    # Test normal log output
    patch("sys.stdout", stderr).start()
    logging.basicConfig(stream=stderr, level=logging.DEBUG, format="%(message)s")
    assert add(1, 2) == 3

    # Test behavior when exceptions occurs in the log call
   

# Generated at 2022-06-26 01:20:50.172896
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class LoggerMock:
        
        def __init__(self):
            self._log = []

        def debug(self, msg):
            self._log.append(msg)

        def get_log(self):
            return ';\n'.join(self._log)
    from tempfile import TemporaryFile
    from pprint import pformat
    from etl.utilities.logged_function import LoggedFunction
    from unittest import mock
    import sys, os

    _test_case_0_test_function_0_actual_result_0 = None

# Generated at 2022-06-26 01:20:55.395722
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    lf = LoggedFunction(logging.getLogger('debug'))
    @lf
    def foo():
        print('foo')
    foo()
    @lf
    def foo2(x, y, z=1):
        print(x, y, z)
    foo2(4, 5, z=6)


# Generated at 2022-06-26 01:21:10.781462
# Unit test for function build_requests_session
def test_build_requests_session():
    define = [
        (True, True),
        (True, 3),
        (True, Retry()),
        (False, True),
        (False, 3),
        (False, Retry()),
    ]
    for raise_for_status, retry in define:
        s = build_requests_session(raise_for_status, retry)
        assert (raise_for_status and len(s.hooks["response"]) == 1) or (
            not raise_for_status and len(s.hooks["response"]) == 0
        )
        assert s.adapters is not None


if __name__ == "__main__":
    session = build_requests_session()

    url = "http://httpbin.org/get"
    result = session.get(url)

# Generated at 2022-06-26 01:21:19.757185
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger(object):
        def debug(self, msg):
            setattr(MockLogger, "debug_msg", msg)
    def mocked_func(arg1, arg2, karg1="karg1", karg2=True):
        return f"arg1={arg1}; arg2={arg2}; karg1={karg1}; karg2={karg2}"
    logger = MockLogger()
    logged_func = LoggedFunction(logger)
    logged_func = logged_func(mocked_func)
    arg1 = 1
    arg2 = 2
    karg1 = "value1"
    karg2 = False
    result = logged_func(arg1, arg2, karg1=karg1, karg2=karg2)

# Generated at 2022-06-26 01:21:24.351067
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger(__name__)
    logger_0.setLevel(logging.DEBUG)
    logger_0.addHandler(logging.StreamHandler())
    test_case_0 = LoggedFunction(logger_0)
    test_case_0(test_case_0)

test_LoggedFunction___call__()
test_case_0()

# Generated at 2022-06-26 01:21:29.981839
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from .logger import DefaultLogger
    from .logger import get_logger

    logger_0 = DefaultLogger()
    logger_1 = get_logger("my_logger")
    logger_2 = get_logger("my_logger")


    @LoggedFunction(logger_2)
    def f1(x, y, z = 100):
        return x + y + z

    f1("hello", "world")

# Generated at 2022-06-26 01:21:37.803468
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    my_logged_function = LoggedFunction(logger)
    my_logged_function(test_case_0)(session_0)
    print('Unit test end')

# Generated at 2022-06-26 01:21:47.407400
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # func call test case
    @LoggedFunction(logger)
    def test_case_1(a, b):
        return a + b

    assert test_case_1(1, 2) == 3

    # func call with kwargs test case
    @LoggedFunction(logger)
    def test_case_2(a, b):
        return a + b

    assert test_case_2(1, b=2) == 3

if __name__ == '__main__':
    logger = logging.getLogger('test_requests_utils')
    logger.setLevel(level=logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler = logging.StreamHandler()

# Generated at 2022-06-26 01:21:53.845977
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Dummy variables
    logger = None
    func = None
    args = None
    kwargs = None

    # Case 0
    try:
        logger = None
        func = None
        args = None
        kwargs = None

        result = LoggedFunction(logger).__call__(func)(*args, **kwargs)
        assert result is None

    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 01:22:05.709928
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from __builtin__ import unicode
    from logging import Logger
    from logging import StreamHandler
    from sys import stdout
    from uuid import uuid4

    from gotomato.extras import LoggedFunction

    # Prepare test logger
    logger = Logger(f"test_case_{uuid4().hex}")
    logger.addHandler(StreamHandler(stdout))

    # Test cases
    @LoggedFunction(logger)
    def test_case_1(arg1):
        return "result"

    test_case_1(1)
    # test_case_1 -> result

    @LoggedFunction(logger)
    def test_case_2(arg1, arg2):
        return "result"

    test_case_2(1, "abc")
    # test_case_2(1, '

# Generated at 2022-06-26 01:22:14.614006
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Given
    logger = logging.getLogger('test_LoggedFunction___call__')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    def add(a: int, b: int):
        return a + b

    # When
    logged_add = LoggedFunction(logger)(add)

    # Then
    assert logged_add(1, 2) == 3

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:22:18.175804
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    # session_1 = build_requests_session(retry=False)
    # session_2 = build_requests_session(retry=3)
    # session_3 = build_requests_session(retry=Retry(total=3, backoff_factor=0))
    # session_4 = build_requests_session(retry=True)


# Generated at 2022-06-26 01:22:28.355898
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    __call__(func) -> logged_func

        Wrap func so that its arguments are logged before it is executed, and
        its return value is logged afterwards.

        :param func: Function to wrap.
        :return: Wrapped function.
    """
    print("Testing LoggedFunction.__call__()")
    
    # Test for Invalid Input
    f = LoggedFunction()
    try:
        @f
        def func_1():
            pass
        assert False
    except Exception:
        pass

    # Normal Case
    @LoggedFunction
    def func_2():
        pass
    assert True

    # Normal Case
    @LoggedFunction()
    def func_3():
        pass
    assert True


# unit test for method __init__ of class LoggedFunction

# Generated at 2022-06-26 01:22:31.149592
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    a_logger = logging.getLogger()

    a = LoggedFunction(a_logger)
    a__call__result = a.__call__(test_case_0)

# Generated at 2022-06-26 01:22:32.440587
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:22:41.155541
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func = mock.MagicMock()

    logger = mock.MagicMock()
    # called method once
    logger.debug.assert_called_once()

    lf = LoggedFunction(logger)
    logged_func = lf.__call__(func)

    # called function once
    logged_func.assert_called_once()

    # called method twice
    logger.debug.assert_called_twice()

test_case_0()

# Generated at 2022-06-26 01:22:53.119999
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Create a logger for logging debug message
    logger = logging.getLogger('')
    logger.setLevel(logging.DEBUG)

    # Create a stream handler for the logger
    hdlr = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    hdlr.setFormatter(formatter)

    # Apped the stream handler to logger
    logger.addHandler(hdlr)

    # Create an instance of LoggedFunction
    logged_function_0 = LoggedFunction(logger)

    # Call the __call__ method of LoggedFunction instance
    def func(x, y):
        return x + y
    logged_function_1 = logged_function_0.__call__(func)

    # Call the function by the

# Generated at 2022-06-26 01:22:58.131090
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("TestLogger")
    function = LoggedFunction(logger)

    def func(*args, **kwargs):
        return args, kwargs

    logged_func = function.__call__(func)

    args = (1, 2)
    kwargs = {"a": "1", "b": "2"}
    expected_result = (args, kwargs)

    result = logged_func(*args, **kwargs)

    assert result == expected_result

# Generated at 2022-06-26 01:23:06.717539
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from unittest.mock import patch
    from logutils.queue import QueueListener

    with patch('helpers.logged_function.logging.warning') as mock_warning:

        # Setup a logger
        logger = getLogger(__name__ + '.1')
        queue = QueueListener()
        queue.start()
        logger.addHandler(queue)

        # Decorate a function
        @LoggedFunction(logger)
        def test_function(text):
            return text.upper()

        # Unit test
        test_function('hello')

    assert queue.queue.get().getMessage() == 'test_function(\'hello\')'
    assert mock_warning.called is False



# Generated at 2022-06-26 01:23:13.431194
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    def err(msg):
        raise Exception(msg)
    # err.__name__ = 'err' # You can try uncomment this line to compare errors
    logged_err = LoggedFunction(log_error)(err)
    try:
        logged_err('This is a test error')
    except Exception as e:
        log_error.error(f'Exception occurred in test_LoggedFunction___call__: {e}')

# This function is used for test logging

# Generated at 2022-06-26 01:23:22.353185
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func_0(self, *args, **kwargs):
        pass
    logger = logging.Logger(name='test_Logger')
    test_cases = [{
        "name": "case_0",
        "params": {
            "self": LoggedFunction(logger),
            "func": test_func_0,
            "args": (),
            "kwargs": {},
        },
        "expected": {},
    }]

    def _run_case(c):
        return c['expected']['result']

    for case in test_cases:
        actual = _run_case(case)


if __name__ == "__main__":
    logging.basicConfig(format='TEST %(message)s')

    test_case_0()

    #    test_LoggedFunction___call

# Generated at 2022-06-26 01:23:31.653979
# Unit test for method __call__ of class LoggedFunction

# Generated at 2022-06-26 01:23:40.410824
# Unit test for function build_requests_session
def test_build_requests_session():
    with pytest.raises(ValueError) as e:
        session_1 = build_requests_session(retry=Retry())

    with pytest.raises(ValueError) as e:
        session_2 = build_requests_session(retry=1)

    with pytest.raises(ValueError) as e:
        session_3 = build_requests_session(retry=Retry(total=0))

    with pytest.raises(ValueError) as e:
        session_4 = build_requests_session(retry=Retry(total=-1))

    with pytest.raises(ValueError) as e:
        session_5 = build_requests_session(retry=0)

    with pytest.raises(ValueError) as e:
        session_6 = build_requ

# Generated at 2022-06-26 01:23:43.038333
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("name")
    func = lambda x: x + 5
    lf = LoggedFunction(logger)
    lf(func)
    func_rst = lf(func)
    assert func_rst(1) == 6

# Generated at 2022-06-26 01:23:45.852107
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = Logger(LogLevel.DEBUG, True)
    loggedFunction_0 = LoggedFunction(logger_0)
    session_0 = build_requests_session()
    loggedFunction_0(session_0)


test_case_0()

# Generated at 2022-06-26 01:23:48.633489
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger)
    def test_LoggedFunction___call__():
        pass
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:24:06.679474
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def debug(self, message):
            print(message)

    @LoggedFunction(TestLogger())
    def get_test(test_id, has_test = False):
        return test_id if has_test else None

    test_id = 1
    assert get_test(test_id) == None
    assert get_test(test_id, True) == 1

if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:24:11.831139
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("hello")

    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s: %(levelname)s: %(message)s"))
    logger.addHandler(handler)

    logger.setLevel(logging.DEBUG)


    @LoggedFunction(logger)
    def abc(arg1, arg2):
        return "hello"


    abc("a", "b")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:24:14.753463
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_2 = build_requests_session()
    session_3 = build_requests_session()
    session_4 = build_requests_session()
    session_5 = build_requests_session(retry=3)
    session_6 = build_requests_session(retry=False)

# Generated at 2022-06-26 01:24:15.912812
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logged_function = build_requests_session()

# Generated at 2022-06-26 01:24:24.516246
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Set logger
    logger = logging.getLogger()

    # Create LoggedFunction
    class_LoggedFunction_instance_0 = LoggedFunction(logger)

    # Create LoggedFunction
    class_LoggedFunction_instance_1 = LoggedFunction(logger)

    # Create LoggedFunction
    class_LoggedFunction_instance_2 = LoggedFunction(logger)

    # Create LoggedFunction
    class_LoggedFunction_instance_3 = LoggedFunction(logger)

    # Create LoggedFunction
    class_LoggedFunction_instance_4 = LoggedFunction(logger)

    # Create LoggedFunction
    class_LoggedFunction_instance_5 = LoggedFunction(logger)

    # Create LoggedFunction
    class_LoggedFunction_instance_6 = LoggedFunction(logger)

    # Create LoggedFunction
    class_LoggedFunction_instance_7

# Generated at 2022-06-26 01:24:33.734942
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import datetime

    class LoggingCapturingStream(io.StringIO):
        def __init__(self, stream, level=logging.DEBUG):
            self.stream = stream
            self.level = level

        def write(self, message):  # pylint: disable=missing-function-docstring
            if message.strip():
                self.stream.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S}: {message.strip()}")

        def flush(self):  # pylint: disable=missing-function-docstring
            self.stream.flush()

        def close(self):  # pylint: disable=missing-function-docstring
            self.stream.close()


# Generated at 2022-06-26 01:24:44.415745
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger)
    def function_0(param_0, param_1, param_2, param_3):
        session_0 = build_requests_session(param_0, param_1)
        session_0.add_hooks(param_2)
        session_0.mount(param_3, param_4)

    session_0 = build_requests_session()
    session_0.mount(param_0, param_1)
    function_0(param_2, 'https://', True, param_3)
    function_0(param_4, param_5, param_6, param_7, param_8=param_9)
    function_0(param_10, 'http://', param_11, param_12, param_13)

# Generated at 2022-06-26 01:24:46.399762
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func = LoggedFunction(logger=logging.getLogger("test"))(func=test_case_0)
    func()



# Generated at 2022-06-26 01:24:54.438288
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def debug(self, msg):
            print(msg)

    def func(a, b=3):
        return (a, b)

    @LoggedFunction(Logger())
    def func2(a, b=3):
        return (a, b)

    func2(1)
    func2(1, 4)
    func(1, 4)


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:25:00.284443
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from fortnitepy.http import FortniteClient

    session_0 = build_requests_session()