

# Generated at 2022-06-26 01:15:29.802175
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from testcase import test_case_0
    from depthy import logger
    import inspect
    import functools

    def get_func_info(func):
        func_info_dict = dict()
        func_info_dict["__call__"] = inspect.iscoroutinefunction(func)
        func_info_dict["__name__"] = func.__name__
        if func.__name__ == "get_func_info":
            func_info_dict["__code__"] = func.__code__
            func_info_dict["__defaults__"] = func.__defaults__
            func_info_dict["__globals__"] = func.__globals__
            func_info_dict["__kwdefaults__"] = func.__kwdefaults__

# Generated at 2022-06-26 01:15:34.616235
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger_0 = logging.getLogger()
    def function_0(_arg_0, _arg_1):
        return _arg_0 + _arg_1
    LoggedFunction_0 = LoggedFunction(logger_0)
    if not LoggedFunction_0.__call__(function_0)(1, 2):
        raise AssertionError



# Generated at 2022-06-26 01:15:41.511722
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.debug_logs = list()

        def debug(self, msg):
            self.debug_logs.append(msg)

    def test_func():
        pass

    logger = MockLogger()
    logged_function = LoggedFunction(logger)
    logged_func = logged_function(test_func)
    logged_func()
    assert len(logger.debug_logs) == 1
    assert logger.debug_logs[0] == "test_func()"



# Generated at 2022-06-26 01:15:46.467170
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    session_0 = build_requests_session(raise_for_status=True)
    session_0 = build_requests_session(retry=2)
    session_0 = build_requests_session(raise_for_status=True, retry=2)
    session_1 = build_requests_session(raise_for_status=True, retry=False)


# Generated at 2022-06-26 01:15:54.251016
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    # Create logger
    from logging import getLogger, NOTSET
    logger = getLogger("_test_LoggedFunction___call__")
    logger.setLevel(NOTSET)

    # Create LoggedFunction
    from pytorch_lightning.utilities.exceptions import MisconfigurationException
    logged_function = LoggedFunction(logger)

    # Create test function
    def test_function(arg1, arg2, arg3=None):
        return "TEST"

    # Should be able to decorate a test function
    logged_test_function = logged_function(test_function)

    # Log just before calling the test function
    logged_test_function("test1", "test2", arg3="test3")

    # This should throw an exception

# Generated at 2022-06-26 01:15:57.597532
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


# Generated at 2022-06-26 01:16:00.333535
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    assert session_0.hooks == {"response":lambda r, *args, **kwargs: r.raise_for_status()}


# Generated at 2022-06-26 01:16:11.614505
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from json import dumps
    from requests import Response
    from unittest.mock import patch
    from unittest.mock import MagicMock
    import json
    import pytest
    with open("test/test-data/test-data-test_case_0.json") as data_file:
        data_expected_0 = Response()
        data_expected_0.status_code = 200
        data_expected_0._content = json.loads(data_file.read())['requests-Session-get-python_web.hangout.org-default']
        data_expected_0.encoding = 'utf-8'
    # You can debug "test_case_0" to explore it in the test runner.

# Generated at 2022-06-26 01:16:22.536579
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger()
    loggedfunction_0 = LoggedFunction(logger_0)
    def function_0(*args, **kwargs):
        return args
    logged_function_0 = loggedfunction_0(function_0)
    assert type(logged_function_0) == functools._wraps_Holder
    assert logging.getLogger(logged_function_0.__module__).getEffectiveLevel() == 10
    assert logged_function_0.__module__ == "__main__"
    assert logged_function_0.__wrapped__ == function_0
    assert logged_function_0.__name__ == "function_0"
    args_0 = (1, 2, 3)
    kwargs_0 = {"a": "b"}
    args_1 = (1, 2)

# Generated at 2022-06-26 01:16:29.420231
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = Mock(name='logger_0')
    function_0 = Mock(name='function_0')
    function_0.__name__ = Mock(name='function_0.__name__')
    logged_func_0 = LoggedFunction(logger_0)(function_0)
    args_0 = Mock(name='args_0')
    kwargs_0 = Mock(name='kwargs_0')
    logged_func_0(*args_0, **kwargs_0)

# Generated at 2022-06-26 01:16:38.098093
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test case 0
    session_0 = build_requests_session(
        raise_for_status=True,
        retry=Retry(total=5, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504]),
    )
    assert isinstance(session_0.adapters.HTTPAdapter, HTTPAdapter)

    # Test case 1, multiple mount with different retry
    session_1 = build_requests_session()
    assert isinstance(session_1.adapters.HTTPAdapter, HTTPAdapter)
    assert isinstance(session_1.adapters.HTTPAdapter.max_retries, Retry)
    assert session_1.adapters.HTTPAdapter.max_retries.total == 3
    assert session_1.adapters.HTTPAdapter.max_retries.backoff_factor == 0.

# Generated at 2022-06-26 01:16:46.648597
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def a(c, d):
        return 3
    LoggedFunction_0 = LoggedFunction('logger_0')
    assert LoggedFunction_0.__call__(a)(1,2) == 3
    # assert LoggedFunction_0.__call__(a) == '<function a at 0x7f62b1e88c80>'

# Generated at 2022-06-26 01:16:52.577381
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import os

    def test_function(a, b=1, c=2):
        return a + b + c

    logging.basicConfig(filename=os.devnull)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    result = LoggedFunction(logger)(test_function)(1, 2, 3)
    assert result == 6

# Generated at 2022-06-26 01:17:01.115181
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def _func(alpha, bravo=None):
        pass
    
    class _MyLogger:
        def __init__(self):
            self._data = ''
        
        def debug(self, msg):
            self._data += msg
        
        def get(self):
            return self._data
    
    logger = _MyLogger()
    log_func = LoggedFunction(logger)
    
    # test zero arg
    result = log_func(_func)
    assert result() == None
    assert logger.get() == '_func()'
    
    # test one arg
    logger = _MyLogger()
    log_func = LoggedFunction(logger)
    result = log_func(_func)
    assert result('one') == None

# Generated at 2022-06-26 01:17:02.411693
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # TODO: Test method LoggedFunction.__call__()
    pass

# Generated at 2022-06-26 01:17:12.330876
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    logger.debug("test_LoggedFunction___call__")
    logger.debug("Entering build_requests_session")
    session = build_requests_session()
    logger.debug("Exited build_requests_session")
    session_0 = LoggedFunction(logger)(build_requests_session)()
    assert not (session != session_0)


if __name__ == "__main__":
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    test_case_0()



# Generated at 2022-06-26 01:17:15.679501
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger("test")
    logger.disabled = True
    logged_function = LoggedFunction(logger)
    def test_function(para_1, para_2, para_3=4, para_4=5, *args, **kwargs):
        return str(para_1) + str(para_2) + str(para_3) + str(para_4) + str(args) + str(kwargs)
    result = logged_function.__call__(test_function)

# Generated at 2022-06-26 01:17:22.828026
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = None # TODO - implement me
    func = lambda self, x: x

# Generated at 2022-06-26 01:17:34.899513
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create mocked logger
    mock_logger = mock.Mock()
    # Create LoggedFunction
    logged_function_0 = LoggedFunction(mock_logger)
    # Create mock function
    mock_func = mock.Mock()
    # Call __call__
    result = logged_function_0.__call__(mock_func)("Test", a="Test", b="Test")
    # Assertions
    mock_logger.debug.assert_called_with(
        f"{mock_func.__name__}('Test', a='Test', b='Test')"
    )
    mock_func.assert_called_with("Test", a="Test", b="Test")
    assert (mock_logger.debug.call_count == 1)
    assert (mock_func.call_count == 1)

# Generated at 2022-06-26 01:17:44.541786
# Unit test for function build_requests_session
def test_build_requests_session():

    # Test case: Test for invalid parameter types
    with pytest.raises(ValueError, match=r".*retry*."):
        build_requests_session(retry = "")
    with pytest.raises(ValueError, match=r".*retry*."):
        build_requests_session(retry = 3.0)

    # Test case: Test for normal session creation
    session_1 = build_requests_session()
    assert session_1 is not None

    # Test case: Test for session creation with retries
    session_2 = build_requests_session(retry = 3)
    assert session_2 is not None


# Generated at 2022-06-26 01:17:52.528212
# Unit test for function build_requests_session
def test_build_requests_session():
    response = build_requests_session()
    print(response)

if __name__ == '__main__':
    test_build_requests_session()

# Generated at 2022-06-26 01:17:53.709728
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # TODO:
    pass
    # session_0 = build_requests_session()

# Generated at 2022-06-26 01:17:55.127601
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)



# Generated at 2022-06-26 01:17:59.888183
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logging.getLogger("test_logger"))
    def foo(x, y=0, *, z=0):
        return x + y + z

    foo(1, y=1, z=1)
    foo(1, 1, z=1)
    foo(1, 1)


# Generated at 2022-06-26 01:18:09.272110
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test input arguments, return type and return value
    logger = logging.getLogger(__name__)

    def test_func_1(arg1, arg2=None, arg3=None):
        pass

    logged_func_1 = LoggedFunction(logger)(test_func_1)
    assert inspect.isfunction(logged_func_1)
    assert logged_func_1.__name__ == "test_func_1"
    assert logged_func_1.__doc__ == test_func_1.__doc__
    # Test execution
    logged_func_1(None, None)
    logged_func_1(None, None, None)



# Generated at 2022-06-26 01:18:17.988728
# Unit test for function build_requests_session
def test_build_requests_session():
    for raise_for_status in [True, False]:
        for retry in [None, True, 2, Retry(total=10, status=40)]:
            session = build_requests_session(raise_for_status, retry)

            assert(isinstance(session, Session))
            assert(session.hooks == {} or session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]})

            if retry:
                if isinstance(retry, bool):
                    retry = Retry()

                assert(isinstance(retry, Retry))
                assert(isinstance(session.adapters, dict))
                assert('http://' in session.adapters)
                assert('https://' in session.adapters)

# Generated at 2022-06-26 01:18:21.642733
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from sample_service.logging_utils import logger

    logger_0 = logger

    def func_0(*args, **kwargs):
        pass

    logged_func_0 = LoggedFunction(logger_0)(func_0)
    LoggedFunction.__call__(logged_func_0)



# Generated at 2022-06-26 01:18:36.039217
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import types

    class LoggedFunctionTest(unittest.TestCase):
        def setUp(self):
            self._logger = logging.getLogger("logger_0")
            self._logged_function = LoggedFunction(self._logger)

        def test_logged_function_type(self):
            @self._logged_function
            def func_0(param_0):
                return param_0

            self.assertTrue(type(func_0) == types.FunctionType)

        def test_logged_function(self):
            @self._logged_function
            def func_0(param_0):
                return param_0

            self.assertEqual(func_0(1), 1)

# Generated at 2022-06-26 01:18:39.327167
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def t(*args):
        print(args)

    f = LoggedFunction(None)
    @f
    def do_nothing(*args):
        pass

    do_nothing(1)


test_LoggedFunction___call__()

# Generated at 2022-06-26 01:18:46.071736
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    def my_func(x, y):
        return x + y

    my_func_logged = LoggedFunction(logger)(my_func)
    my_func_logged(1, 2)

    # Clean up logger
    logger.removeHandler(handler)

test_LoggedFunction___call__()

# Generated at 2022-06-26 01:19:07.255270
# Unit test for function build_requests_session
def test_build_requests_session():
    @LoggedFunction(logger = getLogger(__name__))
    def test_case_0(session, raise_for_status, retry):
        assert isinstance(session, Session), "session should be instance of Session"
        assert session.max_redirects == 30, "max_redirects should be 30"
        assert (
            session.hooks["response"] == [lambda r, *args, **kwargs: r.raise_for_status()]
        ) == raise_for_status, "raise_for_status should be set correctly"
        retry_count = 0
        if isinstance(retry, bool):
            retry_count = 3
        elif isinstance(retry, int):
            retry_count = min(retry, 3)

# Generated at 2022-06-26 01:19:13.359941
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import MagicMock
    logger_mock = MagicMock(logging.Logger)
    lf = LoggedFunction(logger_mock)

    # call decorator without argument
    @lf
    def add(a, b):
        return a + b

    add(1, 2)
    logger_mock.debug.assert_called_with("add(1, 2)")


# Generated at 2022-06-26 01:19:21.234889
# Unit test for function build_requests_session
def test_build_requests_session():
    test_cases = [
        (True, None),
        (True, 3),
        (True, ""),
        (True, 0),
        (False, ''),
        (False, -1),
        (False, ""),
        (False, Retry(3)),
    ]
    for raise_for_status, retry in test_cases:
        try:
            session = build_requests_session(raise_for_status, retry)
            print("session",session)
            print(type(session))
        except ValueError:
            continue


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-26 01:19:22.145723
# Unit test for function build_requests_session
def test_build_requests_session():
    assert(build_requests_session() is not None)

# Generated at 2022-06-26 01:19:31.851072
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Object session_0 of class Session
    session_0 = build_requests_session()
    # Object logger_0 of class Logger
    logger_0 = logging.getLogger("user:")
    # Object logger_1 of class Logger
    logger_1 = logging.getLogger("user:")
    f: function
    # Object logged_function_0 of class LoggedFunction
    logged_function_0 = LoggedFunction(logger_0)
    # Object logged_function_1 of class LoggedFunction
    logged_function_1 = LoggedFunction(logger_1)

    # Call method __call__ of class LoggedFunction to wrap build_requests_session
    logged_function_0(build_requests_session)
    # Call method __call__ of class LoggedFunction to wrap test_case_0

# Generated at 2022-06-26 01:19:34.654002
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # define logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    # define LoggedFunction instance
    logged_function = LoggedFunction(logger)
    # define a sample function
    def test_func(name):
        return f'My name is {name}'
    # test logged function
    logged_test_func = logged_function(test_func)
    logged_test_func('Ganesh')

# Generated at 2022-06-26 01:19:38.840259
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session(retry=False)
    session_0.__call__(
        "http://httpbin.org/get", params={"key_3": "val_3", "key_4": "val_4"}
    )



# Generated at 2022-06-26 01:19:47.566450
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func(a, b, c=3):
        return a + b * c

    logger = logging.getLogger('')
    logger.setLevel(logging.INFO)
    decorated_func = LoggedFunction(logger)(func)
    assert decorated_func(1, 2) == 7
    assert decorated_func(a=1, b=2) == 3
    assert decorated_func(1, b=2) == 7
    assert decorated_func(1, 2, c=4) == 13
    assert decorated_func(1, 2, c=5) == 15
    assert decorated_func(1, 2, 3, 4, 5) == 23

# Generated at 2022-06-26 01:19:49.521795
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    test_case_0()

# Generated at 2022-06-26 01:19:58.461632
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
    )
    def add_1(x, y):
        return x + y
    # case 1: args and kwargs is none
    f = LoggedFunction(logger)
    f(add_1)()
    # case 2: args is empty
    f(add_1)(*())
    # case 3: args is not empty
    f(add_1)(1,2)
    # case 4: kwargs is empty
    f(add_1)(*(), **{})
    # case 5: kwargs is not empty

# Generated at 2022-06-26 01:20:29.731453
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    log_func = LoggedFunction(logger)
    test_case_0 = log_func(build_requests_session())
    test_case_1 = log_func(build_requests_session)
    # __call__ method return function
    assert callable(test_case_0)
    assert callable(test_case_1)
    assert isinstance(test_case_0, Session)
    assert isinstance(test_case_1, Session)


# Generated at 2022-06-26 01:20:30.511692
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session()


# Generated at 2022-06-26 01:20:44.223200
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestClass():
        def __init__(self, logger):
            self.logger = logger
        # Test call to method __call__ of class LoggedFunction
        @LoggedFunction(self.logger)
        def test_0(self):
            pass
        @LoggedFunction(self.logger)
        def test_1(self, *args, **kwargs):
            pass
    logger = logging.getLogger(__name__)
    try:
        test_class = TestClass(logger)
        def test_0():
            pass
        test_class.test_0()
        test_class.test_1()
    except Exception as e:
        print(e)

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.get

# Generated at 2022-06-26 01:20:45.744295
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    session_0.close()



# Generated at 2022-06-26 01:20:53.141693
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test(x):
        return x

    logger = MagicMock()
    logged_function = LoggedFunction(logger)
    wrapped_function = logged_function(test)
    wrapped_function(123)
    logger.debug.assert_called_once_with('test(123)')

# Generated at 2022-06-26 01:20:56.017699
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_logged_func = LoggedFunction(logger=None).__call__(test_case_0)
    test_case_logged_func()

# Generated at 2022-06-26 01:20:57.554807
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("pytrips.trips")
    logged_func = LoggedFunction(logger)
    @logged_func
    def func_0(hello, world):
        print("{} {}".format(hello, world))

    func_0("hello", "world")

# Generated at 2022-06-26 01:21:01.832407
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import patch

    from ebrains_atlas_api.utils import LoggedFunction

    # Create logger object
    logger = logging.getLogger()

    # Create params
    function = lambda: None
    function.__name__ = 'function'
    args = ('argument',)
    kwargs = {'keyword argument': 'keyword argument'}
    captured_output = None

    # Create LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Patching 'logger.debug'
    with patch('ebrains_atlas_api.utils.logger.debug') as patched_debug:
        # Calling method to test
        logged_function(function)(*args, **kwargs)

        # Retrieve call arguments
        captured_output = patched_debug.call

# Generated at 2022-06-26 01:21:05.698567
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # when
    @LoggedFunction(logging.getLogger())
    def test_func():
        pass
    
    # then
    assert test_func.__name__ == "test_func"
    

# Generated at 2022-06-26 01:21:17.689406
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pprint import pprint
    from logging import getLogger
    from vyperlogix.misc.funky_decorators import LoggedFunction
    logger = getLogger(__name__)
    test_cases = [
        {
            "name": "LoggedFunction.__call__",
            "method": test_case_0,
        },
    ]
    for test_case in test_cases:
        try:
            print(f"Running test: {test_case['name']}")
            pprint(test_case)
            test_case["method"]()
        except Exception as e:
            logger.exception(f"Error occurred in {__name__}: {e}")
            
if __name__ == "__main__":
    from vyperlogix.misc._logging import configure_logging


# Generated at 2022-06-26 01:22:11.171940
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger
    from unittest.mock import Mock

    # Create a mock logger
    logger = Mock(Logger)

    # Create a mocked function
    def test_function(x, y, z = 0):
        pass

    # Call LoggedFunction to create a new function
    wrapped_function = LoggedFunction(logger)(test_function)

    # Call the new function
    wrapped_function(10, 99, z = 3)

    # Check that the logger was used correctly
    logger.debug.assert_any_call("test_function(10, 99, z=3)")



# Generated at 2022-06-26 01:22:16.420442
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    session_1 = build_requests_session(raise_for_status=False)
    session_2 = build_requests_session(retry=Retry(total=4, backoff_factor=0.5))
    session_3 = build_requests_session(retry=False)
    session_4 = build_requests_session(retry=5)
    pass

if __name__ == '__main__':
    test_build_requests_session()

# Generated at 2022-06-26 01:22:27.515687
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger
    from io import StringIO

    logger = Logger("test_logger")
    handler = logging.StreamHandler(stream=StringIO)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    def func_1(a: int, b: int, c=1, d=2):
        return a + b + c + d + 0.1

    def func_2(a: int):
        return a + 0.1

    # by default, the self.logger of LoggedFunction is test_logger.
    # it will use default Retry configuration (total retry count is 3)
    logged_func_1 = LoggedFunction.__call__(func_1)
    logged_func_

# Generated at 2022-06-26 01:22:38.941315
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def debug(self, msg):
            print(msg)

    logger = Logger()
    logged_func = LoggedFunction(logger)

    @logged_func
    def test_logged_func(param_1, param_2='Two', param_3=3.0, param_4=None):
        return param_1 + param_2 + param_3 + param_4

    test_logged_func(param_1='One', param_2='Two', param_3='3.0', param_4=None)


if __name__ == '__main__':
    # test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:22:44.101977
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    func = LoggedFunction(logger)
    assert issubclass(func.__class__, object)
    assert func.logger == logger
    #result is None
    out = func(test_case_0)
    assert out is not None
    assert out() == None

# Generated at 2022-06-26 01:22:48.867959
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    @LoggedFunction(logger)
    def test_function(a:str, b:str, c:str = 'c'):
        return 1
    test_function('a', 'b')

if __name__ == '__main__':
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:22:50.647474
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock

    test_logger = MagicMock()
    test_function = LoggedFunction(test_logger)
    test_function.__call__(test_case_0)

# Generated at 2022-06-26 01:22:54.016042
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("epyk_ui.test")
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    logger.addHandler(stream_handler)

    decorated_func = LoggedFunction(logger)(test_case_0)
    decorated_func()


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:22:57.273830
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=None)
    def test_func(arg0, arg1, arg2):
        return "test_string"

    assert test_func("test_arg0", "test_arg1", "test_arg2") == "test_string"

# Generated at 2022-06-26 01:23:06.089691
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func():
        return None

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s|%(levelname)s|%(name)s|%(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    test_func = LoggedFunction(logger)(test_func)
    test_func()


if __name__ == "__main__":
    # test_LoggedFunction___call__()
    test_case_0()

# Generated at 2022-06-26 01:24:45.057028
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger)
    def f1(a, b, c=10, d=20):
        return a + b + c + d
    res = f1(1, 2, c=3, d=4)
    assert res == 10



# Generated at 2022-06-26 01:24:56.105815
# Unit test for function build_requests_session
def test_build_requests_session():
    session_default = build_requests_session()
    assert type(session_default) == Session
    assert session_default.mounts
    assert session_default.hooks
    session_default = build_requests_session(raise_for_status=False)
    assert type(session_default) == Session
    assert session_default.mounts
    assert not session_default.hooks
    session_default = build_requests_session(retry=False)
    assert type(session_default) == Session
    assert not session_default.mounts
    session_default = build_requests_session(retry=2)
    assert type(session_default) == Session
    assert session_default.mounts
    session_default = build_requests_session(retry=Retry(retry=2))

# Generated at 2022-06-26 01:24:57.447452
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:25:10.550272
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger

    def add(a, b):
        return a + b

    # test logger
    logger = getLogger("test")
    logger_0 = LoggedFunction(logger)
    logger_1 = logger_0(add)
    try:
        logger_1(1, 2)
    except Exception as e:
        assert False
    # pass


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

    # test utility functions build_requests_session, LoggedFunction

    # test utility class
    # class A:
    #    def __init__(self):
    #        pass
    #    def _add(self, a, b):
    #        return a + b
    #    func_add = LoggedFunction(logger

# Generated at 2022-06-26 01:25:11.422391
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass



# Generated at 2022-06-26 01:25:22.733965
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    assert(session_0.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]})

    session_1 = build_requests_session(raise_for_status=False)
    assert(session_1.hooks == {})

    session_2 = build_requests_session(retry=False)
    assert(session_2.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]})

    session_3 = build_requests_session(retry=False, raise_for_status=False)
    assert(session_3.hooks == {})

    session_4 = build_requests_session(retry=True)