

# Generated at 2022-06-26 01:15:28.206061
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create a new LoggedFunction instance
    instance = LoggedFunction(logger=Logger())

    # Decorate a function, then create a new function which just calls that function
    def func_0(arg1, arg2): return None

    # Invoke the newly decorated function, and
    instance(func_0)(arg1=dict_0, arg2=list_0)



# Generated at 2022-06-26 01:15:32.626353
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    test_case_0()
    logger.removeHandler(logging.StreamHandler())


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:15:36.996458
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.Logger()
    logged_function = LoggedFunction(logger)
    def test_case_0():
        dict_0 = {}
        var_0 = format_arg(dict_0)
        logged_function.__call__(var_0)

# Generated at 2022-06-26 01:15:45.411392
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.debug('start Log Function')
    log_func_obj_0 = LoggedFunction(logger)
    def fun_0(arg_0, arg_1, arg_2):
        return
    lg_0 = log_func_obj_0.__call__(fun_0)
    lg_0(dict(), dict(), dict())
    lg_0(dict(), dict(), object())
    lg_0(dict(), object(), dict())
    lg_0(dict(), object(), object())
    lg_0(object(), dict(), dict())
    lg_0(object(), dict(), object())
    lg_0(object(), object(), dict())
    lg_0(object(), object(), object())

# Generated at 2022-06-26 01:15:53.494495
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_obj_0 = LoggedFunction()
    func_0 = lambda : None
    instance_0 = test_obj_0.__call__(func_0)
    instance_0()
    test_obj_1 = LoggedFunction()
    str_0 = str()
    func_1 = lambda str_0: str_0
    instance_1 = test_obj_1.__call__(func_1)
    instance_1('str_0')
    test_obj_2 = LoggedFunction()
    int_0 = int()
    func_2 = lambda int_0: int_0
    instance_2 = test_obj_2.__call__(func_2)
    instance_2(int_0)
    test_obj_3 = LoggedFunction()
    dict_0 = {}

# Generated at 2022-06-26 01:16:01.590796
# Unit test for function build_requests_session
def test_build_requests_session():
    assert(build_requests_session(False) != None)
    assert(build_requests_session(True) != None)
    assert(build_requests_session(5) != None)
    assert(build_requests_session(False, 5) != None)
    assert(build_requests_session(True, 5) != None)
    assert(build_requests_session(False, True) != None)
    assert(build_requests_session(True, True) != None)


# Generated at 2022-06-26 01:16:11.601957
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    class Test_LoggedFunction(unittest.TestCase):
        def test_0(self):
            logger.debug('Start test method test_0 of class Test_LoggedFunction')

            # Test method __call__ of class LoggedFunction
            temp_0 = LoggedFunction(logger)
            temp_1 = temp_0.__call__(test_case_0)
            temp_2 = temp_1()
            assert temp_2 == None

            logger.debug('End test method test_0 of class Test_LoggedFunction')

        def test_1(self):
            logger.debug('Start test method test_1 of class Test_LoggedFunction')

            # Test method __call__

# Generated at 2022-06-26 01:16:14.038880
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    var_0 = format_arg(dict_0)

# Generated at 2022-06-26 01:16:23.316378
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest import TestCase

    class TestLogger(TestCase):
        def setUp(self):
            self.logger = Mock()
            self.logged_function = LoggedFunction(self.logger)

        def test_args_logging(self):
            self.logged_function(test_case_0)
            self.logger.debug.assert_called_once()
            self.assertIn('dict_0={}', self.logger.debug.call_args[0][0])

        def test_result_logging(self):
            self.logged_function(test_case_0)
            self.logger.debug.assert_called_with(
                'test_case_0 -> {}'
            )

    return TestLogger()




# Generated at 2022-06-26 01:16:26.446777
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    var_0 = LoggedFunction(dict_0)


# Generated at 2022-06-26 01:16:37.050248
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Result: initialization should set _func to None
    logged_func = LoggedFunction(None)
    assert logged_func._func == None
    # Input:
    #   func -- an instance of function
    # Result: _func should be set to func and the return value of _call__ should be the same as _func
    func = test_case_0
    logged_func = LoggedFunction(None)(func)
    assert logged_func._func == func
    assert logged_func == func

# Generated at 2022-06-26 01:16:42.239877
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Defined at line 45 of file utils.py
    """

    from unittest import TestCase
    from unittest.mock import Mock

    from .utils import LoggedFunction

    class Test:
        logger = Mock()
        log_func = LoggedFunction(logger)

        @log_func
        def test_func(param):
            pass

    test = Test()
    test.test_func("param")

    test.logger.debug.assert_called_once_with(
        "test_func('param')",
    )

# Generated at 2022-06-26 01:16:50.269793
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    lf = LoggedFunction(logger)
    @lf
    def test_case_1(para0, para1='default_value'):
        str_1 = 'test_case_1 -> para0={}, para1={}'.format(para0, para1)
    test_case_1('para_00','para_01')
    test_case_1('para_10')


# Generated at 2022-06-26 01:17:00.298316
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    def test_case_0():
        pass

    def test_case_1():
        str_1 = 'test_case_1 -> {}'
        str_1 = str_1.format(1)
        return str_1

    def test_case_2(num_0, num_1):
        str_1 = 'test_case_2 -> {} + {} = {}'
        str_1 = str_1.format(num_0, num_1, num_0 + num_1)
        return str_1

    def test_case_3(num_0, num_1=1):
        str_1 = 'test_case_3 -> {} + {} = {}'
        str_1 = str_1.format(num_0, num_1, num_0 + num_1)
        return str_1

   

# Generated at 2022-06-26 01:17:01.402527
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass



# Generated at 2022-06-26 01:17:07.397798
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logged_func = LoggedFunction(logging.getLogger('test_case_0'))
    test_case = logged_func(test_case_0)
    test_case()
    return True

import argparse
import logging
#from argparse import ArgumentParser
from typing import Any

from signal_processing.loggers import setup_logging
from signal_processing.utils import *



# Generated at 2022-06-26 01:17:13.525960
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = Logger('test_LoggedFunction___call__')
    logger_0.setLevel(INFO)
    logger_0.addHandler(StreamHandler(stream=stdout))
    str_0 = 'test_LoggedFunction___call__'
    if (str_0 == 'test_LoggedFunction___call__'):
        test_case_0()

if (__name__ == '__main__'):
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:23.930195
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # ########## Configuration ##################
    # logger: https://docs.python.org/3/howto/logging.html
    import logging
    import sys
    logger = logging.getLogger('test_LoggedFunction___call__')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    # ########## End Configuration ##################

    logged_function = LoggedFunction(logger)
    logged_function(test_case_0)('Hahahahahhah')


# Generated at 2022-06-26 01:17:31.977464
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    '''
    test_case_0 -> str_0 = 'test_case_0 -> {}'
    test_case_0 -> str_1 = 'test_case_0 -> {}'
    test_case_0 -> str_2 = '{}'
    test_case_0 -> str_3 = ''
    test_case_0 -> param_dict = {}
    test_case_0 -> param_dict = {'a':1, 'b':2}
    test_case_0 -> param_dict = {'a':1}
    test_case_0 -> param_dict = {'b':2}
    '''
    str_0 = str_1 = 'test_case_0 -> {}'
    str_2 = '{}'
    str_3 = ''
    param_dict = {}

# Generated at 2022-06-26 01:17:32.986643
# Unit test for function build_requests_session
def test_build_requests_session():
    test_session = build_requests_session()
    assert type(test_session) == Session


# Generated at 2022-06-26 01:17:40.643701
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MagicMock()
    logged_function = LoggedFunction(logger)
    mock_function = MagicMock()
    logged_function(mock_function)
    logger.debug.assert_not_called()
    mock_function()
    logger.debug.assert_called_once()


# Generated at 2022-06-26 01:17:42.279175
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Call function
    result = LoggedFunction.__call__()

    # Check result
    assert result == None


# Generated at 2022-06-26 01:17:45.172885
# Unit test for function build_requests_session
def test_build_requests_session():
    pass


if __name__ == "__main__":
    # Basic testing
    test_case_0()

    # Unit testing
    test_build_requests_session()

# Generated at 2022-06-26 01:17:54.709210
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Local variables
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_1["a"] = dict_0
    dict_1["b"] = dict_2
    dict_1["c"] = dict_0
    dict_1["d"] = dict_0
    dict_1["e"] = dict_0
    str_0 = str(dict_1)
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_1["a"] = dict_0
    dict_1["b"] = dict_2
    dict_1["c"] = dict_0
    dict_1["d"] = dict_0
    dict_1["e"] = dict_0
    str_1 = str(dict_1)
    dict_0 = {}
   

# Generated at 2022-06-26 01:18:00.100517
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # arrange
    logger = logging.getLogger('test_LoggedFunction')
    # logger.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    logger.addHandler(ch)
    logged_function = LoggedFunction(logger)

    # act: call test_case_0
    value_0 = logged_function(test_case_0)
    value_0()



# Generated at 2022-06-26 01:18:10.942748
# Unit test for function build_requests_session
def test_build_requests_session():
    test_session = build_requests_session(raise_for_status=False, retry=False)
    assert(isinstance(test_session, Session))
    assert(len(test_session.hooks) == 0)
    assert(isinstance(test_session.adapters, dict))
    assert(len(test_session.adapters) == 2)

    test_session = build_requests_session(raise_for_status=False, retry=True)
    assert(isinstance(test_session, Session))
    assert(len(test_session.hooks) == 0)
    assert(isinstance(test_session.adapters, dict))
    assert(len(test_session.adapters) == 2)


# Generated at 2022-06-26 01:18:19.039497
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    func = LoggedFunction(logger)

    def test_func_0(arg_0):
        pass

    def test_func_1(arg_0, arg_1):
        pass

    def test_func_2(arg_0):
        return arg_0

    def test_func_3(arg_0, arg_1):
        return arg_0 + arg_1

    func_wrapper_0 = func(test_func_0)
    func_wrapper_1 = func(test_func_1)
    func_wrapper_2 = func(test_func_2)
    func_wrapper_3 = func(test_func_3)

    func_wrapper_0(1)
    func_wrapper_0(a=1)

# Generated at 2022-06-26 01:18:22.961013
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    list_0 = []
    def func_0(arg_0):
        return arg_0
    logged_func_0 = LoggedFunction.__call__(LoggedFunction, func_0)
    var_0 = logged_func_0(dict_0)


# Generated at 2022-06-26 01:18:30.404108
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    var_0 = format_arg(dict_0)

# Generated at 2022-06-26 01:18:36.539013
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    if not logger.handlers:
        logging.basicConfig(format='%(asctime)s %(levelname)s %(message)s',
                            level=logging.DEBUG)
    class_0 = LoggedFunction(logger)
    func = functools.partial(test_case_0)
    class_0(func)
    pass



# Generated at 2022-06-26 01:18:45.483440
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from __main__ import LoggedFunction
    from unittest.mock import Mock
    logger = Mock()
    decorator = LoggedFunction(logger)
    decorator(test_case_0)()
    assert logger.debug.called



# Generated at 2022-06-26 01:18:59.400481
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import pytest
    base_session = build_requests_session(retry=False)
    assert isinstance(base_session, requests.Session)
    assert len(base_session.hooks['response']) == 0
    retry_session = build_requests_session(retry=1)
    assert isinstance(retry_session, requests.Session)
    hook = retry_session.hooks['response']
    assert hook[0](None) is None
    retry_session = build_requests_session(retry=Retry(1, total=5))
    assert isinstance(retry_session, requests.Session)
    hook = retry_session.hooks['response']
    assert hook[0](None) is None

# Generated at 2022-06-26 01:19:03.064475
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = format_arg({})

    format_arg_0 = (lambda var_0: format_arg(var_0))
    format_arg_0_1 = (lambda var_1: format_arg(var_1))
    format_arg_0_2 = (lambda var_2: format_arg(var_2))
    functools = lambda var_3: var_3
    format_arg_0_4 = (lambda var_4: format_arg(var_4))
    format_arg_0_5 = (lambda var_5: format_arg(var_5))
    format_arg_0_6 = (lambda var_6: format_arg(var_6))
    list_0 = ({})
    functools_0 = (lambda var_7: functools(var_7))
    test_case

# Generated at 2022-06-26 01:19:05.408667
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    lf = LoggedFunction(logger)
    assert lf is not None
    dec_0 = lf.__call__(test_case_0)
    assert dec_0 is not None

# Generated at 2022-06-26 01:19:07.095275
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    obj_LoggedFunction = LoggedFunction()
    result_LoggedFunction___call__ = LoggedFunction.__call__(obj_LoggedFunction)

# Generated at 2022-06-26 01:19:09.734455
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.Logger()
    obj = LoggedFunction(logger)
    func = lambda a: print(a)
    func_2 = obj(func)
    func_2(1)



# Generated at 2022-06-26 01:19:11.427462
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert(isinstance(session, Session))


# Generated at 2022-06-26 01:19:21.991768
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    def func_0(a, b, c):
        pass

    var_0 = LoggedFunction(logging.getLogger("Debug"))
    var_1 = var_0(func_0)
    var_1(1, 2, 3)

    def func_1(a: bool):
        pass

    var_2 = var_0(func_1)
    var_2(True)

    def func_2(a: bytes):
        pass

    var_3 = var_0(func_2)
    var_3(b"a")

    def func_3(a: dict):
        pass

    var_4 = var_0(func_3)
    var_4({})

    def func_4(a: list):
        pass

    var_5 = var_0(func_4)
    var

# Generated at 2022-06-26 01:19:28.045587
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dummy_logger = object()
    dummy_function = object()
    logged_func = LoggedFunction(dummy_logger)(dummy_function)

    class DummyKlass(object):
        def __init__(self):
            self.test = 'test'

    dummy_klass = DummyKlass()

    logged_func(1, 2, 3, test1=1, test2=2, test3=dummy_klass)

# Generated at 2022-06-26 01:19:34.130526
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test data
    logger = None
    func = None
    args = None
    kwargs = None
    # Setup test data
    logger = logging.Logger("test_logger")
    func = lambda s: s
    args = (1, 2)
    kwargs = {
        "key1": "value1",
        "key2": "value2",
    }
    # Test execution
    test_obj = LoggedFunction(logger)
    result = test_obj.__call__(func)(*args, **kwargs)
    # Test result


# Generated at 2022-06-26 01:19:55.585876
# Unit test for method __call__ of class LoggedFunction

# Generated at 2022-06-26 01:20:02.234118
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create a mock for Logger
    mock_Logger = Mock()

    # Invoke constructor of class LoggedFunction with parameter mock_Logger
    obj_LoggedFunction = LoggedFunction(mock_Logger)

    # The code to be tested
    obj_LoggedFunction(test_case_0)

    # Verification: Verify that method debug of mock mock_Logger has been called with parameter ftest_case_0({args}{kwargs})

# Generated at 2022-06-26 01:20:12.049169
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # The following lines of code create local variables that are used as
    # actual parameters of the following three methods to be tested:
    # __init__, logged_func, and __call__.
    # When you write your own test case, you just need to create these local
    # variables.
    #
    # __init__
    #  logger
    #   Logger to send output to.
    dict_0 = {}
    dict_0["name"] = logger_name
    dict_0["level"] = logging.DEBUG
    dict_0["handlers"] = [logging.NullHandler]
    dict_0["propagate"] = False
    dict_0["lazy"] = True
    dict_0["factory"] = logging.getLogManager().getLogger
    dict_0["incremental"] = False

# Generated at 2022-06-26 01:20:18.820889
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Init Logger
    logger_0 = logging.getLogger(__name__)

    # Init Logged Function
    logged_function_0 = LoggedFunction(logger_0)

    # Test function
    test_case_0()



# Generated at 2022-06-26 01:20:20.663158
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-26 01:20:31.803514
# Unit test for method __call__ of class LoggedFunction

# Generated at 2022-06-26 01:20:35.446111
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger("test")

    @LoggedFunction(logger)
    def test_func(a):
        return a + 1

    test_func(1)


# Generated at 2022-06-26 01:20:47.242262
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from os import path
    from pathlib import PurePath
    from typing import Any, Callable
    from logging import getLogger

    logger = getLogger()
    logger.setLevel("DEBUG")
    logged_func = LoggedFunction(logger)
    func_0: Callable[..., Any] = logged_func(test_case_0)
    func_0()
    func_0_output_file_path: PurePath = PurePath(__file__).parent.joinpath(
        "test_call_output.log"
    )
    func_0_output = ""
    with open(func_0_output_file_path, 'r') as file_0:
        func_0_output = file_0.read()

# Generated at 2022-06-26 01:20:51.018327
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch

    with patch('somelib.log.LoggedFunction.logger.debug') as mock_debug:
        dict_0 = {}
        var_0 = format_arg(dict_0)
        def looged_func():
            pass

        # Call
        logged_func = LoggedFunction(mock_debug)
        logged_func(looged_func)

        # Assert
        mock_debug.assert_called_once_with()



# Generated at 2022-06-26 01:21:04.615686
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from logging import DEBUG
    from logging import StreamHandler

    logger = getLogger(__name__)
    h = StreamHandler()
    h.setLevel(DEBUG)
    logger.setLevel(DEBUG)
    logger.addHandler(h)

    # TODO: pretty printing for dicts
    # TODO: handle iterables
    @LoggedFunction(logger)
    def func(a, b, c="hello", d="world", s=None):
        return (a, b, c, d, s)

    func(1, 2, "aaa", "bbb", s="hello")
    func(1, 2, "aaa", "bbb")
    func(1, 2, "aaa")
    func(1, 2)


if __name__ == "__main__":
    test

# Generated at 2022-06-26 01:21:29.055186
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    a = LoggedFunction
    a.__call__()



# Generated at 2022-06-26 01:21:29.682585
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    
    pass

# Generated at 2022-06-26 01:21:34.587796
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    print("Testing method __call__ of class LoggedFunction")
    # Case 0
    # func =
    # args =
    # kwargs =
    # output =
    # test_case_0()
    test_case_0()

if __name__ == "__main__":
    test_function = eval(input("Enter the name of the test function you want to run: "))
    test_function()

# Generated at 2022-06-26 01:21:38.319142
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    # Test method __call__ of class LoggedFunction with first_arg as {} and second_arg as {'key': 'valu'}
    test_case_0()

# Generated at 2022-06-26 01:21:47.733698
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    assert format_arg(dict_0) == "{}"
    dict_0 = dict()
    dict_0 = {}
    dict_0[''] = {}
    assert format_arg(dict_0) == "{'': {}}"
    dict_0 = dict()
    dict_0 = {}
    dict_0[''] = {}
    dict_0[''] = {}
    assert format_arg(dict_0) == "{'': {}, '': {}}"
    dict_0 = dict()
    dict_0 = {}
    dict_0[''] = {}
    dict_0[''] = {}
    dict_0[''] = {}
    assert format_arg(dict_0) == "{'': {}, '': {}, '': {}}"
    dict_0 = dict()

# Generated at 2022-06-26 01:21:58.256592
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # arrange
    logger = getLogger(__name__)

    def test_case_0(dict_0,  dict_1, dict_2):

        # arrange
        logger = getLogger(__name__)
        test_obj = LoggedFunction(logger)

        # act
        test_result = test_obj(test_case_0)
        test_result(dict_0, dict_1, dict_2)

    dict_0 = {"a": "b"}
    dict_1 = {1: 2}
    dict_2 = {"c": "d"}
    test_case_0(dict_0, dict_1, dict_2)


if __name__ == '__main__':
    test_case_0()
    build_requests_session(True, 0)
    build_requests_session

# Generated at 2022-06-26 01:22:04.391806
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    dict_0 = {'key_0':'value_0'}
    dict_0 = {'key_0':'value_0' , 'key_1':'value_1'}
    var_0 = format_arg(dict_0)


# Generated at 2022-06-26 01:22:13.852455
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Logger()
    f = LoggedFunction(logger)
    def test_func_0(*args, **kwargs):
        assert len(args) == 2
        assert args[0] == 3
        assert args[1] == "test"
        assert len(kwargs) == 2
        assert kwargs['a1'] == 4
        assert kwargs['a2'] == "test_2"
        return 5
    def test_func_1(*args, **kwargs):
        assert len(args) == 1
        assert args[0] == 1
        return 2
    f_0 = f(test_func_0)
    f_0(3, "test", a1=4, a2="test_2")
    f_1 = f(test_func_1)
    f_1(1)

# Generated at 2022-06-26 01:22:17.829481
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # @LoggedFunction
    # def test_case_0(arg_1, arg_2, arg_3=None, arg_4={}, arg_5=[]):
    #     pass
    # test_case_0(1, 2, arg_3=3, arg_4={4}, arg_5=[5])
    return


if __name__ == "__main__":
    # test_LoggedFunction___call__()
    test_case_0()

# Generated at 2022-06-26 01:22:23.933484
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    # Turn on debug logging.
    logging.basicConfig(level=logging.DEBUG)

    # Create test logger
    logger = logging.getLogger("test_LoggedFunction___call__")

    # Create LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Make LoggedFunction instance the decorator of test_case_0 function
    logged_function(test_case_0)

    # Invoke test_case_0 function
    test_case_0()

# Generated at 2022-06-26 01:23:20.876403
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler_0 = logging.StreamHandler()
    logFormatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    handler_0.setFormatter(logFormatter)
    logger.addHandler(handler_0)
    # print(logger)

    def foo(a, b, c, d=None):
        return a + b + c

    logged_foo = LoggedFunction(logger)(foo)
    # print(logged_foo)
    print(logged_foo(1, 2, 3))


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:23:22.845503
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    var_0 = LoggedFunction(dict_0)
    test_case_0(var_0)

# Generated at 2022-06-26 01:23:25.446950
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    dict_1 = {}
    var_0 = build_requests_session(dict_0, dict_1)
    var_1 = test_LoggedFunction___call__()

# Generated at 2022-06-26 01:23:27.193494
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('logged-function')
    handler = logging.StreamHandler()
    logge

# Generated at 2022-06-26 01:23:36.063772
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = open('logger.tmp', 'w')
    def logged_func(*args, **kwargs):
        return
    def func(*args, **kwargs):
        return

    # Test for all values possible of args, kwargs, result
    args = None
    kwargs = {'test': None}
    result = None

    LoggedFunction(logger)(func)(args, kwargs)
    logger.close()
    logger = open('logger.tmp', 'r')
    func_name = func.__name__
    assert(logger.readline() == f"{func_name}({format_arg(args)}, {format_arg(kwargs)});\n")
    assert(logger.readline() == f"{func_name} -> {format_arg(result)};\n")


# Generated at 2022-06-26 01:23:38.591369
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    @LoggedFunction(logging.getLogger(__name__))
    def test_function(x, y):
        return x * y

    test_function(10, 20)
    assert test_function(10, 20) == 200
    assert test_function(0, 0) == 0


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:23:40.955172
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    f = LoggedFunction(logger=None)
    f(test_case_0)("")

# Generated at 2022-06-26 01:23:42.229717
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    dict_0 = {}
    var_1 = format_arg(dict_0)
    print(var_1)

# Generated at 2022-06-26 01:23:43.853469
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    log = logging.Logger("logger")
    f = LoggedFunction(log)
    f.__call__(test_case_0)

# Generated at 2022-06-26 01:23:52.750289
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test logger")
    logged_func = LoggedFunction(logger)(lambda: None)
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"
    assert logged_func.__name__ == "lambda"