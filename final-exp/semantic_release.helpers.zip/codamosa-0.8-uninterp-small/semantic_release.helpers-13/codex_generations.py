

# Generated at 2022-06-26 01:15:36.640728
# Unit test for function build_requests_session
def test_build_requests_session():
    # Create a session with basic configuration
    session_0 = build_requests_session()
    assert type(session_0) == Session

    # Create a session with basic configuration and raise_for_status
    session_1 = build_requests_session(raise_for_status=True)
    assert type(session_1) == Session

    # Create a session with basic configuration and retry
    session_2 = build_requests_session(retry=True)
    assert type(session_2) == Session

    # Create a session with basic configuration and retry
    session_3 = build_requests_session(retry=Retry(48))
    assert type(session_3) == Session

# Generated at 2022-06-26 01:15:39.988781
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_1 = build_requests_session(retry=True)
    session_2 = build_requests_session(retry=False)
    session_3 = build_requests_session(retry=1)

if __name__ == '__main__':
    print(build_requests_session())
    print(build_requests_session(True))
    print(build_requests_session(False))
    print(build_requests_session(Retry()))
    print(build_requests_session(Retry(5)))

# Generated at 2022-06-26 01:15:40.685910
# Unit test for function build_requests_session
def test_build_requests_session():
    test_case_0()


# Generated at 2022-06-26 01:15:42.397014
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session), 'session is not a requests.Session object'
    assert hasattr(session, 'hooks'), 'session object has no hooks'

# Generated at 2022-06-26 01:15:51.065371
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test default parameters
    session = build_requests_session()
    assert session.hooks == {}
    assert isinstance(session.adapters['http://'].max_retries, Retry)
    assert isinstance(session.adapters['https://'].max_retries, Retry)
    session.mount('http://', HTTPAdapter())
    session.mount('https://', HTTPAdapter())
    assert session.adapters['http://'].max_retries.total == 10
    assert session.adapters['https://'].max_retries.total == 10

    # Test raise for status
    session_1 = build_requests_session(raise_for_status=True)
    assert session_1.hooks != {}

    # Test retry adapter
    session_2 = build_requests_session(retry=False)

# Generated at 2022-06-26 01:15:52.622021
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    assert session_0.__module__ == 'requests.sessions'

# Generated at 2022-06-26 01:15:56.908628
# Unit test for function build_requests_session
def test_build_requests_session():

    session_1 = build_requests_session()
    session_2 = build_requests_session()

    assert id(session_1) != id(session_2)

# Generated at 2022-06-26 01:15:58.004612
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # test cases
    test_case_0()

# Generated at 2022-06-26 01:16:09.835598
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    import sys
    import io
    from contextlib import redirect_stdout
    from io import StringIO

    class LoggedFunctionUnitTest(unittest.TestCase):
        """Unit test for method __call__ of class LoggedFunction"""

        def test_0(self):
            session_0 = build_requests_session()

            # Mock logger
            logger = logging.getLogger(__name__)
            # Use the custom logger
            # Create a new logger object
            logger = logging.getLogger(__name__)
            # Logging level
            logger.setLevel(logging.DEBUG)
            # Create stream handler for logger
            ch = logging.StreamHandler(sys.stdout)
            # Set logging level
            ch.setLevel(logging.DEBUG)
            # Create formatter and

# Generated at 2022-06-26 01:16:19.166322
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_function(a, b, c):
        return a + b / c

    logger = MagicMock()

    f = LoggedFunction(logger)(test_function)

    # Generate output
    result = f(1, 2, 3)

    logger.debug.assert_any_call("test_function(1, 2, 3)")
    logger.debug.assert_any_call("test_function -> 1.6666666666666667")
    assert result == 1.6666666666666667



# Generated at 2022-06-26 01:16:32.514084
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logger import get_logger
    logger_0 = get_logger("")
    loggedfunction_0 = LoggedFunction(logger_0)
    @loggedfunction_0
    def func_0(arg_0):
        return arg_0
    func_0("Hello world")
    @loggedfunction_0
    def func_1(arg_0, arg_1):
        return arg_0, arg_1
    func_1("Hello world", "Hello world")
    @loggedfunction_0
    def func_2(*args, **kwargs):
        return args, kwargs
    func_2("Hello world", "Hello world", "Hello world")
    func_2("Hello world", "Hello world", "Hello world", "Hello world")

# Generated at 2022-06-26 01:16:38.245430
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    session_0.hooks = {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    session_0.max_redirects = 30
    session_0.mount("http://", HTTPAdapter(max_retries=3))
    session_0.mount("https://", HTTPAdapter(max_retries=3))
    session_0.params = {"ApiKey": "uZw6mE7VYqPR8A9N9yCx"}
    session_0.proxies = {"http": "", "https": ""}
    session_0.verify = "path/to/bundle.pem"
    logger = logging.getLogger("LOG_CALL_TEST")
    logged_function = LoggedFunction

# Generated at 2022-06-26 01:16:52.785083
# Unit test for function build_requests_session
def test_build_requests_session():
    # Retry False
    session_0 = build_requests_session(retry=False)
    r_0 = session_0.get("http://www.google.com")
    assert r_0.status_code == 200

    # Retry True
    session_1 = build_requests_session()
    r_1 = session_1.get("http://www.google.com")
    assert r_1.status_code == 200

    # Retry 3
    session_2 = build_requests_session(retry=3)
    r_2 = session_2.get("http://www.google.com")
    assert r_2.status_code == 200
    assert len(session_2.adapters['http://'].max_retries.history) == 3

    # Retry with raise_for_status


# Generated at 2022-06-26 01:16:59.514992
# Unit test for function build_requests_session
def test_build_requests_session():
    test_cases = [
        (True, True),
        (True, 5),
        (True, Retry(retry_on_status=(400, 401, 403), status_forcelist=[403])),
        (False, False),
    ]

    for test_case_0 in test_cases:
        session_0 = build_requests_session(raise_for_status=test_case_0[0], retry=test_case_0[1])
        assert session_0 is not None
        assert type(session_0) is Session


# Generated at 2022-06-26 01:17:10.352157
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock
    from unittest.mock import MagicMock

# Generated at 2022-06-26 01:17:13.948226
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func = test_case_0
    logger = logging.getLogger("TEST_FUNCTION")
    logger.setLevel(logging.DEBUG)
    logged_func = LoggedFunction(logger)(func)
    logged_func()

# Generated at 2022-06-26 01:17:21.403130
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from .logger import get_logger

    logger = get_logger("example_logger")
    log_func = LoggedFunction(logger)

    def sleep():
        time.sleep(0.1)

    sleep = log_func(sleep)

    # Unit test for function sleep
    start = time.time()
    sleep()
    end = time.time()
    assert end - start >= 0.1


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:32.827763
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # In case the decorated function is called.
    # The log should contain the func.__name__, and the parameters of the call.
    # The log should also contain the return value.
    # Source: https://stackoverflow.com/a/26778519/9572091
    logger = logging.getLogger("test")
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test_func(a, b, c=None, d=5):
        return "the result"

    test_func(1, 2, 3, 4)
    # Expected log output
    # DEBUG:test:test_func(1, 2, 3, '4', d=5) -> the result



# Generated at 2022-06-26 01:17:41.742928
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import _thread, threading, time

    def f(name):
        time.sleep(0.2)
        print(threading.currentThread().getName(), 'Starting')
        time.sleep(0.1)
        print(threading.currentThread().getName(), 'Exiting')
        return threading.currentThread().getName()

    # Create a new thread
    print("creating thread object")
    thread = _thread.start_new_thread(f, ("Thread-1",))
    # print("threadId=", thread)
    time.sleep(0.5)
    # print("threadId=", thread)

# Generated at 2022-06-26 01:17:51.149125
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    assert session_0.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session_0.mounts.keys() == frozenset(['http://', 'https://'])
    assert session_0.mounts.values()[0] == HTTPAdapter(max_retries=Retry())
    assert type(session_0.mounts.values()[0]) == HTTPAdapter
    assert session_0.mounts.values()[1] == HTTPAdapter(max_retries=Retry())
    assert type(session_0.mounts.values()[1]) == HTTPAdapter


# Generated at 2022-06-26 01:18:09.078391
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    print("Test __call__ method of LoggedFunction class.")
    import logging
    import random

    def func_call(x: int, y: int, z: int) -> int:
        return x + y + z

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    logged_func: LoggedFunction = LoggedFunction(logger)
    wrapped_func = logged_func(func_call)
    assert wrapped_func(random.randint(0, 10), random.randint(0, 10), random.randint(0, 10)) == func_call(
        random.randint(0, 10), random.randint(0, 10), random.randint(0, 10)
    )



# Generated at 2022-06-26 01:18:12.826887
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger_0 = logging.getLogger()

    def logged_func_0(*args, **kwargs):
        return args[0]

    assert LoggedFunction(logger_0)(logged_func_0)(1) == 1



# Generated at 2022-06-26 01:18:16.136278
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func_label_0(a, b=1, c="a"):
        print(a + b + c)
    
    # test case 0
    logger_0 = logging.Logger("__name__")
    logged_function_0 = LoggedFunction(logger_0)
    logged_function_0(test_func_label_0(a=1, b=1, c="a"))

# Generated at 2022-06-26 01:18:19.757476
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=__name__)
    def test_f(x, y, z=1, *args, **kwargs):
        pass

    test_f(1, 2, 3, 4, 5)
    test_f(1, 2, 3, a=11, b=12)
    test_f(1, 2, 3, 4, 5, a=11, b=12)


# Generated at 2022-06-26 01:18:25.108310
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=None)
    def test_function(arg1, arg2, kwarg1=None, kwarg2=None):
        return arg1 + arg2 + kwarg1 + kwarg2

    test_function(1, 2, kwarg2=3, kwarg1=4)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:18:32.995220
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def debug(self, msg):
            print(msg)
    logger = MockLogger()

    @LoggedFunction(logger)
    def func_0():
        print("func_0()")

    func_0()


# Generated at 2022-06-26 01:18:39.684889
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func(x, y, z=1):
        return x + y + z

    logger = logging.getLogger("test_LoggedFunction___call__")
    f = LoggedFunction(logger)
    logged_func = f(test_func)
    assert logged_func(1, 2) == 4
    assert logged_func(1, 2, 3) == 6


if __name__ == "__main__":
    session_0 = build_requests_session()

    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:18:50.308863
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_foo(arg1, arg2):
        return arg1 + arg2

    class MockLogger:
        def __init__(self):
            self.counter = 0
            self.logs = []

        def debug(self, string):
            self.counter += 1
            self.logs.append(string)

    logger = MockLogger()
    logged_function = LoggedFunction(logger)
    logged_foo = logged_function(test_foo)
    assert logger.counter == 0
    assert logged_foo(1, 2) == 3
    assert logger.counter == 2
    assert logger.logs == ["test_foo(1, 2)", "test_foo -> 3"]

    logger = MockLogger()
    logged_function = LoggedFunction(logger)
    logged_foo = logged_function(test_foo)

# Generated at 2022-06-26 01:19:02.940541
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from contextlib import redirect_stdout

    session_0 = build_requests_session()
    logger_0 = Logger("test_LoggedFunction___call__", level="DEBUG")
    logged_function_0 = LoggedFunction(logger_0)


    @logged_function_0
    def f(x):
        return x * 2

    f_1 = f(1)
    assert f_1 == 2
    with redirect_stdout(StringIO()) as output:
        logger_0.print_buffer()
    assert output.getvalue().strip() == "DEBUG test_LoggedFunction___call__:f(1) -> 2"



# Generated at 2022-06-26 01:19:09.844335
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # init logger
    logger = logging.getLogger(__file__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)

    # test case 0
    logger.debug("Test Case 0")
    logged_func = LoggedFunction(logger)
    @logged_func
    def func_0():
        logger.debug("func_0")

    func_0()
    # 2020-05-

# Generated at 2022-06-26 01:19:23.124513
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    # Test for missing input argument
    try:
        LoggedFunction.__call__()
        assert False
    except:
        assert True



# Generated at 2022-06-26 01:19:32.759510
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import os
    import shutil
    import tempfile

    logging.basicConfig(level=logging.DEBUG)

    from requests import get

    logger = logging.getLogger(__name__)
    logged_get = LoggedFunction(logger)(get)
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-26 01:19:43.649671
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase
    from io import StringIO

    import logging

    from .TestUtil import filter_log_level

    class LoggedFunctionTestCase(TestCase):
        def test_call_function(self):
            logger = logging.getLogger(self.__class__.__name__)
            logger.setLevel(logging.DEBUG)
            output_buffer = StringIO()
            logger.addHandler(filter_log_level(logging.DEBUG, logging.StreamHandler(output_buffer)))
            lf = LoggedFunction(logger)

            def test_func(a, b, c=1):
                return (a, b, c)

            lf(test_func)
            self.assertEqual([], output_buffer.getvalue(), "There should be no output!")


# Generated at 2022-06-26 01:19:49.023943
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MagicMock()
    logged_function = LoggedFunction(logger)
    @logged_function
    def func(a, b, c=1):
        pass
    func('a', 'b')
    func('a', 'b', 'c')
    logger.debug.assert_has_calls([call("func('a', 'b')"), call("func('a', 'b', c='c')")])

# Generated at 2022-06-26 01:19:51.641538
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """Method __call__ of class LoggedFunction"""
    test_case_0()


# Generated at 2022-06-26 01:19:54.041910
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger
    from logging import getLogger

    from ..utils.logging import LoggedFunction

    logger = getLogger(__name__)
    logger.info('Test is not yet implemented.')

# Generated at 2022-06-26 01:19:57.535820
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func_0(*args, **kwargs):
        return args, kwargs

    logged_func_0 = LoggedFunction(logger=_logger)(func_0)
    logged_func_0(a=1, b=2)


if __name__ == "__main__":
    pass

# Generated at 2022-06-26 01:20:05.936192
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Configure logger
    logging.basicConfig(
        format="%(asctime)s %(levelname)s %(message)s", level=logging.DEBUG
    )
    logger = logging.getLogger()

    # Create LoggedFunction
    logged_func = LoggedFunction(logger)

    # Test function logging
    @logged_func
    def test_func(arg1, arg2, kwarg1=None):
        return arg1 + arg2 + (0 if kwarg1 is None else kwarg1)

    # Invoke function
    assert test_func(1, 2, kwarg1=12) == 15



# Generated at 2022-06-26 01:20:11.404089
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_function():
        return 0
    logger = logging.getLogger()
    logged_function = LoggedFunction(logger)
    call_function = logged_function(test_function)
    assert call_function.__name__ == "test_function"
    assert call_function() == 0
    logger = logging.getLogger()
    assert logger.debug.call_count == 1


# Generated at 2022-06-26 01:20:17.808146
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    @LoggedFunction("Test").__call__
    def func_0_to_test(param_0):
        return param_0

    func_0_to_test("test_case_0")

# Generated at 2022-06-26 01:20:43.760061
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=None)
    def test_func(*args):
        return str(args)
    assert test_func(1, 2, 3) == "(1, 2, 3)"


if __name__ == '__main__':
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:20:50.673455
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from os import path, remove
    from requests import get
    from logging import DEBUG, getLogger, FileHandler, StreamHandler

    # Define logger
    logger = getLogger("LoggedFunction")
    logger.setLevel(DEBUG)
    if path.isfile("test_LoggedFunction___call__.log"):
        remove("test_LoggedFunction___call__.log")
    file_handler = FileHandler("test_LoggedFunction___call__.log")
    file_handler.setLevel(DEBUG)
    stream_handler = StreamHandler()
    stream_handler.setLevel(DEBUG)
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)


# Generated at 2022-06-26 01:21:04.337993
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    log_file = "test.log"
    import logging

    logging.basicConfig(filename=log_file, level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def func_1(a, b=2, *args, **kwargs):
        return "{a} {b} {args} {kwargs}".format(
            a=a, b=b, args=args, kwargs=kwargs
        )

    # @LoggedFunction(logger)
    # def func_2(a:int, b: int = 2, *args, **kwargs):
    #     return f"{a} {b} {args} {kwargs}"

    func_1(1)

# Generated at 2022-06-26 01:21:16.896863
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Logger("test")
    print("TEST: test_LoggedFunction___call__")
    print("LoggedFunction(logger).__call__(func)")
    print("Where 'func' is a function:")
    print("def func(arg1, arg2, arg3):")
    print("    return arg1 + arg2 + arg3")
    @LoggedFunction(logger)
    def func(arg1, arg2, arg3):
        return arg1 + arg2 + arg3
    print("func(1, 2, 3) should return 6")
    print("=> func returns", func(1, 2, 3))
    print("func(1, 2, 3) should log below two lines:")
    print("    DEBUG:test:func(1, 2, 3)")

# Generated at 2022-06-26 01:21:20.561048
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import logging
    import unittest
    from contextlib import redirect_stdout
    from peppy.utils import LoggedFunction

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    log_stream = io.StringIO()
    log_handler = logging.StreamHandler(log_stream)
    log_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(log_handler)

    logged = LoggedFunction(logger)

    @logged
    def print_hello_world():
        print("Hello world!")

    @logged
    def return_hello_world():
        return "Hello world!"


# Generated at 2022-06-26 01:21:28.851124
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.Logger('logger_0')
    handler_0 = logging.StreamHandler()
    logger_0.addHandler(handler_0)

    @LoggedFunction(logger_0)
    def func_0(*args, **kwargs):
        # print('Hello from func_0!')
        return args, kwargs
        # pass

    func_0(*[1, 2, 3])
    func_0(*[4, 5, 6], **{'arg_7': 7, 'arg_8': 8})

    handler_0.close()
    logger_0.removeHandler(handler_0)
    logging.shutdown()


# Generated at 2022-06-26 01:21:33.285397
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    skipped = True
    if not skipped:
        logger.debug('test case 0')
        logger_0 = None
        logged_func_0 = LoggedFunction(logger_0)
        test_case_0()
    else:
        logger.debug('test case skipped')


# Generated at 2022-06-26 01:21:42.231231
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.info = []

        def debug(self, x):
            self.info.append(x)

    @LoggedFunction(MockLogger())
    def log_me(a: int, b: int) -> int:
        return a + b

    log_me(1, 2)
    assert log_me.__name__ == "log_me"
    assert log_me.info == [
        "log_me(1, 2)",
        "log_me -> 3",
    ]


if __name__ == "__main__":
    test_LoggedFunction___call__()
    test_case_0()

# Generated at 2022-06-26 01:21:51.071806
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func(a, b, c=5, d=7):
        print(a, b, c, d)

    logging.basicConfig(level=logging.DEBUG)
    logger_0 = logging.getLogger()
    logged_func_0 = LoggedFunction(logger_0)
    logged_func_1 = logged_func_0(test_func)

    for test_case in [
        (1, 2, 3, 4),
        (1, 2),
        (),
    ]:
        logged_func_1(*test_case)


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:21:57.671276
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # class DummyLogger:
    #     def debug(self, msg):
    #         print(f"DummyLogger.debug({msg})")
    # logger_0 = DummyLogger()
    # @LoggedFunction(logger_0)
    # def add(x, y):
    #     return x+y
    # assert add(1, 2) == 3
    # print(f"{add.__name__} = {add}")

    test_case_0()

# Unit test

# Generated at 2022-06-26 01:22:48.791727
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session = build_requests_session()
    logger = logging.getLogger()
    logger.info("hello, world!")
    logger.critical("critical error!")
    logger.error("error!")
    for i in range(10):
        logger.debug("hello, world!")
    logger.info("hello, world!")

    logger.setLevel("DEBUG")
    logger.info("hello, world!")
    logger.critical("critical error!")
    logger.error("error!")
    for i in range(10):
        logger.debug("hello, world!")
    logger.info("hello, world!")


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:22:55.347860
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from typing import Dict
    from typing import List
    from typing import Tuple

    class Logger:
        def __init__(self):
            self.record: Dict[str, Tuple[int, List[str]]] = {}

        def debug(self, msg):
            self.record.setdefault(msg, [0, []])
            self.record[msg] = (self.record[msg][0] + 1, self.record[msg][1])

    def test_func(a, b=2, c=3):
        return str(a) + "-" + str(b) + "-" + str(c)

    logger = getLogger("test")
    logger.setLevel("DEBUG")

    func_logger = LoggedFunction(logger)
    func_1 = func

# Generated at 2022-06-26 01:22:56.472738
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()
test_LoggedFunction___call__()

# Generated at 2022-06-26 01:23:05.989909
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_function_0():
        pass
    def test_function_1(a, b, c = None, d = 0, e = "my_string"):
        pass
    def test_function_2(a, b, c = None, d = 0, e = {}):
        pass
    logger = logging.getLogger("logged_function_test")
    logged_function = LoggedFunction(logger)
    logged_test_function_0 = logged_function(test_function_0)
    logged_test_function_1 = logged_function(test_function_1)
    logged_test_function_2 = logged_function(test_function_2)
    
    # Test case0
    logged_test_function_0()
    # Test case1

# Generated at 2022-06-26 01:23:14.684423
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Given a logger object
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # formatter = logging.Formatter('%(levelname)s - %(message)s')
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    print(f"logger.level:{logger.getEffectiveLevel()}")

    # and an LoggedFunction object constructed with above logger object
    logged_function = LoggedFunction(logger)

    # and a function (e.g. test_case_0)
    test_func = test_case

# Generated at 2022-06-26 01:23:19.876139
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def _test(logger):
        _logger = logger or set_logger()
        LoggedFunction(_logger)(test_case_0)()
        compare_logger(
            _logger,
            out_log=f"""\
test_case_0()""",
        )
        return True
    assert_function_execution(_test)

test_LoggedFunction___call__()

# Generated at 2022-06-26 01:23:22.765057
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=logging.getLogger(__name__))
    def foo(a, b=2, c=3.14):
        return a + b + c
    foo(1, 2, 3)



# Generated at 2022-06-26 01:23:31.955165
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from unittest.mock import patch
    from logging import StreamHandler, DEBUG, Logger

    def test_func(a: int, b: str, c: str=None) -> str:
        pass

    # Create logger and stream
    s = StringIO()
    handler = StreamHandler(s)
    handler.setLevel(DEBUG)
    logger = Logger("test", level=DEBUG)
    logger.addHandler(handler)

    # Create LoggedFunction with logger as parameter
    decorator_0 = LoggedFunction(logger)

    # Make sure correct log will be output
    with patch("logging.Logger.debug") as debug_mock:
        # Call the decorated test_func with no parameter
        test_0 = decorator_0(test_func)
        test_0()
        exp_

# Generated at 2022-06-26 01:23:36.964446
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import sys

    class LoggedFunction___call__Test(unittest.TestCase):
        def setUp(self):
            logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
            self.logger = logging.getLogger(__name__)
            self.instance = LoggedFunction(self.logger)

        def test_0(self):
            self.instance(test_case_0)

# Generated at 2022-06-26 01:23:45.502933
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def __call__(self, func):
        @functools.wraps(func)
        def logged_func(*args, **kwargs):
            # Log function name and arguments
            self.logger.debug(
                "{function}({args}{kwargs})".format(
                    function=func.__name__,
                    args=", ".join([format_arg(x) for x in args]),
                    kwargs="".join(
                        [f", {k}={format_arg(v)}" for k, v in kwargs.items()]
                    ),
                )
            )

            # Call function
            result = func(*args, **kwargs)

            # Log result
            if result is not None:
                self.logger.debug(f"{func.__name__} -> {result}")
            return result



# Generated at 2022-06-26 01:25:24.928323
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger("{name}_0".format(name="logger_0"))
    # logger_0.debug("\n" + "logger_0".rjust(30, "*"))
    logged_function_0 = LoggedFunction(logger_0)
    logged_function_1 = logged_function_0(test_case_0)
    logged_function_1()

if __name__ == "__main__":
    test_LoggedFunction___call__()