

# Generated at 2022-06-26 01:15:24.057831
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session()

# Generated at 2022-06-26 01:15:24.851687
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:15:27.007990
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    try:
        test_case_0()
    except:
        print("Exception raised")



# Generated at 2022-06-26 01:15:29.298482
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, 1)
    assert isinstance(session.hooks, dict)
    assert session.hooks["response"] is not None


# Generated at 2022-06-26 01:15:31.750910
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Building the data structure


    # Invoking the method
    logged_function_0 = LoggedFunction({})
    logged_function_0
    print('test_case 0')




# Generated at 2022-06-26 01:15:36.536662
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import __main__ as main
    function = main.__getattribute__(next(x for x in dir(main) if x.startswith('test_LoggedFunction___call__')))
    logged_function = LoggedFunction(None)
    logged_function(function)()

test_LoggedFunction___call__()

# Generated at 2022-06-26 01:15:45.012339
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    str_0 = ""
    str_1 = '8l'
    str_2 = ",t"
    def func_0(arg_0, arg_1, arg_2, arg_3):
        return arg_2
    str_3 = 'ci"'
    str_4 = 'd9!'
    def func_1(arg_0, arg_1):
        return arg_1
    list_0 = [str_0, str_1, str_2]
    list_1 = [str_3, str_4]

# Generated at 2022-06-26 01:15:45.766513
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:15:48.530346
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    str_0 = ',.=fz'
    dict_0 = {str_0: str_0, str_0: str_0}
    logged_function_0 = LoggedFunction(dict_0)
    class_0 = type('',(),{})
    class_0.a = 'f'
    class_0.b = '_h'
    def function_0(a, b):
        pass
    logged_function_0(function_0)
    logged_function_0(hash)
    logged_function_0(class_0.a)
    logged_function_0(class_0.b)

# Generated at 2022-06-26 01:15:50.913008
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session()
    build_requests_session(None, None)
    build_requests_session(None, None, None)
    build_requests_session(None, False)


# Generated at 2022-06-26 01:15:57.286713
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    lf = LoggedFunction(logger)
    lf(test_case_0)()

# Generated at 2022-06-26 01:16:09.100460
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def f1(param_1: int, param_2: str):
        return param_1 + len(param_2)

    def f2(param: str, *args, param_2: str, **kwargs):
        pass

    def f3(param_1: int, param_2: str):
        return param_1 + len(param_2)

    # Test case 1
    logged_f1 = LoggedFunction(logger=None)(f1)
    logged_f1(1, "abc")

    logged_f2 = LoggedFunction(logger=None)(f2)
    logged_f2("abc", "qwqwqw", param_2="qwqwqw", qwqwqw=True)

    logged_f3 = LoggedFunction(logger=None)(f3)
    logged

# Generated at 2022-06-26 01:16:14.377030
# Unit test for function build_requests_session
def test_build_requests_session():
    session_1 = build_requests_session(raise_for_status=False)
    session_2 = build_requests_session(retry=False)
    session_3 = build_requests_session(retry=5)


# Generated at 2022-06-26 01:16:23.338268
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest, logging
    from math import sin
    target = LoggedFunction(logging)
    decorated = target.__call__(sin)
    test_cases = [
        (1, 0.8414709848078965),
        (2, 0.9092974268256817),
        (3, 0.1411200080598672),
    ]
    unittest.TestCase().assertEqual(decorated(1), 0.8414709848078965)
    unittest.TestCase().assertEqual(decorated(2), 0.9092974268256817)
    unittest.TestCase().assertEqual(decorated(3), 0.1411200080598672)



# Generated at 2022-06-26 01:16:30.340561
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from mjtestpy import LoggedFunction

    # Arrange
    logger = logging.getLogger("test_logger")
    decorator = LoggedFunction(logger)
    
    # Act
    def func_0(arg_0, arg_1, kwarg_0 = 1, kwarg_1 = 2, kwarg_2 = 3):
        pass

    decorated_func_0 = decorator(func_0)
    decorated_func_0(1, 2, kwarg_0 = 1, kwarg_1 = 2, kwarg_2 = 3)

# Generated at 2022-06-26 01:16:37.246813
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup
    session_0 = build_requests_session()
    logger_0 = logging.getLogger(__name__)
    logger_0.setLevel(logging.DEBUG)
    logger_0.addHandler(logging.StreamHandler())
    logged_function_0 = LoggedFunction(logger_0)

    # Test
    test_case_0()

    # Teardown
    logger_0.handlers = []


# Generated at 2022-06-26 01:16:44.050012
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import pytest
    import requests

    index_url = "https://httpbin.org/"

    class MockLogger:
        def __init__(self):
            self.log = ""

        def debug(self, log):
            self.log += log + "\n"

    mock_logger = MockLogger()

    def mock_request_function():
        """
        Mock a request function.
        """
        response = requests.get(index_url)
        return response.json()["url"]

    decorated_request_function = LoggedFunction(mock_logger)(mock_request_function)

    # Test case 0
    # No parameters
    decorated_request_function()

# Generated at 2022-06-26 01:16:54.963876
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    assert session_0.hooks is None, "hook should be none when raise_for_status is False"
    session_1 = build_requests_session(True)
    assert len(session_1.hooks["response"]) == 1, "hook should be one when raise_for_status is True"
    session_2 = build_requests_session(False, Retry(total=100))
    assert session_2.adapters['http://'].max_retries.total == 100, "http retry should be 100 when raise_for_status is False"
    assert session_2.adapters['https://'].max_retries.total == 100, "https retry should be 100 when raise_for_status is False"

# Generated at 2022-06-26 01:17:02.459738
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch
    from logging import Logger
    # Mock a logger instance
    mocked_logger = Logger("mocked_logger")
    mocked_debug = patch.object(mocked_logger, "debug")
    mocked_logger.debug = mocked_debug.start()
    # Create a logged function with mocked logger and then test logged_func
    logged_function = LoggedFunction(mocked_logger)
    def func_0(x: int, y: int, z: int) -> int:
        return x * y * z
    logged_func_0 = logged_function(func_0)
    assert(logged_func_0(1, 2, 3) == 6)
    mocked_logger.debug.assert_called_with("func_0(1, 2, 3)")
   

# Generated at 2022-06-26 01:17:03.752911
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()

# Generated at 2022-06-26 01:17:10.612354
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=logging.getLogger(__name__))
    def add(x, y):
        return x + y
    result = add(1, 2)
    assert result == 3

if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:16.652399
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import os
    import sys
    import unittest
    import requests
    import logging
    import tempfile
    
    logging.getLogger().setLevel(logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def func():
        return 0

    # Test that output is present
    
    # Test that output is present
    
    
    


# Generated at 2022-06-26 01:17:22.040415
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create logger
    logger = logging.getLogger(__name__)

    # LoggedFunction
    _logged_function = LoggedFunction(logger)

    # Call __call__
    assert_equal(_logged_function(test_case_0), None)

    assert_equal(logging.getLogger(__name__).getEffectiveLevel(), logging.DEBUG)

# Generated at 2022-06-26 01:17:33.744482
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test for instance LoggedFunction(logging.Logger)
    logger_0 = logging.Logger()
    _instance_type_0 = type(logger_0)
    _instance_type_1 = logging.Logger
    assert isinstance(logger_0, logging.Logger)
    def function_0():
        return 0
    _instance_type_2 = type(function_0)
    _instance_type_3 = function_0
    def function_1():
        return 0
    _instance_type_4 = type(function_1)
    _instance_type_5 = function_1
    _instance_type_6 = type(function_1())
    _instance_type_7 = int
    _instance_type_8 = int
    def function_2():
        return 0
    _instance_type_

# Generated at 2022-06-26 01:17:45.173501
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest


    class LoggedFunctionTestCase(unittest.TestCase):
        def test_case_0(self):
            from fdkcc import utils

            logging.basicConfig(stream=sys.stdout)
            log = logging.getLogger(__name__)
            log.setLevel(logging.DEBUG)

            @utils.LoggedFunction(log)
            def fun(arg_0):
                return arg_0

            fun(123)

            @utils.LoggedFunction(log)
            def fun_0(arg_0, arg_1):
                return arg_0 + arg_1

            fun_0(123, 456)


# Generated at 2022-06-26 01:17:52.137966
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    lfunc = LoggedFunction(logger)
    @lfunc
    def fun(x, *args, y=1, **kwargs):
        return x + y
    fun(1, 2, 3, y=4, z=5)


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:58.833374
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import tempfile
    import os
    import logging
    import logging.config
    import datetime
    
    config = """
    [loggers]
    keys=root
    
    [handlers]
    keys=console
    
    [formatters]
    keys=simple
    
    [logger_root]
    level=DEBUG
    handlers=console
    
    [handler_console]
    level=DEBUG
    formatter=simple
    class=StreamHandler
    args=(sys.stdout,)
    
    [formatter_simple]
    format=%(asctime)s - %(name)s - %(levelname)s - %(message)s
    datefmt=
    class=logging.Formatter
    """


# Generated at 2022-06-26 01:18:00.146197
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_1 = build_requests_session(retry=False)

# Generated at 2022-06-26 01:18:02.388112
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session = build_requests_session(False)
    test_case_0()
    test_case_1(session)


# Generated at 2022-06-26 01:18:06.286972
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test logger")
    def a_func(*args, **kwargs):
        return str(kwargs)
    logged_func = LoggedFunction(logger)(a_func)
    logged_func("arg1", arg2=2)

# Generated at 2022-06-26 01:18:15.637167
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()
    logger.info(f"logger={logger}")
    decorator = LoggedFunction(logger)
    @decorator
    def test_function(x, y, z, a=1, b=2, c=3):
        return x * y * z * a * b * c
    assert test_function(1, 2, 3, a=1) == 36


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:18:17.824729
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    lf = LoggedFunction(logger)

    assert lf.logger == logger
    fn = lf(session_0)
    fn()

# Generated at 2022-06-26 01:18:19.379618
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    p = LoggedFunction(logger)
    p(test_case_0)()

test_LoggedFunction___call__()

# Generated at 2022-06-26 01:18:20.400902
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


# Generated at 2022-06-26 01:18:21.799767
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)

# Generated at 2022-06-26 01:18:30.632078
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create a logger.
    logger_0 = logging.Logger("logger_0", level=logging.INFO)

    # Create a new instance of class LoggedFunction.
    logged_function_0 = LoggedFunction(logger_0)

    # Call LoggedFunction.__call__()
    test_case_0 = logged_function_0.__call__(test_case_0)


# Generated at 2022-06-26 01:18:33.625740
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    t = LoggedFunction(session_0)
    t(session_0.get)



# Generated at 2022-06-26 01:18:41.665752
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import patch

    logger = logging.getLogger("TEST")

    @LoggedFunction(logger)
    def func_0(a_0, a_1, a_2=3):
        pass

    func_0(1, 2)
    func_0(1, 2, 3)
    func_0(1, 2, a_2=3)
    func_0(1, 2, a_2=3, a_1="HI")
    with patch.object(logger, "debug") as mock_debug:
        func_0(1, 2, a_2=3)
        mock_debug.assert_called_with("func_0(1, '2', a_2=3)")
        mock_debug.reset_mock()
        func_0

# Generated at 2022-06-26 01:18:43.808306
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger)
    def func_0(arg_0, arg_1, arg_2=None):
        pass


# Generated at 2022-06-26 01:18:57.173221
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock, call
    import logging

    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("[%(asctime)s] %(levelname)s - %(name)s: %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger_mock = Mock()
    func_mock = Mock(return_value=1)
    logged_func = LoggedFunction(logger_mock)(func_mock)
    logged_func(1, 2, 3)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:19:01.233048
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    session_1 = build_requests_session(raise_for_status=False)
    session_2 = build_requests_session(retry=3)
    session_3 = build_requests_session(retry=False)

# Generated at 2022-06-26 01:19:06.901179
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def foo(a, b=None): return a + b if b is not None else a

    @LoggedFunction(logger=None)
    def foo_a(a, b=None): return a + b if b is not None else a

    assert foo(a=1) == foo_a(a=1)
    assert foo(a=1, b=2) == foo_a(a=1, b=2)

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:19:09.070961
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    expected_result = "n/a"
    actual_result = "n/a"
    assert expected_result == actual_result


# Generated at 2022-06-26 01:19:19.168922
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test for function without a return
    def test_func_0(param_0, param_1=None):
        return
    test_func_0_logged = LoggedFunction(Logger())(test_func_0)
    # Test case 0
    test_func_0_logged(0, 1)

    # Test for function with return
    def test_func_1(param_0=None):
        return param_0
    test_func_1_logged = LoggedFunction(Logger())(test_func_1)
    # Test case 0
    test_func_1_logged(0)

    # Test for function with multiple parameters
    def test_func_2(param_0, param_1, param_2):
        return param_0

# Generated at 2022-06-26 01:19:26.225040
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=logging.getLogger(__name__))
    def test_func(a, b=1, **kwargs):
        return a ** b

    test_func(2)
    test_func(a=2)
    test_func(2, 3)
    test_func(a=2, b=3)
    test_func(2, b=3)
 #   test_func(2, 3, 4, b=5) # raise an exception


# Generated at 2022-06-26 01:19:27.318086
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)

# Generated at 2022-06-26 01:19:30.233786
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    wrapped_func = LoggedFunction(logger)(compare_columns)
    wrapped_func(11, 4)

# Generated at 2022-06-26 01:19:32.333559
# Unit test for function build_requests_session
def test_build_requests_session():
    Session = build_requests_session()

    assert isinstance(Session, type(Session())) == True
    assert isinstance(Session, requests.Session) == True



# Generated at 2022-06-26 01:19:33.345779
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    session_0.auth = ('user', 'pass')
    test_case_0()

# Generated at 2022-06-26 01:19:36.683749
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from basket_index.index_client import IndexClient

    logger = logging.getLogger("IndexClient")
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s %(name)-12s %(levelname)-8s %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    client = IndexClient(logger, basket_index_url="http://localhost:9200")
    client.get_basket_index(index_name="index_name")

# Generated at 2022-06-26 01:19:46.939333
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func0(*args, **kwargs):
        pass

    # Fixture
    logger = Logger.getLogger("test_LoggedFunction___call__")

    # Execution
    wrapped_func = LoggedFunction(logger)(func0)

    # Test
    assert wrapped_func.__name__ == "func0"

# Generated at 2022-06-26 01:19:51.641798
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = lambda *arg, **kwargs: print(*arg, **kwargs)
    func = lambda *args, **kwargs: print(*args, **kwargs)
    logged_func = LoggedFunction(logger)(lambda *args, **kwargs: print(*args, **kwargs))
    logged_func("hello")

# Generated at 2022-06-26 01:19:58.282225
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    class FakeLogger():
        def __init__(self):
            self.log = ""

        def debug(self, log_msg):
            self.log = log_msg

    logger = FakeLogger()
    logged_function = LoggedFunction(logger)
    def test_function(num_1, num_2, str_1, str_2):
        return num_1 + num_2

    # Act
    logged_function(test_function)(1, 2, "hello", "world")

    # Assert
    assert logger.log == "test_function(1, 2, 'hello', str_2='world')"

# Generated at 2022-06-26 01:19:59.437933
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    print(LoggedFunction(print)(test_case_0)().__code__.co_filename)

#  str(LoggedFunction(print)(test_case_0)()) does not work

test_LoggedFunction___call__()

# Generated at 2022-06-26 01:20:09.182392
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_1 = build_requests_session()
    session_2 = build_requests_session()
    session_3 = build_requests_session()
    session_4 = build_requests_session()
    session_5 = build_requests_session()
    session_6 = build_requests_session()
    session_7 = build_requests_session()
    session_8 = build_requests_session()
    session_9 = build_requests_session()
    session_10 = build_requests_session()
    session_11 = build_requests_session()
    session_12 = build_requests_session()
    session_13 = build_requests_session()
    session_14 = build_requests_session()
    session_15 = build_requests_session()
    session_16

# Generated at 2022-06-26 01:20:15.823314
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from requests.api import post

    import logging
    import unittest.mock

    class TestHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.records = []

        def emit(self, record):
            self.records.append(record)

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = TestHandler()
    logger.addHandler(handler)

    # Capturing result
    @LoggedFunction(logger)
    def test_func(*args, **kwargs):
        return post("http://httpbin.org/post", data={"x": "y"})


# Generated at 2022-06-26 01:20:20.087371
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # initialize global variable
    global LOGGER
    LOGGER = getLogger(logger_name)
    # create a handle for logged function
    logged_function = LoggedFunction(logger)
    # test __call__ of class LoggedFunction using LoggedFunction
    @logged_function
    def test_function(x, y=0):
        """Just a test function to test LoggedFunction.__call__."""
        return x + y

    # wrap test_function by a handle of LoggedFunction
    test_function(1, y=2)


if __name__ == "__main__":
    # set logger level, in this case it will log DEBUG and above
    logger_level = DEBUG
    # logger name
    logger_name = "LoggedFunction"
    # get a logger
    logger = getLogger(logger_name)
   

# Generated at 2022-06-26 01:20:26.915791
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    lf = LoggedFunction(logger)
    a = 10
    b = 20
    c = lf.__call__(add)(a,b)
    assert c == a + b
    a = "hello world"
    b = "good morning"
    c = lf.__call__(add)(a,b)
    assert c == a + b

# Generated at 2022-06-26 01:20:33.772943
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest import mock
    from requests import Session

    logger_0 = logging.getLogger(__name__)

    @LoggedFunction(logger_0)
    def logged_func_0(*args, **kwargs):
        return int(args[0] / args[1])

    logged_func_0(24, 8)

    @LoggedFunction(logger_0)
    def logged_decorated_func_0():
        return 'foo'

    logged_decorated_func_0()

    @LoggedFunction(logger_0)
    def logged_decorated_func_1():
        return None

    logged_decorated_func_1()


# Generated at 2022-06-26 01:20:46.247292
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # 1. Create a logger
    logger = logging.getLogger('logged_func')
    logger.setLevel(logging.WARNING)
    logger.addHandler(logging.StreamHandler())
    # 2. Create a LoggedFunction instance
    logged_func = LoggedFunction(logger)
    # 3. Call the __call__ method
    import random
    # 3.1. Define a function taking no arguments
    def func():
        return random.randint(1, 100)
    logged_func_0 = logged_func(func)
    assert logged_func_0() == func()
    # 3.2. Define a function taking arguments
    def func(a, b, *c):
        return a + b + sum(c)
    logged_func_1 = logged_func(func)
    assert logged_func_1

# Generated at 2022-06-26 01:20:57.905025
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MagicMock()
    logged_function = LoggedFunction(logger)
    f = lambda x: x ** 2
    f = logged_function.__call__(f)
    f(2)
    logger.debug.assert_called_once_with("f(2)")

# Generated at 2022-06-26 01:21:02.061325
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    session_0.proxies = {'http': 'http://www-cache.reith.bbc.co.uk:80', 'https': 'http://www-cache.reith.bbc.co.uk:80'}
    session_0.headers = {'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'User-Agent': 'python-requests/2.18.4'}
    session_0.hooks['response'] = [lambda r, *args, **kwargs: r.raise_for_status()]

    test_obj_0 = LoggedFunction(logging.getLogger())
    test_func_0 = test_obj_0(session_0.head)

    #print(test_func_0.__glob

# Generated at 2022-06-26 01:21:04.294160
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_fns = [
        test_case_0
    ]
    for fn in test_fns:
        fn()

# Generated at 2022-06-26 01:21:14.138335
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger("test_LoggedFunction")

    @LoggedFunction(log)
    def test_func(a, b, c=None, d="None"):
        print(f"{a}, {b}, {c}, {d}")
        return a + b + c + d

    test_func(1, 2, c=3, d=4)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:21:14.964943
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()


# Generated at 2022-06-26 01:21:21.719926
# Unit test for function build_requests_session
def test_build_requests_session():

    session = build_requests_session()
    assert isinstance(session,Session)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert isinstance(session.adapters['https://'], HTTPAdapter)
    assert isinstance(session.adapters['http://'], HTTPAdapter)
    assert isinstance(session.adapters['https://'].max_retries, Retry)
    assert isinstance(session.adapters['http://'].max_retries, Retry)

    session = build_requests_session(False)
    assert isinstance(session, Session)
    assert not hasattr(session, 'hooks')
    assert isinstance(session.adapters['https://'], HTTPAdapter)

# Generated at 2022-06-26 01:21:32.026231
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import datetime
    import json
    import logging
    import random

    import requests
    from requests.models import Request

    class RequestLogger(logging.LoggerAdapter):
        def process(self, msg, kwargs):
            return f"{datetime.datetime.utcnow().isoformat()} : " f"{msg}", kwargs

    logger = RequestLogger(logging.getLogger("LoggedFunctionTest"), {})

    test_method_0_url = "http://127.0.0.1:80"
    test_method_0_method = "get"
    test_method_0_adapter = requests.adapters.HTTPAdapter()
    test_method_0_adapter.max_retries = Retry(connect=3, backoff_factor=0.5)
    test_

# Generated at 2022-06-26 01:21:41.897220
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from logging import Logger
    from enum import Enum
    from random import random, randint, choice
    import requests
    import functools
    import requests
    import sys
    import io
    logger = logging.getLogger("LoggedFunction")
    if not logger.hasHandlers():
        logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)
    class RequestMethod(Enum):
        GET = "GET"
        POST = "POST"
    class ApiType(Enum):
        ODS_API = "ODS_API"
        WEB_API = "WEB_API"
        BILLING_API = "BILLING_API"
        ACCOUNT_API = "ACCOUNT_API"

# Generated at 2022-06-26 01:21:42.878454
# Unit test for function build_requests_session

# Generated at 2022-06-26 01:21:52.224568
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("a_logger_name")
    logger.setLevel(logging.DEBUG)
    # logger.addHandler(logging.StreamHandler())
    logged_func = LoggedFunction(logger)

    test_functions = {
        "f0": lambda a, b, c: a + b + c,
        "f1": lambda a, b, c="c": a + b + c,
        "f2": lambda a, b, c=None: a + b + c,
    }

    for func in test_functions.values():
        logged_func(func)(1, 2, 3)


test_LoggedFunction___call__()

# Generated at 2022-06-26 01:22:17.490520
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger, DEBUG
    logger = getLogger("LoggedFunction")
    logger.setLevel(DEBUG)

    @LoggedFunction(logger)
    def testFunc(a, b, c=1, d=2):
        return c

    assert testFunc(0, 1, 2, 3) == 2
    assert testFunc(0, 1, 3) == 3
    assert testFunc(2, 3) == 1

# Generated at 2022-06-26 01:22:19.610398
# Unit test for function build_requests_session
def test_build_requests_session():
    session_1 = build_requests_session()
    assert type(session_1) == Session



# Generated at 2022-06-26 01:22:23.354392
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = Logger("")
    loggedFunction_0 = LoggedFunction(logger_0)
    function_0 = lambda: list(chain.from_iterable(set(chain.from_iterable(set()))))
    loggedFunction_0.__call__(function_0)


# Generated at 2022-06-26 01:22:28.469930
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger()
    logged_function_0 = LoggedFunction(logger_0)
    print(logged_function_0.__call__(test_case_0))


if __name__ == '__main__':
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:22:29.653534
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()


# Generated at 2022-06-26 01:22:30.658415
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


# Generated at 2022-06-26 01:22:39.271910
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=logging.getLogger("test_log_name"))
    def func_0(*args, **kwargs):
        print("func_0", args, kwargs)
    
    func_0("1", "2", arg_0=True, arg_1=False)
    func_0("1", arg_0=True)
    func_0("1", "2", "3")
    func_0("1")



# Generated at 2022-06-26 01:22:49.305286
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger)
    def func(a, b):
        pass
    logger.debug(func.__name__)
    func(1, 2)
    func(3)
    pass


if __name__ == "__main__":

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)



# Generated at 2022-06-26 01:22:51.220937
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from .logger_factory import logger_factory
    logger = logger_factory()
    logged_function = LoggedFunction(logger)
    logged_function(test_case_0)

# Generated at 2022-06-26 01:22:53.302349
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = build_requests_session()
    logger.debug("Method build_requests_session was invoked with arguments ():")
    logger.debug("Method build_requests_session returned"  +  ": " + str(session_0))

# Generated at 2022-06-26 01:23:42.919280
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    from io import StringIO
    import logging
    from unittest import TestCase
    from unittest.mock import patch


    class LoggedFunctionTest(TestCase):
        def setUp(self):
            self.test_logger = logging.getLogger("test_logger")
            self.test_logger.addHandler(logging.StreamHandler(stream=StringIO()))
            self.test_logger.setLevel(logging.DEBUG)

        def test_LoggedFunction___call__(self):
            """
            Test method __call__ of LoggedFunction.
            """
            test = LoggedFunction(self.test_logger)
            @test
            def test_target_func(a, b, c=True):
                return a + b



# Generated at 2022-06-26 01:23:51.647785
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger()
    logged_function_0 = LoggedFunction(logger_0)
    def func_0(*args, **kwargs):
        query_0 = Query.from_file("/home/ubuntu/git/analysis-of-iterative-data-access-patterns-in-python/querys/test_for_first_test_case.sql")
        query_0.to_csv("/home/ubuntu/git/analysis-of-iterative-data-access-patterns-in-python/querys/test_for_first_test_case.csv")
        query_0 = Query.from_file("/home/ubuntu/git/analysis-of-iterative-data-access-patterns-in-python/querys/test_for_first_test_case.sql")
        query_0

# Generated at 2022-06-26 01:23:52.610078
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()

# Generated at 2022-06-26 01:24:00.660996
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.last_msg = None
        def debug(self, msg):
            self.last_msg = msg
    func_f = LoggedFunction(MockLogger())
    def func(arg1, arg2=1, *args):
        pass
    func = func_f(func)
    args = (1, 2, 3, 4)
    kwargs = {'arg2': 1, 'arg3': 3}
    func(*args, **kwargs)
    func_name = func.__name__
    assert func.__doc__ == func_f.__doc__, 'func doc err'
    assert func.__name__ == func_name, 'func name err'

# Generated at 2022-06-26 01:24:04.393829
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func():
        pass

    logger = getLogger(__name__)
    decorator = LoggedFunction(logger)
    func = decorator(test_func)
    func()
    logger.debug('test_LoggedFunction___call__ OK')


# unit tests for the function build_requests_session

# Generated at 2022-06-26 01:24:11.666683
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    
    class MockLogger:
        def debug(self, msg):
            pass
            
    logger = MockLogger()
    func = MagicMock()
    logged_function = LoggedFunction(logger)
    
    # Case: the function should be called
    with patch.object(logged_function, '_call_func', return_value='mock_result') as mock_call_func:
        logged_function.__call__(func)('arg1', kwarg1='kwarg1')
        
        mock_call_func.assert_called_once_with(func, 'arg1', kwarg1='kwarg1')
    
    # Case: the function should not be called

# Generated at 2022-06-26 01:24:19.417943
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    class TestLogger:
        def __init__(self, level: str) -> None:
            self.level = level
            self.lines = []

        def debug(self, message: str) -> None:
            if self.level == "debug":
                self.lines.append(message)

        def info(self, message: str) -> None:
            if self.level in ("debug", "info"):
                self.lines.append(message)

        def warn(self, message: str) -> None:
            if self.level in ("debug", "info", "warn"):
                self.lines.append(message)


# Generated at 2022-06-26 01:24:28.438725
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('test_LoggedFunction___call__')
    logger.debug('test_LoggedFunction___call__')
    def test_function(x, y):
        logger.debug(f'test_function({x}, {y})')
        return x + y
    logger_0 = logging.getLogger('test_LoggedFunction___call___0')
    logger_0.debug('test_LoggedFunction___call___0')
    test_function_logged = LoggedFunction(logger_0)(test_function)
    test_function_logged(1, 2)


if __name__=="__main__":
    # Set logger for debug debug
    logging.basicConfig(level=logging.DEBUG)

    # Tests run
    test_case_0()
    test_LoggedFunction___

# Generated at 2022-06-26 01:24:30.274982
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:24:33.877302
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    try:
        x = LoggedFunction("test_LoggedFunction___call__")
    except Exception as e:
        print("test_LoggedFunction___call__ failed: " + str(e))
    else:
        print("test_LoggedFunction___call__ succeeded")
