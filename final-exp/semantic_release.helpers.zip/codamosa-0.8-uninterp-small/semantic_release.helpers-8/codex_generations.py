

# Generated at 2022-06-26 01:15:24.967202
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_input():
        pass
    output = LoggedFunction(logger=None)(test_input)
    assert output == test_input

# Generated at 2022-06-26 01:15:34.831381
# Unit test for function build_requests_session
def test_build_requests_session():
    session_1 = build_requests_session(
        raise_for_status=False, retry=False
    )
    assert session_1.hooks == {}
    assert not hasattr(session_1.adapters, "http://")
    assert not hasattr(session_1.adapters, "https://")

    session_2 = build_requests_session(raise_for_status=True, retry=True)
    assert session_2.hooks == {
        "response": [lambda r, *args, **kwargs: r.raise_for_status()]
    }
    assert isinstance(session_2.adapters["http://"].max_retries, Retry)
    assert isinstance(session_2.adapters["https://"].max_retries, Retry)

    session_3 = build_

# Generated at 2022-06-26 01:15:35.552459
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    sys.setrecursionlimit(100000)
    assert test_case_0() == None

# Generated at 2022-06-26 01:15:44.046579
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func():
        pass

    def logged_func(*args, **kwargs):
        # Log function name and arguments
        self.logger.debug(
            "{function}({args}{kwargs})".format(
                function=func.__name__,
                args=", ".join([format_arg(x) for x in args]),
                kwargs="".join(
                    [f", {k}={format_arg(v)}" for k, v in kwargs.items()]
                ),
            )
        )

        # Call function
        result = func(*args, **kwargs)

        # Log result
        if result is not None:
            self.logger.debug(f"{func.__name__} -> {result}")
        return result



# Generated at 2022-06-26 01:15:51.651720
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('test_LoggedFunction___call__')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    @LoggedFunction(logger)
    def myprint(a, b, c=3, d=[], e={}):
        pass

    myprint(1, 2)
    myprint(1, 2, e={'a': [1, 2, 3]})


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:15:56.983804
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create mock logger
    class MockLogger:
        def __init__(self):
            self.debug_logs = []

        def debug(self, message):
            self.debug_logs.append(message)

    # Create mock function
    class Mock:
        def mock_function(
            self, a, b, c=None, d="default", e=99, f=[], g={}, h=set(), i=None
        ):
            i = i if i != None else 99
            return (a, b, c, d, e, f, g, h, i)

    # Create a LoggedFunction wrapper
    mock_logger = MockLogger()
    decorator = LoggedFunction(mock_logger)
    function = decorator(Mock().mock_function)

    # Call the decorated function, checks that the

# Generated at 2022-06-26 01:16:08.914883
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    print("Test start: test_LoggedFunction___call__")
    import io
    import logging
    import sys
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger = logging.getLogger("Logger")
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def add(a, b):
        return a + b

    add(1,2)
    add(3,4)
    stream.seek(0)
    stream_value = stream.read()
    assert stream_value == "DEBUG:Logger:add(1, 2)\nDEBUG:Logger:add -> 3\nDEBUG:Logger:add(3, 4)\nDEBUG:Logger:add -> 7\n"
    print("test_LoggedFunction___call__ passed")

test_

# Generated at 2022-06-26 01:16:13.058498
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    def test_func_0():
        pass

    logged_func = LoggedFunction(None)
    assert logged_func(test_func_0) == test_func_0

# Generated at 2022-06-26 01:16:19.451220
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=logger)
    def func_0(a, b):
        logger.debug(f"func_0: entered with {a} and {b}.")
        return a + b

    assert func_0(1, 2) == 3
    assert func_0("abc", "def") == "abcdef"

# Generated at 2022-06-26 01:16:23.066591
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logger import Logger

    logger = Logger("test")
    def foo():
        print('foo')

    foo_logged = LoggedFunction(logger)(foo)
    foo_logged()

test_case_0()

# Generated at 2022-06-26 01:16:29.242159
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    func = LoggedFunction(logger)(test_case_0)
    func()

if __name__ == '__main__':
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:16:43.674454
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logger.debug("TEST START")
    logged_function = LoggedFunction(logger)
    @logged_function
    def test_function(a, b=8):
        return a + b

    test_function(2)
    test_function(2, 3)
    test_function(b=1, a=2)
    test_function(1, 2, 3)
    logger.debug("TEST END")

# Generated at 2022-06-26 01:16:49.951441
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    @LoggedFunction(logger)
    def foo(a, b=0):
        return a + b + 1
    result = foo(1, b=2)
    print(f"result is {result}")

if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:00.106954
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from requests import Session
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    def build_requests_session(
        raise_for_status=True, retry: Union[bool, int, Retry] = True
    ) -> Session:
        """
        Create a requests session.
        :param raise_for_status: If True, a hook to invoke raise_for_status be installed
        :param retry: If true, it will use default Retry configuration. if an integer, it will use default Retry
        configuration with given integer as total retry count. if Retry instance, it will use this instance.
        :return: configured requests Session
        """
        session = Session()

# Generated at 2022-06-26 01:17:10.870174
# Unit test for function build_requests_session
def test_build_requests_session():
    print("Test for build_requests_session(False)")
    session_0 = build_requests_session()
    print("OK")

    print("Test for build_requests_session(False)")
    session_0 = build_requests_session(False)
    print("OK")

    print("Test for build_requests_session(True)")
    session_1 = build_requests_session(True)
    print("OK")

    print("Test for build_requests_session(False,True)")
    session_1 = build_requests_session(False,True)
    print("OK")

    # print("Test for build_requests_session(False,5)")
    # session_1 = build_requests_session(False,5)
    # print("OK")


# Generated at 2022-06-26 01:17:20.981227
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger_0 = logging.Logger("test_logger")
    handler_0 = logging.StreamHandler()
    logger_0.addHandler(handler_0)
    logger_0.setLevel(logging.DEBUG)
    logged_func_0 = LoggedFunction(logger_0)
    @logged_func_0
    def test_func(a: int, b: str = None):
        print(a)
        print(b)
    test_func(1)
    test_func(1, "b")
    test_func(a=1, b="b")


if __name__ == "__main__":
    test_case_0()
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:25.766313
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func(arg_1, arg_2, Kwarg_1='kwarg_1'):
        pass
    logger = logging.getLogger()
    logged_func = LoggedFunction(logger)(test_func)
    logged_func('arg_1', arg_2=2)

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:17:29.396041
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    from common import LoggedFunction

    logger = Mock(logging.Logger)
    logged_func = LoggedFunction(logger)(lambda x: x * 2)
    result = logged_func(3)
    logger.debug.assert_any_call("<lambda>(3)")
    logger.debug.assert_any_call("<lambda> -> 6")
    assert result == 6


# Generated at 2022-06-26 01:17:31.310789
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger0 = logging.getLogger()
    logged_func = LoggedFunction(logger=logger0)(test_case_0)
    logged_func()

# Generated at 2022-06-26 01:17:35.686843
# Unit test for function build_requests_session
def test_build_requests_session():
    import threading
    import requests

    def run_test_case(test_case_func):
        lock = threading.Lock()
        def run_test_case_func_wrapper(*args, **kwargs):
            with lock:
                session_0 = build_requests_session()
            session_1 = build_requests_session()
            session_2 = build_requests_session()

            # Test if raised for status is enabled
            try:
                session_1.get("http://httpbin.org/status/418")
            except requests.HTTPError as e:
                pass
            else:
                raise AssertionError("'raise_for_status' is not enabled")

            # Test if retry is enabled
            session_2.get("http://httpbin.org/status/418")

            test_case_func

# Generated at 2022-06-26 01:17:45.941690
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = Logger("logger_0", level="DEBUG", propagate=False)
    logged_func_0 = LoggedFunction(logger_0)
    def func_0():
        pass
    logged_func_0(func_0)
    try:
        logged_func_0("test", caller=test_LoggedFunction___call__)
    except AssertionError:
        pass


# Generated at 2022-06-26 01:17:55.143225
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    class TestClass:
        def __init__(self, logger):
            self.logger = logger
            self.logged_func = LoggedFunction(logger)(TestClass.test_function_0)

        @LoggedFunction(logger)
        def test_function_1(a1, a2, a3, a4: str, a5: int):
            return "test_function_1"

        @staticmethod
        @LoggedFunction(logger)
        def test_function_2(a1, a2, a3, a4: str, a5: int):
            return "test_function_2"


# Generated at 2022-06-26 01:18:04.915945
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logging.root.setLevel(logging.DEBUG)
    logfile_handler = logging.FileHandler("test.log")
    formatter = logging.Formatter("%(asctime)s.%(msecs)d %(levelname)s: %(message)s", "%Y-%m-%d %H:%M:%S")
    logfile_handler.setFormatter(formatter)
    logging.root.addHandler(logfile_handler)

    logger = logging.getLogger("LoggedFunction")
    logged_func = LoggedFunction(logger)(test_case_0)
    logged_func()
    logging.info("finished")


if __name__ == '__main__':
    test_LoggedFunction___call__()

# Generated at 2022-06-26 01:18:06.142300
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func = lambda: None
    assert LoggedFunction(None)(func)() == func()

# Generated at 2022-06-26 01:18:16.285866
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Unit test for method __call__ of class LoggedFunction
    """
    from .logged_function import LoggedFunction
    from .logger import get_logger

    logger = get_logger(__name__)

    @LoggedFunction(logger)
    def run_method_0(a: int, b: float, c: str, d: bool):
        pass

    @LoggedFunction(logger)
    def run_method_1(a: int, b: float, c: str, d: bool) -> str:
        return "success"

    @LoggedFunction(logger)
    def run_method_2(a: int, b: float, c: str, d: bool) -> None:
        pass

    # Call run_method_0 and run_method_1

# Generated at 2022-06-26 01:18:16.736024
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass


# Generated at 2022-06-26 01:18:18.775553
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Logger(level=Logger.DEBUG)
    func = LoggedFunction(logger=logger)
    func_0 = func.__call__(test_case_0)
    func_0()



# Generated at 2022-06-26 01:18:32.348202
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """Function for testing __call__ in LoggedFunction.

    Returns:
        The string 'PASSED' if __call__ was called successfully,
        an error message otherwise.
    """
    import io
    import logging

    from .context import reports_generator

    # Create a dummy logger to use with LoggedFunction
    string_stream = io.StringIO()
    handler = logging.StreamHandler(string_stream)
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Create a LoggedFunction
    logged = reports_generator.LoggedFunction(logger)

    # Check that __call__ works as expected
    def test_case(x, y=1):
        """Dummy function for testing __call__ in LoggedFunction."""
        return x * y

    check

# Generated at 2022-06-26 01:18:41.389297
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Test:
        method_name = "method_0"
        @LoggedFunction("logger_0")
        def method_0(self, arg_0, arg_1, kwarg_1, kwarg_0=0):
            return arg_0 + arg_1 + kwarg_0 - kwarg_1
        def method_1(self, arg_0, arg_1, kwarg_1, kwarg_0=0):
            return self.method_2(arg_0, arg_1, kwarg_1, kwarg_0)

# Generated at 2022-06-26 01:18:43.563547
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    '''
    LoggedFunction.__call__
    '''
    def foo():
        print(123)

    case = LoggedFunction(foo)


# Generated at 2022-06-26 01:18:55.947030
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger_0 = logging.getLogger()
    logged_function_0 = LoggedFunction(logger_0)
    logged_function_0(test_case_0)

# Generated at 2022-06-26 01:19:04.513589
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logzero import logger

    session_1 = build_requests_session(raise_for_status=True)
    decorated = LoggedFunction(logger)(build_requests_session)(raise_for_status=True)
    assert decorated.__name__ == "build_requests_session"
    assert session_1.hooks.get("response")
    decorated = LoggedFunction(logger)(build_requests_session)(raise_for_status=False)
    assert decorated.__name__ == "build_requests_session"
    assert session_1.hooks.get("response") is None



# Generated at 2022-06-26 01:19:06.055528
# Unit test for function build_requests_session
def test_build_requests_session():
    test_session = build_requests_session()
    assert isinstance(test_session, Session)


# Generated at 2022-06-26 01:19:15.800758
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_1 = build_requests_session(retry=False)
    session_2 = build_requests_session(retry=0)
    session_3 = build_requests_session(retry=3)
    session_4 = build_requests_session(retry=Retry())
    session_5 = build_requests_session(raise_for_status=False)
    session_6 = build_requests_session(raise_for_status=False, retry=False)
    session_7 = build_requests_session(raise_for_status=False, retry=0)
    session_8 = build_requests_session(raise_for_status=False, retry=3)
    session_9 = build_requests_session(raise_for_status=False, retry=Retry())

# Generated at 2022-06-26 01:19:26.334520
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger

    import requests

    expected_result_0 = "abcd"

    logger_mock = getLogger()
    logger_mock.debug = lambda s, *args: print(s % args)
    logged_function_0 = LoggedFunction(logger_mock)
    functools.wraps(logged_function_0)(lambda *args, **kwargs: expected_result_0)

    result_0 = logged_function_0(None)
    if result_0 != expected_result_0:
        raise Exception(f"expected: {expected_result_0}, return value: {result_0}")

if __name__ == "__main__":
    test_case_0()
    from sys import argv


# Generated at 2022-06-26 01:19:31.108891
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from logging import DEBUG, basicConfig, getLogger
    from sys import stdout

    logger = getLogger(__name__)
    out = StringIO()
    basicConfig(level=DEBUG, stream=out)
    decorated = LoggedFunction(logger)(test_case_0)
    decorated()
    assert out.getvalue() == 'test_case_0()\n'



# Generated at 2022-06-26 01:19:31.971135
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session()


# Generated at 2022-06-26 01:19:41.484990
# Unit test for function build_requests_session
def test_build_requests_session():
    session_1 = build_requests_session(retry=True)
    # Check if retry is configured
    assert len(session_1.adapters) == 2
    assert 'http://' in session_1.adapters
    assert 'https://' in session_1.adapters
    # Check if raise_for_status is configured
    assert hasattr(session_1, 'hooks')
    assert session_1.hooks['response'] is not None
    # Check if max_retries is configured
    assert session_1.adapters['http://'].max_retries.total == 10
    assert session_1.adapters['https://'].max_retries.total == 10
    # Check if backoff_factor is configured
    assert 0.1 == session_1.adapters['http://'].max_retries.back

# Generated at 2022-06-26 01:19:52.967459
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # If a function is wrapped with LoggedFunction, when it is called, a log
    # will be generated.
    session_0 = build_requests_session()

    # Unit test for method __call__ of class LoggedFunction
    # The input arguments are logged before the function is called, and the
    # return value is logged once it has completed

    def func_0(logger):

        def logged_func(*args, **kwargs):
            logger.debug(
                "function_0({args}{kwargs})".format(
                    function="function_0",
                    args=", ".join([format_arg(x) for x in args]),
                    kwargs="".join(
                        [f", {k}={format_arg(v)}" for k, v in kwargs.items()]
                    ),
                )
            )

            result

# Generated at 2022-06-26 01:19:57.176785
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    logger_1 = logging.getLogger("Tester")
    logger_1.setLevel(logging.DEBUG)

    def foo_1(*args, **kwargs):
        logger_1.debug("Starting foo_1")
        return "test_result"

    foologger_1 = LoggedFunction(logger_1)

    result = foologger_1(foo_1)('123', 'abc', a=1, b=2)

    result = foologger_1(build_requests_session)(
        raise_for_status=True, retry=False)

    result = foologger_1(build_requests_session)(
        raise_for_status=True, retry=False)


# Generated at 2022-06-26 01:20:15.708003
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert type(session).__name__ == 'Session'



# Generated at 2022-06-26 01:20:20.023607
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestClass:
        def test_member(self):
            pass

    import logging
    from unittest.mock import Mock

    logger = Mock()

    test_function = LoggedFunction(logger=logger)
    logged_test_function = test_function(test_member)

    logged_test_function(11, "22", arg1=1, arg2="2")
    logger.debug.assert_called_with(
        "test_member(11, '22', arg1=1, arg2='2')"
    )

    test_instance = TestClass()
    logged_test_method = test_function(test_instance.test_member)

    logged_test_method(11, "22", arg1=1, arg2="2")

# Generated at 2022-06-26 01:20:27.980940
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    logger = logging.Logger("logger_test")
    handler = logging.StreamHandler(stream=sys.stdout)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logged = LoggedFunction(logger)
    @logged
    def foo(n):
        return n
    foo(1)
    foo(n=2)

# Generated at 2022-06-26 01:20:34.110411
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch
    import logging
    
    # Mocking module logging
    mock_logging = Mock()
    with patch.dict('sys.modules', {'logging': mock_logging}):
        from pyee import EventEmitter
        
        # Mocking class EventEmitter
        mock_EventEmitter = Mock(spec = EventEmitter)

# Generated at 2022-06-26 01:20:46.504603
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from debugger_protocol import logger
    from debugger_protocol import pydevd_command
    from debugger_protocol import pydevd_io
    from debugger_protocol import pydevd_poll_for_file_changes
    from debugger_protocol import pydevd_schedule_notification_thread
    from debugger_protocol import pydevd_set_debugger_for_thread
    from debugger_protocol import pydevd_set_exception_breakpoint
    from debugger_protocol import pydevd_set_next_statement
    from debugger_protocol import pydevd_set_pause

    lf_0 = LoggedFunction(logger)
    pydevd_command.LoggedFunction.__call__ = lf_0.__call__

    # test pydevconsole.write

# Generated at 2022-06-26 01:21:02.916836
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    assert session_0.hooks == {}
    assert not session_0.adapters['http://'].max_retries.total
    assert not session_0.adapters['https://'].max_retries.total

    session_1 = build_requests_session(raise_for_status=False)
    assert session_1.hooks == {}
    assert not session_1.adapters['http://'].max_retries.total
    assert not session_1.adapters['https://'].max_retries.total

    session_2 = build_requests_session(retry=False)
    assert session_2.hooks == {}
    assert not session_2.adapters['http://'].max_retries.total
    assert not session_2.adapters

# Generated at 2022-06-26 01:21:11.719841
# Unit test for function build_requests_session
def test_build_requests_session():
    session_1 = build_requests_session(True, True)
    session_2 = build_requests_session(False, True)
    session_3 = build_requests_session(True, 1)
    session_4 = build_requests_session(True, 3)
    session_5 = build_requests_session(False, Retry(connect = 1, read = 2))


if __name__ == '__main__':
    test_case_0()
    test_build_requests_session()

# Generated at 2022-06-26 01:21:19.072128
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = getlogger("LoggedFunction")
    logger.setLevel("DEBUG")
    ch = StreamHandler()
    ch.setLevel("DEBUG")
    formatter = Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    logged_function = LoggedFunction(logger)
    session_0 = build_requests_session()
    session_0 = logged_function(session_0)
    print(session_0.get("https://httpbin.org/get").json())
    print("end")

# Generated at 2022-06-26 01:21:28.728757
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    def func_0(arg_0):
        return arg_0
    session_1 = build_requests_session()
    def func_1(arg_0):
        return arg_0
    session_2 = build_requests_session()
    def func_2(arg_0):
        return arg_0
    session_3 = build_requests_session()
    def func_3(arg_0):
        return arg_0
    session_4 = build_requests_session()
    def func_4(arg_0):
        return arg_0
    session_5 = build_requests_session()
    def func_5(arg_0):
        return arg_0
    session_6 = build_requests_session()

# Generated at 2022-06-26 01:21:39.119946
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create a logger instance
    logger = logging.getLogger("TestLogger")
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter("%(name)s - %(processName)s - %(asctime)s - %(levelname)s - %(message)s")
    )
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Create a LoggedFunction instance
    logged_function = LoggedFunction(logger)

    # Create a target function
    def test_func(p1, p2):
        return "RetValue"

    test_func_name = test_func.__name__
    
    # Invoke method __call__ of LoggedFunction
    test_func = logged_function(test_func)

   

# Generated at 2022-06-26 01:22:05.932646
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = logging.getLogger(__name__)
    loggedfunction_0 = LoggedFunction(logger_0)
    def func_0(the_0, the_1):
        return (the_0 + the_1)

    logged_func_0 = loggedfunction_0(func_0)
    result_0 = logged_func_0(1, 2)
    assert result_0 == 3



# Generated at 2022-06-26 01:22:15.038615
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test 1: get a return value
    @LoggedFunction(logger=print)
    def func_1(name):
        return f"Hello, {name}!"
    assert func_1("world") == "Hello, world!"

    # Test 2: no return value
    @LoggedFunction(logger=print)
    def func_2(name):
        print(f"Hello, {name}!")
    assert func_2("world") is None

    # Test 3: has params and return value
    @LoggedFunction(logger=print)
    def func_3(name, age, *, gender):
        return f"Hello, {name}! You're {age} years old. Your gender is {gender}."

# Generated at 2022-06-26 01:22:19.590120
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logzero import logger
    from pprint import pprint

    def f_x(x: int, y: int = 0, *args, **kwargs):
        return x + y

    @LoggedFunction(logger)
    def f_f_x(x: int, y: int = 0, *args, **kwargs):
        return f_x(x, y, *args, **kwargs)

    # f_f_x(1, 2)
    # f_f_x(1, 2, 3, 4, label='f_f_x', logger=logger)
    # pprint(globals())


# Generated at 2022-06-26 01:22:20.475113
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_case_0()

# Generated at 2022-06-26 01:22:24.185522
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logging.getLogger('unit-test'))
    def test_method(x: int, y: int) -> int:
        return x + y

    assert test_method(1, 1) == 2
    assert test_method(1, 2) == 3



# Generated at 2022-06-26 01:22:38.038233
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test_method_0(x):
        return x * 10

    @LoggedFunction(logger)
    def test_method_1(x, y):
        return x + y

    test_method_0(100)
    test_method_1(100, 200)
    # Log debug message
    # --------------
    # test_method_0(100)
    # test_method_0 -> 1000
    # --------------
    # test_method_1(100, 200)
    # test_method_1 -> 300


if __name__ == "__main__":
    test_Log

# Generated at 2022-06-26 01:22:48.193956
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from requests import Session
    session_0 = build_requests_session()
    test_target = LoggedFunction(session_0)
    logged_func = test_target.__call__()
    logged_func_0 = logged_func.__name__
    assert logged_func_0 == build_requests_session
    logged_func = test_target.__call__()
    logged_func_1 = logged_func.__name__
    assert logged_func_1 == build_requests_session
    logged_func = test_target.__call__()
    logged_func_2 = logged_func.__name__
    assert logged_func_2 == build_requests_session
    logged_func = test_target.__call__()
    logged_func_3 = logged_func.__name__
    assert logged_func_

# Generated at 2022-06-26 01:22:53.909649
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    logger_0 = unittest.mock.Mock()
    logged_function_0 = LoggedFunction(logger_0)
    def test_function(arg_0, arg_1):
        return arg_0 == arg_1
    logged_test_function_0 = logged_function_0.__call__(test_function)
    assert logged_test_function_0(1, 1)
    assert not logged_test_function_0(1, 3)

# Generated at 2022-06-26 01:23:03.187769
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_case_1():
        session_0 = build_requests_session()

    def test_case_2():
        session_0 = build_requests_session(raise_for_status=True)

    def test_case_3():
        session_0 = build_requests_session(retry=2)

    def test_case_4():
        retry_0 = Retry()
        session_0 = build_requests_session(retry=retry_0)
    # test branch
    def test_case_5():
        retry_0 = Retry()
        session_0 = build_requests_session(retry=retry_0)

    def test_case_6():
        retry_0 = Retry(3)

# Generated at 2022-06-26 01:23:12.254720
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestSession:
        def request(self, method, url, **kwargs):
            return
        def close(self):
            return

    def test_func_0(x, y):
        return x + y

    def test_func_1(x, y, z):
        return x + y + z

    def test_func_2():
        return None

    ses = TestSession()
    func_0 = LoggedFunction(ses)
    func_1 = LoggedFunction(ses)

    func_0(test_func_0)(1, 2)
    func_0(test_func_0)('a', 'b')
    func_0(test_func_1)(1, 2, 3)
    func_0(test_func_1)('a', 'b', 'c')

# Generated at 2022-06-26 01:23:55.972370
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_0 = Mock()
    logger_0.debug = Mock()
    func_0 = Mock()
    func_0.__name__ = 'abc'
    logged_func_0 = LoggedFunction(logger_0).__call__(func_0)
    logged_func_0(1, 2, 3)
    logger_0.debug.assert_called_once_with(
        'abc(1, 2, 3)')


# Generated at 2022-06-26 01:24:03.353051
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    assert isinstance(session_0, Session)
    session_1 = build_requests_session(raise_for_status=False)
    assert isinstance(session_1, Session)
    session_2 = build_requests_session(retry=False)
    assert isinstance(session_2, Session)
    session_3 = build_requests_session(retry=Retry())
    assert isinstance(session_3, Session)
    session_4 = build_requests_session(retry=3)
    assert isinstance(session_4, Session)
    test_case_0()
    print('Test function build_requests_session ... OK!')


# Generated at 2022-06-26 01:24:10.729919
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    hello_text = "World"
    test_string_0 = "val1"
    test_string_1 = 'World'

    def test_func(*args):
        assert len(args) == 2, "Illegal argument count"
        assert args[0] == test_string_0, "Illegal argument value"
        assert args[1] == test_string_1, "Illegal argument value"
        return hello_text

    class test_logger:
        def debug(self, val):
            assert val == (f"{test_func.__name__}({format_arg(test_string_0)}, "
                           f"{format_arg(test_string_1)})"), "Illegal debug value"

    test_logger = test_logger()

# Generated at 2022-06-26 01:24:18.008307
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import requests

    logger_0 = logging.getLogger()
    logged_function_0 = LoggedFunction(logger_0)
    @logged_function_0
    def func_0(arg_0 = 1, arg_1 = 2, arg_2 = 3, arg_3 = 4, arg_4 = 5):
        return arg_0 + arg_1 + arg_2 + arg_3 + arg_4
    
    assert func_0(1, 2, 3, 4, 5) == 15
    assert func_0(1, 2, 3, 4) == 10
    assert func_0(1, 2, 3) == 6
    assert func_0(1, 2) == 3
    assert func_0(1) == 1
    assert func_0() == 0


# Generated at 2022-06-26 01:24:27.236591
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session()
    session_1 = build_requests_session(True)
    session_2 = build_requests_session(False)
    session_3 = build_requests_session(retry=5)
    session_4 = build_requests_session(retry=Retry(total=2))
    try:
        session_5 = build_requests_session(retry=3)
        raise ValueError("session_6 should raise ValueError")
    except ValueError:
        pass
    try:
        session_6 = build_requests_session(retry=True)
        raise ValueError("session_6 should raise ValueError")
    except ValueError:
        pass

# Generated at 2022-06-26 01:24:30.965868
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test a normal function
    test_func = lambda x, y: x * y
    
    logged_func = LoggedFunction
    logged_func.__call__(test_func)

    assert logged_func(2, 3) == 6
    assert logged_func.__name__ == "test_func"

test_LoggedFunction___call__()

# Generated at 2022-06-26 01:24:33.669900
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func_0():
        return 1
    assert LoggedFunction(logging.getLogger('test')).__call__(func_0)() == 1



# Generated at 2022-06-26 01:24:40.330141
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    class log:

        def __init__(self):
            self.log_list = []

        def debug(self, log_message):
            self.log_list.append(log_message)

    lf = LoggedFunction(log())

    def foo(x: str):
        return x

    foo = lf(foo)
    foo("abcd")
    
    assert lf.logger.log_list[0] == "foo('abcd')"
    assert lf.logger.log_list[1] == "foo -> abcd"



# Generated at 2022-06-26 01:24:42.753778
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    session_0 = build_requests_session()
    session_0.close()

# Generated at 2022-06-26 01:24:46.399410
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=logger)
    def fun(x, y=0):
        logger.debug("In function fun, x=%s, y=%s" % (x, y))

    fun(1, 2)
    fun()
