

# Generated at 2022-06-24 01:42:42.429673
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = "mock_logger"
    f = LoggedFunction(logger)
    assert f.logger == logger



# Generated at 2022-06-24 01:42:45.596158
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("a") == "'a'"
    assert format_arg(" a  ") == "' a  '"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:42:54.278018
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session
    assert session.max_redirects == 30
    assert session.adapters["http://"].max_retries
    assert session.adapters["https://"].max_retries
    assert not session.hooks

    session = build_requests_session(False, False)
    assert session
    assert not session.adapters["http://"].max_retries
    assert not session.adapters["https://"].max_retries
    assert not session.hooks

    session = build_requests_session(True, False)
    assert session
    assert not session.adapters["http://"].max_retries
    assert not session.adapters["https://"].max_retries
    assert session.hooks


# Generated at 2022-06-24 01:42:58.799802
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def add(num1, num2):
        return num1 + num2

    add(3, 4)

# Generated at 2022-06-24 01:43:05.358025
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.Logger("test_log")
    logged_function = LoggedFunction(logger)

    def test_function(a, b, c=1, d=2):
        return a + b + c + d

    assert logged_function.__call__(test_function)(1, 2) == 6
    assert logged_function.__call__(test_function)(1, 2, d=4) == 8
    assert logged_function.__call__(test_function)(1, 2, c=3, d=4) == 10

# Generated at 2022-06-24 01:43:14.070838
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger, and attach a StringIO to it
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    string_io = io.StringIO()
    log.addHandler(logging.StreamHandler(string_io))

    # Define a decorated function
    @LoggedFunction(log)
    def my_function(x, y, z=1, *, a=1, b=2, c=3):
        return x + y + z + a + b + c

    # Call the function
    result = my_function(1, 2, 3, b=4)

    # Check that the final value is logged
    assert result == 15

# Generated at 2022-06-24 01:43:19.317016
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import MagicMock
    from logging import Logger

    logger = MagicMock(spec=Logger)
    logged_function = LoggedFunction(logger)

    def func():
        pass

    logged_func = logged_function(func)
    assert logged_func.__name__ == "func"
    assert logged_func.__doc__ == "func"

    logged_func()
    # No assert on output, just checking that it doesn't raise any errors

# Generated at 2022-06-24 01:43:27.773216
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(raise_for_status=False, retry=True)
    assert isinstance(s.adapters["https://"].max_retries, Retry)
    s = build_requests_session(raise_for_status=False, retry=False)
    assert s.adapters["https://"].max_retries is None
    s = build_requests_session(raise_for_status=False, retry=3)
    assert isinstance(s.adapters["https://"].max_retries, Retry)
    assert s.adapters["https://"].max_retries.total == 3
    s = build_requests_session(raise_for_status=False, retry=Retry(total=5))
    assert s.adapters["https://"].max_ret

# Generated at 2022-06-24 01:43:30.012892
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        logger = Logger.get_logger(__name__)
        LoggedFunction(logger)
    except:
        assert False, "LoggedFunction have not been created"
    assert True


# Generated at 2022-06-24 01:43:34.755358
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    lf1 = LoggedFunction("logger")
    lf2 = LoggedFunction("logger")
    assert lf1 == lf2, "Success"
    assert lf1 != "logger", "Success"
    assert lf1 == lf1, "Success"


# Generated at 2022-06-24 01:43:42.389713
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=5)

    assert isinstance(session, Session), "it should return a requests.Session instance"
    assert isinstance(session.max_retries, Retry), "it should create the Retry instance"
    assert session.max_retries.total == 5, "it should use the parameter as retry count"

# Generated at 2022-06-24 01:43:43.156088
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

# Generated at 2022-06-24 01:43:53.588087
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    #Arrange
    class MockLogger:
        # Class for mocking a logger
        def __init__(self):
            self.log = []
        def debug(self, message):
            self.log.append(message)
    def func(arg1, arg2, kwarg1=None):
        return [arg1, arg2, kwarg1]
    func.__name__ = "func"
    logger = MockLogger()
    decorator = LoggedFunction(logger)

    #Act
    decorator(func)(2, 3, kwarg1=True)

    #Assert
    assert logger.log == ["func(2, 3, kwarg1=True)", "func -> [2, 3, True]"]

# Test for method __call__ of class LoggedFunction
test_LoggedFunction___call__()

# Generated at 2022-06-24 01:44:05.392335
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import os

    # Test custom logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # Create file handler which logs even debug messages
    log_file = os.path.join(os.path.dirname(__file__), "log", "logged_function.log")
    fh = logging.FileHandler(log_file)
    fh.setLevel(logging.DEBUG)
    # Create console handler with a higher log level
    ch = logging.StreamHandler()
    ch.setLevel(logging.ERROR)
    # Create formatter and add it to the handlers
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
   

# Generated at 2022-06-24 01:44:07.158470
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc") == "'abc'"
    assert format_arg(1) == "1"


# Generated at 2022-06-24 01:44:18.534516
# Unit test for function build_requests_session
def test_build_requests_session():
    assert (
        build_requests_session(raise_for_status=False, retry=False)
        == build_requests_session(raise_for_status=False, retry=False)
    )
    assert (
        build_requests_session(raise_for_status=False, retry=False)
        != build_requests_session(raise_for_status=True, retry=5)
    )
    assert (
        build_requests_session(raise_for_status=True, retry=False)
        == build_requests_session(raise_for_status=True, retry=False)
    )

# Generated at 2022-06-24 01:44:25.898923
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger
    from unittest.mock import Mock

    logger = getLogger(__name__)
    logger.setLevel("DEBUG")

    with LoggedFunction(logger):

        def test_function(a, b=1, c=2):
            pass

        test_function("arg1", b=100, c=200)

# Generated at 2022-06-24 01:44:28.622735
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    a = LoggedFunction()
    assert a.logger == a.logger

# Generated at 2022-06-24 01:44:31.921282
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger

    logger = getLogger("logged_function_test")

    @LoggedFunction(logger)
    def foo(*args, **kwargs):
        return 1

    foo()



# Generated at 2022-06-24 01:44:37.020947
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1234) == '1234'
    assert format_arg('  1234') == "'  1234'"
    assert format_arg("'1234'") == "'\'1234\''"
    assert format_arg("'1234") == "'\'1234'"



# Generated at 2022-06-24 01:44:39.731904
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("test") == "'test'"
    assert format_arg([1, 2]) == "[1, 2]"



# Generated at 2022-06-24 01:44:50.928747
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MagicMock()
    logged_function = LoggedFunction(logger)
    @logged_function
    def test_func(arg1, arg2):
        return arg1 + arg2
    result = test_func(1, 2)
    assert result == 3
    logger.debug.assert_called_once_with("test_func(1, 2)")
    logger.debug.reset_mock()

    # Test with keyword args
    result = test_func(arg1=1, arg2=2)
    assert result == 3
    logger.debug.assert_called_once_with("test_func(1, 2)")
    logger.debug.reset_mock()

    # Test with argument as string
    result = test_func("arg1", "arg2")
    assert result == "arg1arg2"


# Generated at 2022-06-24 01:44:56.623294
# Unit test for function format_arg
def test_format_arg():
    # Test string argument
    assert format_arg("0.25     ") == "'0.25'"

    # Test int
    assert format_arg(1000000) == "1000000"

    # Test float
    assert format_arg(0.25) == "0.25"

    # Test float with exp (1.25e-02)
    assert format_arg(1.25e-2) == "0.0125"

# Generated at 2022-06-24 01:44:58.593330
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('a') == "'a'"
    assert format_arg(1) == "1"



# Generated at 2022-06-24 01:45:06.757216
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Setup test
    logger = logging.getLogger()
    expected_log_output = [
        "logged_function(hello, world, a=1, c=3, b=2)",
        "logged_function -> returning",
    ]

    # Run test
    @LoggedFunction(logger)
    def logged_function(hello, world, a, b, c):
        return "returning"

    assert logged_function("hello", "world", a=1, b=2, c=3) == "returning"
    assert logger.outputs == expected_log_output



# Generated at 2022-06-24 01:45:16.571935
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.logged_msg = ""

        def debug(self, msg):
            self.logged_msg = msg

    logger = TestLogger()
    called_by_logged_function = False

    @LoggedFunction(logger)
    def func(*args, **kwargs):
        nonlocal called_by_logged_function
        called_by_logged_function = True
        return [1, 2, 3]

    func("a", "b", "c", a=1, b=2, c=3)
    assert logger.logged_msg == "func('a', 'b', 'c', a=1, b=2, c=3)"
    assert called_by_logged_function
    called_by_logged_function = False

# Generated at 2022-06-24 01:45:23.244626
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg(" abc ") == "' abc '"
    try:
        import datetime
        dt = datetime.datetime.now()
        assert format_arg(dt) == str(dt)
    except ImportError:
        pass


# Generated at 2022-06-24 01:45:28.987264
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError

    session = build_requests_session()
    try:
        session.get("http://httpbin.org/status/404")
        assert False
    except HTTPError as e:
        assert e.response.status_code == 404

    session = build_requests_session(raise_for_status=False)
    rsp = session.get("http://httpbin.org/status/404")
    assert rsp.status_code == 404



# Generated at 2022-06-24 01:45:39.636203
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger("Test_Logger")
    logger.setLevel(logging.DEBUG)

    func_logger = logging.getLogger("Function_Logger")
    func_logger.setLevel(logging.DEBUG)

    logging.basicConfig()
    logger.debug("Start of test")

    @LoggedFunction(func_logger)
    def my_func(a, b=2, c=3):
        return a + b + c

    my_func(1)
    my_func(1, 2)
    my_func(1, 2, 3)
    my_func(1, b=2, c=3)
    my_func(1, c=3, b=2)
    my_func(c=3, b=2, a=1)




# Generated at 2022-06-24 01:45:45.771503
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(10) == "10"
    assert format_arg('lolol') == "'lolol'"
    assert format_arg(' ') == "' '"
    assert format_arg(None) == 'None'
    assert format_arg(True) == 'True'
    assert format_arg(False) == 'False'

# Generated at 2022-06-24 01:45:55.423204
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock
    from time import sleep

    def test_function(*args, **kwargs):
        sleep(1)
        return args, kwargs

    logger = mock.MagicMock()
    logged_func = LoggedFunction(logger)(test_function)
    assert logged_func.__name__ == test_function.__name__
    result = logged_func(1, 2, a=3, b=4)
    logger.debug.assert_any_call(
        "test_function(1, 2, a=3, b=4)"
    )  # Test logging function name and arguments
    logger.debug.assert_any_call(
        "test_function -> ((1, 2), {'a': 3, 'b': 4})"
    )  # Test logging function result

# Generated at 2022-06-24 01:46:02.001554
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test when valid logger is given
    with patch("logging.Logger"):
        logger = Logger
        logger.debug = MagicMock()

        @LoggedFunction(logger)
        def foo(arg):
            return "bar"

        foo(1)
        logger.debug.assert_called()

    # Test when invalid logger is given
    with pytest.raises(ValueError):
        logger = None
        LoggedFunction(logger)

    # Test when no logger is given
    with pytest.raises(ValueError):
        LoggedFunction()


# Unit tests for default_retry_after_setup

# Generated at 2022-06-24 01:46:06.497717
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # test 1
    # check if logged function will have the same name as the input function
    func_name = "func_name"
    logger = "logger"
    logged_func = LoggedFunction(logger)
    function_logged = logged_func(func_name)
    assert function_logged.__name__ == func_name

    # test 2
    # check if logged function will return the right value
    result = "result"
    assert function_logged(None) == result


# Generated at 2022-06-24 01:46:13.988572
# Unit test for function build_requests_session
def test_build_requests_session():
    # Create a session with hooks to raise for status
    session = build_requests_session()
    assert session.hooks is not None
    assert len(session.hooks["response"]) == 1
    assert isinstance(session.hooks["response"][0], functools.partial)
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters


# Generated at 2022-06-24 01:46:23.744441
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logged_function = LoggedFunction(logger)

    def test_function(arg1, arg2):
        return arg1 + arg2

    test_function = logged_function(test_function)

    def test_function_with_kwargs(arg1, arg2):
        return arg1 + arg2

    kwargs_function = logged_function(test_function_with_kwargs)

    arg1 = 2
    arg2 = 4
    log_handler = logging.StreamHandler()
    log_handler.setLevel(logging.DEBUG)
    log_format = logging.Formatter("%(levelname)s - %(message)s")
    log_handler.setFormatter(log_format)
    logger.addHandler(log_handler)
   

# Generated at 2022-06-24 01:46:31.521474
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["http://"].max_retries.total == Retry().total
    assert session.adapters["https://"].max_retries.total == Retry().total
    
    session = build_requests_session(raise_for_status=False)
    assert not session.hooks
    
    session = build_requests_session(retry=False)
    assert not session.adapters
    
    session = build_requests_session(retry=2)
    assert session.adapters["http://"].max_retries.total == 2
    assert session.adapters["https://"].max_retries.total == 2
    
    retry = Retry(total=3)

# Generated at 2022-06-24 01:46:38.977147
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class DummyLogger:
        def debug(self, msg):
            print(msg)

    dummy_logger = DummyLogger()
    logged_func = LoggedFunction(dummy_logger)

    def func(a, b, c=3):
        return a + b + c

    wrapped = logged_func(func)

    assert func.__name__ == wrapped.__name__
    assert func(1, 2) == wrapped(1, 2)
    assert func(1, 2, 3) == wrapped(1, 2, 3)
    assert func(1, 2, c=3) == wrapped(1, 2, c=3)

if __name__ == '__main__':
    test_LoggedFunction()

# Generated at 2022-06-24 01:46:48.786216
# Unit test for function build_requests_session
def test_build_requests_session():
    # no raise by default
    session = build_requests_session()
    assert session.hooks == {}

    # raise enabled
    session = build_requests_session(True)
    assert len(session.hooks["response"]) == 1

    # retry enabled
    session = build_requests_session(False, True)
    assert session.adapters[Adapter]

    # retry enabled with given count
    session = build_requests_session(False, 2)
    assert session.adapters[Adapter].max_retries.total == 2

    # given Retry instance
    retry = Retry()
    retry.backoff_factor = 2
    retry.total = 3
    session = build_requests_session(False, retry)
    assert session.adapters[Adapter].max_retries.backoff

# Generated at 2022-06-24 01:46:58.595313
# Unit test for function build_requests_session
def test_build_requests_session():
    import logging
    import requests
    import requests_mock

    logging.basicConfig(level=logging.DEBUG)

    with requests_mock.Mocker() as mock:
        # setup
        mock.get("http://localhost", status_code=503)
        mock.head("http://localhost/head", status_code=503)

        # test
        session = build_requests_session(
            retry=Retry(total=2, status_forcelist=[404, 500, 502, 503, 504])
        )
        logger = logging.getLogger(__name__)
        logger.debug("test build_requests_session")

# Generated at 2022-06-24 01:47:03.425858
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test")
    test_func = LoggedFunction(logger)
    assert test_func is not None


# Generated at 2022-06-24 01:47:14.902320
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from familysearch.client import FamilySearch
    from familysearch.resources.collections import Collections
    from familysearch.resources.searchandmatch import SearchAndMatch
    from familysearch.resources.query import Query
    from familysearch.resources.gensearch import GenSearch
    from familysearch.resources.other import Other
    from familysearch.resources.pedigree import Pedigree
    from familysearch.resources.places import Places
    from familysearch.resources.tree import Tree
    from familysearch.resources.users import Users
    from familysearch.resources.discussions import Discussions
    from familysearch.resources.memories import Memories
    from familysearch.resources.merge_analysis import MergeAnalysis
    from familysearch.resources.merge_results import MergeResults
    from familysearch.resources.change_history import ChangeHistory
    from familysearch.resources.ordinances import Ord

# Generated at 2022-06-24 01:47:20.374288
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from .logging_setup import setup_logging

    stream = StringIO()
    setup_logging(stream=stream)
    # setup_logging(stream=stream, level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    test_func(1, 2, c=6)

    assert stream.getvalue().strip() == "test_logging_decorators.test_LoggedFunction___call__ - DEBUG - test_func(1, 2, c=6) -> 9"

# Generated at 2022-06-24 01:47:23.717033
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import pytest

    def test():
        if not LoggedFunction(None):
            raise Exception("LoggedFunction is None")
    test()
    with pytest.raises(Exception):
        test()

# Generated at 2022-06-24 01:47:29.713136
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Create dummy Logger
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    logger.addHandler(stream_handler)

    # Create dummy function
    def test_function(a, b, c=0):
        pass

    # Construct LoggedFunction
    logged_function = LoggedFunction(logger)

    # Call decorator
    wrapped_function = logged_function(test_function)

    # Call wrapped function
    wrapped_function(1, 2, 3)


# Decorator for logging
logged_function = LoggedFunction(logging.getLogger(__name__))

# Generated at 2022-06-24 01:47:37.202962
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session().adapters['http://'].max_retries.total == 1
    assert build_requests_session(retry=True).adapters['http://'].max_retries.total == 3
    assert build_requests_session(retry=False).adapters['http://'].max_retries.total == 1
    assert build_requests_session(retry=5).adapters['http://'].max_retries.total == 5
    retry = Retry(total=7, backoff_factor=1.5)
    assert build_requests_session(retry=retry).adapters['http://'].max_retries.total == 7

# Generated at 2022-06-24 01:47:41.715942
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    t1=LoggedFunction(logger)
    t2=LoggedFunction(logger)
    t3=LoggedFunction(logger)
    t4=LoggedFunction(logger)
    t5=LoggedFunction(logger)


# Generated at 2022-06-24 01:47:52.109667
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction.
    """

    class MockLogger:
        def __init__(self):
            self.args = None

        def debug(self, value):
            self.args = value
            
    logger = MockLogger()
    logged_function = LoggedFunction(logger)
    logged_function(lambda x, y: x + y)(1, 2)
    assert logger.args == "func(1, 2)"
    logged_function(lambda x, y: None)(1, 2)
    assert logger.args == "func(1, 2)"
    logged_function(lambda x, y: x + y)(1, 2, 3)
    assert logger.args == "func(1, 2, 3)"

# Generated at 2022-06-24 01:47:56.695882
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s, Session)

    s = build_requests_session(retry=False)
    assert not hasattr(s, "adapters")
    assert len(s.hooks["response"]) == 0

    s = build_requests_session(retry=1)
    assert isinstance(s, Session)

    s = build_requests_session(raise_for_status=False)
    assert isinstance(s, Session)

# Generated at 2022-06-24 01:48:05.022175
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc") == "'abc'"
    assert format_arg("a b c") == "'a b c'"
    assert format_arg(" a b c ") == "' a b c '"
    assert format_arg("a'b'c") == "'a'b'c'"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(1 + 0j) == "(1+0j)"



import unittest



# Generated at 2022-06-24 01:48:13.370956
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Create temporary handler and logger
    handler = logging.StreamHandler()
    logger = logging.getLogger()
    logger.addHandler(handler)

    # Create test function which returns a string
    def my_function(a, b, c="test"):
        return f"{a} {c} {b}"

    # Create decorator instance
    logged_function = LoggedFunction(logger)
    logged_function = logged_function(my_function)
    result = logged_function(-1, 5)
    assert result == "-1 test 5"
    assert handler.stream.getvalue() == "my_function(-1, 5, c='test')\nmy_function -> -1 test 5\n"

# Generated at 2022-06-24 01:48:21.209932
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        log = []

        def __init__(self, level):
            pass

        def debug(self, msg: str):
            self.log.append(msg)

    logger = TestLogger(10)

    @LoggedFunction(logger)
    def test(a, b=2, c="3"):
        return f"{a}-{b}-{c}"

    test(1)
    test(a=1)
    test(1, b=2)
    test(1, b=2, c="3")
    test(1, c="3")
    test(1, 2, "3")
    test(1, 2, c="3")


# Generated at 2022-06-24 01:48:28.251140
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pprint import pprint
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    pprint(locals())

    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    pprint(locals())

    add(1, 2)



# Generated at 2022-06-24 01:48:36.303177
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    
    from datetime import datetime
    
    # create logger
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    
    # set handler
    import sys
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    
    # test function
    @LoggedFunction(logger)
    def add(a: int, b: int) -> int:
        return a + b
    
    # test
    add(1, 2)
    add(a=1, b=2)
    add(1, b=2)
    add(1, b=2, c=3)


if __name__ == "__main__":
    import sys
    import logging
    logging.basicConfig()
    logger

# Generated at 2022-06-24 01:48:45.278485
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import numpy as np
    import logging
    import random

    logging.basicConfig(filename="/tmp/logged_function_test", level=logging.DEBUG)
    logger = logging.getLogger("test")

    def func1(a, b, c=3, d=None):
        print(f"func1 a={a}, b={b}, c={c}, d={d}")
        return a + b + c

    def func2():
        return np.random.randint(0, 100)

    def func3(a: list):
        a = a[:]
        random.shuffle(a)
        return a

    @LoggedFunction(logger)
    def test1(a, b, c, d):
        return func1(a, b, c, d)


# Generated at 2022-06-24 01:48:47.889604
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    print("Testing constructor of class LoggedFunction")



# Generated at 2022-06-24 01:48:57.897521
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    
    def show_loggings(logged_function):
        #logging.basicConfig(stream=sys.stdout, format="%(levelname)s:%(message)s", level=logging.DEBUG)
        
        @logged_function(logging.basicConfig(stream=sys.stdout, format="%(levelname)s:%(message)s", level=logging.DEBUG))
        def show(name, age):
            x = {"name":name}
            y = {'age':age}
            return x,y
        
        show("Robert", 25)
        
    test_LoggedFunction.show_loggings = show_loggings


# Generated at 2022-06-24 01:49:00.567764
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"

# Generated at 2022-06-24 01:49:06.726793
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert type(session) == Session
    session = build_requests_session(raise_for_status=False)
    assert type(session) == Session
    session = build_requests_session(raise_for_status=False, retry=False)
    assert type(session) == Session
    session = build_requests_session(raise_for_status=False, retry=3)
    assert type(session) == Session
    session = build_requests_session(raise_for_status=False, retry=Retry())
    assert type(session) == Session


# Generated at 2022-06-24 01:49:08.022010
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    LoggedFunction(logger)


# Generated at 2022-06-24 01:49:14.692240
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    loggerMock = MagicMock()
    loggerMock.debug = MagicMock()
    funcMock = MagicMock(return_value=None)
    funcMock.__name__ = 'test_function'
    funcMock.__wrapped__ = funcMock
    loggedFunction = LoggedFunction(loggerMock)
    loggedFunction(funcMock)('arg1', 'arg2', 'arg3', keyword1='kwarg1')
    loggerMock.debug.assert_called_once_with("test_function('arg1', 'arg2', 'arg3', keyword1='kwarg1')")
    funcMock.assert_called_once_with('arg1', 'arg2', 'arg3', keyword1='kwarg1')


# Generated at 2022-06-24 01:49:24.865777
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(-5) == '-5'
    assert format_arg(5) == '5'
    assert format_arg(5.0) == '5.0'
    assert format_arg("") == "''"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc def") == "'abc def'"
    assert format_arg(" abc def") == "' abc def'"
    assert format_arg("abc def ") == "'abc def '"
    assert format_arg(" abc def ") == "' abc def '"
    assert format_arg("|abc#def|") == "'|abc#def|'"

# Test for logged function

# Generated at 2022-06-24 01:49:32.333594
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks is None
    assert len(session.adapters) == 0

    session = build_requests_session(raise_for_status=False)
    assert session.hooks is None
    assert len(session.adapters) == 0

    session = build_requests_session(retry=False)
    assert session.hooks is None
    assert len(session.adapters) == 0

    session = build_requests_session(retry=Retry())
    assert session.hooks is None
    assert len(session.adapters) == 1
    for prefix, adapter in session.adapters.items():
        assert isinstance(adapter, HTTPAdapter)
        assert isinstance(adapter.max_retries, Retry)

    session = build_requests_session

# Generated at 2022-06-24 01:49:39.470129
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import time

    def test_func(a, b, c="c"):
        time.sleep(0.5)
        return a+b+c

    logger = logging.getLogger(__name__)

    # create an instance of LoggedFunction class and use it as a decorator
    logged_test_func = LoggedFunction(logger=logger)(test_func)

    # execute function logged_test_func, which is decorated by LoggedFunction instance
    result = logged_test_func(1, 2, c="c")

# Generated at 2022-06-24 01:49:44.402509
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    
    logger = logging.getLogger("test_logger")
    logger.setLevel("DEBUG")

    @LoggedFunction(logger)
    def test_function(a: int, b: str = "test", c: str = 'test"test', *args):
        print("test")
        return 1

    test_function(1, c='test"test2')

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:49:46.821009
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('1')=="'1'"
    assert format_arg(1)=='1'
    assert format_arg(None) == 'None'
    assert format_arg(float(1)) == '1.0'


# Generated at 2022-06-24 01:49:51.021603
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("1") == "'1'"
    assert format_arg('"1"') == "'\"1\"'"

# Generated at 2022-06-24 01:49:54.233771
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(True, True)
    assert isinstance(s.adapters["http://"], HTTPAdapter)



# Generated at 2022-06-24 01:50:06.231148
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters.get('http://').max_retries.total == 3
    assert session.adapters.get('https://').max_retries.total == 3
    session = build_requests_session(retry=False)
    assert session.adapters.get('http://').max_retries.total == 0
    assert session.adapters.get('https://').max_retries.total == 0
    with pytest.raises(ValueError):
        build_requests_session(retry=0)
    with pytest.raises(ValueError):
        build_requests_session(retry=-1)
    with pytest.raises(ValueError):
        build_requests_session(retry='a')

# Generated at 2022-06-24 01:50:16.255057
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError
    
    # This raises a HTTP 400 Error.
    session = build_requests_session()
    try:
        session.get("http://httpbin.org/status/400")
    except HTTPError:
        pass
    # This raises a HTTP 400 Error also.
    try:
        session.get("http://httpbin.org/status/400")
    except HTTPError:
        pass
    # This raises a HTTP 400 Error, but will be retried, which means no HTTPError raised here.
    session = build_requests_session(retry=True)
    session.get("http://httpbin.org/status/400")
    # This raises a HTTP 400 Error, but will be retried, which means no HTTPError raised here.

# Generated at 2022-06-24 01:50:20.782196
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc") == "'abc'"
    assert format_arg("a bc") == "'a bc'"
    assert format_arg("ab c") == "'ab c'"
    assert format_arg("a   b   c") == "'a   b   c'"
    assert format_arg("") == "''"
    assert format_arg("    ") == "''"
    assert format_arg(123) == "123"

# Generated at 2022-06-24 01:50:27.347274
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.__dict__.get("hooks") is None

    session = build_requests_session(raise_for_status=False)
    assert session.__dict__.get("hooks") is None

    session = build_requests_session(raise_for_status=True)
    assert session.__dict__.get("hooks")

    session = build_requests_session(retry=True)
    assert session.adapters.get("http://")
    assert session.adapters.get("https://")

    session = build_requests_session(retry=10)
    assert session.adapters.get("http://")
    assert session.adapters.get("https://")

    session = build_requests_session(retry=Retry())
    assert session

# Generated at 2022-06-24 01:50:32.139333
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg(" 1 ") == "' 1 '"
    assert format_arg(None) == "None"
    assert format_arg(float("inf")) == 'inf'

# Generated at 2022-06-24 01:50:41.993318
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Mock logger
    class FakeLogger:
        def debug(self, message):
            self.message = message
        def __repr__(self):
            return 'fake logger'

    fake_logger = FakeLogger()
    log_fn = LoggedFunction(fake_logger)
    # Decorate function
    @log_fn
    def test_func(*args, **kwargs):
        assert fake_logger.message == "test_func('Hello', 'world', a='A', b='B')"
        return 'test result'
    # Test
    assert test_func('Hello', 'world', a='A', b='B') == 'test result'
    assert fake_logger.message == "test_func -> test result"



# Generated at 2022-06-24 01:50:50.003106
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert len(session.adapters) == 2

    session = build_requests_session(retry=Retry(1))
    assert len(session.adapters) == 2

    session = build_requests_session(retry=1)
    assert len(session.adapters) == 2

    session = build_requests_session(retry=False)
    assert len(session.adapters) == 0

if __name__ == '__main__':
    test_build_requests_session()

# Generated at 2022-06-24 01:50:57.573370
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest
    from unittest.mock import patch

    logger = logging.getLogger(__name__)
    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
    logger.debug("{}({}) -> {}".format(LoggedFunction.__name__, "logger", "None"))

    class TestLoggedFunction(unittest.TestCase):
        def test_call(self):
            self.assertTrue(True)

    LoggedFunction(logger)(TestLoggedFunction.test_call)

    with patch("sys.stdout") as fake_stdout:
        TestLoggedFunction().test_call()

# Generated at 2022-06-24 01:51:05.174566
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(10) == "10"
    assert format_arg(3.1415) == "3.1415"
    assert format_arg("string") == "'string'"
    assert format_arg(" ") == "' '"
    assert format_arg(" string ") == "' string '"



# Generated at 2022-06-24 01:51:15.304629
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest
    import sys
    import io

    class Logger:
        def debug(self, message):
            print(message, file=self.stream)
     
    class LoggedFunctionTest(unittest.TestCase):
        def test_log(self):
            logger = Logger()
            logger.stream = io.StringIO()
            @LoggedFunction(logger)
            def test_fn(a, b, c=1, d=2):
                return a * b * c * d
            test_fn(2, 3, 4, 5)
            self.assertEqual(logger.stream.getvalue(), 'test_fn(2, 3, c=4, d=5)\ntest_fn -> 120\n')


# Generated at 2022-06-24 01:51:21.621083
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(raise_for_status=True, retry=3)
    assert s.hooks.get("response")[0] == Session().hooks.get("response")[0]
    assert isinstance(s.adapters["http://"], HTTPAdapter)
    assert isinstance(s.adapters["https://"], HTTPAdapter)
    assert s.adapters["http://"].max_retries.total == 3
    assert s.adapters["https://"].max_retries.total == 3
    s = build_requests_session(raise_for_status=True, retry=False)
    assert s.hooks.get("response")[0] == Session().hooks.get("response")[0]
    assert s.adapters.get("http://") == None
    assert s.adapters

# Generated at 2022-06-24 01:51:27.051231
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # setup test
    class TestLogger:
        def __init__(self):
            self.debug_count = 0
            self.debug_args = []

        def debug(self, *args, **kwargs):
            self.debug_count += 1
            self.debug_args = args
    
    logger = TestLogger()
    logged_function = LoggedFunction(logger)

    # set expected result
    expected_result = "test result"

# Generated at 2022-06-24 01:51:30.980998
# Unit test for function build_requests_session
def test_build_requests_session():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    session = build_requests_session()
    try:
        response = session.get("https://www.google.com")
        response.raise_for_status()
    except Exception as e:
        logger.error(e)
        raise e

# Generated at 2022-06-24 01:51:35.994515
# Unit test for function format_arg
def test_format_arg():
    assert f"{format_arg(1)}" == "1"
    assert f"{format_arg('test')}" == "'test'"
    assert f"{format_arg('  test  ')}" == "'test'"

# Generated at 2022-06-24 01:51:45.080977
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def debug(self, message):
            print(message)

    @LoggedFunction(DummyLogger())
    def test_method(a, b, c=3):
        pass

    test_method(1, 2, 3)
    test_method(1, 2)
    test_method("a", "b", "c")
    test_method("a", "b", c="c")
    test_method("a", "b", "c", d="d")
    test_method("a", "b", c="c", d="d")


test_LoggedFunction___call__()

# Generated at 2022-06-24 01:51:51.689764
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock

    logger = MagicMock()
    LoggedFunction(logger)

    @LoggedFunction(logger)
    def hello():
        return "hello"

    assert hello() == "hello"
    assert hello(1, 2, 3) == "hello"
    
    n = 0
    assert n == 0
    hello.__call__()
    assert n == 0

# Generated at 2022-06-24 01:51:56.296776
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def debug(self, *args, **kwargs):
            print(*args, **kwargs)

    logger = DummyLogger()
    @LoggedFunction(logger)
    def test_function(x, y, z=3):
        return z * (x + y)

    assert test_function(5, 7) == 36
    assert test_function(3, 4, z=5) == 35
    assert test_function(y=2, x=5) == 13

# Generated at 2022-06-24 01:52:08.332385
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import Logger, CRITICAL, getLogger
    from io import StringIO
    from contextlib import redirect_stdout, redirect_stderr

    logger = getLogger(__name__)
    logger.setLevel(CRITICAL)
    captured_output = StringIO() # Create StringIO object
    logger.addHandler(logging.StreamHandler(captured_output))

    loggingfn = LoggedFunction(logger)

    @loggingfn
    def func1(a, b, c):
        return a + b + c

    with redirect_stdout(captured_output), redirect_stderr(captured_output):
        func1(1, 2, 3)
    assert captured_output.getvalue() == "func1(1, 2, 3)\n"


# Generated at 2022-06-24 01:52:17.142856
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    # Arrange
    logger = Mock()
    f = LoggedFunction(logger)

    @f
    def test_function(x, y, z="hello", *args, **kwargs):
        return x + y

    # Act
    test_function(3, 4, 5, 8, 9, w="world")

    # Assert
    assert logger.debug.call_count == 2


# Generated at 2022-06-24 01:52:26.540293
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import request, exceptions
    session = build_requests_session()
    # no raise
    resp = request("GET", "https://httpbin.org/get")
    assert resp.raise_for_status() is None
    with pytest.raises(exceptions.HTTPError):
        request("GET", "https://httpbin.org/status/400")

    # raise
    session = build_requests_session(raise_for_status=True)
    resp = request("GET", "https://httpbin.org/get")
    assert resp.raise_for_status() is None
    with pytest.raises(exceptions.HTTPError):
        request("GET", "https://httpbin.org/status/400")

# Generated at 2022-06-24 01:52:36.712075
# Unit test for function build_requests_session
def test_build_requests_session():
    def sample_request():
        # Function to fail which is ok.
        session = build_requests_session()
        session.get("https://httpstat.us/403")

    # Test case 1: If raise_for_status is True, a hook will be installed to invoke raise_for_status
    with pytest.raises(requests.exceptions.HTTPError):
        sample_request()

    # Test case 2: If raise_for_status is False, no hook will be installed, and it can pass
    # successfully
    session = build_requests_session(raise_for_status=False)
    r = session.get("https://httpstat.us/403")
    assert r.status_code == 403

    # Test case 3: If retry is False, no adapter will be installed, and it will fail successfully

# Generated at 2022-06-24 01:52:48.088544
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True)
    try:
        session.get('http://httpbin.org/status/401')
    except Exception as e:
        assert type(e) == requests.exceptions.HTTPError
    session = build_requests_session()
    assert session.get('http://httpbin.org/status/401').status_code == 401
    session = build_requests_session(False, False)
    assert session.get('http://httpbin.org/status/401').status_code == 401
    session = build_requests_session(False, 1)
    assert session.get('http://httpbin.org/status/401').status_code == 401
    retry = Retry(status_forcelist=[400])
    session = build_requests_session(False, retry)