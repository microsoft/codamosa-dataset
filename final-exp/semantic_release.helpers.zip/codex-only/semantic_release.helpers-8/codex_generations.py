

# Generated at 2022-06-24 01:42:41.008874
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)

# Generated at 2022-06-24 01:42:49.263274
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg([1, "2a", 3.0]) == "[1, '2a', 3.0]"
    assert format_arg({"k1": "v1", "k2": "v2"}) == "{'k1': 'v1', 'k2': 'v2'}"
    assert format_arg("abc") == "'abc'"
    assert format_arg(" abc") == "' abc'"
    assert format_arg("'abc") == "'\\'abc'"
    assert format_arg(" a'bc") == "' a\\'bc'"

# Generated at 2022-06-24 01:42:56.816015
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger, DEBUG
    from contextlib import contextmanager

    @contextmanager
    def debug_logging(logger, level=DEBUG):
        """Context manager to temporarily set logger level."""
        old_level = logger.level
        logger.setLevel(level)
        try:
            yield
        finally:
            logger.setLevel(old_level)

    log = getLogger("test")

    @LoggedFunction(log)
    def some_function(*args, **kwargs):
        pass

    with debug_logging(log):
        some_function(1, x=2, y=3)



# Generated at 2022-06-24 01:43:03.996342
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

    def my_func(a, b, c=5):
        pass

    logged_func = LoggedFunction(logger)(my_func)

    logged_func(1, 2)
    logged_func(a=1, b=2)
    logged_func(1, 2, c=6)


# Generated at 2022-06-24 01:43:14.870723
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)
    assert isinstance(build_requests_session(False), Session)
    assert isinstance(build_requests_session(True), Session)
    assert isinstance(build_requests_session(int), Session)
    assert isinstance(build_requests_session(Retry), Session)
    try:
        build_requests_session(1.1)
    except ValueError as e:
        assert "retry should be a bool, int or Retry instance." in str(e)
    try:
        build_requests_session("true")
    except ValueError as e:
        assert "retry should be a bool, int or Retry instance." in str(e)

# Generated at 2022-06-24 01:43:19.292262
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests

    session = build_requests_session()
    response = session.get("https://www.google.com/")
    assert response.status_code == requests.codes.OK


# Generated at 2022-06-24 01:43:25.165290
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("a string") == "'a string'"
    assert format_arg(123) == "123"
    assert format_arg([1, "2"]) == "[1, '2']"
    assert format_arg({"a": 1, "b": "2"}) == "{'a': 1, 'b': '2'}"

# Generated at 2022-06-24 01:43:34.282614
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger('dummy')
    logger.setLevel(logging.NOTSET)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    )
    logger.addHandler(handler)
    l = LoggedFunction(logger = logger)
    l(add)(1, 2)
    l(add)(3, 4, 5)
    l(add)(a = 1, b = 2)
    l(add)(a = 3, b = 4, c = 5)


# Generated at 2022-06-24 01:43:42.925993
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():

    import logging
    logging.basicConfig(level=logging.DEBUG)

    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def test_1():
        pass

    @LoggedFunction(logger)
    def test_2(un):
        return un

    @LoggedFunction(logger)
    def test_3(a1, a2):
        return a1, a2

    @LoggedFunction(logger)
    def test_4(a1, a2, *args):
        return a1, a2, args

    @LoggedFunction(logger)
    def test_5(a1, a2, **kwargs):
        return a1, a2, kwargs


# Generated at 2022-06-24 01:43:48.075206
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True,3)
    assert session.mounts["http://"][0].max_retries.total == 3
    assert session.mounts["https://"][0].max_retries.total == 3

# Generated at 2022-06-24 01:43:51.815226
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)
    session.get("https://www.google.com")

# Generated at 2022-06-24 01:43:59.767595
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session()
    assert build_requests_session(raise_for_status=False)
    assert build_requests_session(retry=1)
    assert build_requests_session(retry=Retry())
    assert build_requests_session(retry=False)
    try:
        build_requests_session(retry=None)
        assert False
    except AssertionError:
        pass
    try:
        build_requests_session(retry={"a": "b"})
        assert False
    except AssertionError:
        pass


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-24 01:44:03.106436
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=3)
    assert session.adapters["http://"].max_retries.total == 3
    assert session.adapters["https://"].max_retries.total == 3

# Generated at 2022-06-24 01:44:05.771696
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session()
    assert type(requests_session) == Session
    requests_session.close()



# Generated at 2022-06-24 01:44:08.368543
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def foo(a, b, c):
        print("foo")

    f = LoggedFunction("logger")
    print(f(foo)(1, b=2, c=("c", "d")))

# Generated at 2022-06-24 01:44:11.321798
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    lf = LoggedFunction(logger)
    def test():
        print("My function test")
    lf(test)()

# Generated at 2022-06-24 01:44:22.516127
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MagicMock()
    decorated_func = LoggedFunction(logger)(lambda x, y: x+y)
    assert decorated_func.__name__ == "lambda"
    assert decorated_func.__doc__ == "<lambda>"
    decorated_func(1, 2)
    logger.debug.assert_called_once_with("<lambda>(1, 2)")
    logger.debug.reset_mock()

    decorated_func = LoggedFunction(logger)(lambda x, y: None)
    decorated_func(1, 2)
    logger.debug.assert_any_call("<lambda>(1, 2)")
    assert logger.debug.call_count == 1
    logger.debug.reset_mock()

    decorated_func = LoggedFunction(logger)(lambda x: None)
    decorated_func(1)
    logger

# Generated at 2022-06-24 01:44:27.151812
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging_utils.init_logger(logging.DEBUG)
    test_logger = LoggedFunction(logger)
    test1 = test_logger(test1)
    test2 = test_logger(test2)
    test1(1,2,3)
    test2(1,2,3)
    return 


# Generated at 2022-06-24 01:44:30.576588
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)

# Generated at 2022-06-24 01:44:31.321377
# Unit test for function build_requests_session
def test_build_requests_session():
    pass

# Generated at 2022-06-24 01:44:32.416428
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session()

# Generated at 2022-06-24 01:44:42.227165
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import io
    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def f(a, b, c=2, d=3):
        return a + b + c + d
    f(1, 2)
    stream.seek(0)
    assert (
        stream.read()
        == "DEBUG:LoggedFunction:f(1, 2, c=2, d=3)\nDEBUG:LoggedFunction:f -> 8\n"
    )
    stream.close()

# Generated at 2022-06-24 01:44:47.527054
# Unit test for function format_arg
def test_format_arg():
    print(format_arg(None))
    print(format_arg(1))
    print(format_arg(1.0))
    print(format_arg("1"))
    print(format_arg("1.0"))
    print(format_arg("ab"))
    print(format_arg(True))
    print(format_arg(False))



# Generated at 2022-06-24 01:44:50.532798
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("  string  ") == "'string'"
    assert format_arg(3.1412) == "3.1412"
    assert format_arg(1000) == "1000"

# Generated at 2022-06-24 01:44:54.359942
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    @LoggedFunction()
    def test(x, y, z=1):
        return 0
    
    assert test.__name__ == 'test'
    assert test.__doc__ == "Decorator which adds debug logging to a function.\n\nThe input arguments are logged before the function is called, and the\nreturn value is logged once it has completed."


# Generated at 2022-06-24 01:45:05.385234
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import logging.config
    import sys
    import tempfile
    import unittest

    import yaml


# Generated at 2022-06-24 01:45:15.687025
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("") == "''"
    assert format_arg("a") == "'a'"
    assert format_arg("a ") == "'a '"
    assert format_arg(" a") == "' a'"
    assert format_arg(" a ") == "' a '"
    assert format_arg(0) == "0"
    assert format_arg(0.0) == "0.0"
    assert format_arg([]) == "[]"
    assert format_arg((1,)) == "(1,)"
    assert format_arg({}) == "{}"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg({'a': 3}) == "{'a': 3}"

# Generated at 2022-06-24 01:45:25.535683
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # create a logger and LoggingFunction instance
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def add(a, b):
        return a + b

    input_values = [(1, 2), (2, 3)]
    expected_values = [3, 5]

    for in_value, expected in zip(input_values, expected_values):
        assert add(*in_value) == expected

    # FIXME: find a way to verify the logs use inspected.signature(add).parameters

# Generated at 2022-06-24 01:45:31.928336
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import Mock

    # Set up logger mock
    log_mock = Mock()
    logger = LoggedFunction(log_mock)

    @logger
    def test_function(a, b, c="test"):
        return a + b

    # Call function
    result = test_function(1, 2, c=3)

    # Check output
    assert result == 3
    log_mock.debug.assert_called_with("test_function(1, 2, c=3)")
    assert log_mock.debug.call_count == 2

# Generated at 2022-06-24 01:45:36.418212
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Check creating a LoggedFunction with a logger
    logger = logging.getLogger("test")
    assert_equal(LoggedFunction(logger).logger, logger)


# Decorator which returns a function that proxies the input and output of a given
# function to an initialised logger.
logged = LoggedFunction(logging.getLogger())



# Generated at 2022-06-24 01:45:46.857411
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import return_value_logger

    logger = logging.getLogger("example")
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)

    @return_value_logger.LoggedFunction(logger)
    def example_function(a, b):
        return 1

    def example_function_with_args(a, b, c=3, d=4):
        return 2

    example_function_logged = return_value_logger.LoggedFunction(logger)(
        example_function_with_args
    )

    assert example_function(1, 2) == 1
    assert example_function_with_args(1, 2) == 2
    assert example_function_logged(1, 2) == 2

# Generated at 2022-06-24 01:45:56.325467
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10
    assert not session.hooks

    session = build_requests_session(False)
    assert not session.hooks

    session = build_requests_session(True)
    assert len(session.hooks["response"]) == 1

    session = build_requests_session(retry=False)
    assert not session.adapters
    assert not session.hooks

    session = build_requests_session(retry=True)

# Generated at 2022-06-24 01:45:59.222424
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=3)
    print(session.adapters)
    for name, max_retries in session.adapters.items():
        print(name, max_retries.max_retries)

# Generated at 2022-06-24 01:46:05.302765
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import shutil
    import sys
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.log_file = tempfile.NamedTemporaryFile(delete=False)
            logging.basicConfig(
                stream=self.log_file,
                level=logging.DEBUG,
                format="%(asctime)s [%(levelname)-5.5s] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )

        def tearDown(self):
            self.log_file.close()
            os.unlink(self.log_file.name)


# Generated at 2022-06-24 01:46:09.967252
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('hello') == "'hello'"
    assert format_arg(123) == "123"
    assert format_arg(None) == "None"
    assert format_arg(b'blah') == "b'blah'"

# Generated at 2022-06-24 01:46:20.747810
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from .logging import LoggerFactory

    logger = LoggerFactory.create_logger("test")
    def test_func(a, b='c'):
        return None

    @LoggedFunction(logger=logger)
    def foo_func(a, b='c'):
        return 1

    @LoggedFunction(logger=logger)
    def bar_func(a, b='c'):
        return 2

    assert foo_func.__name__ == "foo_func"
    assert bar_func.__name__ == "bar_func"
    assert foo_func.__doc__ == "test_func"
    assert bar_func.__doc__ == "test_func"
    assert foo_func(1, 2) == 1
    assert bar_func(1, 2) == 2
    assert foo_

# Generated at 2022-06-24 01:46:26.179799
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(2) == "2"
    assert format_arg("test") == "'test'"
    assert format_arg(" 'test' ") == "'test'"
    assert format_arg(" 'test'\n") == "'test'"

# Generated at 2022-06-24 01:46:28.522320
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=3)
    session.get("https://www.baidu.com")

# Generated at 2022-06-24 01:46:32.925353
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # arrange
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    def test_func(a, b, c):
        return a + b + c

    # act
    f = LoggedFunction(logger)(test_func)
    result = f(1, 2, 3)

    # assert
    assert result == 6


# Generated at 2022-06-24 01:46:36.741177
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg("a") == "'a'"
    assert format_arg('"a"') == "'\"a\"'"
    assert format_arg(" a ") == "' a '"
    assert format_arg(None) == 'None'

# Generated at 2022-06-24 01:46:47.956527
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test with default config
    session = build_requests_session()
    assert session is not None

    # Test with raise_for_status
    session = build_requests_session(raise_for_status=False)
    assert session is not None

    # Test with retry
    session = build_requests_session(retry=True)
    assert session is not None

    # Test with retry and int
    session = build_requests_session(retry=10)
    assert session is not None

    # Test with retry and Retry
    session = build_requests_session(retry=Retry())
    assert session is not None

    # Test with retry and bad input
    try:
        session = build_requests_session(retry=object())
    except ValueError:
        pass

# Generated at 2022-06-24 01:46:57.601915
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger('test')
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    # create a function to test constructor of class LoggedFunction
    def test_function(a, b=1):
        return a+b
    # create a class LoggedFunction
    logged_function = LoggedFunction(logger)
    # test constructor of class LoggedFunction
    assert logged_function.logger == logger


# Generated at 2022-06-24 01:47:00.715488
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    f = LoggedFunction(logging.getLogger())
    assert f


# Generated at 2022-06-24 01:47:02.478638
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1234)=="1234"
    assert format_arg("1, 2, 3, 4") == "'1, 2, 3, 4'"

# Generated at 2022-06-24 01:47:14.496162
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=True)
    assert session.mounts["http://"][0].max_retries.total == 10
    session = build_requests_session(retry=False)
    assert session.mounts["http://"][0].max_retries.total == 1
    session = build_requests_session(retry=1)
    assert session.mounts["http://"][0].max_retries.total == 2
    session = build_requests_session(retry=Retry(5))
    assert session.mounts["http://"][0].max_retries.total == 6
    session = build_requests_session(retry=True, raise_for_status=True)

# Generated at 2022-06-24 01:47:24.226287
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class FakeLogger:
        debug = lambda *args, **kwargs: None
        info = lambda *args, **kwargs: None

    # Check that _log_function() is called upon creation
    class FakeFunction:
        def __init__(self):
            self.call_log = []

        def __call__(self, *args, **kwargs):
            self.call_log.append((args, kwargs))

    f = FakeFunction()
    result = LoggedFunction(FakeLogger())(f)
    result(1, 2, 3)
    assert f.call_log == [(('1', '2', '3'), {})]

# Generated at 2022-06-24 01:47:28.235818
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(str(1)) == '1'
    assert format_arg('a') == "'a'"
    assert format_arg(' a b  ') == "'a b'"
    assert format_arg(None) == 'None'
    assert format_arg(True) == 'True'
    assert format_arg(False) == 'False'

# Generated at 2022-06-24 01:47:31.404164
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert(LoggedFunction)



# Generated at 2022-06-24 01:47:36.275745
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def foo(a, b):
        return a + b

    logger = logging.getLogger(__name__)
    logger.disabled = True
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    logged = LoggedFunction(logger)
    f = logged(foo)
    f(1, 2)
    assert f(2, 3) == 5
    f("hello", "world")



# Generated at 2022-06-24 01:47:44.925411
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)

            self.log_handler = logging.StreamHandler()
            self.logger.addHandler(self.log_handler)

            @LoggedFunction(self.logger)
            def test_function(a, b, c):
                return a + b + c

            self.test_function = test_function

        def test_call(self):
            result = self.test_function("a", "b", "c")
            self.logger.debug("\n".join(self.log_handler.messages))
            self.log_handler.close()


# Generated at 2022-06-24 01:47:48.763517
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg("   ") == "'   '"
    assert format_arg(" abc ") == "' abc '"
    assert format_arg("abc") == "'abc'"
    with pytest.raises(NameError):
        format_arg(abc)

# Generated at 2022-06-24 01:47:56.641558
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test with retry True
    session = build_requests_session(retry=True)
    assert len(session.adapters) == 2
    assert isinstance(list(session.adapters.values())[0], HTTPAdapter)
    assert list(session.adapters.values())[0].max_retries.total == 10
    assert len(session.hooks["response"]) == 0

    # Test with raise_for_status True and retry False
    session = build_requests_session(raise_for_status=True, retry=False)
    assert len(session.adapters) == 0
    assert len(session.hooks["response"]) == 1
    assert callable(session.hooks["response"][0])

    # Test with retry 3

# Generated at 2022-06-24 01:48:07.431082
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import exceptions

    session = build_requests_session(raise_for_status=False)

    resp = session.get("http://www.example.com/")
    assert resp.status_code == 200
    resp.raise_for_status()

    with pytest.raises(exceptions.HTTPError):
        session = build_requests_session(raise_for_status=True)
        session.get("http://www.example.com/")

    session = build_requests_session(raise_for_status=False, retry=False)
    with pytest.raises(exceptions.ConnectionError):
        session.get("http://www.this-is-not-exist.com/")

    session = build_requests_session(raise_for_status=False, retry=5)

# Generated at 2022-06-24 01:48:13.003330
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from loguru import logger
    logger.disable('__main__')
    
    greetings = 'hello world'
    @LoggedFunction(logger)
    def dummy(a, b):
        return a+b
    logger.enable('__main__')
    assert dummy('hello', ' world') == greetings

# Generated at 2022-06-24 01:48:24.713447
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from contextlib import redirect_stdout

    from logging import StreamHandler, Logger, DEBUG, INFO

    logger = Logger(__name__)

    # Create a stream for logging to
    stream = StringIO()
    stream_handler = StreamHandler(stream)

    logger.addHandler(stream_handler)

    # Decorate function
    @LoggedFunction(logger)
    def test(a, b):
        return a + b

    # Run function
    with redirect_stdout(stream):
        test(1, 2)

    # Should be a debug level
    assert stream.getvalue() == "test(1, 2)\n"

    # Run function again with different arguments
    with redirect_stdout(stream):
        test(b="a", a="b")

    # Should be a debug level


# Generated at 2022-06-24 01:48:26.769908
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s, Session)

# Generated at 2022-06-24 01:48:34.175420
# Unit test for function build_requests_session
def test_build_requests_session():
    # test type of return value
    assert isinstance(build_requests_session(), Session)

    # test if raise_for_status is True, a hook to raise status will be installed
    r = build_requests_session(True).get("https://httpstat.us/404")
    assert r.status_code == 404
    assert r.reason != "OK"

    try:
        r.raise_for_status()
    except Exception as e:
        assert str(e).startswith("404 Client Error")

    # test if raise_for_status is False, a hook to raise status will not be installed
    r = build_requests_session(False).get("https://httpstat.us/404")
    assert r.status_code == 404
    assert r.reason != "OK"
    assert r.raise_for_status

# Generated at 2022-06-24 01:48:35.611737
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True)
    session.get("https://google.com")

# Generated at 2022-06-24 01:48:45.259695
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    # create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # decorate func with class LoggedFunction
    @LoggedFunction(logger)
    def test_func(arg1, arg2='hello', arg3=True):
        return f"arg1={arg1}, arg2={arg2}, arg3={arg3}"
    print(test_func('world'))
    
    
    


# Generated at 2022-06-24 01:48:49.944076
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(True, False)
    assert s.hooks["response"] == [lambda r, *args, **kwargs: r.raise_for_status()]



# Generated at 2022-06-24 01:49:01.118588
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from datetime import datetime
    from src.common.logger import Logger
    from src.common.config import Config
    from src.common.types import LogLevel

    config = Config()
    config.log_folder = "."
    config.log_level = LogLevel.DEBUG
    config.log_file_prefix = "test_common"
    logger = Logger(config)

    @LoggedFunction(logger)
    def test_func(a, b=10, *args, **kwargs):
        return (a * b, args, kwargs)

    result = test_func(2, 3, 4, 5, *list(range(10)), **{"c": 10, "d": 20})

# Generated at 2022-06-24 01:49:03.526942
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    session = build_requests_session()
    assert isinstance(session, Session)

# Generated at 2022-06-24 01:49:12.514335
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    from unittest.mock import MagicMock
    from unittest.mock import patch
    logger = MagicMock()
    class Sample(object):

        @LoggedFunction(logger)
        def log_func(self):
            return 42

    with patch.object(logger, 'debug') as mock_debug:
        sample = Sample()
        sample.log_func()
        mock_debug.assert_called_once_with('log_func() -> 42')



# Generated at 2022-06-24 01:49:15.782657
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('a=1') == "'a=1'"
    assert format_arg(123) == '123'
    assert format_arg(None) == 'None'
    assert format_arg(None) == 'None'



# Generated at 2022-06-24 01:49:19.281847
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = MagicMock()
    func = LoggedFunction(logger)
    @func
    def tfn(x):
        return x
    assert isinstance(tfn, functools.partial)

# Generated at 2022-06-24 01:49:22.265047
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("foo bar") == "'foo bar'"



# Generated at 2022-06-24 01:49:32.075222
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s.adapters['https://'].max_retries, Retry)
    s = build_requests_session(False)
    assert not hasattr(s, 'hooks')
    s = build_requests_session(True)
    assert len(s.hooks['response']) == 1
    s = build_requests_session(True, False)
    assert len(s.hooks['response']) == 1
    assert not hasattr(s.adapters['https://'], 'max_retries')
    s = build_requests_session(False, False)
    assert not hasattr(s, 'hooks')
    assert not hasattr(s.adapters['https://'], 'max_retries')
    s = build_requests_session

# Generated at 2022-06-24 01:49:35.759431
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("a") == "'a'"
    assert format_arg(True) == "True"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:49:44.621549
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()

    # Test adding debug logging to a function
    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a + b + (c or 0)

    test_func(1, 2, 3)
    test_func(1, 2)
    test_func(1, 2, c=3)
    test_func(1, 2, c=None)

    # Test function name and arguments
    test_func("A", "B", "C")
    test_func("A", "B", c="C")
    test_func("A", "B", c=None)
    test_func("A", "B")
    test_func("A", "B", c=None)

    # Test function works as expected after decoration
    assert test_

# Generated at 2022-06-24 01:49:50.530359
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert dir(LoggedFunction) == ['__call__', '__class__', '__delattr__', '__dict__',
                                   '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__',
                                   '__gt__', '__hash__', '__init__', '__init_subclass__', '__le__', '__lt__',
                                   '__module__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__',
                                   '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__',
                                   'logger']



# Generated at 2022-06-24 01:49:51.702670
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(None)



# Generated at 2022-06-24 01:49:55.395894
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session(retry=True)
    build_requests_session(retry=2)
    build_requests_session(retry=False)
    Retry(2)
    with pytest.raises(ValueError):
        build_requests_session(retry=Retry(2))

# Generated at 2022-06-24 01:50:04.190873
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None
    assert session.max_redirects == 30
    assert session.headers == {"User-Agent": "Ancora-API-Client"}
    assert not session.hooks
    assert session.adapters != {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    retry = session.adapters["http://"].max_retries
    assert isinstance(retry, Retry)
    assert retry.total == 5
    assert retry.redirect == 0

# Generated at 2022-06-24 01:50:06.801504
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(' a string ') == "' a string '"

# Generated at 2022-06-24 01:50:13.782541
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert s.max_retries
    with pytest.raises(ValueError):
        build_requests_session(retry="hi")
    with pytest.raises(ValueError):
        build_requests_session(retry=None)
    with pytest.raises(ValueError):
        build_requests_session(retry=1.0)

# Generated at 2022-06-24 01:50:24.626786
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest import mock

    @LoggedFunction(logging.getLogger())
    def test_function(a, b=None, *args):
        return a + b + sum(args)

    # Call the logging method, capturing the output
    test_args = (1, 2)
    test_kwargs = {"b": 2, "c": 1.0, "d": True, "e": "test"}
    with StringIO() as buf, mock.patch("sys.stdout", buf):
        result = test_function(*test_args, **test_kwargs)

    # Check that the output is as expected
    result_string = buf.getvalue()

# Generated at 2022-06-24 01:50:30.038954
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("")
    func = lambda x, y : x+y
    decorated = LoggedFunction(logger)(func)
    assert decorated.__name__ == "func"
    decorated(1, 2)

# Generated at 2022-06-24 01:50:40.729754
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger
    from unittest import mock

    # Mock the logger
    logger = getLogger("test")
    with mock.patch.object(logger, "debug") as mock_log:
        # Mock function to be logged
        def mock_func(*args, **kwargs):
            # Should print:
            # >>> mock_func(1, 2, 3)
            # >>> mock_func(1, 2, 3) -> 42
            return 42

        # Create logged function
        logged_func = LoggedFunction(logger)(mock_func)

        # Call function
        assert logged_func(1, 2, 3) == 42

        # Check for log messages
        assert mock_log.call_count == 2
        mock_log.assert_any_call("mock_func(1, 2, 3)")


# Generated at 2022-06-24 01:50:48.169407
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func_name = "some func"
    x = 1
    y = "hi"
    z = {}
    w = []
    args = [x, y, z, w]
    kwargs = {"key1": x, "key2": y, "key3": z, "key4": w}
    func = lambda x, y, z, w, key1, key2, key3, key4: x, y, z, w, key1, key2, key3, key4
    func.__name__ = func_name
    logger = mock.Mock()
    logged = LoggedFunction(logger)
    logged_func = logged(func)
    result = logged_func(*args, **kwargs)

# Generated at 2022-06-24 01:50:54.221594
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    from unittest import mock

    logger = logging.Logger("test-logger")
    with mock.patch.object(logger, "debug") as debug_mock:
        # Create LoggedFunction wrapper
        logged_func = LoggedFunction(logger)(lambda x: x * x)

        # Call the wrapped function
        logged_func(3)

        # Check the logging
        debug_mock.assert_called_once_with("<lambda>(3)")
        logger.debug.assert_has_calls(
            [
                mock.call("<lambda>(3)"),
                mock.call("<lambda> -> 9"),
            ]
        )

# Generated at 2022-06-24 01:51:01.227828
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from StringIO import StringIO
    from types import FunctionType
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("LoggedFunction")
            log_file = StringIO()
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler(log_file))
            @LoggedFunction(logger)
            def double(x):
                return 2 * x
            self.assertIsInstance(double, FunctionType)
            double(3)
            self.assertEqual(
                log_file.getvalue(),
                "DEBUG:LoggedFunction:double(3)\n"
                "DEBUG:LoggedFunction:double -> 6\n",
            )

# Generated at 2022-06-24 01:51:02.735798
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-24 01:51:08.104622
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import datetime
    import io
    import logging
    import unittest

    @LoggedFunction(logging.getLogger("test"))
    def test_function(a, b):
        """
        Test function.

        :param a: First argument
        :param b: Second
        :return: a+b
        """
        return a + b

    class LoggedFunctionTestCase(unittest.TestCase):
        def test__call__(self):
            stream = io.StringIO()
            handler = logging.StreamHandler(stream=stream)
            handler.setFormatter(logging.Formatter("%(message)s"))

            logger = logging.getLogger("test")
            logger.addHandler(handler)
            logger.setLevel(logging.DEBUG)

            result = test_function(1, 2)
           

# Generated at 2022-06-24 01:51:17.943185
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    # Set up logger
    logger = logging.getLogger("foo")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    # Define a function
    @LoggedFunction(logger)
    def bar(a, b, c=None):
        return a + b + (c or 0)

    # Call function and check that logging works
    @LoggedFunction(logger)
    def baz():
        return "test"

    bar(1, 2)
    bar(1, None, 2)
    bar(1, 2, "c")
    baz()

# Generated at 2022-06-24 01:51:24.560479
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(12) == "12"
    assert format_arg("message") == "'message'"
    assert format_arg("message with space") == "'message with space'"
    assert format_arg(" message with space") == "' message with space'"
    assert format_arg(" message with space ") == "' message with space '"



# Generated at 2022-06-24 01:51:29.267502
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from .log import Logger

    logger = Logger("abc")
    logged_func = LoggedFunction(logger)

    class A:
        def __init__(self, x, y=1):
            self.x = x
            self.y = y

        @logged_func
        def test1(self, z):
            return z + self.x

    a = A(1)
    assert a.test1(2) == 3



# Generated at 2022-06-24 01:51:35.668629
# Unit test for function build_requests_session
def test_build_requests_session():
    def test_retry(retry, default=3):
        session = build_requests_session(retry=retry)
        adapter = session.adapters["http://"]
        assert isinstance(adapter.max_retries, Retry)
        assert adapter.max_retries.total == default

    test_retry(True)
    test_retry(3)
    test_retry(Retry(4))
    with pytest.raises(ValueError):
        test_retry(1.0)

# Generated at 2022-06-24 01:51:46.238962
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    >>> import sys, logging
    >>> logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
    >>> @LoggedFunction(logging.getLogger(__name__))
    ... def foo(a, b=2):
    ...     pass
    >>> foo(1)
    DEBUG:__main__:foo(1, b=2)
    DEBUG:__main__:foo -> None
    >>> foo(1, 2)
    DEBUG:__main__:foo(1, b=2)
    DEBUG:__main__:foo -> None
    >>> foo(1, b=2)
    DEBUG:__main__:foo(1, b=2)
    DEBUG:__main__:foo -> None
    """



# Generated at 2022-06-24 01:51:55.181206
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test arguments
    arg1 = "a"
    arg2 = 1
    arg3 = None
    arg4 = ""
    arg5 = True
    arg6 = []
    arg7 = {}
    # Test parameters
    param1 = "b"
    param2 = 2
    param3 = "None"
    param4 = " "
    param5 = False
    param6 = ["a"]
    param7 = {"a": 1}
    # Test function
    def func(arg1, arg2=param2, arg3=param3, arg4=param4, arg5=param5, arg6=param6, arg7=param7):
        return arg1 + arg2 + len(arg3) + len(arg4) + arg5 + len(arg6) + len(arg7)

    # Test logged function

# Generated at 2022-06-24 01:52:05.319636
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["http://"].max_retries.total == 5
    assert session.adapters["https://"].max_retries.total == 5
    session = build_requests_session(retry=3)
    assert session.adapters["http://"].max_retries.total == 3
    assert session.adapters["https://"].max_retries.total == 3
    session = build_requests_session(retry=Retry(0))
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.total == 0

# Generated at 2022-06-24 01:52:12.535300
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest
    import unittest.mock as mock

    # monkey patch logging
    logger = mock.MagicMock()

    with mock.patch("wiser.signals.logging.Logger") as logger_mock:
        logger_mock.getLogger.return_value = logger
        @logged_function(logger)
        def func(a, b="B"):
            return None

    func("a", "b")
    logger_mock.getLogger.assert_called_once_with("wiser.signals.logger")
    logger.debug.assert_called_once_with("func('a', b='b')")

# Generated at 2022-06-24 01:52:24.383150
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, 3)
    assert session.hooks.get("response") is not None
    assert isinstance(session.mounts.get("http://").max_retries, Retry)
    assert isinstance(session.mounts.get("https://").max_retries, Retry)
    session = build_requests_session(True, False)
    assert session.hooks.get("response") is not None
    assert session.mounts.get("http://").max_retries is None
    assert session.mounts.get("https://").max_retries is None
    session = build_requests_session(True, Retry(3, backoff_factor=0.5))
    assert session.hooks.get("response") is not None

# Generated at 2022-06-24 01:52:26.965219
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(3) == "3"
    assert format_arg("hello  ") == "'hello'"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"
    assert format_arg({3, 2, 1}) == "{1, 2, 3}"
    assert format_arg({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-24 01:52:32.259618
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("A") == "'A'"
    assert format_arg('"') == '\'"\''
    assert format_arg(5) == "5"
    assert format_arg(None) == "None"
    assert format_arg(["a", "b"]) == "['a', 'b']"

# Generated at 2022-06-24 01:52:37.760232
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test")
    handler = logging.StreamHandler(stream=sys.stdout)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    assert isinstance(LoggedFunction(logger), LoggedFunction)



# Generated at 2022-06-24 01:52:41.194744
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger=logger)
    def test_func(a, b):
        return a + b
    ans = test_func(1, b=2)
    assert ans == 3