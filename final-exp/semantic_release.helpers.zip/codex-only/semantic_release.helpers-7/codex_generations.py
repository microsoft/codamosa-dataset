

# Generated at 2022-06-24 01:42:44.911802
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg("1,2") == "'1,2'"
    assert format_arg(1.1) == "1.1"
    assert format_arg(None) == "None"
    assert format_arg({'a': 1}) == "{'a': 1}"

# Generated at 2022-06-24 01:42:53.812270
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test setting
    class TestConfig:
        pass
    test_config = TestConfig()
    test_config.debug = True
    # Test
    test_logger = logging.getLogger("TestLogger")
    test_logger.setLevel(logging.DEBUG)
    test_logger.addHandler(logging.NullHandler())
    @LoggedFunction(logger=test_logger)
    def test_func(a, b=2, c=None):
        return a+b
    test_func(a=1)
    test_func(a=1, b=3, c=3)
    test_func(c=3, b=3, a=1)
    test_func(1, 2)
    test_func(1, 2, "c")

# Generated at 2022-06-24 01:42:57.448884
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('test') == "'test'"
    assert format_arg(1) == '1'


# Generated at 2022-06-24 01:43:03.053299
# Unit test for function build_requests_session
def test_build_requests_session():
    session1 = build_requests_session()
    assert session1.hooks == {}
    assert len(session1.adapters) == 1
    assert "http://" in session1.adapters
    assert "https://" in session1.adapters

    session2 = build_requests_session(retry=Retry(10))
    assert session2.hooks == {}
    assert len(session2.adapters) == 1
    assert "http://" in session2.adapters
    assert "https://" in session2.adapters

# Generated at 2022-06-24 01:43:14.072127
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger(__name__ + "." + "test")
    logger.setLevel(logging.DEBUG)
    sh = logging.StreamHandler()
    sh.setLevel(logging.DEBUG)
    logger.addHandler(sh)
    logger.propagate = False

    def add(a, b):
        return a + b

    logged_add = LoggedFunction(logger)(add)
    logged_add(1, 2)
    logged_add(1, b=2)
    logged_add(a=1, b=2)
    logged_add(a="ab", b=2)
    logged_add(a="a'b", b=2)


# Generated at 2022-06-24 01:43:22.416176
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    # Create logger to send output to
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create logger to send output to
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Attach output handler to logger
    #
    # The handler records log messages and is used here to get the debug
    # output from the decorators. This output can then be checked against
    # the expected output.
    logger.addHandler(logging.NullHandler())
    assert logger.handlers[0].__class__.__name__ == "NullHandler"
    handler = logging.StreamHandler()
    logger.handlers[0] = handler

    # Create a decorator to add debug logging to print_number()
    logged_

# Generated at 2022-06-24 01:43:24.966217
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class Test():

        def __init__(self):
            self.logger = logging.getLogger()

    test = Test()
    assert test.logger == logging.getLogger()


# Generated at 2022-06-24 01:43:30.841031
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg(" 1 ") == "' 1 '"
    assert format_arg(True) == "True"



# Generated at 2022-06-24 01:43:38.218316
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(Retry()) == build_requests_session(False)
    assert (
        build_requests_session(5) == build_requests_session(Retry(5))
        == build_requests_session()
    )
    try:
        build_requests_session("string")
        assert False
    except ValueError:
        pass
    try:
        build_requests_session(object())
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 01:43:44.063274
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger=logging.getLogger()

    def hello(name):
        return f"hello {name}"
    decorated_hello = LoggedFunction(logger)(hello)
    
    @LoggedFunction(logger)
    def hello2(name):
        return f"hello {name}"
    
    print(decorated_hello('world'))
    print(hello2('world'))

# Generated at 2022-06-24 01:43:54.169364
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch

    def my_function(x, y):
        return x + y

    with patch("logging.Logger.debug") as mock_debug:
        logged_func = LoggedFunction("dummy")(my_function)
        assert logged_func.__name__ == my_function.__name__

        assert logged_func(1, 2) == 3
        mock_debug.assert_any_call("my_function(1, 2)")
        mock_debug.assert_any_call("my_function -> 3")

        assert logged_func("a", "b") == "ab"
        mock_debug.assert_any_call("my_function('a', 'b')")
        mock_debug.assert_any_call("my_function -> ab")


# Generated at 2022-06-24 01:44:05.467462
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert isinstance(session.adapters, dict)
    assert 'http://' in session.adapters
    assert 'https://' in session.adapters
    assert isinstance(session.adapters['http://'], HTTPAdapter)
    assert isinstance(session.adapters['https://'], HTTPAdapter)
    assert session.hooks is None

    session = build_requests_session(False)
    assert isinstance(session, Session)
    assert isinstance(session.adapters, dict)
    assert 'http://' in session.adapters
    assert 'https://' in session.adapters
    assert isinstance(session.adapters['http://'], HTTPAdapter)
    assert isinstance(session.adapters['https://'], HTTPAdapter)


# Generated at 2022-06-24 01:44:15.823387
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import Logger, NOTSET, DEBUG

    # mock setupLogging method
    def setupLogging(level=NOTSET):
        pass

    # mock logger
    class MockLogger(Logger):
        def __init__(self):
            pass

        def debug(self,msg):
            print(msg)
    # create mock logger
    logger = MockLogger()

    # create mock logger which raise error
    logger_error = MockLogger()
    def raise_error(msg):
        raise AssertionError

    logger_error.debug = raise_error

    # create decorator with logger
    decorator = LoggedFunction(logger)

    # mock function
    def mock_function(arg1,arg2,arg3=None):
        return None

    # create decorated function

# Generated at 2022-06-24 01:44:17.393883
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    log = LoggedFunction(logging.getLogger('tester.logger'))



# Generated at 2022-06-24 01:44:28.791916
# Unit test for function build_requests_session
def test_build_requests_session():
    with pytest.raises(ValueError):
        build_requests_session(retry=Retry(1, False))
    with pytest.raises(ValueError):
        build_requests_session(retry=False)
    with pytest.raises(ValueError):
        build_requests_session(retry="a")

    s = build_requests_session(retry=1)
    assert type(s) == Session
    s = build_requests_session(retry=Retry(1))
    assert type(s) == Session
    s = build_requests_session(retry=True)
    assert type(s) == Session
    s = build_requests_session(retry=False)
    assert type(s) == Session

# Generated at 2022-06-24 01:44:30.808687
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session()
    assert isinstance(requests_session, Session)

# Generated at 2022-06-24 01:44:34.307522
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    l = LoggedFunction()
    @l
    def fun(*args,**kwargs):
        return
    fun(2, 3, 4, kw1=5, kw2=6)



# Generated at 2022-06-24 01:44:38.332769
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1), "1"
    assert format_arg(1.0), "1.0"
    assert format_arg(""), """"""

# Generated at 2022-06-24 01:44:41.571958
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()


# Generated at 2022-06-24 01:44:45.321730
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True)
    # Note: the below url does not exist, this is just for the session test.
    session.get("http://www.example.com")

# Generated at 2022-06-24 01:44:54.663499
# Unit test for function build_requests_session
def test_build_requests_session():
    from unittest.mock import patch
    from requests.exceptions import HTTPError

    session = build_requests_session(raise_for_status=True, retry=False)
    with patch.object(session, "get", side_effect=HTTPError()):
        with pytest.raises(HTTPError):
            session.get("url")

    session = build_requests_session(raise_for_status=False, retry=False)
    with patch.object(session, "get", side_effect=HTTPError()):
        session.get("url")

    session = build_requests_session(raise_for_status=True, retry=True)

# Generated at 2022-06-24 01:44:58.395403
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('"test"') == "'\"test\"'"
    assert format_arg(1) == "1"

# Generated at 2022-06-24 01:45:06.555209
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest

    def mock_func(*args, **kwargs):
        pass

    class TestLoggedFunction(unittest.TestCase):
        def test_no_args(self):
            logger = logging.getLogger()
            decorated = LoggedFunction(logger)(mock_func)
            self.assertEqual(decorated.__name__, mock_func.__name__)

        def test_args(self):
            logger = logging.getLogger()
            decorated = LoggedFunction(logger)(mock_func)
            self.assertEqual(decorated.__name__, mock_func.__name__)
            decorated(1, 2)

        def test_kwargs(self):
            logger = logging.getLogger()

# Generated at 2022-06-24 01:45:12.605804
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == '5'
    assert format_arg('str') == "'str'"
    assert format_arg('') == "''"
    assert format_arg('str') == format_arg('str')
    assert format_arg('str  ') == format_arg('str')

# Generated at 2022-06-24 01:45:13.393397
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    _ = LoggedFunction(logger = None)

# Generated at 2022-06-24 01:45:16.392941
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session(retry=True).get('https://httpbin.org/status/503')
    build_requests_session(retry=1).get('https://httpbin.org/status/503')
    build_requests_session(retry=Retry(total=0)).get('https://httpbin.org/status/503')

# Generated at 2022-06-24 01:45:21.849735
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg("a b") == "'a b'"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:45:27.299059
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("test") == "'test'"
    assert format_arg(" test ") == "'test'"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg("ta'amul") == "'ta'amul'"


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:45:33.750282
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg("") == "''"
    assert format_arg("abc") == "'abc'"
    assert format_arg(123) == "123"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(1.2) == "1.2"
    assert format_arg({"a": 1}) == "{'a': 1}"

# Generated at 2022-06-24 01:45:41.745566
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter("%(levelname)-8s %(name)-15s %(message)s")
    )
    logger.addHandler(handler)

    def test_func(a, b, c=3, d=4, e="5", f="6", g=7):
        pass

    logged_test_func = LoggedFunction(logger)(test_func)
    logged_test_func(1, 2)
    logged_test_func(1, 2, d=4, c=3, f="6", e="5", g=7)

# Generated at 2022-06-24 01:45:52.508361
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import os
    import logging

    # Object of class LoggedFunction
    logger = logging.getLogger("Test")
    logger.setLevel(logging.DEBUG)
    test_func = LoggedFunction(logger)
    assert test_func is not None
    assert type(test_func) is LoggedFunction
    assert test_func.logger is not None
    assert type(test_func.logger) is logging.Logger
    assert test_func.logger.name == "Test"

    # Function of class LoggedFunction
    def func_test(p1, p2, *, k1="value1", k2=2):
        debug_info = f"{func_test.__name__}({p1}, {p2}, {k1}, {k2})"

# Generated at 2022-06-24 01:46:03.394297
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    class DummyFunc:
        def __init__(self):
            self.logger = logging.getLogger("logged_func_test")
            self.logger.setLevel(logging.DEBUG)

            self.handler = logging.FileHandler("logged_func_test.log")
            self.handler.setLevel(logging.DEBUG)
            self.handler.setFormatter(
                logging.Formatter(
                    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
                )
            )

            self.logger.addHandler(self.handler)

        @LoggedFunction(logger=logging.getLogger("logged_func_test"))
        def func1(self):
            pass


# Generated at 2022-06-24 01:46:05.970406
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class LoggerMock:
        def debug(self, msg):
            print(msg)

    @LoggedFunction(LoggerMock())
    def my_func(a, b, c="abc", d=17):
        return a + b

    my_func(17, 10)

# Generated at 2022-06-24 01:46:10.287281
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('a') == "'a'"
    assert format_arg(2) == "2"
    assert format_arg(2.) == "2.0"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:46:21.150422
# Unit test for function build_requests_session
def test_build_requests_session():
    ses = build_requests_session()
    assert ses.hooks == {}
    assert isinstance(ses.adapters['http://'].max_retries, Retry)
    assert ses.adapters['http://'].max_retries.total == 10
    assert ses.adapters['http://'].max_retries.backoff_factor == 0.1
    assert ses.adapters['http://'].max_retries.status_forcelist == [500, 502, 503, 504]
    assert ses.adapters['https://'].max_retries.total == 10
    assert ses.adapters['https://'].max_retries.backoff_factor == 0.1

# Generated at 2022-06-24 01:46:26.254676
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    Test the constructor of LoggedFunction
    :return:
    """
    logger = logging.getLogger('test logger')
    logged_function = LoggedFunction(logger)
    assert (logged_function.logger == logger)


# Generated at 2022-06-24 01:46:35.624928
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_method(*args, **kwargs):
        return "test"
    
    logger = logging.getLogger(__name__)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s: - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    test_case = LoggedFunction(logger)
    test_case.__call__(test_method)
    # logger.removeHandler(ch)
    assert test_case.logger.name == "backend.LoggedFunction"
    assert test_method(1, 2, 3) == "test"
   

# Generated at 2022-06-24 01:46:37.419039
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc") == "'abc'"
    assert format_arg(1) == "1"
    assert format_arg([1, 2]) == "[1, 2]"

# Generated at 2022-06-24 01:46:48.495582
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import tempfile
    import logging

    # Create a temporary file and remove if it exists
    filename = tempfile.mktemp()
    try:
        with open(filename, "w"):
            pass
    except FileNotFoundError:
        pass

    # Configure logging to log to a temporary file
    logging.basicConfig(filename=filename, level=logging.DEBUG)
    logger = logging.getLogger("LoggedFunction")

    # Create a LoggedFunction that uses the logger
    logged_func = LoggedFunction(logger)

    # Define a function to log
    @logged_func
    def foo(x, y=2):
        return x * y

    # Call the logged function with different arguments
    foo(1)
    foo(1, y=3)

    # Check that the logger worked

# Generated at 2022-06-24 01:46:51.086072
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("some string") == "'some string'"
    assert format_arg("'some string'") == "'some string'"
    assert format_arg(123) == "123"
    assert format_arg(0.1234) == "0.1234"
    assert format_arg(True) == "True"
    return True



# Generated at 2022-06-24 01:47:00.204599
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig()
    logger = logging.getLogger("LoggedFunction")

    @LoggedFunction(logger)
    def test_func(a, b, *args, c=None, d=None, **kwargs):
        print(a, b, c, d, args, kwargs)

    a = "a"
    b = "b"
    c = "c"
    d = "d"
    args = "args"
    kwargs = {"kwargs1": "kwargs1", "kwargs2": "kwargs2"}

    # Call test_func
    test_func(a, b, c, d, args, **kwargs)



# Generated at 2022-06-24 01:47:03.672760
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    with LoggedFunction(logging.getLogger())(
        lambda x, y, z=3: x + y + z
    ) as f:
        f(1, 2, z=4)

# Generated at 2022-06-24 01:47:14.904546
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert isinstance(session.adapters['http://'].max_retries, Retry)
    assert isinstance(session.adapters['https://'].max_retries, Retry)

    # test raise_for_status
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

    # test retry
    session = build_requests_session(retry=False)
    assert "http://" not in session.adapters.keys()
    assert "https://" not in session.adapters.keys()
    session = build_requests_session(retry=2)
    assert isinstance

# Generated at 2022-06-24 01:47:16.744301
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # log to logger. might be a better way to do this.
    import logging

    logging.basicConfig(level=logging.DEBUG)

    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    assert add.__name__ == "add"
    assert add(2, 3) == 5



# Generated at 2022-06-24 01:47:25.849670
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock

    function_name = 'function_name'
    function_args = ['value1', 'value2']
    function_kwargs = {'kwarg1' : 'value3', 'kwarg2' : 'value4'}
    expected_log_entry = f"{function_name}('{function_args[0]}', '{function_args[1]}', kwarg1='{function_kwargs['kwarg1']}', kwarg2='{function_kwargs['kwarg2']}')"
    expected_result = 'expected_result'

    def mocked_logger_debug(log_entry):
        assert log_entry == expected_log_entry

    def function_to_log(*args, **kwargs):
        assert args == function_args
        assert kwargs == function_

# Generated at 2022-06-24 01:47:29.617622
# Unit test for function build_requests_session
def test_build_requests_session():
    # test bool
    build_requests_session()

    # test int
    build_requests_session(retry=5)

    try:
        # test wrong type
        build_requests_session(retry=None)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert str(e) == "retry should be a bool, int or Retry instance."

# Generated at 2022-06-24 01:47:31.838677
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session.get("https://www.example.com").status_code, int)

    retry_session = build_requests_session(retry=0)
    assert isinstance(retry_session.get("https://www.example.com").status_code, int)

# Generated at 2022-06-24 01:47:40.160858
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    session = build_requests_session(False)
    assert isinstance(session, requests.Session)
    assert hasattr(session, 'hooks')
    assert session.hooks == {}
    session = build_requests_session(True)
    assert isinstance(session, requests.Session)
    assert hasattr(session, 'hooks')
    assert len(session.hooks) == 1
    assert 'response' in session.hooks.keys()
    assert len(session.hooks['response']) == 1
    assert isinstance(session.hooks['response'][0], functools.partial)
    assert isinstance(session.hooks['response'][0].func, requests.Response.raise_for_status)
    assert session.hooks['response'][0].args == ()
    assert session.hook

# Generated at 2022-06-24 01:47:50.967484
# Unit test for function build_requests_session
def test_build_requests_session():
    from httpbin import HttpBin
    import requests

    httpbin = HttpBin(session_factory=build_requests_session)
    assert isinstance(httpbin.session, Session)
    assert httpbin.session.hooks
    assert httpbin.session.hooks.get('response', [])
    assert isinstance(httpbin.session.adapters['http://'].max_retries, Retry)
    assert isinstance(httpbin.session.adapters['https://'].max_retries, Retry)

    httpbin = HttpBin(session_factory=build_requests_session, raise_for_status=False)
    assert not httpbin.session.hooks.get('response', [])


# Generated at 2022-06-24 01:47:57.898824
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError
    from requests.models import Response
    from requests import Session
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    session = build_requests_session()
    assert type(session) == Session

    session = build_requests_session(raise_for_status=False)
    assert type(session) == Session
    assert len(session.hooks["response"]) == 0

    session = build_requests_session(raise_for_status=True)
    assert type(session) == Session
    assert len(session.hooks["response"]) == 1
    assert session.hooks["response"][0].__name__ == "logged_func"

# Generated at 2022-06-24 01:48:05.921789
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def func(a,b,c):
        return a+b+c
    logged_func=LoggedFunction(print)(func)
    logged_func(1,2,3)
    logged_func(1,2,c=3)
    logged_func(1,c=2,b=3)
    logged_func(c=1,b=2,a=3)


if __name__=="__main__":
    test_LoggedFunction()

# Generated at 2022-06-24 01:48:09.972556
# Unit test for function format_arg
def test_format_arg():
    assert '"A string"' == format_arg("A string")
    assert '1' == format_arg(1)
    assert 'None' == format_arg(None)

# Generated at 2022-06-24 01:48:18.460315
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class MockLogger:
        def __init__(self):
            self.messages = []

        def debug(self, message):
            self.messages.append(message)

    mock_logger = MockLogger()
    decorated_func = LoggedFunction(mock_logger)(
        lambda a, b: a + b)  # Dynamically construct decorated function
    decorated_func(1, 2)
    assert len(mock_logger.messages) == 2
    assert mock_logger.messages[0] == "decorated_func(1, 2)"
    assert mock_logger.messages[1] == "decorated_func -> 3"

# Generated at 2022-06-24 01:48:27.642282
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None
    assert "requests" == session.headers["User-Agent"]
    session = build_requests_session(raise_for_status = True, retry = False)
    assert session is not None
    assert "requests" == session.headers["User-Agent"]
    assert  session.raise_for_status is not None
    session = build_requests_session(raise_for_status = False, retry = 3)
    assert session is not None
    assert "requests" == session.headers["User-Agent"]
    assert  session.raise_for_status is None
    session = build_requests_session(raise_for_status = True, retry = 3)
    assert session is not None

# Generated at 2022-06-24 01:48:31.500704
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg("test test") == "'test test'"
    assert format_arg("test\n\ttest") == "'test\n\ttest'"
    assert format_arg(10) == "10"
    assert format_arg(10.0) == "10.0"

# Generated at 2022-06-24 01:48:35.128771
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)

# Generated at 2022-06-24 01:48:37.054821
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("'") == "''"
    assert format_arg("'""") == "''"

# Generated at 2022-06-24 01:48:44.252066
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger("LoggedFunction")
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test(a, b, c=3, d=4):
        return a + b + c + d

    test(1, 2)
    test(1, 2, d = 5)
    test(1, 2, c = 5, d = 6)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:48:47.229931
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("str") == "'str'"
    assert format_arg('  str  ') == "'str'"

# Generated at 2022-06-24 01:48:53.477632
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Initialize
    logger = logging.getLogger(__name__)
    logged_function = LoggedFunction(logger)

    # Dummy function
    def dummy_function(a, b=1):
        c = a + b
        return c
    # Decorate function
    logged_dummy_function = logged_function(dummy_function)
    # Call function
    dummy_result = logged_dummy_function(1, b=2)
    # Assert
    assert dummy_result == 3

# Generated at 2022-06-24 01:49:03.455618
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.Logger('test')
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    stream_formatter = logging.Formatter('%(message)s')
    file_handler = logging.FileHandler('example.log')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(stream_formatter)
    logger.addHandler(stream_handler)

    @LoggedFunction(logger)
    def func(a, b, c=2, d=1.0, e=None):
        return a + b + c + d


# Generated at 2022-06-24 01:49:09.101357
# Unit test for function format_arg
def test_format_arg():
    # Test a string input
    assert format_arg("abc") == "'abc'"
    # Test a number input
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"


# Generated at 2022-06-24 01:49:13.740209
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("a") == "'a'"
    assert format_arg(" a ") == "' a '"
    assert format_arg('"a"') == "'\"a\"'"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    

# Generated at 2022-06-24 01:49:25.317171
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup
    import logging

    logger_name = "logged_function_logger"
    logging.getLogger(logger_name)

    # Test
    from loguru import logger

    logger.add(sys.stdout, format="{level} {message}", level="DEBUG")
    logger = logging.getLogger(logger_name)

    @LoggedFunction(logger)
    def func():
        return "123"

    result = func()
    print("result:", repr(result))

    logger.debug("123123123")

    import timeit


# Generated at 2022-06-24 01:49:31.609665
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import tempfile

    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s %(levelname)s %(message)s",
        filename=str(tempfile.mktemp()),
    )

    def foo(var1, var2):
        print(var1, var2)

    logged_foo = LoggedFunction(logging.getLogger())(foo)
    logged_foo(1, 2)
    # Output: 2020-11-17 11:34:05 DEBUG foo(1, 2)
    # Output: 2020-11-17 11:34:05 DEBUG foo -> None

# Generated at 2022-06-24 01:49:41.534246
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def add(a, b):
        return a + b

    def test_logged_function_should_log_function_invocation_and_result():
        expected_output = """
DEBUG:add:add(1, 2)
DEBUG:add:add -> 3
        """
        actual_output = io.StringIO()
        with contextlib.redirect_stdout(actual_output):
            result = add(1, 2)
            assert (result == 3)
        assert (actual_output.getvalue() == expected_output.strip())
    
    test_logged_function_should_log_function_invocation_and_result

# Generated at 2022-06-24 01:49:47.106141
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    from gbd.constants import GBD_LOG_LEVEL

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(GBD_LOG_LEVEL)

    # Create LoggedFunction decorator
    logged_func = LoggedFunction(logger)

    # Log some arguments with it
    @logged_func
    def func(a, b, c="hi"):
        pass

    func(1, 2)
    func(1, 2, c=3)
    func(1, 2, 3)

# Generated at 2022-06-24 01:49:54.911378
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

    session.get("http://httpbin.org/status/503")
    session.get("http://httpbin.org/status/503")
    session.get("http://httpbin.org/status/503")

    session = build_requests_session(raise_for_status=False, retry=False)

    session.get("http://httpbin.org/status/503")
    session.get("http://httpbin.org/status/503")
    session.get("http://httpbin.org/status/503")



# Generated at 2022-06-24 01:50:03.055371
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def debug(self, msg):
            pass

    class A:
        @LoggedFunction(Logger())
        def func(self, a, b, *args, **kwargs):
            pass

    a = A()
    a.func(1, 2)
    a.func(1, 2, 3, 4, a="a", b="b")
    a.func(1, 2, 3, 4, a="a", b="b", c="c", d="d")

# Generated at 2022-06-24 01:50:10.377670
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import requests
    from requests.exceptions import HTTPError

    @LoggedFunction(logger=None)
    def test_func(a, b, c="c", *, d, e="e"):
        requests.get("http://httpbin.org/status/500")
        return (a + b) * c

    try:
        test_func(1, 2, d=3, e="e")
    except HTTPError as e:
        assert e.response.status_code == 500

test_LoggedFunction___call__()

# Generated at 2022-06-24 01:50:19.575387
# Unit test for function build_requests_session
def test_build_requests_session():

    s = build_requests_session()
    assert s.hooks == {}
    assert isinstance(s.mounts["http://"][0].max_retries, Retry)

    s = build_requests_session(retry=False)
    assert s.hooks == {}
    assert "http://" not in s.mounts

    s = build_requests_session(raise_for_status=False)
    assert s.hooks == {}
    assert isinstance(s.mounts["http://"][0].max_retries, Retry)

    s = build_requests_session(raise_for_status=False, retry=False)
    assert s.hooks == {}
    assert "http://" not in s.mounts


# Generated at 2022-06-24 01:50:24.017833
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    test_logger = logging.getLogger()
    test_logger.setLevel(logging.DEBUG)
    log_func = LoggedFunction(test_logger)
    @log_func
    def test_func(x, y):
        return x + y

    test_result = test_func(1, 2)
    assert test_result == 3

# Generated at 2022-06-24 01:50:27.711485
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('abcd') == "'abcd'"
    assert format_arg(1234) == "1234"

# Generated at 2022-06-24 01:50:34.753760
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # When calling __call__ of the LoggedFunction class, the output of the wrapped
    # function should be shown
    import logging

    LOGGER = logging.getLogger(__name__)
    LOGGER.addHandler(logging.NullHandler())

    @LoggedFunction(logger=LOGGER)
    def add(a, b):
        return a + b

    add(3, 4)



# Generated at 2022-06-24 01:50:44.259042
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import unittest
    import logging

    class TestLoggedFunction(unittest.TestCase):
        def test_logging(self):
            log = logging.getLogger("test")
            with self.assertLogs(log, level="DEBUG") as cm:
                @LoggedFunction(log)
                def test(*args, **kwargs):
                    return (args, kwargs)
                test(1, "TWO", three=3)
            self.assertEqual(len(cm.output), 2)
            self.assertEqual(
                cm.output[0], "DEBUG:test:test(1, 'TWO', three=3)"
            )
            self.assertEqual(cm.output[1], "DEBUG:test:test -> ((1, 'TWO'), {'three': 3})")

    unitt

# Generated at 2022-06-24 01:50:49.016331
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    l = LoggedFunction(logging.getLogger())
    @l
    def foo(x: int, y: str, z: str = "baz", *args):
        return x + 2
    assert foo(2, "bar") == 4
    assert foo(2, "bar", "baz") == 4
    assert foo(2, "bar", "baz", "qux") == 4




# Generated at 2022-06-24 01:50:50.109369
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)

# Generated at 2022-06-24 01:50:51.968786
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("'") == "'\\''"
    assert format_arg(1) == '1'

# Generated at 2022-06-24 01:50:57.105785
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger(object):
        @staticmethod
        def debug(msg):
            pass
    mock_logger = MockLogger()
    @LoggedFunction(mock_logger)
    def foo(a, b, c=None):
        pass
    try:
        foo(1, 2)
    except Exception:
        pass

# Generated at 2022-06-24 01:51:06.452365
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger("test_LoggedFunction___call__")
    lf = LoggedFunction(logger)
    @lf
    def f(a, b):
        return a + b
    f(1, 2)
    if len(logger.handlers) == 0:
        h = logging.StreamHandler()
        h.setLevel(logging.DEBUG)
        h.setFormatter(
            logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        )
        logger.addHandler(h)
    logger.setLevel(logging.DEBUG)
    f(1, 2)

# Generated at 2022-06-24 01:51:07.776358
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    logger = logging.getLogger()

    # create an instance of LoggedFunction
    logged_function = LoggedFunction(logger)
    assert logged_function.logger is logger



# Generated at 2022-06-24 01:51:13.095120
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import logging.handlers
    import logging.config

    logging.config.fileConfig("logging.ini")
    # create logger
    logger = logging.getLogger("simpleExample")
    logger.debug("debug message")

    log = LoggedFunction(logger)
    @log
    def my_sum(a, b):
        return a + b
    my_sum(3, 4)

# Generated at 2022-06-24 01:51:23.176403
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    import unittest

    class LoggedFunctionTest(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("logged_function_test")
            self.logger.setLevel(logging.INFO)
            out_handler = logging.StreamHandler(sys.stdout)
            self.logger.addHandler(out_handler)

        def test_constructor(self):
            f = LoggedFunction(self.logger)
            self.assertEqual(f.logger, self.logger)

    unittest.main(exit=False, verbosity=2)

# Generated at 2022-06-24 01:51:34.349394
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # mock_logger = Mock(spec=logging.Logger)
    mock_logger = MagicMock(name='logger')
    mock_logger = Mock()

    def test_func(*args, **kwargs):
        if (len(args) >= 1) and (args[0] == "Don't work"):
            print(args[0])
            return None
        else:
            print(args[0])
            return args[0]

    @LoggedFunction(mock_logger)
    def test_func(*args, **kwargs):
        if (len(args) >= 1) and (args[0] == "Don't work"):
            print(args[0])
            return None
        else:
            print(args[0])
            return args[0]

    test_func("Work")

# Generated at 2022-06-24 01:51:40.673142
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("asd") == "'asd'"
    assert format_arg("   12   ") == "'   12   '"


# Generated at 2022-06-24 01:51:43.706091
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from flexmock import flexmock
    logger = flexmock()
    logger.should_receive("debug")
    LoggedFunction(logger)


# Generated at 2022-06-24 01:51:52.875083
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():

    logging.basicConfig(filename="test_LoggedFunction.log")
    logging.getLogger().setLevel(logging.DEBUG)

    TEST_TEXT = "This is a test."

    test1 = LoggedFunction(logging)

    @test1
    def test_func():
        """
        Test function for LoggedFunction.
        """
        return TEST_TEXT

    assert test_func() == TEST_TEXT

    test2 = LoggedFunction(logging)

    @test2
    def test_func(text):
        """
        Test function for LoggedFunction taking parameters.
        """
        return text

    assert test_func(TEST_TEXT) == TEST_TEXT



# Generated at 2022-06-24 01:51:58.619989
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('hello') == "'hello'"
    assert format_arg(1) == '1'
    assert format_arg(None) == 'None'


logger = logging.getLogger("my-logger")
logging.basicConfig(level=logging.DEBUG)


# Generated at 2022-06-24 01:52:08.635398
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import contextlib
    import sys

    @LoggedFunction(logging.getLogger())
    def foo(a, b=2, c=""):
        return a ** b + len(c)

    with contextlib.redirect_stderr(StringIO()) as out:
        sys.stderr = out
        foo(2, 3)
        foo(2, 3, c="test")
        assert (
            out.getvalue().strip()
            == """DEBUG:root:foo(2, 3)
DEBUG:root:foo -> 7
DEBUG:root:foo(2, 3, c='test')
DEBUG:root:foo -> 10"""
        )

# Generated at 2022-06-24 01:52:10.604782
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(retry=2)
    retry = s.adapters["http://"].max_retries
    assert retry.total == 2

# Generated at 2022-06-24 01:52:21.592601
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False)
    assert session.hooks is None
    assert (
        session.adapters["http://"].max_retries.total == Retry().total
    ) and (session.adapters["https://"].max_retries.total == Retry().total)

    session = build_requests_session(False, False)
    assert session.hooks is None
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.total == 0

    session = build_requests_session(False, 2)
    assert session.hooks is None
    assert session.adapters["http://"].max_retries.total == 2
    assert session.adapters["https://"].max_retries.total

# Generated at 2022-06-24 01:52:30.228639
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logged = LoggedFunction(logger)
    assert logged.logger == logger



# Generated at 2022-06-24 01:52:38.859110
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger()
    def func1(a, b=1, *args, **kwargs):
        pass

    def func2(a, b, *args, **kwargs):
        pass

    def func3(a, b, *args, **kwargs):
        pass

    class funcClass1:
        def __init__(self):
            self.a = 1
            self.b = 2
        def __repr__(self):
            return f'{self.__class__.__name__}({self.a}, {self.b})'
        def __str__(self):
            return f'{self.__class__.__name__}({self.a}, {self.b})'
    class funcClass2:
        def __init__(self):
            self.a