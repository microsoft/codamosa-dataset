

# Generated at 2022-06-24 01:42:40.302216
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test when the parameter is a function
    def foo():
        pass
    instance = LoggedFunction(foo)
    assert callable(instance)
    assert hasattr(instance, '__name__')

    # Test when the parameter is not a function
    instance = LoggedFunction(int)
    assert callable(instance)
    assert hasattr(instance, '__name__')

# Generated at 2022-06-24 01:42:47.924849
# Unit test for function build_requests_session
def test_build_requests_session():
    # Should return a session with configured hooks
    session = build_requests_session()
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    # Should return a session with configured retry
    session = build_requests_session(retry=Retry(total=0))
    assert session.adapters["http://"].max_retries.total == 0
    # Should raise exception when retry is not a bool, int or Retry
    with pytest.raises(ValueError):
        session = build_requests_session(retry={})

# Generated at 2022-06-24 01:42:51.047055
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg("foo 'bar'") == "'foo ''bar'''"
    assert format_arg("foo 'bar") == "'foo ''bar'"


# Generated at 2022-06-24 01:42:54.952754
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    @LoggedFunction(logger)
    def add(x, y):
        return x + y
    add(2, 3)


# Generated at 2022-06-24 01:43:00.508249
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("") == "''"
    assert format_arg("a") == "'a'"
    assert format_arg("a b") == "'a b'"
    assert format_arg("'") == "''"
    assert format_arg("a b") == "'a b'"
    assert format_arg(1) == "1"
    assert format_arg(1.23) == "1.23"



# Generated at 2022-06-24 01:43:06.828711
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.setLevel(logging.WARNING)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    @LoggedFunction(logger)
    def foo(a, b=None):
        return a + b

    foo(1, 2)
    foo(1, b=2)


# Generated at 2022-06-24 01:43:11.506003
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("a") == "'a'"
    assert format_arg("a ") == "'a '"



# Generated at 2022-06-24 01:43:18.117633
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import sys
    import logging
    import logging.handlers
    import io

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    stream_handler.setFormatter(formatter)
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)
    
    test_logged_function = LoggedFunction(logger)
    
    @test_logged_function
    def sum(a,b):
        return a + b
    
    sum(1, 2)
    sum("H", "e")
    sum("H", 2)
   

# Generated at 2022-06-24 01:43:29.535058
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import pytest
    logging.basicConfig()
    log = logging.getLogger("unit-test")
    # unit test a function
    def test_func(a, b=2):
        return a + b
    decorated_func = LoggedFunction(log)(test_func)
    # test if inited successfully
    assert(decorated_func != test_func)
    assert(decorated_func.__name__ == test_func.__name__)
    # test if basic usage
    assert(decorated_func(1) == 3)
    assert(decorated_func(1, b=3) == 4)
    # test if log
    with pytest.raises(AssertionError):
        decorated_func(1)

# Generated at 2022-06-24 01:43:40.437679
# Unit test for function build_requests_session
def test_build_requests_session():
    from os import getenv
    from unittest.mock import patch
    from requests.exceptions import HTTPError
    requests_session = build_requests_session(False)
    try:
        url = "https://httpbin.org/status/404"
        requests_session.get(url)
    except HTTPError as e:
        assert e.response.status_code == 404

    with patch.object(requests_session.adapters.HTTPAdapter, "build_response") as mock_build_response:
        try:
            url = "https://httpbin.org/status/500"
            requests_session.get(url)
        except HTTPError:
            pass
        assert mock_build_response.call_count == 3

    raise_for_status_session = build_requests_session(True)

# Generated at 2022-06-24 01:43:42.124227
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg('abc')=="'abc'"
    assert format_arg('')=="''"

# Generated at 2022-06-24 01:43:49.605486
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class Logger:
        def __init__(self):
            self.log = []
            self.debug = self.log.append

    @LoggedFunction(Logger())
    def func_to_decorate(value1, value2=None):
        return "returned"

    func_to_decorate("arg1", value2="arg2")
    assert Logger.log == ['func_to_decorate(\'arg1\', value2=\'arg2\')', 'func_to_decorate -> returned']

# Generated at 2022-06-24 01:43:57.249444
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)
    assert isinstance(build_requests_session(False), Session)
    assert isinstance(build_requests_session(retry=False), Session)
    assert isinstance(build_requests_session(retry=3), Session)
    assert isinstance(build_requests_session(retry=Retry()), Session)
    try:
        build_requests_session(retry=0)
    except ValueError:
        pass



# Generated at 2022-06-24 01:44:00.914537
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """Create an instance of LoggedFunction and check for expected attributes"""
    logger = logging.getLogger()
    logged_function = LoggedFunction(logger)
    assert logged_function._LoggedFunction__logger == logger



# Generated at 2022-06-24 01:44:12.049955
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("logged_function")
    logger.setLevel(logging.DEBUG)

    log_handler = logging.StreamHandler()
    log_handler.setLevel(logging.DEBUG)

    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    log_handler.setFormatter(formatter)

    logger.addHandler(log_handler)
    logger.info("test_logged_function logger INFO")

    test_obj = LoggedFunction(logger)

    @test_obj
    def aaa(a, b, c = 3):
        return a + b + c

    bbb = aaa(1, 2)

    print(bbb)

# Generated at 2022-06-24 01:44:16.093949
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    lf = LoggedFunction(logging.getLogger(__name__))

    @lf
    def some_func(a, b, *, c=None):
        return a * b * c

    assert some_func(1, 2, c=3) == 6

# Generated at 2022-06-24 01:44:19.340869
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('1') == "'1'"
    assert format_arg(1) == '1'
    assert format_arg(None) == 'None'
    assert format_arg(True) == 'True'
    assert format_arg(False) == 'False'


# Generated at 2022-06-24 01:44:29.031050
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(threadName)s - %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def say_hello(name, age=None):
        pass

    say_hello("World")
    say_hello("World", 18)


if __name__ == "__main__":
    test_LoggedFunction()

# Generated at 2022-06-24 01:44:40.496843
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger(object):
        def __init__(self):
            self._logs = []
        def debug(self, msg):
            self._logs.append(msg)
    
    def test_method():
        pass

    logger = FakeLogger()
    expected_log = 'test_method()'
    lf = LoggedFunction(logger)
    lf(test_method)()
    assert logger._logs[0] == expected_log
    
    expected_log = 'test_method(1, 2, 3)'
    lf(test_method)(1, 2, 3)
    assert logger._logs[1] == expected_log
    
    expected_log = "test_method(arg1='value1', arg2='value2', arg3='value3')"

# Generated at 2022-06-24 01:44:48.436608
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.info = []

        def debug(self, msg):
            self.info.append(msg)

    t = TestLogger()
    f = LoggedFunction(t)

    @f
    def test(a, b, c=3):
        return a + b + c

    result = test(1, 2)
    assert result == 6
    assert t.info == [
        "test(1, 2, c=3)",
        "test -> 6",
    ]



# Generated at 2022-06-24 01:44:55.522824
# Unit test for function build_requests_session
def test_build_requests_session():
    url = "http://httpbin.org/range/15"
    # Test raise_for_status=False and retry=False
    session = build_requests_session(
        raise_for_status=False, retry=False
    )
    # This should not raise an exception
    session.get(url)
    # Test raise_for_status=True and retry=True
    session = build_requests_session(
        raise_for_status=True, retry=True
    )
    # This should not raise an exception
    session.get(url)
    # Test raise_for_status=True and retry=2
    session = build_requests_session(
        raise_for_status=True, retry=2
    )
    # This should not raise an exception
    session.get(url)


# Generated at 2022-06-24 01:44:59.995501
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger('test')
    dec = LoggedFunction(logger)
    @dec
    def foo(a, b, c='x'):
        print(a, b, c)
        return 5

    foo('a', 'b')

if __name__ == "__main__":
    import sys
    sys.exit(test_LoggedFunction())

# Generated at 2022-06-24 01:45:07.680778
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

# Generated at 2022-06-24 01:45:15.270834
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create fake logger and function
    class FakeLogger:

        def __init__(self):
            self.logged = []

        def debug(self, msg):
            self.logged.append(msg)

    def fake_func(a, b, c=None):
        return a + b + (c or 0)

    # Wrap function in LoggedFunction and call it
    logger = FakeLogger()
    logged_func = LoggedFunction(logger)(fake_func)
    logged_func(1, 2, c=3)

    # Verify logger debug output
    assert len(logger.logged) == 2
    assert logger.logged[0] == "fake_func(1, 2, c=3)"
    assert logger.logged[1] == "fake_func -> 6"

# Generated at 2022-06-24 01:45:24.637318
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test for method __call__ of class LoggedFunction
    """
    from unittest.mock import Mock

    class Test:
        """
        Test class
        """

        @LoggedFunction(Mock())
        def method(self, *args, **kwargs):
            """
            Test method
            :param args: arguments
            :param kwargs: key arguments
            :return: method result
            """
            return args, kwargs

    test = Test()
    test.method("a", "b", "c", a=1, b=2, c=3)



# Generated at 2022-06-24 01:45:33.183875
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch, call

    # Patch the logging class
    with patch("psylogger.log.Logger") as mock_logger:
        # Ensure that the logger is initialized
        ret_logger = mock_logger()
        # We're going to be testing with a mock logger object
        mock_logger.return_value = ret_logger

        # This is the function that we're going to be wrapping
        def test_function(a, b="test"):
            return a

        # Ensure that the logger hasn't recorded any debug calls yet
        ret_logger.debug.assert_not_called()

        # Create a decorator with this logger
        decorator = LoggedFunction(ret_logger)
        # Run the decorator
        decorated_function = decorator(test_function)
        # Test the

# Generated at 2022-06-24 01:45:43.836575
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    #from unittest import TestCase
    from unittest.mock import MagicMock

    class TestLoggedFunction___call__(unittest.TestCase):

        def setUp(self):
            self.mock_logger = MagicMock()

        def test_logged_func(self):

            def test_func(*args, **kwargs):
                return '''Test Success!'''

            test_logged_func = LoggedFunction(logging.getLogger())(test_func)
            test_logged_func('hello', a=1, b=2)
            test_logged_func.__name__ == 'test_func'

    unittest.main()

# Generated at 2022-06-24 01:45:52.541736
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from test.framework.base_unit_test_case import BaseUnitTestCase
    from logging import getLogger
    from datetime import datetime

    class LoggedFunctionTestCase(BaseUnitTestCase):
        def setUp(self):
            self.logger = getLogger()
            self.logger.debug = self.logger_debug_mock
            self.logged_func = LoggedFunction(self.logger)

        def logger_debug_mock(self, message):
            if not hasattr(self, "logged_results"):
                self.logged_results = []
            self.logged_results.append(message)

        def test(self):
            # define test function
            def func(a, b=1, c="xyz"):
                return datetime.now()

            # register the test function

# Generated at 2022-06-24 01:45:54.677135
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("testing") == "'testing'"
    assert format_arg(" testing ") == "' testing '"

# Generated at 2022-06-24 01:46:05.310836
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch

    mock_logging = Mock()

    def func(a=1, b=2, c=3):
        return a + b + c

    logged_func = LoggedFunction(mock_logging)(func)

    # Test for basic case
    with patch("python_utility.logger.LoggedFunction"):
        logged_func()
        mock_logging.debug.assert_called_with("func()")

    # Test for case having many arguments
    mock_logging.reset_mock()
    with patch("python_utility.logger.LoggedFunction"):
        logged_func(1, b=2, c=3)

# Generated at 2022-06-24 01:46:15.981313
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def func(x, y):
        return x + y

    logger = logging.getLogger()
    mock_logger = Mock()
    logger.debug = mock_logger

    logged_func = LoggedFunction(logger)(func)
    logged_func(2, 3)

    mock_logger.assert_called_with("func(2, 3)")
    mock_logger.reset_mock()

    logged_func = LoggedFunction(logger)(func)
    logged_func(a = 2, b = 3)
    mock_logger.assert_called_with("func(a=2, b=3)")
    mock_logger.reset_mock()


# Generated at 2022-06-24 01:46:18.848581
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('a') == "'a'"
    assert format_arg(1) == "1"
    assert format_arg(['a', 1]) == "['a', 1]"



# Generated at 2022-06-24 01:46:27.096969
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["http://"]
    assert session.adapters["https://"]

    session = build_requests_session(retry=False)
    assert session.adapters["http://"] is None
    assert session.adapters["https://"] is None

    session = build_requests_session(retry=Retry(connect=100, status=100, backoff_factor=100))
    assert session.adapters["http://"].max_retries.connect == 100
    assert session.adapters["http://"].max_retries.status_forcelist == [100]
    assert session.adapters["http://"].max_retries.backoff_factor == 100
    assert session.adapters["https://"].max_retries.connect == 100

# Generated at 2022-06-24 01:46:29.404307
# Unit test for function build_requests_session
def test_build_requests_session():
    # Make sure the function raise error if the retry is not a bool or an int
    assert_raises(ValueError, build_requests_session, retry = ('1', '2'))


# Generated at 2022-06-24 01:46:34.278886
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg(" 123 ") == "' 123 '"



# Generated at 2022-06-24 01:46:46.155859
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session._hooks['response'] == [functools.partial(lambda r, *args, **kwargs: r.raise_for_status())]
    assert session.adapters['http://'].max_retries._max_retries == Retry()._max_retries
    assert session.adapters['https://'].max_retries._max_retries == Retry()._max_retries

    session = build_requests_session(raise_for_status=False)
    assert session._hooks == {}

    session = build_requests_session(retry=False)
    assert session.adapters['http://'].max_retries == None
    assert session.adapters['https://'].max_retries == None


# Generated at 2022-06-24 01:46:55.654075
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # pylint: disable=unused-variable
    class FakeLogger:
        def __init__(self):
            self.messages = []

        def debug(self, msg):
            self.messages.append(msg)

        def get_messages(self):
            return self.messages

    logger = FakeLogger()

    logged_function = LoggedFunction(logger)

    @logged_function
    def test_method(a, b, c=None):
        print(a+b)

    test_method(1, 1)
    test_method(1, 1, c=2)

# Generated at 2022-06-24 01:47:06.081206
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.adapters import HTTPAdapter

    session = build_requests_session()
    assert HTTPAdapter in [type(a) for a in session.adapters.values()]
    assert "response" in session.hooks

    with pytest.raises(TypeError) as excinfo:
        session = build_requests_session(retry=0.5)
    assert "retry should be a bool, int or Retry instance" in str(excinfo.value)

    # try to build a session with custom retry object
    session = build_requests_session(retry=Retry(total=3, raise_on_redirect=False))
    assert HTTPAdapter in [type(a) for a in session.adapters.values()]
    assert "response" in session.hooks

# Generated at 2022-06-24 01:47:13.570626
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    logger.addHandler(console)

    @LoggedFunction(logger)
    def foo(x, y, z=1):
        print("inside foo")
        return x * y * z

    foo(2, 3)
    foo(2, 3, 4)
    foo(3, y=3, z=4)

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:47:20.169253
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()

    # Test constructor
    logged_function = LoggedFunction(logger)

    # Test __call__ method
    @logged_function
    def test_function(data1, data2, key1=None, key2=None, key3=None):
        return data1 + data2

    assert test_function(1, 2, key1=4) == 3



# Generated at 2022-06-24 01:47:27.099901
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(1.0e-5) == "1.0e-05"
    assert format_arg("i'm a string") == "'i'm a string'"
    assert format_arg("") == "''"
    assert format_arg(" ' ") == "' '"
    assert format_arg("a'b") == "'a'b'"
    assert format_arg("a''b") == "'a''b'"
if __name__ == '__main__':
    test_format_arg()

# Generated at 2022-06-24 01:47:30.766449
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=True)
    assert(isinstance(session, Session))
    session = build_requests_session(retry=Retry(1))
    assert(isinstance(session, Session))
    session = build_requests_session(retry=False)
    assert(isinstance(session, Session))
    try:
        session = build_requests_session(retry="10")
        assert(False)
    except ValueError:
        pass

# Generated at 2022-06-24 01:47:39.375578
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func_name = "test"
    args = [1, "a", True]
    kwargs = {"x": 2, "z": "b", "y": False}

    class Logger:
        _records = []

        @staticmethod
        def debug(*msg):
            Logger._records.append(msg)

        def clear(self):
            Logger._records.clear()

    logger = Logger()

    def func(*args, **kwargs):
        pass

    lf = LoggedFunction(logger)
    f = lf(func)
    f(*args, **kwargs)
    assert all(
        [expected in " ".join(record) for expected, record in zip(args, logger._records)]
    )
    for (k, v) in kwargs.items():
        assert all

# Generated at 2022-06-24 01:47:45.652150
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["https://"].max_retries.total == 10
    session = build_requests_session(False)
    assert session.hooks == {}
    assert session.adapters["https://"].max_retries.total == 10
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["https://"].max_retries.total == 10
    session = build_requests_session(retry=False)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert "https://" not in session.adapters
    session = build_requests_session

# Generated at 2022-06-24 01:47:47.528621
# Unit test for function format_arg
def test_format_arg():
    assert "1" == format_arg(1)
    assert "'test'" == format_arg("test")


# Generated at 2022-06-24 01:47:55.021199
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    class TestObject:
        def __init__(self):
            self._logger = logging.getLogger(self.__class__.__name__)


# Generated at 2022-06-24 01:48:00.162589
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    from unittest.mock import MagicMock, call

    # Set up mock logger
    logger = MagicMock()

    # Define function
    @LoggedFunction(logger)
    def hello(name):
        return f"Hello {name}!"

    # Unit test no arguments given
    hello()

    # Check method was called once
    assert hello.__call__.call_count == 1

    # Check logger called once
    logger.debug.assert_called_once_with("hello()")

    # Unit test one argument given
    hello(name="World")

    # Check method was called twice
    assert hello.__call__.call_count == 2

    # Check logger was called with the correct values

# Generated at 2022-06-24 01:48:00.703115
# Unit test for function format_arg
def test_format_arg():
    # TODO
    pass



# Generated at 2022-06-24 01:48:07.950736
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    @LoggedFunction(logger)
    def func(a, b, c, d=1, e=2):
        return a + b + c + d + e
    assert func(1, 2, 3, 4, e=5) == 15


# Generated at 2022-06-24 01:48:17.087732
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError
    from unittest.mock import Mock, call

    session = build_requests_session(raise_for_status=False)
    session.send = Mock()
    response = Mock(status_code=200)
    session.send.return_value = response
    assert session.send.call_count == 0
    session.get("http://www.example.com")
    session.send.assert_called_once_with(
        Mock(full_url="http://www.example.com", method="GET")
    )

    response.raise_for_status = Mock(side_effect=HTTPError)
    try:
        build_requests_session(raise_for_status=True).get("http://www.example.com")
    except HTTPError:
        pass

# Generated at 2022-06-24 01:48:26.503141
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class FakeLogger:
        def __init__(self):
            self.logs = []
        def debug(self, msg):
            self.logs.append(msg)

    logger = FakeLogger()

    def test_fn(a, b, *args, **kwargs):
        pass

    logged_fn = LoggedFunction(logger)(test_fn)

    logged_fn(1, 2)
    assert logger.logs[-1] == "test_fn(1, 2)"

    logged_fn(1, 2, 3, "4", key_1="value 1", key_2=2)
    assert logger.logs[-1] == "test_fn(1, 2, 3, '4', key_1='value 1', key_2=2)"

# Generated at 2022-06-24 01:48:29.061338
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    function_logger = LoggedFunction(logger)
    function_logger(print)


# Generated at 2022-06-24 01:48:34.003918
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class MockedLogger:
        def debug(self, message):
            pass

    logger = MockedLogger()
    @LoggedFunction(logger)
    def tested_func(arg1, arg2=2):
        pass
    assert isinstance(tested_func, functools.partial)
    assert tested_func.__name__ == "tested_func"
    assert tested_func.__dict__ == {}


# Generated at 2022-06-24 01:48:38.454652
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    def test_func(a, b, c=9, d=10):
        return "test_result"
    logged_func = LoggedFunction(logger)(test_func)
    result = logged_func(2, 3, d=11)
    assert result == "test_result"
    assert logger.debug.call_args_list == [
        call("test_func(2, 3, c=9, d=11)"),
        call("test_func -> test_result")
    ]

# Generated at 2022-06-24 01:48:44.209268
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    lf = LoggedFunction(logger)

    @lf # LoggedFunction.__call__(f) returns logged_func
    def f(n):
        return n + 1

    assert f(1) == 2


# Generated at 2022-06-24 01:48:51.766572
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest
    import unittest.mock

    log_out = io.StringIO()
    test_logger = logging.getLogger("test_func")
    test_logger.setLevel(logging.DEBUG)
    console_handler = logging.StreamHandler(log_out)
    console_handler.setFormatter(logging.Formatter("%(message)s"))
    test_logger.addHandler(console_handler)

    class mock_func:
        def __init__(self, *args, **kwargs):
            self.name = "mock_func"
            self.args = args
            self.kwargs = kwargs

        def __call__(self, *args, **kwargs):
            return self.name


# Generated at 2022-06-24 01:48:58.292873
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg("test") == "'test'"
    assert format_arg("  ") == "''"
    assert format_arg("  test  ") == "'test'"

# Generated at 2022-06-24 01:49:03.561365
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.Logger("my_logger")
    my_decorator = LoggedFunction(logger)
    @my_decorator
    def function(a, b, c="test"):
        return a + b + c
    function(1, 2)



# Generated at 2022-06-24 01:49:13.401434
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import mock
    import StringIO
    logger = mock.MagicMock(logging.Logger)
    message = "a test log message"
    decorator = LoggedFunction(logger)
    @decorator
    def test(message):
        print(message)

    logger.debug.side_effect = lambda arg: print(arg)
    test(message)
    assert logger.debug.call_args[0][0] == "test('a test log message')"
    assert logger.debug.call_count == 2
    out, err = capsys.readouterr()
    assert out == "a test log message\ntest -> None\n"



# Generated at 2022-06-24 01:49:24.999319
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest


    def test_func(x, y):
        return x + y


    class LoggedFunctionTest(unittest.TestCase):
        def test_call(self):
            logstream = io.StringIO()
            handler = logging.StreamHandler(logstream)
            logger = logging.getLogger("debug")
            logger.addHandler(handler)
            logger.setLevel(logging.DEBUG)
            logged_func = LoggedFunction(logger)(test_func)
            x = 1
            y = 2
            result = logged_func(x, y)
            self.assertEqual(result, x + y)

# Generated at 2022-06-24 01:49:29.232827
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg('aa') == "'aa'"
    assert format_arg('aa bb') == "'aa bb'"
    assert format_arg('aa\'bb') == "'aa'bb'"

# Generated at 2022-06-24 01:49:38.748862
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test")
    logger.setLevel("DEBUG")

    def test_func(x,y=5):
        return x-y

    # Test if function is properly wrapped
    logged_function = LoggedFunction(logger)
    logged_function(test_func)

    # Test if returned function properly logs
    logged_func = logged_function(test_func)
    logged_func(5)

    # Test if returned function properly logs
    logged_func(x=10)

    # Test if returned function properly logs
    logged_func(5, y=2)

    # Test if returned function properly logs
    logged_func(x=10, y=2)


# Generated at 2022-06-24 01:49:45.019482
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.addHandler(logging.NullHandler())
    decorator = LoggedFunction(logger)
    @decorator
    def add(x, y):
        return x + y
    assert add(1, 2) == 3


# Generated at 2022-06-24 01:49:46.968085
# Unit test for function format_arg
def test_format_arg():
    assert repr(format_arg("Python")) == "'Python'"
    assert repr(format_arg(None)) == 'None'



# Generated at 2022-06-24 01:49:50.376784
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('a') == "'a'"
    assert format_arg(' a b ') == "' a b '"

# Generated at 2022-06-24 01:49:57.597873
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from .logging import configure_logging
    from .logging import configure_test_logging

    logger = logging.getLogger("test.logger")

    # Verify calling the class constructor works
    with TemporaryDirectory() as tmp_dir:
        log_file = Path(tmp_dir) / "test_logged_function"
        configure_logging(path=log_file, progname="test")
        LoggedFunction(logger)

    # Verify calling the decorated function works
    # pylint: disable=unused-variable
    configure_test_logging()
    @LoggedFunction(logger)
    def f(a, b=3):
        return a + b

    f(2)
    f(a=2)
    f

# Generated at 2022-06-24 01:50:06.950353
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('A') == "'A'"
    assert format_arg('  A  ') == "'A'"
    assert format_arg(None) == "None"
    assert format_arg(1.0) == "1.0"
    assert format_arg(1) == "1"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(False) == "False"
    assert format_arg(['A', 1, None, True]) == "['A', 1, None, True]"
    assert format_arg({'A': 2, True: 1}) == "{'A': 2, True: 1}"

# Generated at 2022-06-24 01:50:16.759631
# Unit test for function build_requests_session
def test_build_requests_session():

    @build_requests_session(raise_for_status=False, retry=False)
    def test_func(url, session):
        # Test requests without retry and without raise for status
        session.get(url)

    @build_requests_session(raise_for_status=True, retry=True)
    def test_func(url, session):
        # Test requests with raise for status and retry
        session.get(url)

    @build_requests_session(raise_for_status=False, retry=True)
    def test_func(url, session):
        # Test requests with retry and without raise for status
        session.get(url)


# Generated at 2022-06-24 01:50:24.406512
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch
    from unittest import TestCase

    # Subclass for testing only
    class TestLoggedFunction(LoggedFunction):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # Patch logger
    with patch("logging.Logger.debug") as mock_logger_debug:
        # Create decorator
        decorated_function = TestLoggedFunction("foo.bar")(lambda x, y: x + y)

        # Call function, which should use the logger
        a = "b"
        b = "c"
        result = decorated_function(a, y=b)
        assert result == "bc"

        # Verify that the function name and arguments were logged
        assert mock_logger_debug.call_args_

# Generated at 2022-06-24 01:50:30.463261
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def x(a, b):
        return a + b


    x(1, 2)

# Generated at 2022-06-24 01:50:41.024536
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        debug = False

        def debug(self, msg: str):
            self.msg = msg

    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_logger = TestLogger()

    logged_func = LoggedFunction(test_logger)(test_func)

    logged_func(1, 2)
    assert (
        test_logger.msg == f"test_func(1, 2, c={format_arg(3)}, d={format_arg(4)})"
    )

    logged_func(1)
    assert (
        test_logger.msg == f"test_func(1, c={format_arg(3)}, d={format_arg(4)})"
    )


# Generated at 2022-06-24 01:50:44.295565
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg("1") == "'1'"
    assert format_arg(" 1") == "' 1'"
    assert format_arg(" 1 ") == "' 1 '"

# Generated at 2022-06-24 01:50:55.854045
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    import logging

    def test_function():
        pass

    logger = logging.getLogger()
    logged_function = LoggedFunction(logger)
    mock = unittest.mock.Mock()
    logger.debug = mock
    result = logged_function(test_function)
    result()
    mock.assert_called_once_with("test_function()")
    mock.reset_mock()
    result("a")
    mock.assert_called_once_with("test_function('a')")
    mock.reset_mock()
    result("a", b="b")
    mock.assert_called_once_with("test_function('a', b='b')")
    mock.reset_mock()
    result(1, 2)
    mock.assert_called_

# Generated at 2022-06-24 01:51:04.806259
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    @LoggedFunction(logger)
    def testfunction(a, b, *args, **kwargs):
        print('testfunction print')
        return 1
    print('testfunction', testfunction(2, 3, 4, 5))
    # testfunction(2, 3, 4, 5)
    # print(type(logger))
    # logger.debug(logger)
    
    

# Generated at 2022-06-24 01:51:15.253189
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    lf = LoggedFunction()
    lf.logger = mocked_logger = Mock()
    @lf
    def foo(x, y):
        None

    foo(1, 2)
    mocked_logger.debug.assert_called_with('foo(1, 2)')
    foo('x', 'y')
    mocked_logger.debug.assert_called_with("foo('x', 'y')")
    foo(1, 'y')
    mocked_logger.debug.assert_called_with("foo(1, 'y')")

    @lf
    def bar(x, y, z=3):
        return x + y + z

    bar(1, 2)
    mocked_logger.debug.assert_called_with('bar(1, 2, z=3)')

# Generated at 2022-06-24 01:51:19.899625
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logging.basicConfig(level=logging.INFO)
    test_logger = logging.getLogger('test_logger')
    test_logger.setLevel(logging.INFO)

    def test_func(a, b, c=5):
        return c

    logged_func = LoggedFunction(test_logger)(test_func)
    logged_func(1, 2)
    logged_func(1, 2, c=3)

# Generated at 2022-06-24 01:51:21.301734
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('"') == "\'" + '"\\\'"' + "\'"


# Generated at 2022-06-24 01:51:29.202482
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from requests import Session
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    x = LoggedFunction(print)

    @x
    def aaa(x, y, z=3):
        print(x, y, z)
        return "aaaaaaa"

    aaa(1, 2)
    # 1 2 3
    # <function aaa at 0x7f3077d6ee18> -> aaaaaaa

# Generated at 2022-06-24 01:51:32.218643
# Unit test for function format_arg
def test_format_arg():
    assert "''" == format_arg("")
    assert "'a'" == format_arg("a")

# Generated at 2022-06-24 01:51:41.716065
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MagicMock()
    decorator = LoggedFunction(logger)
    def my_function(a, b ,c =1, d =1.0, e="hi"):
        return "hi"
    decorated = decorator(my_function)
    decorated(1, 2, e ="hello")
    logger.debug.assert_called_once_with("my_function(1, 2, c=1, d=1.0, e='hello')")
    logger.debug.reset_mock()
    decorated(1, 2)
    logger.debug.assert_called_once_with("my_function(1, 2, c=1, d=1.0)")



# Generated at 2022-06-24 01:51:49.866209
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg("") == "''"
    assert format_arg("    ") == "''"
    assert format_arg("hi") == "'hi'"
    assert format_arg("hi there") == "'hi there'"
    assert format_arg(" hi there ") == "' hi there '"

# Generated at 2022-06-24 01:51:51.475552
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    lf = LoggedFunction(logging.getLogger())
    assert lf is not None


# Generated at 2022-06-24 01:51:57.702412
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    import logging
    import re

    logger = Mock(spec=logging.Logger)
    logged_function = LoggedFunction(logger)

    @logged_function
    def my_function1(arg1, arg2="default value", *args, **kwargs):
        pass

    def my_function2(arg1, arg2="default value", *args, **kwargs):
        pass

    my_function1("arg1 value", "arg2 value", "arg3 value", by_name="value")
    logger.debug.assert_called_once()
    assert re.match(
        r"my_function1\((arg1 value, arg2 value, arg3 value, by_name=value)\)\Z",
        logger.debug.call_args[0][0],
    )

# Generated at 2022-06-24 01:52:09.037074
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from logging import getLogger, DEBUG
    from logging import StreamHandler
    from pydantic.dataclasses import dataclass
    from unittest import TestCase

    @dataclass
    class Student:
        id: int
        name: str
        birthdate: str

    @LoggedFunction(getLogger(__name__))
    def create_student(id: int, name: str, birthdate: str) -> Student:
        return Student(id=id, name=name, birthdate=birthdate)

    # Get a logger
    logger = getLogger(__name__)
    handler = StreamHandler(StringIO())
    logger.setLevel(DEBUG)
    logger.addHandler(handler)

    # Create student

# Generated at 2022-06-24 01:52:21.464525
# Unit test for function build_requests_session
def test_build_requests_session():
    from nose.tools import assert_is_instance
    from nose.tools import assert_equal
    from requests.packages.urllib3.util.retry import Retry

    retry = build_requests_session(retry=False).adapters["http://"].max_retries
    assert_is_instance(retry, Retry)
    assert_equal(retry.total, 0)

    retry = build_requests_session(retry=True).adapters["http://"].max_retries
    assert_is_instance(retry, Retry)
    assert_equal(retry.total, 5)

    retry = build_requests_session(retry=4).adapters["http://"].max_retries
    assert_is_instance(retry, Retry)

# Generated at 2022-06-24 01:52:26.644623
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(raise_for_status=False, retry=False)
    print(type(s))
    print(s.hooks)
    s = build_requests_session(raise_for_status=False, retry=10)
    print(s.adapters)
    print(s.__dict__)


# Generated at 2022-06-24 01:52:31.411372
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("1") == "'1'"
    assert format_arg(1) == "1"
    assert format_arg(1.234) == "1.234"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:52:40.472121
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest import TestCase

    class TestLogger(logging.Logger):
        def __init__(self):
            self.debug_msg = ""
            self.info_msg = ""

        def debug(self, msg, *args, **kwargs):
            self.debug_msg = msg

        def info(self, msg, *args, **kwargs):
            self.info_msg = msg

    def test_func(a, b, c=3):
        return a + b + c

    class TestLoggedFunction(TestCase):
        def test_logged_function(self):
            test_logger = TestLogger()
            logged_func = LoggedFunction(test_logger)
            result = logged_func(test_func)(1, 2)