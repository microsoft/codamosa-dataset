

# Generated at 2022-06-24 01:42:41.294753
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    l1 = LoggedFunction(logger)
    assert l1.logger == logger


# Generated at 2022-06-24 01:42:46.925804
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction(): 
    from logging.config import fileConfig
    from logging import getLogger

    fileConfig("logging_config.ini")
    logger = getLogger("test")

    @LoggedFunction(logger)
    def test_method(name, id):
        return (name + " has id " + str(id))

    result = test_method("jack", 1)
    print(result)


# Generated at 2022-06-24 01:42:49.285198
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None

# Generated at 2022-06-24 01:42:57.890237
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    def test_func(x, y):
        return x + y

    logger = Mock()

    logged_func = LoggedFunction(logger)

    logged_func(test_func)(1, 2)

    logger.debug.assert_called_once_with("test_func(1, 2)")

    logger.reset_mock()

    logged_func(test_func)(1, y=2)

    logger.debug.assert_called_once_with("test_func(1, y=2)")

    logger.reset_mock()

    logged_func(test_func)(x=2, y=4)

    logger.debug.assert_called_once_with("test_func(x=2, y=4)")

# Generated at 2022-06-24 01:42:59.427401
# Unit test for function format_arg
def test_format_arg():
    value = "abc"
    assert format_arg(value) == f"'{value}'"



# Generated at 2022-06-24 01:43:01.659196
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    url = "https://google.com"
    response = session.get(url)
    assert response.url == url

# Generated at 2022-06-24 01:43:14.812257
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase, main

    class TestLoggedFunction(TestCase):
        def setUp(self):
            def function_to_test(*args, **kwargs):
                """
                Function to test.
                """
                return (args, kwargs)

            self.function_to_test = function_to_test

        def test_call(self):
            """
            Test that LoggedFunction works.
            """
            # GIVEN: A function with no parameters
            logger = Mock()

            # WHEN: the function is invoked
            result = LoggedFunction(logger)(self.function_to_test)()

            # THEN: it should return a tuple containing an empty list and an empty dict
            # and the logger should be called
            self.assertEqual(result, ((), {}))
            logger.debug.assert_

# Generated at 2022-06-24 01:43:16.940503
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("'a'") == "'\'a\''"
    assert format_arg("a") == "'a'"



# Generated at 2022-06-24 01:43:24.956687
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(retry=False)
    assert len(s.adapters) == 1
    s = build_requests_session()
    assert len(s.adapters) == 2  # 2 schemes: 'http://' and 'https://'
    assert "response" in s.hooks.keys()


# Generated at 2022-06-24 01:43:26.744759
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    Unit test for constructor of class LoggedFunction
    """
    logger = logging.getLogger()
    LoggedFunction(logger)

# Generated at 2022-06-24 01:43:30.760846
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def f(x, y=3):
        return x + y

    logger = logging.getLogger("foo")
    logger.setLevel(logging.DEBUG)
    logging.basicConfig()
    f_logged = LoggedFunction(logger)(f)
    assert f(1, 2) == f_logged(1, 2)

# Generated at 2022-06-24 01:43:39.923318
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s, Session)
    assert "response" in s.hooks and len(s.hooks["response"]) == 1
    assert "http://" in s.adapters
    assert "https://" in s.adapters
    assert (
        s.adapters["http://"].max_retries
        and s.adapters["https://"].max_retries
    )
    Retry = s.adapters["http://"].max_retries.increment

    s = build_requests_session(False)
    assert isinstance(s, Session)
    assert "response" not in s.hooks
    assert "http://" in s.adapters
    assert "https://" in s.adapters

# Generated at 2022-06-24 01:43:43.796001
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("") == "' '"
    assert format_arg("Hello") == "'Hello'"
    assert format_arg(1) == "1"
    assert format_arg(1.1) == "1.1"



# Generated at 2022-06-24 01:43:52.069145
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)
    assert isinstance(build_requests_session(raise_for_status=False), Session)
    assert isinstance(build_requests_session(retry=False), Session)
    assert isinstance(build_requests_session(retry=2), Session)
    assert isinstance(build_requests_session(retry=Retry()), Session)
    try:
        build_requests_session(retry=Retry(1, total=1, backoff_factor=0))
        raise Exception()
    except:
        pass
    try:
        build_requests_session(retry=object())
        raise Exception()
    except:
        pass

# Generated at 2022-06-24 01:44:03.744359
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert len(session.adapters.keys()) == 2
    assert len(session.hooks["response"]) == 1
    session = build_requests_session(raise_for_status=False)
    assert len(session.hooks["response"]) == 0
    session = build_requests_session(retry=False)
    assert len(session.adapters.keys()) == 0
    session = build_requests_session(retry=2)
    assert len(session.adapters.keys()) == 2
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 2

# Generated at 2022-06-24 01:44:13.271796
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import StringIO

    log_buf = StringIO.StringIO()

    logger = logging.getLogger("testing")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = logging.StreamHandler(log_buf)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    log_test = LoggedFunction(logger)

    def test_func(arg1, kwarg1=0):
        return arg1 + kwarg1

    log_test(test_func)(1, 2)
    log_test(test_func)('a str', kwarg1=2)


# Generated at 2022-06-24 01:44:20.827388
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import Mock
    from unittest import TestCase
    from unittest.mock import MagicMock

    def test_function(*args, **kwargs):
        return 3.14

    class TestName(TestCase):
        def test(self):
            logger = Mock()
            loggedfunction_instance = LoggedFunction(logger)
            logged_function = loggedfunction_instance(test_function)
            logged_function(1, 2, 3, 4, 5)
            # It's hard to test logger, because no matter how you test, it always returns the same value
            self.assertTrue(logger.debug.called)


if __name__ == "__main__":
    lf = LoggedFunction(None)
    print(lf.__call__(test_LoggedFunction))

# Generated at 2022-06-24 01:44:27.882548
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == str(None)
    assert format_arg(True) == str(True)
    assert format_arg(1) == str(1)
    assert format_arg(1.0) == str(1.0)
    assert format_arg("s1") == "'s1'"
    assert format_arg(" s1 ") == "' s1 '"


# Generated at 2022-06-24 01:44:36.894318
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test basic case
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters.keys() == {"http://", "https://"}

    # Test raise_for_status case
    session = build_requests_session(raise_for_status=True)
    assert len(session.hooks["response"]) == 1

    # Test retry case
    retry = Retry()
    session = build_requests_session(retry=retry)
    assert session.adapters.keys() == {"http://", "https://"}


# Generated at 2022-06-24 01:44:46.545070
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def debug(self, s):
            print(s, end="")

    def f(a, b, c=0, *args, **kwargs):
        return a + b + c + sum(args) + sum(kwargs.values())

    decorated_f = LoggedFunction(Logger()).__call__(f)

    decorated_f(1, 2, 3, 4, 5, d=6, e=7)
    print()
    decorated_f(1, 2, 3, 4, 5, d=6, e=7)
    print()
    decorated_f(1, 2, 3, 4)
    print()


# Generated at 2022-06-24 01:44:54.665670
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Set up logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()

    # Define a test function.
    @LoggedFunction(logger)
    def testfunction(a, b=None):
        return (a, b)

    # Call the test function.
    assert ((1, 2) == testfunction(1, 2))
    assert (("hello", None) == testfunction("hello"))

# Generated at 2022-06-24 01:45:01.691868
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import requests_mock
    session = build_requests_session()
    url = "http://fake.url/"
    with requests_mock.mock(raise_exceptions=False) as m:
        m.get(url, text="fake result")
        r = session.get(url)
    assert r.raise_for_status.__self__ == r
    assert r.text == "fake result"

# Generated at 2022-06-24 01:45:05.488527
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=False, retry=Retry(0))
    session.post("http://httpbin.org/anything", data={"data": "hello"})

# Generated at 2022-06-24 01:45:07.308626
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(logger="logger")


# Generated at 2022-06-24 01:45:14.095589
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    logger.debug("Test for logged function")
    @LoggedFunction(logger)
    def test(a, b):
        return a + b
    test(1, 2)
    test(1, b=2)



# Generated at 2022-06-24 01:45:20.853138
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(10) == "10"
    assert format_arg("10") == "'10'"
    assert format_arg(1.2) == "1.2"
    assert format_arg("test str") == "'test str'"
    assert format_arg(" test str ") == "' test str '"
    assert format_arg(" 'quoted' ") == "' 'quoted' '"

# Generated at 2022-06-24 01:45:30.277230
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session()

    # test if retry is True
    assert sess.adapters["http://"].max_retries.total == 3
    assert sess.adapters["https://"].max_retries.total == 3

    # test if retry is int
    sess_retry_once = build_requests_session(retry=1)
    assert sess_retry_once.adapters["http://"].max_retries.total == 1
    assert sess_retry_once.adapters["https://"].max_retries.total == 1

    # test if retry is Retry
    retry = Retry(connect=1, read=2, redirect=3, status=4)

# Generated at 2022-06-24 01:45:35.847112
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging

    class LoggedFunctionTest(unittest.TestCase):
        def setUp(self):
            self.lf = LoggedFunction(logging.getLogger("test"))

        def test_logged_func_with_return(self):
            @self.lf
            def f(a, b):
                return a + b
            self.assertEqual(f(1, b=1), 2)

        def test_logged_func_without_return(self):
            @self.lf
            def f(a, b):
                pass
            f(1, b=1)

    unittest.main()

# Generated at 2022-06-24 01:45:40.227266
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger("log_test")
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    logger.debug("test")
    logger.debug("test_method")

# Test for building a requests session

# Generated at 2022-06-24 01:45:46.298784
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    
    # First, test with correct dtype of input logger
    from logging import getLogger
    logger = getLogger(__name__)
    logged_func = LoggedFunction(logger)

    # Next, test with incorrect dtype of input logger
    try:
        logged_func = LoggedFunction(__name__)
    except TypeError:
        print('Exception: TypeError -- pass')


# Generated at 2022-06-24 01:45:55.853068
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=False, retry=False)
    assert not hasattr(session, "hooks")
    assert len(session.adapters) == 0

    session = build_requests_session(raise_for_status=True, retry=False)
    assert len(session.hooks["response"]) == 1
    assert callable(session.hooks["response"][0])
    assert len(session.adapters) == 0

    session = build_requests_session(raise_for_status=False, retry=True)
    assert not hasattr(session, "hooks")
    assert len(session.adapters) == 2
    for v in session.adapters.values():
        assert isinstance(v, HTTPAdapter)

# Generated at 2022-06-24 01:45:59.718606
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import Mock

    logger = Mock()
    func = LoggedFunction(logger)
    assert func.logger == logger


# Generated at 2022-06-24 01:46:04.381052
# Unit test for function format_arg
def test_format_arg():
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"
    assert format_arg((1, 2, 3)) == "(1, 2, 3)"
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg("hello") == "'hello'"

# Generated at 2022-06-24 01:46:16.111465
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import logging
    import unittest


    class TestLoggedFunction(unittest.TestCase):
        def test(self):
            log_stream = io.StringIO()
            logger = logging.getLogger("mixer")
            logger.addHandler(logging.StreamHandler(log_stream))
            logger.setLevel(logging.DEBUG)

            def func(*args, **kwargs):
                return args, kwargs

            logged_func = LoggedFunction(logger)(func)
            logged_func(1, 2, a=3, b=4)

# Generated at 2022-06-24 01:46:24.183546
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from loguru import logger
    from datetime import datetime
    from pytest import raises
    from unittest.mock import Mock
    from requests.adapters import HTTPAdapter

    # test constructor with logger
    logger.info("Hello")
    function = LoggedFunction(logger)
    assert function.logger == logger

    # test constructor with a mock logger
    logger = Mock()
    function = LoggedFunction(logger)
    assert function.logger == logger

    # test constructor with an adapter
    adapter = HTTPAdapter(max_retries=5)
    with raises(AssertionError):
        assert LoggedFunction(adapter)

# Generated at 2022-06-24 01:46:29.181666
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    test_logger = logging.getLogger("test_logger")
    logged_func = LoggedFunction(test_logger)
    def test_func():
        pass
    assert logged_func.__call__(test_func)


# Generated at 2022-06-24 01:46:37.766944
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyClass:
        def a_method(self, arg1, arg2, kwarg1=1, kwarg2=2):
            return 42

    class MockLogger:
        def debug(self, text):
            print(text)

    dummy_object = DummyClass()
    dummy_object.a_method(1, 2, kwarg1=3, kwarg2=4)
    LoggedFunction(MockLogger())(dummy_object.a_method)(1, 2, kwarg1=3, kwarg2=4)

# Generated at 2022-06-24 01:46:48.445274
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.output = []

        def debug(self, message):
            self.output.append(message)

    @LoggedFunction(TestLogger())
    def test_function(a, b=None, c=2):
        return a + b + c

    test_function(10, 11)
    assert test_function.__name__ == "test_function"
    assert (
        test_function.logger.output[0] == "test_function(10, 11, c=2)"
    ), test_function.logger.output[0]
    assert (
        test_function.logger.output[1] == "test_function -> 23"
    ), test_function.logger.output[1]



# Generated at 2022-06-24 01:46:57.879366
# Unit test for function format_arg
def test_format_arg():
    assert "0" == format_arg(0)
    assert "1" == format_arg(1)
    assert "'abc'" == format_arg("abc")
    assert "'abc'" == format_arg("   abc   ")
    assert "''" == format_arg("")
    assert "'a''b''c'" == format_arg("a'b'c")
    assert "(1, 2, 3)" == format_arg((1, 2, 3))
    assert "[1, 2, 3]" == format_arg([1, 2, 3])
    assert "{'a': 1, 'b': 2}" == format_arg({"a": 1, "b": 2})
    assert "{'a': {'1': 1}}" == format_arg({"a": {"1": 1}})

# Generated at 2022-06-24 01:47:06.572191
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('"\'\\') == "'\"\'\\'"
    assert format_arg(42) == "42"
    assert format_arg(None) == 'None'
    assert format_arg(True) == 'True'
    assert format_arg(False) == 'False'
    assert format_arg(3.14) == '3.14'
    assert format_arg(3.1416e+42) == '3.1416e+42'
    assert format_arg([1,2,3]) == '[1, 2, 3]'
    assert format_arg((None, 1, 2, 3)) == '(None, 1, 2, 3)'
    assert format_arg({1,2,3}) == '{1, 2, 3}'

# Generated at 2022-06-24 01:47:12.035915
# Unit test for function build_requests_session
def test_build_requests_session():
    _ = build_requests_session()
    _ = build_requests_session(raise_for_status=False)
    _ = build_requests_session(retry=False)
    _ = build_requests_session(retry=1)
    _ = build_requests_session(retry=Retry(2))
    with pytest.raises(ValueError):
        _ = build_requests_session(retry="")

# Generated at 2022-06-24 01:47:14.496038
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger(__name__)
    dec = LoggedFunction(logger)
    assert dec(lambda: None)() == None


# Generated at 2022-06-24 01:47:24.705090
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s, Session)
    assert s.adapters is not None and len(s.adapters) > 0
    assert s.hooks is None
    s = build_requests_session(False, 2)
    assert isinstance(s, Session)
    assert s.adapters is not None and len(s.adapters) > 0
    assert s.hooks is None
    s = build_requests_session(True)
    assert isinstance(s, Session)
    assert s.adapters is not None and len(s.adapters) > 0
    assert s.hooks is not None and len(s.hooks) > 0


# Generated at 2022-06-24 01:47:29.402952
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hello") == "'hello'"
    assert format_arg("hello'") == "'hello''"
    assert format_arg("") == "''"
    assert format_arg("hello 'world'") == "'hello ''world'''"
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg(1.23) == "1.23"
    assert format_arg(1.234) == "1.234"

# Generated at 2022-06-24 01:47:39.237387
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from logging import basicConfig, DEBUG, getLogger
    from logzero import logger

    # Create a logger with a trash handler so that the test can inspect the output
    # without any other output being added to the log file.
    _buf = StringIO()
    _handler = logging.StreamHandler(_buf)
    _logger = getLogger(__name__)
    _logger.addHandler(_handler)
    _logger.setLevel(DEBUG)

    # Initialize decorator
    logged_function = LoggedFunction(_logger)

    # Create a sample decorated function
    @logged_function
    def concatenate(first, second):
        return first + second

    # Run test
    @logged_function
    def test_concatenate():
        assert concatenate("foo", "bar")

# Generated at 2022-06-24 01:47:50.224643
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10

    session = build_requests_session(retry=False)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

# Generated at 2022-06-24 01:47:51.970893
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = lambda : 3
    obj = LoggedFunction(logger)
    assert obj.logger == logger


# Generated at 2022-06-24 01:47:52.816869
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    f = LoggedFunction(None)


# Generated at 2022-06-24 01:48:01.194171
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session() == build_requests_session(retry=False)
    assert build_requests_session(retry=1) == build_requests_session(retry=Retry(1))

    with pytest.raises(TypeError):
        build_requests_session(retry="1")

    with pytest.raises(ValueError):
        build_requests_session(retry=Retry(1)) == build_requests_session(retry="1")

# Generated at 2022-06-24 01:48:12.004320
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False, raise_for_status=False)
    assert session
    assert "response" not in session.hooks
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=3, raise_for_status=False)
    assert session
    assert "response" not in session.hooks
    assert list(session.adapters["http://"].max_retries._retry_attempts._max_retry_attempt_numbers) == [
        3,
        3,
        3,
    ]

# Generated at 2022-06-24 01:48:18.433344
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)

    # session should have a hook to raise exception if status code is not 2**
    assert session.hooks["response"][0](requests.Response()) == None
    assert session.hooks["response"][0](requests.Response().raise_for_status()) == None
    assert session.hooks["response"][0](requests.Response(status_code=401)) != None

    # session should have retry configuration
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    # clear hooks and retry

# Generated at 2022-06-24 01:48:27.615514
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(raise_for_status=True, retry=False)
    assert s.hooks.get('response')
    s = build_requests_session(raise_for_status=False, retry=True)
    assert s.hooks.get('response') is None
    assert isinstance(s.adapters.get('http://'), HTTPAdapter)
    assert isinstance(s.adapters.get('https://'), HTTPAdapter)
    s = build_requests_session(raise_for_status=False, retry=2)
    assert s.hooks.get('response') is None
    assert isinstance(s.adapters.get('http://'), HTTPAdapter)
    assert isinstance(s.adapters.get('https://'), HTTPAdapter)

# Generated at 2022-06-24 01:48:30.245181
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" 12s,s ") == "' 12s,s '"
    assert format_arg(123) == "123"
    assert format_arg([1, 2]) == "[1, 2]"



# Generated at 2022-06-24 01:48:37.643096
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from requests.exceptions import HTTPError

    session = build_requests_session()
    assert not session.hooks
    with pytest.raises(HTTPError):
        session.request("GET", "http://httpbin.org/status/404")

    session = build_requests_session(raise_for_status=False)
    assert not session.hooks
    with pytest.raises(HTTPError):
        session.request("GET", "http://httpbin.org/status/404")

    session = build_requests_session(raise_for_status=True)
    assert "response" in session.hooks
    with pytest.raises(HTTPError):
        session.request("GET", "http://httpbin.org/status/404")


# Generated at 2022-06-24 01:48:44.411889
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger, DEBUG, getLogger
    
    class DummyFunc:
        @LoggedFunction(logger=getLogger())
        def f1(self, a, b, c):
            return "f1"
        @LoggedFunction(logger=getLogger())
        def f2(self, a, b, c, d=1, e=2):
            return "f2"
        @LoggedFunction(logger=getLogger())
        def f3(self, a, b=1, c=2, d=3):
            return "f3"
    dummy = DummyFunc()
    dummy.f1(1, 2, 3)
    dummy.f2(1, 2, 3)
    dummy.f3(1)

# Generated at 2022-06-24 01:48:50.136943
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc def") == "'abc def'"
    assert format_arg(123) == "123"
    assert format_arg(.23) == "0.23"

# Generated at 2022-06-24 01:48:54.626399
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1.1) == "1.1"
    assert format_arg(42) == "42"
    assert format_arg("foo") == "'foo'"
    assert format_arg("foo bar") == "'foo bar'"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:48:59.887664
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg("test") == "'test'"

# Generated at 2022-06-24 01:49:03.081644
# Unit test for function format_arg
def test_format_arg():
    assert(format_arg(1) == "1")
    assert(format_arg(1.2) == "1.2")
    assert(format_arg("abc") == "'abc'")
    assert(format_arg("abc efg") == "'abc efg'")

# Generated at 2022-06-24 01:49:05.234403
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('1') == "'1'"
    assert format_arg(' a ') == "' a '"
    assert format_arg(1.2) == '1.2'


# Generated at 2022-06-24 01:49:10.681382
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock, patch
    import logging
    import functools

    mock_logger = MagicMock(logging.Logger)

    logged_function = LoggedFunction(mock_logger)

    mock_func = MagicMock(spec=lambda: 1)
    mock_func.__name__ = "mock_func"
    mock_func.__doc__ = "mock_func"

    mock_func.return_value = 1

    args = [1, 2]
    kwargs = {'a': 3}

    # Call first logging function
    logged_func = logged_function(mock_func)

    mock_logger.debug.assert_not_called()
    mock_func.assert_not_called()

    # Call function with arguments and assert logging is correct
   

# Generated at 2022-06-24 01:49:12.105685
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction
    assert LoggedFunction.__init__
    assert LoggedFunction.__call__


# Generated at 2022-06-24 01:49:20.020651
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    # Setup a log handler so we can see the output
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Decorate a function and call it
    @LoggedFunction(logger)
    def example_function():
        """Function whose behaviour we want to log."""
        return 1

    example_function()


if __name__ == "__main__":
    test_LoggedFunction()

# Generated at 2022-06-24 01:49:29.739110
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import DEBUG, getLogger
    from logging import StreamHandler
    from logging import Formatter

    # create logger for LoggedFunction
    logger = getLogger("LoggedFunction")
    logger.setLevel(DEBUG)

    # create console handler and set level to debug
    ch = StreamHandler()
    ch.setLevel(DEBUG)

    # create formatter
    log_format = "%(name)s - %(levelname)s - %(message)s"
    formatter = Formatter(log_format)

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    def foo(val):
        print(val)

    foo = LoggedFunction(logger)(foo)
    foo("alamakota")

# Generated at 2022-06-24 01:49:35.498330
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger()
    logging.basicConfig(level=logging.DEBUG)

    def test_func():
        logger.debug("calling test_func")
        print(test_func.__name__)
        return test_func.__name__

    new_func = LoggedFunction(logger)(test_func)
    assert new_func() == 'test_func'


# Generated at 2022-06-24 01:49:44.323773
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import tempfile

    # Define function to be tested
    @LoggedFunction(logger=logging.getLogger(__name__))
    def test_func(a, b, c):
        print(f"{a} {b} {c}")
        return f"{a} {b} {c}"

    # Set up file handler
    file_handle = tempfile.TemporaryFile(mode='w+')
    file_handler = logging.FileHandler(file_handle)
    file_handler.setLevel(logging.DEBUG)

    logger = logging.getLogger(__name__)
    logger.addHandler(file_handler)

    # Call the function, test the logs
    test_func("aa", "bb", "cc")

    logger.removeHandler(file_handler)

# Generated at 2022-06-24 01:49:50.529940
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.records = []

        def debug(self, msg):
            self.records.append(msg)

    logger = Logger()
    decoratee = LoggedFunction(logger)

    def test_func_1(a1, a2, kw1=None, kw2="My Keyword 2"):
        pass

    # Test using log with non-empty records
    decorated_func = decoratee(test_func_1)
    decorated_func(1, 2)
    decorated_func(3, 4, kw1="My Keyword 1")
    assert "test_func_1(1, 2)" == logger.records[0]

# Generated at 2022-06-24 01:49:51.291593
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("'") == "'\\''"
    assert format_arg("'test") == "''\\''test'"

# Generated at 2022-06-24 01:50:03.447295
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest import mock

    my_logger = logging.getLogger("test")

    function_log_capture_string = (
        "{function}({args}{kwargs})"
    )

    def simple_test_function(*args, **kwargs):
        return "test"

    def complex_test_function(*args, **kwargs):
        return "test2"

    def test_captures_with_positional_args_kwargs():
        with mock.patch.object(my_logger, "debug") as debug_mock:
            logged_function = LoggedFunction(logger=my_logger)(simple_test_function)
            logged_function(arg1="arg1", arg2="arg2")
            assert len(debug_mock.call_args_list) == 2

# Generated at 2022-06-24 01:50:14.734264
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import sys
    from io import StringIO
    from unittest.mock import patch
    from tests.utils.mock import mock_logger
    from logging import DEBUG
    logger = mock_logger()
    logged_func = LoggedFunction(logger)

    # test function with no return value
    @logged_func
    def test_func_no_return():
        pass
    test_func_no_return()
    assert logger.debug.call_count == 2
    assert logger.debug.call_args_list[0][0][0] == "test_func_no_return()"
    assert logger.debug.call_args_list[1][0][0] == "test_func_no_return -> None"
    logger.debug.reset_mock()

    # test function with no input argument

# Generated at 2022-06-24 01:50:17.780048
# Unit test for function format_arg
def test_format_arg():
    assert "123" == format_arg(123)
    assert "'abc'" == format_arg("abc")
    assert "' a b c '" == format_arg(" a b c ")

# Generated at 2022-06-24 01:50:21.703185
# Unit test for function build_requests_session
def test_build_requests_session():
    import random
    import time
    session = build_requests_session(raise_for_status=False, retry=False)
    for i in range(3):
        try:
            session.get("https://www.baidu.com/s", params={"ie": "utf-8", "wd": "riji"})
        except Exception as e:
            print(e)

# Generated at 2022-06-24 01:50:37.704316
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {"http://": HTTPAdapter(max_retries=Retry()),
                                "https://": HTTPAdapter(max_retries=Retry())}

    session = build_requests_session(raise_for_status=False, retry=False)
    assert session.hooks == {}
    assert session.adapters == {}

    session = build_requests_session(retry=2)
    assert session.hooks == {}
    assert session.adapters == {"http://": HTTPAdapter(max_retries=Retry(2)),
                                "https://": HTTPAdapter(max_retries=Retry(2))}

    session = build_requests_session(retry=Retry())
    assert session.hooks

# Generated at 2022-06-24 01:50:43.222427
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import Timeout
    from requests.exceptions import ConnectionError

    requests_session = build_requests_session()
    try:
        requests_session.get("http://www.google.com")
    except Timeout:
        assert True
    except ConnectionError:
        assert True
    else:
        assert False


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-24 01:50:47.354122
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        _ = LoggedFunction(None)
    except Exception as e:
        assert type(e) == TypeError
    assert str(e) == "logger should not be None."


# Generated at 2022-06-24 01:50:49.367615
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

# Generated at 2022-06-24 01:50:57.515388
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # initialize
    logger= logging.getLogger(__name__)
    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(name)-12s %(levelname)-8s %(message)s")
    )
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logged_function_instance = LoggedFunction(logger=logger)
    # dummy function
    # test input arguments and return value
    def round(x, place=0):
        return int(x * (10 ** place + 0.5)) / 10.0 ** place
    def sum(x, y):
        return x + y
    def sum1(x, y, z=None):
        return x + y + z

# Generated at 2022-06-24 01:51:07.144628
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test")
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

    # Make sure the function's regular name is preserved
    @LoggedFunction(logger)
    def test(a, b):
        return a + b

    assert test.__name__ == "test"

    assert test(1, 2) == 3  # noqa

    # Make sure kwargs are logged semantically
    @LoggedFunction(logger)
    def test2(a=1, b=2):
        return a + b

    assert test2() == 3  # noqa

    @LoggedFunction(logger)
    def test3(a, b=2):
        return a + b

    assert test3(3) == 5  #

# Generated at 2022-06-24 01:51:17.836457
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class Test(unittest.TestCase):
        @LoggedFunction(logging.getLogger("foo"))
        def foo(self, a, b, c=3):
            return a + b + c

        def test_1(self):
            # replace sys.stdout
            saved_stdout = sys.stdout

# Generated at 2022-06-24 01:51:28.366793
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()

    @LoggedFunction(logger)
    def foo(a, b=1, *args, **kwargs):
        return None

    @LoggedFunction(logger)
    def bar(a, b=1, *args, **kwargs):
        return a + b

    @LoggedFunction(logger)
    def baz(a, b=1, *args, **kwargs):
        return (a, b)

    foo(5, b=5)
    bar(5, b=5)
    baz(5, b=5)

if __name__ == '__main__':
    test_LoggedFunction()

# Generated at 2022-06-24 01:51:33.397313
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert(session.adapters == {})
    session = build_requests_session(retry=True)
    assert(len(session.adapters) == 2)
    session = build_requests_session(retry=1)
    assert(len(session.adapters) == 2)
    assert list(session.adapters.values())[0].max_retries.total == 1
    retry = Retry(total=10)
    session = build_requests_session(retry=retry)
    assert(len(session.adapters) == 2)
    assert list(session.adapters.values())[0].max_retries.total == 10

# Generated at 2022-06-24 01:51:38.451550
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    logger = logging.getLogger("test")
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def add_one(x):
        return x + 1

    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    @LoggedFunction(logger)
    def none():
        return None

    assert add_one(1) == add(1, 0) == 2
    none()

# Generated at 2022-06-24 01:51:42.731310
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(3) == "3"
    assert format_arg("1") == "'1'"
    assert format_arg(" 1") == "' 1'"
    assert format_arg("1 ") == "'1 '"
    assert format_arg(" 1 ") == "' 1 '"
    assert format_arg(1.1) == "1.1"
    assert format_arg(True) == "True"



# Generated at 2022-06-24 01:51:45.354195
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    s = LoggedFunction(logger=None)
    assert(s is not None)



# Generated at 2022-06-24 01:51:48.298514
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert isinstance(LoggedFunction({}),LoggedFunction)

# Generated at 2022-06-24 01:51:54.287639
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(False) == "False"
    assert format_arg(True) == "True"
    assert format_arg(0) == "0"
    assert format_arg(1) == "1"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"
    assert format_arg("abc") == "'abc'"
    assert format_arg(" abc ") == "' abc '"

if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:51:57.285567
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("  a  b   ") == "'a  b'"
    assert format_arg(1) == "1"
    assert format_arg(1.1) == "1.1"

# Generated at 2022-06-24 01:52:08.998244
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry
    from datetime import datetime
    from time import sleep

    # Test 1
    session = build_requests_session(
        raise_for_status=False,
        retry=Retry(total=5,
                    status_forcelist=[500, 502, 503, 504],
                    method_whitelist=["HEAD", "GET", "OPTIONS"]),
    )
    # test status_forcelist
    response = session.get("https://httpbin.org/status/500")
    assert response.status_code == 500
    assert session.adapters["https://"].max_retries.total == 5
    # test method_whitelist

# Generated at 2022-06-24 01:52:19.258933
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session()
    sess = build_requests_session(raise_for_status=False)
    sess = build_requests_session(retry=2)
    sess = build_requests_session(retry=Retry(2))
    sess = build_requests_session(raise_for_status=False, retry=False)
    sess = build_requests_session(raise_for_status=False, retry=2)
    sess = build_requests_session(raise_for_status=False, retry=Retry(2))

# Generated at 2022-06-24 01:52:31.227678
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    session = build_requests_session(retry=False, raise_for_status=True)
    session.get('http://www.google.com')
    r = session.get('https://httpbin.org/status/418')
    try:
        r.raise_for_status()
    except requests.HTTPError:
        print("received 418")
    else:
        raise AssertionError("Should have received a 418")
    session = build_requests_session(retry=False, raise_for_status=False)
    session.get('http://www.google.com')
    r = session.get('https://httpbin.org/status/418')
    if r.status_code != 418:
        print(r.status_code)
        raise AssertionError("Should have received a 418")

# Generated at 2022-06-24 01:52:41.229148
# Unit test for function build_requests_session
def test_build_requests_session():
    with build_requests_session(True, False) as s:
        assert s.raise_for_status == True
        assert False
    with build_requests_session(False, False) as s:
        assert s.raise_for_status == False
        assert False
    with build_requests_session(True, True) as s:
        assert s.raise_for_status == True
        assert s.max_retries.total == 3
    with build_requests_session(False, True) as s:
        assert s.raise_for_status == False
        assert s.max_retries.total == 3
    with build_requests_session(True, 2) as s:
        assert s.raise_for_status == True
        assert s.max_retries.total == 2