

# Generated at 2022-06-24 01:42:44.898652
# Unit test for function build_requests_session
def test_build_requests_session():

    from requests import codes

    from .test import TestClient

    client = TestClient(build_requests_session())

    # get
    assert client.get("/test/get/200").status_code == codes.ok
    assert client.get("/test/get/401").status_code == codes.unauthorized
    assert client.get("/test/get/500").status_code == codes.internal_server_error

    # post
    assert client.post("/test/post/200").status_code == codes.ok
    assert client.post("/test/post/401").status_code == codes.unauthorized
    assert client.post("/test/post/500").status_code == codes.internal_server_error

    # put
    assert client.put("/test/put/200").status_code == codes.ok


# Generated at 2022-06-24 01:42:48.064820
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def func(*args, **kwargs):
        return True
    lf = LoggedFunction(print)
    lf(func)
    assert lf(func)()
    assert lf(func)(1, 3, a='a', b='b')



# Generated at 2022-06-24 01:42:54.405080
# Unit test for function format_arg
def test_format_arg():
    assert eval(format_arg("a string")) == "a string"
    assert format_arg("a string") == "'a string'"
    assert format_arg(" a string ") == "' a string '"
    assert eval(format_arg(1)) == 1
    assert eval(format_arg(1.0)) == 1.0
    assert eval(format_arg(True)) is True
    assert eval(format_arg([1, 2, 3])) == [1, 2, 3]
    assert eval(format_arg({"a":1})) == {"a":1}



# Generated at 2022-06-24 01:43:04.128783
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import tmp.tmp_logger as tmp_logger

    class Test_LoggedFunction___call__(unittest.TestCase):
        def test_success(self):
            logger = tmp_logger.TmpLogger()
            log_func = LoggedFunction(logger)

            def add(a, b, c=3):
                return a + b + c

            log_add = log_func(add)
            self.assertEqual(9, log_add(1, 2))
            self.assertEqual(6, log_add(1, 2, c=3))

            with self.assertRaisesRegex(Exception, "test"):
                log_add(1, 2, c=4)


# Generated at 2022-06-24 01:43:14.384250
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session
    assert isinstance(session, Session)

    session = build_requests_session(raise_for_status=False)
    assert session
    assert isinstance(session, Session)
    assert len(session.hooks["response"]) == 0

    retry = Retry()

    session = build_requests_session(retry=retry)
    assert session
    assert isinstance(session, Session)

    try:
        session = build_requests_session(retry="foo")
        assert False
    except ValueError:
        pass

    try:
        session = build_requests_session(retry=1)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 01:43:22.728032
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=False)
    r = session.get("http://httpbin.org/status/404")
    assert r.status_code == 404
    try:
        r.raise_for_status()
    except Exception as e:
        pass
    else:
        assert False

    session = build_requests_session(raise_for_status=False, retry=False)
    r = session.get("http://httpbin.org/status/404")
    assert r.status_code == 404
    r.raise_for_status()

    session = build_requests_session(raise_for_status=False, retry=True)

# Generated at 2022-06-24 01:43:30.353342
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import os
    import sys
    logger = logging.getLogger("LoggedFunction.test")
    # set logger level to <WARN, it will filter out all the <WARN messages.
    logger.setLevel(os.environ.get("LOG_LEVEL", "WARN"))
    # Initialize a console handler
    handler = logging.StreamHandler(sys.stdout)
    # Register handler to the logger
    logger.addHandler(handler)
    # Initialize a decorator instance
    logged_function = LoggedFunction(logger)

    @logged_function
    def foo(a, b, c):
        return a + b + c

    # Execute the decorated function
    foo(12, 4, c=8)

# Generated at 2022-06-24 01:43:41.011283
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.packages.urllib3.util.retry import Retry
    from requests.adapters import HTTPAdapter

    session = build_requests_session(raise_for_status=True, retry=True)
    session.hooks
    assert type(session.hooks['response'][0]) == functools.partial
    assert type(session.adapters['http://']) == HTTPAdapter
    assert type(session.adapters['https://']) == HTTPAdapter
    assert type(session.adapters['https://'].max_retries) == Retry
    session.adapters['https://'].max_retries.total
    session.adapters['https://'].max_retries.status_forcelist
    session.adapters['https://'].max_retries.backoff_factor

# Generated at 2022-06-24 01:43:51.596496
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def foo(a, b=10):
        return a * b

    assert hasattr(foo, "__name__")
    assert foo.__name__ == "foo"

    from logging import getLogger, INFO, DEBUG
    # import logging
    # logging.basicConfig(level=DEBUG)

    logger = getLogger()
    logger.setLevel(DEBUG)
    logged_foo = LoggedFunction(logger)(foo)

    assert hasattr(logged_foo, "__name__")
    assert logged_foo.__name__ == "foo"
    # TODO: assertLogs doesn't work.
    # with assertLogs(logger, level=INFO) as cm:
    #     result = logged_foo(5)
    # assert result == 50
    # assert len(cm.output) == 2
    # assert "foo

# Generated at 2022-06-24 01:43:59.444196
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import loggign
    import os
    import time

    @LoggedFunction(loggign.getLogger(__name__))
    def some_function(x):
        return x + 1

    # Logging config
    loggign.THREADING_LOGGERS = False
    loggign.LOGGERS_LEVEL = 10
    loggign.log_file_config(
        os.path.join(os.path.dirname(__file__), "logs", "test.log")
    )

    some_function(1)
    time.sleep(1)
    some_function(2)

# test_LoggedFunction___call__()

# Generated at 2022-06-24 01:44:06.964399
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg(r"hello world") == r"'hello world'"
    assert format_arg(r"""hello world""") == r"""hello world"""
    assert format_arg(r"""'hello world'""") == r"""'hello world'"""
    assert format_arg(r'""' + r"'hello world'" + r'""') == r'""' + r"'hello world'" + r'""'

if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:44:11.805493
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    assert LoggedFunction(None)(lambda x, y: x + y)(1, 2) == 3
    assert LoggedFunction(None)(lambda x, y, **z: x + y)(1, 2, name="Ruoyao") == 3



# Generated at 2022-06-24 01:44:14.859226
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    f = LoggedFunction(logger)
    def g():
        pass
    assert f(g).__name__ == 'g'


# Generated at 2022-06-24 01:44:21.657697
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session(raise_for_status=True, retry=False)) == Session
    assert type(build_requests_session(raise_for_status=True, retry=True)) == Session
    assert type(build_requests_session(raise_for_status=True)) == Session

    try:
        build_requests_session(retry="foo")
        raise Exception("build_requests_session must accept only bool, int or Retry input")
    except ValueError:
        pass

# Generated at 2022-06-24 01:44:27.275537
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Create logger
    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Test function
    @LoggedFunction(logger)
    def foo(x):
        return x ** 2

    # Call function
    foo(3)

# Generated at 2022-06-24 01:44:37.020876
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.log_list = []

        def debug(self, log):
            self.log_list.append(log)

    test_logger = TestLogger()

    @LoggedFunction(test_logger)
    def f(a, b=0):
        return a + b

    assert f(10, b=20) == 30
    assert (
        test_logger.log_list[0] == "f(10, b=20)"
    ), f"First log incorrect. Logs: {test_logger.log_list}"
    assert (
        test_logger.log_list[1] == "f -> 30"
    ), f"Second log incorrect. Logs: {test_logger.log_list}"

# Generated at 2022-06-24 01:44:44.999767
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    a = 1
    b = "hello"
    c = {"x" : 1, "y": "hello"}
    class FakeLogger:
        def debug(self, string):
            print(string)
    l = FakeLogger()
    lf = LoggedFunction(l)
    @lf
    def test_func(x, y, z = None):
        pass
    print("init finished")
    test_func(a, b, z = c)

if __name__ == "__main__":
    test_LoggedFunction()

# Generated at 2022-06-24 01:44:49.346943
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(0) == "0"
    assert format_arg('0') == "'0'"
    assert format_arg('  0') == "'  0'"
    assert format_arg('0 ') == "'0 '"
    assert format_arg('  0  ') == "'  0  '"

# Generated at 2022-06-24 01:44:58.666242
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    noname_func = LoggedFunction(logger)

    @noname_func
    def sum(a, b):
        return a + b

    sum(5, 4)



# Generated at 2022-06-24 01:45:07.260823
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging
    import unittest.mock as mock

    logger = mock.Mock(spec=logging.Logger)
    func = mock.Mock(spec=lambda: None)

    lf = LoggedFunction(logger)
    lf(func)(1, 2, 3, param_one=4, param_two=5)
    logger.debug.assert_called_once_with(
        "{function}({args}{kwargs})".format(
            function="func", args="1, 2, 3", kwargs=", param_one=4, param_two=5"
        )
    )
    func.assert_called_once_with(1, 2, 3, param_one=4, param_two=5)

# Generated at 2022-06-24 01:45:15.473445
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert not session.hooks, "hooks should be empty if raise_for_status is False"

    session = build_requests_session(raise_for_status=False, retry=False)
    assert not session.hooks, "hooks should be empty if raise_for_status is False"

    session = build_requests_session()
    assert session.hooks, "hooks should not be empty if raise_for_status is True"

    session = build_requests_session(retry=False)
    adapter = session.adapters["http://"]
    assert not adapter.max_retries.total, "total should be 0 if retry is False"

    session = build_requests_session(retry=True)

# Generated at 2022-06-24 01:45:27.029833
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        LoggedFunction(logger=True)
        assert False  # should raise TypeError
    except TypeError:
        assert True

    try:
        LoggedFunction(logger=True)
        assert False  # should raise TypeError
    except TypeError:
        assert True

    try:
        LoggedFunction(logger=0)
        assert False  # should raise TypeError
    except TypeError:
        assert True

    try:
        LoggedFunction(logger='hello')
        assert False  # should raise TypeError
    except TypeError:
        assert True

    try:
        LoggedFunction(logger=['hello'])
        assert False  # should raise TypeError
    except TypeError:
        assert True


# Generated at 2022-06-24 01:45:32.894069
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test(a, b=None):
        """
        Test method for LoggedFunction
        :param a:
        :param b:
        :return:
        """
        return a, b
    from logging import getLogger
    logger = getLogger("logged function")
    logger.debug = lambda x: print(x)
    logged_test = LoggedFunction(logger)(test)
    assert logged_test("a", b="b") == ("a", "b")
    assert logged_test("a") == ("a", None)

# Generated at 2022-06-24 01:45:40.126501
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" a ") == "' a '"
    assert format_arg(1) == "1"
    assert format_arg(1.1) == "1.1"
    assert format_arg((1, "a", (1,))) == "(1, 'a', (1,))"
    assert format_arg({"a": 1}) == "{'a': 1}"

# Generated at 2022-06-24 01:45:50.230626
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert s.adapters['http://'].max_retries.total == 10
    assert s.adapters['http://'].max_retries.connect == 5
    assert s.adapters['http://'].max_retries.read == 5
    assert s.adapters['http://'].max_retries.status_forcelist == (500,)
    assert s.adapters['http://'].max_retries.backoff_factor == 0.3
    s = build_requests_session(retry=False)
    assert 'http://' not in s.adapters
    assert 'https://' not in s.adapters
    s = build_requests_session(retry=3)
    assert s.adapters['http://'].max_retries.total == 3

# Generated at 2022-06-24 01:46:01.204282
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    import math
    from unittest.mock import patch
    from unittest import TestCase

    with patch("logging.getLogger", return_value=Mock()) as mock_get_logger, patch(
        "logging.Logger.debug"
    ) as mock_debug, patch("math.sqrt", return_value=2) as square:
        logged_func = LoggedFunction(mock_get_logger())
        result = logged_func(math.sqrt)(4)
        mock_debug.assert_any_call("sqrt(4)")
        mock_debug.assert_any_call("sqrt -> 2")
        square.assert_called_once_with(4)
        TestCase().assertEqual(result, 2)

# Generated at 2022-06-24 01:46:10.541410
# Unit test for method __call__ of class LoggedFunction

# Generated at 2022-06-24 01:46:14.096408
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    func = LoggedFunction(logger)
    func_called = func(testLoggedFunction)
    func_called(1, 2, 3, a=3)


# Generated at 2022-06-24 01:46:16.198830
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.mounts["https://"] == HTTPAdapter(max_retries=Retry())

# Generated at 2022-06-24 01:46:23.394216
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.last_msg = None

        def debug(self, msg):
            self.last_msg = msg

    logger = FakeLogger()
    logged_function = LoggedFunction(logger)

    def dummy_func(x, y, z):
        return x + y + z

    logged_func = logged_function(dummy_func)
    assert logged_func(1, 2, 3) == 6
    assert logger.last_msg == "dummy_func(1, 2, 3) -> 6"



# Generated at 2022-06-24 01:46:26.884621
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(1.1) == '1.1'
    assert format_arg('hello') == "'hello'"
    assert format_arg('hello world') == "'hello world'"

# Generated at 2022-06-24 01:46:31.905099
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False)
    assert type(session) == Session

    session = build_requests_session(True)
    assert type(session) == Session

    session = build_requests_session(False, False)
    assert type(session) == Session

    session = build_requests_session(False, True)
    assert type(session) == Session

    session = build_requests_session(False, 20)
    assert type(session) == Session

# Generated at 2022-06-24 01:46:34.902363
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=False, retry=True)
    session.get("http://www.baidu.com")

# Generated at 2022-06-24 01:46:48.193419
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.level = logging.DEBUG

    _logger = logging.getLogger(__name__)
    _logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)
    stream_handler.setFormatter(
        logging.Formatter("%(levelname)8s:%(name)s: %(message)s")
    )
    _logger.addHandler(stream_handler)

    @LoggedFunction(logger)
    def original_func(a, b, c):
        return a + b + c

    original_func(1, 2, 3)



# Generated at 2022-06-24 01:46:52.011815
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

    assert session.headers['User-Agent'].startswith('requests-oauth2/')



# Generated at 2022-06-24 01:46:53.906024
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" hello \"world\" ") == "' hello \"world\" '"
    assert format_arg(123) == "123"



# Generated at 2022-06-24 01:47:00.178695
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("   abc   ") == "'abc'"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc:def:") == "'abc:def:'"
    assert format_arg("abc:def") == "'abc:def'"
    assert format_arg(" abc:def: ") == "'abc:def:'"
    assert format_arg(" abc:def: ghi ") == "'abc:def: ghi'"
    assert format_arg([]) == "[]"
    assert format_arg({}) == "{}"
    assert format_arg([[]]) == "[[]]"
    assert format_arg({1, 2}) == "{1, 2}"

# Generated at 2022-06-24 01:47:07.033707
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from datetime import datetime
    from .date import get_date_range, get_logger
    lf = LoggedFunction(get_logger())
    logger = get_logger()
    test_date = datetime(2020, 4, 14)
    date_range = get_date_range(test_date, test_date)
    result = lf(get_date_range)(test_date, test_date)
    assert result == date_range
    result = lf(get_date_range)(datetime(2020, 4, 14), datetime(2020, 4, 14))
    assert result == [datetime(2020, 4, 14)]
    assert lf(get_date_range)(datetime(2020, 4, 14), datetime(2020, 4, 14)) == result

# Generated at 2022-06-24 01:47:16.748135
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # setup
    import logging
    from io import StringIO
    import sys

    out = StringIO()
    handler = logging.StreamHandler(out)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    def foo(a, b, c=3):
        return 42

    # run
    wrapped = LoggedFunction(logger)(foo)
    wrapped(1, 2)
    wrapped(1, 2, 3)

    # assert
    output = [line.rstrip() for line in out.getvalue().splitlines()]
    assert output[0] == "foo(1, 2)"
    assert output[1] == "foo -> 42"
    assert output[2] == "foo(1, 2, c=3)"
    assert output

# Generated at 2022-06-24 01:47:25.862525
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg("") == "' '"
    assert format_arg("abc") == "'abc'"
    assert format_arg("ab c") == "'ab c'"
    assert format_arg("a'b") == "'a'b'"
    assert format_arg("a'b'") == "'a'b'"
    assert format_arg("a''b") == "'a''b'"
    assert format_arg("a''b'") == "'a''b'"
    assert format_arg("a''b''") == "'a''b'''"
    assert format_arg("a''b'''") == "'a''b'''"
    assert format_arg("'") == "''''"
    assert format_arg("'a") == "'''a'"

# Generated at 2022-06-24 01:47:27.284238
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg('1') == "'1'"

# Generated at 2022-06-24 01:47:28.876630
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("123 456") == "'123 456'"
    assert format_arg(123) == "123"

# Generated at 2022-06-24 01:47:38.377669
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(10) == "10"
    assert format_arg("10") == "'10'"
    assert format_arg("10.0") == "'10.0'"
    assert format_arg("10.00") == "'10.00'"
    assert format_arg("1,000") == "'1,000'"
    assert format_arg("1,000,000") == "'1,000,000'"
    assert format_arg("1,000,000.00") == "'1,000,000.00'"
    assert format_arg(1.0) == "1.0"
    assert format_arg(1.00) == "1.0"
    assert format_arg(1.000) == "1.0"

# Generated at 2022-06-24 01:47:43.138020
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(1.5) == '1.5'
    assert format_arg(None) == 'None'
    assert format_arg('abc') == "'abc'"
    assert format_arg('abc def') == "'abc def'"
    assert format_arg('abc\'def') == "'abc\\'def'"

# Generated at 2022-06-24 01:47:52.741616
# Unit test for function build_requests_session
def test_build_requests_session():
    from chalicelib.db.database import get_db_session
    from chalicelib.utils.string import random_string
    from chalicelib.utils.web import build_requests_session
    from chalicelib.utils.web import call_with_retry
    from pynamodb.exceptions import PutError

    def test_fn(session, i):
        session.put_item(i)

    retry = Retry(connect=2, backoff_factor=1)
    database = random_string(10)

    # test if it will raise error when raised_for_status is True
    session = get_db_session(database)
    rand = random_string(10)

# Generated at 2022-06-24 01:47:59.800893
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class logger:
        def debug(self, message):
            print(message)

    @LoggedFunction(logger())
    def func(a, b, c):
        print(a, b, c)

    func("a", "b", "c")


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:48:09.403389
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 0

    session = build_requests_session(True)
    assert session
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 1

    session = build_requests_session(False)
    assert session
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 0

    session = build_requests_session(True, False)
    assert session
    assert isinstance(session, Session)
    assert len(session.adapters) == 2

# Generated at 2022-06-24 01:48:14.560547
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    # Create a logger which logs to console
    log = logging.getLogger("test_logger")
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler())

    # decorated class with class LoggedFunction
    @LoggedFunction(log)
    def test(a, b, c):
        return "hi"

    # run the above function
    test(1, 2, c=3)

# Generated at 2022-06-24 01:48:19.269901
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def func(*args, **kwargs):
        pass

    logger = logging.getLogger(__name__)
    log = LoggedFunction(logger)
    logged_func = log(func)
    logged_func(1, 2, key1="value1", key2="value2")

# Generated at 2022-06-24 01:48:28.139800
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    class MockLogging:
        def __init__(self):
            self.debug = logging.Logger.debug
            self.output = ""

        def debug(self, msg):
            self.output = msg

    class TestClass:
        def __init__(self):
            self.output = ""
            self.logger = MockLogging()

        @LoggedFunction(logger=MockLogging())
        def test_function(self, a, b, c=0, d=1):
            self.output = a + b + c + d

    # Test with non-keyword arguments
    test_class = TestClass()
    test_class.test_function(3, 2)
    assert test_class.output == 5

# Generated at 2022-06-24 01:48:36.176748
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import unittest
    import unittest.mock

    # Create fake logger and stream
    logger = unittest.mock.Mock()
    stream = io.StringIO()

    #Create fake function
    def func(a, b=None, c=3):
        pass
    
    # Decorate function
    decorated = LoggedFunction(logger)(func)

    # Test with different argument combinations

# Generated at 2022-06-24 01:48:39.768264
# Unit test for function build_requests_session
def test_build_requests_session():
    pass

# Generated at 2022-06-24 01:48:46.671139
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("str1") == "'str1'"
    assert format_arg("str2 ") == "'str2 '"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:48:57.590302
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest
    import warnings

    class LoggerMock(logging.Logger):
        def __init__(self):
            super().__init__('logger_mock')
            self.logged_text = ''

        def debug(self, msg, *args, **kwargs):
            if args or kwargs:
                msg_formatted = msg % (args or kwargs)
            else:
                msg_formatted = msg
            self.logged_text = self.logged_text + ' ' + msg_formatted

        def reset(self):
            self.logged_text = ''

    class TestLoggedFunction(unittest.TestCase):

        def setUp(self):
            logger_mock = LoggerMock()
            self.logged_

# Generated at 2022-06-24 01:49:06.785506
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL
    
    # Create class for testing
    class TestLoggedFunction(unittest.TestCase):
        
        def setUp(self):
            # log level
            self.logLevel = DEBUG
            # max function invocation time
            self.maxInvocationTime = 1
            # max invocation time
            self.maxWaitTime = 3
            # time stamp
            self.timeStamp = time.time()
            
            # log format
            self.logFormat = "%(asctime)s - %(levelname)s - %(message)s"
            
            # create logger
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(self.logLevel)
            
            # create console handler

# Generated at 2022-06-24 01:49:12.859538
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(b"test") == "'test'"
    assert format_arg(1) == "1"
    assert format_arg(1.5) == "1.5"
    assert format_arg(["a", "b", "c"]) == "['a', 'b', 'c']"
    assert format_arg({"a": 1, "b": 2}) == "{'a': 1, 'b': 2}"
    assert format_arg("test") == "'test'"


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:49:24.449122
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock as mock

    logger = mock.create_autospec(logging.Logger)
    logged_func = LoggedFunction(logger).__call__(sum)

    logger.debug.assert_not_called()
    logged_func(1)
    logger.debug.assert_any_call("sum('1')")
    logger.debug.assert_any_call("sum -> 1")
    logger.debug.assert_called_once()

    logger.debug.reset_mock()
    logged_func(1, 2)
    logger.debug.assert_any_call("sum('1', '2')")
    logger.debug.assert_any_call("sum -> 3")
    logger.debug.assert_called_once()

    logger.debug.reset_m

# Generated at 2022-06-24 01:49:25.767379
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)



# Generated at 2022-06-24 01:49:32.790776
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert hasattr(session.adapters["http://"], "max_retries")
    assert isinstance(session.hooks.get("response"), list)
    assert len(session.hooks["response"]) == 0
    session = build_requests_session(raise_for_status=False)
    assert len(session.hooks["response"]) == 0
    retry = Retry(total=10, backoff_factor=1)
    session = build_requests_session(retry=retry)
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries is retry
    session = build_requests_session(retry=10)
    assert isinstance

# Generated at 2022-06-24 01:49:37.959193
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():  
    class logger:
        def debug(self, str):
            pass
    @LoggedFunction(logger())
    def test_fun(arg1, arg2=1):
        return arg2
    assert test_fun(3) == 1
    assert test_fun(3, arg2=2) == 2

# Generated at 2022-06-24 01:49:44.982034
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(str(1)) == '1'
    assert format_arg('a') == "'a'"
    assert format_arg(' a ') == "' a '"
    assert format_arg(['a', 'b']) == "['a', 'b']"

# Generated at 2022-06-24 01:49:49.302457
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc ") == "'abc '"
    assert format_arg(1) == "1"

# Generated at 2022-06-24 01:49:53.197296
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    
    logger = logging.basicConfig()
    assert logger is None

    def foo(x:int, y:str)->str:
        return f'x={x}, y={y}'

    @LoggedFunction(logging)
    def bar(x:int, y:str)->str:
        return f'x={x}, y={y}'

    logging.getLogger().setLevel(logging.DEBUG)
    print(foo(3, 'b')) 
    print(bar(3, 'b'))

test_LoggedFunction()

# Generated at 2022-06-24 01:49:55.606117
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test")
    assert isinstance(LoggedFunction(logger), LoggedFunction)



# Generated at 2022-06-24 01:50:06.792978
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=True)
    assert session.__class__ == Session
    assert Retry.from_int(session.mounts['http://'][0].max_retries) == Retry()
    session = build_requests_session(retry=False)
    assert session.__class__ == Session
    assert Retry.from_int(session.mounts['http://'][0].max_retries) == None
    session = build_requests_session(retry=Retry(total=10, status_forcelist=[404]))
    assert session.__class__ == Session
    assert Retry.from_int(session.mounts['http://'][0].max_retries) == Retry(total=10, status_forcelist=[404])

# Generated at 2022-06-24 01:50:15.222471
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    _test_logged_function = LoggedFunction(logger)
    _test_logged_function2 = LoggedFunction(logger)
    assert _test_logged_function.__str__() == "<__main__.LoggedFunction object>"
    assert _test_logged_function.__repr__() == "<__main__.LoggedFunction object>"
    assert _test_logged_function.__eq__(_test_logged_function2) == True
    assert _test_logged_function.__ne__(_test_logged_function2) == False


# Generated at 2022-06-24 01:50:22.777995
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    Test LoggedFunction class constructor
    :return:
    """
    # Set up test logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    def test_logged_func():
        logger.debug("test_logged_func")
        return "test_logged_func"

    @LoggedFunction(logger)
    def test_logged_func2():
        logger.debug("test_logged_func2")
        return "test_logged_func2"

    def test_logged_func_args(a, b=1):
        logger.debug(f"test_logged_func_args({a}, {b})")

# Generated at 2022-06-24 01:50:26.515452
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    test = LoggedFunction("logger")


# Generated at 2022-06-24 01:50:32.350646
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hello") == "'hello'"
    assert format_arg("") == "''"
    assert format_arg("   ") == "''"
    assert format_arg(123) == "123"
    assert format_arg(None) == "None"


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:50:42.857880
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import time
    import unittest

    logger = logging.getLogger(__name__)

    class TestCase(unittest.TestCase):
        pass

    @LoggedFunction(logger)
    def test_function(arg1, arg2):
        time.sleep(0.1)
        return f"{arg1} + {arg2}"

    def add(a, b):
        return a + b

    def test_LoggedFunction___call___1(self):
        self.assertEqual(test_function(123, 456), "123 + 456")

    def test_LoggedFunction___call___2(self):
        self.assertEqual(test_function(1, 2), "1 + 2")


# Generated at 2022-06-24 01:50:49.095388
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    # Given
    def add(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    func = LoggedFunction(logging.getLogger())

    # When
    add_logged = func(add)
    multiply_logged = func(multiply)

    result = add_logged(5, 11)

    # Then
    assert result == 16
    assert func.logger.handlers[0].buffer[0] == "add(5, 11)"
    assert func.logger.handlers[0].buffer[1] == "add -> 16"

    result = multiply_logged(2, 5)
    assert result == 10
    assert func.logger.handlers[0].buffer[2] == "multiply(2, 5)"
    assert func.logger

# Generated at 2022-06-24 01:50:57.250691
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from time import time

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self) -> None:
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler())
            self.logger.propagate = False
            self.log = LoggedFunction(self.logger)

        def test_logged_func(self):
            @self.log
            def test_func(a, b, c='c', d=10.5, e=None):
                return time()
            self.assertLess(test_func(1, (2, 3), d=4), time())

    unittest.main()



# Generated at 2022-06-24 01:51:00.932741
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("   1234\n") == "'1234'"

# Generated at 2022-06-24 01:51:07.679424
# Unit test for function build_requests_session
def test_build_requests_session():
    from collections import namedtuple
    from http.server import BaseHTTPRequestHandler, HTTPServer

    Response = namedtuple("Response", ["status_code", "reason"])

    class TestRequestHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/error":
                self.send_response(503, "Server Error")
            else:
                self.send_response(200, "OK")
            self.end_headers()

    httpd = HTTPServer(("localhost", 8765), TestRequestHandler)

    import threading
    import time

    ServerThread = threading.Thread(target=httpd.handle_request)
    ServerThread.start()


# Generated at 2022-06-24 01:51:17.666865
# Unit test for function build_requests_session
def test_build_requests_session():
    from unittest.mock import patch
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    with patch.object(Session, "mount") as mock_obj:
        build_requests_session()
        mock_obj.assert_called()

    with patch.object(Session, "hooks") as mock_obj:
        build_requests_session(raise_for_status=True)
        mock_obj.assert_called()

    build_requests_session(retry=True)
    build_requests_session(retry=False)
    build_requests_session(retry=100)
    build_requests_session(retry=Retry(100))


# Generated at 2022-06-24 01:51:28.834304
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert not isinstance(session, Session)

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)

    session = build_requests_session(retry=False, raise_for_status=False)
    assert isinstance(session, Session)

    session = build_requests_session(retry=True)
    assert isinstance(session, Session)

    session = build_requests_session(retry=True, raise_for_status=True)
    assert isinstance(session, Session)

    session = build_requests_session(retry=0)
    assert isinstance(session, Session)

    session = build_requests_session(retry=1)
    assert isinstance(session, Session)

    session = build_

# Generated at 2022-06-24 01:51:35.352416
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Mock
    logger = Mock()

    # Call
    func = (
        LoggedFunction(logger)
        .__call__(lambda x: x ** 2)
        .__wrapped__.__wrapped__
    )
    result = func(3)

    # Asserts
    logger.debug.assert_has_calls([
        call("@call(3)"),
        call("@call -> 9",)
    ], any_order=False)
    assert result == 9

# Generated at 2022-06-24 01:51:41.501482
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("Test") == "'Test'"
    assert format_arg(None) == "None"
    assert format_arg([1, 2, 'test']) == "[1, 2, 'test']"
    assert format_arg({1, 2, 'test'}) == "{1, 2, 'test'}"
    assert format_arg({'a': 1, 'b': 2, 'c': 'test'}) == "{'a': 1, 'b': 2, 'c': 'test'}"

# Generated at 2022-06-24 01:51:49.516487
# Unit test for function build_requests_session
def test_build_requests_session():
    import pandas as pd
    import pandas_datareader.data as web

    session = build_requests_session(True, True)
    web.DataReader("F", "yahoo", session=session)

    with pytest.raises(Exception):
        session = build_requests_session(True, False)
        web.DataReader("F", "yahoo", session=session)

# Generated at 2022-06-24 01:51:56.646699
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)
    assert isinstance(build_requests_session(False), Session)
    assert isinstance(build_requests_session(True), Session)
    assert isinstance(build_requests_session(False, False), Session)
    assert isinstance(build_requests_session(False, True), Session)
    assert isinstance(build_requests_session(True, False), Session)
    assert isinstance(build_requests_session(True, True), Session)
    assert isinstance(build_requests_session(False, 123), Session)
    assert isinstance(build_requests_session(True, 123), Session)
    with pytest.raises(ValueError):
        build_requests_session(False, "123")

# Generated at 2022-06-24 01:52:08.677568
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["http://"].max_retries.total >= 0
    session = build_requests_session(retry=False)
    assert session.adapters["http://"].max_retries.total == 0
    session = build_requests_session(retry=2)
    assert session.adapters["http://"].max_retries.total == 2
    session = build_requests_session(retry=5)
    assert session.adapters["http://"].max_retries.total == 5
    with pytest.raises(ValueError):
        build_requests_session(retry=Retry(3))
        build_requests_session(retry=None)
        build_requests_session(retry="abc")
        build_

# Generated at 2022-06-24 01:52:14.781549
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    "Start including the time delta for requests in debug logging"
    """
    @LoggedFunction(logger=logging.getLogger(__name__))
    def func(a, b):
        return a + b
    assert func(1, 2) == 3

# Generated at 2022-06-24 01:52:17.760474
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("test") == "'test'"
    assert format_arg(" test ") == "'test'"

# Generated at 2022-06-24 01:52:21.773890
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from dataclasses import dataclass
    from logging import basicConfig, DEBUG

    @dataclass
    class Logger:
        debug_arg = None

        def debug(self, arg):
            self.debug_arg = arg

    logger = Logger()
    basicConfig(
        format="%(levelname)-8s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        level=DEBUG,
    )


LoggedFunction(logger)(lambda a, b: a + b)(1, b=2)
assert logger.debug_arg == "f(1, b=2)"

# Generated at 2022-06-24 01:52:27.033369
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(3) == '3'
    assert format_arg(' a ') == "' a '"
    assert format_arg(['a', 'b']) == "['a', 'b']"
    assert format_arg(None) == 'None'

if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:52:36.494003
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    logger_mock = Mock(name="logger.debug")
    logged_func = LoggedFunction(logger_mock)
    def func(*args, **kwargs):
        return f"{args}, {kwargs}"
    logged_func(func)(1,2,3,a=1, b=2, c=3)
    logger_mock.assert_any_call("func((1, 2, 3), (a=1, b=2, c=3))")
    logger_mock.assert_any_call("func -> (1, 2, 3), {'a': 1, 'b': 2, 'c': 3}")
    logger_mock.assert_not_called()