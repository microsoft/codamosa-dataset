

# Generated at 2022-06-24 01:42:37.605525
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    def test_function(a, b=None, c=False):
        print(a, b, c)
        return (a, b, c)

    logged_function = LoggedFunction(logging)
    decorated_function = logged_function(test_function)
    decorated_function(1, b=2, c=True)

# Generated at 2022-06-24 01:42:44.280289
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError

    session = build_requests_session(True, True)
    try:
        session.get("https://www.google.com/")  # This raises 404
    except HTTPError:
        pass
    session.get("https://www.google.com")  # This works

# Generated at 2022-06-24 01:42:48.141620
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" a") == "' a'"
    assert format_arg(1) == "1"
    assert format_arg((1, 2, 3)) == "(1, 2, 3)"
    assert format_arg(None) == "None"
    print("OK: Passed unit test for function 'format_arg'")



# Generated at 2022-06-24 01:42:55.732909
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters['http://'].max_retries.total == 8
    assert session.adapters['https://'].max_retries.total == 8
    session = build_requests_session(False)
    assert session.adapters['http://'].max_retries.total == 8
    assert session.adapters['https://'].max_retries.total == 8
    session = build_requests_session(False, False)
    assert not session.adapters['http://'].max_retries
    assert not session.adapters['https://'].max_retries
    session = build_requests_session(False, 5)
    assert session.adapters['http://'].max_retries.total == 5

# Generated at 2022-06-24 01:42:57.678963
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(' my  ') == "'my'"

# Generated at 2022-06-24 01:43:04.129614
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from datetime import datetime

    #
    # Test: test_constructor_with_wrong_type_logger_parameter
    #
    try:
        # Arrange
        logger = datetime.now()

        # Act
        loggedFunction = LoggedFunction(logger)

        # Assert
        assert False, "LoggedFunction constructor did not throw"
    except TypeError as e:
        assert (
            str(e) == "logger parameter should be an instance of logging.Logger."
        ), "Unexpected exception message thrown"
    except Exception as e:
        assert False, "Unexpected exception thrown"



# Generated at 2022-06-24 01:43:09.181045
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    logged = LoggedFunction(logger)
    assert logged
    assert type(logged) is LoggedFunction
    assert logged.logger is logger


# Generated at 2022-06-24 01:43:14.203241
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    r = session.get("http://httpbin.org/get")
    assert r.status_code == 200

# Generated at 2022-06-24 01:43:22.578561
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter(
        "%(asctime)-6s | %(name)-18s | %(levelname)-8s | %(message)s"
    )
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)

    @LoggedFunction(logger)
    def test_function(arg1, arg2=None, arg3=None):
        return "This is a test."

    test_function(1, 2, 3)


# Generated at 2022-06-24 01:43:30.715794
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert not [i for i in session.adapters.keys() if i.startswith("http://")]
    assert not [i for i in session.adapters.keys() if i.startswith("https://")]
    assert session.hooks == {}

    session = build_requests_session(raise_for_status=False, retry=False)
    assert not [i for i in session.adapters.keys() if i.startswith("http://")]
    assert not [i for i in session.adapters.keys() if i.startswith("https://")]
    assert not session.hooks

    session = build_requests_session()

# Generated at 2022-06-24 01:43:38.820433
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session
    assert type(build_requests_session(False)) == Session
    assert type(build_requests_session(True, False)) == Session
    assert type(build_requests_session(True, 3)) == Session
    assert type(build_requests_session(True, Retry(1))) == Session
    try:
        build_requests_session(True, 3.14)  # type: ignore
        assert False
    except ValueError as e:
        assert e.args[0] == "retry should be a bool, int or Retry instance."

# Generated at 2022-06-24 01:43:45.124541
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    
    _ = logging.getLogger(__name__)
    _.setLevel(logging.DEBUG)
    _.addHandler(logging.StreamHandler())
    
    @LoggedFunction(_)
    def add(x, y):
        return x + y
    
    @LoggedFunction(_)
    def sub(x, y):
        return x - y
    
    @LoggedFunction(_)
    def mul(x, y):
        return x * y
    
    add(1, 2)
    sub('3','5')
    mul("",'6')



# Generated at 2022-06-24 01:43:54.823373
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session(retry=True)
    assert isinstance(sess, Session)

    # If a session is already configured with Retry, this function should not configure it again
    sess.mount("http://", HTTPAdapter(max_retries=Retry(5)))
    sess = build_requests_session(retry=True)
    assert isinstance(sess, Session)

    # Check if a given Retry instance can be used
    retry = Retry(5)
    sess = build_requests_session(retry=retry)
    assert isinstance(sess, Session)

    # Check if an integer as retry count is ok
    sess = build_requests_session(retry=5)
    assert isinstance(sess, Session)

# Generated at 2022-06-24 01:44:05.399788
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == str(None)
    assert format_arg(123) == str(123)
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc def") == "'abc def'"
    assert format_arg("abc 'def'") == "'abc 'def''"
    assert format_arg("abc \ndef") == "'abc \ndef'"
    assert format_arg(b"abc") == "'abc'"
    assert format_arg(1.22) == str(1.22)
    assert format_arg(1.22e4) == str(1.22e4)
    assert format_arg(1.22e40) == str(1.22e40)


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:44:07.157204
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    response = session.get('https://twitter.com')
    print(response)

# Generated at 2022-06-24 01:44:18.272360
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def f():
        return "result_from_f"

    def g(a, b="b", **kwargs):
        return (a, b, kwargs)

    import logging

    class MockedLogger:
        def __init__(self):
            self.log = []

        def debug(self, msg):
            self.log.append(msg)

    logger = MockedLogger()
    lf = LoggedFunction(logger)
    assert lf.logger is logger
    lf(f)()
    assert logger.log == ["f()", "f -> result_from_f"]
    logger.log = []
    lf(g)(1, b=2, c="abc")

# Generated at 2022-06-24 01:44:28.068491
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from loguru import logger as real_logger
    real_logger.remove()
    real_logger.add(sys.stdout, format="{message}")

    logger = real_logger.bind(key="value")

    @LoggedFunction(logger)
    def test_func(param1, param2=True, *args, **kwargs):
        pass

    # Call function
    test_func(1, "two", param3="three", param4=False, param5=["six"])

    real_logger.remove()


# Generated at 2022-06-24 01:44:35.355003
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from requests.models import Response

    sess = build_requests_session(True, False)
    assert type(sess) == Session
    resp = sess.get("https://httpbin.org/status/200")
    assert type(resp) == Response

    with pytest.raises(Exception):
        sess = build_requests_session(True, Retry(0))
        sess.get("https://httpbin.org/status/400")


# Generated at 2022-06-24 01:44:47.348291
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup
    from unittest import TestCase, main
    from unittest.mock import patch
    class TestLoggedFunction(TestCase):
        def setUp(self):
            self.logger = patch("logging.getLogger").start()

        def tearDown(self):
            patch.stopall()

        def test__call__(self):
            log_function = LoggedFunction(self.logger)

            @log_function
            def test_function(*args, **kwargs):
                return len(args) + len(kwargs)

            test_function("hello", "world", "!")
            self.logger.debug.assert_called_once_with("test_function('hello', 'world', '!')")
            self.logger.debug.reset_mock()

# Generated at 2022-06-24 01:44:58.355921
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    def foo(x: int, y: int, *args):
        pass

    foo_with_log = LoggedFunction(logger)(foo)

    with pytest.raises(AssertionError) as execinfo:
        foo_with_log("x", "y", "a", "b")
        assert "foo('x', 'y', 'a', 'b')" in execinfo
        assert "foo -> None" in execinfo

    foo_with_log(1, 2, "a", "b")
    foo_with_log(1, 2, 42)
    foo_with_log(1, 2)



# Generated at 2022-06-24 01:45:06.562178
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    # class LoggedFunction_test(unittest.TestCase):
    #     def test__call__(self):
    class Foo:
        def __init__(self):
            self.logger = logging.getLogger()

        @LoggedFunction(logger=logging.getLogger())
        def method(self, arg1, arg2, kwarg1=1):
            return 5

    # method = Foo.method  # type: LoggedFunction
    # method.__validated__ = True
    # method = SentryDecorator._get_method_object(sentry_client, Foo, "method")
    # log_level = method._capture_log
    # method = method._remove_capture_log()
    foo = Foo()

# Generated at 2022-06-24 01:45:15.592143
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_check_logger_correctly_assigned(self):
            logger = logging.getLogger(__name__)
            func = LoggedFunction(logger)
            self.assertEqual(func.logger, logger)

        @LoggedFunction(logging.getLogger(__name__))
        def test_decorator(self, a, b=1, c="bob"):
            return a + b

        def tes(self):
            self.test_decorator(1, 2, 3)

    unittest.main()

# Generated at 2022-06-24 01:45:27.112906
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest.mock

    logger = logging.getLogger()
    logger.disabled = True
    log_handler = unittest.mock.Mock()
    logger.addHandler(log_handler)

    @LoggedFunction(logger)
    def myfunc(x, y):
        return x + y

    myfunc(1, 2)
    log_handler.handle.assert_called_once_with(
        logging.makeLogRecord({"msg": "myfunc(1, 2)"})
    )

    myfunc(3, 4)
    log_handler.handle.assert_called_with(
        logging.makeLogRecord({"msg": "myfunc(3, 4)"})
    )



# Generated at 2022-06-24 01:45:32.678534
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" hello world ")=="'hello world'"
    assert format_arg("hello'world")=="'hello'world'"
    assert format_arg("hello'world'")=="'hello'world''"
    assert format_arg("hello''world")=="'hello''world'"

    assert format_arg(None)=="None"
    assert format_arg(1)=="1"
    assert format_arg(1.1)=="1.1"
    assert format_arg(True)=="True"

# Generated at 2022-06-24 01:45:37.510769
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    @LoggedFunction(logger=logging.getLogger("test"))
    def a_function():
        return "this is a test"

    assert a_function.__name__ == "a_function"

# Generated at 2022-06-24 01:45:48.073535
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock as mock

    class Test(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.addHandler(logging.NullHandler())
            self.loggedFunction = LoggedFunction(logger=self.logger)

        def test__LoggedFunction___call__(self):
            def test_function(*args, **kwargs):
                return "test_result"

            with mock.patch.object(self.logger, "debug") as mock_debug:
                # test first scenario
                logged_function = self.loggedFunction(test_function)
                logged_function()

# Generated at 2022-06-24 01:45:55.459623
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(0) == "0"
    assert format_arg(1) == "1"
    assert format_arg(0.01) == "0.01"
    assert format_arg("") == "'{}'"
    assert format_arg("a") == "'a'"
    assert format_arg("a b") == "'a b'"
    assert format_arg(" a b ") == "' a b '"

# Generated at 2022-06-24 01:46:01.546643
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class DummyLogger:
        def __init__(self):
            self.logs = []

        def debug(self, message):
            self.logs.append(message)

    logger = DummyLogger()

    @LoggedFunction(logger)
    def test_function(x):
        return x + 1

    test_function(3)

    assert len(logger.logs) == 2
    assert logger.logs[0] == "test_function(3)"
    assert logger.logs[1] == "test_function -> 4"



# Generated at 2022-06-24 01:46:10.834027
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys

    log_handler = logging.StreamHandler(sys.stdout)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(log_handler)

    # Print:
    #   test_LoggedFunction DEBUG: test_logged_function(): None
    #   test_LoggedFunction DEBUG: test_logged_function() -> None
    @LoggedFunction(logger)
    def test_logged_function():
        pass

    test_logged_function()

    # Print:
    #   test_LoggedFunction DEBUG: test_logged_function_with_args(1, 2, value=3): None
    #   test_LoggedFunction DEBUG: test_logged_function_with_args() -> None

# Generated at 2022-06-24 01:46:17.055427
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("")
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter("%(levelname)s: %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    foo = LoggedFunction(logger)
    assert foo.logger is logger


# Generated at 2022-06-24 01:46:25.628424
# Unit test for function build_requests_session
def test_build_requests_session():
    import unittest

    class TestRequestsSession(unittest.TestCase):
        def test_default(self):
            s = build_requests_session()
            self.assertIsInstance(s, Session)

        def test_raise_status(self):
            s = build_requests_session(raise_for_status=False)
            self.assertIsInstance(s, Session)
            self.assertIsNone(s.hooks.get("response"))

        def test_retry_true(self):
            s = build_requests_session(retry=True)
            self.assertIsInstance(s, Session)

        def test_retry_false(self):
            s = build_requests_session(retry=False)
            self.assertIsInstance(s, Session)


# Generated at 2022-06-24 01:46:29.995901
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.5) == "1.5"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc\n") == "'abc'"
    assert format_arg("abc\t") == "'abc'"

# Generated at 2022-06-24 01:46:34.406361
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = object()
    logged_function = LoggedFunction(logger)
    assert logged_function.logger == logger


# Generated at 2022-06-24 01:46:40.291830
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
  logger = logging.getLogger()
  logger.setLevel(logging.DEBUG)
  # create console handler with a higher log level
  handler = logging.StreamHandler()
  handler.setLevel(logging.DEBUG)
  # create formatter and add it to the handlers
  formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
  handler.setFormatter(formatter)
  # add the handlers to the logger
  logger.addHandler(handler)
  lf = LoggedFunction(logger)

  @lf
  def test_func(a,b,c):
      return a+b+c
  test_func(1,2,3)
  test_func(1,2,3,4)

# Generated at 2022-06-24 01:46:44.330492
# Unit test for function format_arg
def test_format_arg():
    val = [1, 2, 'abc def']
    for i in val:
        assert format_arg(i) == str(i), f'format_arg({i}): {format_arg(i)} != {str(i)}'
    

# Generated at 2022-06-24 01:46:54.522575
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('1') == "'1'"
    assert format_arg(' 1 ') == "' 1 '"
    assert format_arg(None) == 'None'
    assert format_arg('') == "''"
    assert format_arg(' ') == "' '"
    assert format_arg({}) == '{}'


# # Unit test for function build_requests_session
# def test_build_requests_session():
#     session = build_requests_session()
#     assert session is not None

#     with pytest.raises(ValueError) as excinfo:
#         build_requests_session(retry=object())
#     assert "retry should be a bool, int or Retry instance." in str(excinfo.value)



# Generated at 2022-06-24 01:46:57.083194
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    log = logging.getLogger("root")
    logged_function = LoggedFunction(log)
    assert logged_function.logger.name == "{}.root".format(__name__)



# Generated at 2022-06-24 01:47:06.573006
# Unit test for function build_requests_session
def test_build_requests_session():
    # Use default configuration
    session = build_requests_session()
    adapter = session.get_adapter("https://")
    assert adapter.max_retries.total == 10
    assert session.hooks == {}

    # Use default configuration with raise_for_status
    session = build_requests_session(raise_for_status=True)
    assert len(session.hooks['response']) == 1

    # Use default configuration with retry
    session = build_requests_session(retry=True)
    adapter = session.get_adapter("https://")
    assert adapter.max_retries.total == 10

    # Use default configuration with retry and raise_for_status
    session = build_requests_session(raise_for_status=True, retry=True)
    adapter = session.get_adapter

# Generated at 2022-06-24 01:47:10.908927
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(False) == "False"
    assert format_arg(True) == "True"
    assert format_arg(0) == "0"
    assert format_arg(1.1) == "1.1"
    assert format_arg("") == "''"
    assert format_arg("foo") == "'foo'"
    assert format_arg("foo bar") == "'foo bar'"



# Generated at 2022-06-24 01:47:13.392212
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.1) == "1.1"
    assert format_arg("   abc   ") == "'abc'"

# Generated at 2022-06-24 01:47:16.996157
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # no arguments
    logger = logging.getLogger()
    log_func = LoggedFunction(logger)
    assert log_func.logger == logger



# Generated at 2022-06-24 01:47:25.960385
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Unit test for method __call__ of class LoggedFunction
    """
    instance = LoggedFunction(logging.getLogger())

    def test_func(a, b, c=3, d="4"):
        pass

    # Test whether the logging statement is performed correctly
    # before the function is called.
    original_logging_debug = logging.debug

    # Monkey patch for logging.debug
    def call_counting_logging_debug(*args, **kwargs):
        if "->" in args[0]:
            call_counting_logging_debug.result_log_call_count += 1
        else:
            call_counting_logging_debug.args_log_call_count += 1

    call_counting_logging_debug.result_log_call_count = 0
    call_counting

# Generated at 2022-06-24 01:47:28.541725
# Unit test for function format_arg
def test_format_arg():
    assert "123" == format_arg(123)
    assert "'hello'" == format_arg("hello")
    assert "'hello'" == format_arg('hello')
    assert "'hello'" == format_arg('  hello ')


# Generated at 2022-06-24 01:47:33.848213
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=1)
    adapter = next(x for x in session.adapters.values() if isinstance(x, HTTPAdapter))
    assert adapter.max_retries.total == 1
    # TODO: add test for raise_for_status

# Generated at 2022-06-24 01:47:44.581577
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    import os
    import sys
    import io


    class TestLoggedFunction(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            stream = io.StringIO()
            logger.addHandler(logging.StreamHandler(stream))
            loggedfunction = LoggedFunction(logger)
            @loggedfunction
            def foo(x, y, z="OK"):
                os.environ["foo"] = "bar"
                return z
            result = foo("a", "b", z="c")
            self.assertEqual(result, "c")

# Generated at 2022-06-24 01:47:53.568265
# Unit test for function build_requests_session
def test_build_requests_session():
    import unittest
    from unittest.mock import Mock


    class TestBuildRequestsSession(unittest.TestCase):
        def test_raise_for_status_hook(self):
            with self.assertRaises(Exception):
                session = build_requests_session()
                session.hooks = {'response': [lambda r, *args, **kwargs: r.raise_for_status()]}
                mock_response = Mock(status_code=404)
                session.hooks['response'][0](mock_response)

        def test_default_retry_config(self):
            session = build_requests_session(retry=3)
            self.assertIsInstance(session.adapters['http://'].max_retries, Retry)

# Generated at 2022-06-24 01:47:57.320299
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    print(session)

# Generated at 2022-06-24 01:48:08.246403
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def test_func(a, b, c=0):
        return a + b + c

    logger = unittest.mock.Mock()
    logger.debug = unittest.mock.Mock()

    logged_func = LoggedFunction(logger)(test_func)

    # Test arguments with no default values
    logged_func(1, 2)
    logger.debug.assert_any_call("test_func(1, 2)")
    logger.debug.assert_any_call("test_func -> 3")

    # Test arguments with default values
    logged_func(1, 2, 3)
    logger.debug.assert_any_call("test_func(1, 2, c=3)")
    logger.debug.assert_any_call("test_func -> 6")

    logger.clear()
    # Test

# Generated at 2022-06-24 01:48:13.328732
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" string ") == f"' string'"
    assert format_arg(1) == "1"
    assert format_arg(1.123) == "1.123"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"

# Generated at 2022-06-24 01:48:13.884695
# Unit test for function build_requests_session
def test_build_requests_session():
    pass

# Generated at 2022-06-24 01:48:16.431317
# Unit test for function build_requests_session
def test_build_requests_session():
    conn = build_requests_session()
    print(conn)
    conn = build_requests_session(retry=Retry(total=500))
    print(conn)



# Generated at 2022-06-24 01:48:22.653777
# Unit test for function build_requests_session
def test_build_requests_session():
    session1 = build_requests_session()
    assert session1.hooks["response"] == [lambda r, *args, **kwargs: r.raise_for_status()]
    session2 = build_requests_session(False)
    assert not session2.hooks.get("response", None)
    session3 = build_requests_session(retry=False)
    assert not session3.max_retries.total
    session4 = build_requests_session(retry=3)
    assert session4.max_retries.total == 3
    session5 = build_requests_session(retry=Retry(total=5))
    assert session5.max_retries.total == 5

# Generated at 2022-06-24 01:48:29.456667
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    lf = LoggedFunction(logger)
    def test_func(a, b=2):
        return "Hello world"
    assert lf(test_func)



# Generated at 2022-06-24 01:48:36.849768
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.mounts['http://']

    session = build_requests_session(raise_for_status=False)
    assert 'response' not in session.hooks

    session = build_requests_session(retry=False)
    assert 'max_retries' not in session.mounts['http://'].max_retries

    session = build_requests_session(retry=Retry(total=1, backoff_factor=1))
    assert session.mounts['http://'].max_retries.total == 1
    assert session.mounts['http://'].max_retries.backoff_factor == 1

# Unit testing for class LoggedFunction and the wrapper 

# Generated at 2022-06-24 01:48:45.313544
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    logger = Mock()

    @LoggedFunction(logger)
    def func1(x,y,z):
        return str(x*y*z)

    @LoggedFunction(logger)
    def func2(x,y,z, a=1, b=2):
        return str(x*y*z*a*b)

    @LoggedFunction(logger)
    def func3(x,y,z, *args):
        return str(x*y*z)

    @LoggedFunction(logger)
    def func4(x,y,z, *args, **kwargs):
        return str(x*y*z)

    # Normal call
    func1(1,2,3)

# Generated at 2022-06-24 01:48:49.943671
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    session.get("http://www.baidu.com")


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-24 01:48:54.002109
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(None) == 'None'
    assert format_arg('None') == "'None'"
    assert format_arg(' None ') == "' None '"

# Generated at 2022-06-24 01:49:03.891735
# Unit test for function build_requests_session
def test_build_requests_session():
    import json
    from requests.exceptions import HTTPError
    from requests.status_codes import _codes

    from .functions import build_requests_session

    session = build_requests_session()
    mock_endpoint_url = "http://127.0.0.1:8088/status/"
    response = session.get(mock_endpoint_url)
    assert response.ok
    mock_data = response.json()
    for code, _ in _codes.items():
        # iterate all http status codes, for each of them, we expect
        # a response with the same http status code to be returned
        if code < 400:
            # http status codes with value < 400 are valid
            response = session.get(f"{mock_endpoint_url}{code}/")

# Generated at 2022-06-24 01:49:13.974206
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None
    assert session.hooks == {}
    assert len(session.adapters) == 2
    session = build_requests_session(raise_for_status=True)
    assert session is not None
    assert len(session.hooks["response"]) == 1
    session = build_requests_session(retry=True)
    assert session is not None
    assert len(session.adapters) == 2
    session = build_requests_session(retry=1)
    assert session is not None
    assert len(session.adapters) == 2
    session = build_requests_session(retry=Retry())
    assert session is not None
    assert len(session.adapters) == 2

# Generated at 2022-06-24 01:49:16.254693
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(10) == "10"
    assert format_arg("str") == "'str'"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:49:28.000198
# Unit test for function build_requests_session
def test_build_requests_session():
    # simple test
    session = build_requests_session(raise_for_status=True)

# Generated at 2022-06-24 01:49:31.935146
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hello") == "'hello'"
    assert format_arg(123) == "123"
    assert format_arg(None) == "None"
    assert format_arg("  spaces  ") == "'  spaces  '"

# Generated at 2022-06-24 01:49:41.992717
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from mock import Mock, call

    logger = Mock()
    logged_func = LoggedFunction(logger)

    test_args = 1, 2, 3
    test_kwargs = {"x": 4}

    def test_func(*args, **kwargs):
        assert args == test_args
        assert kwargs == test_kwargs
        return True

    logged_test_func = logged_func(test_func)

    assert logged_test_func.__name__ == "test_func"

    result = logged_test_func(*test_args, **test_kwargs)

    assert result
    logger.debug.assert_has_calls(
        [
            call("test_func(1, 2, 3, x=4)"),
            call("test_func -> True"),
        ]
    )



# Generated at 2022-06-24 01:49:51.221704
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger, getLogger

    class TestLogger(Logger):
        def __init__(self):
            super().__init__("test")
            self.level = 10
            self.logged_messages = []

        def debug(self, msg):
            self.logged_messages.append(msg)

    # Test without kwargs
    logger = TestLogger()
    logged_func = LoggedFunction(logger)(lambda x, y: x + y)
    assert (
        logged_func.__name__ == "lambda"
    ), "Wrapper should not change function name."
    assert (
        logged_func.__doc__ is None
    ), 'Wrapper changes function docstring to "Wrapped function..."'

    # Call
    assert logged_func(2, 3) == 5
    assert logger

# Generated at 2022-06-24 01:49:53.095905
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    test_logged_function = LoggedFunction(logger="test_logger")
    assert test_logged_function!=None


# Generated at 2022-06-24 01:50:00.812316
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def f(a, b, c="C"):
        return a + b

    logger = Mock()
    logged_func = LoggedFunction(logger)
    result = logged_func(f)("A", "B")
    assert result == "AB"
    logger.debug.assert_has_calls(
        [
            call("f('A', 'B', c='C')"),
            call("f -> AB"),
        ]
    )



# Generated at 2022-06-24 01:50:08.657952
# Unit test for function build_requests_session
def test_build_requests_session():
    session1 = build_requests_session(raise_for_status=True, retry=False)
    assert len(session1.hooks["response"]) == 1
    session2 = build_requests_session(raise_for_status=False, retry=False)
    assert session1.hooks.get("response") == session2.hooks.get("response")
    session3 = build_requests_session(raise_for_status=True, retry=False)
    assert session1.hooks.get("response") == session3.hooks.get("response")
    session1.hooks["response"].append(lambda r, *args, **kwargs: None)
    assert session1.hooks.get("response") != session3.hooks.get("response")

# Generated at 2022-06-24 01:50:11.790239
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('123') == "'123'"
    assert format_arg(123) == '123'
    assert format_arg(123.0) == '123.0'
    assert format_arg(None) == 'None'

# Generated at 2022-06-24 01:50:20.307013
# Unit test for function build_requests_session
def test_build_requests_session():
    from urllib.error import HTTPError
    from urllib.request import urlopen
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    def test_hook_raise_for_status(raise_for_status: bool):
        session = build_requests_session(raise_for_status)
        try:
            with session.get("https://www.google.com/") as resp:
                pass
        except HTTPError as e:
            assert raise_for_status
            assert "403" in str(e)
        else:
            assert not raise_for_status

    def test_retry(retry):
        session = build_requests_session(retry=retry)

# Generated at 2022-06-24 01:50:28.440186
# Unit test for function build_requests_session
def test_build_requests_session():
    url = 'https://randomuser.me/api/'
    session = build_requests_session(raise_for_status=False)

    try:
        session.get(url)
    except Exception:
        pass

    session = build_requests_session(raise_for_status=True)

    try:
        session.get(url)
    except Exception:
        pass

    session = build_requests_session(raise_for_status=False, retry=False)

    try:
        session.get(url)
    except Exception:
        pass

    session = build_requests_session(raise_for_status=False, retry=5)

    try:
        session.get(url)
    except Exception:
        pass


# Generated at 2022-06-24 01:50:28.983420
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    pass

# Generated at 2022-06-24 01:50:31.092109
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():    
    lf1 = LoggedFunction(logging.getLogger(__name__))
    lf2 = LoggedFunction(logging.getLogger(__name__))
    assert lf1.logger == lf2.logger
    

# Generated at 2022-06-24 01:50:41.716594
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Here we use pytest-mock to test method __call__ of class LoggedFunction.
    :return:
    """
    import pytest
    import logging
    import functools

    def sample_func(a, b, c='hello'):
        return a + b + c

    mocked_logger = logging.Logger(name='sample_logger')


# Generated at 2022-06-24 01:50:52.547925
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from testfixtures import LogCapture
    from io import StringIO
    import logging

    _test_string = """
        Test string {test_arg}
    """

    class BasicLogger(logging.Logger):
        def __init__(self, *args, **kwargs):
            self.test_arg = 0
            super().__init__(*args, **kwargs)

        def _log(self, level, msg, args, exc_info=None, extra=None, stack_info=False):
            if extra is None:
                extra = {}
            msg = msg.format(test_arg=self.test_arg)
            super()._log(level, msg, args, exc_info, extra, stack_info)


# Generated at 2022-06-24 01:50:55.882705
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(
        raise_for_status=True, retry=True
    )
    assert session.hooks is not None
    assert len(session.adapters) == 2


test_build_requests_session()

# Generated at 2022-06-24 01:51:02.464995
# Unit test for function format_arg
def test_format_arg():
    # Given
    x = "Hello world"
    y = 1

    # When
    x_formatted = format_arg(x)
    y_formatted = format_arg(y)

    # Then
    assert x_formatted == "'Hello world'"
    assert y_formatted == "1"



# Generated at 2022-06-24 01:51:08.269646
# Unit test for function format_arg
def test_format_arg():
    tests = [("aa", "'aa'"), (3, "3"), ([3, 5], "[3, 5]")]
    for test in tests:
        assert format_arg(test[0]) == test[1]

# Generated at 2022-06-24 01:51:11.864362
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" a 'b' ") == "' a 'b' '"
    assert format_arg(3) == "3"
    assert format_arg(3.0) == "3.0"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:51:16.621098
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == 'None'
    assert format_arg(3.14) == '3.14'
    assert format_arg('hello') == "'hello'"
    assert format_arg(' hello ') == "'hello'"

# Generated at 2022-06-24 01:51:21.673603
# Unit test for function build_requests_session
def test_build_requests_session():
    from contextlib import contextmanager
    from unittest.mock import patch

    @contextmanager
    def mock_session(*args, **kwargs):
        with patch('requests.Session') as mock_session:
            mock_session.return_value = Session(*args, **kwargs)
            yield mock_session

    with mock_session() as mock_session:
        build_requests_session()
        build_requests_session(False)
        build_requests_session(True)
        build_requests_session(True, False)
        build_requests_session(True, 2)
        build_requests_session(True, Retry())
    assert mock_session.call_count == 6
    mock_session.assert_called_with()

# Generated at 2022-06-24 01:51:27.087630
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg("test") == "'test'"
    assert format_arg("  test  ") == "'test'"

# Generated at 2022-06-24 01:51:28.039124
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(logging.getLogger(__name__)) is not None

# Generated at 2022-06-24 01:51:37.934854
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    testLogger = logging.getLogger("test-logger")
    lf = LoggedFunction(testLogger)

    # Test None arguments
    @lf
    def dummy_function():
        pass

    # Tests one normal string argument
    @lf
    def dummy_function_one_string(a):
        pass

    # Tests one normal number argument
    @lf
    def dummy_function_one_number(a):
        pass

    # Tests multiple normal arguments
    @lf
    def dummy_function_multiple(a, b, c):
        pass

    # Tests multiple normal arguments but last one is string
    @lf
    def dummy_function_multiple_last_string(a, b, c):
        pass

    # Tests multiple keyword arguments

# Generated at 2022-06-24 01:51:43.858498
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests

    def test_raise_for_status(hook):
        try:
            raise requests.exceptions.HTTPError
        except:
            hook(None, None)

    test_raise_for_status(build_requests_session().hooks["response"][0])
    build_requests_session(raise_for_status=False).hooks["response"]

# Generated at 2022-06-24 01:51:47.127699
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # create object
    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    assert isinstance(logger, logging.Logger)
    # create decorator function
    lf = LoggedFunction(logger)
    assert lf.logger == logger


# Generated at 2022-06-24 01:51:53.272618
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import sentinel
    from unittest.mock import MagicMock
    from unittest.mock import patch

    # Test1: call function with null arguments and null return value
    lf = LoggedFunction(MagicMock())
    func = MagicMock(return_value = None)
    logged_func = lf(func)
    ret = logged_func()
    func.assert_called_once_with()
    lf.logger.debug.assert_called_once_with("{function}({args}{kwargs})".format(function = "func", args = "", kwargs = ""))
    lf.logger.debug.assert_called_with("func -> None")

    # Test2: call function with arguments and null return value
    lf = LoggedFunction(MagicMock())


# Generated at 2022-06-24 01:52:05.120448
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    import unittest

    logger = logging.getLogger()
    handler = logging.StreamHandler(sys.stderr)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    
    class BaseClass:
        pass

    class TestClass(BaseClass):
        def __init__(self):
            self.logger = logging.getLogger()

        @LoggedFunction(logger)
        def foo(self, a, b, c=1, d=2):
            return a + b + c + d

        @LoggedFunction(logger)
        def bar(self, d):
            return d + 1

        @LoggedFunction(logger)
        def baz(self):
            return 3


# Generated at 2022-06-24 01:52:12.936737
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import re
    from unittest import TestCase
    from io import StringIO
    from contextlib import contextmanager

    logging.basicConfig(level=logging.DEBUG)

    @LoggedFunction(logger=logging.getLogger())
    def test_method(a, b):
        return a + b

    @contextmanager
    def capture_stdout(logger):
        # Create a StringIO object
        string_io = StringIO()
        # Save the original logger stream
        original_stream = logger.handlers[0].stream
        # Replace the original stream with our StringIO object
        logger.handlers[0].stream = string_io
        try:
            yield string_io
        finally:
            # Close the StringIO instance
            string_io.close()
            # Set back the original stream


# Generated at 2022-06-24 01:52:20.154948
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hi") == "'hi'"
    assert format_arg("hi ") == "'hi'"
    assert format_arg(['hi']) == "['hi']"
    assert format_arg([1, 2]) == "[1, 2]"
    assert format_arg(['hi', ['hello']]) == "['hi', ['hello']]"
    assert format_arg(("hi", (1, ))) == "('hi', (1,))"
    assert format_arg(set()) == "set()"



# Generated at 2022-06-24 01:52:31.032293
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger_test = logging.Logger("test_logger", level=logging.DEBUG)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)
    stream_handler.setFormatter(logging.Formatter('%(levelname)s: %(name)s - %(message)s'))
    logger_test.addHandler(stream_handler)

    logged_function = LoggedFunction(logger_test)
    @logged_function
    def func_to_be_logged(arg1, arg2='kwarg1'):
        print(arg1, arg2)
    func_to_be_logged('arg1')


# Generated at 2022-06-24 01:52:40.555111
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError
    from unittest.mock import patch, call

    # init
    with patch.object(functools, "wraps", return_value=lambda x: x) as wraps:
        session = build_requests_session(raise_for_status=True, retry=3)

    # assertion
    wraps.assert_called_once()
    assert isinstance(session, Session)
    assert session.hooks["response"][0].__name__ == "logged_func"

    # raise_for_status only