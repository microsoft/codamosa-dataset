

# Generated at 2022-06-24 01:42:44.842714
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["http://"].max_retries.total == 5
    assert session.adapters["https://"].max_retries.total == 5
    session = build_requests_session(retry=False)
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters
    session = build_requests_session(retry=Retry(total=0))
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.total == 0
    session = build_requests_session(retry=1)
    assert session.adapters["http://"].max_retries.total == 1

# Generated at 2022-06-24 01:42:46.402482
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)


# Generated at 2022-06-24 01:42:56.972651
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger(f"{__name__}.test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logging.basicConfig(level=logging.DEBUG)

    logged_function = LoggedFunction(logger=logger)

    @logged_function
    def func1(arg1, arg2='c'):
        return arg1+arg2

    func1('a', 'b')

    @logged_function
    def func2():
        return 'a'

    func2()

    @logged_function
    def func3(*args, **kwargs):
        return 'a'

    func3('b', 'c')
    func3(arg1='a', arg2='b')



# Generated at 2022-06-24 01:43:04.928971
# Unit test for function build_requests_session
def test_build_requests_session():
    from freezegun import freeze_time
    import time
    import re
    from unittest.mock import Mock
    @LoggedFunction(logger=Mock())
    def func1():
        return 0

    assert func1.__name__ == 'func1'
    assert func1() == 0

    @LoggedFunction(logger=Mock())
    def func2(arg1):
        return arg1 + 1

    assert func2.__name__ == 'func2'
    assert func2(0) == 1

    @LoggedFunction(logger=Mock())
    def func3(arg1, arg2, kw1="def1", kw2="def2"):
        return arg1 + arg2 + kw1 + kw2

    assert func3.__name__ == 'func3'
   

# Generated at 2022-06-24 01:43:13.093911
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    import time

    def mocked_session(success, time_cost, status_code=200):
        class MockResponse:
            def __init__(self, success, time_cost, status_code):
                self.status_code = status_code
                if success:
                    self.ok = True
                else:
                    self.ok = False
                self.time_cost = time_cost

            def raise_for_status(self):
                if not self.ok:
                    raise Exception("Not 200")

        class MockedSession:
            def __init__(self, success, time_cost, status_code):
                self.success = success
                self.time_cost = time_cost
                self.status_code = status_code
                self.counter = 0


# Generated at 2022-06-24 01:43:14.612258
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(None)


# Generated at 2022-06-24 01:43:17.341148
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    # request by GET method
    session.get("https://httpbin.org/get")
    # request by POST method
    session.post("https://httpbin.org/post")

# Generated at 2022-06-24 01:43:22.027381
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    decorator = LoggedFunction(logger=logging.getLogger(__name__))

    @decorator
    def test_function(a: int, b: int) -> int:
        return a + b

    logging.basicConfig(level=logging.DEBUG)
    result = test_function(1, 2)
    assert result == 3

# Generated at 2022-06-24 01:43:28.016205
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None
    session = build_requests_session(retry=False)
    assert session is not None
    session = build_requests_session(retry=1)
    assert session is not None
    session = build_requests_session(retry=Retry(0))
    assert session is not None
    try:
        session = build_requests_session(retry=None)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-24 01:43:30.340200
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg("'") == "'\\''"
    assert format_arg("'\"") == "'\\'\"'"

# Generated at 2022-06-24 01:43:34.605465
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("test") == "'test'"
    assert format_arg(" test") == "' test'"
    assert format_arg("test ") == "'test '"



# Generated at 2022-06-24 01:43:41.874462
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    funcName = 'PrintTestFunction'
    def _func(self):
        print('Test printing')
    t_obj = LoggedFunction(self.logger)
    t_obj.__call__(_func)
    t_obj.logger.info(funcName + ' test passed!')

# Generated at 2022-06-24 01:43:49.819109
# Unit test for function format_arg
def test_format_arg():
    # Test int
    assert format_arg(1) == "1"
    assert format_arg(0) == "0"

    # Test float
    assert format_arg(1.0) == "1.0"
    assert format_arg(0.0) == "0.0"

    # Test str
    assert format_arg('hello " world') == "'hello \\\" world'"
    assert format_arg('') == "''"

    # Test others
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:43:59.371171
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__ + ".test_LoggedFunction___call__")

    @LoggedFunction(logger)
    def f1(x, y=1, *args):
        return x + y + sum(args)

    log_output = []

    def mock_log(msg, *args):
        log_output.append(msg)

    logger.debug = mock_log

    result = f1(1, 2, 3, 4, 5)
    assert result == sum(range(1, 6))
    assert log_output == [
        "f1('1', y='2', '3', '4', '5')",
        "f1 -> 15",
    ]

    log_output = []
    result = f1(1, y=123)
    assert result == 125
    assert log_

# Generated at 2022-06-24 01:44:05.753089
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc def") == "'abc def'"
    assert format_arg("abc'def") == "'abc''def'"

# Generated at 2022-06-24 01:44:13.908481
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("foo") == "'foo'"
    assert format_arg("foo   ") == "'foo'"
    assert format_arg(" foo   ") == "'foo'"
    assert format_arg("   foo   ") == "'foo'"
    assert format_arg("  'foo' ") == "'  'foo''"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(False) == "False"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:44:15.239071
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    log = logging.getLogger(__name__)
    
    xlist = [1,2]
    @LoggedFunction(log)
    def func(x,y):
        return x+y
    func(xlist[0],1)
    
test_LoggedFunction()

# Generated at 2022-06-24 01:44:26.256265
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    response = session.get("https://www.baidu.com")
    print(response.text)
    session = build_requests_session(retry=True)
    response = session.get("https://www.baidu.com")
    print(response.text)
    session = build_requests_session(retry=Retry(False))
    response = session.get("https://www.baidu.com")
    print(response.text)
    session = build_requests_session(retry=Retry(False))
    response = session.get("https://www.baidu.com")
    print(response.text)



# Generated at 2022-06-24 01:44:35.163081
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    retry = Retry(tenacity.wait.random_exponential(multiplier=1, max=10), 10)
    session = build_requests_session(retry=retry)
    session = build_requests_session(retry=2)

# Generated at 2022-06-24 01:44:46.973291
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from unittest.mock import Mock
    import logging
    import unittest.mock
    from argparse import ArgumentParser

    from dvbobjects.utils import LoggedFunction

    def my_mock_function():
        pass

    def my_mock_function_with_arguments(arg1, arg2):
        pass

    def my_mock_funciton_with_keyword_arguments(arg1="hello", arg2="world"):
        pass

    def my_mock_function_with_keyword_and_arguments(arg1, arg2="world"):
        pass

    def my_mock_function_with_keyword_and_arguments_returning_value():
        return "I'm returning something"


# Generated at 2022-06-24 01:44:49.128977
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("value") == "'value'"
    assert format_arg(123) == "123"



# Generated at 2022-06-24 01:44:55.419606
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pprint import pformat
    from logging import getLogger
    from test.utility import DummyLogger

    @LoggedFunction(logger=DummyLogger())
    def test_func(a, b, c=5):
        return (a * b) + c

    test_func.__name__ = "test_func"
    expected = "test_func({0}) -> {1}"

    # Test default argument
    assert test_func(3, 2) == 11
    assert test_func.__name__ == "test_func"
    assert pformat(test_func._logger.logs[-2]) == expected.format(
        "3, 2", test_func(3, 2)
    )
    assert test_func._logger.logs[-1] is None

    # Test named arguments


# Generated at 2022-06-24 01:45:02.095100
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import logging
    from contextlib import redirect_stdout

    # Test without return value
    output = io.StringIO()
    log = logging.getLogger("test_logger")
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(output))
    logged_func = LoggedFunction(log)

    def func(arg1, arg2, kwarg1=1, kwarg2=2):
        pass

    f = logged_func(func)
    with redirect_stdout(output):
        f("arg1", "arg2", kwarg1="kwarg1", kwarg2="kwarg2")

# Generated at 2022-06-24 01:45:11.952217
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger(__name__ + "test_LoggedFunction")
    logger.setLevel(logging.DEBUG)

    # log to the console.
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    def foo(a, b):
        return a + b

    logged_foo = LoggedFunction(logger)(foo)
    assert logged_foo(1, 2) == foo(1, 2)

# Generated at 2022-06-24 01:45:21.454993
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == 'None'
    assert format_arg(1) == '1'
    assert format_arg('') == "''"
    assert format_arg('h') == "'h'"
    assert format_arg('  h  ') == "'  h  '"
    assert format_arg([]) == '[]'
    assert format_arg(['a', 'b']) == "['a', 'b']"
    assert format_arg({}) == '{}'
    assert format_arg({'a': 1}) == "{'a': 1}"
    assert format_arg({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-24 01:45:26.892497
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger

    logger = getLogger()
    logger.debug("test")
    logger.debug("test2", "test3")
    lf = LoggedFunction(logger)
    assert lf.logger == logger

    @lf
    def test_func(x, y):
        return x + y


    assert test_func(1, 2) == 3


if __name__ == "__main__":
    test_LoggedFunction()

# Generated at 2022-06-24 01:45:34.729498
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)

    f = LoggedFunction(logger)

    @f
    def func(*args, **kwargs):
        logger.critical('critical')
        logger.error('error')
        logger.warning('warning')
        logger.info('info')
        logger.debug('debug')
        return "test"

    func('test1', 'test2', test3='test3', test4='test4')
    assert "test" == func.__doc__
    assert "func" == func.__name__
    assert len(logger.handlers) == 1

    class Test:
        def __init__(self, arg):
            self.arg = arg

        def __eq__(self, other):
            return self.arg == other.arg


# Generated at 2022-06-24 01:45:37.994488
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    lf = LoggedFunction(logger)
    
    def test_func(a: str, b: int):
        return a * b

    assert lf(test_func)("a", 3) == "aaa"

# Generated at 2022-06-24 01:45:47.759793
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from tests.unit.fixtures import mock_logging_configured
    import logging

    (real_logging_configured, logging_configured) = mock_logging_configured()
    real_logging_configured()
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    def inner_func(x, y=1):
        return x * y

    logged_inner_func = LoggedFunction(log)(inner_func)
    assert logged_inner_func(2) == 2
    logged_inner_func(2, 3)
    logged_inner_func(x=2, y=2)

# Generated at 2022-06-24 01:45:50.517211
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction

    """
    pass

# Generated at 2022-06-24 01:45:54.202471
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)
    assert isinstance(build_requests_session(raise_for_status=False), Session)
    assert isinstance(build_requests_session(retry=False), Session)
    assert isinstance(build_requests_session(retry=10), Session)



# Generated at 2022-06-24 01:46:04.905782
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    logger = logging.getLogger(__name__)

    log_entries = []

    class LogCapture(logging.Handler):
        def emit(self, record):
            log_entries.append(record)

    log_capture = LogCapture()
    logger.addHandler(log_capture)

    class TestLoggedFunction(unittest.TestCase):
        def test_multiple_arguments(self):
            def sample_function(a, b, c="Test"):
                pass

            sample_function = LoggedFunction(logger)(sample_function)
            sample_function(1, 2, 3)
            self.assertEqual(
                log_entries[0].getMessage(), "sample_function(1, 2, 3)"
            )


# Generated at 2022-06-24 01:46:15.217807
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)
    assert isinstance(
        build_requests_session(retry=False), Session
    )  # retry=False, do not add retry request adapter
    assert isinstance(
        build_requests_session(retry=True), Session
    )  # retry=True, add retry request adapter with default configuration
    assert isinstance(
        build_requests_session(retry=Retry(total=3)), Session
    )  # add retry request adapter with given configuration
    assert isinstance(build_requests_session(raise_for_status=False), Session)  # do not raise for status

# Generated at 2022-06-24 01:46:17.656734
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("test") == "'test'"
    assert format_arg(" test ") == "' test '"


# Generated at 2022-06-24 01:46:21.018500
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(12) == "12"
    assert format_arg("12") == "'12'"
    assert format_arg("  12  ") == "'  12  '"

# Generated at 2022-06-24 01:46:25.574607
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger

    logger = getLogger("foo")
    log_func = LoggedFunction(logger)
    assert log_func.logger == logger



# Generated at 2022-06-24 01:46:27.149562
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    Linear = LoggedFunction()

# Generated at 2022-06-24 01:46:29.190407
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    logger = MagicMock()
  

# Generated at 2022-06-24 01:46:35.761886
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Detect if python3.7 or later
    if sys.version_info[1] >= 7:
        # Error: Class LoggedFunction cannot be used as a decorator
        assert False
    else:
        # Success: Class LoggedFunction could be used as a decorator
        assert True


# Generated at 2022-06-24 01:46:46.381365
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import sys
    import io

    # create a container for captured output
    output = io.StringIO()
    sys.stdout = output

    # Create and execute a LoggedFunction
    from logging import StreamHandler, Formatter, DEBUG, getLogger
    from logging.handlers import RotatingFileHandler

    log_format = "%(levelname)s %(message)s"
    logging.getLogger().setLevel(DEBUG)
    log_handler = StreamHandler()
    log_handler.setFormatter(Formatter(log_format))
    logging.getLogger().addHandler(log_handler)

    # Create and execute a LoggedFunction
    @LoggedFunction(logger)
    def hello(name):
        return f"hello {name}"

    my_name = "Jeff"
    result = hello(my_name)

# Generated at 2022-06-24 01:46:47.942462
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None
    session = build_requests_session(3)
    assert session is not None

# Generated at 2022-06-24 01:46:58.094111
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import mock
    import logging

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = mock.Mock()
            self.logger.debug = mock.Mock()

            self.func = mock.Mock()
            self.func.__name__ = "UNIT_TEST"

        def test_args_not_kwargs(self):
            @LoggedFunction(self.logger)
            def test_func():
                pass

            test_func()
            self.logger.debug.assert_called_once_with("UNIT_TEST()")
            self.func.assert_called_once_with()


# Generated at 2022-06-24 01:47:07.240600
# Unit test for function build_requests_session
def test_build_requests_session():
    # case 1
    s = build_requests_session()
    assert s.hooks['response'] == [lambda r, *args, **kwargs: r.raise_for_status()]
    assert isinstance(s.adapters['https://'], HTTPAdapter)
    # case 2
    s = build_requests_session(raise_for_status=False)
    assert s.hooks['response'] == []
    assert isinstance(s.adapters['https://'], HTTPAdapter)
    # case 3
    s = build_requests_session(retry=False)
    assert s.hooks['response'] == [lambda r, *args, **kwargs: r.raise_for_status()]
    try:
        s.adapters['https://']
        assert False
    except KeyError:
        pass

   

# Generated at 2022-06-24 01:47:16.876415
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test default value
    session = build_requests_session()
    assert session.hooks == {}
    assert str(session.adapters.get("http://").max_retries) == str(Retry())
    assert str(session.adapters.get("https://").max_retries) == str(Retry())

    # Test raise_for_status=True
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {
        "response": [lambda r, *args, **kwargs: r.raise_for_status()]
    }
    assert str(session.adapters.get("http://").max_retries) == str(Retry())
    assert str(session.adapters.get("https://").max_retries) == str(Retry())

    #

# Generated at 2022-06-24 01:47:25.918616
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.max_retries.total == 10
    assert session.max_retries.backoff_factor == 0.3
    assert session.max_retries.status_forcelist == frozenset(
        [500, 502, 503, 504]
    )
    assert session.max_retries.raise_on_status == False
    assert len(session.hooks["response"]) == 0

    session = build_requests_session(True)
    assert session.max_retries.total == 10
    assert session.max_retries.backoff_factor == 0.3
    assert session.max_retries.status_forcelist == frozenset(
        [500, 502, 503, 504]
    )

# Generated at 2022-06-24 01:47:31.728798
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    session = build_requests_session()
    assert isinstance(session, requests.Session)
    assert len(session.hooks["response"]) == 0
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries == Retry()
    assert session.adapters["https://"].max_retries == Retry()

    session = build_requests_session(retry=False)
    assert len(session.adapters) == 0

    session = build_requests_session(retry=7)
    assert session.adapters["http://"].max_retries._max_retries == 7
    assert session.adapters["https://"].max_retries._max_retries == 7

# Generated at 2022-06-24 01:47:40.268720
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Mock()
    tester = LoggedFunction(logger)
    assert tester.__call__ == tester.__call__

    # test log when raise Exception in the function
    def test_func_raise(a, b=None):
        raise Exception("test exception")

    decorated_test_func_raise = tester(test_func_raise)
    assert decorated_test_func_raise
    with pytest.raises(Exception) as e:
        decorated_test_func_raise(1)
    actual = str(e.value)
    expected = "test exception"
    assert actual == expected

    # test log when no argument
    def test_func_no_arg():
        return "test"

    decorated_test_func_no_arg = tester(test_func_no_arg)
    assert decorated_test

# Generated at 2022-06-24 01:47:51.086431
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from flask import Flask, logging

    # Create app
    app = Flask(__name__)
    app.config["TESTING"] = True

    # Add a logger
    app.logger.setLevel(logging.DEBUG)

    # Add a hello route
    @app.route("/hello")
    @LoggedFunction(app.logger)
    def hello_world(name):
        return f"Hello, {name}!"

    # Test the route
    with app.test_client() as client:
        response = client.get("/hello?name=world")
        assert response.status_code == 200
        assert response.data == b"Hello, world!"

    # Test the logger

# Generated at 2022-06-24 01:47:51.990019
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

# Generated at 2022-06-24 01:47:58.381538
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create test handler
    handler = logging.StreamHandler(StringIO())
    handler.setFormatter(logging.Formatter("%(message)s"))
    handler.setLevel(logging.DEBUG)

    # Create test logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Create a logging decorator
    logged = LoggedFunction(logger)

    # Create a test class
    class Test:
        def __init__(self):
            self.value = 42

        @logged
        def test(self, a, b):
            return a * b

        def ignore(self):
            return 100

    # Create a test instance
    test = Test()

    # Test function call
    assert test

# Generated at 2022-06-24 01:48:05.456984
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.debug("start logging")
    lf = LoggedFunction(logger)
    assert lf is not None
    assert lf.logger is not None
    assert lf.logger.name == __name__


# Generated at 2022-06-24 01:48:10.134707
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    assert logger
    logger.disabled = True
    logfunc = LoggedFunction(logger)
    assert isinstance(logfunc, LoggedFunction)



# Generated at 2022-06-24 01:48:13.633297
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == "5"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc ") == "'abc '"


# Generated at 2022-06-24 01:48:21.403639
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)

    assert(
        str(session.mount("https://", None).max_retries)
        == str(Retry())
    )
    assert(session.hooks["response"][0] == Session.raise_for_status)

    session = build_requests_session(raise_for_status=False, retry=True)

    assert(
        str(session.mount("https://", None).max_retries)
        == str(Retry())
    )
    assert(session.hooks == {})

    session = build_requests_session(raise_for_status=True, retry=False)

    # Session does not contain retry configuration
    assert(session.mount("https://", None) == None)
   

# Generated at 2022-06-24 01:48:26.764333
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(raise_for_status=False)
    requests_session.get("https://www.baidu.com")

# Generated at 2022-06-24 01:48:36.241565
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    headers = {}

# Generated at 2022-06-24 01:48:40.693957
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("my name") == "'my name'"
    assert format_arg(123) == "123"



# Generated at 2022-06-24 01:48:45.842283
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)
    assert session.hooks
    assert session.adapters

# Generated at 2022-06-24 01:48:47.610761
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert isinstance(LoggedFunction(None), LoggedFunction)

# Generated at 2022-06-24 01:48:58.021665
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from logging import Logger

    #
    # Test arguments
    #

    # Mock function
    func = Mock()
    func.__name__ = "func"
    func.__qualname__ = "func"
    func.__doc__ = None
    func.__annotations__ = {}
    func.__kwdefaults__ = None
    func.__defaults__ = None
    func.__code__ = None
    func.__globals__ = {}
    func.__closure__ = None
    func.__dict__ = {}

    # Mock logger
    logger = Mock(spec=Logger)

    #
    # Test scenarios
    #

    # Scenario 1: Function which completes
    func.return_value = "result"

# Generated at 2022-06-24 01:49:04.323720
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg(" test ") == "' test '"
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"

# Generated at 2022-06-24 01:49:09.459027
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("hello") == "'hello'"
    assert format_arg(None) == "None"
    assert format_arg("a") == "'a'"
    assert format_arg("2") == "'2'"

# Generated at 2022-06-24 01:49:14.872753
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    Verify that build_requests_session works as expected
    """
    session: Session
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters == {"https://": HTTPAdapter(max_retries=Retry(total=0)), "http://": HTTPAdapter(max_retries=Retry(total=0))}
    session = build_requests_session(True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.adapters == {"https://": HTTPAdapter(max_retries=Retry(total=0)), "http://": HTTPAdapter(max_retries=Retry(total=0))}
    session = build_requests_session(False, True)

# Generated at 2022-06-24 01:49:25.767511
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("tester")
    @LoggedFunction(logger)
    def tester(x):
        return x

    tester("hello") # should log "hello"
    tester("hello", "world") # should log "hello, world"
    tester(hello="there") # should log "hello=there"
    tester("hello", world="there") # should log "hello, world=there"
    tester(hello=["a", "list"]) # should log "hello=a, list"
    tester(hello={"a", "set"}) # should log "hello=a, set"
    tester(hello={"a": "dict"}) # should log "hello=a, dict"

# Generated at 2022-06-24 01:49:31.328220
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s, Session)
    s = build_requests_session(retry=3)
    assert isinstance(s, Session)
    s = build_requests_session(retry=Retry(1))
    assert isinstance(s, Session)
    try:
        s = build_requests_session(retry="x")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 01:49:40.924736
# Unit test for function build_requests_session
def test_build_requests_session():
    # noinspection PyPackageRequirements
    session = build_requests_session(raise_for_status=False)
    session.get('https://httpbin.org/status/404')
    session.get('https://httpbin.org/status/404')
    session.get('https://httpbin.org/status/404')

    # noinspection PyPackageRequirements
    session = build_requests_session(raise_for_status=True)
    try:
        session.get('https://httpbin.org/status/404')
        raise AssertionError("raise_for_status=True should raise exception.")
    except Exception:
        pass

    # noinspection PyPackageRequirements
    session = build_requests_session(retry=False)

# Generated at 2022-06-24 01:49:43.844419
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    log = logging.getLogger()
    log.debug("Test")
    log.debug("Test")
    log.debug("Test")
    log.debug("Test")
    log.debug("Test")

# Generated at 2022-06-24 01:49:46.248574
# Unit test for function build_requests_session
def test_build_requests_session():
    """Test case for function build_requests_session"""
    assert (
        build_requests_session().__class__ == Session
    ), "build_requests_session should return a session"

# Generated at 2022-06-24 01:49:51.260874
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("hello") == "'hello'"
    assert format_arg("  'hello'  ") == "'  'hello'  '"
    assert format_arg("  hello  ") == "'  hello  '"

# Generated at 2022-06-24 01:49:54.862287
# Unit test for function format_arg
def test_format_arg():
    s = format_arg('string')
    assert s == "'string'"
    n = format_arg(987654321)
    assert n == '987654321'
    assert format_arg(True) == 'True'

# Generated at 2022-06-24 01:50:06.630921
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError

    # noop
    assert build_requests_session()

    # default Retry
    assert build_requests_session(retry=True)

    # Retry with given retry count
    assert build_requests_session(retry=1)
    assert build_requests_session(retry=10)

    # Retry with given Retry instance
    assert build_requests_session(retry=Retry())

    # raise_for_status
    with pytest.raises(HTTPError):
        build_requests_session(raise_for_status=True).get("http://httpbin.org/status/500")

    # error for retry argument
    with pytest.raises(ValueError):
        build_requests_session(retry="0")

# Generated at 2022-06-24 01:50:16.614223
# Unit test for function build_requests_session
def test_build_requests_session():
    import logging
    import time
    print("Test function build_requests_session:")
    with build_requests_session(retry=Retry(total=5, backoff_factor=1), raise_for_status=True) as sess:
        def callback(response, *args, **kwargs):
            print(response.headers)

# Generated at 2022-06-24 01:50:19.977847
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class MyLogger():
        def debug(self, msg):
            print(msg)

    my_logger = MyLogger()
    logged_func = LoggedFunction(my_logger)
    logged_func("Test")

if __name__ == "__main__":
    test_LoggedFunction()

# Generated at 2022-06-24 01:50:22.263165
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('abc') == "'abc'"
    assert format_arg(123) == "123"
    assert format_arg([]) == "[]"
    assert format_arg(1.23) == "1.23"

# Generated at 2022-06-24 01:50:24.315930
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(10)
    logged_func = LoggedFunction(logger)(log)
    logged_func(100)

# Generated at 2022-06-24 01:50:32.745688
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("a") == "'a'"
    assert format_arg("") == "''"
    assert format_arg("'") == "'''"
    assert format_arg("'abc") == "'''abc'"
    assert format_arg(" 'abc") == " ''abc'"
    assert format_arg("abc'") == "'abc'''"
    assert format_arg(" abc'") == " 'abc'''"



# Generated at 2022-06-24 01:50:43.104780
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=False)
    response = session.get("https://httpbin.org/get")
    assert response.status_code == 200

    session = build_requests_session(raise_for_status=True)
    try:
        session.get("https://httpbin.org/status/400")
    except Exception as e:
        assert "400 Client Error" in str(e)
        assert "HTTPStatusException" in str(e)
    else:
        assert False

    # Test retry = True
    session = build_requests_session(raise_for_status=True, retry=True)
    response = session.get("https://httpbin.org/status/400")
    assert response.status_code == 400

    # Test retry = an integer
    session

# Generated at 2022-06-24 01:50:54.184231
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import tempfile
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s - %(filename)s[line:%(lineno)d] - "
            "%(levelname)s: %(message)s",
            datefmt="%a, %d %b %Y %H:%M:%S",
            filename=f.name,
            filemode="w",
        )
        logger = logging.getLogger("test")
        func = LoggedFunction(logger=logger)

        @func
        def test_function(a, b, c=1):
            return a + b + c


# Generated at 2022-06-24 01:50:58.703847
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import logging

    LOGGER = logging.getLogger()
    LOGGER.setLevel(logging.DEBUG)
    LOGGER.handlers = [logging.StreamHandler(io.StringIO())]

    @LoggedFunction(LOGGER)
    def a_function(input_argument: str) -> str:
        return input_argument

    a_function("test")



# Generated at 2022-06-24 01:51:02.351910
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest

    from unittest.mock import MagicMock

    from buildscripts.util import LoggedFunction

    mock_logger = MagicMock()

    @LoggedFunction(mock_logger)
    def foo(a, b, c):
        return "abc"

    # call the decorated func and check the output
    foo(1, 2, 3)
    mock_logger.debug.assert_any_call("foo(1, 2, 3)")
    mock_logger.debug.assert_any_call("foo -> abc")

    # confirm we logged as many as we expected
    assert mock_logger.debug.call_count == 2



# Generated at 2022-06-24 01:51:13.278887
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import pytest
    import logging
    import io
    import sys

    def a(x, y):
        return x + y

    class MyLogger:
        def debug(self, *args, **kwargs):
            pass

    def rm_whitespaces(s):
        return s.replace(" ", "").replace("\n", "")

    # Test Legit
    test_stream = io.StringIO()
    sys.stderr = test_stream
    logger = MyLogger()
    logged_f = LoggedFunction(logger)
    assert rm_whitespaces(logged_f.__call__(a)(1, 2)) == rm_whitespaces("a(1,2)")
    assert rm_whitespaces(test_stream.getvalue()) == rm_whitespaces("Not_None")

    #

# Generated at 2022-06-24 01:51:22.613250
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == "5"
    assert format_arg(0) == "0"
    assert format_arg(-5) == "-5"
    assert format_arg(-1.1) == "-1.1"
    assert format_arg(1.1) == "1.1"
    assert format_arg("abc") == "'abc'"
    assert format_arg("bcd ") == "'bcd '"
    assert format_arg("   ") == "'   '"
    assert format_arg(" a b c ") == "' a b c '"



# Generated at 2022-06-24 01:51:25.622050
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    logger = logging.getLogger("test")
    logfunc = LoggedFunction(logger)
    
    def test_func():
        pass

    logfunc(test_func)


# A class to store the information of a single staff.

# Generated at 2022-06-24 01:51:28.485073
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("A string") == "'A string'"
    assert format_arg(42) == "42"



# Generated at 2022-06-24 01:51:33.258373
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_logger = logging.getLogger(__name__)
    logged_function = LoggedFunction(test_logger)
    @logged_function
    def test_function(*args, **kwargs):
        return None
    test_function(1, 2, 3)
    test_function(1, 2, 3, a=1, b=2, c="string")
    test_function(a=1, b=2, c="string")

# Generated at 2022-06-24 01:51:40.313682
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock
    import logging

    # Setup logger to be used in the test
    logger_mock = MagicMock()
    logger = logging.getLogger("LoggedFunction")
    logger.addHandler(logger_mock)

    # Setup test function which should be logged
    def test_func(a, b=1, c=None):
        return a + b

    # Setup decorated function
    decorated_func = LoggedFunction(logger)(test_func)

    # Call decorated function
    decorated_func(1, b=2, c=3)

    # Check if logger was called with correct parameters
    calls = logger_mock.debug.call_args_list
    assert calls[0][0][0] == "test_func(1, b=2, c=3)"

# Generated at 2022-06-24 01:51:45.378295
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.mounts["https://"][0].max_retries.total == 1
    assert session.mounts["http://"][0].max_retries.total == 1
    assert "response" not in session.hooks

    session = build_requests_session(False)
    assert session.mounts["https://"][0].max_retries.total == 1
    assert session.mounts["http://"][0].max_retries.total == 1
    assert "response" not in session.hooks

    session = build_requests_session(True)
    assert session.mounts["https://"][0].max_retries.total == 1
    assert session.mounts["http://"][0].max_retries.total == 1

# Generated at 2022-06-24 01:51:50.940856
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s", "%Y-%m-%d %H:%M:%S"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    test_class = LoggedFunction(logger)

    # Act
    result = test_class.__call__(lambda a, b: a + b)(1, b=2)

    # Assert
    assert result == 3



# Generated at 2022-06-24 01:51:56.009772
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    lf = LoggedFunction(print)

    def f(s):
        return s

    def g(s, t):
        return s

    def h(s, t, v):
        pass

    def k(s: str, t: str, v: str):
        pass

    def m(s=1, t=2, v=3):
        pass

    lf(f)
    lf(g)
    lf(h)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:52:07.981278
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.level = 0
            self.debugs = []
            self.infos = []
            self.warnings = []
            self.errors = []
            self.criticales = []

        def debug(self, msg):
            self.debugs.append(msg)

        def info(self, msg):
            self.infos.append(msg)
    
        def warning(self, msg):
            self.warnings.append(msg)
    
        def error(self, msg):
            self.errors.append(msg)
    
        def critical(self, msg):
            self.criticales.append(msg)

    def test_function(x: str, y: int = 2, *args, **kwargs):
        return x

    logger = Logger

# Generated at 2022-06-24 01:52:13.257341
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(0) == "0"
    assert format_arg("a") == "'a'"
    assert format_arg("a'b") == "'a'b'"

# Generated at 2022-06-24 01:52:24.803255
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import sys

    class LoggedFunctionTestCase(unittest.TestCase):
        def test_call_function_with_return(self):
            @LoggedFunction(logging.getLogger("test_call_function_with_return"))
            def func(a, b, c="foo"):
                return "bar"

            with Capturing() as output:
                func(1, 2, 3)

            self.assertEqual(
                output,
                [
                    "test_call_function_with_return DEBUG: func(1, 2, 3)",
                    "test_call_function_with_return DEBUG: func -> bar",
                ],
            )


# Generated at 2022-06-24 01:52:26.368121
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" a string ") == "'a string'"
    assert format_arg(123) == "123"

# Generated at 2022-06-24 01:52:36.568125
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import os
    import tempfile

    my_logger = logging.getLogger()
    log_stream = logging.StreamHandler()
    log_stream.setFormatter(logging.Formatter('%(levelname).1s %(message)s'))
    my_logger.addHandler(log_stream)
    temp_dir = tempfile.gettempdir()
    temp_filename = os.path.join(temp_dir, 'tmp_file.txt')
    log_file = logging.FileHandler(temp_filename)
    log_file.setFormatter(logging.Formatter('%(levelname).1s %(message)s'))
    my_logger.addHandler(log_file)
    my_logger.setLevel(logging.DEBUG)
