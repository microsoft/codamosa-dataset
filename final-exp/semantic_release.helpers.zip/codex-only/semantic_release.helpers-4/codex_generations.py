

# Generated at 2022-06-24 01:42:41.330171
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = object()
    assert logger == LoggedFunction(logger)(lambda x: None).logger


# Generated at 2022-06-24 01:42:51.902396
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import unittest
    import logging
    import datetime

    filename = 'log.txt'

    def init_logging(filename):
        # Set up logging
        root = logging.getLogger()
        root.setLevel(logging.DEBUG)

        handler = logging.FileHandler(filename=filename)
        handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter("%(asctime)s: %(levelname)s: %(message)s")
        handler.setFormatter(formatter)
        root.addHandler(handler)



# Generated at 2022-06-24 01:42:57.170703
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock

    logger = unittest.mock.MagicMock()
    logged_function = LoggedFunction(logger)
    func = unittest.mock.MagicMock()

    # Test no args, no kwargs
    func.__name__ = "test_func_no_args_no_kwargs"
    func.return_value = "test_result_no_args_no_kwargs"
    logged_func = logged_function(func)
    assert logged_func() == "test_result_no_args_no_kwargs"
    logger.debug.assert_called_once_with(
        "test_func_no_args_no_kwargs()"
    )

# Generated at 2022-06-24 01:43:01.934990
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class LoggedFunctionTest:
        @LoggedFunction(logger=None)
        def test(self, a, b, c=None):
            return a + b + c
    instance = LoggedFunctionTest() # type: LoggedFunctionTest
    assert instance.test(1, 2) == 3
    assert instance.test(1, 2, c=3) == 6
    assert instance.test(3, 4, c=5) == 12


# Generated at 2022-06-24 01:43:10.856831
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from StringIO import StringIO
    from logging import getLogger, StreamHandler, DEBUG

    logger = getLogger("test")
    logger.setLevel(DEBUG)
    # We send logging to a stringio instance, so we can assert it's content later
    logger.addHandler(StreamHandler(StringIO()))
    logger.info('TestInfo')
    logger.warning('TestWarning')
    logger.error('TestError')
    logger.critical('TestCritical')

    # The returned object is called 'handler' in the logging module
    string_io = logger.handlers[0].stream

    logger.debug('TestDebug')

    # The returned object is a io object
    assert string_io.getvalue() == 'TestDebug', 'Wrong output from logging'

# Generated at 2022-06-24 01:43:15.941261
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()

    def get_func():
        def f(x, y=1):
            return x + y
        return f

    f = LoggedFunction(logger)
    f = f(get_func())

    f(1) # x == 1
    f(1, 2) # y == 2


# Generated at 2022-06-24 01:43:23.659779
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("   ") == "'   '"
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg([]) == "[]"

# Generated at 2022-06-24 01:43:27.944914
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class FooLogger(object):

        def debug(self, string):
            print(string)

    foo_logger = FooLogger()
    logged_function = LoggedFunction(foo_logger)
    assert id(foo_logger) == id(logged_function.logger)
    assert logged_function == logged_function.__call__


# Generated at 2022-06-24 01:43:35.291448
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=10)
    assert session.mounts["http://"][0].max_retries.total == 10
    assert session.mounts["https://"][0].max_retries.total == 10

    session = build_requests_session()
    assert session.mounts["http://"][0].max_retries.total == 3
    assert session.mounts["https://"][0].max_retries.total == 3

# Generated at 2022-06-24 01:43:42.706382
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(123456) == "123456"
    assert format_arg(12.345) == "12.345"
    assert format_arg("a") == "'a'"
    assert format_arg("a   ") == "'a'"
    assert format_arg("a b c") == "'a b c'"

# Generated at 2022-06-24 01:43:50.406083
# Unit test for function build_requests_session
def test_build_requests_session():
    from vws import VWS, cloud_path
    session = build_requests_session()
    vws_client = VWS(
        server_access_key=cloud_path("tests/server_access_key.txt"),
        server_secret_key=cloud_path("tests/server_secret_key.txt"),
        session=session,
    )
    target_id = vws_client.add_target(
        name="name", width=1, image="", active_flag=True, application_metadata="",
    )

# Generated at 2022-06-24 01:43:55.464771
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class MyLogger:
        def debug(self, msg):
            pass

    def my_function():
        pass

    x = LoggedFunction(MyLogger())

    assert isinstance(x, LoggedFunction)

    my_function = x(my_function)
    assert my_function.__name__ == "my_function"

# Generated at 2022-06-24 01:44:04.814900
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session
    assert type(build_requests_session(False)) == Session
    assert type(build_requests_session(True)) == Session
    assert type(build_requests_session(retry=False)) == Session
    assert type(build_requests_session(retry=True)) == Session
    assert type(build_requests_session(retry=3)) == Session
    try:
        build_requests_session(retry=Retry())
        build_requests_session(retry="test")
        assert False, "test above should throw exception."
    except ValueError:
        pass

# Generated at 2022-06-24 01:44:07.793841
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.4) == "1.4"
    assert format_arg("hello world") == "'hello world'"
    assert format_arg("'") == "''"


# Generated at 2022-06-24 01:44:16.973146
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test")
    handler = logging.FileHandler("test_LoggedFunction.log", mode="w")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    dec = LoggedFunction(logger)
    @dec
    def foo(x, y, z="123"):
        return (x + y) * z
    foo(1,2,3)
    foo(1,2)
    foo(x=1, y=2, z=3)
    foo(y=2, x=1, z=3)
    foo(y=2, x=1)
    foo(1, 2, z="123")

# Generated at 2022-06-24 01:44:23.186778
# Unit test for function build_requests_session
def test_build_requests_session():
    # test default request session
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks == {}
    assert len(session.adapters) == 2
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    # test session with raise for status
    session = build_requests_session(raise_for_status=True)
    assert session.hooks["response"][0](None) is None
    # test session with retry=True
    session = build_requests_session(retry=True)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

# Generated at 2022-06-24 01:44:25.534837
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert type(s) is Session

# Generated at 2022-06-24 01:44:31.915180
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    # create the logger (root)
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    # add the handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)

    # create an instance of the decorator
    logger = logging.getLogger(__name__)
    decorator = LoggedFunction(logger)

    # apply the decorator to the function

# Generated at 2022-06-24 01:44:43.626532
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session()
    assert isinstance(requests_session, Session)
    assert isinstance(requests_session.adapters["http://"], HTTPAdapter)
    assert isinstance(requests_session.adapters["https://"], HTTPAdapter)
    assert isinstance(requests_session.adapters["http://"].max_retries, Retry)
    assert isinstance(requests_session.adapters["https://"].max_retries, Retry)
    assert requests_session.hooks == {}

    requests_session = build_requests_session(raise_for_status=True)
    assert requests_session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}


# Generated at 2022-06-24 01:44:53.530412
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Note that this is not a traditional unit test in the sense that no assertions are made, but it is still a useful
    # test as it is run automatically as part of the development cycle and will therefore prevent us from breaking
    # logged functions.
    from unittest.mock import Mock

    logger = Mock()
    logged_function = LoggedFunction(logger)

    # Call test function with no arguments
    @logged_function
    def nothing():
        pass

    nothing()
    logger.debug.assert_called_with("nothing()")

    # Call test function with int and string
    @logged_function
    def int_and_string(x: int, y: str):
        return x + len(y)

    assert int_and_string(3, "something") == 8

# Generated at 2022-06-24 01:45:03.456413
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # initialize the logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    # feed in the logger to the constructor of LoggedFunction
    logged_function = LoggedFunction(logger)
    # initialize a function
    def func(arg1, arg2):
        return arg1 + arg2
    # call the logged function
    logged_function(func)(1, 2)
    # function is called with proper argument, and the return value is logged.


# Generated at 2022-06-24 01:45:14.371842
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()

    # Case 1
    assert isinstance(s, Session) is True

    # Case 2
    s_2 = build_requests_session(retry=False)
    assert s_2.adapters == {}

    # Case 3
    s_3 = build_requests_session(retry=True)
    assert isinstance(s_3.adapters["http://"], HTTPAdapter)
    assert isinstance(s_3.adapters["http://"].max_retries, Retry)
    assert isinstance(s_3.adapters["https://"], HTTPAdapter)
    assert isinstance(s_3.adapters["https://"].max_retries, Retry)

    # Case 4
    s_4 = build_requests_session(retry=1)

# Generated at 2022-06-24 01:45:25.701873
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    import logging
    import sys

    def my_func():
        return "Hello World!"

    # Redirect stdout to a string in memory so that debug messages are not
    # displayed
    std_out = sys.stdout
    capture = StringIO()
    sys.stdout = capture

    logger = logging.getLogger("test")
    logged_func = LoggedFunction(logger)
    logged_func(my_func)()

    # Restore stdout and retrieve the logged text
    sys.stdout = std_out
    logged_text = capture.getvalue()

    # The logged text should show the function name, its arguments and its
    # return value
    assert logged_text == f"DEBUG:test:my_func()\nDEBUG:test:my_func -> Hello World!\n"

# Generated at 2022-06-24 01:45:28.558489
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(12) == "12"
    assert format_arg(12.01) == "12.01"
    assert format_arg("A string") == "'A string'"

# Generated at 2022-06-24 01:45:37.033041
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Logger("logger")
    def func(arg1, arg2):
        pass
    logged_function = LoggedFunction(logger)
    logged_func = logged_function.__call__(func)
    assert logged_func is not None
    assert logged_func is not func
    assert logged_func.__name__ == func.__name__
    assert logged_func.__doc__ == func.__doc__
    assert logged_func.__annotations__ == func.__annotations__
    assert "logger.debug" in logged_func.__code__.co_code
    assert "func(" in logged_func.__code__.co_code
    assert logged_func(1, 2) is None

# Generated at 2022-06-24 01:45:39.743495
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc ") == "'abc '"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:45:46.269217
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Hello World") == "'Hello World'"
    assert format_arg("") == "''"
    assert format_arg(123) == "123"
    assert format_arg(1.23) == "1.23"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"

# Generated at 2022-06-24 01:45:51.518786
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def f(a, b, c=1):
        return a + b + c

    assert f(1, 2) == 4

# Generated at 2022-06-24 01:45:56.505811
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("string") == "'string'"
    assert format_arg(1) == "1"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:46:07.232533
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import logging.handlers
    fh = logging.handlers.RotatingFileHandler('test.log', maxBytes=2000, backupCount=5)
    fh.setLevel(logging.DEBUG)
    logger = logging.getLogger('test')
    logger.addHandler(fh)
    @LoggedFunction(logger)
    def func(arg1, arg2=None, *args, kwarg1=None, **kwargs):
        pass
    func(1, 2)
    func(1, 2, 3)
    func(1, kwarg1=2)
    func(arg1=1, arg2=2, arg3=3)
    func(arg1=1, arg2=2, arg3=3, kwarg1=2)
    func()

# Generated at 2022-06-24 01:46:11.009299
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.Logger(name="logger", level=logging.INFO)
    logged_function = LoggedFunction(logger)
    assert logged_function.logger == logger


# Generated at 2022-06-24 01:46:21.840500
# Unit test for function build_requests_session
def test_build_requests_session():
    # test 1, raise_for_status=True, retry=True
    session = build_requests_session()
    assert session.hooks["response"][0] == (lambda r, *args, **kwargs: r.raise_for_status())
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    # test 2, raise_for_status=True, retry=3
    session = build_requests_session(retry=3)
    assert session.hooks["response"][0] == (lambda r, *args, **kwargs: r.raise_for_status())
    assert isinstance(session.adapters["http://"].max_retries, Retry)
   

# Generated at 2022-06-24 01:46:26.254378
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class myClass:
        def __init__(self):
            self.logger = "logger"
    obj = myClass()
    attr = LoggedFunction(obj.logger)
    assert attr != None


# Generated at 2022-06-24 01:46:35.624989
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert len(session.adapters["http://"].max_retries.total) == 10
    assert len(session.adapters["https://"].max_retries.total) == 10
    
    session = build_requests_session(retry=True)
    assert isinstance(session, Session)
    assert len(session.adapters["http://"].max_retries.total) == 10
    assert len(session.adapters["https://"].max_retries.total) == 10

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert "max_retries" not in session.adapters["http://"].__dict__

# Generated at 2022-06-24 01:46:46.296812
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    class Logger:
        def __init__(self):
            self._log_stream = StringIO()
            self._logger = logging.getLogger(self.__class__.__name__)
            self._logger.setLevel(level=logging.DEBUG)
            handler = logging.StreamHandler(self._log_stream)
            handler.setLevel(logging.DEBUG)
            formatter = logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            )
            handler.setFormatter(formatter)
            self._logger.addHandler(handler)

        def debug(self, msg):
            self._logger.debug(msg)


# Generated at 2022-06-24 01:46:52.564694
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pyhap.logger import get_logger
    from pyhap.util import LoggedFunction

    logger = get_logger('test')
    func = LoggedFunction(logger)
    f = func(print)
    f('hello')


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:47:00.096732
# Unit test for function build_requests_session
def test_build_requests_session():
    from soteris_client.client import SoterisClient
    from soteris_client.auth import TokenAuth
    from soteris_client.config import BASE_URL

    requests_session = build_requests_session(False, True)
    token_auth = TokenAuth("BJq3rZrYQ2WuvlnemzIbVMJXFyRygx8W")
    client = SoterisClient("http://localhost:8282", token_auth, requests_session)
    assert client.base_url == "http://localhost:8282"
    try:
        client.list_requests()
        assert False
    except:
        assert True



# Generated at 2022-06-24 01:47:06.633927
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class dummy_logger:
        def debug(self, msg):
            print(msg)

    x = 2
    y = 3
    z = "yes"
    print_y = LoggedFunction(dummy_logger())(lambda x: x)
    add2 = LoggedFunction(dummy_logger())(lambda x, y: x + y)
    add_kw = LoggedFunction(dummy_logger())(lambda x, y, z=False: x + y + int(z))

    print_y(x)
    add2(x, y)
    add_kw(x, y, z=z)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:47:12.495201
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import Session, exceptions

    s = build_requests_session()
    assert type(s) == Session
    for url in ["https://www.baidu.com", "https://httpbin.org/status/404"]:
        try:
            r = s.get(url, timeout=5)
        except exceptions.HTTPError:
            if url == "https://httpbin.org/status/404":
                pass
            else:
                raise
    


# Generated at 2022-06-24 01:47:14.208971
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg(123) == "123"

# Generated at 2022-06-24 01:47:19.702837
# Unit test for function format_arg
def test_format_arg():
    assert("'a'" == format_arg("a"))
    assert("None" == format_arg(None))
    assert("1" == format_arg(1))
    assert("1.2" == format_arg(1.2))
    assert('"a"' == format_arg('a"'))

# Generated at 2022-06-24 01:47:25.231540
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    log_func = LoggedFunction(logger)

    @log_func
    def sum_two_int(a, b):
        return a+b

    print(sum_two_int(1, 2))
    print(sum_two_int(1, 2, c=3))

if __name__ == '__main__':
    test_LoggedFunction()

# Generated at 2022-06-24 01:47:29.448405
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('1') == "'1'"
    assert format_arg('') == "''"
    assert format_arg('s') == "'s'"
    assert format_arg(' s ') == "' s '"

# Generated at 2022-06-24 01:47:32.644533
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # test whether the constructor of class LoggedFunction works
    foo = LoggedFunction(logging.getLogger())
    assert foo != None

# Generated at 2022-06-24 01:47:44.485310
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg("'test") == "'test'"
    assert format_arg("test'") == "'test'"
    assert format_arg("''test'") == "'test'"
    assert format_arg("test''") == "'test'"
    assert format_arg("test' '") == "'test' '"
    assert format_arg("test' 'test") == "'test' 'test'"
    assert format_arg("test' 'test'") == "'test' 'test'"

    assert format_arg(123) == "123"
    assert format_arg(123.456) == "123.456"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"

    class TestClass:
        pass


# Generated at 2022-06-24 01:47:47.988862
# Unit test for function format_arg
def test_format_arg():
    assert '"1"' == format_arg(1)
    assert '"abc"' == format_arg('abc')
    assert '" abc "' == format_arg(' abc ')
    assert format_arg is functools.partial(format_arg, value=3)


# Generated at 2022-06-24 01:47:56.136658
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logging.disable(logging.CRITICAL)
    logger = logging.getLogger("test")

    @LoggedFunction(logger)
    def test_func(x, y=1):
        return x + y


    test_func(3, 4)
    assert logger.handlers[0].output == "test_func(3, 4)\n"
    sample_output = "test_func -> 7\n"
    assert logger.handlers[0].output == sample_output

    logger.handlers[0].output = ""
    test_func("test", y=3)
    sample_output = "test_func('test', y=3)\n"
    sample_output += "test_func -> test3\n"
    assert logger.handlers[0].output == sample_output


# Generated at 2022-06-24 01:48:04.423760
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)
    console_hanlder = logging.StreamHandler()
    console_hanlder.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s %(name)s %(levelname)s: %(message)s")
    console_hanlder.setFormatter(formatter)
    logger.addHandler(console_hanlder)
    lp = LoggedFunction(logger)
    assert lp.logger is logger



# Generated at 2022-06-24 01:48:10.541896
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger=LoggedFunction(logger = logging.getLogger(__name__))
    def some_function(a, b, c):
        return 1
    some_function(1, 2, 3)
    LoggedFunction(logger=logging.getLogger(__name__))(some_function)
    some_function(1, 2, 3)

# Generated at 2022-06-24 01:48:18.784648
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import Mock

    mock_logger = Mock()

    @LoggedFunction(logger=mock_logger)
    def test_func(arg_1: str, arg_2: str = "arg_2", *args, **kwargs):
        return f"result {arg_1}-{arg_2}"

    assert test_func("value1", "value2") == "result value1-value2"

    mock_logger.debug.assert_any_call(
        "test_func('value1', arg_2='value2')")
    mock_logger.debug.assert_any_call(
        "test_func -> result value1-value2")



# Generated at 2022-06-24 01:48:23.406371
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("foo") == "'foo'"
    assert format_arg(" foo") == "' foo'"
    assert format_arg("foo ") == "'foo '"
    assert format_arg(" foo ") == "' foo '"
    assert format_arg(4) == "4"



# Generated at 2022-06-24 01:48:29.521088
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import Logger, INFO
    logger = Logger(name="test", level=INFO)

    @LoggedFunction(logger)
    def f(s):
        return s

    assert f("test") == "test"

# Generated at 2022-06-24 01:48:37.341785
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    from unittest.mock import MagicMock, sentinel

    logger = logging.Logger("test")
    logger.debug = MagicMock()

    class TestLoggedFunction(unittest.TestCase):

        def setUp(self):
            self.obj = sentinel.obj
            self.func = MagicMock(return_value=self.obj)

        def test_no_args_no_kwargs(self):
            logged_func = LoggedFunction(logger)(self.func)
            result = logged_func()
            self.assertEqual(result, self.obj)
            self.assertEqual(self.func.call_count, 1)
            self.func.assert_called_once_with()
            logger.debug.assert_any_call("func()")


# Generated at 2022-06-24 01:48:41.723949
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from mcmd.core.log import get_logger

    logger = get_logger()
    logged_func = LoggedFunction(logger)(test_func)

    logged_func(1, 2, 3)
    logged_func(1, 2, c=3)
    logged_func(1, 2, 3, c=4)

    # TODO: check log output



# Generated at 2022-06-24 01:48:51.108998
# Unit test for function build_requests_session
def test_build_requests_session():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def assert_session(self, session, **kwargs):
            self.assertEqual(session.hooks, kwargs.get("hooks"))
            self.assertEqual(session.mounts, kwargs.get("mounts"))

        def test_no_arg(self):
            session = build_requests_session()
            self.assert_session(session, mounts=["http://", "https://"])

        def test_raise_for_status(self):
            session = build_requests_session(raise_for_status=False)
            self.assert_session(session, mounts=["http://", "https://"], hooks={})
            session = build_requests

# Generated at 2022-06-24 01:48:57.222717
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def test_func(x, y=3):
        return x * y
    import logging
    import string
    import random
    logging.basicConfig()
    for i in range(10):
        x = str("".join(random.choices(string.ascii_lowercase, k=5)))
        y = random.randint(0, 10000)
        l = LoggedFunction(logging)
        assert l(test_func)(x, y) == test_func(x, y)



# Generated at 2022-06-24 01:49:04.947408
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__file__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    @LoggedFunction(logger)
    def hello_world(hello = "world", error = None):
        if error:
            raise error
        return "Hello " + hello

    hello_world()
    hello_world(hello = "you")
    try:
        hello_world(error = ValueError)
    except ValueError:
        logger.exception("Caught ValueError")


# Generated at 2022-06-24 01:49:08.904934
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg("123") == "'123'"
    assert format_arg(" 123 ") == "' 123 '"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:49:13.370284
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest.mock
    log = logging.getLogger("test_LoggedFunction")
    logger = unittest.mock.Mock(log)
    test = LoggedFunction(logger)
    test_func = test(lambda : 'test')
    test_func()
    logger.debug.assert_any_call("<lambda>()")
    logger.debug.assert_any_call("<lambda> -> test")


# Generated at 2022-06-24 01:49:24.953453
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import math
    from unittest.mock import Mock

    logger = Mock("logger")
    logged_function = LoggedFunction(logger)
    logged_func = logged_function(math.sqrt)

    logged_func(25)
    logged_func(25, 2)

    logger.debug.assert_any_call("sqrt(25)")
    logger.debug.assert_any_call("sqrt(25, 2)")


# Code snippet from https://code-maven.com/serialize-dataclass-object-as-json-in-python
# The MIT License (MIT)
#
# Copyright (c) 2019 Szabolcs Nagy
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the

# Generated at 2022-06-24 01:49:27.489528
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("hello") == "'hello'"
    assert format_arg("  hello  ") == "'hello'"

# Generated at 2022-06-24 01:49:30.922142
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("arguments format test") == "'arguments format test'"
    assert format_arg(123) == "123"



# Generated at 2022-06-24 01:49:41.265454
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    
    # Test
    def func_test(a, b, c='c'):
        return a+b
    test = LoggedFunction(logger)
    func_test = test(func_test)
    func_test(1, 2)
    func_test(1, 2, 'c')
    func_test(a=1, b=2)
    func_test(a=1, b=2, c='c')
    func_test(1, b=2, c='c')

# Generated at 2022-06-24 01:49:48.567431
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Mock function and Logger
    function = mock.Mock(return_value='return_value')
    logger = mock.Mock()

    # Create LoggedFunction object
    lf = LoggedFunction(logger)

    decorator_func = lf(function)

    # Test with different input arguments
    lf(function)('arg1')
    assert function.call_count == 1
    assert function.call_args_list[0][0] == ('arg1',)
    assert function.call_args_list[0][1] == {}
    assert logger.debug.call_count == 2
    assert logger.debug.call_args_list[0][0] == ("function('arg1')",)
    assert logger.debug.call_args_list[1][0] == ("function -> return_value",)


# Generated at 2022-06-24 01:49:51.061159
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("prateek") == "'prateek'"
    assert format_arg("  kapoor ") == "'kapoor'"


# Generated at 2022-06-24 01:49:54.001589
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg(["1", "2"]) == "['1', '2']"



# Generated at 2022-06-24 01:49:58.071888
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('1') == "'1'"
    assert format_arg(' a ') == "' a '"
    assert format_arg('a b') == "'a b'"

# Generated at 2022-06-24 01:50:08.027631
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.max_redirects == 30
    assert session.trust_env == True
    assert session.stream == False
    assert session.verify == True
    assert session.cert == None
    assert session.proxies == {}
    assert session.adapters == {"http://": HTTPAdapter(max_retries=Retry()),
                              "https://": HTTPAdapter(max_retries=Retry())}

# Generated at 2022-06-24 01:50:10.142015
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("p1") == "'p1'"
    assert format_arg("pe'r") == "'pe'r'"



# Generated at 2022-06-24 01:50:18.877536
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=2)
    assert isinstance(session.adapters['http://'].max_retries, Retry)
    assert session.adapters['http://'].max_retries.total == 2
    assert session.adapters['http://'].max_retries.backoff_factor == 0.3
    session = build_requests_session(retry=Retry(total=2, backoff_factor=0.4))
    assert session.adapters['http://'].max_retries.backoff_factor == 0.4
    session = build_requests_session(retry=False)
    assert 'http://' not in session.adapters

# Generated at 2022-06-24 01:50:26.049996
# Unit test for function build_requests_session
def test_build_requests_session():
    import logging
    import time
    from datetime import datetime
    from requests.exceptions import HTTPError
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    logging.basicConfig(format='%(asctime)s %(levelname)-5s %(message)s',
                        datefmt='%H:%M:%S',
                        level=logging.DEBUG)


# Generated at 2022-06-24 01:50:33.535153
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import inspect

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    def foo(a, b, c="c", d="d"):
        logger.info("inside foo")

    assert foo.__name__ == "foo"
    assert foo.__qualname__ == "test_LoggedFunction___call__.<locals>.foo"

    LoggedFunction(logger)(foo)()

# Generated at 2022-06-24 01:50:36.335785
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("logger")
    logged_func = LoggedFunction(logger)
    assert logged_func.logger == logger


# Generated at 2022-06-24 01:50:45.265706
# Unit test for function build_requests_session
def test_build_requests_session():
    import os
    import requests
    from urllib3.util import Retry
    def test_session(session: requests.Session, url: str, retry: Retry):
        assert session.adapters["http://"].max_retries.total == retry.total
        assert session.adapters["https://"].max_retries.total == retry.total

        response = session.get(url)
        assert response.status_code == 200

    test_session(build_requests_session(), "https://cloud.sagemaker.aws/", Retry())
    test_session(build_requests_session(retry=False), "https://cloud.sagemaker.aws/", Retry())

# Generated at 2022-06-24 01:50:56.535969
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s, Session)
    assert s.hooks == {}
    assert len(s.adapters) == 2
    assert isinstance(s.adapters['http://'].max_retries, Retry)
    assert isinstance(s.adapters['https://'].max_retries, Retry)

    s = build_requests_session(retry=False)
    assert isinstance(s, Session)
    assert s.hooks == {}
    assert len(s.adapters) == 0

    s = build_requests_session(retry=1)
    assert isinstance(s, Session)
    assert s.hooks == {}
    assert len(s.adapters) == 2

# Generated at 2022-06-24 01:51:04.371102
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hello") == "'hello'"
    assert format_arg(123) == "123"
    assert format_arg(None) == "None"
    class Dummy:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    dummy = Dummy("one", 2, 3.3)
    assert format_arg(dummy) == "one, 2, 3.3"

# Generated at 2022-06-24 01:51:15.226177
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logga import log

    global func_name
    func_name = None
    global func_args
    func_args = None
    global func_kwargs
    func_kwargs = None
    global result
    result = None
    global result_stored
    result_stored = None

    def func(*args, **kwargs):
        global result
        result = args, kwargs
        return result_stored

    logger = logga.log.get_logger("test_LoggedFunction___call__")
    decorator = LoggedFunction(logger)
    times = 1000
    for i in range(times):
        args = tuple(range(i))
        kwargs = {f"x{j}": j * 0.1 for j in range(i)}
        result_stored = args, kwargs


# Generated at 2022-06-24 01:51:21.301246
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        build_requests_session(retry=1.1)
    except:
        pass
    else:
        raise Exception("should not be able to build with float as retry number")
    build_requests_session(retry=False)
    build_requests_session(retry=10)
    build_requests_session(retry=Retry())


test_build_requests_session()

# Generated at 2022-06-24 01:51:24.419709
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from importlib import resources
    import logging
    from logging.config import dictConfig

    with resources.path(__name__, "logging.json") as logging_config_file:
        dictConfig(json.loads(logging_config_file.read_text()))
    logger = logging.getLogger()

    # Test LoggedFunction constructor
    assert isinstance(LoggedFunction(logger), LoggedFunction)
    assert LoggedFunction(logger).logger == logger
    assert LoggedFunction(logger2).logger == logger2


# Generated at 2022-06-24 01:51:34.495445
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert not session.hooks
    assert not session.adapters
    session = build_requests_session(retry=True)
    assert isinstance(session.adapters, dict)
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)
    session = build_requests_session(retry=3)

# Generated at 2022-06-24 01:51:39.227236
# Unit test for function format_arg
def test_format_arg():
    a = format_arg("hello")
    b = format_arg(123)
    c = "hello"

    assert a == "'hello'"
    assert str(b) == "123"
    assert str(c) == "hello"

# Generated at 2022-06-24 01:51:42.497305
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('abc') == "'abc'"
    assert format_arg('abc ') == "'abc'"
    assert format_arg(123) == '123'



# Generated at 2022-06-24 01:51:52.421158
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class _Logger:
        def __init__(self):
            self.log = []
        def debug(self, message):
            self.log.append(message)
    def _func(*args, **kwargs):
        pass

    _logger = _Logger()
    _logged_function = LoggedFunction(_logger)
    _logged_func = _logged_function(_func)
    _logged_func('a','b',c='c',d=123)
    assert _logger.log == [
        "_func('a', 'b', c='c', d=123)",
        "_func -> None",
    ]

# Generated at 2022-06-24 01:51:55.946781
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import builtins
    def my_function():
        return True
    function = LoggedFunction(builtins.print)
    assert function(my_function)()
    assert my_function.__name__ == "my_function"

# Generated at 2022-06-24 01:51:59.964606
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("testing")

    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    assert add(1, 2) == 3



# Generated at 2022-06-24 01:52:02.186999
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    session.get("http://www.geekdigging.com")

# Generated at 2022-06-24 01:52:10.256436
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    handler = logging.StreamHandler()
    logging.basicConfig(level=logging.DEBUG)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    @LoggedFunction(logger)
    def logged_function(a, b):
        print('logged_function is called')
        return a + b
    logged_function(1,2)

if __name__ == '__main__':
    test_LoggedFunction()

# Generated at 2022-06-24 01:52:15.472470
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(2) == '2'
    assert format_arg('abc') == "'abc'"
    assert format_arg('abcdef') == "'abcdef'"
    assert format_arg(2.2) == '2.2'
    assert format_arg(None) == 'None'


# Generated at 2022-06-24 01:52:26.450978
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Prepare logger
    logger_mock = MagicMock()
    logger_mock.debug = MagicMock()

    # Prepare LoggedFunction
    logged_function = LoggedFunction(logger_mock)

    # Prepare function
    def foo(a, b):
        return a + b
    foo.__name__ = "foo"

    # Test LoggedFunction.__call__
    # Test 1
    logger_mock.reset_mock()
    foo_wrapped = logged_function(foo)
    assert foo_wrapped(1, 2) == 3
    assert logger_mock.debug.call_count == 2
    assert logger_mock.debug.call_args_list[0][0] == ("foo(1, 2)",)

# Generated at 2022-06-24 01:52:35.414603
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class Logger:
        def __init__(self):
            self.log = []

        def debug(self, msg):
            self.log.append(msg)

    my_logger = Logger()
    logger = LoggedFunction(my_logger)


    @logger
    def foo(x, y, z=1):
        """
        This is a docstring
        :param x:
        """
        return x + y + z


    foo(2, 3)
    assert my_logger.log == [
        "foo(2, 3, z=1)",
        "foo -> 6",
    ]
    foo.__doc__ == "This is a docstring"

# Generated at 2022-06-24 01:52:37.560805
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg(True) == "True"


# Generated at 2022-06-24 01:52:43.865589
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    class x:
        def __init__(self):
            self.a = 1
        @LoggedFunction(logger)
        def f1(self, a, *args, **kwargs):
            return a

    assert x().f1(1, 2, b=3, c=4) == 1
    return