

# Generated at 2022-06-24 01:42:36.802253
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" Hello World ") == "' Hello World '"
    assert format_arg(3) == "3"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:42:45.098574
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import Logger, NOTSET, DEBUG
    from logging import Formatter
    from logging import StreamHandler
    from unittest.mock import Mock
    from io import StringIO
    
    
    logger = Logger('test_LoggedFunction')
    logger.setLevel(DEBUG)
    stream_handler = StreamHandler()
    stream_handler.setLevel(DEBUG)
    formatter = Formatter('%(levelname)s - %(message)s')
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    stdout_stream = StringIO()
    stream_handler.stream = stdout_stream 
    
    
    logged_function = LoggedFunction(logger)
    
    def mock_func(*args):
        return f'foo {args[0]}'

    mock

# Generated at 2022-06-24 01:42:56.052334
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Unit test for method __call__ of class LoggedFunction
    """
    class __DummyLogger:
        def debug(self, msg):
            self.msg = msg
    def __test_function(a, b, c):
        return 1, 2, 3

    dl = __DummyLogger()
    lf = LoggedFunction(dl)
    dlf = lf(__test_function)
    dlf(1, 2, 3)
    assert dl.msg == f"__test_function(1, 2, 3)"

    dlf("abc", c=100, b="defg")
    assert dl.msg == f"__test_function('abc', 'defg', 100)"
    # test ends


# Generated at 2022-06-24 01:43:04.790271
# Unit test for function format_arg
def test_format_arg():
    test_items = [
        (1, "1"),
        ("a", "'a'"),
        ("  b ", "'  b '"),
        ("c  ", "'c  '"),
        ("'d", "'\\'d'"),
        ('"e', '\'"e\''),
        ([1, 2, 3], "[1, 2, 3]"),
        (['a', 'b', 'c'], "['a', 'b', 'c']"),
    ]
    for test_args, expected in test_items:
        assert format_arg(test_args) == expected
        

# Generated at 2022-06-24 01:43:14.930368
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock

    class TestClass:
        def __init__(self):
            self.logger = mock.MagicMock()
        @LoggedFunction(logger = mock.MagicMock())
        def test_func1(self, a, b, c=30, *args, **kwargs):
            return (a, b, c, args, kwargs)
        @LoggedFunction(logger = self.logger)
        def test_func2(self, a, b, c=30, *args, **kwargs):
            return (a, b, c, args, kwargs)

    obj = TestClass()
    assert obj.test_func1(1, 2) == (1, 2, 30, (), {})

# Generated at 2022-06-24 01:43:17.305113
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(3) == "3"
    assert format_arg("3") == "'3'"
    assert format_arg("hello world") == "'hello world'"



# Generated at 2022-06-24 01:43:24.638806
# Unit test for function format_arg
def test_format_arg():
    assert("'Hello World'" == format_arg("Hello World"))
    assert("False" == format_arg(False))
    assert("None" == format_arg(None))
    assert("1.0" == format_arg(1.0))
    assert("True" == format_arg(True))

# Generated at 2022-06-24 01:43:30.503088
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(1.0) == '1.0'
    assert format_arg('1') == "'1'"
    assert format_arg('1.0') == "'1.0'"
    assert format_arg('a') == "'a'"
    assert format_arg(None) == 'None'
    assert format_arg([1, 2]) == '[1, 2]'
    assert format_arg({'a':1}) == "{'a': 1}"
    assert format_arg('a b') == "'a b'"


# Generated at 2022-06-24 01:43:34.606102
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest import mock

    logger = mock.Mock()
    logged_func = LoggedFunction(logger)
    assert logger == logged_func.logger
    assert callable(logged_func)


# Generated at 2022-06-24 01:43:45.916402
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock
    import unittest

    logger = MagicMock()
    @LoggedFunction(logger=logger)
    def decoded_func(a, b, c=10):
        return a*b*c
    
    decoded_func(3, 4, c=2)
    logger.debug.assert_called_once_with('decoded_func(3, 4, c=2)')

    logger.debug.reset_mock()
    decoded_func(5, 6, 7)
    logger.debug.assert_called()
    assert logger.debug.call_count == 2
    logger.debug.assert_called_with('decoded_func(5, 6, 7)')    
    
    logger.debug.reset_mock()

# Generated at 2022-06-24 01:43:52.315752
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging

    logger = logging.getLogger("test_logger")
    logged = LoggedFunction(logger)

    @logged
    def test_func(a, b, c=3):
        return a * b * c

    assert test_func(1, 2) == 6
    assert test_func(1, 2, 5) == 10

# Generated at 2022-06-24 01:44:00.243827
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger
    from .logging_setup import setup_logging

    setup_logging(level="DEBUG")

    logger = getLogger(__name__)

    @LoggedFunction(logger=logger)
    def add(x, y):
        """Test adding two numbers."""
        return x + y

    result = add(5, y=3)

    assert result == 8


# Generated at 2022-06-24 01:44:04.628918
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction
    """
    from unittest.mock import Mock
    from logging import Logger
    from logging import INFO

    # Create logger and extract its debug method
    logger = Logger("LoggedFunction")
    logger.setLevel(INFO)
    info_method = logger.info

    # Create LoggedFunction instance and its __call__ method
    logged_function = LoggedFunction(logger)
    logged_function_call = logged_functio

# Generated at 2022-06-24 01:44:10.354686
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # set up logger
    logger = logging.getLogger("test_log")
    logger.addHandler(logging.StreamHandler(stream=None))
    logger.setLevel(logging.DEBUG)
    # call decorated function
    test_func = LoggedFunction(logger=logger)(lambda x: x)
    result = test_func(0)
    # verify func is decorated
    assert result == 0


# Generated at 2022-06-24 01:44:19.687426
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session.get(url="http://httpbin.org/get").json()["origin"],
                      str)

    session = build_requests_session(False)
    assert isinstance(session.get(url="http://httpbin.org/get").json()["origin"],
                      str)

    session = build_requests_session(False, False)
    assert isinstance(session.get(url="http://httpbin.org/get").json()["origin"],
                      str)

    session = build_requests_session(False, 0)
    assert isinstance(session.get(url="http://httpbin.org/get").json()["origin"],
                      str)

    session = build_requests_session(False, 1)

# Generated at 2022-06-24 01:44:26.256284
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from loguru import logger
    class Example:
        def __init__(self):
            self.logger = logger

        @LoggedFunction(logger)
        def add(self, x, y):
            return x + y
    assert Example().add(1, 2) == 3

# Generated at 2022-06-24 01:44:32.822342
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc") == "'abc'"
    assert format_arg(123) == "123"
    assert format_arg(" 123") == "' 123'"
    assert format_arg("123 ") == "'123 '"
    assert format_arg(" 123 ") == "' 123 '"
    assert format_arg("1'2") == "\"1'2\""


# Generated at 2022-06-24 01:44:44.577323
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import pandas as pd
    import pandas.testing as tm
    import datetime
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    log_str = logging.StreamHandler()
    log_str.setLevel(logging.DEBUG)
    logger.addHandler(log_str)


    @LoggedFunction(logger)
    def func(a, b, c: float = 0) -> pd.DataFrame:
        return pd.DataFrame(
            [
                (1, datetime.datetime.now(), 1.0),
                (2, datetime.datetime.now(), 2.0),
            ],
            columns=["a", "b", "c"],
        )


    func(3, b="b", c=0.5)

# Generated at 2022-06-24 01:44:50.481203
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from libratom.utils.logger import logger

    @LoggedFunction(logger=logger)
    def test_func(a, b, c=3):
        return a + b + c

    assert test_func(1, 2, 3) == 6



# Generated at 2022-06-24 01:44:54.186349
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg(" test ") == "' test '"
    assert format_arg("123 test") == "'123 test'"
    assert format_arg(123) == "123"
    assert format_arg(123.123) == "123.123"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:44:55.668017
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" Value  ") == "'Value'"
    assert format_arg(123) == "123"

# Generated at 2022-06-24 01:44:59.728683
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('hai "ha" 3') == "'hai \"ha\" 3'", "Single quotes for strings"
    assert format_arg(1) == "1", "No quotes for non-strings"
    assert format_arg(None) == "None", "Special value None"
    assert format_arg('') == "''", "Empty string"

# Unit tests for function build_requests_session

# Generated at 2022-06-24 01:45:04.839882
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(1) == "1"
    assert format_arg(3.14) == "3.14"
    assert format_arg(" hello ") == "' hello '"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"

# Generated at 2022-06-24 01:45:09.854158
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def bar(a, b, c, d=4, e=5):
        return 2 * a + b + c

    bar(1, 2, 3)
    bar(1, 2, 3, d=4)
    bar(1, 2, 3, d=4, e=3)
    bar(a=1, b=2, c=3, d=4, e=3)

# Generated at 2022-06-24 01:45:16.776717
# Unit test for function build_requests_session
def test_build_requests_session():
    # Make sure max_retries is set when retry is True
    assert build_requests_session(retry=True).adapters["http://"].max_retries.total == 10
    # Make sure max_retries is set to given integer when retry is an integer
    assert build_requests_session(retry=5).adapters["http://"].max_retries.total == 5
    # Make sure max_retries is set to given Retry instance when retry is a Retry instance
    assert (
        build_requests_session(retry=Retry(total=15)).adapters["http://"].max_retries.total
        == 15
    )

# Generated at 2022-06-24 01:45:27.946159
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg("abc bcd") == "'abc bcd'"
    assert format_arg("abc bcd") == "'abc bcd'"
    assert format_arg(" abc bcd ") == "' abc bcd '"
    assert format_arg("'a'") == "'\'a\''"
    assert format_arg("\n") == "'\n'"
    assert format_arg(1.0) == "1.0"
    assert format_arg(1) == "1"
    assert format_arg(0) == "0"
    assert format_arg(1+2j) == "(1+2j)"
    assert format_arg(False) == "False"
    assert format_arg(True) == "True"

# Generated at 2022-06-24 01:45:32.667789
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, 3)
    response = session.get('https://httpbin.org/status/404')
    assert response.status_code == 404
    response = session.get('https://httpbin.org/status/200')
    assert response.status_code == 200

# Generated at 2022-06-24 01:45:36.004876
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    assert LoggedFunction('logger')

# Generated at 2022-06-24 01:45:46.448317
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    #  Arrange
    from unittest.mock import Mock
    from unittest.mock import sentinel
    logger = Mock()
    logged_function = LoggedFunction(logger)
    func = Mock(return_value=sentinel.return_value)
    args = (sentinel.arg1, sentinel.arg2)
    kwargs = {'kwarg1': sentinel.kwarg1, 'kwarg2': sentinel.kwarg2}

    #  Act
    logged_func = logged_function(func)
    result = logged_func(*args, **kwargs)

    #  Assert
    func.assert_called_once_with(*args, **kwargs)
    assert result == sentinel.return_value

# Generated at 2022-06-24 01:45:47.896935
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    with pytest.raises(ValueError):
        LoggedFunction("a")


# Generated at 2022-06-24 01:45:53.862642
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    def func(*args, **kwargs):
        return kwargs['first'] + kwargs['second']
    logging.basicConfig(level=logging.NOTSET)
    logger = logging.getLogger(__name__)
    lf = LoggedFunction(logger)
    assert lf(func)(1, 2, 3, first=100, second=1000) == 1100


# Generated at 2022-06-24 01:46:02.748836
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    logger = logging.Logger(name='foo')
    logger.setLevel(logging.DEBUG)
    info_handler = logging.StreamHandler()
    logger.addHandler(info_handler)
    def foo(last_name, first_name):
        return f"{first_name}, {last_name}"
    decorated_func = LoggedFunction(logger)(foo)
    # Act
    result = decorated_func(last_name='Bond', first_name='James')
    # Assert
    assert result == foo(last_name='Bond', first_name='James')

# Generated at 2022-06-24 01:46:05.969822
# Unit test for function build_requests_session
def test_build_requests_session():
    # test raise_for_status is True
    session = build_requests_session()
    assert len(session.hooks.get("response")) == 1
    # test raise_for_status is False
    session = build_requests_session(raise_for_status=False)
    assert len(session.hooks) == 0



# Generated at 2022-06-24 01:46:17.798110
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # arrange
    logger = MagicMock()
    logger.debug = MagicMock()
    target = LoggedFunction(logger)

    def mock_func(arg, kwarg=None):
        return f"mock result, {arg}, {kwarg}"

    target.__call__(mock_func)("test", kwarg="mock")

    # assert
    logger.debug.assert_called_once_with(
        "mock_func('test', kwarg='mock')"
    )

    # act
    mock_func_logged = target.__call__(mock_func)
    result = mock_func_logged("test", kwarg="mock")

    # assert

# Generated at 2022-06-24 01:46:26.480893
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import datetime
    import logging
    import pytest
    import sys
    from io import StringIO

    # Capture stdout so we can assert on the messages logged by the decorated
    # functions
    test_out = StringIO()
    logging.basicConfig(stream=test_out, level=logging.DEBUG)

    # Define a function that will return the current date
    @LoggedFunction(logger=logging.getLogger("test_logger"))
    def get_date():
        return datetime.datetime.now().strftime("%y-%m-%d")

    # Call the function
    result = get_date()

    # Check that the correct log message was printed
    test_out.seek(0)

# Generated at 2022-06-24 01:46:35.624862
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Create a simple logger to record log output
    from logging import Logger
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def io_context(s):
        yield s
        s.seek(0)

    stream = StringIO()
    logger = Logger("LoggedFunction test")
    stream_handler = logging.StreamHandler(stream=stream)
    logger.addHandler(stream_handler)

    # Create a dummy function to log
    with io_context(stream) as stream:
        @LoggedFunction(logger)
        def dummy(a: int, b: str, c: float = 1.0, d: bool = False, e=None):
            pass

        # Call the function, and check the output is as expected

# Generated at 2022-06-24 01:46:38.390160
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    for method in ["get", "post", "put", "patch", "delete"]:
        assert hasattr(session, method)
    session = build_requests_session(False, False)
    assert not hasattr(session.hooks, "response")

# Generated at 2022-06-24 01:46:43.690472
# Unit test for function build_requests_session
def test_build_requests_session():
    @build_requests_session(retry=True)
    def test_func(session):
        return session.get("https://google.com").url

    assert test_func() == "https://google.com/"
    assert test_func() == "https://google.com/"

# Generated at 2022-06-24 01:46:50.081618
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys

    # capture print output
    result = StringIO()
    sys.stdout = result

    # set logger instance
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    shnd = logging.StreamHandler(sys.stdout)
    shnd.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    shnd.setFormatter(formatter)
    logger.addHandler(shnd)

    # test
    def my_func(arg1, arg2, arg3='def'):
        return f"{arg1}-{arg2}-{arg3}"

    logged_func = Logged

# Generated at 2022-06-24 01:46:58.493919
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    session = build_requests_session(True, None)
    assert isinstance(session, requests.Session)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert len(session.adapters) == 0

    session = build_requests_session(False, False)
    assert isinstance(session, requests.Session)
    assert session.hooks == {}
    assert len(session.adapters) == 0

    session = build_requests_session(True, False)
    assert isinstance(session, requests.Session)

# Generated at 2022-06-24 01:47:04.618498
# Unit test for function build_requests_session
def test_build_requests_session():
    session: Session = build_requests_session()
    assert isinstance(session, Session)
    assert len(session.hooks) == 0
    session: Session = build_requests_session(retry={'total' : 3})

# Generated at 2022-06-24 01:47:10.744603
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # create a logger
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # create your function
    def foo(a, b):
        return a + b
    
    # use it
    foo = LoggedFunction(logger)(foo)
    foo(1, 2)


# Generated at 2022-06-24 01:47:14.294517
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("a") == "'a'"
    assert format_arg("a b") == "'a b'"

# Generated at 2022-06-24 01:47:16.673693
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session



# Generated at 2022-06-24 01:47:23.445771
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    logger.addHandler(console_handler)

    @LoggedFunction(logger)
    def foo(a, b, c="bar"):
        return "result"

    foo(1, 2, c=3)



# Generated at 2022-06-24 01:47:26.516992
# Unit test for function format_arg
def test_format_arg():
    for x in '', 'string', 'tup(1, 2)':
        assert format_arg(x) == f"'{x}'"
    for x in 0, 1, 2, 3.1415, (1, 2, 3):
        assert format_arg(x) == str(x)



# Generated at 2022-06-24 01:47:31.706805
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("str") == "'str'"
    assert format_arg("  str  ") == "'str'"
    assert format_arg(None) == "None"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"
    assert format_arg([1, "   x   ", 3]) == "[1, 'x', 3]"
    assert format_arg({"x": 1, "y": 2}) == "{'x': 1, 'y': 2}"
    assert format_arg({"x": "  1  ", "y": " 2 "}) == "{'x': '1', 'y': '2'}"



# Generated at 2022-06-24 01:47:36.548315
# Unit test for function build_requests_session
def test_build_requests_session():
    from logging import Logger
    from unittest.mock import MagicMock

    # prepare mock logger
    logger = MagicMock(spec=Logger)

    # prepare mock hook
    hook = MagicMock()

    with build_requests_session(True, retry=3) as session:
        if session.hooks["response"][0] != hook:
            hook(session.hooks["response"][0])



# Generated at 2022-06-24 01:47:45.043692
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)
    assert session.hooks is None

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)
    assert session.hooks is None

    session = build_requests_session(retry=True)
    assert isinstance(session.adapters["http://"].max_retries, Retry)

# Generated at 2022-06-24 01:47:50.302752
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(
        raise_for_status=False,
        retry=Retry(total=3, backoff_factor=0.2, status_forcelist=[500, 502, 503, 504]),
    )
    response = session.get("http://httpbin.org/get")
    response.raise_for_status()
    assert response.json()["url"] == "http://httpbin.org/get"



# Generated at 2022-06-24 01:47:54.190256
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg("") == "''"
    assert format_arg(" ") == "' '"
    assert format_arg(" test ") == "' test '"

# Generated at 2022-06-24 01:47:56.696092
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(1.0) == '1.0'
    assert format_arg(' a ') == "' a '"
    assert format_arg((' a ',)) == "(' a ',)"


# Generated at 2022-06-24 01:48:07.516833
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import os
    import sys
    import io
    import unittest
    from io import StringIO

    class Logger:
        def __init__(self, stream = StringIO()):
            self.stream = stream

        def debug(self, msg):
            print(msg, file = self.stream)

        def getvalue(self):
            return self.stream.getvalue()

    def foo(x, y, z):
        return x * y * z

    @LoggedFunction(Logger())
    def bar(x, y, z):
        return x * y * z

    assert(foo(1, 2, 3) == bar(1, 2, 3))

    s0 = ""
    s0 += "foo(1, 2, 3)\n"
    s0 += "foo -> 6\n"

# Generated at 2022-06-24 01:48:16.845128
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None
    assert "response" not in session.hooks
    assert "https://" not in session.adapters
    assert "http://" not in session.adapters

    session = build_requests_session(False)
    assert session is not None
    assert "response" not in session.hooks
    assert "https://" not in session.adapters
    assert "http://" not in session.adapters

    session = build_requests_session(True)
    assert session is not None
    assert "response" in session.hooks
    assert "https://" not in session.adapters
    assert "http://" not in session.adapters

    session = build_requests_session(True, retry=False)
    assert session is not None

# Generated at 2022-06-24 01:48:18.712281
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    a = LoggedFunction("test_logger")



# Generated at 2022-06-24 01:48:27.584339
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters == {}

    session = build_requests_session(retry=False)
    assert session.adapters == {}

    session = build_requests_session(retry=1)
    adapter = session.adapters.get("http://")
    assert adapter.max_retries.total == 1
    adapter = session.adapters.get("https://")
    assert adapter.max_retries.total == 1

    session = build_requests_session(retry=Retry(1))
    adapter = session.adapters.get("http://")
    assert adapter.max_retries.total == 1
    adapter = session.adapters.get("https://")
    assert adapter.max_retries.total == 1



# Generated at 2022-06-24 01:48:33.203686
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    @LoggedFunction(logger)
    def test_func(a, b=1, *args, c, **kwargs):
        return a * b * c * args[0] * kwargs['d']
    result = test_func(1, 2, 3, c=4, d=5, e=6)
    assert result == 120
    assert test_func.__name__ == 'test_func'

# Generated at 2022-06-24 01:48:36.997373
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("") == "''"
    assert format_arg(" a ") == "'a'"



# Generated at 2022-06-24 01:48:43.646900
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    mylogger = logging.getLogger("mylogger")
    mylogger.setLevel("DEBUG")
    ch = logging.StreamHandler()
    ch.setLevel("DEBUG")
    mylogger.addHandler(ch)

    loggedfunc = LoggedFunction(mylogger)

    def myfunc(arg1, arg2=None):
        return arg1

    result = loggedfunc(myfunc)("arg1")

    assert(result == "arg1")

# Generated at 2022-06-24 01:48:52.560399
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest

    logger = logging.getLogger(__name__)
    logger.level = logging.DEBUG

    def foo(a, bar):
        return bar

    @LoggedFunction(logger)
    def bar(a, b, c, d):
        return a + b + c + d
    
    def test_log_function(self):
        self.assertEqual(foo(1, "bar"), "bar")
        self.assertEqual(bar(1, 2, 3, 4), 10)


# Generated at 2022-06-24 01:49:02.405889
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class FakeLogger:
        def __init__(self):
            self.message = ""

        def debug(self, message):
            self.message = message

    def hello(name, extra_thing=None):
        print("Hello, " + str(name))

        if extra_thing:
            print("You've done this too: " + str(extra_thing))

        return name

    fake_logger = FakeLogger()
    logged_function = LoggedFunction(fake_logger)
    hello_logged = logged_function(hello)
    hello_logged("Bob")
    assert (
        fake_logger.message
        == "hello('Bob' ) -> Bob\nHello, Bob\nYou've done this too: None"
    )



# Generated at 2022-06-24 01:49:09.316499
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("mylogger")
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    logger.setLevel("DEBUG")
    logger.debug("Now test LoggedFunction.__call__")
    @LoggedFunction(logger)
    def testmethod_1(a, b, c=None):
        print("test")
        return a+b

    # Check calling
    result = testmethod_1(1, 2, c=[1, 2])
    assert result == 3

    # Check logger output
    handler.flush()
    assert handler.stream.getvalue().strip() == "Now test LoggedFunction.__call__\ntestmethod_1(1, 2, c=[1, 2])\ntest\ntestmethod_1 -> 3"
    handler.stream.trunc

# Generated at 2022-06-24 01:49:12.177815
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(10) == '10'
    assert format_arg('a') == "'a'"
    assert format_arg(' a ') == "' a '"
    assert format_arg(['a', 'b']) == "['a', 'b']"

# Generated at 2022-06-24 01:49:19.022744
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    import os
    logger = logging.getLogger('LoggedFunction')
    logger.setLevel(logging.DEBUG)
    logger.handlers = []
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    @LoggedFunction(logger)
    def test_function(a,b):
        return a+b
    test_function(1,2)
    logger.handlers = []

# Generated at 2022-06-24 01:49:25.272802
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger()
    logger.setLevel('DEBUG')
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def add(a, b):
        return a + b

    add(1, 2)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:49:27.454048
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    Test constructor of class LoggedFunction
    """
    f = LoggedFunction(logging.getLogger())



# Generated at 2022-06-24 01:49:39.227453
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    session = build_requests_session(raise_for_status=True, retry=3)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    session_adapter = session.adapters.get("http://")
    assert isinstance(session_adapter, HTTPAdapter)
    assert isinstance(session_adapter.max_retries, Retry)
    assert session_adapter.max_retries.total == 3

    session = build_requests_session(raise_for_status=False, retry=False)
    assert not session.hooks
    assert not session.adapters


# Generated at 2022-06-24 01:49:43.299363
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session()
    assert type(sess) == Session

# Generated at 2022-06-24 01:49:47.877288
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(42) == "42"
    assert format_arg(1.2) == "1.2"
    assert format_arg("foo") == "'foo'"
    assert format_arg("foo ") == "'foo '"
    assert format_arg(" foo ") == "' foo '"

# Generated at 2022-06-24 01:49:56.395249
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    with pytest.raises(AttributeError) as excinfo:
        LoggedFunction("test1")
    assert str(excinfo.value) == "'str' object has no attribute 'debug'"

    with pytest.raises(AttributeError) as excinfo:
        LoggedFunction({})
    assert str(excinfo.value) == "'dict' object has no attribute 'debug'"

    with pytest.raises(AttributeError) as excinfo:
        LoggedFunction([])
    assert str(excinfo.value) == "'list' object has no attribute 'debug'"

    with pytest.raises(AttributeError) as excinfo:
        LoggedFunction(object)
    assert str(excinfo.value) == "'type' object has no attribute 'debug'"

    with pytest.raises(AttributeError) as excinfo:
        logger = {}

# Generated at 2022-06-24 01:50:07.167838
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import os
    import unittest
    import shutil
    import tempfile
    # Create logger with tempfile as handler
    log_dir = tempfile.mkdtemp()
    log_file = os.path.join(log_dir, "test.log")
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    # Set handler to output debug log to file
    fh = logging.FileHandler(log_file)
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s-%(levelname)s-%(name)s-%(message)s"
    )
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # Define a test class

# Generated at 2022-06-24 01:50:15.706899
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("boo") == "'boo'"
    assert format_arg("boo\n") == "'boo'"
    assert format_arg("'boo'") == "'boo'"
    assert format_arg("\n'boo'") == "'boo'"
    assert format_arg("boo''") == "'boo'''"
    assert format_arg('"boo"') == "'boo'"
    assert format_arg("\n\"boo\"") == "'boo'"
    assert format_arg("\"\nboo\"") == "'\nboo'"
    assert format_arg(1) == "1"

# Generated at 2022-06-24 01:50:18.593599
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('    hi"  ') == "'    hi\"  '"
    assert format_arg(10) == '10'
    assert format_arg(10.0) == '10.0'
    assert format_arg('haha') == "'haha'"

# Generated at 2022-06-24 01:50:27.606804
# Unit test for function build_requests_session
def test_build_requests_session():
    session1 = build_requests_session()

    assert isinstance(session1, Session)
    assert len(session1.adapters) == 1
    assert len(session1.adapters["http://"]) == 2
    assert isinstance(session1.adapters["http://"][-1], Retry)
    assert len(session1.adapters["https://"]) == 2
    assert isinstance(session1.adapters["https://"][-1], Retry)

    session2 = build_requests_session(retry=False)
    assert isinstance(session2, Session)
    assert len(session2.adapters) == 1
    assert len(session2.adapters["http://"]) == 0
    assert len(session2.adapters["https://"]) == 0

    session3 = build_requests_session

# Generated at 2022-06-24 01:50:36.288605
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(1) == "1"
    assert format_arg(1.1) == "1.1"
    assert format_arg("$%#") == "'$%#'"
    assert format_arg(str) == "<class 'str'>"
    assert format_arg(list) == "<class 'list'>"
    assert format_arg(dict) == "<class 'dict'>"

# Generated at 2022-06-24 01:50:37.364670
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    @LoggedFunction(logger=None)
    def f():
        return 1

    assert f() == 1

# Generated at 2022-06-24 01:50:40.992297
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("a") == "'a'"
    assert format_arg(1) == "1"



# Generated at 2022-06-24 01:50:44.243813
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def foo(bar: str, baz=1):
        return f"{bar} {baz}"

    foo("hello", baz=4)
    # foo("hello")
    # foo("hello", baz=5)


# Generated at 2022-06-24 01:50:45.803040
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(logger).args == (logger,)
    assert LoggedFunction(logger).logger == logger

# Generated at 2022-06-24 01:50:56.874020
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    # Configure logger to output debug messages to stderr
    logger = logging.Logger("test_logger", level=logging.DEBUG)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    # Create LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Decorate test function
    @logged_function
    def test_function(a, b, c):
        return a * b + c

    # Call the test function and check the result
    test_function(2, 3, 4)
    assert test_function(2, 3, 4) == 10
    test_function(a=2, b=3, c=4)
   

# Generated at 2022-06-24 01:51:06.291538
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import inspect
    import logging

    logger = logging.Logger("main.dummy")
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def dummy_function(a, b, c=10):
        return a + b + c

    # Fit function to string
    dummy_function_string = inspect.getsource(dummy_function).strip()
    dummy_function_string = (
        dummy_function_string.replace("  ", "").replace("\n", "")
    )

    # Test class constructor
    assert dummy_function_string == "@LoggedFunction(logger)\ndef dummy_function(a,b,c=10):return a+b+c"

# Generated at 2022-06-24 01:51:10.009618
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)

# Generated at 2022-06-24 01:51:19.109058
# Unit test for function build_requests_session
def test_build_requests_session():
    # should pass
    build_requests_session(True)
    build_requests_session(False)
    build_requests_session(True, True)
    build_requests_session(True, 10)
    build_requests_session(True, Retry(2))
    build_requests_session(False, True)
    build_requests_session(False, 10)
    build_requests_session(False, Retry(2))

    # should raise exception
    try:
        build_requests_session(False, "test")
    except ValueError as e:
        assert "retry should be a bool, int or Retry instance." in str(e)


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-24 01:51:20.010128
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(3) == "3"
    assert format_arg("test") == "'test'"

# Generated at 2022-06-24 01:51:25.703632
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def f(a, b, c=3):
        return a+b+c

    lf = LoggedFunction(logging.getLogger("test"))
    assert lf(f)(1, 2) == 6
    assert lf(f)(1, b=2) == 6
    assert lf(f)(1, b=2, c=0) == 3

# Generated at 2022-06-24 01:51:34.573448
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import MagicMock
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(MagicMock())
    obj = LoggedFunction(logger)

    # Test 0 args
    @obj
    def zero_args():
        return 3

    assert zero_args() == 3

    # Test 1 arg
    @obj
    def one_arg(a):
        return a

    assert one_arg(3) == 3
    assert one_arg(a=3) == 3

    # Test 2 args
    @obj
    def two_args(a, b):
        return (a, b)

    assert two_args(3, 4) == (3, 4)

# Generated at 2022-06-24 01:51:38.908092
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import Response
    from pytest import raises
    # test for raise_for_status
    session = build_requests_session(raise_for_status=True)
    # response is OK, no exception should be raised
    session.get("http://httpbin.org/get")

    # response is NOT OK, exception should be raised
    with raises(Exception):
        session.get("http://httpbin.org/status/401")
    # test for retry
    session = build_requests_session(
        raise_for_status=False, retry=Retry(total=2, backoff_factor=0)
    )
    # number of times executed is 2, and no exception should be raised
    response: Response = session.get("http://httpbin.org/get")

    assert response.json().get("url").end

# Generated at 2022-06-24 01:51:42.263260
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import MagicMock, Mock
    with MagicMock() as logger:
        func = LoggedFunction(logger)
        assert func is not None


# Generated at 2022-06-24 01:51:53.983946
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger, DEBUG, basicConfig
    from unittest import TestCase
    from unittest.mock import Mock
    from datetime import date, datetime

    basicConfig(level=DEBUG)

    logger = getLogger(__name__)

    # Unit test for constructor of class LoggedFunction
    def test_LoggedFunction():
        from logging import getLogger, DEBUG, basicConfig
        from unittest import TestCase
        from unittest.mock import Mock
        from datetime import date, datetime

        basicConfig(level=DEBUG)

        logger = getLogger(__name__)

        @LoggedFunction(logger)
        def add(a, b):
            return a + b

        @LoggedFunction(logger)
        def sub(a, b):
            return a - b

       

# Generated at 2022-06-24 01:52:05.721641
# Unit test for function build_requests_session
def test_build_requests_session():
    default_retry = Retry(total=3, read=3, connect=3, backoff_factor=0.1, status_forcelist=(500, 502, 504))
    # test all the valid input
    session = build_requests_session()
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries == Retry()
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert session.adapters["https://"].max_retries == Retry()
    session = build_requests_session(False)
    assert session.hooks == {}
    assert isinstance(session.adapters["http://"], HTTPAdapter)

# Generated at 2022-06-24 01:52:09.494046
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert s.adapters["http://"] == s.adapters["https://"]

# Generated at 2022-06-24 01:52:21.508425
# Unit test for function build_requests_session
def test_build_requests_session():
    from types import MethodType
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from requests import Session

    # Test default output
    session = build_requests_session()
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 1
    assert len(session.hooks["response"]) == 1

    # Test setting option raise_for_status=False
    session = build_requests_session(False)
    assert isinstance(session, Session)
    assert len(session.adapters) == 2
    assert len(session.hooks) == 1
    assert len(session.hooks["response"]) == 0

    # Test setting option retry=False

# Generated at 2022-06-24 01:52:26.368377
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(True) == "True"
    assert format_arg("Foo") == "'Foo'"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:52:33.935806
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    '''
    This function tests the constructor of class LoggedFunction. It verifies whether the logger is properly created, and
    it checks if the decorator works.
    '''
    from loguru import logger

    # Test if logger is created
    @LoggedFunction(logger)
    def test():
        return 'Test'

    # Test if the decorator works
    @LoggedFunction(logger)
    def test_logged_function(number):
        return number + 1

    assert test_logged_function(5) == 6

# Generated at 2022-06-24 01:52:44.633342
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

    assert isinstance(session, Session)
    assert session.hooks is None

    session = build_requests_session(raise_for_status=True)

    assert isinstance(session, Session)
    assert "response" in session.hooks
    assert len(session.hooks["response"]) >= 1

    session = build_requests_session(retry=False)

    assert isinstance(session, Session)
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    def call_hook(response, *args, **kwargs):
        pass

    session = build_requests_session(retry=False)
    session.hooks["response"].append(call_hook)

    assert isinstance(session, Session)
   