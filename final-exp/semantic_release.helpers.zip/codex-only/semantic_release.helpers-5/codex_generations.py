

# Generated at 2022-06-24 01:42:39.767188
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import unittest
    import logging
    import logging.handlers
    import io
    import sys

    class Logger(unittest.TestCase):
        # Set up a logger to use inside tests
        #
        # This logger sends output to an in-memory stream, which is captured by
        # a StringIO object and subsequently checked by test methods.

        @classmethod
        def setUpClass(cls):
            logger = logging.getLogger("test_logger")
            logger.setLevel(logging.DEBUG)

            handler = logging.StreamHandler(io.StringIO())
            handler.setFormatter(logging.Formatter("%(asctime)s - %(message)s"))

            logger.addHandler(handler)

            cls.logger = logger


# Generated at 2022-06-24 01:42:41.214012
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(logging)

# Generated at 2022-06-24 01:42:44.494155
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(' test ') == "' test '"
    assert format_arg(None) == 'None'


# Generated at 2022-06-24 01:42:53.505510
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        "Test class LoggedFunction"

        def test_call_function(self):
            "Test calling function with arguments"

            # Capture logging output
            log_capture_string = io.StringIO()
            ch = logging.StreamHandler(log_capture_string)
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            logger.addHandler(ch)

            @LoggedFunction(logger)
            def add_two_numbers(a, b):
                return a + b

            add_two_numbers(a=1, b=2)


# Generated at 2022-06-24 01:43:03.952464
# Unit test for function build_requests_session
def test_build_requests_session():
    # tests without retry
    session = build_requests_session(retry=False)
    assert session.request.retries.total == 0
    session = build_requests_session(retry=None)
    assert session.request.retries.total == 0
    # test with retry
    session = build_requests_session(retry=True)
    assert session.request.retries.total == 10
    session = build_requests_session(retry=4)
    assert session.request.retries.total == 4
    retry = Retry(connect=10, read=10, redirect=False)
    session = build_requests_session(retry=retry)
    assert session.request.retries.total == retry
    with pytest.raises(ValueError):
        build_requests_

# Generated at 2022-06-24 01:43:13.870325
# Unit test for function build_requests_session
def test_build_requests_session():
    # test default value
    session = build_requests_session()
    assert session.hooks is None
    assert isinstance(session.adapters, dict)
    assert len(session.adapters) == 2

    # test set value
    session = build_requests_session(False, Retry(total=1, status_forcelist=[404]))
    assert session.hooks is None
    assert isinstance(session.adapters, dict)
    assert len(session.adapters) == 2
    for adapter in session.adapters.values():
        assert adapter.max_retries.total == 1
        assert 404 in adapter.max_retries.status_forcelist



# Generated at 2022-06-24 01:43:18.028194
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    @LoggedFunction(logging.getLogger())
    def foo(*args):
        return args

    assert foo(1, 2, 3, bar="baz") == (1, 2, 3)

# Generated at 2022-06-24 01:43:28.666019
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    session = build_requests_session(retry=True)
    assert isinstance(session, Session)
    session = build_requests_session(retry=10)
    assert isinstance(session, Session)
    r = Retry(connect=10)
    session = build_requests_session(retry=r)
    assert isinstance(session, Session)
    try:
        session = build_requests_session(retry="abc")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 01:43:35.688826
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    m_logger = unittest.mock.MagicMock()
    m_logged_func = LoggedFunction.__call__(
        m_logger,
        lambda: None
    )
    m_logged_func(1, 2, 3, 4)
    m_logger.debug.assert_called_with("<lambda>(1, 2, 3, 4)")

# Generated at 2022-06-24 01:43:41.457498
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    print(s.mounts)
    r = s.get("https://www.google.com")
    print(r.text)



# Generated at 2022-06-24 01:43:47.817089
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('hello') == "'hello'"
    assert format_arg('no trailing space') == "'no trailing space'"
    assert format_arg('leading space ') == "'leading space '"
    assert format_arg(' both leading and trailing') == "' both leading and trailing'"


# Generated at 2022-06-24 01:43:59.216844
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import DEBUG, StreamHandler, getLogger
    from io import StringIO
    from sys import stdout
    from unittest import TestCase

    with StringIO() as out:
        stdout.write = out.write
        logger = getLogger()
        handler = StreamHandler(stdout)
        logger.addHandler(handler)
        logger.setLevel(DEBUG)
        logged_function = LoggedFunction(logger)

        @logged_function
        def add(a, b):
            return a + b

        add(1, 2)
        add(1, b=2)
        add(a=1, b=2)


# Generated at 2022-06-24 01:44:01.981681
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(3) == "3"
    assert format_arg("A B") == "'A B'"


# Generated at 2022-06-24 01:44:13.188674
# Unit test for function build_requests_session

# Generated at 2022-06-24 01:44:20.751195
# Unit test for function build_requests_session
def test_build_requests_session():
    import json
    import pytest
    from requests import HTTPError

    session = build_requests_session(retry=False)
    assert session.mounts["http://"] == []
    assert session.mounts["https://"] == []
    response = session.get("https://httpbin.org/get", params={"hello": "world"})
    result = json.loads(response.content.decode("utf-8"))
    assert "hello" in result["args"]
    with pytest.raises(HTTPError):
        session.get("https://httpbin.org/status/404")

    session = build_requests_session(retry=1)
    assert isinstance(session.mounts["http://"][0].max_retries, Retry)
    assert session.mounts["http://"][0].max_

# Generated at 2022-06-24 01:44:30.329301
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError

    session = build_requests_session()
    assert session.max_redirects == 30
    session.get('http://httpbin.org/get') # No error
    try:
        session.get('http://httpbin.org/status/404')
        assert False, "Non-200 response should raise an error"
    except HTTPError:
        pass

    session = build_requests_session(raise_for_status=False)
    session.get('http://httpbin.org/get') # No error
    session.get('http://httpbin.org/status/404')

    session = build_requests_session(retry=False)
    session.get('http://httpbin.org/get') # No error

# Generated at 2022-06-24 01:44:39.767182
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class MockLogger(object):
        def __init__(self):
            self.debug_message = None

        def debug(self, message):
            self.debug_message = message

    def test_function(a, b, c='kw_arg'):
        return "return value"

    logger = MockLogger()
    logged_function = LoggedFunction(logger)
    decorated = logged_function(test_function)
    decorated(1, 3, c=4)
    assert logger.debug_message == "test_function(1, 3, c=4)"

if __name__ == '__main__':
    test_LoggedFunction()

# Generated at 2022-06-24 01:44:46.917887
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1.0) == "1.0"
    assert format_arg(1) == "1"
    assert format_arg("abc") == "\'abc\'"
    assert format_arg("a b c") == "\'a b c\'"
    assert format_arg("1a&%$") == "\'1a&%$\'"
    assert format_arg("1a&%$ b") == "\'1a&%$ b\'"

# Generated at 2022-06-24 01:44:50.563843
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("'test'") == "'test'"
    assert format_arg("test") == "'test'"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:44:54.969514
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.Logger()
    logged_func = LoggedFunction(logger=logger)
    @logged_func
    def add(x, y):
        return x + y
    assert add(1, 2) == 3


# Generated at 2022-06-24 01:45:01.807033
# Unit test for function build_requests_session
def test_build_requests_session():
    etag_request_header_key = "If-None-Match"
    etag_response_header_key = "ETag"
    etag_request_header_value = "123"
    etag_response_header_value = "456"
    dummy_url = "http://www.example.com"

    # test default parameter values
    test_session_default_params = build_requests_session()
    req = test_session_default_params.get(dummy_url)
    assert req.status_code == 200
    assert etag_request_header_key not in req.request.headers

    # test return type for function
    assert isinstance(test_session_default_params, Session)

    # test default parameter values with default retry configuration
    test_session_retry_false = build_requests_session

# Generated at 2022-06-24 01:45:11.026057
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class Logger:
        def __init__(self):
            self.log = []
        def debug(self, msg):
            self.log.append(msg)

    logger = Logger()

    def test_function(a, b, c=None):
        pass

    logged_function = LoggedFunction(logger)(test_function)
    logged_function('a', 'b')
    assert logger.log[0] == "test_function(a, b)"

    logged_function('a', 'b', c='c')
    assert logger.log[1] == "test_function(a, b, c='c')"


# Generated at 2022-06-24 01:45:13.055143
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    Just instantiate the class LoggedFunction.
    """
    from logging import getLogger

    logger = getLogger()
    LoggedFunction(logger)

# Generated at 2022-06-24 01:45:24.081920
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    LoggedFunction(logger)(logging)("logging")("logging")
    LoggedFunction(logger)(sum)([1, 2, 3])
    LoggedFunction(logger)(sum)(1, 2, 3)

# Generated at 2022-06-24 01:45:27.071788
# Unit test for function format_arg
def test_format_arg():
    assert(format_arg(1) == "1")
    assert(format_arg(1.0) == "1.0")
    assert(format_arg("") == "''")
    assert(format_arg("abc") == "'abc'")

# Generated at 2022-06-24 01:45:30.278605
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == '123'
    assert format_arg("123") == "'123'"
    assert format_arg("  123  ") == "'  123  '"
    assert format_arg("'") == "''"

# Generated at 2022-06-24 01:45:33.728024
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction(): 
    class Test(LoggedFunction):
        def test_hello(self, name):
            return f"hello {name}!"

    t = Test(None)
    assert t.test_hello("chhliu") == "hello chhliu!"
    assert t.test_hello(4) == "hello 4!"
 

# Generated at 2022-06-24 01:45:41.745482
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from loguru import logger
    from unittest.mock import patch
    from docopt import docopt

    import automatic_speech_recognition as asr

    def func1(x, y, z):
        return x + y + z

    def func2(x, y, z=1):
        return x + y + z

    def func3(x, y, **kwargs):
        return x + y + len(kwargs)

    def func4(x, y, z=1, **kwargs):
        return x + y + z + len(kwargs)

    def func5(*args):
        return len(args)

    def func6(**kwargs):
        return len(kwargs)

    def func7(*args, **kwargs):
        return len(args) + len(kwargs)


# Generated at 2022-06-24 01:45:52.544338
# Unit test for function build_requests_session
def test_build_requests_session():
    from unittest.mock import Mock, patch
    from requests.adapters import HTTPAdapter

    # should not raise any exception
    s = build_requests_session()

    # should raise exception
    def side_effect(*args, **kwargs):
        raise Exception("exception")

    # set up mocks
    hooked_response = Mock()
    hooked_response.status_code = 200
    hooked_response.raise_for_status = side_effect
    session = Mock()
    session.hooks = {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    session.send = Mock(return_value=hooked_response)

    def mock_session_init(*args, **kwargs):
        return session


# Generated at 2022-06-24 01:46:03.390667
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    _logged_func = LoggedFunction(logger = log)
    _logged_func(func = pd.DataFrame.describe)
    _logged_func(func = pd.DataFrame.describe, logger = log)
    _logged_func(func = pd.DataFrame.describe, logger = log)
    _logged_func(func = pd.DataFrame.describe, logger = log)
    _logged_func(func = pd.DataFrame.describe, logger = log)
    _logged_func(func = pd.DataFrame.describe, logger = log)
    _logged_func(func = pd.DataFrame.describe, logger = log)


log = logging.getLogger(__name__)

## Configuration for devpysysml.log module

# Generated at 2022-06-24 01:46:03.871443
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert callable(LoggedFunction)



# Generated at 2022-06-24 01:46:06.246024
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg("abc") == "'abc'"
    assert format_arg(None) == 'None'

# Generated at 2022-06-24 01:46:16.199295
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(
        raise_for_status=True, retry=Retry(total=15, method_whitelist=False)
    )
    session = build_requests_session(
        raise_for_status=True, retry=True
    )
    session = build_requests_session(
        raise_for_status=True, retry=False
    )
    session = build_requests_session(
        raise_for_status=True, retry=10
    )
    session = build_requests_session(
        raise_for_status=True
    )



# Generated at 2022-06-24 01:46:21.752777
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    @LoggedFunction(logger)
    def foo(a, b, c=1):
        return a + b + c

    foo(4, 2, c=3)
    foo(4, 2)
    foo(10, 2, c=10)


# Generated at 2022-06-24 01:46:30.852116
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest

    class TestCase(unittest.TestCase):
        def test_with_return_value(self):
            sio=io.StringIO()
            logger=logging.getLogger()
            formatter=logging.Formatter('%(message)s')
            handler=logging.StreamHandler(sio)
            handler.setFormatter(formatter)
            logger.handlers=[]
            logger.addHandler(handler)
            logger.setLevel(logging.DEBUG)

            @LoggedFunction(logger)
            def return_value(x):
                return x

            return_value(1)
            self.assertEqual(sio.getvalue(), 'return_value(1)\nreturn_value -> 1\n')


# Generated at 2022-06-24 01:46:38.169196
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test_LoggedFunction")
    def func(a, b, *args, **kwargs):
        return a + b
    logged_func = LoggedFunction(logger)(func)
    assert func.__name__ == logged_func.__name__
    assert func.__doc__ == logged_func.__doc__
    assert func.__module__ == logged_func.__module__
    assert func(1, 2) == logged_func(1, 2)
    assert func(1, 2, c=3) == logged_func(1, 2, c=3)

# Generated at 2022-06-24 01:46:41.533205
# Unit test for function format_arg
def test_format_arg():
    print("======= Test function format_arg ======= ")
    assert format_arg("") == "''"
    assert format_arg("hello") == "'hello'"
    assert format_arg("123") == "'123'"
    assert format_arg(None) == "None"
    print("Test for function format_arg passed.")


# Generated at 2022-06-24 01:46:46.350685
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def dummy_logger():
        pass

    # The dummy_logger is not callable
    with pytest.raises(TypeError):
        LoggedFunction(dummy_logger)



# Generated at 2022-06-24 01:46:49.093406
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("a") == "'a'"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(True) == "True"
    assert format_arg(None) == "None"


# Generated at 2022-06-24 01:46:54.105010
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" a b ") == "'a b'"
    assert format_arg("123") == "'123'"
    assert format_arg(123) == "123"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"
    assert format_arg({"a": "b"}) == '{"a": "b"}'

# Generated at 2022-06-24 01:46:58.764124
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging

    logger = logging.getLogger()

    class Test(unittest.TestCase):
        def setUp(self):
            self.lf = LoggedFunction(logger)

        def test_logged_func(self):
            logger.addHandler(logging.StreamHandler())
            logger.setLevel(logging.DEBUG)

            @self.lf
            def add(a, b):
                return a + b

            add(1, 2)

    unittest.main()

# Generated at 2022-06-24 01:47:02.784226
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    pass
# - END test_LoggedFunction

# Generated at 2022-06-24 01:47:09.257337
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hi") ==  "'hi'"
    assert format_arg("hi ") ==  "'hi'"
    assert format_arg(3) ==  "3"
    assert format_arg(3.0) ==  "3.0"
    assert format_arg(None) ==  "None"

# Generated at 2022-06-24 01:47:12.915351
# Unit test for function format_arg
def test_format_arg():
    from nose.tools import assert_equal, assert_raises
    assert_equal(format_arg(1), '1')
    assert_equal(format_arg(' abc '), "'abc'")
    assert_raises(TypeError, format_arg, None)


# Generated at 2022-06-24 01:47:24.473475
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        LoggedFunction()
        assert False, "Successfully constructed LoggedFunction without parameter"
    except TypeError:
        pass
    try:
        LoggedFunction(1)
        assert False, "Successfully constructed LoggedFunction with int parameter"
    except TypeError:
        pass
    try:
        LoggedFunction("a")
        assert False, "Successfully constructed LoggedFunction with string parameter"
    except TypeError:
        pass
    try:
        LoggedFunction(1.0)
        assert False, "Successfully constructed LoggedFunction with float parameter"
    except TypeError:
        pass
    try:
        LoggedFunction([])
        assert False, "Successfully constructed LoggedFunction with list parameter"
    except TypeError:
        pass

# Generated at 2022-06-24 01:47:31.613336
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('ab') == 'ab'
    assert format_arg(' ab') == 'ab'
    assert format_arg('ab ') == 'ab'
    assert format_arg(' ab ') == 'ab'
    assert format_arg(1) == '1'
    assert format_arg(1.1) == '1.1'
    assert format_arg('a"b') == "'a\"b'"
    assert format_arg("a'b") == "'a\'b'"
    assert format_arg("a's'b") == "'a\'s\'b'"

# Generated at 2022-06-24 01:47:40.040795
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from sqlalchemy.ext.declarative import declarative_base, Column, Integer, String
    from sqlalchemy import create_engine, MetaData
    from logging import Logger, getLogger
    import logging

    metadata = MetaData()
    Base = declarative_base(metadata=metadata)

    class User(Base):
        __table__ = Table('users', metadata,
                        Column('id', Integer, primary_key=True),
                        Column('name', String),
                        Column('fullname', String),
                        )
    engine = create_engine('sqlite:///:memory:')
    logger = getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())



# Generated at 2022-06-24 01:47:47.049344
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    @LoggedFunction(logger)
    def test_func(a: int, b: float):
        return a + b
    assert test_func.__name__ == 'test_func'
    assert test_func.__qualname__ == 'test_LoggedFunction.<locals>.test_func'
    assert test_func(1, 2.5) == 3.5


# Generated at 2022-06-24 01:47:53.755586
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger
    from logzero import logger
    logger = getLogger("test")
    loggedFunction = LoggedFunction(logger)
    def sampleFunc():
        return 'Sample'
    result = loggedFunction(sampleFunc)
    assert result() == 'Sample'

# Generated at 2022-06-24 01:47:57.530355
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(logging.getLogger(__file__))

# Generated at 2022-06-24 01:48:06.427176
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    logging.basicConfig(level=logging.DEBUG)

    class TestLoggedFunction(unittest.TestCase):
        def test_logging(self):
            @LoggedFunction(logging.getLogger())
            def add(x, y):
                return x + y

            self.assertEqual(add(1, 2), 3)
            self.assertEqual(add(1, y=2), 3)
            self.assertEqual(add("a", "b"), "ab")

    unittest.main()


# Generated at 2022-06-24 01:48:15.936548
# Unit test for function format_arg

# Generated at 2022-06-24 01:48:22.999387
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test for method __call__ of class LoggedFunction
    """
    import logging
    import unittest

    class LogHandler(logging.Handler):
        """
        Log handler.

        Used to capture the log messages created by the test code.
        """

        def __init__(self, log_level: int = logging.DEBUG):
            super().__init__(log_level)
            self.records = []

        def emit(self, record: logging.LogRecord) -> None:
            self.records.append(record)

    class LoggedFunctionTest(unittest.TestCase):
        """
        Class to unit test LoggedFunction.
        """

        def test___call__(self):
            """
            Test for LoggedFunction.__call__
            """

# Generated at 2022-06-24 01:48:30.885858
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class Test:
        def __init__(self):
            self.logger = logging.getLogger("test")

        @LoggedFunction(logger=logging.getLogger("test"))
        def add(self, a, b):
            return a + b

    test = Test()
    test.add(3, 4)
    #logging.info("this is a test for LoggedFunction")
    
    

# Generated at 2022-06-24 01:48:42.058080
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    args = "-l -a"
    kwargs = [('-k','v'),('-a','bbb')]
    func = LoggedFunction(None)
    @func
    #def func(arg1, arg2, *args, arg3=None, arg4=None, **kwargs):
    def func(arg1, arg2, *args, **kwargs):
        return 'success'
    print(func.__name__)
    from logging import getLogger, DEBUG
    _logger = getLogger(name=__name__)
    _logger.setLevel(DEBUG)
    _logger.debug(func(args, *kwargs))
    #func.__call__(func)
#test_LoggedFunction___call__()

# Generated at 2022-06-24 01:48:51.518385
# Unit test for function build_requests_session
def test_build_requests_session():
    import nose

    session = build_requests_session()
    assert isinstance(session, Session)
    assert "response" in session.hooks
    assert len(session.adapters) == 2
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)

    session = build_requests_session(raise_for_status=False)
    assert "response" not in session.hooks

    nose.tools.assert_raises(ValueError, build_requests_session, retry="10")

# Generated at 2022-06-24 01:48:58.102560
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Mock()

    def test_func(first, second=None):
        return 1

    logged_func = LoggedFunction(logger)(test_func)
    logged_func("a", "b")
    result = logged_func("a", second="b")
    assert result == 1

    logger.debug.assert_has_calls(
        [
            call("test_func('a', 'b')"),
            call("test_func -> 1"),
            call("test_func('a', second='b')"),
            call("test_func -> 1"),
        ]
    )

# Generated at 2022-06-24 01:49:01.991515
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" hello world ") == "' hello world '"
    assert format_arg(123) == "123"


# Generated at 2022-06-24 01:49:13.686640
# Unit test for function build_requests_session
def test_build_requests_session():
    import random
    import string
    import os
    import math
    import urllib3

    def generate_random_string(length: int) -> str:
        if length < 1:
            raise ValueError("Length of random string must be positive")

        return "".join(
            random.SystemRandom().choice(string.ascii_uppercase + string.digits)
            for _ in range(length)
        )

    def test_default_configuration(logger):
        logger.info("Testing default configuration of requests session...")
        session = build_requests_session()
        logger.info("Testing connection with google...")
        session.get("http://www.google.com")
        logger.info("Default configuration check passed!")
        logger.info("Testing default retry configuration")
        default_retry = Retry

# Generated at 2022-06-24 01:49:20.020413
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger("test_logger")
    
    result = ""
    
    @LoggedFunction(logger)
    def test_func(arg1, arg2):
        result = f"{arg1} {arg2}"
        return result

    test_func("arg1", "arg2")
    
    assert result == "arg1 arg2"

# Generated at 2022-06-24 01:49:21.093297
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction("logging") != None

# Generated at 2022-06-24 01:49:26.076191
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg("\nabc   \t") == "'abc'"
    assert format_arg("'abc''") == "'abc'''"
    assert format_arg("\"abc\"") == "'\"abc\"'"

# Generated at 2022-06-24 01:49:30.878050
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger, DEBUG
    from unittest.mock import Mock
    logger = Mock(Logger)
    logger.debug = Mock(spec=Logger.debug)
    logged_func = LoggedFunction(logger)
    def func(*args, **kwargs):
        pass
    func_with_log = logged_func(func)
    func_with_log()
    logger.debug.assert_called_once_with(f"{func.__name__}()")

    logger.debug.reset_mock()
    func_with_log(1)
    logger.debug.assert_called_once_with(f"{func.__name__}(1)")

    logger.debug.reset_mock()
    func_with_log(1, 2, 3)
    logger.debug.assert_called_

# Generated at 2022-06-24 01:49:39.576379
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def foo(a, b, c=3):
        return a + b + c
    logger = logging.getLogger("foo")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.NullHandler())
    foo_logger = LoggedFunction(logger)
    result = foo_logger(foo)
    assert result(1, 2) == 6
    result = foo_logger(foo)
    assert result(1, 2, c=4) == 7

if __name__ == "__main__":
    test_LoggedFunction()

# Generated at 2022-06-24 01:49:46.030429
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=True)
    assert len(session.adapters) == 2

    session = build_requests_session(retry=Retry(total=3))
    assert len(session.adapters) == 2
    assert session.adapters["http://"].max_retries.total == 3

# Generated at 2022-06-24 01:49:51.260874
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('hello') == "'hello'"
    assert format_arg('hello world') == "'hello world'"
    assert format_arg(3) == "3"
    assert format_arg(3.14) == "3.14"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:49:56.995141
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        build_requests_session(retry="test")
        assert False
    except ValueError as e:
        assert "retry should be a bool, int or Retry instance." in str(e)
        pass
    try:
        build_requests_session(retry=[0])
        assert False
    except ValueError as e:
        assert "retry should be a bool, int or Retry instance." in str(e)
        pass

    # Test normal cases
    build_requests_session()
    build_requests_session(retry=False)
    build_requests_session(retry=True)
    build_requests_session(raise_for_status=False)
    build_requests_session(retry=0)
    build_requests_session(retry=100)
   

# Generated at 2022-06-24 01:50:02.546132
# Unit test for function format_arg
def test_format_arg():
    assert "123" == format_arg(123)
    assert "'test'" == format_arg("test")
    assert "'a test'" == format_arg("a test")
    assert "'test with space'" == format_arg("test with space")
    assert "'test with spaces   '" == format_arg("test with spaces   ")


# Generated at 2022-06-24 01:50:13.795096
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import os
    import tempfile
    import unittest
    import requests

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            # Create a temporary file
            self.test_file, self.test_file_name = tempfile.mkstemp()

            # Create a logger with a temporary file handler
            self.test_logger = logging.getLogger(__name__)
            self.test_logger.setLevel(logging.DEBUG)
            self.file_handler = logging.FileHandler(self.test_file_name)
            self.file_handler.setLevel(logging.DEBUG)
            self.test_logger.addHandler(self.file_handler)

        def tearDown(self):
            # Close and delete the temporary file
            self.file

# Generated at 2022-06-24 01:50:24.630739
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import pytest
    # test with raising for status
    with pytest.raises(requests.exceptions.HTTPError):
        session = build_requests_session()
        session.get("http://httpbin.org/status/404")
    # test with retries
    session = build_requests_session(raise_for_status=False, retry=Retry(0, False))
    with pytest.raises(requests.exceptions.ConnectionError):
        session.get("http://bad.domain.com")
    # test with total retries
    session = build_requests_session(raise_for_status=False, retry=1)
    with pytest.raises(requests.exceptions.ConnectionError):
        session.get("http://bad.domain.com")
    # test with

# Generated at 2022-06-24 01:50:36.613033
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.5) == "1.5"
    assert format_arg((1, 2, 3)) == "(1, 2, 3)"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"
    assert format_arg({"a": 1, "b": 2}) == "{'a': 1, 'b': 2}"
    assert format_arg("a") == "'a'"
    assert format_arg(" a ") == "' a '"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"



# Generated at 2022-06-24 01:50:39.224505
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session()
    assert requests_session is not None, "should create a new session"
    requests_session.close()



# Generated at 2022-06-24 01:50:44.889294
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.call_count = 0
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)
            self.call_count += 1

    @LoggedFunction(TestLogger())
    def test_func(a, b, c):
        return a + b + c

    test_func("1", b="2", c="3")
    assert test_func.logger.call_count == 2

# Generated at 2022-06-24 01:50:49.780254
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == "5"
    assert format_arg("hello") == "'hello'"
    assert format_arg(" hello ") == "' hello '"

# Generated at 2022-06-24 01:50:53.233897
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        a = LoggedFunction()
    except:
        AssertionError("Should not display exception if no arguments are passed.")
    try:
        a = LoggedFunction(logger="logger")
    except:
        AssertionError("Should not display exception if an object is passed.")

# Generated at 2022-06-24 01:50:57.263318
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from pytest import raises

    logger = object()
    lf = LoggedFunction(logger)

    assert lf.logger == logger

    with raises(ValueError):
        LoggedFunction(logger, invalid=True)

# Unit test of function __call__ of class LoggedFunction

# Generated at 2022-06-24 01:51:02.975975
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("foo") == "'foo'"
    assert format_arg("foo bar") == "'foo bar'"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:51:13.016171
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    def target(hello, world, **kwargs):
        return hello + world
    
    logger.debug("a"*10)
    logged_target = LoggedFunction(logger)(target)
    logged_target("hello", "world", first="one", second="two")
    logger.debug("a"*10)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-24 01:51:20.265140
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session
    assert type(build_requests_session(retry=True)) == Session
    assert type(build_requests_session(retry=False)) == Session


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-24 01:51:29.727683
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    raise_for_status = True
    retry = True
    retry_count = 10
    retry_config = Retry(retry_count)
    session = build_requests_session(raise_for_status, retry)
    assert isinstance(session, requests.Session)
    assert raise_for_status == True
    assert retry == True

    session = build_requests_session(raise_for_status, retry_count)
    assert isinstance(session, requests.Session)
    assert raise_for_status == True
    assert isinstance(session.adapters['http://'].max_retries, Retry)
    assert session.adapters['http://'].max_retries.total == retry_count

# Generated at 2022-06-24 01:51:38.058877
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import random
    import time
    import logging
    import logging.config

    # Setup logging

# Generated at 2022-06-24 01:51:41.632231
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session
    assert type(build_requests_session(None, True)) == Session
    assert type(build_requests_session(None, Retry())) == Session
    assert type(build_requests_session(None, 3)) == Session
    try:
        build_requests_session(None, "hello world")
    except ValueError as e:
        assert True
    else:
        assert False



# Generated at 2022-06-24 01:51:48.330948
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg("abc") == "'abc'"
    assert format_arg(" a b c ") == "' a b c '"

# Generated at 2022-06-24 01:51:53.809659
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg("") == "''"
    assert format_arg("   ") == "''"
    assert format_arg("'") == "''"
    assert format_arg("'   ") == "''"
    assert format_arg("a b c") == "'a b c'"
    assert format_arg("a b c",) == "'a b c'"
    assert format_arg("a,b,c") == "'a,b,c'"

# Generated at 2022-06-24 01:51:58.287469
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger=logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def foo(a, b, *args):
        return a / b

    assert foo(1, 2) == 0.5

# Generated at 2022-06-24 01:52:04.550265
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg("ab'c") == "'ab'c'"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(None) == "None"


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:52:14.302824
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    class MockLogger:
        def __init__(self):
            self.messages = []

        def debug(self, *args, **kwargs):
            self.messages.append((args, kwargs))

    mock_logger = MockLogger()
    logged_function = LoggedFunction(mock_logger)

    @logged_function
    def my_function(x, y, z="wibble"):
        return x + y + z

    my_function(1, y=2)
    assert mock_logger.messages == [
        (("my_function(1, y=2)",), {}),
        (("my_function -> 3wibble",), {}),
    ]

    @logged_function
    def my_none_function():
        return None

   

# Generated at 2022-06-24 01:52:20.476395
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logzero import logger
    logger.setLevel("DEBUG")
    logger.name = "LoggedFunction"
    @LoggedFunction(logger)
    def foo(x, y=2, z=3):
        pass
    foo(1, z=2)
    foo(x=1, z=2)
    foo(x=1, y=2)
    foo(1, 2, 3)



# Generated at 2022-06-24 01:52:21.260355
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    lf = LoggedFunction()
    assert lf is not None

# Generated at 2022-06-24 01:52:24.760689
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    my_logger = logging.getLogger("mylogger")
    my_logged = LoggedFunction(my_logger)
    assert my_logged.logger == my_logger

# Generated at 2022-06-24 01:52:28.035760
# Unit test for function format_arg
def test_format_arg():
    a = 100
    b = "a string"
    assert format_arg(a) == "100"
    assert format_arg(b) == "'a string'"

# Generated at 2022-06-24 01:52:30.126193
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def test_func(a, b):
        pass
    logger = logging.getLogger("test_logger")
    dec = LoggedFunction(logger)
    func = dec(test_func)
    assert(func.__name__ == "test_func")
    assert(func.__module__ == "__main__")

# Generated at 2022-06-24 01:52:38.813192
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters
    assert session.adapters.keys()
    assert len(session.adapters) == 2
    assert "http://" in session.adapters
    assert "https://" in session.adapters
    assert session.hooks

    session = build_requests_session(raise_for_status=False)
    assert not session.hooks

    session = build_requests_session(retry=False)
    assert not session.adapters
    assert not session.adapters.keys()
    assert len(session.adapters) == 0

    session = build_requests_session(retry=5)
    assert session.adapters
    assert session.adapters.keys()
    assert len(session.adapters) == 2