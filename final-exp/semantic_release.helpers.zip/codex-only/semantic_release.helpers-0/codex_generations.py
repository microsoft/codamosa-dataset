

# Generated at 2022-06-24 01:42:45.073309
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert type(session.adapters["http://"]) == HTTPAdapter
    assert type(session.adapters["https://"]) == HTTPAdapter
    assert session.adapters["http://"].max_retries == Retry(
        total=10, method_whitelist=frozenset(["GET", "PUT", "HEAD"]), status_forcelist=(500, 502, 504)
    )
    assert session.adapters["https://"].max_retries == Retry(
        total=10, method_whitelist=frozenset(["GET", "PUT", "HEAD"]), status_forcelist=(500, 502, 504)
    )
    assert {"response": [lambda r, *args, **kwargs: r.raise_for_status()]} in session.hooks.values

# Generated at 2022-06-24 01:42:48.944290
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("a") == "'a'"
    assert format_arg(" a ") == "' a '"
    assert format_arg({"a": "b"}) == "{'a': 'b'}"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"

# Generated at 2022-06-24 01:42:52.998487
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def function():
        pass

    # Create the decorator
    log_function = LoggedFunction(logging.getLogger())

    # Decorate a function
    decorated_function = log_function(function)

    # Check the __name__ attribute
    assert decorated_function.__name__ == "function"

# Generated at 2022-06-24 01:42:56.752974
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('2') == "'2'"
    assert format_arg('3 ') == "'3 '"
    assert format_arg(None) == 'None'
    assert format_arg(True) == 'True'


# Generated at 2022-06-24 01:43:04.815387
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == 'None'
    assert format_arg("None") == "'None'"
    assert format_arg(0) == '0'
    assert format_arg("0") == "'0'"
    assert format_arg("0.0") == "'0.0'"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc def") == "'abc def'"
    assert format_arg("'abc'") == "'\\'abc\\''"


if __name__ == "__main__":
    # Unit test for function format_arg
    test_format_arg()

# Generated at 2022-06-24 01:43:12.274304
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session
    assert type(build_requests_session(retry=False)) == Session
    assert type(build_requests_session(retry=True)) == Session
    assert type(build_requests_session(retry=1)) == Session
    assert type(build_requests_session(retry=Retry())) == Session
    try:
        build_requests_session(retry=0)
        assert False, "Should have raised ValueError"
    except ValueError:
        pass
    try:
        build_requests_session(retry=Retry(total=0))
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

# Generated at 2022-06-24 01:43:18.126729
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("hello") == "'hello'"
    assert format_arg(True) == "True"
    assert format_arg(None) == "None"
    assert format_arg(1.0) == "1.0"
    assert format_arg(["a", "b"]) == "['a', 'b']"
    assert format_arg(("a", "b")) == "('a', 'b')"
    assert format_arg({1, 2}) == "{1, 2}"
    assert format_arg({"a": "b"}) == "{'a': 'b'}"


if __name__ == "__main__":
    test_format_arg()
    import logging

    logging.basicConfig(level=logging.DEBUG)


# Generated at 2022-06-24 01:43:29.534804
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError

    session = build_requests_session(retry=3)
    try:
        session.get("http://httpbin.org/status/404")
    except HTTPError as e:
        assert e.response.status_code == 404

    session = build_requests_session(retry=True)
    try:
        session.get("http://httpbin.org/status/404")
    except HTTPError as e:
        assert e.response.status_code == 404

    session = build_requests_session(retry=False)
    try:
        session.get("http://httpbin.org/status/404")
    except HTTPError as e:
        assert e.response.status_code == 404


# Generated at 2022-06-24 01:43:40.516841
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert isinstance(session.adapters["https://"].max_retries, Retry)
    assert session.adapters["https://"].max_retries.total == 0
    assert session.adapters["https://"].max_retries.connect == 0
    assert session.adapters["https://"].max_retries.read == 0
    assert session.adapters["https://"].max_retries.status == 0
    assert session.adapters["http://"].max_retries.total == 0
    assert session.adapters["http://"].max_retries.connect == 0
    assert session.adapters["http://"].max

# Generated at 2022-06-24 01:43:41.815929
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('test') ==  "'test'"
    assert format_arg(12) ==  "12"

# Generated at 2022-06-24 01:43:46.261464
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == '123'
    assert format_arg("'123") == "'\\'123'"
    assert format_arg("\\") == "'\\\\'"

# Generated at 2022-06-24 01:43:51.374936
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class Logger:
        def __init__(self):
            self.logged = []

        def debug(self, msg):
            self.logged.append(msg)

    logger = Logger()
    decorated = LoggedFunction(logger)(func)
    decorated(10, 20, A=30, B=40)

    assert logger.logged[0] == "func(10, 20, A='30', B='40')"
    assert logger.logged[1] == "func -> 70"


# Generated at 2022-06-24 01:43:59.968838
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert s is not None
    assert s.hooks == {}

    s = build_requests_session(raise_for_status=True)
    assert s.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

    s = build_requests_session(raise_for_status=True, retry=True)
    assert s.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    assert isinstance(s.adapters["http://"], HTTPAdapter)
    assert s.adapters["http://"].max_retries.total == 10
    assert s.adapters["https://"].max_retries.total == 10


# Generated at 2022-06-24 01:44:09.934843
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False, False)
    assert session.hooks == dict()
    session = build_requests_session(False, Retry(total=3, status_forcelist=[401]))
    assert session.hooks == dict()
    session = build_requests_session(False, 3)
    assert session.hooks == dict()
    session = build_requests_session(True, False)
    assert callable(session.hooks["response"][0])
    session = build_requests_session(True, Retry(total=3, status_forcelist=[401]))
    assert callable(session.hooks["response"][0])
    session = build_requests_session(True, 3)
    assert callable(session.hooks["response"][0])

# Generated at 2022-06-24 01:44:17.894898
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test 1
    def foo(a, b, c, d):
        pass

    actual = LoggedFunction(logging.Logger)(foo)(1, 2, 3, 4)
    assert actual == None

    # Test 2
    def foo(a, b, c, d):
        return 5

    actual = LoggedFunction(logging.Logger)(foo)(1, 2, 3, 4)
    assert actual == 5

    # Test 3
    def foo(a: str, b: float, c: int, d: bool):
        return 5

    actual = LoggedFunction(logging.Logger)(foo)(1, 2, 3, 4)
    assert actual == 5



# Generated at 2022-06-24 01:44:22.996345
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(0.5) == '0.5'
    assert format_arg('0.5') == "'0.5'"
    assert format_arg("'a'") == "'a'"
    assert format_arg('') == "''"


# Generated at 2022-06-24 01:44:25.644100
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    result = LoggedFunction("test")

    assert result.logger == "test"


# Generated at 2022-06-24 01:44:28.119293
# Unit test for function format_arg
def test_format_arg():
    for x, y in [
        (1, "1"),
        ("a", "'a'"),
        (" a ", "'a'"),
        (" a b ", "'a b'"),
        (" ' ", "' '' '"),
    ]:
        assert format_arg(x) == y

# Generated at 2022-06-24 01:44:36.962138
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import unittest
    import io
    import sys
    import logging
    from contextlib import redirect_stdout
    
    class TestLoggedFunction(unittest.TestCase):
        
        def test_basic_params(self):
            logger = logging.getLogger()
            if len(logger.handlers) > 0:
                logger.handlers.pop()
            logger.propagate = False
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler())
            logged_func = LoggedFunction(logger)
            @logged_func
            def test_decorated(a, b, c, d = '', e = 0):
                return a + b + c + d + e
            f = io.StringIO()

# Generated at 2022-06-24 01:44:42.729065
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        log_info = []
        def debug(self, info):
            self.log_info.append(info)


# Generated at 2022-06-24 01:44:45.243150
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    response = session.get("http://www.baidu.com/")
    assert response.ok

# Generated at 2022-06-24 01:44:54.627360
# Unit test for function build_requests_session
def test_build_requests_session():
    # without arguments, the result must be a requests session
    session = build_requests_session()
    assert isinstance(session, Session)
    # if `raise_for_status` is True, a hook to invoke raise_for_status should be installed
    session = build_requests_session()
    assert "response" in session.hooks
    assert session.hooks["response"][0]()
    # if `raise_for_status` is False, a hook to invoke raise_for_status should not be installed
    session = build_requests_session(False)
    assert "response" not in session.hooks
    # if `retry` is True, set retry to default value.
    session = build_requests_session()
    assert hasattr(session.adapters["http://"], "max_retry")

# Generated at 2022-06-24 01:45:03.566418
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    session = build_requests_session(retry=0)
    assert isinstance(session, Session)
    session = build_requests_session(retry=1)
    assert isinstance(session, Session)
    session = build_requests_session(retry=Retry())
    assert isinstance(session, Session)

# Generated at 2022-06-24 01:45:14.505153
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    message_list = []
    def mocked_logger_debug(message):
        message_list.append(message)
    logger = type("", (object,), {"debug": mocked_logger_debug})()
    @LoggedFunction(logger)
    def test_function(arg1, arg2, kw1=1, kw2=2):
        return arg1 + arg2 + kw1 + kw2
    result = test_function(1, 2, kw1=3, kw2=4)
    assert result == 10
    assert len(message_list) == 3
    assert message_list[0] == "test_function(1, 2, kw1=3, kw2=4)"
    assert message_list[1] == "test_function -> 10"
    assert message_list[2]

# Generated at 2022-06-24 01:45:17.044358
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg('"a"') == "'\"a\"'"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:45:21.528866
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test the constructor of the class LoggedFunction
    func1 = LoggedFunction()
    assert func1.logger == None


# Generated at 2022-06-24 01:45:30.561708
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    '''Test code for
        LoggedFunction.__call__
    '''

    # Arrange
    import logging
    import sys
    import io
    import unittest.mock as um

    logger = logging.getLogger()

# Generated at 2022-06-24 01:45:32.316832
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    Log = LoggedFunction()
    assert Log.logger is None


# Generated at 2022-06-24 01:45:37.073109
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.debug = test_logger_debug
    def test_logger_debug(s):
        print(s)
    @LoggedFunction(TestLogger())
    def test(a,b,c):
        return 2*a+b-c
    test(1,2,3)

# Generated at 2022-06-24 01:45:44.059133
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("1") == "'1'"
    assert format_arg("1.0") == "'1.0'"
    assert format_arg('"') == r"'\"'"
    assert format_arg("'") == r"'\''"
    assert format_arg("123456789") == "'123456789'"
    assert format_arg("ab'cd") == r"'ab\'cd'"


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:45:52.805162
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    s = []
    def logger(s, x):
        s.append(x)
    lf = LoggedFunction(functools.partial(logger, s))
    @lf
    def f(x, y):
        return x + y
    x = 1
    y = 2
    z = f(x,y)
    assert z == 3
    assert len(s) == 2
    assert s[0] == "f(1, 2)"
    assert s[1] == "f -> 3"
    assert f.__name__ == "f"
    @lf
    def f(x, y, a=3, b=4):
        return x + y + a + b
    x = 1
    y = 2
    z = f(x,y)
    assert z == 3 + 4 + 1 + 2
   

# Generated at 2022-06-24 01:46:02.859763
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert len(session.adapters) == 2

    session = build_requests_session(raise_for_status=True)
    assert session.hooks["response"][0].__name__ == "logged_func"

    retry = Retry()
    session = build_requests_session(retry=retry)
    assert session.adapters["http://"].max_retries == retry
    assert session.adapters["https://"].max_retries == retry

    session = build_requests_session(retry=1)
    assert session.adapters["http://"].max_retries.total == 1
    assert session.adapters["https://"].max_retries.total == 1

    session = build_requ

# Generated at 2022-06-24 01:46:07.390787
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("test") == "'test'"
    assert format_arg("  test  ") == "'test'"

# Generated at 2022-06-24 01:46:10.014156
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    session.get("http://www.baidu.com")

# Generated at 2022-06-24 01:46:22.043392
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import DEBUG

    # Given
    log_output = []
    logger = type(
        "Logger",
        (),
        {
            "name": "",
            "level": DEBUG,
            "debug": lambda *args, **kw: log_output.append(
                f"{args[0]} {args[1:]} {kw}"
            ),
            "info": lambda *args, **kw: None,
            "warning": lambda *args, **kw: None,
            "error": lambda *args, **kw: None,
            "critical": lambda *args, **kw: None,
            "exception": lambda *args, **kw: None,
            "log": lambda *args, **kw: None,
        },
    )

    # When
    logged_function = LoggedFunction(logger)

    # Then


# Generated at 2022-06-24 01:46:28.909411
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    test_logger = logging.getLogger()
    test_logger.setLevel(logging.DEBUG)
    @LoggedFunction(test_logger)
    def test_func(a, b, c=3, d="four", e=None):
        print(a, b, c, d, e)
    test_func(1, 2)
    test_func(1, "two", None, "four")
    test_func("one", 2, e=None)



# Generated at 2022-06-24 01:46:37.532757
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from tests.utils import capture_writes

    logger = getLogger()
    input_args = [20, 30]
    input_kwargs = {"a": "A", "b": "B"}
    expected_call_string = "calc({args}{kwargs})".format(
        args=", ".join([format_arg(x) for x in input_args]),
        kwargs="".join([f", {k}={format_arg(v)}" for k, v in input_kwargs.items()]),
    )
    expected_return_string = "calc -> 50"

    def calc():
        return sum(input_args) + sum(input_kwargs.values())


# Generated at 2022-06-24 01:46:48.581583
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert (
        type(s.adapters["https://"]) == HTTPAdapter
    ), "Default configuration should be https."
    s = build_requests_session(raise_for_status=False, retry=False)
    assert s.hooks == {}, "hooks should be empty if raise_for_status is false"
    s = build_requests_session(raise_for_status=False, retry=True)
    assert (
        s.adapters["https://"].max_retries.total == Retry().total
    ), "retry count should be the same as Retry()"
    s = build_requests_session(raise_for_status=False, retry=3)
    assert s.adapters["https://"].max_retries.total == 3

# Generated at 2022-06-24 01:46:50.585647
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    def func1(x, y, z=3):
        return x + y + z

    log_func1 = LoggedFunction(logger=None)(func1)
    assert(log_func1(1, 2, z=4) == 7)

# Generated at 2022-06-24 01:46:56.261182
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.1) == "1.1"
    assert format_arg("abc") == "'abc'"
    assert format_arg("  abc  ") == "'  abc  '"

# Generated at 2022-06-24 01:47:06.100762
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters == {
        "http://": HTTPAdapter(max_retries=Retry()),
        "https://": HTTPAdapter(max_retries=Retry()),
    }
    assert "response" in session.hooks
    assert callable(session.hooks["response"][0])

    session = build_requests_session(False)
    assert "response" not in session.hooks

    session = build_requests_session(retry=False)
    assert session.adapters == {}

    session = build_requests_session(retry=Retry())

# Generated at 2022-06-24 01:47:16.178151
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    from unittest.mock import Mock

    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = Mock()

        def test_ShouldLogNameAndArguments(self):
            logger = self.logger

            @LoggedFunction(logger)
            def test(value):
                return value

            test(4)

            logger.debug.assert_called_with("test(4)")

        def test_ShouldLogReturnValue(self):
            logger = self.logger

            @LoggedFunction(logger)
            def add(a, b):
                return a + b

            add(4, 5)

            logger.debug.assert_called_with("add -> 9")

        def test_ShouldLogReturnValueNone(self):
            logger

# Generated at 2022-06-24 01:47:18.923980
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    x = LoggedFunction(logging.getLogger("test_logger"))
    assert(x.logger == logging.getLogger("test_logger"))

# Generated at 2022-06-24 01:47:23.386397
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == 'None'
    assert format_arg(123) == '123'
    assert format_arg('no') == "'no'"
    assert format_arg(' yes ') == "' yes '"

# Generated at 2022-06-24 01:47:29.007233
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("   abc ") == "'abc'"
    assert format_arg("") == "''"
    assert format_arg(123) == "123"
    assert format_arg(b"bytes") == "b'bytes'"

# Generated at 2022-06-24 01:47:39.207044
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    import unittest

    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

    class LoggedFunctionTest(unittest.TestCase):
        @LoggedFunction(logger)
        def test_function(self, param1, param2="default_val"):
            return "some_output"

        def test_logging(self):
            # Verify logging of no-argument function
            self.test_function()

            # Verify logging of multiple-argument function
            self.test_function("some_parameter")

            # Verify logging of multiple-argument function
            self.test_function("some_parameter", "another_parameter")

    unittest.main()

# Generated at 2022-06-24 01:47:50.225615
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import Mock
    from unittest import TestCase
    from logging import DEBUG
    from typing import List
    from dataclasses import dataclass, field

    @dataclass
    class Record:
        levelno: int
        msg: str = ""

    @dataclass
    class FakeLogger:
        def __init__(self):
            self.handlers: List[Record] = []

        def debug(self, msg: str):
            self.handlers.append(Record(DEBUG, msg))

    logger = FakeLogger()
    func = LoggedFunction(logger)
    decorated_function = func(Mock())
    decorated_function(1, 2, a=3, b=4)
    assert len(logger.handlers) == 2
    assert logger.handlers[0].msg

# Generated at 2022-06-24 01:47:57.706792
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import unittest
    import logging
    
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    def test_function(a, b, c=5):
        return a + b + c

    decorator = LoggedFunction(logger)
    logged_function = decorator(test_function)


# Generated at 2022-06-24 01:48:05.379675
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(10)

    def some_function(*args, **kwargs):
        print(f"args: {args}")
        print(f"kwargs: {kwargs}")
        return 1234

    logged_function = LoggedFunction(logger)(some_function)
    logged_function(1, 2, 3, a=5, b=6, c=7)

# Generated at 2022-06-24 01:48:14.837358
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False)
    session = build_requests_session(False, False)
    session = build_requests_session(False, 0)
    session = build_requests_session(False, Retry())
    session = build_requests_session(False, Retry(2))
    session = build_requests_session()
    session = build_requests_session(retry=False)
    session = build_requests_session(retry=0)
    session = build_requests_session(retry=Retry())
    session = build_requests_session(retry=Retry(2))
    session = build_requests_session(raise_for_status=False)

# Generated at 2022-06-24 01:48:16.249969
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    result = LoggedFunction(1)
    assert result != 1

# Generated at 2022-06-24 01:48:26.001954
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test case 1
    import logging
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    f = LoggedFunction(logger)
    def one(x, y, z=3):
        return x + y + z
    g = f(one)
    assert g.__name__ == "one"
    assert g(2, 3) == 8
    # Test case 2
    import logging
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    f = LoggedFunction(logger)

# Generated at 2022-06-24 01:48:33.579878
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.message = None

        def debug(self, message):
            self.message = message

        def __str__(self):
            return f"FakeLogger:\n\t{self.message}"

    _arg1: int = 2
    _arg2: int = 5
    _arg3: str = "seven"
    _expected_result: int = _arg1 + _arg2

    # Tested function
    def func(_arg1: int, _arg2: int, _arg3: str) -> int:
        return _arg1 + _arg2

    # Test
    _fake_logger = FakeLogger()
    _logged_func = LoggedFunction(_fake_logger)(func)

# Generated at 2022-06-24 01:48:42.036181
# Unit test for function build_requests_session
def test_build_requests_session():
    session=build_requests_session(raise_for_status=False, retry=5)
    assert session.max_redirects==30
    assert session.mounts['http://']
    assert session.mounts['https://']
    assert not session.hooks
    session=build_requests_session(raise_for_status=True)
    assert len(session.hooks['response'])==1
    assert session.max_redirects==30
    assert session.mounts['http://']
    assert session.mounts['https://']



# Generated at 2022-06-24 01:48:50.695734
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    _logger = logging.getLogger("logged-function-test")
    _logger.handlers = []
    _logger.setLevel(logging.DEBUG)
    _ch = logging.StreamHandler()
    _ch.setLevel(logging.DEBUG)
    _logger.addHandler(_ch)
    @LoggedFunction(_logger)
    def test_func(a, b, c=5):
        return "result"
    test_func(1, b=2, c=3)
    # Test output:
    # test_func(1, b=2, c=3)
    # test_func -> result

# if __name__ == "__main__":
#     test_LoggedFunction___call__()

# Generated at 2022-06-24 01:48:54.544914
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("one") == "'one'"
    assert format_arg(True) == "True"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:49:06.054226
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    mock_logger = Mock()
    method_name = "method"
    argument_lists = [
        (()),
        ((1, 2, 3),),
        ((0,), {"a": 1, "b": 2}),
        (("a", 2), {"c": 1, "b": "B", "e": "E"}),
    ]

    for arguments in argument_lists:
        mock_logger.reset_mock()

        @LoggedFunction(mock_logger)
        def method(*args, **kwargs):
            return (args, kwargs)

        method(*arguments[0], **arguments[1])
        assert mock_logger.debug.call_count == 2
        assert method_name in mock_logger.debug.mock_c

# Generated at 2022-06-24 01:49:08.745726
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg(None) == "None"



# Generated at 2022-06-24 01:49:15.297060
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert type(session) == Session

    session = build_requests_session(raise_for_status=False)
    assert type(session) == Session

    session = build_requests_session(raise_for_status=False, retry=True)
    assert type(session) == Session

    session = build_requests_session(raise_for_status=False, retry=3)
    assert type(session) == Session

    retry = Retry()
    session = build_requests_session(raise_for_status=False, retry=retry)
    assert type(session) == Session

    try:
        session = build_requests_session(raise_for_status=False, retry="aa")
    except ValueError:
        assert True



# Generated at 2022-06-24 01:49:22.801040
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from requests.models import Response
    from requests.structures import CaseInsensitiveDict

    logger = Mock()
    logged_func = LoggedFunction(logger)
    func = Mock(return_value="a")
    logged_func = logged_func(func)
    logged_func(1, 2, b=3)
    logger.debug.assert_called_once_with("mock(1, 2, b=3)")


# Generated at 2022-06-24 01:49:28.790528
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock as M
    import logging as L
    import sys
    log = L.getLogger("test_logged_function")
    log.addHandler(L.StreamHandler(sys.stdout))
    log.setLevel(L.DEBUG)
    LF = LoggedFunction(log)
    @LF
    def f(a,b,c=3,d=4):
        return a+b+c+d
    f(1,2,d=9)


# Generated at 2022-06-24 01:49:32.010547
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-24 01:49:39.263018
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger, DEBUG
    logger = getLogger()
    logger.setLevel(DEBUG)

    def func(a, b, c="c"):
        print(f"function {func.__name__} called with a={a}, b={b}, c={c}")
        return "result"

    logged_func = LoggedFunction(logger)(func)
    result = logged_func("a", "b", c="c")
    assert result == "result"


# Generated at 2022-06-24 01:49:46.248987
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """Tests function LoggedFunction's constructor"""
    try:
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.DEBUG)
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        @LoggedFunction(logger)
        def test_func(first, second, third=None):
            return first + second

        test_func(1, 2)
        test_func(1, 2, third=3)
        assert(True)
    except Exception as e:
        print(f"Exception: {e}")
        assert(False)

# Generated at 2022-06-24 01:49:55.566355
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import inspect, logging
    from unittest import TestCase
    from mock import patch

    class TestLoggedFunction(TestCase):

        @LoggedFunction(logger=logging.getLogger("TestLoggedFunction"))
        def bar(self, a, b, c, d="foo"):
            return a + b + c + d

        def test_logs(self):
            # Mock logging functions
            with patch("logging.Logger.debug") as mock_debug:
                # Run function
                self.bar(1, 2, 3)

                # Assert log calls
                self.assertEqual(mock_debug.mock_calls, [
                    ("debug", ("bar(1, 2, 3, d='foo')",), {}),
                    ("debug", ("bar -> foo",), {})
                ])

# Generated at 2022-06-24 01:50:05.950988
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('Hello') == "'Hello'"
    assert format_arg(' Hello ') == "' Hello '"
    assert format_arg('Hello World') == "'Hello World'"
    assert format_arg('Hello "World"') == "'Hello \"World\"'"
    assert format_arg('Hello "World"') == "'Hello \"World\"'"
    assert format_arg([1, 2, 3]) == '[1, 2, 3]'
    assert format_arg({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

if __name__ == '__main__':
    test_format_arg()

# Generated at 2022-06-24 01:50:12.396792
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    logger.setLevel("DEBUG")

    def add(x, y=0):
        return x + y

    sumLog = LoggedFunction(logger)
    sumLog(add)



# Generated at 2022-06-24 01:50:17.089000
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == "5"
    assert format_arg(" test") == "' test'"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:50:18.659584
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('test') == "'test'"
    assert format_arg(1) == '1'

# Generated at 2022-06-24 01:50:25.902736
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging
    import unittest
    import sys

    class LoggedFunctionTest(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.level = logging.DEBUG
            stream_handler = logging.StreamHandler(sys.stdout)
            self.logger.addHandler(stream_handler)
            self.logged_function = LoggedFunction(logger=self.logger)

        def test_logged_function_with_no_args(self):
            def func():
                pass

            logged_func = self.logged_function(func=func)
            logged_func()

        def test_logged_function_with_one_arg(self):
            def func(arg):
                pass


# Generated at 2022-06-24 01:50:32.137700
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("Test")

    class TestClass:
        TEST_CONST = "TEST_VALUE"

        @LoggedFunction(logger)
        def test_function(self, arg1, arg2):
            return arg1, arg2

    t = TestClass()
    t.test_function("a1", "a2")



# Generated at 2022-06-24 01:50:36.976095
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")

    @LoggedFunction(logger)
    def func(a, b=2, c=3):
        return a + b + c

    func(1, b=None, c=5)
    func(2, 2)



# Generated at 2022-06-24 01:50:45.706285
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    def test_func(a, b, *args, **kwargs):
        return a + b + sum(args) + sum(kwargs.values())

    class LoggedFunctionTest(unittest.TestCase):
        def test(self):
            # Create a mock logger
            logger = logging.Logger("test-logger")
            logger.setLevel(logging.DEBUG)
            log_string_stream  = StringIO()
            logger.addHandler(logging.StreamHandler(log_string_stream))

            # Create decorator
            logged_function = LoggedFunction(logger=logger)

            # Decorate function
            logged_test_func = logged_function(test_func)

            # Call function

# Generated at 2022-06-24 01:50:56.826480
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert session.adapters == {}
    session = build_requests_session(retry=True)
    assert session.adapters != {}
    session = build_requests_session(retry=2)
    assert session.adapters != {}
    retry = Retry(total=0)
    session = build_requests_session(retry=False)
    assert session.adapters == {}

    from requests import Session
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

# Generated at 2022-06-24 01:51:02.850690
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg("test") == "'test'"
    assert format_arg(" test ") == "'test'"
    assert format_arg(None) == "None"

# Generated at 2022-06-24 01:51:14.273215
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MyLogger:
        def __init__(self):
            self.logs = []

        def debug(self, text: str):
            self.logs.append(text)

    def my_func(arg1, arg2, arg3, arg4=None):
        return arg1 * arg2 * arg3 * arg4

    my_logger = MyLogger()

    logged_func = LoggedFunction(my_logger)(my_func)
    logged_func(1, 2, 3, None)
    logged_func(1, 2, 3, 4)


# Generated at 2022-06-24 01:51:19.265067
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel("DEBUG")
    handler = logging.StreamHandler()
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def add_numbers(a, b):
        return a + b

    add_numbers(1, 2)

# Generated at 2022-06-24 01:51:25.895456
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('abc') == "'abc'"
    assert format_arg('abc def') == "'abc def'"
    assert format_arg(' abc def ') == "' abc def '"
    assert format_arg('') == "''"
    assert format_arg(' ') == "' '"
    assert format_arg(None) == 'None'

# Generated at 2022-06-24 01:51:27.545603
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('a') == "'a'"
    assert format_arg('a ') == "'a '"
    assert format_arg(1) == '1'

# Generated at 2022-06-24 01:51:29.850616
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('string') == "'string'"
    assert format_arg(5) == "5"
    assert format_arg({'a': 'b'}) == "{'a': 'b'}"

# Generated at 2022-06-24 01:51:33.184397
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == 'None'
    assert format_arg(1) == '1'
    assert format_arg('a') == "'a'"
    assert format_arg(' a ') == "' a '"

# Generated at 2022-06-24 01:51:39.113670
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False, raise_for_status=False)
    print(session)
    assert True


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-24 01:51:43.351629
# Unit test for function format_arg
def test_format_arg():
    # This is useless except that it forces the generation of the docstring for
    # the format_arg function.
    assert format_arg("foo") == "'foo'"
    assert format_arg("foo 'bar' baz") == "'foo 'bar' baz'"



# Generated at 2022-06-24 01:51:49.619616
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    import tempfile

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    debug_handler = logging.StreamHandler(sys.stderr)
    debug_handler.setFormatter(logging.Formatter("%(message)s"))
    debug_handler.setLevel(logging.DEBUG)
    logger.addHandler(debug_handler)

    @LoggedFunction(logger)
    def test_function(a, b):
        return a ** b

    test_function(0, 1)
    test_function(2, 3)
    test_function(4, 5)
    test_function(a=7, b=8)
    test_function(a=9, b=10)
    test_function(a=11, b=12)

# Generated at 2022-06-24 01:51:53.874028
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=3)
    assert isinstance(session, Session)
    assert session.mounts == {
        "http://": HTTPAdapter(max_retries=Retry(total=3)),
        "https://": HTTPAdapter(max_retries=Retry(total=3)),
    }
    assert len(session.hooks["response"]) == 1

# Generated at 2022-06-24 01:52:04.392897
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger("logged_function.test_LoggedFunction")
    logger.level = logging.DEBUG
    logger.addHandler(logging.StreamHandler())

    def test_func(x, y):
        logger.info("in test_func")
        return x + y

    logged_test_func = LoggedFunction(logger)(test_func)

    assert (
        logged_test_func.__name__ == "test_func"
    ), "expected function to keep its name"
    assert (
        logged_test_func.__doc__ == test_func.__doc__
    ), "expected function to keep its documentation"

    logged_test_func(1, 2)



# Generated at 2022-06-24 01:52:09.320498
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("hello") == "'hello'"

# Generated at 2022-06-24 01:52:20.384967
# Unit test for function build_requests_session
def test_build_requests_session():
    session1 = build_requests_session()
    assert isinstance(session1, Session)

    session2 = build_requests_session(retry=5)
    assert isinstance(session2, Session)

    session3 = build_requests_session(retry=False)
    assert isinstance(session3, Session)

    session4 = build_requests_session(retry=Retry())
    assert isinstance(session4, Session)

    # wrong type for retry
    try:
        session4 = build_requests_session(retry=dict())
    except ValueError:
        pass
    else:
        raise ValueError("Should throw an error for wrong type for retry.")



# Generated at 2022-06-24 01:52:31.225583
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    class Dummy:
        def __init__(self):
            self.logger = logging.Logger(name="Dummy", level=logging.DEBUG)
            self.func = LoggedFunction(self.logger)(self.dummy_func)
        def __call__(self, *args, **kwargs):
            return self.func(*args, **kwargs)
        def dummy_func(self, a, b=2):
            return int(a)*b
    dummy = Dummy()
    dummy.logger.setLevel(logging.DEBUG)
    assert dummy(1) == 2
    dummy.logger.setLevel(logging.INFO)
    assert dummy(2) == 4

# Generated at 2022-06-24 01:52:40.460388
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import unittest as ut
    import sys
    import StringIO

    class LoggedFunctionUnitTest(ut.TestCase):
        """
        Unit test for constructor of class LoggedFunction
        """
        def setUp(self):
            self.captured_log_output = StringIO.StringIO()
            self.test_logger = logging.getLogger(self.__class__.__name__)
            self.test_logger.setLevel(logging.DEBUG)

            self.captured_log_handler = logging.StreamHandler(self.captured_log_output)
            self.captured_log_handler.setLevel(logging.DEBUG)

            self.test_logger.addHandler(self.captured_log_handler)
