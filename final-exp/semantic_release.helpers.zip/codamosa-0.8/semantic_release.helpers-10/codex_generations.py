

# Generated at 2022-06-12 06:32:49.860268
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        log = []

        def debug(self, r):
            self.log.append(r)

    def test(a, b, c="3"):
        return str(a) + str(b) + str(c)

    logger = TestLogger()
    decorated_test = LoggedFunction(logger)(test)
    assert decorated_test(1, 2, c=4) == "124"
    assert len(logger.log) == 3
    assert logger.log[0] == "test(1, 2, c=4)"
    assert logger.log[1] == "test -> 124"
    return

# Generated at 2022-06-12 06:33:00.373497
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    class Logger:
        def __init__(self):
            self.log = ""
        def debug(self, x):
            self.log += f"{x}\n"
    def func1(a, b, c="", d=None, e=123, f=123.456, g=True, h=None, i=[]):
        return a+b+c+d+e+f+g+h+i
    @LoggedFunction(Logger())
    def func2():
        return 1
    @LoggedFunction(Logger())
    def func3(a):
        return a+1
    @LoggedFunction(Logger())
    def func4(a=1, b=2):
        return a+b
    
    # Act
    logger = Logger()
    logged_func

# Generated at 2022-06-12 06:33:07.345473
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock

    # Dummy class for testing
    class DummyClass:
        def __init__(self, logger):
            self.logger = logger

        @LoggedFunction(logger=MagicMock())
        def simple_method(self):
            pass

        @LoggedFunction(logger=MagicMock())
        def positional_args(self, a, b, c=3):
            pass

        @LoggedFunction(logger=MagicMock())
        def keyword_args(self, d=4, e=5, f=6):
            pass

        @LoggedFunction(logger=MagicMock())
        def mixed_args(self, g, h=7, i=8):
            pass


# Generated at 2022-06-12 06:33:18.757050
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger('mylogger')
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    logger.addHandler(ch)

    @LoggedFunction(logger)
    def f(x):
        return x + 1

    @LoggedFunction(logger)
    def f2(x, y):
        return x + y + 1

    @LoggedFunction(logger)
    def f3(x, y=3):
        return x + y + 1

    f(3)
    f2(3, 2)
    f3(2)

# Generated at 2022-06-12 06:33:28.132481
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import StringIO
    import unittest.mock

    with unittest.mock.patch.object(logging, "getLogger") as getLogger:
        logger = logging.Logger("test_LoggedFunction___call__")
        logger.addHandler(logging.StreamHandler())
        getLogger.return_value = logger

        # Test with parameter
        with unittest.mock.patch.object(logger, "debug") as debug:
            @LoggedFunction(logger)
            def test(param):
                return param

            test("Hello")
            debug.assert_any_call("test('Hello')")
            debug.assert_any_call("test -> Hello")

        # Test without parameter

# Generated at 2022-06-12 06:33:31.552033
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLoggerClass:
        def debug(self, *args, **kwargs):
            pass

        def info(self, *args, **kwargs):
            pass

        def warning(self, *args, **kwargs):
            pass

    lf = LoggedFunction(TestLoggerClass())
    def test_func(*args, **kwargs):
        pass
    logged_test_func = lf(test_func)
    assert logged_test_func.__name__ == test_func.__name__

# Generated at 2022-06-12 06:33:38.385821
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger()
    logged_function = LoggedFunction(logger)

    @logged_function
    def func(a, b=5, c=6):
        return a + b + c

    func(1, 2, c=3)
    func(4, b=5)
    func(6)
    func(a=7, c=8)
    func(c=9)
    func(10, 11)

# Generated at 2022-06-12 06:33:46.064284
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    global logger
    logger = getLogger(__name__)

    # LoggedFunction.__call__(func)
    def func(a, b, c=3):
        """
        unit test function
        :param a: first parameter
        :param b: second parameter
        :param c: third parameter
        """
        return a + b + c

    func_logged = LoggedFunction(logger)(func)
    assert func_logged(1, 2) == 6
    assert func_logged(1, 2, c=4) == 7
    assert func_logged.__doc__ == func.__doc__
    assert func_logged.__name__ == func.__name__
    assert func_logged.__module__ == func.__module__
    assert func_logged.__defaults__ == func.__defaults

# Generated at 2022-06-12 06:33:54.003420
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def __init__(self):
            self.log = []

        def debug(self, message):
            self.log.append(message)

    logger = DummyLogger()
    decorator = LoggedFunction(logger)

    @decorator
    def run_test(name):
        return f"Hello, {name}!"

    decorated_function = run_test("world")
    assert logger.log[0] == (
        "run_test('world')"
    ), f"LoggedFunction decorator fails to log function call, " f"log:{logger.log[0]}"
    assert decorated_function == "Hello, world!", "LoggedFunction decorator fails to properly decorate function"

# Generated at 2022-06-12 06:34:01.299445
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger("__main__")
    LoggedFunction(logger)(lambda x: x + 1)(2)
    LoggedFunction(logger)(lambda x, y, z: x * y * z)(2, 3, 4)
    LoggedFunction(logger)(lambda x, y, z, c=9: x * y * z * c)(2, 3, 4)
    LoggedFunction(logger)(lambda x, y, z, c=9: x * y * z * c)(2, 3, 4, c=5)


# Generated at 2022-06-12 06:34:14.349542
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function_log(self):
            class MockLogger:
                def __init__(self):
                    self.log = []

                def debug(self, msg):
                    self.log.append(msg)

            mock_logger = MockLogger()

            @LoggedFunction(mock_logger)
            def test_func(a, k=None):
                return a + (k or 0)

            result = test_func(1, k=2)
            self.assertEqual(result, 3)


# Generated at 2022-06-12 06:34:25.514452
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    try:
        class MockLogger:
            def __init__(self):
                self.logs = []

            def __repr__(self):
                return repr(self.logs)

            def debug(self, s):
                self.logs.append(s)

        logger = MockLogger()

        @LoggedFunction(logger)
        def foo(a, *b, c="c", **d):
            return a * len(b) + len(c) + len(d)

        assert foo(1, 2, 3, 4, c="c5", d=6, e=7) == 21
    except Exception as e:
        print(e)
    finally:
        print(f"LoggedFunction___call__: {logger!r}")



# Generated at 2022-06-12 06:34:36.768841
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import pytest
    import io

    stream = io.StringIO()
    logger = logging.getLogger()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    def clean_stream():
        handler.flush()
        stream.seek(0)
        stream.truncate()

    @LoggedFunction(logger)
    def test_func(arg1='arg1', arg2: int = 2, kwarg1=None):
        return f"{arg1}.{arg2}.{kwarg1}"

    # Enable logger for test
    clean_stream()
    result = test_func('a1', arg2=3, kwarg1='kw')
    assert result == 'a1.3.kw'

# Generated at 2022-06-12 06:34:49.217651
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    original_function = lambda: "This is original function"

    # Test calling function without arguments
    decorated_function = LoggedFunction(logger)(original_function)
    for check_log in [
        u"test_LoggedFunction___call__ DEBUG original_function()",
        u"test_LoggedFunction___call__ DEBUG original_function -> This is original function",
    ]:
        assert check_log in [rec.msg for rec in logger.manager.loggerDict["test_LoggedFunction___call__"].output]

    # Test calling function with arguments
    original_function_arg1 = lambda arg1: "This is arg1"
    decorated_function_arg1 = LoggedFunction(logger)(original_function_arg1)

# Generated at 2022-06-12 06:35:00.653405
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    '''
    This function is used to test __call__() of class LoggedFunction
    '''
    from requests.exceptions import HTTPError
    from requests.packages.urllib3.exceptions import MaxRetryError
    from requests import Session
    from logging import getLogger
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    def func(x, p=None, q=None):
        return x + p

    with Session() as session:
        retry = Retry()
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        logger = getLogger(__name__)
        logged_function = LoggedFunction(logger)

# Generated at 2022-06-12 06:35:07.661642
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    
    from logging import Logger
    from unittest.mock import Mock, patch
    from logging import DEBUG, INFO, WARNING
    mock_logger = Mock()
    # default args
    decorated_function = LoggedFunction(mock_logger)(function_with_no_args)
    decorated_function()
    mock_logger.assert_called_with("function_with_no_args()")
    mock_logger.reset_mock()
    # one positional arg
    decorated_function = LoggedFunction(mock_logger)(function_with_one_positional_arg)
    decorated_function('abc')
    mock_logger.assert_called_with("function_with_one_positional_arg('abc')")
    mock_logger.reset_mock()
    # two positional args

# Generated at 2022-06-12 06:35:15.076873
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger("test_LoggedFunction___call__")
    logged_func = LoggedFunction(logger)
    class MockFunc:
        __name__ = "hello"
    mock_func = MockFunc()
    mock_func.__name__ = "hello"
    mock_func.__call__ = lambda *args, **kwargs: (args, kwargs)
    logged_func = logged_func(mock_func)
    assert logged_func(1, 2, 3, a=1, b=2) == ((1, 2, 3), {"a": 1, "b": 2})
    assert mock_func(1, 2, 3, a=1, b=2) == ((1, 2, 3), {"a": 1, "b": 2})

# Generated at 2022-06-12 06:35:23.398601
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from logging import Logger, StreamHandler, DEBUG
    import unittest

    log_stream = StringIO()

    logger = Logger(__name__)
    logger.setLevel(DEBUG)
    logger.addHandler(StreamHandler(log_stream))

    @LoggedFunction(logger)
    def test_func(
        arg1: str, arg2: int, arg3: float, arg4=None, arg5=True
    ) -> Union[None, str]:
        return

    test_func("test string", 1, 3.14, "a", arg5=False)

    u = unittest.TestCase("__init__")

# Generated at 2022-06-12 06:35:27.584095
# Unit test for function build_requests_session
def test_build_requests_session():
    import logging
    logging.basicConfig(
        format="%(asctime)s - %(module)s.%(funcName)s(%(lineno)d) - %(levelname)s - %(message)s",
        level=logging.DEBUG,
    )
    session = build_requests_session(retry=3)
    session.get("https://httpbin.org/get")

# Generated at 2022-06-12 06:35:34.543289
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Test function with no arguments
    @LoggedFunction(logging.getLogger())
    def foo():
        pass

    foo()

    # Test function with arguments
    @LoggedFunction(logging.getLogger())
    def bar(a, b, c="foobar"):
        return "Hello"

    bar("foo", 1, c=1)
    assert bar("foo", 1, c=1) == "Hello"


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:35:45.438466
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging, sys
    
    class Test:
        @LoggedFunction(logging.getLogger(__name__))
        def hello(self, x):
            return f"hello {x}"

    stream_handler = logging.StreamHandler(sys.stdout)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)

    test = Test()
    hello = test.hello
    logger.info(f"(1) The outupt value of hello('world') is {hello('world')}")
    logger.info(f"(2) The outupt value of hello('world') is {hello('world')}")

# Generated at 2022-06-12 06:35:55.943933
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest

    class TestLogger:
        def __init__(self):
            self.calls = []
        
        def debug(self, msg):
            self.calls.append(msg)
    
    def test_func(a, b, c="c", d=3):
        pass

    def test_func2(a, b, c="c", d=3):
        return a + b + c + str(d)
    
    logger = TestLogger()
    dec = LoggedFunction(logger)
    func = dec(test_func)
    func("a", "b", "c", d=3)
    func("a", b="b", c="c", d=3)
    func("a", "b", d=3)
    func("a", d=3)
    func2

# Generated at 2022-06-12 06:36:07.387539
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from contextlib import contextmanager

    @contextmanager
    def capture_stdout(logger):
        capture = io.StringIO()
        oldout = logger.handlers[0].stream
        logger.handlers[0].stream = capture
        yield capture.getvalue()
        logger.handlers[0].stream = oldout

    class TestLoggedFunction(unittest.TestCase):
        def test_log_function_call(self):
            # Initialize logger
            logger = logging.getLogger()
            logger.addHandler(logging.StreamHandler(sys.stdout))
            logger.setLevel(logging.DEBUG)

            # Initialize decorator
            logged_func = LoggedFunction(logger)

            # Wrap function

# Generated at 2022-06-12 06:36:16.347340
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.models import Response
    from unittest.mock import Mock, MagicMock

    session = build_requests_session(raise_for_status=True)
    response = Response()
    response.raise_for_status = Mock()
    session.hooks["response"][0](response, "fake", "args", "here")
    assert response.raise_for_status.call_count == 1

    session = build_requests_session(raise_for_status=False)
    response = Response()
    response.raise_for_status = Mock()
    session.hooks["response"][0](response, "fake", "args", "here")
    assert response.raise_for_status.call_count == 0

    session = build_requests_session()  # default it True

    # default Retry
    session

# Generated at 2022-06-12 06:36:26.296123
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging
    from logging import Logger
    from logging import LoggerAdapter

    from unittest.mock import patch
    from unittest import TestCase

    from logging import LogRecord

    class MockLogger(Logger):

        def __init__(self):
            self.messages = []

        def debug(self, msg, *args, **kwargs):
            self.messages.append(msg)

    # Mock object for function __call__
    mock_func = TestCase().assert_called_with
    mock_func.__name__ = "assert_called_with"
    mock_func.__code__ = TestCase().assert_called_with.__code__


# Generated at 2022-06-12 06:36:36.157495
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    from unittest.mock import patch, call
    
    class TestCase(unittest.TestCase):
        def test_should_log_name_and_arguments(self):
            with patch("logging.getLogger") as getLoggerMock:
                with patch("logging.Logger.debug") as debugMock:
                    class Clazz:
                        @LoggedFunction(getLoggerMock())
                        def method(self, arg1, arg2, kwarg1=1, kwarg2=2):
                            pass
                    
                    Clazz().method("foo", "bar", kwarg1=3, kwarg2="baz")
                    

# Generated at 2022-06-12 06:36:37.352766
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch

# Generated at 2022-06-12 06:36:48.628135
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock
    from loguru import logger
    from .main import Num

    # mock logger
    mock_logger = mock.Mock()
    mock_logger.debug = mock.Mock()

    # create mock obj
    mock_num = mock.Mock()
    mock_num.add = mock.Mock(return_value=6)

    # create a LoggedFunction instance
    obj = LoggedFunction(mock_logger)

    # invoke __call__()
    wrapped_add = obj(mock_num.add)
    # call wrapped_add()
    wrapped_add(2, 4)
    mock_num.add.assert_called_with(2, 4)
    assert mock_num.add.call_count == 1


# Generated at 2022-06-12 06:36:58.039695
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create logging formatter which leaves out timestamp and logger name
    formatter = logging.Formatter(
        "%(levelname)s:%(module)s:%(funcName)s:%(message)s"
    )

    # Create logging handler which writes to console stream
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    # Define string to assert against

# Generated at 2022-06-12 06:37:08.673997
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    logger = logging.getLogger(__name__)

    # Test without raise_for_status
    @LoggedFunction(logger)
    def test_logged_func_without_raise_for_status():
        session = build_requests_session(raise_for_status=False)
        response = session.get('http://127.0.0.1:5000')
        return response.status_code

    assert test_logged_func_without_raise_for_status() == 200

    # Test with raise_for_status
    @LoggedFunction(logger)
    def test_logged_func_with_raise_for_status():
        session = build_requests_session(raise_for_status=True)
        response

# Generated at 2022-06-12 06:37:21.754601
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    stream = StringIO()
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(stream))

    def a():
        pass

    def b(a):
        pass

    def c(a, b):
        pass

    def d(a, b, c):
        return a + b + c

    @LoggedFunction(logger)
    def e():
        pass

    @LoggedFunction(logger)
    def f(a):
        pass

    @LoggedFunction(logger)
    def g(a, b):
        pass

    @LoggedFunction(logger)
    def h(a, b, c):
        return a + b

# Generated at 2022-06-12 06:37:24.036475
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # test with a function with arguments
    test_logger = logging.getLogger()
    test_function = LoggedFunction(test_logger)
    test_function_2 = test_function(test_function)
    test_function_2(1, 2, 3, a=4)


# Generated at 2022-06-12 06:37:29.257055
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    mock_logger = MagicMock()
    logged_function = LoggedFunction(mock_logger)
    test_func = logged_function(lambda x, y, z: x + y + z)
    result = test_func(1, 2, z=3)
    mock_logger.debug.assert_called_once_with(
        "func(1, 2, z=3)"
    )
    assert result == 6
    mock_logger.debug.assert_any_call("func -> 6")


# Generated at 2022-06-12 06:37:39.307837
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    import logging
    import logging.config

    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "standard": {
                    "format": "[%(asctime)s] [%(levelname)s] [%(name)s] [%(lineno)d] - %(message)s"
                }
            },
            "handlers": {
                "default": {
                    "level": "DEBUG",
                    "formatter": "standard",
                    "class": "logging.StreamHandler",
                }
            },
            "loggers": {"": {"handlers": ["default"], "level": "DEBUG", "propagate": True}},
        }
    )
    logger = logging.getLogger

# Generated at 2022-06-12 06:37:50.544551
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    root_logger = logging.getLogger()
    root_logger.disabled = True

    @LoggedFunction(logging.getLogger("test-logger"))
    def test_function(a, b=1, *args, **kwargs):
        return "result"

    # Test with function arguments
    test_function(1, 2, 3, 4, d=5, e=6)
    log_record = logging.getLogger("test-logger").handlers[0].buffer[0]
    assert log_record == "test-function(1, 2, 3, 4, d=5, e=6) -> result"

    # Test with no arguments
    test_function()
    log_record = logging.getLogger("test-logger").handlers[0].buffer[1]

# Generated at 2022-06-12 06:37:57.642275
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    logger = Mock(spec=logging.Logger)

    @LoggedFunction(logger)
    def add(a, b):
        return a + b

    add(1, 2)
    add(1, 2, c=3)
    add(a=3, b=5)

    logger.debug.assert_has_calls([
        Mock(args=("add(1, 2)",)),
        Mock(args=("add(1, 2, c=3)",)),
        Mock(args=("add(a=3, b=5)",))
    ])



# Generated at 2022-06-12 06:38:03.701122
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import pytest
    import logging

    class FakeLogger:
        def __init__(self):
            self.debug_message = None

        def debug(self, message):
            self.debug_message = message

    @LoggedFunction(FakeLogger())
    def my_function(a, b):
        return a + b

    result = my_function(1, 2)
    assert result == 3
    assert my_function.__name__ == "my_function"
    assert my_function.__doc__ == "logged function"

    my_function.__wrapped__(4, 5)
    assert my_function.__wrapped__.__name__ == "my_function"
    assert my_function.__wrapped__.__doc__ == "logged function"
    assert my_function.__wrapped__.__

# Generated at 2022-06-12 06:38:12.310625
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    class TestLogger(logging.Logger):
        class TestHandler(logging.Handler):
            def __init__(self):
                super().__init__()
                self._records = []
            def emit(self, record):
                if record:
                    self._records.append(record)
            def __len__(self):
                return len(self._records)
            def __getattr__(self, name):
                return getattr(self._records, name)
        def __init__(self, name, level=logging.WARNING):
            super().__init__(name, level)
            self.__handler = TestLogger.TestHandler()
            self.addHandler(self.__handler)

# Generated at 2022-06-12 06:38:23.028763
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    from contextlib import redirect_stdout
    @LoggedFunction(logging.getLogger("test_LoggedFunction___call__"))
    def test_func(a, b=1):
        return a

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger_handler = logging.StreamHandler()
    logger_handler.setFormatter(logging.Formatter("%(levelname)s:%(message)s"))
    logger.addHandler(logger_handler)

    with io.StringIO() as buf, redirect_stdout(buf):
        logger.debug("This should be logged.")
        test_func(1)
        test_func(a=2)

# Generated at 2022-06-12 06:38:25.842579
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger()

    def print_hello():
        logger.debug("Hello, world!")

    decorated_func = LoggedFunction(logger)(print_hello)
    decorated_func()

# Generated at 2022-06-12 06:38:45.075717
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from StringIO import StringIO

    logger = logging.getLogger()
    logger.level = logging.DEBUG

    logging_handler = logging.StreamHandler(StringIO())
    logger.addHandler(logging_handler)

    @LoggedFunction(logger)
    def foo(name, age, address):
        return "bar"

    foo("a", 20, address="xyz")
    foo(1, 2, 3)
    foo("Carl", 30, address="Carl's home")
    logging_handler.stream.seek(0)
    lines = logging_handler.stream.readlines()

# Generated at 2022-06-12 06:38:51.297676
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test(param1, *, param2, param3=123):
        return param1 + param2 + param3

    # test is an object of class LoggedFunction
    test(1, param2=2)

# Generated at 2022-06-12 06:38:55.322745
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.call_history = []

        def __call__(self, call):
            self.call_history.append(call)

    logger = MockLogger()

    @LoggedFunction(logger=logger)
    def f(_a, _b, c=1, d=2):
        return "return-value"

    f(1, 2, c=3, d=4)

    assert logger.call_history == [
        "f(1, 2, c='3', d='4')",
        "f -> return-value",
    ]

# Generated at 2022-06-12 06:39:01.763066
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

    # In case the default session is changed
    assert session.hooks == {}

    # Test default retry session
    session = build_requests_session(retry=True)
    assert isinstance(session.get_adapter("http://").max_retries, Retry)
    assert isinstance(session.get_adapter("https://").max_retries, Retry)
    # Test retry count
    session = build_requests_session(retry=10)
    assert session.get_adapter("http://").max_retries.total == 10
    assert session.get_adapter("https://").max_retries.total == 10
    # Test custom retry
    session = build_requests_session(retry=Retry(total=3))

# Generated at 2022-06-12 06:39:09.565836
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch
    from logging import Logger
    from requests import get
    from requests import Session

    # Create mocked session and get
    get_patch = patch("requests.get")
    session_patch = patch("requests.Session")
    with get_patch as get_mock, session_patch as session_mock:
        session_mock.return_value.get = get_mock
        get_mock.return_value.text = "response"
        session = Session()

        # Create mocked logger
        logger = Logger("logger")
        log_patch = patch.object(logger, "debug")
        with log_patch as log_mock:
            # Call funtion with decorator
            my_decorator = LoggedFunction(logger)

# Generated at 2022-06-12 06:39:15.552645
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    logger = logging.getLogger("main")

    @LoggedFunction(logger)
    def test_log(arg):
        return arg

    test_log(1)
    test_log(first=1, second=2)



# Generated at 2022-06-12 06:39:26.560840
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    for adapter in session.adapters.values():
        assert isinstance(adapter, HTTPAdapter)
        print(adapter.max_retries)
        assert isinstance(adapter.max_retries, Retry)
        assert adapter.max_retries.total == 10
    session = build_requests_session(retry = False)
    for adapter in session.adapters.values():
        assert isinstance(adapter, HTTPAdapter)
        print(adapter.max_retries)
        assert adapter.max_retries.total == 0
    session = build_requests_session(retry = 5)
    for adapter in session.adapters.values():
        assert isinstance(adapter, HTTPAdapter)
        print(adapter.max_retries)

# Generated at 2022-06-12 06:39:38.227087
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger()
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    def test_func(arg1, arg2, kwarg1="default kwarg1", kwarg2="default kwarg2"):
        return f"result {arg1}{arg2}{kwarg1}{kwarg2}"


# Generated at 2022-06-12 06:39:49.755828
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from log import getLogger
    from io import StringIO
    from sys import stdout
    from contextlib import redirect_stdout

    log_output = StringIO()
    logger = getLogger("tests", level=10, stream=log_output, fmt="%(message)s")
    logged_func = LoggedFunction(logger)

    @logged_func
    def func1(*args, **kwargs):
        return "a"

    @logged_func
    def func2(a, b, *args, c=1, d=2, **kwargs):
        return a

    @logged_func
    def func3(a, b, *args, c=1, d=2, **kwargs):
        return a + b


# Generated at 2022-06-12 06:39:56.146217
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(io.StringIO()))

    @LoggedFunction(logger)
    def test_function(a, b, c=2, d=5):
        return a + b + c + d

    assert test_function("a", "b", 1, 2) == 11
    assert test_function("a", "b", 1, d=7) == 12
    assert test_function("a", "b", 1, d=0) == 8
    assert test_function("a", "b", 1) == 9
    assert test_function("a", "b") == 9
    assert test_function("a", "b", d=0) == 8

# Generated at 2022-06-12 06:40:25.486727
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig()
    logger = logging.getLogger()

    @LoggedFunction(logging.getLogger())
    def foo(x, y=None):
        return x * y

    logger.setLevel(logging.DEBUG)
    assert foo(10, 2) == 20
    assert foo(10) is None


# Generated at 2022-06-12 06:40:34.322324
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from qe_common import Log
    from unittest import mock

    logger = Log("test", "/tmp")

    with mock.patch("qe_common.LoggedFunction.logger") as mock_logger:
        LoggedFunction(logger)
        mock_logger.debug.assert_called_with(
            "test({args}{kwargs})".format(
                function=logger,
                args=", ".join([format_arg(x) for x in logger]),
                kwargs="".join(
                    [f", {k}={format_arg(v)}" for k, v in logger.items()]
                ),
            )
        )

        mock_logger.debug.assert_called_with(f"test -> {logger}")

# Generated at 2022-06-12 06:40:45.038752
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    from unittest import TestCase, mock
    from unittest.mock import patch

    class TestLoggedFunction(TestCase):
        @mock.patch("logging.Logger.debug")
        def test_arg_type_string(self, mock_debug):
            @LoggedFunction(mock_debug)
            def test_func(str_arg):
                return str_arg

            test_func("test_string")
            mock_debug.assert_called_with("test_func('test_string')")

        @mock.patch("logging.Logger.debug")
        def test_arg_type_int(self, mock_debug):
            @LoggedFunction(mock_debug)
            def test_func(int_arg):
                return int_arg

            test_func

# Generated at 2022-06-12 06:40:51.546694
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.Logger("a logger")
    def a_func(name:str, age:int=40, address:str=None):
        return name
    a_func.__name__ = "a_func"
    a_func = LoggedFunction(logger)(a_func)
    # execute __call__
    assert a_func("johnson") == "johnson"
    assert a_func("johnson", 40) == "johnson"
    assert a_func("johnson", 41) == "johnson"
    assert a_func("johnson", address="234 main street") == "johnson"
    assert a_func("johnson", age=41, address="234 main street") == "johnson"



# Generated at 2022-06-12 06:40:53.293227
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    assert LoggedFunction(logging.getLogger())(format_arg)(1) == '1'

# Generated at 2022-06-12 06:40:56.592347
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # set logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test(a, b):
        print(a + b)
        return a * b

    test(1, 2)

# Generated at 2022-06-12 06:41:08.356432
# Unit test for function build_requests_session
def test_build_requests_session():
    valid_retry_param = [True, Retry(), Retry(0), Retry(1), Retry(2), 1, 2]
    s = build_requests_session(True, Retry(0))
    assert isinstance(s, Session) is True
    s = build_requests_session(False, Retry(0))
    assert isinstance(s, Session) is True
    for valid_param in valid_retry_param:
        s = build_requests_session(False, valid_param)
        assert isinstance(s, Session) is True
    try:
        build_requests_session(False, False)
    except ValueError:
        pass
    else:
        raise Exception("build_requests_session with invalid retry param did not raise exception.")


# Generated at 2022-06-12 06:41:16.892340
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    class Logger:
        def __init__(self):
            # self.log = []
            self.log = ""
        def debug(self, message):
            # self.log.append(message)
            self.log += message
        def close(self):
            pass

    """
    Unittest test_LoggedFunction___call__
    :return:
    """
    logger = Logger()
    logged_function = LoggedFunction(logger=logger)
    @logged_function
    def test_function():
        return "OK"
    @logged_function
    def test_function_args(arg1, arg2=None):
        return "OK"

# Generated at 2022-06-12 06:41:23.239073
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MockLogger()
    test_logger = LoggedFunction(logger)
    test_func = test_logger(test_func)

    assert test_func.__name__ == 'test_func'  # ensure __name__ is the same as that of function tested
    test_func()
    assert logger.get_log().find('todos') != -1

# Generated at 2022-06-12 06:41:31.633373
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    resultList = []

    # Method under test
    @LoggedFunction(logger=resultList)
    def function(a, b, c, d=1, e=3, f=5):
        return "%s%s%s%s%s%s" % (a, b, c, d, e, f)

    result_a = function("hello", 1, 3.1)
    assert("function(hello, 1, 3.1, d=1, e=3, f=5)" == resultList[0])
    assert("hello13.1135" == result_a)
    assert("function -> hello13.1135" == resultList[1])

    result_b = function(a=1, b=2, c=3)

# Generated at 2022-06-12 06:42:33.376747
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    method_call_expected1 = "functionname(123, test_string='test', test_int=456)"
    method_call_expected2 = "functionname(123, test_string='test', test_int=456)"
    method_call_expected3 = "functionname(123, test_string='test', test_int=456)"
    method_response_expected = "functionname -> function_response"
    
    class test_logger:
        def __init__(self):
            self.method_call_result = ""
            self.method_response_result = None
        
        def debug(self, message):
            if "functionname" in message:
                self.method_call_result += message
            elif message.startswith("functionname ->"):
                self.method_response_result = message

# Generated at 2022-06-12 06:42:40.880630
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO

    from telegram.bots import Bot

    import logging
    import random
    import unittest

    bot = Bot("", "")
    logger = logging.getLogger("logged_function_test")
    handler = logging.StreamHandler(StringIO())
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    random_medals = {
        "Bronze": ["Argentina", "Russia"],
        "Silver": ["Spain", "Argentina"],
        "Gold": ["England", "Uruguay"],
    }