

# Generated at 2022-06-12 06:32:46.696635
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        build_requests_session(retry=-1)
    except ValueError:
        pass
    else:
        raise RuntimeError("Test failed!")

# Generated at 2022-06-12 06:32:54.775253
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    from unittest.mock import Mock, patch

    logger = Mock()
    LoggedFunction(logger)(lambda x, y, *, a=1, b=2, **kwargs: print(x,y,a,b,kwargs))(3, "a", b=4, c=5, d=6)
    assert logger.debug.call_args_list[0][0][0] == "lambda(3,'a', a=1, b=4, c=5, d=6)"
    assert logger.debug.call_args_list[1][0][0] == "lambda -> None"


# Generated at 2022-06-12 06:32:55.376969
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-12 06:33:04.097759
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a buffer for logging
    stream = io.StringIO()
    logger = logging.getLogger("test_function")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(stream))

    # Define a test function
    @LoggedFunction(logger)
    def test_function(a, b=None):
        return a + b

    # Call test function and check logging
    test_function(2, b=5)
    assert stream.getvalue() == "test_function(2, b=5)\ntest_function -> 7\n"

    # Restore logging
    logger.removeHandler(logger.handlers[0])


# Generated at 2022-06-12 06:33:13.879305
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest import TestCase
    from unittest.mock import Mock
    from dataclasses import dataclass

    class Logger(Mock):
        pass

    logger1 = Logger()
    logger1.debug = Mock()

    logger2 = Logger()
    logger2.debug = Mock()

    class Test(TestCase):
        def test_LoggedFunction___call__(self):
            @LoggedFunction(logger=logger1)
            def foo(bar, baz="qux"):
                return bar

            @LoggedFunction(logger=logger2)
            def bar():
                pass

            foo("Hello, World!", baz="Hi, there")
            foo("Hi, there", bar="Hello, World!")
            foo("Hi, there")

# Generated at 2022-06-12 06:33:19.054700
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    adapter = session.adapters["http://"]
    adapter1 = session.adapters["https://"]
    assert isinstance(adapter, HTTPAdapter)
    assert adapter.max_retries.total == 10
    assert isinstance(adapter1, HTTPAdapter)
    assert adapter1.max_retries.total == 10
    session = build_requests_session(retry=False)
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters
    session = build_requests_session(retry=5)
    adapter = session.adapters["http://"]
    assert isinstance(adapter, HTTPAdapter)
    assert adapter.max_retries.total == 5



# Generated at 2022-06-12 06:33:28.131708
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    def foo(x: str) -> int:
        return len(x)
    class TestLoggedFunction(unittest.TestCase):
        def test_LoggedFunction_mocked_logger(self):
            mocked_logger = logging.Logger("test")
            lf = LoggedFunction(mocked_logger)
            foo_logged = lf(foo)
            # test log messages
            # args: 'test'
            # ret: 4
            mocked_logger.debug = unittest.mock.Mock()
            foo_logged("test")

# Generated at 2022-06-12 06:33:39.770619
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    log = logging.getLogger("logged_function")
    format = logging.Formatter("%(message)s")
    handler = logging.StreamHandler()
    handler.setFormatter(format)
    log.setLevel(logging.DEBUG)
    log.addHandler(handler)

    def f1(a, b):
        return a * b

    def f2(a, b, **kwargs):
        return a * b

    def f3(a, b):
        return a + b

    def f4(a, b, **kwargs):
        return a + b

    def f5(a, b, **kwargs):
        return None

    @LoggedFunction(log)
    def f6(a, b=1):
        return a * b


# Generated at 2022-06-12 06:33:49.838377
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import contextlib
    import io
    import unittest

    from unittest.mock import patch

    from .logging_utils import get_logger

    logger = get_logger()
    logged_function = LoggedFunction(logger)

    def test_func(a, b=None, c=10):
        return a + b + c

    @logged_function
    def logged_test_func(a, b=None, c=10):
        return a + b + c

    with contextlib.redirect_stdout(io.StringIO()):
        logged_test_func(20, c=100)

        stdout = io.StringIO()
        with patch("sys.stdout", stdout):
            logger.debug("This is debug log.")

# Generated at 2022-06-12 06:34:00.665863
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def f(a, b=2, *args, c=3, **kwargs):
        return a, b, args, c, kwargs

    f(1)
    f(1, 2)
    f(1, 2, 3)
    f(1, 2, 3, 4)
    f(1, b=2, c=33)
    f(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)



# Generated at 2022-06-12 06:34:06.916027
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test cases for method __call__ of class LoggedFunction.
    """
    logger = logging.getLogger()
    logged_function = LoggedFunction(logger)
    assert logged_function.__call__(test_LoggedFunction___call__)() == None

# Generated at 2022-06-12 06:34:15.555475
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock as mock
    import os

    class TestLoggedFunction__call__(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.logger.handlers = [logging.StreamHandler()]
            self.logged_function = LoggedFunction(self.logger)

        def test__call__(self):
            with mock.patch.object(self.logger, "debug") as mock_debug:
                @self.logged_function
                def logged_func(a):
                    return a * 2

                logged_func(10)


# Generated at 2022-06-12 06:34:26.046253
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock as mock
    import logging

    logger = mock.Mock(spec=logging.Logger)
    func = LoggedFunction(logger)(lambda name, x, y, z=0: name + x + y + z)

    func('a', 1, 2)
    logger.debug.assert_called_with("<lambda>(a, 1, 2)")
    logger.debug.assert_called_with("<lambda> -> a12")

    func('a', 1, 2, 3)
    logger.debug.assert_called_with("<lambda>(a, 1, 2, 3)")
    logger.debug.assert_called_with("<lambda> -> a123")

    func('a', 1, y=2, z=3)

# Generated at 2022-06-12 06:34:37.257181
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    log_list = []
    class mock_logger:
        def debug(self, message):
            log_list.append(message)

    def test_func(a, b, c=3, d=4, e=5):
        return a + b + c + d + e

    def func_without_args():
        return "no args"

    func_without_args_logged = LoggedFunction(mock_logger())(func_without_args)
    func_without_args_logged()

    func_logged = LoggedFunction(mock_logger())(test_func)
    func_logged(1, 2, d=10)

    assert func_logged.__name__ == "test_func"
    assert len(log_list) == 3

# Generated at 2022-06-12 06:34:49.257907
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    class TestLogger(logging.Logger):
        def debug(self, message):
            self.lastMsg = message

    def test_func(a, b):
        return "result"

    logger = TestLogger("name")
    logged_func = LoggedFunction(logger)(test_func)
    logged_func(1, 2)
    assert logger.lastMsg == "test_func(1, 2)"

    logger = TestLogger("name")
    logged_func = LoggedFunction(logger)(test_func)
    logged_func(1, "abc def")
    assert logger.lastMsg == "test_func(1, 'abc def')"

    logger = TestLogger("name")
    logged_func = LoggedFunction(logger)(test_func)

# Generated at 2022-06-12 06:35:00.698731
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from logging import Logger

    def foo():
        pass

    def bar(*args):
        return args

    def baz(**kwargs):
        return kwargs

    def qux(*args, **kwargs):
        return (args, kwargs)

    def quux(a):
        return a

    def quuz(a, b):
        return a, b

    def corge(a, b, c):
        return a, b, c

    def grault(a, b, c, d):
        return a, b, c, d

    def garply(*args):
        return args

    def waldo(**kwargs):
        return kwargs

    def fred(a, b="b"):
        return a, b


# Generated at 2022-06-12 06:35:06.082480
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    
    # Create logger
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    
    # Create logged function
    @LoggedFunction(logger)
    def add(x, y=1):
        return x + y
    
    # Call function
    print(add(3, y=4))
    

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:35:12.285695
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger("test")

    @LoggedFunction(logger)
    def test_function(
        arg1, arg2=4, *args, kwarg1="fizz", kwarg2=None, **kwargs
    ):
        return 123
    test_function("foo", arg2=3, kwarg1=None, kwarg3="bar", baz=1)



# Generated at 2022-06-12 06:35:15.785381
# Unit test for function build_requests_session
def test_build_requests_session():
    Session_instance = build_requests_session()

    assert isinstance(Session_instance, Session), f"Session instance is not created"


test_build_requests_session()

# Generated at 2022-06-12 06:35:16.741129
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert True

# Generated at 2022-06-12 06:35:22.928400
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=False, retry=Retry(total=10, backoff_factor=0.1))



# Generated at 2022-06-12 06:35:29.502433
# Unit test for function build_requests_session
def test_build_requests_session():
    with pytest.raises(ValueError) as excinfo:
        build_requests_session(retry=1.1)
    assert "retry should be a bool, int or Retry instance." in str(excinfo.value)
    sess = build_requests_session(retry=Retry(total=1, status_forcelist=[500, 502]))
    with pytest.raises(Exception) as excinfo:
        sess.get("http://httpbin.org/status/500")
        sess.get("http://httpbin.org/status/500")
    assert "500 Server Error" in str(excinfo.value)
    assert "Retry failed to retrieve http://httpbin.org/status/500 (failed 1 times): 500 Server Error" in str(excinfo.value)

# Generated at 2022-06-12 06:35:32.215883
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=None)
    def function(name, age=None, *args, **kwargs):
        pass

    assert function("Peter") == None



# Generated at 2022-06-12 06:35:40.871441
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    stream = io.StringIO()
    logger.handlers = [logging.StreamHandler(stream=stream)]

    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    add(1, 2)
    # assert stream.getvalue() == "add(1, 2)\nadd -> 3\n"
    assert stream.getvalue() == "add(1, 2)\n"

# Generated at 2022-06-12 06:35:45.811065
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)

    def test_function(*, one: int, two: str, three: str = "test") -> str:
        return "done"

    logged_function = LoggedFunction(logger)
    logged_function = logged_function(test_function)

    assert (
        logged_function(one=1, two="2")
        == test_function(one=1, two="2")
    )



# Generated at 2022-06-12 06:35:53.252318
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    def foo(x, y):
        return x, y

    logged_foo = LoggedFunction(logger=logger)(foo)
    assert logged_foo(1, 2) == (1, 2)
    assert logged_foo(arg1=1, arg2=2) == (1, 2)



# Generated at 2022-06-12 06:35:54.914510
# Unit test for function build_requests_session
def test_build_requests_session():
    Session = build_requests_session()
    Session.get("http://httpbin.org/")

# Generated at 2022-06-12 06:36:05.792601
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # make logger
    logger = logging.getLogger("LoggedFunction Test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # make test function
    @LoggedFunction(logger)
    def test_func(x, y, z=None, a=1, b=2, c=3):
        print(x, y, z, a, b, c)

    # test cases
    test_func(1, 2)
    test_func(1, 2, 3)
    test_func(1, 2, 3, 4)
    test_func(1, 2, c=9, a=7)
    test_func(1, 2, b=8, z=6)

# Generated at 2022-06-12 06:36:11.622403
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    log = logging.getLogger("log")


    @LoggedFunction(log)
    def test(a, *args, **kwargs):
        pass


    try:
        test(1, 2, 3)
        test(1, 2, 3, c="4", d=4)
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-12 06:36:18.226301
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import os
    import unittest

    class Test(unittest.TestCase):
        def test_1(self):
            class A:
                @LoggedFunction(logging.getLogger())
                def f(self, x, y=10, *args, **kwargs):
                    return x + y + sum(args) + sum(kwargs.values())

            a = A()
            self.assertEqual(a.f(1), 11)
            self.assertEqual(a.f(x=1), 11)
            self.assertEqual(a.f(y=1, x=1), 12)
            self.assertEqual(a.f(1, x=1), 12)

# Generated at 2022-06-12 06:36:30.688283
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from io import StringIO
    import logging

    stream = StringIO()
    logging.basicConfig(stream=stream)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    f = LoggedFunction(logger)(add)
    assert f(1, 2, 3) == 6
    assert stream.getvalue() == "add(1, 2, 3)\nadd -> 6\n"

    stream = StringIO()
    logging.basicConfig(stream=stream)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    f = LoggedFunction(logger)(add_keywords)
    assert f(a=1, b=2, c=3) == 6

# Generated at 2022-06-12 06:36:39.264881
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger(object):
        def __init__(self):
            self.msg = ""

        def debug(self, *args):
            self.msg += " ".join([str(a) for a in args]) + " "

    logger = DummyLogger()
    f = LoggedFunction(logger)

    @f
    def test_func(x, y):
        return x + y

    result = test_func(1, 2)
    assert result == 3
    assert logger.msg == "test_func(1, 2) test_func(1, 2) -> 3 "

    result = test_func("a ", "b")
    assert result == "a b"

# Generated at 2022-06-12 06:36:49.833457
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
        Test function __call__ of class LoggedFunction
        Args:
        Return:
        Raises:
    """
    class MyLogger:
        def __init__(self):
            self.__logged = ""

        def clear(self):
            self.__logged = ""

        def debug(self, message):
            self.__logged += f"{message}\n"

        def logged(self):
            return self.__logged

    def f():
        pass

    def f1(a):
        pass

    def f2(a, b):
        pass

    def f3(a, b, c):
        pass

    def f4(a, b, c, d):
        pass

    def f5(a, b, c, d, e):
        pass


# Generated at 2022-06-12 06:36:57.123362
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest.mock as mock
    from unittest.mock import patch


    logger = logging.getLogger('test_LoggedFunction___call__')
    logger.setLevel(logging.DEBUG)
    logger.handlers = []
    logger.addHandler(logging.StreamHandler())
    logger.propagate = False

    def foo(x):
        return x
    
    with patch.object(logger, 'debug') as mocked_debug:
        logged_foo = LoggedFunction(logger)(foo)
        result = logged_foo(3)

    assert result == 3

# Generated at 2022-06-12 06:37:05.917875
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    logger = Mock()
    @LoggedFunction(logger)
    def foo(x, y=1):
        return x + y

    foo(1)
    logger.debug.assert_any_call('foo(1, y=1)')
    logger.debug.assert_any_call('foo -> 2')

    foo(2, y=3)
    logger.debug.assert_any_call('foo(2, y=3)')
    logger.debug.assert_any_call('foo -> 5')

test_LoggedFunction___call__()

# Generated at 2022-06-12 06:37:09.901928
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test_logger")

    @LoggedFunction(logger)
    def foo(a, b, c=1):
        return a + b + c

    foo(2, 3)
    assert logger.hasHandlers()
    # test logger
    foo(1, 2, c=3)

# Generated at 2022-06-12 06:37:14.772571
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def myfunction(a, b, c=None):
        return a + b + c

    myfunction(3, 4, 5)
    myfunction(3, 4, c=5)

# Generated at 2022-06-12 06:37:19.660725
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    @LoggedFunction(logger)
    def foo(a, b, c=3, d=4):
        return a*b*c*d
    logger.info(foo(2, 3, d=8))
    logger.info(foo(2, 3, c=7, d=8))
    logger.info(foo(2, 3))


# Generated at 2022-06-12 06:37:24.598882
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test for __call__ method of LoggedFunction.
    """
    logger = Mock()
    logged_function = LoggedFunction(logger)
    func = logged_function(lambda x : x)
    result = func('Test')
    assert result == 'Test'
    logger.debug.assert_called_once_with("<lambda>(\'Test\')")

# Generated at 2022-06-12 06:37:29.874377
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Set logger
    logger = logging.getLogger("test")
    logger.setLevel(10)

    # Define test function
    def test_function(x, y=5, z=6):
        return x + y + z

    # Test
    test_func = LoggedFunction(logger)(test_function)
    assert test_func(1, y=2, z=3) == 6
    assert test_func(x=1, y=2, z=3) == 6
    assert test_func(1, 2, 3) == 6

# Generated at 2022-06-12 06:37:41.393645
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import requests_mock

    with requests_mock.Mocker() as m:
        # Mock requests.get()
        m.get("http://test.com", text="data")
        m.get("http://test.com", status_code=404)

        # Request with success
        session = build_requests_session(raise_for_status=True)
        response = session.get("http://test.com")
        assert response.text == "data"
        assert response.status_code == 200

        # Request failed with 404
        session = build_requests_session(raise_for_status=True)
        try:
            response = session.get("http://test.com")
            assert False
        except requests.exceptions.HTTPError:
            assert True

# Generated at 2022-06-12 06:37:52.091054
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class log:
        def debug(self, msg):
            print(msg)
    logger = log()
    @LoggedFunction(logger)
    def hello():
        print("Hello")
    @LoggedFunction(logger)
    def add(a, b):
        return a + b
    @LoggedFunction(logger)
    def sub(a, b):
        return a - b
    @LoggedFunction(logger)
    def f(a, b, c="c", d="d"):
        return a + b + c + d
    @LoggedFunction(logger)
    def fib(n):
        if n == 0 or n == 1:
            return 1
        else:
            return fib(n - 1) + fib(n - 2)
    hello()

# Generated at 2022-06-12 06:37:54.301714
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False, 1)
    assert session is not None
    assert not hasattr(session, "hooks")
    assert hasattr(session, "adapters")

# Generated at 2022-06-12 06:38:01.835422
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # [arrange]
    class FakeLogger:
        def __init__(self):
            self.outputs = []

        def debug(self, m):
            self.outputs.append(m)

    args = [1, 2, 3, "4"]
    kwargs = {"a": 1, "b": "2"}
    expected_str = "foo(1, 2, 3, '4', a=1, b='2')"
    logger = FakeLogger()
    logged_function = LoggedFunction(logger)

    # [act]
    def foo(*args, **kwargs):
        pass

    logged_foo = logged_function(foo)
    logged_foo(*args, **kwargs)

    # [assert]
    assert logger.outputs[0] == expected_str

# Generated at 2022-06-12 06:38:11.690684
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from unittest.mock import patch, MagicMock

    # Mock the logger and patched into the decorator
    logger = getLogger()
    mockLogger = MagicMock()
    logger.debug = mockLogger

    # Decorator to add logging to a function
    @LoggedFunction(logger)
    def square(x):
        return x ** 2

    # call function with argument
    square(3)
    mockLogger.assert_called_once_with("square(3)")

    # call function without any argument
    @LoggedFunction(logger)
    def buddy():
        return 'Hello there'
    buddy()
    mockLogger.assert_called_with('buddy()')

    # call function with multiple arguments

# Generated at 2022-06-12 06:38:22.356329
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    import logging

    class Struct:
        pass

    class TestLogger:
        def info(self, message):
            pass

        def debug(self, message):
            pass

        def error(self, message):
            pass

    def test_function(x, y, z):
        return x + y + z

    logger = TestLogger()
    logger.debug = unittest.mock.MagicMock()
    logged_function = LoggedFunction(logger)
    logged_test_function = logged_function(test_function)
    logged_test_function(1, 2, z="3")
    logger.debug.assert_called_once_with("test_function(1, 2, z='3')")

    # Test non-None return value
    logger.debug.reset_mock

# Generated at 2022-06-12 06:38:28.742854
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    
    import logging
    
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.ERROR)
    logger.addHandler(logging.NullHandler())
    
    @LoggedFunction(logger)
    def function_to_log(name: str, age: int, **kwargs: str) -> str:
        return f"Hello, {name}, you are {age} year(s) old."
    
    assert function_to_log("Joe", 3) == "Hello, Joe, you are 3 year(s) old."

# Generated at 2022-06-12 06:38:34.529495
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    from pytest import raises

    from logging import Logger, DEBUG

    from requests import get

    from unittest.mock import DEFAULT, Mock, patch

    from requests_toolbelt.adapters import HTTPAdapter

    # Mocks
    mock_logger = Mock(spec=Logger)
    mock_func = Mock(spec=get, __name__="get")

    # Arguments to __call__
    kwargs = {"raise_for_status": True, "retry": True}
    args = ("http://httpbin.org",)

    # Expected
    expected_init_call = patch.call(**kwargs)
    expected_init_call_args = list(kwargs.values())
    expected_func_call = patch.call(args=args, kwargs={})

# Generated at 2022-06-12 06:38:43.531550
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import sentinel
    from uuid import uuid4
    from unittest import mock
    logger = mock.Mock(spec=logging.Logger)
    function_name = str(uuid4())
    function_id = str(uuid4())
    function_args = sentinel.args
    function_args_formatted = str(uuid4())
    function_kwargs = sentinel.kwargs
    function_kwargs_formatted = str(uuid4())

# Generated at 2022-06-12 06:38:49.958922
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from mock import Mock
    from logging import Logger
    
    func = lambda a, b, c=3: f"{a}+{b}+{c}"
    logger = Mock(spec=Logger)
    
    decorated_func = LoggedFunction(logger)(func)
    decorated_func(1, 2)
    logger.debug.assert_called_once_with(
        "f(1, 2, c=3)"
    )

# Generated at 2022-06-12 06:40:24.011038
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from requests.exceptions import RequestException

    @LoggedFunction(logger = print)
    def func(a, b):
        return a * b

    rs = build_requests_session()
    try:
        rs.get("http://httpbin.org/status/404")
    except RequestException:
        pass
    
    try:
        rs = build_requests_session()
        rs.hooks = None
        rs.get("http://httpbin.org/status/404")
    except RequestException:
        pass

    with pytest.raises(ValueError):
        rs = build_requests_session(retry="blah")


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-12 06:40:33.152031
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    logger = logging.getLogger()
    logged_function = LoggedFunction(logger)
    func = lambda a, b, c: (a, b, c)

    # Act
    logged_func = logged_function(func)

    # Assert
    assert logged_func.__name__ == 'func'
    assert logged_func.__doc__ == 'Unit test for method __call__ of class LoggedFunction'
    assert logged_func.__module__ == 'tests.test_api_http_utils'

    # Act
    (a, b, c) = logged_func(1, 2, 3)

    # Assert
    assert a == 1
    assert b == 2
    assert c == 3

# Generated at 2022-06-12 06:40:37.274052
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False, False)
    session.get("https://www.google.com")
    session = build_requests_session(False, 1)
    session.get("https://www.google.com")
    session = build_requests_session(False, Retry(1))
    session.get("https://www.google.com")
    with pytest.raises(TypeError):
        session = build_requests_session(False, 10.0)

# Generated at 2022-06-12 06:40:47.267909
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestClass:
        @LoggedFunction(logger=None)
        def test_func1(self, a, b, c=33, d=44):
            return a + b + c + d

        @LoggedFunction(logger=None)
        def test_func2(self, a, b=22, c=33, d=44):
            return a + b + c + d

        @LoggedFunction(logger=None)
        def test_func3(self, a, b, c=33, d=44, e=55):
            return a + b + c + d + e # noqa: E225

        @LoggedFunction(logger=None)
        def test_func4(self, a, b, c=33):
            return a + b + c


# Generated at 2022-06-12 06:40:56.319043
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock

    logger = mock.MagicMock()
    function = mock.MagicMock(return_value="hello")

    @LoggedFunction(logger)
    def new_function():
        pass

    new_function()

    logger.debug.assert_called_once_with(
        "new_function()"
    )
    logger.debug.reset_mock()

    function()

    logger.debug.assert_called_with("function() -> hello")
    logger.debug.reset_mock()

    function(1, "a", c="c")

    logger.debug.assert_called_with(
        "function(1, 'a', c='c') -> hello"
    )
    logger.debug.reset_mock()

    function(a=1, c="c")


# Generated at 2022-06-12 06:41:08.117131
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test case: call a function, return value is not None.
    class TestLogger:
        def __init__(self):
            self.debug_logs = []
        def debug(self, message):
            self.debug_logs.append(message)

    def test_function1(a, b=2, *args):
        return a + b

    logger = TestLogger()
    logged_function = LoggedFunction(logger)
    logged_function.__call__(test_function1)(1)
    assert (
        logger.debug_logs[0] == "test_function1(1, b=2)"
        and logger.debug_logs[1] == "test_function1 -> 3"
    )

    # Test case: call a function, return value is None.

# Generated at 2022-06-12 06:41:15.856473
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func_name = "test_func"
    func_value = "test_value"
    mock_logger = mock.MagicMock()
    test_function = LoggedFunction(mock_logger)
    @test_function
    def test_func(*args, **kwargs):
        return func_value
    result = test_func(1,2,3,a="aaa",b="bbb")
    assert result == func_value
    mock_logger.debug.assert_any_call(f"{func_name}(1, 2, 3, a='aaa', b='bbb')")
    mock_logger.debug.assert_any_call(f"{func_name} -> {func_value}")

# Generated at 2022-06-12 06:41:27.347607
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    # Set up logging to the console
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s: %(message)s", datefmt="%H:%M:%S"
    )
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    @LoggedFunction(logger)
    def test(a, b, c="c", d=True):
        return 123

    result = test(100, "test", d=False)
    assert result == 123

# Generated at 2022-06-12 06:41:33.320946
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import sys

    logger = logging.getLogger()
    logger.level = logging.DEBUG
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)

    # setup test
    @LoggedFunction(logger)
    def test_function1(a, b=2, c="3"):
        return a + b - int(c)

    # test without kwargs
    assert test_function1(1) == 0

    # test with kwargs
    assert test_function1(1, c=4) == 2

    # test with logging
    assert test_function1(1, 3, c=4) == 2


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:41:37.863179
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    @LoggedFunction(logger=logger)
    def add(x, y):
        return x + y

    add(1, 2)

    return add.__name__ == "add"