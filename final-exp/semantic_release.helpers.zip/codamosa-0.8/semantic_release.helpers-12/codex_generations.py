

# Generated at 2022-06-12 06:32:47.275024
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = MagicMock(spec=())
    log = LoggedFunction(logger)
    @log
    def f(a, b):
        return a + b
    f(5, 6)
    logger.debug.assert_called_once_with("f(5, 6)")
    logger.debug.reset_mock()
    f(5, b=6)
    logger.debug.assert_called_once_with("f(5, b=6)")
    logger.debug.reset_mock()
    ret = f(5, b=6)
    logger.debug.assert_called_once_with("f -> 11")
    logger.debug.reset_mock()

# Generated at 2022-06-12 06:32:55.141015
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    func1 = LoggedFunction(logger)(lambda x, y: x + y)
    assert callable(func1)
    func2 = LoggedFunction(logger)(lambda x, y, z: x + y + z)
    assert callable(func2)

    func1(1, 2)
    logger.debug("----")
    func2(1, 2, 3)
    return True

# Generated at 2022-06-12 06:33:04.501719
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            logger = logging.getLogger(__name__)
            logged_func = LoggedFunction(logger=logger)
            @logged_func
            def func(arg1, arg2="no_arg2", *args, **kwargs):
                return 'result'
            logger.debug = lambda x: self.assertEqual(x, "func(arg1, arg2='no_arg2', *args, **kwargs)")
            logger.debug = lambda x: self.assertEqual(x, "func -> result")
            self.assertEqual(func(arg1='arg1'), 'result')

# Generated at 2022-06-12 06:33:11.456327
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    def my_method(a: str, b: int) -> str:
        return f'{a}-{b}'

    logger = logging.Logger("name")

    logged_my_method = LoggedFunction(logger)(my_method)

    logger.debug = print
    logged_my_method("a", 1)
    printed_string = '-'.join([str(i) for i in range(1000)])
    logged_my_method("a", printed_string)


# Generated at 2022-06-12 06:33:20.464314
# Unit test for function build_requests_session
def test_build_requests_session():
    # test using default option
    assert build_requests_session().max_redirects == 30

    # test with given raise_for_status option
    assert build_requests_session(raise_for_status=False).hooks == {}
    assert (
        "raise_for_status"
        in build_requests_session(raise_for_status=True).hooks["response"][0].__name__
    )

    # test with given retry option
    assert (
        build_requests_session(retry=Retry(total=10)).max_retries
        == build_requests_session(retry=10).max_retries
    )

# Generated at 2022-06-12 06:33:27.487668
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    
    def mock_logger_debug(msg):
        logger_debug_called.append(msg)

    logger_debug_called = []
    mock_logger = logging.Logger("some_mock_logger")
    mock_logger.debug = mock_logger_debug

    lf = LoggedFunction(mock_logger)
    add = lf(lambda num_1, num_2: num_1 + num_2)
    add(1, 2)

    assert logger_debug_called[-1] == "add(1, 2)"
    assert add(3, 4) == 7
    assert logger_debug_called[-1] == "add -> 7"


# Generated at 2022-06-12 06:33:32.476257
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import asyncio
    from aiohttp import ClientSession
    from pyelasticsearch import ElasticSearch, ElasticHttpError
    from requests.exceptions import HTTPError

    class Calc:
        def add(self, x, y):
            return x + y

    class Log:
        def __init__(self):
            self.log = []

        def debug(self, s):
            self.log.append(s)

    class OldService:
        @LoggedFunction(logger)
        def send(self, url, data):
            session = build_requests_session()
            session.post(url=url, data=data)


# Generated at 2022-06-12 06:33:42.716427
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.logs = []
            self.debug_has_been_called = False

        def debug(self, msg):
            self.logs.append(msg)
            self.debug_has_been_called = True

    logger = FakeLogger()
    logged_function = LoggedFunction(logger)
    func = logged_function(lambda x: x + 3)
    func(3)
    assert func.__name__ == "test_logged_function___call__.<locals>.<lambda>"
    assert logger.logs == [
        "test_logged_function___call__.<locals>.<lambda>(3)",
        "test_logged_function___call__.<locals>.<lambda> -> 6",
    ]
    assert func.__doc__

# Generated at 2022-06-12 06:33:51.340281
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = mock.Mock()
    function = mock.Mock()
    function.__name__ = "test_function"
    decorator = LoggedFunction(logger)
    function = decorator(function)
    function()
    function(3, 4, a=5)
    function.assert_has_calls(
        [
            mock.call(),
            mock.call(3, 4, a=5),
        ]
    )
    logger.debug.assert_has_calls(
        [
            mock.call("test_function()"),
            mock.call("test_function(3, 4, a='5')"),
        ]
    )



# Generated at 2022-06-12 06:34:01.967576
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.output = []

        def debug(self, msg):
            self.output.append(msg)

        def clear(self):
            self.output.clear()

    test_logger = TestLogger()
    logged_function = LoggedFunction(test_logger)

    def test_func():
        pass

    # Check that the called function is logged
    logged_test_func = logged_function(test_func)
    logged_test_func()
    assert test_logger.output[0] == "test_func()"

    # Check that the arguments are logged
    logged_test_func = logged_function(test_func)
    logged_test_func(1, "2", 3.0)

# Generated at 2022-06-12 06:34:14.252053
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock

    def test_func(a, b="ok", *, c: int = 5) -> int:
        return 1

    logger = mock.MagicMock()
    decorator = LoggedFunction(logger)

    # Create function with logging
    logged_func = decorator(test_func)

    # Call function
    result = logged_func(1, b="ok", c=3)

    # Check
    assert result == 1
    logger.debug.assert_has_calls(
        [
            mock.call(
                "test_func(1, 'ok', c=3)"
            ),
            mock.call(
                "test_func -> 1"
            )
        ]
    )



# Generated at 2022-06-12 06:34:21.875419
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Prepare
    logger = logging.getLogger()
    testFunc = lambda name: f"Hello {name}!"
    testObj = LoggedFunction(logger)

    # Test
    loggedFunc = testObj.__call__(testFunc)
    result = loggedFunc("Andy")

    # Verify
    assert result == "Hello Andy!", "The original function should be called"
    assert (
        loggedFunc.__name__ == testFunc.__name__
    ), "The wrapper should have the original function name"

# Generated at 2022-06-12 06:34:28.202216
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("TestLog")
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    logger.setLevel("DEBUG")

    @LoggedFunction(logger)
    def test_function(a: int, b: str, c: str, d: str = "default") -> str:
        return b+c+d

    assert test_function(10, "hello", "world") == "helloworlddefault"
    assert test_function(10, "hello", "world", d="worked") == "helloworldworked"



# Generated at 2022-06-12 06:34:38.956610
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    expected_logging_start = "foo(bar, 1, baz=2, 3, 4, 5, None)"
    expected_logging_return = "foo -> None"
    import logging

    class TestLogger(logging.Logger):
        def __init__(self):
            super().__init__("test")
            self.logs = []

        def debug(self, msg, *args, **kwargs):
            self.logs.append(msg % args % kwargs)

    @LoggedFunction(TestLogger())
    def foo(bar, *args, **kwargs):
        return

    foo(bar="bar", baz=2, *["1", 3, 4, 5, None])
    got_logging_start = foo.logger.logs[0]
    got_logging_return

# Generated at 2022-06-12 06:34:46.929840
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from src.log import get_logger
    from src.util.safe_str import safe_str

    # Initialize logger
    logger = get_logger(__name__)

    # Test LoggedFunction decorator
    @logger.debug(LoggedFunction(logger))
    def test_func(a, b, c=3, d=4, e=5, f=6):
        return a + b + c + d + e + f

    test_func(1, 2)



# Generated at 2022-06-12 06:34:57.950772
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import os
    import tempfile

    # Create a logger for the tests
    temp_file = os.path.join(tempfile.gettempdir(), "test_LoggedFunction___call__")
    logger = logging.getLogger("test_LoggedFunction___call__")
    handler = logging.FileHandler(temp_file)
    handlers = logger.handlers
    logger.handlers = [handler]
    logger.setLevel(logging.DEBUG)

    # Create a LoggedFunction instance, and decorate a function
    logged_function = LoggedFunction(logger)

    @logged_function
    def myfunc(a, b, c=42):
        return a + b + c

    # Call the function, and check that its argument values and return values are logged
    assert myfunc(1, 2) == 45
   

# Generated at 2022-06-12 06:35:06.329278
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import json
    import logging
    import tempfile
    from Logging import create_logger
    from functools import reduce

    logger = create_logger(level=logging.DEBUG)
    logged_function = LoggedFunction(logger)

    @logged_function
    def sum(*numbers):
        return reduce(lambda a, b: a + b, numbers)

    @logged_function
    def concat(*strings):
        return "".join(strings)

    # Test sum()
    assert sum(1, 2, 3, 4, 5) == 15, "sum() doesn't work"

    # Test concat()
    assert concat("This is a ", "test", "!") == "This is a test!", "concat() doesn't work"


# Generated at 2022-06-12 06:35:17.098133
# Unit test for function build_requests_session
def test_build_requests_session():
    # raise_for_status and retry are True.
    session_1 = build_requests_session(raise_for_status=True, retry=True)
    assert session_1.hooks is not None
    assert session_1.adapters is not None
    assert "response" in session_1.hooks
    assert isinstance(session_1.adapters['http://'].max_retries, Retry)
    assert isinstance(session_1.adapters['https://'].max_retries, Retry)

    # raise_for_status is True and retry is 5
    session_2 = build_requests_session(raise_for_status=True, retry=5)
    assert session_2.hooks is not None
    assert session_2.adapters is not None
    assert "response" in session

# Generated at 2022-06-12 06:35:24.267581
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # define inner method with logging
    def my_func(a, b):
        return a + b

    # define method with logging
    @LoggedFunction
    def my_func1(a, b):
        return a + b

    # create logger
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    format = logging.Formatter("%(levelname)s:%(message)s")
    handler = logging.StreamHandler()
    handler.setFormatter(format)
    logger.addHandler(handler)

    my_func_with_logging = LoggedFunction(logger=logger)(my_func)

    my_func_logger = logging.getLogger(__name__)

# Generated at 2022-06-12 06:35:27.199382
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger()
    loggedFunction = LoggedFunction(logger)

    def addition(x, y):
        return x + y

    loggedAddition = loggedFunction(addition)
    loggedAddition(1, 2)


# Generated at 2022-06-12 06:35:44.582859
# Unit test for function build_requests_session
def test_build_requests_session():
    # default config
    session = build_requests_session()
    assert session
    assert len(session.adapters) == 2
    adapter = session.adapters.get("https://")
    assert adapter
    assert isinstance(adapter.max_retries, Retry)
    assert "response" in session.hooks

    # with raise_for_status
    session = build_requests_session(raise_for_status=False)
    assert len(session.adapters) == 2
    assert "response" not in session.hooks

    # with retry
    session = build_requests_session(retry=Retry(5))
    assert len(session.adapters) == 2
    adapter = session.adapters.get("https://")
    assert adapter

# Generated at 2022-06-12 06:35:49.634576
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from loguru import logger

    logger.remove()
    logger.add(sys.stderr, level="DEBUG")

    def test(a, b, c=1, d=2):
        return a + b + c + d

    test = LoggedFunction(logger=logger)(test)
    res = test(1, 2, d=5, c=5)
    assert res == 13

# Generated at 2022-06-12 06:35:58.368198
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase
    from unittest.mock import patch, Mock

    class MockLogger:
        def __init__(self):
            self.debug = Mock()

    class TestLoggedFunction___call__(TestCase):
        @patch("logging.getLogger")
        def test_(self, mock_getLogger):
            mock_logger = MockLogger()
            mock_getLogger.return_value = mock_logger

            def mock_func(x, y):
                return x + y

            mock_func_name = "mock_func"
            mock_func.__name__ = mock_func_name
            mock_x = 3
            mock_y = 4
            mock_return = 7


# Generated at 2022-06-12 06:36:10.138977
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Add the log message handler to the logger
    handler = logging.StreamHandler()
    # Use the `str.format` style of logging
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Make a dummy function
    @LoggedFunction(logger)
    def dummy(a, b, c=3, d=4):
        """Dummy function to unit test LoggedFunction class."""
        print(a, b, c, d)

    # Call it a few times

# Generated at 2022-06-12 06:36:17.481523
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import threading
    from queue import Queue, Empty
    def on_call(record):
        record_queue.put(record)
    handler = logging.handlers.QueueHandler(record_queue)
    handler.handle = on_call
    logging.basicConfig(level=logging.INFO, handlers=[handler])
    logger = logging.getLogger("test")
    logger.disabled = False
    def test_func(a, b, c=3):
        return (a, b, c)
    dec = LoggedFunction(logger)
    test_func = dec(test_func)
    t = threading.Thread(target=test_func, args=(1,2), kwargs={"c":3})
    t.start()

# Generated at 2022-06-12 06:36:27.381760
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger, Logger

    # Initialize logger
    logger: Logger = getLogger("logged-function")
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # This "is" a function
    def func(a: str, b: float, c: int = 0):
        return int(a) + int(c) + b

    # Verify that decorator outputs debug messages
    logged_func = LoggedFunction(logger)(func)
    logged_func("1", 1.1)
    logged_func("1", b=1.1)  # output should be the same as above
    logged_func("1", 1.1, c=2)
    logged_func("1", 1.1, c=2)  # output should

# Generated at 2022-06-12 06:36:36.919371
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger(object):
        def __init__(self):
            self.log = []
        def warn(self, message):
            self.log.append(message)
        def debug(self, message):
            self.log.append(message)
        def info(self, message):
            self.log.append(message)
        def exception(self, message):
            self.log.append(message)
        def critical(self, message):
            self.log.append(message)

    logger = Logger()

    @LoggedFunction(logger=logger)
    def my_function(a, b, c=3, d=4):
        return a + b + c + d

    my_function(1, 2, 3)
    if not logger.log:
        # No log
        return
    assert logger

# Generated at 2022-06-12 06:36:48.270648
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock
    from unittest.mock import MagicMock
    from requests import Session
    from pprint import pformat
    import logging

    # class Session:
    #     def request(self, method, url, **kwargs):
    #         return

    def function(a: str, b: int, c: float, d: str, e: bytes):
        return

    with mock.patch("time.sleep") as mock_sleep:
        mock_logger = MagicMock(spec=logging.Logger)
        logged_function = LoggedFunction(mock_logger)
        logged_instancemethod = logged_function(function)
        logged_instancemethod("arg1", 2, 3.0, "arg3", b"arg4")

# Generated at 2022-06-12 06:36:57.923485
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import logging.config
    import tempfile

    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "simple": {
                    "format": "%(name)s - %(funcName)s - %(levelname)s - %(message)s"
                }
            },
            "handlers": {
                "console": {"class": "logging.StreamHandler", "level": "DEBUG",}
            },
            "loggers": {"": {"handlers": ["console"], "level": "DEBUG",}},
        }
    )
    logger = logging.getLogger(__name__)

    # test with no return value

# Generated at 2022-06-12 06:37:02.606179
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None

    session = build_requests_session(retry=3)
    assert session is not None

    session = build_requests_session(retry=False)
    assert session is not None

# Generated at 2022-06-12 06:37:11.274923
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def foo(s, x, y=2):
        return s + x + y

    lf = LoggedFunction(logging.getLogger("test"))

    foo_logged = lf(foo)

    assert foo("a", 1) == foo_logged("a", 1)



# Generated at 2022-06-12 06:37:14.774462
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Given
    logger = logging.getLogger()
    logged_function_decorator = LoggedFunction(logger)
    test_args = (1, 2, 3)
    test_kwargs = {"arg1": "arg1", "arg2": "arg2", "arg3": "arg3"}

    # When
    @logged_function_decorator
    def logged_function(*args, **kwargs):
        return args, kwargs

    logged_function(test_args, **test_kwargs)

    # Then
    assert True

# Generated at 2022-06-12 06:37:20.578429
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # test case 1
    logger = logging.Logger("")
    logger.debug = lambda msg: print("logger: " + msg)
    logged_func = LoggedFunction(logger)(lambda x, y: x + y)
    assert logged_func(1, 2) == 3

    # test case 2
    logged_func = LoggedFunction(logger)(lambda: 1)
    assert logged_func() == 1


if __name__ == "__main__":
    import sys

    function_name = sys.argv[1]
    if not function_name:
        sys.exit()

    print(eval(function_name)())

# Generated at 2022-06-12 06:37:28.223150
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction
    """
    from unittest.mock import MagicMock
    from functools import wraps
    import logging

    logger = logging.getLogger('TestDebugger')
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    logger.info('Start test')
    logger.info('\tTest __init__')
    log_decor = LoggedFunction(logger)

    @log_decor
    def hello():
        return 'Hello'

    logger.info('\tTest __call__')
    assert hello() == 'Hello'
    logger.info('End of test')



# Generated at 2022-06-12 06:37:35.894261
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Create logger
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    # Create handler
    handler = logging.NullHandler()
    handler.setLevel(logging.DEBUG)

    # Add handler to logger
    logger.addHandler(handler)

    # Decorate function
    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    # Call function
    add(2, 3)
    add(3, 4)



# Generated at 2022-06-12 06:37:40.592567
# Unit test for function build_requests_session
def test_build_requests_session():
    # mock test with unittest
    class MockAdapter:
        def mount(self, protocol, adapter):
            print(f"mount {protocol} to requests session")

    session = build_requests_session()
    assert session.hooks == {"response":[lambda r, *args, **kwargs: r.raise_for_status()]}
    assert session.mount.called

# Generated at 2022-06-12 06:37:51.810567
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger, DEBUG
    from io import StringIO
    import sys

    def my_function(a, b, c=3, d=4):
        return a * b * c * d

    logger = Logger("test_logger", level=DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)
    logged_function = LoggedFunction(logger)
    my_logged_function = logged_function(my_function)

    # function name and input arguments
    my_logged_function(1, 2)
    assert stream.getvalue() == 'test_logger DEBUG test_logger : "my_function(1, 2, c=3, d=4)\n'
    stream.seek(0)
    stream.truncate(0)



# Generated at 2022-06-12 06:37:52.326823
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-12 06:38:00.525087
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import io

    logging.basicConfig(level=logging.DEBUG)

    class LoggedFunctionTester(unittest.TestCase):
        def setUp(self):
            self.test_logger = logging.Logger("test_logger")
            f = io.StringIO()
            hdl = logging.StreamHandler(f)
            self.test_logger.addHandler(hdl)
            self.test_logger.setLevel(logging.DEBUG) # to avoid filter out

        def tearDown(self):
            for handler in self.test_logger.handlers:
                self.test_logger.removeHandler(handler)

        def test_function_with_no_args_is_called(self):
            def func(arg1, arg2):
                return 1



# Generated at 2022-06-12 06:38:10.626845
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger object
    logfile = StringIO()
    logging.basicConfig(
        level=logging.DEBUG, format="%(asctime)s %(message)s", stream=logfile
    )
    logger = logging.getLogger("Tester Logger")

    # Call the decorator class
    @LoggedFunction(logger)
    def test_function(a, b, c="string", d=True):
        pass

    # Set up test cases

# Generated at 2022-06-12 06:38:29.020131
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import io
    import logging
    import sys
    import re

    class LoggedFunctionTest(unittest.TestCase):
        def test__call__(self):
            def test_func(a: int, b: str, c: bool = True, d=None) -> str:
                return "test result"

            log_stream = io.StringIO()
            logger = logging.getLogger("test_logger")
            handler = logging.StreamHandler(log_stream)
            logger.addHandler(handler)
            lf = LoggedFunction(logger)
            decorated_func = lf(test_func)

            # test decorator
            self.assertTrue(test_func)
            self.assertTrue(decorated_func)
            decorated_func(1, "2")

            # test log


# Generated at 2022-06-12 06:38:34.696942
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import pytest
    from StringIO import StringIO
    import os

    logging.basicConfig()

    logger = logging.getLogger("test_logged_function")
    handler = logging.StreamHandler(StringIO())
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def add(a, b):
        return a + b

    logger.setLevel(logging.DEBUG)
    handler.setLevel(logging.DEBUG)
    assert add(2, 3) == 5
    assert (
        handler.stream.getvalue()
        == "test_logged_function DEBUG: add(2, 3)\n"
        "test_logged_function DEBUG: add -> 5\n"
    )

    assert logger.isEnabledFor(logging.INFO) is False

# Generated at 2022-06-12 06:38:43.602802
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    logger = Logger()
    decorator = LoggedFunction(logger)
    # test function with no arguments
    @decorator
    def no_args():
        return True

    no_args()
    assert logger.logs[0] == "no_args()"
    assert logger.logs[1] == "no_args -> True"
    # test function with arguments
    @decorator
    def func(a, b):
        return a+b

    func(3,5)
    assert logger.logs[2] == "func(3, 5)"
    assert logger.logs[3] == "func -> 8"
    #

# Generated at 2022-06-12 06:38:50.011959
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import types

    test_logger = logging.getLogger("test")
    test_logger.setLevel(logging.DEBUG)

    @LoggedFunction(test_logger)
    def test_func(a, b, c, d=10, e=20):
        pass

    assert isinstance(test_func, types.FunctionType)
    test_func(1, "test", None, e=30)

# Generated at 2022-06-12 06:38:59.741084
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Mock()
    logged_function = LoggedFunction(logger)
    @logged_function
    def test_func(param1, param2):
        return param1+param2
    test_func(1, 2)
    logger.debug.assert_called_with("test_func(1, 2)")
    logger.debug.assert_called_with("test_func -> 3")


if __name__ == '__main__':
    import unittest

    class LoggedFunctionTest(unittest.TestCase):
        def test__LoggedFunction__call__(self):
            logger = Mock()
            logged_function = LoggedFunction(logger)
            @logged_function
            def test_func(param1, param2):
                return param1+param2
            test_func(1, 2)
            logger

# Generated at 2022-06-12 06:39:08.902972
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import mock
    import sys

    import pyparsing as pp

    mock_Logger = mock.MagicMock()
    mock_Logger.debug = mock.MagicMock()
    logger = mock_Logger

    def add(x, y, z=3):
        return x + y + z

    logged_add = LoggedFunction(logger)(add)
    logged_add(1, 2)
    logged_add(1, 2, z=4)
    logger.debug.assert_has_calls(
        [
            mock.call("add(1, 2, z=3)"),
            mock.call("add -> 6"),
            mock.call("add(1, 2, z=4)"),
            mock.call("add -> 7"),
        ]
    )



# Generated at 2022-06-12 06:39:10.586950
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session


# Generated at 2022-06-12 06:39:19.362762
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.call_count = 0
            self.debug_args = []

        def debug(self, *args):
            self.call_count += 1
            self.debug_args.append(args)

    def func(arg1, arg2=0):
        return arg1 + arg2

    logger = Logger()
    logged_func = LoggedFunction(logger)(func)
    assert logged_func(1) == 1
    assert logged_func(1, 2) == 3
    assert logger.call_count == 2
    assert logger.debug_args[0] == ("func(1)",)
    assert logger.debug_args[1] == ("func(1, 2)",)

# Generated at 2022-06-12 06:39:29.036085
# Unit test for function build_requests_session
def test_build_requests_session():
    # test: raise_for_status is True
    session = build_requests_session(raise_for_status=True)
    assert len(session.hooks["response"]) == 1
    assert session.hooks["response"][0].__name__ == "raise_for_status"

    # test: raise_for_status is False
    session = build_requests_session(raise_for_status=False)
    assert len(session.hooks["response"]) == 0

    # test: retry is True
    session = build_requests_session(retry=True)
    assert session.adapters["https://"].max_retries.total == 10

    # test: retry is False
    session = build_requests_session(retry=False)
    assert not hasattr(session, "mount")

   

# Generated at 2022-06-12 06:39:38.310838
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.debug = print

    @LoggedFunction(logger)
    def f(a: int, b: int, c: str = "c") -> str:
        return f"{a} {b} {c}"

    print(f(1, 2))
    print(f(1, 2, c="3"))
    print(f(1, 2, "3"))
    print(f(1, 2, "3", d=4))


test_LoggedFunction___call__()

# Generated at 2022-06-12 06:40:07.779768
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    logger = Mock()

    lf = LoggedFunction(logger)
    func = Mock(name="mock_func")
    func.__name__ = "name"

    # with args, w/kwargs
    lf(func)(1, 2, 3, kwarg1="kwarg1", kwarg2="kwarg2")
    logger.debug.assert_called()
    logger.debug.assert_called_with("name(1, 2, 3, kwarg1='kwarg1', kwarg2='kwarg2')")
    func.assert_called_with(1, 2, 3, kwarg1="kwarg1", kwarg2="kwarg2")

    # with args, no kwargs
    lf(func)(1, 2, 3)


# Generated at 2022-06-12 06:40:15.195927
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import unittest.mock

    logger = unittest.mock.MagicMock()

    def test_func(a, b, c="c"):
        pass

    decorated_func = LoggedFunction(logger)(test_func)

    # Test empty arguments
    decorated_func()
    logger.debug.assert_any_call("test_func()")
    # Clear log
    logger.reset_mock()

    # Test non-keyword arguments
    decorated_func(1, 2, 3)
    logger.debug.assert_any_call("test_func(1, 2, 3)")
    logger.reset_mock()

    # Test keyword arguments
    decorated_func(1, 2, c=3)

# Generated at 2022-06-12 06:40:22.876115
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    class TestLogger(logging.getLoggerClass()):
        def __init__(self, level=logging.NOTSET):
            super().__init__("TestLogger")
            self.level = level
            self.msg = ""

        def handle(self, record):
            if self.level <= record.levelno:
                self.msg += "{}\n".format(record.getMessage())

        def reset(self):
            self.msg = ""

    logger = TestLogger(logging.DEBUG)
    logging.setLoggerClass(TestLogger)
    capturedOutput = StringIO()
    logging.basicConfig(stream=capturedOutput, level=logging.DEBUG)

    def testFuncA(a, b, c):
        return a + b + c

   

# Generated at 2022-06-12 06:40:32.939587
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(levelname)s] <%(name)s> %(message)s",
    )

    class A:
        @LoggedFunction(logger=logging.getLogger(__name__))
        def foo(self, a, b):
            return a * b * 3

        @LoggedFunction(logger=logging.getLogger(__name__))
        def bar(self, c):
            return c * 6 + self.foo(1, 2)

    a = A()
    assert a.foo(2, 3) == 18
    assert a.bar(3) == 18
    a.foo.__name__
    assert a.foo.__name__ == "foo"




# Generated at 2022-06-12 06:40:39.150611
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import contextlib
    from diana.dixel import Dixel
    from diana.apis import Orthanc
    from diana.utils import DicomLevel, find_dicom_level
    from diana.utils.dicom import make_dicom_dataset, add_dcm_meta, ds_handler
    from diana.utils import TestClass


# Generated at 2022-06-12 06:40:48.864118
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session(True, True)
    assert isinstance(sess, Session)
    sess = build_requests_session(False, True)
    assert isinstance(sess, Session)
    sess = build_requests_session(False, False)
    assert isinstance(sess, Session)
    retry = Retry()
    sess = build_requests_session(False, retry)
    assert isinstance(sess, Session)
    retry = Retry(1)
    sess = build_requests_session(False, retry)
    assert isinstance(sess, Session)
    try:
        build_requests_session(False, "retry")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-12 06:40:57.618000
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.logs = []

        def debug(self, log):
            self.logs.append(log)

    def logged_func(*args, **kwargs):
        pass

    def decorated_func(*args, **kwargs):
        pass

    logger = Logger()
    logged_function = LoggedFunction(logger)
    logged_function(logged_func)("arg1", kwarg1="kwarg1", kwarg2="kwarg2")
    assert logger.logs[0] == "logged_func('arg1', kwarg1='kwarg1', kwarg2='kwarg2')"

    assert decorated_func.__name__ == 'decorated_func'
    decorated_func = logged_function(decorated_func)

# Generated at 2022-06-12 06:41:07.059566
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock, sentinel

    func = Mock()
    func.__name__ = "123"
    decorated = LoggedFunction(Mock())(func)
    decorated("a", "b", c="d")
    func.assert_called_once_with("a", "b", c="d")
    func.reset_mock()
    decorated("a", "b", c="d")
    func.assert_called_once_with("a", "b", c="d")
    func.return_value = sentinel.RETURNED
    decorated("a", "b", c="d")
    func.assert_called_once_with("a", "b", c="d")

# Generated at 2022-06-12 06:41:14.165836
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock
    from unittest import TestCase, main

    class TestLoggedFunction(TestCase):
        def test_LoggedFunction(self):
            logger = logging.Logger("test")
            handler = Mock()
            logger.addHandler(handler)

            def add(x, y):
                return x + y

            add_logged = LoggedFunction(logger)(add)
            add_logged(1, 2)
            self.assertEqual(handler.handle.call_count, 1)

    main()

# Generated at 2022-06-12 06:41:17.682362
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test")
    loggedFunction = LoggedFunction(logger)
    logging.basicConfig(level=logging.DEBUG, format="%(message)s")

    @loggedFunction
    def f(x):
        return x

    f(1)
    f(1, 2)
    f(x=1)
    f(1, x=2)

# Generated at 2022-06-12 06:41:55.515788
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    test_logger = logging.getLogger("test")
    test_logger.setLevel(logging.DEBUG)
    test_logger.addHandler(logging.StreamHandler())
    test_func = LoggedFunction(test_logger)

    tmp_logger_level = test_logger.level

    @test_func
    def test_func1():
        pass

    test_logger.setLevel(logging.DEBUG)
    result = test_func1()
    assert result == None
    assert test_func1.__name__ == "test_func1"
    test_logger.setLevel(logging.ERROR)
    result = test_func1()
    assert result == None


# Generated at 2022-06-12 06:42:04.759581
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    class MyLogger(logging.Logger):
        def __init__(self):
            self.log = []
            super().__init__(None)

        def handle(self, record):
            self.log.append(record)

    mylogger = MyLogger()
    logging.setLoggerClass(MyLogger)

    LoggedFunction(mylogger)(lambda x, y: x // y)(10, 3)

    assert mylogger.log[-2].getMessage() == "lambda(10, 3)"
    assert mylogger.log[-1].getMessage() == "lambda -> 3"

# Generated at 2022-06-12 06:42:14.892491
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Case 1: No arguments are passed
    # Create mock logger
    logger = Mock()

    # Create LoggedFunction
    logged_function = LoggedFunction(logger)

    # Create function to wrap
    func = Mock(__name__="test_func")

    # Wrap function
    logged_func = logged_function(func)

    # Invoke function
    logged_func()

    # Check if logger.debug was called
    logger.debug.assert_called_once_with("test_func()")

    # Check if function was called
    func.assert_called_once_with()

    # Reset mocks
    logger.reset_mock()
    func.reset_mock()

    # Case 2: 1 argument is passed
    # Create mock logger
    logger = Mock()

    # Create LoggedFunction

# Generated at 2022-06-12 06:42:23.838566
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger(object):
        def __init__(self):
            self.logs = []
        
        def debug(self, msg):
            self.logs.append(msg)
    
    def test_func(*args, **kwargs):
        return str(args) + str(kwargs)

    logger = TestLogger()
    log_decorator = LoggedFunction(logger)
    test_func_decorated = log_decorator(test_func)

    assert test_func_decorated(1, 'string', [1, 2, 3], key=True, value=False) == "(1, 'string', [1, 2, 3]){'key': True, 'value': False}"
    assert len(logger.logs) == 2

# Generated at 2022-06-12 06:42:34.204091
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func1(a, b):
        return a + b

    def func2(a, *args):
        return a

    class Logger:
        def debug(self, message):
            assert message == "func1('a', b='c')"

        def info(self, message):
            raise RuntimeError("info is not implemented")

        def warning(self, message):
            raise RuntimeError("warning is not implemented")

        def error(self, message):
            raise RuntimeError("error is not implemented")

    logged_func = LoggedFunction(Logger())(func1)
    logged_func('a', b='c')
    logged_func(a='a', b='c')
    logged_func(a='a', b='c', d='f')
    logged_func('a', 'c')

# Generated at 2022-06-12 06:42:37.865815
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("my_logger")
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def some_function(param1, param2="abc"):
        pass

    some_function("foo", param2="bar")

