

# Generated at 2022-06-12 06:32:47.467869
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger, DEBUG

    logger = getLogger()
    logger.setLevel(DEBUG)
    logged_function = LoggedFunction(logger)
    @logged_function
    def return_func():
        return "return value"
    return_func()



# Generated at 2022-06-12 06:32:57.664612
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class _Logger:
        def __init__(self):
            self.debug_calls = []

        def debug(self, msg):
            self.debug_calls.append(msg)

    def _func_1(a, b, c, d=5, e="hi"):
        return

    def _func_2():
        return "hello"

    logger = _Logger()
    logged_func = LoggedFunction(logger)(_func_1)
    logged_func(1, 2, 3)
    logged_func(1, 2, 3, d=7)
    logged_func(1, 2, 3, d=7, e="hola")
    logged_func(1, 2, 3, e="hola")


# Generated at 2022-06-12 06:33:05.988376
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import sys
    import logging
    import inspect
    from contextlib import redirect_stdout

    # Set up logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = logging.StreamHandler(sys.stdout)
    stream.setLevel(logging.DEBUG)
    logger.addHandler(stream)

    # Create LoggedFunction decorator
    logged_function = LoggedFunction(logger)

    # Test class method
    class TestClass:
        @logged_function
        def test_method(self, *args):
            return args


# Generated at 2022-06-12 06:33:12.664315
# Unit test for function build_requests_session
def test_build_requests_session():
    # no raise no retry
    session = build_requests_session(False, False)
    assert "response" not in session.hooks

    # no raise with retry
    session = build_requests_session(False, True)
    assert "response" not in session.hooks

    # with raise no retry
    session = build_requests_session(True, False)
    assert "response" in session.hooks

    # with raise with retry
    session = build_requests_session(True, True)
    assert "response" in session.hooks

# Generated at 2022-06-12 06:33:24.358517
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Unit test for method __call__ of class LoggedFunction
    """
    class Obj:
        pass

    obj = Obj()
    for logger in (logging.getLogger("test"), logging.getLogger("test.prefix")):
        logger.debug("test")
        decorate = LoggedFunction(logger)
        def test_add(): return 1 + 2
        test_add1 = decorate(test_add)
        obj.test_add2 = decorate(test_add)
        assert test_add1() == 3
        assert obj.test_add2() == 3
        assert "test_add() -> 3" == logger.handlers[0].messages[-1]
        assert "test_add2() -> 3" == logger.handlers[0].messages[-2]

# Generated at 2022-06-12 06:33:36.998245
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import tempfile
    from io import StringIO
    from logging import StreamHandler, getLogger

    logger = getLogger(__file__)
    logger.addHandler(StreamHandler(stream=StringIO()))

    @LoggedFunction(logger)
    def test(x, p1=0, p2=0):
        return x + p1 + p2

    test(1, 2, 3)
    assert logger.handlers[0].stream.getvalue().strip() == "test(1, 2, 3)"
    logger.handlers[0].stream.truncate(0)

    test(1, 2, 3)
    assert logger.handlers[0].stream.getvalue().strip() == "test(1, 2, 3)"
    logger.handlers[0].stream.truncate(0)


# Generated at 2022-06-12 06:33:43.424520
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from loguru import logger
    
    test_value = 0
    logger.disable("test_module")
    logger.enable("test_module")
    logger.debug("")

    @LoggedFunction(logger)
    def f(a : int, b : str) -> int:
        nonlocal test_value
        test_value = a
        return a + int(b)
    result = f(1, "2")
    assert result == test_value + 2
    assert logger.records[-1].message == "f(1, 2) -> 3"

# Generated at 2022-06-12 06:33:50.354859
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch
    from logging import getLogger

    @LoggedFunction(getLogger("test"))
    def test_func(i1, i2, kw1="foo", kw2="bar"):
        pass

    with patch("logging.getLogger") as mock_getLogger:
        mock_getLogger.return_value.debug = lambda msg: print(msg)
        test_func(1, "foo", kw1=2, kw2="baz")



# Generated at 2022-06-12 06:33:56.524478
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Given a function
    def func():
        pass
    # Given a function_2 with multiple arguments
    def func_2(arg1, arg2, kwarg1, kwarg2):
        pass

    with mock.patch("logging.Logger.debug") as mock_debug:
        # When decorate the function
        f = LoggedFunction('a')
        res = f(func)

        # Then function is called
        res()

        # And log function name and function arguments
        mock_debug.assert_called_once()
        assert mock_debug.call_args[0][0] == "func()"

    with mock.patch("logging.Logger.debug") as mock_debug:
        # When decorate the function_2
        f = LoggedFunction('a')
        res = f(func_2)

       

# Generated at 2022-06-12 06:34:03.887589
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    import unittest

    # Mock logging function
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream=stream)
    logger.addHandler(handler)

    # Test case: method without arguments
    @LoggedFunction(logger)
    def method():
        return "Hello World!"

    result = method()
    assert result == "Hello World!"
    assert stream.getvalue().strip() == "method()"

    stream.truncate(0) # Clear stream
    stream.seek(0) # Reset stream position to the beginning

    # Test case: method with 1 argument

# Generated at 2022-06-12 06:34:15.339370
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger()
    logger.level = logging.DEBUG
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    class Test:
        @LoggedFunction(logger)
        def foo(self, x, y, z=1):
            return x + y + z

    test = Test()
    assert test.foo(1, 2) == 4
    assert stream.getvalue() == "foo(1, 2, z=1)\nfoo -> 4\n"
    stream.truncate(0)
    assert test.foo(1, y=2, z=3) == 6

# Generated at 2022-06-12 06:34:25.841404
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    from unittest import mock

    # Given
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

# Generated at 2022-06-12 06:34:37.050382
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from contextlib import redirect_stdout, redirect_stderr

    funcName = str()
    ret = dict()
    args = tuple()
    kwargs = dict()

    def test_func(*args, **kwargs):
        nonlocal funcName
        funcName = test_func.__name__
        nonlocal ret
        ret = {"args": args, "kwargs": kwargs}
        return ret

    logger = logging.getLogger('test_logger')
    loggerHandler = logging.StreamHandler()
    logger.addHandler(loggerHandler)
    logger.setLevel(logging.DEBUG)
    loggerHandler.setLevel(logging.DEBUG)

    logFunc = LoggedFunction(logger)
    test_func = logFunc(test_func)

# Generated at 2022-06-12 06:34:49.257390
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    @LoggedFunction(logger=logging.getLogger(__name__))
    def test_func(x, y=1, *args, **kwargs):
        return f"{x} {y} {args} {kwargs}"

    test_func(None, *["one", "two"], **{"three": 3, "four": 4})
    assert(
        logging.getLogger(__name__).debug.mock_calls[0][1][0] ==
        "test_func(None, 'one', 'two', three=3, four=4)"
    )

# Generated at 2022-06-12 06:35:00.698945
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import json
    import requests
    from requests.adapters import HTTPAdapter

    # create logger
    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter("%(levelname)s - %(message)s")

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    class TestClass:
        @LoggedFunction(logger=logger)
        def add(self, x, y):
            return x + y


# Generated at 2022-06-12 06:35:12.396023
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    
    class LoggedFunctionTester(unittest.TestCase):
        def test_logged_func(self):
            logger = logging.getLogger(__class__.__name__)
            logger.setLevel(logging.DEBUG)
            logger.propagate = False
            handler = logging.StreamHandler()
            handler.setLevel(logging.DEBUG)
            handler.setFormatter(logging.Formatter("[%(name)s] %(message)s"))
            logger.addHandler(handler)

            @LoggedFunction(logger)
            def func(a: str, b: int = 1, c: bool = False):
                return a + str(b) + str(c)

            self.assertEqual(func("string", 2, True), "string21True")

# Generated at 2022-06-12 06:35:22.108789
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create a test logger:
    class TestLogger:
        def __init__(self):
            self.log = ""
        def debug(self, msg):
            self.log += msg + '\n'

    # Test data

# Generated at 2022-06-12 06:35:28.097221
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest.mock
    from contextlib import redirect_stdout

    l = logging.getLogger("TestLogger")
    l.setLevel(logging.DEBUG)
    stdout = io.StringIO()
    handler = logging.StreamHandler(stdout)
    l.addHandler(handler)
    func = LoggedFunction(l)
    decorated = func(unittest.mock.Mock()) 
    with redirect_stdout(stdout):
        decorated()

    output = stdout.getvalue().strip()
    assert output == "test() -> None"

# Generated at 2022-06-12 06:35:33.931437
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.called = False

        def debug(self, *args, **kwargs):
            self.called = True

    logger = MockLogger()
    decorator = LoggedFunction(logger)

    def foo():
        pass

    decorated_foo = decorator(foo)
    assert decorated_foo() is None
    assert logger.called

# Generated at 2022-06-12 06:35:45.228382
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('testlogger')
    logger.propagate = False
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    with logger.manager.log_action(logger.name, logging.DEBUG, 'Testing LoggedFunction'):
        loggedFunction = LoggedFunction(logger)
        @loggedFunction
        def logged_func(a,b,c=True,d=None):
            return a+b+c

        logged_func(1,2)
        logged_func(1,2,c=False)
        logged_func(1,2,c=None)

# Generated at 2022-06-12 06:35:54.462153
# Unit test for function build_requests_session
def test_build_requests_session():
    logger = logging.getLogger("test_build_requests_session")
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def f(x, y=2):
        return x + y

    f(1)

# Generated at 2022-06-12 06:36:00.109539
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test_logger")
    logged_func = LoggedFunction(logger)
    @logged_func
    def func(a, b, c: str=None, d="", e=None):
        # type: (int, float, str, str, float) -> int
        return a + b + c + d + e
    func(1, 2, 3, 4, 5)

# Generated at 2022-06-12 06:36:11.352440
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    class MockLogger:
        """Mock class that simulates a logging.Logger instance"""

        def __init__(self):
            self.debug_calls = []

        def debug(self, *args, **kwargs):
            """Record a call to debug"""
            self.debug_calls.append((args, kwargs))

        def assert_debug_call_count(self, count):
            """Check that log.debug() has been called the expected number of times"""
            assert len(self.debug_calls) == count

        def assert_debug_call_args(self, index, expected_args, expected_kwargs):
            """Check the log.debug() call with the given index contains the expected arguments"""
            assert self.debug_calls[index][0] == expected_args

# Generated at 2022-06-12 06:36:18.100941
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pprint import pprint
    from datetime import timedelta
    import logging
    import sys

    class Logger:
        def __init__(self):
            self.records = []

        def __getattr__(self, item):
            return lambda *args, **kwargs: self.records.append(
                [item, args, kwargs]
            )

        def getRecords(self):
            return self.records

    # create a stream to redirect stdout
    sys.stdout = open("test_output.txt", "w")

    # create a logger
    logger = Logger()
    logger.debug = lambda msg: logger.records.append(["debug", [msg]])

    # create a decorator
    logged_func = LoggedFunction(logger)

    # create a function

# Generated at 2022-06-12 06:36:25.033540
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import call

    logger = Mock()
    logged_function = LoggedFunction(logger)

    @logged_function
    def square(x):
        return x * x

    assert logger.debug.call_count == 0
    square(3)
    assert logger.debug.call_count == 2
    logger.debug.assert_has_calls(
        [
            call("square(3)"),
            call("square -> 9"),
        ]
    )


# Generated at 2022-06-12 06:36:34.849410
# Unit test for function build_requests_session
def test_build_requests_session():
    # basic test
    session = build_requests_session()
    for base_url in ["http://www.example.com", "https://www.example.com"]:
        r = session.get(base_url)
        assert r.status_code == 200

    # basic test with default retry of 3 times
    session = build_requests_session(retry=3)
    for base_url in ["http://www.example.com", "https://www.example.com"]:
        r = session.get(base_url)
        assert r.status_code == 200

    # basic test with custom retry instance
    retry_instance = Retry(total=1, backoff_factor=0.5, status_forcelist=[500])
    session = build_requests_session(retry=retry_instance)


# Generated at 2022-06-12 06:36:39.764142
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    import logging
    import sys

    logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
    logger = logging.getLogger("TestLoggedFunction")
    decorator = LoggedFunction(logger)
    def mock_func(*args, **kwargs):
        return "result"

    # Act
    logged_func = decorator(mock_func)
    result = logged_func("arg1", "arg 2", kwarg1="arg 3", kwarg2=4)

    # Assert
    assert result == "result"

# Generated at 2022-06-12 06:36:49.892004
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.mounts["http://"][0].max_retries.total == 3
    assert session.mounts["https://"][0].max_retries.total == 3
    session = build_requests_session(retry=Retry(total=5))
    assert session.mounts["http://"][0].max_retries.total == 5
    assert session.mounts["https://"][0].max_retries.total == 5
    session = build_requests_session(retry=3)
    assert session.mounts["http://"][0].max_retries.total == 3
    assert session.mounts["https://"][0].max_retries.total == 3
    session = build_requests_session

# Generated at 2022-06-12 06:36:58.522802
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def debug(self, message):
            self.debug_message = message

    func = LoggedFunction(TestLogger())

    def target(foo, bar, baz=None):
        return None

    target_func = func(target)
    assert target_func("foo", "bar") is None
    assert target_func.__name__ == "target"
    assert target_func.__doc__ is None
    assert target_func.__module__ == "pytest"
    assert (
        target_func.__qualname__ == "test_LoggedFunction___call__.<locals>.target"
    )
    assert target_func("foo", "bar") is None
    assert target_func("foo", "bar", baz="baz") is None
    assert target_func("foo", "bar") is None

# Generated at 2022-06-12 06:37:08.765812
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    This unit test checks the method LoggedFunction.__call__
    It verifies that : The input arguments are logged before the function is called, and the
    return value is logged once it has completed.
    """

    class Logger:
        def __init__(self):
            self.debug_string = ''

        def debug(self, string):
            self.debug_string += string

    logger = Logger()
    logged_function = LoggedFunction(logger)

    def test_function(a, b, *c, x, y=1):
        return a

    logged_test_function = logged_function(test_function)

    logged_test_function(1, 2, 3, 4, x=5)

# Generated at 2022-06-12 06:37:38.027884
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase
    from unittest.mock import Mock
    from inspect import getfullargspec

    logger = Mock()

    class LoggedFunctionTest(TestCase):
        def test_logged(self):
            def _method(a, b, c="3", d=7):
                return a + b + c + str(d)

            method = LoggedFunction(logger)(_method)
            method(1, 2, d=4)

            logger.debug.assert_called_once()
            logger.debug.assert_called_with(
                "test_logged(_method)(1, 2, c='3', d=4)"
            )


# Generated at 2022-06-12 06:37:49.658863
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase, mock
    from unittest.mock import MagicMock, patch

    logger = mock.MagicMock()
    decorator = LoggedFunction(logger)

    logger.debug = mock.MagicMock()

    def func(arg1, arg2, kwarg1=None, kwarg2=None):
        return "result"

    func = decorator(func)

    result = func("arg1", "arg2", "kwarg1", "kwarg2")
    assert result == "result"
    assert logger.debug.call_args == mock.call(
        "func(arg1, arg2, kwarg1=kwarg1, kwarg2=kwarg2)"
    )
    assert logger.debug.call_args == mock.call("func -> result")

# Generated at 2022-06-12 06:37:54.858284
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def debug(self, message):
            print(message)

    def test(a, b=2, c=3):
        pass

    test = LoggedFunction(TestLogger())(test)

    test(1)
    test(1, 2, 3)
    test(a=1, c=3)
    test(b=2, c=3)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:38:00.435502
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase

    class Example(TestCase):
        def test_example(self):
            test_logger = logging.getLogger("test")
            logged_function = LoggedFunction(test_logger)

            test_logger.disabled = True

            @logged_function
            def return_test(test: str) -> int:
                return int(test)

            self.assertEqual(1, return_test("1"))
            self.assertEqual(2, return_test("2"))

    Example().test_example()

# Generated at 2022-06-12 06:38:10.626364
# Unit test for method __call__ of class LoggedFunction

# Generated at 2022-06-12 06:38:21.049160
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    class LoggedFunctionTester(unittest.TestCase):
        def test__call__(self):
            logger = logging.getLogger("test_LoggedFunction___call__")
            logger.addHandler(logging.StreamHandler(sys.stdout))

            def f(x: int, y: int, z: int = 1) -> int:
                return x + y + z

            f = LoggedFunction(logger)(f)

            f(1, 2)
            f(x=3, y=4)
            f(5, y=6, z=7)

    unittest.main()

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:38:27.044888
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    class FakeLogger:
        def __init__(self):
            pass

        def debug(self, message):
            print(message)

    def fake_func(a, b, c=None):
        return 1

    logger = FakeLogger()
    deco = LoggedFunction(logger)
    func = deco(fake_func)
    func(2, 3, c=4)
    func(b=3, c=4, a=2)

# Generated at 2022-06-12 06:38:33.411510
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import get
    from requests.exceptions import HTTPError
    session = build_requests_session(raise_for_status=True)
    try:
        session.get("https://api.nasa.gov/planetary/apod")
    except HTTPError as e:
        print(e)

    session = build_requests_session(raise_for_status=False, retry=True)
    try:
        session.get("https://api.nasa.gov/planetary/apod")
    except HTTPError as e:
        print(e)

    session = build_requests_session(raise_for_status=False, retry=3)
    try:
        session.get("https://api.nasa.gov/planetary/apod")
    except HTTPError as e:
        print(e)

# Generated at 2022-06-12 06:38:40.176765
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    logging.basicConfig(level=logging.DEBUG)
    log_capture_string = io.StringIO()

    def func_test(*args, **kwargs):
        return 1

    decorated = LoggedFunction(logging.getLogger("__main__"))(func_test)
    decorated()

    # Asserts
    log_capture_string.seek(0)
    assert log_capture_string.read() == "__main__ DEBUG func_test()\n"

# Generated at 2022-06-12 06:38:49.652747
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    from contextlib import redirect_stdout

    from test_log_utils import DummyLogger

    def test_func(*args, **kwargs):
        return 42

    test_logger = DummyLogger()
    decorated_test_func = LoggedFunction(test_logger)(test_func)

    with io.StringIO() as buf, redirect_stdout(buf):
        result = decorated_test_func(1, 2, 3, a=4, b=5, c=6)
        output = buf.getvalue()
    expected_output = f"{test_func.__name__}(1, 2, 3, a=4, b=5, c=6)\n"
    assert output == expected_output

    assert result == 42
    assert test_logger.mess

# Generated at 2022-06-12 06:39:19.608674
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock
    from collections import namedtuple

    this_module = sys.modules[__name__]
    # create mock of logger
    mock_logger = mock.MagicMock()
    decorated_name = "_decorated"
    decorator = LoggedFunction(mock_logger)

    # create mock of decorated function
    decorated_function = mock.MagicMock(name=decorated_name)
    setattr(this_module, decorated_name, decorated_function)

    # create mock of return value
    mock_return_value = mock.MagicMock()
    decorated_function.return_value = mock_return_value

    # apply __call__ (decorate)
    logged_function = decorator.__call__(decorated_function)

    # test with normal args and kwargs
   

# Generated at 2022-06-12 06:39:29.207409
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.output = []

        def debug(self, msg):
            self.output.append(msg)

    logger = FakeLogger()
    lgf = LoggedFunction(logger)
    def test_func(a=3, b=2, c=1):
        return a + b + c
    logged_func = lgf(test_func)

    logged_func(1)
    assert logger.output == ["test_func(1)", "test_func -> 4"]

    # Reset logger
    logger.output = []

    logged_func(1, b=4)
    assert logger.output == ["test_func(1, b=4)", "test_func -> 6"]

    # Reset logger
    logger.output = []


# Generated at 2022-06-12 06:39:38.118267
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def x(a, b, c=3):
        return a + b + c

    assert x(1, 2) == 6
    assert x(1, 2, 3) == 6
    assert x(1, 2, c=3) == 6


if __name__ == '__main__':
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:39:39.930001
# Unit test for function build_requests_session
def test_build_requests_session():
    requests.Session = build_requests_session


test_build_requests_session()

# Generated at 2022-06-12 06:39:50.867249
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import tempfile

    logger = logging.getLogger(__name__)
    hdlr = logging.FileHandler(tempfile.gettempdir() + "/test___call__.log")
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test_function(a, b, c):
        return a + b + c

    test_function(1, 2, 3)
    with open(tempfile.gettempdir() + "/test___call__.log") as f:
        content = f.read()

# Generated at 2022-06-12 06:39:53.237189
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def f(a, b):
        return a+b
    from loguru import logger
    logger = logger.bind(name='LoggedFunction')
    f = LoggedFunction(logger)(f)
    f(1,2)

# Generated at 2022-06-12 06:40:04.353257
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import logging.handlers
    from tempfile import NamedTemporaryFile
    from io import StringIO
    from sys import stdout
    from contextlib import contextmanager

    # Setup logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler(stdout)
    stream_handler.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)

    # Setup temp file
    temp_file = NamedTemporaryFile(mode="w", delete=False)
    file_handler = logging.FileHandler(temp_file.name)
    file_handler.setLevel(logging.DEBUG)
    logger.addHandler(file_handler)

    # Add test cases

# Generated at 2022-06-12 06:40:13.331816
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging

    class MockLogger:
        def __init__(self):
            self.logged_things = {}

        def __getattr__(self, name):
            return MockLoggerMethod(name, self.logged_things)

    class MockLoggerMethod:
        def __init__(self, name, logged_things):
            self.name = name
            self.logged_things = logged_things

        def __call__(self, *args, **kwargs):
            if self.name not in self.logged_things:
                self.logged_things[self.name] = []

# Generated at 2022-06-12 06:40:22.249052
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():  # pylint: disable=C0103
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)

        def test_no_args(self):
            @LoggedFunction(self.logger)
            def foo():
                return "bar"

            self.assertEqual(foo(), "bar")

        def test_args(self):
            @LoggedFunction(self.logger)
            def foo(first, second):
                return f"{first}{second}"

            self.assertEqual

# Generated at 2022-06-12 06:40:29.930095
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import os

    # Use file here to test the method.
    if os.path.exists("temp.txt"):
        os.remove("temp.txt")

    @LoggedFunction(logger=logging.getLogger("logged"))
    def f(a, b, c=3, d=4):
        with open("temp.txt", "w") as f:
            f.write("")

    f(1, 2, d=5)

    if os.path.exists("temp.txt"):
        os.remove("temp.txt")


# Generated at 2022-06-12 06:41:16.366283
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    
    import logging

    # Initialise logger with debug output
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create a LoggedFunction which will add debug logging to the following function
    @LoggedFunction(logger)
    def test_function(a: int, b: int) -> int:
        return a + b

    # Call the function with some arguments
    test_function(1, 2)



# Generated at 2022-06-12 06:41:22.244288
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.logs = []

        def debug(self, message):
            self.logs.append(message)

    def test_func(x, y=1, **kwargs):
        raise NotImplementedError()

    logger = MockLogger()
    logged_test_func = LoggedFunction(logger)(test_func)
    logged_test_func(1)
    assert logger.logs[0] == "test_func(1, y=1)"
    logged_test_func(1, y=2)
    assert logger.logs[1] == "test_func(1, y=2)"
    logged_test_func(1, y=2, z=3)

# Generated at 2022-06-12 06:41:26.255234
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    session.get("http://httpbin.org/status/200")
    session.get("http://httpbin.org/status/404")

if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-12 06:41:32.942933
# Unit test for function build_requests_session

# Generated at 2022-06-12 06:41:37.107087
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    c = LoggedFunction(logger = None)
    @c
    def test(a, b, c=0):
        return a + b + c
    assert test(1, 2, c=3) == 6
    
    

# Generated at 2022-06-12 06:41:45.918654
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    from unittest.mock import MagicMock

    class TestCase(unittest.TestCase):
        def test_call_function(self):
            logger = MagicMock()
            logged_function = LoggedFunction(logger)

            @logged_function
            def test_function():
                return "function_output"

            # Call function
            test_function()

            # Check output
            self.assertEqual(
                logger.method_calls,
                [
                    ("debug", ("test_function()",), {}),
                    ("debug", ("test_function -> function_output",), {}),
                ],
            )

    unittest.main(argv=[__file__])

# Generated at 2022-06-12 06:41:54.140111
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import Session
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    session = build_requests_session()
    assert type(session) == Session
    for protocol in ['http://', 'https://']:
        assert type(session.adapters[protocol]) == HTTPAdapter
        retry_obj = session.adapters[protocol].max_retries.get_backoff_time()
        assert type(retry_obj) == Retry

    retry = Retry(total=10, method_whitelist=['GET', 'POST'])
    session = build_requests_session(retry=retry)
    assert type(session) == Session

# Generated at 2022-06-12 06:42:05.130310
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock
    from . import mock_logger
    func_name = "func_name"
    args = ["arg1", "arg2"]
    kwargs = {"kwarg1": "foo"}
    logger = mock_logger.MockLogger()
    func = mock.Mock()
    func.__name__ = func_name
    dec = LoggedFunction(logger)
    func = dec(func)
    func(*args, **kwargs)
    logger.debug.assert_called_once_with(
        f"{func_name}({', '.join([format_arg(x) for x in args])}{', '.join([f'{k}={format_arg(v)}' for k, v in kwargs.items()])})"
    )
    assert func.called
    assert logger

# Generated at 2022-06-12 06:42:15.333874
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)

    logger = logging.getLogger("test")

    logfun = LoggedFunction(logger)

    def f(a, b=2, c=4):
        return a + b + c

    func = logfun(f)

    assert func(1, 2) == 6
    assert func(1, c=4) == 6
    assert func(1) == 6
    assert func(1, 2, 3) == 6
    assert func(1, b=3) == 6
    assert func(1, b="3") == 6
    assert func(1, b="3", c="2") == 6

    logger.info("test_LoggedFunction___call__ ends")



# Generated at 2022-06-12 06:42:23.573597
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    class MockLogger:

        def __init__(self):
            self.log = []

        def debug(self, msg):
            self.log.append(msg)

    @LoggedFunction(logger=MockLogger())
    def test_function(a, b, c=3, d=4):
        pass

    test_function(1, 2, 5)
    test_function(1, 2)

    # Test function_name, args and kwargs of the log
    assert MockLogger.log[0] == "test_function(1, 2, 5, d=4)"
    assert MockLogger.log[1] == "test_function(1, 2, c=3, d=4)"