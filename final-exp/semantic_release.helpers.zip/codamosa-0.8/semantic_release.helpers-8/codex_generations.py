

# Generated at 2022-06-12 06:32:44.619058
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        build_requests_session(retry=None)
    except ValueError as e:
        print(e)



# Generated at 2022-06-12 06:32:54.407550
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import create_autospec, Mock

    from requests import Session

    from common.logging import Logger
    from webapp.session_factory import RequestsSession

    logger = Mock(spec=Logger)
    logged_func = LoggedFunction(logger=logger).__call__(func=Mock())
    logged_func(1, foo=2)
    logged_func(3)
    logged_func(4, 5, bar=6)
    logger.debug.assert_called_once_with("<unnamed>((1, 'foo', 2), (3,), (4, 5, 'bar', 6))")
    logger.reset_mock()

# Generated at 2022-06-12 06:33:03.965282
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError

    # Raise for status is true
    session = build_requests_session()
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

    # Raise for status is false
    session = build_requests_session(False)
    assert session.hooks == {}

    # Raise for status is true, retry is false
    session = build_requests_session(True, False)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

    # Raise for status is true, retry is integer
    session = build_requests_session(True, 3)

# Generated at 2022-06-12 06:33:13.880728
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    lf = LoggedFunction(logger)

    # Function without return value
    def func_a(arg1, arg2):
        assert arg1 == "test1"
        assert arg2 == "test2"
        return None

    # Function with return value
    def func_b(arg1, arg2):
        assert arg1 == "test1"
        assert arg2 == "test2"
        return "test3"

    # Testing function without return value
    logged_func_a = lf(func_a)
    result = logged_func_a("test1", "test2")
    assert result is None

    # Testing function with return value
    logged_func_b = lf(func_b)

# Generated at 2022-06-12 06:33:21.344007
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    def add(x, y):
        return x + y

    logger = logging.getLogger("test_logger")
    handler = logging.StreamHandler(stream=io.StringIO())
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    decorated = LoggedFunction(logger)(add)
    actual = decorated(1, 2)
    expected = 3
    assert actual == expected


# Generated at 2022-06-12 06:33:32.723833
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger = logging.getLogger('test')
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    decorator = LoggedFunction(logger=logger)

    @decorator
    def test_func(arg1, arg2, kwarg1=10, kwarg2=20):
        return arg1 + arg2 + kwarg1 + kwarg2

    assert test_func(1, 2, kwarg1=3, kwarg2=4) == 10
    assert stream.getvalue() == "test_func(1, 2, kwarg1=3, kwarg2=4)\ntest_func -> 10\n"

# Generated at 2022-06-12 06:33:41.917110
# Unit test for function build_requests_session
def test_build_requests_session():
    session1 = build_requests_session()
    assert isinstance(session1, Session)

    session2 = build_requests_session(raise_for_status=False)
    assert isinstance(session2, Session)

    session3 = build_requests_session(retry=False)
    assert isinstance(session3, Session)

    session4 = build_requests_session(retry=1)
    assert isinstance(session4, Session)

    retry = Retry()
    session5 = build_requests_session(retry=retry)
    assert isinstance(session5, Session)

    with pytest.raises(ValueError):
        build_requests_session(retry=object())

# Generated at 2022-06-12 06:33:43.049735
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-12 06:33:52.265134
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function(self):
            logger = logging.getLogger("test")
            # Make the logger log everything
            logger.setLevel(logging.DEBUG)
            # Capture logs in StringIo
            import io
            capture = io.StringIO()
            logger.addHandler(logging.StreamHandler(capture))

            @LoggedFunction(logger)
            def sum(x, y):
                return x + y

            # Test logging
            x = 3
            y = 4
            sum(x, y)
            self.assertEqual(
                capture.getvalue(), f"sum({x}, {y})\nsum -> {x + y}\n"
            )

            # Test logging with keyword

# Generated at 2022-06-12 06:33:57.968310
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging

    class MockLogger:
        def __init__(self, logger_name):
            pass

        def debug(self, message):
            print(message)

    class Test(unittest.TestCase):
        logger = MockLogger("MockLogger")
        lf = LoggedFunction(logger)

        def test_regular(self):
            def f(arg1, arg2, *, kwarg1, kwarg2=5):
                return arg1 * arg2

            lf = self.lf(f)
            lf_result = lf(2, 3, kwarg1="4")
            self.assertEqual(lf_result, 6)

        def test_0_args(self):
            def f():
                return "0 args"


# Generated at 2022-06-12 06:34:02.608849
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None, "session object should not be none"

# Generated at 2022-06-12 06:34:09.034003
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=2)
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert isinstance(session.adapters["https://"], HTTPAdapter)
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)
    assert session.adapters["http://"].max_retries.total == 2
    assert session.adapters["https://"].max_retries.total == 2

# Generated at 2022-06-12 06:34:16.154466
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger

    from unittest.mock import patch

    with patch("logging.Logger.debug") as mock_logger_debug:
        def test_function(a, b=1, c=2):
            return a + b + c

        logger = getLogger("my_logger")
        logged_function = LoggedFunction(logger)
        logged_test = logged_function(test_function)

        logged_test(1)
        assert mock_logger_debug.call_count == 2
        assert mock_logger_debug.mock_calls[0][1][0] == "test_function(1)"
        assert mock_logger_debug.mock_calls[1][1][0] == "test_function -> 4"


# Generated at 2022-06-12 06:34:26.547986
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import sys
    import unittest.mock as mock
    from logging import Logger

    class Logger:
        """
        Logger to capture logging calls.
        """

        def __init__(self):
            self.messages = []

        def debug(self, *messages):
            self.messages.extend(messages)

    # Create logger
    logger = Logger()

    # Create dummy function
    def func(arg1, arg2=2, arg3=3):
        return arg1 + arg2 + arg3

    # Wrap and call dummy function
    logged_func = LoggedFunction(logger)(func)
    result = logged_func(1, arg3=4)

    # Check logging messages

# Generated at 2022-06-12 06:34:36.658553
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    mock_logger = Mock()
    lfunc = LoggedFunction(mock_logger)

    def test_func(a, b=1):
        return a + b

    wrapped_func = lfunc(test_func)
    assert (
        wrapped_func.__name__ == test_func.__name__
    ), "after wrapping, the func's name should be preserved"
    assert (
        wrapped_func.__doc__ == test_func.__doc__
    ), "after wrapping, the func's doc should be preserved"

    wrapped_func(1)
    mock_logger.debug.assert_called_once_with("test_func(1, b=1)")

# Generated at 2022-06-12 06:34:49.217948
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test case which checks the output of the __call__ method.
    """
    # Define a logger which just records all calls
    logger = MyLogger()

    # Define a function which we can decorate
    def my_func(arg1, arg2, kwarg1="hello", kwarg2="world"):
        return 42

    # Decorate and call the function
    logged_func = LoggedFunction(logger)(my_func)
    result = logged_func(1, 2)

    # Check that output matches expected value
    assert result == 42
    assert logger.calls == [
        "my_func(1, 2, kwarg1='hello', kwarg2='world')",
        "my_func -> 42",
    ]


# Class which records all calls to its debug method

# Generated at 2022-06-12 06:34:52.090315
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__(): 
    ls = ["debug", "error", "info"]
    
    # TODO: This is a stub.
    if True:
        raise NotImplementedError()



# Generated at 2022-06-12 06:35:02.957977
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import logging
    import warnings

    # Create a logger that logs to an IOBuffer
    log_buffer = io.StringIO()
    log_handler = logging.StreamHandler(stream=log_buffer)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(log_handler)

    logged_func = LoggedFunction(logger)(test_func)

    # Logging happens
    logged_func(1, 2, keyword_arg=True)
    assert "test_func(1, 2, keyword_arg=True)" in log_buffer.getvalue()
    assert "test_func -> 3" in log_buffer.getvalue()

    # Non-logging happens
    assert logged_func(1, 2, keyword_arg=True) == 3



# Generated at 2022-06-12 06:35:13.758694
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import sys
    import io

    logger = logging.getLogger()
    logger.level = logging.DEBUG

    # capture stdout
    out = io.StringIO()
    sys.stdout = out

    # Test with a simple function
    @LoggedFunction(logger)
    def _test_func_1(a, b, c=3):
        return "test"

    _test_func_1(1, 2)
    # Assert stdout content is
    # test_func_1(1, 2, c=3)
    # test_func_1 -> test
    assert out.getvalue().strip() == "test_func_1(1, 2, c=3)\n_test_func_1 -> test"

    # Test with a function returning None

# Generated at 2022-06-12 06:35:21.164943
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    def test_func(a=3, b=4, *args, **kwargs):
        logger.info("Function body")

    test_func = LoggedFunction(logger)(test_func)
    test_func(2, 3)
    test_func(a=2, b=3)
    test_func(1, 2, 3)
    test_func(1, 2)
    test_func(d="foo", c="bar", b=3, a=5)

# Generated at 2022-06-12 06:35:33.698808
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def foo(a):
        return "aaa"
    log = logging.getLogger("foo")
    log.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setFormatter(logging.Formatter("%(message)s"))
    log.addHandler(handler)

    bar = LoggedFunction(log)(foo)
    bar(10)
    bar(a=10)
    bar(a="s")



# Generated at 2022-06-12 06:35:40.197044
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    x = 5
    def simple_function(x):
        return x**2
    logger = logging.getLogger("LoggedFunction")
    log_func = LoggedFunction(logger)
    func = log_func(simple_function)
    assert func(x) == simple_function(x)
    assert simple_function.__name__ == func.__name__

# Generated at 2022-06-12 06:35:47.137546
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert hasattr(session, "mount")
    session = build_requests_session(False)
    assert hasattr(session, "mount")
    session = build_requests_session(retry=False)
    assert hasattr(session, "mount")
    session = build_requests_session(retry=2)
    assert hasattr(session, "mount")
    from requests.packages.urllib3.util.retry import Retry
    retry = Retry()
    session = build_requests_session(retry=retry)
    assert hasattr(session, "mount")
    session = build_requests_session(True)
    assert hasattr(session, "hooks")
    session = build_requests_session(True, False)
    assert hasattr

# Generated at 2022-06-12 06:35:51.237022
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    try:
        import pytest
    except ImportError:
        raise ImportError("Missing pytest package")

    @LoggedFunction(logger=logging.getLogger("my_logger"))
    def test_function():
        return 0
    with pytest.raises(RuntimeError):
        test_function(1)

# Generated at 2022-06-12 06:35:55.944451
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger('test logger')
    @LoggedFunction(logger)
    def my_test_function(a, b):
        return a + b
    my_test_function(1, 2)
    my_test_function(a=1, b=2)

# Generated at 2022-06-12 06:36:07.387262
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError
    from requests.models import Response
    import unittest
    import os

    class TestCase(unittest.TestCase):
        # This doesn't need to be a real URL, since we are using a fake adapter.
        url = "http://www.example.com"

        def test_response(self):
            with self.subTest("raise_for_status=True"):
                session = build_requests_session(raise_for_status=True)
                with self.assertRaises(HTTPError):
                    session.request("GET", self.url)
            with self.subTest("raise_for_status=False"):
                session = build_requests_session(raise_for_status=False)
                response = session.request("GET", self.url)
                self.assertIs

# Generated at 2022-06-12 06:36:16.348197
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestClass():
        """Test Class

        Test class to run functions with LoggedFunction decorator.
        test_class_func_with_params, test_class_func_without_params,
        test_class_func_with_params_and_return,
        test_class_func_without_params_and_return are the functions
        run with LoggedFunction decorator.
        """

        def test_class_func_with_params(self, arg1, arg2, kwarg1, kwarg2):
            """Test function

            Run test_class_func_with_params with LoggedFunction decorator.
            Returns None.
            """

        def test_class_func_without_params(self):
            """Test function

            Run test_class_func_without_params with LoggedFunction decorator.
            Returns None.
            """

# Generated at 2022-06-12 06:36:23.097749
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.message = None

        def debug(self, msg):
            self.message = msg

    def func(*args, **kwargs):
        pass

    logger = Logger()
    logged_function = LoggedFunction(logger)
    result = logged_function(func)
    result(1, 2, 3)
    assert logger.message == "func(1, 2, 3)"


# Generated at 2022-06-12 06:36:32.028126
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.disabled = True

    l = LoggedFunction(logger)
    def func(a,b,c=12,d=14):
        return None
    logged_func = l(func)
    assert logged_func(1,2) == None
    assert logged_func([1,2,3], {'a':0, 'b':1}) == None
    assert logged_func(1.1,2,3.3,d=3.3) == None

    handler = logging.StreamHandler()
    logger.addHandler(handler)

# Generated at 2022-06-12 06:36:33.402074
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLo

# Generated at 2022-06-12 06:36:50.605349
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    from logging.handlers import SysLogHandler

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(name)s: %(message)s")
    handler = SysLogHandler(address = '/dev/log')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    class X(unittest.TestCase):
        @LoggedFunction(logger)
        def f(self, arg1, arg2):
            return arg1 + arg2

    x = X()
    assert x.f(3, 4) == 7



# Generated at 2022-06-12 06:36:58.472083
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup
    from logging import getLogger, WARN
    from logging import StreamHandler
    from io import StringIO
    import sys

    # Capture stdout
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    logger = getLogger("LoggedFunction")
    logger.setLevel(WARN)
    logger.addHandler(StreamHandler(sys.stdout))

    # Test
    logged_func = LoggedFunction(logger)(lambda a, b, c=None: None)
    result = logged_func(1, 2, 3)

    # Asserts
    assert result is None
    assert mystdout.getvalue().strip() == "logged_func(1, 2, c=3)"

# Generated at 2022-06-12 06:37:08.766293
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """Unit test for method __call__ of class LoggedFunction"""

    def func(*args, **kwargs):
        return 1

    @LoggedFunction(logger=None)
    def foo(*args, **kwargs):
        return 1

    assert foo() == 1
    assert foo(2) == 1
    assert foo(2, 3) == 1
    assert foo(2, 3, 4) == 1
    assert foo(2, a=3) == 1
    assert foo(2, 3, a=4) == 1
    assert foo(2, 3, 4, a=5) == 1
    assert foo(2, a=3, b=4) == 1
    assert foo(2, 3, a=4, b=5) == 1
    assert foo(2, 3, 4, a=5, b=6) == 1


# Generated at 2022-06-12 06:37:16.307283
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from datetime import datetime
    from unittest.mock import Mock
    from unittest.mock import patch

    def foo():
        pass
    def bar(a, b):
        pass
    def baz(a, b, **kwargs):
        pass

    mock_logger = Mock()
    decorator = LoggedFunction(mock_logger)

    decorated_func = decorator(foo)
    decorated_func()
    mock_logger.debug.assert_called_once_with("foo()")

    mock_logger.reset_mock()
    decorated_func = decorator(bar)
    decorated_func(1, 2)
    mock_logger.debug.assert_called_once_with("bar(1, '2')")

    mock_logger.reset_mock()
    decorated

# Generated at 2022-06-12 06:37:23.160774
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def say_hello(name):
        return 'Hello ' + name

    def say_hello_to_other_person(name, other_person):
        return other_person + ' says hello to ' + name

    class TestLogger:
        def debug(self, message):
            print(message)

    @LoggedFunction(TestLogger())
    def test_function(test_str):
        return test_str

    test_function('test str')



# Generated at 2022-06-12 06:37:29.902627
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.history = []

        def debug(self, message):
            self.history.append(message)

    @LoggedFunction(MockLogger())
    def my_func(a, b, c=1):
        return a + b + c

    assert len(my_func.__wrapped__.__wrapped__.__globals__) == 0
    assert my_func.__wrapped__.__wrapped__.__code__.co_argcount == 4
    assert my_func(1, 2, 3) == 6
    assert my_func(1, 2) == 4
    assert my_func(1) == 2

# Generated at 2022-06-12 06:37:30.881153
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(False) != None

# Generated at 2022-06-12 06:37:40.315985
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def debug(self, content):
            print(content)

    logger = MockLogger()

    @LoggedFunction(logger)
    def test_none_result(a, b=3, c=None):
        print(a, b, c)
        return None

    test_none_result(1)
    # expected output:
    # test_none_result(1, b=3, c=None)
    # 1 3 None

    @LoggedFunction(logger)
    def test_nonnone_result(a, b, c=None):
        print(a, b, c)
        return 2

    test_nonnone_result(1, 2, 3)
    # expected output:
    # test_nonnone_result(1, 2, c=3)
    # 1 2

# Generated at 2022-06-12 06:37:48.451394
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def test_func(a, b):
        return int(a) + int(b)

    test_func('2', 3)

# Generated at 2022-06-12 06:37:48.779956
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass



# Generated at 2022-06-12 06:38:13.271789
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    LoggedFunction.__call__() Test:
    """

    class FakeLogger:
        @LoggedFunction(logger=None)
        def logged_function(self, name: str, age: int, weight: float) -> bytes:
            return name.encode("utf-8")

        def debug(self, msg: str):
            self.log_msg = msg

    fake_logger = FakeLogger()

    fake_logger.logged_function("Kevin", 26, 68.5)

    assert fake_logger.log_msg == "logged_function('Kevin', 26, weight=68.5)"



# Generated at 2022-06-12 06:38:24.012206
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    logger = logging.Logger("test_logger")
    logger.setLevel(logging.DEBUG)
    string_io = io.StringIO()
    handler = logging.StreamHandler(string_io)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    loggedFunction = LoggedFunction(logger)
    def test_func(x, y, *args, k = 0, **kwargs):
        pass
    logged_func = loggedFunction(test_func)
    logged_func(10, 20, a=1, b=2, c=3)
   

# Generated at 2022-06-12 06:38:29.337165
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session
    assert type(build_requests_session(raise_for_status=False)) == Session
    assert type(build_requests_session(retry=False)) == Session
    assert type(build_requests_session(retry=3)) == Session
    assert type(build_requests_session(retry=Retry())) == Session
    try:
        build_requests_session(retry="3")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-12 06:38:40.174690
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import tempfile
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_log_output(logger):
        """
        A context manager to capture the output of a logger

        :param logger: The logger to capture the output of
        """
        out = StringIO()
        hdlr = logging.StreamHandler(out)
        logger.addHandler(hdlr)
        try:
            yield out
        finally:
            logger.removeHandler(hdlr)

    def logged_func(*args, **kwargs):
        return 1

    with tempfile.TemporaryDirectory() as tempdir:
        log_file = os.path.join(tempdir, "test.log")
        logger = logging.getLogger("test")
        logger.setLevel(logging.DEBUG)


# Generated at 2022-06-12 06:38:45.873359
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
    logger = logging.getLogger("LoggedFunction")

    a = 1
    b = 2
    c = 3

    @LoggedFunction(logger=logger)
    def test(a, b, c):
        """
        test for LoggedFunction
        """
        return a + b + c

    assert test(a, b, c) == 6

# Generated at 2022-06-12 06:38:53.048663
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Monkey-patch logger to write to string buffer
    logger = logging.getLogger(__name__)
    stream = io.StringIO()
    logger.addHandler(logging.StreamHandler(stream))
    logger.setLevel(logging.DEBUG)

    # Define test function
    @LoggedFunction(logger)
    def test_function(x, y="two"):
        return x + y

    # Run test
    assert test_function(1, y=2) == "12"
    assert stream.getvalue() == "test_function(1, y=2)\ntest_function -> 12\n"



# Generated at 2022-06-12 06:38:59.896083
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # PREPARE
    class LoggerMock:
        def __init__(self):
            self.logs = []
        def debug(self, message):
            self.logs.append(message)

    logger = LoggerMock()
    decorated_function = LoggedFunction(logger)

    # RUN
    @decorated_function
    def f1(a1):
        return a1

    # ASSERT
    assert f1('a') == 'a'
    assert logger.logs == [
        "f1('a')",
        "f1 -> a"
    ]

# Generated at 2022-06-12 06:39:05.735757
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        def __init__(self):
            self.result = None
        
        def debug(self, content):
            self.result = content
            
    @LoggedFunction(TestLogger())
    def test_function(n):
        return n
    
    test_function(1)
    assert test_LoggedFunction___call__.__annotations__
    
    

# Generated at 2022-06-12 06:39:16.828065
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import pytest
    from contextlib import redirect_stdout, redirect_stderr
    result = "result"

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    log_fd = io.StringIO("")
    logger.addHandler(logging.StreamHandler(log_fd))

    @LoggedFunction(logger)
    def test_func(*args, **kwargs):
        return result

    with redirect_stdout(log_fd), redirect_stderr(log_fd):
        ret = test_func()
        assert ret == result
        assert "test_func() -> result" in log_fd.getvalue()
        ret = test_func("aaa", "bbb", "ccc")
        assert ret == result

# Generated at 2022-06-12 06:39:22.193144
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)

    def test_func(arg1, arg2, arg3):
        return

    wrapper = LoggedFunction(logger)
    decorator = wrapper(test_func)
    decorator(1, 2, arg3=3)


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:40:11.173988
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import string
    import random
    import logging
    from unittest.mock import MagicMock
    logger_name = "".join([random.choice(string.ascii_letters) for i in range(5)])
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(logger_name)
    logger_handler = MagicMock()
    logger.addHandler(logger_handler)
    decorator_test_value = random.randint(1, 100)
    @LoggedFunction(logger)
    def decorated_func(*args, **kwargs):
        return decorator_test_value
    decorated_func_result = decorated_func(1, 2, 3, kw1="val1", kw2="val2")
    assert decorated_func_result == decorator_

# Generated at 2022-06-12 06:40:22.029899
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from collections import namedtuple
    from unittest import mock
    from unittest.mock import call

    Annotated = namedtuple("Annotated", ("function", "function_name", "args"))

    @LoggedFunction(mock.Mock())
    def test(a, b, c=1, d=2):
        return a + b + c + d

    test(1, 2)
    assert Annotated(test, "test", "1, 2, c=1, d=2") == test.__annotations__["args"]
    test(a=0, b=1, c=2, d=3)
    assert Annotated(test, "test", "a=0, b=1, c=2, d=3") == test.__annotations__[
        "args"
    ]

# Generated at 2022-06-12 06:40:24.770707
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    a = "abc"
    b = 123
    r = LoggedFunction.__call__(func, a, b)
    assert r == a + str(b)


# Generated at 2022-06-12 06:40:34.322409
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from requests.exceptions import ConnectionError, RequestException
    from requests.models import Response

    def raise_connectionerror():
        raise ConnectionError()

    def raise_requestexception():
        raise RequestException()

    def return_five():
        return 5

    def raise_for_status(response: Response, *args, **kwargs):
        response.raise_for_status()

    session = build_requests_session(False)
    session.hooks = {"response": [raise_for_status]}
    session.get = raise_connectionerror

    with pytest.raises(ConnectionError):
        session.get("http://www.google.com")

    session.get = raise_requestexception
    with pytest.raises(RequestException):
        session.get("http://www.google.com")



# Generated at 2022-06-12 06:40:45.038272
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    func = LoggedFunction(logger=None)
    assert func(lambda arg1, arg2, arg3: None)(1, 2, 3)
    assert func(lambda arg1, arg2, arg3: None)(arg1=1, arg2=2, arg3=3)
    assert func(lambda arg1, arg2, arg3: None)(1, arg2=2, arg3=3)
    assert func(lambda arg1, arg2, arg3: None)(arg3=3, arg1=1, arg2=2)
    assert func(lambda arg1, arg2, arg3: None)(1, 2, arg3=3)
    assert func(lambda arg1: None)(1)
    assert func(lambda arg1: None)(arg1=1)
    assert func(lambda: None)()

# Generated at 2022-06-12 06:40:49.614364
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    logger = getLogger(__name__)
    logged_function = LoggedFunction(logger)
    logged_function.__call__(lambda s: print(s))("hello")
    logged_function.__call__(lambda s, n=2: print(s * n))("hello")
    logged_function.__call__(lambda n: print(n))(2)
    logged_function.__call__(lambda: print("hello"))()

# Generated at 2022-06-12 06:40:57.500215
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from io import StringIO

    log = Mock()
    log.handlers = [Mock()]
    logger = type(log)()
    logger.handlers = [
        type(log.handlers[0])()
    ]  # [(<Mock name='mock.handlers[0]'.stream.stream.getvalue()>,)]

    @LoggedFunction(logger)
    def foo(a, b, c="", d=1, *args, **kwargs):
        return

    foo(1, 2, 3, d=5)
    logger.debug.assert_called_with(
        "foo(1, 2, 3, d=5)"
    )  # (*args, **kwargs) are not logged

# Generated at 2022-06-12 06:41:08.538979
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import Response
    from requests.models import Request
    from unittest.mock import Mock, patch
    from requests_toolbelt.utils.dump import expect_header
    import logging
    import tempfile
    import os

    def return_raise_for_status(r, *args, **kwargs):
        r.raise_for_status()

    logger_name = "test.logger"
    with tempfile.TemporaryDirectory() as d:
        temp_file = os.path.join(d, "test.log")
        logging.basicConfig(filename=temp_file, filemode="w", level=logging.DEBUG)
        logger = logging.getLogger(logger_name)
        session1 = build_requests_session(raise_for_status=False, retry=False)
        session2 = build

# Generated at 2022-06-12 06:41:17.005395
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest, logging
    from unittest.mock import Mock
    from unittest.mock import patch

    with patch("logging.Logger.debug") as log_debug:
        with patch("logging.Logger.error") as log_error:
            logging_logger = logging.getLogger("logger_test")
            decorator = LoggedFunction(logging_logger)
            def test_func(str1, str2, str3):
                return "test_result"

            func_test = decorator(test_func)
            func_test("arg1", "arg2", str3="arg3")

            log_debug.assert_called_with(
                "test_func('arg1', 'arg2', str3='arg3')"
            )
            log_debug.assert_called_

# Generated at 2022-06-12 06:41:28.384508
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    log_stream = StringIO()  # Create stream for logging output
    logger = logging.getLogger("test")  # Create logger
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(log_stream))  # Log to stream

    # Define function to decorate
    @LoggedFunction(logger)
    def test_func(arg1, arg2, kwarg1=None, kwarg2="test"):
        return "test"

    # Call function with named arguments
    test_func(1, "test", kwarg2=None, kwarg1="test")

    # Assert that arguments are logged correctly