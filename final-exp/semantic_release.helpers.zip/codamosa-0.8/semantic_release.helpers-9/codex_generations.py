

# Generated at 2022-06-12 06:32:47.274896
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_function(arg1, arg2=1):
        return arg1 + arg2

    expected_outputs = [
        "test_function(1)",
        "test_function(1, arg2=2)",
        "test_function(1) -> 2",
        "test_function(1, arg2=2) -> 3",
    ]

    class Logger:
        outputs = []

        def debug(self, output):
            self.outputs.append(output)

    logger = Logger()
    wrapped_function = LoggedFunction(logger)(test_function)

    wrapped_function(1)
    assert logger.outputs == expected_outputs[:2]
    assert wrapped_function(1) == 2

    wrapped_function(1, arg2=2)
    assert logger.outputs == expected_outputs

# Generated at 2022-06-12 06:32:51.956460
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    logged_func = LoggedFunction(logger)(lambda x: x)
    logged_func("x", "y", z="z")

# Generated at 2022-06-12 06:32:56.987013
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Unit tests for LoggedFunction.__call__
    """
    logger = make_logger(__name__)
    log = LoggedFunction(logger)
    @log
    def f(a, b, c=1):
        return a+b+c
    assert f(1, 2, 3) == 6
    assert f(1,2) == 4

# Generated at 2022-06-12 06:33:05.533180
# Unit test for function build_requests_session
def test_build_requests_session():
    print("Starting test_build_requests_session")

    # default session should be return
    session = build_requests_session()
    assert session.hooks == {}
    assert hasattr(session.adapters["http://"].max_retries, "raise_on_status") == False

    # raise_for_status session should be returned
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {
        "response": [
            lambda r, *args, **kwargs: r.raise_for_status()
        ]
    }
    assert hasattr(session.adapters["http://"].max_retries, "raise_on_status") == False

    # retry session should be returned
    session = build_requests_session(retry=True)

# Generated at 2022-06-12 06:33:12.145157
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    logger = Logger()
    logged_func = LoggedFunction(logger)

    @logged_func
    def add(a, b):  # type: ignore
        return a + b

    add(1, 2)

    assert logger.logs == [
        "add(1, 2)",
        "add -> 3",
    ]

# Generated at 2022-06-12 06:33:17.233230
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)


    @LoggedFunction(logger)
    def testFunc(a, b = "hello", c = True):
        print("Hello world!")
        return "this is a returned string"


    testFunc(1, c = False)



# Generated at 2022-06-12 06:33:25.898266
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def debug(self, msg):
            print(msg)

    def test_func(a, b, c):
        pass

    logger = DummyLogger()
    logged_method = LoggedFunction(logger)(test_func)
    logged_method(1, 2, 3)
    logged_method(1, 2, c=3)
    logged_method(1, b=2, c=3)
    logged_method(a=1, b=2, c=3)
    # LoggedFunction(lambda msg: print(msg))(test_func)(1, 2, 3)
    # LoggedFunction(lambda msg: print(msg))(test_func)(1, 2, c=3)
    # LoggedFunction(lambda msg: print(msg))(test_func)(1, b=2, c=

# Generated at 2022-06-12 06:33:38.817927
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)
    assert isinstance(session, Session)
    assert session.hooks
    assert session.max_redirects
    assert session.mounts
    assert session.adapters

    session = build_requests_session(raise_for_status=False, retry=True)
    assert isinstance(session, Session)
    assert not session.hooks
    assert session.max_redirects
    assert session.mounts
    assert session.adapters

    session = build_requests_session(raise_for_status=True, retry=False)
    assert isinstance(session, Session)
    assert session.hooks
    assert session.max_redirects
    assert not session.mounts
    assert not session.adapters

   

# Generated at 2022-06-12 06:33:46.326978
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def debug(self, msg):
            self.msg = msg
    logger = FakeLogger()
    logged_func = LoggedFunction(logger)(lambda a, b: a + b)
    logged_func(5, 3)
    assert logger.msg == "logged_func(5, 3)"

    logger = FakeLogger()
    logged_func = LoggedFunction(logger)(lambda a, b:"hi")
    logged_func(5, 3)
    assert logger.msg == "logged_func -> hi"

    logger = FakeLogger()
    logged_func = LoggedFunction(logger)(lambda a, b, c=3, d=4:"hi")
    logged_func(5, 3)

# Generated at 2022-06-12 06:33:54.147077
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from mock import Mock
    from logging import DEBUG
    from .test_utils import get_logger
    logger = get_logger("testLoggedFunction", DEBUG)
    logger.debug = Mock()
    fun = LoggedFunction(logger)

    @fun
    def add(x, y):
        return x + y

    add(1, 2)
    logger.debug.assert_called_once()
    assert logger.debug.call_args[0][0] == "add(1, 2)"

    add(y=3, x=4)
    logger.debug.assert_any_call("add(4, y=3)")

    logger.debug.reset_mock()
    assert add(5, 6) == 11
    logger.debug.assert_any_call("add(5, 6)")

# Generated at 2022-06-12 06:34:04.202470
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # expected result
    expected_result = None

    # mock logger
    import logging
    import unittest.mock as mock
    logger = mock.MagicMock(spec=logging.Logger)

    # mock func
    func = mock.MagicMock()
    func.__name__ = "func"

    # invoke __call__
    logged_func = LoggedFunction(logger)(func)
    result = logged_func(0, 1, 2, a=3, b="4", c=5)

    # assert
    # check logger.debug
    logger.debug.assert_called_with(
        "func(0, 1, 2, a=3, c=5, b='4')"
    )
    logger.debug.assert_called_with("func -> None")
    # check result
    assert result == expected

# Generated at 2022-06-12 06:34:13.938669
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test 1
    lf = LoggedFunction("Logger")
    def test(x, y):
        return x + y
    assert lf(test)(1, 2) == 3
    # Test 2
    lf = LoggedFunction("Logger")
    def test(x, y):
        return x * y
    assert lf(test)(1, 2) == 2
    # Test 3
    lf = LoggedFunction("Logger")
    def test(x, y):
        return x / y
    assert lf(test)(1, 2) == 0.5
    # Test 4
    lf = LoggedFunction("Logger")
    def test(x, y):
        return x * x
    assert lf(test)(3, 4) == 9
    # Test 5
    lf = LoggedFunction("Logger")
   

# Generated at 2022-06-12 06:34:25.306847
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    class TestLogger:
        def __init__(self):
            self.outputs = []

        def debug(self, msg):
            self.outputs.append(msg)

    def test_func(*args, **kwargs):
        return "test"

    # Test normal case
    logger = TestLogger()
    lf = LoggedFunction(logger)
    test_func_decorated = lf(test_func)
    assert test_func_decorated(1, a=2, b=3) == "test"
    assert logger.outputs == [
        "test_func(1, a=2, b=3)",
        "test_func -> test",
    ]

    # Test if function returns None
    logger.outputs.clear()

# Generated at 2022-06-12 06:34:36.025318
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Testing of number format
    @LoggedFunction(logger=print)
    def logged_function_test(a: int = 3, b: int = 7, c: str = "hi"):
        return a + b
    assert logged_function_test(a=3, b=7, c="hi") == 10
    # Assertion of keywords
    assert logged_function_test(a=3, b=7) == 10
    # Assertion of position arguments
    assert logged_function_test(3, 7, "hi") == 10
    # Assertion of generic function without arguments
    assert logged_function_test() == 10


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:34:42.204217
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock

    logger = mock.MagicMock()

    @LoggedFunction(logger)
    def func(a, b, c=5, d: str = "test"):
        pass

    func(1, 2, 3, d="test")
    logger.debug.assert_called_once_with(
        "func(1, 2, 3, c=5, d='test')",
    )
    logger.reset_mock()

    func("hello", "world")
    logger.debug.assert_called_once_with("func('hello', 'world', c=5, d='test')")
    logger.reset_mock()

    func("hello", "world", d="foo")

# Generated at 2022-06-12 06:34:50.914257
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # See https://stackoverflow.com/questions/18262099/how-to-mock-a-python-class-method
    logger = Mock()
    target = LoggedFunction(logger)
    result = target(Mock())
    mocked_logger = Mock()
    result(mocked_logger)
    mocked_logger.debug.assert_called()
    mocked_logger.debug.assert_called_with('<MagicMock name=\'mock.__call__()\' id=\'140683429054752\'>(<MagicMock name=\'mock.__call__().logger\' id=\'140683435386624\'>)')


# Generated at 2022-06-12 06:35:02.044200
# Unit test for method __call__ of class LoggedFunction

# Generated at 2022-06-12 06:35:10.062230
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    callcount = 0

    class Logger:
        def debug(self, msg):
            nonlocal callcount
            assert msg == "func(1, 2, 3)" or msg == "func -> 4"
            callcount += 1

    logger = Logger()
    logged_func = LoggedFunction(logger)(func)
    logged_func(1, 2, 3)
    assert callcount == 2
    assert logged_func.__name__ == "func"



# Generated at 2022-06-12 06:35:20.132674
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)

    # Test 1:
    # Test normal case with no arguments
    @LoggedFunction(logger)
    def testFunction1():
        return 1

    assert testFunction1() == 1

    # Test 2:
    # Test case with only one integer argument
    @LoggedFunction(logger)
    def testFunction2(a):
        return a

    assert testFunction2(1) == 1

    # Test 3:
    # Test case with multiple arguments with different types
    @LoggedFunction(logger)
    def testFunction3(a, b, c, d):
        return a + b + c + d

    assert testFunction3(1, 2, '1', '2') == 6

# Generated at 2022-06-12 06:35:25.692844
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger("LoggedFunction")

    # input arguments
    func = "function name"
    args = ["a", "b", "c"]
    kwargs = {"d": "d", "e": "e"}

    @LoggedFunction(logger)
    def test(func, *args, **kwargs):
        return [func, args, kwargs]

    result = test(func, *args, **kwargs)

    assert result == [func, args, kwargs]
    for handler in logger.handlers:
        assert (handler.buffer[0] == f"{func}('a', 'b', 'c', d='d', e='e')")

# Generated at 2022-06-12 06:35:34.485188
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup
    class DummyLogger:
        def debug(self, msg):
            print(msg)

    # Call and check
    @LoggedFunction(DummyLogger())
    def test_function(a, b, c, d=1, e=2, **kwargs):
        return a + b + c + d + e + sum(kwargs.values())

    test_function(1, 2, 3, 4, 5, f=6, g=7)



# Generated at 2022-06-12 06:35:45.516132
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import os
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
    logger.addHandler(handler)

    fake_func = LoggedFunction(logger)

    @fake_func
    def calculate(a, b):
        return a + b

    calculate(1, 2)
    calculate(1, 2, 3)
    calculate(1,2, c=3, d=4)
    calculate(a=1, b=2)

# Generated at 2022-06-12 06:35:55.113278
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test")
    logging.basicConfig(level=logging.DEBUG)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test_func(arg1, arg2, kwarg1="test", kwarg2=9):
        return "result"

    assert test_func(1, 2, kwarg1=None) == "result"
    assert test_func(arg1=None, arg2=4, kwarg1="t", kwarg2=99).startswith(
        "test_func(None, 4, kwarg1='t', kwarg2=99) -> result"
    )

# Generated at 2022-06-12 06:36:06.014189
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    def mock_log(level, msg, *args, **kwargs):
        print(msg % args, **kwargs)

    logger = logging.getLogger("test")
    logger.log = mock_log
    logger.setLevel(logging.DEBUG)

    def test(a, b, c="test", d=5):
        return f"{a}-{b}-{c}-{d}"

    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        logged_test = LoggedFunction(logger)(test)
        value = logged_test(1, 2, d=4)
        assert value == "1-2-test-4"

# Generated at 2022-06-12 06:36:15.083022
# Unit test for function build_requests_session
def test_build_requests_session():
    retry_3 = Retry(
        total=3, status_forcelist=[408],
    )
    session_3 = build_requests_session(retry=retry_3)
    assert session_3.mounts['http://'][0].max_retries == retry_3
    session_true = build_requests_session(retry=True)
    assert session_true.mounts['http://'][0].max_retries.total == 10
    session_3 = build_requests_session(retry=3)
    assert session_3.mounts['http://'][0].max_retries.total == 3
    assert session_3.hooks['response'][0].raise_for_status() == None

# Generated at 2022-06-12 06:36:23.100129
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger('test_LoggedFunction')
    logger.setLevel(logging.DEBUG)
    # handler = logging.StreamHandler()
    # handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    # logger.addHandler(handler)

    @LoggedFunction(logger)
    def add(a, b):
        return a + b
    assert add(1, 2) == 3


# Generated at 2022-06-12 06:36:32.028293
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from functools import partial
    from unittest.mock import Mock

    func = Mock(return_value=1, __name__="test_func")
    logger = Mock()
    call = LoggedFunction(logger)

    # test no arg no return
    func.reset_mock()
    logger.reset_mock()
    func.side_effect = partial(func, return_value=None)
    logged_func = call(func)
    logged_func()
    func.assert_called_once_with()
    logger.debug.assert_called_once_with(
        "test_func()"
    )

    # test no arg
    func.reset_mock()
    logger.reset_mock()
    func.side_effect = partial(func, return_value=2)

# Generated at 2022-06-12 06:36:39.976948
# Unit test for function build_requests_session
def test_build_requests_session():
    # test for basic usage
    session = build_requests_session()
    assert session.hooks == {}
    for adapter in session.adapters.values():
        assert not adapter.max_retries

    # test for raise_for_status = False
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}

    # test for retry = False
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    for adapter in session.adapters.values():
        assert not adapter.max_retries

    # test for retry = int
    session = build_requests_session(retry=3)
    assert session.hooks == {}
    for adapter in session.adapters.values():
        assert adapter.max_retries

# Generated at 2022-06-12 06:36:49.456490
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False, False)
    assert isinstance(session, Session)
    session = build_requests_session(False, 0)
    assert isinstance(session, Session)
    session = build_requests_session(False, Retry())
    assert isinstance(session, Session)
    try:
        build_requests_session(False, 1.1)
    except ValueError as e:
        assert str(e) == "retry should be a bool, int or Retry instance."
    try:
        build_requests_session(False, False)
    except ValueError as e:
        assert str(e) == "retry should be a bool, int or Retry instance."


# Generated at 2022-06-12 06:36:58.293168
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import json
    import unittest
    from io import StringIO

    class LoggedFunctionTest(unittest.TestCase):
        def setUp(self):
            self.io = StringIO()

        def tearDown(self):
            self.io.close()

        def test_logged_func(self):
            def func(a, b, *args, d=None, **kwargs):
                return a + b

            logged_func = LoggedFunction(json)(func)

            result = logged_func(11, 22, d=33, e=44)
            self.assertEqual(result, 33)
            expected = json.dumps({"msg": "func(11, 22, d=33)"})
            self.assertEqual(self.io.getvalue().strip(), expected)

    # replace io with io.StringIO

# Generated at 2022-06-12 06:37:11.031309
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from unittest.mock import patch

    class Test(unittest.TestCase):
        def setUp(self) -> None:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)

        def test_no_return(self):
            def func(*args, **kwargs):
                pass

            with patch.object(self.logger, "debug") as mock_debug:
                logged_func = LoggedFunction(self.logger)(func)
                logged_func()
                mock_debug.assert_any_call(f"{func.__name__}")

        def test_return(self):
            def func(*args, **kwargs):
                return "value"


# Generated at 2022-06-12 06:37:20.164914
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock

    logger = MagicMock()
    function_decorator = LoggedFunction(logger)

    @functools.wraps(logged_func)
    def logged_func(x, y):
        return x + y

    assert logged_func(5, 2) == 7

    iter_logs = iter(logger.debug.call_args_list)
    assert next(iter_logs)[0] == ("{function}({args}{kwargs})".format(
        function="logged_func",
        args="5, 2",
        kwargs="",
    ),)
    assert next(iter_logs)[0] == ("{function} -> 7".format(
        function="logged_func",
    ),)

# Generated at 2022-06-12 06:37:28.791309
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from .simple_logger import SimpleLogger
    logger = SimpleLogger()
    logged_function = LoggedFunction(logger)

    # Define a function which will be logged
    @logged_function
    def do_nothing(a, b, c=3, d="foo", e=None, f=True):
        pass

    # We haven't called the function yet so there should be nothing in the log
    logger.assert_no_warning()
    logger.assert_no_info()
    logger.assert_no_debug()

    # Call the function
    do_nothing(1, 2, e=None, f=False)

    # The call to the function should have been logged

# Generated at 2022-06-12 06:37:38.957170
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # Create a logger
    log_stream = io.StringIO()
    handler = logging.StreamHandler(log_stream)
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Test
    def func1(a, b):
        return a + b

    def func2(name1, name2):
        return f"{name1} {name2}"

    def func3(name, **kwargs):
        return f"{name} {kwargs['city']} {kwargs['state']}"

    func1_logged = LoggedFunction(logger)(func1)
    func1_logged(1, 2)
    log_stream.seek(0)

# Generated at 2022-06-12 06:37:50.275939
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    def test_func(a, b, c=1, d=2, e=3):
        return 42

    func_id = id(test_func)
    fake_logger = FakeLogger()
    logged_func = LoggedFunction(fake_logger)(test_func)
    result = logged_func('a', 'b', e=None)

    assert fake_logger.logs == [
        f'test_func(a, b, c=1, d=2, e=None)',
        f'test_func -> 42',
    ]
    assert result == 42
    assert func_id == id(logged_func)



# Generated at 2022-06-12 06:37:58.950686
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    class _Test_Logger:
        def __init__(self):
            self._output = io.StringIO()
            self.level = logging.DEBUG
            self.name = None

        def debug(self, *args, **kargs):
            print(*args, file=self._output, **kargs)

        def getvalue(self):
            return self._output.getvalue()

    def test_LoggedFunction___call__():
        def test(arg1, arg2=2):
            return arg1 + arg2

        # Unit test for method __call__ of class LoggedFunction
        def test_LoggedFunction___call__():
            def test(arg1, arg2=2):
                return arg1 + arg2

            # Unit test for method __call__ of class LoggedFunction


# Generated at 2022-06-12 06:38:09.720815
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from contextlib import redirect_stdout
    from unittest.mock import Mock

    logger = logging.getLogger("LoggedFunctionTest")
    logger.setLevel(logging.DEBUG)

    lf = LoggedFunction(logger)
    f = Mock(return_value=1, __name__="f")

    # Call the logged function with no arguments
    g = lf(f)
    g()

    # Check log output
    log_output = StringIO()
    with redirect_stdout(log_output):
        for record in logger.handlers[0].buffer:
            print(record.getMessage())
    assert (
        log_output.getvalue()
        == """f()
f -> 1
"""
    ), log_output.getvalue()

    # Call

# Generated at 2022-06-12 06:38:21.802932
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from datetime import datetime
    from unittest import TestCase
    from unittest import mock
    from logging import DEBUG
    from logging import Formatter
    from logging import StreamHandler

    class TestFunc:
        def __init__(self):
            self.called = False
            self.value = None
            self.args = []
            self.kwargs = {}

        def __call__(self, *args, **kwargs):
            self.called = True
            self.args = args
            self.kwargs = kwargs
            return self.value

    # Set logger
    formatter = Formatter("%(message)s")
    logger = mock.Mock()
    handler = StreamHandler()
    handler.setFormatter(formatter)
    logger.handlers = [handler]

# Generated at 2022-06-12 06:38:26.221380
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging 
    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.DEBUG)

    def foo(bar: str, baz=None):
        return bar + ' ' + baz

    logged_foo = LoggedFunction(logger)(foo)
    logged_foo('bar', baz='baz')

# Generated at 2022-06-12 06:38:32.902168
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    logger = Mock()
    logged_function = LoggedFunction(logger)
    @logged_function
    def fun1(*args, **kwargs):
        return args, kwargs
    fun1(1, 2, 3, a=4, b=5, c=6)
    logged_call_args = logger.debug.call_args[0][0]
    assert logged_call_args == "fun1(1, 2, 3, a=4, b=5, c=6)"
    @logged_function
    def fun2():
        return 1
    assert fun2() == 1
    logged_call_args = logger.debug.call_args[0][0]
    assert logged_call_args == "fun2 -> 1"


# Generated at 2022-06-12 06:38:43.034663
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        build_requests_session(True, -1)
        assert False
    except ValueError:
        assert True

    try:
        build_requests_session(True, Retry(total=5, backoff_factor=0.1))
        assert True
    except ValueError:
        assert False

    try:
        build_requests_session(True, 3)
        assert True
    except ValueError:
        assert False

    try:
        build_requests_session(True, True)
        assert True
    except ValueError:
        assert False



# Generated at 2022-06-12 06:38:52.627426
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Decorator class LoggedFunction should have method __call__
    that adds debug logging to a function.
    """

    class Logger:
        def __init__(self):
            self.log = ""

        def debug(self, log):
            self.log += log

    def test_func(*args, **kwargs):
        pass

    logger = Logger()
    logged_func = LoggedFunction(logger)(test_func)

    logged_func(1, 3)
    assert logger.log == "test_func(1, 3)"

    logger.log = ""
    logged_func(1, x=3)
    assert logger.log == "test_func(1, x=3)"

    logger.log = ""
    logged_func(x=3)

# Generated at 2022-06-12 06:38:58.136114
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    from riptide_engine.execution.task import Task

    @LoggedFunction(unittest.mock.create_autospec(lambda: None))
    def wrapped(arg=None):
        print(arg)

    wrapped()
    wrapped("a")
    wrapped("a", "b")
    wrapped(arg="a")
    wrapped(arg="a", arg2="b")

# Generated at 2022-06-12 06:39:08.450122
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # set up a fake stream to capture output
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    logger = logging.getLogger("test")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    def test_fn(s: str, x: int = 1, y: float = 2.3, z: object = object()):
        "test function"
        return (x, y, z)

    # create test instance
    lf = LoggedFunction(logger)

    # test that calling it works
    result = lf(test_fn)("test", 2, z=4.5)
    assert result == (2, 2.3, 4.5)

    # test that the logging message is correct

# Generated at 2022-06-12 06:39:18.654889
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Prepare
    class TestClass:
        def __init__(self, logger):
            self.logger = logger
        @LoggedFunction(logger=logging.getLogger("test"))
        def test_func(self, arg1, arg2, arg3):
            return arg1+arg2+arg3
    test_a = TestClass(logger=logging.getLogger("test"))
    test_b = TestClass(logger=logging.getLogger("test"))
    test_b.logger.setLevel(logging.DEBUG)

    # Execute
    result_a = test_a.test_func(1,2,3)
    result_b = test_b.test_func(arg1=1, arg2=2, arg3=3)

    # Assert


# Generated at 2022-06-12 06:39:28.532956
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock
    from unittest.mock import sentinel
    from unittest.mock import Mock

    logger = mock.sentinel.logger

    mock_func = Mock(spec=["__name__"], return_value=sentinel.func_value)
    mock_func.__name__ = sentinel.func_name

    logged_func = LoggedFunction(logger)(mock_func)
    logged_func(sentinel.arg1, sentinel.arg2, kwarg1=sentinel.kwarg1, kwarg2=sentinel.kwarg2)
    mock_func.assert_called_once_with(sentinel.arg1, sentinel.arg2, kwarg1=sentinel.kwarg1, kwarg2=sentinel.kwarg2)

# Generated at 2022-06-12 06:39:40.029677
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock as mock

    class MockLogger:
        def debug(self, msg, *args, **kwargs):
            print(msg)

    def test_func_1(arg_1, arg_2=None, *args, **kwargs):
        return arg_1 + arg_2

    def test_func_2(arg_1, arg_2=None, *args, **kwargs):
        return arg_1 + arg_2

    # @LoggedFunction(logging.getLogger(__name__))
    @LoggedFunction(MockLogger())
    def test_func_3(arg_1, arg_2=None, *args, **kwargs):
        return arg_1 + arg_2


# Generated at 2022-06-12 06:39:50.865840
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.args = []
            self.kwargs = []

        def debug(self, *args, **kwargs):
            self.args = list(args)
            self.kwargs = dict(**kwargs)

    def f(a, b=2, *, c):
        pass

    logger = FakeLogger()
    @LoggedFunction(logger)
    def g(x, y=1, *, z):
        pass

    g(1, 2)
    assert logger.args[0] == "g(1, y=2)"
    g(1, 2, 3, 4, 5)
    assert logger.args[0] == "g(1, 2, 3, 4, 5)"

# Generated at 2022-06-12 06:39:56.751485
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    mock_logger = MockLogger()
    logged_func = LoggedFunction(mock_logger)

    def func(x, y, z=10, *args, **kwargs):
        return x * y + z

    logged_func(func)(1, 2)
    assert mock_logger.logs == ["func(1, 2)"]

    logged_func(func)(1, 2, 3)
    assert mock_logger.logs == ["func(1, 2)", "func(1, 2, z=3)"]

    logged_func(func)(1, 2, w=5, j=6)
    assert mock_logger

# Generated at 2022-06-12 06:40:07.337837
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    loggerMock = Mock(spec=logging.Logger)
    mockFunction = Mock(spec=lambda: None)

    testSubject = LoggedFunction(loggerMock)
    result = testSubject(mockFunction)

    result()
    mockFunction.assert_called_once()
    loggerMock.debug.assert_called_once()

    result.__name__ = "tester"
    result(1)
    mockFunction.assert_called_with(1)
    loggerMock.debug.assert_called_with("tester(1)")

    result(2, 3, 4)
    mockFunction.assert_called_with(2, 3, 4)
    loggerMock.debug.assert_called_with("tester(2, 3, 4)")


# Generated at 2022-06-12 06:40:22.032018
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # create a logger
    logger = logging.getLogger(name="test_logger")
    logger.setLevel(logging.DEBUG)

    # create the handler and add it to the logger
    handler = logging.FileHandler("test_logged_func.log")
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter(fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    )
    logger.addHandler(handler)

    # call the method to test
    f = LoggedFunction(logger=logger)

    def test_func(*args, **kwargs):
        return "test_func result"

    f(test_func)()



# Generated at 2022-06-12 06:40:30.780914
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def debug(self, message):
            print(message)

    f = LoggedFunction(DummyLogger())


    def test(a, *args, **kwargs):
        print("test function")
        return True


    g = f(test)

    assert g("hello") == True
    assert g("hello", "world", test="hi") == True


    def test2(a, b, *args, **kwargs):
        print("test2 function")
        return True


    g2 = f(test2)

    assert g2("hello", "world") == True
    assert g2("hello", "world", test="hi") == True

# Generated at 2022-06-12 06:40:38.018789
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class TestLoggingFunction(unittest.TestCase):
        def setUp(self):
            logging.basicConfig(level=logging.DEBUG)
            self.logger = logging.getLogger("TestLoggingFunction")
            self.logged_function = LoggedFunction(logger=self.logger)

        @unittest.mock.patch("logging.Logger.debug")
        def test_logging_function_with_two_args(self, mock_log_debug):
            self.logged_function(two_arg_func)("first", "second")
            mock_log_debug.assert_any_call(
                "two_arg_func('first', 'second')"
            )

# Generated at 2022-06-12 06:40:46.654727
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger
    from unittest.mock import patch
    from logging import DEBUG

    class Logger:
        def debug(self, msg):
            self.msg = msg

    logger = Logger()
    logged_function = LoggedFunction(logger)
    @logged_function
    def test_method(param1, param2='test'):
        return True

    test_method(1, "test2")
    assert logger.msg == "test_method(1, test2)"

    test_method(1, param2="test_param2")
    assert logger.msg == "test_method(1, param2=test_param2)"

# Generated at 2022-06-12 06:40:50.740463
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock

    logger = MagicMock()
    function_name = "add"
    logged_function = LoggedFunction(logger)
    logged_function.__call__(function_name)
    logger.debug.assert_called_with(f"{function_name}()")

# Generated at 2022-06-12 06:40:57.617560
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def f1(a, b):
        return a + b
    f2 = LoggedFunction()(f1)
    # Should work
    f2(1,2)
    # Should work
    f2(1,'2',)
    # Should work
    f2(a=1,b=2)
    # Should work
    f2('1','2',)
    # Should work
    f2(a='1',b='2',)
    # Should work
    f2(a='1',b=2)
    # Should work
    f2(1,b='2')
    # Should work

# Generated at 2022-06-12 06:40:58.248849
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-12 06:41:09.235838
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.log = ""

        def debug(self, msg):
            self.log += msg + "\n"

    logger = FakeLogger()
    dummy_decorator = LoggedFunction(logger)

    def dummy(a, b, c=None):
        pass

    # Test a simple call
    dummy_decorator(dummy)("a", "d")
    assert logger.log == "dummy('a', 'd')\n"

    # Test a function with many arguments
    logger.log = ""
    dummy_decorator(dummy)("a", "b", "c")
    assert logger.log == "dummy('a', 'b', 'c')\n"

    # Test a function with keyword arguments
    logger.log = ""
   

# Generated at 2022-06-12 06:41:17.478045
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)

    @LoggedFunction(logger=logging.getLogger(__name__))
    def func1(x):
        return x ** 2

    @LoggedFunction(logger=logging.getLogger(__name__))
    def func2(x, y):
        return x * y

    @LoggedFunction(logger=logging.getLogger(__name__))
    def func3(x, y, z):
        return x * y * z

    assert func1(1) == 1
    assert func1(2) == 4
    assert func2(2, 3) == 6
    assert func3(2, 3, 4) == 24


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:41:22.829822
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    import StringIO

    class LoggedFunction__call__Test(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger()
            self.log_stream = StringIO.StringIO()
            handler = logging.StreamHandler(self.log_stream)
            self.logger.addHandler(handler)

        def tearDown(self):
            self.logger.removeHandler(self.logger.handlers[0])

        def test_logged_func(self):
            logged_function = LoggedFunction(self.logger)

            @logged_function
            def my_func(a, b, c):
                return "result from my_func"

            my_func("a", "b", "c")

# Generated at 2022-06-12 06:41:45.624427
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest

    class DemoClass:
        def __init__(self, logger):
            pass
        @LoggedFunction(logger=None)
        def demo_func1(self, arg1, arg2):
            return 0
        @LoggedFunction(logger=None)
        def demo_func2(self):
            return None
        @LoggedFunction(logger=None)
        def demo_func3(self, arg1, kwarg1=2):
            return 0
        @LoggedFunction(logger=None)
        def demo_func4(self, arg1, kwarg1=None):
            return 0

    def test_case1():
        demo_obj = DemoClass(None)
        assert demo_obj.demo_func1(arg1=1, arg2=2) == 0

# Generated at 2022-06-12 06:41:48.981575
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def debug(self, msg):
            print(msg)

    @LoggedFunction(DummyLogger())
    def say_hello(args):
        print(args)
        return 'hello'

    say_hello('world')


# Generated at 2022-06-12 06:41:55.456435
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("LoggedFunction")
    # Use the below line to print the log to stdout.
    # logging.basicConfig(level=logging.DEBUG)


    def test_func(x, y=1, *args, **kwargs):
        return x + y + sum(args) + sum(kwargs.values())


    logged_func = LoggedFunction(logger)(test_func)

    assert logged_func(1) == 2
    assert logged_func(1, 2) == 4
    assert logged_func(1, y=2) == 4
    assert logged_func(1, 2, 3) == 6
    assert logged_func(1, 2, 3, z=10) == 16

# Generated at 2022-06-12 06:42:03.227635
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_logger = logging.getLogger("test")
    test_logger.addHandler(logging.NullHandler())
    logging.basicConfig(level=logging.DEBUG)
    test_logger.debug("test_LoggedFunction___call__ starts")
    @LoggedFunction(test_logger)
    def add(a, b):
        return a + b

    assert add(1, 3) == 4
    test_logger.debug("test_LoggedFunction___call__ ends")

# Generated at 2022-06-12 06:42:05.008608
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from repESP.logging import REPESPLogger

    logger = REPESPLogger.get_instance()

    @LoggedFunction(logger)
    def func(x):
        return 2 * x

    func(3)
    func(x=10)

# Generated at 2022-06-12 06:42:15.201317
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logging.basicConfig(level=logging.DEBUG)
    _buffer = StringIO()
    _handler = logging.StreamHandler(_buffer)
    _handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    _logger = logging.getLogger()
    _logger.addHandler(_handler)

    @LoggedFunction(_logger)
    def add(x, y):
        return x + y

    @LoggedFunction(_logger)
    def sub(x, y):
        return x - y

    assert add(1, 2) == 3
    assert sub(1, 2) == -1

    _buffer.seek(0)
    _lines = _buffer.readlines()
    assert len(_lines) == 4


# Generated at 2022-06-12 06:42:24.032051
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    def say_hello(name):
        return f"Hello {name}!"

    # Create a logger and a LoggedFunction decorator
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logged_func = LoggedFunction(logger)

    # Decorate a function using the LoggedFunction decorator
    hello = logged_func(say_hello)

    # Call the decorated function
    hello("World")

    # Verify log output
    logRecord = logging.LogRecord(
        __name__, logging.DEBUG, "", 0, "say_hello('World')", (), None, None
    )
    logger.handle(logRecord)

# Generated at 2022-06-12 06:42:34.430802
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.handlers = [logging.StreamHandler()]
    @LoggedFunction(logger)
    def test_01(var1):
        return var1 * 3

    @LoggedFunction(logger)
    def test_02(var1, var2):
        return var1 * 3 + var2

    @LoggedFunction(logger)
    def test_03(var1):
        return

    @LoggedFunction(logger)
    def test_04():
        return 1

    @LoggedFunction(logger)
    def test_05(var1, var2='hello', var3='world'):
        return
