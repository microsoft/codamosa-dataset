

# Generated at 2022-06-12 06:32:43.048063
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Mock logger
    logger = MagicMock()
    logger.debug = MagicMock()

    # Define function to decorate
    @LoggedFunction(logger)
    def test(*args):
        return len(args)

    # Call function using various arguments
    assert test() == 0
    logger.debug.assert_called_once_with(
        "test()"
    )  # Check that logger was called with correct parameters
    logger.reset_mock()  # Reset logger

    assert test(5) == 1
    logger.debug.assert_called_once_with(
        "test('5') -> 1"
    )  # Check that logger was called with correct parameters
    logger.reset_mock()  # Reset logger

    assert test(5, 55, 555) == 3
    logger.debug.assert_called_once

# Generated at 2022-06-12 06:32:53.869184
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("LoggedFunction_test")
    logger.setLevel(logging.DEBUG)
    logger.info("abc")
    logger.debug("abc")
    for handler in logger.handlers:
        handler.setFormatter(logging.Formatter("%(message)s"))
    logging.basicConfig()
    lf = LoggedFunction(logger)
    @lf
    def add(a, b):
        return a+b
    add(1, 2)
    add("a", "  b")
    add("a", "  b", c="c")
    add("a", "  b", c=4)
    add("a", "  b", c="4")
    add("a", 3, c=4)
    add("a", 4, c=4, d="d")


# Generated at 2022-06-12 06:33:03.516751
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging
    import unittest
    import unittest.mock as mock

    class TestLoggedFunction(unittest.TestCase):

        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.addHandler(logging.NullHandler())

        def test_normal_case(self):
            # Create a dummy function
            @LoggedFunction(logger=self.logger)
            def dummy_function(a, b, c=3, d=4):
                return a + b * c * d
            # mock the log info function
            with mock.patch.object(self.logger, "debug") as mock_log:
                dummy_function(1, 2, d=8)

# Generated at 2022-06-12 06:33:13.879343
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    string_io = io.StringIO()
    handler = logging.StreamHandler(string_io)
    handler.setFormatter(
        logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    )
    logger.addHandler(handler)
    LoggedFunction(logger)(lambda *args, **kwargs: None)(1, 2, 3, a=4, b=5, c=6)

# Generated at 2022-06-12 06:33:21.060190
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch

    with patch("logging.Logger.debug") as mock_debug:
        logger = logging.Logger("test")
        logged_function = LoggedFunction(logger)
        function = logged_function(lambda x, y: x + y)
        function(1, 2)
        mock_debug.assert_any_call("<lambda>(1, 2)")
        mock_debug.assert_any_call("<lambda> -> 3")

# Generated at 2022-06-12 06:33:32.345227
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock, call

    logger = Mock()
    lf = LoggedFunction(logger)
    test_args = [1, 2]
    test_kwargs = {"b": 3, "a": 4}

    # Test logger is called with correct args
    # and call goes through to mocked function
    def func(a, b, c=None, d=None):
        return (a * b * c * d)

    wrapper = lf(func)
    result = wrapper(*test_args, **test_kwargs)
    assert result == 1 * 2 * 4 * 3
    logger.debug.assert_has_calls(
        [
            call("func(1, 2, b=3, a=4)"),
            call("func -> 48"),
        ]
    )
    logger.debug.reset

# Generated at 2022-06-12 06:33:42.603475
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # test case example:
    # 1. logged_func = LoggedFunction(passed_in_logger).__call__(func)
    # 2. logged_func(*args, **kwargs)
    # 3. assert that debug calls are made in right order
    # 4. assert that the function is called after log

    # Stub
    # Stub out the logger
    mock_logger = mock.Mock()
    mock_logger.debug = mock.Mock()  # type: Mock
    mock_function = mock.Mock()

    # Test data
    test_args = ["a", "bcd"]
    test_kwargs = {"c": "apple", "d": "banana"}

    # Exercise
    logged_function = LoggedFunction(mock_logger)
    logged_function(mock_function)
    logged_

# Generated at 2022-06-12 06:33:49.135400
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    session = build_requests_session(False)
    assert isinstance(session, Session)
    session = build_requests_session([])
    assert isinstance(session, Session)
    retry = Retry(2)
    session = build_requests_session(retry)
    assert isinstance(session, Session)

# Generated at 2022-06-12 06:34:01.268819
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    s.get('https://www.baidu.com')


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(message)s")
    logger = logging.getLogger("TEST")

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a

    @LoggedFunction(logger)
    def test_func2(a, b, c=None):
        return a * b * c

    # test_func()
    test_func(1, 2)
    test_func("hello", "world", c="bonjour")
    test_func("hello", "world")


# Generated at 2022-06-12 06:34:09.877294
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import DEBUG
    from logging import StreamHandler

    from logging import getLogger
    from io import StringIO

    # Create logger
    logger = getLogger()
    logger.setLevel(DEBUG)

    # Create log output stream
    stream = StringIO()

    # Add handler for log output stream
    handler = StreamHandler(stream)
    handler.setLevel(DEBUG)
    logger.addHandler(handler)

    # Make logging decorator
    logged = LoggedFunction(logger)

    # Create function to test
    @logged
    def function(a, b=2, c=None):
        return a + b

    # Call function
    assert function(1, b=3, c=4) == 4

    # Check log output

# Generated at 2022-06-12 06:34:27.579778
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger

    def f(a, b, c=3, d=4, e=5):
        return a + b + c + d + e

    # empty logger
    class LoggerNull:
        def debug(self, msg):
            pass

    with mock.patch("ocean_utils.logging.logger", LoggerNull()):
        logged_f = LoggedFunction(logger).__call__(f)
        logged_f(1, 2, 3, 4, 5)
        logged_f(1, 2)
        logged_f(1, 2, d=6, e=6)

    # test logger
    class LoggerTest:
        def debug(self, msg):
            assert msg == "f(1, 2, 3, 4, 5)" or msg == "f -> 15"
            assert msg

# Generated at 2022-06-12 06:34:38.512991
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest

    # Set up a logger for logging to a test stream.
    test_stream = io.StringIO()
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    logger_handler = logging.StreamHandler(test_stream)
    logger.addHandler(logger_handler)

    # Define a function
    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    # Call the function
    add(3, 4)

    # We should now have two logged lines
    logged_lines = [line for line in test_stream.getvalue().split("\n") if line]
    assert len(logged_lines) == 2

# Generated at 2022-06-12 06:34:46.930597
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def debug(self, msg):
            self.message = msg

    def f(x, y, k1='a', k2="b", k3=3):
        return x

    logger = MockLogger()
    logged_func = LoggedFunction(logger)(f)
    logged_func(1, 2, k1=4, k2=5, k3=6)
    assert logger.message == "f(1, 2, k1=4, k2=5, k3=6) -> 1"



# Generated at 2022-06-12 06:34:54.720380
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import json
    import pytest
    from unittest.mock import Mock

    # -----
    # Test function with no arguments or return value
    logger = Mock()

    def no_args_no_return():
        pass

    LoggedFunction(logger)(no_args_no_return)()

    # Assert function name and arguments were logged
    assert logger.debug.call_count == 1
    assert logger.debug.mock_calls == [
        ("no_args_no_return()",),
    ]

    # -----
    # Test function with no arguments but a return value
    logger = Mock()

    def no_args_return():
        return "no_args_return's return value"

    LoggedFunction(logger)(no_args_return)()

    # Assert function name and arguments were logged

# Generated at 2022-06-12 06:35:02.709667
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase, mock

    class TestLoggedFunction(TestCase):
        def test_logged_function(self):
            mock_logger = mock.Mock()
            decorated_function = LoggedFunction(mock_logger)(
                lambda x, y: x + y,
            )
            self.assertEqual(decorated_function(1, 2), 3)
            mock_logger.debug.assert_has_calls(
                [mock.call("lambda(1, 2)"), mock.call("lambda -> 3")],
            )

    TestLoggedFunction().test_logged_function()

# Generated at 2022-06-12 06:35:08.105871
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    my_func = LoggedFunction(logging.getLogger(__name__))(lambda a: a + 1)
    assert my_func(2) == 3
    assert my_func(a=2) == 3

# Generated at 2022-06-12 06:35:18.874609
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import inspect

    logger = logging.getLogger()

    # set logger level
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def foo_bar(s, a, b):
        return a + b

    # function foo_bar is decorated by LoggedFunction
    if foo_bar.__globals__[inspect.signature(foo_bar).return_annotation] is not inspect._empty:
        # logger set the level DEBUG, so debug message is printed on console
        assert foo_bar("hello", 1, 2) == "foo_bar('hello', 1, 2) -> 3"
    else:
        assert foo_bar("hello", 1, 2) == 3

# Generated at 2022-06-12 06:35:28.189587
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    log_mock = mock.Mock()
    arg1 = "a"
    arg2 = "b"
    arg3 = "c"
    arg4 = "d"
    arg5 = "e"
    kwargs_ref = {"kwarg1": "f", "kwarg2": "g"}
    func_ref = mock.Mock()
    func_ref.__name__ = "func_ref"
    result_ref = "result_ref"
    func_ref.side_effect = lambda *args, **kwargs: result_ref
    func_ref.__name__ = "func_ref"

    logged_func = LoggedFunction(log_mock)(func_ref)
    result = logged_func(arg1, arg2, arg3, arg4, arg5, **kwargs_ref)

    assert result

# Generated at 2022-06-12 06:35:33.608564
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    @LoggedFunction(logger=logging.getLogger(__name__))
    def testfunc(a, b=1.0, **kwargs):
        return a + b

    testfunc(1, b=-1.0, test=True)
    testfunc(2, c=3, test=False)
    testfunc(3.5, d=5)

# Generated at 2022-06-12 06:35:44.853472
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from mlsnippets.utils.logging import get_logger
    from unittest.mock import Mock

    logger = get_logger(__name__)
    tmp_logger = Mock(spec=logger)
    logged_func = LoggedFunction(tmp_logger)(func)
    logged_func(1, 2)
    logged_func(1, 2, 3, 4)
    logged_func(1, 'a', 'b')
    logged_func(1, 2, 'a', 'b')

# Generated at 2022-06-12 06:36:07.305296
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    import sys
    import unittest


    def logged_func(*args, **kwargs):
        """This is logging function."""
        return args, kwargs


    class TestLoggedFunction(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLoggedFunction")
            self.logger.setLevel(logging.DEBUG)
            self.output = StringIO()
            self.handler = logging.StreamHandler(self.output)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)
            self.logged_func = LoggedFunction(logger=self.logger)(logged_func)

        def tearDown(self):
            self.logger

# Generated at 2022-06-12 06:36:16.289208
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from sys import stdout
    import logging
    from contextlib import redirect_stdout

    # define logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stdout)
    logger.addHandler(handler)

    # create decorator
    log = LoggedFunction(logger)

    # decorate function
    @log
    def test_func(a, b, kwarg=None):
        return a + 2*b - 3*kwarg

    # call the cause of execution of the decorator
    with redirect_stdout(stdout):
        res = test_func(1, 2, kwarg=3)
    assert res == 3


# TODO: Add unit test for use of format_arg in __call__ of class LoggedFunction

# Generated at 2022-06-12 06:36:26.260974
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    output = io.StringIO()
    handler = logging.StreamHandler(output)
    logger.addHandler(handler)
    logged_function = LoggedFunction(logger)

    def func(a, b, c=3, d="4"):
        return a * b * c * d

    logged_func = logged_function(func)
    logged_func(1, 2, d="4")
    logged_func(1, 2, 3, d="4")
    logged_func(1, 2)


# Generated at 2022-06-12 06:36:36.159783
# Unit test for function build_requests_session
def test_build_requests_session():
    from unittest import TestCase
    from unittest.mock import Mock

    with TestCase.assertRaises(TestCase, ValueError):
        build_requests_session(retry=object())
    with TestCase.assertRaises(TestCase, ValueError):
        build_requests_session(retry="test")

    retry_config = Retry(total=5, connect=5, read=5, backoff_factor=0.1, status_forcelist=[502, 503, 504])
    session = build_requests_session(retry=retry_config)
    adapter = session.adapters.get("http://")
    TestCase.assertIsNotNone(TestCase, adapter)
    TestCase.assertEqual(TestCase, adapter.max_retries.total, retry_config.total)
   

# Generated at 2022-06-12 06:36:47.453327
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import os
    import tempfile

    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # Create formatter
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    # Create and add handler
    handler = logging.FileHandler(os.path.join(tempfile.gettempdir(), "test.log"))
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # test function
    @LoggedFunction(logger)
    def test_func(test_int, test_str, test_none, test_dict={}):
        pass

# Generated at 2022-06-12 06:36:51.964518
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    simple_class = type("TestClass", (), {})
    instance = simple_class()
    instance.logger = type("Logger", (), {"debug": lambda x: print("logger:", x)})()
    lf = LoggedFunction(instance.logger)
    def test_func(args, kwarg=None):
        print("test_func:", args, kwarg)
    test_func = lf(test_func)
    test_func("hello", kwarg="world")

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:36:59.214950
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    from contextlib import contextmanager
    from io import StringIO
    import os

    class TestLoggedFunction(unittest.TestCase):
        @contextmanager
        def captured_output(self):
            new_out, new_err = StringIO(), StringIO()
            old_out, old_err = sys.stdout, sys.stderr
            try:
                sys.stdout, sys.stderr = new_out, new_err
                yield sys.stdout, sys.stderr
            finally:
                sys.stdout, sys.stderr = old_out, old_err

        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.log

# Generated at 2022-06-12 06:37:09.017547
# Unit test for function build_requests_session
def test_build_requests_session():
    session1 = build_requests_session()
    assert isinstance(session1, Session)
    assert session1.hooks == {}
    assert len(session1.adapters) == 2
    assert isinstance(session1.adapters['http://'], HTTPAdapter)

    session2 = build_requests_session(False)
    assert isinstance(session2, Session)
    assert session2.hooks == {}
    assert len(session2.adapters) == 2
    assert isinstance(session2.adapters['http://'], HTTPAdapter)
    assert session2.adapters['http://'].max_retries.total == 10

    session3 = build_requests_session(False, False)
    assert isinstance(session3, Session)
    assert session3.hooks == {}

# Generated at 2022-06-12 06:37:16.452462
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger, DEBUG
    import unittest
    import unittest.mock

    logger = getLogger()
    logger.setLevel(DEBUG)

    with unittest.mock.patch("logging.Logger.debug") as mock_logger:
        @LoggedFunction(logger)
        def do_something(foo: str, bar: int = 1) -> int:
            return 42

        do_something('"hello", world', 123)
        mock_logger.assert_any_call(
            'do_something(\'\\"hello\\", world\', 123)'
        )
        mock_logger.assert_any_call('do_something -> 42')

if (__name__ == "__main__"):
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:37:22.604372
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    logger = FakeLogger()
    logged_func = LoggedFunction(logger)(func)
    result = logged_func()
    assert result == "return"
    assert logger.logs == ["func([])", "func -> return"]



# Generated at 2022-06-12 06:37:39.897609
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert not session.hooks
    assert session.adapters
    assert [
        (a, a.max_retries.total)
        for a in session.adapters.values()
        if isinstance(a, HTTPAdapter)
    ] == [
        ("http://", Retry().total),
        ("https://", Retry().total),
    ]
    session = build_requests_session(False, False)
    assert not session.adapters
    session = build_requests_session(False, 3)

# Generated at 2022-06-12 06:37:48.451615
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def debug(self, msg):
            print(msg)
    # test1: not return None
    logged_func = LoggedFunction(DummyLogger())(lambda x, y: x + y)
    logged_func(1, 2)
    # test2: return None
    logged_func = LoggedFunction(DummyLogger())(lambda x: None)
    logged_func(1)
    # test3: without arguments
    logged_func = LoggedFunction(DummyLogger())(lambda: None)
    logged_func()



# Generated at 2022-06-12 06:37:57.483741
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    import logging.handlers
    from io import StringIO
    from contextlib import redirect_stdout

    class LoggedFunctionTestCase(unittest.TestCase):
        def setUp(self):
            self.stream = StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)
            self.logged_function = LoggedFunction(self.logger)
        def tearDown(self):
            self.logger.removeHandler(self.handler)

# Generated at 2022-06-12 06:38:03.585184
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from hypothesis import given
    from hypothesis.strategies import text, integers, lists
    from hypothesis.extra.datetime import datetimes
    from hypothesis.extra.django import from_model

    # Create logging string IO handler
    handler = logging.StringIO()
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler(handler))

    # Define decorator
    @LoggedFunction(logger)
    def foo(s: str, i: int, d: datetime.datetime) -> int:
        return i + 1

    # Test logging
    @given(text(), integers(), datetimes())
    def test(string, integer, datetime):
        foo(string, integer, datetime)

# Generated at 2022-06-12 06:38:06.406167
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    log = logging.getLogger(__name__)

    @LoggedFunction(log)
    def hello():
        return "Hello"

    hello()
    hello()
    hello()


# Generated at 2022-06-12 06:38:13.718437
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    # Set up a mock logger object which captures all log messages at the debug level
    log_stream = io.StringIO()
    logger = logging.getLogger()
    logger.level = logging.DEBUG
    handler = logging.StreamHandler(log_stream)
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s", "%Y-%m-%d %H:%M:%S"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.propagate = False

    # Define a function which has a decorator applied
    @LoggedFunction(logger)
    def foo(x, y="world"):
        return "Hello " + y

# Generated at 2022-06-12 06:38:24.462591
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger
    from unittest.mock import patch
    import io

    """
    With patch, we can change the stdout with a StringIO object, so that we
    can then get the value and test
    """

    def mock_logger(s):
        return s

    with patch.object(Logger, "debug", side_effect=mock_logger) as mock_method:
        m = LoggedFunction(mock_method)
        m(test_LoggedFunction___call__)()
        assert mock_method.call_count == 3
        args, kwargs = mock_method.call_args_list[0]
        assert str(args[0]) == "test_LoggedFunction___call__([], {})"
        args, kwargs = mock_method.call_args_list[1]

# Generated at 2022-06-12 06:38:31.862043
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    # Attach mocked logger to function
    mock_logger = logging.Logger("")
    mock_logger.debug = MagicMock()
    logged_function = LoggedFunction(mock_logger)

    # Act
    @logged_function
    def some_function(a, b, c=3):
        return 1

    # Assert
    # Test behaviour with no arguments
    # Test behaviour with no arguments
    some_function()
    mock_logger.debug.assert_called_with("some_function()")
    mock_logger.debug.assert_called_with("some_function -> 1")

    # Test behaviour with 3 positional arguments
    some_function("a", "b", "c")

# Generated at 2022-06-12 06:38:36.841069
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Unit test for method __call__ of class LoggedFunction
    """
    import logging

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test_func(a, b=2):
        return a + b

    test_func(5, b=10)

# Generated at 2022-06-12 06:38:43.247630
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def test_func(arg1, arg2, arg3=3, arg4=4):
        return 5

    log = []
    def log_function(message):
        log.append(message)

    decorated_func = LoggedFunction(log_function)(test_func)
    decorated_func(a, b, arg3=c, arg4=d)
    assert len(log) == 2
    assert log[0] == f"test_func({a}, {b}, arg3={c}, arg4={d})"
    assert log[1] == "test_func -> 5"

# Generated at 2022-06-12 06:39:07.533355
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Mocks
    import logging
    import sys

    logger = logging.getLogger("test")
    logger.setLevel("DEBUG")

    stream_handler = logging.StreamHandler(stream=sys.stdout)
    formatter = logging.Formatter("%(asctime)s %(name)-12s %(levelname)-8s %(message)s")
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    class Dummy:
        def __init__(self, logger):
            self.logged_function = LoggedFunction(logger)

        @self.logged_function
        def foo(self, *args, **kwargs):
            return "hello world"

    dummy = Dummy(logger)
    assert dummy.foo() is None

# Generated at 2022-06-12 06:39:15.224720
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logging.basicConfig()
    logger = logging.getLogger("my_logger")
    logger.setLevel(logging.DEBUG)

    def sum(a, b):
        return a + b

    wrapped = LoggedFunction(logger)(sum)
    wrapped(1, b=2)

    # TODO: The following line does not work.
    # assert re.match(r'a=1, b=2 -> 3', logger.info.call_args[0][0])

# Generated at 2022-06-12 06:39:26.259245
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    from contextlib import redirect_stdout

    logger = logging.getLogger()
    formatter = logging.Formatter('%(message)s')
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    # set the level of logger
    stream_handler.setLevel(logging.DEBUG)
    logger.addHandler(stream_handler)

    # set the level of logger
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def add(x,y):
        return x + y

    assert add(1, 2) == 3
    assert add("abc", "def") == "abcdef"

    f = io.StringIO()

# Generated at 2022-06-12 06:39:37.877685
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging
    import string

    # We need a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    def test_func(a, b):
        return a + b

    # Create a LoggedFunction and call it with a function
    # The logger is also passed to LoggedFunction as an argument
    logged_func = LoggedFunction(logger)(test_func)

    logger.info("Calling logged_func")
    num_chars = logged_func(4, 8)
    logger.info(f"logged_func returned {num_chars}")
    assert num_chars == 12

    alphabet = string.ascii_uppercase
    logger.info("Calling logged_func")
    first_char = logged_func(alphabet, 0)
    logger.info

# Generated at 2022-06-12 06:39:49.329329
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    logger = Mock()
    logged_function = LoggedFunction(logger)
    from math import sqrt

    logged_sqrt = logged_function(sqrt)

    # No logging on function call
    assert logger.debug.call_count == 0

    # Call function
    result = logged_sqrt(2)

    # Check logging
    expected_calls = [
        Mock(call_args=[("sqrt(2)",)], call_count=1),
        Mock(call_args=[("sqrt() -> 1.414213562373095",)], call_count=1),
    ]
    assert logger.debug.call_args_list == expected_calls

    # Check result
    assert result == 1.4142135623730951

# Generated at 2022-06-12 06:39:54.007931
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import unittest.mock
    logger = unittest.mock.MagicMock()
    logged_func = LoggedFunction(logger)(lambda x: x)
    logged_func(1)
    logger.debug.assert_called_once_with("<lambda>(1)")
    logger.reset_mock()
    logged_func(1, x=2)
    logger.debug.assert_called_once_with("<lambda>(1, x=2)")

# Generated at 2022-06-12 06:39:58.191753
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()

    @LoggedFunction(logger)
    def test(a, b, c="c"):
        return a + b + c

    test(1, 2)



# Generated at 2022-06-12 06:40:09.037769
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # import libs
    import io
    import logging
    import unittest

    # create logging stream
    stream = io.StringIO()

    # create log handler
    handler = logging.StreamHandler(stream)

    # define log level
    handler.setLevel(logging.DEBUG)

    # create logger
    logger = logging.getLogger()

    # add handler to logger
    logger.addHandler(handler)

    # define logging level
    logger.setLevel(logging.DEBUG)

    # create a fixture
    @LoggedFunction(logger)
    def test_func(int_input, str_input=None):
        return int_input + 2

    # test function
    assert test_func(1, str_input="test") == 3

    # check output

# Generated at 2022-06-12 06:40:15.781620
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    buf = io.StringIO()
    handler = logging.StreamHandler(buf)
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test_func(*args, **kws):
        return (args, kws)

    test_func(5, 4, key1="val1", key2="val2")

    buf.seek(0)
    output = "".join(buf.readlines())
    assert output == "test_func((5, 4), key1='val1', key2='val2')\ntest_func -> ((5, 4), {'key1': 'val1', 'key2': 'val2'})\n"

# Generated at 2022-06-12 06:40:22.892492
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger("test")
    def test_func(a, b=None, *args, **kwargs):
        print(a, b, args, kwargs)
        return 123
    
    logged_func = LoggedFunction(logger)(test_func)
    assert logged_func.__doc__ == test_func.__doc__, "__doc__ should be wrapped."

    logged_func(1)
    logged_func(1, b=5, c=6, e=[1,3,5])
    logged_func(1, 5, 7, c=6, e=[1,3,5])


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)


# Generated at 2022-06-12 06:41:10.377348
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.INFO)
    handler = logging.FileHandler("test_loggedfunction_call.log", mode="w")
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    logger.info("INFO message")

    @LoggedFunction(logger)
    def test_func(arg1, arg2, kwarg1=None):
        return arg1 + arg2 + kwarg1

    test_func(1, 2, 3)

    logger.info("INFO message")



# Generated at 2022-06-12 06:41:17.946648
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    from tssc.logging_config import TSSCLoggingConfig
    from tssc.config.defaults import ConfigFileDefaults

    logging_config = TSSCLoggingConfig()
    logging_config.set_logger_level(ConfigFileDefaults.LOGGER_NAME,
                                    ConfigFileDefaults.LOGGER_LEVEL)
    logger = logging_config.get_logger(ConfigFileDefaults.LOGGER_NAME)

    @LoggedFunction(logger=logger)
    def check_log(arg1, arg2):
        print('Logger test')
        print(f"{arg1} {arg2}")
        return 'Fake return'

    check_log('Arg1', 'Arg2')

    # TODO: test for return value

# Generated at 2022-06-12 06:41:21.132887
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    cookies = session.cookies

if __name__ == '__main__':
    test_build_requests_session()

# Generated at 2022-06-12 06:41:30.916268
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys


    class Logger:
        """
        Logger which stores logging messages in the 'log' attribute
        """

        def __init__(self):
            self.log = []

        def debug(self, message):
            self.log.append(message)


    def test_function(a, b, c="test", *args, **kwargs):
        return a + b


    logger = Logger()
    # original_stdout = sys.stdout
    # sys.stdout = open(os.devnull, "w")
    wrapped = LoggedFunction(logger)(test_function)
    assert wrapped(1, 2) == 3
    assert wrapped(1, 2, 3) == 3
    assert wrapped(1, 2, c="testing") == 3

# Generated at 2022-06-12 06:41:42.116360
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    import io
    import sys

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.stream = io.StringIO()
            handler = logging.StreamHandler(self.stream)
            self.logger = logging.getLogger()
            self.logger.level = logging.DEBUG
            self.logger.addHandler(handler)

        def test_regular(self):
            @LoggedFunction(self.logger)
            def test_func(a, b=None, c=1):
                return a + c

            test_func(5)

# Generated at 2022-06-12 06:41:50.924867
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    # Suppress output from logging
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    ch.setFormatter(formatter)
    root.addHandler(ch)

    logger = logging.getLogger("unit_test")

    class A:
        @LoggedFunction(logger)
        def foo(self, a, b=2):
            return a + b

        @LoggedFunction(logger)
        def bar(self, a):
            return a


# Generated at 2022-06-12 06:41:56.677546
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logging.basicConfig(
        handlers=[logging.StreamHandler(stream=sys.stdout)],
        format="%(asctime)s - %(levelname)s - %(name)s:%(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    @LoggedFunction(logger)
    def test(a, b, c=3, d=4):
        print(a, b, c, d)

    test(1, 2)
    test(1, b=2, c=3, d=3)

# Generated at 2022-06-12 06:42:04.943147
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def debug(self, msg):
            print(msg)

    def func(a, b, c):
        pass

    logged_func = LoggedFunction(FakeLogger())(func)
    logged_func(1, 2, 3)
    logged_func('1', '2', '3')
    logged_func(a=1, b=2, c=3)
    logged_func(a='1', b='2', c='3')


if __name__ == '__main__':
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:42:15.136432
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Set up a mock logger
    mock_logger = unittest.mock.create_autospec(logging.Logger)

    # Define a function
    def sum(a: int, b: int = 0, *args: int) -> int:
        """ Return the sum of two numbers. """
        return a + b + sum(args) if args else a + b

    # Create a LoggedFunction
    logged_sum = LoggedFunction(logger=mock_logger)
    # Test the LoggedFunction
    assert logged_sum(sum)(1, 2, 3, 4) == sum(1, 2, 3, 4)

# Generated at 2022-06-12 06:42:23.026856
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # arrange
    class Logger:
        def __init__(self):
            self.log = []
        def debug(self, text):
            self.log.append(text)
    logger = Logger()
    deco = LoggedFunction(logger)
    def func(a, b, c=None):
        return a + b + c
    expected_log = ["func(a, b, c=None)","func -> 6"]
    # act
    a, b, c = 1, 2, 3
    deco(func)(a, b, c=c)
    # assert
    assert logger.log == expected_log
