

# Generated at 2022-06-12 06:32:47.094368
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase
    from unittest.mock import Mock
    from logging import Logger

    class Test(TestCase):
        def test(self):
            logger = Mock(spec=Logger)
            logged_foo = LoggedFunction(logger)(foo)

            logged_foo(1)

            logger.debug.assert_called_with('foo(1)')
            self.assertEqual(logger.debug.call_count, 2)

    def foo(x):
        return x

    test_LoggedFunction___call__.Test = Test
    import unittest

    unittest.main()


# Generated at 2022-06-12 06:32:57.243811
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False, False)
    assert 1 == len(session.adapters)
    assert not session.hooks
    session = build_requests_session(True, False)
    assert 1 == len(session.adapters)
    assert 1 == len(session.hooks)
    session = build_requests_session(False, True)
    assert 1 == len(session.adapters)
    assert 1 == len(session.hooks)
    session = build_requests_session(True, True)
    assert 1 == len(session.adapters)
    assert 2 == len(session.hooks)
    session = build_requests_session(False, 3)
    assert 1 == len(session.adapters)
    assert 1 == len(session.hooks)
    session = build_requests_

# Generated at 2022-06-12 06:33:05.027605
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    handler = logging.StreamHandler()
    logger = logging.getLogger()
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s:%(lineno)d | %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    def test_func(a, b, *args, c=1, d=2, **kwargs):
        return b

    logged_func = LoggedFunction(logger)(test_func)
    logged_func(1, 2, 3, 4, c=5, d=6)

# Generated at 2022-06-12 06:33:13.879817
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Tests functionality of LoggedFunction.__call__()
    """
    import logging
    import unittest
    import unittest.mock

    # An empty logger that logs everything to a StringIO
    # Since StringIO cannot be used as a context manager, we need to wrap it
    # in a class
    class StringIOLogger(logging.Logger):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.log_text = io.StringIO()

        def handle(self, record):
            self.log_text.write(record.getMessage())

    class LoggedFunctionTests(unittest.TestCase):
        """
        Tests functionality of LoggedFunction.__call__()
        """


# Generated at 2022-06-12 06:33:22.803919
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    # capture log to memory
    f = io.StringIO()
    handler = logging.StreamHandler(f)
    handler.setLevel(logging.DEBUG)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # Decorator which adds debug logging to a function.
    @LoggedFunction(logger)
    def test(a, b):
        c = a + b
        return c

    test(3, 4)

    assert f.getvalue() == "test(3, 4)\ntest -> 7\n"

# Generated at 2022-06-12 06:33:31.485823
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def test_function(a, b, c, d=1, e=2):
        return a + b + c + d + e

    test_function(1, 2, 3)
    test_function(1, 2, 3, 4, e=4)
    test_function(b=1, d=2, e=3, a=4, c=5)

#test_LoggedFunction___call__()


# Generated at 2022-06-12 06:33:41.959737
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    # Create a function
    def example_function(x, y):
        return x + y

    # Test with a logger which sends output to the console
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()
    assert example_function(5, 6) == 11
    assert example_function(12.7, -10) == 2.7
    logged_function = LoggedFunction(logger)
    assert logged_function(example_function)(5, 6) == 11
    assert logged_function(example_function)(12.7, -10) == 2.7

    # Test with a logger which does not send output
    logger = logging.getLogger()
    assert example_function(5, 6) == 11
    assert example_function(12.7, -10) == 2.7


# Generated at 2022-06-12 06:33:52.049444
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("devops-test")
    f = LoggedFunction(logger)
    def foo(a, b, c=1, d=1, *args, e=1, f=1, **kwargs): pass
    foo = f(foo)
    foo(1,2)
    foo(1,2,3)
    foo(1,2,3,4,5,6)
    foo(1,2,3,4,5,6,7,8,9)
    foo(1,2,3,4,5,6,7,8,e=10,f=11)
    foo(1,2,3,4,5,6,7,8,c=10)

# Generated at 2022-06-12 06:34:00.216214
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    @LoggedFunction(logger=MagicMock())
    def test_function(a, b, key1='default', key2='default'):
        return a, b, key1, key2

    test_function(1, 2, 'key1', 'key2')
    
    mock = patch('logging.Logger.debug')
    mock.assert_called_with("test_function(1, 2, key1='key1', key2='key2')")

# Generated at 2022-06-12 06:34:09.438542
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging

    class LoggedFunctionTestCase(unittest.TestCase):
        def test_log_function_arguments_and_result(self):
            class MockLogger:
                def __init__(self):
                    self.output = []

                def debug(self, *args):
                    self.output += args

            def test_function(a, b, c, **kwargs):
                return dict(a=a, b=b, c=c, **kwargs)

            # Generate LoggedFunction wrapper function
            logger = MockLogger()
            wrapper = LoggedFunction(logger)(test_function)

            # Call function
            wrapper(1, 2, 3, a=4, b=5)

            # Check logger output

# Generated at 2022-06-12 06:34:20.620103
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogging:
        def __init__(self):
            self.calls = []

        def debug(self, message):
            self.calls.append(message)

    @LoggedFunction(MockLogging())
    def test_function(param1, other_param=None):
        return param1

    result = test_function("hello", other_param="yes")
    assert result == "hello"
    assert len(test_function.__logger__.calls) == 2
    assert test_function.__logger__.calls[0] == "test_function('hello', other_param='yes')"
    assert test_function.__logger__.calls[1] == "test_function -> hello"

# Generated at 2022-06-12 06:34:28.996762
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    log.addHandler(handler)

    logged_func = LoggedFunction(log)

    # Test simple function with no arguments
    @logged_func
    def simple_func():
        return "simple"

    assert simple_func() == "simple"
    assert stream.getvalue().strip() == "simple_func() -> simple"
    assert simple_func.__name__ == "simple_func"
    stream.truncate(0)

    # Test simple function with arguments

# Generated at 2022-06-12 06:34:39.022979
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import os
    import sys
    import logging

    # set up logger
    logger = logging.getLogger("LoggedFunctionTestLogger")
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    LF = LoggedFunction(logger)

    # test with no kwargs
    @LF
    def test_func(a, b):
        return a + b

    result = test_func(1, 2)
    assert result == 3

    # test with kwargs
    @LF
    def test_func2(a=1, b=2):
        return

# Generated at 2022-06-12 06:34:50.162798
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    class MockLogger:
        def debug(self, message):
            print(f"Debug: {message}.")

    logger = MockLogger()

    @LoggedFunction(logger)
    def foo(a, b, c, d=1, e=2):
        return a + b + c + d + e

    def foo_without_decorator(a, b, c, d=1, e=2):
        return a + b + c + d + e

    assert foo(1, 2, 3) == foo_without_decorator(1, 2, 3)
    assert foo(1, 2, 3, d=4, e=5) == foo_without_decorator(1, 2, 3, d=4, e=5)

# Generated at 2022-06-12 06:35:01.419034
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry
    from requests import Session

    s = build_requests_session()

    assert isinstance(s, Session)
    assert isinstance(s.adapters["https://"], HTTPAdapter)
    assert isinstance(s.adapters["https://"].max_retries, Retry)

    s = build_requests_session(retry=False)

    assert isinstance(s, Session)
    assert "https://" not in s.adapters

    s = build_requests_session(retry=1)

    assert isinstance(s, Session)
    assert isinstance(s.adapters["https://"], HTTPAdapter)

# Generated at 2022-06-12 06:35:07.971149
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    class test_class:
        def __init__(self):
            self.x = "x"
            self.y = "y"
            self.logger = logging.getLogger("test_class")

        @LoggedFunction(logger=logging.getLogger("test_class"))
        def func_1(self, a, b, c=None, d=None):
            return "func_1"

        @LoggedFunction(logger=logging.getLogger("test_class"))
        def func_2(self, a, b, c=None, d=None):
            return "func_2"

    tc = test_class()
    tc.func_1(1, 2, 3)
    tc.func_2("x", "y", d=["z"])

# Generated at 2022-06-12 06:35:14.762802
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Arrange
    import logging
    logger = logging.getLogger("test")
    logged_function = LoggedFunction(logger)

    # Act
    logged = logged_function(add)

    # Assert
    assert logged(1, 2, 3) == 6
    assert logged(1, 2, add=3, b=5) == 11
    assert logged(1.0, 2.0, add=3.0) == 6.0



# Generated at 2022-06-12 06:35:23.256950
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from functools import wraps

    func = Mock()

    @wraps(func)
    def func_wrap_mock(arg):
        pass

    logger = Mock()
    func_wrap = LoggedFunction(logger)(func_wrap_mock)
    func_wrap(1)
    func_wrap(1, arg='a')
    func_wrap(1, arg2='b')
    func_wrap(1, arg='a', arg2='b')

    func_wrap_mock.assert_called_once()
    logger.debug.assert_any_call("func(1)")
    logger.debug.assert_any_call("func(1, arg='a')")
    logger.debug.assert_any_call("func(1, arg2='b')")
   

# Generated at 2022-06-12 06:35:29.636929
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import os

    import logging

    # Set default level to WARN
    logging.getLogger().setLevel(logging.WARN)

    logger = logging.getLogger("test")

    # Unit test for method __call__ of class LoggedFunction
    # This should print the following output in the console:
    # test - DEBUG - my_func(1, 2, 3, abc=4, foo=bar)
    # test - DEBUG - my_func -> some_result
    # test - DEBUG - my_func_with_args(1, 2, 3, abc=4, foo=bar)
    # test - DEBUG - my_func_with_args -> some_result
    # test - DEBUG - my_func_with_kwargs(1, 2, 3, abc=4, foo=bar)
    # test - DEBUG - my_func

# Generated at 2022-06-12 06:35:34.314457
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_logger = logging.getLogger("Test")
    test_logger.addHandler(logging.StreamHandler())
    test_logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger=test_logger)
    def test_function(a: int, b: int) -> int:
        return a + b

    test_function(1, 2)

# Generated at 2022-06-12 06:35:44.599427
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import functools

    def test_func(*args, **kwargs):
        return f"{args}{kwargs}"

    log_stream = io.StringIO()
    logging.basicConfig(
        level=logging.DEBUG, stream=log_stream, format="%(levelname)s: %(message)s"
    )
    logger = logging.getLogger("test")
    test_func = LoggedFunction(logger)(test_func)
    assert test_func("arg1", "arg2", kwarg1="kwarg1", kwarg2="kwarg2") == "(arg1, arg2){'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}"

# Generated at 2022-06-12 06:35:55.351453
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger, DEBUG
    from unittest.mock import patch

    mocked_logger = getLogger(__name__)
    mocked_logger.setLevel(DEBUG)
    mocked_logger.debug = patch("logging.Logger.debug").start()

    @LoggedFunction(mocked_logger)
    def func1(a, b=1, c="foo"):
        return a * (b + c)

    func1(10)

    mocked_logger.debug.assert_called_with("func1(10, b=1, c='foo')")
    mocked_logger.debug.reset_mock()

    func1(10, b="bar")

    mocked_logger.debug.assert_called_with("func1(10, c='foo', b='bar')")


# Generated at 2022-06-12 06:36:06.680482
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    if sys.platform == "win32":
        format = "%(asctime)s - %(levelname)s - %(message)s"
    else:
        format = "\033[0m%(asctime)s \033[1m%(levelname)s\033[0m%(message)s"

    class Context(logging.Logger):

        def __enter__(self):
            self.io = io.StringIO()
            handler = logging.StreamHandler(self.io)
            handler.setFormatter(logging.Formatter(format))
            self.addHandler(handler)
            return self

        def __exit__(self, *args):
            self.removeHandler(self.handlers[0])


# Generated at 2022-06-12 06:36:15.845973
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    logger = unittest.mock.create_autospec(logging.Logger, spec_set=True)
    logged_func = LoggedFunction(logger)(make_a_string)

    # Run test -
    #
    # Test when input arguments contains named argument and no positional arguments
    logged_func(named_argument="named argument")

    # Test when there is a return value
    assert logged_func() == None

    # Test when input arguments contains positional argument only
    logged_func(1)

    # Test when input arguments contains positional argument first and named argument
    logged_func(1, named_argument="named argument")

    # Test when input arguments contains named argument only
    logged_func(named_argument="named argument")

    # Test when input arguments contains named arguments only

# Generated at 2022-06-12 06:36:22.217972
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.log = []

        def debug(self, msg):
            self.log.append(msg)

    def f(x, y):
        pass

    logger = Logger()
    f = LoggedFunction(logger)(f)
    f(1, y=2)
    assert logger.log == ["f(1, y=2)"]



# Generated at 2022-06-12 06:36:31.160867
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    def f(a, b):
        return a + b

    @LoggedFunction(logging.getLogger())
    def g(a, b):
        return a + b

    # Test LoggedFunction is a decorator which wraps a function
    assert f is not g
    assert f(2, 3) == 5
    assert g(2, 3) == 5

    # Test the logger is called with the expected arguments
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger = logging.getLogger()
    logger.addHandler(handler)
    g(2, 3)
    logger.removeHandler(handler)
    assert stream.getvalue() == "g(2, '3')\ng -> 5\n"

    # Test function arguments which require quotation marks
    stream

# Generated at 2022-06-12 06:36:35.965379
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger()
    loggedFunction = LoggedFunction(logger)
    def foo(a, b):
        return a + b
    decorated_foo = loggedFunction(foo)
    assert decorated_foo(1, 2) == 3

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:36:47.084672
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import sys

    class TestLogRecord(logging.LogRecord):
        def __init__(self, name, level, pathname, lineno, msg, args, exc_info):
            super().__init__(name, level, pathname, lineno, msg, args, exc_info)
            self.msg = f"[{self.funcName}] {msg}"

    class TestLogger(logging.Logger):
        def makeRecord(self, name, level, fn, lno, msg, args, exc_info, func=None, extra=None):
            if func is None:
                func = '<unknown>'
            elif func == '__init__':
                func = 'initialising'


# Generated at 2022-06-12 06:36:55.344682
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest.mock import patch

    # Test if method __call__ of class LoggedFunction correctly calls __call__ of wrapped function
    mock_logger = Mock()
    # Wrapping a function
    func = LoggedFunction(mock_logger)(lambda x: x + 1)
    # Calling it
    res = func(1)
    assert res == 2
    # Checking the logger
    assert mock_logger.debug.call_count == 2


# Generated at 2022-06-12 06:37:03.959129
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from loguru import logger

    def add(a,b):
        return a+b

    logger.add("trace", sink="test", format="{message}")

    @LoggedFunction(logger)
    def add_logged(a,b):
        return a+b

    assert add_logged(10, 9) == add(10, 9)
    # test if trace is printed
    assert logger.remove("test")[0].level == "TRACE"
    # clean the logger
    logger.purge()

# Generated at 2022-06-12 06:37:16.518435
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import pytest
    # Setup logging
    logging.basicConfig(level=logging.DEBUG)

    # Setup logged function
    @LoggedFunction(logger=logging.getLogger(__name__))
    def add(a, b):
        return a + b

    # Test logged function

# Generated at 2022-06-12 06:37:26.918873
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
	import sys
	import logging
	logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
	logger = logging.getLogger("LoggedFunction")
	logger.info("Start testing LoggedFunction.__call__")

	logger.debug("TEST 1: logger is None")
	decorator = LoggedFunction(None)
	# decorator(func) has to be called
	# we don't need to test @decorator here
	# we just test it here to simulate the whole process
	assert decorator(test_LoggedFunction___call___func)(2, 3, 1) == 6
	assert decorator(test_LoggedFunction___call___func)(3, 1) == 4

	logger.debug("TEST 2: logger is not None")

# Generated at 2022-06-12 06:37:32.354868
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test_LoggedFunction___call__")
    def print_out(x):
        print(x)
    test_logger = LoggedFunction(logger)(print_out)
    test_logger(5)
    test_logger(0, a=2, b=3)
    test_logger(a=1)


# Generated at 2022-06-12 06:37:39.134347
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.debug_calls = []

        def debug(self, msg):
            self.debug_calls.append(msg)

    def base_function():
        return "base function called"

    logger = Logger()
    logged_function = LoggedFunction(logger)
    logged = logged_function(base_function)
    assert logged() == "base function called"
    assert logger.debug_calls == ['base_function()', 'base_function -> base function called']

# Generated at 2022-06-12 06:37:47.961301
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    _logger = object()
    _func = object()
    lf = LoggedFunction(_logger)

    _func.__name__ = "foo"
    assert lf.__call__(_func)(1, 2, 3, a=1, b=2, c=3).__name__ == "foo"
    _func.__name__ = "bar"
    assert lf.__call__(_func)().__name__ == "bar"
    _func.__name__ = "Baz"
    assert lf.__call__(_func).__name__ == "Baz"


# Generated at 2022-06-12 06:37:55.808897
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def __init__(self):
            self.debug_messages = []

        def debug(self, msg):
            self.debug_messages.append(msg)

    dummy_logger = DummyLogger()

    @LoggedFunction(dummy_logger)
    def dummy_func(a, b, c):
        return None


    dummy_func(123, b=456, c=789)

    assert dummy_logger.debug_messages[0] == "dummy_func(123, b=456, c=789)"
    assert dummy_logger.debug_messages[1] == "dummy_func -> None"

# Generated at 2022-06-12 06:38:02.634029
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import logging

    # Configure logging
    out = io.StringIO()
    handler = logging.StreamHandler(out)
    handler.setLevel(logging.DEBUG)
    logging.getLogger().setLevel(logging.DEBUG)
    logging.getLogger().addHandler(handler)

    # Test with basic function
    @LoggedFunction(logger=logging.getLogger())
    def add(a, b, c="test"):
        return a + b

    add(1, 2)
    log = out.getvalue()
    assert log.startswith("add(1, 2, c='test')\n"), log

    # Test with lambda function

# Generated at 2022-06-12 06:38:03.482735
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-12 06:38:10.008622
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    log = []

    class MockLogger:
        def debug(self, text):
            log.append(text)

    @LoggedFunction(MockLogger())
    def test_func(a: int, b: float, c: str = "str"):
        pass

    test_func(1, 3.14, "c")
    log = log[0]

    assert "test_func" in log
    assert "a=1" in log
    assert "b=3.14" in log
    assert "c='c'" in log



# Generated at 2022-06-12 06:38:21.845756
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Mock()
    func = Mock()
    func.__name__ = "fct"
    with patch.object(logger, 'debug') as mocked_debug:
        @LoggedFunction(logger)
        def func(*args, **kwargs):
            pass
        func(1,2,param1="value1", param2='value2')
        mocked_debug.assert_any_call('fct(1, 2, param1=value1, param2=value2)')
    with patch.object(logger, 'debug') as mocked_debug:
        result = "test"
        @LoggedFunction(logger)
        def func(*args, **kwargs):
            return result
        func(1,2,param1="value1", param2='value2')

# Generated at 2022-06-12 06:38:40.672768
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    #Dependency inversion principle (DIP)
    #Dependency injection
    class MockLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    # Setup
    logger = MockLogger()
    logged_func = LoggedFunction(logger)
    func = lambda x: x * 3

    # Exercise
    decorated_func = logged_func(func)

    # Verify
    decorated_func(3)
    assert len(logger.logs) == 2
    assert logger.logs[0] == "lambda(3)"
    assert logger.logs[1] == "lambda -> 9"


# Generated at 2022-06-12 06:38:43.573632
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from .logger import Logger
    logger = Logger("test")
    logged_function = LoggedFunction(logger)

    @logged_function
    def func(a,b,c):
        return a + b + c

    func("aa","bb","cc")



# Generated at 2022-06-12 06:38:53.048929
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    expected_input = "expected_input"
    expected_output = "expected_output"
    def test_func(input: str):
        return expected_output
    func_name = "test_func"
    expected_log = f"{func_name}('{expected_input}')\ntest_func -> {expected_output}"

    # Test
    @LoggedFunction(logger)
    def test_func(input: str):
        return

# Generated at 2022-06-12 06:39:01.030438
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    from unittest.mock import Mock
    from unittest.mock import patch

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_function_should_not_log_return_value_if_not_specify_logger_level(self):
            @LoggedFunction(logger)
            def func():
                return "result"
            with patch.object(logger, "debug") as mock_debug:
                result = func()
                self.assertEqual(mock_debug.call_count, 1)  # only log function args
                self.assertEqual(result, "result")


# Generated at 2022-06-12 06:39:09.319596
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    class Logger():
        # Set debug level
        level = logging.DEBUG

        def __init__(self):
            # Make a StringIO object
            self.stringio = io.StringIO()
            # Make a format string with the current datetime and level
            self.format = "%(asctime)s %(levelname)s %(message)s"
            # Create a logger for the main function
            self.logger = logging.getLogger("Logger")
            # Create a logger handler that writes to StringIO
            self.handler = logging.StreamHandler(self.stringio)
            # Create a logger formatter
            self.formatter = logging.Formatter(self.format)
            # Associate the handler and formatter with the logger
            self.handler.setFormatter(self.formatter)

# Generated at 2022-06-12 06:39:19.211496
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(retry=False)
    assert len(s.adapters) == 0
    s = build_requests_session()
    assert len(s.adapters) == 2
    s = build_requests_session(retry=0)
    assert s.adapters["https://"].max_retries.total == 0
    assert s.adapters["http://"].max_retries.total == 0
    s = build_requests_session(retry=3)
    assert s.adapters["https://"].max_retries.total == 3
    assert s.adapters["http://"].max_retries.total == 3
    s = build_requests_session(retry=Retry(total=9))
    assert s.adapters["https://"].max_retries

# Generated at 2022-06-12 06:39:28.929434
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Create a dummy logger for LoggedFunction.__call__ unit test
    :return: Dummy loger
    """
    class DummyLogger:
        def __init__(self):
            self._debug_buffer = []

        def debug(self, msg):
            self._debug_buffer.append(msg)

        def clear(self):
            self._debug_buffer = []

    def dummy_function(a, b, c="c"):
        return a, b, c

    logger = DummyLogger()
    logged_function = LoggedFunction(logger)

    # Unit test for single parameter
    logged_function(dummy_function)(1)
    assert logger._debug_buffer[0] == "'1' -> (1,)"
    logger.clear()

    # Unit test for double parameter

# Generated at 2022-06-12 06:39:40.145354
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    def method(a, b, c="c"):
        return (a, b, c)

    logger = Logger()
    f = LoggedFunction(logger)
    method = f(method)
    method(1,2)
    method(1,2, 3)
    method(1,2, c=3)
    assert logger.logs[0] == "method(1, 2, c='c')"
    assert logger.logs[1] == "method -> (1, 2, 'c')"
    assert logger.logs[2] == "method(1, 2, 3)"

# Generated at 2022-06-12 06:39:50.902573
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging, io, sys

    # A fake logger so we can test that it was passed the correct messages
    class FakeLogger:
        def __init__(self):
            self.captured_output = io.StringIO()
            self.handler = logging.StreamHandler(self.captured_output)
            self.logger = logging.getLogger("FakeLogger")
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            self.handler.close()
            self.captured_output.close()


# Generated at 2022-06-12 06:39:56.769799
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Create a stream handler to write log entries to
    file_handler = logging.StreamHandler()
    file_handler.setLevel(logging.DEBUG)

    # Set the format of the log entry
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    file_handler.setFormatter(formatter)

    # Add file handler to logger so it can write log entries to file
    logger.addHandler(file_handler)

    # Create a decorator to decorate all functions
    logged_function = LoggedFunction(logger=logger)

    # Define a function, which only print hello world

# Generated at 2022-06-12 06:40:21.658989
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs += [msg]

    logger = FakeLogger()
    decorated = LoggedFunction(logger)(sum)
    decorated(range(10))
    assert logger.logs[0] == "sum(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)"
    assert logger.logs[1] == "sum -> 45"

# Generated at 2022-06-12 06:40:32.026431
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import MagicMock

    logger = MagicMock()
    func_to_test = MagicMock()
    logged_func = LoggedFunction(logger)
    result = "result of the function to test"
    func_to_test.return_value = result
    func_to_call = logged_func(func_to_test)
    func_to_call(1, 2, 3)
    func_to_call(1, b=2, c=3)
    logger.debug.assert_any_call("func_to_test(1, 2, 3)")
    logger.debug.assert_any_call("func_to_test(1, b=2, c=3)")
    logger.debug.assert_any_call(f"func_to_test -> {result}")
   

# Generated at 2022-06-12 06:40:42.417752
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Set logging level to DEBUG
    logging.basicConfig(level=logging.DEBUG)

    # Create logger
    logger = logging.getLogger("test_LoggedFunction___call__")

    # Create decorator object
    decorator = LoggedFunction(logger)

    # Define function
    @decorator
    def my_function(parameter1, parameter2, keyword1=1, keyword2=2):
        """
        Original docstring.
        """
        pass

    # Ensure function name is logged correctly
    assert "test_LoggedFunction___call__" == logger.name

    # Check decorator does not remove __name__
    assert "my_function" == my_function.__name__

    # Check decorator does not remove docstring
    assert "Original docstring." == my_function.__doc__

# Generated at 2022-06-12 06:40:51.551339
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import random
    import string

    # Get some random inputs
    inputs = "".join(random.choice(string.ascii_letters) for _ in range(10))
    outputs = "".join(random.choice(string.ascii_letters) for _ in range(10))

    # Create a logger to capture debug messages
    handler = logging.StreamHandler()
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Set up the logged function
    @LoggedFunction(logger)
    def test_function(a, b):
        return f"{a}-{b}-{outputs}"

    # Call the function
    test_function(inputs, "hello")

    # Check the log entries

# Generated at 2022-06-12 06:40:58.926645
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    logger = logging.getLogger()

    @LoggedFunction(logger)
    def add(x, y=1):
        return x + y

    @LoggedFunction(logger)
    def add_non(x, y=1):
        print(x + y)

    for handler in logger.handlers:
        logger.removeHandler(handler)
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    add(1)
    add(2, 3)
    add(1, y=2)
    add_non(1)
    add_non(2, 3)


# Generated at 2022-06-12 06:41:10.010865
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestClass:
        def __init__(self):
            self.logger = logging.getLogger()
            self.logged_function = LoggedFunction(self.logger)

        @LoggedFunction(logger=logging.getLogger())
        def test_function(self):
            pass

        def test_function_with_args(self, arg1, arg2):
            pass

        def test_function_with_kwargs(self, kwarg1, kwarg2):
            pass

    test_obj = TestClass()
    # test without args
    test_obj.logged_function.__call__(test_obj.test_function)()

    # test with args
    test_obj.logged_function.__call__(test_obj.test_function_with_args)(1, 2)



# Generated at 2022-06-12 06:41:11.284144
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)

# Generated at 2022-06-12 06:41:16.652969
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    LoggedFunction(logger)(lambda: None)()  # lambda: None is a function without parameters and return value
    LoggedFunction(logger)(sum)(1, 2)
    LoggedFunction(logger)(sum)((1, 2))
    LoggedFunction(logger)(lambda a, b: None)(1, 2)

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-12 06:41:22.394858
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import sys
    import io
    import logging

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_func(self):
            logged = LoggedFunction(logging.getLogger(__name__))
            s = io.StringIO()
            h = logging.StreamHandler(s)
            h.setLevel(logging.DEBUG)
            logging.getLogger(__name__).addHandler(h)
            logging.getLogger(__name__).setLevel(logging.DEBUG)
            @logged
            def foo(bar, baz):
                return bar + baz

            foo(2, 3)
            self.assertEqual(s.getvalue(), "foo(2, 3)\nfoo -> 5\n")


# Generated at 2022-06-12 06:41:31.244450
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock as mock
    mock_logger = mock.create_autospec(__name__="mock_logger")
    func = mock.MagicMock(name="mock_func")
    func.__name__ = "mock_called_func"
    func.return_value = "mock_func_return_value"
    logged_function = LoggedFunction(mock_logger)
    logged_func = logged_function(func)
    logged_func(1, 2, 3, kwarg1="kwarg1", kwarg2="kwarg2")
    mock_logger.debug.assert_called_with(
        "mock_called_func(1, 2, 3, kwarg1='kwarg1', kwarg2='kwarg2')"
    )
    mock

# Generated at 2022-06-12 06:42:18.900934
# Unit test for function build_requests_session
def test_build_requests_session():
    r = build_requests_session()

    try:
        r.get("https://httpbin.org/status/401")
        assert False, "Failed to get 401 error"
    except Exception:
        pass

    r = build_requests_session(raise_for_status=False)
    r.get("https://httpbin.org/status/401")

    r = build_requests_session(retry=False)
    r.get("https://httpbin.org/status/404")

    r = build_requests_session(retry=2)
    r.get("https://httpbin.org/status/404")

    r = build_requests_session(retry=Retry(2))
    r.get("https://httpbin.org/status/404")



# Generated at 2022-06-12 06:42:21.576001
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def debug(self, msg):
            pass
    func = LoggedFunction(Logger())(lambda x, y, z=3: None)
    func(1, 2)
    func(1, 2, 3)
    func(1, y=2, z=3)

# Generated at 2022-06-12 06:42:31.565763
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    logger = logging.getLogger("test_LoggedFunction___call__")
    logger.setLevel(logging.DEBUG)
    # StreamHandler is used to display log in terminal
    ch = logging.StreamHandler()
    # add handler to logger instance
    logger.addHandler(ch)

    def test_func(arg1, arg2, kwarg1="kw_default_value", kwarg2="kw_default_value"):
        return f"{arg1},{arg2},{kwarg1},{kwarg2}"

    logged_func = LoggedFunction(logger)(test_func)
    # Test for different case of argument
    assert logged_func("arg1", "arg2") == "arg1,arg2,kw_default_value,kw_default_value"

# Generated at 2022-06-12 06:42:40.158504
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    # Create logger and set stream to stdout
    logger = logging.getLogger(__name__)
    handler = logging.StreamHandler(sys.stdout)

    # Configure logger for unit test
    logger.setLevel(logging.DEBUG)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Create LoggedFunction object
    LF = LoggedFunction(logger)
    """
    __call__(func) calls the wrapped function and logs the arguments and the return value of the function,
    then returns the return value of the function.
    """

    # Test case 1: function with return value
    @LF
    def foo(a):
        return