

# Generated at 2022-06-21 20:46:25.707989
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger

    some_function = LoggedFunction(getLogger("test"))(lambda x, y=2: x + y)
    assert some_function(2, 3) == 5
    assert some_function(4, 6) == 10
    assert some_function(4) == 6

    some_function = LoggedFunction(getLogger("test"))(lambda x, y=2: x - y)
    assert some_function(2, 3) == -1
    assert some_function(6, 5) == 1
    assert some_function(7) == 5

# Generated at 2022-06-21 20:46:28.272058
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('this is a string') == "'this is a string'"
    assert format_arg(5) == '5'



# Generated at 2022-06-21 20:46:37.303034
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    import logging.handlers
    import sys

    class TestLogger(logging.getLoggerClass()):
        """
        Simple logger that can capture log messages and make them available for
        testing.
        """

        def __init__(self):
            super().__init__("TEST")
            self.propagate = False
            self.messages = []

        def callHandlers(self, record):
            self.messages.append(record.getMessage())

    class LoggedFunctionTest(unittest.TestCase):
        def setUp(self):
            self.logger = TestLogger()
            self.logged_function = LoggedFunction(self.logger)


# Generated at 2022-06-21 20:46:45.958864
# Unit test for function build_requests_session
def test_build_requests_session():
    # test for success
    build_requests_session(True, False)
    build_requests_session(True, 1)
    build_requests_session(True, Retry())
    build_requests_session(True)

    # test for failure
    try:
        build_requests_session(True, "")
        raise Exception("build_requests_session should not accept str")
    except ValueError:
        pass
    try:
        build_requests_session(True, [])
        raise Exception("build_requests_session should not accept list")
    except ValueError:
        pass

# Generated at 2022-06-21 20:46:52.997585
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert session.max_retries.total == 1
    session = build_requests_session(retry=5)
    assert session.max_retries.total == 5
    session = build_requests_session(retry=Retry(5))
    assert session.max_retries.total == 5



# Generated at 2022-06-21 20:46:58.200086
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class MyLogger:
        def debug(self, s):
            print(s)
    logger = MyLogger()
    a = 123
    b = "abc"
    c = "def"
    d = "ghi"
    g = LoggedFunction(logger)
    @g
    def f(a, b, c=c, *args, **kwargs):
        return 1
    f(a, b=b, d=d)

# Generated at 2022-06-21 20:47:01.982992
# Unit test for function format_arg
def test_format_arg():
    assert(format_arg("f") == "'f'")
    assert(format_arg(4) == "4")
    assert(format_arg(4.1) == "4.1")



# Generated at 2022-06-21 20:47:02.927500
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session() # type: ignore

# Generated at 2022-06-21 20:47:07.582841
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    def add(a, b):
        return a + b

    logging_add = LoggedFunction(logger)(add)
    res = logging_add(1, 2)
    assert res == 3

# Generated at 2022-06-21 20:47:16.709393
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    import unittest.mock

    # Create Mock logger
    mock_logger = unittest.mock.create_autospec(logging.Logger)

    # Create Mock function
    mock_function = unittest.mock.MagicMock()
    mock_function.__name__ = "dummy_function"

    # Create LoggedFunction object
    log_function = LoggedFunction(mock_logger)

    # Call __call__
    function = log_function(mock_function)

    # Call dummy function
    function(1, 2, 3)

    # Assert the mock logger have been called with correct log message
    mock_logger.debug.assert_called_with("dummy_function(1, 2, 3)")

    # Call dummy function

# Generated at 2022-06-21 20:47:29.208240
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create mock logger
    logger = MagicMock()
    def fake_debug(msg):
        logger.msg = msg
    logger.debug = fake_debug

    # Create function to test
    def fake_func(*args, **kwargs):
        return f"<{args}> <{kwargs}>"
    logged_func = LoggedFunction(logger)
    logged_func = logged_func(fake_func)

    # Run logged_func
    result = logged_func(1, 2, x=3, y=4)

    # Verify
    assert result == "<(1, 2)> <{'x': 3, 'y': 4}>"
    assert logger.msg == "fake_func(1, '2', x='3', y='4')"

# Generated at 2022-06-21 20:47:33.714192
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("ABC") == "'ABC'"
    assert format_arg(" ABC ") == "' ABC '"
    assert format_arg("1") == "'1'"
    assert format_arg(2) == "2"

# Generated at 2022-06-21 20:47:37.686362
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == '123'
    assert format_arg(123.456) == '123.456'
    assert format_arg('abc') == "'abc'"
    assert format_arg('   abc  ') == "'abc'"
    assert format_arg(None) == 'None'

# Generated at 2022-06-21 20:47:45.007558
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(True)
    assert isinstance(s, Session)
    s.get("https://baidu.com")
    s.get("https://github.com")
    s.post("https://github.com")
    s.post("https://github.com")
    s.get("https://www.bing.com/search?q=test")
    try:
        s.get("https://github.com/error")
    except Exception as e:
        assert True

    s = build_requests_session(False)
    s.get("https://baidu.com")
    s.get("https://github.com")
    s.post("https://github.com")
    s.post("https://github.com")

# Generated at 2022-06-21 20:47:49.211440
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = None
    logger = LoggedFunction(logger)
    def func(args, kwargs):
        return None
    assert func(0, 0) == None

# Generated at 2022-06-21 20:47:59.176960
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest import TestCase

    class TestLoggedFunction(TestCase):
        def testLoggedFunction(self):
            from logging import getLogger
            from unittest.mock import MagicMock, call

            logger = getLogger("TestLoggedFunction")
            logger.level = 2
            logger_method = MagicMock()
            logger.debug = logger_method
            # @LoggedFunction(logger)
            # def my_function(a, b, c, d=10, e=20):
            #     pass
            # my_function(1, 2, 3)
            logged_function = LoggedFunction(logger)
            logged_my_function = logged_function(my_function)
            logged_my_function(1, 2, 3)
            # Verify Log
            logger_method.assert_has_

# Generated at 2022-06-21 20:48:05.489140
# Unit test for function format_arg
def test_format_arg():
    assert(format_arg(1) == "1")
    assert(format_arg("abc") == "'abc'")
    assert(format_arg("'abc'") == "'abc'")
    assert(format_arg("'''abc'''") == "'abc'")
    assert(format_arg("   abc   ") == "'abc'")


# Generated at 2022-06-21 20:48:14.052973
# Unit test for function build_requests_session
def test_build_requests_session():
    from urllib3.exceptions import MaxRetryError

    # test with raise_for_status=False, retry=True
    session = build_requests_session(False)
    response = session.get("https://www.google.com")
    assert response.status_code == 200

    # test with raise_for_status=True
    session = build_requests_session()
    response = session.get("https://www.google.com")
    assert response.status_code == 200

    # test with retry=int
    session = build_requests_session(retry=1)
    try:
        session.get("https://www.google.com/wrong")
    except MaxRetryError:
        pass
    else:
        raise Exception("expected MaxRetryError")

    # test with retry=Ret

# Generated at 2022-06-21 20:48:15.716962
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(logging.getLogger(__name__)).logger.name == __name__



# Generated at 2022-06-21 20:48:27.299525
# Unit test for function build_requests_session
def test_build_requests_session():
    from threading import Thread

    from flask import Flask, request
    from requests.exceptions import ReadTimeout, ConnectTimeout

    # create a flask app to test
    app = Flask(__name__)

    @app.route("/hello")
    def hello():
        return "hello"

    server = Thread(target=app.run, kwargs={"host": "127.0.0.1", "port": "8000"})
    server.start()

    # test normal request
    session = build_requests_session()
    request_url = "http://127.0.0.1:8000/hello"
    assert session.get(request_url).text == "hello"

    # test raise_for_status
    session = build_requests_session(raise_for_status=False)

# Generated at 2022-06-21 20:49:24.425503
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger("a")

    @LoggedFunction(logger)
    def test():
        return None

    test()

    @LoggedFunction(logger)
    def test1(a):
        return a

    test1(1)
    test1("b")

    @LoggedFunction(logger)
    def test2(a, b):
        return a + b

    test2(1, 2)
    test2("a", "b")

    @LoggedFunction(logger)
    def test3(a=1, c=None):
        return a+c

    test3()
    test3(1, 2)
    test3(c=2)

# Generated at 2022-06-21 20:49:35.926055
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    # Set up testing logger
    test_logger = logging.getLogger("tests.test_logged_function")
    test_logger.setLevel(logging.DEBUG)
    test_logger.addHandler(logging.StreamHandler())

    # Test with a function that has no return value
    @LoggedFunction(logger=test_logger)
    def test_no_return_value(a, b):
        pass

    # Test calling the function with no arguments
    test_no_return_value()

    # Test calling the function with one argument
    test_no_return_value(1)

    # Test calling the function with two arguments
    test_no_return_value(1, 2)

    # Test calling the function with two arguments and keyword arguments

# Generated at 2022-06-21 20:49:40.637202
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session
    session = build_requests_session(raise_for_status=False)
    assert session
    session = build_requests_session(retry=False)
    assert session
    session = build_requests_session(retry=Retry())
    assert session

# Generated at 2022-06-21 20:49:48.003324
# Unit test for function build_requests_session
def test_build_requests_session():
    # raise_for_status
    session = build_requests_session(raise_for_status=True)
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}
    session = build_requests_session(raise_for_status=False)
    assert "response" not in session.hooks
    # retry
    session = build_requests_session(raise_for_status=True, retry=True)
    assert session.adapters["https://"].max_retries.total == 3
    session = build_requests_session(raise_for_status=True, retry=5)
    assert session.adapters["https://"].max_retries.total == 5
    with pytest.raises(ValueError):
        session = build_

# Generated at 2022-06-21 20:49:58.084166
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)

    def my_func(a, b, c=4):
        return None

    wrapped = LoggedFunction(logger)(my_func)
    wrapped(1,2)
    wrapped(1,2,c=3)

    with patch.object(logger, 'debug'):
        wrapped(1,2)
        assert logger.debug.call_count == 1
        assert logger.debug.call_args[0][0] == "my_func(1, 2)"
        wrapped(1,2,c=3)
        assert logger.debug.call_count == 2
        assert logger.debug.call_args[0][0] == "my_func(1, 2, c=3)"

# Generated at 2022-06-21 20:49:59.534744
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None


# Generated at 2022-06-21 20:50:00.352170
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    pass



# Generated at 2022-06-21 20:50:11.026707
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    import logging
    import tests.src.common.utils as utils

    # Set up logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # Set up mock logger
    mock_logger = unittest.mock.MagicMock()
    logger.handlers = [utils.MockLoggingHandler(mock_logger)]
    # Set up LoggedFunction instance
    logged_function = LoggedFunction(logger)

    def test_function():
        # Do some stuff
        return "Test output"

    # Call test_function decorated with LoggedFunction
    logged_function(test_function)()
    # Check that logger was called twice
    assert mock_logger.call_count == 2
    # Get all logger calls
    mock_

# Generated at 2022-06-21 20:50:18.230501
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import time
    import unittest

    # Set up test logging
    logging.getLogger().setLevel(logging.DEBUG)
    logged_function = LoggedFunction(logger=logging.getLogger())

    # Define test functions
    @logged_function
    def increment(x):
        return x + 1

    @logged_function
    def foo():
        return "bar"

    @logged_function
    def add(x, y):
        return x + y

    @logged_function
    def wait_and_return(x, seconds):
        time.sleep(seconds)
        return x

    # Create test class
    class LoggedFunctionTest(unittest.TestCase):
        def test_increment(self):
            self.assertEqual(increment(0), 1)

# Generated at 2022-06-21 20:50:21.008963
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("ABC") == "'ABC'"
    assert format_arg(" ABC ") == "' ABC '"
    assert format_arg(100) == "100"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:50:41.646058
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=Retry())
    assert session.adapters['http://'].max_retries.total == Retry().total
    assert session.adapters['https://'].max_retries.total == Retry().total

    session = build_requests_session(retry=Retry(total=10))
    assert session.adapters['http://'].max_retries.total == 10
    assert session.adapters['https://'].max_retries.total == 10

    session = build_requests_session(retry=True)
    assert session.adapters['http://'].max_retries.total == Retry().total
    assert session.adapters['https://'].max_retries.total == Retry().total


# Generated at 2022-06-21 20:50:44.961404
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    class DummyLogger:
        def debug(self, x):
            pass

    mocked_logger = Mock(DummyLogger)
    loggedfunction = LoggedFunction(mocked_logger)
    @loggedfunction
    def loggedfunc():
        pass

    loggedfunc()
    mocked_logger.debug.assert_called_once_with("loggedfunc()")


# Generated at 2022-06-21 20:50:51.682926
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def debug(self, msg):
            self._msg = msg

    fake_logger = FakeLogger()

    @LoggedFunction(fake_logger)
    def fun(x, y, z=3, **kwargs):
        pass

    fun(1, 2, w=3, v=4)
    assert fake_logger._msg == "fun(1, 2, z=3, w=3, v=4)"

# Generated at 2022-06-21 20:50:55.610574
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Constructor
    logger = logging.getLogger("test_LoggedFunction")
    log = LoggedFunction(logger)

    # Test function
    def test_function(x, y=1):
        return x * y

    # Function with debug logger
    logged_function = log(test_function)
    logged_function(5, y=5)
    logged_function(5)

# Generated at 2022-06-21 20:50:59.623440
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('hello "world"') == "'hello \"world\"'"
    assert format_arg('hello "world"') == "'hello \"world\"'"
    assert format_arg(666) == "666"
    assert format_arg(3.14) == "3.14"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:51:09.307912
# Unit test for function build_requests_session
def test_build_requests_session():
    raise_for_status = True
    retry = True
    session = build_requests_session(raise_for_status, retry)
    assert session.hooks['response'][0](requests.Response()) == None

    raise_for_status = False
    retry = 3
    session = build_requests_session(raise_for_status, retry)
    assert session.hooks == dict()
    assert session.adapters['http://'].max_retries.total == 3
    assert session.adapters['https://'].max_retries.total == 3

# Generated at 2022-06-21 20:51:16.945940
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    logger = Mock()
    debug = logger.debug
    logged_func = LoggedFunction(logger)(lambda x, y, z=1: x + y + z)

    # Call the logged function
    logged_func(1, 2)
    logged_func(1, 2, 3)
    logged_func(1)

    # Check the output
    expected_args = ["lambda(1, 2)", "lambda(1, 2, z=3)", "lambda(1)"]
    debug.assert_has_calls([Mock(call=arg) for arg in expected_args])



# Generated at 2022-06-21 20:51:26.562595
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import PreparedRequest, Response
    from requests.sessions import merge_setting
    from urllib3.response import HTTPResponse

    assert build_requests_session().hooks == {}

    assert build_requests_session(raise_for_status=True).hooks == {
        "response": [lambda r, *args, **kwargs: r.raise_for_status()]
    }

    assert build_requests_session(False).hooks == {}

    # test default retry
    session = build_requests_session(retry=True)
    request = PreparedRequest()
    request.prepare_url("http://localhost", {})
    request.prepare_body("GET")
    request.prepare_headers(merge_setting(session.headers, {}))
    response = session.send

# Generated at 2022-06-21 20:51:37.788000
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import pytest
    from logging.config import dictConfig
    from io import StringIO


# Generated at 2022-06-21 20:51:46.440098
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # mock calls to logger and func
    logger = mock.MagicMock()
    func = mock.MagicMock()

    # creating instance of LoggedFunction
    logged_func = LoggedFunction(logger)

    # all of these are input arguments passed to __call__ method
    args = ["arg1", "arg2"]
    kwargs = {"arg3": 3, "arg4": "four"}

    # call __call__ method
    logged_func.__call__(func)(*args, **kwargs)

    # test if logger.debug was called with the right string

# Generated at 2022-06-21 20:52:31.386039
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test the __call__ method of class LoggedFunction.
    """
    def orig_func(x, y=10):
        """
        Original func.

        :param x: input x.
        :param y: input y, default=10.
        :return: x + y.
        """
        return x + y

    logger = logging.getLogger()
    logged_func = LoggedFunction(logger)(orig_func)
    assert logged_func.__name__ == "orig_func"
    assert logged_func.__doc__ == "Original func."

    # Format: <logger name>.<level name>: <message>
    with patch("logging.Logger.debug") as mock_debug:
        logged_func(1, 2)

# Generated at 2022-06-21 20:52:40.840834
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    x = LoggedFunction(logging.debug)
    assert (
        x.__call__(lambda a,b: a+b)(1,2)
        == LoggedFunction.__call__(x)(lambda a,b: a+b)(1,2)
    )
    assert (
        x.__call__(lambda a,b,c=3: a+b+c)(2,3)
        == LoggedFunction.__call__(x)(lambda a,b,c=3: a+b+c)(2,3)
    )
    assert (
        x.__call__(lambda a,b,c=3: a+b+c)(2,3,4)
        == LoggedFunction.__call__(x)(lambda a,b,c=3: a+b+c)(2,3,4)
    )


# Generated at 2022-06-21 20:52:47.186102
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger
    from io import StringIO
    from contextlib import redirect_stdout

    # Create logger to capture output
    logger = getLogger("testlogger")
    str_stream = StringIO()
    logger.addHandler(logging.StreamHandler(str_stream))

    # Inject logger into decorator
    logfunc = LoggedFunction(logger)

    @logfunc
    def test_function(test_arg, test_kwarg="default"):
        return f"output: {test_arg} {test_kwarg}".strip()

    # Call test function and capture output
    with redirect_stdout(str_stream):
        test_function("test", test_kwarg="argument")

    # Ensure output is as expected
    output = str_stream.getvalue()


# Generated at 2022-06-21 20:52:55.468820
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def my_logger(arg):
        print(arg)
    my_logger.debug = my_logger

    @LoggedFunction(my_logger)
    def test1(arg1, arg2=None, arg3="hello"):
        return 42

    @LoggedFunction(my_logger)
    def test2():
        return "test2"

    test1(1, 2, arg3=3)
    test2()

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-21 20:52:58.695217
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logging.basicConfig(level=logging.DEBUG)
    logger=logging.getLogger('logger')

    @LoggedFunction(logger)
    def return_value():
        return 5

    return_value()



if __name__ == "__main__":
    test_LoggedFunction()

# Generated at 2022-06-21 20:53:03.841554
# Unit test for function format_arg
def test_format_arg():
    # Test str
    assert '"hello, world"' == format_arg("hello, world")
    assert "'hello, world'" == format_arg('hello, world')

    # Test int
    assert "123" == format_arg(123)

    # Test float
    assert "123.45" == format_arg(123.45)

# Generated at 2022-06-21 20:53:13.158042
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session(raise_for_status=True, retry=True)
    assert "response" in sess.hooks
    assert sess.mounts["http://"][0].max_retries.total == 3
    assert sess.mounts["https://"][0].max_retries.total == 3

    sess = build_requests_session(raise_for_status=True, retry=1)
    assert sess.mounts["http://"][0].max_retries.total == 1

    sess = build_requests_session(raise_for_status=False, retry=True)
    assert "response" not in sess.hooks
    assert sess.mounts["http://"][0].max_retries.total == 3
    assert sess.mounts

# Generated at 2022-06-21 20:53:24.931886
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLoggingHandler(logging.Handler):
        records = []

        def emit(self, record):
            self.records.append(record)

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(FakeLoggingHandler())

    @LoggedFunction(logger)
    def foo(*args, **kwargs):
        return (args, kwargs)

    foo("a", "b", c="d")
    assert len(logger.handlers[0].records) == 2
    assert logger.handlers[0].records[0].msg == "foo('a', 'b', c='d')"

# Generated at 2022-06-21 20:53:28.198391
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s, Session)
    s.close()



# Generated at 2022-06-21 20:53:37.117123
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Testing function __call__ of class LoggedFunction
    # Arrange
    def function_name(*args, **kwargs):
        return

    class dummy_logger:
        def debug(self, message):
            print(message)

    dummy_logger = dummy_logger()

    dummy_logger.debug = lambda message: print(message)

    # Act
    dummy_func = LoggedFunction(dummy_logger)(function_name)

    # Assert
    dummy_func()
    dummy_func(1)
    dummy_func(2, 3)
    dummy_func(x=1)
    dummy_func(x=2, y=3)
    dummy_func(1, x=1)
    dummy_func(1, 2, x=1, y=2)

# Generated at 2022-06-21 20:54:44.304995
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import Response
    from requests.adapters import HTTPAdapter

    response = Response()
    response.status_code = 200
    session = build_requests_session()
    adapter = session.adapters["http://"]
    assert isinstance(adapter, HTTPAdapter)
    assert adapter.max_retries.total == 10
    response = session.get("http://example.com")
    assert response.status_code == 200
    assert isinstance(response, Response)
    session = build_requests_session(retry=False)
    adapter = session.adapters["http://"]
    assert isinstance(adapter, HTTPAdapter)
    assert adapter.max_retries.total == 0
    session = build_requests_session(retry=1)
    adapter = session.adapters["http://"]

# Generated at 2022-06-21 20:54:51.822404
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hello") == "'hello'"
    assert format_arg("hello 'world'") == "'hello 'world''"
    assert format_arg("''") == "''''"
    assert format_arg(" ' ' ") == " ' ' "
    assert format_arg(1) == "1"
    assert format_arg(2.2) == "2.2"
    assert format_arg(None) == 'None'
    assert format_arg(True) == "True"
    assert format_arg({"test:test"}) == "{'test:test'}"

# Generated at 2022-06-21 20:54:57.238821
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    from unittest.mock import Mock, call
    with unittest.mock.patch("hug.logging.logged_function.logger") as mock_logger:
        @LoggedFunction(mock_logger)
        def example_func(arg, kwarg=None):
            pass
        example_func(42, kwarg="woah")
        mock_logger.debug.assert_called_once_with("example_func(42, kwarg='woah')")



# Generated at 2022-06-21 20:55:08.826702
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from tempfile import TemporaryFile
    from logging import Logger, DEBUG, INFO, basicConfig
    from functools import reduce

    class TestLogger(Logger):
        """
        Custom logger used to test LoggedFunction.
        """

        def __init__(self):
            super().__init__("test")
            self.handlers = [TemporaryFile()]

        @property
        def output(self):
            """
            Return the output of the log handlers as a string.
            """
            return reduce(lambda x, y: x + y, [x.read().decode() for x in self.handlers])

    # Create test logger
    logger = TestLogger()
    logger.setLevel(DEBUG)
    basicConfig(level=INFO)

    # Create LoggedFunction instance
    logged = LoggedFunction(logger)

    #

# Generated at 2022-06-21 20:55:15.195157
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    from unittest.mock import patch

    class Tests(unittest.TestCase):
        def test_LoggedFunction___call__(self):
            from contextlib import contextmanager
            from io import StringIO

            @contextmanager
            def captured_output():
                new_out, new_err = StringIO(), StringIO()
                old_out, old_err = sys.stdout, sys.stderr
                try:
                    sys.stdout, sys.stderr = new_out, new_err
                    yield sys.stdout, sys.stderr
                finally:
                    sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-21 20:55:23.017855
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import Logger, DEBUG, getLogger
    from unittest.mock import Mock

    logger = Mock(Logger, name="logger")
    logger.debug = Mock()

    def func(foo, bar):
        print(f"func({foo}, {bar})")
        return foo + bar

    logged_func = LoggedFunction(logger)(func)

    logged_func(1, 2)

    logger.debug.assert_any_call("func(1, 2)")
    logger.debug.assert_any_call("func -> 3")

# Generated at 2022-06-21 20:55:26.828955
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('no quotes needed') == "no quotes needed"
    assert format_arg('but quotes are needed here') == "'but quotes are needed here'"
    assert format_arg(100) == '100'
    assert format_arg(3.14159) == '3.14159'
    assert format_arg(True) == 'True'
    assert format_arg(False) == 'False'


# Generated at 2022-06-21 20:55:27.799316
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-21 20:55:30.665845
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("foo") == "'foo'"
    assert format_arg(1) == "1"
    assert format_arg(None) == "None"


# Generated at 2022-06-21 20:55:31.913464
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger('test')
    test = LoggedFunction(logger)
    assert test.logger == logger