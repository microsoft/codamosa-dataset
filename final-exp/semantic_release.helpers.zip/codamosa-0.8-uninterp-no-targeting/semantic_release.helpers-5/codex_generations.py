

# Generated at 2022-06-21 20:46:27.325586
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # Create handler
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    # Create formatter and add it to the handler
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    handler.setFormatter(formatter)
    # Add handler to the logger
    logger.addHandler(handler)

    # Unit test
    @LoggedFunction(logger)
    def add_function(x, y):
        return x + y

    @LoggedFunction(logger)
    def add_function_kwargs(x, y):
        return x + y


# Generated at 2022-06-21 20:46:32.641270
# Unit test for function format_arg
def test_format_arg():
    assert "1" == format_arg(1)
    assert "'my string'" == format_arg("my string")
    assert "'my string'" == format_arg("my string ")
    assert "'my string'" == format_arg(" my string")
    assert "'my string'" == format_arg(" my string ")



# Generated at 2022-06-21 20:46:42.586515
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger(__name__)

    def simple_function(num):
        return num + 1

    simple_function_decorator = LoggedFunction(logger)

    simple_function_decorated = simple_function_decorator(simple_function)

    ret = simple_function_decorated(num=10)

    assert ret == 11
    assert simple_function != simple_function_decorated
    assert simple_function.__name__ == simple_function_decorated.__name__
    assert simple_function.__doc__ == simple_function_decorated.__doc__



# Generated at 2022-06-21 20:46:49.420928
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class MockLogger:
        def __init__(self):
            self.last_message = None

        def debug(self, msg):
            self.last_message = msg

    logger = MockLogger()

    @LoggedFunction(logger=logger)
    def func(a, b, c=20, d="hi"):
        return a

    assert logger.last_message is None
    func(a=10, b=30)
    assert logger.last_message == "func(10, 30, c=20, d='hi')"
    func(20, 40, d="hello")
    assert logger.last_message == "func(20, 40, c=20, d='hello')"

# Generated at 2022-06-21 20:46:51.946021
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(10) == "10"
    assert format_arg("abc") == "'abc'"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:46:56.290750
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from src.test.test_logger import TestLogger

    tl = TestLogger()
    Log = LoggedFunction(tl)
    @Log
    def my_function():
        return 'hello world'

    my_function()
    assert tl.log[len(tl.log) - 1] == 'my_function() -> hello world'



# Generated at 2022-06-21 20:46:59.708114
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('a=b') == "'a=b'"
    assert format_arg([1,2]) == "[1, 2]"
    assert format_arg(1) == "1"


# Generated at 2022-06-21 20:47:04.411677
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    Create a logging function to use.
    :return: create a logging function for testing.
    """
    logger = logging.getLogger(__name__ + ".TEST")
    logger.setLevel(logging.DEBUG)
    return LoggedFunction(logger)



# Generated at 2022-06-21 20:47:14.697916
# Unit test for function build_requests_session
def test_build_requests_session():
    # create a requests session that raise_for_status
    session = build_requests_session(raise_for_status=True)
    try:
        session.get("http://httpbin.org/status/404")
    except Exception as e:
        assert isinstance(e, requests.exceptions.HTTPError)
        # print(f"got exception {e}")
    
    # create a requests session that not raise_for_status
    session = build_requests_session(raise_for_status=False)
    response = session.get("http://httpbin.org/status/404")
    assert response.status_code == 404

    # create a requests session that will retry 3 times
    session = build_requests_session(retry=3)

# Generated at 2022-06-21 20:47:18.284847
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def foo(x, y):
        return x * y

    @LoggedFunction(logger)
    def bar():
        return "hello"

    assert foo(3, 4) == 12
    assert bar() == "hello"



# Generated at 2022-06-21 20:47:30.266462
# Unit test for function build_requests_session
def test_build_requests_session():
    from time import time
    from urllib.parse import urljoin

    from .api import get_metadata

    session = build_requests_session(retry=3, raise_for_status=True)

    t = time()
    get_metadata(session, urljoin("http://example.com?retry=3", "dns-fail"))
    assert int(time()) - t >= 3

    t = time()
    get_metadata(session, urljoin("http://example.com?retry=3", "connection-fail"))
    assert int(time()) - t >= 9

    try:
        get_metadata(session, urljoin("http://example.com?retry=3", "raise-exception"))
        assert False
    except Exception:
        pass

    assert get_metadata(session, "http://example.com").status

# Generated at 2022-06-21 20:47:33.762406
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('test') == "'test'"
    assert format_arg(None) == 'None'

# Generated at 2022-06-21 20:47:39.090968
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.2) == "1.2"
    assert format_arg("") == "''"
    assert format_arg("a") == "'a'"
    assert format_arg("a b") == "'a b'"
    assert format_arg(1j) == "1j"


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-21 20:47:44.352344
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """Test case for constructor of class LoggedFunction."""
    def f(x, y):
        return x + y
    logger = {}
    logger["debug"] = lambda *args: args
    logger["debug"].__name__ = "debug"
    g = LoggedFunction(logger)
    h = g(f)
    h(1, 2)
    assert len(logger["debug"]()) == 2
    assert logger["debug"]()[0] == "f(1, 2)"
    assert logger["debug"]()[1] == "f -> 3"


# Generated at 2022-06-21 20:47:46.105083
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    f = LoggedFunction('logger')
    result = f.__call__(print)
    assert result == print

# Generated at 2022-06-21 20:47:53.684393
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    # Create logger with debug set to True
    logger = logging.getLogger("test_logger")
    logger.level = logging.DEBUG
    logger.addHandler(logging.StreamHandler(sys.stdout))

    @LoggedFunction(logger)
    def my_function(param1, param2):
        return f"{param1} {param2}"

    my_function("Hello", "World")


# Generated at 2022-06-21 20:47:59.146147
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("logged.function")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    @LoggedFunction(logger)
    def func(a, b=10, c=20):
        return a + b * c
    func(1, c=10, b=0)
    func(2, 3)
    func(2)



# Generated at 2022-06-21 20:48:07.271113
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError

    session = build_requests_session()
    response = session.get("https://httpbin.org/get")
    assert response.status_code == 200

    with pytest.raises(HTTPError):
        session = build_requests_session(raise_for_status=True)
        session.get("https://httpbin.org/status/404")

    with pytest.raises(ValueError):
        session = build_requests_session(retry="I am a string")

# Generated at 2022-06-21 20:48:11.255567
# Unit test for function build_requests_session
def test_build_requests_session():
    # test creating requests session
    session = build_requests_session()
    assert isinstance(session, Session)

    # test default retry configuration
    total_retry_count = 3
    retry = Retry(total_retry_count, backoff_factor=0)
    session = build_requests_session(retry=retry)
    assert session.adapters["http://"].max_retries.total == total_retry_count
    assert session.adapters["https://"].max_retries.total == total_retry_count

    # test default retry count configuration
    total_retry_count = 3
    session = build_requests_session(retry=total_retry_count)
    assert session.adapters["http://"].max_retries.total == total_retry_count

# Generated at 2022-06-21 20:48:15.473872
# Unit test for function build_requests_session
def test_build_requests_session():
    
    # assert the function
    assert callable(build_requests_session)
    
    # assert the object returned from the function is of type requests.Session
    assert isinstance(build_requests_session(),requests.Session)
    


# Generated at 2022-06-21 20:48:25.906223
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == "5"
    assert format_arg("") == "''"
    assert format_arg("  ") == "''"
    assert format_arg("hello") == "'hello'"
    assert format_arg(" hello ") == "'hello'"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"



# Generated at 2022-06-21 20:48:27.907806
# Unit test for function build_requests_session
def test_build_requests_session():
    r = build_requests_session()
    r.get("http://www.example.org")
    r.post("http://www.example.org")

# Generated at 2022-06-21 20:48:32.417523
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == '123'
    assert format_arg('abc def') == "'abc def'"
    # Note that the string "abc 'def'" is not quoted, but will be interpreted as ['abc ', 'def']
    assert format_arg("abc 'def'") == "'abc 'def''"

# Generated at 2022-06-21 20:48:39.016491
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from unittest import TestCase
    import logging

    logger = Mock(logging.Logger)

    def func(a, b):
        pass

    logged_func = LoggedFunction.__call__(logger)(func)
    logged_func(1, 2)
    logged_func(1, b=2)
    logged_func(a=1, b=2)
    assert logger.debug.call_count == 3

# Generated at 2022-06-21 20:48:43.155146
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import Mock
    logger = Mock()
    lgf = LoggedFunction(logger)
    lgf.__call__(test_LoggedFunction)
    assert logger.debug.call_count == 1
    logger.debug.assert_called_with('test_LoggedFunction()')


# Generated at 2022-06-21 20:48:46.923404
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import sys
    logger = logging.getLogger("logged")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(stream = sys.stdout))
    @LoggedFunction(logger)
    def myfunc(str1, str2, str3):
        return str1+str2+str3

# Generated at 2022-06-21 20:48:52.420029
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("this is a string") == "'this is a string'"
    assert format_arg(["a", "b"]) == "['a', 'b']"
    assert format_arg(["a", "b'"]) == "['a', 'b\\'']"


# Generated at 2022-06-21 20:49:03.448026
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test logger
    import io
    import logging
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger("mylog")
    stream = io.StringIO()
    log.addHandler(logging.StreamHandler(stream))

    # Test function
    def foo(bar, baz):
        return True

    # Test decorator
    @LoggedFunction(log)
    def bar(baz):
        return False

    # Check that the function name and args are logged
    foo("test_value", "test_value2")
    assert "foo('test_value', 'test_value2')\nfoo -> True" in stream.getvalue()

    # Check that the function name, args and return value are logged
    bar("test_value3")

# Generated at 2022-06-21 20:49:13.069643
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from requests import Response
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    assert isinstance(build_requests_session().adapters["https://"], HTTPAdapter)
    assert isinstance(build_requests_session().adapters["http://"], HTTPAdapter)
    assert isinstance(
        build_requests_session().adapters["http://"].max_retries, Retry
    )
    assert isinstance(
        build_requests_session().adapters["https://"].max_retries, Retry
    )
    assert 3 == build_requests_session(retry=3).adapters["https://"].max_retries.total

# Generated at 2022-06-21 20:49:14.639839
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('hello\tworld') == "'hello    world'"
    assert format_arg(123) == '123'



# Generated at 2022-06-21 20:49:24.225440
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=True)
    try:
        session.get("http://t.cn")
    except Exception:
        pass

    session = build_requests_session(retry=False)
    try:
        session.get("http://t.cn")
    except Exception as e:
        print(e)
    else:
        raise ValueError("It should fail without retry")


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-21 20:49:35.927664
# Unit test for function build_requests_session
def test_build_requests_session():
    import logging
    import requests
    import requests.exceptions
    from unittest.mock import MagicMock
    s = build_requests_session(False)

    def verify_raising_for_status(s):
        response = s.get("https://www.baidu.com/")
        assert response.status_code == requests.codes.ok

    def verify_no_raising_for_status(s):
        response = s.get("https://www.baidu.com/")
        assert response.status_code == requests.codes.ok
        assert response.raise_for_status.call_count == 0

    # default should set raise_for_status as True
    verify_raising_for_status(s)

    # raise_for_status as False should disable it

# Generated at 2022-06-21 20:49:39.638627
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("  foo  ") == "'  foo  '"
    assert format_arg(5) == "5"
    assert format_arg(5.5) == "5.5"

# Generated at 2022-06-21 20:49:40.918376
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(False)
    assert isinstance(s.adapters['http://'], HTTPAdapter)
    assert isinstance(s.adapters['https://'], HTTPAdapter)

# Generated at 2022-06-21 20:49:48.182378
# Unit test for function build_requests_session
def test_build_requests_session():
    import unittest

    class MockResponse(object):
        def __init__(self, status):
            self.status_code = status

    class TestBuildRequestsSession(unittest.TestCase):
        def test_normal(self):
            session = build_requests_session()
            self.assertIsNotNone(session.hooks)
            self.assertTrue(len(list(session.hooks.keys())) > 0)

        def test_with_raise_for_status(self):
            session = build_requests_session(raise_for_status=True)
            self.assertIsNotNone(session.hooks)
            self.assertTrue(len(list(session.hooks.keys())) > 0)


# Generated at 2022-06-21 20:49:59.181701
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import pytest

    s = build_requests_session()

    # dummy https web server, which returns b'hello world'
    # use https://github.com/arp242/dummy-web-server
    s.get("http://localhost:8000")

    with pytest.raises(requests.HTTPError), pytest.raises(requests.ConnectionError):
        s.get("http://localhost:8001")

    s = build_requests_session(retry=False)

    # dummy https web server, which returns b'hello world'
    # use https://github.com/arp242/dummy-web-server
    s.get("http://localhost:8000")

    with pytest.raises(requests.ConnectionError):
        s.get("http://localhost:8001")



# Generated at 2022-06-21 20:50:09.571867
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def add(a, b):
        return a + b

    assert add(1,2) == 3
    assert add(a=4, b=3) == 7
    assert add(a=4, b=3, c=5) == 7
    assert add(1, 2, 3) == 3
    

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-21 20:50:13.358211
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

import json
filepath = './data/members.json'
with open(filepath, 'r') as f:
    info = json.load(f)
    for x in info.items():
        print(x[0])
        for y in x[1]:
            print(y)

# Generated at 2022-06-21 20:50:19.557009
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.mounts == {
        'http://': [],
        'https://': []
    }
    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    session = build_requests_session(retry=False)
    assert session.mounts == {
        'http://': [],
        'https://': []
    }
    session = build_requests_session(retry=5)

# Generated at 2022-06-21 20:50:22.433035
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(10) == '10'
    assert format_arg("Hello World!") == "'Hello World!'"


# Generated at 2022-06-21 20:50:53.745408
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest
    from io import StringIO
    from unittest.mock import MagicMock

    logger = logging.getLogger("LoggedFunction")
    logger.setLevel("DEBUG")
    stream = StringIO()
    streamHandler = logging.StreamHandler(stream)
    streamHandler.setLevel("DEBUG")
    formatter = logging.Formatter("%(levelname)s - %(message)s")
    streamHandler.setFormatter(formatter)
    logger.addHandler(streamHandler)

    @LoggedFunction(logger)
    def func1(arg1):
        return arg1

    arg1value = "aux"
    func1(arg1value)
    expected = "DEBUG - func1('aux')\nDEBUG - func1 -> aux\n"
    assert stream.getvalue()

# Generated at 2022-06-21 20:50:54.932990
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc") == "'abc'"
    assert format_arg(123) == "123"



# Generated at 2022-06-21 20:50:56.355041
# Unit test for function format_arg
def test_format_arg():
    assert '"test"' == format_arg('test'), "format_arg() is not working."



# Generated at 2022-06-21 20:50:58.475386
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import mock
    LoggedFunction(mock.MagicMock())(lambda x,y,z: True)(1,2,3)

# Generated at 2022-06-21 20:51:09.209531
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    @LoggedFunction(logger)
    def factorial(n):
        if n < 0:
            return None
        acc = 1
        for i in range(1, n + 1):
            acc *= i
        return acc
    assert factorial(3) == 6


# Generated at 2022-06-21 20:51:10.683275
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None



# Generated at 2022-06-21 20:51:18.824380
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction___call__")
    decorator = LoggedFunction(logger)

    @decorator
    def test_func_1(a, b=1, **c):
        import json

        return json.dumps({"a": a, "b": b, "c": c})

    @decorator
    def test_func_2(a):
        return a

    @decorator
    def test_func_3(a, b, c):
        return [a, b, c]

    assert test_func_1(1, 2, c=3) == '{"a": 1, "b": 2, "c": {"c": 3}}'
    assert test_func_2(1) == 1

# Generated at 2022-06-21 20:51:26.265226
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("ABC") == "'ABC'"
    assert format_arg(" ABC ") == "' ABC '"
    assert format_arg("") == "''"
    assert format_arg("    ") == "''"
    assert format_arg("123") == "123"
    assert format_arg(123) == "123"
    assert format_arg("123.45") == "123.45"
    assert format_arg("2.5") == "2.5"
    assert format_arg("123.45ABC") == "123.45ABC"
    assert format_arg("123.45ABC", "123.45") == "123.45"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:51:30.759232
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("str") == "'str'"
    assert format_arg(" str ") == "' str '"

# Generated at 2022-06-21 20:51:41.053400
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    from unittest.mock import patch

    # Get LoggingHandler object from LoggingHandler of class Logger
    logger = logging.getLogger()
    log_handler = logger.handlers[0]
    # Log string of message 'DEBUG'
    logging_output = io.StringIO()
    log_handler.stream = logging_output
    # Configure logging level to 'debug'
    logger.setLevel(logging.DEBUG)
    # Define logged function
    def logged_function(x, y):
        """
        Define logged function
        :param x: x-value
        :param y: y-value
        :return: sum of x and y
        """
        return x + y

    # Create object of LoggedFunction
    logged_function_obj = LoggedFunction(logger)



# Generated at 2022-06-21 20:51:52.925204
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock
    with unittest.mock.patch("logging.getLogger") as mock_getLogger:
        logger_instance = unittest.mock.MagicMock()
        logger_instance.debug = unittest.mock.MagicMock()
        logger_instance.debug.return_value = None
        mock_getLogger.return_value = logger_instance
        logger = mock_getLogger.return_value
        some_func = LoggedFunction(logger)
        @some_func
        def func(*args, **kwargs):
            return "func"
        func("some", "args", b = "some_thing")
        assert func("some", "args", b = "some_thing") == "func"
        assert logger.debug.call_count == 2

# Generated at 2022-06-21 20:51:57.766740
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Good morning") == "'Good morning'"
    assert format_arg(12) == "12"
    assert format_arg(None) == "None"
    try:
        format_arg(object())
    except Exception as e:
        pass
    else:
        raise ValueError("expected an exception")

# Generated at 2022-06-21 20:52:06.205111
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction
    """
    import logging
    import sys

    import pytest

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)

    test_object = LoggedFunction(logger=logger)
    result = test_object(test_method)

    # Assert method name used in log message
    assert result.__name__ == "test_method"



# Generated at 2022-06-21 20:52:10.480714
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logging import getLogger

    def foo(a, b):
        return "result"

    logger = getLogger()
    logged_foo = LoggedFunction(logger)(foo)
    assert logged_foo(2, 3) == "result"
    assert logged_foo(2, 3, debug_flag=True) == "result"



# Generated at 2022-06-21 20:52:13.265864
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test constructor of class LoggedFunction
    assert(type(LoggedFunction) == type(type))
    assert(LoggedFunction(logging.getLogger()) is not None)


# Generated at 2022-06-21 20:52:15.187486
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Hello \'World\'") == "'Hello 'World''"
    assert format_arg(3.14) == "3.14"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:52:19.190607
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc'") == "'abc'''"

# Generated at 2022-06-21 20:52:21.388008
# Unit test for function format_arg
def test_format_arg():
    assert eval(format_arg(1)) == 1
    assert eval(format_arg(1.0)) == 1.0
    assert eval(format_arg('"a"')) == '"a"'
    assert eval(format_arg('"a" ')) == '"a" '
    assert eval(format_arg(' "a"')) == ' "a"'

# Generated at 2022-06-21 20:52:24.570666
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Create mock logger
    class MockLogger:
        def debug(self, msg):
            self.msg = msg

    logger = MockLogger()
    logged_func = LoggedFunction(logger)
    def test_func(*args, **kwargs):
        return "test_return"
    logged_test_func = logged_func(test_func)
    assert logged_test_func(1, 2, ["3", "4"], kwarg1=True, kwarg2=1234) == "test_return"
    assert logger.msg == "test_func([1, 2, ['3', '4']], kwarg1=True, kwarg2=1234)"

# Generated at 2022-06-21 20:52:32.088855
# Unit test for function format_arg
def test_format_arg():
    x = 1
    assert format_arg(x) == "1"
    x = "abc"
    assert format_arg(x) == "'abc'"
    x = {
        "123": 123,
        "456": "456",
        "789": 789,
        "012": "012"
    }
    assert format_arg(x) == "{'123': 123, '456': '456', '789': 789, '012': '012'}"

# Generated at 2022-06-21 20:52:43.572904
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    test_logger = logging.getLogger('test_logger')
    test_logger.setLevel(logging.DEBUG)

    @LoggedFunction(test_logger)
    def fib(n: int) -> int:
        if n <= 0:
            return 0
        elif n == 1:
            return 1
        else:
            return fib(n - 1) + fib(n - 2)

    # Assertions
    assert fib(0) == 0
    assert fib(1) == 1
    assert fib(2) == 1
    assert fib(3) == 2
    assert fib(4) == 3
    assert fib(5) == 5



# Generated at 2022-06-21 20:52:55.923347
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging

    def test_func(arg1, arg2, arg3=None):
        return 123

    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    import pytest
    from conftest import captured_output

    with captured_output() as (out, err):
        logger.debug("before")
        try:
            LoggedFunction(logger)(test_func)("hello", "world", arg3=123)
        except Exception as e:
            pass
        logger.debug("after")

    output = out.getvalue().strip()

# Generated at 2022-06-21 20:53:01.195900
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging

    def testing_func(*args, **kwargs):
        return "success"

    def testing_func_error(*args, **kwargs):
        raise Exception("testing exception for LoggedFunction")

    class TestLoggedFunction(unittest.TestCase):
        def test_normal_call(self):
            logger = logging.getLogger("TestLoggedFunction.test_normal_call")
            logged_function = LoggedFunction(logger)
            logged_function(testing_func)()
            with self.assertRaises(Exception):
                logged_function(testing_func_error)()

    unittest.main()



# Generated at 2022-06-21 20:53:05.202942
# Unit test for function format_arg
def test_format_arg():
    assert(format_arg(1) == '1')
    assert(format_arg(None) == 'None')
    assert(format_arg('asd') == "'asd'")


# Generated at 2022-06-21 20:53:08.878595
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.23) == "1.23"
    assert format_arg("abcd") == "'abcd'"
    assert format_arg(" 'abcd' ") == "' 'abcd' '"

# Generated at 2022-06-21 20:53:12.059434
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg("1 ") == "'1 '"
    assert format_arg(" 1") == "' 1'"
    assert format_arg(" 1 ") == "' 1 '"

# Generated at 2022-06-21 20:53:14.634087
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    #Arrange
    import logging
    logger = logging.getLogger(__name__)
    # Act
    LoggedFunction(logger)(lambda x, y: print(x+y))("xx", "yy")
# Act
test_LoggedFunction___call__()

# Generated at 2022-06-21 20:53:26.073739
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import mock
    import six

    if six.PY2:
        mock_input = "__builtin__.input"
        mock_print = "__builtin__.print"
    else:
        mock_input = "builtins.input"
        mock_print = "builtins.print"

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def test(a, b, c=0, d=1):
        input()
        return a + b + c + d


# Generated at 2022-06-21 20:53:31.550120
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)

    def hello(name):
        return "Hello " + name

    logged_hello = LoggedFunction(logger)(hello)
    # Expected output to stdout:
    #     hello('world')
    #     hello -> Hello world
    logged_hello("world")

# Generated at 2022-06-21 20:53:38.454678
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=False, retry=5)
    assert isinstance(session, Session)
    assert len(session.hooks["response"]) == 0
    assert len(session.adapters) == 2
    http_adapter = session.adapters["http://"]
    assert isinstance(http_adapter, HTTPAdapter)
    assert http_adapter.max_retries.total == 5
    https_adapter = session.adapters["https://"]
    assert isinstance(https_adapter, HTTPAdapter)
    assert https_adapter.max_retries.total == 5



# Generated at 2022-06-21 20:53:50.027802
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-21 20:54:00.077158
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import io

    # Create logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Test function
    @LoggedFunction(logger)
    def add(a, b, c=None):
        return a + b + c if c else a + b

    # Call function
    add(1, 2)
    add(1, 2, 3)

    # Assert outputs
    assert stream.getvalue() == "add(1, 2)\nadd -> 3\nadd(1, 2, 3)\nadd -> 6\n"

# Generated at 2022-06-21 20:54:02.601876
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(" str  ") == "'str'"
    assert format_arg(None) == "None"


# Generated at 2022-06-21 20:54:05.977226
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger

    logger = getLogger(__name__)

    @LoggedFunction(logger)
    def test_function(a, b):
        pass

    assert test_function("a", "b") is None



# Generated at 2022-06-21 20:54:10.367802
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from unittest.mock import Mock
    logger = Mock()
    lf = LoggedFunction(logger)
    @lf
    def test_func(param1, param2):
        pass

    test_func('s1', 's2')
    logger.debug.assert_called_with("test_func('s1', 's2')")

    test_func('s1', 's2', param3='s3')
    logger.debug.assert_called_with("test_func('s1', 's2', param3='s3')")


# Generated at 2022-06-21 20:54:13.142194
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" an ' argument ") == "'an \\' argument '"
    assert format_arg(True) == "True"

# Generated at 2022-06-21 20:54:22.657749
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    class FakeLogger:
        def __init__(self):
            self.stream = io.StringIO()
            handler = logging.StreamHandler(self.stream)
            formatter = logging.Formatter("...")
            handler.setFormatter(formatter)
            self.logger = logging.getLogger("test")
            self.logger.addHandler(handler)

        def getvalue(self):
            return self.stream.getvalue()

    @LoggedFunction(FakeLogger().logger)
    def f(a, b, c="hi"):
        return "abc"

    assert f(1, 2) == "abc"

    s = FakeLogger().getvalue()

# Generated at 2022-06-21 20:54:27.263304
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock as mock

    @LoggedFunction(logger=mock.MagicMock())
    def f(a, b, *, c=1, d=2):
        return "result"

    f(1, 2, d=3)
    f.logger.debug.assert_called_once_with(
        "f(1, 2, c=1, d='3') -> 'result'"
    )

# Generated at 2022-06-21 20:54:35.683908
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hello") == "'hello'"
    assert format_arg("hello world") == "'hello world'"
    assert format_arg(" hello world \n") == "' hello world \n'"
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg([]) == "[]"
    assert format_arg({}) == "{}"
    assert format_arg([1, "hello"]) == "[1, 'hello']"
    assert format_arg({"alpha": 0, "beta": 2}) == "{'alpha': 0, 'beta': 2}"

# Generated at 2022-06-21 20:54:38.203067
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        # Test passing in a boolean
        checked_logger = LoggedFunction(True)
        assert False
    except TypeError:
        pass

    try:
        # Test passing in dict
        checked_logger = LoggedFunction({})
        assert False
    except TypeError:
        pass
    

# Generated at 2022-06-21 20:55:03.105038
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('abc') == "'abc'"
    assert format_arg('abc  ') == "'abc'"
    assert format_arg(None) == 'None'
    assert format_arg(1) == '1'
    assert format_arg(1.1) == '1.1'


# Generated at 2022-06-21 20:55:03.744821
# Unit test for function build_requests_session
def test_build_requests_session():
    pass

# Generated at 2022-06-21 20:55:11.513009
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    @LoggedFunction(log)
    def hello_world():
        print("Hello World!")

    @LoggedFunction(log)
    def hello_who(who):
        print(f"Hello {who}")

    @LoggedFunction(log)
    def add(a, b):
        return a + b

    @LoggedFunction(log)
    def add_with_kwargs(a, b, c):
        return a + b + c

    print("-- Calling hello_world() --")
    hello_world()
    print("-- Calling hello_who() --")
    hello_who("Chris")
    print("-- Calling add() --")
    print(add(1, 2))
   

# Generated at 2022-06-21 20:55:14.142665
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    def my_func(a):
        return a + 2

    func = LoggedFunction(Mock())
    wrapped_func = func(my_func)
    wrapped_func(1)

    func.logger.debug.assert_called_with("my_func(1)")



# Generated at 2022-06-21 20:55:20.285650
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('1') == "'1'"
    assert format_arg(' abc') == "' abc'"
    assert format_arg('abc ') == "'abc '"
    assert format_arg(' abc ') == "' abc '"


if __name__ == "__main__":
    test_format_arg()

# Generated at 2022-06-21 20:55:27.615119
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging
    import tempfile

    # logger
    logger = logging.getLogger("TestLogger")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # decorator
    logged_func = LoggedFunction(logger)

    # methods to be tested
    def func_without_return(arg1, arg2):
        print(f"func_without_return: ({arg1}, {arg2})")

    def func_without_return_with_kwargs(arg1, arg2, kwarg1=None):
        print(f"func_without_return_with_kwargs: ({arg1}, {arg2}, {kwarg1})")


# Generated at 2022-06-21 20:55:30.230882
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hello") == "'hello'"
    assert format_arg(123) == "123"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:55:31.770643
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("string") == "'string'"
    assert format_arg(1) == "1"

# Generated at 2022-06-21 20:55:33.504944
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg(123.456) == "123.456"
    assert format_arg("abc def") == "'abc def'"


# Generated at 2022-06-21 20:55:35.938385
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Hello World") == "'Hello World'"
    assert format_arg("Hello 'World") == "'Hello \\'World'"
    assert format_arg("Hello World\n") == "'Hello World\\n'"
    assert format_arg(123456) == "123456"