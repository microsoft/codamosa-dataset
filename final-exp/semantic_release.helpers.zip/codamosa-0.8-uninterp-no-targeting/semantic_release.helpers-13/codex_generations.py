

# Generated at 2022-06-21 20:46:15.699835
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)



# Generated at 2022-06-21 20:46:18.547801
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(10) == "10"
    assert format_arg(0.01) == "0.01"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg('   ') == "'   '"
    assert format_arg('"') == "'\"'"

# Generated at 2022-06-21 20:46:19.539027
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    instance: LoggedFunction = LoggedFunction(logger=None)
    assert instance is not None

# Generated at 2022-06-21 20:46:29.074157
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase
    from logga import Logga

    # Mock arguments and result
    mock_args = (1, 2, 3)
    mock_kwargs = {"arg4": "arg4", "arg5": "arg5"}
    mock_result = True

    logger = Logga(name="testLoggedFunction___call__", level="DEBUG")

    class Caller:
        @LoggedFunction(logger)
        def called_func(self, *args, **kwargs):
            return mock_result

    caller = Caller()
    result = caller.called_func(*mock_args, **mock_kwargs)
    TestCase.assertEqual(logger.last_log_message, f"{result}")



# Generated at 2022-06-21 20:46:33.230021
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('str') == "'str'"
    assert format_arg(5) == '5'
    assert format_arg(True) == 'True'
    assert format_arg(None) == 'None'

# Generated at 2022-06-21 20:46:44.857927
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import logging
    import sys

    # Capture stdout
    old_stdout = sys.stdout
    captured_stdout = io.StringIO()
    sys.stdout = captured_stdout

    # Create logger
    logger = logging.getLogger("logged_function_test")
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)

    # Create decorated function
    function_logger = LoggedFunction(logger)

    # Decorate function
    @function_logger
    def test_function(x, y=1):
        return x + y

    # Call function
    result = test_function(1, y=2)

    # Check result
    assert result == 3

    # Reset stdout
    sys.stdout = old_stdout

    #

# Generated at 2022-06-21 20:46:47.997574
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(DEBUG_LOGGER)
    @LoggedFunction(logger=logger)
    def f():
        return 666

    # Because the logger is set to DEBUG, the logger will show the function name and return value
    f()

# Generated at 2022-06-21 20:46:50.146263
# Unit test for function build_requests_session
def test_build_requests_session():
    request_session = build_requests_session(True)
    assert True

# Generated at 2022-06-21 20:47:01.224143
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest
    import sys

    import argparse

    def test_function(a, b='default'):
        return a + b

    logger = logging.getLogger('test_logger')
    mem_handler = logging.StreamHandler(io.StringIO())
    logger.addHandler(mem_handler)
    logger.setLevel(logging.DEBUG)

    logged_function = LoggedFunction(logger)
    wrapped_function = logged_function(test_function)

    orig_stdout = sys.stdout
    sys.stdout = io.StringIO()

# Generated at 2022-06-21 20:47:03.396738
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger

    logger = getLogger("test")
    log_func = LoggedFunction(logger)



# Generated at 2022-06-21 20:47:11.245921
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    func1 = LoggedFunction(logging.getLogger(__name__))
    func2 = LoggedFunction(logging.getLogger(__name__))
    assert func1.logger == func2.logger
    assert func1.__name__ == 'logged_func'
    assert func2.__name__ == 'logged_func'

# Generated at 2022-06-21 20:47:19.297591
# Unit test for function build_requests_session
def test_build_requests_session():
    r = build_requests_session()
    assert isinstance(r, Session)
    assert r.hooks == {}
    assert isinstance(r.adapters["http://"].max_retries, Retry)
    assert isinstance(r.adapters["https://"].max_retries, Retry)

    r = build_requests_session(raise_for_status=True)
    assert r.hooks == {
        "response": [
            lambda r, *args, **kwargs: r.raise_for_status()
        ]
    }

    r = build_requests_session(retry=False)
    assert r.adapters["http://"].max_retries == None
    assert r.adapters["https://"].max_retries == None


# Generated at 2022-06-21 20:47:23.020410
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Hello ") == "'Hello '"
    assert format_arg(False) == "False"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"

# Generated at 2022-06-21 20:47:26.331854
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(123) == "123"
    assert format_arg("Hello") == "'Hello'"
    assert format_arg("  Hello  ") == "'  Hello  '"


# Generated at 2022-06-21 20:47:28.799542
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('1') == "'1'"
    assert format_arg('foo') == "'foo'"


# Generated at 2022-06-21 20:47:33.195345
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry
    from requests.packages.urllib3.util.retry import Retry

    session = build_requests_session()
    assert isinstance(session, Session)
    assert 'response' not in session.hooks
    assert len(session.adapters) == 0

    session = build_requests_session(raise_for_status=False)
    assert isinstance(session, Session)
    assert 'response' not in session.hooks
    assert len(session.adapters) == 0

    session = build_requests_session(retry=False)
    assert isinstance(session, Session)
    assert 'response' not in session.hooks
    assert len(session.adapters) == 0


# Generated at 2022-06-21 20:47:42.156915
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session.__name__ == "build_requests_session"
    assert isinstance(build_requests_session(False, False), Session)
    assert isinstance(build_requests_session(False, True), Session)
    assert isinstance(build_requests_session(False, 3), Session)
    assert isinstance(build_requests_session(False, Retry()), Session)
    assert isinstance(build_requests_session(True, True), Session)
    assert isinstance(build_requests_session(True, 3), Session)
    assert isinstance(build_requests_session(True, Retry()), Session)
    try:
        build_requests_session(False, "")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 20:47:44.999675
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("some string") == "'some string'"
    assert format_arg(110) == "110"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:47:45.960006
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

# Generated at 2022-06-21 20:47:55.071376
# Unit test for function build_requests_session
def test_build_requests_session():
    _test_build_requests_session_with_retry_true()
    _test_build_requests_session_with_retry_false()
    _test_build_requests_session_with_retry_int()
    _test_build_requests_session_with_retry_class()
    _test_build_requests_session_with_default_value()
    _test_build_requests_session_with_raise_for_status_true()
    _test_build_requests_session_with_raise_for_status_false()



# Generated at 2022-06-21 20:48:04.501290
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    logger = Mock()
    decorator = LoggedFunction(logger)

    @decorator
    def test(x, y=None):
        pass

    test(1, y=2)
    logger.debug.assert_called_with(
        "test('1', y='2')"
    )



# Generated at 2022-06-21 20:48:11.195406
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('') == "''"
    assert format_arg('   ') == "''"
    assert format_arg('\n') == "''"
    assert format_arg('some value') == "'some value'"
    assert format_arg(1) == '1'
    assert format_arg(1.6) == '1.6'
    assert format_arg(None) == 'None'
    assert format_arg([]) == '[]'
    assert format_arg([1, 2]) == '[1, 2]'


# Generated at 2022-06-21 20:48:23.515477
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert hasattr(session, 'hooks')
    assert isinstance(session.hooks['response'][0], functools.partial)
    assert session.mounts['http://'][0].max_retries.DEFAULT_RETRIES == 10
    assert session.mounts['https://'][0].max_retries.DEFAULT_RETRIES == 10

    session = build_requests_session(False)
    assert not hasattr(session, 'hooks')
    assert isinstance(session.mounts['http://'][0], HTTPAdapter)
    assert isinstance(session.mounts['https://'][0], HTTPAdapter)

    session = build_requests_session(True, False)

# Generated at 2022-06-21 20:48:25.588179
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, False)
    session.get("https://httpbin.org/get")
    assert False



# Generated at 2022-06-21 20:48:29.590327
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test for invalid logger
    with pytest.raises(ValueError):
        LoggedFunction(logger=[])
    try:
        # Test for valid logger
        LoggedFunction(logger=logging.getLogger(__name__))
    except ValueError:
        pytest.fail("Accepts valid logger")


# Generated at 2022-06-21 20:48:38.128803
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=False)
    assert not hasattr(session.adapters, "http://")
    assert not hasattr(session.adapters, "https://")
    assert session.hooks["response"] == [lambda r, *args, **kwargs: r.raise_for_status()]
    session = build_requests_session(raise_for_status=False)
    assert hasattr(session.adapters, "http://")
    assert hasattr(session.adapters, "https://")
    assert session.hooks == {}



# Generated at 2022-06-21 20:48:43.966266
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("  a\nb\"c \'d") == "'a\nb\"c \'d'"
    assert format_arg("abcdefg") == "'abcdefg'"
    assert format_arg(123) == "123"
    assert format_arg(None) == "None"
    assert format_arg(True) == 'True'
    assert format_arg(False) == 'False'
    assert format_arg({"a":"test", "b":5}) == "{'a': 'test', 'b': 5}"

# Generated at 2022-06-21 20:48:55.244087
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, False)
    assert type(session) == requests.Session
    assert session.hooks == {"response": [lambda r, *args, **kwargs: r.raise_for_status()]}

    try:
        session.mount("http://", HTTPAdapter(max_retries=0))
        raise AssertionError("build_requests_session should raise exception if retry is False")
    except ValueError as err:
        if "total" not in str(err):
            raise AssertionError("build_requests_session should raise exception with message of 'total'")

    session = build_requests_session(True, 0)
    assert type(session) == requests.Session

# Generated at 2022-06-21 20:48:57.343085
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"



# Generated at 2022-06-21 20:49:02.238563
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("") == "''"
    assert format_arg("hello") == "'hello'"
    assert format_arg(123) == "123"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"
    assert format_arg({"a": 1}) == "{'a': 1}"


# Generated at 2022-06-21 20:49:14.927903
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session
    assert issubclass(type(session), Session)

    session = build_requests_session(raise_for_status=False)
    assert session
    assert type(session.hooks) == dict
    assert session.hooks.keys() == {'response'}
    assert type(session.hooks['response']) == list
    assert len(session.hooks['response']) == 1

    session = build_requests_session(retry=False)
    assert session
    assert len(session.adapters.keys()) == 2
    assert len(session.adapters['http://'].max_retries.retry_errors_dict.keys()) == 0

# Generated at 2022-06-21 20:49:17.860942
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert s.__class__ == Session
    s = build_requests_session(retry=False)
    assert s.__class__ == Session
    s = build_requests_session(retry=True)
    assert s.__class__ == Session


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-21 20:49:22.449643
# Unit test for function format_arg
def test_format_arg():
    test_values = [(1, "1"), (True, "True"), (0.1, "0.1"), ("test", "'test'")]
    for value, expected in test_values:
        assert format_arg(value) == expected



# Generated at 2022-06-21 20:49:34.434486
# Unit test for function build_requests_session
def test_build_requests_session():
    import unittest

    class BuildRequestsSessionTestCase(unittest.TestCase):
        def test_build_requests_session(self):
            raise_for_status = True
            retry = Retry(
                total=5,
                read=5,
                connect=5,
                backoff_factor=0.1,
                method_whitelist=frozenset(["GET", "POST", "OPTIONS"]),
            )

            requests_session = build_requests_session(
                raise_for_status=raise_for_status, retry=retry
            )

            self.assertIsInstance(requests_session, Session)
            self.assertEqual(len(requests_session.hooks["response"]), 1)

# Generated at 2022-06-21 20:49:43.641671
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import sys
    import logging

    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter("[%(levelname)s] %(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    foo = LoggedFunction(logger)

    @foo
    def func(one, two, three=3, four=4, five=5):
        return one * two * three * four * five

    assert func(2, 3, four=6, five=7) == 2 * 3 * 3 * 6 * 7



# Generated at 2022-06-21 20:49:47.557069
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("a") == "'a'"
    assert format_arg("a b") == "'a b'"
    assert format_arg(" a b ") == "' a b '"
    assert format_arg(1) == "1"


# Generated at 2022-06-21 20:49:57.137929
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class TestLogger:
        def __init__(self):
            self.logged_string = None

        def debug(self, message):
            self.logged_string = message

    test_logger = TestLogger()
    logged_function = LoggedFunction(test_logger)

    @logged_function
    def test_function(x, y, z='w'):
        pass

    test_function(1, 2, z=3)

    print(test_logger.logged_string)
    assert test_logger.logged_string == (
        "test_function(1, 2, z=3)"
    )



# Generated at 2022-06-21 20:50:03.037680
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # TODO: The class LoggedFunction is not very testable, since all it does
    # is add together a bunch of strings. There's nothing to assert on.
    # Consider refactoring this class, or perhaps replacing it with a library
    # such as https://lagerdata.se/en/latest/pylogger.html
    #
    # Also, at the time of writing, the code in the else clause of the
    # constructor has a bug, whereby it will log "None -> None" rather than
    # just "None" if the result is actually None.
    pass

# Generated at 2022-06-21 20:50:09.690018
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    print('\nTesting constructor of class LoggedFunction')

    # Create mock logger object
    from unittest.mock import Mock
    mock_logger = Mock()

    # Create new LoggedFunction object
    logged_function = LoggedFunction(mock_logger)
    assert logged_function is not None, 'Failed to create LoggedFunction object'
    assert logged_function.logger is mock_logger, 'Logger is not correct'


# Generated at 2022-06-21 20:50:17.281786
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import unittest

    class TestCase(unittest.TestCase):
        def test_logged_function_works(self):
            message_buffer = io.StringIO()
            logger = logging.getLogger(__name__)
            handler = logging.StreamHandler(message_buffer)
            logger.setLevel(logging.DEBUG)
            logger.addHandler(handler)

            logged_func = LoggedFunction(logger)(lambda x: x)
            result = logged_func(2)

            message_buffer.seek(0)
            self.assertEqual(message_buffer.readline(), "lambda(2)\n")
            self.assertEqual(message_buffer.readline(), "lambda -> 2\n")

            self.assertEqual(result, 2)

    unittest.main

# Generated at 2022-06-21 20:50:30.436211
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import mock
    logging.basicConfig(level=logging.DEBUG)
    mock_logger = mock.Mock(logging.Logger)
    f = LoggedFunction(mock_logger)

    # Function without arguments
    def test1():
        pass

    test1()
    mock_logger.debug.assert_called_once_with(
        "test1()"
    )
    mock_logger.debug.reset_mock()
    assert test1() is None
    mock_logger.debug.assert_not_called()

    # Function with arguments
    def test2(arg1, arg2):
        return f"{arg1} {arg2}"

    test2("foo", "bar")

# Generated at 2022-06-21 20:50:40.166098
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import Response
    from requests import status_codes
    import time
    import requests_mock
    import unittest
    import unittest.mock as mock

    class TestBuildRequestsSession(unittest.TestCase):
        def test_positive_case(self):
            mock_object = mock.MagicMock(spec=Response())
            mock_object.status_code = status_codes._codes.OK[0]
            # this is the default raise_for_status retry
            with requests_mock.Mocker() as m:
                mock_url = "http://www.test.com"

# Generated at 2022-06-21 20:50:44.765897
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class FakeLogger():
        def __init__(self):
            self.logged = []
        
        def debug(self, msg):
            self.logged.append(msg)
    
    lf = LoggedFunction(FakeLogger())
    lf.__call__(lambda x: x * 6)
    lf.__call__(lambda x, y: x * y)

##############################################################################
### DO NOT CHANGE ANYTHING BELOW THIS LINE ##################################
##############################################################################

from unittest import main
from unittest import TestCase



# Generated at 2022-06-21 20:50:48.919883
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def sample_func():
        pass

    logger = logging.getLogger("test")
    # If this doesn't raise an exception, we're good
    function = LoggedFunction(logger)(sample_func)



# Generated at 2022-06-21 20:50:57.236164
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.max_redirects is None
    assert len(session.hooks["response"]) == 0
    assert session.adapters == {"http://": HTTPAdapter(max_retries=Retry()),
                                "https://": HTTPAdapter(max_retries=Retry())}

    session = build_requests_session(False)
    assert session.adapters == {"http://": HTTPAdapter(max_retries=Retry()),
                                "https://": HTTPAdapter(max_retries=Retry())}
    assert session.max_redirects is None
    assert len(session.hooks["response"]) == 0

    session = build_requests_session(True)
    assert session.max_redirects is None

# Generated at 2022-06-21 20:51:00.569255
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test if the logger is one of the arguments
    logger = lambda : None
    lg = LoggedFunction(logger)
    assert lg.logger == logger

# Test if the logged_func return the same thing as func 

# Generated at 2022-06-21 20:51:13.325971
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import contextlib

    # Create dummy function
    @LoggedFunction(logging.getLogger())
    def dummy_function(arg1, arg2, arg3=True, arg4=None):
        return arg1 + arg2

    class DummyLogger:
        def __init__(self, name):
            self.name = name
            self.messages = []

        def debug(self, msg):
            self.messages.append(msg)

    # Test
    @LoggedFunction(DummyLogger)
    def dummy_function(arg1, arg2, arg3=True, arg4=None):
        return arg1 + arg2

    result = dummy_function(1, 2)
    assert result == 3

# Generated at 2022-06-21 20:51:15.338516
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from src.utils.logging_util import logger
    lf = LoggedFunction(logger)
    assert lf.logger == logger


# Generated at 2022-06-21 20:51:20.180118
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert session.mounts["http://"][0] is session.mounts["https://"][0]
    assert isinstance(session.mounts["http://"][0], HTTPAdapter)
    assert session.mounts["http://"][0].max_retries is None
    session = build_requests_session(retry=1)
    assert session.mounts["http://"][0] is session.mounts["https://"][0]
    assert isinstance(session.mounts["http://"][0], HTTPAdapter)
    assert session.mounts["http://"][0].max_retries.total == 1

# Generated at 2022-06-21 20:51:27.484003
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import HTTPError

    with build_requests_session().get("http://www.google.com") as res:
        print(res.url)

    with build_requests_session(raise_for_status=False).get("http://www.google.com") as res:
        print(res.url)

    try:
        with build_requests_session().get("http://www.google.com") as res:
            res.raise_for_status()
            print(res.url)
    except HTTPError as e:
        print(e)

    try:
        with build_requests_session().get("http://a-bad-url-xyz.com") as res:
            res.raise_for_status()
            print(res.url)
    except HTTPError as e:
        print

# Generated at 2022-06-21 20:51:44.048677
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock as mock
    import logging

    def test_func(*args, **kwargs):
        return {"arg": args, "kwarg": kwargs}

    logger = mock.MagicMock(spec=logging.Logger)
    func_decorated = LoggedFunction(logger)(test_func)

    func_decorated(1, 2, 3, 4, keyword_arg=5)
    logger.debug.assert_called_once_with(
        "test_func(1, 2, 3, 4, keyword_arg=5)"
    )

    func_decorated(1, 2)
    logger.debug.assert_called_with(
        "test_func(1, 2)"
    )

    func_decorated(1, 2, keyword_arg=5)

# Generated at 2022-06-21 20:51:47.465076
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        a = LoggedFunction("name")
    except:
        assert False, "The constructor of class LoggedFunction failed."
    assert a.logger == "name", "The constructor of class LoggedFunction failed."


# Generated at 2022-06-21 20:51:49.062242
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Should print a message to the console
    lf = LoggedFunction(logging.getLogger())
    assert lf

# Generated at 2022-06-21 20:51:59.825296
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=False)
    assert not session.hooks.get("response")

    session = build_requests_session(raise_for_status=True)
    assert session.hooks["response"]

    with pytest.raises(ValueError):
        build_requests_session(retry={})

    build_requests_session(retry=False)
    build_requests_session(retry=5)

    retry = Retry(total=10, connect=3, read=5)
    session = build_requests_session(retry=retry)
    assert session.adapters["http://"].max_retries == retry
    assert session.adapters["https://"].max_retries == retry


# Generated at 2022-06-21 20:52:09.030337
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Given
    logger = logging.getLogger("temp_logger")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stream=sys.stderr)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    decorated_func = LoggedFunction(logger)(add_nums)

    # When
    decorated_func(2, 3)

    # Then
    # See stdout


# Generated at 2022-06-21 20:52:11.533373
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Hello world") == "'Hello world'"
    assert format_arg(2) == "2"
    assert format_arg(3.14) == "3.14"

# Generated at 2022-06-21 20:52:14.614402
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == 'None'
    assert format_arg(1) == '1'
    assert format_arg(1.0) == '1.0'
    assert format_arg("a") == "'a'"
    assert format_arg("a ") == "'a '"
    assert format_arg(" a ") == "' a '"

# Generated at 2022-06-21 20:52:19.411184
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Mocking object
    logger_factory = Mock()
    logger = logger_factory.getChild('test_log')

    logged_func = LoggedFunction(logger)
    logged_func(lambda a: a)



# Generated at 2022-06-21 20:52:23.895325
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    assert logger.getEffectiveLevel() == logging.DEBUG
    logging_function_decorator = LoggedFunction(logger)

    @logging_function_decorator
    def test(a, b, c):
        return (a, b, c)

    assert test.__name__ == "test"

    assert test(1, 2, 3) == (1, 2, 3)

    try:
        test(a="1", b="2", c="3")
        assert False
    except TypeError:
        pass

    try:
        test(1, b="2", c="3")
        assert False
    except TypeError:
        pass


# Generated at 2022-06-21 20:52:24.470280
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest

# Generated at 2022-06-21 20:52:46.082052
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('test') == "'test'"
    assert format_arg('   test   ') == "'test'"
    assert format_arg(None) == 'None'
    assert format_arg(True) == 'True'
    assert format_arg(False) == 'False'
    assert format_arg(1.1) == '1.1'
    assert format_arg(1.11111111111111111111111111111111111111111111) == '1.111111111111111'

# Generated at 2022-06-21 20:52:57.402793
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logger = logging.getLogger('example'+'.'+__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = \
        logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    #
    def func1(a1, a2, a3='aaa'):
        logger.debug('in func1')
        return 'bbb'
    func1 = LoggedFunction(logger)(func1)
    func1(1,2)
    #
    def func2():
        logger.debug('in func1')
        return

# Generated at 2022-06-21 20:53:08.064227
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False, False)

    session = build_requests_session(True, False)
    assert len(session.hooks["response"]) == 1

    session = build_requests_session(True, True)
    session.get("http://www.google.com/")
    
    session = build_requests_session(True, 0)
    session.get("https://www.google.com/")

    with pytest.raises(TypeError):
        session = build_requests_session(True, {})

    with pytest.raises(TypeError):
        session = build_requests_session(True, "True")

    with pytest.raises(TypeError):
        session = build_requests_session(True, True, True)


# Generated at 2022-06-21 20:53:15.601154
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True,retry=True)
    session.get("https://www.baidu.com")
    session = build_requests_session(raise_for_status=True,retry=3)
    session.get("https://www.baidu.com")
    session = build_requests_session(raise_for_status=True,retry=Retry(total=3))
    session.get("https://www.baidu.com")
    session = build_requests_session(raise_for_status=False,retry=True)
    session.get("https://www.baidu.com")
    session = build_requests_session(raise_for_status=False,retry=3)

# Generated at 2022-06-21 20:53:17.494981
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=2)

# Generated at 2022-06-21 20:53:27.230402
# Unit test for function build_requests_session
def test_build_requests_session():
    # test default
    session = build_requests_session()
    assert (
        session.hooks["response"]
        == [lambda r, *args, **kwargs: r.raise_for_status()]
    )
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert isinstance(session.adapters["https://"].max_retries, Retry)

    # test if raise_for_status=False, then no hook for response
    session = build_requests_session(raise_for_status=False)
    assert not session.hooks

    # test if retry=False, then no retry adapter
    session = build_requests_session(retry=False)
    assert not session.adapters

    # test if give an integer, then max_retries will

# Generated at 2022-06-21 20:53:36.513255
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger_output = StringIO()
    log_handler = logging.StreamHandler(stream=logger_output)
    logger = logging.getLogger("test_logger")
    logger.addHandler(log_handler)
    logger.setLevel("DEBUG")

    @LoggedFunction(logger)
    def func1(a, b, c=3, *args, **kwargs):
        return a + b + c + sum(args) + sum(kwargs.values())

    assert func1(1, 2, 4, 5, 6, d=1, e=7) == 1 + 2 + 4 + 5 + 6 + 1 + 7

# Generated at 2022-06-21 20:53:38.301518
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("  test  ") == f"'{'test'}'"
    assert format_arg(5) == str(5)

# Generated at 2022-06-21 20:53:49.200412
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    arg1 = 'first'
    arg2 = 'second'
    arg3 = 'third'
    logged_func = LoggedFunction(logger=logger)(func_test_constructor)
    logged_func(arg1=arg1, arg2=arg2, arg3=arg3)
        

# Generated at 2022-06-21 20:54:00.677713
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert len(session.adapters) == 0

    session = build_requests_session(raise_for_status=False)
    assert session.hooks == {}
    assert len(session.adapters) == 0

    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert len(session.adapters) == 0

    session = build_requests_session(retry=Retry(0, False))
    assert session.hooks == {}
    assert len(session.adapters) == 0

    session = build_requests_session(retry=3)
    assert session.hooks == {}
    assert len(session.adapters) != 0

# Generated at 2022-06-21 20:55:11.096135
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    x = LoggedFunction(logger=None)
    assert x is not None

# Generated at 2022-06-21 20:55:11.827319
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    pass

# Generated at 2022-06-21 20:55:13.975170
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger, DEBUG
    logger = getLogger("test_logger")
    logger.addHandler(DEBUG)
    loggedFunction = LoggedFunction(logger)
    logger.debug("LoggedFunction constructor test passed.")
    assert True


# Generated at 2022-06-21 20:55:24.157447
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    import sys

    class FakeLogger:
        def __init__(self):
            self.text = io.StringIO()
            self.handler = logging.StreamHandler(self.text)
            self.logger = logging.getLogger()
            self.logger.addHandler(self.handler)

        def debug(self, message):
            return self.logger.debug(message)

        def __enter__(self):
            return self

        def __exit__(self, *args):
            self.logger.removeHandler(self.handler)

    def test_function(message):
        print(message)
        return message

    with FakeLogger() as logger:
        logged_function = LoggedFunction(logger.logger)
        wrapped_function = logged_function(test_function)


# Generated at 2022-06-21 20:55:29.852169
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" hello world ") == "' hello world '"
    assert format_arg("'hello world'") == "'hello world'"
    assert format_arg(123) == "123"



# Generated at 2022-06-21 20:55:34.679574
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    logging.basicConfig(level="DEBUG")
    logger = logging.getLogger("test_LoggedFunction")
    def add3(a,b,c):
        return a+b+c
    log_fun = LoggedFunction(logger)
    fun = log_fun(add3)
    fun(1,2,3)
    fun(1,b=2,c=3)
    assert a.b == 3

# Generated at 2022-06-21 20:55:38.332712
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg(4) == "4"
    assert format_arg("test test") == "'test test'"
    assert format_arg("'test test'") == "'test test'"


# Generated at 2022-06-21 20:55:40.911291
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    session.get("http://www.google.com")



# Generated at 2022-06-21 20:55:43.405380
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # with dummy_logger() as logger:
    #     LoggedFunction(logger)

    #     with pytest.raises(TypeError):
    #         LoggedFunction(None)
    assert 1==1

# Generated at 2022-06-21 20:55:46.761655
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    test constructor of class LoggedFunction

    :return: None
    """
    import logging

    logger = logging.getLogger("default")
    log_func = LoggedFunction(logger)
    assert log_func.logger == logger
