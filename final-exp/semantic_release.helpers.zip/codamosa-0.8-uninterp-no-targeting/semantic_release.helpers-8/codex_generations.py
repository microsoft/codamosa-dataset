

# Generated at 2022-06-21 20:46:16.609180
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg("A") == "'A'"
    assert format_arg(" A ") == "'A'"  # No spaces needed
    assert format_arg(1) == "1"



# Generated at 2022-06-21 20:46:19.656765
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc def") == "'abc def'"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:46:29.806990
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def f(a, b, c=3, d=4):
        return a + b + c + d
    logger=logging.getLogger()
    f_logged=LoggedFunction(logger)(f)

    logger.setLevel(logging.DEBUG)
    assert f_logged(1,2) == 3 + 4 + 3 + 4
    handler = logging.handlers.BufferingHandler(10)
    logger.addHandler(handler)
    assert f_logged(1,2) == 3 + 4 + 3 + 4
    assert len(handler.buffer) == 2
    assert handler.buffer[0].getMessage() == "f(1, 2, c=3, d=4)"
    assert handler.buffer[1].getMessage() == "f -> 10"

# Generated at 2022-06-21 20:46:37.772363
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    assert isinstance(logger, logging.Logger)
    assert logger == logging.getLogger(__name__)
    assert logger.getEffectiveLevel == logging.WARNING
    assert logger.hasHandlers() == False
    
    consoleHandler = logging.StreamHandler()
    consoleHandler.setLevel(logging.NOTSET)
    logger.addHandler(consoleHandler)
    assert logger.hasHandlers() == True
    
    logger.setLevel(logging.DEBUG)
    assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.hasHandlers() == True
    
    logged_func = LoggedFunction(logger)
    assert isinstance(logged_func, LoggedFunction)
    assert logged_func.logger == logger

# Generated at 2022-06-21 20:46:47.154682
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    class Handler(logging.Handler):
        def emit(self, record):
            print(self.format(record))

    logger = logging.getLogger("testlogger")
    logger.setLevel(logging.DEBUG)
    handler = Handler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    func_to_decorate = lambda s: s + s
    output = LoggedFunction(logger)(func_to_decorate)("test")
    assert output == "testtest"
    logger.removeHandler(handler)

if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-21 20:46:50.533422
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"

# Generated at 2022-06-21 20:46:57.786607
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test_debug_log")
    decorator = LoggedFunction(logger)

    @decorator
    def dummy_function(a, b, c="hi"):
        return a + b

    dummy_function(1, 2, c=3)
    assert logger.debug.call_count == 2
    assert logger.debug.call_args_list[0][0] == ("dummy_function(1, 2, c=3)")
    assert logger.debug.call_args_list[1][0] == ("dummy_function -> 6")



# Generated at 2022-06-21 20:47:05.816760
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger('logger')

    def foo(a, b):
        return a + b
    foo = LoggedFunction(logger)(foo)
    assert foo(1, 2) == 3

    def bar(a):
        return a
    bar = LoggedFunction(logger)(bar)
    assert bar(1) == 1

    def baz(a, b, c=3):
        return a + b + c
    baz = LoggedFunction(logger)(baz)
    assert baz(1, 2) == 6

# Generated at 2022-06-21 20:47:10.489550
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger('decorator_log')
    def fn_test(x, y):
        return x + y
    assert fn_test(3, 5) == 8
    fn_test_logged = LoggedFunction(logger)(fn_test)
    assert fn_test_logged(3, 5) == 8
    return

# Generated at 2022-06-21 20:47:13.057306
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    d = LoggedFunction(logging.getLogger(__name__))
    assert d.logger.name == __name__


# Generated at 2022-06-21 20:47:22.099811
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg("name") == "'name'"
    assert format_arg('name"') == "'name\"'"



# Generated at 2022-06-21 20:47:25.235881
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger("logged_function")
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logged_function = LoggedFunction(logger)
    assert logged_function is not None



# Generated at 2022-06-21 20:47:30.958331
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # create a logger
    logging.basicConfig(level=logging.DEBUG, format="%(message)s")
    logger = logging.getLogger()

    # create a LoggedFunction
    testobj = LoggedFunction(logger)

    # create a function
    def test_func(x, y, z=0):
        return x + y + z
    
    # assert the result
    assert testobj(test_func)(1,2,3) == 6
    assert testobj(test_func)(1,2) == 3
    assert testobj(test_func)(1,2,z=3) == 6


# Generated at 2022-06-21 20:47:41.341679
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger:
        def debug(self, msg):
            print(msg)

    logger = FakeLogger()
    logged_func = LoggedFunction(logger).__call__(lambda n: n * n)

    logged_func(2)
    logged_func(2, 3, a=4)

if __name__ == "__main__":
    test_LoggedFunction___call__()

# def build_logger():
#     logger = logging.getLogger(__name__)
#     logger.setLevel(logging.DEBUG)
#     file_handler = logging.FileHandler(os.path.join(DIR_LOG, "logger.log"))
#     file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s: %(message)s"))

# Generated at 2022-06-21 20:47:49.573153
# Unit test for function build_requests_session
def test_build_requests_session():
    rs = build_requests_session()
    rs.get("https://www.google.com")
    rss = build_requests_session(retry=False)
    rsss = build_requests_session(retry=3)
    rssss = build_requests_session(retry=Retry())
    # TODO: add unittest for raising exception


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-21 20:47:53.894165
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test with correct input
    assert LoggedFunction(logger=None)
    assert LoggedFunction(logger=lambda x: None)
    # Test constructor with incorrect input
    with pytest.raises(Exception):
        LoggedFunction()
        LoggedFunction(None)
        LoggedFunction(logger=10)



# Generated at 2022-06-21 20:47:55.950588
# Unit test for function format_arg
def test_format_arg():
    print(format_arg("text"))
    print(format_arg(0))
    print(format_arg(20.3))

# Generated at 2022-06-21 20:47:58.096300
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        logged_func = LoggedFunction()
    except Exception as e:
        raise e
    return True

# Generated at 2022-06-21 20:47:59.608997
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('foo') == "'foo'"
    assert format_arg(1) == "1"



# Generated at 2022-06-21 20:48:00.109888
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    pass

# Generated at 2022-06-21 20:48:14.279546
# Unit test for function format_arg
def test_format_arg():
    argSpec = inspect.getfullargspec(format_arg)
    # Verify that the argument is called 'value'
    assert argSpec.args == ['value']
    # Verify that the function does not take any keyword arguments
    assert argSpec.kwonlyargs == []
    # Verify that the function does not take any default arguments
    assert argSpec.defaults == None
    # Verify that the function does not take any variadic arguments
    assert argSpec.varargs == None
    # Verify that the function does not take any keyword-only variadic arguments
    assert argSpec.kwonlydefaults == None

    # Verify that the function returns a string
    assert type(format_arg('a')) == str

    # Verify that the function returns a quoted string, when the input is a string
    assert format_arg('a') == "'a'"

    # Verify that the

# Generated at 2022-06-21 20:48:25.847196
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("LoggedFunction")
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    decorator = LoggedFunction(logger)

    # Test functions
    @decorator
    def add(x, y):
        return x + y

    @decorator
    def sub(a, b=3):
        return a - b

    # Test
    logger.debug("------LoggedFunction unit test------")
    logger.debug("")
    add(1, 2)
    sub(1)
    sub(1, 2)
    # Expected output:
    # ------LoggedFunction unit test------
    #
    # add(1, 2)
    # add -> 3
    # sub(1)
    # sub -> -2
    # sub(1, 2)

# Generated at 2022-06-21 20:48:34.311211
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("5") == "'5'"
    assert format_arg(5) == "5"
    assert format_arg("5") == "'5'"
    assert format_arg(None) == "None"
    assert format_arg([]) == "[]"
    assert format_arg([1, 2]) == "[1, 2]"
    assert format_arg([1, 2, [3, []]]) == "[1, 2, [3, []]]"
    assert format_arg({"a": 1, "b": [1, 2]}) == "{'a': 1, 'b': [1, 2]}"

# Generated at 2022-06-21 20:48:41.398885
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import inspect

    logger = logging.getLogger("LoggedFunction_Debug")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def example_function(a, b, c="foo", d=12):
        return a + b + c + str(d)

    example_function(2, 3, c=5, d="bar")

# Generated at 2022-06-21 20:48:47.371410
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None
    assert session.max_retries.total == Retry().total
    assert session._adapters is not None

    session = build_requests_session(retry=False)
    assert session.max_retries.total == 0

    session = build_requests_session(retry=10)
    assert session.max_retries.total == 10

    session = build_requests_session(retry=Retry(5))
    assert session.max_retries.total == 5


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-21 20:48:58.604872
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    import unittest

    @LoggedFunction(logging.Logger("test", level="DEBUG"))
    def logged_function(a, b, c, d=False, e=True):
        return "return value"

    class TestLoggedFunction(unittest.TestCase):

        def setUp(self):
            self.handler = logging.StreamHandler(sys.stdout)
            self.logger = logging.Logger("test", level="DEBUG")
            self.logger.addHandler(self.handler)
            self.logger.propagate = False

        def test__call__(self):
            logged_function("Some text", 42, True)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()

    unitt

# Generated at 2022-06-21 20:49:09.827045
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from pytest import raises
    from logging import INFO

    logger = logging.getLogger(__name__)
    logger.debug("test-debug") # test logger

    # Retry?
    assert build_requests_session(retry=True)
    assert build_requests_session(retry=1)
    assert build_requests_session(retry=False)

    # Incorrect retry should raise ValueError
    with raises(ValueError):
        build_requests_session(retry="")

    # Decorator usage
    @LoggedFunction(logger)
    def test_function(a: int, b: int) -> int:
        return a + b

    # Should be return addtional debug logs

# Generated at 2022-06-21 20:49:12.484953
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1)=='1'
    assert format_arg('a')=="'a'"
    assert format_arg(" a b ") == "' a b '"


# Generated at 2022-06-21 20:49:17.286770
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(9) == "9"
    assert format_arg(9.1) == "9.1"
    assert format_arg("str") == "'str'"
    assert format_arg(["a", "b"]) == "['a', 'b']"
    assert format_arg({"a": "b"}) == "{'a': 'b'}"
    assert format_arg(test_format_arg) == "'test_format_arg'"

# Generated at 2022-06-21 20:49:26.165441
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" 'abc' ") == r"' 'abc' '"
    assert format_arg("\t  abc  ") == r"'\t  abc  '"
    assert format_arg("\t  'a'  ") == r"'\t  'a'  '"
    assert format_arg("'abc'") == r"'\'abc\''"
    assert format_arg("abc") == r"'abc'"
    assert format_arg(123) == "123"
    assert format_arg(123.4) == "123.4"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:49:46.517938
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10
    session = build_requests_session(retry=False)
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters
    session = build_requests_session(retry=3)
    assert session.adapters["http://"].max_retries.total == 3
    assert session.adapters["https://"].max_retries.total == 3
    session = build_requests_session(retry=Retry(total=5))
    assert session.adapters["http://"].max_retries.total == 5

# Generated at 2022-06-21 20:49:57.536442
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pathlib import Path
    from unittest.mock import MagicMock
    from ..lcs_base import LcsBase
    from ..fileutils import FileUtils

    class MockLcsBase(LcsBase):
        class LcsModule:
            pass

    class MockLcsModule(MockLcsBase.LcsModule):
        pass

    class MockLcsModule2(MockLcsModule):
        pass

    @LoggedFunction(logger=MockLcsBase._logger)
    def test_func(x, y, z=False, *args, **kwargs):
        print(x, y, z, args, kwargs)
        return x * y + len(args)


# Generated at 2022-06-21 20:50:01.426026
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg({"a": 1}) == "{'a': 1}"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"


# Generated at 2022-06-21 20:50:10.492740
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import io
    import sys
    import unittest
    import unittest.mock

    print_buffer = io.StringIO()
    print_buffer_save = sys.stdout
    sys.stdout = print_buffer
    try:
        logger = unittest.mock.MagicMock()
        LoggedFunction(logger)(lambda x: x)("Hello!")
        assert (
            logger.debug.call_args[0][0]
            == "<lambda>(Hello!) -> <function <lambda> at 0x111343b00>"
        )
        assert "Hello!" in print_buffer.getvalue()
    finally:
        sys.stdout = print_buffer_save

# Generated at 2022-06-21 20:50:17.861058
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    logger = logging.getLogger()
    handler = logging.StreamHandler(StringIO())
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def foo(a, b, c="test", d=None):
        return a + b

    foo(1, 2)
    assert "foo(1, 2, c='test') -> 3" == handler.stream.getvalue().strip()
    handler.stream.truncate(0)
    handler.stream.seek(0)
    foo(1, 2, "test", None)
    assert "foo(1, 2, c='test', d=None) -> 3" == handler.stream.getvalue().strip()
    handler.stream.truncate(0)

# Generated at 2022-06-21 20:50:28.503576
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction

    Tests cases:
    1. test_function -> test_function(1, 2, 3, 4, 5) -> 15
    2. test_function -> test_function('b', 2, a='a', b='b') -> Error
    """
    def test_function(*args):
        return sum(args)

    logger = logging.getLogger("test")


# Generated at 2022-06-21 20:50:32.701218
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(3) == "3"
    assert format_arg(3.2) == "3.2"
    assert format_arg("1") == "'1'"
    assert format_arg("1 ") == "'1 '"



# Generated at 2022-06-21 20:50:41.869912
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logging.debug("To ensure that logging is in debug mode.")
    # Test normal call with no return value
    test_logged_func = LoggedFunction(logger)(lambda: None)
    test_logged_func()
    # Test normal call with return value
    test_logged_func = LoggedFunction(logger)(lambda: 5)
    assert test_logged_func() == 5
    # Test call with arguments
    def test(a, *args, **kwargs):
        return a
    test_logged_func = LoggedFunction(logger)(test)
    assert test_logged_func(5, 2, a=1, z=7) == 5



# Generated at 2022-06-21 20:50:52.144815
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    logger = logging.getLogger("LoggedFunction.test")
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    logger.handlers = []  # removes old handlers
    logger.addHandler(logging.StreamHandler(stream))
    logger.propagate = False

    @LoggedFunction(logger)
    def add_two_numbers(a: int, b: int) -> int:
        return a + b

    add_two_numbers(a=3, b=5)
    assert stream.getvalue().strip() == "add_two_numbers(3, 5) -> 8"



# Generated at 2022-06-21 20:50:57.078150
# Unit test for function format_arg
def test_format_arg():
    inputs = [
        (1, "1"),
        (1.2, "1.2"),
        (1.23, "1.23"),
        ("abc", "'abc'"),
        (" abc ", "' abc '"),
        ("abc'", "abc'"),
        ("abc, def", "'abc, def'"),
        ("abc, \"def\"", "'abc, \"def\"'"),
        ("abc, 'def'", "'abc, 'def''"),
    ]
    for input in inputs:
        assert format_arg(input[0]) == input[1]

# Generated at 2022-06-21 20:51:25.336384
# Unit test for function build_requests_session
def test_build_requests_session():
    # NO Retry
    session = build_requests_session(retry=False)
    assert session.adapters == {}

    # Retry with default parameter
    session = build_requests_session()
    assert session.adapters != {}
    assert session.adapters["https://"].max_retries.total == 10

    # Retry with given parameter
    session = build_requests_session(retry=5)
    assert session.adapters["https://"].max_retries.total == 5

# Generated at 2022-06-21 20:51:36.553444
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest
    import logging

    # Logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # Test function
    @LoggedFunction(logger)
    def test_func(param1, param2="arg2"):
        return param1 + param2
    class TestCases(unittest.TestCase):
        def test_call(self):
            assert test_func(1, param2=2) == 3
           

# Generated at 2022-06-21 20:51:38.845949
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    a = LoggedFunction("logger")
    assert a.logger == "logger"


# Generated at 2022-06-21 20:51:41.638010
# Unit test for function build_requests_session
def test_build_requests_session():
    requests.get('https://www.baidu.com')
    requests.get('https://www.baidu.com/asd')
    requests.get('https://www.google.com')

# Generated at 2022-06-21 20:51:49.117652
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io
    class MyLogger(logging.Logger):
        def __init__(self, name, level=logging.NOTSET):
            super().__init__(name, level)
            self.buffer = io.StringIO()
            self.handler = logging.StreamHandler(self.buffer)
            self.addHandler(self.handler)
        def get_log_content(self):
            self.buffer.seek(0)
            return self.buffer.read()
        def clear_log(self):
            self.buffer.seek(0)
            self.buffer.truncate()
    logger = MyLogger('TestLogger')
    logger.setLevel(logging.DEBUG)
    @LoggedFunction(logger)
    def foo(a, b):
        return a + b
    foo

# Generated at 2022-06-21 20:51:59.895792
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from common.logging import get_logger
    from unittest.mock import MagicMock

    log = get_logger("testLogger")
    log.debug = MagicMock()

    def test_func(a, b, c=3, d=4):
        return a + b + c + d

    test_func = LoggedFunction(log)(test_func)
    test_func(1, 2)
    log.debug.assert_called_with("test_func(1, 2, c=3, d=4)")

    test_func(8, 9, 10, 11)
    log.debug.assert_called_with("test_func(8, 9, 10, 11)")

    test_func(c=1, a=2, b=3, d=4)
    log.debug.assert_

# Generated at 2022-06-21 20:52:10.777074
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import ConnectionError
    from requests.exceptions import HTTPError
    from requests.exceptions import Timeout
    import logging
    import pytest

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def get_url(url, requests_session=None):
        if requests_session:
            return requests_session.get(url)
        else:
            return requests.get(url)


    def test_raise_for_status_true():
        session = build_requests_session(raise_for_status=True)
        with pytest.raises(HTTPError):
            get_url("https://httpbin.org/status/401", requests_session=session)


# Generated at 2022-06-21 20:52:15.157243
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # set up
    import unittest
    from unittest.mock import Mock
    from unittest.mock import patch
    with patch("logging.getLogger") as mock_logger:
        mock_logger.return_value = Mock()
        assert mock_logger.return_value
        test_obj = LoggedFunction(mock_logger.return_value)
        assert isinstance(test_obj, LoggedFunction)



# Unit tests for @LoggedFunction

# Generated at 2022-06-21 20:52:17.939537
# Unit test for function build_requests_session
def test_build_requests_session():
    assert(isinstance(build_requests_session(), Session))

# Generated at 2022-06-21 20:52:28.527454
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session == Session()

    session = build_requests_session(raise_for_status=True)
    assert "response" in session.hooks
    session = build_requests_session(raise_for_status=False)
    assert "response" not in session.hooks

    session = build_requests_session(retry=True)
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    session = build_requests_session(retry=False)
    assert "http://" not in session.adapters
    session = build_requests_session(retry=4)
    assert isinstance(session.adapters["http://"], HTTPAdapter)
    assert session.adapters["http://"].max_retries.total == 4
    retry = Ret

# Generated at 2022-06-21 20:53:26.418031
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Set up dummy logger
    logger = logging.Logger(__name__)
    logger.setLevel(logging.DEBUG)
    output = io.StringIO()
    logger.addHandler(logging.StreamHandler(output))

    @LoggedFunction(logger=logger)
    def test_func(a, b, c=3, d=4, e=None):
        return a + b + c + d

    # Call wrapped function
    assert test_func(1, 2) == 8

    # Check output
    assert output.getvalue() == "test_func(1, 2, c=3, d=4)\n"

    # Call wrapped function with explicit arguments
    assert test_func(1, 2, c=5, d=6) == 14

    # Check output

# Generated at 2022-06-21 20:53:36.391618
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)
    assert session.hooks['response'][0].__name__ == 'logged_func'
    assert isinstance(session.adapters['http://'].max_retries.total, Retry)
    assert isinstance(session.adapters['https://'].max_retries.total, Retry)

    session = build_requests_session(raise_for_status=True, retry=False)
    assert session.hooks['response'][0].__name__ == 'logged_func'
    assert not hasattr(session, 'adapters')

    session = build_requests_session(raise_for_status=True, retry=1)

# Generated at 2022-06-21 20:53:38.491405
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=Retry(total=5, status_forcelist=[500]))
    assert isinstance(session, Session)



# Generated at 2022-06-21 20:53:46.711239
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc'") == "'abc''"
    assert format_arg('abc"') == "'abc\"'"
    assert format_arg("abc\\") == "'abc\\\\'"
    assert format_arg("abc\n") == "'abc\\n'"
    assert format_arg("abc\r") == "'abc\\r'"
    assert format_arg("") == "''"
    assert format_arg(123) == "123"

# Generated at 2022-06-21 20:53:50.851781
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session()
    assert isinstance(sess, Session)

# Generated at 2022-06-21 20:54:01.172232
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.config["keep_alive"] is True, "keep-alive should be enabled by default"

    retry = Retry()
    session = build_requests_session(retry=retry)
    assert session.adapters.popitem()[1].max_retries._max_retries == retry._max_retries, "Retry configuration does not match"

    session = build_requests_session(retry=False)
    assert "https://" not in session.adapters, "Retry should not be enabled"

    session = build_requests_session(raise_for_status=False)
    assert not session.hooks, "Hook should not be added if raise_for_status is False"

# Generated at 2022-06-21 20:54:02.842637
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert not s.hooks
    assert not s._adapters

# Generated at 2022-06-21 20:54:07.708871
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    print("test_LoggedFunction")

    def f():
        pass

    class Logger:
        def __init__(self):
            self.called_count = 0

        def debug(self, msg):
            self.called_count += 1

    logger = Logger()

    wrapped_f = LoggedFunction(logger)(f)
    wrapped_f()
    assert logger.called_count == 2



# Generated at 2022-06-21 20:54:18.756752
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger
    from logging import DEBUG
    from logging import StreamHandler
    from logging import Formatter

    handler = StreamHandler()
    handler.setLevel(DEBUG)
    handler.setFormatter(Formatter(
        "[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
    ))
    logger = getLogger()
    logger.setLevel(DEBUG)
    logger.addHandler(handler)

    logged_func = LoggedFunction(logger)
    @logged_func
    def my_function(a, b, c=10):
        return a + b + c

    my_function(1, 2)
    assert True


# Generated at 2022-06-21 20:54:26.680092
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == "5"
    assert format_arg("pouet") == "'pouet'"
    assert format_arg("  pouet") == "'  pouet'"
    assert format_arg("pouet  ") == "'pouet  '"
    assert format_arg("  pouet  ") == "'  pouet  '"
    assert format_arg(5.) == '5.0'
    assert format_arg(5.1) == '5.1'

# Generated at 2022-06-21 20:56:15.189132
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # setup
    log_list = []

    class DummyLogger():
        def debug(self, msg):
            log_list.append(msg)

    def some_func(a, b, c='d'):
        return a+b+c
    
    logger = DummyLogger()
    lf = LoggedFunction(logger)

    # action
    func = lf(some_func)
    func('a', 'b', c='c')

    # assert
    assert log_list[0] == "some_func('a', 'b', c='c')"
    assert log_list[1] == "some_func -> abc"
    return 


if __name__ == "__main__":
    test_LoggedFunction___call__()
    import doctest
    doctest.testmod()