

# Generated at 2022-06-21 20:46:18.793141
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import inspect
    logger = inspect.getmodule(inspect.currentframe()) # Fake logger
    logger.debug = print
    @LoggedFunction(logger)
    def foo(a, b, c=3):
        return a+b+c
    foo(1, 2)
    foo(1, 2, c=5)
    foo(1, 2, 3, 4) # Ignores the extra argument


# Generated at 2022-06-21 20:46:22.371256
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg(None) == "None"
    assert format_arg(b"abc") == "'abc'"
    assert format_arg(True) == "True"

# Generated at 2022-06-21 20:46:29.114096
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    # initialize LoggerInstance
    LFDecorator = LoggedFunction(logger)
    # test for @LoggedFunction
    @LFDecorator
    def test(c, b, a):
        print("Test function is invoked")
        return a + b + c
    # call test function
    test(1, 2, 3)


# Generated at 2022-06-21 20:46:33.226708
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg('hello') == "'hello'"
    assert format_arg(' "world"') == "' \"world\"'"


# Generated at 2022-06-21 20:46:36.513024
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    lf = LoggedFunction(logging.getLogger(test_LoggedFunction.__name__))
    assert lf.logger.name == test_LoggedFunction.__name__


# Generated at 2022-06-21 20:46:47.541905
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Create mock object to replace logging
    class MockLogger:
        def __init__(self):
            self.debug_log = []

        def debug(self, msg):
            self.debug_log.append(msg)

    logger = MockLogger()

    # Create LoggedFunction decorator instance
    logged_function = LoggedFunction(logger)

    # Define and decorate sample function
    @logged_function
    def sample_no_inputs():
        pass

    @logged_function
    def sample_one_input(inp):
        return inp * 2

    @logged_function
    def sample_one_input_with_defaults(inp=2):
        return inp * 2


# Generated at 2022-06-21 20:46:51.369919
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("  a  ") == "'a'"
    assert format_arg(123) == "123"
    assert format_arg("\n") == "'\n'"

# Generated at 2022-06-21 20:46:58.127681
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    retry = Retry(
        total=5,
        backoff_factor=0.5,
        status_forcelist=[500, 502, 503, 504],
        method_whitelist=["HEAD", "GET", "OPTIONS"],
    )
    session2 = build_requests_session(retry=retry)
    with pytest.raises(ValueError):
        session3 = build_requests_session(retry="WrongType")
    assert session != session2
    assert session2 != session3

# Generated at 2022-06-21 20:47:02.334509
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(12.5) == '12.5'
    assert format_arg('  hello ') == "'hello'"
    assert format_arg(None) == 'None'
    assert format_arg(True) == 'True'

# Generated at 2022-06-21 20:47:10.536224
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("str1") == "'str1'"
    assert format_arg(None) == "None"
    assert format_arg(2) == "2"
    assert format_arg(2.0) == "2.0"
    assert format_arg(False) == "False"
    assert format_arg([2, 3, 4]) == "[2, 3, 4]"
    assert format_arg({"a": 1, "b": 2}) == "{'a': 1, 'b': 2}"
    assert format_arg({2, 3, 4}) == "{2, 3, 4}"

test_format_arg()

# Generated at 2022-06-21 20:47:21.457666
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["https://"].max_retries.total == 10
    session = build_requests_session(retry=1)
    assert session.hooks == {}
    assert session.adapters["http://"].max_retries.total == 1
    assert session.adapters["https://"].max_retries.total == 1
    session = build_requests_session(retry=False)
    assert session.hooks == {}
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

# Generated at 2022-06-21 20:47:25.312607
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        # Instance of class LoggedFunction
        obj = LoggedFunction()

        # Check if the constructor is working
        assert obj == LoggedFunction()
    except:
        # Output error message if test fails
        print("Object instantiation error in class LoggedFunction")


# Generated at 2022-06-21 20:47:29.902883
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class _Logger:
        def debug(self, s):
            print(s)
            return self
    logger = _Logger()
    debug_func = LoggedFunction(logger)

    @debug_func
    def test_function(test_arg, test_keyword_arg=None):
        pass

    test_function("test_arg", test_keyword_arg="test_keyword_arg")


# Generated at 2022-06-21 20:47:39.301897
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test_LoggedFunction")
    def get_logged_function(logger):
        class MyClass:
            @LoggedFunction(logger)
            def MyFunction1(self, param1, param2, kwarg1="abc", kwarg2=123):
                pass

        return MyClass().MyFunction1

    loggedfunction = get_logged_function(logger)
    loggedfunction(1, "a", kwarg1="xyz", kwarg2=456)
    loggedfunction("a", "b", kwarg2=456)
    loggedfunction("a", "b")

# Generated at 2022-06-21 20:47:41.814167
# Unit test for function format_arg
def test_format_arg():
    # Format string
    assert format_arg(" hello") == "' hello'"

    # Format number
    assert format_arg(1.25) == "1.25"
    assert format_arg(1) == "1"

# Generated at 2022-06-21 20:47:54.195638
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters['http://'].max_retries.total == 3
    assert session.adapters['http://'].max_retries.backoff_factor == 0.3
    assert "response" not in session.hooks
    assert not session.hooks

    session = build_requests_session(raise_for_status=False)
    assert "response" not in session.hooks
    assert not session.hooks

    session = build_requests_session(retry=False)
    assert not session.adapters

    session = build_requests_session(retry=Retry(total=5, backoff_factor=1))
    assert session.adapters['http://'].max_retries.total == 5
    assert session.adapters['http://'].max

# Generated at 2022-06-21 20:48:01.750465
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import tempfile
    from logging import DEBUG, INFO

    with tempfile.TemporaryDirectory() as logdir:
        import re

        import structlog
        from structlog.stdlib import LoggerFactory
        from structlog.processors import JSONRenderer
        from structlog.processors import TimeStamper, StackInfoRenderer

        def add_log_path(logger, method_name, event_dict):
            event_dict["log_path"] = re.sub(r"^.*/", "", logfile.name)
            return event_dict


# Generated at 2022-06-21 20:48:11.929284
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert s.hooks.get("response", None) == None
    assert s.adapters["http://"].max_retries == None
    assert s.adapters["https://"].max_retries == None
    s = build_requests_session(raise_for_status=False)
    assert len(s.hooks.get("response", [])) == 0
    s = build_requests_session(retry=False)
    assert s.adapters["http://"].max_retries == None
    assert s.adapters["https://"].max_retries == None
    s = build_requests_session(retry=1)
    assert s.adapters["http://"].max_retries.total == 1

# Generated at 2022-06-21 20:48:14.753248
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Hello World") == "'Hello World'"
    assert format_arg(1234) == "1234"
    assert format_arg(1234.1234) == "1234.1234"

# Generated at 2022-06-21 20:48:26.350988
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import threading

    logger = logging.getLogger(__name__)
    log_level = logging.DEBUG
    logger.setLevel(log_level)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    logger.addHandler(console_handler)
    
    # Disabling the logging for the main thread as the logging gets invoked multiple times as per the settings on the logger object
    logger.disabled = True

    def loggedFunction():
        logging.info('Inside logged function')

    originalFunction = loggedFunction
    loggedFunction = LoggedFunction(logger)(loggedFunction)

    originalFunction()
    loggedFunction()

    # Check: logged_thread is

# Generated at 2022-06-21 20:48:34.352644
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert type(session.adapters["http://"]) == HTTPAdapter
    assert type(session.adapters["https://"]) == HTTPAdapter


# Generated at 2022-06-21 20:48:37.413773
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg(5) == "5"
    assert format_arg(4.2) == "4.2"



# Generated at 2022-06-21 20:48:42.687084
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
        # Given
        logger = Mock()
        # When
        logged = LoggedFunction(logger)
        # Then
        LoggedFunction.__init__(logged, logger)
        # Given
        def test():
            return 4 # Any value
        # When
        logged = LoggedFunction(logger)(test)
        # Then
        assert test.__name__ == 'test'
        assert type(logged) == function
        assert logged() == 4

# Generated at 2022-06-21 20:48:47.717774
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("  a") == f"'a'"
    assert format_arg("ab ") == f"'ab'"
    assert format_arg("  a  ") == f"'a'"
    assert format_arg(None) == "None"
    assert format_arg([1, 2.3, "a"]) == "[1, 2.3, 'a']"

# Generated at 2022-06-21 20:48:58.864531
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.hooks["response"] is not None
    assert type(session.adapters["https://"]) == HTTPAdapter
    assert type(session.adapters["http://"]) == HTTPAdapter
    assert session.adapters["https://"].max_retries.total == 10
    assert session.adapters["http://"].max_retries.total == 10
    session = build_requests_session(raise_for_status=False)
    assert session.hooks["response"] is None
    assert type(session.adapters["https://"]) == HTTPAdapter
    assert type(session.adapters["http://"]) == HTTPAdapter
    assert session.adapters["https://"].max_retries.total == 10

# Generated at 2022-06-21 20:49:01.076302
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    logger = logging.getLogger('test')
    a = LoggedFunction(logger)
    assert(a)



# Generated at 2022-06-21 20:49:10.736402
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch
    from unittest import TestCase

    test = TestCase()

    class MockLogger:
        def __init__(self):
            self.info = patch.object(LoggedFunction, "info").start()
            self.debug = patch.object(LoggedFunction, "debug").start()

    with patch.object(LoggedFunction, "logger", new_callable=MockLogger):
        mock_func = LoggedFunction(LoggedFunction.logger)
        mock_func.__call__(lambda: None)
        test.assertEqual(LoggedFunction.logger.debug.call_count, 2)



# Generated at 2022-06-21 20:49:12.889395
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    d = LoggedFunction(logging.getLogger("test_LoggedFunction"))
    assert isinstance(d, LoggedFunction)
    assert Callable(d)


# Generated at 2022-06-21 20:49:24.605741
# Unit test for function build_requests_session
def test_build_requests_session():
    from pytest import raises
    from requests import HTTPError
    from requests.models import Response

    s = build_requests_session(raise_for_status=False)
    assert not hasattr(s, "hooks")
    s.get("https://httpbin.org/status/200")

    s = build_requests_session(raise_for_status=True)
    assert s.hooks is not None
    s.get("https://httpbin.org/status/200")

    with raises(HTTPError):
        s.get("https://httpbin.org/status/400")

    s = build_requests_session(retry=False)
    assert s.adapters["http://"] is not None
    assert s.adapters["http://"].max_retries is None

# Generated at 2022-06-21 20:49:32.703321
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger_list = []
    class fake_logging:
        @staticmethod
        def debug(message):
            logger_list.append(message)
    lf = LoggedFunction(fake_logging)
    _ = lf(lambda x, y, z=1, t=3: (x, y, z, t))(1, 2, 3, 4)
    assert logger_list[0] == "lambda(1, 2, z=3, t=4)"
    assert logger_list[1] == "lambda -> (1, 2, 3, 4)"

# Generated at 2022-06-21 20:49:42.609150
# Unit test for function format_arg
def test_format_arg():
    assert format_arg({'a': 'b', 'c': 'd'}) == str({'a': 'b', 'c': 'd'})
    assert format_arg('str') == "'str'"
    assert format_arg('string  ') == "'string'"
    assert format_arg(123) == '123'



# Generated at 2022-06-21 20:49:53.882117
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test for method __call__ of class LoggedFunction.
    """

    import io
    import logging
    from logging import StreamHandler

    # Make a logger which captures log messages in a stream
    stream = io.StringIO()
    logger = logging.Logger("test_logger")
    handler = StreamHandler(stream)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Make a logged function which generates a log message when it is called
    @LoggedFunction(logger)
    def logged_function():
        pass

    # Test that the function is logged
    logged_function()

    assert (
        stream.getvalue()
        == "DEBUG:test_logger:logged_function()\nDEBUG:test_logger:logged_function -> None\n"
    )

# Generated at 2022-06-21 20:49:58.440108
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys
    logger = logging.Logger("logged_function_test", logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    @LoggedFunction(logger)
    def add(a, b):
        return a+b
    logger.debug(add(2, 3))

# Generated at 2022-06-21 20:50:00.825521
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('Hello') == '\'Hello\''
    assert format_arg(False) == 'False'
    assert format_arg(1) == '1'


# Generated at 2022-06-21 20:50:02.684524
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Hello") == "'Hello'"
    assert format_arg(1) == "1"



# Generated at 2022-06-21 20:50:11.305655
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest import TestCase
    from unittest.mock import patch
    from .logger import Logger

    logger = Logger()
    lf = LoggedFunction(logger)

    # test_LoggedFunction___call__
    @lf
    def test_function(x, y):
        pass

    with patch.object(logger, "debug") as mock_logger_debug:
        test_function(1, y=2)

    assert mock_logger_debug.call_args_list[0][0][0] == \
        "test_function(1, y='2')"



# Generated at 2022-06-21 20:50:13.506503
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg("  1  ") == "'  1  '"

# Generated at 2022-06-21 20:50:23.971433
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(retry=None) == build_requests_session()
    assert build_requests_session() == build_requests_session(retry=True) == build_requests_session(retry=Retry()) == build_requests_session(retry=3)
    assert build_requests_session(retry=False) == build_requests_session(retry=0)
    assert build_requests_session(retry=True).max_retries == Retry()
    assert build_requests_session(retry=3).max_retries == Retry(3)
    assert build_requests_session(retry=Retry(10)).max_retries == Retry(10)
    assert len(build_requests_session().hooks['response']) == 0

# Generated at 2022-06-21 20:50:32.061913
# Unit test for function build_requests_session
def test_build_requests_session():
    from unittest.mock import Mock
    from requests import Response
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry

    session = build_requests_session()
    response = session.get("http://fake.com")
    assert response.status_code == 200

    session = build_requests_session(retry=False)
    response = session.get("http://fake.com")
    assert response.status_code == 200

    session = build_requests_session(retry=True)
    response = session.get("http://fake.com")
    assert response.status_code == 200

    session = build_requests_session(retry=Retry(stop_max_attempt_number=0))

# Generated at 2022-06-21 20:50:38.086263
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    Test the constructor of LoggedFunction class.
    :return: None
    """
    from logging import getLogger
    import sys

    logger = getLogger()
    logger.setLevel('DEBUG')
    logger.addHandler(sys.stdout)

    @LoggedFunction(logger)
    def test_func(a, b, c=None):
        return a+b
    test_func(1, 2)
    test_func(1, 2, c=3)

# Generated at 2022-06-21 20:50:55.617389
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.string = ""
        def debug(self, s):
            self.string += s
    @LoggedFunction(Logger())
    def f(a, b, c):
        return a + b + c
    f("a", "b", "c")
    assert "f('a', 'b', 'c') -> abc" == Logger().string

# Generated at 2022-06-21 20:51:07.473943
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger

    # Expected output
    EXPECTED_OUTPUT = "debug_func(a, b=c, d=e)\n"

    class TestLogger:
        def __init__(self):
            self.log = ""

        def debug(self, message):
            self.log += message + "\n"

    # Get test logger
    test_logger = TestLogger()
    logger = getLogger()
    logger.addHandler(test_logger)

    # Decorate debug function
    @LoggedFunction(logger)
    def debug_func(a, b=None, d=None):
        return "return_value"

    # Call function
    debug_func("a", b="c", d="e")

    assert test_logger.log == EXPECTED_OUTP

# Generated at 2022-06-21 20:51:17.109936
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session()) == Session
    assert type(build_requests_session(raise_for_status=True)) == Session
    assert type(build_requests_session(retry=True)) == Session
    assert type(build_requests_session(retry=2)) == Session
    assert type(build_requests_session(retry=Retry())) == Session
    assert type(build_requests_session(raise_for_status=True, retry=True)) == Session
    assert type(build_requests_session(raise_for_status=True, retry=2)) == Session
    assert type(build_requests_session(raise_for_status=True, retry=Retry())) == Session

# Generated at 2022-06-21 20:51:26.587073
# Unit test for function build_requests_session
def test_build_requests_session():
    a_requests_session = build_requests_session()
    assert a_requests_session is not None
    assert isinstance(a_requests_session, Session)
    a_requests_session = build_requests_session(raise_for_status=False)
    assert a_requests_session is not None
    assert isinstance(a_requests_session, Session)
    a_requests_session = build_requests_session(retry=False)
    assert a_requests_session is not None
    assert isinstance(a_requests_session, Session)
    a_requests_session = build_requests_session(retry=3)
    assert a_requests_session is not None
    assert isinstance(a_requests_session, Session)
    a_requests_session = build

# Generated at 2022-06-21 20:51:35.606147
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from datetime import datetime as dt
    from logging import INFO, Formatter, StreamHandler, getLogger, NOTSET

    # Create logger
    logger = getLogger("example")
    logger.setLevel(INFO)
    handler = StreamHandler()
    handler.setLevel(INFO)
    handler.setFormatter(Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
    logger.addHandler(handler)

    # Decorate function
    @LoggedFunction(logger)
    def add(a, b):
        return a + b

    # Call function
    add(6, 6)



# Generated at 2022-06-21 20:51:45.367300
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Check that the decorator adds logging to the function
    class TestLogger:
        def __init__(self):
            self.output = ""

        def debug(self, message):
            self.output += message + "\n"

    logger = TestLogger()

    @LoggedFunction(logger)
    def test_func(a, b, c=3):
        return a + b + c

    assert test_func.__name__ == "test_func"
    assert test_func.__doc__ == "Unit test for method __call__ of class LoggedFunction"
    assert test_func(1, 2) == 6
    assert logger.output == (
        "test_func(1, 2, c=3)\n"
        "test_func -> 6\n"
    )



# Generated at 2022-06-21 20:51:50.722479
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg("123 ") == "'123'"
    assert format_arg(" 123") == "'123'"
    assert format_arg(" 123 ") == "'123'"
    assert format_arg(123.45) == "123.45"
    assert format_arg(" 123.45 ") == "'123.45'"

# Generated at 2022-06-21 20:51:53.779228
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(2) == '2'
    assert format_arg("2 ") == "'2 '"
    assert format_arg("'") == "'\\''"
    assert format_arg('') == "''"

# Generated at 2022-06-21 20:51:54.865361
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction

# Generated at 2022-06-21 20:51:59.785595
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg('"test"') == '\'"test"\''
    assert format_arg(1) == "1"
    assert format_arg(["test"]) == "['test']"
    assert format_arg({"test": "test"}) == "{'test': 'test'}"

# Generated at 2022-06-21 20:52:27.933382
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    logger = logging.getLogger("test")
    handler = logging.StreamHandler()
    logger.addHandler(handler)

    # Wrap function
    @LoggedFunction(logger)
    def fn_print(x, y, z):
        return "{0}={1}, {2}={3}, {4}={5}".format(
            str(x), str(y), str(z), str(z), str(x), str(y),
        )

    fn_print(1, 2, 3)
    fn_print(1, 2)

# Generated at 2022-06-21 20:52:33.330266
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    def func1(a, b):
        return a + b
    def func2(*args):
        return sum(args)
    def func3(**kwargs):
        return sum(v for _, v in kwargs.items())
    def func4(*args, **kwargs):
        return sum(args) + sum(v for _, v in kwargs.items())
    def func5(a, b, *args, **kwargs):
        return a + b + sum(args) + sum(v for _, v in kwargs.items())

    from io import StringIO
    from logging import DEBUG, INFO
    from loggerfactory import LoggerFactory

    factory = LoggerFactory(stream=StringIO(), level=DEBUG)
    logger = factory.get_logger(__name__)
    logger.level = INFO



# Generated at 2022-06-21 20:52:38.921557
# Unit test for function build_requests_session
def test_build_requests_session():
    assert Session() != build_requests_session()
    assert build_requests_session() != build_requests_session(raise_for_status=False)
    assert build_requests_session() != build_requests_session(retry=False)
    assert build_requests_session() != build_requests_session(retry=1)
    assert build_requests_session() != build_requests_session(retry=Retry())

# Generated at 2022-06-21 20:52:43.576664
# Unit test for function format_arg
def test_format_arg():
    """
    Unit test for function format_arg
    :return:
    """
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.5) == "1.5"
    assert format_arg("ab cd") == "'ab cd'"
    assert format_arg(["a", "b", "c"]) == "['a', 'b', 'c']"



# Generated at 2022-06-21 20:52:51.444290
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class DummyLogger:
        def __init__(self):
            self.logs = []

        def debug(self, msg):
            self.logs.append(msg)

    dummy_logger = DummyLogger()
    logged_func = LoggedFunction(dummy_logger)(lambda x: x)
    assert logged_func(2) == 2
    assert dummy_logger.logs == [
        "lambda(2)",
        "lambda -> 2",
    ]



# Generated at 2022-06-21 20:53:00.284583
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO

    # Create a logger and a stream to which all output will be written
    stream = StringIO()
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Create a LoggedFunction object
    lf = LoggedFunction(logger)

    # Define a function to test
    @lf
    def test_function(a, b, c=3, d=6, *args, **kwargs):
        return a + b + c + d + args[0] + kwargs["extra"]

    # Execute the function
    test_function(1, 2, extra=5, e=9)

    # Check that the right output was written to the log


# Generated at 2022-06-21 20:53:05.868494
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import getLogger
    from loggingsetup import add_console_handler

    logger = getLogger()
    add_console_handler(logger, level="DEBUG")

    @LoggedFunction(logger=logger)
    def add(x, y):
        return x + y

    add(3,4)



# Generated at 2022-06-21 20:53:14.241751
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest
    import warnings

    class TestLoggedFunction(unittest.TestCase):
        @staticmethod
        def log_warnings(callable_f, *args, **kwargs):
            with warnings.catch_warnings(record=True) as w:
                # Cause all warnings to always be triggered.
                warnings.simplefilter("always")
                # Trigger a warning.
                result = callable_f(*args, **kwargs)
                # Verify some things
                assert len(w) == 0
            return result

        def test_it_logs_input_arguments(self):
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            original_log = logger.info

# Generated at 2022-06-21 20:53:23.227552
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class CustomLogger:
        def __init__(self):
            self.logged_lines = []

        def debug(self, message):
            self.logged_lines.append(message)

    logger = CustomLogger()
    logged_func = LoggedFunction(logger)(lambda a, b: a + b)
    logged_func(1, 2)
    assert logger.logged_lines[0] == "logged_func(1, 2)"
    assert logger.logged_lines[1] == "logged_func -> 3"


# Generated at 2022-06-21 20:53:28.285476
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg(None) == "None"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"



# Generated at 2022-06-21 20:54:12.785148
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup
    from unittest.mock import Mock
    logger = Mock(spec=["debug"])
    obj = LoggedFunction(logger)
    # Exercise
    @obj
    def target():
        pass
    target()
    # Verify
    assert logger.debug.call_count == 1



# Generated at 2022-06-21 20:54:15.455881
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(9) == "9"
    assert format_arg("foo bar") == "'foo bar'"
    assert format_arg(None) == "None"


# Generated at 2022-06-21 20:54:24.612612
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest.mock
    from io import StringIO

    stream = StringIO()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stream)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def make_noise(item):
        print(item)

    make_noise("hello")

    handler.close()
    stream.seek(0)
    assert stream.read() == "make_noise('hello')\n"


# Generated at 2022-06-21 20:54:28.495907
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    s.get("http://www.baidu.com")

    s2 = build_requests_session(retry=False)
    try:
        s2.get("http://www.baidu.com")
    except Exception:
        pass
    else:
        raise Exception("Fail")


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-21 20:54:32.765676
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("  hello  ") == "'  hello  '"
    assert format_arg("") == "''"
    assert format_arg("None") == "'None'"
    assert format_arg(1) == "1"



# Generated at 2022-06-21 20:54:36.997432
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('hello')=="'hello'"
    assert format_arg(1)=="1"
    assert format_arg(None)=="None"
    assert format_arg(True)=="True"
    assert format_arg(False)=="False"
    assert format_arg({})=="{}"
    assert format_arg([])=="[]"


# Generated at 2022-06-21 20:54:40.795941
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    lf = LoggedFunction(logging.getLogger())
    assert lf(lambda x: x+1)(1) == 2
    assert lf(lambda x: x+1)(x=1) == 2
    assert lf(lambda x: x+1)(x=1, y=2) == 2
    assert lf(lambda x: x+1)(x=1, y=2, z=3) == 2

# Generated at 2022-06-21 20:54:50.636257
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    assert session.hooks['response'][0] == (
        lambda r, *args, **kwargs: r.raise_for_status()
    )
    assert (
        session.adapters['https://'].max_retries.total ==
        session.adapters['http://'].max_retries.total
    )
    session = build_requests_session(raise_for_status=False)
    assert not session.hooks
    session = build_requests_session(retry=False)
    assert not session.adapters
    session = build_requests_session(retry=5)

# Generated at 2022-06-21 20:54:58.212508
# Unit test for function build_requests_session
def test_build_requests_session():
    from .logging import configure_logging
    from .config import config

    configure_logging(level=config['logger']['level'])
    logger = logging.getLogger(__name__)

    # Test raise_for_status
    session = build_requests_session()
    try:
        session.get('https://httpbin.org/status/404')
    except Exception as e:
        logger.info(f'Successfully raised for status: {e!r}')
    else:
        logger.error('Should throw an exception.')

    session = build_requests_session(raise_for_status=False)

# Generated at 2022-06-21 20:55:06.991855
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger('logger')
    logging.basicConfig(
        level=logging.DEBUG, format="%(asctime)s %(levelname)-8s %(message)s"
    )

    # Check the __call__ function
    @LoggedFunction(logger)
    def foo(x,y):
        print('x')
    @LoggedFunction(logger)
    def foo2(m):
        print('m')
    foo(10,20)
    foo2('jafar')