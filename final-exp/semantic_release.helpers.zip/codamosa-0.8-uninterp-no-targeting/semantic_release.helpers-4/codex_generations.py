

# Generated at 2022-06-21 20:46:22.213017
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    @LoggedFunction(logger=None)
    def test(a, b):
        print("test body")
        return a + b
    test(1, 2)

# Generated at 2022-06-21 20:46:29.661067
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.max_retries
    session2 = build_requests_session(retry=False)
    assert not session2.max_retries
    assert isinstance(build_requests_session(retry=5).max_retries.total, int)
    assert isinstance(build_requests_session(retry=Retry(5)).max_retries.total, int)
    try:
        build_requests_session(retry="5")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-21 20:46:37.883114
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    l = LoggedFunction(logging.getLogger())
    assert(l.__call__(lambda: 1)() == 1)
    assert(l.__call__(lambda x: x * 2)(4) == 8)
    assert(l.__call__(lambda x, y: x * y)(2, 3) == 6)
    assert(l.__call__(lambda x, y=1: x * y)(2, y=2) == 4)
    assert(l.__call__(lambda x, y=1: x * y)(2) == 2)
    assert(l.__call__(lambda *args: sum(args))(1, 2, 3) == 6)

# Generated at 2022-06-21 20:46:39.136947
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)

# Generated at 2022-06-21 20:46:46.523194
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level="DEBUG")
    logger = logging.getLogger(__name__)
    log = LoggedFunction(logger)
    @log
    def add(a, b, c=0):
        return a+b+c
    print(add(1,2))
    print(add(1,c=3,b=2))

# test_LoggedFunction___call__()

# Generated at 2022-06-21 20:46:58.077457
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(True) == "True"
    assert format_arg("") == "''"
    assert format_arg(" ") == "' '"
    assert format_arg("a ") == "'a '"
    assert format_arg(" a") == "' a'"
    assert format_arg(" a ") == "' a '"
    assert format_arg("'") == "'\\''"
    assert format_arg("''") == "'\\''\\''"
    assert format_arg("'a'") == "'\\'a\\''"
    assert format_arg("\"") == "'\"'"
    assert format_arg("a b") == "'a b'"

# Generated at 2022-06-21 20:47:09.593189
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Mock logger
    logger = mock.MagicMock()

    # Decorate function
    @LoggedFunction(logger)
    def my_function(a, b, c=None, d=None):
        return "hello"

    # Call it
    my_function("a", "b")
    my_function("a", "b", c="c")
    my_function("a", "b", c="c", d="d")

    # Check that it logged the correct calls

# Generated at 2022-06-21 20:47:15.746815
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def debug(self, text):
            print(text)

    def func():
        return 8

    def func_args(a=8, b=9):
        return "just a test"

    logged_func = LoggedFunction(Logger())(func)
    assert logged_func() == 8

    logged_func_args = LoggedFunction(Logger())(func_args)
    assert logged_func_args(b='test') == "just a test"


test_LoggedFunction___call__()

# Generated at 2022-06-21 20:47:20.345461
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("logger1")
    a = LoggedFunction(logger)
    b = LoggedFunction(logger)

    assert(a.logger is b.logger)


# Generated at 2022-06-21 20:47:25.534059
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    @LoggedFunction(logger)
    def f(a, b=None, c=None):
        return a + (b or c)

    result = f(1, b=2)
    assert result == 3


# Generated at 2022-06-21 20:47:38.063258
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from fake_logger import FakeLogger
    from typing import Callable, List

    class Test:
        def __init__(self):
            self.logger = FakeLogger()
            self.logged_functions: List[Callable] = []

        def get_function(self, index: int) -> Callable:
            return self.logged_functions[index]

        @LoggedFunction(logger=lambda: self.logger)
        def function_1(self, a: int, b: str, c: float) -> float:
            return float(a) / 2 + float(b) / 3 + c


# Generated at 2022-06-21 20:47:45.220965
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Create a mock logger to check the output of the decorator.
    mock_logger = Mock()
    lf = LoggedFunction(mock_logger)
    # Define a dummy function that we can test with
    def dummy_function(a, b, c=False):
        return a + b + c

    logged_function = lf(dummy_function)
    assert logged_function.__name__ == "dummy_function"
    logged_function(1, 2, c=False)
    logged_function(a=1, b=2, c=False)
    logged_function(1, b=2, c=False)
    logged_function(1, 2, c=True)

    # Check that logger has been called the correct number of times.

# Generated at 2022-06-21 20:47:57.561164
# Unit test for function build_requests_session
def test_build_requests_session():
    from .client import ACTIVE_USER_DATA, API_BASE_URL
    import requests
    import logging

    test_url = API_BASE_URL + "/test"
    test_user = ACTIVE_USER_DATA[0]

    req_ses = build_requests_session()
    client = Client(test_user, global_session=req_ses)

    # Testing raise_for_status=True
    req_ses_not_raise_for_status = build_requests_session(raise_for_status=False)
    client_norfs = Client(test_user, global_session=req_ses_not_raise_for_status)

    # Test with raise_for_status=True

# Generated at 2022-06-21 20:48:08.954070
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert session.mounts[0].retries is None, "no adapter mounted"
    session = build_requests_session(retry=True)
    assert session.mounts[0].retries.total == 10, "total is 10"
    assert session.mounts[0].retries.status_forcelist == [500, 502, 503, 504], "retry on server side error"
    session = build_requests_session(retry=5)
    assert session.mounts[0].retries.total == 5, "total is 5"
    assert session.mounts[0].retries.status_forcelist == [500, 502, 503, 504], "retry on server side error"

# Generated at 2022-06-21 20:48:09.818304
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    pass



# Generated at 2022-06-21 20:48:10.409106
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session is not None

# Generated at 2022-06-21 20:48:16.704610
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    test_func = LoggedFunction(None)
    test_func.logger = Mock()

    def test_func_0(arg0: str, arg1: int, arg2: str, arg3: float) -> bool:
        return True

    test_func(test_func_0)("arg0", 1, "arg2", 3.14)

    test_func.logger.debug.assert_called_once_with("test_func_0('arg0', 1, 'arg2', 3.14)")
    test_func.logger.debug.reset_mock()

    def test_func_1() -> int:
        return 1

    test_func(test_func_1)()

    test_func.logger.debug.assert_called_once_with("test_func_1 -> 1")
    test_func

# Generated at 2022-06-21 20:48:19.952053
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = None
    try:
        logger = logging.getLogger("test")
        logger.debug("test")
    except Exception as err:
        assert False, err
    assert True


# Generated at 2022-06-21 20:48:31.003411
# Unit test for function build_requests_session
def test_build_requests_session():
    from unittest import TestCase

    with TestCase().subTest(raise_for_status=True, retry=True):
        session = build_requests_session()
        assert session.hooks["response"][0].__name__ == "raise_for_status"
        assert isinstance(session.adapters["http://"].max_retries, Retry)
        assert isinstance(session.adapters["https://"].max_retries, Retry)

    with TestCase().subTest(raise_for_status=False, retry=True):
        session = build_requests_session(raise_for_status=False)
        assert "response" not in session.hooks
        assert isinstance(session.adapters["http://"].max_retries, Retry)

# Generated at 2022-06-21 20:48:41.439481
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session_1 = build_requests_session(raise_for_status=True)
    assert isinstance(requests_session_1, Session)
    requests_session_2 = build_requests_session(raise_for_status=False)
    assert isinstance(requests_session_2, Session)
    requests_session_3 = build_requests_session(raise_for_status=True, retry=False)
    assert isinstance(requests_session_3, Session)
    requests_session_4 = build_requests_session(raise_for_status=True, retry=True)
    assert isinstance(requests_session_4, Session)
    requests_session_5 = build_requests_session(raise_for_status=True, retry=5)

# Generated at 2022-06-21 20:48:54.896630
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Case 1 -- Function without return value
    def foo(a, b, c, d=2, e=3):
        return None

    # Decorator should add debug logging
    logger = Mock()
    logged_foo = LoggedFunction(logger)(foo)
    logged_foo(1, 2, 3)
    logger.debug.assert_called_once_with("foo(1, 2, 3, d=2, e=3)")

    # Case 2 -- Function with return value
    def bar(a, b, c, d=2, e=3):
        return "bar"

    # Decorator should add debug logging
    logger = Mock()
    logged_bar = LoggedFunction(logger)(bar)
    logged_bar(1, 2, 3)

# Generated at 2022-06-21 20:49:03.693169
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(3.14) == "3.14"
    assert format_arg("hello") == "'hello'"
    assert format_arg("  hello  ") == "'hello'"
    assert format_arg([1,2,3]) == "[1, 2, 3]"
    assert format_arg({"a":1,"b":2}) == "{'a': 1, 'b': 2}"
    # assert format_arg({"a":1,"b":2}).strip().replace(' ', '') == "{'a':1,'b':2}"

# Generated at 2022-06-21 20:49:06.993026
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("string") == "'string'"
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"



# Generated at 2022-06-21 20:49:11.241621
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('aa') == "'aa'"
    assert format_arg(1) == '1'
    assert format_arg([1, 2]) == '[1, 2]'
    assert format_arg({'x': 1, 'y': 2}) == "{'x': 1, 'y': 2}"


# Generated at 2022-06-21 20:49:16.280738
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(2) == "2"
    assert format_arg('2') == "'2'"
    assert format_arg('abc d ef') == "'abc d ef'"
    assert format_arg('') == "''"
    assert format_arg(None) == "None"
    assert format_arg(3.1415) == "3.1415"
    assert format_arg(True) == "True"
    assert format_arg([]) == "[]"
    assert format_arg(['a', 'b']) == "['a', 'b']"

# Generated at 2022-06-21 20:49:25.562993
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Setup
    class MockLogger:
        def __init__(self):
            self.info_message = None
            self.debug_message = None

        def info(self, message):
            self.info_message = message

        def debug(self, message):
            self.debug_message = message

    def function(a, b):
        return a + b

    mockLogger = MockLogger()

    # Call __call__
    loggedFunction = LoggedFunction(mockLogger)
    wrappedFunction = loggedFunction(function)
    result = wrappedFunction(10, 20)

    # Assert
    assert result == 30
    assert mockLogger.info_message is None
    assert mockLogger.debug_message == "function(10, 20)"

# Generated at 2022-06-21 20:49:36.486198
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from logger import get_basic_logger
    from contextlib import redirect_stdout

    # Logger and stream to redirect stdout
    logger = get_basic_logger()
    stream = StringIO()

    # Decorate function
    @LoggedFunction(logger)
    def my_func(x, y):
        return x + y

    # Call function
    my_func(2, 3)

    # Write to string
    with redirect_stdout(stream):
        logger.debug("\n" + logger.handlers[0].formatter._fmt.replace("%(message)s", "{message}"))
    s = stream.getvalue()

    # Check result

# Generated at 2022-06-21 20:49:45.732480
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False)
    session.get("https://www.google.com")
    session.get("https://www.google.com")
    session = build_requests_session()
    session.get("https://www.google.com")
    session.get("https://www.google.com")
    session = build_requests_session(retry=False)
    session.get("https://www.google.com")
    session.get("https://www.google.com")
    session = build_requests_session(retry=0)
    session.get("https://www.google.com")
    session.get("https://www.google.com")
    session = build_requests_session(retry=Retry(total=0))

# Generated at 2022-06-21 20:49:56.739949
# Unit test for function build_requests_session
def test_build_requests_session():
    create_session_with_hook = build_requests_session()
    assert create_session_with_hook.hooks == {
        "response": [lambda r, *args, **kwargs: r.raise_for_status()]
    }
    create_session_without_hook = build_requests_session(raise_for_status=False)
    assert create_session_without_hook.hooks == {}
    create_session_with_retry = build_requests_session(retry=True)
    assert create_session_with_retry.adapters.HTTPAdapter.max_retries.total == Retry().total
    create_session_with_retry_count = build_requests_session(retry=5)
    assert create_session_with_retry_count.adapters.HTTPAdapter.max_ret

# Generated at 2022-06-21 20:50:00.427471
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('  2  ') == "'  2  '"
    assert format_arg(2) == '2'
    assert format_arg(2.0) == '2.0'


if __name__ == '__main__':
    test_format_arg()

# Generated at 2022-06-21 20:50:08.002630
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=True, retry=True)
    assert isinstance(session, Session)

# Generated at 2022-06-21 20:50:10.251613
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("str") == "'str'"
    assert format_arg(3.14) == "3.14"



# Generated at 2022-06-21 20:50:14.030424
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger(__name__)

    class A:
        @LoggedFunction(logger)
        def function_name(self, a, b):
            return a + b

    a = A()
    result = a.function_name(1, b=2)
    assert result == 3


# Generated at 2022-06-21 20:50:17.149009
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session()
    assert not isinstance(sess.hooks, list)
    assert sess.hooks["response"][0](object()) is None



# Generated at 2022-06-21 20:50:18.657454
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(logging.getLogger('test'))

# Generated at 2022-06-21 20:50:29.111982
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
        Test for method __call__ of class LoggedFunction
    """
    result_log = []
    test_logger = logging.getLogger()
    test_logger.setLevel(logging.DEBUG)
    test_logger.handlers = [logging.StreamHandler(stream=logging.StringIO())]
    test_logger.handlers[0].terminator = ""

    test_logged_function = LoggedFunction(test_logger)

    def test_func(a, b, c="1", d="2"):
        pass

    test_value = test_logged_function(test_func)
    test_value(1, 2)
    test_value(a=1, b=2, c=3)
    test_value(1, b=3)

# Generated at 2022-06-21 20:50:33.602037
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc def") == "'abc def'"
    assert format_arg("'abc def'") == r"'\'abc def\''"

# Generated at 2022-06-21 20:50:35.397392
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"

# Generated at 2022-06-21 20:50:40.681377
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("simple_logger")
    logging.basicConfig(level=logging.DEBUG)

    @LoggedFunction(logger)
    def foo(x, y):
        return x + y

    foo(1, 2)

    @LoggedFunction(logger)
    def bar(x, y, z='x'):
        return x + y + z

    bar(1, 2)



# Generated at 2022-06-21 20:50:46.561420
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock
    import pytest

    def test_func():
        pass

    expected_result = object()
    test_func.return_value = expected_result

    test_logger = Mock(logging.Logger)

    decorated = LoggedFunction(test_logger)(test_func)

    result = decorated()

    assert result == expected_result

    test_func.assert_called_once()

    test_logger.debug.assert_called_with(
        "test_func()"
    )
    test_logger.debug.assert_called_with(
        "test_func() -> {}".format(repr(expected_result))
    )

    result = decorated(1, 2, 3)

    assert result == expected_result

    test_func.assert_called

# Generated at 2022-06-21 20:51:00.058470
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('abc') == "'abc'"
    assert format_arg(123) == '123'
    assert format_arg(0.5) == '0.5'
    assert format_arg(True) == 'True'
    assert format_arg(None) == 'None'
    assert format_arg(['abc', 123]) == "['abc', 123]"
    assert format_arg(('abc', 123)) == "('abc', 123)"
    assert format_arg(('abc', 123, 0.5, True, None, ['abc', 123])) == "('abc', 123, 0.5, True, None, ['abc', 123])"
    assert format_arg({'a':1, 'b':2}) == "{'a':1, 'b':2}"

# Generated at 2022-06-21 20:51:03.772887
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()
    result = LoggedFunction(logger)
    assert(result != None)


# Generated at 2022-06-21 20:51:11.221272
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # create a file handler
    handler = logging.FileHandler('hello.log')
    handler.setLevel(logging.INFO)

    # create a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # add the handlers to the logger
    logger.addHandler(handler)

    # test case 1
    @LoggedFunction(logger)
    def test_func(a,b,c,d):
        return str(a)+str(b)+str(c)+str(d)

    test_func(1,2,3,4)


# Generated at 2022-06-21 20:51:17.360896
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging

    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
    def foo(a, b):
        return a + b
    def bar(c, d, e):
        return c + d + e
    foo = LoggedFunction(logger)(foo)
    bar = LoggedFunction(logger)(bar)
    assert foo(1, 2) == 3
    assert bar(1, 2, 3) == 6

# Generated at 2022-06-21 20:51:25.921370
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    global logger
    logger = logging.getLogger(__name__) 
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    # Decorate function
    @LoggedFunction(logger)
    def add(x, y):
        return x + y
    print("add(1,2):")
    add(1,2)

'''
test_LoggedFunction()
'''

# Generated at 2022-06-21 20:51:29.878959
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(3) == "3"
    assert format_arg(3.1) == "3.1"
    assert format_arg("stringArg") == "'stringArg'"

# Generated at 2022-06-21 20:51:32.064507
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("a") == "'a'"
    assert format_arg("a b c") == "'a b c'"
    assert format_arg(5) == "5"

# Generated at 2022-06-21 20:51:39.471208
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class FakeLogger(object):

        def debug(self, msg):
            print(f"Debug: {msg}")

    def testFunction(A, B, C="C", D="D"):
        print(f"testFunction({A}, {B}, {C}, {D})")

    loggedFunction = LoggedFunction(FakeLogger())
    loggedFunction(testFunction)(1, 2, 3, 4)
    loggedFunction(testFunction)(1, 3, 4)
    loggedFunction(testFunction)(1, 2)
    loggedFunction(testFunction)(1)

# Generated at 2022-06-21 20:51:41.923908
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    mockLogger = unittest.mock.MagicMock()
    lf = LoggedFunction(mockLogger)
    assert lf.logger == mockLogger


# Generated at 2022-06-21 20:51:48.390265
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=False)
    assert isinstance(session.adapters, dict)
    assert "http://" not in session.adapters
    assert "https://" not in session.adapters

    session = build_requests_session(retry=5)
    retry = session.adapters["http://"].max_retries
    assert isinstance(retry, Retry)
    assert retry.total == 5

    session = build_requests_session(retry=True)
    retry = session.adapters["http://"].max_retries
    assert isinstance(retry, Retry)
    assert retry.total == 3

# Generated at 2022-06-21 20:52:01.066344
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert LoggedFunction(None).__init__(None) == None

# Generated at 2022-06-21 20:52:10.482338
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(42) == "42"
    assert format_arg(3.14) == "3.14"
    assert format_arg("") == "''"
    assert format_arg("  ") == "''"
    assert format_arg("abc") == "'abc'"
    assert format_arg(" abc   ") == "'abc'"
    assert format_arg(["a", "b"]) == "['a', 'b']"
    assert format_arg({"a": "b"}) == "{'a': 'b'}"



# Generated at 2022-06-21 20:52:13.192721
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(1.0) == '1.0'
    assert format_arg('hello') == "'hello'"
    assert format_arg('') == "''"
    assert format_arg('hello world') == "'hello world'"

# Generated at 2022-06-21 20:52:24.026119
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        s = build_requests_session()
    except:
        raise AssertionError("build_requests_session() is broken")
    try:
        s = build_requests_session(retry=1)
    except:
        raise AssertionError("build_requests_session() is broken")
    try:
        s = build_requests_session(retry=Retry())
    except:
        raise AssertionError("build_requests_session() is broken")
    try:
        s = build_requests_session(raise_for_status=False)
    except:
        raise AssertionError("build_requests_session() is broken")

# Generated at 2022-06-21 20:52:31.014410
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(0) == "0"
    assert format_arg("test") == "'test'"
    assert format_arg(" test ") == "'test'"
    assert format_arg("'test'") == "'test'"
    assert format_arg("'test") == "'test'"
    assert format_arg("test'") == "'test'"
    assert format_arg("'test\"") == "'test\"'"



# Generated at 2022-06-21 20:52:35.194929
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    f = LoggedFunction(logging.getLogger(__name__))
    # f(logging.getLogger(__name__))
    print(f)
    print(f.__call__)
    f1 = f(test_args)
    print(f1)
    f1()

# Generated at 2022-06-21 20:52:38.393938
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.1) == "1.1"
    assert format_arg("hello") == "'hello'"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:52:39.888349
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(" abc") == "'abc'"
    assert format_arg(123) == "123"

# Generated at 2022-06-21 20:52:49.552423
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session()
    assert isinstance(s, Session)
    assert len(s.hooks.get("response", [])) == 0
    s = build_requests_session(raise_for_status=True)
    assert len(s.hooks.get("response", [])) == 1
    s = build_requests_session(retry=True)
    assert isinstance(s.adapters.get("http://"), HTTPAdapter)
    s = build_requests_session(retry=Retry())
    assert isinstance(s.adapters.get("http://"), HTTPAdapter)

# Generated at 2022-06-21 20:52:59.380087
# Unit test for function build_requests_session
def test_build_requests_session():

    session = build_requests_session()

    assert session is not None
    assert isinstance(session, Session)

    # Check that the hook was installed
    assert "response" in session.hooks
    assert len(session.hooks["response"]) == 1
    hook = session.hooks["response"][0]
    assert hook.__name__ == "lambda"
    hook(None)

    # Check that the HTTPAdapter is applied
    assert any(isinstance(adapter, HTTPAdapter) for adapter in session.adapters.values())
    # Only one adapter should exist
    assert len(session.adapters) == 1
    adapter = next(iter(session.adapters.values()))
    assert adapter.max_retries.total == 10
    assert adapter.max_retries.connect == 2
    assert adapter.max_retries

# Generated at 2022-06-21 20:53:28.758444
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("arg1") == "'arg1'"
    assert format_arg("arg2   ") == "'arg2   '"
    assert format_arg("arg3\t") == "'arg3\t'"
    assert format_arg("arg4\n") == "'arg4\n'"
    assert format_arg("arg5\r") == "'arg5\r'"
    assert format_arg(3) == "3"
    assert format_arg(3.0) == "3.0"
    assert format_arg(0) == "0"
    assert format_arg(0.0) == "0.0"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"

# Generated at 2022-06-21 20:53:30.060485
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session(retry=False)) is Session

# Generated at 2022-06-21 20:53:32.426032
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("test") == "'test'"
    assert format_arg("test with space ") == "'test with space '"

# Generated at 2022-06-21 20:53:35.592273
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Arrange
    class logger:
        def debug(self, message):
            print(message)
    
    log_function = LoggedFunction(logger())
    @log_function
    def add(x, y):
        return x + y
    
    add(1, 2)

# Generated at 2022-06-21 20:53:39.408394
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import unittest
    import logging

    class TestLoggedFunction(unittest.TestCase):

        def test__call__(self):
            logger = logging.Logger("tst")
            logger.setLevel(logging.DEBUG)
            LoggedFunction(logger)

    unittest.main()


# Generated at 2022-06-21 20:53:45.233031
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    @LoggedFunction(logger=None)
    def LoggedFunction_1(arg1, arg2):
        return arg1 + arg2
    assert(LoggedFunction_1(1, 1) == 2)
    try:
        LoggedFunction(None)
        assert(0)
    except TypeError:
        pass


# Generated at 2022-06-21 20:53:52.703747
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def func1(a, b, foo="bar"):
        return "func1"

    def func2(a, b, c, foo="bar"):
        return "func2"

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    @LoggedFunction(logger)
    def wrapped_func1(a, b, foo="bar"):
        return "wrapped_func1"

    @LoggedFunction(logger)
    def wrapped_func2(a, b, c, foo="bar"):
        return "wrapped_func2"

    func1(1, 2)
    wrapped_func1(1, 2)
    func1(1, 2, foo="foo")

# Generated at 2022-06-21 20:54:01.551767
# Unit test for function build_requests_session
def test_build_requests_session():
    import logging
    logging.basicConfig()
    session = build_requests_session(retry=False)
    assert len(session.adapters) == 0
    session = build_requests_session(retry=Retry(total=10))
    assert len(session.adapters) == 2
    assert isinstance(session.adapters["http://"].max_retries, Retry)
    assert session.adapters["http://"].max_retries.total == 10
    assert session.adapters["http://"].max_retries.status_forcelist == Retry.DEFAULT_STATUS_FORCELIST
    session = build_requests_session(retry=True)
    assert len(session.adapters) == 2

# Generated at 2022-06-21 20:54:08.733911
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("test_LoggedFunction")
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    logged_func = LoggedFunction(logger)
    
    def test_function(a, b):
        return a + b
    
    @logged_func
    def test_function1(a, b, *arg, **karg):
        return a + b
    
    res = test_function(1, 2)
    res2 = test_function1(1, 2, 3, a=1, b=2)


# Generated at 2022-06-21 20:54:10.839064
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session() is not None



# Generated at 2022-06-21 20:55:03.305611
# Unit test for function build_requests_session
def test_build_requests_session():
    import unittest.mock as mock

    def mock_retry(retry_count=3):
        def mock_adapter(max_retries):
            assert max_retries.total == retry_count
            return mock.Mock()

        return mock_adapter

    # Test with raise_for_status=True, retry=True
    with mock.patch("requests.Session", autospec=True) as mock_session:
        mock_session.return_value.hooks = {}
        mock_session.return_value.mount = mock.Mock()
        session = build_requests_session(raise_for_status=True, retry=True)
        assert len(session.hooks["response"]) == 1
        assert session.hooks["response"][0]
        session.mount.assert_has_

# Generated at 2022-06-21 20:55:11.389133
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from io import StringIO
    from unittest import TestCase, main
    _buffer = StringIO()

    def test_function(x, y, z=1):
        return x + y + z

    _logger = logging.getLogger(__name__)
    _logger.setLevel(level=logging.DEBUG)
    _logger.addHandler(logging.StreamHandler(_buffer))
    _logger.handlers[0].setFormatter(logging.Formatter("%(message)s"))

    logged_function = LoggedFunction(_logger)

    logged_function.__call__(test_function)(1, y=2, z=3)
    _logger.handlers[0].flush()

# Generated at 2022-06-21 20:55:14.612365
# Unit test for function build_requests_session
def test_build_requests_session():
    def inner(**kwargs):
        session = build_requests_session(**kwargs)
        assert isinstance(session, Session)
        return session
    session = inner()
    for raise_for_status in [True, False, None]:
        for retry in [True, False, None, 1, Retry(total=10)]:
            inner(raise_for_status=raise_for_status, retry=retry)




# Generated at 2022-06-21 20:55:20.450575
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("abcd") == "'abcd'"
    assert format_arg(" abcd ") == "' abcd '"
    assert format_arg(" 'abcd' ") == "' 'abcd' '"
    assert format_arg(1234) == "1234"
    assert format_arg("1234") == "'1234'"

# Generated at 2022-06-21 20:55:22.743145
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('this is a string') == "'this is a string'"
    assert format_arg(1234) == "1234"
    assert format_arg(None) == "None"



# Generated at 2022-06-21 20:55:23.772271
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    test = LoggedFunction()
    assert test.logger is None


# Generated at 2022-06-21 20:55:28.490070
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import unittest
    import unittest.mock

    class MyTestCase(unittest.TestCase):
        def test_logging(self):
            logger = logging.getLogger("test.logged_function")

            def my_function(value):
                return "my_function_result"

            logged_func = LoggedFunction(logger)(my_function)
            logged_func("my_value")

            logger.debug.assert_called_once_with("my_function('my_value')")

    unittest.main()


# Generated at 2022-06-21 20:55:35.150085
# Unit test for function format_arg
def test_format_arg():
    a = 's'
    b = "s"
    c = " ' "
    d = 1
    e = 0.11
    f = None
    g = ''
    assert(format_arg(a) == "'s'")
    assert(format_arg(b) == "'s'")
    assert(format_arg(c) == "' \' '")
    assert(format_arg(d) == '1')
    assert(format_arg(e) == '0.11')
    assert(format_arg(f) == 'None')
    assert(format_arg(g) == "''")


# Generated at 2022-06-21 20:55:36.770302
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    from logging import Logger

    logger = Logger(name="LoggedFunction")
    tmp = LoggedFunction(logger)

# Generated at 2022-06-21 20:55:45.738665
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger(__name__)

    decorator = LoggedFunction(logger)

    @decorator
    def foo(a, b=1):
        return a + b

    @decorator
    def bar(a, b, c=3, d=4):
        return a + b + c + d

    @decorator
    def void():
        pass

    assert foo(10) == 11
    assert bar(10, 20) == 37

    assert void() is None

    root_logger = logging.getLogger()

    list_handler = logging.handlers.MemoryHandler(capacity=999)
    list_handler.setFormatter(logging.Formatter("%(message)s"))
    list_handler.setLevel(logging.DEBUG)