

# Generated at 2022-06-21 20:46:25.698810
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("value with 'quote'") == "'value with 'quote''"
    assert format_arg("value with \"quote\"") == "'value with \"quote\"'"
    assert format_arg("value with (parenthesis)") == "'value with (parenthesis)'"
    assert format_arg("value with \t\t\t whitespace") == "'value with \t\t\t whitespace'"
    assert format_arg(None) == "None"
    assert format_arg(4) == "4"
    assert format_arg(4.0) == "4.0"

# Generated at 2022-06-21 20:46:27.451437
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

# Unit tests for function LoggedFunction

# Generated at 2022-06-21 20:46:30.030301
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == '123'
    assert format_arg(" 123 ") == "' 123 '"
    assert format_arg("123") == "'123'"

# Generated at 2022-06-21 20:46:33.688326
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == '5'
    assert format_arg('  test  ') == "'test'"
    assert format_arg(None) == 'None'

# Generated at 2022-06-21 20:46:40.978307
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("42") == "'42'"
    assert format_arg("'abc def'") == "'abc def'"
    assert format_arg('"abc def') == '"abc def"'
    assert format_arg(42) == "42"
    assert format_arg(["array", "of", "strings"]) == "['array', 'of', 'strings']"
    assert format_arg({"a": 1, "b": 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 20:46:46.334117
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(3.14) == '3.14'
    assert format_arg('abc') == "'abc'"
    assert format_arg('a b c') == "'a b c'"
    assert format_arg('') == "''"
    print('Test function format_arg passed...')


# Generated at 2022-06-21 20:46:58.077756
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(retry=False)
    assert isinstance(s, Session)
    assert len(s.__dict__["adapters"]) == 0
    assert "response" in s.__dict__["hooks"]

    s = build_requests_session(retry=True)
    assert isinstance(s, Session)
    assert len(s.__dict__["adapters"]) == 2
    assert "http://" in s.__dict__["adapters"]
    assert "https://" in s.__dict__["adapters"]
    for adapter in s.__dict__["adapters"].values():
        assert isinstance(adapter, HTTPAdapter)
        assert isinstance(adapter.max_retries, Retry)
        assert isinstance(adapter.max_retries.total, int)

# Generated at 2022-06-21 20:47:01.881196
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abc") == "'abc'"
    assert format_arg(None) == "None"
    assert format_arg("abc d ") == "'abc d'"

# Generated at 2022-06-21 20:47:12.839968
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session()

    # test default config
    assert requests_session.hooks == {}
    assert requests_session.adapters["https://"] == requests_session.adapters["http://"]
    assert requests_session.adapters["https://"].max_retries.total == 3
    assert requests_session.adapters["https://"].max_retries.read == 0

    requests_session = build_requests_session(False)
    # test config without install raise_for_status hook
    assert requests_session.hooks == {}

    requests_session = build_requests_session(retry=False)
    # test config with retry=False
    assert requests_session.hooks == {}
    assert requests_session.adapters.keys() == []

    requests_session = build_requests

# Generated at 2022-06-21 20:47:15.001003
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    sample_func = LoggedFunction(logger=logging.getLogger())(sample_func)
    assert sample_func(123, "456", word="hello world") == True


# Generated at 2022-06-21 20:47:19.490291
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg('a') == "'a'"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:47:24.468991
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    from loguru import logger
    logging.basicConfig(level=logging.DEBUG)

    lgf = LoggedFunction(logger)
    @lgf
    def test_function(x, y, z=1):
        return x / y + z

    assert test_function(10, 5, z=2) == 3

# Generated at 2022-06-21 20:47:30.426850
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    # test_logger = logging.getLogger(__name__)
    # test_logger.setLevel(logging.DEBUG)
    # handler = logging.StreamHandler()
    # handler.setLevel(logging.DEBUG)
    # test_logger.addHandler(handler)
    # test_logger.propagate = False

    # def test_func(a, b, c):
    #     return a+b+c
    # logged_func = LoggedFunction(test_logger)(test_func)
    # result = logged_func(1, 2, 3)
    # assert result == 6

# Generated at 2022-06-21 20:47:33.759578
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("test") == "'test'"
    assert format_arg(1) == "1"



# Generated at 2022-06-21 20:47:42.565664
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False)
    assert session.hooks == {}
    assert isinstance(session.adapters['http://'], HTTPAdapter)
    assert isinstance(session.adapters['https://'], HTTPAdapter)
    assert session.adapters['http://'].max_retries == Retry(0)
    assert session.adapters['https://'].max_retries == Retry(0)

    session = build_requests_session()

# Generated at 2022-06-21 20:47:50.285088
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    @LoggedFunction(logger=logging.getLogger())
    def my_logged_function(a, b=None):
        return 1, b

    assert my_logged_function.__name__ == my_logged_function.__name__, "Name changed"
    assert my_logged_function.__doc__ == my_logged_function.__doc__, "doc changed"
    assert my_logged_function(1) == (1, None)

# Generated at 2022-06-21 20:47:59.821838
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test raise_for_status=False and retry=False
    session = build_requests_session(raise_for_status=False, retry=False)
    assert "response" not in session.hooks

    # Test raise_for_status=True and retry=False
    session = build_requests_session(raise_for_status=True, retry=False)
    assert "response" in session.hooks

    # Test raise_for_status=True and retry=True
    session = build_requests_session(raise_for_status=True, retry=True)
    assert "response" in session.hooks

    # Test raise_for_status=True and retry=int
    session = build_requests_session(raise_for_status=True, retry=3)
    assert "response"

# Generated at 2022-06-21 20:48:06.971926
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(True, True)
    assert s.hooks.get("response") is not None
    s = build_requests_session(True, False)
    assert s.hooks == {}
    s = build_requests_session(False, True)
    assert s.hooks == {}
    s = build_requests_session(False, 3)
    assert s.hooks == {}

# Generated at 2022-06-21 20:48:14.720566
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    global test_data
    test_data = []

    class Logger:
        def debug(self, message):
            test_data.append(message)

    logger = Logger()

    logged_func = LoggedFunction(logger)

    def test_func(x, y, z):
        return x + y + z

    assert test_data == []
    result = logged_func(test_func)(1, 2, 3)
    assert result == 6
    assert test_data[0] == "test_func(1, 2, 3)"
    assert test_data[1] == "test_func -> 6"

    result = logged_func(test_func)(100, y=200, z=300)
    assert result == 600

# Generated at 2022-06-21 20:48:19.793306
# Unit test for function format_arg
def test_format_arg():
    assert format_arg('  abcdef  ') == "'  abcdef  '"
    assert format_arg('abcdef') == "'abcdef'"
    assert format_arg(None) == 'None'
    assert format_arg(0.3456) == '0.3456'
    assert format_arg(1) == '1'

# Generated at 2022-06-21 20:48:26.227919
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(None) == "None"
    assert format_arg("foo") == "'foo'"
    assert format_arg("foo\nbar") == "'foo bar'"
    assert format_arg({"foo": 2}) == "{'foo': 2}"

# Generated at 2022-06-21 20:48:32.592635
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(raise_for_status=False)
    assert isinstance(s, Session)
    
    s = build_requests_session(retry=False)
    assert isinstance(s, Session)
    
    s = build_requests_session(retry=5)
    assert isinstance(s, Session)
    
    s = build_requests_session(retry=Retry())
    assert isinstance(s, Session)


# Generated at 2022-06-21 20:48:41.719076
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import io

    buffer = io.StringIO()
    handler = logging.StreamHandler(buffer)
    logger = logging.getLogger(__name__)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    try:
        @LoggedFunction(logger)
        def myfunc(a, b, c=5):
            return a * b * c

        assert myfunc(2, 3, c=4) == 24
        assert buffer.getvalue() == "test_LoggedFunction___call__ myfunc(2, 3, c=4)\ntest_LoggedFunction___call__ -> 24\n"
    except:
        logger.removeHandler(handler)
        raise

# Generated at 2022-06-21 20:48:45.063281
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger()
    handler = logging.StreamHandler()
    logger.addHandler(handler)

    @LoggedFunction(logger)
    def add(a, b = 100):
        return a + b

    add(10)
    add(10, 20)

# Generated at 2022-06-21 20:48:56.014626
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import sys
    from contextlib import contextmanager
    from io import StringIO
    from logging import getLogger, StreamHandler, DEBUG

    @LoggedFunction(getLogger("test"))
    def my_function(x, y):
        return x + y

    @contextmanager
    def capture_stdout():
        original_stdout = sys.stdout
        sys.stdout = StringIO()
        yield sys.stdout
        sys.stdout = original_stdout

    logger = getLogger("test")
    handler = StreamHandler(sys.stdout)
    logger.addHandler(handler)
    logger.setLevel(DEBUG)

    my_function(1, 2)
    with capture_stdout() as stdout:
        my_function(1, 2)
    handler.close()

# Generated at 2022-06-21 20:49:05.577712
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(1) == "1"
    assert format_arg("") == "''"
    assert format_arg("a") == "'a'"
    assert format_arg("abc") == "'abc'"
    assert format_arg("abc ") == "'abc '"
    assert format_arg("123") == "'123'"
    assert format_arg("true") == "'true'"
    assert format_arg("True") == "'True'"
    assert format_arg("FalSE") == "'FalSE'"



# Generated at 2022-06-21 20:49:14.545487
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class MockLogger:
        def __init__(self):
            self.debug_log = []
        def debug(self, message: str):
            self.debug_log.append(message)

    def test_function(a, b=None, c=None, d=None, e=None, f=None, g=None, h=None):
        return a + b

    test_function.__name__ = "test_function"

    # test logger
    logger = MockLogger()
    # test LoggedFunction
    f = LoggedFunction(logger)
    f2 = f(test_function)
    f2()
    f2(1)
    f2(1, 2)
    f2(a=1, b=2)
    f2(1, 2, a=3)

# Generated at 2022-06-21 20:49:19.708983
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("a") == "'a'"
    assert format_arg(1) == "1"
    assert format_arg(None) == "None"
    assert format_arg(["a", "b"]) == "['a', 'b']"
    assert format_arg({1: "a", 2: "b"}) == "{1: 'a', 2: 'b'}"
    assert format_arg({1: "a", 2: None}) == "{1: 'a', 2: None}"
    assert format_arg({1: "a", 2: None, 3: {"b": "b", "c": None}}) == "{1: 'a', 2: None, 3: {'b': 'b', 'c': None}}"
    assert format_arg("a b") == "'a b'"

# Generated at 2022-06-21 20:49:27.103430
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import patch, call
    import datetime

    from .logging import get_logger
    from .config import set_global_config
    
    logger = get_logger()
    def test_func_1(a, b, c=4, d=5, e=6):
        pass
    def test_func_2():
        return 'abcdefg'

    logger.setLevel('DEBUG')
    with patch.object(logger, 'debug') as mock_debug:
        set_global_config('log_function_arguments', True)
        LoggedFunction(logger)(test_func_1)(1, 2)
        LoggedFunction(logger)(test_func_1)(1, 2, e=10)
        LoggedFunction(logger)(test_func_2)()

        mock_debug

# Generated at 2022-06-21 20:49:30.226841
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg("haha'") == "'haha'''"

# Generated at 2022-06-21 20:49:44.925673
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    # Test for return value
    @LoggedFunction(logger = None)
    def test_func_return_value():
        return 0
    assert test_func_return_value() == 0

    # Test for function call with no arguments
    @LoggedFunction(logger = None)
    def test_func_no_arguments():
        return 0
    test_func_no_arguments()

    # Test for function call with arguments, with no keywords
    @LoggedFunction(logger = None)
    def test_func_with_arguments(a, b):
        return 0
    test_func_with_arguments(1, 2)

    # Test for function call with arguments, with keywords

# Generated at 2022-06-21 20:49:49.559850
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1234) == '1234'
    assert format_arg('Hello, World') == "'Hello, World'"
    assert format_arg([1,2,3,4]) == '[1, 2, 3, 4]'
    assert format_arg((1,2,3,4)) == '(1, 2, 3, 4)'
    assert format_arg({1,2,3,4}) == '{1, 2, 3, 4}'
    assert format_arg({'name':'Jack'}) == "{'name': 'Jack'}"
    assert format_arg(None) == 'None'

# Generated at 2022-06-21 20:49:57.823140
# Unit test for function format_arg
def test_format_arg():
    assert '" 1 "' == format_arg(" 1 ")
    assert '1' == format_arg(1)
    assert '1.3' == format_arg(1.3)
    assert '1.3' == format_arg(1.3)
    assert '1.3' == format_arg(1.3)

# Generated at 2022-06-21 20:50:08.328179
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    #create an instance of LoggedFunction
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    #create handler
    #handler = logging.StreamHandler(sys.stdout)
    handler = logging.FileHandler('./output.log')
    handler.setLevel(logging.DEBUG)

    #create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    #add formatter to the file handler
    handler.setFormatter(formatter)
    
    #add handler to the logger
    logger.addHandler(handler)
    lf = LoggedFunction(logger)
    assert lf.logger is not None
    assert lf.logger.level is not logging.ERROR
   

# Generated at 2022-06-21 20:50:14.754526
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Test") == "'Test'"
    assert format_arg("Test") == f"'Test'"
    assert format_arg([1,2,3]) == "[1, 2, 3]"
    assert format_arg([1,2,3]) != f"[1, 2, 3]"
    assert format_arg({"key":"value"}) == "{'key': 'value'}"
    assert format_arg({"key":"value"}) != f"{'key': 'value'}"
    assert format_arg(True) == "True"
    assert format_arg(True) != f"True"

# Generated at 2022-06-21 20:50:20.763391
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    test_logger = logging.getLogger("test_logger")
    test_logger.setLevel(logging.DEBUG)
    test_log = LoggedFunction(test_logger)
    def test_func(a,b,*args,**kwargs):
        return(a,b,args,kwargs)
    test_log(test_func)(1,2,3,4,c=1,d=2)


# Generated at 2022-06-21 20:50:23.772218
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger(__name__)
    lf = LoggedFunction(logger)
    assert lf.logger == logger


# Generated at 2022-06-21 20:50:30.259109
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    lf = LoggedFunction()
    lf.logger = True
    lf.__call__(True)
    lf.__call__("Unit Test")
    lf.__call__("Unit Test", "__call__")
    lf.__call__("Unit Test", "__call__", "Logger")
    lf.__call__("Unit Test", "__call__", "Logger", "__call__")
    lf.__call__("Unit Test", "__call__", "Logger", "__call__", "logger")

# Generated at 2022-06-21 20:50:35.254332
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("") == "''"
    assert format_arg(" ") == "' '"
    assert format_arg("a") == "'a'"
    assert format_arg(" a") == "' a'"
    assert format_arg("a ") == "'a '"
    assert format_arg(" a ") == "' a '"

# Generated at 2022-06-21 20:50:39.640950
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(5) == "5"
    assert format_arg(9.9) == "9.9"
    assert format_arg("hello") == "'hello'"
    assert format_arg(" hello ") == "' hello '"



# Generated at 2022-06-21 20:50:58.403778
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLogger:
        log_info = None
        
        def debug(self, log_info):
            self.log_info = log_info
    
    logger = TestLogger()
    @LoggedFunction(logger)
    def func(arg_1, arg_2, *args, kwarg_1=None, kwarg_2=3, **kwargs):
        pass
    
    func(1, 2, 3, 4, kwarg_1="str", kwarg_2=None)
    assert logger.log_info == "func(1, 2, 3, 4, kwarg_1='str', kwarg_2=None)"

    func(1, 2, 3, 4)
    assert logger.log_info == "func(1, 2, 3, 4)"


# Generated at 2022-06-21 20:51:03.505595
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class TestLogger:
        def debug(self, *args, **kwargs):
            pass

    logger = TestLogger()
    lf = LoggedFunction(logger)
    assert lf.__class__ == LoggedFunction
    assert lf.logger == logger

# Generated at 2022-06-21 20:51:14.604616
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import random
    import unittest
    from unittest.mock import patch, MagicMock

    from . import util

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = MagicMock()
    logger.addHandler(handler)

    class TestLoggedFunction(unittest.TestCase):
        def test_logged_func(self):
            # Arrange
            test_cases = [
                (random.randint(0, 100), random.randint(0, 100))
                for _ in range(0, 100)
            ]

            @LoggedFunction(logger)
            def gcd(a, b):
                a, b = max(a, b), min(a, b)
                while b != 0:
                    a

# Generated at 2022-06-21 20:51:20.468571
# Unit test for function build_requests_session
def test_build_requests_session():
    from enum import Enum
    from django.conf import settings
    from django.test import TestCase

    settings.configure()

    class HttpResponseCode(Enum):
        OK = 200
        BAD_REQUEST = 400
        NOT_FOUND = 404
        TOO_MANY_REQUESTS = 429
        INTERNAL_SERVER_ERROR = 500

    def _get_httpbin_response(session, status_code):
        return session.get(
            "https://httpbin.org/status/{}".format(status_code)
        ).status_code

    session = build_requests_session()
    self.assertEquals(
        _get_httpbin_response(session, HttpResponseCode.OK.value),
        HttpResponseCode.OK.value,
    )


# Generated at 2022-06-21 20:51:24.637922
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg("abc") == "'abc'"
    assert format_arg(" 123 ") == "' 123 '"
    assert format_arg(["a", "b"]) == "['a', 'b']"


# Generated at 2022-06-21 20:51:35.945337
# Unit test for function build_requests_session
def test_build_requests_session():
    from unittest import TestCase
    from unittest.mock import patch

    class TestCase(TestCase):
        @patch('requests.Session')
        @patch('requests.adapters.HTTPAdapter')
        def test_build_requests_session(self, mock_adapter, mock_session):
            build_requests_session()
            mock_session.assert_called_once_with()
            mock_session.mount.assert_has_calls(
                [
                    patch.call('http://', mock_adapter.return_value),
                    patch.call('https://', mock_adapter.return_value),
                ]
            )
            mock_adapter.assert_called_once_with(max_retries=retry)

    retry = Retry()
    TestCase().test_build_requ

# Generated at 2022-06-21 20:51:45.658358
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = logging.Logger(name='test')
    def logged_func(*args, **kwargs):
        return args, kwargs

    test_func = LoggedFunction(logger)(logged_func)

    # test no args
    result = test_func()
    assert result == ((), {})

    # test only args
    result = test_func(1, 2, 3)
    assert result == ((1, 2, 3), {})

    # test only kwargs
    result = test_func(a=1, b=2, c=3)
    assert result == ((), {'a': 1, 'b': 2, 'c': 3})

    # test both args and kwargs
    result = test_func(1, 2, 3, a=4, b=5, c=6)

# Generated at 2022-06-21 20:51:55.982650
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import Mock

    test_logger = Mock(spec=logging.Logger)
    logged_func = LoggedFunction(test_logger)

    @logged_func
    def test_func(*args, **kwargs):
        return (args, kwargs)

    test_func(1, 2, 3, cat="dog", rabbit="moose")
    expected_debug_call_args = [
        (
            "test_func(1, 2, 3, cat='dog', rabbit='moose')",
            (),
            {},
        ),
        (
            "test_func -> ((1, 2, 3), {'cat': 'dog', 'rabbit': 'moose'})",
            (),
            {},
        ),
    ]
    assert test_logger.debug

# Generated at 2022-06-21 20:52:02.162996
# Unit test for function format_arg
def test_format_arg():
    assert "\'hi\'" == format_arg("hi")
    assert "\'hi\'" == format_arg(" hi ")
    assert "1" == format_arg(1)
    assert "1.2" == format_arg(1.2)
    assert "False" == format_arg(False)
    assert "True" == format_arg(True)
    assert "None" == format_arg(None)

# Generated at 2022-06-21 20:52:12.126789
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Unit tests for LoggedFunction, method __call__.
    """
    class FakeLogger:
        """
        Create a fake logger object.
        """
        def debug(self, msg):
            """
            Record a debug message.
            """
            self.debug_msg = msg

    def my_function(a, b=3):
        """
        A fake function to test LoggedFunction.
        """
        return (a, b)

    log = FakeLogger()
    for func in [my_function, str.upper]:
        # Create a LoggedFunction object.
        log_func = LoggedFunction(log)

        # Test the function.

# Generated at 2022-06-21 20:52:35.104467
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
  logger = "Logger"
  obj = LoggedFunction(logger)
  assert obj.logger == logger

# Generated at 2022-06-21 20:52:43.434352
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import os, sys, tempfile, logging
    assert os.getcwd() == sys.path[0]
    original_wd = os.getcwd()
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            os.chdir(temp_dir)
            logger = logging.getLogger(__name__)
            
            @LoggedFunction(logger)
            def test_function(x):
                return x + 1
            
            test_function(1)
            test_function(1, 2, 3)
            test_function(x=2)
            test_function(y=1)
            test_function(x=2, y=1)
    finally:
        os.chdir(original_wd)

test_LoggedFunction___call__()

# Generated at 2022-06-21 20:52:54.652652
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    logging.basicConfig(level=logging.DEBUG, format="[%(asctime)s][%(levelname)s]%(message)s")
    logger = logging.getLogger("test")
    @LoggedFunction(logger)
    def multi_arg_function(a, b="b", c=None):
        pass
    multi_arg_function("a", "b")
    multi_arg_function("a", c=None)
    multi_arg_function("a", c="c")
    multi_arg_function("a")
    multi_arg_function("a", c=1)
    multi_arg_function()
    multi_arg_function(c=None)



# Generated at 2022-06-21 20:52:59.698582
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("foo") == "'foo'"
    assert format_arg("foo bar") == "'foo bar'"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(None) == "None"
    assert format_arg([1, 2, 3]) == "[1, 2, 3]"
    assert format_arg((1, 2, 3)) == "(1, 2, 3)"


# Generated at 2022-06-21 20:53:10.508292
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.auth == None

    session = build_requests_session(raise_for_status=False)
    assert 'response' not in session.hooks

    session = build_requests_session(retry=False)
    assert session.adapters['http://'].max_retries.total == 0
    assert session.adapters['https://'].max_retries.total == 0

    session = build_requests_session(retry=1)
    assert session.adapters['http://'].max_retries.total == 1
    assert session.adapters['https://'].max_retries.total == 1

    retry = Retry(total=2)
    session = build_requests_session(retry=retry)

# Generated at 2022-06-21 20:53:13.897167
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    logger = Mock()
    fun = LoggedFunction(logger)
    f = fun(lambda x: x)
    f(1,2,3,a=3,b=4)

    logger.debug.assert_called_once()
    assert "3, a=3, b=4)" in logger.debug.call_args[0]

# Generated at 2022-06-21 20:53:18.297690
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("testLogger")
    def foo(x, y):
        return x + y
    logged_foo = LoggedFunction(logger)(foo)
    logged_foo(3, 7)
    logged_foo(3)

# Generated at 2022-06-21 20:53:25.611529
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    # Set up logger
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    log = logging.getLogger("lct")

    # Prepare the test decorator
    @LoggedFunction(log)
    def foo(s, d):
        return f"{s} is {d}"

    # Test with some inputs
    assert foo("Bob", "a nice guy") == "Bob is a nice guy"
    assert foo(1, "two") == "1 is two"



# Generated at 2022-06-21 20:53:28.850584
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger("SubLogger")
    def foo():
        return "foo"
    a = LoggedFunction(logger)
    a(foo)



# Generated at 2022-06-21 20:53:32.303125
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    cfg = dict(Logging=dict(level='DEBUG'))
    logger = get_logger(cfg)
    lf = LoggedFunction(logger)

    @lf
    def foo(x):
        return x ** 2
    foo(3)

test_LoggedFunction()

# Generated at 2022-06-21 20:54:22.030773
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from requests.exceptions import HTTPError

    # raise_for_status is True, retry is True
    session = build_requests_session()
    with pytest.raises(HTTPError):
        session.get("https://httpbin.org/status/403")

    # retry is False
    session = build_requests_session(retry=False)
    with pytest.raises(HTTPError):
        session.get("https://httpbin.org/status/403")

    # retry is an int
    session = build_requests_session(retry=3)
    # retry 3 times, request success on 3rd time
    session.get("https://httpbin.org/status/403")

    # retry is an instance of Retry

# Generated at 2022-06-21 20:54:23.169837
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("'") == "'\\''"

# Generated at 2022-06-21 20:54:29.724843
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class TestLoggedFunction:
        def __init__(self):
            self.test_logs = []

        def debug(self, *args):
            self.test_logs.append(args[0])

        def assert_logs_contains(self, log):
            assert log in self.test_logs
            print(f'Test of assert_logs_contains success: "{log}" in "{self.test_logs}"')

    class TestFunctionClass:
        def __init__(self):
            self.logger = TestLoggedFunction()

        @LoggedFunction(logger=None)
        def test1(self):
            self.logger.debug("test1()")


# Generated at 2022-06-21 20:54:33.374181
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=Retry(total=3))
    try:
        session.get('http://httpbin.org/status/500')
    except Exception:
        pass

# Generated at 2022-06-21 20:54:41.123146
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import sys

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    @LoggedFunction(logger)
    def test(a, b, c=None, d=0):
        return a + b + c + d

    test(1, 2, 3, 4)

    test(1, 2, d=4)

    test(1, 2, 3)

    test(1, 2)

    test(1, b=2, c=3, d=4)

    test(1, b=2, c=3)

    test(1, b=2)

    test(1)

    test.__qualname__

    test.__annotations__

    test.__annotations__

# Generated at 2022-06-21 20:54:42.397903
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from cxtpy.metrics_functions import test_logged_function
    test_logged_function()

# Generated at 2022-06-21 20:54:46.295660
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests import RequestException

    @build_requests_session(raise_for_status=True)
    def test_raise_for_status(session):
        response = session.get("https://google.com/not-found")
        # Should raise RequestException
        response.raise_for_status()

    try:
        test_raise_for_status()
    except RequestException:
        pass
    else:
        raise AssertionError("should raise RequestException")

    @build_requests_session(retry=2)
    def test_retry(session):
        response = session.get("http://www.google.com")
        # Retries should be enabled
        response.raise_for_status()

    test_retry()


# Generated at 2022-06-21 20:54:54.123097
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import unittest.mock as mock
    from .test_utils import LoggerStub

    # Arrange
    logger = LoggerStub()
    logged_function = LoggedFunction(logger)

    # Act
    @logged_function
    def testfunction(a, b):
        return a, b

    # Assert
    assert testfunction(1, 2) == (1, 2), "Logged function should return value"
    assert len(logger.debug_log) == 2, "Logged function should log once before and once after"
    assert (
        logger.debug_log[0] == "testfunction(1, 2)"
    ), "Logging should contain arguments with values"

# Generated at 2022-06-21 20:54:57.898950
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.23) == "1.23"
    assert format_arg("a") == "'a'"
    assert format_arg(" abc ") == "' abc '"


# Generated at 2022-06-21 20:55:01.597119
# Unit test for function format_arg
def test_format_arg():
    assert(format_arg(1) == '1')
    assert(format_arg(' abc ') == "' abc '")
    assert(format_arg('abc') == "'abc'")

# Generated at 2022-06-21 20:55:56.415303
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    Test build_requests_session, check whether it raises for status and retry for connections.
    """
    # FIXME: Make these parameterized tests
    # No raise for status
    session = build_requests_session(raise_for_status=False)
    response = session.get("http://www.invalid.url/")
    print(response.content)
    # raise for status
    session = build_requests_session(raise_for_status=True)
    with pytest.raises(requests.exceptions.HTTPError):
        response = session.get("http://www.invalid.url/")
    # No retry
    session = build_requests_session(retry=False)

# Generated at 2022-06-21 20:55:59.388663
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(5) == "5"
    assert format_arg("abc") == "'abc'"
    assert format_arg("a'6c") == "'a'6c'"
    assert format_arg("a,b") == "'a,b'"
    assert format_arg("a\nb") == "'a\nb'"

# Generated at 2022-06-21 20:56:09.993456
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock

    logger_mock = Mock()
    LoggedFunction(logger_mock).__call__(
        lambda first_arg, second_arg="default_value", third_arg=None: None
    )(
        "first_arg_value",
        "second_arg_value",
        third_arg="third_arg_value",
        extra_arg="extra_arg_value",
    )
    logger_mock.debug.assert_called_once_with(
        "lambda(first_arg_value, second_arg_value, third_arg=third_arg_value, extra_arg=extra_arg_value)"
    )

# Generated at 2022-06-21 20:56:20.825206
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from unittest.mock import Mock
    from logger import get_logger
    from os import path

    log_file = path.join(path.dirname(path.abspath(__file__)), "unit_test.log")
    logger = get_logger(log_file=log_file)
    func = Mock(return_value="{'some': 'json'}")

    logged_func = LoggedFunction(logger)(func)
    logged_func(1, 2, k1="v1", k2="v2")

    assert ['__call__', 'return_value'] == func.method_calls[0][0]

    # test logging - return value