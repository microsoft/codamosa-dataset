

# Generated at 2022-06-21 20:46:28.725873
# Unit test for function build_requests_session
def test_build_requests_session():
    # given
    def mock_get(*args, **kwargs):
        class Response():
            def __init__(self, status_code=200):
                self.status_code = status_code

            @property
            def ok(self):
                return self.status_code == 200

        if args[0] == "http://good":
            return Response()
        elif args[0] == "http://raise_status_code":
            return Response(status_code=404)

    session = build_requests_session(raise_for_status=True)
    session.get = mock_get

    # when
    session.get("http://good")
    session.get("http://raise_status_code")

# Generated at 2022-06-21 20:46:35.201102
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    test_logger = logging.getLogger("LoggedFunction")
    test_logger.setLevel(logging.DEBUG)
    test_handler = logging.StreamHandler()
    test_logger.addHandler(test_handler)
    test_func = LoggedFunction(test_logger)
    @test_func
    def test(a,b):
        return a+b
    test(1,2)


# Generated at 2022-06-21 20:46:43.134670
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.0) == "1.0"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg("abc") == "'abc'"
    assert format_arg("123") == "'123'"
    assert format_arg("a bc") == "'a bc'"
    assert format_arg(" a' ") == "' a' '"
    assert format_arg(123) == "123"

# Generated at 2022-06-21 20:46:57.114493
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(raise_for_status=False)
    assert not session.hooks
    session = build_requests_session(raise_for_status=True)
    assert len(session.hooks["response"]) == 1

    # Retries
    session = build_requests_session(retry=True)
    assert session.adapters["http://"].max_retries.total == 3
    session = build_requests_session(retry=False)
    assert "max_retries" not in session.adapters["http://"].__dict__
    session = build_requests_session(retry=5)
    assert session.adapters["http://"].max_retries.total == 5
    r = Retry(3)

# Generated at 2022-06-21 20:47:02.334017
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    d = dict()
    d["name"] = "logged"
    d["level"] = logging.DEBUG
    logging.basicConfig(**d)
    lf = LoggedFunction(logging)
    @lf
    def abc(a: int, b: str):
        return a
    abc(1, "2")

# Generated at 2022-06-21 20:47:13.225962
# Unit test for function build_requests_session
def test_build_requests_session():
    result = build_requests_session()
    assert isinstance(result, Session)
    assert len(result.adapters) == 2
    assert "http://" in result.adapters
    adapter = result.adapters["http://"]
    assert isinstance(adapter, HTTPAdapter)
    assert isinstance(adapter.max_retries, Retry)
    assert adapter.max_retries.total == 5
    assert "https://" in result.adapters
    adapter = result.adapters["https://"]
    assert isinstance(adapter, HTTPAdapter)
    assert isinstance(adapter.max_retries, Retry)
    assert adapter.max_retries.total == 5
    result = build_requests_session(True)
    assert isinstance(result, Session)
    assert len(result.adapters) == 2

# Generated at 2022-06-21 20:47:20.413861
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def foo(x: str) -> None:
        pass

    @LoggedFunction(logger)
    def bar(x: str, y: str) -> None:
        pass

    @LoggedFunction(logger)
    def baz(x: int) -> int:
        return x

    foo("test foo1")
    foo("test foo2")
    bar("test bar1", "test bar2")
    bar("test bar3", "test bar4")
    print(baz(1))
    print(baz(2))


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-21 20:47:29.772022
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.max_retries.total == 10
    assert session.max_retries.connect == 1
    assert session.max_retries.read == 1
    assert session.max_retries.status == 1

    session = build_requests_session(retry=False)
    assert session.max_retries.total == 0

    session = build_requests_session(retry=1)
    assert session.max_retries.total == 1

    session = build_requests_session(retry=Retry(connect=1, read=2, total=3))
    assert session.max_retries.connect == 1
    assert session.max_retries.read == 2
    assert session.max_retries.total == 3

# Generated at 2022-06-21 20:47:40.910133
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(retry=True)
    retry = session.adapters["http://"].max_retries
    assert retry.total == 0
    assert retry.read == 0
    assert retry.connect == 0

    status_hook_installed = False
    for hook in session.hooks.get("response"):
        if hook.__name__ == "raise_for_status":
            status_hook_installed = True
    assert status_hook_installed

    session = build_requests_session(retry=False)
    assert session.adapters.get("http://") is None

    session = build_requests_session(retry=2)
    retry = session.adapters["http://"].max_retries
    assert retry.total == 2

# Generated at 2022-06-21 20:47:53.533553
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import logging.config
    import logging.handlers
    import logging.handlers
    import tempfile

    with tempfile.TemporaryDirectory() as tempdir:

        # Configure logging
        test_log = os.path.join(tempdir, "test.log")

# Generated at 2022-06-21 20:48:00.229154
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("1") == "'1'"
    assert format_arg(1) == "1"
    assert format_arg("param") == "'param'"
    assert format_arg("param_1") == "'param_1'"

# Generated at 2022-06-21 20:48:09.609820
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == '1'
    assert format_arg(True) == 'True'
    assert format_arg(1.1) == '1.1'
    assert format_arg([1,2,3,4]) == '[1, 2, 3, 4]'
    assert format_arg({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert format_arg('a bc') == '\'a bc\''
    assert format_arg('') == '\'\''
    assert format_arg('  a  ') == '\'  a  \''

# Generated at 2022-06-21 20:48:13.170325
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging as log
    logger = log.getLogger()
    logger.setLevel(log.DEBUG)
    s = log.StreamHandler()
    logger.addHandler(s)

    @LoggedFunction(logger)
    def test(a, b):
        return a + b

    test(1, 2)


# Generated at 2022-06-21 20:48:14.317603
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()

# Generated at 2022-06-21 20:48:25.894225
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    from unittest.mock import MagicMock

    logger = MagicMock(spec=logging.Logger, autospec=True)
    logged_function = LoggedFunction(logger)
    @logged_function
    def my_function(arg1, arg2):
        pass

    my_function(1, 2)
    logger.debug.assert_called_once_with(
        f"my_function({format_arg(1)}, {format_arg(2)})"
    )

    my_function(arg2=2, arg1=1)
    logger.debug.assert_called_with(
        f"my_function({format_arg(1)}, arg2={format_arg(2)})"
    )


# Generated at 2022-06-21 20:48:32.241353
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import unittest
    import logging

    class TestLoggedFunction(unittest.TestCase):

        def test_logged_function(self):
            logger = logging.getLogger()

            @LoggedFunction(logger)
            def square(x: int) -> int:
                return x * x

            self.assertEqual(square(5), 25)
            self.assertEqual(square.__name__, "square")

            @LoggedFunction(logger)
            def add(x: int, y: int) -> int:
                return x + y

            self.assertEqual(add(100, 110), 210)

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-21 20:48:42.492066
# Unit test for function build_requests_session
def test_build_requests_session():
    from requests.exceptions import Timeout

    def gen_http_error():
        try:
            s = build_requests_session()
            s.get("http://localhost:12345", timeout=0.01)
        except Timeout:
            pass

    def gen_http_error_with_retry_0():
        try:
            s = build_requests_session(retry=0)
            s.get("http://localhost:12345", timeout=0.01)
        except Timeout:
            pass

    def gen_http_error_with_retry_1():
        try:
            s = build_requests_session(retry=1)
            s.get("http://localhost:12345", timeout=0.01)
        except Timeout:
            pass


# Generated at 2022-06-21 20:48:49.037652
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    class Dummy(object):
        DUMMY_LOGGER = 'Test logger'
        def __init__(self):
            self.logger = Dummy.DUMMY_LOGGER
        @LoggedFunction(logger)
        def dummy_func(self):
            print('Hello World')
    
    dummy = Dummy()
    assert dummy.logger == Dummy.DUMMY_LOGGER
    assert dummy.dummy_func.__qualname__ == 'LoggedFunction.__call__.<locals>.logged_func'



# Generated at 2022-06-21 20:48:53.461111
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(2) == "2"
    assert format_arg("a") == "'a'"
    assert format_arg("a b") == "'a b'"
    assert format_arg(None) == "None"



# Generated at 2022-06-21 20:49:04.545643
# Unit test for function build_requests_session
def test_build_requests_session():
    from contextlib import closing
    from io import StringIO

    import pytest
    import requests

    @LoggedFunction(logger=pytest.logging_stream)
    def test_func(param):
        return param

    @build_requests_session(retry=True)
    def test_func2(param):
        return param

    with closing(StringIO()) as sio:
        pytest.logging_stream = sio
        pytest.logging_stream_handler.stream = sio
        test_func("Hello")
        test_func("Hello", ", world!")
        test_func("Hello", ", world!", times=3)
        assert "test_func('Hello')" in sio.getvalue()
        assert "test_func -> Hello" in sio.getvalue()


# Generated at 2022-06-21 20:49:09.537544
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    func = LoggedFunction(logging.getLogger())
    assert func is not None


# Generated at 2022-06-21 20:49:11.894515
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(2) == "2"
    assert format_arg("test") == "'test'"
    assert format_arg(" test ") == "'test'"

# Generated at 2022-06-21 20:49:18.706459
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # if  logger attribute of LoggedFunction is set to none, then the constructor of class LoggedFunction Returns error
    logger = None
    with pytest.raises(Exception):
        LoggedFunction(logger)
   
      # if logger attribute of LoggedFunction is set to non-none value, then the constructor of class LoggedFunction Returns a
    # class LoggedFunction object
    logger = object()
    instance = LoggedFunction(logger)
    assert isinstance(instance, LoggedFunction)



# Generated at 2022-06-21 20:49:25.388449
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    import unittest

    logger = logging.getLogger(__name__)

    class LoggedFunctionUnitTest(unittest.TestCase):
        def test_result(self):
            def foo(msg, times=1):
                return msg * times

            logged_foo = LoggedFunction(logger)(foo)

            logged_foo("test", 2)
            logged_foo("test", times=3)

    unittest.main()


if __name__ == "__main__":
    test_LoggedFunction___call__()

# Generated at 2022-06-21 20:49:36.316845
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.adapters["https://"].max_retries.total == Retry().total
    assert session.adapters["http://"].max_retries.total == Retry().total

    session = build_requests_session(retry=False)
    assert "https://" not in session.adapters
    assert "http://" not in session.adapters

    session = build_requests_session(retry=1)
    assert session.adapters["https://"].max_retries.total == 1
    assert session.adapters["http://"].max_retries.total == 1

    retry_obj = Retry(5)
    session = build_requests_session(retry=retry_obj)
    assert session.adapters["https://"].max_

# Generated at 2022-06-21 20:49:45.598714
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    raise_for_status_session = build_requests_session(raise_for_status=True)
    try:
        raise_for_status_session.get("https://this_url_does_not_exist.org").raise_for_status()
    except Exception as e:
        # Expected to raise exception
        assert isinstance(e, Exception)
    try:
        retry_session = build_requests_session(raise_for_status=True, retry=Retry(0))
        retry_session.get("https://this_url_does_not_exist.org").raise_for_status()
    except Exception as e:
        # Expected to raise exception
        assert isinstance(e, Exception)
    retry_

# Generated at 2022-06-21 20:49:50.933074
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    logger = logging.getLogger("logged_function_unit_test")
    logged_function = LoggedFunction(logger)
    # function format: name, a, b
    @logged_function
    def test_function(a, b):
        return a + b
    def test_function1(a, b):
        return a + b
    def test_function2(a, b):
        return a + b
    assert(test_function.__name__ == "test_function")
    assert(test_function(1, 2) == 3)
    assert(test_function("hello", "world") == "helloworld")
    assert(test_function1.__name__ == "test_function1")
    assert(test_function2.__name__ == "test_function2")

# Generated at 2022-06-21 20:49:52.389317
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("  abc def") == "'abc def'"

# Generated at 2022-06-21 20:49:55.552897
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def test():
        print("hello")
    test = LoggedFunction(logging.getLogger(__name__))(test)
    test()

# Generated at 2022-06-21 20:50:00.021223
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert isinstance(session, Session)
    session = build_requests_session(raise_for_status=True, retry=False)
    assert isinstance(session, Session)
    session = build_requests_session(raise_for_status=True, retry=True)
    assert isinstance(session, Session)

# Generated at 2022-06-21 20:50:16.198580
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    """
    Test method __call__ of class LoggedFunction
    :return:
    """
    import logging
    from unittest import mock

    logger = logging.getLogger("LoggedFunction")
    logger.setLevel(logging.DEBUG)

    mock_handler = mock.MagicMock()
    logger.addHandler(mock_handler)

    @LoggedFunction(logger)
    def test(x, y=2):
        return x * y

    test(1)
    test(1, y=3)

    assert len(mock_handler.handle.call_args_list) == 2
    assert mock_handler.handle.call_args_list[0][0][0].msg == "test(1, y=2)"

# Generated at 2022-06-21 20:50:27.700575
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test for raise_for_status and retry
    session = build_requests_session(raise_for_status=True, retry=3)
    assert session.hooks['response'] != None
    assert isinstance(session.adapters['http://'].max_retries, Retry)
    assert session.adapters['http://'].max_retries.total == 3
    assert isinstance(session.adapters['https://'].max_retries, Retry)
    assert session.adapters['https://'].max_retries.total == 3

    # Test for raise_for_status and no retry
    session = build_requests_session(raise_for_status=True, retry=False)
    assert session.hooks['response'] != None
    assert 'http://' not in session.adapters
   

# Generated at 2022-06-21 20:50:32.214377
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    logger = logging.getLogger()

    def foo(x, y=3, z=None):
        return 1

    lf=LoggedFunction(logger)
    lf(foo)



# Generated at 2022-06-21 20:50:40.975048
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging

    import Logging.Loggable

    logger = Logging.Loggable.TempLogger(
        logging.getLogger("__main__"), logging.DEBUG, logging.FileHandler("test.log", mode="w")
    )

    @LoggedFunction(logger)
    def foo(x, y, z=None):
        print("Executing foo")
        return x + y + (0 if z is None else z)

    assert foo(1, 2, 3) == 6

    with open("test.log", "r") as f:
        assert f.readlines() == ["foo(1, 2, z=3)\n", "foo -> 6\n"]


from .Loggable import Loggable, TempLogger

# Generated at 2022-06-21 20:50:46.713031
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("Good") == "'Good'"
    assert format_arg("Bad'") == "'Bad\\''"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"
    assert format_arg(1.2) == "1.2"
    assert format_arg(None) == "None"


# Generated at 2022-06-21 20:50:51.879673
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    logger = logging.getLogger(__name__)

    @LoggedFunction(logger)
    def add(x, y):
        return x + y

    assert(add(1,2)==3)

if __name__ == "__main__":
    test_LoggedFunction()

# Generated at 2022-06-21 20:50:56.104049
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("'hello world'") == "'hello world'"
    assert format_arg("'hello world") == "'hello world'"
    assert format_arg("hello world'") == "hello world'"
    assert format_arg("hello world") == "'hello world'"
    assert format_arg(1) == "1"
    assert format_arg(1.5) == "1.5"


# Generated at 2022-06-21 20:50:57.472550
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    lf=LoggedFunction(None)
    lf(lambda x,y: x+y)(2,3)

# Generated at 2022-06-21 20:51:07.188743
# Unit test for function build_requests_session
def test_build_requests_session():
    session_1 = build_requests_session()
    session_2 = build_requests_session(retry=False)
    session_3 = build_requests_session(retry=True)
    session_4 = build_requests_session(retry=1)
    retry = Retry(total=2)
    session_5 = build_requests_session(retry=retry)
    session_6 = build_requests_session(raise_for_status=False)


if __name__ == "__main__":
    test_build_requests_session()

# Generated at 2022-06-21 20:51:09.866901
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    try:
        LoggedFunction()
    except Exception as ex:
        assert 0, "Exception " + str(ex) + " occurred"
    return True


# Generated at 2022-06-21 20:51:28.034813
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    import logging
    
    cases = [
        # case 1
        {
            'logger': logging.getLogger(__name__),
            'func': lambda a, b: a + b,
            'args': [1, 2],
            'kwargs': {},
            'expected_output': "func(1, 2)"
        },
        # case 2
        {
            'logger': logging.getLogger(__name__),
            'func': lambda a, b: a + b,
            'args': [1, 2],
            'kwargs': {'c': 3},
            'expected_output': "func(1, 2, c=3)"
        }
    ]

    for case in cases:
        # initialize
        logger = case['logger']
        func = case['func']

# Generated at 2022-06-21 20:51:31.371157
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    # Test the constructor of class LoggedFunction
    logger = mock()
    logged_func = LoggedFunction(logger)
    assert logged_func == logged_func
    assert id(logged_func) == id(logged_func)

# Generated at 2022-06-21 20:51:36.141947
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():

    import logging

    # Create logger
    logger = logging.getLogger("LoggedFunction")
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)

    # Create and configure decorator
    decorator = LoggedFunction(logger)

    # Define function to test
    @decorator
    def test(a: int, b: str = None):
        return a * 10

    # Call function
    result = test(1, b="2")
    assert result == 10

# Generated at 2022-06-21 20:51:40.502157
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(1.5) == "1.5"
    assert format_arg(None) == "None"
    assert format_arg([1, 2]) == "[1, 2]"
    assert format_arg("abc") == "'abc'"
    assert format_arg("'abc'") == "'''abc'''"
    assert format_arg(('a',)) == "('a',)"
    assert format_arg('a""b') == "'a\"\"b'"
    assert format_arg([1, "abc"]) == "[1, 'abc']"
    assert format_arg((1, "a'b")) == "(1, 'a''b')"

# Generated at 2022-06-21 20:51:47.831004
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from pytest import raises
    from logging import getLogger, DEBUG, basicConfig

    basicConfig(level=DEBUG)

    logger = getLogger("TestLogger")

    @LoggedFunction(logger)
    def test(a, b, c=1):
        return a + b + c

    assert test(1, 2, 3) == 6
    assert test(4, 5) == 10
    assert test(4, 5, c=6) == 15

    with raises(ValueError, match="retry should be a bool, int or Retry instance."):
        build_requests_session(retry=object())


if __name__ == "__main__":
    from pytest import main

    main([__file__])

# Generated at 2022-06-21 20:51:49.921855
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("  test ") == "'test'"
    assert format_arg(123) == "123"



# Generated at 2022-06-21 20:51:55.935083
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    result = []

    logger = type("", (), {})
    logger.debug = lambda s: result.append(s)
    lf = LoggedFunction(logger)

    @lf
    def foo(a, b="foo", *args, c=None, **kwargs):
        pass

    foo(1, "bar", c=3)
    assert result == ["foo(1, b='bar', c=3)"]



# Generated at 2022-06-21 20:52:00.934123
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(123) == "123"
    assert format_arg("test") == "'test'"
    assert format_arg(None) == "None"
    assert format_arg(1.2) == "1.2"
    assert format_arg([1,2,3]) == "[1, 2, 3]"

# Generated at 2022-06-21 20:52:11.253988
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from requests import exceptions

    @build_requests_session()
    def test_session():
        return test_session.get("https://www.google.com.vn")
    with pytest.raises(exceptions.HTTPError):
        test_session()
    assert test_session.max_retries.total == 0

    @build_requests_session(raise_for_status=False)
    def test_session():
        return test_session.get("https://www.google.com.vn")
    test_session()
    assert test_session.max_retries.total == 0

    @build_requests_session(retry=False)
    def test_session():
        return test_session.get("https://www.google.com.vn")

# Generated at 2022-06-21 20:52:17.433698
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    from loguru import logger
    from nose.tools import assert_equals, assert_true
    from unittest.mock import Mock, patch

    # Create a Mock logger to check if the correct output is logged
    mock_logger = Mock()
    mock_logger.attach = Mock()
    logger.remove()
    logger.add(mock_logger, level="DEBUG")

    # Use the decorator on a dummy function
    @LoggedFunction(logger)
    def dummy_func(a, b, c):
        return (a, b, c)

    # Check if the output is the same as expected
    dummy_func("1", "2", "3")
    mock_logger.debug.assert_called_once_with(
        "dummy_func('1', '2', '3')"
    )



# Generated at 2022-06-21 20:52:47.347260
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(True) == 'True'
    assert format_arg(False) == 'False'
    assert format_arg('a') == "'a'"
    assert format_arg(1) == '1'
    assert format_arg(1.0) == '1.0'


# Generated at 2022-06-21 20:52:50.592427
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    obj = LoggedFunction(logging.getLogger())
    def func():
        pass
    func1 = obj(func)
    func1()
    assert func1.__name__ == func.__name__

# Generated at 2022-06-21 20:52:59.910957
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def func_return_1(arg1: int, arg2: str) -> int:
        return 1

    from logging import getLogger
    from io import StringIO
    import sys

    logger = getLogger("test_logger")
    logger.setLevel(10)
    output = StringIO()
    logger.handlers = []
    stream = logging.StreamHandler(output)
    stream.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    logger.addHandler(stream)

    # Use decorator
    func_return_1_logged = LoggedFunction(logger)(func_return_1)
    # Run the decorated function
    func_return_1_logged(1, "test")


# Generated at 2022-06-21 20:53:10.585588
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    from pytest import raises
    from urllib3.exceptions import MaxRetryError
    from requests.exceptions import HTTPError

    # Test whenever raise_for_status is false or true
    for is_raise_for_status in [True, False]:
        url = "https://httpbin.org/status/200"

        # Test whenever retry is false or true
        for is_retry in [True, False]:
            resp = requests.get(url)
            assert resp.status_code == 200
            if is_raise_for_status:
                with raises(HTTPError):
                    resp = requests.get(url, hooks={"response": [lambda r, *args, **kwargs: r.raise_for_status()]})

            # Test for raise for status

# Generated at 2022-06-21 20:53:14.694908
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    session.get("http://httpbin.org/get")
    session = build_requests_session(raise_for_status=False)
    session.get("http://httpbin.org/status/404")
    retry = Retry(total=2)
    session = build_requests_session(retry=retry)
    session.get('http://httpbin.org/status/429')

# Generated at 2022-06-21 20:53:20.390998
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("string value") == "'string value'"
    assert format_arg(123) == "123"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"
    assert format_arg(False) == "False"


# Generated at 2022-06-21 20:53:28.631138
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    """
    Test for Constructor of the class LoggedFunction
    """
    # Create a custom logger to use in the test
    import logging

    class CustomLogger(logging.Logger):
        def __init__(self):
            super().__init__("CustomLogger")
            self.messages = []

        def debug(self, *args, **kwargs):
            self.messages.append(args[0])

    logger_inst = CustomLogger()
    logger = LoggedFunction(logger_inst)

    def func(a, b, c=1, **kwargs):
        print(a, b, c)

    func = logger(func)
    func(0, 1, d=2, e=4)

    # check whether function calls are logged correctly or not
    # logging of function calls

# Generated at 2022-06-21 20:53:30.284695
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    f = LoggedFunction(logger=None)
    assert f is not None


# Generated at 2022-06-21 20:53:33.310417
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("abcd ef") == "'abcd ef'"
    assert format_arg(None) == "None"
    assert format_arg(True) == "True"

# Generated at 2022-06-21 20:53:41.045103
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    with patch("logging.Logger.debug") as patched_debug:
        logger = MagicMock()
        func = LoggedFunction(logger)
        func_name = "foo"
        mocked_func = MagicMock()
        mocked_func.__name__ = func_name
        mocked_func.return_value = None

        final_func = func(mocked_func)
        mocked_func.assert_not_called()

        final_func()
        assert func_name in patched_debug.call_args_list[0][0][0]
        mocked_func.assert_called_once_with()
        assert func_name not in patched_debug.call_args_list[1][0][0]

        mocked_func.reset_mock()
        mocked_func.return_value = 123

# Generated at 2022-06-21 20:54:11.257156
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    assert session.max_retries.total == 10

# Generated at 2022-06-21 20:54:21.820366
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session()
    session.get('https://httpbin.org/status/200')

    session = build_requests_session(retry=False)
    with pytest.raises(requests.exceptions.HTTPError):
        session.get('https://httpbin.org/status/404')

    session = build_requests_session(retry=5)
    session.get('https://httpbin.org/status/200')

    retry = Retry(total=1)
    session = build_requests_session(retry=retry)
    with pytest.raises(requests.exceptions.ConnectionError):
        session.get('https://httpbin.org/status/200')


# Generated at 2022-06-21 20:54:29.267846
# Unit test for method __call__ of class LoggedFunction
def test_LoggedFunction___call__():
    class Logger:
        def __init__(self):
            self.test_log_lines = []

        def debug(self, line):
            self.test_log_lines.append(line)

    # Define a logger instance to test
    logger = Logger()

    # Define a function
    def test_func(*args, **kwargs):
        return args, kwargs

    # Define a LoggedFunction instance based on above function and logger.
    function_wrapper = LoggedFunction(logger)

    # Test
    test_args = (1, 2)
    test_kwargs = {"a": 3, "b": "c"}
    test_result = function_wrapper(test_func)(*test_args, **test_kwargs)

    # Assert

# Generated at 2022-06-21 20:54:35.655133
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg(3.14) == "3.14"
    assert format_arg(None) == "None"
    assert format_arg("") == "''"
    assert format_arg("  ") == "''"
    assert format_arg("hello") == "'hello'"
    assert format_arg("this is a test") == "'this is a test'"
    assert format_arg("  this is a test  ") == "'this is a test'"

# Generated at 2022-06-21 20:54:37.976202
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("i'm a string") == "'i'm a string'"
    assert format_arg("umm") == "'umm'"
    assert format_arg("") == "''"
    assert format_arg(1) == "1"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:54:41.885127
# Unit test for function format_arg
def test_format_arg():
    test_tuples = [
        (1, "1"),
        (1.0, "1.0"),
        ("a", "'a'"),
        (["a"], "['a']"),
    ]
    for test_input, expected_output in test_tuples:
        actual_output = format_arg(test_input)
        assert expected_output == actual_output, f"format_arg({test_input}) should be {expected_output}, but is {actual_output}"

# Generated at 2022-06-21 20:54:45.595193
# Unit test for function format_arg
def test_format_arg():
    assert format_arg("hello") == "'hello'"
    assert format_arg(1) == "1"
    assert format_arg(1.1) == "1.1"
    assert format_arg(None) == "None"

# Generated at 2022-06-21 20:54:54.650014
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    import logging
    import tempfile
    temp = tempfile.NamedTemporaryFile(mode="w+")
    logger = logging.getLogger(__name__+"test")
    logger.setLevel(logging.DEBUG)
    f_handler = logging.FileHandler(temp.name)
    f_handler.setLevel(logging.DEBUG)
    logger.addHandler(f_handler)
    atest = LoggedFunction(logger)
    @atest
    def foo(x, y, z=0):
        return x + y + z
    foo(1, 2)
    temp.seek(0)
    assert "foo(1, 2)" in temp.read()
    foo(1, 2, 3)
    temp.seek(0)

# Generated at 2022-06-21 20:54:57.898782
# Unit test for function format_arg
def test_format_arg():
    assert format_arg(1) == "1"
    assert format_arg("1") == "'1'"
    assert format_arg("a b") == "'a b'"



# Generated at 2022-06-21 20:55:03.741074
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    def test_function(name):
        return name
    log_func = LoggedFunction(logging.getLogger(__name__))
    function_logged = log_func(test_function)
    assert function_logged("abc") == "abc"
    assert function_logged.__name__ == "test_function"


# Generated at 2022-06-21 20:56:01.617945
# Unit test for constructor of class LoggedFunction
def test_LoggedFunction():
    assert(len(LoggedFunction.__init__.__code__.co_varnames) == 2)
    assert(LoggedFunction.__init__.__code__.co_varnames[0] == 'self')
    assert(LoggedFunction.__init__.__code__.co_varnames[1] == 'logger')

test_LoggedFunction()

# Generated at 2022-06-21 20:56:14.044425
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(), Session)
    assert isinstance(build_requests_session(None, False), Session)
    assert isinstance(build_requests_session(False, 0), Session)
    assert isinstance(build_requests_session(False, Retry()), Session)
    assert isinstance(build_requests_session(False, Retry(max_retries=0)), Session)
    assert isinstance(build_requests_session(True, True), Session)
    assert isinstance(build_requests_session(True, False), Session)
    assert isinstance(build_requests_session(True, 0), Session)
    assert isinstance(build_requests_session(True, Retry()), Session)

# Generated at 2022-06-21 20:56:23.190687
# Unit test for function build_requests_session
def test_build_requests_session():
    def mock_response(status_code):
        return lambda *args, **kwargs: status_code
    def test_hook(session, response):
        assert response == 200
    session = build_requests_session(raise_for_status=False)
    session.hooks["response"] = [test_hook]
    session.get("", hooks={"response": [mock_response(200)]})
    session = build_requests_session(raise_for_status=True)
    with pytest.raises(HTTPError):
        session.get("", hooks={"response": [mock_response(404)]})
    session = build_requests_session(retry=False)
    session.get("")
    session = build_requests_session(retry=2)
    session.get("")
    default_ret