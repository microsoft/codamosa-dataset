

# Generated at 2022-06-17 00:01:38.211590
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23.0.1'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts)

# Generated at 2022-06-17 00:01:49.692749
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 2048
    assert hardware.facts['memfree_mb'] == 1536
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'B.11.31.1509'

# Generated at 2022-06-17 00:02:00.054831
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2

    collected_facts = {'ansible_architecture': 'ia64'}
    collected_facts['ansible_distribution_version'] = "B.11.23"
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

   

# Generated at 2022-06-17 00:02:11.956140
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'B.11.31.1401'

# Generated at 2022-06-17 00:02:24.905404
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx8640'
    assert hardware.facts['firmware_version'] == 'B.11.31.1404'

# Generated at 2022-06-17 00:02:31.594783
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:02:42.346946
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0

# Generated at 2022-06-17 00:02:54.072820
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v2.00'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:02:58.940638
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:03:09.030489
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    # Test for HP-UX 11.31 ia64
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'

    # Test for HP-UX 11.31 ia64 with hyperthreading

# Generated at 2022-06-17 00:03:29.613897
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hw.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:03:34.899274
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:03:38.888545
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw._fact_class == HPUXHardware
    assert hw.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:03:48.095341
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:03:54.295251
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.fact_class == HPUXHardware
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:04:03.525686
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'HPD9'
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:04:13.842805
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    hardware_obj.populate(collected_facts)
    assert hardware_obj.facts['processor_count'] == 2
    assert hardware_obj.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_obj.facts['processor_cores'] == 2
    assert hardware_obj.facts['memfree_mb'] == 5
    assert hardware_obj.facts['memtotal_mb'] == 1024
    assert hardware_obj.facts['swaptotal_mb'] == 0
    assert hardware_obj.facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:04:20.459225
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-17 00:04:26.214772
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v3.00'
    assert hw_facts['product_serial'] == 'USC9069X8D'


# Generated at 2022-06-17 00:04:35.059979
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'

# Generated at 2022-06-17 00:05:07.998156
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.fact_class == HPUXHardware
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:05:17.370377
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 16384
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 16384
    assert memory_facts

# Generated at 2022-06-17 00:05:26.174573
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0

# Generated at 2022-06-17 00:05:31.728742
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw._fact_class == HPUXHardware


# Generated at 2022-06-17 00:05:39.099982
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:05:41.487291
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:05:51.199289
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23.0'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts)

# Generated at 2022-06-17 00:05:54.862968
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:05:56.639453
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module=module)
    hw.get_hw_facts()

# Generated at 2022-06-17 00:05:59.199264
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.fact_class == HPUXHardware
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:07:07.357690
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23.0.1'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts

# Generated at 2022-06-17 00:07:17.052050
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0



# Generated at 2022-06-17 00:07:28.561118
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9300 series'
    assert cpu_facts['processor_cores'] == 4

    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

# Generated at 2022-06-17 00:07:39.828606
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'B.11.31.1504'

# Generated at 2022-06-17 00:07:47.677669
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0



# Generated at 2022-06-17 00:07:55.828114
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:08:07.922333
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    if not HAS_LIBVIRT:
        module.fail_json(msg='libvirt is not importable')
    if not HAS_LIBVIRT_PYTHON:
        module.fail_json(msg='libvirt-python is not importable')

    # Create a fake module
    set_module_args(dict(
        gather_subset=['all'],
    ))

    # Instantiate HardwareCollector class
    hw_collector = HPUXHardwareCollector(module=module)

    # Instantiate HPUXHardware class
    hw = HPUXHardware(module)

    # Call method get_

# Generated at 2022-06-17 00:08:20.111400
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'B.11.23.0608.0104'
    assert hw_facts['model'] == 'ia64 hp server rx8640'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts)

# Generated at 2022-06-17 00:08:27.626963
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= 0

# Generated at 2022-06-17 00:08:34.821254
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0

# Generated at 2022-06-17 00:09:48.478117
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0

# Generated at 2022-06-17 00:09:54.732841
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor_count'] == 2
    assert hardware_obj.facts['processor_cores'] == 1
    assert hardware_obj.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_obj.facts['memtotal_mb'] == 4096
    assert hardware_obj.facts['memfree_mb'] == 3
    assert hardware_obj.facts['swaptotal_mb'] == 0
    assert hardware_obj.facts['swapfree_mb'] == 0
    assert hardware_obj.facts['model'] == 'ia64 hp server rx2660'

# Generated at 2022-06-17 00:10:04.913247
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_LIB_HP_UX:
        module.fail_json(msg='hp-ux-libs required for this module')

    hw = HPUXHardware(module)
    facts = hw.populate()
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:10:11.082319
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:10:18.279265
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx8640'
    assert hw_facts['firmware_version'] == 'B.11.23.0.1'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts

# Generated at 2022-06-17 00:10:24.583388
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:10:34.941247
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:10:45.767338
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'B.11.23.0609.01.01.0'
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-17 00:10:48.453785
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    hw.get_hw_facts()
    assert hw.facts['model'] == 'ia64 hp server rx2660'
    assert hw.facts['firmware_version'] == 'B.11.31.1404'
    assert hw.facts['product_serial'] == 'US12345678'



# Generated at 2022-06-17 00:10:52.534227
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
