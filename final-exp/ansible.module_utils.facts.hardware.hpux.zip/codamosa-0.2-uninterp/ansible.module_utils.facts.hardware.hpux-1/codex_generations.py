

# Generated at 2022-06-17 00:01:36.310410
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    collected_facts['ansible_distribution_version'] = "B.11.23"
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2
    collected_facts['ansible_distribution_version'] = "B.11.31"
    cpu_facts

# Generated at 2022-06-17 00:01:46.519852
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:01:57.400362
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:02:08.367090
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:02:12.328861
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware


# Generated at 2022-06-17 00:02:15.398494
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware


# Generated at 2022-06-17 00:02:24.755753
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    hw_facts = hw.get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx4640'
    assert hw_facts['firmware_version'] == 'B.11.31.1404'
    assert hw_facts['product_serial'] == 'USC1-1-1-1'


# Generated at 2022-06-17 00:02:31.165565
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware

# Generated at 2022-06-17 00:02:43.175168
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 16384
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 16384
    assert memory_facts

# Generated at 2022-06-17 00:02:49.252674
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v2.00'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'


# Generated at 2022-06-17 00:03:09.127977
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'B.11.23'
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hw.get_hw_facts(collected_facts)

# Generated at 2022-06-17 00:03:12.890885
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:03:21.946139
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_facts['memfree_mb'] == 696
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memtotal_mb'] == 8192

# Generated at 2022-06-17 00:03:28.954161
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 512
    assert hardware.facts['swaptotal_mb'] == 512
    assert hardware.facts['swapfree_mb'] == 256
    assert hardware.facts['model'] == 'ia64'
    assert hardware.facts['firmware_version'] == 'B.11.23'
    assert hardware.facts['product_serial'] == '123456789'


# Generated at 2022-06-17 00:03:33.666014
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector._fact_class == HPUXHardware


# Generated at 2022-06-17 00:03:45.238200
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == '1.0'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:03:52.246437
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx8640'
    assert hw_facts['firmware_version'] == 'v2.00'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:04:00.209715
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:04:10.822999
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1
   

# Generated at 2022-06-17 00:04:14.714538
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.fact_class == HPUXHardware
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:04:42.759840
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:04:52.214079
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'HPD9'
    assert hw_facts['model'] == 'ia64 hp server rx8640'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:05:03.563581
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:05:16.145869
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0

# Generated at 2022-06-17 00:05:24.435696
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:05:34.743401
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23'
    assert hw_facts['product_serial'] == 'US12345678'



# Generated at 2022-06-17 00:05:46.259312
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_facts['memfree_mb'] == 8192
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_facts['memfree_mb'] == 8192
    assert memory_facts

# Generated at 2022-06-17 00:05:57.914341
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu

# Generated at 2022-06-17 00:06:07.656074
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:06:14.295437
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx8640'
    assert hardware.facts['firmware_version'] == 'B.11.31.1407'

# Generated at 2022-06-17 00:07:16.752276
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2
    collected_facts

# Generated at 2022-06-17 00:07:24.502606
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw_facts = HPUXHardware(module).get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v3.10'
    assert hw_facts['product_serial'] == 'US123456789'



# Generated at 2022-06-17 00:07:30.789564
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:07:35.796047
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.get_hw_facts()


# Generated at 2022-06-17 00:07:45.476494
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0

    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0

# Generated at 2022-06-17 00:07:50.337631
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:07:57.061875
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'B.11.31.1411'


# Generated at 2022-06-17 00:08:03.868357
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector._fact_class == HPUXHardware


# Generated at 2022-06-17 00:08:11.272196
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0

# Generated at 2022-06-17 00:08:21.285389
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 15984
    assert hardware_facts['swaptotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 16384
    assert hardware_facts['model'] == 'ia64 hp server rx8640'
    assert hardware_facts['firmware_version'] == 'B.11.31.1412'

# Generated at 2022-06-17 00:09:23.884739
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.fact_class == HPUXHardware
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:09:26.286438
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:09:33.461433
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 15963
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'v2.00'

# Generated at 2022-06-17 00:09:35.424156
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector._fact_class == HPUXHardware

# Generated at 2022-06-17 00:09:43.982101
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'B.11.31.0912'

# Generated at 2022-06-17 00:09:52.733579
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-17 00:09:55.668634
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:09:57.691064
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    hw.get_memory_facts()


# Generated at 2022-06-17 00:10:06.996798
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 4096
    assert hardware.facts['memfree_mb'] == 3999
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'v2.00'

# Generated at 2022-06-17 00:10:11.656417
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw._fact_class == HPUXHardware
