

# Generated at 2022-06-17 00:01:36.839104
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': '9000/785'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

# Generated at 2022-06-17 00:01:43.160790
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-17 00:01:47.197726
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware


# Generated at 2022-06-17 00:01:50.648543
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware

# Generated at 2022-06-17 00:02:00.835433
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2

    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:02:12.884479
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:02:26.112359
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'v2.00'
    assert hardware.facts['product_serial'] == 'USC0101'

# Generated at 2022-06-17 00:02:38.139860
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu

# Generated at 2022-06-17 00:02:43.750165
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware


# Generated at 2022-06-17 00:02:55.834841
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'v2.00'
    assert hw_facts['product_serial'] == 'ABCD12345678'
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31')
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'v2.00'

# Generated at 2022-06-17 00:03:12.349321
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:03:21.612876
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:03:32.134580
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    collected_facts['ansible_distribution_version'] = "B.11.23"
    cpu_facts = hw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:03:40.821409
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_HPUX:
        module.fail_json(msg='hpux_hpux_hardware required for this module')

    hw = HPUXHardware(module=module)
    facts = hw.populate()

    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-17 00:03:44.817003
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:03:54.584668
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'v2.16'

# Generated at 2022-06-17 00:04:03.143309
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'


# Generated at 2022-06-17 00:04:07.022339
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:04:12.744726
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:04:23.739155
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9350'

# Generated at 2022-06-17 00:04:51.709513
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memfree_mb'] == 5
    assert hardware.facts['memtotal_mb'] == 16
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'B.11.31.1404'

# Generated at 2022-06-17 00:05:03.665805
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    hardware_facts = hardware.populate(collected_facts)
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0

# Generated at 2022-06-17 00:05:16.302327
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw = HPUXHardware(module=module)

    # Test with B.11.31
    hw.module.run_command = MagicMock(return_value=(0, 'ia64', ''))
    hw.module.run_command.side_effect = [
        (0, 'B.11.31', ''),
        (0, 'HP Integrity rx2800 i4', ''),
        (0, 'Firmware revision = 1.0', ''),
        (0, 'Machine serial number = CZC12345', ''),
    ]
    hw_facts = hw.get_hw_facts()

# Generated at 2022-06-17 00:05:26.255740
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:05:37.046295
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_

# Generated at 2022-06-17 00:05:47.285097
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:05:49.289915
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware


# Generated at 2022-06-17 00:05:54.748189
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:06:02.073235
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:06:08.176727
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-17 00:06:34.445172
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 16384
    assert memory_facts['swaptotal_mb'] == 16384
    assert memory_facts['swapfree_mb'] == 16384
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 16384
    assert memory

# Generated at 2022-06-17 00:06:40.025112
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:06:51.418301
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:07:01.983013
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:07:08.538433
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:07:16.410895
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.optional_facts == set()
    assert hw_collector.additional_facts == set()
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:07:23.047322
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware


# Generated at 2022-06-17 00:07:30.290672
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution_version': 'B.11.23'}
    hardware_obj.populate(collected_facts)
    assert hardware_obj.facts['processor_count'] == 1
    assert hardware_obj.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_obj.facts['processor_cores'] == 1
    assert hardware_obj.facts['memtotal_mb'] == 2048
    assert hardware_obj.facts['memfree_mb'] == 1741
    assert hardware_obj.facts['swaptotal_mb'] == 0
    assert hardware_obj.facts['swapfree_mb']

# Generated at 2022-06-17 00:07:37.095403
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:07:44.208135
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:08:03.828248
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23.0609.1'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_

# Generated at 2022-06-17 00:08:10.411421
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware


# Generated at 2022-06-17 00:08:20.598002
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v2.60'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:08:28.132223
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:08:34.844081
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v2.00'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'


# Generated at 2022-06-17 00:08:46.504431
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_

# Generated at 2022-06-17 00:08:57.571703
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = MockModule()
    hw.module.run_command.return_value = (0, 'HP-UX B.11.31 U ia64  0204818056', '')
    hw.get_hw_facts()
    hw.module.run_command.assert_called_with('model')
    hw.module.run_command.return_value = (0, 'Firmware revision = B.11.31.08', '')
    hw.get_hw_facts()
    hw.module.run_command.assert_called_with("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    hw.module.run_command

# Generated at 2022-06-17 00:09:09.590874
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:09:20.026585
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= 0

# Generated at 2022-06-17 00:09:23.727979
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_LIB_HP_UX:
        module.fail_json(msg='hp-ux libs not found')

    hw = HPUXHardware(module=module)
    hw_facts = hw.get_hw_facts()

    module.exit_json(ansible_facts=hw_facts)



# Generated at 2022-06-17 00:09:57.553996
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:10:07.441914
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    # Test for B.11.23
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert cpu_facts['processor_cores'] == 2

    # Test for B.11.31
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get

# Generated at 2022-06-17 00:10:16.767113
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v3.60'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:10:25.614117
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'v2.00'
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'v2.00'


# Generated at 2022-06-17 00:10:35.736243
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 15892
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['model'] == 'ia64 hp server rx8640'
    assert hardware.facts['firmware_version'] == 'v2.01'

# Generated at 2022-06-17 00:10:41.087580
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:10:44.171927
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware

# Generated at 2022-06-17 00:10:54.019229
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'B.11.23.0609.1'
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_

# Generated at 2022-06-17 00:11:00.904565
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v2.00'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:11:03.679150
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw._fact_class == HPUXHardware
    assert hw._platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])