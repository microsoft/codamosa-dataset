

# Generated at 2022-06-17 00:01:35.114053
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'HPD7'
    assert hw_facts['product_serial'] == 'ABCD1234'


# Generated at 2022-06-17 00:01:40.429205
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:01:50.937612
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31'
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }

# Generated at 2022-06-17 00:01:58.555979
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:02:01.669658
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:02:13.766639
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_

# Generated at 2022-06-17 00:02:26.802901
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23.0.0'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts

# Generated at 2022-06-17 00:02:32.067708
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector._fact_class == HPUXHardware

# Generated at 2022-06-17 00:02:42.391039
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware.get_memory_facts(collected_facts)
    assert hardware.facts['memfree_mb'] == 0
    assert hardware.facts['memtotal_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    hardware.get_memory_facts(collected_facts)
    assert hardware.facts['memfree_mb'] == 0
    assert hardware.facts['memtotal_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0

# Generated at 2022-06-17 00:02:46.591316
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:03:15.673038
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'HPD8'
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:03:23.752726
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hw = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23'
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

# Generated at 2022-06-17 00:03:32.721985
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23.0.0'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert h

# Generated at 2022-06-17 00:03:44.103537
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-17 00:03:49.640933
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_HPUX:
        module.fail_json(msg='hpux-utils required for this module')

    hw_facts = HPUXHardware(module).get_hw_facts()

    module.exit_json(ansible_facts=dict(ansible_hardware=hw_facts))



# Generated at 2022-06-17 00:03:55.122470
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:04:00.377973
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:04:04.916652
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware

# Generated at 2022-06-17 00:04:14.714748
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23.0'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:04:23.257345
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:05:16.373560
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.23.0'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-17 00:05:26.358747
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:05:37.101638
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor_count'] == 2
    assert hardware_obj.facts['processor_cores'] == 2
    assert hardware_obj.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_obj.facts['memtotal_mb'] == 16384
    assert hardware_obj.facts['memfree_mb'] == 16384
    assert hardware_obj.facts['swaptotal_mb'] == 0
    assert hardware_obj.facts['swapfree_mb'] == 0
    assert hardware_obj.facts['model'] == 'ia64 hp server rx8640'

# Generated at 2022-06-17 00:05:47.993341
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'v2.00'
    assert hardware.facts['product_serial'] == 'US123456789'



# Generated at 2022-06-17 00:05:59.017485
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0

# Generated at 2022-06-17 00:06:03.770682
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count']

# Generated at 2022-06-17 00:06:12.006280
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:06:22.418286
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 9984
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx8640'
    assert hardware.facts['firmware_version'] == 'B.11.31.1302'

# Generated at 2022-06-17 00:06:26.979099
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:06:34.542395
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:07:32.856145
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx8640'
    assert hardware.facts['firmware_version'] == 'B.11.31.1411'

# Generated at 2022-06-17 00:07:40.482014
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 586
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'B.11.31.1411'

# Generated at 2022-06-17 00:07:51.369340
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor 9100 series'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['model'] == 'ia64 hp server rx6600'
    assert hardware.facts['firmware_version'] == 'B.11.31.1401'

# Generated at 2022-06-17 00:07:53.627421
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:08:04.478915
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-17 00:08:11.636919
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    hardware_facts = hardware.populate(collected_facts)
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['model'] == 'ia64 hp server rx8640'
   

# Generated at 2022-06-17 00:08:17.225959
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector._fact_class == HPUXHardware


# Generated at 2022-06-17 00:08:28.171393
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'

# Generated at 2022-06-17 00:08:32.025327
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.optional_facts == set()
    assert hw_collector.additional_facts == set()
    assert hw_collector.fact_class == HPUXHardware


# Generated at 2022-06-17 00:08:40.585476
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0

# Generated at 2022-06-17 00:09:48.528012
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor_count'] == 1
    assert hardware_obj.facts['processor_cores'] == 1
    assert hardware_obj.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_obj.facts['memtotal_mb'] == 8192
    assert hardware_obj.facts['memfree_mb'] == 8192
    assert hardware_obj.facts['swaptotal_mb'] == 8192
    assert hardware_obj.facts['swapfree_mb'] == 8192
    assert hardware_obj.facts['model'] == 'ia64 hp server rx2660'

# Generated at 2022-06-17 00:09:54.749819
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'

# Generated at 2022-06-17 00:10:00.195021
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0

# Generated at 2022-06-17 00:10:09.403577
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:10:15.780092
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:10:25.025250
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memtotal_mb']

# Generated at 2022-06-17 00:10:32.800514
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    hw_facts = hw.get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.31.1401'
    assert hw_facts['product_serial'] == 'USC03900Z2'


# Generated at 2022-06-17 00:10:38.926547
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:10:43.549247
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-17 00:10:50.013759
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.fact_class == HPUXHardware
