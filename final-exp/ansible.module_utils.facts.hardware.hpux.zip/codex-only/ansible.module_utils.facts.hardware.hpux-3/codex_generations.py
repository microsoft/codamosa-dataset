

# Generated at 2022-06-22 23:04:10.068811
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector({'platform': 'HP-UX'}, None, MockModule())
    assert hardware.platform == 'HP-UX'



# Generated at 2022-06-22 23:04:16.993155
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Create HPUXHardwareCollector object
    """
    hw_fact_collector = HPUXHardwareCollector()
    assert hw_fact_collector
    assert isinstance(hw_fact_collector, HardwareCollector)
    assert hw_fact_collector.fact_class == HPUXHardware
    assert hw_fact_collector.required_facts == set(['platform', 'distribution'])
    assert hw_fact_collector.platform == 'HP-UX'

# Generated at 2022-06-22 23:04:26.080169
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    m = HPUXHardware({})
    m.populate({'platform': 'HP-UX', 'architecture': '9000/800'})
    assert m.facts['processor_count'] == 2
    assert m.facts['memtotal_mb'] == 8192
    assert m.facts['memfree_mb'] == 7652
    assert m.facts['swaptotal_mb'] == 3583
    assert m.facts['swapfree_mb'] == 361


# Generated at 2022-06-22 23:04:36.586879
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    class TestModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, command, use_unsafe_shell=None):
            return 0, '', ''

    def test_get_cpu_facts(self, collected_facts=None):
        collected_facts = collected_facts or {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
        hw = HPUXHardware(TestModule())
        cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
        assert cpu_facts['processor'] == 'Intel Xeon E5-2640 v3'
        assert cpu_facts['processor_cores'] == 20
        assert cpu_facts['processor_count'] == 2

        collected

# Generated at 2022-06-22 23:04:43.563294
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware.get_cpu_facts(collected_facts={'ansible_architecture':'9000/800'})
    assert cpu_facts['processor_count'] == 2
    cpu_facts = HPUXHardware.get_cpu_facts(collected_facts={'ansible_architecture':'9000/785'})
    assert cpu_facts['processor_count'] == 2
    cpu_facts = HPUXHardware.get_cpu_facts(collected_facts={'ansible_architecture':'ia64'})
    # when cpu_facts['processor_count'] is null it means we use B.11.11 of B.11.31 < 1204
    assert cpu_facts['processor_count'] == 4

# Generated at 2022-06-22 23:04:53.858845
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """ Unit test for method get_cpu_facts of class HPUXHardware """
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    rc, out, err = hardware.module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    assert hardware.get_cpu_facts(collected_facts)['processor_count'] == int(out.strip().split('=')[1])

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

# Generated at 2022-06-22 23:04:57.578192
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware(dict(ansible_facts=dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23'), module=None))
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-22 23:05:07.213020
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class DummyModule(object):

        def __init__(self, command_list):
            self.command_list = command_list
            self.command_execute = 0

        def run_command(self, command, use_unsafe_shell=False):
            rc = 0
            out = ' '
            err = ''
            if self.command_execute < len(self.command_list):
                out = self.command_list[self.command_execute][0]
                rc = self.command_list[self.command_execute][1]
                self.command_execute += 1
            return (rc, out, err)


# Generated at 2022-06-22 23:05:13.527846
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h = HPUXHardware(dict(ansible_facts=dict(ansible_architecture='ia64', ansible_distribution_version="B.11.23")))
    out = h.get_hw_facts()
    assert out['model'] == 'ia64 hp server rx2660'
    assert out['firmware_version'] == 'v5.02'


# Generated at 2022-06-22 23:05:22.541856
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    #
    # HPUX Hardware Tests for Populate method
    #

    hardware_hpu_ux = HPUXHardware(dict(module=None))
    collected_facts = dict(ansible_architecture="ia64", ansible_distribution_version="B.11.31")
    hardware_hpu_ux.populate(collected_facts=collected_facts)
    cpu_facts = hardware_hpu_ux.get_cpu_facts(collected_facts=collected_facts)
    memory_facts = hardware_hpu_ux.get_memory_facts()
    hw_facts = hardware_hpu_ux.get_hw_facts()

    assert int(cpu_facts["processor_cores"]) == 16
    assert int(cpu_facts["processor_count"]) == 2

# Generated at 2022-06-22 23:05:29.328132
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    my_module = FakeAnsibleModule()
    setattr(my_module, 'run_command', run_command_mock)
    setattr(my_module, 'get_bin_path', get_bin_path_mock)

    My_hpux_hw = HPUXHardware()
    My_hpux_hw.module = my_module
    My_hpux_hw.populate()


# Test for method get_cpu_facts of class HPUXHardware

# Generated at 2022-06-22 23:05:30.824286
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({})
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-22 23:05:42.952520
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # testing a lot on the same object is not a good idea.
    # As soon as you have one specific test case,
    # use another object for the next one
    module = AnsibleModuleMock(platform="HP-UX")
    module.run_command.return_value=(0,'','','')
    hpux = HPUXHardware(module)
    assert hpux.populate({"ansible_distribution": "HP-UX", "ansible_distribution_version": "B.11.31"}) == \
           {"processor_count": 2, "processor": "Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz", "processor_cores": 16}

# Generated at 2022-06-22 23:05:45.507687
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_info = HPUXHardware(dict())
    assert hardware_info.platform == 'HP-UX'

# Generated at 2022-06-22 23:05:56.575687
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import platform
    module = platform.system()
    HPUXHardware.module = module
    hphw = HPUXHardware()

    test_facts = {'ansible_architecture': 'ia64'}
    expected = {'processor_count': 4, 'processor_cores': 4, 'processor': 'Intel(R) Itanium(R) Processor'}
    assert hphw.get_cpu_facts(collected_facts=test_facts) == expected

    test_facts = {'ansible_architecture': '9000/800'}
    expected = {'processor_count': 2}
    assert hphw.get_cpu_facts(collected_facts=test_facts) == expected

    test_facts = {'ansible_platform_version': 'B.11.23'}
    assert hphw

# Generated at 2022-06-22 23:06:01.470448
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Test constructor of class HPUXHardwareCollector
    object = HPUXHardwareCollector()
    assert object._platform == 'HP-UX'
    assert object._fact_class == HPUXHardware
    assert object.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-22 23:06:05.819447
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware(dict(ansible_facts=dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')))
    assert hardware.platform == 'HP-UX', "Initial Platform not match"
    assert hardware.populate()['processor_count'] == 1, "Number of processor not match"

# Generated at 2022-06-22 23:06:10.725666
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.fact_class == HPUXHardware
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:06:14.565327
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    HPUXHardware = HPUXHardwareCollector._fact_class(None)
    collected_facts = {
   'distribution': 'HPUX',
   'distribution_version': 'B.11.31',
   'ansible_architecture': 'ia64',
    }

    cpu_facts = HPUXHardware.get_cpu_facts(collected_facts)

    assert(isinstance(cpu_facts['processor_count'], int))
    assert(isinstance(cpu_facts['processor_cores'], int))
    assert(isinstance(cpu_facts['processor'], str))


# Generated at 2022-06-22 23:06:18.508774
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
   hw = HPUXHardware({'architecture':'ia64'})
   assert hw.get_memory_facts() == {'swaptotal_mb': 0,
                                    'swapfree_mb': 0,
                                    'memtotal_mb': 128,
                                    'memfree_mb': 0}



# Generated at 2022-06-22 23:06:29.904927
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # We load the test data from a yaml string to be sure that it can be loaded at runtime and for various reasons we
    # would rather not read a static file
    import yaml
    fact_data = """---
        ansible_architecture: "9000/800"
    """
    hardware = HPUXHardwareCollector()
    hardware.facts = yaml.load(fact_data)
    assert hardware.facts.get('ansible_architecture') == "9000/800"
    assert hardware.get_memory_facts()['memtotal_mb'] == 1024
    assert hardware.get_memory_facts()['memfree_mb'] == 256
    assert hardware.get_memory_facts()['swaptotal_mb'] == 0
    assert hardware.get_memory_facts()['swapfree_mb'] == 0

# Unit

# Generated at 2022-06-22 23:06:38.419960
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    mem_facts = hw.get_memory_facts(collected_facts)
    assert mem_facts['memtotal_mb'] == 1056
    assert mem_facts['memfree_mb'] == 92

    # Test for ia64
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    mem_facts = hw.get_memory_facts(collected_facts)
    assert mem_facts['memtotal_mb'] == 7168
    # Test for ia64

# Generated at 2022-06-22 23:06:48.535164
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    class HPUXHardware_populate_test_class(object):
        def __init__(self, test_string):
            self.test_string = test_string

        def run_command(self, cmd, use_unsafe_shell=False):
            if "machinfo" in cmd:
                if 'B.11.23' in self.test_string:
                    if 'Number of CPUs' in cmd:
                        return (0, "Number of CPUs = 2", "")
                    if 'processor family' in cmd:
                        return (0, "processor family = Intel(R) Itanium(R) processor 9300 series", "")
                    if 'Firmware revision' in cmd:
                        return (0, "Firmware revision = 2.70.C.0", "")

# Generated at 2022-06-22 23:06:55.771816
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    result = hw.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert result['processor_count'] == 20
    result = hw.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert result['processor_count'] == 2
    assert result['processor'] == 'Intel(R) Itanium 2 1.60GHz'
    assert result['processor_cores'] == 16

# Generated at 2022-06-22 23:07:09.257695
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    ''' Test get_memory_facts method of HPUXHardware class '''
    fake_module = type('', (), {
        'run_command': lambda self, cmd: ('0', '', ''),
        'params': {},
    })
    module = fake_module()
    hpux_hw = HPUXHardware(module)
    # Test with HPUX B.11.31
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hpux_hw.module.run_command = lambda cmd: ('0', '0 core', '')
    assert hpux_hw.get_memory_facts(collected_facts=collected_facts) == {'memfree_mb': 0, 'memtotal_mb': 0}
    collected

# Generated at 2022-06-22 23:07:20.969965
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Unit test for constructor of class HPUXHardwareCollector"""
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import Cacheable
    from ansible.module_utils.facts.hardware.hpuxtest import HPUXHardwareCollector
    # Test that constructor of class HPUXHardwareCollector
    # can be called
    HPUXHardwareCollector()
    # Test that instance of class HPUXHardwareCollector
    # inherits from BaseCollector
    obj = HPUXHardwareCollector()
    ##################################
    # Test for method get_collector_instance
    ##################################
    # Test that method get_collector_instance does not return

# Generated at 2022-06-22 23:07:23.136823
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert isinstance(hw, HPUXHardware)


# Generated at 2022-06-22 23:07:33.669737
# Unit test for method get_memory_facts of class HPUXHardware

# Generated at 2022-06-22 23:07:37.849813
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hw_obj = HPUXHardware(module)

    module.exit_json(changed=False, ansible_facts={'test_hw_obj': hw_obj})



# Generated at 2022-06-22 23:07:49.369397
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    m = HPUXHardware({})
    data = {'ansible_architecture': 'ia64',
            'ansible_distribution_version': "B.11.23"}
    out = m.get_hw_facts(data)
    assert out['firmware_version'] == 'UX 1.0'
    data = {'ansible_architecture': 'ia64',
            'ansible_distribution_version': "B.11.31"}
    out = m.get_hw_facts(data)
    assert out['product_serial'] == 'EC1G835'
    data = {'ansible_architecture': '9000/785'}
    out = m.get_hw_facts(data)
    assert out['model'] == 'HP9000/785'

# Generated at 2022-06-22 23:07:59.529915
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = Mock()
    module.run_command.return_value = (0, '300', '')
    hardware_collector = HPUXHardwareCollector(module=module)
    hardware_facts = hardware_collector._fact_class(module=module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware_facts.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 300
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware_facts.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 300

# Generated at 2022-06-22 23:08:09.949351
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = dict(platform='HP-UX', distribution='B.11.31')
    module = MockModule(facts)
    HPUXHardware(module).get_memory_facts()
    assert module.run_command.call_count == 6
    print(module.run_command.call_args_list)
    assert module.run_command.call_args_list[0][0][0] == 'swapinfo -m -d -f -q'
    assert module.run_command.call_args_list[1][0][0] == 'swapinfo -m -d -f | egrep \'^dev|^fs\''



# Generated at 2022-06-22 23:08:14.528770
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(dict())
    collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.23"
    }
    facts = hw.get_hw_facts(collected_facts)
    assert facts is not None, 'HPUXHardware_get_hw_facts should return facts not none'
    assert facts['firmware_version'], 'HPUXHardware_get_hw_facts should return firmware_version'
    assert facts['model'], 'HPUXHardware_get_hw_facts should return model'



# Generated at 2022-06-22 23:08:26.312773
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    m = HPUXHardware({'architecture': '9000/800'})
    s = re.sub(' +', ' ', """procs                          memory            page            disk          faults      cpu
 r  b  w  swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st
0  0  0 327028   1672   4340 390980    0    0     0     0    0    0  0  0 100  0  0""")
    assert m.get_memory_facts(collected_facts={'architecture': '9000/800'}) == {
        "memfree_mb": 4,
        "memtotal_mb": 972,
        "swaptotal_mb": 1288,
        "swapfree_mb": 1288
    }
    s

# Generated at 2022-06-22 23:08:32.365085
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    mock_module = Mock()

    # valid arguments - HP-UX
    mock_module.params = {'gather_subset': ['all', 'network', 'hardware'], 'gather_timeout': 10}
    mock_module.facts = {'distribution': 'HP-UX', 'platform': 'HP-UX'}

    # invalid argument - AIX
    mock_module.params = {'gather_subset': ['all', 'network', 'hardware'], 'gather_timeout': 10}
    mock_module.facts = {'distribution': 'AIX', 'platform': 'AIX'}

    assert HPUXHardwareCollector(mock_module).collect() is None

# Generated at 2022-06-22 23:08:45.069531
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    m.module = FakeModule()
    assert m.get_cpu_facts()['processor'] == 'Intel Itanium 2 9100 series'
    assert m.get_cpu_facts()['processor_cores'] == 4

    m = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    m.module = FakeModule()
    assert m.get_cpu_facts()['processor'] == 'Intel Xeon E5-2699 v4'
    assert m.get_cpu_facts()['processor_cores'] == 18
    assert m.get_cpu_facts()['processor_count'] == 2

# Generated at 2022-06-22 23:08:52.521181
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    collected_facts = {'ansible_architecture':'9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == 'Itanium'
    collected_facts = {'ansible_architecture':'ia64'}
    collected_facts = {'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 8

# Generated at 2022-06-22 23:08:57.817775
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = None
    hw = HPUXHardwareCollector(module)
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert isinstance(hw.get_facts(), dict)



# Generated at 2022-06-22 23:09:06.442899
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('', (), {})()
    setattr(module, 'run_command', fake_run_command)
    hardware = HPUXHardware(module)
    hardware_facts = hardware.get_hw_facts()
    assert hardware_facts['model'] == 'ia64 hp integrity rx2600'
    assert hardware_facts['firmware_version'] == '07.00.00'
    assert hardware_facts['product_serial'] == 'SERIAL'

# Method fake_run_command return fake data for tests.

# Generated at 2022-06-22 23:09:16.971024
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # success
    if module.params['gather_subset'] == ['!all']:
        hardware = HPUXHardware()
        res = hardware.populate()

        assert res['processor_count'] == int(16)
        assert res['processor_cores'] == int(16)
        assert res['processor'] == 'Intel(R) Itanium(R) Processor'
        assert res['memtotal_mb'] == int(262098)
        assert res['swaptotal_mb'] == int(16)
        assert res['swapfree_mb'] == int(16)

    # success

# Generated at 2022-06-22 23:09:20.989054
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # Initialize class
    h = HPUXHardware(dict(module=None))

    # Test populate method
    if not h.populate():
        raise Exception('Failed to populate')
    else:
        print('Test passed')

# Generated at 2022-06-22 23:09:32.773351
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class TestAnsibleModule:
        def run_command(self, cmd, use_unsafe_shell=False):
            data = []
            if cmd == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
                data = [0, "Number of CPUs = 2", None]
            if cmd == "ioscan -FkCprocessor | wc -l":
                data = [0, "2", None]
            if cmd == "grep Physical /var/adm/syslog/syslog.log":
                data = [0, "test", None]

# Generated at 2022-06-22 23:09:39.037674
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({})
    hardware_collector = HPUXHardwareCollector()
    hardware = hardware_collector.collect(module=module, collected_facts={})
    facts = hardware.populate()
    assert type(facts) == dict
    for key, value in facts.items():
        assert type(value) != type(None)



# Generated at 2022-06-22 23:09:47.837783
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = dict(platform="HP-UX", distribution="B.11.31")
    hardware = HPUXHardware(None, collected_facts)
    hardware._module.run_command = lambda *args, **kwargs: (0, 'HP rx2660 base, base 2048MB, IOAPIC enabled', '')
    assert hardware.get_hw_facts(collected_facts) == {'model': 'HP rx2660 base, base 2048MB, IOAPIC enabled'}
    collected_facts = dict(platform="HP-UX", distribution="B.11.23")
    hardware = HPUXHardware(None, collected_facts)
    hardware._module.run_command = lambda *args, **kwargs: (0, 'B22 G5 Base (2 CPU) base 2048MB', '')
    assert hardware.get_hw_facts

# Generated at 2022-06-22 23:10:00.720091
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {
        'ansible_architecture': '9000/800'
    }
    hardware_facts = HPUXHardware(None).get_cpu_facts(collected_facts=collected_facts)

    assert hardware_facts['processor_count'] == 0
    assert not hardware_facts.get('processor')
    assert not hardware_facts.get('processor_cores')
    assert not hardware_facts.get('processor_count')

    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hardware_facts = HPUXHardware(None).get_cpu_facts(collected_facts=collected_facts)

    assert hardware_facts['processor_count'] > 0

# Generated at 2022-06-22 23:10:01.830369
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    c = HPUXHardwareCollector()
    assert c.collect() is not None

# Generated at 2022-06-22 23:10:07.356634
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    hpux_hardware_obj = HPUXHardware(dict())
    # Test when ansible_architecture is 9000/800
    hpux_hardware_obj.module.run_command = lambda x: (0, '2', '')
    hpux_hardware_obj.module.run_command = lambda x: (0, '4', '')
    hpux_hardware_obj.module.run_command = lambda x: (0, '1', '')
    hpux_hardware_obj.module.run_command = lambda x: (0, '6', '')
    hpux_hardware_obj.module.run_command = lambda x: (0, '8', '')
    hpux_hardware_obj.module

# Generated at 2022-06-22 23:10:16.448512
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h = HPUXHardware()
    h.module = MockModule()

    fake_collector_facts = {'ansible_architecture': h.platform, 'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'}
    facts = h.populate(collected_facts=fake_collector_facts)

    assert(facts['processor_count'])
    assert(facts['processor'])
    assert(facts['processor_cores'])
    assert(facts['memfree_mb'])
    assert(facts['memtotal_mb'])
    assert(facts['swapfree_mb'])
    assert(facts['swaptotal_mb'])
    assert(facts['model'])



# Generated at 2022-06-22 23:10:22.169858
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()
    module.exit_json(changed=False, ansible_facts=dict(hardware=hardware_obj.facts))



# Generated at 2022-06-22 23:10:32.489477
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    m = HPUXHardware({'architecture': "ia64"})
    m.module.run_command = lambda x: (0, 'B.11.31', '')
    m.populate()
    assert m.get_hw_facts({'distribution_version': 'B.11.23'}) == {'model': 'HP rx7620', 'firmware_version': '05.34.D4.02'}
    assert m.get_hw_facts({'distribution_version': 'B.11.31'}) == {'model': 'HP rx7620', 'firmware_version': '05.34.D4.02', 'product_serial': 'PB50961200'}

# Generated at 2022-06-22 23:10:43.372919
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = type('AnsibleModule', (object,),
                       {'run_command': run_command_mock,
                        'params': {'gather_subset': ['all']}})

    test_class = HPUXHardware(test_module)
    # test machinfo case
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    test_cpu_facts = {'processor_cores': 28, 'processor': 'Intel(R) Itanium(R) Processor 9300', 'processor_count': 4}
    assert test_class.get_cpu_facts(collected_facts) == test_cpu_facts, "Error in get_cpu_facts method for B.11.23 release"
    # test ioscan case


# Generated at 2022-06-22 23:10:56.410078
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Test case 1
    module = FakeAnsibleModule()
    module.run_command = run_command_mock

# Generated at 2022-06-22 23:11:09.352987
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class MockModule(object):

        def __init__(self):
            self.run_command_counter = 0
            self.run_command = None
            self.run_command_output = {'rc': 0, "out": "", "err": ""}

        def run_command(self, cmd, check_rc=True, use_unsafe_shell=False):
            self.run_command_counter += 1
            self.run_command = cmd
            return self.run_command_output['rc'], self.run_command_output['out'], self.run_command_output['err']

    class MockFacts(object):

        def __init__(self):
            self.ansible_facts = {}

    module = MockModule()
    facts = MockFacts()

# Generated at 2022-06-22 23:11:12.519538
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hw_obj = HPUXHardware(module)
    assert hw_obj.platform == 'HP-UX'

# Generated at 2022-06-22 23:11:22.666819
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Create the mock module
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 23:11:34.126064
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    hw_facts = hw.get_hw_facts(collected_facts)
    module = FakeAnsibleModule()
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts)

# Generated at 2022-06-22 23:11:39.774432
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)

    class TestHPUXHardware(HPUXHardware):
        def __init__(self):
            self.model = "fake_model"

    test_hw = TestHPUXHardware()

    hw_facts = test_hw.get_hw_facts()

    assert hw_facts["model"] == "fake_model"


# Generated at 2022-06-22 23:11:46.347225
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = FakeModule()
    hw.module.run_command.side_effect = [[0, 'rp2405\n', '']]
    hw.get_hw_facts({"ansible_architecture": "ia64"})
    hw.module.run_command.assert_called_with("model")



# Generated at 2022-06-22 23:11:50.394305
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert isinstance(h, HardwareCollector)
    assert h.platform == 'HP-UX'
    assert h.required_facts == {'platform', 'distribution'}



# Generated at 2022-06-22 23:11:57.731834
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Test with processor_count and processor in machinfo output
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['all']
    module.params['filter'] = '*'
    hpu = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hpu.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor        (1.20 GHz, 16 MB)'
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_count'] == 2

    # Test with processor_count and processor not in machinfo

# Generated at 2022-06-22 23:12:08.967294
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Test the HPUXHardware class.
    """
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = {
                ('/usr/bin/vmstat | tail -1',): ("", " "),
                ("grep Physical /var/adm/syslog/syslog.log",): ("", " "),
            }

        def run_command(self, args, **kwargs):
            rc = 0
            out = err = ""
            if args in self.run_command_calls:
                rc = 0
                out, err = self.run_command_calls[args]
            return rc, out, err


# Generated at 2022-06-22 23:12:19.695082
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # create test data
    data_output = b"mem_total:   426468 Kbytes\nmem_free:    397388 Kbytes\nswap_total:  522136 Kbytes\nswap_free:   522136 Kbytes\n\n"
    # create instance of class
    hardware_mock = HPUXHardware(dict(module=dict(run_command=lambda *args, **kwargs: (0, data_output, ''))))
    # run method
    hardware_mock.populate()
    # check data
    assert hardware_mock.facts['memfree_mb'] == 388
    assert hardware_mock.facts['memtotal_mb'] == 416
    assert hardware_mock.facts['swapfree_mb'] == 507

# Generated at 2022-06-22 23:12:23.753592
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MockModule()
    hw = HPUXHardware(module)

    hw.get_hw_facts()

    module.run_command.assert_has_calls([
        call('model'),
        call('/usr/contrib/bin/machinfo |grep -i \'Firmware revision\' | grep -v BMC'),
        call('/usr/contrib/bin/machinfo |grep -i \'Machine serial number\' ')
    ])


# Generated at 2022-06-22 23:12:27.188300
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    c = HPUXHardwareCollector()
    assert c.platform == 'HP-UX'
    assert c.required_facts == {'platform', 'distribution'}
    assert c._fact_class == HPUXHardware

# Generated at 2022-06-22 23:12:39.713459
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """ Test get_hw_facts of class HPUXHardware """
    from ansible.modules.system import hpux_hw_facts
    test_module = hpux_hw_facts.FakeModule()
    test_facts = HPUXHardware(module=test_module)
    test_facts.populate()
    hw_facts = test_facts.get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx7640', "get_hw_facts: test_HPUXHardware_get_hw_facts assert #1 failed"
    assert hw_facts['firmware_version'] == '4.24', "get_hw_facts: test_HPUXHardware_get_hw_facts assert #2 failed"

# Generated at 2022-06-22 23:12:50.958840
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    with open('tests/unit/test_data/hardware/HPUXHardware_get_hw_facts_test.txt', 'rb') as f:
        out = f.read()
    module = FakeModule(out=out)
    hw = HPUXHardware(module)
    result = hw.get_hw_facts(collected_facts={'ansible_architecture': 'ia64',
                                              'ansible_distribution_version': "B.11.23"})
    assert result == {'firmware_version': u'B.11.23.0606', 'model': u'ia64 hp server rx8640', 'product_serial': u'CZC8421F9L'}



# Generated at 2022-06-22 23:13:01.033454
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # basic test for populate method of HPUXHardware class
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]


# Generated at 2022-06-22 23:13:06.095515
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    collected_facts = {}
    hardware_facts = hardware.populate(collected_facts=collected_facts)

    # Ensure that no exceptions are thrown and that the output is basically a dict
    assert isinstance(hardware_facts, dict)



# Generated at 2022-06-22 23:13:16.913796
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 16


# Generated at 2022-06-22 23:13:28.854094
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware({})
    collected_facts = {'ansible_architecture': 'parisc'}
    result = hw.get_cpu_facts(collected_facts=collected_facts)
    assert result['processor_count'] == 1
    assert result['processor_cores'] == 1
    assert result['processor'] == 'PA-RISC 2.0 (1.0 Mhz)'
    assert not result.get('processor_vcpus')
    assert not result.get('processor_threads_per_core')

    collected_facts = {'ansible_architecture': '9000/800'}
    result = hw.get_cpu_facts(collected_facts=collected_facts)
    assert result['processor_count'] == 2
    assert result['processor_cores'] == 1


# Generated at 2022-06-22 23:13:38.849231
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpux = HPUXHardware({})
    hw_facts = hpux.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hw_facts['model'] == 'ia64 hp integrity rx2660 server'
    assert hw_facts['firmware_version'] == 'B.11.23'
    assert hpux.populate({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})['ansible_processor_count'] == 4

# Generated at 2022-06-22 23:13:40.589169
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpu = HPUXHardware()
    assert hpu.platform == 'HP-UX'

# Generated at 2022-06-22 23:13:51.779437
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    sample_input = {
        'ansible_facts': {
            'ansible_architecture': 'ia64',
            'ansible_distribution': 'HP-UX',
            'ansible_distribution_version': 'B.11.31'
        }
    }
    sample_output = {
        'ansible_facts': {
            'model': 'ia64',
            'firmware_version': 'B.11.31',
            'product_serial': 'B.11.31'
        }
    }
    test = HPUXHardware()
    test.get_hw_facts()

    test.module.run_command = lambda x: (0, '', '')

# Generated at 2022-06-22 23:14:03.285992
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    This function sets up a dictionary (facts) to simulate data collected by Ansible
    and test the populate method of HPUXHardware class.
    The keys of facts are concatenations of ansible_ and the name of a fact, the value is the value of the fact.
    """
    module = None
    facts = {'ansible_architecture': 'ia64',
             'ansible_distribution': 'HP-UX',
             'ansible_distribution_version': 'B.11.31',
             'ansible_os_family': 'Debian',
             'ansible_platform': 'HP-UX',
             }
    hardware = HPUXHardware(module)
    hardware.populate(facts)
    assert "processor_count" in hardware.data

if __name__ == '__main__':
    test_

# Generated at 2022-06-22 23:14:15.953316
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    If a system reports a swap space of 0, then Ansible must still report the
    swapfree_mb as 0 rather than undefined (None).
    """
    # Setup all needed objects for the unit test.
    def vmunix_module(self):
        return None
    globals()['vmunix_module'] = vmunix_module
    class AnsibleModule(object):
        def __init__(self, argument_spec=None, bypass_checks=None,
                     check_invalid_arguments=None, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=None, supports_check_mode=None,
                     required_by=None):
            return None