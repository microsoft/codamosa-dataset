

# Generated at 2022-06-22 23:04:23.528311
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    # Output of uname -m for ia64
    module.ansible_facts['uname_machine'] = 'ia64'
    # Output of /usr/contrib/bin/machinfo for B.11.23
    module.run_command.return_value = (0, '    Number of CPUs = 16', '')
    module.ansible_facts['ansible_architecture'] = "ia64"
    module.ansible_facts['ansible_distribution_version'] = "B.11.23"

    hardware = HPUXHardware(module=module)
    hardware_facts = hardware.get_cpu_facts()

    assert hardware_facts['processor_count'] == 16

    # Output of uname -m for ia64

# Generated at 2022-06-22 23:04:33.930045
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hw = HPUXHardware(module)
    assert hw.populate() == {'processor': 'Intel(R) Itanium(R) Processor 9560',
                             'processor_count': 2,
                             'memfree_mb': 448,
                             'memtotal_mb': 1024,
                             'processor_cores': 2,
                             'firmware_version': '4.30.0.0',
                             'swapfree_mb': 0,
                             'swaptotal_mb': 0,
                             'model': 'ia64 hp server rx2660',
                             'product_serial': 'USL008401'}



# Generated at 2022-06-22 23:04:42.062796
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    cpu_count = 4
    rc, out, err = HardwareCollector.module.run_command("/usr/sbin/swapinfo -m -d -f -q")
    swap_total_before_add = int(out.strip())
    rc, out, err = HardwareCollector.module.run_command("/usr/sbin/swapinfo -m -d -f | egrep '^dev|^fs'", use_unsafe_shell=True)
    swap_free_before_add = 0
    for line in out.strip().splitlines():
        swap_free_before_add += int(re.sub(' +', ' ', line).split(' ')[3].strip())
    pagesize = 4096

# Generated at 2022-06-22 23:04:47.757464
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Test unit for method populate of class HPUXHardware.
    # Test object instantiation.
    hw = HPUXHardware()
    assert hw
    # Test data collection.
    hw.populate()
    assert hw.data

# Generated at 2022-06-22 23:04:55.441012
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({})
    hardware = HPUXHardware(module=module)
    collected_facts = {
        "platform": "HP-UX",
        "architecture": "ia64",
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.31"
    }
    hardware_facts = hardware.populate(collected_facts=collected_facts)
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor'] == 'Intel Itanium 2'
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['memfree_mb'] == 1693
    assert hardware_facts['memtotal_mb'] == 14167
    assert hardware_facts['swaptotal_mb'] == 1023
    assert hardware_

# Generated at 2022-06-22 23:05:05.821228
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hphw = HPUXHardware(module)
    hphw.collect_platform_subset_facts = Mock(return_value=dict(ansible_architecture='9000/800', ansible_distribution_version='B.11.23'))
    rc, out, err = hphw.module.run_command("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)
    hphw.module.run_command = Mock(return_value=(0, out, ''))

    facts = hphw.populate()
    assert facts.get('processor_count') == 1
    assert facts.get('memtotal_mb') == 1
    assert facts.get('memfree_mb') == 1

# Generated at 2022-06-22 23:05:16.981801
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware_facts = HPUXHardware().get_cpu_facts(collected_facts)
    assert hardware_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hardware_facts = HPUXHardware().get_memory_facts(collected_facts)
    assert hardware_facts['memtotal_mb'] > 1
    assert hardware_facts['memfree_mb'] > 1
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware_facts = HPUXHardware().populate(collected_facts)
    assert hardware_facts['processor_count'] == 1

# Generated at 2022-06-22 23:05:29.129487
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert 'processor_cores' in facts
    assert facts['processor_cores'] == 1
    assert 'processor_count' in facts
    assert facts['processor_count'] == 2
    assert 'model' in facts
    assert facts['model'] == '9000/785'
    assert 'firmware_version' in facts
    assert facts['firmware_version'] == 'BC12'
    assert 'product_serial' in facts
    assert facts['product_serial'] == 'MXSE6381966'
    assert 'memfree_mb' in facts

# Generated at 2022-06-22 23:05:39.245512
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    # Define inputs
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    expected_facts = {
        'memfree_mb': 189,
        'memtotal_mb': 3865,
        'swaptotal_mb': 7,
        'swapfree_mb': 7
    }

    # Assertion
    assert expected_facts == HPUXHardware().get_memory_facts(collected_facts=collected_facts)

# Generated at 2022-06-22 23:05:51.581679
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = MockModule()
    hardware = HPUXHardware(module)

    module.run_command.return_value = (0, '', '')
    module.run_command.return_value = (0, '/dev/vg00/lvol1             204800   137056   67744   68% /stand', '')
    assert hardware.get_memory_facts() == {'memfree_mb': 137056 * 4096 / 1024 / 1024, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 204800 * 4096 / 1024 / 1024}
    assert module.run_command.call_args_list[0][0][0] == '/usr/bin/vmstat'

# Generated at 2022-06-22 23:05:53.536384
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict())
    assert hw.platform == 'HP-UX'



# Generated at 2022-06-22 23:06:04.400730
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    import os
    import test.utils as testutils
    testutils.run_module(
        'hpu_hardware', dict(
            state='list',
            ansible_facts=dict(
                distribution='B.11.231',
                ansible_architecture='ia64'
            )
        ),
        ignore_current_env=True,
    )

    data = testutils.get_parsed_results()
    assert data['ansible_facts']['ansible_product_serial']
    assert data['ansible_facts']['ansible_firmware_version']


# Generated at 2022-06-22 23:06:08.026444
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({})
    assert hardware.platform == 'HP-UX'



# Generated at 2022-06-22 23:06:14.820633
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    HPUX_hw_col = HPUXHardwareCollector()
    assert HPUX_hw_col._fact_class == HPUXHardware
    assert HPUX_hw_col._platform == 'HP-UX'
    assert HPUX_hw_col.required_facts == {'platform', 'distribution'}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-22 23:06:16.422381
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector()
    assert hardware._platform == 'HP-UX'
    assert hardware._fact_class._platform == 'HP-UX'

# Generated at 2022-06-22 23:06:25.207697
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware().populate()
    assert hardware_facts['processor'] == 'Itanium 9300'
    assert hardware_facts['processor_cores'] == 48
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['memtotal_mb'] == 107586
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['firmware_version'] == 'v1.18'
    assert hardware_facts['product_serial'] == 'ABC1234567'
    assert hardware_facts['model'] == 'ia64 hp server rx2800 i4'

# Generated at 2022-06-22 23:06:32.021904
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec=dict())
    facts_obj = HPUXHardwareCollector(module)
    assert facts_obj.platform == 'HP-UX'
    assert facts_obj.required_facts == set(['platform', 'distribution'])
    assert facts_obj._fact_class == HPUXHardware


# Generated at 2022-06-22 23:06:42.239508
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware(None)
    hw.module.run_command = lambda x: (0, '4\n', '')
    assert hw.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'}) == {'processor_count': 4}

    hw.module.run_command = lambda x: (0, 'Intel(R) Itanium(R) Processor\n', '')
    assert hw.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}) == {'processor': 'Intel(R) Itanium(R) Processor', 'processor_count': 4, 'processor_cores': 4}


# Generated at 2022-06-22 23:06:44.476321
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    mac = HPUXHardwareCollector()
    assert mac.platform == 'HP-UX'
    assert mac.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:06:55.079582
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Test data
    data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

    class Platform:
        platform = "HP-UX"
        distribution = "HP-UX"

    class Module:
        platform = Platform()
        run_command = mock_run_command

    # Creating instance of class HPUXHardware
    obj = HPUXHardware(module=Module())
    # Calling get_cpu_facts method of class HPUXHardware
    results = obj.get_cpu_facts(data)

    # Test assertions
    assert results['processor_count'] == 6
    assert results['processor'] == "Intel(R) Itanium(R) Processor 9320"
    assert results['processor_cores'] == 12



# Generated at 2022-06-22 23:07:08.401677
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand().run_command

    hw_obj = HPUXHardware(module)
    hw_facts_dict = hw_obj.get_hw_facts()
    hw_facts_dict['firmware'] = hw_facts_dict.pop('firmware_version')
    hw_facts_dict['serialnumber'] = hw_facts_dict.pop('product_serial')

    fake_ansible_facts = {
        'ansible_distribution_version': 'B.11.23',
        'ansible_distribution': 'HP-UX',
        'ansible_architecture': 'ia64'
    }

    # Pass a fake ansible_facts

# Generated at 2022-06-22 23:07:16.283303
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware_obj = HPUXHardware(module)
    memory_facts = hardware_obj.get_memory_facts()

    assert(memory_facts['memfree_mb'] > 0)
    assert(memory_facts['memtotal_mb'] > 0)
    assert(memory_facts['swaptotal_mb'] > 0)
    assert(memory_facts['swapfree_mb'] > 0)



# Generated at 2022-06-22 23:07:25.279036
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    required_facts = {
        'platform': 'HP-UX',
        'distribution_version': 'B.11.31',
        'architecture': 'ia64',
    }
    test_class = HPUXHardware(dict(), dict(), True)
    test_class.populate()
    cpu_facts = test_class.get_cpu_facts(required_facts)
    assert isinstance(cpu_facts['processor_count'], int)
    assert isinstance(cpu_facts['processor_cores'], int)
    assert isinstance(cpu_facts['processor'], str)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor'] == 'Intel(R) Itanium 2 9500 series processors'


# Generated at 2022-06-22 23:07:26.418046
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUXHardwareCollector().populate()

# Generated at 2022-06-22 23:07:28.228210
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-22 23:07:36.833436
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    hardware = HPUXHardware(module=None)

    collected_facts = dict(
        ansible_architecture="9000/800",
        ansible_distribution_version="B.11.11",
    )
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert 'processor_count' in cpu_facts
    assert 'processor' not in cpu_facts

    collected_facts = dict(
        ansible_architecture="ia64",
        ansible_distribution_version="B.11.23",
    )
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert 'processor_count' in cpu_facts
   

# Generated at 2022-06-22 23:07:40.879756
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector()
    assert hc is not None
    assert issubclass(hc.fact_class, HPUXHardware)
    assert hc.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:47.154653
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = None
    hardware = HPUXHardware(module)
    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(facts)
    assert 'model' in hw_facts
    assert 'firmware_version' in hw_facts
    assert 'product_serial' in hw_facts


# Generated at 2022-06-22 23:07:54.058017
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23',
    }
    hardware = HPUXHardware(dict(module=None), facts=facts)

    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts == {
        'processor_count': 2,
        'processor': 'Intel(R) Itanium(R) Processor',
        'processor_cores': 1,
    }

    facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
    }
    hardware = HPUXHardware(dict(module=None), facts=facts)

    cpu_facts = hardware.get_cpu_facts()
    assert cpu_

# Generated at 2022-06-22 23:07:55.850309
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector()
    assert hardware.platform == "HP-UX"



# Generated at 2022-06-22 23:08:08.035363
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.sysctl = dict()
    module.cpuinfo = dict()
    hpux_hardware = HPUXHardware(module)
    collected_facts = dict()

    # Test CPU facts with architecture 9000/800
    collected_facts['ansible_architecture'] = '9000/800'
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] is None
    assert cpu_facts['processor_cores'] is None

    # Test CPU facts with architecture 9000/785
    collected_facts['ansible_architecture'] = '9000/785'
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts)

# Generated at 2022-06-22 23:08:15.905751
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    result = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw = HPUXHardware(None)
    hw.module = type('', (), {})
    hw.module.run_command = lambda *args: ('0', 'model 9000/800', '')
    ans = hw.get_hw_facts(collected_facts=result)
    assert ans['model'] == '9000/800'

# Generated at 2022-06-22 23:08:24.055751
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    hw = HPUXHardware(module=module)
    facts = hw.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swapsize_mb' in facts
    assert 'swapfree_mb' in facts

# Generated at 2022-06-22 23:08:25.742537
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    assert HPUXHardware().platform == "HP-UX"


# Generated at 2022-06-22 23:08:29.235145
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()
    assert hhc.platform == 'HP-UX'
    assert hhc.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-22 23:08:41.815171
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    module.run_command.return_value = (0, ' ', '')

    hw = HPUXHardware(module)
    hw.populate(collected_facts={'ansible_architecture': '9000/800'})

    module.run_command.assert_called_with("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)

    hw = HPUXHardware(module)
    hw.populate(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})


# Generated at 2022-06-22 23:08:54.369363
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hu = HPUXHardware({})
    rc, out, err = hu.module.run_command("echo 'HP 9000/785       A3000        2013491863  16:16:04   OSP11-C1SE    2-DEC-2003  B_11.00.50.0' | cut -c 1-25")
    rc, out, err = hu.module.run_command("echo 'HP 9000/785       A3000        2013491863  16:16:04   OSP11-C1SE    2-DEC-2003  B_11.00.50.0%' | cut -c 1-25")

# Generated at 2022-06-22 23:08:58.799874
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts = set(['platform', 'distribution'])
    hhc = HPUXHardwareCollector
    my_required_facts = hhc.required_facts
    assert my_required_facts == required_facts

# Generated at 2022-06-22 23:09:01.700573
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = MagicMock()
    hw = HPUXHardware(module)
    hw.populate()



# Generated at 2022-06-22 23:09:12.563670
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()

    # Test on HP-UX B.11.31 IA64
    hw.module.run_command = lambda *_, **__: [
        0, ' model             : rx7640', None
    ]
    hw.module.run_command = lambda *_, **__: [
        0, ' Firmware revision  = v2.37', None
    ]
    hw.module.run_command = lambda *_, **__: [
        0, ' Machine serial number = CZC01234567', None
    ]

    hw.module.get_bin_path = lambda _: '/usr/contrib/bin/machinfo'
    hw.module.get_bin_path = lambda _: '/usr/bin/model'


# Generated at 2022-06-22 23:09:25.251364
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class MockModule():
        def __init__(self):
            self.run_command_called = False
        def run_command(self, command, use_unsafe_shell=None):
            self.run_command_called = True

# Generated at 2022-06-22 23:09:27.696774
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_facts = HPUXHardware(dict())
    assert hardware_facts.platform == 'HP-UX'


# Generated at 2022-06-22 23:09:30.996011
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    try:
        module = get_module_mock()
        HPUXHardwareCollector(module=module)
    except Exception:
        raise Exception("Failed to construct HPUXHardwareCollector")


# Generated at 2022-06-22 23:09:43.761693
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    class MockModule(object):
        def __init__(self):
            self.run_command = MockRunCommand()

    class MockRunCommand(object):
        def __call__(self, command, use_unsafe_shell=True):
            if re.search(r'model', command):
                output = 'ia64 Integrity rx3600'
            elif re.search(r'machinfo', command):
                if re.search(r'Firmware revision', command):
                    output = 'Firmware revision = ""'
                elif re.search(r'Machine serial number', command):
                    output = 'Machine serial number = ""'
                elif re.search(r'Memory', command):
                    output = 'Memory = 8192MB'
                else:
                    output = 'Socket = 2'

            return 0, output,

# Generated at 2022-06-22 23:09:47.130114
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector_inst = HPUXHardwareCollector()
    assert hw_collector_inst._fact_class == HPUXHardware


# Generated at 2022-06-22 23:10:00.033300
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_mock = HPUXHardware()
    hardware_mock.module = MagicMock()
    hardware_mock.module.run_command.return_value = (0, 'HP-UX', None)
    hardware_mock.module.run_command = MagicMock()

# Generated at 2022-06-22 23:10:04.289289
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = Mock()
    module.run_command.side_effect = [
        (0, "ia64 ia64 ia64 amd64 hp 9000 800", ""),
        (0, "Integrity rx2660", "")
    ]
    hardware = HPUXHardware(module)
    res = hardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert res == {
        'firmware_version': '',
        'model': "Integrity rx2660"
    }



# Generated at 2022-06-22 23:10:14.383359
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    hardware_facts = HPUXHardware()
    # Test HP-UX 11.31 ia64 and no hyperthreading
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware_facts.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    # Test HP-UX 11.31 ia64 and hyperthreading

# Generated at 2022-06-22 23:10:16.827175
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h._fact_class == HPUXHardware
    assert h._platform == 'HP-UX'
    assert h.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:10:21.189880
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector(None)
    assert h._fact_class == HPUXHardware
    assert h._platform == 'HP-UX'
    assert h.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-22 23:10:23.682577
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware().get_hw_facts()
    assert hw_facts.get('firmware_version')
    assert hw_facts.get('product_serial')

# Generated at 2022-06-22 23:10:27.585607
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector('ansible_facts')
    assert (collector.required_facts == set(['platform', 'distribution']))
    assert (collector.platform == 'HP-UX')
    assert (collector._fact_class == HPUXHardware)
    collector.collect()

# Generated at 2022-06-22 23:10:39.741675
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Set value for FAKE_HP_UX_HARDWARE env var to fake execute command
    os.environ['FAKE_HP_UX_HARDWARE'] = ''
    cpu_facts = {'processor_count': 2}
    memory_facts = {'memfree_mb': 319, 'memtotal_mb': 7450, 'swapfree_mb': 6144, 'swaptotal_mb': 8192}
    hw_facts = {'model': 'ia64 hp server rx8640', 'firmware_version': 'B.11.31', 'product_serial': 'PA7333DL9H'}
    # Run method
    hardware = HPUXHardware(module)

# Generated at 2022-06-22 23:10:51.096525
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test HPUXHardware.get_hw_facts()
    """
    h = HPUXHardware()
    facts = h.get_hw_facts({'platform': 'HP-UX', 'distribution': 'B.11.23'})

    assert 'ia64' in facts['hw_architecture']
    assert 'Intel(R) Itanium(R) Processor' in facts['processor']
    assert 'B.11.23' in facts['distribution_version']
    assert 32 == facts['processor_cores']
    assert 1 == facts['processor_count']
    assert '0x200000000' in facts['memtotal_mb']
    assert 'Integrity rx2800 i2' in facts['model']
    assert 'F.22' in facts['firmware_version']

# Generated at 2022-06-22 23:11:00.904276
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.collector.hpux.hpux_booted_kernel import HPUXKernel
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module)
    bootsys = HPUXKernel(module)
    data = bootsys.get_bootsys()
    if data:
        collected_facts = {'ansible_architecture': data.get('arch')}
    else:
        collected_facts = {'ansible_architecture': 'ia64'}
    data = hardware.get_cpu_facts(collected_facts)
    print("get_cpu_facts " + str(data))
    assert isinstance(data, dict)


# Generated at 2022-06-22 23:11:04.797529
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.required_facts == set(['platform', 'distribution'])
    assert h._fact_class is HPUXHardware



# Generated at 2022-06-22 23:11:16.539721
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = {'ansible_archiecture': '9000/785',
             'ansible_distribution': 'HP-UX',
             'ansible_distribution_version': 'B.11.31'}
    hardware_facts = HPUXHardware(facts)

# Generated at 2022-06-22 23:11:24.812877
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution_version': 'B.11.23'}
    facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert facts == {'swaptotal_mb': 2056,
                     'swapfree_mb': 2056,
                     'memfree_mb': 634,
                     'memtotal_mb': 1023}

# Generated at 2022-06-22 23:11:28.337629
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HardwareCollector.platform = 'HP-UX'
    HardwareCollector.required_facts = set(['platform', 'distribution'])
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:11:33.415105
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hd = HPUXHardware({'module_setup': True, 'ansible_architecture': '9000/785'})

    out = hd.populate({'ansible_architecture': '9000/785'})
    hd.module.exit_json(**out)


if __name__ == '__main__':
    test_HPUXHardware_populate()

# Generated at 2022-06-22 23:11:37.188302
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
        Constructor test of class HPUXHardware
    """
    module = None
    hphw = HPUXHardware(module)

    assert hphw.platform == 'HP-UX'
    assert hphw.files == {}

# Generated at 2022-06-22 23:11:41.351456
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """Unit test for method get_hw_facts of class HPUXHardware"""
    module = type('', (object,), {
        'run_command': lambda *args, **kwargs: (0, "", "")
    })()
    _HPUXHardware = HPUXHardware(module)
    facts = _HPUXHardware.get_hw_facts()
    assert isinstance(facts, dict)


# Generated at 2022-06-22 23:11:44.907492
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector
    assert hhc._platform == 'HP-UX'
    assert hhc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:11:49.403171
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts import FactCollector
    facts = FactCollector(None, None)
    facts.collect(['platform', 'distribution'])

    obj = HPUXHardwareCollector(facts)
    assert obj._platform == 'HP-UX'

# Generated at 2022-06-22 23:11:57.314648
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    module.run_command.return_value = (0, 'out', 'err')
    hardware = HPUXHardware(module)

    # Test simple host
    hardware.populate()

# Generated at 2022-06-22 23:12:06.431000
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    hw = HPUXHardware(dict(), dict())

    hw.get_cpu_facts = lambda: {'a': '1', 'b': '2'}
    hw.get_memory_facts = lambda: {'c': '3', 'd': '4'}
    hw.get_hw_facts = lambda: {'e': '5', 'f': '6'}

    assert hw.populate() == {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5', 'f': '6'}

# Generated at 2022-06-22 23:12:09.255950
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware()
    assert h.platform == 'HP-UX'
    assert h._platform == 'HP-UX'

# Generated at 2022-06-22 23:12:14.412879
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    hw = HPUXHardwareCollector._fact_class(dict(module=None), facts=facts)
    assert hw.populate() == {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31', 'processor': 'Intel(R) Itanium(R) 9100 series processor @ 1.44GHz', 'processor_cores': 8, 'processor_count': 4}

# Generated at 2022-06-22 23:12:19.161277
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    collected_facts = {}
    hardware = HPUXHardware()
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'



# Generated at 2022-06-22 23:12:20.604766
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'



# Generated at 2022-06-22 23:12:24.343251
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert set(HPUXHardwareCollector.required_facts) == set(['platform', 'distribution'])
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector._fact_class is HPUXHardware

# Generated at 2022-06-22 23:12:37.335232
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Test case to validate the result of method populate of class HPUXHardware
    """
    m_run_command = MagicMock(return_value=(0, "2", ""))
    m_module = MagicMock(return_value=m_run_command)
    hpux_hardware = HPUXHardware(m_module, {'ansible_architecture': "9000/800"})
    result_facts = hpux_hardware.populate()


# Generated at 2022-06-22 23:12:44.899425
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    loader, inventory, variable_manager = ModuleUtils.setup_loader()
    module = AnsibleModule(argument_spec=dict())
    module._ansible_diff = True
    result = HPUXHardwareCollector(module=module).collect()
    assert result['failed'] is False
    assert list(result.keys()) == ['ansible_facts']
    assert list(result['ansible_facts'].keys()) == ['ansible_hardware']
    assert result['ansible_facts']['ansible_hardware'] == dict(memfree_mb=None, memtotal_mb=None, swapfree_mb=None,
                                                               swaptotal_mb=None,
                                                               processor_cores=None, processor_count=None,
                                                               processor=None, model=None, firmware_version=None)



# Generated at 2022-06-22 23:12:57.610057
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # initialize some test var
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': "B.11.31"
    }
    # initialize test object
    HPUXHardware = HPUXHardware()
    # call method under test
    result = HPUXHardware.get_memory_facts(collected_facts)
    # check results
    correct_values = {
        'memfree_mb': 12,
        'memtotal_mb': 11395,
        'swaptotal_mb': 0,
        'swapfree_mb': 0
    }

# Generated at 2022-06-22 23:13:05.676796
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class HPUXHardware"""

    from ansible.module_utils.facts.hardware.hpu_ux import HPUXHardware

    cpu_facts_b23_ia64 = {'processor': 'Intel(R) Itanium(R) 2 processor 9100 family',
                          'processor_cores': 1, 'processor_count': 1}

    cpu_facts_b23_pa_risc = {'processor_cores': 1, 'processor_count': 1}

    cpu_facts_b31_ia64 = {'processor': 'Intel(R) Itanium(R) 2 processor 9100 family',
                          'processor_cores': 8, 'processor_count': 2}

    cpu_facts_b31_pa_risc = {'processor_count': 4}

    cpu_facts

# Generated at 2022-06-22 23:13:16.607215
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class MockModule:
        """
        Mock class for module import
        """
        def __init__(self):
            self.run_command = Mock(return_value=[0, '', ''])
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            """
            Method to fail json
            """
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

    class MockFacts:
        """
        Mock class for facts class import
        """
        def __init__(self):
            self.dict = dict()

    class MockHardware(HPUXHardware):
        """
        Mock class for class HPUXHardware import
        """
        def __init__(self, module):
            self.module = module

   

# Generated at 2022-06-22 23:13:28.537945
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class MockHPUXHardware(HPUXHardware):
        def __init__(self, module):
            self.module = module
            self.module.run_command = run_command
            self.platform = 'HP-UX'


    class MockModule:
        def __init__(self):
            self.run_command = run_command


    def run_command(cmd, *args, **kwargs):
        if cmd == "ioscan -FkCprocessor | wc -l":
            return (0, "4", "")
        elif cmd == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
            return (0, "Number of CPUs = 2", "")

# Generated at 2022-06-22 23:13:37.924792
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, 'HP-UX B.11.31 U ia64 2881113556', '')
    module.run_command = Mock(return_value=(0, 'HP 9000/785', ''))
    class_attr = {'module': module}

    hpux_hw_facts_object = HPUXHardware()
    hpux_hw_facts_object.__dict__ = class_attr
    facts = hpux_hw_facts_object.get_hw_facts()
    assert facts == {'model': 'HP 9000/785', 'firmware': 'B.11.31 U ia64 2881113556'}



# Generated at 2022-06-22 23:13:44.528621
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_facts = HPUXHardwareCollector()
    assert hw_facts._fact_class == HPUXHardware
    assert hw_facts._platform == 'HP-UX'

    list_required_facts = ['platform', 'distribution']
    assert hw_facts.required_facts == set(list_required_facts)

# Generated at 2022-06-22 23:13:55.490480
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    cpu_facts = hardware.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert cpu_facts['processor_count'] == 8
    cpu_facts = hardware.get_cpu_facts(collected_facts={'ansible_architecture': '9000/785'})
    assert cpu_facts['processor_count'] == 8
    cpu_facts = hardware.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64',
                                                        'ansible_distribution_version': 'B.11.23'})
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == 'Intel Itanium 2'
   

# Generated at 2022-06-22 23:14:00.529453
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw_facts = hw.get_hw_facts()
    assert hw_facts["model"] == "HP-UX"
    assert isinstance(hw_facts["firmware_version"], basestring)
    assert isinstance(hw_facts["product_serial"], basestring)


# Generated at 2022-06-22 23:14:05.259495
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hphw = HPUXHardware(module)
    hphw.populate()
    for key in ['processor_count', 'processor_cores', 'processor_threads_per_core', 'processor_vcpus']:
        assert key in hphw.device

# Generated at 2022-06-22 23:14:17.720300
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module=module)
    collected_facts = dict(ansible_architecture='ia64')
    hw = HPUXHardware(module)
    data = hw.populate(collected_facts=collected_facts)
    assert data['processor'] == 'Intel(R) Itanium(R) Processor 9100 series'
    assert data['processor_cores'] == 16
    assert data['processor_count'] == 16
    assert data['model'] == 'Integrity rx2660'
    assert data['memtotal_mb'] == 8192
    assert data['swaptotal_mb'] == 7680
    collected_facts = dict(ansible_architecture='9000/800')