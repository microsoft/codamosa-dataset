

# Generated at 2022-06-22 23:04:23.163131
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule({'platform': 'HP-UX', 'distribution': 'B.11.31'})
    docs = HPUXHardwareCollector.__doc__
    hpx_hw = HPUXHardwareCollector(module=module, facts={}, warn_on_missing=True)
    # for pclass in hpx_hw._fact_class.__dict__.items():
    #     print(pclass)
    facts = hpx_hw._fact_class.__dict__
    # print(test._fact_class.__dict__['get_memory_facts'].__doc__)
    # Test method with standard output

# Generated at 2022-06-22 23:04:32.458378
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = type('MockModule', (object,), {'run_command': lambda *args, **kwargs: (0, '', '')})
    module.params = {}
    module.exit_json = lambda *args, **kwargs: None
    hw_facts = HPUXHardware(module)
    assert hw_facts.populate() == {'processor_count': 1, 'processor': '2.1 GHZ Intel Itanium 2 9500', 'processor_cores': 1, 'model': 'ia64 HP Integrity rx2660 Server', 'memtotal_mb': 2048, 'memfree_mb': 2040, 'swapfree_mb': 0, 'swaptotal_mb': 0}


# Generated at 2022-06-22 23:04:35.805230
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64'
    }

    result = hw.get_hw_facts(collected_facts=collected_facts)

    assert result.get('model')
    assert result.get('firmware_version')



# Generated at 2022-06-22 23:04:42.750072
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    args = dict(
        ansible_facts=dict(
            ansible_distribution='HP-UX',
            ansible_distribution_version='B.11.31',
            ansible_architecture='ia64'
        )
    )
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    h = HPUXHardware(module=None, params=args)
    result = h.get_hw_facts()
    assert result['model'] == u'ia64 hp server rx4640'
    assert result['product_serial'] == u'ABCDEFGHIJKLMNOP'
    assert result['firmware_version'] == u'B.11.31'


# Generated at 2022-06-22 23:04:44.445750
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict(ansible_architecture='ia64', ansible_distribution_version="B.11.23"))
    hw = HPUXHardware(dict(ansible_architecture='ia64', ansible_distribution_version="B.11.31"))



# Generated at 2022-06-22 23:04:46.230405
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec=dict())
    hwh = HPUXHardware(module)

    assert hwh.platform == 'HP-UX'
    assert isinstance(hwh.populate(), dict)



# Generated at 2022-06-22 23:04:52.467454
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw_hpux = HPUXHardware(None)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    facts = hw_hpux.get_memory_facts(collected_facts)
    if os.access("/dev/kmem", os.R_OK):
        assert facts.get('memtotal_mb') == 0
    else:
        assert facts.get('memtotal_mb') == 2520

# Generated at 2022-06-22 23:04:56.045603
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """ Unit test for constructor of class HPUXHardwareCollector """
    collected_facts = dict()
    collector = HPUXHardwareCollector
    assert collector.collect(collected_facts)



# Generated at 2022-06-22 23:05:06.246942
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw=HPUXHardware({})
    hw.module.run_command=lambda x: (0, "ioscan -FkCprocessor | wc -l", "")
    assert hw.get_cpu_facts() == {'processor_count': 1}
    # Python 2.6
    hw.module.run_command=lambda x: (0, "processor_count = 2", "")
    assert hw.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}) == {'processor_count': 2}
    hw.module.run_command=lambda x: (0, "processor family = Intel Itanium 2 9000 series processor (1.6 GHz, 1600 Mhz FSB, 12 MB L3)", "")

# Generated at 2022-06-22 23:05:17.137942
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module)
    hardware.module.run_command = run_command
    hardware.module.get_bin_path = get_bin_path
    hardware.module.get_file_content = get_file_content
    facts = hardware.populate()
    assert facts['memfree_mb'] == 3053
    assert facts['memtotal_mb'] == 20000
    assert facts['swapfree_mb'] == 1476
    assert facts['swaptotal_mb'] == 16021
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert facts['processor_cores'] == 2
    assert facts['processor_count'] == 2
    assert facts['model'] == 'ia64 hp Integrity rx6600'
    # Only for ia64

# Generated at 2022-06-22 23:05:19.558301
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    h = HPUXHardware({})
    assert h.platform == 'HP-UX'



# Generated at 2022-06-22 23:05:23.511500
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector()
    assert hc.platform == 'HP-UX'
    assert hc.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-22 23:05:25.915826
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_col = HPUXHardwareCollector()
    assert hw_col._platform == 'HP-UX'

# Generated at 2022-06-22 23:05:29.174799
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    assert hardware.platform == "HP-UX"
    assert hardware.get_cpu_facts() == {}
    assert hardware.get_memory_facts()

# Generated at 2022-06-22 23:05:41.563124
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_args = set()
            self.run_command_kwargs = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def run_command(self, *args, **kwargs):
            self.run_command_args.add(args)
            self.run_command_kwargs.append(kwargs)
            rc, out, err = self.run_command_rcs.pop(0), self.run_command_outs.pop(0), self.run_command_errs.pop(0)
            return rc, out, err

    class MockHardwareClass(HPUXHardware):
        def __init__(self):
            self

# Generated at 2022-06-22 23:05:53.485915
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    hpu_hw = HPUXHardware(module)

    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31',
    }

    # test valid PA_RISC
    pa_risc_cpu_facts = hpu_hw.get_cpu_facts(collected_facts)
    assert pa_risc_cpu_facts['processor_count'] == 1

    # test valid PA_RISC with ia64 architecture
    collected_facts['ansible_architecture'] = 'ia64'
    pa_risc_cpu_facts = hpu_hw.get_cpu_facts(collected_facts)
    assert pa_risc_cpu

# Generated at 2022-06-22 23:05:57.292523
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_obj = HPUXHardwareCollector()
    assert hardware_obj.facts['platform'] == 'HP-UX'
    assert hardware_obj.fact_class == HPUXHardware
    assert hardware_obj.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:06:07.290808
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hw_collector = HPUXHardwareCollector(module=module)
    # Check it is instance of HPUXHardwareCollector
    assert isinstance(hw_collector, HPUXHardwareCollector)
    # Check if constructor called base class constructor
    assert isinstance(hw_collector, HardwareCollector)
    # Check if it stores module reference to self.module
    assert hw_collector.module == module
    # Check if it stores platform reference to self._platform
    assert hw_collector._platform == 'HP-UX'
    # Check if it stores fact_class reference to self._fact_class
    assert hw_collector._fact_class == HPUXHardware
    # Check if it stores required_facts reference to self.required_facts
    assert hw_

# Generated at 2022-06-22 23:06:13.547604
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({'platform': 'HP-UX',
                       'distribution': ('HP-UX', 'B.11.31', 'U ia64')})
    assert hw.platform == 'HP-UX'
    assert hw.distribution == ('HP-UX', 'B.11.31', 'U ia64')

# Generated at 2022-06-22 23:06:18.973774
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}

    hw = HPUXHardware(module=None)
    cpu_facts = hw.get_cpu_facts(collected_facts)

    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor'] == 'Intel Itanium 2'
    assert cpu_facts['processor_cores'] == 4


# Generated at 2022-06-22 23:06:28.825802
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['memtotal_mb'] == 2048
    assert hardware_facts['swaptotal_mb'] == 2240
    assert hardware_facts['model'] == "ia64 hp server rx6600"
    assert hardware_facts['processor'] == "Intel(R) Itanium(R) 9300 series processor @ 1.59GHz"
    assert hardware_facts['firmware_version'] == "v4.47"



# Generated at 2022-06-22 23:06:35.812596
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware = HPUXHardwareCollector.fetch_facts(module)['ansible_facts']
    assert hardware['processor_count'] == 2
    assert hardware['processor_cores'] == 2
    assert hardware['processor'] == 'Intel(R) Itanium(R) Processor'



# Generated at 2022-06-22 23:06:45.231440
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class AnsibleModuleMock:
        def run_command(self, command, use_unsafe_shell=False):
            if command == "/usr/bin/vmstat | tail -1":
                return 0, "512000", ""
            elif command == "grep Physical /var/adm/syslog/syslog.log":
                return 0, "Physical: 131072 Kbytes", ""
            elif command == "adb -k /stand/vmunix /dev/kmem":
                return 0, "phys_mem_pages/D: 32712\n", ""
            else:
                return 0, "", ""

    class AnsibleModule(object):
        def __init__(self):
            self.run_command = AnsibleModuleMock().run_command

    hw = HPUXHardwareCollector.fetch_

# Generated at 2022-06-22 23:06:55.907082
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu = HPUXHardware()
    # Test with flag hpux_ia64_model_11i_v3
    cpu.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert cpu.populate()['processor_cores'] == 4
    # Test with flag hpux_ia64_model_11i_v2
    cpu.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert cpu.populate()['processor'] == 'Itanium 2'
    # Test with flag hpux_hp_pa_risc_8xxx

# Generated at 2022-06-22 23:07:09.363492
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={'platform': dict(required=False, default='HP-UX')})
    hardware = HPUXHardware(module=module)
    hardware._distribution = 'HP-UX'
    hardware._architecture = '9000/800'
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    hardware._architecture = 'ia64'
    hardware._distribution_version = 'B.11.23'
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    hardware._distribution_version = 'B.11.31'
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-22 23:07:21.046874
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    hw.module = 123123

# Generated at 2022-06-22 23:07:23.192979
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    TestHPUXHardware = HPUXHardware({})
    TestHPUXHardware.populate()



# Generated at 2022-06-22 23:07:33.711029
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    This function tests for the correct output of method populate of
    class HPUXHardware; this test uses the same fixture data file as
    the test for add_sysctl_facts and check_sysctl_facts from
    module_utils/facts/facts/hardware/linux.py
    """
    h = HPUXHardware(dict(), dict())
    h.module = AnsibleModuleMock()
    h.module.run_command = run_command_mock
    h.populate()
    # assert all known facts to match expected results
    assert h.facts['processor_cores'] == 8
    assert h.facts['processor_count'] == 2
    assert h.facts['firmware_version'] == 'HP-UX 11i v3 vmod'
    assert h.facts['swapfree_mb'] == 0

# Generated at 2022-06-22 23:07:45.470081
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Test get_memory_facts method of HPUXHardware class
    """

    import json
    import tempfile

    facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    # Mocking module and commands execution

# Generated at 2022-06-22 23:07:56.763421
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Create a instance of HPUXHardware
    hardware = HPUXHardware(dict(module=dict()))

    # initialise the module
    module = dict(run_command=lambda args, **kwargs: (0, '', ''))
    hardware.module = module

    # initialise the collected_facts
    collected_facts = dict(
        ansible_architecture='ia64'
    )

    # Mock the run_command function
    def run_command(args, **kwargs):
        out = (
            """
Number of CPUs = 4
    processor family = Intel(r) Itanium(r) processor
    processor type =  9000/800

Memory:
Real:         108924 MB
Kernel:         1565 MB
Virtual:       335739 MB
"""
        )
        return 0, out, ''

   

# Generated at 2022-06-22 23:08:03.223878
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    if not os.access("/dev/kmem", os.R_OK):
        pytest.skip("Test require root access to get memory facts")

    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    facts = hardware.get_memory_facts({'ansible_architecture': '9000/800'})
    assert isinstance(facts.get('memtotal_mb'), int)
    assert facts['memtotal_mb'] > 0


# Generated at 2022-06-22 23:08:15.347726
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test with no /dev/kmem
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '-1', ''))
    collector = HPUXHardwareCollector(module=module)
    print(collector.get_memory_facts())

    # Test with world-readable /dev/kmem and machinfo, swapinfo
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '-1', ''))
    module.run_command.return_value = (0, '12345', '')
    collector = HPUXHardwareCollector(module=module)
    print(collector.get_memory_facts())



# Generated at 2022-06-22 23:08:27.817464
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test if the method get_hw_facts of class HPUXHardware works as expected
    """

    hardware = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert hardware.get_hw_facts() == {'model': 'hp rx4640', 'firmware_version': '7.11', 'product_serial': 'ABCD12345'}

    hardware = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hardware.get_hw_facts() == {'model': 'hp rx4640', 'firmware_version': '1.47'}


# Generated at 2022-06-22 23:08:40.275781
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hw = HPUXHardware(module=module)
    # Test on ia64
    hw.populate(collected_facts=dict(ansible_architecture='ia64'))
    cpu_facts = hw.get_cpu_facts(collected_facts=dict(ansible_architecture='ia64'))
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts
    # Test on parisc
    hw.populate(collected_facts=dict(ansible_architecture='9000/800'))
    cpu_facts = hw.get_cpu_facts(collected_facts=dict(ansible_architecture='9000/800'))

# Generated at 2022-06-22 23:08:42.891090
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict(module=dict()))
    assert hw.platform == 'HP-UX'



# Generated at 2022-06-22 23:08:49.840155
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware(dict())
    module = MagicMock()
    module.run_command.return_value = (0, "Swap configuration: swapfile          dev  swaplo blocks   free\n", "")
    h.module = module
    results = h.get_memory_facts()
    assert results == {'swapfree_mb': 0, 'swaptotal_mb': 0}


# Generated at 2022-06-22 23:08:56.466041
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_facts = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts_data = {'processor_count': 8}
    cpu_facts = hardware_facts.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == cpu_facts_data


# Generated at 2022-06-22 23:09:08.717097
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware(module=module)
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v1.03'
    assert hw_facts['product_serial'] == 'US12345678'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts)


# Generated at 2022-06-22 23:09:19.415450
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}

    # Create instance of class to test
    hp_hw = HPUXHardware()
    hp_hw.module = MockModule()

    # Call method HPUXHardware.get_cpu_facts
    result = hp_hw.get_cpu_facts(collected_facts=facts)
    assert result == {'processor_count': 2,
                      'processor': 'Intel(R) Itanium(R) Processor 9560',
                      'processor_cores': 1}

    # B.11.23
    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    result = hp_hw.get_cpu_facts

# Generated at 2022-06-22 23:09:31.921640
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = {}
    facts['ansible_architecture'] = 'ia64'
    facts['ansible_distribution_version'] = 'B.11.31'

    hwfact = HPUXHardware(module=None, facts=facts)
    hwfact.populate(facts)

    # Test cpu facts
    assert hwfact.memory_facts['memtotal_mb']
    assert hwfact.memory_facts['swaptotal_mb']
    assert hwfact.hw_facts['model']
    assert hwfact.hw_facts['firmware_version']
    assert hwfact.hw_facts['product_serial']
    assert hwfact.cpu_facts['processor_count']
    assert hwfact.cpu_facts['processor_cores']
    assert hwfact.cpu_facts['processor']

# Generated at 2022-06-22 23:09:44.148915
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = dict(platform='HP-UX', ansible_architecture='9000/800', ansible_distribution='HP-UX')
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list')),
        supports_check_mode=False)
    hardware = HPUXHardware(module)
    hardware.collect_device_facts = MagicMock(return_value=collected_facts)
    hardware.populate()
    assert hardware.facts['memfree_mb']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware

# Generated at 2022-06-22 23:09:46.521230
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:09:49.101038
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    myHPUXHardware = HPUXHardware({'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'})
    assert myHPUXHardware.platform == "HP-UX"


# Generated at 2022-06-22 23:09:51.112077
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-22 23:10:03.104291
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = None
    cmd_output = {
        'mem_size': '',
        'mem_free': '',
        'swap_size': '',
        'swap_free': '',
        'cpu_model': '',
        'cpu_socket': '',
        'cpu_cores': '',
        'machinfo': '',
        'ioscan': '',
        'model': '',
        'machinfo2': '',
    }

    # Run function with some cases
    def run_command_mock(self, cmd, use_unsafe_shell=False, check_rc=True):
        rc = 1
        if cmd.startswith('model'):
            out = 'B132L'

# Generated at 2022-06-22 23:10:14.083438
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    # Test for get_cpu_facts for B.11.23 or B.11.31
    hpux_hw = HPUXHardware(module)
    rc, out, err = module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    is_returned_true = False
    if int(out.strip().split('=')[1]) > 0:
        is_returned_true = True
    assert is_returned_true

    # Test for get_memory_facts on HP-UX B.11.31

# Generated at 2022-06-22 23:10:21.243072
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hpux_hardware = HPUXHardware(None, facts)
    cpu_facts = hpux_hardware.get_cpu_facts()
    assert cpu_facts.get('processor_count') == 2
    assert cpu_facts.get('processor') == 'Intel(R) Itanium(R) 9320'



# Generated at 2022-06-22 23:10:31.354916
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # set variables
    module = AnsibleModule(argument_spec={})
    module.params['gather_timeout'] = 5
    module.params['gather_subset'] = []
    module.params['filter'] = '*'
    facts = dict(
        ansible_architecture='ia64',
        ansible_distribution_version='B.11.31',
        ansible_distribution='HP-UX'
    )

    # instantiate the object
    hux = HPUXHardware(module)

    # get facts
    facts = hux.populate(facts)

    # check values
    assert 'processor_count' in facts
    assert 'processor_cores' in facts
    assert 'processor' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
   

# Generated at 2022-06-22 23:10:42.437578
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = dict()
    hw_facts['ansible_architecture'] = 'ia64'
    hw_facts['ansible_distribution_version'] = 'B.11.23'
    mod = AnsibleModule({})
    hphw = HPUXHardware(mod)
    result = hphw.get_hw_facts(collected_facts=hw_facts)
    assert result['model'] == 'ia64 hp server Integrity rx2660'
    assert result['firmware_version'] == 'HPH01.00'
    assert result['product_serial'] == 'KBL16031367'
    hw_facts['ansible_distribution_version'] = 'B.11.31'
    result = hphw.get_hw_facts(collected_facts=hw_facts)
   

# Generated at 2022-06-22 23:10:55.221742
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h = HPUXHardware()
    #ia64 case : B.11.31 release > 1204
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    res = h.get_cpu_facts(collected_facts=collected_facts)
    assert res['processor_count'] == 2
    assert res['processor_cores'] == 24
    assert res['processor'] == 'Intel(R) Xeon(R) CPU X5677  @ 3.47GHz'
    #ia64 case : B.11.31 release <= 1204
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-22 23:10:59.131072
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mock_module = HPUXHardware()
    mock_module.module = MockModule
    # Test with IA64 HP-UX
    mock_module.module.collect_facts = "B.11.31"
    mock_module.module.run_command = Mock(return_value=[0, "Memory         = 16384 MB (16384 MB installed)", ""])
    expected = {'memtotal_mb': 16384}
    result = mock_module.get_memory_facts()
    assert result == expected
    # Test with 9000/800 HP-UX

# Generated at 2022-06-22 23:11:12.737407
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mem = HPUXHardware()
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = "B.11.31"

    def run_command(self, cmd, check_rc=True, close_fds=True, use_unsafe_shell=False):
        results = {'rc': 0, 'err': '', 'out': ''}
        if cmd == '/usr/contrib/bin/machinfo | grep Intel':
            results['out'] = 'Intel(R) Itanium(R)                                processor 9050'
        elif cmd == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
            results['out'] = 'Number of CPUs: 32'

# Generated at 2022-06-22 23:11:18.551101
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    modules = {'sys': {}, 'os': {}, 'config': {}}
    required_facts = ['platform', 'distribution']
    hwc = HPUXHardwareCollector(modules, required_facts)
    assert hwc._fact_class == HPUXHardware
    assert hwc._platform == 'HP-UX'
    assert hwc.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-22 23:11:30.057331
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Creating instance of HPUXHardware
    hardware = HPUXHardware(module='test_module')

    # Setting collected facts
    hardware.module.params.update({
        'ansible_architecture': '9000/785',
        'ansible_distribution_version': 'B.11.23'
    })

    collected_facts = {
        'ansible_architecture': '9000/785',
        'ansible_distribution_version': 'B.11.23'
    }

    # Value of shell command "ioscan -FkCprocessor | wc -l"
    out = """
    1
    """

    # Mocking shell command to test method
    hardware.module.run_command = lambda x, check_rc=True: (0, out, None)
    # Testing method
    cpu_facts

# Generated at 2022-06-22 23:11:40.057776
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_facts = HPUXHardware()

    for version in ['B.11.23', 'B.11.31']:
        collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': version}
        memory_facts = hardware_facts.get_memory_facts(collected_facts=collected_facts)
        assert(memory_facts['memtotal_mb'] > 0)
        assert(memory_facts['memfree_mb'] > 0)
        assert(memory_facts['swaptotal_mb'] > 0)
        assert(memory_facts['swapfree_mb'] > 0)

    collected_facts = {'ansible_architecture': '9000/800'}

# Generated at 2022-06-22 23:11:52.239248
# Unit test for method get_cpu_facts of class HPUXHardware

# Generated at 2022-06-22 23:12:04.406585
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = MagicMock(name='ansible.module_utils.facts.hardware.hpux.HPUXHardware')
    hw = HPUXHardware(test_module)
    test_module.run_command = MagicMock(return_value=(0, "", ""))
    test_module.run_command.assert_called_once()
    # Test get_memory_facts
    test_module.run_command.side_effect = [
        (0, "", ""),
        (0, "", ""),
        (0, "32", ""),
        (0, "", ""),
        (0, "128\n128\n128\n128", "")
    ]
    collected_facts = {'ansible_architecture': '9000/800'}

# Generated at 2022-06-22 23:12:09.903872
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware({})
    memory_facts = h.get_memory_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"})
    assert memory_facts['memfree_mb'] == 527
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['swaptotal_mb'] == 256
    assert memory_facts['swapfree_mb'] == 256



# Generated at 2022-06-22 23:12:14.978480
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({}, {'ansible_architecture': '9000/800'})
    hw = HPUXHardware({}, {'ansible_architecture': 'ia64'})
    hw = HPUXHardware({}, {'ansible_architecture': '9000/785'})

# Generated at 2022-06-22 23:12:22.759066
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Reads the output of the commands issued to calculate the facts.
    """
    data_dir = os.path.dirname(__file__)
    results = []
    class FakeModule(object):
        def run_command(self, command, use_unsafe_shell=False):
            data_file = os.path.join(data_dir, '%s.out' % command.split(' ')[0].replace('/', '-'))
            with open(data_file, 'r') as f:
                return 0, f.read(), ''
    module = FakeModule()
    fact_subclass = HPUXHardware(module)
    result = fact_subclass.populate()
    assert result['processor_count'] == 2

# Generated at 2022-06-22 23:12:35.585800
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    hardware_instance = HPUXHardware()

    # Platform 9000/800
    facts_mock_800 = {'ansible_architecture': '9000/800'}
    hardware_instance._module = module
    cpu_facts_800 = hardware_instance.get_cpu_facts(collected_facts=facts_mock_800)
    assert cpu_facts_800 == {'processor_count': 2}

    # Platform 9000/785
    facts_mock_785 = {'ansible_architecture': '9000/785'}
    hardware_instance._module = module

# Generated at 2022-06-22 23:12:40.807414
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    collected_facts = dict(
        distribution='HP-UX',
        distribution_version='B.11.23',
        architecture='ia64',
    )
    hph = HPUXHardware(module)
    module.exit_json(changed=False, ansible_facts=hph.populate(collected_facts))



# Generated at 2022-06-22 23:12:53.402913
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware1 = HPUXHardware({}, {'ansible_architecture': '9000/800'})
    hardware2 = HPUXHardware({}, {'ansible_architecture': '9000/785'})
    hardware3 = HPUXHardware({}, {'ansible_architecture': 'ia64'})
    hardware4 = HPUXHardware({}, {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    hardware5 = HPUXHardware({}, {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})

    result1 = hardware1.get_cpu_facts()
    assert result1['processor_count'] == 14
    result2 = hardware2.get_cpu_facts

# Generated at 2022-06-22 23:13:02.161885
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpu_hw = HPUXHardware({'platform': 'HP-UX', 'distribution_version': 'B.11.23'})
    assert hpu_hw.ansible_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hpu_hw.ansible_facts['processor_count'] == 1
    assert hpu_hw.ansible_facts['processor_cores'] == 1
    assert hpu_hw.ansible_facts['memtotal_mb'] == 10112
    # On B.11.23 swap_total is not available
    assert 'swaptotal_mb' not in hpu_hw.ansible_facts
    assert hpu_hw.ansible_facts['firmware_version'] == 'B.11.23'
    assert hpu_hw.ansible_facts['model']

# Generated at 2022-06-22 23:13:14.362456
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """Test get_hw_facts method of HPUXHardware class"""

    # Set test data
    drive_data = {
        '/dev/dsk/c0t0d0': {
            'rotational': '1',
            'size': '2048000',
            'vendor': 'WD'
        }
    }

    sysctl_data = {}

    # Initialize module with empty data
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']

    # Initialize Hardware class instance
    hwobj = HPUXHardware(module)
    hwobj._devices = Devices(module)
    hwobj._devices.get_all_block_devices = mock.MagicMock(return_value=drive_data)
    hwobj._

# Generated at 2022-06-22 23:13:21.535994
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    hardware = HPUXHardware(module)

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    result = hardware.get_memory_facts(collected_facts)

    assert result['memfree_mb'] == 16
    assert result['memtotal_mb'] == 8192
    assert result['swaptotal_mb'] == 511
    assert result['swapfree_mb'] == 0

    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    result = hardware.get_memory_facts(collected_facts)


# Generated at 2022-06-22 23:13:22.672225
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HPUXHardware().get_hw_facts()

# Generated at 2022-06-22 23:13:26.910119
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    hardware.get_memory_facts()
    assert module.exit_args == (1, 'memtotal_mb and swaptotal_mb are required at this time')

# Fake AnsibleModule

# Generated at 2022-06-22 23:13:33.708396
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw.fact_class == HPUXHardware
    assert hw.fact_subclasses == {}
    assert hw._collector == \
        ['HPUXHardwareCollector', 'GenericHardwareCollector', 'HardwareCollector']

# Generated at 2022-06-22 23:13:37.553904
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'
    assert hardware.distribution is None
    assert hardware.distribution_version is None
    assert not hardware.facts


# Generated at 2022-06-22 23:13:49.828327
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({'platform': 'HP-UX'})
    facts_dict = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hardware.module = MockModule()
    hardware.module.run_command = Mock(return_value=(0, '', ''))

# Generated at 2022-06-22 23:13:53.568991
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({'module': {'run_command': run_command}})
    hw_facts = hw.get_hw_facts({'ansible_distribution_version': "B.11.31",
                                'ansible_architecture': 'ia64'})
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'HPD9'
    assert hw_facts['product_serial'] == 'US123456789'



# Generated at 2022-06-22 23:14:00.755876
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts = {'ansible_distribution_version': 'B.11.23', 'ansible_architecture': 'ia64'}
    hardware = HPUXHardware(ansible_module=None, collected_facts=facts)
    hw_facts = hardware.get_hw_facts()
    hw_facts_expected = {'model': 'ia64', 'firmware_version': '09/01/2016', 'product_serial': '123456'}
    assert hw_facts == hw_facts_expected

# Generated at 2022-06-22 23:14:06.559737
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (object,), {})()
    setattr(module, 'run_command', lambda *args: (0, '', ''))
    module.run_command = type('', (object,), {'run_command': run_command})()
    hardware = HPUXHardware(module)
    hardware.get_memory_facts()



# Generated at 2022-06-22 23:14:18.956364
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Creating a dummy module
    module = AnsibleModule(argument_spec={})

    # Creating an instance of class HPUXHardware
    hw = HPUXHardware(module=module)

    # Creating a dummy collected_facts
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

    # Creating a module utils class
    class linux_module:
        def run_command(self, command, use_unsafe_shell=True):
            if command.startswith('model'):
                return 0, 'HP-UX B.11.31 ia64  0761716076', ''
            elif command.endswith('| wc -l'):
                return 0, '1', ''