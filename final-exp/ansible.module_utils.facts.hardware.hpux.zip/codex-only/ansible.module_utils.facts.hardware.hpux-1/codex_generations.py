

# Generated at 2022-06-22 23:04:12.702308
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()

    data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    result = hw.get_cpu_facts(collected_facts=data)
    assert result['processor_cores'] == 12
    assert result['processor_count'] == 6
    assert result['processor'] == 'Intel(R) Itanium(R) Processor 9350'


# Generated at 2022-06-22 23:04:25.325234
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Test method populate of class HPUXHardware
    :return:
    """
    from ansible.module_utils.facts import FactCollector

    fact_collector = FactCollector()

    hw_hpux = HPUXHardware()

    # Test with parameters collected_facts={'ansible_architecture':'ia64'}
    # If we have ia64 architecture
    collected_facts = {'ansible_architecture':'ia64'}
    assert hw_hpux.populate(collected_facts)['processor_count'] == 12

    # Test with parameters collected_facts={'ansible_architecture':'9000/800'}
    collected_facts = {'ansible_architecture':'9000/800'}

# Generated at 2022-06-22 23:04:30.260464
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    gathered_facts = {'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'}
    module = AnsibleModule(argument_spec={})
    module.exit_json(ansible_facts=dict(ansible_hardware=HPUXHardware().get_hw_facts(collected_facts=gathered_facts)))



# Generated at 2022-06-22 23:04:36.672605
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"})
    facts = hw.populate()
    assert facts['ansible_architecture'] == 'ia64'
    assert facts['ansible_distribution_version'] == 'B.11.31'
    assert facts['processor_count'] == facts['processor_cores']

# Generated at 2022-06-22 23:04:49.631423
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class MockModule:
        def __init__(self):
            self.params = {
                'gather_subset': 'all'
            }

        def run_command(self, cmd):
            return 0, cmd, ''

    m = MockModule()
    h = HPUXHardware(module=m)
    result = h.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert result['processor_count'] == 1, "Failed to set 'processor_count'"

    result = h.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})

# Generated at 2022-06-22 23:04:55.823383
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_col = HPUXHardwareCollector()
    assert isinstance(hw_col, HardwareCollector), 'hw_col is not an object of HardwareCollector'
    assert hw_col.platform == 'HP-UX', 'Platform is not HP-UX'
    assert hw_col._fact_class.platform == 'HP-UX', '_fact_class platform is not HP-UX'

# Generated at 2022-06-22 23:05:05.468703
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=True)

    hw = HPUXHardware(module)

    if module.check_mode:
        module.exit_json(changed=False)

    hw_facts = hw.populate()
    for i in ['processor', 'processor_cores', 'processor_count', 'model', 'firmware']:
        assert isinstance(hw_facts[i], str)
    for i in ['memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb']:
        assert isinstance(hw_facts[i], int)

# Generated at 2022-06-22 23:05:16.760223
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = None
    hw = HPUXHardware(module)
    # Pa-risc
    collected_facts = {'ansible_architecture': '9000/785'}
    assert hw.get_cpu_facts(collected_facts=collected_facts) == {'processor_count': 1}
    # Itanium
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    assert hw.get_cpu_facts(collected_facts=collected_facts) == {'processor_count': 2, 'processor': 'Intel Itanium 2 processor', 'processor_cores': 2}

# Generated at 2022-06-22 23:05:28.929493
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h = HPUXHardware()
    h.module = MagicMock()

    h.module.run_command.return_value = (0, '', '')

    collected_facts = {
        "ansible_architecture": "9000/800",
        "ansible_distribution_version": "B.11.23",
        "ansible_kernel": "HP-UX"
    }

    h.populate(collected_facts)

    k = h.populate(collected_facts)

    assert k['processor_count'] == 2
    assert k['processor_cores'] == 2
    assert k['processor'] == "Itanium processor"
    assert k['memfree_mb'] == 37
    assert k['memtotal_mb'] == 256
    assert k['swaptotal_mb'] == 511

# Generated at 2022-06-22 23:05:41.336969
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module=module, facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    hardware = hardware_collector.collect()[0]
    hardware_facts = hardware.populate()

    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['processor'] == 'Intel Itanium 2 9100 series'
    assert hardware_facts['memfree_mb'] == 636
    assert hardware_facts['memtotal_mb'] == 1536
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_

# Generated at 2022-06-22 23:05:44.294942
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector()
    # Test required_facts
    assert hwc.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-22 23:05:55.292978
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    with open('hpuxtest.log', 'r') as infile:
        output = infile.read().split('\n')
    with open('hpuxtest2.log', 'r') as infile:
        output2 = infile.read().split('\n')
    facts = { 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23' }
    hw = HPUXHardware({'module_run_command_output': [ output, output2 ]}, facts)
    assert hw.get_memory_facts() == {'memfree_mb': 496, 'swapfree_mb': 8, 'swaptotal_mb': 10, 'memtotal_mb': 3060}

# Generated at 2022-06-22 23:05:57.884215
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_facts = HPUXHardware()
    assert type(hpux_facts) == HPUXHardware


# Generated at 2022-06-22 23:06:07.503089
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = type('module1', (object,), {
        'run_command': lambda x, y: (0, '2', ''),
        'get_bin_path': lambda x: '/bin/true',
        '_ansible_version': '2.3.0',
        'params': {},
        'fail_json': lambda x: None,
        'warn': lambda x: None
    })()
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    m = HPUXHardware()
    m.module = module
    m.populate(collected_facts=collected_facts)

# Generated at 2022-06-22 23:06:10.967211
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware.get_hw_facts(dict(platform='HP-UX'))
    assert hw_facts.get('model')


# Generated at 2022-06-22 23:06:19.754325
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hf = HPUXHardware()
    # Unit test for PA-RISC platform
    hf.module = object()
    hf.module.run_command = lambda x, use_unsafe_shell: (0, '123456', '')
    hf.module.run_command.__name__ = 'run_command'
    hf.populate({'ansible_architecture': '9000/785'})
    assert hf.memtotal_mb == 683904
    assert hf.memfree_mb == 4672
    assert hf.swapfree_mb == 128
    assert hf.swaptotal_mb == 128
    # Unit test for Itanium platform HPUX 11.23
    hf.module = object()

# Generated at 2022-06-22 23:06:26.584132
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('module', (object,), {'run_command': get_run_command_data})

    hardware = HPUXHardware(module)
    facts = hardware.get_memory_facts()

    assert facts['memtotal_mb'] == 64
    assert facts['memfree_mb'] == 32
    assert facts['swaptotal_mb'] == 50
    assert facts['swapfree_mb'] == 48



# Generated at 2022-06-22 23:06:28.024482
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {}
    HPUXHardwareCollector(facts)

# Generated at 2022-06-22 23:06:33.579903
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    '''
    Test HPUXHardware class get_memory_facts method
    '''
    hpux_hardware = HPUXHardware({})
    assert hpux_hardware.get_memory_facts() == {}


# Generated at 2022-06-22 23:06:43.265568
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    # run with ia64 and B.11.31
    data = dict(ansible_architecture='ia64', ansible_distribution_version="B.11.31")
    rc, out, err = 0, 'Hyperthreading: ON\nLogical CPUs: 14\Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz\n', ''
    rc2, out2, err2 = 0, '1 socket', ''
    rc3, out3, err3 = 0, '14 cores', ''
    rc4, out4, err4 = 0, 'Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz', ''
    dicts = dict(ansible_architecture='ia64', ansible_distribution_version="B.11.23")
    m

# Generated at 2022-06-22 23:06:53.918068
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.31"
    }
    result = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert result.get('processor_count') == 24
    assert result.get('processor_cores') == 8
    assert result.get('processor') == 'Intel(R) Itanium(R) Processor 9340 2.40GHz'

    collected_facts = {
        "ansible_architecture": "9000/785"
    }
    result = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert result.get('processor_count') == 1



# Generated at 2022-06-22 23:06:56.726686
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
        collector = HPUXHardwareCollector()
        assert collector.fact_class is HPUXHardware
        assert collector.platform == 'HP-UX'
        assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:07:10.587600
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    if not module.check_mode:
        hw = HPUXHardware(module, {'platform': 'HP-UX', 'distribution': 'HP-UX', 'ansible_architecture': '9000/800'})
        facts = hw.populate()
        assert facts['processor_count'] == 2
        assert facts['processor'] == 'PA-RISC 2.0'
        assert facts['processor_cores'] == 2
        assert facts['memfree_mb'] > 0
        assert facts['memtotal_mb'] > 0
        assert facts['swaptotal_mb'] > 0
        assert facts['swapfree_mb'] > 0
        assert facts['model']
        assert facts['firmware_version']

# Generated at 2022-06-22 23:07:22.348383
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all', '!min'])
        )
    )

    FakeClass = collections.namedtuple('FakeClass', ['value', 'out', 'err'])
    FakeFacts = collections.namedtuple('FakeFacts', ['ansible_architecture', 'ansible_distribution_version'])
    FakeSWAP = collections.namedtuple('FakeSWAP', ['return_code', 'out', 'err'])
    FakePhysical = collections.namedtuple('FakePhysical', ['return_code', 'out', 'err'])
    FakeKmem = collections.namedtuple('FakeKmem', ['return_code', 'out', 'err'])

    # PARAMETERS TEST
    # 1

# Generated at 2022-06-22 23:07:33.003408
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_hw = HPUXHardware()
    collected_facts = {'platform': 'HP-UX',
                       'distribution': 'B.11.31',
                       'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    hpux_hw.populate(collected_facts)
    assert hpux_hw.memory['memtotal_mb'] == 4294967296 / 1024 / 1024
    assert hpux_hw.memory['memfree_mb'] == 1
    assert hpux_hw.memory['swaptotal_mb'] == 4294967296 / 1024 / 1024
    assert hpux_hw.memory['swapfree_mb'] == 1
    assert hpux_hw.cpu['processor_count'] == 8

# Generated at 2022-06-22 23:07:38.739149
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware()
    hw.module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        )
    )
    hw.populate()
    assert hw.data['processor_count'] == 1
    assert hw.data['processor_cores'] == 2

# Generated at 2022-06-22 23:07:43.424723
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    m_module = type('MockModule', (object,), {})()
    m_module.run_command = type('MockRunCommand', (object,), {})()
    hw_facts = HPUXHardware(m_module)
    assert hw_facts.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:45.930115
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()

    assert h.fact_class == HPUXHardware
    assert h.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:50.968689
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    facts = dict()
    facts['ansible_architecture'] = '9000/800'
    module = AnsibleModule(argument_spec=dict())
    hpux_hw = HPUXHardware(module)
    result = hpux_hw.populate(facts)
    assert result is not None


# Generated at 2022-06-22 23:07:56.592972
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)

    hpx_hw = HPUXHardware(module)
    hw = hpx_hw.get_hw_facts()

    assert hw.get('model')
    assert hw.get('firmware_version')
    assert hw.get('product_serial')


# Generated at 2022-06-22 23:08:03.141160
# Unit test for constructor of class HPUXHardware

# Generated at 2022-06-22 23:08:15.702305
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Unit test to check memory facts for given values
    # VMware Virtual Platform
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': '',
        'gather_timeout': 0,
        'filter': '*'
    }
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    hpux_hw = HPUXHardware(module)
    memory_facts = hpux_hw.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 3071
    assert memory_facts['memtotal_mb'] == 20000
    assert memory_facts['swaptotal_mb'] == 2951
    assert memory_facts['swapfree_mb'] == 2951

    # Logical

# Generated at 2022-06-22 23:08:28.202021
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    m = HPUXHardwareCollector()
    # Test populate
    h = m.populate()
    assert h.__class__.__name__ == 'HPUXHardware', 'test_HPUXHardware_populate: populate() does not return HPUXHardware'
    assert isinstance(h.firmware_date, datetime), 'test_HPUXHardware_populate: firmware_date is not a datetime object'
    assert h.manufacturer == 'Hewlett-Packard Company'
    assert h.product_serial == 'UA995415RS'
    assert h.processor == 'Intel(R) Itanium(R) Processor 9300 series'
    assert h.processor_count == 2, 'test_HPUXHardware_populate: processor_count is not 2'

# Generated at 2022-06-22 23:08:31.549091
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    # Create instance of class HPUXHardware
    t_Hardware = HPUXHardware(dict())

    # Check instance created successfully
    assert t_Hardware.platform == 'HP-UX'


# Generated at 2022-06-22 23:08:35.026785
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert x.required_facts == set(['platform', 'distribution'])
    assert x._platform == 'HP-UX'
    assert x._fact_class == HPUXHardware

# Generated at 2022-06-22 23:08:38.647863
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({'platform': 'HP-UX', 'distribution_version': 'B.11.31'})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-22 23:08:41.049012
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector._fact_class == HPUXHardware

# Generated at 2022-06-22 23:08:53.454322
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware(None)

    # Set S/W & H/W facts
    hardware.module.params['gather_subset'] = '!all'
    hardware.module.params['gather_timeout'] = 1
    hardware.module.params['gather_device_timeout'] = 1
    hardware.module.params['filter'] = 'Hardware'

    # Set values for the facts

# Generated at 2022-06-22 23:08:56.041743
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardwareCollector = HPUXHardwareCollector()
    assert hardwareCollector._platform == 'HP-UX'

# Generated at 2022-06-22 23:09:00.056894
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"})
    assert hardware_obj.platform == 'HP-UX'

# Generated at 2022-06-22 23:09:11.104252
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpux_hw = HPUXHardware({},{'ansible_architecture': '9000/800'})
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hpux_hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor_cores': 2, 'processor_count': 2}
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hpux_hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor_cores': 1, 'processor_count': 1, 'processor': 'Intel(R) Itanium(R) Processor 9000 Family'}

# Generated at 2022-06-22 23:09:21.896860
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module_mock = AnsibleModuleMock()
    hardware = HPUXHardware(module_mock)
    facts = hardware.populate()
    assert isinstance(facts, dict)
    assert isinstance(facts['memtotal_mb'], int)
    assert isinstance(facts['memfree_mb'], int)
    assert isinstance(facts['swaptotal_mb'], int)
    assert isinstance(facts['swapfree_mb'], int)
    assert isinstance(facts['processor'], str)
    assert isinstance(facts['processor_cores'], int)
    assert isinstance(facts['processor_count'], int)
    assert isinstance(facts['model'], str)
    assert isinstance(facts['firmware'], str)



# Generated at 2022-06-22 23:09:30.217910
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()

    facts = dict(
        ansible_architecture='9000/800',
    )

    gathered_facts = hardware.get_memory_facts(collected_facts=facts)

    assert gathered_facts['memtotal_mb'] == 2048
    assert gathered_facts['memfree_mb'] == 1506
    assert gathered_facts['swaptotal_mb'] == 3868
    assert gathered_facts['swapfree_mb'] == 3868

# Generated at 2022-06-22 23:09:36.080861
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_factory = HPUXHardwareCollector(dict(), dict())
    assert isinstance(hw_factory, HPUXHardwareCollector)
    assert hw_factory.platform == 'HP-UX'
    assert hw_factory.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-22 23:09:38.424591
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector()
    assert hc is not None


# Generated at 2022-06-22 23:09:47.328530
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_hw = HPUXHardware(dict(module=dict(params=dict(gather_subset="all"))))
    facts = hpux_hw.populate()
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 2
    assert facts['processor'] == "Intel Xeon L7455 @ 1800 MHz"
    assert facts['memfree_mb'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['model'] == "ia64 hp server rx1600"
    assert facts['firmware_version'] == "B.11.31"
    assert facts['product_serial'] == 'ABCD1234ZYY'

# Generated at 2022-06-22 23:10:00.246113
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hpux_hw = HPUXHardware()
    rc, out, err = hpux_hw.module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    data = int(re.sub(' +', ' ', out).split(' ')[5].strip())
    memfree = data * 4096 // 1024 // 1024
    rc, out, err = hpux_hw.module.run_command("/usr/contrib/bin/machinfo | grep Memory", use_unsafe_shell=True)
    data = re.search(r'Memory[\ :=]*([0-9]*).*MB.*', out).groups()[0].strip()
    memtotal = int(data)

# Generated at 2022-06-22 23:10:03.599255
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector.platform == 'HP-UX'
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])
    assert HPUXHardwareCollector._fact_class == HPUXHardware

# Generated at 2022-06-22 23:10:14.135140
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector

    test_collector = ansible_collector.get_collector('HPUXHardwareCollector', HPUXHardware)

    # Test with machine: 9000/800

# Generated at 2022-06-22 23:10:18.163419
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})

    hw = HPUXHardware(module)
    assert hw.platform == 'HP-UX'
    assert hw.cpu_facts is None
    assert hw.memory_facts is None
    assert hw.hw_facts is None

# Generated at 2022-06-22 23:10:29.207366
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    HPUXHardware_get_cpu_facts = HPUXHardware(dict())
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': '11.23'
    }
    expected_result = {
        "processor_count": 2
    }
    result = HPUXHardware_get_cpu_facts.get_cpu_facts(collected_facts=collected_facts)
    assert result == expected_result

    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    expected_result = {
        "processor_count": 2,
        "processor": "Intel Itanium 2",
        "processor_cores": 8
    }

# Generated at 2022-06-22 23:10:40.908247
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class Options():
        def __init__(self, **entries):
            self.__dict__.update(entries)

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, "2.6.32-3-amd64", ""))
    module.get_bin_path = MagicMock(return_value="/usr/bin/python")
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware(module=module, collected_facts=collected_facts)
    all_cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert all_cpu

# Generated at 2022-06-22 23:10:49.781587
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_facts = {
        'distribution': 'HP-UX',
        'architecture': 'ia64',
        'distribution_release': 'B.11.23'
    }
    hware = HPUXHardware(dict(), test_facts)
    hw_facts = hware.get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx6600'
    assert hw_facts['firmware_version'] == 'HPD8'
    assert hw_facts['product_serial'] == 'USL9110032G'

# Generated at 2022-06-22 23:10:58.099371
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    test_module.run_command = MagicMock(return_value=(0, "", ""))
    hpux_hardware = HPUXHardware(test_module)
    collected_facts = {'ansible_architecture': 'ia64'}
    hpux_hardware.get_memory_facts(collected_facts)
    hpux_hardware.get_memory_facts()



# Generated at 2022-06-22 23:11:11.320356
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    hw.collector = HPUXHardwareCollector()
    # ia64 with B.11.23 and B.11.31
    hw.collector.facts['ansible_architecture'] = 'ia64'
    hw.collector.facts['ansible_distribution_version'] = 'B.11.31'
    rc, out, err = hw.module.run_command("/usr/contrib/bin/machinfo | grep socket", use_unsafe_shell=True)
    assert out
    rc, out, err = hw.module.run_command("/usr/sbin/psrset | grep LCPU", use_unsafe_shell=True)
    assert out

# Generated at 2022-06-22 23:11:21.637971
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hphw_obj = HPUXHardware(module)
    rc, out, err = module.run_command("/usr/contrib/bin/machinfo | grep Intel", use_unsafe_shell=True)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    expected_cpu_facts = {'processor': out.strip(), 'processor_cores': 4, 'processor_count': 1}
    cpu_facts = hphw_obj.get_cpu_facts(collected_facts)
    assert expected_cpu_facts == cpu_facts

# Generated at 2022-06-22 23:11:32.376262
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23'
    }

    expected_facts = {
        'processor_count': 4,
        'processor': 'Intel(R) Itanium(R) Processor',
        'processor_cores': 4
    }

    cpu_facts = hardware.get_cpu_facts(collected_facts)

    assert cpu_facts == expected_facts, "actual: %s, expected: %s" % (cpu_facts, expected_facts)
    module.exit_json(**cpu_facts)



# Generated at 2022-06-22 23:11:34.540681
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)
    hardware.get_memory_facts()

# Generated at 2022-06-22 23:11:38.151843
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Test that the constructor of the class works
    """
    hhc = HPUXHardwareCollector()
    assert 'HP-UX' == hhc._platform
    assert HPUXHardware == hhc._fact_class

# Generated at 2022-06-22 23:11:50.661204
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    class HPUXHardware(object):
        module = None
        def __init__(self):
            self.data = {}
        def get_cpu_facts(self):
            return {'processor': 'IA64',
                    'processor_cores': 4,
                    'processor_count': 1}
        def get_memory_facts(self):
            return {'memfree_mb': 1280,
                    'memtotal_mb': 4096,
                    'swapfree_mb': 0,
                    'swaptotal_mb': 0}
        def get_hw_facts(self):
            return {'model': 'HP Integrity rx2660',
                    'firmware_version': 'v3.0',
                    'product_serial': 'US1018475P'}


# Generated at 2022-06-22 23:11:56.390676
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    cpu_facts = hw.get_cpu_facts()

    # Make sure count and cores are set
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts

    # Make sure count > cores
    assert cpu_facts['processor_count'] >= cpu_facts['processor_cores']



# Generated at 2022-06-22 23:11:58.853605
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hp_ux_facts = HPUXHardware({})
    assert hp_ux_facts.platform == 'HP-UX'



# Generated at 2022-06-22 23:12:09.257423
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    HPUXHardwareCollector.platform = "HP-UX"
    HPUXHardwareCollector.distribution = "B.11.31"
    HPUXHardwareCollector.ansible_architecture = "ia64"
    HPUXHardwareCollector.ansible_machine = "ia64"
    HPUXHardwareCollector.ansible_system = "HP-UX"
    HPUXHardwareCollector.ansible_lsb = {"major_release": "B.11.31", "minor_release": "1131"}
    HPUXHardwareCollector.ansible_machine = "ia64"

    hw = HPUXHardware()
    data = hw.get_memory_facts()
    assert data['memtotal_mb'] == 32768

# Generated at 2022-06-22 23:12:16.038864
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    hw.module = type('', (), {'run_command': create_fixture_get_memory_facts})
    facts = hw.get_memory_facts()
    assert facts['memfree_mb'] == 1369
    assert facts['memtotal_mb'] == 7430
    assert facts['swaptotal_mb'] == 6553
    assert facts['swapfree_mb'] == 6500



# Generated at 2022-06-22 23:12:21.104539
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collections = ['hardware']
    required_facts = set(['platform', 'distribution'])

    hpux_hw = HPUXHardwareCollector(collections, required_facts)

    assert hpux_hw._fact_class == HPUXHardware
    assert hpux_hw._platform == 'HP-UX'
    assert hpux_hw.required_facts == {'platform', 'distribution'}



# Generated at 2022-06-22 23:12:33.409234
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    def run_command(module, *cmds):
        output = ''
        command = cmds[0]
        if command == "ioscan -FkCprocessor | wc -l":
            output = '2'
        elif command == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
            output = 'Number of CPUs = 2'
        elif command == "/usr/contrib/bin/machinfo | grep 'processor family'":
            output = 'processor family = Intel(r) Itanium(r) processor'
        elif command == "/usr/contrib/bin/machinfo | grep core | wc -l":
            output = '0'

# Generated at 2022-06-22 23:12:43.235167
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.hardware.hpux import HPUXHardware

    hpux_hardware = HPUXHardware({})

    with patch.object(hpux_hardware.module, 'run_command', return_value=(0, '9000/785', '')):
        hpux_hardware.get_hw_facts()
        hpux_hardware.module.run_command.assert_called_with('model')

    with patch.object(hpux_hardware.module, 'run_command', return_value=(0, 'hppa', '')):
        hpux_hardware.get_hw_facts()
        hp

# Generated at 2022-06-22 23:12:49.542536
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    result = HPUXHardwareCollector(module)
    assert result.platform == 'HP-UX'
    assert result._fact_class == HPUXHardware
    assert result._platform == 'HP-UX'
    assert result.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:13:00.341050
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    def mock_run_command(self, cmd, check_rc=True):
        if cmd == "ioscan -FkCprocessor | wc -l":
            return 0, '2', None
        elif cmd == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
            return 0, "Number of CPUs = 8\n", None
        elif cmd == "/usr/contrib/bin/machinfo | grep 'processor family'":
            return 0, "Intel(R) Xeon(R) CPU E7-8880 v4 @ 2.20GHz\n", None
        elif cmd == "/usr/contrib/bin/machinfo | egrep 'core|logical'":
            return 0, "Number of cores = 48\nNumber of logical CPUs = 96\n", None

# Generated at 2022-06-22 23:13:02.505707
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hardware.get_hw_facts()

# Generated at 2022-06-22 23:13:14.529410
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware(dict(module=None), dict(platform='HP-UX', ansible_architecture='ia64'))
    cpu_facts = hardware_facts.get_cpu_facts()
    memory_facts = hardware_facts.get_memory_facts()
    hw_facts = hardware_facts.get_hw_facts()
    facts = hardware_facts.populate()
    assert facts == cpu_facts
    assert facts == memory_facts
    assert facts == hw_facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts

# Generated at 2022-06-22 23:13:21.629158
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = dict(ansible_architecture='9000/800')
    module = dict()
    module['run_command'] = lambda *args, **kwargs: None
    module['run_command'].return_value = None
    module['run_command'].return_value = [0, '', '']
    module['run_command'].return_value = [0, '  Physical:   131072 Kbytes\n', '']
    module['run_command'].return_value = None
    module['run_command'].return_value = [0, '', '']
    module['run_command'].return_value = [0, ' dev:  total:   used:    free: req:   swap:   swap:  ', '']

# Generated at 2022-06-22 23:13:25.576960
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module)
    assert hardware_collector.get_required_facts() == {'distribution', 'platform'}


# Generated at 2022-06-22 23:13:26.656070
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:13:37.657628
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """ Test HPUXHardware.get_hw_facts method """

    # Test Case 1:
    module = FakeAnsibleModule(ansible_architecture='ia64')
    MockFile.read_data['/usr/contrib/bin/machinfo'] = """
        Architecture:        ia64
        Host ID:             XXXXXXXXXXXXXXXX
        Processor:           Intel(R) Itanium(R) Processor 9300 Series (1.73 GHz, 96 MB)
        Memory:              4 GB
        Firmware revision:   version=B.11.23.07.00
        Firmware variations: revision=B.03
        Firmware build:      date=01/23/2014
        Machine serial number: XXXXXXXXXXXXXXXX
        Console login:       enabled
        Physical:	    28672K bytes.
    """
    hw = H

# Generated at 2022-06-22 23:13:45.166246
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    fake_module = type('FakeModule', (object,), {'run_command': run_command})()

    def run_command(self, *cmd, **kwargs):
        return 0, '', ''

    # Create an instance of HPUXHardware to call populate method
    hardware = HPUXHardware(fake_module)
    hardware.populate({'ansible_architecture': '9000/800'})

# Generated at 2022-06-22 23:13:57.022010
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # Test with empty facts
    collected_facts = {}
    hw = HPUXHardware(module=None)
    hw.populate(collected_facts)

    assert hw.facts.get('processor_cores') == 0
    assert hw.facts.get('swaptotal_mb') == 0
    assert hw.facts.get('processor_count') == 0
    assert hw.facts.get('model') == ''
    assert hw.facts.get('memtotal_mb') == 0
    assert hw.facts.get('swapfree_mb') == 0
    assert hw.facts.get('processor') == ''
    assert hw.facts.get('memfree_mb') == 0

    # Test with populated facts

# Generated at 2022-06-22 23:14:04.780397
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    data = {
        'ansible_architecture': '9000/800',
    }
    h = HPUXHardware({}, data)
    r = h.get_memory_facts()
    assert r['memfree_mb'] == 16000
    assert r['memtotal_mb'] == 16000
    r = h.get_memory_facts({'ansible_architecture': 'ia64'})
    assert r['memfree_mb'] == 16000
    assert r['memtotal_mb'] == 16000



# Generated at 2022-06-22 23:14:06.125441
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:14:08.502008
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector(None)
    assert collector.fact_class == HPUXHardware