

# Generated at 2022-06-22 23:04:16.823630
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    data1 = """ 
  kthr      memory            page              faults      cpu
 r b w   swap  free  re  mf pi po fr de sr m0 m1 m2 --   in   sy   cs us sy id wa
  1 1 0 172360 27908 16  27  0  0  0  0  0  0  0 --  100  185  662  4  1  6  9
    """
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command=MagicMock(return_value=(0, data1, None))
    hardware_facts = hardware.get_memory_facts()
    assert hardware_facts['memfree_mb'] == 70
    assert hardware_facts['memtotal_mb'] == 0
    assert hardware_facts['swaptotal_mb']

# Generated at 2022-06-22 23:04:28.393705
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()

    # Test method with empty collected_facts
    collected_facts = {}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0

    # Test method with collected_facts for PA-RISC system
    collected_facts = {
        'ansible_architecture': '9000/800',
    }
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0

    # Test method with collected_facts for Itanium system

# Generated at 2022-06-22 23:04:38.855811
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class Object(object):
        pass

    class AnsibleModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd.startswith('/usr/bin/vmstat'):
                return 0, '0 59600 15552', ''
            if cmd.startswith('grep Physical'):
                return 0, 'Apr 10 20:00:00 hostname vmunix: Physical: 704328 Kbytes', ''
            if cmd.startswith('echo '):
                return 0, '28244', ''
            if cmd.startswith('/usr/sbin/swapinfo'):
                return 0, '1', ''

# Generated at 2022-06-22 23:04:43.609588
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    data = HPUXHardware(dict(ansible_facts=dict(platform='HP-UX'))).get_hw_facts()
    assert 'model' in data
    assert 'firmware_version' in data


# Generated at 2022-06-22 23:04:49.833232
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hostname = 'test'
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    set_module_args(dict(gather_subset=['all']))

    my_hardware = HPUXHardware(module=module, collected_facts={'ansible_architecture': 'ia64',
                                                               'ansible_distribution_version': 'B.11.31'})
    memory_facts_b11 = my_hardware.get_memory_facts()

    my_hardware = HPUXHardware(module=module, collected_facts={'ansible_architecture': 'ia64',
                                                               'ansible_distribution_version': 'B.11.23'})
    memory_facts_b10 = my_hardware.get_memory_facts()

# Generated at 2022-06-22 23:05:02.004746
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector_instance = HPUXHardwareCollector(module)
    hw_instance = collector_instance.collect()
    hw_facts = hw_instance.populate()
    assert hw_facts.get('processor_count')
    assert hw_facts.get('processor_cores')
    assert hw_facts.get('processor')
    assert hw_facts.get('memfree_mb')
    assert hw_facts.get('memtotal_mb')
    assert hw_facts.get('swapfree_mb')
    assert hw_facts.get('swaptotal_mb')
    assert hw_facts.get('model')
    assert hw_facts.get('firmware_version')


# Generated at 2022-06-22 23:05:09.327413
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Fact gathering is tested using an AnsibleModule object
    """
    from ansible.module_utils.facts import ModuleFacts

    module = ModuleFacts(
        argument_spec={},
        supports_check_mode=True
    )
    # Set up test input
    collected_facts = {
        'ansible_facts': {
            'ansible_architecture': 'ia64',
            'ansible_distribution_version': 'B.11.23'
        }
    }
    # Define parts of the out and err strings
    out = "Memory Size = 12288 MB"
    data = "12288"
    # Define fake AnsibleModule object and populate it with test input
    module.params = {'module_name': 'ansible.module_utils.facts.hardware.hpux'}
   

# Generated at 2022-06-22 23:05:15.317102
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    # test with empty params
    hw_facts = HPUXHardware()
    assert hw_facts.platform == 'HP-UX'

    # test with params
    hw_facts = HPUXHardware({'example': 'example'})
    assert hw_facts.platform == 'HP-UX'
    assert hw_facts.custom_facts['example'] == 'example'


# Generated at 2022-06-22 23:05:27.519732
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('', (), {'run_command': _run_command})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Test with fact ansible_architecture = 9000/800
    hw = HPUXHardware(module)
    output = hw.get_cpu_facts({'ansible_architecture': '9000/800'})
    assert output['processor_count'] == 3

    # Test with fact ansible_architecture = 9000/785
    hw = HPUXHardware(module)
    output = hw.get_cpu_facts({'ansible_architecture': '9000/785'})
    assert output['processor_count'] == 3

    # Test with fact ansible_architecture = ia64
    hw = HPUXHardware

# Generated at 2022-06-22 23:05:39.468224
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware()
    hw.module = FakeModule()
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution_version': 'B.11.23'}
    facts = hw.populate(collected_facts)
    assert facts['processor_count'] == 2
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor T800'
    assert facts['processor_cores'] == 2
    assert facts['memtotal_mb'] == 4096
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 256
    assert facts['swapfree_mb'] == 45
    assert facts['model'] == 'ia64 hp 9000/800'



# Generated at 2022-06-22 23:05:44.688467
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    config = {
        'module_setup': True,
        'module_utils': 'ansible.module_utils.facts.hardware.hpux',
        'gather_subset': 'all',
        'gather_timeout': 5,
        'filter': '*'
    }
    hardware = HPUXHardware(config)

    assert hardware is not None
    assert hardware.config is not None
    assert hardware.cache is not None

# Generated at 2022-06-22 23:05:48.810006
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MockModule()
    hardware = HPUXHardware(module)
    hardware.get_hw_facts()
    assert hardware.facts['model'] == "ia64 hp server rx4640"


# Generated at 2022-06-22 23:05:58.193508
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = None
    collected_facts = {'ansible_architecture': "9000/800"}
    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_count'] == 1
    collected_facts = {'ansible_architecture': "ia64"}
    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_cores'] in [1, 2, 4]
    assert cpu_facts['processor_count'] == 1

# Generated at 2022-06-22 23:06:07.562241
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    pagesize = 4096
    facts = {'ansible_architecture':'9000/800'}
    module = AnsibleModule(argument_spec={})
    module.params = {}
    klass = HPUXHardware(module=module)
    klass.populate()
    rc, out, err = module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    data = int(re.sub(' +', ' ', out).split(' ')[5].strip())
    memory_facts = klass.get_memory_facts(facts)
    assert memory_facts['memfree_mb'] == pagesize * data // 1024 // 1024
    assert memory_facts['swaptotal_mb'] == 3091
    assert memory_facts['swapfree_mb'] == 3091

# Generated at 2022-06-22 23:06:18.594278
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module_mock = MagicMock()
    d = HPUXHardware(module_mock)
    data = {'ansible_architecture': '9000/785', 'ansible_distribution': 'HP-UX'}
    d.module.run_command.return_value = (0, '1', '')
    assert_equals(d.populate(data), {'processor_count': 1, 'processor': '', 'processor_cores': 1, 'memfree_mb': 0, 'memtotal_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'model': '', 'firmware': ''})

# Generated at 2022-06-22 23:06:23.399811
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({
        "system_vendor": "HP",
        "distribution": "HP-UX",
        "distribution_version": "B.11.31",
        "ansible_architecture": "ia64"
        })
    assert hardware

# Generated at 2022-06-22 23:06:25.779223
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_test = HPUXHardware(dict())
    assert hardware_test.platform == 'HP-UX'



# Generated at 2022-06-22 23:06:29.584570
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    mod = HPUXHardware({})
    assert isinstance(mod, HPUXHardware)


# Generated at 2022-06-22 23:06:34.697553
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hpuxtest = HPUXHardware(module)

    assert hpuxtest.populate().get('processor_count') == 32

# Generated at 2022-06-22 23:06:36.405853
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
   h = HPUXHardware()
   assert h.platform == "HP-UX"

# Generated at 2022-06-22 23:06:45.040742
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpuxtest = HPUXHardware()
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    data = hpuxtest.get_cpu_facts(collected_facts)
    assert data['processor_count'] == 2
    assert data['processor'] == 'Intel(R) Itanium(R) processor 9734'
    assert data['processor_cores'] == 8
    collected_facts['ansible_architecture'] = '9000/800'
    data = hpuxtest.get_cpu_facts(collected_facts)
    assert data['processor_count'] == 16



# Generated at 2022-06-22 23:06:55.658355
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    data = {'ansible_architecture': '9000/800',
            'ansible_distribution': 'HP-UX'}
    module = AnsibleModule(argument_spec={})
    h = HPUXHardware(module=module, collected_facts=data)
    # Control that the method get_cpu_facts returns a dictionary with processor_count key
    assert 'processor_count' in h.get_cpu_facts()
    data = {'ansible_architecture': 'ia64',
            'ansible_distribution': 'HP-UX',
            'ansible_distribution_version': 'B.11.31'}
    h = HPUXHardware(module=module, collected_facts=data)
    # Control that the method get_cpu_facts returns a dictionary with processor key
    assert 'processor' in h.get

# Generated at 2022-06-22 23:07:02.696755
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.run_command = run_command
    facts_obj = HPUXHardwareCollector()
    cpufacts = facts_obj._assemble_facts(None)
    assert 'processor_count' in cpufacts



# Generated at 2022-06-22 23:07:05.260392
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})

    hw = HPUXHardware(module)

    assert hw.module == module

# Generated at 2022-06-22 23:07:10.455558
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    facts = {}
    hardware = HPUXHardware(module)

    memory_facts = hardware.get_memory_facts(facts)
    assert memory_facts == {'memfree_mb': 328, 'memtotal_mb': 1027, 'swapfree_mb': 819, 'swaptotal_mb': 1027}



# Generated at 2022-06-22 23:07:12.194228
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw is not None

# Generated at 2022-06-22 23:07:23.298781
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Test method populate of class HPUXHardware.

    """

    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))

    cpu_facts = {'processor': "Intel(R) Itanium(R) Processor 9550",
                 'processor_cores': 2,
                 'processor_count': 2}
    memory_facts = {'memfree_mb': 1024,
                    'memtotal_mb': 4096,
                    'swapfree_mb': 2048,
                    'swaptotal_mb': 8192}
    hw_facts = {'model': "ia64 hp server rx8640", 'firmware_version': "v3.3.1"}


# Generated at 2022-06-22 23:07:31.081997
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.side_effect = [(0, '2', ''), (0, '', ''), (0, '', '')]
    hpux_hw = HPUXHardware()
    hpux_hw.module = module
    hpux_hw.populate()
    assert hpux_hw.facts == {'processor_count': 2, 'processor_cores': 4}



# Generated at 2022-06-22 23:07:35.970134
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({'platform': 'Linux', 'distribution': 'Fedora'}, {})
    hw.module = mock.Mock()
    hw.module.run_command.return_value = 0, 'HP-UX', None
    hw.get_hw_facts()
    assert hw.model == 'HP-UX'



# Generated at 2022-06-22 23:07:46.485670
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hw.get_memory_facts()['swaptotal_mb'] > 0, "Failing on get_memory_facts method"
    assert hw.get_memory_facts()['swapfree_mb'] > 0, "Failing on get_memory_facts method"
    assert hw.get_memory_facts()['memtotal_mb'] > 0, "Failing on get_memory_facts method"
    assert hw.get_memory_facts()['memfree_mb'] > 0, "Failing on get_memory_facts method"

# Generated at 2022-06-22 23:07:57.605345
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpu = HPUXHardware()
    data = hpu.get_hw_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert data == {'firmware_version': u'I26 v2.29', 'model': u'Integrity rx2660'}

    data = hpu.get_hw_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert data == {'firmware_version': u'v2.62', 'model': u'Integrity rx2660'}

# Generated at 2022-06-22 23:08:09.896959
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware({'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'})
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'}
    result = {'processor_count': 2, 'memfree_mb': 1086, 'memtotal_mb': 5154, 'swaptotal_mb': 2687, 'swapfree_mb': 2068, 'processor': 'PA-RISC 2.0', 'processor_cores': 1, 'model': '9000/800', 'firmware_version': 'B.11.31', 'product_serial': 'CZ8824MMS2'}
    assert result == hw.populate(facts)

# Generated at 2022-06-22 23:08:20.433202
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "HP Virtual Connect for c-Class BladeSystem", "")
    module.run_command.return_value = (0, "Serial Number : SN1234567890", "")
    hw = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': 'ia64'}

    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert len(hw_facts.keys()) == 2
    assert hw_facts['model'] == "HP Virtual Connect for c-Class BladeSystem"
    assert hw_facts['firmware_version'] == "SN1234567890"


# Test for method get_cpu_facts of class HPUXHardware


# Generated at 2022-06-22 23:08:21.505103
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:08:33.212596
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}

    # syslog.log has a line containing Physical memory
    rc, out, err = module.run_command("grep Physical /var/adm/syslog/syslog.log")
    data = re.search('.*Physical: ([0-9]*) Kbytes.*', out).groups()[0].strip()
    if err:
        module.fail_json(msg=err, rc=rc)

    result = hw.get_memory_facts(collected_facts)
    assert(result['memtotal_mb'] == int(data) // 1024)

    # The syslog.log file contains no lines containing Physical memory
    rc, out, err

# Generated at 2022-06-22 23:08:46.018213
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({})
    population_method = HPUXHardware.populate
    # Test 9k/800
    set_module_args(dict(ansible_facts=dict(
        ansible_architecture='9000/800',
    )))
    hardware = HPUXHardware(module)
    facts = hardware.populate()
    assert facts['processor_count'] == 2
    # Test 9k/785
    set_module_args(dict(ansible_facts=dict(
        ansible_architecture='9000/785',
    )))
    hardware = HPUXHardware(module)
    facts = hardware.populate()
    assert facts['processor_count'] == 1, 'returned facts: %s' % facts
    # Test ia64

# Generated at 2022-06-22 23:08:53.333299
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/usr/bin')
    HPUXHardware.get_cpu_facts = Mock(return_value={'one': '1'})
    HPUXHardware.get_memory_facts = Mock(return_value={'two': '2'})
    HPUXHardware.get_hw_facts = Mock(return_value={'three': '3'})

    hardware = HPUXHardware(module)
    hardware.populate()

    assert HPUXHardware.get_cpu_facts.call_count == 1
    assert HPUXHardware.get_memory_facts.call_count == 1
    assert HPUXHardware.get_hw_facts.call_count == 1

# Generated at 2022-06-22 23:09:06.543949
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    test = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}

    with open('tests/unit/module_utils/ansible_collections/ansible/community/plugins/module_utils/facts/hardware/hpux/test_HPUXHardware_get_memory_facts.txt', 'r') as f:
        out = to_text(f.read())
        err = ''

        hardware_facts = test.get_memory_facts(collected_facts)
        assert hardware_facts['memfree_mb'] == 1005
        assert hardware_facts['memtotal_mb'] == 32128

# Generated at 2022-06-22 23:09:15.430070
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    fake_module = type('FakeModule', (), {'run_command': lambda *args, **kwargs: (0, 'Fake model', '')})()
    hw = HPUXHardware(fake_module)
    assert hw.get_hw_facts() == {'model': 'Fake model'}

    fake_module = type('FakeModule', (), {'run_command': lambda *args, **kwargs: (0, 'Firmware revision : F.23.34.56', '')})()
    hw = HPUXHardware(fake_module)
    assert hw.get_hw_facts() == {'firmware_version': 'F.23.34.56'}

# Generated at 2022-06-22 23:09:21.053657
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware({}, {})

    hw_facts = hw.get_memory_facts({'ansible_architecture': '9000/800'})

    assert hw_facts['memtotal_mb'] > hw_facts['memfree_mb'] > hw_facts['swaptotal_mb'] > hw_facts['swapfree_mb']

# Generated at 2022-06-22 23:09:32.808121
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = [0, '', '']
    result = hardware.get_cpu_facts({'ansible_architecture': '9000/800'})
    assert result['processor_count'] == 1
    result = hardware.get_cpu_facts({'ansible_architecture': 'ia64'})
    assert result['processor_count'] == 1
    assert result['processor'] == 'Intel(R) Itanium(R) Processor Family'
    assert result['processor_cores'] == 1
    result = hardware.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert result['processor_count'] == 1


# Generated at 2022-06-22 23:09:44.312495
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hppux_hardware = HPUXHardware(dict(module=None, collected_facts=dict(platform='HP-UX', ansible_architecture='9000/800')))
    out = hppux_hardware.populate()
    assert out.get('processor_count') == 1
    assert out.get('processor') is None
    assert out.get('processor_cores') is None
    assert out.get('memfree_mb') > 0
    assert out.get('memtotal_mb') > 0
    assert out.get('swapfree_mb') > 0
    assert out.get('swaptotal_mb') > 0
    assert out.get('model') is not None
    assert out.get('firmware') is None



# Generated at 2022-06-22 23:09:49.360982
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.required_facts == set(['platform', 'distribution'])
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector._fact_class == HPUXHardware


# Generated at 2022-06-22 23:10:01.967271
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Test with a set of facts.
    """
    facts = dict(
        ansible_architecture='ia64',
        ansible_distribution_major_version='11',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31.LZ'
    )
    m = HPUXHardware(dict(), facts)
    m.populate()
    assert m.facts['swaptotal_mb'] == 3353
    assert m.facts['swapfree_mb'] == 3353
    assert m.facts['memfree_mb'] == 968
    assert m.facts['memtotal_mb'] == 16384
    assert m.facts['processor_cores'] == 8
    assert m.facts['processor_count'] == 16

# Generated at 2022-06-22 23:10:04.781800
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    h = HPUXHardware(module)
    assert h.__class__.__name__ == 'HPUXHardware'

# Generated at 2022-06-22 23:10:11.221982
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    facts = {'ansible_architecture': 'ia64'}
    hardware = HPUXHardware(module)
    hardware.populate(facts)
    keys = ('memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb', 'processor',
            'processor_cores', 'processor_count', 'model', 'firmware')
    assert all(key in hardware.facts for key in keys)

# Generated at 2022-06-22 23:10:18.745646
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec=dict())
    hphw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    facts = hphw.get_hw_facts(collected_facts=collected_facts)
    assert facts['firmware_version'] == "HP-UX"
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    facts = hphw.get_hw_facts(collected_facts=collected_facts)
    assert facts['firmware_version'] == "HPUX"


# Generated at 2022-06-22 23:10:21.139135
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    hardware_facts = HPUXHardware()

    assert hardware_facts.platform == 'HP-UX'



# Generated at 2022-06-22 23:10:26.614445
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hw_facts = HPUXHardwareCollector()
    assert hpux_hw_facts.__dict__['_fact_class'] == HPUXHardware
    assert hpux_hw_facts.__dict__['_platform'] == 'HP-UX'
    assert hpux_hw_facts.__dict__['required_facts'] == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:10:37.374922
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware({'ansible_facts': {'ansible_architecture': '9000/800'}})
    hw.get_memory_facts()
    assert hw.facts['memfree_mb'] == 120
    assert hw.facts['memtotal_mb'] == 1010
    assert hw.facts['swaptotal_mb'] == 101
    assert hw.facts['swapfree_mb'] == 10
    assert hw.facts['memfree'] == 1234567
    assert hw.facts['memtotal'] == 1010101
    assert hw.facts['swaptotal'] == 1010101
    assert hw.facts['swapfree'] == 1010



# Generated at 2022-06-22 23:10:44.932891
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # Test with missing params
    hpu = HPUXHardware({})
    assert hpu.platform == 'HP-UX'

    # Test with all params
    hpu = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"})
    assert hpu.platform == 'HP-UX'

    # Test with missing params
    hpu = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"})
    assert hpu.platform == 'HP-UX'



# Generated at 2022-06-22 23:10:57.606899
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module_obj = AnsibleModule(argument_spec=dict(),
                               supports_check_mode=True)
    h = HPUXHardware(module=module_obj)
    test_cases = [
        (dict(ansible_architecture='9000/800',
              collected_facts=dict(ansible_architecture='9000/800')),
         dict(processor_count=4)),
        (dict(ansible_architecture='ia64',
              ansible_distribution_version='B.11.23',
              collected_facts=dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')),
         dict(processor_count=2,
              processor_cores=2,
              processor='Intel(R) Itanium(R) Processor'))
    ]


# Generated at 2022-06-22 23:11:02.950295
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    fhw = HPUXHardwareCollector()
    assert fhw.platform == 'HP-UX'
    assert fhw.required_facts == set(['platform', 'distribution'])
    assert fhw._fact_class == HPUXHardware



# Generated at 2022-06-22 23:11:04.862470
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-22 23:11:14.300778
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    hardware = HPUXHardware(module)
    hardware.populate({'ansible_architecture': '9000/800'})
    assert len(hardware.facts) == 5
    assert hardware.facts['processor_cores'] == 12
    assert hardware.facts['processor_count'] == 12
    assert hardware.facts['memtotal_mb'] == 262144
    assert hardware.facts['memfree_mb'] == 221086
    assert hardware.facts['swaptotal_mb'] == 18561
    assert hardware.facts['swapfree_mb'] == 18551



# Generated at 2022-06-22 23:11:16.453686
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    mod = AnsibleModule(argument_spec={})
    har = HPUXHardware(mod)
    assert har.populate() == {}

# Generated at 2022-06-22 23:11:28.547950
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    hw = HPUXHardware(module=module)

    result_for_ia64 = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    hw_facts_for_ia64 = hw.get_hw_facts(collected_facts=result_for_ia64)

    result_for_pa_risc = {'ansible_architecture': '9000/800'}
    hw_facts_for_pa_risc = hw.get_hw_facts(collected_facts=result_for_pa_risc)


# Generated at 2022-06-22 23:11:35.229152
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    input = {'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'}
    output = {'model': 'ia64 hp server rx2620', 'firmware_version': '1.40', 'product_serial': 'CZHXXXX0B6'}
    hw = HPUXHardware(input)
    assert hw.get_hw_facts() == output



# Generated at 2022-06-22 23:11:38.404307
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector()
    assert hardware._platform == "HP-UX"
    assert hardware._fact_class == HPUXHardware
    assert hardware.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:11:51.068995
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Module needs to be mocked in order to avoid actual call to run_command
    # When used in conjunction with pytest patch function
    module = os.path.basename(__file__)
    if module == "test_hpuxtohardware.py":
        module = "ansible.module_utils.facts.hardware.hpuxtohardware"
    elif module == "__init__.py" or module == "hpuxtohardware.py":
        module = "ansible.module_utils.facts.hardware.hpuxtohardware"
    elif module == "hpux":
        module = "ansible.module_utils.facts.hardware.hpux.hpuxtohardware"

# Generated at 2022-06-22 23:11:58.028745
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    assert HPUXHardware({}).get_cpu_facts({'ansible_architecture': '9000/800'}) == {'processor_count': 7}
    assert HPUXHardware({}).get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}) == \
           {'processor_count': 7,
            'processor_cores': 7,
            'processor': 'Intel Itanium 2'}

# Generated at 2022-06-22 23:12:09.312515
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('MockModule', (object,), {})
    module.run_command = type('MockRunCommand', (object,), {})()
    module.run_command.return_value = (0, "ia64", "")
    module.check_mode = False
    module.no_log = False
    module.exit_json = type('MockExitJson', (object,), {})()
    module.fail_json = type('MockFailJson', (object,), {})()

    hp = HPUXHardware(module=module)
    hp._get_distribution_version = lambda: "B.11.23"
    hw_facts = hp.get_hw_facts()


# Generated at 2022-06-22 23:12:19.900828
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict())

    module.params['gather_subset'] = '!all,!min'

    hw = HPUXHardware()
    hw.module = module

    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31',
        ansible_os_family='HP-UX',
        ansible_system='HP-UX',
    )

    hw_facts = hw.populate(collected_facts=collected_facts)


# Generated at 2022-06-22 23:12:25.646372
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    fake_out = 'Virtual Machine'
    module.run_command = Mock()
    setattr(module.run_command, 'return_value', (0, fake_out, ''))
    hw_facts = HPUXHardware(module).get_hw_facts()
    assert 'model' in hw_facts

# Generated at 2022-06-22 23:12:31.378698
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_facts = HPUXHardwareCollector(None, '', [''], ['']).collect()
    assert hw_facts.__class__.__name__ == 'dict'
    assert hw_facts['firmware_version']
    assert hw_facts['model']
    assert hw_facts['product_serial']

# Generated at 2022-06-22 23:12:32.528834
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:12:42.874937
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module_mock = Mock(return_value='/usr/bin/vmstat | tail -1\n')
    out = Mock(return_value='123 123 123 123 123', split=' ')
    re_mock = Mock(return_value=out)
    with patch.object(HPUXHardware, 'module') as module:
        with patch.object(HPUXHardware, 'run_command') as run_command:
            with patch('re.sub') as re_sub:
                module.run_command = module_mock
                re_sub.return_value = out
                re.sub('.*', ' ', out)
                memory_facts = HPUXHardware().get_memory_facts()

# Generated at 2022-06-22 23:12:46.575874
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts_collector = HPUXHardware(module)
    facts = facts_collector.populate()
    assert facts['firmware_version'] != ''

# Generated at 2022-06-22 23:12:58.601923
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({'architecture': '9000/800'})
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock(return_value=(0, '', ''))

    cpu_facts = hardware.get_cpu_facts()
    hardware.module.run_command.assert_called_with("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)
    assert cpu_facts['processor_count'] == 0

    hardware.module.run_command = MagicMock(return_value=(0, '2', ''))
    hardware.get_cpu_facts()
    assert hardware.module.run_command.call_count == 2
    assert hardware.get_cpu_facts()['processor_count'] == 2


# Generated at 2022-06-22 23:13:06.242988
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Create a test instance
    hyper = HPUXHardware(dict())

    # Minimal collected_facts
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31',
                       'ansible_system': 'hpux',
                       'ansible_distribution': 'HP-UX',
                       'ansible_machine': 'ia64'}
    # Test method populate
    hardware_facts = hyper.populate(collected_facts=collected_facts)

    # Asserts
    assert 'model' in hardware_facts
    assert 'firmware_version' in hardware_facts
    assert 'product_serial' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'memtotal_mb' in hardware_facts

# Generated at 2022-06-22 23:13:14.063293
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_collector = HPUXHardwareCollector()
    test_hw = hardware_collector.collect({'platform': 'HP-UX', 'distribution': 'B.11.31'}, None)
    assert isinstance(test_hw, HPUXHardware)
    cpu_facts = test_hw.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor' in cpu_facts


# Generated at 2022-06-22 23:13:19.176877
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware({})
    hw_facts = hw.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert 'processor_count' in hw_facts.keys()
    assert 'processor_cores' in hw_facts.keys()
    assert 'processor' in hw_facts.keys()



# Generated at 2022-06-22 23:13:28.124534
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={},
    )
    hardware_obj = HPUXHardware(module=module)
    cpu_facts = hardware_obj.get_cpu_facts(
        collected_facts={'ansible_architecture': '9000/800'})
    assert cpu_facts['processor_count'] == 1

    cpu_facts = hardware_obj.get_cpu_facts(
        collected_facts={'ansible_architecture': 'ia64'})
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-22 23:13:37.267479
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module=module)

    # Test HP-UX on PA-RISC
    assert hw.get_cpu_facts({'ansible_architecture': '9000/800'}) == {'processor_count': 2}

    # Test HP-UX on Itanium
    assert hw.get_cpu_facts({'ansible_architecture': 'ia64'}) == {'processor': 'Intel(R) Itanium(R) Processor Family 9340',
                                                                  'processor_count': 2,
                                                                  'processor_cores': 32}



# Generated at 2022-06-22 23:13:46.035502
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module_args = dict(
        gather_subset='all',
        filter='*'
    )
    pc = HPUXHardware(module_args)
    pc_facts = pc.populate()
    assert pc_facts['processor_count'] == 1
    assert pc_facts['memtotal_mb'] == 8192
    assert pc_facts['memfree_mb'] == 7843
    assert pc_facts['swaptotal_mb'] == 4
    assert pc_facts['swapfree_mb'] == 4

# Generated at 2022-06-22 23:13:51.236863
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    my_obj = HPUXHardware(module)
    assert my_obj.platform == 'HP-UX'
    assert my_obj.required_facts == set(['platform', 'distribution'])
    assert my_obj.ignore_list == []
    assert my_obj.additional_list == []
# This is required to be able to run tests with PyTest.

# Generated at 2022-06-22 23:13:57.862316
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware(dict(), list(), list(), {}).get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'v2.31 (20-jan-2014)'
    assert hw_facts['product_serial'] == 'USO122C5XN'


# Generated at 2022-06-22 23:14:09.804135
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    fake_collected_facts = {'ansible_architecture': '9000/800',
                            'ansible_distribution': 'HP-UX',
                            'ansible_distribution_version': 'B.11.31'}

    h = HPUXHardware()
    h.module = mock_module('/usr/sbin/psrset')
    h.module.run_command = mock_command(h.module)
    h.module.run_command.return_value = (0, '1', '')

    rc = h.module.run_command.call_count
    expected_rc = 1
    assert rc == expected_rc, "HP-UXHardware.get_cpu_facts should have run a command %s times, it ran %s times" % (expected_rc, rc)
    run_command_args