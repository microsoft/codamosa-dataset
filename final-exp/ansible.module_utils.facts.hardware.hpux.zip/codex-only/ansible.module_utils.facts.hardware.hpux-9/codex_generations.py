

# Generated at 2022-06-22 23:04:21.144898
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()

    # First case: IA64
    # Second case: IA64 on release B.11.23
    # Third case:  IA64 on release B.11.31
    # Forth case:  IA64 on release B.11.31 with hyperthreading ON
    # Fifth case:  IA64 on release B.11.31 with hyperthreading OFF
    # Sixth case:  IA64 on release B.11.31 with machinfo known bug
    # Seventh case: 9000/800, 9000/785
    collected_facts = dict(ansible_architecture='ia64',
                           ansible_distribution='HP-UX',
                           ansible_distribution_major_version='B.11',
                           ansible_distribution_version='B.11.31')

# Generated at 2022-06-22 23:04:24.038269
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hardware_facts = HPUXHardware(module)
    hardware_facts.populate()
    assert module.fail_json.called


# Generated at 2022-06-22 23:04:32.429348
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})

    hw = HPUXHardware(module)

    assert hw.populate()['processor'] == 'IA64'
    assert hw.populate()['processor_cores'] == 8
    assert hw.populate()['processor_count'] == 1
    assert hw.populate()['model'] == 'HP 9000/785'
    assert hw.populate()['firmware_version'] == 'B.11.11'



# Generated at 2022-06-22 23:04:34.577963
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw_hpux = HPUXHardware({})
    assert hw_hpux.platform == 'HP-UX'

# Generated at 2022-06-22 23:04:40.161313
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    memory_facts = hardware.get_memory_facts()

    assert memory_facts.get('memfree_mb')
    assert memory_facts.get('memtotal_mb')
    assert memory_facts.get('swaptotal_mb')
    assert memory_facts.get('swapfree_mb')


# Generated at 2022-06-22 23:04:52.284896
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = type('test_module', (object,), {'run_command': lambda self, k, use_unsafe_shell: (0, '', '')})
    test_class = HPUXHardware({'module': test_module})
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}
    result = test_class.get_hw_facts(collected_facts=collected_facts)
    assert result['model'] == ' '
    assert result['firmware_version'] == ' '
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"}

# Generated at 2022-06-22 23:05:03.834285
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    h = HPUXHardware(module)
    # model
    ret = h.get_hw_facts()
    assert ret['model'] == 'IA64 hp server rx2660'
    ret = h.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert ret['model'] == 'IA64 hp server rx2660'
    # firmware_version
    ret = h.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert ret.get('firmware_version') == 'v2.00 (c) Copyright 2005 Hewlett-Packard Development Company, L.P.'
    ret

# Generated at 2022-06-22 23:05:10.102026
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts_dict = {'platform': 'HP-UX', 'distribution': 'B.11.23'}
    result = HPUXHardwareCollector(facts_dict)

    assert result.facts == facts_dict
    assert result.required_facts == set(['platform', 'distribution'])
    assert result.platform == 'HP-UX'
    assert result.fact_class == HPUXHardware
    assert result._platform == 'HP-UX'
    assert result.fact_subclass == 'HP-UX'


# Generated at 2022-06-22 23:05:19.362382
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['memfree_mb'] > 0
    assert hardware.facts['memtotal_mb'] > 0
    assert hardware.facts['swapfree_mb'] > 0
    assert hardware.facts['swaptotal_mb'] > 0
    assert hardware.facts['processor'] is not None or hardware.facts['processor_cores'] is None
    assert hardware.facts['processor_cores'] > 0
    assert hardware.facts['processor_count'] > 0
    assert hardware.facts['model'] is not None or hardware.facts['firmware_version'] is None
    assert hardware.facts['firmware_version'] is not None or hardware.facts['firmware_version'] is None

# Generated at 2022-06-22 23:05:27.611481
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_params = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX'
    }
    hpux_hw_collector = HPUXHardwareCollector(required_params)
    assert hpux_hw_collector.platform == 'HP-UX'
    assert hpux_hw_collector.required_facts == set(['platform', 'distribution'])
    assert hpux_hw_collector._fact_class == HPUXHardware
# Unit test end


# Generated at 2022-06-22 23:05:39.995024
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    HardwareCollector.collectors['HP-UX'] = HPUXHardwareCollector
    collected_facts = {}

    collected_facts['ansible_distribution'] = 'HP-UX'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    collected_facts['ansible_architecture'] = 'ia64'

    ha = HPUXHardware()

    # Test is HP-UX platform
    assert ha.get_platform() == 'HP-UX'

    # Test mandatory facts
    assert ha.get_mandatory_facts() == {'platform': 'HP-UX'}

    # Test optional facts
    assert ha.get_optional_facts() == set([
        'distribution',
        'distribution_version',
        'architecture'
    ])

    # Test populate memory facts
   

# Generated at 2022-06-22 23:05:45.667745
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw_facts = HPUXHardware
    result = hw_facts.get_memory_facts()
    assert result['memtotal_mb'] == 456
    assert result['memfree_mb'] == 123
    assert result['swaptotal_mb'] == 998
    assert result['swapfree_mb'] == 321


# Generated at 2022-06-22 23:05:56.647231
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    @Test: Create a HP-UX hardware object with mocked facts and verify
    hardware facts are collected correctly
    @Feature: HPUX Hardware
    @Assert: Hardware facts are collected
    """
    set_module_args({})
    my_obj = HPUXHardwareCollector()
    my_obj.exit_json = exit_json
    my_obj.get_platform = get_platform_mock
    my_obj.get_distribution = get_distribution_mock
    with mock.patch('ansible.module_utils.facts.hardware.hpux.HPUXHardware.get_hw_facts',
                    autospec=True) as get_hw_facts_mock:
        my_obj.populate()
        get_hw_facts_mock.assert_called_once()



# Generated at 2022-06-22 23:06:06.941811
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class TestModule:
        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    hardware = HPUXHardware(TestModule())
    collected_facts = dict(ansible_architecture='9000/785')
    facts = hardware.get_memory_facts(collected_facts)
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert facts['memfree_mb'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] >= facts['swapfree_mb']

# Generated at 2022-06-22 23:06:14.258068
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = HPUXHardware()
    assert facts.platform == 'HP-UX'
    assert facts.populate() == {
        'processor': '', 'swaptotal_mb': 0, 'processor_count': 0, 'processor_cores': 0,
        'memtotal_mb': 0, 'memfree_mb': 0, 'swapfree_mb': 0, 'model': ''
    }


# Generated at 2022-06-22 23:06:24.734823
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_facts = HPUXHardware()
    collected_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX',
        'ansible_architecture': '9000/800',
    }
    result = hpux_facts.populate(collected_facts=collected_facts)
    assert result['processor'] == 'PA-RISC 2.0 (with FPU)'
    assert result['processor_cores'] == 1
    assert result['processor_count'] == 1
    assert result['memfree_mb'] == 8940
    assert result['memtotal_mb'] == 16384
    assert result['swaptotal_mb'] == 10240
    assert result['swapfree_mb'] == 10240
    assert result['model'] == '9000/800'

# Generated at 2022-06-22 23:06:34.476862
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'}
    hardware_obj = HPUXHardware(facts)

    assert hardware_obj.platform == 'HP-UX'
    assert hardware_obj.get_cpu_facts(facts) == {'processor': None, 'processor_cores': 12, 'processor_count': 16}
    assert hardware_obj.get_hw_facts(facts) == {'model': '9000/800', 'firmware_version': None, 'product_serial': None}
    assert hardware_obj.get_memory_facts(facts) == {'memfree_mb': 602, 'memtotal_mb': 32768, 'swaptotal_mb': 1024, 'swapfree_mb': 0}
    assert hardware_obj.populate

# Generated at 2022-06-22 23:06:38.566008
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate(collected_facts={'ansible_architecture': '9000/800',
                                        'ansible_distribution': 'HP-UX'})



# Generated at 2022-06-22 23:06:41.177572
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:06:45.736811
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(required=False, type='list')
        ),
        supports_check_mode=False,
    )

    mem_facts = HPUXHardware().get_memory_facts()

    module.exit_json(changed=False, ansible_facts={'hardware_mem': mem_facts})



# Generated at 2022-06-22 23:06:55.160314
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor_count'] == int(4)  # Number of logical CPU
    assert hardware_facts['processor_cores'] == int(4)  # Number of physical CPU
    assert hardware_facts['memtotal_mb'] == int(8192)
    assert hardware_facts['memfree_mb'] == int(8213)
    assert hardware_facts['swapfree_mb'] == int(0)
    assert hardware_facts['swaptotal_mb'] == int(0)


# Utility function to generate test_mock_data

# Generated at 2022-06-22 23:06:56.824618
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'


# Generated at 2022-06-22 23:07:07.503027
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Create an instance of HPUXHardware class
    hpu = HPUXHardware()

    # Construct a facts dictionary for unit test
    test_facts = {
                   'ansible_architecture': 'ia64',
                   'ansible_distribution_version': 'B.11.23'
                 }

    # Call method get_cpu_facts of class HPUXHardware
    cpu_facts = hpu.get_cpu_facts(test_facts)

    # Check first key value of result and compare it with expected result
    assert cpu_facts['processor_count'] == 12

# Generated at 2022-06-22 23:07:19.304129
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module_mock = Mock()
    module_mock.run_command.return_value = (0, '', '')
    hardware = HPUXHardware(module_mock)
    assert hardware.get_cpu_facts() == {
        'processor_count': None,
        'processor': None,
        'processor_cores': None,
    }


if __name__ == "__main__":
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )

    result = HPUXHardwareCollector(module).fetch_all()
    module.exit_json(ansible_facts=result)

# Generated at 2022-06-22 23:07:30.641691
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['hardware'], type='list')})
    collected_facts = dict()
    collected_facts['ansible_architecture'] = "ia64"
    collected_facts['ansible_distribution_version'] = "B.11.23"
    obj = HPUXHardware(module=module, collected_facts=collected_facts)
    rc, out, err = module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    data = int(re.sub(' +', ' ', out).split(' ')[5].strip())
    memfree_mb = 4096 * data // 1024 // 1024
    memory_facts = obj.get_memory_facts(collected_facts=collected_facts)

# Generated at 2022-06-22 23:07:33.359071
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardwareCollector.collect(dict(distribution='foo', platform='bar'))
    assert hw.populate()['processor'] == 'Intel'

# Generated at 2022-06-22 23:07:36.400591
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware_facts = hardware.populate({})
    assert hardware_facts['system'] == 'HP-UX'

# Generated at 2022-06-22 23:07:38.844421
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict(), dict())
    assert hw.facts == dict()

# Generated at 2022-06-22 23:07:44.973657
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(dict())
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'JE5'


# Generated at 2022-06-22 23:07:54.082506
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    harware = HPUXHardware(module=module, collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    # For test vmstat return private data
    mem_facts = harware.get_memory_facts()
    assert mem_facts['memfree_mb'] == 1024
    assert mem_facts['swapfree_mb'] == 0
    assert mem_facts['swaptotal_mb'] == 0
    assert mem_facts['memtotal_mb'] == 1024


# Generated at 2022-06-22 23:07:58.246417
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """ Function to test  get_memory_facts of class HPUXHardware
    :return:
    """
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware()
    hardware.populate(collected_facts)
    hardware.get_memory_facts(collected_facts)


# Generated at 2022-06-22 23:07:59.715281
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardwareCollector()
    assert(isinstance(h, HPUXHardwareCollector))

# Generated at 2022-06-22 23:08:11.481972
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = MockAnsibleModule()
    h = HPUXHardware(module=module)
    res = h.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert res.get('processor_count') == 2
    assert res.get('processor') is None
    assert res.get('processor_cores') is None

    res = h.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64'})
    assert res.get('processor_count') == 2
    assert res.get('processor') == 'Intel processor'
    assert res.get('processor_cores') == 2


# Generated at 2022-06-22 23:08:21.142545
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec={})
    hardware = HPUXHardware(module=module, collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    hardware.module.run_command = Mock(return_value=(0, "", ""))

# Generated at 2022-06-22 23:08:26.816728
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class TestModule():
        pass

    x = TestModule()
    x.run_command = run_command

    class TestAnsibleModule():
        def __init__(self, x):
            self.params = {}
            self.run_command = x.run_command

    memory_facts = HPUXHardware(TestAnsibleModule(x)).get_memory_facts()
    assert memory_facts['memfree_mb'] == 2577
    assert memory_facts['memtotal_mb'] == 32768
    assert memory_facts['swaptotal_mb'] == 10240
    assert memory_facts['swapfree_mb'] == 0



# Generated at 2022-06-22 23:08:34.306807
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    sample_data = [
        ('''
total_mb=16288
memfree_mb=14651
swaptotal_mb=0
swapfree_mb=0
        '''.strip(), {
            'memfree_mb': 14651,
            'memtotal_mb': 16288,
            'swapfree_mb': 0,
            'swaptotal_mb': 0
        }),
        ('''
total_mb=161259
memfree_mb=160542
swaptotal_mb=0
swapfree_mb=0
        '''.strip(), {
            'memfree_mb': 160542,
            'memtotal_mb': 161259,
            'swapfree_mb': 0,
            'swaptotal_mb': 0
        })
    ]


# Generated at 2022-06-22 23:08:39.245677
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    facts = HPUXHardware.get_hw_facts()
    assert facts['model']
    assert facts['firmware_version']
    assert facts['product_serial']

# Generated at 2022-06-22 23:08:52.000890
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware()

    collected_facts = {'ansible_architecture': '9000/785',
                       'ansible_distribution': 'HP-UX'}

    hardware_facts.populate(collected_facts=collected_facts)

    expected_cpu_facts = {'processor_count': 2}
    assert hardware_facts.cpu == expected_cpu_facts

    expected_memory_facts = {'memfree_mb': 72,
                             'memtotal_mb': 1048576,
                             'swapfree_mb': 2163,
                             'swaptotal_mb': 2163}
    assert hardware_facts.memory == expected_memory_facts


# Generated at 2022-06-22 23:08:57.655288
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.required_facts == set(['platform', 'distribution'])
    assert h._platform == 'HP-UX'
    assert h._fact_class.platform == 'HP-UX'
    assert h.platform == 'HP-UX'


# Generated at 2022-06-22 23:09:04.494938
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    facts = hw.populate({'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.11'})
    assert facts['processor'] == 'PA-RISC 2.0'
    assert facts['processor_count'] == '2'


# Generated at 2022-06-22 23:09:07.388369
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    fact_class = HPUXHardwareCollector(module)
    assert fact_class.platform == 'HP-UX'



# Generated at 2022-06-22 23:09:12.810966
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    platform, fact_class, required_facts = hardware_collector._platform, \
                                            hardware_collector._fact_class, \
                                            hardware_collector.required_facts
    assert platform == 'HP-UX'
    assert fact_class == HPUXHardware
    assert required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:09:17.992406
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    collected_facts = {'ansible_architecture': 'ia64'}
    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 8

# Generated at 2022-06-22 23:09:30.741855
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts = dict()
    facts['ansible_architecture'] = 'ia64'
    facts['ansible_distribution'] = 'HP-UX'
    facts['ansible_distribution_version'] = 'B.11.23'
    hpux_hw = HPUXHardware(None)
    hw_facts = hpux_hw.get_hw_facts(collected_facts=facts)
    assert 'model' in hw_facts
    assert hw_facts['firmware_version'] == 'C.1.9'
    facts['ansible_distribution_version'] = 'B.11.31'
    hw_facts = hpux_hw.get_hw_facts(collected_facts=facts)
    assert hw_facts['firmware_version'] == 'C.1.16'


#

# Generated at 2022-06-22 23:09:41.300892
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware()

    hw_facts = hardware.populate({'ansible_architecture': '9000/800'})
    assert hw_facts['processor_count'] == 1
    assert hw_facts['memfree_mb'] > 0
    assert hw_facts['swapfree_mb'] > 0
    assert hw_facts['memtotal_mb'] > 0
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'Extension ROM revision 1.12'

# Generated at 2022-06-22 23:09:45.143540
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    hw.populate()
    assert type(hw.facts['processor_count']) == type(0)
    assert type(hw.facts['processor_cores']) == type(0)
    assert type(hw.facts['processor']) == type('')


# Generated at 2022-06-22 23:09:58.250908
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({'ansible_distribution': 'HP-UX', 'ansible_architecture': 'ia64'}, {'ansible_distribution_version': 'B.11.23'})
    rc, out, err = hw.module.run_command('echo "=PH8000-27: B.11.23"')
    hw_facts = hw.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hw_facts == {'model': 'PH8000-27', 'firmware_version': 'B.11.23'}

# Generated at 2022-06-22 23:10:07.635391
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    # Test the hp700 case
    PARAMS = {'ansible_architecture': '9000/800'}
    result = hardware.get_cpu_facts(collected_facts=PARAMS)
    assert result == {'processor': 'HP PA-RISC 2.0', 'processor_count': 2, 'processor_cores': 2}
    # Test the hpia64 case
    PARAMS = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}
    result = hardware.get_cpu_facts(collected_facts=PARAMS)
    assert result == {'processor': 'Intel Itanium2', 'processor_count': 4, 'processor_cores': 4}

# Generated at 2022-06-22 23:10:09.242158
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hr = HPUXHardware(dict())
    assert hr.platform == 'HP-UX'

# Generated at 2022-06-22 23:10:17.871699
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    class TestModule(object):
        def __init__(self):
            self.run_command_results = []

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False):
            rc, out, err = self.run_command_results.pop(0)
            return rc, out, err

    testmodule = TestModule()
    testmodule.run_command_results.append((0, '9000/800/E25', ''))
    testmodule.run_command_results.append((0, 'B.11.31', ''))

# Generated at 2022-06-22 23:10:19.595911
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    Return a HPUXHardware object
    """
    return HPUXHardware()

# Generated at 2022-06-22 23:10:25.178195
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector.platform == 'HP-UX'
    assert hpux_hardware_collector.required_facts == set(['platform', 'distribution'])
    assert hpux_hardware_collector._fact_class == HPUXHardware

# Generated at 2022-06-22 23:10:33.306025
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('', (object,), {"run_command": random_cmd})
    module.module_utils = type('', (object,), {"basic": Basic})()
    module.params = {}
    module.distribution = 'HP-UX'
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts['model'] == 'HP rp4440 PA8700 PCX-L2'
    assert hardware.facts['firmware_version'] == 'B.11.31'


# Generated at 2022-06-22 23:10:37.693955
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})

    hw_collector = HPUXHardwareCollector(module)
    hw = hw_collector.collect()
    assert hw != {}
    assert type(hw) is HPUXHardware


# Generated at 2022-06-22 23:10:46.674569
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    _ansible_module = AnsibleModule(argument_spec=dict())
    hpu = HPUXHardware(_ansible_module)

    # Check HP-UX 11.23
    collected_facts = {
        "ansible_distribution_version": "11.23",
        "ansible_architecture": "ia64"
    }
    cpu_facts = hpu.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) CPU      T8250  @ 2.00GHz'
    assert cpu_facts['processor_cores'] == 4

    # Check HP-UX 11.31

# Generated at 2022-06-22 23:10:53.819609
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_module = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    facts = hardware_module.get_memory_facts(collected_facts)
    assert facts['memfree_mb'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0


# Generated at 2022-06-22 23:10:55.979759
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:11:03.432868
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = {
        'run_command': lambda x, **kwargs: (0, '', ''),
    }
    hardware_obj = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
    }
    cpu_facts_facts = hardware_obj.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts_facts['processor_count'] == 8
    assert cpu_facts_facts['processor_cores'] == 24
    assert cpu_facts_facts['processor'] == 'Intel(R) Itanium(R) Processor 9300 series'
    assert not cpu_facts_facts['processor_cores']


# Generated at 2022-06-22 23:11:04.796451
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    return {}



# Generated at 2022-06-22 23:11:10.723316
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(None)
    # Test with ioscan
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    # Test with machinfo
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 4
    # Test with machinfo but hyperthreading is active

# Generated at 2022-06-22 23:11:13.866761
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({'platform': 'HP-UX', 'distribution': 'B.11.31'})
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-22 23:11:21.188793
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = {}
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True
    )

    if not HAS_HPUXUTILS:
        module.fail_json(msg="hpuxutils required for this module")

    h = HPUXHardware(module=test_module)
    cpu_facts = h.get_cpu_facts()
    assert isinstance(cpu_facts['processor_count'], int)


# Generated at 2022-06-22 23:11:26.485867
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module=module)
    hw_facts = hardware.get_hw_facts({'ansible_distribution': 'HP-UX'})
    assert 'model' in hw_facts
    assert 'firmware_version' in hw_facts



# Generated at 2022-06-22 23:11:37.585295
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({'module_setup': True},
                            collected_facts={"ansible_architecture": "9000/800", "ansible_distribution_version": "B.11.31"})
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor'] == "Intel(R) Itanium(R) processor"

    hardware = HPUXHardware({'module_setup': True},
                            collected_facts={"ansible_architecture": "ia64", "ansible_distribution_version": "B.11.23"})
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 2
    assert cpu

# Generated at 2022-06-22 23:11:40.085577
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'platform': 'HP-UX',
             'distribution': 'HP-UX'}
    hc = HPUXHardwareCollector(facts=facts)
    assert hc.platform == 'HP-UX'
    assert hc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:11:47.613140
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Constructor of HPUXHardwareCollector should set the
    platform, fact_class and required_facts properties of the
    instance.
    """
    collector = HPUXHardwareCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXHardware
    assert collector.required_facts == set(['platform', 'distribution'])

# Unit test case for HPUXHardware

# Generated at 2022-06-22 23:11:51.069251
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """Unit test for constructor of class HPUXHardware"""
    hardware_facts_obj = HPUXHardware(None, {})

    assert hardware_facts_obj.platform  == 'HP-UX'

# Generated at 2022-06-22 23:12:03.041062
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUXHardware.model = ''
    HPUXHardware.firmware = ''
    HPUXHardware.processor = ''
    HPUXHardware.processor_cores = 0
    HPUXHardware.processor_count = 0
    HPUXHardware.memfree_mb = 0
    HPUXHardware.memtotal_mb = 0
    HPUXHardware.swapfree_mb = 0
    HPUXHardware.swaptotal_mb = 0
    data = {'ansible_architecture': "9000/800"}
    HPUXHardware.populate(data)
    assert HPUXHardware.model == 'rp3410'
    assert HPUXHardware.firmware == 'HPUX'

# Generated at 2022-06-22 23:12:11.149745
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module=module)

    hw.populate()
    assert hw.facts['processor']
    assert hw.facts['processor_cores']
    assert hw.facts['processor_count']
    assert hw.facts['model']
    assert hw.facts['memtotal_mb']
    assert hw.facts['memfree_mb']
    assert hw.facts['swaptotal_mb']
    assert hw.facts['swapfree_mb']

# Generated at 2022-06-22 23:12:15.857257
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])
    assert hardware_collector.fact_class == HPUXHardware


# Generated at 2022-06-22 23:12:26.226987
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    test_HPUXHardware_get_memory_facts
    """
    h = HPUXHardware()
    h.module = FakeAnsibleModule()

# Generated at 2022-06-22 23:12:38.970307
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware_object = HPUXHardware({})
    hardware_object.module.run_command = mock_run_command
    hardware_object.module.params = {}
    hardware_object.module.params['command_timeout'] = 10
    hardware_object.module.params['gather_timeout'] = 10

    hardware_object.module.run_command = mock_run_command

    collected_facts = {
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
        'ansible_architecture': 'ia64',
    }

    expected_result = {
        'firmware_version': 'P170-01-00',
        'product_serial': '0123456789'
    }
    result = hardware_object.get_hw_facts

# Generated at 2022-06-22 23:12:44.880593
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware({})
    facts = {}
    assert h.get_memory_facts(facts) == {'swaptotal_mb': 0, 'swapfree_mb': 0}
    facts = {'ansible_architecture': '9000/800'}
    data = '             0  3437480  2889788  3353420      62    2   6522984         0'
    assert h.get_memory_facts(facts) == {'swaptotal_mb': 0, 'swapfree_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}
# Test for method get_cpu_facts on class HPUXHardware

# Generated at 2022-06-22 23:12:53.045049
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    col = HPUXHardwareCollector()
    hw = col.get_fact_class()
    input = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    output = hw.get_hw_facts(input)
    assert output == {'model': 'ia64 hp server', 'firmware_version': '1.0'}



# Generated at 2022-06-22 23:13:01.996550
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware_facts = {}
    # Test ia64 11.23
    module.run_command = MagicMock(return_value=(0, "4\n", ""))
    harware_facts['ansible_architecture'] = 'ia64'
    harware_facts['ansible_distribution_version'] = 'B.11.23'
    harware_facts['ansible_memfree_mb'] = MagicMock()
    harware_facts['ansible_memtotal_mb'] = MagicMock()
    harware_facts['ansible_swapfree_mb'] = MagicMock()
    harware_facts['ansible_swaptotal_mb'] = MagicMock()
    harware_facts['ansible_processor'] = MagicMock()
    har

# Generated at 2022-06-22 23:13:10.160667
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31',
        platform='HP-UX'
    )
    hpux_hardware = HPUXHardware({}, collected_facts)
    assert hpux_hardware.platform == 'HP-UX'
    assert hpux_hardware.required_collector_facts == {'distribution', 'platform'}

# Generated at 2022-06-22 23:13:18.802032
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts import Collector
    facts_dict = dict(ansible_architecture='ia64', ansible_distribution='HP-UX', ansible_distribution_version='B.11.31')
    facts_collector = Collector(module=None, facts=facts_dict)
    # Test for product serial
    data_serial = dict(ansible_architecture='ia64', ansible_distribution='HP-UX', ansible_distribution_version='B.11.23')
    hardware_collector = HPUXHardwareCollector(module=None, facts=data_serial)
    hardware_class = hardware_collector.collect()[0]

# Generated at 2022-06-22 23:13:30.229209
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})

    hwfact = HPUXHardware(module=module)
    memory_facts = hwfact.get_memory_facts()
    cpu_facts = hwfact.get_cpu_facts()
    hw_facts = hwfact.get_hw_facts()

    module_args = {}
    module_args.update(memory_facts)
    module_args.update(cpu_facts)
    module_args.update(hw_facts)

    result = {}
    result.update(module_args)
    result.update(dict(changed=False, ansible_facts={'ansible_hardware': module_args}))

    module.exit_json(**result)


# Generated at 2022-06-22 23:13:39.390417
# Unit test for method populate of class HPUXHardware

# Generated at 2022-06-22 23:13:44.110217
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.required_facts == {'platform', 'distribution'}
    assert collector._platform == 'HP-UX'
    assert issubclass(collector._fact_class, HPUXHardware)

# Generated at 2022-06-22 23:13:46.142956
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({})
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-22 23:13:55.014910
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    output = {'ansible_facts': {'hw_product_serial': '9RC9F0', 'hw_model': 'ia64 hp rx6600', 'hw_firmware_version': 'B.11.31'}}
    data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hp = HPUXHardware(None, data)
    assert hp.get_hw_facts() == output['ansible_facts']

# Generated at 2022-06-22 23:14:06.413888
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    h = HPUXHardware(data)
    result = h.populate()
    assert result['processor_count'] == 4  # Test that the processor count is at 4
    assert result['processor_cores'] == 16  # Test that the processor cores is at 16
    assert result['processor'] == 'Intel(R) Itanium(R) Processor 9300 series CPUs'  # Test that processor is the expected string
    assert result['firmware_version'] == 'HP-UX_B.11.31_IA_PA-RISC_09.49'  # Test that firmware version is the expected string

# Generated at 2022-06-22 23:14:18.830567
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.hardware.hpuux import HPUXHardwareCollector

    # Get the instance of class defined in this file
    hw = HPUXHardwareCollector()

    # Check the facts retrieved by the instance
    facts = hw.collect()
    assert facts['model'] == 'ia64 hp Integrity Superdome 2'

    # Check that the instance can call the generic get_cpu_facts method
    # This method is provided by the class HardwareCollector
    cpu_facts = hw.get_cpu_facts()
    assert sorted(cpu_facts.keys()) == ['processor', 'processor_cores', 'processor_count']

    # Check that the instance can call the generic get_memory_facts method
    # This method is provided by the class HardwareCollector
    memory_facts = hw.get_memory_