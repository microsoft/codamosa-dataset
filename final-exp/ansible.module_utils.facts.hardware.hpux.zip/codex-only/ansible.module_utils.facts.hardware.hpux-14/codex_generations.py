

# Generated at 2022-06-22 23:04:15.392725
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    class ModuleMock:
        def __init__(self, module):
            self.run_command = module.run_command

    hpux_hardware = HPUXHardware(ModuleMock(module))

    module.run_command = Mock(return_value=(0, 'ia64', ''))
    hpux_hardware.module.run_command = module.run_command
    hw_facts = hpux_hardware.get_hw_facts()
    assert hw_facts['firmware_version'] == '3.88'


# Generated at 2022-06-22 23:04:22.486447
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardwareCollector.fetch_facts(module)['ansible_facts']['ansible_hardware']
    assert hardware['memtotal_mb']
    assert hardware['memfree_mb']
    assert hardware['swaptotal_mb']
    assert hardware['swapfree_mb']



# Generated at 2022-06-22 23:04:25.668215
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    test_hw_collector = HPUXHardwareCollector(module=module)
    assert test_hw_collector.platform == 'HP-UX'



# Generated at 2022-06-22 23:04:29.281352
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    my_obj = HPUXHardwareCollector()
    assert my_obj._platform == 'HP-UX'
    assert my_obj._fact_class == HPUXHardware
    assert my_obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:04:34.438361
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    cpu_facts = HPUXHardware.get_cpu_facts()
    for k in cpu_facts:
        assert k in ['processor', 'processor_cores', 'processor_count']


# Generated at 2022-06-22 23:04:39.769913
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    hardware = HPUXHardware({'module_setup': True})
    hardware._module.run_command = MagicMock(return_value=(0, "32", ""))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0

# Generated at 2022-06-22 23:04:52.161031
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params['fact_path'] = os.path.dirname(os.path.realpath(__file__)) + '/../../../'
    hardware_collector = HPUXHardwareCollector(module=module)
    # Test model 9000/800
    facts = hardware_collector.collect(['ansible_architecture'], '9000/800')
    assert facts['processor_count'] == 24
    # Test model 9000/785
    facts = hardware_collector.collect(['ansible_architecture'], '9000/785')
    assert facts['processor_count'] == 12
    # Test model ia64
    facts = hardware_collector.collect(['ansible_architecture'], 'ia64')
    assert facts['processor_count'] == 1


# Generated at 2022-06-22 23:05:03.791092
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # No vmstat output should return empty dictionary
    assert HPUXHardware(dict()).get_memory_facts() == {}

    # Invalid vmstat output should return empty dictionary
    assert HPUXHardware(dict()).get_memory_facts() == {}

    # Valid vmstat output with an architecture of 9000/800 or 9000/785 should
    # return memfree_mb, memtotal_mb, swapfree_mb, and swaptotal_mb.
    hw = HPUXHardware({'ansible_architecture': '9000/800'})
    hw.module = MockModuleShellCommand("vmstat\n17\n")
    facts = hw.get_memory_facts()
    assert facts['memfree_mb'] == 28
    assert facts['memtotal_mb'] == 1024
    assert facts['swapfree_mb'] == 0

# Generated at 2022-06-22 23:05:12.415922
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test get_hw_facts of class HPUXHardware class.
    :return:
    """
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    print("\n Testing get_hw_facts of class HPUXHardware")
    hpux_hardware_obj = HPUXHardware(module=None)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hw_facts_result = hpux_hardware_obj.get_hw_facts(collected_facts=collected_facts)
    print("hw_facts_result is " + str(hw_facts_result))

# Generated at 2022-06-22 23:05:21.921552
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test HPUXHardware.get_cpu_facts method
    """
    hardware = HPUXHardware({})

    collected_facts = {'ansible_architecture': '9000/785',
                       'ansible_distribution_version': 'B.11.31',
                       'ansible_distribution': 'HP-UX'}
    # Testing with fact ansible_architecture=9000/785
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor'] == 'Intel Itanium 2'
    assert cpu_facts['processor_cores'] == 24
    assert cpu_facts['processor_count'] == 16

# Generated at 2022-06-22 23:05:31.833283
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())

    mod_info = {
        'ansible_architecture': '9000/800',
    }

    def run_command(module, cmd, use_unsafe_shell):
        memtotal_mb = 10485760
        memfree_mb = 1527104
        swaptotal_mb = 1024
        swapfree_mb = 0

        if cmd == '/usr/bin/vmstat | tail -1':
            out = '0       0   1527104        0        0         0         0         0         0         0         0         0'
            return (0, out, '')

# Generated at 2022-06-22 23:05:33.178662
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_hardware = HPUXHardware()

# Generated at 2022-06-22 23:05:44.154656
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    abstract_hw = HPUXHardware(dict())

    collected_facts = {'ansible_architecture': '9000/785'}
    cpu_facts = abstract_hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor_count': 1}

    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = abstract_hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {}

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = abstract_hw.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-22 23:05:49.389036
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware_obj = HPUXHardware(module)
    module.exit_json(ansible_facts=dict(ansible_hardware=hardware_obj.populate()))


# Generated at 2022-06-22 23:05:51.734486
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware(dict())
    assert hardware_obj.platform == "HP-UX"


# Generated at 2022-06-22 23:05:53.613669
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hpu = HPUXHardware(module)

# Generated at 2022-06-22 23:06:04.444535
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_hpu = HPUXHardware()
    test_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    rc, out, err = test_hpu.module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    assert (test_hpu.get_hw_facts(test_facts) == {'firmware_version': out.strip().split('=')[1].strip(), 'model': 'ia64'})
    test_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    rc, out, err = test_h

# Generated at 2022-06-22 23:06:17.726809
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # settings for test
    module = AnsibleModule()
    module.params = {}
    module.run_command = MagicMock()

    # testing the constructor and creating object from class HPUXHardware
    hw = HPUXHardware(module)

    # testing the facts
    ansible_facts = {}

    ansible_facts['ansible_architecture'] = "ia64"
    ansible_facts['ansible_distribution_version'] = "B.11.23"
    ansible_facts['ansible_distribution'] = "HP-UX"

    hw_facts = hw.populate(collected_facts=ansible_facts)
    assert hw_facts['processor_cores'] == 4
    assert hw_facts['processor_count'] == 4

# Generated at 2022-06-22 23:06:29.176863
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Setup test variables
    setattr(module, 'run_command', fake_run_command)

    # Construct our class
    memory_facts = HPUXHardware(module).get_memory_facts(
        {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})

    # Test resulting memfree_mb
    assert memory_facts['memfree_mb'] == 21855

    # Test resulting memtotal_mb
    assert memory_facts['memtotal_mb'] == 4464

    # Test resulting swaptotal_mb
    assert memory_facts['swaptotal_mb'] == 1717

    # Test resulting swapfree_mb

# Generated at 2022-06-22 23:06:41.222082
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = HPUXHardware(module, collected_facts).get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'

    collected_facts = {'ansible_architecture': '9000/785', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = HPUXHardware(module, collected_facts).get_cpu_facts(collected_facts)

# Generated at 2022-06-22 23:06:51.526067
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = ModuleStub()

# Generated at 2022-06-22 23:06:53.963268
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts == {'memtotal_mb': 31960, 'swaptotal_mb': 3840, 'swapfree_mb': 3840, 'memfree_mb': 22843}



# Generated at 2022-06-22 23:07:00.354003
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Output from vmstat command
    vmstat_output = '1  0  1  16  1012  3185'

    # Output from swapinfo command
    swapinfo_output = 'Device          1M-blocks     Used    Avail Capacity  Priority\n' \
                      'fs             102570.50   65321.50  37249.00    64%    1'

    # Initialize TestModule
    test_module = TestModule({'vmstat': vmstat_output, 'swapinfo': swapinfo_output})

    # Initialize HPUXHardware class
    hw_fact_module = HPUXHardware(test_module)

    # Check output of method get_memory_facts
    memory_facts = hw_fact_module.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1025

# Generated at 2022-06-22 23:07:04.657448
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware.get_cpu_facts()
    assert('processor' in cpu_facts)
    assert('processor_cores' in cpu_facts)
    assert('processor_count' in cpu_facts)


# Generated at 2022-06-22 23:07:12.210683
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    module.params = {}
    module.params['gather_subset'] = 'all'
    module.run_command.return_value = (0, 'test_data', '')

    hw = HPUXHardware(module)

    hw.populate()
    assert 'memfree_mb' in hw.facts
    assert 'memtotal_mb' in hw.facts
    assert 'swapfree_mb' in hw.facts
    assert 'swaptotal_mb' in hw.facts
    assert 'processor' in hw.facts
    assert 'processor_cores' in hw.facts
    assert 'processor_count' in hw.facts
    assert 'model' in hw.facts
    assert 'firmware_version' in hw.facts

# Generated at 2022-06-22 23:07:17.204310
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    assert HPUXHardware.get_hw_facts() == {'model': 'ia64', 'firmware_version': 'MP (c) Compaq Computer Corporation', 'product_serial': 'ABCDEFG'}, "Unexpected result for HP-UX system."

# Generated at 2022-06-22 23:07:28.665998
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = type('Module', (object,), {})
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware(module)
    data = hardware.populate(collected_facts)
    assert data.get('processor')
    assert data.get('processor_cores')
    assert data.get('processor_count')
    assert data.get('memfree_mb')
    assert data.get('memtotal_mb')
    assert data.get('swapfree_mb')
    assert data.get('swaptotal_mb')
    assert data.get('model')
    assert data.get('firmware')

# Generated at 2022-06-22 23:07:38.077811
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    HP-UX hardware fact - Unit test for get_memory_facts
    """
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    test_data = {}
    test_data['ansible_architecture'] = 'ia64'
    test_data['ansible_distribution_version'] = 'B.11.31'

    memory_facts = {}
    hardware = HPUXHardware(dict(module=dict()))
    hardware.module.run_command = lambda x: (0, '', None)
    hardware.module.run_command = lambda x: (0, '', None)
    hardware.module.run_command = lambda x: (0, '', None)
    hardware.module.run_command = lambda x: (0, '', None)

# Generated at 2022-06-22 23:07:40.780094
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({'platform': 'HP-UX'}, {}, {})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:52.463101
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware(None, collected_facts)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['memtotal_mb'] == 393780
    assert hardware_facts['memfree_mb'] == 8099
    assert hardware_facts['swapfree_mb'] == 3931
    assert hardware_facts['swaptotal_mb'] == 3931
    assert hardware_facts['model'] == 'HP Integrity rx8640 Server'
    assert hardware_

# Generated at 2022-06-22 23:08:01.041976
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_HPUXHardware = HPUXHardware(test_module)
    test_HPUXHardware_get_cpu_facts_result = {'processor': 'Intel(R) Itanium(R) Processor 9300 series',
                                              'processor_cores': 16,
                                              'processor_count': 12}
    assert test_HPUXHardware.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64',
                                                            'ansible_distribution': 'HP-UX',
                                                            'ansible_distribution_version': 'B.11.31'}) == test_HPUXHardware_get_cpu_facts_result
    test_HPUXHardware_get_cpu

# Generated at 2022-06-22 23:08:08.772788
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpux_hw = HPUXHardware()
    hw_facts = hpux_hw.get_hw_facts({'ansible_architecture': 'ia64'})
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'Integrity Virtual Machine'
    assert hw_facts['product_serial'] == '1138'



# Generated at 2022-06-22 23:08:19.860862
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    m = HPUXHardwareCollector(None)
    out = "procs ---memory--- -----swap-------- -----io---- --system-- -----cpu----- r b swpd free inact active si so bi bo in cs us sy id wa st"

    # Test for HP-UX B.11.31
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    m = HPUXHardware(m, collected_facts)
    rc, out, err = m.module.run_command("/usr/contrib/bin/machinfo | grep -e '[0-9] core' | tail -1", use_unsafe_shell=True)
    assert out == '2 cores'

# Generated at 2022-06-22 23:08:25.088318
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Test with a collect_facts equal to None
    HPUXHardware().get_hw_facts()

    # Test with a collect_facts.ansible_architecture equal to '9000/800'
    HPUXHardware().get_hw_facts({'ansible_architecture': '9000/800'})


# Generated at 2022-06-22 23:08:37.464005
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModuleMock({})
    hardware = HPUXHardware(module=module)

    # Example with architecture 9000/800
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23'
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts.get('processor_count') == 8

    # Example with architecture 9000/785
    collected_facts = {
        'ansible_architecture': '9000/785',
        'ansible_distribution_version': 'B.11.23'
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-22 23:08:43.322787
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({}, {'platform': 'HP-UX', 'distribution_version': 'B.11.23'})
    out = hw.get_hw_facts()
    assert out['model'] == 'ia64 hp server rx2600'
    assert out['firmware_version'] == 'v3.08'
    hw = HPUXHardware({}, {'platform': 'HP-UX', 'distribution_version': 'B.11.31'})
    out = hw.get_hw_facts()
    assert out['model'] == 'ia64 hp server rx2600'
    assert out['firmware_version'] == 'v3.06'

# Generated at 2022-06-22 23:08:45.816501
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw_obj = HPUXHardware(None)
    assert hw_obj.platform == 'HP-UX'



# Generated at 2022-06-22 23:08:51.762854
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware()
    h.module.run_command = lambda *args, **kwargs: (0, "54212", "")
    h.get_memory_facts() == {'memfree_mb': 823, 'memtotal_mb': 823, 'swaptotal_mb': 823, 'swapfree_mb': 823}

# Generated at 2022-06-22 23:09:05.036531
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = None
    facts = {}
    HPUXHardware = HPUXHardwareCollector._fact_class(module, facts, None)
    HPUXHardware.populate()
    assert 'processor_cores' in HPUXHardware.populate()
    assert 'processor_count' in HPUXHardware.populate()
    assert 'memfree_mb' in HPUXHardware.populate()
    assert 'memtotal_mb' in HPUXHardware.populate()
    assert 'swapfree_mb' in HPUXHardware.populate()
    assert 'swaptotal_mb' in HPUXHardware.populate()
    assert 'processor' in HPUXHardware.populate()
    assert 'model' in HPUXHardware.populate()
    assert 'firmware_version' in HPUXHardware.pop

# Generated at 2022-06-22 23:09:15.627832
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware({'ansible_distribution': 'HP-UX',
                             'ansible_distribution_version': 'B.11.31',
                             'ansible_architecture': 'ia64'})
    hardware.module = FakeModule()
    hardware.get_cpu_facts = FakeMethod(return_value={'processor_count': 2, 'processor_cores': 4, 'processor': 'Intel(R) Xeon(R) CPU E5-2697A v4 @ 2.60GHz'})
    hardware.get_memory_facts = FakeMethod(return_value={'memfree_mb': 956,
                                                         'memtotal_mb': 31930,
                                                         'swaptotal_mb': 8192,
                                                         'swapfree_mb': 1766})
    hardware.get_hw_

# Generated at 2022-06-22 23:09:28.604320
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    # Testing with architecture 9000/800
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.31'}

    hardware_facts = hw.populate(collected_facts=collected_facts)
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) 9500 processor series'
    assert hardware_facts['memfree_mb'] == 0

# Generated at 2022-06-22 23:09:37.072876
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({})
    rc, out, err = hardware.module.run_command("date; echo 'model'")
    hw_facts = hardware.get_hw_facts({'ansible_architecture': 'itanium'})
    assert hw_facts['model'] == out.strip()

    rc, out, err = hardware.module.run_command("echo 'hp-dl980g7-01'")
    hw_facts = hardware.get_hw_facts({'ansible_architecture': 'itanium'})
    expected_firmware = '7.60'

# Generated at 2022-06-22 23:09:46.850172
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """ Test if the class HPUXHardware works when we call the method populate """
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    test_HPUXHardware = HPUXHardware(module=test_module)

    # Test with firmware version > 1204
    test_HPUXHardware.module.facts['ansible_distribution_version'] = "B.11.31"
    test_HPUXHardware.module.facts['ansible_architecture'] = "ia64"
    test_HPUXHardware.module.run_command = MagicMock(return_value=(2, '0', ''))

# Generated at 2022-06-22 23:09:59.806338
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import sys
    try:
        import ansible.modules.system.hardware.HPUXHardware as HW
    except ImportError:
        sys.path.append('../../../')
        import ansible.modules.system.hardware.HPUXHardware as HW
    import json

    module = HW.HPUXHardware.get_module_class()()
    vmstat = """
 procs -----------memory---------- ---swap-- -----io---- --system-- -----cpu------
 r  b         swpd         free        buff   cache   si   so    bi    bo   in   cs us sy id wa st
 2  0      494776      476336      33604       23      0     0     3     0    0    0  0  0 100  0  0
    """

# Generated at 2022-06-22 23:10:05.689100
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = {'ansible_architecture': 'ia64'}
    hw = HPUXHardware(fake_module, facts=facts)
    result = hw.get_memory_facts()
    assert result['memtotal_mb'] == 16384
    assert result['memfree_mb'] < 16384
    assert result['swaptotal_mb'] > 0
    assert result['swapfree_mb'] < result['swaptotal_mb']



# Generated at 2022-06-22 23:10:15.483923
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type("Fake", (), {})
    module.run_command = lambda command, use_unsafe_shell=False: (0, "", "")
    hardware = HPUXHardware({'ansible_architecture': '9000/800'}, module=module)
    assert hardware.get_cpu_facts() == {'processor_count': 0}
    hardware = HPUXHardware({'ansible_architecture': '9000/785'}, module=module)
    assert hardware.get_cpu_facts() == {'processor_count': 0}
    hardware = HPUXHardware({'ansible_architecture': 'ia64'}, module=module)
    assert hardware.get_cpu_facts() == {'processor': None, 'processor_cores': None, 'processor_count': None}


# Generated at 2022-06-22 23:10:27.072138
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({'module': None})
    collected_facts = {'ansible_architecture': '9000/785'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 4
    collected_facts = {'ansible_architecture': 'X', 'ansible_distribution_version': 'B.11.31',
                       'ansible_distribution': 'HP-UX'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)

# Generated at 2022-06-22 23:10:34.453521
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_facts = HPUXHardware({
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.31"
    })
    facts = hardware_facts.get_memory_facts()
    assert facts['memtotal_mb'] >= 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0

# Generated at 2022-06-22 23:10:38.932487
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector()
    assert hwc._fact_class is not None
    assert hwc._platform == 'HP-UX'
    assert hwc.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:10:49.996677
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = HPUXHardwareCollector.init_module_mock()
    hw.module.run_command.return_value = (0, "HP Integrity rx2800 i4 2.4GHz 2-socket 4-core 128GB\n", '')
    assert hw.get_hw_facts(collected_facts={'ansible_architecture': 'ia64'}) == {'model': 'HP Integrity rx2800 i4 2.4GHz 2-socket 4-core 128GB'}


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['--verbose', __file__]))

# Generated at 2022-06-22 23:10:57.952282
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)

    collector = HPUXHardwareCollector(hpux_module)
    hardware_inst = HPUXHardware(hpux_module)
    result = hardware_inst.populate()
    assert result == hardware_inst.get_cpu_facts()
    assert result == hardware_inst.get_hw_facts()
    assert result == hardware_inst.get_memory_facts()


# Generated at 2022-06-22 23:11:11.213725
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()

    assert hw.required_facts == {'platform', 'distribution'}, 'required_facts must be a set of \'platform\', \'distribution\''
    assert hw.collectible_facts == {'processor', 'processor_cores', 'processor_count', 'memfree_mb', 'memtotal_mb',
                                    'swapfree_mb', 'swaptotal_mb', 'model', 'firmware_version', 'product_serial'}, 'collectible_facts must contain only keys: processor, processor_cores, processor_count, memfree_mb, memtotal_mb, swapfree_mb, swaptotal_mb, model, firmware_version, product_serial'
    assert hw.fact_class == HPUXHardware, 'fact_class must be HPUXHardware'
   

# Generated at 2022-06-22 23:11:19.692197
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Call function with collected_facts
    facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
    }
    cpu_facts = HPUXHardwareCollector.get_cpu_facts(facts)

    assert cpu_facts['processor'] == "Intel(R) Xeon(R) CPU E5-2670 v2 @ 2.50GHz"
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-22 23:11:24.199557
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_attr = HPUXHardwareCollector({})
    assert hw_attr.platform == 'HP-UX'
    assert hw_attr.required_facts == set(['platform', 'distribution'])
    assert hw_attr._fact_class == HPUXHardware



# Generated at 2022-06-22 23:11:25.660254
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    assert HPUXHardware



# Generated at 2022-06-22 23:11:29.292418
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:11:36.206780
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    sys_args = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    hw_facts = HPUXHardware(sys_args).get_hw_facts()
    assert hw_facts.get('firmware_version')
    assert hw_facts.get('product_serial')


# Generated at 2022-06-22 23:11:38.693483
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    assert hardware_obj.platform == 'HP-UX'


# Generated at 2022-06-22 23:11:47.879345
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    test_HPUXHardware = HPUXHardware(test_module)

    out = """\
Physical: 16464 Kbytes
"""
    test_HPUXHardware.module.run_command = Mock(return_value=(0, out, None))

    memory_facts = test_HPUXHardware.get_memory_facts({'ansible_architecture':'9000/800'})

    assert memory_facts['memtotal_mb'] == 16


# Generated at 2022-06-22 23:11:53.591264
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('test', (object,), {'run_command': run_command_test_get_cpu_facts})
    hardware = HPUXHardware(module=module)
    facts = hardware.get_cpu_facts()
    assert facts['processor_cores'] == 4
    assert facts['processor_count'] == 4
    assert facts['processor'] == 'Intel(R) Xeon(R) CPU E5-4620 0 @ 2.20GHz'



# Generated at 2022-06-22 23:12:05.354009
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.module = module
    hardware.populate()
    # Test on a system with memory under 4GB
    if hardware.module.run_command("grep Physical /var/adm/syslog/syslog.log")[0] == 0:
        mem_total_mb = float(hardware.module.run_command("grep Physical /var/adm/syslog/syslog.log")[1].strip().split()[4]) / 1024
        assert hardware.facts['memtotal_mb'] == mem_total_mb
    else:
        # TODO: Implement parsing of /dev/kmem on systems without syslog
        pass


# Unit tests on a system with memory under 4GB
# Run with: nosetests -s -

# Generated at 2022-06-22 23:12:09.265467
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    hardware.populate({'ansible_architecture':'ia64'})
    cpu_facts = hardware.get_cpu_facts({'ansible_architecture':'ia64'})
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-22 23:12:15.018728
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()
    # Test that constructed class is of correct type
    assert isinstance(hhc, HPUXHardwareCollector)
    # Test that required and optional facts are populated
    assert set(hhc.required_facts) == HPUXHardwareCollector.required_facts
    assert set(hhc.optional_facts) == HPUXHardwareCollector.optional_facts
    # Test that platform is set correctly
    assert hhc._platform == HPUXHardwareCollector._platform
    # Test that correct class is set to be used for facts
    assert hhc._fact_class == HPUXHardware


# Generated at 2022-06-22 23:12:20.080818
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Constructor does not take any params
    obj = HPUXHardwareCollector()
    assert obj
    # _fact_class is set to HPUXHardware
    assert obj._fact_class == HPUXHardware
    # _platform is set to 'HP-UX'
    assert obj._platform == 'HP-UX'
    # required_facts is a set {'platform', 'distribution'}
    assert obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:12:22.157197
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = Hardware()
    hardware_facts.collect()
    hardware_facts.populate()



# Generated at 2022-06-22 23:12:24.190255
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert (hw.platform == 'HP-UX')


# Generated at 2022-06-22 23:12:31.581079
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """ Unit test for method get_memory_facts of class HPUXHardware """
    hw_facts = HPUXHardware()
    mem_facts = hw_facts.get_memory_facts()
    assert mem_facts['memfree_mb'] >= 0
    assert mem_facts['memtotal_mb'] >= 0
    assert mem_facts['swaptotal_mb'] >= 0
    assert mem_facts['swapfree_mb'] >= 0


# Generated at 2022-06-22 23:12:42.336001
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_hardware_f = os.path.join(os.path.dirname(__file__), 'test_hardware_data', 'hpux.json')
    test_hardware_data = ({}, open(test_hardware_f, 'rb').read())
    new = HPUXHardware(None, test_hardware_data)
    # Run method
    memory_facts = new.get_memory_facts()
    # Check result
    assert isinstance(memory_facts, dict) and len(memory_facts) == 4
    assert memory_facts.get('memfree_mb') == 3897
    assert memory_facts.get('memtotal_mb') == 20926
    assert memory_facts.get('swaptotal_mb') == 2140
    assert memory_facts.get('swapfree_mb') == 2140
   

# Generated at 2022-06-22 23:12:49.369135
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
        'ansible_os_family': 'unix',
        'ansible_system': 'HP-UX',
    })
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-22 23:12:52.595797
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    collected_facts = dict()
    collected_facts['ansible_architecture'] = '9000/800'
    hardware.module = Mock(run_command=Mock(return_value=(0, '1600', '')))
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 400


# Generated at 2022-06-22 23:13:01.763708
# Unit test for method get_memory_facts of class HPUXHardware

# Generated at 2022-06-22 23:13:04.137458
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = None
    hardware = HPUXHardware(module)

    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-22 23:13:06.356252
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({})
    assert hardware.platform == 'HP-UX'


# Generated at 2022-06-22 23:13:17.054865
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    # Test if system is IA64 B.11.23
    set_module_args(dict(
        ansible_facts={
            'ansible_architecture': 'ia64',
            'ansible_distribution_version': 'B.11.23'
        }
    ))
    modobj = module.params
    modobj['ansible_facts']['ansible_processor'] = ['Intel(R) Itanium(R) family']
    modobj['ansible_facts']['ansible_processor_count'] = 4
    modobj['ansible_facts']['ansible_processor_cores'] = 4
    hardware = HPUXHardware(module)
    data = hardware.get_cpu_facts()
    assert data['processor_count'] == 4

# Generated at 2022-06-22 23:13:25.417678
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = AnsibleModule(
        argument_spec=dict(
        )
    )
    hw = HPUXHardware()
    hw.module = test_module
    hw_facts = hw.get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp Integrity rx2660 Server'
    assert hw_facts['firmware_version'] == 'B.11.31.1106'
    assert hw_facts['product_serial'] == 'US12345678'


# Generated at 2022-06-22 23:13:31.837673
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """ This function is used to test constructor of class HPUXHardwareCollector """
    hwcol = HPUXHardwareCollector()
    assert hwcol.platform == 'HP-UX'

if __name__ == '__main__':
    # Unit test for class HPUXHardwareCollector
    print('Running unit test for class HPUXHardwareCollector')
    test_HPUXHardwareCollector()

# Generated at 2022-06-22 23:13:39.307709
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Unit test: ansible.module_utils.facts.hardware.hpux.HPUXHardware.get_memory_facts
    """
    module = FakeAnsibleModule()
    obj_hw = HPUXHardware(module=module)

    # Run get_memory_facts of class HPUXHardware
    memory_facts = obj_hw.get_memory_facts()

    assert (memory_facts.get('memfree_mb'))
    assert (memory_facts.get('memtotal_mb'))
    assert (memory_facts.get('swaptotal_mb'))
    assert (memory_facts.get('swapfree_mb'))



# Generated at 2022-06-22 23:13:44.528850
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({'ansible_facts': {'ansible_architecture': 'ia64'}})
    HPUXHardware.module = module
    hw_facts = HPUXHardware()
    hw_facts.populate()


# Generated at 2022-06-22 23:13:52.534950
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_facts = HPUXHardware({})
    assert hardware_facts.platform == 'HP-UX'
    cpu_facts = hardware_facts.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    memory_facts = hardware_facts.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    hw_facts = hardware_facts.get_hw_facts()
    assert hw_facts['model'] is not None
    assert hw_facts['firmware_version'] is not None
    assert hw_facts['product_serial'] is not None

# Generated at 2022-06-22 23:13:58.233035
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, "600000", ""))
    hardware = HPUXHardware(mock_module)
    data = hardware.get_memory_facts()
    assert data['memfree_mb'] == 9536
    assert data['memtotal_mb'] == 12288


# Generated at 2022-06-22 23:14:10.224300
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModuleMock({'ansible_architecture': 'ia64'})
    Hardware = HPUXHardware(module)
    cpu_facts = Hardware.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == "Intel(R) Itanium(R) Processor 9150"

    module = AnsibleModuleMock({'ansible_architecture': 'ia64'})
    Hardware = HPUXHardware(module)