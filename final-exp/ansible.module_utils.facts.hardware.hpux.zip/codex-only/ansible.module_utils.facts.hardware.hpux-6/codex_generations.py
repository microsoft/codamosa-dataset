

# Generated at 2022-06-22 23:04:24.266276
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    class ModuleStub:
        def __init__(self):
            self.run_command = BaseModuleTest.run_command
    class FactsStub:
        def __init__(self):
            self.__ansible_facts__ = {}
            self.__ansible_facts__['ansible_distribution_version'] = 'B.11.31'
            self.__ansible_facts__['ansible_architecture'] = 'ia64'
    class KernelCommandStub:
        def __init__(self):
            self.__ansible_kernel__ = 'HP-UX'
    class RunnerStub:
        def __init__(self, module):
            self.module = ModuleStub()
    hardware_stub = HPUXHardware()
    hardware_stub.runner = RunnerStub(ModuleStub())


# Generated at 2022-06-22 23:04:28.503725
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    h = HPUXHardware(module=module)
    hw_facts = h.get_hw_facts()
    assert hw_facts['model']
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']


# Generated at 2022-06-22 23:04:38.249469
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test function for get_hw_facts method of HPUX.
    :return:
    """
    test_obj = HPUXHardware(module=None)
    # Test with no input argument
    hw_facts = test_obj.get_hw_facts()
    assert hw_facts is not None, "hw_facts must be returned from get_hw_facts"
    assert type(hw_facts) == dict, "hw_facts must be returned as dictionary from get_hw_facts"
    assert type(hw_facts.get('model')) == str, "hw_facts must contain model string"
    assert type(hw_facts.get('firmware_version')) == str, "hw_facts must contain firmware_version string"

# Generated at 2022-06-22 23:04:51.108720
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = MockModule()
    hardware = HPUXHardware(module)
    assert hardware.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64',
                                                   'ansible_distribution_version': 'B.11.23'}) == {'processor_count': 24,
                                                                                                'processor': 'Intel(R) Itanium(R) Processor',
                                                                                                'processor_cores': 24}

# Generated at 2022-06-22 23:04:58.173340
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({'module_setup': True, 'gather_subset': 'all'})
    assert hw.get_hw_facts()['model'] == 'ia64 hp Integrity rx2660'
    assert hw.get_hw_facts()['firmware_version'] == 'HPUX v4.70'
    assert hw.get_hw_facts()['product_serial'] == 'US1234567890'



# Generated at 2022-06-22 23:05:02.779045
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Unit test for constructor of class HPUXHardwareCollector
    """
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector._fact_class == HPUXHardware
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:05:15.955004
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # setup test
    module = AnsibleModule(argument_spec=dict())
    set_module_args(dict(
        gather_subset=['all'],
        filter=dict(type='dict', required=False),
    ))
    hardware = HPUXHardware(module=module)

    # testing
    rc, out, err = hardware.module.run_command("model")
    hardware.get_hw_facts()
    assert hardware.facts['model'] == out.strip()
    testrc, testout, testerr = hardware.module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    separator = '='

# Generated at 2022-06-22 23:05:24.239889
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params['platform'] = 'HP-UX'
    hw = HPUXHardware(module)

    # Test with architecture 9000/800
    module.params['architecture'] = '9000/800'
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == 'Intel'
    assert cpu_facts['processor_count'] == 1

    # Test with architecture 9000/785
    module.params['architecture'] = '9000/785'
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1

# Generated at 2022-06-22 23:05:30.339182
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({'ansible_facts': {'ansible_architecture': 'ia64',
                                               'ansible_distribution': 'HPUX',
                                               'ansible_distribution_version': 'B.11.23'}})
    assert hardware.platform == 'HP-UX'
    assert hardware.distribution == 'HPUX'
    assert hardware.distribution_version == 'B.11.23'


# Generated at 2022-06-22 23:05:31.582681
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector() is not None

# Generated at 2022-06-22 23:05:38.427451
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    harw_fact = HPUXHardware()
    h_fact = Hardware()
    col = HPUXHardwareCollector()
    assert col.__class__.__bases__[0] == HardwareCollector
    assert col._fact_class == harw_fact.__class__
    assert col._platform == 'HP-UX'
    assert col.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:05:44.414597
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31',
    }
    expected = {
        'processor_count': 96,
        'processor_cores': 48,
        'processor': 'Intel Xeon E5-2697 v4',
    }
    assert hardware.get_cpu_facts(collected_facts=facts) == expected



# Generated at 2022-06-22 23:05:56.064486
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Testing case where ansible_architecture is 9000/800
    collected_facts = dict(ansible_architecture='9000/800')
    module = dict()
    module['run_command'] = lambda *_, **kwargs: (0, '24', '')
    hpu = HPUXHardware(module)
    assert hpu.get_cpu_facts(collected_facts=collected_facts) == dict(processor_count=24)

    # Testing case where ansible_architecture is 9000/785
    collected_facts = dict(ansible_architecture='9000/785')
    module = dict()
    module['run_command'] = lambda *_, **kwargs: (0, '24', '')
    hpu = HPUXHardware(module)
    assert hpu.get_cpu_facts

# Generated at 2022-06-22 23:06:06.529880
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    unit test to test the get_memory_facts method of HPUXHardware class
    """
    import re
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command = self.mock_run_command

        def mock_run_command(self, cmd, use_unsafe_shell=False):
            return 0, '2048', ''

    class MockFacts(object):
        def __init__(self):
            self.ansible_architecture = '9000/800'

    module = MockModule()
    facts = MockFacts()
    hardware = HPUXHardware(module)
    mem_facts = hardware.get_memory_facts(collected_facts=facts)


# Generated at 2022-06-22 23:06:16.430758
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict(module=dict()), dict())
    assert hw.populate() == {
        'processor': 'Intel(R) Itanium(R) 9500 series processors',
        'processor_cores': 1,
        'processor_count': 1,
        'memfree_mb': 138,
        'memtotal_mb': 4011,
        'swapfree_mb': 78,
        'swaptotal_mb': 79,
        'model': 'ia64 hp Integrity rx2660',
        'firmware_version': 'C.4.4'}

# Generated at 2022-06-22 23:06:27.843148
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hardware = HPUXHardware(module)

    # Test read of syslog instead of /dev/kmem
    module.run_command = Mock(return_value=(0, """May 10 06:33:25 debby init: Physical: 524288 Kbytes\n""", ""))
    assert hardware.get_memory_facts()['memtotal_mb'] == 512

    # Test read of /dev/kmem
    module.run_command = Mock(return_value=(0, "262144", ""))
    assert hardware.get_memory_facts()['memtotal_mb'] == 1024

    # Test read of /dev/kmem with error
    module.run_command = Mock(return_value=(1, "", ""))
    assert hardware.get_memory_

# Generated at 2022-06-22 23:06:30.765077
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    dummy_module = object()
    class_instance = HPUXHardware(dummy_module)

    # class_instance.get_cpu_facts()
    class_instance.get_memory_facts()
    class_instance.populate()

# Generated at 2022-06-22 23:06:41.686969
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    # tests for HP-UX 11.31
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'}
    result = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert result['processor_count'] == 4
    assert result['processor'] == 'Intel(R) Itanium(R) Processor 9500'
    assert result['processor_cores'] == 8

    # tests for HP-UX 11.23
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'}
    result = hardware.get

# Generated at 2022-06-22 23:06:52.069777
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    # Initialization
    hw = HPUXHardware()

    # Check for facts HP9000
    for arch in ['9000/800', '9000/785']:
        data = {'ansible_architecture': arch}
        cpu = hw.get_cpu_facts(collected_facts=data)
        assert cpu['processor_count'] == 1

    # Check for facts ia64
    for dist in ['B.11.23', 'B.11.31']:
        data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': dist}
        cpu = hw.get_cpu_facts(collected_facts=data)
        assert int(cpu['processor_count']) > 0
        assert cpu['processor_cores'] > 0



# Generated at 2022-06-22 23:06:56.645500
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeModule()
    hw = HPUXHardware(module)
    data = hw.get_memory_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert data['memtotal_mb'] == 64
    assert data['memfree_mb'] == 64
    assert data['swaptotal_mb'] == 64
    assert data['swapfree_mb'] == 64


# Generated at 2022-06-22 23:07:04.468843
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=False
    )

    result = HPUXHardware(module).populate()
    module.exit_json(ansible_facts=dict(
        hardware=result))


# Generated at 2022-06-22 23:07:17.365784
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 30
    module.facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    module.run_command = MagicMock
    module.run_command.side_effect = run_command_mock

    hardware = HPUXHardware(module)

    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memfree_mb'] == 514
    assert memory_facts['memtotal_mb'] == 4769
    assert memory_facts['swapfree_mb'] == 0
    assert memory_facts

# Generated at 2022-06-22 23:07:28.928588
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_object = HPUXHardware(dict())
    test_object.module.run_command = lambda *args, **kwargs: (0, "", "")

# Generated at 2022-06-22 23:07:36.015824
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = type('', (), {})()
    test_module.run_command = lambda cmd, use_unsafe_shell=False, check_rc=False: (0, '', '')
    test_object = HPUXHardware()
    test_object.module = test_module
    test_cpu_facts = {'processor': 'Intel Itanium 2', 'processor_cores': 8, 'processor_count': 2}
    assert test_object.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}) == test_cpu_facts



# Generated at 2022-06-22 23:07:46.930337
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()
    assert 'processor_count' in hardware_obj.hw_facts
    assert 'processor' in hardware_obj.hw_facts
    assert 'memfree_mb' in hardware_obj.hw_facts
    assert 'memtotal_mb' in hardware_obj.hw_facts
    assert 'swaptotal_mb' in hardware_obj.hw_facts
    assert 'swapfree_mb' in hardware_obj.hw_facts
    assert 'model' in hardware_obj.hw_facts
    assert 'firmware_version' in hardware_obj.hw_facts
    assert 'product_serial' in hardware_obj.hw_facts

# Generated at 2022-06-22 23:07:49.053848
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    Test constructor
    """
    hw_hpux = HPUXHardware()
    assert hw_hpux.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:54.928073
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    objs = []
    objs.append(HPUXHardware(module))
    obj = HPUXHardware(module)
    CPU_FACTS = dict(processor='HP PA-RISC 2.0', processor_cores=2, processor_count=4)
    obj.populate_facts({'ansible_architecture': '9000/785'})
    CPU_FACTS.update(dict(memtotal_mb=8192, memfree_mb=3245, swapfree_mb=3072, swaptotal_mb=3072, model='9000/785', firmware_version='B1200A0', product_serial='J2298A'))
    assert obj.get_facts() == CPU_FACTS



# Generated at 2022-06-22 23:08:02.318935
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_obj = HPUXHardwareCollector({'platform': 'HP-UX'})
    # Collected facts
    collected_facts = {
        'platform': 'HP-UX',
        'ansible_distribution': 'HP-UX'
    }
    # Create an empty HPUXHardware object
    hpux_obj.fact_class = HPUXHardware
    hpux_hw_obj = hpux_obj.fact_class(module=None)
    hpux_hw_obj.get_cpu_facts = lambda: {
        'processor_count': 4,
        'processor': 'Intel(R) Itanium(R) Processor',
        'processor_cores': 4
    }

# Generated at 2022-06-22 23:08:08.384618
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts = set(['platform', 'distribution'])
    hw_collector = HPUXHardwareCollector('dummy_module')
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector.required_facts == required_facts

# Generated at 2022-06-22 23:08:19.167941
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_hw = HPUXHardware({})
    assert hpux_hw.populate() == HPUXHardware({}).populate()
    assert hpux_hw.populate().get('processor')
    assert hpux_hw.populate().get('processor_cores')
    assert hpux_hw.populate().get('processor_count')
    assert hpux_hw.populate().get('model')
    assert hpux_hw.populate().get('firmware')
    assert hpux_hw.populate().get('memfree_mb')
    assert hpux_hw.populate().get('memtotal_mb')
    assert hpux_hw.populate().get('swapfree_mb')
    assert hpux_hw.populate().get('swaptotal_mb')

# Generated at 2022-06-22 23:08:27.766468
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()

    hw_facts = hardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})

    assert hw_facts['model'] == 'IA64 HP Integrity BL860c i2'
    assert hw_facts['firmware_version'] == 'v4.0.0 (ERC_hdd_rsvd_bad_0)'
    assert hw_facts['product_serial'] == 'USCR9115VZ'


# Generated at 2022-06-22 23:08:40.197836
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpu_ux import HPUXHardware, HPUXHardwareCollector
    result = HPUXHardware().populate()
    if result['processor_count'] != 0:
        assert True
    if result['processor_cores'] != 0:
        assert True
    if result['processor'] != 0:
        assert True
    if result['memtotal_mb'] != 0:
        assert True
    if result['memfree_mb'] != 0:
        assert True
    if result['swaptotal_mb'] != 0:
        assert True
    if result['swapfree_mb'] != 0:
        assert True
    if result['model'] != 0:
        assert True
    if result['firmware_version'] != 0:
        assert True


# Generated at 2022-06-22 23:08:49.192919
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({})
    # test method hw.get_hw_facts() with collect_facts parameter {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    # Collected from an HP RX8640
    output = hw.get_hw_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert output['model'] == 'RX8640'
    assert output['firmware_version'] == '\x1b[1;1H0618.068.1B-676494.064-9-01-04-02\x1b[1;1H'

# Generated at 2022-06-22 23:09:02.680792
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts import FactCollector

    class DummyModule:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    # Simple test for HP-UX 11.11, 9000/800 machine with less than 128GB of RAM

# Generated at 2022-06-22 23:09:13.445446
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """Unit test for HPUXHardware._get_memory_facts"""
    hw = HPUXHardware(dict())

    hw.module.run_command = lambda x, shell=False: (1, "", "")
    assert hw.get_memory_facts(collected_facts=dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')) == {'swaptotal_mb': 0, 'swapfree_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}

    hw.module.run_command = lambda x, shell=False: (0, " ", "")

# Generated at 2022-06-22 23:09:16.756479
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_module = HPUXHardware({})
    assert hpux_module.populate()['memtotal_mb'] > 0
    assert hpux_module.populate()['firmware_version']


# Generated at 2022-06-22 23:09:18.887046
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert isinstance(hw, HPUXHardware)


# Generated at 2022-06-22 23:09:28.855906
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeModule({'ansible_facts':{'ansible_architecture':'9000/800', 'ansible_distribution_version':'B.11.31'}})
    class_mem = HPUXHardware(module)
    mem_facts = class_mem.get_memory_facts()
    assert mem_facts['memfree_mb'] == 105
    assert mem_facts['memtotal_mb'] == 2048
    assert mem_facts['swaptotal_mb'] == 2
    assert mem_facts['swapfree_mb'] == 2


# Generated at 2022-06-22 23:09:35.972301
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Unit test for constructor of class HPUXHardwareCollector"""

    # get info about available disks
    hpux_hardware_collector = HPUXHardwareCollector(module=None)

    assert hpux_hardware_collector.required_facts == set(['platform', 'distribution'])
    assert hpux_hardware_collector.platform == 'HP-UX'



# Generated at 2022-06-22 23:09:44.862331
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hardware = HPUXHardware(module=None, collected_facts=facts)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 4096
    assert facts['swaptotal_mb'] == 1500
    assert facts['memfree_mb'] == 3754
    assert facts['swapfree_mb'] == 0

    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware(module=None, collected_facts=facts)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 4096

# Generated at 2022-06-22 23:09:49.001136
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Test the HPUXHardwareCollector constructor."""
    module = AnsibleModule({})
    hardware_collector = HPUXHardwareCollector(module)
    assert hardware_collector._fact_class == HPUXHardware


# Generated at 2022-06-22 23:09:52.072719
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert hasattr(h, '_fact_class')
    assert hasattr(h, '_platform')

# Generated at 2022-06-22 23:09:54.018334
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {}
    facts['platform'] = 'HP-UX'
    facts['distribution'] = 'HP-UX'
    hpux = HPUXHardwareCollector(facts)
    assert hpux._platform == 'HP-UX'
    assert hpux.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-22 23:10:05.046156
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {'ansible_architecture': 'ia64'}
    hw = HPUXHardware(None)
    assert hw.get_cpu_facts(collected_facts) == {
        'processor': 'Intel(R) Itanium(R) Processor 9340',
        'processor_cores': 24,
        'processor_count': 2,
    }
    assert hw.get_memory_facts(collected_facts) == {
        'memfree_mb': 3589,
        'memtotal_mb': 10157,
        'swapfree_mb': 4321,
        'swaptotal_mb': 4321,
    }

    collected_facts = {'ansible_architecture': '9000/785'}

# Generated at 2022-06-22 23:10:12.005171
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware_facts = HPUXHardware()
    hardware_facts.module.run_command = lambda *args, **kwargs: (0, 'HP-UX Test machine B.11.31 U ia64 2973754847 unlimited-user license', '')
    facts = hardware_facts.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX'})
    assert facts['model'] == 'Test machine'
    assert facts['firmware_version'] == 'B.11.31'
    assert facts['product_serial'] == '2973754847'


# Generated at 2022-06-22 23:10:16.677816
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = type('TestModule', (), {})
    test_module.run_command = lambda x: (0, '', '')
    test_instance = HPUXHardware(test_module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    test_instance.get_memory_facts(collected_facts)

# Generated at 2022-06-22 23:10:28.140943
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    instance = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    memory_facts = instance.get_memory_facts(collected_facts=collected_facts)
    cpu_facts = instance.get_cpu_facts(collected_facts=collected_facts)
    hw_facts = instance.get_hw_facts(collected_facts=collected_facts)
    hardware_facts = instance.populate(collected_facts=collected_facts)


# Generated at 2022-06-22 23:10:38.013501
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """This unit test checks if the required attributes are present in constructor
    of class HPUXHardwareCollector.
    """
    from ansible.module_utils.facts.hardware.hpux import HPUXHardwareCollector
    global obj
    obj = HPUXHardwareCollector()
    assert (hasattr(obj, '_fact_class') and callable(getattr(obj, '_fact_class')))
    assert (hasattr(obj, '_platform') and callable(getattr(obj, '_platform')))
    assert (hasattr(obj, 'required_facts') and callable(getattr(obj, 'required_facts')))



# Generated at 2022-06-22 23:10:46.132434
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    hpux = HPUXHardware(data)
    facts = hpux.get_cpu_facts()
    assert facts['processor_cores'] == 16
    assert facts['processor_count'] == 16
    assert facts['processor'] == 'Intel(R) Xeon(R) CPU E7-4809'

# Generated at 2022-06-22 23:10:57.500731
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list')
        }
    )
    result = HPUXHardware(test_module).populate()
    assert result.get('processor_count')
    assert result.get('processor')
    assert result.get('processor_cores')
    assert result.get('memfree_mb')
    assert result.get('memtotal_mb')
    assert result.get('swapfree_mb')
    assert result.get('swaptotal_mb')
    assert result.get('model')
    assert result.get('firmware_version')
    assert result.get('product_serial')


# Generated at 2022-06-22 23:10:58.806479
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:11:02.296322
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector.platform == 'HP-UX'

# Generated at 2022-06-22 23:11:14.689153
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware(None)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    hw.get_memory_facts = lambda: {'memtotal_mb': 4096}
    hw.get_hw_facts = lambda: {'model': 'ia64', 'firmware_version': '11.23-igel-144'}
    hw.get_cpu_facts = lambda: {'processor_count': 1}

    result = hw.populate(collected_facts)

    assert result['memtotal_mb'] == 4096
    assert result['model'] == 'ia64'
    assert result['firmware_version'] == '11.23-igel-144'

# Generated at 2022-06-22 23:11:20.549932
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = MockModule()
    facts = HPUXHardware(module).get_memory_facts()
    assert facts['memfree_mb'] == 'Mocked memfree_mb'
    assert facts['memtotal_mb'] == 'Mocked memtotal_mb'
    assert facts['swaptotal_mb'] == 'Mocked swaptotal_mb'
    assert facts['swapfree_mb'] == 'Mocked swapfree_mb'



# Generated at 2022-06-22 23:11:29.232905
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hpux_facter = HPUXHardware(module)
    _mock_collected_facts = {'ansible_architecture': '9000/800',
                             'ansible_distribution_version': 'B.11.31'}

    memory_facts = hpux_facter.get_memory_facts(collected_facts=_mock_collected_facts)
    assert memory_facts == {'memfree_mb': 149, 'memtotal_mb': 732}



# Generated at 2022-06-22 23:11:38.783237
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    HPUXHardware.get_hw_facts() returns a hw_facts dict
    """
    collected_facts = {
        'platform': 'HP-UX',
        'architecture': 'ia64',
        'distribution': 'HP-UX',
        'distribution_version': 'B.11.23'
    }
    test_obj = HPUXHardware(module=None, collected_facts=collected_facts)
    hw_facts = test_obj.get_hw_facts()
    assert hw_facts == {
        'model': 'rp7410',
        'firmware_version': 'B.11.23',
        'product_serial': 'abc12345'
    }


# Generated at 2022-06-22 23:11:51.553839
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module)
    module.run_command = MagicMock()

    # No error
    mock_run_command = Mock(return_value=(0, '\n2048', ''))
    module.run_command.side_effect = mock_run_command

    # No error, no model in syslog
    mock_run_command = Mock(return_value=(0, '', ''))
    module.run_command.side_effect = mock_run_command

    # Error : machinfo doesn't exist
    mock_run_command = Mock(return_value=(0, '', "machinfo : not found"))
    module.run_command.side_effect = mock_run_command

    # Collected facts and facts for machine version B.11.23

# Generated at 2022-06-22 23:11:57.919682
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    my_host = HPUXHardware()
    collected_facts = {
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    cpu_facts = my_host.get_hw_facts(collected_facts=collected_facts)
    assert not cpu_facts.get('product_serial')
    collected_facts = {
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23'
    }
    cpu_facts = my_host.get_hw_facts(collected_facts=collected_facts)
    assert not cpu_facts.get('product_serial')



# Generated at 2022-06-22 23:12:09.188512
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock(
        dict(
            ansible_architecture='9000/800'
        ),
        dict(
            changed=False,
            ansible_facts={'hw_HPUX': {'firmware_version': 'N/A',
                                       'model': '9000/800/C8000',
                                       'memory_mb': {'memfree_mb': 15,
                                                     'memtotal_mb': 230,
                                                     'swapfree_mb': 139,
                                                     'swaptotal_mb': 256},
                                       'cpu': {'processor_cores': 8,
                                               'processor_count': 8,
                                               'processor': '9000/800'}}}
        )
    )

    hw_HPUX = HPUXHardware()
   

# Generated at 2022-06-22 23:12:19.817053
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_module = HPUXHardware()
    hw_facts = hpux_module.populate()
    assert hw_facts['memfree_mb'] is not None
    assert hw_facts['memtotal_mb'] is not None
    assert hw_facts['swapfree_mb'] is not None
    assert hw_facts['swaptotal_mb'] is not None
    assert hw_facts['processor'] is not None
    assert hw_facts['processor_count'] is not None
    assert hw_facts['processor_cores'] is not None

    # For some systems, like the HP C-Class BladeSystem, the processor_* facts don't exist
    # because the memory is spread across all blades:

# Generated at 2022-06-22 23:12:28.985661
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = mock.Mock()
    module.run_command.side_effect = [
        (0, 'HP Integrity rx2600 Server', ''),
        (0, 'B.11.00 HP-UX', ''),
        (0, 'Firmware revision: 2.0', ''),
        (0, 'Machine serial number: US123456', '')
    ]
    hardware = HPUXHardware(module)
    hardware.get_hw_facts()

    assert module.run_command.call_count == 4


# Generated at 2022-06-22 23:12:40.768713
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Test get_memory_facts method
    """
    class MockModule():
        def __init__(self):
            self.distribution = 'HP-UX'
        def run_command(self, cmd, use_unsafe_shell=False):
            if use_unsafe_shell:
                if cmd.split("|")[0].strip() == "/usr/bin/vmstat" and cmd.split("|")[2].strip() == "tail -1":
                    return 0, "memfree 100", ""
                elif "machinfo" in cmd:
                    if "grep Memory" in cmd:
                        return 0, "Memory     : 4095MB", ""
                    elif "grep 'Firmware revision'" in cmd:
                        return 0, "Firmware revision : v3.10", ""

# Generated at 2022-06-22 23:12:47.447291
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class HPUXHardware"""

    # Define collected facts
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }

    # Build object
    hp_ux_hc = HPUXHardware()

    # Test regular case
    ia64_cpu_facts = hp_ux_hc.get_cpu_facts(collected_facts)
    assert ia64_cpu_facts['processor'] == 'Intel(R) Itanium(R) 9560'
    assert ia64_cpu_facts['processor_cores'] == 4


# Generated at 2022-06-22 23:12:48.488230
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    assert issubclass(HPUXHardware, Hardware)
    assert HPUXHardware().platform == 'HP-UX'

# Generated at 2022-06-22 23:12:50.492434
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({})
    assert hardware.facts == {}



# Generated at 2022-06-22 23:13:00.768800
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Create a class instance
    hardware_obj = HPUXHardware()
    hardware_obj.module = None

# Generated at 2022-06-22 23:13:05.988638
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware()
    assert h.platform == 'HP-UX'
    assert h.get_memory_facts()['memfree_mb'] >= 0
    assert h.get_memory_facts()['swaptotal_mb'] >= 0


# Generated at 2022-06-22 23:13:16.840244
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command_mock_returns_command
    h = HPUXHardware(module, 'HP-UX')

    # Test HP-UX on PA-RISC
    expected_cpu_facts = {'processor_count': 16}
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = h.get_cpu_facts(collected_facts)
    assert cpu_facts == expected_cpu_facts

    # Test HP-UX on Itanium
    expected_cpu_facts = {'processor': 'Intel(R) Itanium(R) Processor 9500 series', 'processor_count': 4, 'processor_cores': 4}

# Generated at 2022-06-22 23:13:20.485903
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert isinstance(hardware_collector, HardwareCollector)
    assert hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:13:33.034048
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    out = '{"ansible_facts": {"ansible_architecture": "9000/800",' \
          '"hardware": {"firmware_version": "", "model": "9000/800", "memfree_mb": 1201, "memtotal_mb": 128, "swapfree_mb": 98, "swaptotal_mb": 128},' \
          '"processor": "", "processor_cores": 0, "processor_count": 1}}'
    h = HPUXHardware()
    h.module = FakeModule()
    collected_facts = {"ansible_architecture": "9000/800", "ansible_distribution": "HP-UX", "ansible_distribution_version": "B.11.31"}
    result = h.populate(collected_facts)

# Generated at 2022-06-22 23:13:38.755126
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({})
    hardware = HPUXHardware(module)
    facts = hardware.populate()
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'model' in facts
    assert 'firmware' in facts



# Generated at 2022-06-22 23:13:42.077520
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = None
    hardware = HPUXHardware(module)
    assert hardware.platform == 'HP-UX'
    assert hardware.required_facts == set([])


# Generated at 2022-06-22 23:13:51.058976
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware(dict())
    cpu_facts = hw.get_cpu_facts({'ansible_architecture': '9000/800'})
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] is None
    assert cpu_facts['processor'] is None
    cpu_facts = hw.get_cpu_facts({'ansible_architecture': 'ia64'})
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0
    assert cpu_facts['processor'] is not None


# Generated at 2022-06-22 23:14:02.811086
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    if not HAS_PLATFORM:
        module.fail_json(msg='platform required for this module')

    hw = HPUXHardware(module=module)
    hw.populate()

    # Test for processor fact
    assert hw.ansible_facts['processor'] == 'Intel(R) Itanium(R) Processor 9150'

    # Test for processor_cores fact
    assert hw.ansible_facts['processor_cores'] == 4

    # Test for memtotal_mb fact
    assert hw.ansible_facts['memtotal_mb'] == 16384

    # Test for memfree_mb fact
    assert hw.ansible_facts['memfree_mb'] == 14695

    #

# Generated at 2022-06-22 23:14:10.178480
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hw_collector = HPUXHardwareCollector()
    assert hpux_hw_collector
    assert isinstance(hpux_hw_collector, HardwareCollector)
    assert hpux_hw_collector._fact_class == HPUXHardware
    assert hpux_hw_collector._platform == 'HP-UX'
    assert hpux_hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:14:22.016175
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    har = HPUXHardware()
    # Test for OS release B.11.23
    module.run_command = MagicMock(return_value=(0, '2', ''))
    collected_facts = dict(platform='HP-UX', distribution='B.11.23')
    cpu_facts = har.get_cpu_facts(collected_facts)
    assert cpu_facts == dict(processor_count=2)
    # Test for OS release B.11.31
    module.run_command = MagicMock(return_value=(0, '2', ''))
    collected_facts = dict(platform='HP-UX', distribution='B.11.31', architecture='ia64')
    cpu_facts = har.get_cpu_facts(collected_facts)
    assert cpu_facts