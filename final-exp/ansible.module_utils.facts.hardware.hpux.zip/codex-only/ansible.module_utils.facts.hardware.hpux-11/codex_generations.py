

# Generated at 2022-06-22 23:04:11.749804
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwx = HPUXHardwareCollector()
    assert isinstance(hwx, HardwareCollector)

# Generated at 2022-06-22 23:04:24.207840
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_obj = HPUXHardware()
    facts = {}
    facts['ansible_architecture'] = 'ia64'
    facts['ansible_distribution_version'] = 'B.11.31'
    out = hw_obj.get_hw_facts(collected_facts=facts)
    assert out.get('model') == 'ia64 hp server rx8620'
    assert out.get('product_serial') == 'CZC03773VZ'
    assert out.get('firmware_version') == 'v2.33'
    # Test with architecture 9000/785
    facts['ansible_architecture'] = '9000/785'
    out = hw_obj.get_hw_facts(collected_facts=facts)

# Generated at 2022-06-22 23:04:34.849144
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = type('MockModule', (), dict(params=dict(), run_command=lambda x: (0, '', '')))()
    module.architecture = 'ia64'
    module.distribution_version = 'B.11.31'

    hw = HPUXHardware()
    hw.module = module
    hw.populate()
    assert hw.memtotal_mb == 32768
    assert hw.memfree_mb == 1485
    assert hw.swaptotal_mb == 256
    assert hw.swapfree_mb == 256
    assert hw.processor_cores == 16
    assert hw.processor_count == 1
    assert hw.processor == 'Intel Haswell'
    assert hw.firmware_version == '01.12.01 (Sep 10 2015)'

# Generated at 2022-06-22 23:04:42.611892
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Instantiate AnsibleModule mock object
    module = AnsibleModule(argument_spec={})

    # Instantiate HPUXHardware mock object
    hw = HPUXHardware(module)

    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': "B.11.31"
    }


# Generated at 2022-06-22 23:04:47.854177
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector()
    assert hardware.platform == 'HP-UX'
    assert hardware.fact_class == HPUXHardware
    assert hardware.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-22 23:04:54.973970
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """ Tests if HPUXHardwareCollector can be instantiated """
    from ansible.module_utils.facts.hardware.hpux import HPUXHardwareCollector
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    obj = HPUXHardwareCollector()
    assert obj
    assert isinstance(obj, HPUXHardwareCollector)
    assert isinstance(obj._fact_class(), HPUXHardware)



# Generated at 2022-06-22 23:04:59.255310
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)
    hardware = HPUXHardware(module)

    hardware.populate()

# Generated at 2022-06-22 23:05:02.642257
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUXHardware.platform = "HP-UX"
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()
    assert hardware.facts is not None

# Generated at 2022-06-22 23:05:15.954964
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m = HPUXHardware({})
    facts = m.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert facts['processor_count'] == 1
    assert facts['processor_cores'] == 1
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor 9500 Series'

    facts = m.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert facts['processor_count'] == 4
    assert facts['processor_cores'] == 4
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor 9100 series'


# Generated at 2022-06-22 23:05:28.175464
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hpux import Hardware, HPUXHardware, HPUXHardwareCollector
    from ansible.module_utils.facts import FactCollector

# Generated at 2022-06-22 23:05:37.465088
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    collected_facts = {
        'ansible_architecture': 'parisc',
        'ansible_distribution_version': 'B.11.23',
    }
    hpux_hardware = HPUXHardware(module)
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor'] == 'Intel Itanium Processor Family'
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor_count'] == 16



# Generated at 2022-06-22 23:05:46.344563
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    a = HPUXHardware()
    # test for ia64 B.11.31 > 1204
    platform = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    rc, out, err = a.module.run_command("echo '123456789: 234567890' | /usr/sbin/psrset -v")
    rc, out, err = a.module.run_command("   "
                                        "Physical    Kbytes     RT        NPT    HPPT       Res   Pages   Lock\n"
                                        ":  10188160        0  10188160  10188160   4025296      0 1331456    0")
    mem_facts = a.get_memory_facts(platform)

# Generated at 2022-06-22 23:05:50.938570
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = type('module', (object,), {'run_command': run_command})()
    test_module.run_command = run_command
    test_class = HPUXHardware(module=test_module)
    test_facts = {'ansible_architecture': '9000/800'}
    test_class.populate(collected_facts=test_facts)
    print(test_class.get_cpu_facts(collected_facts=test_facts))
    assert test_class.get_cpu_facts(collected_facts=test_facts)['processor_count'] == 8
    test_facts = {'ansible_architecture': '9000/785'}
    test_class.populate(collected_facts=test_facts)

# Generated at 2022-06-22 23:05:58.085260
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec={},
    )

    # Patch module and exit json
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.exit_json = MagicMock()

    # We have to do this one additional layer deep to allow for the __init__ to be called
    # See https://stackoverflow.com/questions/35166576/typeerror-issubclass-of-type-which-is-not-a-class-or-tuple-on-python-3
    hardware = HPUXHardwareCollector._fact_class()
    hardware.populate()

# Generated at 2022-06-22 23:06:00.590457
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:06:06.415319
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hwinfo = HPUXHardware(module)
    facts = hwinfo.get_hw_facts()
    assert facts['model'] == '9000/800/L2000-64'
    assert facts['firmware_version'] == 'B.11.00'
    assert facts['product_serial'] == 'SGH3235AKL'



# Generated at 2022-06-22 23:06:18.152936
# Unit test for constructor of class HPUXHardware

# Generated at 2022-06-22 23:06:29.609224
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hardware.get_memory_facts(collected_facts=collected_facts)
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23'
    }
    hardware.get_memory_facts(collected_facts=collected_facts)
    collected_facts = {
        'ansible_architecture': '9000/785',
        'ansible_distribution_version': 'B.11.23'
    }

# Generated at 2022-06-22 23:06:41.605610
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_collector = HPUXHardwareCollector()
    hardware_object = hardware_collector.collect()

    required_facts = hardware_collector.required_facts
    optional_facts = hardware_collector.optional_facts
    hardware_facts = hardware_object.populate(collected_facts={'platform': 'HP-UX', 'distribution': 'B.11.23'})
    # Test required facts
    for fact in required_facts:
        assert fact in hardware_facts
    # Test optional facts, which are not None
    for fact in optional_facts:
        assert fact in hardware_facts
        assert hardware_facts[fact] is not None

    # Test same platform and version again, but with some other facts provided

# Generated at 2022-06-22 23:06:51.972298
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Need to mock:
    #  - module.run_command()
    #  - os.access()
    # Before running the test method.
    meminfo_stub = {'k': '0', 'p': '0', 'w': '0', 'm': '0', 'o': '0', 'f': '11', 'sf': '0', 'si': '0'}
    swpinfo_stub = {'dev': '/dev/vg00/lvol1', 'total': '0k', 'used': '0k', 'avail': '102400k', 'capacity': '0%', 'fs': '/home', 'total': '102400k', 'used': '0k', 'avail': '102400k', 'capacity': '0%'}

# Generated at 2022-06-22 23:06:52.988452
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    inst = HPUXHardware()
    assert isinstance(inst, HPUXHardware)


# Generated at 2022-06-22 23:06:58.474872
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    hardware.module = MockModuleHP()

    rc, out, err = hardware.module.run_command("uname -m")
    facts = {'ansible_architecture': out.strip()}
    rc, out, err = hardware.module.run_command("uname -r")
    facts['ansible_distribution_version'] = out.strip()

    cpu_facts = hardware.get_cpu_facts(collected_facts=facts)
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 4



# Generated at 2022-06-22 23:07:11.306191
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import sys
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.modules.system.hardware import hardware_hpux

    class MockModule(object):
        def __init__(self):
            self.run_command = MockModule.run_command
            self.fail_json = MockModule.fail_json

        @staticmethod
        def run_command(cmd, use_unsafe_shell=None):
            if to_text(cmd, errors='surrogate_then_replace') == to_text(b'/usr/bin/vmstat | tail -1', errors='surrogate_then_replace'):
                return 0, to_

# Generated at 2022-06-22 23:07:12.952932
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert x is not None

# Generated at 2022-06-22 23:07:19.836684
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hphw = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    cpu_facts = hphw.get_cpu_facts(collected_facts=collected_facts)
    assert(cpu_facts['processor_cores'] == 8)

# Generated at 2022-06-22 23:07:31.126412
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # This test is use only for B.11.23 IA64 HP-UX
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    testHPUXHardware = HPUXHardware()
    testHPUXHardware.module = MockModule()
    cpu_fact = testHPUXHardware.get_cpu_facts(collected_facts)
    assert cpu_fact['processor_count'] == 4
    assert cpu_fact['processor'] == 'Intel Itanium 2'
    assert cpu_fact['processor_cores'] == 8

    # This test is use only for B.11.31 IA64 HP-UX

    # No hyperthreading

# Generated at 2022-06-22 23:07:42.414159
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = FakeAnsibleModule()
    hpux_hw = HPUXHardware(module=module)

    hpux_hw_facts = hpux_hw.populate()
    assert hpux_hw_facts['processor_count'] == 4
    assert hpux_hw_facts['processor'] == 'Intel(R) Itanium(R) Processor 9350'
    assert hpux_hw_facts['processor_cores'] == 8
    assert hpux_hw_facts['memtotal_mb'] == 8192
    assert hpux_hw_facts['memfree_mb'] == 7628
    assert hpux_hw_facts['swaptotal_mb'] == 3072
    assert hpux_hw_facts['swapfree_mb'] == 456

# Generated at 2022-06-22 23:07:54.187210
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts import hardware
    hardware._MEMORY_FACTS = {}
    hardware._MEMORY_FACTS['ansible_architecture'] = '9000/800'
    hardware._MEMORY_FACTS['ansible_memtotal_mb'] = 0
    hardware._MEMORY_FACTS['ansible_swaptotal_mb'] = 0
    hardware._MEMORY_FACTS['ansible_swapfree_mb'] = 0
    hpu_hw = HPUXHardware()
    memory_facts = hpu_hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] ==  4096
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0

# Generated at 2022-06-22 23:07:59.893455
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware_collector = HPUXHardwareCollector(module=module)
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware = HPUXHardware("test_host", harware_collector, collected_facts=collected_facts)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['memfree_mb'] > 0



# Generated at 2022-06-22 23:08:12.957913
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    hpux_hw = HPUXHardware(module)

    collected_facts = {
        "ansible_architecture": "9000/800",
        "ansible_distribution_version": "B.11.31"
    }

# Generated at 2022-06-22 23:08:21.971194
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    ''' Unit test for method get_memory_facts of class HPUXHardware '''

    # Create test object
    hpux_hardware_obj = HPUXHardware()

    # Test case for success
    # get_memory_facts() is dependent on get_hw_facts() and get_cpu_facts()
    # get_cpu_facts() returns only one value
    # get_hw_facts() return empty dictionary
    hpux_hardware_obj.get_cpu_facts = MagicMock(return_value={'processor_count': 2})
    hpux_hardware_obj.get_hw_facts = MagicMock(return_value={})

# Generated at 2022-06-22 23:08:33.613035
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Unit test for method get_cpu_facts of class HPUXHardware
    collected_facts_cpu = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23', 'ansible_distribution': 'hp'}
    test_HPUXHardware = HPUXHardware()
    test_HPUXHardware.module = MockModule()
    result_populate = {'processor': 'Intel Itanium 2'}
    result_populate.update(test_HPUXHardware.get_memory_facts())
    result_populate.update(test_HPUXHardware.get_hw_facts())
    test_HPUXHardware.populate(collected_facts_cpu)
    assert test_HPUXHardware.fact == result_populate

# Generated at 2022-06-22 23:08:46.445192
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpuxtestdata import hpuxtestdata as TestFacts
    hpuxtestdata = TestFacts()
    hw = HPUXHardware()
    hw.populate(hpuxtestdata.COLLECTED_HPUX_FACTS)
    assert hw.memfree_mb == 7008
    assert hw.memtotal_mb == 7680
    assert hw.swapfree_mb == 0
    assert hw.swaptotal_mb == 0
    assert hw.processor == "Intel(R) Itanium(R) Processor 9340"
    assert hw.processor_cores == 4
    assert hw.processor_count == 2
    assert hw.model == "ia64 hp Integrity rx8620"
    assert hw.f

# Generated at 2022-06-22 23:08:53.548074
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class ModuleMock:
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
            self.run_command_result_counter = -1
        def run_command(self, args, **kwargs):
            self.run_command_calls.append((args, kwargs))
            self.run_command_result_counter += 1
            return self.run_command_results[self.run_command_result_counter]

    # Memory facts are tested in test_HPUXHardware_get_memory_facts

    # Test with B.11.23
    module = ModuleMock()

# Generated at 2022-06-22 23:08:57.434983
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.__class__.__name__ == 'HPUXHardwareCollector'


# Generated at 2022-06-22 23:09:03.663619
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mem_facts = HPUXHardware.get_memory_facts({'ansible_architecture': '9000/800'})
    assert mem_facts['memtotal_mb'] > 0
    assert mem_facts['memfree_mb'] > 0
    assert mem_facts['swaptotal_mb'] > 0
    assert mem_facts['swapfree_mb'] > 0


# Generated at 2022-06-22 23:09:11.943960
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = FakeAnsibleModule()
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    h = HPUXHardware(module, facts)
    assert h.platform == 'HP-UX'
    assert h.subplatform == 'HP-UX'
    assert h.get_cpu_facts()['processor_count'] == 1
    h.get_memory_facts()
    h.get_hw_facts()
    h.populate()
    assert h.platform == 'HP-UX'



# Generated at 2022-06-22 23:09:12.956931
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:09:18.147322
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Unit test for constructor of class HPUXHardwareCollector"""
    result = HPUXHardwareCollector()
    assert type(result) is HPUXHardwareCollector
    assert result._fact_class == HPUXHardware
    assert result._platform == 'HP-UX'
    assert result.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:09:30.880976
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hardware_collector = module.collector

    '''
    facter_data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_release': 'B.11.31',
        'ansible_distribution_version': 'B.11.31'}
    hardware_collector.collect(facter_data)
    '''
    facter_data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_release': 'B.11.31',
        'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-22 23:09:34.181702
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec=dict())

    har = HPUXHardware(module)

    assert har
    assert har.collect() is not None

# Generated at 2022-06-22 23:09:36.487742
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    my_obj = HPUXHardwareCollector
    assert my_obj is not None

# Generated at 2022-06-22 23:09:43.670949
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    # Create a instance of HPUXHardware
    hpux_hw = HPUXHardware(module=module)

    # Get facts from module_utils
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/785'

    # Check the facts
    hpux_hw.populate(collected_facts=collected_facts)


# Generated at 2022-06-22 23:09:45.899247
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector('module')
    hardware_collector.get_all_facts()

# Generated at 2022-06-22 23:09:55.373397
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware({}, dict(platform='HP-UX', ansible_architecture='9000/800'))
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    populated_facts = hardware.populate(collected_facts=collected_facts)

    assert populated_facts['processor_count'] == 1
    assert populated_facts['memtotal_mb'] == 8192
    assert populated_facts['processor'] == 'PA-RISC 1.1'


# Generated at 2022-06-22 23:09:59.806044
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw
    assert hw.platform == 'HP-UX'
    assert hw.get_cpu_facts() == {}
    assert hw.get_memory_facts() == {}
    assert hw.get_hw_facts() == {}

# Generated at 2022-06-22 23:10:01.372564
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Create an instance of HPUXHardwareCollector
    hw = HPUXHardwareCollector()
    # Assert that _fact_class is HPUXHardware
    assert hw._fact_class is HPUXHardware

# Generated at 2022-06-22 23:10:06.182174
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({})
    h = HPUXHardwareCollector()
    data = h.populate()
    assert data['processor'] == 'Intel(R) Itanium(R) 9300 series'
    assert data['processor_cores'] == 8
    assert data['processor_count'] == 2
    assert data['memtotal_mb'] == 4096
    assert data['swaptotal_mb'] == 52713
    assert data['model'] == 'ia64 hp Integrity rx6600'
    assert data['firmware_version'] == '2.05'
    assert data['memfree_mb'] == 2153


# Generated at 2022-06-22 23:10:16.541060
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts({'ansible_architecture': '9000/800'})
    assert cpu_facts['processor_count'] == 2
    cpu_facts = hardware.get_cpu_facts({'ansible_architecture': '9000/785'})
    assert cpu_facts['processor_count'] == 2
    cpu_facts = hardware.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert cpu_facts['processor'] == 'Intel(r) Itanium(r) Processor 9100 series'
    assert cpu_facts['processor_cores'] == 8

# Generated at 2022-06-22 23:10:19.639368
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpx_hw_collector = HPUXHardwareCollector()
    assert isinstance(hpx_hw_collector._fact_class, HPUXHardware)

# Generated at 2022-06-22 23:10:30.151400
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h = HPUXHardware()

    # Test on system with architecture 9000/800
    collected_facts = dict()
    collected_facts['ansible_architecture'] = '9000/800'
    cpu_facts = h.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1

    # Test on system with architecture 9000/785
    collected_facts = dict()
    collected_facts['ansible_architecture'] = '9000/785'
    cpu_facts = h.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1

    # Test on system with architecture ia64
    collected_facts = dict()
    collected_facts['ansible_architecture'] = 'ia64'
   

# Generated at 2022-06-22 23:10:41.476279
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.six import string_types

    test_hardware = HPUXHardware()
    test_hardware.module = BaseFactCollector()

    def test_run_command(self, args, check_rc=True, close_fds=True, executable=None,
                         data=None, binary_data=False, path_prefix=None, cwd=None,
                         use_unsafe_shell=False):
        res = ""

# Generated at 2022-06-22 23:10:44.614759
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert isinstance(h, HPUXHardware)


# unit test for get_cpu of class HPUXHardware

# Generated at 2022-06-22 23:10:56.883962
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hux import HPUXHardware
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock

    facts = {
             "ansible_architecture": "9000/800",
             "ansible_distribution_version": "B.11.23"
            }
    h = HPUXHardware(Mock(return_value=facts))
    cpu_facts = h.get_cpu_facts()

    assert 'processor_count' in cpu_facts and cpu_facts['processor_count'] == 2
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts and cpu_facts['processor_cores'] == 2


# Generated at 2022-06-22 23:11:07.459742
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    '''
    Test for memory facts for HPUXHardware class
    '''
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, '', ''))
    hw_obj = HPUXHardware(module)
    expected_results = {'memtotal_mb': '16384',
                        'memfree_mb': '8192',
                        'swaptotal_mb': '3072',
                        'swapfree_mb': '2048'}
    results = hw_obj.get_memory_facts()
    assert expected_results == results, 'Test failed'


# Generated at 2022-06-22 23:11:10.355087
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    # Test hp-ux platform
    hpuxhw = HPUXHardwareCollector({'platform': 'HP-UX', 'distribution': 'HP-UX'})
    # On testing hpuxhw object instance must be created of class HPUXHardwareCollector
    assert isinstance(hpuxhw, HPUXHardwareCollector), 'hpuxhw object should be instance of HPUXHardwareCollector'

# Generated at 2022-06-22 23:11:21.004819
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list', default=['!all', '!min'])),
    )
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23',
    }
    hpux_hardware = HPUXHardware(module)
    assert hpux_hardware.get_cpu_facts(collected_facts) == {
        'processor_count': 4
    }

    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
    }
    hpux_hardware = HPUXHardware(module)
    result = hpux_hard

# Generated at 2022-06-22 23:11:30.435841
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Input data
    data_out_vmstat = """
procs                            memory              page              disk         faults                cpu
r   b   w   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st
1   0   0      0 6272616  61152 236468    0    0    93    80    2    1  2  0 98  0  0
"""
    data_out_swapinfo = """
device             total uses   free (MB) (MB) (MB)
/dev/vg00/lvol3    8191     0   8191
"""

# Generated at 2022-06-22 23:11:31.577137
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert x

# Generated at 2022-06-22 23:11:38.599049
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_collector = HPUXHardwareCollector(module)
    hardware = HPUXHardware(hardware_collector)
    module.run_command = MagicMock()
    module.run_command.side_effect = [
        (0, "ia64", ""),
        (0, "Model: 9000/785/B8000", ""),
        (0, "Firmware Revision: \tR.12.0", ""),
        (0, "Machine Serial Number:\tUS123456789", ""),
    ]
    hardware_facts = hardware.get_hw_facts()
    assert hardware_facts['model'] == "9000/785/B8000"
    assert hardware_facts['firmware_version'] == "R.12.0"
    assert hardware_

# Generated at 2022-06-22 23:11:42.502078
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # test
    hardware = HPUXHardware()
    data = hardware.get_hw_facts()
    assert data['model']
    assert data['firmware_version'] 
    assert data['product_serial']

# Generated at 2022-06-22 23:11:53.778960
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hpux_module.params = {}

    true = True
    false = False
    null = None
    product_serial = 'SOMEPRODUCTSERIAL'
    # This is a mock out of dictionary where keys are facts and value are the answers

# Generated at 2022-06-22 23:11:58.423543
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({'platform': 'HP-UX', 'distribution_version': 'B.11.23'})
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == HPUXHardwareCollector.required_facts


# Generated at 2022-06-22 23:12:01.873480
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = type('', (object,), {})
    module.run_command = run_command
    module.params = {}
    hardware = HPUXHardware(module)
    hardware.populate()



# Generated at 2022-06-22 23:12:10.803582
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    class MockModule(object):
        def run_command(self, cmd, check_rc=True, use_unsafe_shell=False):
            if cmd == 'model':
                return 0, "HP rp8420", ""
            if cmd == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC":
                return 0, "Firmware revision                                =     B.11.23.03", ""
            if cmd == "/usr/contrib/bin/machinfo |grep -i 'Machine serial number' ":
                return 0, "Machine serial number                            = USR44529QS", ""


# Generated at 2022-06-22 23:12:12.254083
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUXHardwareCollector.collect()



# Generated at 2022-06-22 23:12:20.460915
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    processor_count = 2
    processor = "Intel(R) Itanium(R) processor II"
    processor_cores = 2
    # test for 32bit systems
    collected_facts = {'ansible_architecture': '9000/800'}
    hw_obj = HPUXHardware(module=None)
    cpu_facts = hw_obj.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == processor_count
    # test for ia64 systems
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version':'B.11.23'}
    hw_obj = HPUXHardware(module=None)
    cpu_facts = hw_obj.get_cpu_facts(collected_facts)
   

# Generated at 2022-06-22 23:12:27.079007
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    HPUXHardware_get_cpu_facts = HPUXHardware().get_cpu_facts(collected_facts={})
    assert(HPUXHardware_get_cpu_facts['processor'] == 'Intel(R) Itanium(R) processor')
    assert(HPUXHardware_get_cpu_facts['processor_count'] == 2)
    assert(HPUXHardware_get_cpu_facts['processor_cores'] == 24)

# Generated at 2022-06-22 23:12:28.128934
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    HPUXHardware()

# Generated at 2022-06-22 23:12:35.561157
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False)
    hw_facts = {'ansible_architecture': 'ia64',
                'ansible_distribution_version': 'B.11.31'}
    hw_collector = HPUXHardwareCollector(module=module, facts=hw_facts)
    assert hw_collector.facts == hw_facts

# Generated at 2022-06-22 23:12:44.724042
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Provide some test data
    return_values = {
        'ansible_architecture': '9000/800',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
        'ansible_distribution_version': 'B.11.23'
    }
    return_strings = {
        "vmstat": "16777216",
        "grep": "Physical: 16777216 Kbytes",
        "echo": "67108864",
        "swapinfo": "16777216",
        "machinfo": "Memory: 2147483648 total",
        "adb": "16777216"
    }

# Generated at 2022-06-22 23:12:54.667596
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    # Check if facts has expected keys
    hardware = HPUXHardware(module)
    hw_facts = hardware.populate()
    keys = [
        'memfree_mb',
        'memtotal_mb',
        'swapfree_mb',
        'swaptotal_mb',
        'processor',
        'processor_cores',
        'processor_count',
        'firmware_version',
        'product_serial',
        'model'
    ]
    assert set(keys).issubset(hw_facts)

# Generated at 2022-06-22 23:12:57.341750
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict())
    print(repr(hw))
    assert hw.facts == {}
    assert hw.module is None


# Generated at 2022-06-22 23:13:05.524707
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = FakeModule({'ansible_architecture': 'ia64'})
    facts = HPUXHardware(module).populate()
    assert facts['processor_cores'] == 2
    assert facts['processor_count'] == 2
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor 9310'

    module = FakeModule({'ansible_architecture': '9000/800'})
    facts = HPUXHardware(module).populate()
    assert facts['processor_cores'] == 4
    assert facts['processor_count'] == 2
    assert 'processor' not in facts
    assert facts['memtotal_mb'] == 8192
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] == 2048
    assert facts['swapfree_mb'] > 0
   

# Generated at 2022-06-22 23:13:16.490073
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.hp_ux import HPUXHardware

    module = basic.AnsibleModule(
        argument_spec={}
    )
    hpux_hardware = HPUXHardware(module=module)
    # Set up some example data, so our test is repeatable/predictable
    hpux_hardware.module.run_command = lambda cmd, check_rc=None: (0, '    0', '')
    hpux_hardware.module.run_command = lambda cmd, check_rc=None: (0, '     0', '')

# Generated at 2022-06-22 23:13:22.044783
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_coll = HPUXHardwareCollector()
    assert hw_coll._fact_class == HPUXHardware
    assert hw_coll._platform == 'HP-UX'
    assert hw_coll.required_facts == set(['platform', 'distribution'])
# Unit tests for constructor of class HPUXHardware

# Generated at 2022-06-22 23:13:34.098994
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    rc, out, err = module.run_command.mock_calls[0][1]
    assert rc == '/usr/bin/vmstat | tail -1'
    rc, out, err = module.run_command.mock_calls[1][1]
    assert rc == 'grep Physical /var/adm/syslog/syslog.log'
    rc, out, err = module.run_command.mock_calls[2][1]
    assert rc == 'model'
    rc, out, err = module.run_command.mock_calls[3][1]
    assert rc == '/usr/sbin/swapinfo -m -d -f -q'
    rc, out, err = module.run_

# Generated at 2022-06-22 23:13:47.331486
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware(None)
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware.module.run_command = lambda x: (
        1, '', '',
    ) if x == 'grep Physical /var/adm/syslog/syslog.log' else (
        0, '', ''
    ) if x == 'echo \'phys_mem_pages/D\' | adb -k /stand/vmunix /dev/kmem' else (
        0, '', '')
    assert hardware.get_memory_facts(collected_facts) == {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    assert hardware.get_memory_facts

# Generated at 2022-06-22 23:13:55.547827
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({'distribution': 'HP-UX'})
    hw = hw.populate()
    assert hw['processor_count'] == hw['processor_cores']
    assert hw['processor_vendor'] == 'GenuineIntel'
    assert hw['processor_architecture'] == 'IA-64'
    assert hw['memtotal_mb'] > 0

# Generated at 2022-06-22 23:14:03.738717
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert issubclass(HPUXHardwareCollector, HardwareCollector) == True
    hwc = HPUXHardwareCollector()
    assert hwc._fact_class == HPUXHardware
    assert hwc._platform == "HP-UX"
    assert hwc.required_facts == set(['platform', 'distribution'])
    assert hwc.optional_facts == set()


# Generated at 2022-06-22 23:14:08.871103
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    HPUXHardware: Test for method get_cpu_facts
    """
    test = HPUXHardware({'module': None})
    result = test.get_cpu_facts({'ansible_architecture': '9000/800'})
    assert len(result) == 3



# Generated at 2022-06-22 23:14:21.171923
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(1, 'out', 'err'))
    hpux = HPUXHardware(module=module)

    facts = {}
    # Return nine because ioscan found 9 processors
    module.run_command.return_value = (0, '9', '')
    facts['ansible_architecture'] = '9000/785'
    res = hpux.get_cpu_facts(collected_facts=facts)
    assert res['processor_count'] == 9

    # Return two because machinfo found 2 processors
    module.run_command.return_value = (0, '2', '')