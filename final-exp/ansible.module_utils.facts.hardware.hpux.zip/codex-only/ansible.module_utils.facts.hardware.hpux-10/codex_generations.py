

# Generated at 2022-06-22 23:04:25.162797
# Unit test for constructor of class HPUXHardware

# Generated at 2022-06-22 23:04:31.149085
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hw_facts = hardware.get_hw_facts()

    # Test if dictionary is not empty
    assert hw_facts is not None

    # Test some keys
    for key in ['model', 'firmware_version']:
        assert key in hw_facts


# Generated at 2022-06-22 23:04:40.717561
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    collection = HPUXHardwareCollector(module=module)
    # On ia64 model 9000/800 HPUX 11.31 :
    # * processor_count = 2
    # * processor = Intel(R) Itanium(R) Processor 9340
    # * processor_cores = 16
    collected_facts = dict(ansible_architecture='9000/800', ansible_distribution_version='B.11.31', ansible_arch='ia64')
    result = collection._fact_class(module).get_cpu_facts(collected_facts)
    assert result['processor_count'] == 2
    assert result['processor_cores'] == 16

# Generated at 2022-06-22 23:04:52.533559
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_data = {'ansible_architecture': '9000/800',
                     'ansible_os_family': 'HP-UX',
                     'ansible_distribution': 'HP-UX'}
    hp_ux = HPUXHardware(module=None, collected_facts=hardware_data)
    cpu_facts = hp_ux.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2

    hardware_data = {'ansible_architecture': 'ia64',
                     'ansible_distribution_version': 'B.11.23',
                     'ansible_os_family': 'HP-UX',
                     'ansible_distribution': 'HP-UX'}
    hp_ux = HPUXHardware(module=None, collected_facts=hardware_data)
    cpu_facts

# Generated at 2022-06-22 23:04:53.824554
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    result = HPUXHardwareCollector().collect()

# Generated at 2022-06-22 23:04:57.167201
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_col = HPUXHardwareCollector()
    assert isinstance(hw_col._fact_class, HPUXHardware)
    assert hw_col._platform == 'HP-UX'

# Generated at 2022-06-22 23:05:03.167207
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = DummyModule()
    hw = HPUXHardware(module)
    mem_facts = hw.get_memory_facts()
    assert mem_facts['memtotal_mb'] == 19988
    assert mem_facts['memfree_mb'] == 16889
    assert mem_facts['swaptotal_mb'] == 64
    assert mem_facts['swapfree_mb'] == 64



# Generated at 2022-06-22 23:05:08.575866
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module=module)

    assert hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:05:14.252115
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Given
    hpux_hw_collector = HPUXHardwareCollector()

    # When

    # Then
    assert hpux_hw_collector._fact_class is HPUXHardware
    assert hpux_hw_collector._platform is 'HP-UX'
    assert hpux_hw_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-22 23:05:16.531260
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    data = hw.get_hw_facts(collected_facts={})
    assert data['model'] == 'ia64 hp server rx2660'

# Generated at 2022-06-22 23:05:19.295500
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware(module)
    assert hardware_obj.platform == 'HP-UX'


# Generated at 2022-06-22 23:05:26.671741
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule({})
    hpux_hw_facts = HPUXHardware.get_memory_facts(module)
    assert hpux_hw_facts['memfree_mb'] > 0
    assert hpux_hw_facts['memtotal_mb'] > 0
    assert hpux_hw_facts['swaptotal_mb'] > 0
    assert hpux_hw_facts['swapfree_mb'] > 0



# Generated at 2022-06-22 23:05:34.888883
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('AnsibleModule', (object,), {'run_command': run_command, 'fail_json': fail_json})
    module = module()
    hpuxhw = HPUXHardware(module)
    facts = hpuxhw.get_hw_facts()
    assert facts.get('model') == '9000/800'
    assert facts.get('firmware_version') == 'C.7.6'
    assert facts.get('product_serial') == 'ABC00001'

# Generated at 2022-06-22 23:05:40.052110
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware({'module': AnsibleModule()})

    m = h.get_memory_facts()
    assert m['memfree_mb'] >= 0
    assert m['memtotal_mb'] >= 0
    assert m['swaptotal_mb'] >= 0
    assert m['swapfree_mb'] >= 0

# Generated at 2022-06-22 23:05:43.919411
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    facts = hardware.populate()
    assert facts['memtotal_mb'] >= facts['memfree_mb']
    assert facts['swaptotal_mb'] >= facts['swapfree_mb']


# Generated at 2022-06-22 23:05:55.720491
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    class MockModule:
        def __init__(self):
            self.run_command_called = False

        def run_command(self, cmd):
            self.run_command_called = True
            if cmd == "model":
                return 0, "ia64-hp-hpux11i", None
            elif cmd == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC":
                return 0, 'Firmware revision = "I64 11.31"', None
            elif cmd == "/usr/contrib/bin/machinfo |grep -i 'Machine serial number' ":
                return 0, 'Machine serial number = US1234567', None
            else:
                return 1, None, None

    # Prepare the test context
    module = MockModule()
   

# Generated at 2022-06-22 23:06:02.815437
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    j = {'ansible_architecture': 'ia64',
         'ansible_distribution': 'HP-UX'}
    r = {'memfree_mb': 282,
         'memtotal_mb': 32764,
         'swapfree_mb': 2614,
         'swaptotal_mb': 2614}
    H = HPUXHardware(j)
    assert H.get_memory_facts() == r


test_HPUXHardware_get_memory_facts()

# Generated at 2022-06-22 23:06:12.081529
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.collect() == {'processor_cores': 4, 'hw_memfree_mb': 36, 'swapfree_mb': 36,
                           'hw_model': 'ia64 hp server rx8640',
                           'processor_count': 2, 'processor': 'Intel(R) Itanium(R) Processor 9140',
                           'memfree_mb': 36, 'memtotal_mb': 192, 'swaptotal_mb': 36}

# Generated at 2022-06-22 23:06:20.215756
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # Test with empty metrics and empty facts
    hardware_facts_class = HPUXHardware()
    assert hardware_facts_class.platform == 'HP-UX'
    cpu_facts = hardware_facts_class.get_cpu_facts()
    assert cpu_facts['processor_count'] == 0
    assert cpu_facts['processor_cores'] == 0
    memory_facts = hardware_facts_class.get_memory_facts()
    assert memory_facts['memfree_mb'] == -1
    assert memory_facts['memtotal_mb'] == -1
    assert memory_facts['swapfree_mb'] == -1
    assert memory_facts['swaptotal_mb'] == -1
    hw_facts = hardware_facts_class.get_hw_facts()
    assert hw_facts['model'] == ''
    assert hw

# Generated at 2022-06-22 23:06:30.727694
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class MockModule(object):
      def __init__(self):
          self.run_command = lambda *args, **kwargs: (0, "foo", "bar")
    class MockCollector(object):
      def __init__(self):
          self.module = MockModule()
          self.facts = { 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

    hpuxHw = HPUXHardware()
    hpuxHw.collector = MockCollector()
    hw_facts = hpuxHw.get_hw_facts()
    assert hw_facts['model'] == "foo"
    assert hw_facts['firmware_version'] == "foo"
    assert hw_facts['product_serial'] == "foo"

#

# Generated at 2022-06-22 23:06:37.008714
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = AnsibleModule()
    hardware_obj = HPUXHardware(test_module)
    output = hardware_obj.get_memory_facts()
    assert isinstance(output, dict)
    assert u'memfree_mb' in output.keys()
    assert u'memtotal_mb' in output.keys()
    assert u'swaptotal_mb' in output.keys()
    assert u'swapfree_mb' in output.keys()


# Generated at 2022-06-22 23:06:45.855357
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    sample_out = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23',
    }
    hardware = HPUXHardware(dict(), '', True)
    assert hardware.get_cpu_facts(sample_out) == {
        'processor_cores': 2,
        'processor_count': 2,
        'processor': 'Intel(R) Xeon(R) CPU E7-2870  @ 2.40GHz',
    }
    sample_out = {
        'ansible_architecture': '9000/800',
    }
    assert hardware.get_cpu_facts(sample_out) == {'processor_count': 2}



# Generated at 2022-06-22 23:06:48.687479
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:06:57.653769
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = MockModule()
    module.run_command.return_value = (0, '/dev/vg00/lvol3 \t 38776 \t 96 \t 96', '')
    module.params = {}

    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': "B.11.23"}
    hw = HPUXHardware(module)
    facts = hw.get_memory_facts(collected_facts)
    assert facts == {'memfree_mb': 0,
                     'swaptotal_mb': 38776,
                     'memtotal_mb': 0,
                     'swapfree_mb': 96}



# Generated at 2022-06-22 23:07:11.250065
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Setup
    module = MockANSibleModule()
    mock_get_cpu_facts = MockGetCpuFacts()
    mock_get_memory_facts = MockGetMemoryFacts()
    hardware = HPUXHardware(module)
    hardware.get_cpu_facts = mock_get_cpu_facts
    hardware.get_memory_facts = mock_get_memory_facts

    # Run
    hardware_facts = hardware.populate()

    # Assert
    assert hardware_facts['processor_count'] == 24
    assert hardware_facts['processor'] == "Intel(R) Itanium(R) Processor"
    assert hardware_facts['processor_cores'] == 24
    assert hardware_facts['swaptotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 16384

# Generated at 2022-06-22 23:07:12.092653
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    assert True

# Generated at 2022-06-22 23:07:15.493904
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXHardware

# Generated at 2022-06-22 23:07:16.438165
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Unit test for constructor of class HPUXHardwareCollector
    """
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:07:25.381110
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=False
    )

    collected_facts = dict(
        ansible_architecture='9000/800',
    )

    # test for PA-RISC
    test_hw = HPUXHardware(module)
    cpu_facts = test_hw.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts['processor_count'] == 2

    # test for ia64
    collected_facts = dict(
        ansible_architecture='ia64',
    )
    cpu_facts = test_hw.get_cpu_facts(collected_facts=collected_facts)

   

# Generated at 2022-06-22 23:07:30.774987
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module = type('', (object,), {})
    hardware.module.run_command = lambda *_: (0, '', '')
    hardware.module.run_command.__reduce__ = lambda *_: (type('', (object,), {}), (299,))
    hardware.get_memory_facts()

# Generated at 2022-06-22 23:07:42.124659
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Creating a instance of HPUXHardware object
    hardware = HPUXHardware()
    hardware.module.run_command = lambda *args, **kwargs: (0, '', '')

    # Testing populate method with different B.11.x
    for v in ['B.11.11', 'B.11.23', 'B.11.31']:
        collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': v}
        hardware_facts = hardware.populate(collected_facts)

        if v == 'B.11.11' or v == 'B.11.23':
            assert hardware_facts['processor']
            assert hardware_facts['processor_cores']
            assert hardware_facts['processor_count']
            assert hardware_facts['memtotal_mb'] > 0

# Generated at 2022-06-22 23:07:44.047220
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_facts = HPUXHardware({})
    hardware_facts.get_memory_facts()

# Generated at 2022-06-22 23:07:55.663877
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts_dict = dict()
    facts_dict['architecture'] = 'ia64'
    facts_dict['distribution_version'] = 'B.11.23'
    assert HPUXHardware(module=None, facts=facts_dict).get_hw_facts() == {'model': 'ia64 hp server rx2660',
                                                                          'firmware_version': 'B.11.31.0912'}
    facts_dict['architecture'] = 'ia64'
    facts_dict['distribution_version'] = 'B.11.31'
    facts_dict['processor_count'] = 6
    facts_dict['processor_cores'] = 16

# Generated at 2022-06-22 23:07:57.933493
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector(None)
    assert hardware_collector._fact_class == HPUXHardware

# Generated at 2022-06-22 23:08:03.183816
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    mock_module = AnsibleModule(
        argument_spec={'gather_subset': dict(default=[], type='list')})
    mock_module.params['gather_subset'] = []

    hpux_hardware_ins = HPUXHardware(mock_module)

    assert hpux_hardware_ins is not None



# Generated at 2022-06-22 23:08:15.702362
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = DummyModule()
    module.run_command.return_value = (0, '4096\n', '')
    module.run_command.side_effect = [
        (1, '', 'machinfo: illegal option -- t'),
        (0, 'Memory:  40960 MB', ''),
        (0, '4096\n4096\n', ''),
        (0, '4096\n4096\n', ''),
    ]
    hw = HPUXHardware(module=module)
    facts = hw.get_memory_facts()
    assert facts['memfree_mb'] == 16
    assert facts['memtotal_mb'] == 40960
    assert facts['swaptotal_mb'] == 16
    assert facts['swapfree_mb'] == 16


# Generated at 2022-06-22 23:08:26.105681
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23'
    }
    hardware_facts = hardware.populate(collected_facts=collected_facts)
    assert hardware_facts['processor'] == 'PA-RISC 2.0 (floating point, 2 instruction issue)'
    collected_facts['ansible_architecture'] = 'ia64'
    hardware_facts = hardware.populate(collected_facts=collected_facts)
    assert hardware_facts['processor'] == 'Intel Itanium 2 (Madison)'



# Generated at 2022-06-22 23:08:38.580749
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.hardware.hpuxtop_parser import CommandsParser
    # The collected facts by ansible_collector are used to define the architecture
    # and the number of cpu
    collected_facts = ansible_collector
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = "B.11.31"
    h = HPUXHardware(module=None, collected_facts=collected_facts)
    result = h.get_cpu_facts(collected_facts)
    assert result['processor'] == 'Intel(R) Xeon(R) CPU E5-2697 v2 @ 2.70GHz'
    assert result['processor_count']

# Generated at 2022-06-22 23:08:42.181301
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    obj = HPUXHardware({}, {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert isinstance(obj, HPUXHardware)

# Generated at 2022-06-22 23:08:54.604645
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    failed_conditions = []

    # fail the module if hpux facts weren't collected
    if not module.params['gather_subset']:
        failed_conditions.append("hpux_facts not found")
    else:
        failed_conditions.append("hpux_facts not found in gather_subset")
    if failed_conditions:
        msg = 'One or more of the following conditions have failed: ' + ', '.join(failed_conditions)
        module.fail_json(msg=msg, failed=True)

    hardware_facts_instance = HPUXHardware(module)

    module.exit_json

# Generated at 2022-06-22 23:09:07.633132
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware_collector = HPUXHardwareCollector()

    # Test with all required facts
    required_facts = dict(
        platform='HP-UX',
        distribution='B.11.11',
        architecture='9000/800'
    )
    hardware = hardware_collector.collect(module=module, collected_facts=required_facts)

# Generated at 2022-06-22 23:09:18.387739
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware import HPUXHardware
    from ansible.module_utils.facts.hardware.hpu.utils import get_facts
    from ansible.module_utils.facts.hardware.hpu.utils import get_machinfo_facts
    from ansible.module_utils.facts.hardware.hpu.utils import get_machinfo_facts_1204
    from ansible.module_utils.facts.hardware.hpu.utils import get_machinfo_facts_parsed
    from ansible.module_utils.facts.hardware.hpu.utils import get_ioscan_facts
    from ansible.module_utils.facts.hardware.hpu.utils import get_machinfo_facts_parsed_13

# Generated at 2022-06-22 23:09:22.773820
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hpux_hardware_object = HPUXHardware(module)

    # Test for method populate
    assert hpux_hardware_object.populate() is None


# Generated at 2022-06-22 23:09:27.696601
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = module.get_cpu_facts(collected_facts)

    assert cpu_facts['processor_count'] == 2



# Generated at 2022-06-22 23:09:32.549702
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec={}
    )
    hardware = HPUXHardware({}, module)
    # test return value of method
    hw_facts = hardware.get_hw_facts()
    assert hw_facts['model']
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']


# Generated at 2022-06-22 23:09:44.430796
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware({'ansible_architecture': 'ia64'})
    hw.module.run_command = lambda x: (0, '1 2 3 4 5', '')
    memory = hw.get_memory_facts()
    assert memory['memfree_mb'] == 1
    hw.module.run_command = lambda x: (0, '1 2 3', '')
    memory = hw.get_memory_facts()
    assert memory['memfree_mb'] == 0
    hw.module.run_command = lambda x: (0, "Memory size = 4096 MB.\nMemory type = Synchronous.\n", '')
    memory = hw.get_memory_facts()
    assert memory['memtotal_mb'] == 4096

# Generated at 2022-06-22 23:09:54.024576
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, MEMORY_VAR, '')

    hpux_hardware = HPUXHardware(mock_module)

    memory_facts = hpux_hardware.get_memory_facts()
    assert memory_facts.get('memfree_mb') == 831
    assert memory_facts.get('memtotal_mb') == 1023
    assert memory_facts.get('swapfree_mb') == 1
    assert memory_facts.get('swaptotal_mb') == 2



# Generated at 2022-06-22 23:09:56.536901
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == {'ansible_architecture', 'ansible_distribution_version'}


# Generated at 2022-06-22 23:10:01.296134
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector(HPUXHardware)
    assert hw_collector.fact_class._platform == 'HP-UX'
    assert hw_collector.fact_class.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:10:07.095557
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    def run_command(self, args, check_rc=True):
        out = ''
        err = ''
        rc = 0
        if args == "vmstat":
            out = 'procs -----------memory---------- ---swap-- -----io---- -system-- ------cpu-----\n'
            out += ' r  b   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st\n'
            out += ' 0  0      0 251624  66812 1309308    0    0     0     0   19   17  1  0 98  0  0\n'
        elif args == "model":
            out = 'HP Integrity rx2800 i4'

# Generated at 2022-06-22 23:10:16.565092
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    if not module.check_mode:
        module.exit_json(changed=False)
    hw = HPUXHardware()
    assert hw.populate() is not None
    assert hw.populate()['processor_cores'] is not None
    assert hw.populate()['processor'] is not None
    assert hw.populate()['processor_count'] is not None
    assert hw.populate()['memfree_mb'] is not None
    assert hw.populate()['memtotal_mb'] is not None
    assert hw.populate()['swaptotal_mb'] is not None
    assert hw.populate()['swapfree_mb'] is not None
    assert hw.populate()['firmware_version'] is not None

# Generated at 2022-06-22 23:10:28.008883
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Populate memory and CPU facts:
    # - memfree_mb
    # - memtotal_mb
    # - swapfree_mb
    # - swaptotal_mb
    # - processor
    # - processor_cores
    # - processor_count
    # - model
    # - firmware

    test_cpu_facts = {'processor': 'RISC i4', 'processor_cores': 4, 'processor_count': 4}
    test_memory_facts = {'memfree_mb': 13952, 'memtotal_mb': 3276, 'swapfree_mb': 312, 'swaptotal_mb': 512}
    test_hw_facts = {'model': '9000/800', 'firmware': 'F.65'}

    # Result is concatenation of test_cpu_facts, test_memory_facts

# Generated at 2022-06-22 23:10:31.409378
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == "HP-UX"
    assert hw.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:10:37.207925
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector({'platform': 'HP-UX', 'distribution': 'B.11.31'})
    assert hardware_collector._fact_class is HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:10:46.394725
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hux_hw = HPUXHardware(module=None)
    hux_hw.ansible_facts = {}
    hux_hw.ansible_facts['ansible_architecture'] = 'ia64'
    hux_hw.ansible_facts['ansible_distribution_version'] = 'B.11.23'
    hw_facts = hux_hw.get_hw_facts()
    assert 'model' in hw_facts
    assert 'firmware_version' in hw_facts
    assert type(hw_facts['model']) == str
    assert type(hw_facts['firmware_version']) == str
    hux_hw.ansible_facts['ansible_distribution_version'] = 'B.11.31'
    hw_facts = hux_hw.get_hw

# Generated at 2022-06-22 23:10:52.475023
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor_count': 4}
    collected_facts = {'ansible_architecture': 'ia64'}
    collected_facts['ansible_distribution_version'] = "B.11.23"
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor': 'Intel(R) Itanium(R) processor 9650', 'processor_count': 4, 'processor_cores': 16}
    collected_facts['ansible_distribution_version'] = "B.11.31"
   

# Generated at 2022-06-22 23:10:56.625213
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collected_facts = {'platform': 'HP-UX', 'distribution': 'HP-UX'}
    hardware_collector = HPUXHardwareCollector({}, collected_facts)
    assert hardware_collector._fact_class == HPUXHardware

# Generated at 2022-06-22 23:11:03.366415
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module_params = {}
    module = AnsibleModule(argument_spec=module_params)
    hpux_hardware = HPUXHardware(module)
    hpux_hardware.populate()

    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution'] = ''
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    collected_facts['ansible_system'] = 'HP-UX'
    assert hpux_hardware.get_hw_facts(collected_facts) == {'firmware_version': '2014.11.05', 'product_serial': 'USXN4605FRA'}

# Generated at 2022-06-22 23:11:05.683092
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw._fact_class is HPUXHardware

# Generated at 2022-06-22 23:11:10.511803
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    hardware = HPUXHardware(module=module)
    hardware.populate()

    module.exit_json(changed=False)


# Generated at 2022-06-22 23:11:17.032527
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({})
    assert h.facts['processor_count'] == 0
    assert h.facts['processor_cores'] == 0
    assert h.facts['processor'] == ''
    assert h.facts['memfree_mb'] == 0
    assert h.facts['memtotal_mb'] == 0
    assert h.facts['swapfree_mb'] == 0
    assert h.facts['swaptotal_mb'] == 0
    assert h.facts['model'] == ''

# Generated at 2022-06-22 23:11:26.497532
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    hpux_hardware = HPUXHardware(module)

    cmd1 = 'model'
    out1 = 'ia64 hp server rx6600 (1.5 ghz, 32 mb)\n'
    err1 = ''
    rc1 = 0
    module.run_command.return_value = (rc1, out1, err1)

    cmd2 = "/usr/contrib/bin/machinfo |grep -i 'Firmware revision'"
    out2 = 'Firmware revision = 8.40\n'
    err2 = ''
    rc2 = 0
    module.run_command.return_value = (rc2, out2, err2)

    cmd3 = "/usr/contrib/bin/machinfo |grep -i 'Machine serial number'"
   

# Generated at 2022-06-22 23:11:37.584379
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class FakeAnsibleModule():
        def run_command(self, command, check_rc=True, use_unsafe_shell=False):
            if command == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'":
                return (0, "4194304", None)
            if command == "grep Physical /var/adm/syslog/syslog.log":
                return (0, "Mar 20 15:42:54 Physical: 8437496 Kbytes", None)
            if command == "model":
                return (0, "HP 9000/800", None)
            if command == "/usr/contrib/bin/machinfo | grep Memory":
                return (0, "Memory: 61927 MB", None)

# Generated at 2022-06-22 23:11:42.745202
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_instance = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware_instance.get_cpu_facts(collected_facts)
    assert cpu_facts == {'processor': 'Intel(R) Itanium(R) Processor 9100 series', 'processor_count': 2, 'processor_cores': 6}
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware_instance.get_cpu_facts(collected_facts)

# Generated at 2022-06-22 23:11:50.964559
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    m = h.get_memory_facts(collected_facts)
    assert m['memfree_mb'] == 7048
    assert m['memtotal_mb'] == 51177
    assert m['swaptotal_mb'] == 13487
    assert m['swapfree_mb'] == 13487


# Generated at 2022-06-22 23:11:52.530548
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector is not None

# Generated at 2022-06-22 23:11:55.029571
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector()
    assert hwc  # constructor should always return a value

# Generated at 2022-06-22 23:12:06.187290
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hw_collector = HPUXHardwareCollector(module=module)
    hw_facts = hw_collector.collect()
    assert isinstance(hw_facts, HPUXHardware)
    assert 'ansible_facts' in hw_facts
    assert 'ansible_system' in hw_facts['ansible_facts']
    assert 'hardware' in hw_facts['ansible_facts']['ansible_system']
    assert 'swaptotal_mb' in hw_facts['ansible_facts']['ansible_system']['hardware']
    assert 'swapfree_mb' in hw_facts['ansible_facts']['ansible_system']['hardware']
    assert 'processor_count' in hw_facts

# Generated at 2022-06-22 23:12:12.305938
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == {'distribution', 'platform'}
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector.fact_class == HPUXHardware


# Generated at 2022-06-22 23:12:17.290406
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hw = HPUXHardware(module)
    facts = hw.populate()
    assert facts['ansible_processor_cores'] == 2
    assert facts['ansible_processor_count'] == 2
    assert facts['ansible_processor'] == 'Intel(R) Itanium(R) 90 processor'

# Generated at 2022-06-22 23:12:28.281262
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0,
                                                 "total 1128K\nfree 76364K\n",
                                                 ""))
    hardware = HPUXHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 4
    assert facts['memfree_mb'] == 29
    module.run_command = MagicMock(return_value=(0,
                                                 "    total:  512000k bytes\n"
                                                 "    free:   167452k bytes\n",
                                                 ""))
    hardware = HPUXHardware(module)
    facts = hardware.get_memory_facts()

# Generated at 2022-06-22 23:12:40.367215
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class TestModule():
        def __init__(self, out, err, rc):
            self.run_command_status = rc
            self.run_command_stdout = out
            self.run_command_stderr = err

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == 'vmstat':
                return (self.run_command_status, 'procs  memory     page            disks   faults        cpu', self.run_command_stderr)
            if cmd == '/usr/bin/vmstat | tail -1':
                return (self.run_command_status, self.run_command_stdout, self.run_command_stderr)

# Generated at 2022-06-22 23:12:42.485957
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.fact_class == HPUXHardware

# Generated at 2022-06-22 23:12:55.449827
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(dict())
    collected_facts = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    rc, out, err = hardware.module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    if out:
        cpu_count = int(out.strip().split('=')[1])
    rc, out, err = hardware.module.run_command("/usr/contrib/bin/machinfo | grep 'processor family'", use_unsafe_shell=True)
    if out:
        processor = re.search('.*(Intel.*)', out).groups()[0].strip()
    rc, out, err = hardware.module.run

# Generated at 2022-06-22 23:12:58.684530
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Test case 1: Invoke the constructor without parameter and check whether it raises expected exception or not
    try:
        HPUXHardwareCollector()
    except Exception as err:
        assert err.__str__() == 'Required parameters are missing!'


# Generated at 2022-06-22 23:13:03.564445
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = HPUXHardwareCollector.fetch_facts(module)
    facts = hardware.get_memory_facts()
    assert facts['memfree_mb'] == 10446
    assert facts['memtotal_mb'] == 10737
    assert facts['swaptotal_mb'] == 10737
    assert facts['swapfree_mb'] == 10737



# Generated at 2022-06-22 23:13:15.234178
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    data_osrelease = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23'
    }
    data_arch = 'ia64'
    data_osrelease_ia64 = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    data_processor = 'Intel(R) Itanium(R) Processor 9850'
    data_firmware = 'HP-UX B.11.23 U ia64 0837105790'
    instance = HPUXHardware
    input_params = dict()

# Generated at 2022-06-22 23:13:16.723697
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-22 23:13:23.895804
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = MockModule()
    hw.module.run_command.return_value = (0, 'HP-UX B.11.31 U ia64 0425078392 unlimited-user license', '')
    hw.get_hw_facts()
    assert hw.facts['model'] == 'ia64'
    assert hw.facts['firmware_version'] == 'B.11.31'


# Generated at 2022-06-22 23:13:35.702605
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test case to check if the method of HPUXHardware class
    get_hw_facts() is working properly.

    """
    class MockModule(object):
        def __init__(self):
            self.run_command = self._run_command

        def _run_command(self, cmd, use_unsafe_shell=False):
            class MockRun(object):
                def __init__(self):
                    self.rc = 0
                    self.stdout = ""
                    self.stderr = ""

                def communicate(self):
                    return self.stdout, self.stderr

            if cmd == "model":
                run = MockRun()
                run.stdout = "ia64 hp rx2660"
                return run.rc, run.stdout, run.stderr

# Generated at 2022-06-22 23:13:41.540873
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector.platform == 'HP-UX'
    assert hpux_hardware_collector.required_facts == set(['platform', 'distribution'])
    assert hpux_hardware_collector._fact_class == HPUXHardware

# Generated at 2022-06-22 23:13:52.803765
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUXHardware = HPUXHardware()
    HPUXHardware.module = AnsibleModuleStub()
    HPUXHardware.module.run_command = run_command_stub
    HPUXHardware.populate()

    assert HPUXHardware.facts['processor_count'] == 2
    assert HPUXHardware.facts['processor_cores'] == 2
    assert HPUXHardware.facts['processor'] == "Intel(R) Itanium(R) Processor 9315"
    assert HPUXHardware.facts['memtotal_mb'] == 16384
    assert HPUXHardware.facts['memfree_mb'] == 4828
    assert HPUXHardware.facts['swaptotal_mb'] == 8192
    assert HPUXHardware.facts['swapfree_mb'] == 4093

# Generated at 2022-06-22 23:13:59.294566
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    c = HPUXHardwareCollector()
    #
    # platform
    #
    assert c._platform == 'HP-UX', "Test platform failed."
    #
    # fact_class
    #
    assert c._fact_class == HPUXHardware, "Test fact_class failed."
    #
    # required_facts
    #
    assert c.required_facts == {'platform', 'distribution'}, "Test required_facts failed."


# Generated at 2022-06-22 23:14:09.319222
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {'ansible_distribution': 'HP-UX', 'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    hw_obj = HPUXHardware(None)
    hw_obj.populate(collected_facts=collected_facts)
    (hw_facts, _) = hw_obj.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts.get('model') == 'ia64 hp server rx6600'
    assert hw_facts.get('firmware_version') == '1.40'

# Generated at 2022-06-22 23:14:17.720354
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}

    assert h.get_cpu_facts(collected_facts=collected_facts) == {'processor_count': 2}

    collected_facts = {'ansible_architecture': 'ia64'}

    assert h.get_cpu_facts(collected_facts=collected_facts) == {'processor_count': 2, 'processor': 'Intel(r) Itanium(r) Processor', 'processor_cores': 8}