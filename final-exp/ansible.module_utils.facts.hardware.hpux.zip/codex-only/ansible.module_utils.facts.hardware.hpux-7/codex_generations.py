

# Generated at 2022-06-22 23:04:22.006052
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    facts_obj = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23'
    }

    # Test for PA-RISC
    expected_cpu_facts = {
        'processor_count': 4,
        'processor': 'PA-RISC2.0',
        'processor_cores': 2
    }

    cpu_facts = facts_obj.get_cpu_facts(collected_facts=collected_facts)
    assert expected_cpu_facts == cpu_facts

    # Test for IA-64

# Generated at 2022-06-22 23:04:27.739393
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = MockModule()
    hardware = HPUXHardware(module=module)

    hardware.get_memory_facts()
    assert hardware.platform == "HP-UX"
    assert hardware.facts['memfree_mb'] > 0
    assert hardware.facts['memtotal_mb'] > 0
    assert hardware.facts['swaptotal_mb'] > 0
    assert hardware.facts['swapfree_mb'] > 0


# Generated at 2022-06-22 23:04:29.553232
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(None)
    assert hw.platform == 'HP-UX'


# Generated at 2022-06-22 23:04:39.808055
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(dict(ansible_architecture='ia64'))
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert 'processor' in cpu_facts.keys()
    assert 'processor_count' in cpu_facts.keys()
    assert 'processor_cores' in cpu_facts.keys()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert 'processor' in cpu_facts.keys()


# Generated at 2022-06-22 23:04:51.270087
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    result = {'ansible_facts': {'hw_firmware_version': 'B.11.31.2908',
                                'hw_model': 'ia64 hp server rx6600',
                                'hw_product_serial': 'USCG2380W8'}}

    hardware_file = open("tests/unit/ansible/modules/extras/inventory/hpux/test_HPUXHardware_get_hw_facts", "r")
    data = hardware_file.read()
    hardware_file.close()

    hardware_obj = HPUXHardware(module=MockModule(data))
    assert hardware_obj.get_hw_facts() == result['ansible_facts']



# Generated at 2022-06-22 23:05:02.480067
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # build collected_facts
    collected_facts = {'ansible_architecture': 'ia64'}
    hardware = HPUXHardware()
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor'] == 'Intel Itanium 2 9100 series'
    assert cpu_facts['processor_cores'] == 4
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware = HPUXHardware()
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 8


# Generated at 2022-06-22 23:05:09.541618
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    import sys
    import ansible.module_utils.facts.hardware.hpux

    if sys.version_info[0] == 2:
        import __builtin__
        builtin_module_name = '__builtin__'
    else:
        import builtins
        builtin_module_name = 'builtins'

    hpux_hardware = ansible.module_utils.facts.hardware.hpux.HPUXHardware()

    # Return empty dict when module run_command return an error
    setattr(hpux_hardware.module, 'run_command', lambda x: (1, '', ''))
    result = hpux_hardware.populate()
    assert result == {}
    # Return empty dict when ansible_architecture isn't supported

# Generated at 2022-06-22 23:05:19.054783
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {'platform': 'HP-UX',
                        'ansible_architecture': 'ia64',
                        'ansible_distribution_version': 'B.11.23'}

    mock_module = Mock()
    mock_module.run_command.return_value = (0, '%s: B.11.23', '')
    fact_class = HPUXHardware(mock_module)

    # Test for model
    mock_module.run_command.return_value = (0, 'TEST', '')
    assert fact_class.get_hw_facts(collected_facts)['model'] == 'TEST'

    # Test for firmware_version
    mock_module.run_command.return_value = (0, 'Firmware revision : 111', '')
    assert fact_class.get_

# Generated at 2022-06-22 23:05:26.025590
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpuxHardwareCollector = HPUXHardwareCollector()
    assert hpuxHardwareCollector._facts
    assert hpuxHardwareCollector._fact_class == HPUXHardware
    assert hpuxHardwareCollector._platform == 'HP-UX'
    assert hpuxHardwareCollector.required_facts == set(['platform', 'distribution'])

# Unit tests for constructor of class HPUXHardware

# Generated at 2022-06-22 23:05:27.514678
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h = HPUXHardware()
    assert h.populate() is not None

# Generated at 2022-06-22 23:05:29.025159
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware()
    assert hardware_obj


# Generated at 2022-06-22 23:05:41.432915
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mock_run_command = Mock(return_value=(0, '322', ''))
    module = Mock()
    module.run_command = mock_run_command
    module.params = dict()
    hpux = HPUXHardware(module)
    hpux.get_memory_facts()
    mock_run_command.assert_has_calls([
        call('/usr/sbin/swapinfo -m -d -f -q'),
        call('/usr/sbin/swapinfo -m -d -f | egrep \'^dev|^fs\'', True)
    ])
    assert hpux.facts == {
        'memfree_mb': 128,
        'swapfree_mb': 0,
        'memtotal_mb': 8192,
        'swaptotal_mb': 8192
    }

# Generated at 2022-06-22 23:05:46.751620
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({'ansible_architecture': 'ia64'})
    assert h.platform == 'HP-UX'
    assert h.get_cpu_facts() == {}
    assert h.get_memory_facts() == {}
    assert h.get_hw_facts() == {}

# Generated at 2022-06-22 23:05:57.158896
# Unit test for method get_cpu_facts of class HPUXHardware

# Generated at 2022-06-22 23:06:04.442712
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = fake_ansible_module()
    hw = HPUXHardware(module)

    hw.module.run_command = fake_command

    hw_facts = hw.get_hw_facts()

    assert hw_facts['model'] == 'ia64 hp Integrity rx6600 Server'
    assert hw_facts['firmware_version'] == 'B.11.31.3200'
    assert hw_facts['product_serial'] == 'US736303937'



# Generated at 2022-06-22 23:06:13.610289
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collected_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX B.11.23',
        'ansible_architecture': 'ia64'
    }
    hw = HPUXHardwareCollector(None, collected_facts, None)

    assert hw.platform == 'HP-UX'
    assert hw.collected_facts == collected_facts
    assert isinstance(hw.get_facts(), dict)

# Generated at 2022-06-22 23:06:18.799834
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module)
    hardware.module.run_command = lambda *args, **kwargs: (0, "123", "")
    facts = hardware.get_memory_facts()

    assert facts['memfree_mb'] == 0
    assert facts['memtotal_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0


# Generated at 2022-06-22 23:06:24.414680
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module=module)
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == {'platform', 'distribution'}



# Generated at 2022-06-22 23:06:33.392988
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    vmunix_ia64_800 = {'ansible_architecture': '9000/800',
                       'ansible_distribution': 'HP-UX'}
    vmunix_ia64_785 = {'ansible_architecture': '9000/785',
                       'ansible_distribution': 'HP-UX'}
    vmunix_ia64 = {'ansible_architecture': 'ia64',
                   'ansible_distribution_major_version': 'B.11',
                   'ansible_distribution_minor_version': '11',
                   'ansible_distribution_release': '23',
                   'ansible_distribution': 'HP-UX'}

# Generated at 2022-06-22 23:06:36.145672
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = HPUXHardwareCollector()
    assert module._fact_class is HPUXHardware


# Generated at 2022-06-22 23:06:45.589953
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hw_facts = hw.get_hw_facts(facts)
    assert hw_facts['model'] == 'hp Superdome 2, PA-RISC'
    assert 'firmware_version' in hw_facts
    assert 'product_serial' in hw_facts
    facts['ansible_distribution_version'] = 'B.11.31'
    hw_facts = hw.get_hw_facts(facts)
    assert hw_facts['model'] == 'hp Superdome 2, Integrity'
    assert 'firmware_version' in hw_facts
    assert 'product_serial'

# Generated at 2022-06-22 23:06:56.257381
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = {}
    collected_facts = {'ansible_architecture':'ia64', 'ansible_distribution_version':'B.11.23'}
    # Test with 11.31
    result = HPUXHardware(module=None).get_hw_facts(collected_facts)
    if result.get('firmware_version') and result.get('product_serial'):
        hw_facts = result
    # Test with 11.23
    result_v23 = HPUXHardware(module=None).get_hw_facts(collected_facts)
    if result.get('firmware_version') and result.get('product_serial'):
        hw_facts = result_v23

# Generated at 2022-06-22 23:07:03.940426
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('', (object,), {'run_command': run_command})
    hardware = HPUXHardware(module)
    collected_facts = {}
    # Check model
    rc, out, err = run_command("model")
    assert out.strip() == hardware.get_hw_facts(collected_facts).get('model')


# Generated at 2022-06-22 23:07:16.852884
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    h = HPUXHardware(module)
    rc, out, err = module.run_command("/usr/contrib/bin/machinfo | grep Memory", use_unsafe_shell=True)
    mem = re.search(r'Memory[\ :=]*([0-9]*).*MB.*', out).groups()[0].strip()
    rc, out, err = module.run_command("/usr/contrib/bin/machinfo | grep socket | tail -1", use_unsafe_shell=True)
    cpu = out.split(" ")
    data = {'ansible_distribution_version': "B.11.31", 'ansible_architecture': 'ia64'}

# Generated at 2022-06-22 23:07:25.642508
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hpux = HPUXHardware(module=module)

    collected_facts = {'ansible_architecture': '9000/800'}
    returned_facts = hpux.get_cpu_facts(collected_facts=collected_facts)
    assert returned_facts['processor_count'] == 8

    collected_facts = {'ansible_architecture': 'ia64'}
    returned_facts = hpux.get_cpu_facts(collected_facts=collected_facts)
    assert returned_facts['processor_count'] == 2
    assert returned_facts['processor_cores'] == 16
    assert returned_facts['processor'] == 'Intel(R) Itanium 2 processor @1600 MHz'


# Generated at 2022-06-22 23:07:35.401472
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Arrange
    memfree_mb = 0
    memtotal_mb = 0
    swapfree_mb = 0
    swaptotal_mb = 0
    result = 0

    # Act
    memfree_mb = HPUXHardware.get_memory_facts()['memfree_mb']
    memtotal_mb = HPUXHardware.get_memory_facts()['memtotal_mb']
    swapfree_mb = HPUXHardware.get_memory_facts()['swapfree_mb']
    swaptotal_mb = HPUXHardware.get_memory_facts()['swaptotal_mb']

    # Assert
    # If all 4 of these items have been returned, then the test has passed

# Generated at 2022-06-22 23:07:39.796132
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    print(HPUXHardwareCollector._platform)
    print(hw._fact_class)
    print(hw.required_facts)


# Generated at 2022-06-22 23:07:40.929004
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:07:43.269006
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware({'platform': 'HP-UX'})
    assert hardware_obj.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:46.140293
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ph = HPUXHardware(module)
    ph.get_memory_facts()



# Generated at 2022-06-22 23:07:55.944505
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = dict(ansible_architecture='ia64',
                           ansible_distribution_version='B.11.23')
    hpux_facts_instance = HPUXHardware()
    hpux_facts_instance.module = DummyAnsibleModule()
    hpux_facts_instance.populate()
    hw_facts = hpux_facts_instance.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts.get('firmware_version') == 'B.11.254'
    assert hw_facts.get('product_serial') == 'GJOBB0'


# Generated at 2022-06-22 23:08:01.433776
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec = dict(
            collected_facts=dict(required=False, type='dict', default=dict()),
            filter=dict(required=False, type='str', default='*')
        )
    )
    # Set up "mock" object for module
    module.run_command = MagicMock(return_value=(0, "a5200", ""))
    hw = HPUXHardware(module)

    result = hw.get_hw_facts()

    assert result == {'model': "a5200"}

# Generated at 2022-06-22 23:08:14.351918
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec={
            'collected_facts': {'type': 'dict', 'required': False}
        }
    )

    hardware = HPUXHardwareModule(module)
    hardware.module = module

    out = hardware.get_memory_facts(collected_facts={'ansible_architecture': '9000/921'})
    assert out['swaptotal_mb'] == 2995

    out = hardware.get_memory_facts(collected_facts={'ansible_architecture': 'ia64'})
    assert out['swaptotal_mb'] == 2995

    out = hardware.get_memory_facts(collected_facts={'ansible_architecture': '9000/785'})
    assert out['memtotal_mb'] == 1280

# Generated at 2022-06-22 23:08:26.261641
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Create an instance of the module
    module_args = {}
    module = AnsibleModule(argument_spec=module_args)

    # Create an instance of class HPUXHardware
    hardware = HPUXHardware(module)

    # Create collected facts (usually computed by Ansible)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }

    hardware_facts = hardware.populate(collected_facts)

    # Check some attributes of the class
    assert hardware_facts['firmware_version'] == 'v1204'
    assert hardware_facts['memfree_mb'] == 14331
    assert hardware_facts['memtotal_mb'] == 62640


# Generated at 2022-06-22 23:08:31.287268
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(facts)
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts


# Generated at 2022-06-22 23:08:38.500290
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = dict()
    hardware = HPUXHardware(module=object(), collected_facts=facts)

    # value of facts['ansible_architecture'] is "9000/800"
    facts['ansible_architecture'] = '9000/800'
    rc, out, err = hardware.module.run_command('ioscan -FkCprocessor | wc -l', use_unsafe_shell=True)
    assert int(out.strip()) == hardware.get_cpu_facts()['processor_count']

    # value of facts['ansible_architecture'] is "9000/785"
    facts['ansible_architecture'] = '9000/785'

# Generated at 2022-06-22 23:08:44.645131
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m = HPUXHardware(dict(ansible_distribution_version='B.11.31', ansible_architecture='ia64'))
    result = m.get_cpu_facts()
    # The result of machinfo should be testable but that's not the case
    assert 'processor_count' in result
    assert 'processor_cores' in result
    assert 'processor' in result

# Generated at 2022-06-22 23:08:57.763798
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Test class HPUXHardware get_memory_facts method
    """

    # Test HP-UX ia64
    mem_facts = HPUXHardware(dict(ansible_facts=dict(ansible_architecture='ia64', ansible_distribution_version="B.11.31"))).get_memory_facts()
    assert mem_facts['memfree_mb'] >= 0
    assert mem_facts['memtotal_mb'] >= 0
    assert mem_facts['swaptotal_mb'] >= 0
    assert mem_facts['swapfree_mb'] >= 0
    mem_facts = HPUXHardware(dict(ansible_facts=dict(ansible_architecture='ia64', ansible_distribution_version="B.11.23"))).get_memory_facts()

# Generated at 2022-06-22 23:09:08.473284
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=True)

    result = HPUXHardware(module).populate()
    assert 'ansible_processor' in result
    assert 'ansible_processor_count' in result
    assert 'ansible_processor_cores' in result
    assert 'ansible_memfree_mb' in result
    assert 'ansible_memtotal_mb' in result
    assert 'ansible_swapfree_mb' in result
    assert 'ansible_swaptotal_mb' in result
    assert 'ansible_model' in result

# Generated at 2022-06-22 23:09:13.444379
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardwareCollector()
    result = hardware.get_memory_facts({'ansible_architecture': '9000/785'})
    assert result['memfree_mb'] < result['memtotal_mb']
    assert result['swaptotal_mb'] > 0
    assert result['swapfree_mb'] <= result['swaptotal_mb']


# Generated at 2022-06-22 23:09:15.578213
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    hardware_facts = HPUXHardware(module=None)

    assert hardware_facts.platform == 'HP-UX'

# Generated at 2022-06-22 23:09:28.555751
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    args = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hw_module = HPUXHardware(module=None, collected_facts=args)
    hardware_facts = hw_module.populate()
    assert hardware_facts['processor'] == 'Intel Itanium 2 9100 series'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_count'] == 2

    args = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    hw_module = HPUXHardware(module=None, collected_facts=args)
    hardware_facts = hw_module.populate()
   

# Generated at 2022-06-22 23:09:30.408890
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    inst = HPUXHardware()
    assert inst.platform == 'HP-UX'

# Generated at 2022-06-22 23:09:32.954227
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    fct = HPUXHardware()
    assert fct.data['platform'] == 'HP-UX'

# Generated at 2022-06-22 23:09:41.793151
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeModule()
    tested_object = HPUXHardware(module)
    tested_object.populate(collected_facts=dict(ansible_architecture='9000/800'))
    assert tested_object.facts['ansible_memfree_mb'] == 6076
    assert tested_object.facts['ansible_memtotal_mb'] == 32768
    assert tested_object.facts['ansible_swapfree_mb'] == 84
    assert tested_object.facts['ansible_swaptotal_mb'] == 256

# Generated at 2022-06-22 23:09:49.488152
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31', 'ansible_system': 'HP-UX'}
    hardware = HPUXHardware(module=None, params=facts, collected_facts=facts)
    hw_facts = hardware.populate()
    assert hw_facts.get('processor_count') == 2
    assert hw_facts.get('processor') == 'Intel(R) Itanium(R) Processor 9320'
    assert hw_facts.get('processor_cores') == 4
    assert hw_facts.get('memfree_mb') == 10
    assert hw_facts.get('memtotal_mb') == 16384
    assert hw_facts.get('swapfree_mb') == 0
    assert hw

# Generated at 2022-06-22 23:09:57.168601
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """Unit test for get_hw_facts method of class HPUXHardware
    """
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'HP 9000/785', ''))
    hpux_hw = HPUXHardware(module)
    assert hpux_hw.get_hw_facts() == {'model': 'HP 9000/785'}


# Generated at 2022-06-22 23:10:05.474976
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware()
    collected_facts = dict(ansible_architecture='9000/800')
    data = hardware_facts.populate(collected_facts)
    assert data['processor_count'] == 2
    collected_facts = dict(ansible_architecture='ia64')
    data = hardware_facts.populate(collected_facts)
    assert data['processor_count'] == 1
    collected_facts = dict(ansible_architecture='9000/785')
    data = hardware_facts.populate(collected_facts)
    assert data['memtotal_mb'] == 8192


# Generated at 2022-06-22 23:10:11.359152
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hpuxtest = HPUXHardware(module=module)
    collected_facts = dict(platform='HP-UX', distribution='HP-UX')
    result = hpuxtest.get_hw_facts(collected_facts=collected_facts)
    assert 'model' in result
    assert 'firmware_version' in result
    assert 'product_serial' in result

# Generated at 2022-06-22 23:10:12.729643
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    HPUXHardware().get_memory_facts()



# Generated at 2022-06-22 23:10:17.924688
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = HPUXHardware(module).populate()
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_facts['memtotal_mb'] == 4096
    assert hardware_facts['swaptotal_mb'] == 2048
    assert hardware_facts['model'] == "ia64 hp integrity rx6600"

# Generated at 2022-06-22 23:10:29.019220
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test working with machinfo
    ah = HPUXHardware()
    class TestModule(object):
        def run_command(self, command, use_unsafe_shell=False):
            if command == "/usr/sbin/swapinfo -m -d -f -q":
                return 0, '10240', ''
            if command == "/usr/sbin/swapinfo -m -d -f | egrep '^dev|^fs'":
                return 0, 'device     1024.000Mb (1048576 pages)', ''
            if command == "/usr/contrib/bin/machinfo | grep Memory":
                return 0, 'Memory : 8192 MB', ''

# Generated at 2022-06-22 23:10:30.777090
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    col = HPUXHardwareCollector(None)
    assert col is not None

# Generated at 2022-06-22 23:10:34.727605
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware().get_hw_facts()
    assert hw_facts['model']
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']



# Generated at 2022-06-22 23:10:36.279841
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-22 23:10:45.105132
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware()
    h.module = MockModule()
    h.module.run_command = Mock(return_value=(0, "  4   651  492    0    3    0    0    0    0    0    0    0    0    0    0 "
                                                  "   0    0    0    0    0   37  651  492", ""))

    mem_facts = {'memtotal_mb': 516, 'memfree_mb': 4, 'swapfree_mb': 54, 'swaptotal_mb': 651}
    assert mem_facts == h.get_memory_facts(collected_facts={'ansible_architecture': 'ia64'})



# Generated at 2022-06-22 23:10:48.251945
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector._fact_class == HPUXHardware
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-22 23:10:59.642046
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.hpu import HPUXHardware

    test_hpu_hw = HPUXHardware(module=None)
    test_facts = {
        "ansible_architecture": "9000/800",
        "ansible_distribution": "HP-UX",
        "ansible_distribution_major_version": "B.11.31",
        "ansible_distribution_version": "B.11.31",
        "ansible_machine": "9000/800",
        "ansible_system": "HP-UX",
    }

# Generated at 2022-06-22 23:11:12.892424
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hardware = HPUXHardware(module)

    collected_facts = {}
    # Test on standard system
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9350'

    # Test on old system
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    cpu_facts = hardware.get_cpu

# Generated at 2022-06-22 23:11:18.670264
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = type('AnsibleModule', (), {})()
    m = HPUXHardware(test_module)
    assert m.get_memory_facts()['memtotal_mb'] == 4106
    assert m.get_memory_facts()['memfree_mb'] == 3159
    assert m.get_memory_facts()['swaptotal_mb'] == 20
    assert m.get_memory_facts()['swapfree_mb'] == 20

# Generated at 2022-06-22 23:11:25.607712
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    hardware.module.run_command.return_value = (0, MEMORY_SWAP_OUTPUT, "")
    facts = hardware.get_memory_facts()
    expected_facts = {'memfree_mb': 233, 'memtotal_mb': 1677, 'swapfree_mb': 1204, 'swaptotal_mb': 1204}
    assert facts == expected_facts


# Generated at 2022-06-22 23:11:31.827192
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    mock_module = type('module', (object,), {})
    mock_module.run_command = MagicMock()
    mock_module.run_command.return_value = (0, "", "")
    facts = HPUXHardware(mock_module)
    facts.populate()
    assert 'memory' in facts.facts
    assert 'cpu' in facts.facts
    assert 'hardware' in facts.facts

# Generated at 2022-06-22 23:11:35.124148
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = HPUXHardwareCollector(module=module)
    assert collector.platform == 'HP-UX'
    assert collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-22 23:11:42.878824
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    hw.module = FakeModule()
    hw.module.run_command.return_value = [0, "", ""]

    rc, out, err = hw.module.run_command.return_value
    hw.module.run_command.assert_called_once_with("/usr/sbin/swapinfo -m -d -f -q")

    rc, out, err = hw.module.run_command.return_value
    hw.module.run_command.assert_called_once_with("/usr/sbin/swapinfo -m -d -f | egrep '^dev|^fs'",
                                                  use_unsafe_shell=True)

    rc, out, err = hw.module.run_command.return_value
    h

# Generated at 2022-06-22 23:11:54.023939
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    out_model = 'Integrity rx2620'
    out_firmware_version = 'v5.7.5'
    out_product_serial = '0012345'
    out_model_firmware = '''Model: Integrity rx2620
Firmware revision: v5.7.5
Machine serial number: 0012345'''
    out_model_firmware_no_serial = '''Model: Integrity rx2620
Firmware revision: v5.7.5'''

    hpux_hardware = HPUXHardware(dict())

    hpux_hardware.module = MagicMock()
    hpux_hardware.module.run_command = MagicMock(return_value=(0, out_model, None))
    hw_facts = hpux_hardware.get_hw_facts

# Generated at 2022-06-22 23:12:00.694579
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector('HP-UX')
    assert x.platform is 'HP-UX', 'Parameter platform has wrong value.'
    assert x.required_facts == set(['platform', 'distribution']), 'Parameter required_facts has wrong value.'
    assert x._fact_class == HPUXHardware, 'Parameter _fact_class has wrong value.'
    assert x._platform == 'HP-UX', 'Parameter _platform has wrong value.'

# Generated at 2022-06-22 23:12:03.194175
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw._fact_class == HPUXHardware
    assert hw._platform == 'HP-UX'

# Generated at 2022-06-22 23:12:11.435446
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module=module)
    hardware.module.run_command = run_command_mock

    hardware_facts = hardware.populate()
    assert hardware_facts['model'] == '9000/800'
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) 2 family'
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 4096
    assert hardware_facts['memfree_mb'] == 3744
    assert hardware_facts['swaptotal_mb'] == 2096434
    assert hardware_facts['swapfree_mb'] == 2055582

# Generated at 2022-06-22 23:12:21.629295
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module=module)
    data = hardware.populate({'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.11'})
    assert data.get('processor_count') == 8
    assert data.get('memtotal_mb') == 2048
    assert data.get('memfree_mb') in (94, 96)
    assert data.get('swapfree_mb') in (500, 504)
    assert data.get('swaptotal_mb') == 528
    assert data.get('processor') is None
    assert data.get('processor_cores') is None
    assert data.get('model') == 'ia64 hp server rx8640'

# Generated at 2022-06-22 23:12:26.375233
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'distribution': 'HP-UX', 'platform': 'HP-UX'}
    hw = HPUXHardwareCollector(None, facts)
    assert len(hw.required_facts) == 2


if __name__ == '__main__':
    test_HPUXHardwareCollector()

# Generated at 2022-06-22 23:12:39.120311
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    '''Unit test for HPUXHardware.py, populate'''

    # Create an empty ansible module object
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    # Create an instance of HPUXHardware
    my_hpuxhw = HPUXHardware(module)

    # Create a dictionary of collected facts
    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

    # Call the populate method
    out = my_hpuxhw.populate(collected_facts=facts)


# Generated at 2022-06-22 23:12:42.438415
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector(None)  # Suppress pylint "Argument must be an instance"
    assert isinstance(hw, HPUXHardwareCollector)
    assert hw._platform == 'HP-UX'

# Generated at 2022-06-22 23:12:55.341423
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Init
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hw = HPUXHardware(module)
    hw.module = module
    # Test when facts = None
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts == {}
    # Test when facts = { ansible_architecture: '9000/800' }
    cpu_facts = hw.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert cpu_facts['processor_count'] >= 1
    # Test when facts = { ansible_architecture: 'ia64' }
    cpu_facts = hw.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64'})
   

# Generated at 2022-06-22 23:13:04.240014
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Test output of HPUXHardware.populate()
    """
    facts = { 'ansible_architecture': 'ia64',
              'ansible_distribution_version': "B.11.31"}
    hw = HPUXHardware(facts)

    cpu = {'processor_cores': 4,
           'processor_count': 2,
           'processor': 'Intel(R) Itanium(R) processor 9320'}
    mem = {'memfree_mb': 4501,
        'memtotal_mb': 32704,
        'swapfree_mb': 0,
        'swaptotal_mb': 0}

# Generated at 2022-06-22 23:13:10.696622
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = {'platform': 'HP-UX', 'distribution_version': 'B.11.31'}
    hpux_hardware = HPUXHardware(facts)
    assert hpux_hardware.facts == facts
    assert hpux_hardware.platform == 'HP-UX'
    assert hpux_hardware.required_facts == HPUXHardwareCollector.required_facts

# Generated at 2022-06-22 23:13:14.277152
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    hw.collect()
    assert hw._fact_class is not None
    assert hw._platform is not None
    assert hw.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:13:17.310637
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (), {})()
    module.run_command = lambda x, use_unsafe_shell=True, **kwargs: (0, '', '')
    hpux = HPUXHardware(module)
    hpux.get_memory_facts()

# Generated at 2022-06-22 23:13:29.709097
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    HPUXHardware.module = FakeAnsibleModule()
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    expected_hw_facts = {
        'firmware_version': '11.24B.01.00',
        'model': 'HP rx2800 i2',
        'product_serial': 'U5Q6U1E',
    }

    hw = HPUXHardware(collected_facts)
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == expected_hw_facts['firmware_version']
    assert hw_facts['model'] == expected_hw

# Generated at 2022-06-22 23:13:32.215036
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware(dict())
    assert hardware_obj.platform == 'HP-UX'


# Generated at 2022-06-22 23:13:37.027415
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    testobj = HPUXHardware()
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')
    output = testobj.get_hw_facts(collected_facts=collected_facts)
    assert 'model' in output
    assert 'firmware_version' in output



# Generated at 2022-06-22 23:13:42.077626
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h is not None
    assert set(h.required_facts) == set(['platform', 'distribution'])
    assert h._fact_class == HPUXHardware
    assert h._platform == "HP-UX"

# Generated at 2022-06-22 23:13:53.090172
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Return memtotal_mb, memfree_mb, swaptotal_mb and swapfree_mb fact
    """
    # For IA64 with firmware revision vC.03.90 and system architecture ia64
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    # Create HPUXHardware instance to test method get_memory_facts
    hardware = HPUXHardware()
    hardware.module = MockModule()
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)

    assert memory_facts['memtotal_mb'] == 66939
    assert memory_facts['memfree_mb'] == 819

# Generated at 2022-06-22 23:13:56.044513
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = Hardware()
    assert h.platform == 'Generic'

    h = Hardware(subclass='HPUXHardware')
    assert h.platform == 'HP-UX'

# Generated at 2022-06-22 23:14:02.289155
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    try:
        module = AnsibleModule(dict(
            ansible_facts={
                'ansible_architecture': 'ia64',
                'ansible_distribution': 'HP-UX',
                'ansible_distribution_version': 'B.11.23',
            }
        ))
        out = HPUXHardware(module)
        out.populate()
    except HPUXHardware:
        pass

# Generated at 2022-06-22 23:14:14.597031
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Test method populate of class HPUXHardware.
    """

    # Set hardware class to HPUXHardware
    hardware_facts = HPUXHardware()

    # Set ansible_architecture to 9000/800
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware_facts.get_cpu_facts(collected_facts=collected_facts)
    hardware_facts.get_memory_facts(collected_facts=collected_facts)
    hardware_facts.get_hw_facts(collected_facts=collected_facts)

    # Set ansible_architecture to 9000/785
    collected_facts = {'ansible_architecture': '9000/785'}
    hardware_facts.get_cpu_facts(collected_facts=collected_facts)