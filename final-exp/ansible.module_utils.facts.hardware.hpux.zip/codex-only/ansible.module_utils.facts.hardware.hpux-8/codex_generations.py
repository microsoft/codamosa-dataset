

# Generated at 2022-06-22 23:04:23.317255
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    class TestModule(object):
        def __init__(self, out1, out2, out3, out4, out5):
            self.out1 = out1
            self.out2 = out2
            self.out3 = out3
            self.out4 = out4
            self.out5 = out5

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "/usr/bin/vmstat | tail -1":
                return 0, self.out1, ''
            if cmd == "grep Physical /var/adm/syslog/syslog.log":
                return 0, self.out2, ''

# Generated at 2022-06-22 23:04:27.741455
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(dict(ansible_distribution='HP-UX', ansible_distribution_version='B.11.23'))
    hw.module = MockModule()
    hw.collector = None
    hw.populate()
    hw.get_hw_facts()


# Generated at 2022-06-22 23:04:38.209012
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('', (object,), {})()
    ansible_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw = HPUXHardware(module, ansible_facts)
    rc, out, err = module.run_command = lambda *args, **kwargs: (0, '4\n', '')
    assert hw.get_cpu_facts() == {'processor_count': 4}

    ansible_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw = HPUXHardware(module, ansible_facts)

# Generated at 2022-06-22 23:04:51.068438
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({'architecture': 'ia64'})
    assert hw.platform == 'HP-UX'
    assert hw.cpu.config is not None
    assert hw.cpu.config.name == 'cpu_config'
    assert hw.cpu.cpu_stats is not None
    assert hw.cpu.cpu_stats.name == 'cpu_stats'
    assert hw.cpu.num_cpus is not None
    assert hw.cpu.num_cpus.name == 'num_cpus'
    assert hw.memory.mem_info is not None
    assert hw.memory.mem_info.name == 'mem_info'
    assert hw.memory.swap_info is not None
    assert hw.memory.swap_info.name == 'swap_info'

# Generated at 2022-06-22 23:05:00.503471
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = dict(platform='HP-UX', distribution='B.11.23')
    hardware = HPUXHardware(dict(), collected_facts)

    data = 'Superdome X server (Superdome X) with 2045 MB RAM\n'
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts.get('model') == data.strip()
    assert hw_facts.get('firmware_version') == '5.5'
    assert hw_facts.get('product_serial') == '1234567890'


# Generated at 2022-06-22 23:05:07.484611
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test HPUXHardware().get_cpu_facts() to validate cpu facts
    """
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list'),
        'filter': dict(default='*', type='str')
    })
    hw_facts = HPUXHardware(module).populate()
    assert hw_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2666 v3 @ 2.90GHz'
    assert hw_facts['processor_count'] == 2
    assert hw_facts['processor_cores'] == 10


# Generated at 2022-06-22 23:05:17.043526
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Create some data to run unit tests on method get_cpu_facts of class HPUXHardware
    """
    # ar.ia64 = ia64
    processor_cores = int("1")
    processor = "Intel(r) Itanium(r) Processor 9300 series"
    processor_count = int("4")
    # ar.9000/800 = rp3440
    processor_cores = int("12")
    processor = "PA-RISC 2.0"
    processor_count = int("2")
    # ar.9000/785 = rp4440
    processor_cores = int("2")
    processor = "PA-RISC 2.0"
    processor_count = int("1")

# Generated at 2022-06-22 23:05:24.918518
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeModule()
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    hardware_facts = hardware.get_hw_facts(collected_facts)
    assert hardware_facts['model'] == 'ia64 hp server rx8620'
    assert hardware_facts['firmware_version'] == 'HPD6'
    assert hardware_facts['product_serial'] == 'USGH0000000'


# Generated at 2022-06-22 23:05:29.641317
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    unittest.TestCase.maxDiff = None
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts[u'processor_count'] == 2


# Generated at 2022-06-22 23:05:36.920951
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({})
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hardware.get_hw_facts(collected_facts)
    assert hardware.facts['model'] == 'ia64 hp server rx2660'
    assert hardware.facts['firmware_version'] == 'S9G1'

# Generated at 2022-06-22 23:05:40.908382
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'distribution': 'HP-UX', 'platform': 'HP-UX'}
    hardware_collector = HPUXHardwareCollector(facts, None)
    assert hardware_collector.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-22 23:05:43.961996
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hc = HPUXHardwareCollector()
    assert hpux_hc._platform == 'HP-UX'
    assert hpux_hc.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:05:55.765744
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Dict for collected facts
    facts = {
        'architecture': 'ia64',
        'distribution': 'HP-UX',
        'distribution_version': 'B.11.23'
    }
    hw = HPUXHardware(dict(), facts)
    results = hw.populate()
    assert results['processor_cores'] == 4
    assert results['processor_count'] == 1
    assert results['processor'] == 'Intel Itanium 2 9100 series'
    assert results['memfree_mb'] > 0
    assert results['memtotal_mb'] > 0
    assert results['swaptotal_mb'] > 0
    assert results['swapfree_mb'] > 0
    assert results['model'] == 'rp3410'

# Generated at 2022-06-22 23:06:05.280339
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec=dict())
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31')
    hpux_hardware = HPUXHardware(module)
    result = hpux_hardware.populate(collected_facts=collected_facts)
    assert result['processor_count'] == 2
    assert result['processor_cores'] == 4
    assert result['processor'] == 'Intel(R) Itanium(R) processor 9300 series'
    assert result['memtotal_mb'] == 8192
    assert result['memfree_mb'] > 100
    assert result['model'] == 'Integrity rx2660'

# Generated at 2022-06-22 23:06:11.292059
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware({}, {})
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock()

    # Test for HP-UX B.11.23
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version' : 'B.11.23'}
    hardware.module.run_command.return_value = (0, '', '')
    hardware.get_memory_facts(collected_facts)
    hardware.module.run_command.assert_called()

    # Test for HP-UX B.11.31
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-22 23:06:17.221674
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpux_hw = HPUXHardware({})
    collected_facts = {
        'ansible_architecture': '9000/800',
    }
    assert hpux_hw.get_cpu_facts(collected_facts=collected_facts) == {
        'processor':  u'parisc',
        'processor_cores':  1,
        'processor_count':  2
    }

# Generated at 2022-06-22 23:06:18.957267
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'


# Generated at 2022-06-22 23:06:22.409314
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert(isinstance(h, HardwareCollector))
    assert(h.fact_class is HPUXHardware)


# Generated at 2022-06-22 23:06:32.078710
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from distutils.version import LooseVersion
    from ansible.module_utils.facts import FactCollector

    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
            'gather_timeout': dict(default=10, type='int'),
        },
        supports_check_mode=True,
    )

    fact_collector = FactCollector(module=module)
    facts = fact_collector.collect(['platform', 'architecture', 'distribution', 'distribution_version'])

    expected_facts = {}
    if facts['platform'] == 'HP-UX':
        hw_facts = HPUXHardware(module=module).populate(facts)

# Generated at 2022-06-22 23:06:34.682544
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModuleMock({})
    harware_class = HPUXHardware(module)
    assert harware_class.platform == 'HP-UX'



# Generated at 2022-06-22 23:06:38.805156
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:06:41.363467
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hg = HPUXHardwareCollector()
    assert hg.platform == 'HP-UX'
    assert hg._fact_class == HPUXHardware


# Generated at 2022-06-22 23:06:47.639089
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23'
    }
    test_hw = HPUXHardware(data, None)
    # Test for model
    if test_hw.populate()['model'] != 'ia64':
        raise AssertionError()
    # Test for firmware
    if test_hw.populate()['firmware_version'] != '03.78':
        raise AssertionError()



# Generated at 2022-06-22 23:06:59.140304
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = DummyModule()
    hw = HPUXHardware(module)

    cpu_facts_1 = hw.get_cpu_facts()
    assert cpu_facts_1['processor_count'] == 4
    assert cpu_facts_1['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts_1['processor_cores'] == 8

    collected_facts_1 = dict(ansible_architecture='9000/800')
    cpu_facts_2 = hw.get_cpu_facts(collected_facts=collected_facts_1)
    assert cpu_facts_2['processor_count'] == 4
    assert 'processor' not in cpu_facts_2
    assert 'processor_cores' not in cpu_facts_2


# Generated at 2022-06-22 23:07:04.645848
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector._platform == 'HP-UX'
    assert hpux_hardware_collector._fact_class == HPUXHardware


if __name__ == '__main__':
    pass

# Generated at 2022-06-22 23:07:07.661100
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware()
    assert hardware_obj.platform == 'HP-UX'
    assert hardware_obj.facts == dict()


# Generated at 2022-06-22 23:07:15.317734
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'
    assert not hw.memfree_mb
    assert not hw.memtotal_mb
    assert not hw.processor
    assert not hw.processor_cores
    assert not hw.processor_count
    assert not hw.model
    assert not hw.firmware
    assert not hw.serial_number



# Generated at 2022-06-22 23:07:20.551141
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUX_Hardware = HPUXHardware()
    data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    HPUX_Hardware.populate(collected_facts=data)
    # Verify processor_cores is not set to 0
    assert HPUX_Hardware.facts['processor_cores'] > 0

# Generated at 2022-06-22 23:07:23.976548
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModuleStub()
    hardware_facts = HPUXHardware(module)
    assert isinstance(hardware_facts.platform, str)
    assert hardware_facts.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:27.371725
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({}, {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:31.676453
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # test an instance of HPUXHardwareCollector
    hw = HPUXHardwareCollector({},{},{})

    assert hw.platform == "HP-UX"
    assert hw.required_facts == set(['platform', 'distribution']), hw.required_facts

# Generated at 2022-06-22 23:07:38.935207
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpu = HPUXHardware()
    hpu.module = AnsibleModuleMock()
    hpu.module.run_command = MagicMock()

# Generated at 2022-06-22 23:07:50.748329
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hw = HPUXHardware(module)

    # Manually set facts, like we would with an actual ansible module.
    hw.facts['ansible_architecture'] = '9000/800'
    out = hw.get_memory_facts()
    assert out['memfree_mb'] == 2971
    assert out['memtotal_mb'] == 2048
    assert out['swaptotal_mb'] == 7864
    assert out['swapfree_mb'] == 2560

    hw.facts['ansible_architecture'] = 'ia64'
    hw.facts['ansible_distribution_version'] = 'B.11.23'

    out = hw.get_memory_facts()
    assert out

# Generated at 2022-06-22 23:08:00.212222
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Define Module instance
    module = type('obj', (object,), {'run_command': run_command})

    # Define HPUXHardware instance
    hux_hw = HPUXHardware(module)

    # Define empty module object
    module = type('obj', (object,), {'run_command': run_command})

    # Init an empty object
    hux_hw = HPUXHardware(module)

    # Define 'ansible_facts'
    ansible_facts = {'ansible_architecture': '9000/800'}

    # Call method
    memory_facts = hux_hw.get_memory_facts(collected_facts=ansible_facts)
    # Assert the number of retrieved key/values
    assert len(memory_facts.keys()) == 4
    # Assert

# Generated at 2022-06-22 23:08:13.303922
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware({'module': dict()})
    hw.module.run_command = lambda *args, **kwargs: (0, 'Foo\n', '')
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.populate(collected_facts)
    assert hw_facts['processor_count'] == 1
    assert hw_facts['memtotal_mb'] == 1024
    assert hw_facts['memfree_mb'] == 512
    assert hw_facts['swaptotal_mb'] == 1024
    assert hw_facts['swapfree_mb'] == 512
    assert hw_facts['model'] == 'Foo'
    assert hw_facts

# Generated at 2022-06-22 23:08:19.860919
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    collected_facts = dict(ansible_architecture='ia64')

    hw_facts = dict(memtotal_mb=1024, memfree_mb=123, swaptotal_mb=2048, swapfree_mb=456)

    hpux_hw = HPUXHardware(module)
    memory_facts = hpux_hw.get_memory_facts(collected_facts=collected_facts)

    assert memory_facts == hw_facts



# Generated at 2022-06-22 23:08:21.389611
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    target = HPUXHardwareCollector()
    result = target.platform
    assert result == 'HP-UX'


# Generated at 2022-06-22 23:08:33.081830
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_obj = HPUXHardware(module=module, collected_facts={'ansible_architecture': 'ia64',
                                                                'ansible_distribution_version': 'B.11.23'})
    hardware_obj.get_cpu_facts()
    assert module.params['cpu_facts']['processor_count'] == 2
    assert module.params['cpu_facts']['processor'] == 'Intel(R) Itanium(R) 9300 series'
    assert module.params['cpu_facts']['processor_cores'] == 1

    module = FakeAnsibleModule()

# Generated at 2022-06-22 23:08:45.869410
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hardware_facts = HPUXHardware(module).populate(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['memtotal_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) processor'


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    from ansible.module_utils.facts.hardware.hpux import *

    module = AnsibleModuleMock()

# Generated at 2022-06-22 23:08:48.920675
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    assert hardware_obj.platform == "HP-UX"


# Generated at 2022-06-22 23:09:02.447323
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw_facts = HPUXHardware({}, {'platform': 'HP-UX', 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert hw_facts.get_cpu_facts() == {}

    hw_facts = HPUXHardware({}, {'platform': 'HP-UX', 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert hw_facts.get_cpu_facts() == {}


# Generated at 2022-06-22 23:09:10.044997
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hardware.module = MockModule()
    hardware.module.run_command = Mock(return_value=(0, 'test', 'test'))
    facts = hardware.get_hw_facts({'ansible_architecture': 'ia64',
                                   'ansible_distribution_version': 'B.11.23'})
    assert facts['firmware_version'] == 'test'
    assert facts['model'] == 'test'
    assert facts['product_serial'] == 'test'



# Generated at 2022-06-22 23:09:13.003707
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={}, support_check_mode=True)
    hardware_facts = HPUXHardware(module=module).populate()
    assert hardware_facts['processor_count']

# Generated at 2022-06-22 23:09:18.189977
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """ This is a pre-cursor for unit testing code for
    HPUXHardwareCollector class. It checks if you have the right
    methods of the class.
    """

    obj = HPUXHardwareCollector()

    _methods = ['get_facts']

    for method in _methods:
      assert hasattr(obj, method)


# Generated at 2022-06-22 23:09:29.464610
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hpux_hardware = HPUXHardware()
    memory_facts = hpux_hardware.get_memory_facts({'ansible_architecture': 'ia64'})
    assert memory_facts['memtotal_mb'] == 24576
    assert memory_facts['swaptotal_mb'] == 32768
    assert memory_facts['swapfree_mb'] == 32768
    # Test on small size server.
    memory_facts = hpux_hardware.get_memory_facts({'ansible_architecture': '9000/800'})
    assert memory_facts['swaptotal_mb'] == 16
    assert memory_facts['swapfree_mb'] == 16

# Generated at 2022-06-22 23:09:32.021507
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict(), dict())

    assert hw.platform == 'HP-UX'

# Generated at 2022-06-22 23:09:44.233558
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module = MockModule()
    hardware.module.run_command.return_value = (0, "", "")

    facts = hardware.get_memory_facts()

    assert hardware.module.run_command.call_count == 4
    assert hardware.module.run_command.call_args_list[0][0][0] == "/usr/bin/vmstat | tail -1"
    assert hardware.module.run_command.call_args_list[1][0][0] == "grep Physical /var/adm/syslog/syslog.log"

# Generated at 2022-06-22 23:09:45.346004
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:09:58.444419
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = None

    hw = HPUXHardware(TestModule())

    # Test populate with PA-RISC
    TestModule.run_command = lambda self, args: (0, "24\n", '')
    hw.module.ansible_architecture = '9000/800'
    hw_facts = hw.populate({'ansible_architecture': '9000/800'})
    assert hw_facts['processor_count'] == 24
    assert hw_facts['memfree_mb'] == 515
    assert hw_facts['memtotal_mb'] == 2048
    assert hw_facts['swaptotal_mb'] == 0

# Generated at 2022-06-22 23:10:00.920831
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    #Mock module
    module = AnsibleModuleMock()
    h = HPUXHardware(module)
    h.get_memory_facts()
    module.run_command.assert_any_call('/usr/sbin/swapinfo -m -d -f -q', check_rc=False)


# Generated at 2022-06-22 23:10:06.743081
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    hpux_hw = HPUXHardware(module=None, facts=hardware_facts)
    assert hpux_hw.processor_count == 2
    assert hpux_hw.processor_cores == 24
    assert hpux_hw.processor == "Intel(R) Xeon(R) CPU E7-8890 v3 @ 2.50GHz"
    assert hpux_hw.memtotal_mb == 16384

    hardware_facts['ansible_architecture'] = '9000/800'
    hpux_hw = HPUXHardware(module=None, facts=hardware_facts)
    assert hpux_hw

# Generated at 2022-06-22 23:10:10.573036
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:10:18.614169
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
            'filter': dict(required=False, type='str'),
            'gather_timeout': dict(required=False, type='int'),
        }
    )
    hw_collector = HPUXHardwareCollector()
    facts = hw_collector.collect(module, [])
    assert isinstance(facts, dict)
    assert 'hardware' in facts
    assert 'processor' in facts['hardware']
    assert 'processor_cores' in facts['hardware']
    assert 'processor_count' in facts['hardware']
    assert 'firmware_version' in facts['hardware']



# Generated at 2022-06-22 23:10:29.419070
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    testcase for method get_hw_facts of class HPUXHardware
    """
    from ansible.module_utils.facts.hardware.hpuxtest import MockModule
    from ansible.module_utils.facts.hardware.hpuxtest import MockRunCommand
    from ansible.module_utils.facts.hardware.hpuxtest import MockFile
    module = MockModule
    module.run_command = MockRunCommand
    os.access = MockFile

    hw = HPUXHardware(module)
    assert hw.get_hw_facts()['model'] == 'Server rx8640'

    module.run_command = MockRunCommand
    os.access = MockFile
    hw = HPUXHardware(module)

# Generated at 2022-06-22 23:10:41.089315
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # With output of vmstat command
    module = MockAnsibleModule
    module.run_command.return_value = (0, " procs     memory     page disk", "")
    module.run_command.return_value = (0, " r b p swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st", "")
    module.run_command.return_value = (0, " 0 0 0     0 184340  14880  53136    0    0     0     0    0    0  0  0 100  0  0", "")
    module.run_command.return_value = (0, " 0 0 0     0  46052  15496  54140    0    0     0     0    0    0  0  0 100  0  0", "")


# Generated at 2022-06-22 23:10:53.764331
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Init new HPUXHardware object
    hphw = HPUXHardware()

    #######################
    # Test populate method 
    #######################
    # When 
    # Then
    assert hphw.populate() == {}

    #######################
    # Test get_cpu_facts method 
    #######################
    # When
    # Then
    assert hphw.get_cpu_facts() == {}
    assert hphw.get_cpu_facts({}) == {}
    assert hphw.get_cpu_facts({'ansible_architecture': '9000/800'}) == {'processor_count': 1}
    assert hphw.get_cpu_facts({'ansible_architecture': '9000/785'}) == {'processor_count': 1}

# Generated at 2022-06-22 23:11:00.500855
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, None, None)
    test_obj = HPUXHardware(module=module)
    test_obj.populate()
    assert test_obj.memory['memtotal_mb'] == 10
    assert test_obj.cpu['processor_cores'] == 8
    assert test_obj.hardware['firmware_version'] == 'HPUX v1.31'
    assert test_obj.hardware['product_serial'] == 'SN12345'



# Generated at 2022-06-22 23:11:13.575488
# Unit test for method get_memory_facts of class HPUXHardware

# Generated at 2022-06-22 23:11:24.508433
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    def run_command(module, command):
        if command == 'model':
            return 0, 'HP-UX vPars partition', ''
        elif command == '/usr/contrib/bin/machinfo |grep -i \'Firmware revision\' | grep -v BMC':
            return 0, 'Firmware revision : C.06.00', ''
        elif command == "/usr/contrib/bin/machinfo |grep -i 'Machine serial number' ":
            return 0, 'Machine serial number = 4CE076E', ''
    module = type('', (), {})
    module.run_command = run_command
    module.__setattr__('CHECKMODE', False)
    module.__setattr__('_ansible_supports_check_mode', False)
    hw_facts = HPUXHardware

# Generated at 2022-06-22 23:11:33.371904
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params['facts'] = dict()
    current_facts = dict(ansible_facts=dict(hardware=dict()), ansible_architecture='9000/785')
    hardware = HPUXHardware(module)
    hardware.populate()
    cpu_facts = hardware.get_cpu_facts(collected_facts=current_facts['ansible_facts']['hardware'])
    module.exit_json(changed=False, ansible_facts=dict(hardware=dict(processors=dict(cpus=cpu_facts))))


# Generated at 2022-06-22 23:11:42.070724
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hw = HPUXHardware(module=module)
    # A.11.31
    collected_facts_ia64 = {'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX',
                            'ansible_distribution_major_version': '11',
                            'ansible_distribution_version': 'B.11.31'}
    # B.11.23
    collected_facts_ia64_b23 = {'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX',
                                'ansible_distribution_major_version': '11',
                                'ansible_distribution_version': 'B.11.23'}
    # 32 bits

# Generated at 2022-06-22 23:11:51.162933
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hpux_hw_class = HPUXHardware(dict(), False)
    test_data = {'ansible_system': 'HP-UX',
                 'ansible_architecture': 'ia64'}
    memory_facts = hpux_hw_class.get_memory_facts(collected_facts=test_data)
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0


# Generated at 2022-06-22 23:11:54.272697
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector()

    assert hardware.platform == 'HP-UX'
    assert hardware._fact_class == HPUXHardware
    assert hardware.required_facts == set(['platform', 'distribution'])


# HP-UX-specific subclass of Hardware.

# Generated at 2022-06-22 23:12:05.650256
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h = HPUXHardware()
    collected_facts = {'kernel': 'HP-UX', 'ansible_architecture': '9000/800',
                       'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'}
    hardware_collector = HPUXHardwareCollector()
    hardware_collector.populate(h, collected_facts)

    assert h.platform == 'HP-UX'
    assert h.processor_count == 8
    assert h.processor_cores == 1
    assert h.processor == 'Intel 9100 Series CPU @ 1.60GHz'
    assert h.memtotal_mb == 35342
    assert h.memfree_mb == 3635
    assert h.swaptotal_mb == 128
    assert h.swapfree_mb == 128


# Generated at 2022-06-22 23:12:13.058957
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hpux_hardware_test_1 = HPUXHardware()
    hpux_hardware_test_1.module = AnsibleModuleMockup(
        dict={'ansible_architecture': '9000/800'}
    )
    hpux_hardware_test_1.module.run_command = run_command_mockup

    hpux_hardware_test_2 = HPUXHardware()
    hpux_hardware_test_2.module = AnsibleModuleMockup(
        dict={'ansible_architecture': 'ia64'}
    )
    hpux_hardware_test_2.module.run_command = run_command_mockup

    hpux_hardware_test_3 = HPUXHardware()
    hpux_hardware_test_3.module = Ans

# Generated at 2022-06-22 23:12:14.977893
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_facts = HPUXHardwareCollector()
    assert hardware_facts._platform == 'HP-UX'

# Generated at 2022-06-22 23:12:23.526155
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hardware.module = FakeANSIModule()
    hardware.module.run_command.side_effect = (
        (0, "DL580 G7", ""),  # model
        (0, "Firmware revision = I19", ""),  # machinfo
        (0, "2017-01-01", ""), # date
    )
    hw_facts = hardware.get_hw_facts()

    assert hw_facts["model"] == "DL580 G7"
    assert hw_facts["firmware_version"] == "I19"
    assert hw_facts["firmware_date"] == "2017-01-01"


# Generated at 2022-06-22 23:12:36.293499
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module)

    # Test with empty collected_facts
    hardware.populate()
    expected = dict(processor_count=8, processor_cores=8, processor="Intel(R) Itanium(R) Processor 9320", memfree_mb=1395, memtotal_mb=4096, swapfree_mb=30976, swaptotal_mb=32128, model="9000/800", firmware_version="J08", product_serial="12345")
    assert hardware.get_facts() == expected

    # Test with collected_facts with ansible_architecture and ansible_distribution_version
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version="B.11.23")

# Generated at 2022-06-22 23:12:40.881409
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_facts = HPUXHardwareCollector(None, {}, {'platform': 'HP-UX'}, None)
    assert hpux_facts.platform == 'HP-UX'
    assert hpux_facts._fact_class == HPUXHardware
    assert hpux_facts._platform == 'HP-UX'
    assert hpux_facts.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:12:44.279898
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector._fact_class.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-22 23:12:45.387609
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()


# Generated at 2022-06-22 23:12:51.013902
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    module.exit_json(changed=False, ansible_facts=dict(ansible_hardware=hardware_obj.populate()))


# Generated at 2022-06-22 23:12:57.433450
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert isinstance(hw, HPUXHardware)
    assert isinstance(hw, Hardware)
    assert hw.platform == 'HP-UX'
    assert hw.populate() is not None
    assert hw.get_cpu_facts() is not None
    assert hw.get_memory_facts() is not None
    assert hw.get_hw_facts() is not None



# Generated at 2022-06-22 23:13:03.951073
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    facts = hw.populate()

    assert facts is not None
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'model' in facts
    assert 'firmware_version' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts


# Generated at 2022-06-22 23:13:13.489632
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = {
        'processor_count': 2,
        'processor': 'Intel(R) Xeon(R) CPU E5-2620 v3 @ 2.40GHz',
        'processor_cores': 1
    }
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': "B.11.23"
    }
    hw_obj = HPUXHardware()
    processor_facts = hw_obj.get_cpu_facts(collected_facts=collected_facts)
    assert processor_facts == cpu_facts

# Generated at 2022-06-22 23:13:18.011767
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = AnsibleModule(argument_spec={})
    hw.module.run_command = MagicMock(return_value=(0, 'unit_test', None))
    hw_facts = hw.get_hw_facts()

    assert hw_facts['model'] == 'unit_test'


# Generated at 2022-06-22 23:13:29.374355
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class MockModule():
        def run_command(self, cmd):
            if cmd == "model":
                return 0, "HP-RACK", ""
        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd
    module = MockModule()
    hpuxtest = HPUXHardware(module)
    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hw_facts = hpuxtest.get_hw_facts(collected_facts)
    assert hw_facts['model'] == "HP-RACK"


# Generated at 2022-06-22 23:13:36.045119
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware({})
    rc, out, err = hardware.module.run_command("echo 'free=563260'")
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 563260 * 4 / 1024 / 1024
    assert memory_facts['memtotal_mb'] == 0



# Generated at 2022-06-22 23:13:44.886463
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HW_FACT = HPUXHardware(dict())
    result = HW_FACT.get_hw_facts({'ansible_architecture': 'ia64',
                                   'ansible_distribution_version': 'B.11.23',
                                   'ansible_machine_id': 'XXX',
                                   'ansible_distribution': 'HP-UX'})
    expected = {'firmware_version': 'P44',
                'model': 'HP9000/rx2600'}
    assert result == expected

# Generated at 2022-06-22 23:13:46.832360
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(dict(), False)
    return hw.get_hw_facts()

# Generated at 2022-06-22 23:13:53.492299
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.collector import CollectedFacts

    collected_facts = CollectedFacts()
    collected_facts.add("ansible_architecture", 'ia64')
    collected_facts.add("ansible_distribution_version", 'B.11.23')

    cls = HPUXHardware()
    cls.module = "module"

    cls.get_hw_facts_ok()



# Generated at 2022-06-22 23:14:04.778501
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    def mock_run_command(self, command):
        return 0, 'HP9000/785', ''

    module = type('AnsibleModuleFake', (object, ), {'run_command': mock_run_command})
    hpux_hw = HPUXHardware(module)
    collected_facts = {'platform': 'HP-UX', 'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}
    hw_facts = hpux_hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts == {'model': 'HP9000/785'}
    collected_facts = {'platform': 'HP-UX', 'ansible_architecture': '9000/800'}
    hw_facts = hpux_hw

# Generated at 2022-06-22 23:14:17.033126
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )

    # mock gather facts to get cpu facts
    def mock_gather_facts(self, module, collected_facts):
        return {'ansible_architecture': '9000/800'}

    HPUXHardware.get_cpu_facts = mock_gather_facts
    # mock run_command of HPUXHardware to get cpu facts
    def mock_run_command(self, command, module, use_unsafe_shell=False):
        return 123, "", ""

    HPUXHardware.module.run_command = mock_run_command

    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts()

