

# Generated at 2022-06-22 23:04:10.675955
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.platform == 'HP-UX'
    assert HPUXHardware in h.fact_class_map.values()
    assert h._required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:04:22.965135
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class HPUXHardware.
    To execute the unit test, execte the following command from the root directory of the project:
    tox -e py36 tests/unit/utils/facts/hardware/hpux_test.py
    """

    import unittest
    from unittest.mock import patch
    from ansible.module_utils.facts.hardware.hp_ux import HPUXHardware

    class HPUXHardwareTestCase(unittest.TestCase):
        def setUp(self):
            self.hpux_hardware_instance = HPUXHardware(module=None)

        def test_is_hpux_hardware_instance(self):
            self.assertIsInstance(self.hpux_hardware_instance, HPUXHardware)


# Generated at 2022-06-22 23:04:27.821039
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Test HPUXHardwareCollector class
    """

    hpux_hardware_collector = HPUXHardwareCollector({'platform': 'HP-UX'})
    assert hpux_hardware_collector.__class__.__name__ is 'HPUXHardwareCollector'
    assert hpux_hardware_collector._platform is 'HP-UX'

# Generated at 2022-06-22 23:04:36.629680
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware({}, None)
    hw_facts = hw.populate(collected_facts={'ansible_architecture': '9000/800','ansible_distribution_version': "B.11.23"})
    assert hw_facts['processor_count'] == 2
    assert hw_facts['memfree_mb'] == 990
    assert hw_facts['swaptotal_mb'] == 2047
    assert hw_facts['swapfree_mb'] == 2047
    assert hw_facts['processor'] == 'Intel(R) Itanium(R) Processor'


# Generated at 2022-06-22 23:04:41.914569
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_obj = HPUXHardware()
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    expected_return = {
        'processor_count': 4,
        'processor_cores': 2,
        'processor': 'Intel(R) Itanium(R) Processor 9650'
    }
    assert hardware_obj.get_cpu_facts(collected_facts) == expected_return


# Generated at 2022-06-22 23:04:53.446645
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = type('', (), {})
    setattr(module, '_ansible_version', '2.4.2.0')
    setattr(module, '_ansible_module_created', 'Wed Jan 24 05:11:37 2018')
    module.params = {}
    module.run_command = lambda x: (0, '', '')
    HPUXHW = HPUXHardware(module)

# Generated at 2022-06-22 23:05:04.373452
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware()
    module.get_bin_path = lambda x: '/usr/bin/' + x
    rc, out, err = module.run_command("/usr/contrib/bin/machinfo | grep 'Firmware revision'", use_unsafe_shell=True)
    out = out.split('=')[1].strip()
    rc, out1, err = module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    out1 = out1.split('=')[1].strip()
    rc, out2, err = module.run_command("/usr/contrib/bin/machinfo | grep core", use_unsafe_shell=True)

# Generated at 2022-06-22 23:05:10.391022
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test method get_hw_facts of class HPUXHardware
    """
    import ansible.module_utils.facts.hardware.hpux
    facts = ansible.module_utils.facts.hardware.hpux.HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = facts.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'HPHXA0'
    assert hw_facts['product_serial'] == '003712201'

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_

# Generated at 2022-06-22 23:05:13.215543
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardwareCollector
    assert isinstance(HPUXHardwareCollector(), HPUXHardwareCollector)

# Generated at 2022-06-22 23:05:26.077496
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware()
    collected_facts = {}
    hw.module.run_command = lambda *args, **kwargs: (0, '1', '')
    hw.module.get_bin_path = lambda *args, **kwargs: "bin_%s" % args[0]
    hw.get_cpu_facts = lambda: {'processor': 'Intel', 'processor_cores': 1, 'processor_count': 1}
    hw.get_memory_facts = lambda: {'memtotal_mb': 128, 'memfree_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0}
    hw.get_hw_facts = lambda: {}

# Generated at 2022-06-22 23:05:33.888743
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Check that the get_memory_facts method return the right values depending on
    the architecture
    """
    hw = HPUXHardware()
    vmstat_out = "r b w   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st\n0 0 0 779356 142081157 5789264 12132650    0    0     0     0    6   39  0  0 100  0  0"
    machinfo_out = "Memory: 1856 MB (1928479232 bytes)  Page size: 16384 bytes  Boot path: 0/0/4/0.0.0  Firmware Version: v1.2 (11/28/06)"

# Generated at 2022-06-22 23:05:44.555612
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hardware = HPUXHardware()
    hardware.module = module

    rc, out, err = module.run_command("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)
    count = int(out.strip())

    # Testing B.11.23
    fake_collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23',
    }
    facts = hardware.populate(fake_collected_facts)
    assert facts['processor_count'] == count
    assert facts['processor_cores'] == count

    # Testing B.11.31

# Generated at 2022-06-22 23:05:46.674855
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    obj_hw_collector = HPUXHardwareCollector()
    assert obj_hw_collector.platform == 'HP-UX'
    assert obj_hw_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-22 23:05:51.580861
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hpux_hw = HPUXHardware(module)
    facts = hpux_hw.get_cpu_facts({'ansible_architecture': '9000/785'})
    assert facts['processor_count'] == 8


# Generated at 2022-06-22 23:05:57.741223
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(module=None)
    facts = {}
    # For Architecture PA-RISC
    facts['ansible_architecture'] = '9000/800'
    # For Architecture IA-64
    facts['ansible_architecture'] = 'ia64'
    facts['ansible_distribution_version'] = 'B.11.23'
    expected = {'processor_count': 2, 'processor': 'Itanium 2', 'processor_cores': 8}
    assert hardware.get_cpu_facts(facts) == expected

# Generated at 2022-06-22 23:06:07.413208
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hw = HPUXHardware(module)

    hw.populate()
    assert hw.facts.get('processor_count') == 4
    assert hw.facts.get('processor') == "Itanium(R) Processor model number 7300"
    assert hw.facts.get('processor_cores') == 2
    assert hw.facts.get('memtotal_mb') == 6098
    assert hw.facts.get('memfree_mb') == 5590
    assert hw.facts.get('swaptotal_mb') == 1258
    assert hw.facts.get('swapfree_mb') == 1257
    assert hw.facts.get('model') == "HP Integrity rx8640 Server"
    assert hw

# Generated at 2022-06-22 23:06:09.001692
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    hardware = HPUXHardware()

    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-22 23:06:14.433284
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    c = HPUXHardwareCollector()
    assert c.platform == 'HP-UX', 'HPUXHardwareCollector platform error'
    assert c.required_facts == set(['platform', 'distribution']), 'HPUXHardwareCollector.required_facts error'

# Generated at 2022-06-22 23:06:24.254820
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module.run_command = MagicMock(return_value=[0, 'HP rp8420 (9000/800) B.11.31 U ia64 104904149236', ''])
    test_module.get_bin_path = MagicMock(return_value='')
    test_module.params = {}

    test_HPUXHardware = HPUXHardware(module=test_module)
    facts_result = test_HPUXHardware.get_hw_facts()
    assert facts_result['model'] == 'HP rp8420 (9000/800) B.11.31 U ia64 104904149236'

# Generated at 2022-06-22 23:06:30.434712
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    # Init HPUXHardwareCollector and HPUXHardware modules
    collector = HPUXHardwareCollector(module=module)
    collected_facts = collector.collect()
    hw_module = HPUXHardware(module=module)

    # Populate memory and CPU facts
    hw_module.populate(collected_facts)



# Generated at 2022-06-22 23:06:40.459899
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic
    from ansible.module_utils.facts.hardware.hpu import HPUXHardware

    m_args = basic.AnsibleModuleArgs()
    facts_instance = ansible_facts.AnsibleFacts(m_args)
    facts_instance.gather_sys_facts()
    hpuxHardware_instance = HPUXHardware(facts_instance)

    rc, out, err = hpuxHardware_instance.module.run_command("echo \"Mem:    0          0         0         0         0          \nSwap:   0          0         0         0         0          \"")
    data = (re.sub(' +', ' ', out.strip()))

# Generated at 2022-06-22 23:06:43.840353
# Unit test for method get_memory_facts of class HPUXHardware

# Generated at 2022-06-22 23:06:51.823371
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_file_path = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(test_file_path, "hpux_machinfo.txt")
    test_fh = open(test_file, "r")
    mock_run_command = lambda *args, **kwargs: (0, test_fh.read(), '')
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    hw_facts = HPUXHardware(mock_run_command).get_hw_facts({'platform': 'HP-UX', 'ansible_architecture': 'ia64'})
    assert 'firmware_version' in hw_facts
    assert 'product_serial' in hw_facts
    assert hw

# Generated at 2022-06-22 23:06:58.555861
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    # Basic test for system B.11.11 9000/785
    collected_facts = dict(
        ansible_architecture='9000/785',
        ansible_processor=[
            'PA-RISC2.0',
            'PA-RISC2.0'],
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.11'
    )
    result = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert result == {'processor_count': 2}

    # Basic test for system B.11.23 ia64

# Generated at 2022-06-22 23:07:11.307594
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    def module_run_command_mock(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False):
        if command == 'model':
            out = "ia64 hp server rx6600"
        elif command == "ioscan -FkCprocessor | wc -l":
            out = 2
        elif command == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
            out = "Number of CPUs = 2"
        elif command == "/usr/contrib/bin/machinfo | grep 'processor family'":
            out = "Intel(R) Itanium(R) Processor family          : Tiger4"

# Generated at 2022-06-22 23:07:17.255888
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    executable = '/usr/bin/grep'
    args = 'hp_ux'
    module = MockModule(executable, args)
    hardware_instance = HPUXHardware(module)
    assert hardware_instance.platform == 'HP-UX'
    assert hardware_instance.module == module


# Generated at 2022-06-22 23:07:28.770766
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Unit test for get_memory_facts

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = args[0]

        def run_command(self, command, use_unsafe_shell=False):
            return 0, test_output[command], ""

    def get_memory_facts():
        module = FakeModule("")
        obj = HPUXHardware(module)
        return obj.get_memory_facts()

    # Test for B.11.31 PA-RISC
    test_output = {'echo \'phys_mem_pages/D\' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk \'{print $2}\'': "65536"}
    facts = get_memory_facts()

# Generated at 2022-06-22 23:07:33.275414
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = dict(platform='HP-UX')
    expected_ansible_os_family = 'HP-UX'
    expected_platform_subclass = 'HPUXHardware'
    returned_hw = HPUXHardware(facts)
    assert returned_hw.platform == facts['platform']
    assert returned_hw.subclass == expected_platform_subclass
    assert returned_hw.ansible_os_family == expected_ansible_os_family

# Generated at 2022-06-22 23:07:44.911185
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts_output = 'HP Integrity rx2800 i4  \n'
    hw_facts_model = 'HP Integrity rx2800 i4'
    hw_facts_firmware = '8.38'
    hw_facts_serial = '0xC8F1C2A'

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class ModuleExit(Exception):
        pass

    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.params = dict()
            self.exit_json = lambda obj: AnsibleExitJson()
            self.fail_json = lambda obj: AnsibleFailJson()

# Generated at 2022-06-22 23:07:48.757923
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({})
    hw_facts = hw.get_hw_facts()
    assert hw_facts and 'model' in hw_facts and 'firmware_version' in hw_facts


# Generated at 2022-06-22 23:07:59.102310
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    rc, out, err = hw.module.run_command("/usr/contrib/bin/machinfo", use_unsafe_shell=True)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
    }
    cpu_facts = hw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    collected_facts = {
        'ansible_architecture': '9000/800',
    }
    cpu_facts = hw.get_cpu_

# Generated at 2022-06-22 23:08:11.482004
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    gathered_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    hardware = HPUXHardware(module)
    facts = hardware.populate(gathered_facts=gathered_facts)
    assert facts['processor_count'] == 2, 'processor_count expected to be 2'
    assert facts['processor_cores'] == 6, 'processor_cores expected to be 6'
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor 9320', 'processor expected to be Intel(R) Itanium(R) Processor 9320'

# Generated at 2022-06-22 23:08:21.109797
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    out = hardware.get_hw_facts(collected_facts)
    assert out['firmware_version'] == 'HPI C.00.54'
    assert out['model'] == '9000/800/L2000'

    # check for B.11.31 release <= 1204
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    out = hardware.get_hw_facts(collected_facts)
    assert out['firmware_version'] == 'HPI C.00.54'

# Generated at 2022-06-22 23:08:25.141007
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    hardware = HPUXHardware({}, {})
    assert hardware.platform == 'HP-UX'
    assert hardware.required_facts == set(['ansible_architecture', 'ansible_distribution_version'])

# Generated at 2022-06-22 23:08:27.909711
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert x.platform == 'HP-UX' and x.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-22 23:08:40.418854
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({'platform': 'HP-UX'})
    collected_facts = {'ansible_architecture': '9000/800'}
    rc_exist = False
    out_test = '2'
    err_exist = False
    hardware.module.run_command = lambda cmd, use_unsafe_shell: (rc_exist, out_test, err_exist)
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64'}
    collected_facts = {'ansible_distribution_version': 'B.11.23'}
    rc_exist = False
    err_exist = False

# Generated at 2022-06-22 23:08:52.659012
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import pytest
    from ansible.module_utils.facts.hardware.hpu_ux import HPUXHardware
    import ansible.module_utils.facts.hardware.base
    class TestAnsibleModule(object):
        def __init__(self):
            self.run_command = self.fake_run_command
            self.params = {}
            self.check_mode = False


# Generated at 2022-06-22 23:08:57.874611
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert isinstance(collector._fact_class, HPUXHardware)
    assert collector._platform == 'HP-UX'
    assert collector.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-22 23:09:09.748073
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    import json
    import platform
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    # Case where the system is a HP-UX PA-RISC 9000/785
    input_json = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX',
        'distribution_version': 'B.11.11',
        'architecture': '9000/785'
    }

# Generated at 2022-06-22 23:09:13.538077
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware().get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp servers, rx7640'
    assert hw_facts['firmware_version'] == "HP-UX 11.31 ia64"

# Generated at 2022-06-22 23:09:20.295727
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    '''Check if method return expected data'''
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, ('ia64\tB.11.31\tU ia64\t1300656320', None))
    hardware = HPUXHardware(mock_module, 'abc')
    data = hardware.get_hw_facts()
    assert 'firmware_version' in data
    assert 'product_serial' in data

# Generated at 2022-06-22 23:09:32.297770
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    args = dict(
        ansible_system_vendor='Hewlett-Packard',
        ansible_lsb_distrib_id='HP-UX',
        ansible_os_family='Unix',
        ansible_distribution='HP-UX',
        ansible_distribution_major_version=11,
        ansible_distribution_version=31,
        ansible_architecture='ia64',
    )
    module = FakeModule(**args)
    mem = HPUXHardware(module).get_memory_facts(args)
    assert 'memfree_mb' in mem
    assert 'memtotal_mb' in mem
    assert 'swaptotal_mb' in mem
    assert 'swapfree_mb' in mem



# Generated at 2022-06-22 23:09:36.424417
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h = HPUXHardware({})
    r = h.get_hw_facts({'ansible_architecture': 'ia64'})
    assert r['firmware_version'] == 'P89'
    assert r['model'] == 'ia64 hp server rx2660'
    assert r['product_serial'] == 'US123456789'


# Generated at 2022-06-22 23:09:44.879367
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    test_hardware_facts = HPUXHardwareCollector(None)

    # Here is the functions of class hardware
    populate_method = getattr(HPUXHardware, 'populate')

    test_hardware_facts.collect()
    # Get the facts
    collected_facts = test_hardware_facts.get_facts()
    cpu = populate_method(test_hardware_facts, collected_facts)

    assert cpu['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu['processor_cores'] == 4
    assert cpu['processor_count'] == 2



# Generated at 2022-06-22 23:09:57.972176
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    facts = dict(platform='HP-UX',
                 distribution='HP-UX')
    module = AnsibleModule(argument_spec={})
    module.params = dict()
    hpux_hardware = HPUXHardware(module=module, collected_facts=facts)

    # Mimic getting memory, cpu and hw facts
    facts['memfree_mb'] = 512
    facts['memtotal_mb'] = 1024
    facts['swapfree_mb'] = 512
    facts['swaptotal_mb'] = 1024
    facts['processor'] = 'Intel'
    facts['processor_cores'] = 4
    facts['processor_count'] = 4
    facts['model'] = 'HP-UX'
    facts['firmware_version'] = 'B.11.31'

    # Mimic running commands, suggest they're not present in collected_

# Generated at 2022-06-22 23:10:05.728949
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_LIBFACTORY:
        module.fail_json(msg='hpu_hardware_facts is required for this module')

    hardware = HPUXHardware(loader=None, module=module)
    hardware_facts = hardware.populate()
    module.exit_json(ansible_facts=dict(ansible_hardware=hardware_facts))



# Generated at 2022-06-22 23:10:08.538672
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = Hardware()
    hc = HPUXHardwareCollector(hw)
    assert hc
    hc.get_facts()
    hc.collect()

# Generated at 2022-06-22 23:10:17.436896
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    data = {
        "ansible_facts": {
            "ansible_architecture": "ia64",
            "ansible_distribution": "HP-UX",
            "ansible_distribution_version": "B.11.31",
        },
        "changed": False,
        "invocation": {
            "module_args": {
            }
        },
        "rc": 0,
        "stderr": "",
        "stdout": "",
    }
    h = HPUXHardware(data)
    result = h.get_hw_facts()
    assert type(result) is dict
    assert result['model'] == "ia64 rx2800 i2"
    assert result['firmware_version'] == "1.12"

# Generated at 2022-06-22 23:10:20.587505
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Unit test for class HPUXHardwareCollector"""
    hhc = HPUXHardwareCollector()
    testobj = hhc
    assert testobj is not None

# Generated at 2022-06-22 23:10:30.924996
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.31',
                       'ansible_architecture': 'ia64',
                       }
    expected = {
        'model': 'HP rx8640 Base Model, No CPU(s), 8GB Memory, No HBA',
        'firmware_version': 'v2.61',
        'product_serial': 'XXYYZZ',
    }

    mocked_HPUXHardware_run_command = hardware.run_command

# Generated at 2022-06-22 23:10:32.983283
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform.startswith('HP-UX')

# Generated at 2022-06-22 23:10:43.614139
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Verify if method populate of class HPUXHardware returns
    all facts described bellow for HP-UX platform
    """
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}

    test_class = HPUXHardware()
    test_class.module = test_module

    test_module.run_command = Mock(return_value=(0, "", ""))

# Generated at 2022-06-22 23:10:47.380241
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    Test the constructor of class HPUXHardware.
    """
    module = MockModule()
    facts = HPUXHardware(module)
    assert(isinstance(facts, dict))

# Generated at 2022-06-22 23:10:59.129438
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = None

    # Create an object HPUXHardware
    hpux_hardware_obj = HPUXHardware(module)
    # Create a dict of facts with required parameters
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.23',
    )
    # Call method populate of class HPUXHardware
    hpux_hardware_obj.populate(collected_facts=collected_facts)
    assert hpux_hardware_obj.hw_facts['processor'] == 'Intel(R) Itanium(R) Family Processor'
    assert hpux_hardware_obj.hw_facts['firmware_version'] == '1.5200.0'
    assert hpux_hardware_obj

# Generated at 2022-06-22 23:11:12.738105
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = args = tmpdir = None

    hw = HPUXHardware()
    hw.module = module
    hw.args = args
    hw.tmpdir = tmpdir
    hw.module.run_command = dummy_run_command


# Generated at 2022-06-22 23:11:20.068317
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = dict()
    facts_module = HPUXHardware(module=module)
    collected_facts = dict()
    collected_facts['ansible_architecture'] = '9000/800'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    cpu_facts = facts_module.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 16


# Generated at 2022-06-22 23:11:29.500585
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    collection_mgr = get_collection_mgr(2)  # 2 is index of HPUXHardware in CollectionManager

    hw = HPUXHardware()
    hw.module = AnsibleModuleMock(dict(ansible_architecture='9000/800'))

    hw.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-22 23:11:36.915244
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module_mock = type('module_mock', (object,), {'run_command': get_memory_facts_mock})
    hw_object = HPUXHardware(module_mock)
    hw_facts = hw_object.get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx2800 i2'
    assert hw_facts['firmware_version'] == '01.18'
    assert hw_facts['product_serial'] == 'ver1'



# Generated at 2022-06-22 23:11:39.787975
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpuxHardwareCollectorObject = HPUXHardwareCollector()
    assert hpuxHardwareCollectorObject._fact_class == HPUXHardware
    assert hpuxHardwareCollectorObject._platform == 'HP-UX'
    assert hpuxHardwareCollectorObject.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-22 23:11:51.069920
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw = HPUXHardware({})
    assert hw.get_hw_facts({'ansible_architecture': 'ia64'}) == {'model': 'ia64', 'firmware_version': '4.00', 'product_serial': '507C2790F4'}
    assert hw.get_hw_facts({'ansible_architecture': '9000/800'}) == {'model': '9000/800/L3000', 'firmware_version': '2.23', 'product_serial': 'MXD7238X9R'}



# Generated at 2022-06-22 23:11:57.339291
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'platform': 'HP-UX', 'distribution': 'B.11.23'}
    collected_facts = HPUXHardwareCollector(facts=facts)

    assert collected_facts._fact_class == HPUXHardware
    assert collected_facts._platform == 'HP-UX'
    assert collected_facts.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-22 23:12:00.596555
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor_count'] is not None

# Generated at 2022-06-22 23:12:04.294324
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(dict(ansible_architecture='ia64', ansible_distribution_version="B.11.31"))
    hw_facts = hw.get_hw_facts()
    assert hw_facts



# Generated at 2022-06-22 23:12:07.031185
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({'platform': 'HP-UX', 'distribution': 'HP-UX'})


# Generated at 2022-06-22 23:12:13.750093
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    hardware_collector = HPUXHardwareCollector(module=module)
    assert hardware_collector.platform == 'HP-UX'



# Generated at 2022-06-22 23:12:15.510922
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector('/foo/bar/ansible_module')
    assert hw is not None


# Generated at 2022-06-22 23:12:20.850989
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hphw = HPUXHardware()
    hphw.module = MagicMock()
    hphw.module.run_command.return_value = (0, '9000/800', '')
    hphw.populate()
    assert hphw.facts['model'] == '9000/800'
    assert hphw.facts['firmware_version'] == '0.13'
    assert sorted(hphw.facts.keys()) == ['firmware_version', 'model']


# Generated at 2022-06-22 23:12:33.148959
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = None
    hardware = HPUXHardware(module)

    # Test for empty collected_facts
    collected_facts = dict()
    hardware_facts = hardware.populate(collected_facts)

    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == 'Intel Itanium 9500'
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['model'] == 'ia64 hp server rx2800 i2'
    assert hardware_facts['firmware_version'] == 'v2.24.0'

    # Test for

# Generated at 2022-06-22 23:12:43.115409
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hpux = HPUXHardware(module=module, collected_facts={'ansible_architecture': '9000/800'})
    assert hpux.get_memory_facts()['memfree_mb'] >= 0
    assert hpux.get_memory_facts()['memtotal_mb'] >= 0
    assert hpux.get_memory_facts()['swaptotal_mb'] >= 0
    assert hpux.get_memory_facts()['swapfree_mb'] >= 0

    hpux = HPUXHardware(module=module, collected_facts={'ansible_architecture': 'ia64'})
    assert hpux.get_memory_facts()['memfree_mb'] >= 0

# Generated at 2022-06-22 23:12:50.080187
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': "B.11.23",
    }
    test_obj = HPUXHardware(module=None, facts={})

    result = test_obj.get_hw_facts(data)
    assert result['firmware_version'] == "\"B.11.23\""

# Generated at 2022-06-22 23:12:52.211452
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'



# Generated at 2022-06-22 23:13:01.120269
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({})
    architecture = 'ia64'
    distribution_version = 'B.11.23'
    collected_facts = {'ansible_architecture': architecture,
                       'ansible_distribution_version': distribution_version}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts == {'processor_count': 4,
                         'processor': 'Intel(R) Xeon(R) CPU E7-4820  @ 2.00GHz',
                         'processor_cores': 16}
    architecture = 'ia64'
    distribution_version = 'B.11.31'
    collected_facts = {'ansible_architecture': architecture,
                       'ansible_distribution_version': distribution_version}
    cpu_facts = hardware.get_cpu_facts

# Generated at 2022-06-22 23:13:13.762029
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hardware_obj = HPUXHardware(module=module)
    collected_facts = {
      "ansible_architecture": "9000/800",
      "ansible_distribution": "HP-UX",
      "ansible_system": "HP-UX",
      "ansible_distribution_major_version": "11",
      "ansible_distribution_version": "B.11.31",
      "ansible_distribution_release": "7671"}
    facts = hardware_obj.populate(collected_facts=collected_facts)
    assert "memtotal_mb" in facts
    assert "memfree_mb" in facts
    assert "swaptotal_mb" in facts
    assert "swapfree_mb" in facts
    assert "processor" in facts


# Generated at 2022-06-22 23:13:21.191760
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23',
        'ansible_system': 'HP-UX'
    }
    facts = hardware.populate(collected_facts=collected_facts)
    assert facts['processor'] == "Intel(R) Itanium(R) Processor 9100 series"
    assert facts['processor_cores'] == 8
    assert facts['processor_count'] == 2
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 3221
    assert facts['swaptotal_mb'] == 1024
    assert facts['swapfree_mb'] == 528


# Generated at 2022-06-22 23:13:28.859578
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({'platform': 'HP-UX', 'distribution': 'HP-UX'})
    collected_facts = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts == {'processor_cores': 4, 'processor_count': 2,
                         'processor': 'Intel(R) Itanium 2 processor 9000 series'}

# Generated at 2022-06-22 23:13:38.848408
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_obj = HPUXHardware()

    hardware_obj.module.run_command = lambda x, **kwargs: (0, "8", "")
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts=collected_facts)
    assert(cpu_facts['processor_count'] == 8)
    assert(not cpu_facts.get('processor'))
    assert(not cpu_facts.get('processor_cores'))
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts=collected_facts)
    assert(not cpu_facts.get('processor_count'))

# Generated at 2022-06-22 23:13:46.310106
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware import HPUXHardware
    hw = HPUXHardware()
    facts = hw.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64'})
    assert facts['processor_cores'] == 1
    assert facts['processor_count'] == 1
    assert facts['processor'] == 'Intel(r) Itanium(r) Processor 9100 series'

# Generated at 2022-06-22 23:13:52.840230
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    host_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.23'
    )
    os_instance = HPUXHardwareCollector(host_facts)
    os_instance._get_cmd_data = get_cmd_data
    os_instance.populate()

    assert os_instance._facts['firmware_version'] == 'B.11.23'



# Generated at 2022-06-22 23:13:53.828689
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Test the constructor of HPUXHardwareCollector"""
    HPUXHardwareCollector()

# Generated at 2022-06-22 23:14:05.044955
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    if module.check_mode:
        module.exit_json(changed=False)

    hardware = HPUXHardware(module=module)
    result = hardware.populate()
    assert result['processor'] == 'Intel(R) Itanium(R) Processor 9350'
    assert result['processor_cores'] == 24
    assert result['processor_count'] == 1
    assert result['memtotal_mb'] == 2560
    assert result['memfree_mb'] == 1623
    assert result['swaptotal_mb'] == 2048
    assert result['swapfree_mb'] == 2048
    assert result['model'] == 'ia64 hp Integrity rx8640 Server'

# Generated at 2022-06-22 23:14:17.290081
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactManager

    fact_manager = FactManager(collector_classes=[HPUXHardwareCollector])
    fact_manager.collect()

    # Unit test for method populate of class HPUXHardware. The following
    # method is deprecated and its used to test HPUXHardware functions.
    # We will remove this test when the method is removed.
    facts = Collector().collect(['hardware', 'gather_subset=!all,!min'], None)['ansible_facts']
    assert isinstance(facts['memfree_mb'], int)
    assert isinstance(facts['swapfree_mb'], int)
    assert isinstance(facts['memtotal_mb'], int)