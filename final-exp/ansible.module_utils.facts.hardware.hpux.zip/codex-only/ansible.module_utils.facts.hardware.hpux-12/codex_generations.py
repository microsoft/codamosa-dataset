

# Generated at 2022-06-22 23:04:16.126319
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    '''
    Test the HPUXHardware class constructor
    '''
    harware = HPUXHardware({})
    assert harware
    assert harware.platform == 'HP-UX'

# Generated at 2022-06-22 23:04:27.821506
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # The 'firmware' fact is not defined on this platform, so it is not tested
    mem_re = re.compile('memtotal_mb')
    proc_re = re.compile('processor')
    mdl_re = re.compile('model')
    swap_re = re.compile('swaptotal_mb')

    hw = HPUXHardware()
    hw_facts = hw.populate()
    assert hw_facts is not None
    assert isinstance(hw_facts, dict)
    assert mem_re.match(list(hw_facts.keys())[0])
    assert proc_re.match(list(hw_facts.keys())[1])
    assert swap_re.match(list(hw_facts.keys())[2])

# Generated at 2022-06-22 23:04:32.657000
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': '9000/785',
                       'ansible_distribution': 'hp-ux',
                       'ansible_distribution_version': 'B.11.31',
                       }

    hardware_facts = hardware.populate(collected_facts=collected_facts)

    assert hardware_facts['processor_count'] == 8
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor 9500'
    assert hardware_facts['processor_cores'] == 48
    assert hardware_facts['memtotal_mb'] == 131072
    assert hardware_facts['memfree_mb'] == 124908

# Generated at 2022-06-22 23:04:41.470269
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import unittest

    class TestHPUXHardware(unittest.TestCase):
        """
        Unit test class for testing get_memory_facts method of class HPUXHardware
        """

        def test_get_memory_facts_for_parisc(self):
            """
            Unit test for get_memory_facts
            """
            hw = HPUXHardware()
            hw.module = MockModule()
            hw.module.run_command.return_value = (0, '', '')
            mock_collected_facts = {'ansible_architecture': '9000/800'}

# Generated at 2022-06-22 23:04:44.900748
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector is not None


# Generated at 2022-06-22 23:04:54.229260
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class HPUXHardware
    """
    # Test for method get_cpu_facts for IA-64 systems
    # Test for method get_cpu_facts for IA-64 systems with machinfo
    mock_module, mock_class = get_mock_args()
    mock_module.run_command.return_value = (0, 'Number of CPUs = 2', None)
    mock_collector = mock_class.return_value
    mock_collector._platform = 'HP-UX'
    mock_collector._fact_class = mock_class.return_value
    mock_collector.get_cpu_facts.return_value = {'processor_count': 2}

# Generated at 2022-06-22 23:04:57.927507
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hpux = HPUXHardware({})
    assert hpux.get_memory_facts({}) == {'memfree_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 0}

# Generated at 2022-06-22 23:05:07.368062
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock()
    hpux_hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    collected_facts['ansible_distribution_version'] = "B.11.23"
    hw_facts = hpux_hw.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx4640'
    assert hw_facts['firmware_version'] == 'UX F.0D 03/10/2006'
    collected_facts['ansible_distribution_version'] = "B.11.31"
    hw_facts = hpux_hw.get_hw_facts(collected_facts)

# Generated at 2022-06-22 23:05:09.158422
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_test = HPUXHardware(None)
    hardware_test.populate()

# Generated at 2022-06-22 23:05:18.612437
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.23',
                       'ansible_system': 'HP-UX'}

    # ia64
    hw_facts = hw.get_hw_facts(collected_facts={'ansible_architecture': 'ia64',
                                                'ansible_distribution': 'HP-UX',
                                                'ansible_distribution_version': 'B.11.23',
                                                'ansible_system': 'HP-UX'})
    assert hw_facts['firmware_version'] == '1.13'

# Generated at 2022-06-22 23:05:23.780859
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModuleMock(dict(ansible_os_family=None, ansible_architecture=None))
    hw = HPUXHardware(module)
    hw.get_memory_facts(dict(ansible_distribution_version=None, ansible_architecture=None))

# Generated at 2022-06-22 23:05:32.890482
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """ Test get_memory_facts method of HPUXHardware class """

    class TestModule(object):

        def __init__(self):
            self.architecture = 'ia64'
            self.distribution_version = 'B.11.23'

        def run_command(self, cmd, use_unsafe_shell=False):
            # return out, err, rc
            if cmd == '/usr/contrib/bin/machinfo | grep Memory':
                out = 'Memory: 32 GB physical, 128 GB virtual (1024 MB reserved for PA-RISC boot, 1021 MB reserved for Firmware) \n'
                err = ''
                rc = 0
            if cmd == '/usr/bin/vmstat | tail -1':
                out = '1 1 0 8388608 838857 8'
                err = ''
                rc = 0

# Generated at 2022-06-22 23:05:43.962462
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Create mock module instance
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    hpux_hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': "9000/800", 'ansible_distribution_version': 'B.11.23', 'platform': 'HP-UX'}

    # Create a mock class for run_command and set its values
    class MockRunCommand:
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-22 23:05:48.983945
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    Constructor unit test for class HPUXHardware.
    """
    hpux_hardware = HPUXHardware()
    assert hpux_hardware.platform == 'HP-UX'
    assert hpux_hardware.system == 'HP-UX'


# Generated at 2022-06-22 23:05:57.831940
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeModule()
    rc, out, err = module.run_command("model")
    collected_facts = {'ansible_distribution': 'HP-UX', 'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31', 'ansible_system': 'HP-UX'}
    hw = HPUXHardware(module)
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == out.strip()
    assert 'firmware_version' in hw_facts.keys()
    assert 'product_serial' in hw_facts.keys()



# Generated at 2022-06-22 23:06:02.964877
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_hw = HPUXHardware("module", "command", "tmp")

    assert hpux_hw.module == "module"
    assert hpux_hw.command == "command"
    assert hpux_hw.tmpdir == "tmp"
    assert hpux_hw.platform == "HP-UX"



# Generated at 2022-06-22 23:06:13.175491
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = type('', (), {})()
    module.run_command = lambda x, y=False: ["", "", ""]
    module.get_bin_path = lambda x: "/usr/contrib/bin/machinfo"
    hw = HPUXHardware(module=module)
    facts = hw.populate()
    assert "processor_count" in facts
    assert "processor" in facts
    assert "processor_cores" in facts
    assert "firmware_version" in facts
    assert "product_serial" in facts



# Generated at 2022-06-22 23:06:20.555913
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware(dict()).get_cpu_facts(dict(ansible_architecture="9000/800"))
    assert cpu_facts.get("processor_count") == 1
    assert set(cpu_facts.keys()) == set(["processor_count"])

    cpu_facts = HPUXHardware(dict()).get_cpu_facts(dict(ansible_architecture="9000/785"))
    assert cpu_facts.get("processor_count") == 1
    assert set(cpu_facts.keys()) == set(["processor_count"])

    cpu_facts = HPUXHardware(dict()).get_cpu_facts(dict(ansible_architecture="ia64"))
    assert set(cpu_facts.keys()) == set(["processor", "processor_cores", "processor_count"])

# Generated at 2022-06-22 23:06:30.874899
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # create a collected_facts data structure
    collected_facts = {'platform': 'HP-UX', 'distribution': 'HP-UX'}

    # instantiate an object of the class HPUXHardwareCollector
    obj = HPUXHardwareCollector(module=None, collected_facts=collected_facts)

    # assert the instance created is of type 'HPUXHardwareCollector'
    assert(isinstance(obj, HPUXHardwareCollector))

    # assert that the instance has an attribute called 'facts'
    assert(hasattr(obj, 'facts'))

    # assert that this attribute is of type 'HPUXHardware'
    assert(isinstance(obj.facts, HPUXHardware))

    # assert that the facts instance created has a 'platform' attribute
    assert(hasattr(obj.facts, 'platform'))

   

# Generated at 2022-06-22 23:06:35.133190
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector(None, '.', None)
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:06:39.222736
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    my_hpux = HPUXHardwareCollector()
    assert my_hpux.fact_class._platform == 'HP-UX'
    assert my_hpux.fact_class.__module__ == 'ansible.module_utils.facts.hardware.hpux'

# Generated at 2022-06-22 23:06:46.638906
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('HP-UX', (object,), dict(run_command=lambda x, y: (0, '', '')))
    collected_facts = {'ansible_architecture': 'ia64'}

    hardware = HPUXHardware(module)

    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

    assert hw_facts['model'] == '', 'Model is not empty'
    assert hw_facts['firmware_version'] == '', 'Firmware version is not empty'
    assert hw_facts['product_serial'] == '', 'Product serial is not empty'

# Generated at 2022-06-22 23:06:54.206832
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    if not HPUXHardwareCollector.detect(module):
        pytest.skip('platform is not HP-UX')
    module.exit_json = exit_json
    Command.run_command = fake_run_command
    hw = HPUXHardware(module)
    hw.populate()
    assert hw.facts['processor_count'] == 2
    assert hw.facts['processor_cores'] == 4
    assert hw.facts['processor'] == 'Intel(R) Xeon(R) CPU E5540 @ 2.53GHz'
    assert hw.facts['memtotal_mb'] == 16000
    assert hw.facts['memfree_mb'] == 13000
    assert hw.facts['swaptotal_mb'] == 16000
    assert hw

# Generated at 2022-06-22 23:06:55.794198
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = FakeModule()
    hardware = HPUXHardware(module)

    assert hardware


# Generated at 2022-06-22 23:07:01.184397
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = MockModule({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    hp = HPUXHardware(module)
    assert hp.platform == 'HP-UX'

# Generated at 2022-06-22 23:07:06.853374
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module)
    hw_facts = hardware.get_hw_facts()
    assert hw_facts['model']
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']


# Generated at 2022-06-22 23:07:10.690847
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector('HP-UX')
    assert hwc.platform == 'HP-UX'
    assert hwc.required_facts == {'platform', 'distribution'}


# For testing purpose

# Generated at 2022-06-22 23:07:15.393450
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    mock_ansible_module():
        - mock AnsibleModule class
        - mock basic module arguments (params)
        - makes sure AnsibleModule.run_command() is called with expected args

    mock_run_command():
        - mock subprocess.Popen()
        - returns RC, stdout, stderr
    """

    from ansible.module_utils.facts import hardware

    def mock_ansible_module(additional_params=None):
        """ mock AnsibleModule """

        import ansible.module_utils.facts.hardware.hpuxtohpux

        # load the original module for deeper inspection
        hp_ux_hardware_module = ansible.module_utils.facts.hardware.hpuxtohpux

        # create a mock module with basic params
        mock_module = hp_ux_hard

# Generated at 2022-06-22 23:07:18.969314
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec={
            "gather_subset": dict(default=["!all"], type='list')
        }
    )
    hw = HPUXHardware(module=module)
    hw.populate()

# Generated at 2022-06-22 23:07:22.379179
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    coll = HPUXHardwareCollector()
    assert coll.platform == 'HP-UX'
    assert coll._fact_class == HPUXHardware
    assert coll.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-22 23:07:29.500303
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    host_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.23"
    }
    result = {
        "memfree_mb": 5427,
        "memtotal_mb": 29134,
        "swaptotal_mb": 0,
        "swapfree_mb": 0
    }
    assert HPUXHardware().get_memory_facts(collected_facts=host_facts) == result

# Generated at 2022-06-22 23:07:39.898094
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # initialise
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)
    # setup

# Generated at 2022-06-22 23:07:51.410170
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    obj = HPUXHardware()
    collected_facts = {'ansible_distribution_version': 'B.11.23',
                       'ansible_architecture': 'ia64'}
    cpu_facts = obj.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts.get('processor_count', None) == 12
    assert cpu_facts.get('processor_cores', None) == 2
    assert cpu_facts.get('processor', None) == 'Intel(R) Itanium(R) Processor 9350'

    collected_facts = {'ansible_distribution_version': 'B.11.31',
                       'ansible_architecture': 'ia64'}
    cpu_facts = obj.get_cpu_facts(collected_facts=collected_facts)
    assert cpu

# Generated at 2022-06-22 23:07:58.267986
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MockModule()
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)

    assert hw_facts['model'] == 'ia64 ia64 ia64 GNU/Linux'
    assert hw_facts['firmware_version'] == 'v5.20.0801 (POST)'

# Generated at 2022-06-22 23:08:04.308561
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    assert hw.get_memory_facts() == {'memtotal_mb': 2048,
                                     'swaptotal_mb': 2048,
                                     'swapfree_mb': 1717,
                                     'memfree_mb': 327}


# Generated at 2022-06-22 23:08:16.473777
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # test for 9k class
    module = type('AnsibleModule', (object,), {'run_command': get_run_command})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts == {'swaptotal_mb': 0, 'memfree_mb': 2475, 'memtotal_mb': 9988, 'swapfree_mb': 0}
    # test for ia64 class
    module = type('AnsibleModule', (object,), {'run_command': get_run_command})
    hardware = HPUXHardware(module)

# Generated at 2022-06-22 23:08:28.825612
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = {'run_command': run_command}
    hpux_hw_populate = HPUXHardware(module)
    hpux_hw_populate.populate()
    assert hpux_hw_populate.facts['processor'] is not None
    assert hpux_hw_populate.facts['processor_cores'] is not None
    assert hpux_hw_populate.facts['processor_count'] is not None
    assert hpux_hw_populate.facts['model'] is not None
    assert hpux_hw_populate.facts['firmware_version'] is not None
    assert hpux_hw_populate.facts['memtotal_mb'] is not None
    assert hpux_hw_populate.facts['memfree_mb'] is not None

# Generated at 2022-06-22 23:08:41.348447
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector

    class RunCommand(object):
        def __init__(self, module):
            pass

        def __call__(self, *args, **kwargs):
            return 0, "foo", ""

    setattr(BaseFactCollector, '_platform', 'HP-UX')
    setattr(BaseFactCollector, '_fact_class', HPUXHardware)
    setattr(Facts, 'collector', BaseFactCollector)
    setattr(HPUXHardware, 'module', RunCommand)

    facts = Facts(dict(ansible_architecture='9000/800'))

    expected = dict

# Generated at 2022-06-22 23:08:53.725234
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    try:
        from __main__ import module
    except ImportError:
        module = None
    hw = HPUXHardware({})
    hw.module = module
    hw.module.run_command = lambda *args, **kwargs: (0, 'Test\n', '')
    hw.populate()
    hw.get_hw_facts()
    assert hw.facts['model'] == 'Test'
    hw.module.run_command = lambda *args, **kwargs: (0, 'Firmware revision = test1\n', '')
    hw.get_hw_facts()
    assert hw.facts['firmware_version'] == 'test1'

# Generated at 2022-06-22 23:09:06.910853
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    # Collected_facts which is dict key, dict value of AnsibleModule object
    # will be used in get_cpu_facts, get_memory_facts, get_hw_facts
    # methods of class HPUXHardware as collected_facts
    module.params['gather_subset'] = ['all']

    # ansible_facts dict is dict return by AnsibleModule object
    # it include all of facts
    ansible_facts = {}
    ansible_facts['ansible_architecture'] = 'ia64'
    ansible_facts['ansible_distribution_version'] = 'B.11.31'
    ansible_facts['ansible_architecture'] = 'ia64'
    ansible_facts

# Generated at 2022-06-22 23:09:08.177707
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpuxHardwareCollector = HPUXHardwareCollector()
    assert hpuxHardwareCollector._platform == 'HP-UX'
    assert hpuxHardwareCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:09:09.421223
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m = HPUXHardware()
    f = m.get_cpu_facts()
    assert 'processor' in f
    assert 'processor_cores' in f
    assert 'processor_count' in f


# Generated at 2022-06-22 23:09:17.072566
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_facts = HPUXHardware({})

    assert hardware_facts.platform == 'HP-UX'
    assert hardware_facts.populate() == {'memfree_mb': 1336, 'memtotal_mb': 1023, 'swapfree_mb': 0, 'swaptotal_mb': 0,
                                         'processor': 'Intel(R) Itanium(R) Processor 9100 series',
                                         'processor_cores': 1, 'processor_count': 1, 'model': 'HP Integrity rx2600',
                                         'firmware_version': '1.27.17'}

# Generated at 2022-06-22 23:09:30.173583
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    h = HPUXHardware()
    h.module = MagicMock()

    h.module.run_command.return_value = (0, '   408388   415568  0  659660  0    0    0  313074   3790994199    0    0    0    0     0     0     0     0     0     0     0     0     0', '')
    mem_facts = h.get_memory_facts()
    assert mem_facts == {'memfree_mb': 415568, 'swapfree_mb': 405796, 'swaptotal_mb': 405796, 'memtotal_mb': 408388}

    h.module.run_command.return_value = (0, '403220344', '')
    mem_facts = h.get_memory_facts()
    assert mem

# Generated at 2022-06-22 23:09:33.864489
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = {
        'platform': 'HP-UX'
    }
    h = HPUXHardware(facts)
    assert isinstance(h.facts, dict)

# Generated at 2022-06-22 23:09:36.595604
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector().collect()[0]
    assert hardware.platform == 'HP-UX'


# Generated at 2022-06-22 23:09:46.592893
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = dict(
        ansible_facts=dict(
            ansible_architecture='ia64',
            ansible_distribution_version='B.11.31'))

    h = HPUXHardware()
    h.module = Mock()

# Generated at 2022-06-22 23:09:53.703407
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    params = dict(hw_facts=dict(ansible_architecture='9000/800'),
                  hw_facts_collected=dict(ansible_architecture='9000/800'))
    hpux_hw = HPUXHardware(params)
    hw_facts = hpux_hw.get_cpu_facts()
    assert (hw_facts == {'processor_count': 1})



# Generated at 2022-06-22 23:10:04.827338
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # mock ansible_facts collection
    ansible_facts = {
        'ansible_architecture': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    h = HPUXHardware({'ansible_facts': ansible_facts})
    assert h.get_memory_facts() == {'swapfree_mb': 3909, 'memfree_mb': 522, 'swaptotal_mb': 4280, 'memtotal_mb': 7916}
    ansible_facts['ansible_architecture'] = '9000/785'
    assert h.get_memory_facts() == {'swapfree_mb': 3909, 'memfree_mb': 522, 'swaptotal_mb': 4280, 'memtotal_mb': 7916}

# Unit

# Generated at 2022-06-22 23:10:13.489365
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeModule({'platform': 'HP-UX'})
    facts = HPUXHardware(module).populate()

    assert facts.get('memfree_mb') > 0
    assert facts.get('memtotal_mb') > 0
    assert facts.get('swaptotal_mb') > 0
    assert facts.get('swapfree_mb') > 0
    assert facts.get('processor_cores') > 0
    assert facts.get('processor_count') > 0
    assert facts.get('processor')
    assert facts.get('model')
    assert facts.get('firmware_version')
    assert facts.get('product_serial')



# Generated at 2022-06-22 23:10:24.287056
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Mock facts
    facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31',
    )

    # Run function
    hw_facts = HPUXHardware(module).get_hw_facts(facts)
    assert hw_facts.get('model') == 'ia64 hp server rx2800 i2'
    assert hw_facts.get('firmware_version') == 'v2.50 (01/15/13)'
    assert hw_facts.get('product_serial') == 'US123456789'

# Generated at 2022-06-22 23:10:35.701663
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware({}, dict(ansible_architecture='9000/800'))
    hardware._module.run_command = run_command_mock

# Generated at 2022-06-22 23:10:37.749338
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'

# Generated at 2022-06-22 23:10:40.605456
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = type('test_module', (object,), {"run_command": run_command})
    hardware = HPUXHardware(module)

    assert hardware.facts


# Generated at 2022-06-22 23:10:52.984307
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    hpux_collector = HPUXHardwareCollector(module=module)
    facts = hpux_collector.collect(None, module, [], [])
    assert 'ansible_memfree_mb' in facts, facts
    assert 'ansible_memtotal_mb' in facts, facts
    assert 'ansible_swapfree_mb' in facts, facts
    assert 'ansible_swaptotal_mb' in facts, facts
    assert 'ansible_processor' in facts, facts
    assert 'ansible_processor_cores' in facts, facts
    assert 'ansible_processor_count' in facts, facts
    assert 'ansible_model'

# Generated at 2022-06-22 23:10:54.329725
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    pass


# Generated at 2022-06-22 23:11:02.666097
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hardware = HPUXHardware(dict())
    hardware.module.run_command = run_command_mock
    hardware.module.run_command.side_effect = run_command_mock_output

    processors_count = hardware.get_cpu_facts(test_data)
    assert processors_count['processor_count'] == 4
    assert processors_count['processor'] == 'Intel(R) Itanium 2 9300'
    assert processors_count['processor_cores'] == 8

    test_data['ansible_distribution_version'] = 'B.11.31'
    processors_count = hardware.get_cpu_facts(test_data)

# Generated at 2022-06-22 23:11:10.513883
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_dict = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31'
    }
    test_obj = HPUXHardware(module=None)
    data = test_obj.get_memory_facts(test_dict)
    assert data['memfree_mb'] == 0
    assert data['memtotal_mb'] == 0
    assert data['swapfree_mb'] == 0


# Generated at 2022-06-22 23:11:16.321821
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Function to test constructor of class HPUXHardwareCollector
    """
    collected_facts = {'platform': 'HP-UX'}

    obj = HPUXHardwareCollector(None, collected_facts=collected_facts, gatherer=None)
    assert obj.platform == 'HP-UX'
    assert obj.required_facts == {'platform', 'distribution'}



# Generated at 2022-06-22 23:11:23.233815
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector_obj = HPUXHardwareCollector()
    assert hasattr(hw_collector_obj, '_fact_class')
    assert hasattr(hw_collector_obj, '_platform')
    assert hw_collector_obj._platform == 'HP-UX'
    assert hasattr(hw_collector_obj, 'required_facts')
    assert len(hw_collector_obj.required_facts) == 2


# Generated at 2022-06-22 23:11:29.269316
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # This test is for systems where syslog doesn't contain memory details
    os.access = MagicMock(return_value=True)
    # Default memory size is 16335 MB in case of error
    module = MagicMock(run_command=MagicMock(return_value=(1, '', '')))
    hardware = HPUXHardware(module)
    data = hardware.get_memory_facts()
    assert data['memtotal_mb'] == 16335



# Generated at 2022-06-22 23:11:36.546194
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    class args:
        def __init__(self):
            self.facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

    facts_obj = HPUXHardware(args)
    facts = facts_obj.populate()
    assert 'model' in facts.keys()
    assert 'processor' in facts.keys()
    assert 'processor_cores' in facts.keys()
    assert 'processor_count' in facts.keys()
    assert 'memfree_mb' in facts.keys()
    assert 'memtotal_mb' in facts.keys()
    assert 'swaptotal_mb' in facts.keys()
    assert 'swapfree_mb' in facts.keys()

# Generated at 2022-06-22 23:11:42.064521
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_fact = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware_fact.get_cpu_facts(collected_facts)
    assert cpu_facts.get('processor_count') == 8
    assert cpu_facts.get('processor') == 'Intel(r) Itanium/9000'
    assert cpu_facts.get('processor_cores') == 8
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware_fact.get_cpu_facts(collected_facts)

# Generated at 2022-06-22 23:11:45.546640
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    hardware = HPUXHardware()
    hardware.populate()
    assert hardware.mem_mb

# Generated at 2022-06-22 23:11:49.125983
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hw = HPUXHardwareCollector()
    assert hpux_hw.platform == "HP-UX"
    assert hpux_hw._fact_class.platform == "HP-UX"

# Generated at 2022-06-22 23:11:57.141886
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MockModule()
    hw = HPUXHardware(module)

    # get_hw_facts
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts == {'firmware_version': 'I57 v2.21', 'product_serial': '0'}

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-22 23:12:08.258252
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """ Parameterized unit tests for method get_hw_facts of class HPUXHardware"""
    # parametrize the different inputs and expected results

# Generated at 2022-06-22 23:12:12.358247
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector()
    assert hwc.platform == 'HP-UX'
    assert hwc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-22 23:12:14.785562
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    raw = HPUXHardware()
    assert raw is not None and isinstance(raw, HPUXHardware)



# Generated at 2022-06-22 23:12:24.994615
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Example (raw) input data
    idata = {'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'}
    # Create class instance
    h = HPUXHardware()
    # Call method
    h.populate(idata)
    # Test processor related facts
    assert h.data['processor'] == 'Intel(R) Xeon(R) CPU E5-2687W v4 @ 3.00GHz'
    assert h.data['processor_count'] == 2
    assert h.data['processor_cores'] == 40
    # Test memory related facts
    assert h.data['memfree_mb'] >= 2736
    assert h.data['memtotal_mb'] == 61440
    assert h.data

# Generated at 2022-06-22 23:12:37.645130
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware(dict())
    # When ia64 architecture, B.11.23 release, test populate methods
    # for processor_count, processor, processor_cores and memtotal_mb
    collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.23"
    }
    rc1, out1, err1 = hardware.module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    rc2, out2, err2 = hardware.module.run_command("/usr/contrib/bin/machinfo | grep 'processor family'", use_unsafe_shell=True)
    rc3, out3, err3 = hardware.module.run

# Generated at 2022-06-22 23:12:45.068229
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    rc, out, err = module.run_command("echo 'ia64'")
    collected_facts = {'ansible_architecture': out.strip(),
                       'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64    server'
    assert hw_facts['firmware_version'] == 'S', out
    assert hw_facts['product_serial'] == '123456789', out
    rc, out, err = module.run_command("echo '9000/785'")

# Generated at 2022-06-22 23:12:57.697713
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class FauxModule:
        def run_command(self, args, check_rc=True):
            if args == 'ioscan -FkCprocessor | wc -l':
                return 0, '3', ''
            if args == '/usr/contrib/bin/machinfo | grep \'Number of CPUs\'':
                return 0, 'Number of CPUs = 2', ''
            if args == '/usr/contrib/bin/machinfo | grep processor':
                return 0, 'processor family = Intel(r) Itanium(r) processor 9500 series', ''

    class FauxCollectedFacts:
        def __init__(self, arch, version):
            self.facts = {'ansible_architecture': arch, 'ansible_distribution_version': version}


# Generated at 2022-06-22 23:13:03.304549
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware().populate()
    assert hardware_facts['processor_count'] == hardware_facts['processor_cores']
    assert hardware_facts['processor_count'] >= 1
    assert hardware_facts['memtotal_mb'] >= hardware_facts['memfree_mb']
    assert hardware_facts['swaptotal_mb'] >= hardware_facts['swapfree_mb']
    assert hardware_facts['model']
    assert hardware_facts['firmware_version']

# Generated at 2022-06-22 23:13:12.105668
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts import FactManager
    h = HPUXHardware()
    h.module = FakeAnsibleModule()
    fm = FactManager(h.module, h.collect(), h.__class__.__name__)
    collected_facts = fm.collect()
    collected_facts['ansible_architecture'] = '9000/800'
    h.populate(collected_facts=collected_facts)



# Generated at 2022-06-22 23:13:19.570369
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock(argument_spec={})
    hardware = HPUXHardware(module)

    # Method populate with PA-RISC architecture
    hardware.module.run_command.return_value = (0, '4', '')
    facts_dict = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    hardware.populate(collected_facts=facts_dict)

    # Method populate with Itanium architecture with release B.11.23

# Generated at 2022-06-22 23:13:31.890363
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    HPUXHardware.get_memory_facts() Test
    """
    class TestHPUXHardware():
        def __init__(self):
            pass


# Generated at 2022-06-22 23:13:39.575559
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # Ensure that HPUXHardware class can be initialized properly
    module = AnsibleModule(argument_spec={})
    # All modules should have the supported_by argument
    # At the moment, this argument is hardcoded to the Ansible
    # Engine for all platforms.
    module.supported_by = 'core'
    # Initialize HPUXHardware
    hw = HPUXHardware(module=module)
    assert(hw)



# Generated at 2022-06-22 23:13:51.104418
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    This function will use the module lib
    to test the get_hw_facts function of the class.
    :return:
    """

    class MockModule(object):
        def __init__(self):
            self.run_command = MagicMock(return_value=(0, "", ""))

    class MockFacts(object):
        def __init__(self):
            self.ansible_facts = {'ansible_architecture': 'ia64'}

    # GIVEN: an HPUXHardware class object and a repository with different os version
    stdout_model_data1 = "Model"
    stdout_firmware_data1 = "Firmware revision : P89 v2.75"
    stdout_machine_serial_data1 = "Machine serial number = XYZ0123"
    stdout

# Generated at 2022-06-22 23:13:57.383214
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test with ioscan output.
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['all'], type='list'),
        }
    )
    facts = HPUXHardwareCollector.get_facts(module)
    assert facts['ansible_processor_count'] == 4
    assert facts['ansible_memtotal_mb'][:-1] == '1638'
    assert facts['ansible_memfree_mb'][:-1] == '1401'
    assert facts['ansible_swaptotal_mb'][:-1] == '1599'
    assert facts['ansible_swapfree_mb'][:-1] == '1591'

# Generated at 2022-06-22 23:14:02.238203
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == {'platform', 'distribution'}
    assert set(hw.__dict__) == set(['_collector', '_module', '_collected_facts', 'platform', 'required_facts'])

# Generated at 2022-06-22 23:14:11.213170
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpu = HPUXHardware({})
    assert hpu.populate() == {'processor': 'Intel(R) Itanium(R) Processor 9320', 'processor_cores': 8,
                              'processor_count': 2, 'memtotal_mb': 16384, 'memfree_mb': 10533,
                              'swaptotal_mb': 524288, 'swapfree_mb': 443417, 'model': 'ia64 hp server rx8640',
                              'firmware_version': 'v2.11', 'product_serial': '12345678'}

# Generated at 2022-06-22 23:14:22.911803
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Test get_memory_facts method of class HPUXHardware
    """
    # get_memory_facts method need an Hardware object to run.
    obj_HPUXHardware = HPUXHardware()

    # Test with an IA64 32 bit architecture syslog.log output