

# Generated at 2022-06-24 21:58:50.225898
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = -374
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {}
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 21:59:00.597188
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test 0
    int_0 = -340
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {}
    collected_facts['ansible_architecture'] = "9000/800"
    returned_value = h_p_u_x_hardware_0.get_memory_facts(collected_facts)
    assert returned_value['memfree_mb'] <= returned_value['memtotal_mb']
    assert returned_value['swaptotal_mb'] <= returned_value['swapfree_mb']

    # Test 1
    int_1 = -340
    h_p_u_x_hardware_1 = HPUXHardware(int_1)
    collected_facts = {}
    returned_value = h_p_u_x_hardware

# Generated at 2022-06-24 21:59:05.481334
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 100
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts_0 = None
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 21:59:11.148271
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -340
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts_0 = int_0
    out = h_p_u_x_hardware_0.get_memory_facts(collected_facts_0)
    assert out == int_0


# Generated at 2022-06-24 21:59:20.641814
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    out = "Test"
    err = 'Test'
    in_1 = {}
    rc = 0
    configuration = {'HPUXHardware.module': HPUXHardware.module, 'HPUXHardware.module.run_command.out': out, 'HPUXHardware.module.run_command.err': err, 'HPUXHardware.module.run_command.rc': rc}
    subject = HPUXHardware.HPUXHardware(configuration=configuration)
    result = subject.get_hw_facts(in_1)
    assert result == {'model': 'Test', 'firmware_version': 'Test', 'product_serial': 'Test'}


# Generated at 2022-06-24 21:59:29.801248
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -340
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    dict_0 = {'memfree_mb': 2481388, 'memtotal_mb': 2481388,
              'swaptotal_mb': 0, 'swapfree_mb': 0}
    dict_1 = h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts)
    assert dict_0 == dict_1


# Generated at 2022-06-24 21:59:35.653855
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -206
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    str_0 = '  ,'
    int_0 = -69
    h_p_u_x_hardware_1 = h_p_u_x_hardware_0.get_memory_facts(str_0, int_0)


# Generated at 2022-06-24 21:59:38.948084
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 21:59:47.999126
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)
    if cpu_facts.get('processor_cores') == 4 and cpu_facts.get('processor_count') == 2 and cpu_facts.get('processor') == "Intel(R) Itanium(R) 9300 series CPU @ 1.60GHz":
        return True
    else:
        return False

# Generated at 2022-06-24 21:59:51.784818
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {}
    int_0 = -2
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts['ansible_architecture'] = '9000/800'
    return_value = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 22:00:06.864955
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    h_p_u_x_hardware_0._collected_facts = data
    # Execution of get_cpu_facts
    out = h_p_u_x_hardware_0.get_cpu_facts()
    assert out['processor_count'] == 7


# Generated at 2022-06-24 22:00:13.093332
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert h_p_u_x_hardware_collector_0._fact_class == h_p_u_x_hardware_0, 'Value assigned to' \
                                                                            ' h_p_u_x_hardware_collector_0._fact_class ' \
                                                                            'is not equal to h_p_u_x_hardware_0'
    assert h_p_u_x_hardware_collector_0._platform == "HP-UX", 'Value assigned to' \
                                                              ' h_p_u_x_hardware_collector_0._platform ' \
                                                              'is not equal to HP-UX'


# Generated at 2022-06-24 22:00:15.139501
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:00:18.871485
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test case for method get_cpu_facts of class HPUXHardware
    """
    h_p_u_x_hardware_0 = HPUXHardware()
    cpu_facts = {}
    cpu_facts_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=None)
    assert cpu_facts_0 == cpu_facts


# Generated at 2022-06-24 22:00:23.370667
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    dict_0 = {'ansible_distribution_version': 'B.11.23', 'ansible_architecture': 'ia64'}
    hw_facts_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=dict_0)
    assert hw_facts_0 == {'model': 'HP Integrity rx2600', 'firmware_version': '2.93'}


# Generated at 2022-06-24 22:00:27.193977
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0.get_hardware_instance() is not None


# Generated at 2022-06-24 22:00:30.010503
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()

# Generated at 2022-06-24 22:00:39.493506
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    h_p_u_x_hardware_0 = HPUXHardware(module=module, collected_facts={
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    })

    assert h_p_u_x_hardware_0.get_cpu_facts() == {
        'processor': 'Intel(R) Itanium(R) Processor 9340',
        'processor_cores': 40,
        'processor_count': 2
    }


# Generated at 2022-06-24 22:00:42.693758
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    facts = {}
    h_p_u_x_hardware_0.populate(facts)


# Generated at 2022-06-24 22:00:53.304599
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    cpu_facts_0 = {'processor': 'Itanium 2', 'processor_cores': '2', 'processor_count': '2'}
    collected_facts_0 = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31', 'ansible_distribution': 'HP-UX'}
    memory_facts = h_p_u_x_hardware_collector_0._fact_class.get_memory_facts(collected_facts=collected_facts_0)
    assert memory_facts == {'memtotal_mb': 3072, 'memfree_mb': 320, 'swaptotal_mb': 8192, 'swapfree_mb': 4075}


# Generated at 2022-06-24 22:01:06.835131
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_collector_0.collect()


# Generated at 2022-06-24 22:01:11.540884
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    assert 'ansible_processor_cores' in h_p_u_x_hardware_0.get_cpu_facts()
    assert 'ansible_processor_count' in h_p_u_x_hardware_0.get_cpu_facts()
    assert 'ansible_processor' in h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:17.820980
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)
    assert var_0 == {}


# Generated at 2022-06-24 22:01:19.765189
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    pass
    

# Unit tests for class HPUXHardware

# Generated at 2022-06-24 22:01:22.958816
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()



if __name__ == '__main__':
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:01:26.800573
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    ansible_architecture_0 = 'ia64'
    ansible_distribution_0 = 'HP-UX'
    ansible_distribution_release_0 = 'B.11.31'
    facts = dict(ansible_architecture=ansible_architecture_0, ansible_distribution=ansible_distribution_0,
                 ansible_distribution_release=ansible_distribution_release_0)
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(facts)
    h_p_u_x_hardware_collector_0.collect()

# Generated at 2022-06-24 22:01:30.032051
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    assert h_p_u_x_hardware_0.get_hw_facts() == {}


# Generated at 2022-06-24 22:01:42.460303
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_2 = {}
    var_2['ansible_architecture'] = "9000/800"
    h_p_u_x_hardware_0.module = mock.Mock()
    h_p_u_x_hardware_0.module.run_command = mock.Mock()
    h_p_u_x_hardware_0.module.run_command.return_value = [0,"12",""]
    h_p_u_x_hardware_0.get_cpu_facts = mock.Mock()
    h_p_u_x_hardware_0.get_cpu_facts.return_value = var_0
    h_p_u_

# Generated at 2022-06-24 22:01:46.205420
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # h_p_u_x_hardware_0 = HPUXHardware(
    #     2
    # )
    # h_p_u_x_hardware_0.get_memory_facts()
    # assert 2 == 2
    assert True


# Generated at 2022-06-24 22:01:52.013719
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = {'ansible_architecture': '9000/785',
                       'ansible_distribution_version': 'B.11.31'}
    h_p_u_x_hardware_0 = HPUXHardware(0, collected_facts=collected_facts)
    var_0 = h_p_u_x_hardware_0.populate()
    assert var_0['processor_cores'] == 2
    assert var_0['processor_count'] == 1


# Generated at 2022-06-24 22:02:14.650883
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    rc, out, err = module.run_command("uname -m")
    if out.strip() == 'ia64':
        rc, out, err = module.run_command("uname -r")
        if out.strip() == 'B.11.23':
            rc, out, err = module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
            if out:
                cpu_facts['processor_count'] = int(out.strip().split('=')[1])
            rc, out, err = module.run_command("/usr/contrib/bin/machinfo | grep 'processor family'", use_unsafe_shell=True)

# Generated at 2022-06-24 22:02:22.800598
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = dict(ansible_architecture = "9000/800")
    var_0 = h_p_u_x_hardware_0.populate(collected_facts)
    assert var_0['processor_count'] == 64
    assert var_0['processor'] == "Intel Itanium 2"
    assert var_0['memfree_mb'] == 16384
    assert var_0['memtotal_mb'] == 131072
    assert var_0['swapfree_mb'] == 131072
    assert var_0['swaptotal_mb'] == 131072
    collected_facts = dict(ansible_architecture = 'ia64')
    var_1 = h

# Generated at 2022-06-24 22:02:32.214264
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts)
    assert var_0 == {'model': 'ia64 hp server rx4640', 'firmware_version': '1.32', 'product_serial': 'US*3V8J9SN'}


# Generated at 2022-06-24 22:02:38.849011
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = "B.11.23"
    hw_facts = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'v5.5.5.5'


# Generated at 2022-06-24 22:02:41.300936
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:43.918192
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:02:48.730848
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_0 = -446
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(int_0)
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware and h_p_u_x_hardware_collector_0.required_facts == {'platform', 'distribution'} and h_p_u_x_hardware_collector_0._platform == 'HP-UX'

# main program
if __name__ == "__main__":
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:02:51.775803
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_1 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:59.175466
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector({})
    assert h_p_u_x_hardware_collector_0.platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])
    assert type(h_p_u_x_hardware_collector_0._fact_class) == type(HPUXHardware(0))

test_case_0()
test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:03:07.742588
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_0.get_cpu_facts = MagicMock(return_value={
        'processor_count': 2,
        'processor': 'Intel(R) Xeon(R) CPU E7-8890 v2 @ 2.80GHz'
    })

# Generated at 2022-06-24 22:03:24.539480
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    map_0 = h_p_u_x_hardware_0.get_cpu_facts()
    print(map_0)


# Generated at 2022-06-24 22:03:33.540732
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    # Try to call method get_hw_facts of class HPUXHardware
    try:
        h_p_u_x_hardware_0.get_hw_facts(None)
    except:
        pass

    try:
        h_p_u_x_hardware_0.get_hw_facts({})
    except:
        pass

    try:
        h_p_u_x_hardware_0.get_hw_facts({'ansible_architecture': 'ia64'})
    except:
        pass


# Generated at 2022-06-24 22:03:40.558320
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Create an instance of HPUXHardware
    h_p_u_x_hardware_0 = HPUXHardware(1464)

    # Invoke method
    var_0 = h_p_u_x_hardware_0.get_memory_facts()

    # Check for test coverage
    assert var_0 is not None


# Generated at 2022-06-24 22:03:43.671904
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == "__main__":
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:03:47.609169
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # setup
    int_0 = -895
    h_p_u_x_hardware_0 = HPUXHardware(int_0)

    # test
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:50.182357
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_collector_0.collect()

################################################################################
# End of unit tests for HPUX hardware facts
################################################################################

# Generated at 2022-06-24 22:03:52.823542
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector._fact_class == HPUXHardware
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-24 22:04:00.241296
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts_0 = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts_0)


# Generated at 2022-06-24 22:04:08.302020
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Input parameters
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts)
    assert 'firmware_version' in var_0
    assert 'model' in var_0
    

# Generated at 2022-06-24 22:04:10.735820
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:49.161606
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_1 = HPUXHardware()
    ansible_architecture_0 = '9000/785'
    ansible_distribution_version_0 = 'B.11.31'
    collected_facts_0 = {'ansible_distribution_version': ansible_distribution_version_0, 'ansible_architecture': ansible_architecture_0}
    h_p_u_x_hardware_1.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:04:54.521609
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_1 = None
    h_p_u_x_hardware_1 = HPUXHardware(var_1)
    var_1 = {'ansible_architecture': 'ia64'}
    var_1 = h_p_u_x_hardware_1.get_memory_facts(var_1)


# Generated at 2022-06-24 22:04:56.633888
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert(isinstance(HPUXHardwareCollector(), object))


# Generated at 2022-06-24 22:05:02.062732
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_0 = -547
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(int_0)
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)



# Generated at 2022-06-24 22:05:11.793179
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    test = HPUXHardwareCollector._fact_class
    test._platform
    test._fact_class._platform
    test._fact_class.platform
    test._fact_class.required_facts
    HPUXHardwareCollector._fact_class.required_facts
    HPUXHardwareCollector._fact_class.required_facts = set()
    HPUXHardwareCollector._fact_class.required_facts = set(['platform', 'distribution'])
    HPUXHardwareCollector._fact_class.required_facts
    HPUXHardwareCollector._fact_class.required_facts = HPUXHardwareCollector._fact_class.required_facts
    HPUXHardwareCollector._fact_class.required_facts = H

# Generated at 2022-06-24 22:05:16.638704
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Test with an argument
    h_p_u_x_hardware_0 = HPUXHardware(-246)
    var_0 = h_p_u_x_hardware_0.populate()
    # Test without an argument
    h_p_u_x_hardware_1 = HPUXHardware(-330)
    var_1 = h_p_u_x_hardware_1.populate()


# Generated at 2022-06-24 22:05:22.397147
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.populate()
    assert var_0 == {'memfree_mb': 45943, 'memtotal_mb': 160464, 'processor': 'Intel(R) Itanium(R) CPU       9180  @ 2.20GHz', 'processor_cores': 32, 'processor_count': 6, 'swapfree_mb': 3200, 'swaptotal_mb': 3200, 'firmware_version': 'v8.20.00', 'product_serial': 'USC1037AX39', 'model': 'HP Integrity rx8640'}


# Generated at 2022-06-24 22:05:24.634180
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

# Generated at 2022-06-24 22:05:29.281163
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = test_case_0()
    print(HPUXHardware.get_cpu_facts.__doc__)
    try:
        print(h_p_u_x_hardware_0.get_cpu_facts())
    except:
        print('Caught exception')


# Generated at 2022-06-24 22:05:33.162980
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_0 = -446
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(int_0)


# Generated at 2022-06-24 22:06:03.557995
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    import datetime

    int_0 = 0
    #Testcase
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.get_cpu_facts()
    h_p_u_x_hardware_0.get_memory_facts()
    h_p_u_x_hardware_0.get_hw_facts()
    assert True


# Generated at 2022-06-24 22:06:06.550917
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts_0 = {}
    collected_facts_0['ansible_distribution_version'] = "B.11.31"
    int_1 = -446
    h_p_u_x_hardware_1 = HPUXHardware(int_1)
    cpu_facts_0 = h_p_u_x_hardware_1.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:06:12.566232
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.module = MockModule()
    str_0 = ''
    h_p_u_x_hardware_0.module.run_command = Mock(return_value=(0, str_0, str_0))
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:06:16.873532
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    # Try to get "model" fact
    assert h_p_u_x_hardware_0._get_hw_facts()["model"] == "Integrity rx2660"


# Generated at 2022-06-24 22:06:22.469650
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = -131043
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    result = h_p_u_x_hardware_0.get_cpu_facts()
    assert result == {'processor_count': 1, 'processor': 'Intel(R) Itanium(R) Processor', 'processor_cores': 1}


# Generated at 2022-06-24 22:06:24.016382
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    int_0 = -732
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:06:29.143752
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = -447
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.11'}
    var_0 = h_p_u_x_hardware_0.get_hw_facts(var_0)
    print(var_0)


# Generated at 2022-06-24 22:06:31.594116
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert callable(HPUXHardwareCollector)


# Generated at 2022-06-24 22:06:34.146115
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Arrange

    # Act
    # uut
    test_case_0()

    # Assert
    assert True # no exception


# Generated at 2022-06-24 22:06:38.372817
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = -354
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:07:43.706336
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:07:45.893681
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:07:54.812833
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {u'ansible_architecture': u'ia64', u'ansible_distribution_version': u'B.11.23'}
    h_p_u_x_hardware_0._module.run_command = lambda *x: (0, u'Intel         Itanium 2', u'')
    h_p_u_x_hardware_0._module.run_command = lambda *x: (0, u'Firmware revision =  C.07.21', u'')
    h_p_u_x_hardware_0._module.run_command = lambda *x: (0, u'Machine serial number = SERIALNUMBER', u'')
   

# Generated at 2022-06-24 22:07:59.321013
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:08:03.881159
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {}

    h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts)


# Generated at 2022-06-24 22:08:07.474809
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -214
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    assert h_p_u_x_hardware_0.get_memory_facts() == {}


# Generated at 2022-06-24 22:08:13.663991
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    interface_0 = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    var_0 = h_p_u_x_hardware_0.get_memory_facts(interface_0)


# Generated at 2022-06-24 22:08:18.201104
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_1 = -93
    h_p_u_x_hardware_1 = HPUXHardware(int_1)
    collected_facts_1 = {}
    h_p_u_x_hardware_1.module.run_command = MagicMock(return_value=(0, 'nothing', 'nothing'))
    h_p_u_x_hardware_1.get_cpu_facts(collected_facts_1)


# Generated at 2022-06-24 22:08:20.132630
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = -446
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    hw_facts = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:08:26.282430
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # instanciation of class HPUXHardware
    h_p_u_x_hardware_0 = HPUXHardware()
    # unittest.TestCase.assertEqual(first, second, msg=None)
    # unittest.TestCase.assertTrue(expr, msg=None)
    h_p_u_x_hardware_0.get_cpu_facts()
