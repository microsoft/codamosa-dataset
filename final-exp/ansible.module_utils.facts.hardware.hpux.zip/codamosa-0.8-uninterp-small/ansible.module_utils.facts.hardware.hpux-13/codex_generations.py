

# Generated at 2022-06-24 21:58:52.626210
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-24 21:58:59.689517
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = {'distribution': 'HP-UX', 'platform': 'HP-UX', 'architecture': 'ia64'}
    h_p_u_x_hardware_0 = HPUXHardware(facts=facts)
    # AssertionError: <type 'exceptions.AttributeError'> != <type 'NoneType'>
    try:
        h_p_u_x_hardware_0.get_memory_facts()
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-24 21:59:12.015248
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.module = str
    h_p_u_x_hardware.module.run_command = lambda x, encoding=None, errors='strict', use_unsafe_shell=False, foo=None: (0, '6', '')
    h_p_u_x_hardware.module.run_command = lambda x, encoding=None, errors='strict', use_unsafe_shell=False, foo=None: (0, '6', '')
    h_p_u_x_hardware.module.run_command = lambda x, encoding=None, errors='strict', use_unsafe_shell=False, foo=None: (0, 'Intel', '')
    h_p_u_x_

# Generated at 2022-06-24 21:59:21.549784
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware = HPUXHardware()
    rc, out, err = h_p_u_x_hardware.module.run_command("swapinfo -m -d -f -q")
    assert out.strip() == str(h_p_u_x_hardware.get_memory_facts()['swaptotal_mb'])
    rc, out, err = h_p_u_x_hardware.module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    assert out.strip() == str(h_p_u_x_hardware.get_memory_facts()['memfree_mb'])


# Generated at 2022-06-24 21:59:32.196879
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    rc, out, err = h_p_u_x_hardware_0.module.run_command("model")
    h_p_u_x_hardware_0.module.run_command("model")
    out_0 = out.strip()
    if out_0:
        rc_1, out_1, err_1 = h_p_u_x_hardware_0.module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'",
                                                                  use_unsafe_shell=True)
        if not err_1:
            data_0 = out_1
            memory_facts_

# Generated at 2022-06-24 21:59:37.515023
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    results = HPUXHardware().get_hw_facts()

    assert results['model'] == 'ia64 hp server rx8620', 'Unexpected value for model'
    assert results['firmware_version'] == '2.60', 'Unexpected value for firmware_version'
    assert results['product_serial'] == 'CZC30333R0', 'Unexpected value for product_serial'


# Generated at 2022-06-24 21:59:48.045326
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    # get_cpu_facts available output
    rc, out, err = 4, "", "ioscan: Class processor not found"
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command.return_value = rc, out, err
    h_p_u_x_hardware_0.module.params = {}
    h_p_u_x_hardware_0.ansible_facts = {'ansible_architecture': '9000/785'}
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts()
    assert cpu_facts['processor_count'] == 0

    rc,

# Generated at 2022-06-24 21:59:50.723868
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 21:59:58.934080
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware({})
    data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    result = h_p_u_x_hardware_0.get_memory_facts(collected_facts=data)
    assert result == {'swapfree_mb': 3915, 'memtotal_mb': 1638396, 'memfree_mb': 511, 'swaptotal_mb': 3915}



# Generated at 2022-06-24 21:59:59.438070
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    pass


# Generated at 2022-06-24 22:00:15.034193
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -72.40
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts = {}
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts)


# Generated at 2022-06-24 22:00:25.983596
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Setting up test values
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = "ansible_architecture='9000/800'"
    collected_facts_1 = "ansible_architecture='9000/785'"
    collected_facts_2 = "ansible_architecture='ia64'"
    collected_facts_3 = "ansible_architecture='ia64', ansible_distribution: 'B.11.31'"
    collected_facts_4 = "ansible_architecture='ia64', ansible_distribution: 'B.11.23'"

    # Invoking method

# Generated at 2022-06-24 22:00:38.537756
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = -2
    str_0 = str(int_0)
    str_1 = str(int_0)
    str_2 = str(int_0)
    str_3 = str(int_0)
    str_4 = str(int_0)
    str_5 = str(int_0)
    str_6 = str(int_0)
    str_7 = str(int_0)
    str_8 = str(int_0)
    str_9 = str(int_0)
    str_10 = str(int_0)
    str_11 = str(int_0)
    str_12 = str(int_0)
    str_13 = str(int_0)
    str_14 = str(int_0)
    str_15 = str(int_0)

# Generated at 2022-06-24 22:00:42.186606
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()



# Generated at 2022-06-24 22:00:47.757543
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = -175.01
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    assert h_p_u_x_hardware_collector_0.platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware

# Generated at 2022-06-24 22:00:51.853106
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:59.239471
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = {}
    collected_facts_0['ansible_architecture'] = 'ia64'
    collected_facts_0['ansible_distribution_version'] = "B.11.31"
    assert h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0) == {'processor': 'Intel(R) Xeon(R) CPU           X5650  @ 2.67GHz', 'processor_count': 8, 'processor_cores': 4}
    collected_facts_1 = {}
    collected_facts_1['ansible_architecture'] = 'ia64'

# Generated at 2022-06-24 22:01:01.496170
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    assert not HPUXHardware.get_memory_facts(None, None)


# Generated at 2022-06-24 22:01:11.299556
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    expected_dict_keys = ['memtotal_mb', 'swaptotal_mb', 'swapfree_mb', 'memfree_mb']
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    h_p_u_x_hardware_0.get_memory_facts(collected_facts)
    returned_dict_keys = h_p_u_x_hardware_0.facts.keys()
    assert len(returned_dict_keys) == len(expected_dict_keys)

# Generated at 2022-06-24 22:01:16.193663
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = -175.01
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    return h_p_u_x_hardware_collector_0


# Generated at 2022-06-24 22:01:46.580809
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    float_1 = -6.179
    float_2 = -300.778
    float_3 = -136.252
    float_4 = -79.8
    float_5 = -389.53
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    h_p_u_x_hardware_1 = HPUXHardware(float_1)
    h_p_u_x_hardware_1._HPUXHardware__set_logger(float_2)
    var_1 = h_p_u_x_hardware_1.get_memory_facts()
    h_p_u_x_hardware_

# Generated at 2022-06-24 22:01:50.372252
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_1 = -67.80
    h_p_u_x_hardware_1 = HPUXHardware(float_1)
    with pytest.raises(AttributeError):
        h_p_u_x_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:01:53.832206
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    print(h_p_u_x_hardware_0.get_hw_facts())


# Generated at 2022-06-24 22:01:59.071212
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts = {}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 22:02:01.861558
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -138.29
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = {'ansible_architecture': '9000/785'}
    var_0 = h_p_u_x_hardware_0.get_memory_facts(var_0)
    assert var_0 == {'memfree_mb': 755, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 1084}


# Generated at 2022-06-24 22:02:06.827896
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts = {}
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts)


# Generated at 2022-06-24 22:02:09.726811
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = -175.01
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    var_0 = h_p_u_x_hardware_collector_0.collect()

# Generated at 2022-06-24 22:02:13.446583
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware('i')
    h_p_u_x_hardware_0.get_hw_facts()
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:02:18.183981
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts({'ansible_architecture': 'ia64'})
    assert var_0 == {'firmware_version': '0x1', 'model': 'ia64 HP rx2660 Baseboard', 'product_serial': 'CN953420S4'}


# Generated at 2022-06-24 22:02:21.091851
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = -116.07
    # Case 0: requirement platform is HP-UX
    # Case 1: requirement platform is not HP-UX
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    var_0 = h_p_u_x_hardware_collector_0.collect()

# Generated at 2022-06-24 22:03:21.938480
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert callable(HPUXHardwareCollector)


# Generated at 2022-06-24 22:03:25.695543
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:03:27.157253
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector_0 = HPUXHardwareCollector()
    assert hpux_hardware_collector_0 is not None


# Generated at 2022-06-24 22:03:30.848771
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:03:34.209905
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    print(h_p_u_x_hardware_0.get_memory_facts())


# Generated at 2022-06-24 22:03:45.366663
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0._module = MockModule()
    h_p_u_x_hardware_0._module.run_command = Mock(return_value=(0, '', ''))
    h_p_u_x_hardware_0._facts = dict()
    h_p_u_x_hardware_0._facts['ansible_architecture'] = 'ia64'

    h_p_u_x_hardware_0._facts['ansible_distribution_version'] = "B.11.23"

    actual_result, exp_result = h_p_u_x_hardware_0.get_memory_facts(), dict()


# Generated at 2022-06-24 22:03:48.888804
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:49.712186
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    assert True


# Generated at 2022-06-24 22:03:53.061644
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = -1.35
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    h_p_u_x_hardware_0.populate(collected_facts)
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:03:55.780570
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:41.060167
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test for correct cpu facts for HP-UX
    """
    # Create a test fixture
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)

    # test for correct processor count for 9000/785/800 HP-UX
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, "2\n", ""))
    collected_facts = {'ansible_architecture':'9000/785'}
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2

    # test for correct processor count & model for ia64 HP-UX
    h_p

# Generated at 2022-06-24 22:04:46.303310
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()

if __name__ == "__main__":
    test_case_0()
    test_HPUXHardware_populate()

# End of generated code

# Generated at 2022-06-24 22:04:56.749825
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = -123.46
    h_p_u_x_hardware_0 = HPUXHardware(float_0)

    platform_0 = 'ia64'
    dist_0 = 'HP-UX'
    collected_facts_0 = {'platform': platform_0, 'distribution': dist_0}
    ansible_0 = {'ansible_architecture': platform_0}
    collected_facts_0.update(ansible_0)
    h_p_u_x_hardware_0.module.params.update({'platform': platform_0})
    h_p_u_x_hardware_0.module.params.update({'distribution': dist_0})

# Generated at 2022-06-24 22:05:06.930765
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    str_0 = '      9  8192K'
    h_p_u_x_hardware_0.module.run_command = lambda x: (0, str_0, '')
    dict_0 = {'ansible_architecture': 'ia64'}
    str_1 = ''
    h_p_u_x_hardware_0.module.run_command = lambda x: (0, dict_0, str_1)
    dict_1 = {'ansible_architecture': 'ia64'}
    h_p_u_x_hardware_0.module.run_command = lambda x: (0, dict_1, str_1)
   

# Generated at 2022-06-24 22:05:12.906545
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = 25.5
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    assert h_p_u_x_hardware_collector_0.platform is 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class is HPUXHardware

# Generated at 2022-06-24 22:05:16.324279
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_0 = 3
    int_1 = 1
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(int_0, int_1)
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware


# Generated at 2022-06-24 22:05:19.993201
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:21.206478
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    #TODO - implement test
    test_case_0()


# Generated at 2022-06-24 22:05:25.301354
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(0.0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:33.569108
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0, 'ansible_architecture', 'processor_cores', 'ansible_distribution_version')
    h_p_u_x_hardware_0.program = '/usr/sbin/swapinfo'
    h_p_u_x_hardware_0.check_output = 't'
    h_p_u_x_hardware_0.run_command = ''
    h_p_u_x_hardware_0.path = ''
    collected_facts = {'ansible_architecture': '9000/800', 'processor_cores': 6, 'ansible_distribution_version': 'B.11.23'}
    h_p_u_x_

# Generated at 2022-06-24 22:06:08.979626
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    s_out = os.linesep + 'Restricted rights. Use, duplication or disclosure is subject to restrictions stated in your contract with Western Digital Corporation.' + os.linesep + 'Physical: 49152 Kbytes, logical: 195318 Kbytes' + os.linesep + 'Compressed Mem:20000 Kbytes' + os.linesep + 'Compressed Mem:20000 Kbytes' + os.linesep + 'Compressed Mem:20000 Kbytes' + os.linesep + 'Compressed Mem:20000 Kbytes' + os.linesep + 'Compressed Mem:20000 Kbytes' + os.lines

# Generated at 2022-06-24 22:06:15.828168
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = dict()
    collected_facts_0["ansible_architecture"] = "9000/800"
    collected_facts_0["ansible_distribution_version"] = "B.11.23"
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)
    collected_facts_1 = dict()
    collected_facts_1["ansible_architecture"] = "9000/800"
    collected_facts_1["ansible_distribution_version"] = "B.11.31"
    var_1 = h_p_u_x_hardware_0.get_cpu

# Generated at 2022-06-24 22:06:21.806573
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = -75.01
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'


# Generated at 2022-06-24 22:06:28.866487
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -91.4
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    if (h_p_u_x_hardware_0.populate().get('processor') == 'Intel(R) Itanium(R) 9500 series'):
        if (h_p_u_x_hardware_0.populate().get('processor_cores') == 40):
            pass
    if (h_p_u_x_hardware_0.populate().get('processor') == 'Intel(R) Itanium(R) 9300 series'):
        if (h_p_u_x_hardware_0.populate().get('processor_cores') == 12):
            assert h_p_u_x_hardware_0.get_cpu_facts().get

# Generated at 2022-06-24 22:06:35.712425
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()
    collected_facts_0 = {}
    var_1 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:06:45.357225
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Define a dict with facts to use
    collected_facts = dict()

    # Assign dict values here
    collected_facts['ansible_architecture'] = "9000/800"

    # Create an instance of HPUXHardware
    float_0 = -175.88
    h_p_u_x_hardware_0 = HPUXHardware(float_0)

    # Get memory facts
    memory_facts = h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts)

    # Test if 'memfree_mb' and 'memtotal_mb' are defined in return dict
    assert ('memfree_mb' in memory_facts and 'memtotal_mb' in memory_facts) is True
    # Test if 'swaptotal_mb' and 'swapfree

# Generated at 2022-06-24 22:06:50.230083
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    print("Testing get_cpu_facts")
    float_0 = -87.18
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:06:57.261662
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -69.25
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = {}
    collected_facts_0['ansible_architecture'] = 'ia64'
    collected_facts_0['ansible_distribution_version'] = "B.11.23"
    var_2 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)


# Generated at 2022-06-24 22:07:07.188272
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -175.01
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = {}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)
    collected_facts_1 = {'ansible_architecture': '9000/800'}
    var_1 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_1)
    collected_facts_1 = {'ansible_architecture': '9000/785'}
    var_2 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_1)

# Generated at 2022-06-24 22:07:16.883899
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -60.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    # get_cpu_facts test
    float_0 = -92.7
    map_0 = h_p_u_x_hardware_0.get_cpu_facts(float_0)
    print(map_0)
    assert len(map_0) == 4
    assert 'processor_count' in map_0
    assert 'processor' in map_0
    assert 'processor_cores' in map_0
    assert isinstance(map_0, dict)
    print(map_0)
    print('')

    float_0 = -49.0

# Generated at 2022-06-24 22:08:30.367404
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_0 = -14
    test_case_0()


if __name__ == '__main__':
    hw_0 = HPUXHardwareCollector()
    hw_0.get_all()