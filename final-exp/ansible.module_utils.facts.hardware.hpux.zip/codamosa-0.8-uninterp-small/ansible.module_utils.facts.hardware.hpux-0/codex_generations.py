

# Generated at 2022-06-24 21:58:50.313226
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert 'HPUXHardwareCollector' == HPUXHardwareCollector.__name__
    assert 'ansible.module_utils.facts.hardware.h_p_u_x' == HPUXHardwareCollector.__module__


# Generated at 2022-06-24 21:58:55.643984
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_1._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_1._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_1.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 21:58:59.738944
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    print(h_p_u_x_hardware_0.get_hw_facts())


# Generated at 2022-06-24 21:59:12.088198
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.module = FakeAnsibleModule("mock_module", "mock_base_module")
    h_p_u_x_hardware.module.run_command = fake_run_command
    h_p_u_x_hardware.module.run_command.side_effect = [
        (0, """0""", ""),
        (0, """0.00""", ""),
    ]
    collected_facts = {'ansible_architecture': 'mock_ansible_architecture'}
    memory_facts = h_p_u_x_hardware.get_memory_facts(collected_facts)
    assert ('memfree_mb' in memory_facts)

# Unit

# Generated at 2022-06-24 21:59:18.698099
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test parameters and expected return values.
    test_data = dict(

    )

    for test_parameters, expected_results in test_data.items():
        h_p_u_x_hardware = HPUXHardware()
        h_p_u_x_hardware.populate(test_parameters)
        results = h_p_u_x_hardware.get_memory_facts()
        assert (results == expected_results)

# Generated at 2022-06-24 21:59:23.414060
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0.__dict__ == {
        '_fact_class': HPUXHardware,
        '_platform': 'HP-UX',
        'required_facts': {'distribution', 'platform'}
    }


# Generated at 2022-06-24 21:59:30.969702
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test in HPUX system
    h_p_ux_hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"}
    memory_facts = h_p_ux_hardware.get_memory_facts(collected_facts=collected_facts)
    if memory_facts['memtotal_mb'] <=  0 and memory_facts['memfree_mb'] <=  0 and memory_facts['swaptotal_mb'] <= 0:
        return False
    else:
        return True


# Generated at 2022-06-24 21:59:39.705292
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution']), "'required_facts' must be equal to ['platform', 'distribution']"
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX', "'_platform' must be equal to 'HP-UX'"
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware, "'_fact_class' must be equal to HPUXHardware"


# Generated at 2022-06-24 21:59:44.710002
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.module = AnsibleModule(
        argument_spec = dict()
    )

    collected_facts = dict(ansible_architecture='9000/800', ansible_distribution_version='B.11.23')
    cpu_facts = h_p_u_x_hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-24 21:59:46.573281
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()



# Generated at 2022-06-24 22:00:04.136813
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Input parameters tests
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)

    # Pass null argument
    state = h_p_u_x_hardware_0.populate(1)
    assert (state == {})

    # Pass an object as argument
    state = h_p_u_x_hardware_0.populate(h_p_u_x_hardware_0)
    assert (state == {})

    # Pass a single value argument
    state = h_p_u_x_hardware_0.populate(str_0)
    assert (state == {})

    # Pass an empty collection as argument
    state = h_p_u_x_hardware_0.populate([])


# Generated at 2022-06-24 22:00:13.949374
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31'
    }

    hpuX_hardware_obj = HPUXHardware("")
    hpuX_hardware_obj.populate(collected_facts=hw_facts)

    expected_result = {
        'processor': 'Intel(R) Itanium(R) Processor 9350',
        'processor_count': 2,
        'processor_cores': 28,
    }

    assert expected_result == hpuX_hardware_obj.get_cpu_facts(collected_facts=hw_facts)


# Generated at 2022-06-24 22:00:18.369566
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:20.752986
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-24 22:00:24.940526
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:30.299006
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = 'E2'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:37.917856
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    var_0 = h_p_u_x_hardware_collector_0.get_required_facts()
    var_1 = h_p_u_x_hardware_collector_0.get_platform()
    var_2 = h_p_u_x_hardware_collector_0.get_fact_class()

# Generated at 2022-06-24 22:00:41.049430
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:45.458855
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:49.566299
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware('.known_hosts.lock')
    var_0 = h_p_u_x_hardware_0.populate()
    assert False, var_0



# Generated at 2022-06-24 22:01:02.309628
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = 'ansible_architecture'
    str_1 = 'ansible_distribution_version'
    str_2 = 'ansible_architecture'
    str_3 = 'ansible_distribution_version'
    str_4 = 'ansible_architecture'
    str_5 = 'ansible_distribution_version'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    var_0 = h_p_u_x_hardware_collector_0.can_run(str_0, str_1)
    var_1 = h_p_u_x_hardware_collector_0.can_run(str_2, str_3)
    var_2 = h_p_u_x_hardware_collector_

# Generated at 2022-06-24 22:01:05.098994
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = 'ansible_architecture'
    str_1 = '=9000/785'
    str_2 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_2)
    var_0 = h_p_u_x_hardware_0.populate(sequencer = {str_0: str_1})


# Generated at 2022-06-24 22:01:09.602192
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)

# Generated at 2022-06-24 22:01:13.580145
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:23.138033
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '    .known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    assert h_p_u_x_hardware_0.get_cpu_facts() is None
    str_0 = 'none has no data'
    h_p_u_x_hardware_1 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_1.get_cpu_facts()
    var_1 = h_p_u_x_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:01:26.079105
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    assert isinstance(h_p_u_x_hardware_0.get_hw_facts(), dict)


# Generated at 2022-06-24 22:01:38.346944
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    function_p_s_0 = 'ansible_distribution_version'
    str_0 = 'ansible_architecture'
    dict_0 = {'processor_count': 2, 'processor_cores': 2, 'processor': 'Intel(R) Itanium(R) Processor'}
    dict_1 = {'ansible_distribution_release': '11.23', 'ansible_architecture': 'ia64', function_p_s_0: 'B.11.23'}
    str_1 = 'a'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_1)

# Generated at 2022-06-24 22:01:48.399197
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    assert isinstance(h_p_u_x_hardware_collector_0, HardwareCollector)
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert isinstance(h_p_u_x_hardware_collector_0._fact_class, Hardware)
    assert h_p_u_x_hardware_collector_0.required_

# Generated at 2022-06-24 22:01:51.703716
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:54.344156
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '*'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()
    assert len(var_0) > 0


# Generated at 2022-06-24 22:02:12.850459
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:15.573732
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_2 = HPUXHardware('.known_hosts.lock')
    var_1 = h_p_u_x_hardware_2.get_memory_facts()



# Generated at 2022-06-24 22:02:18.705871
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:24.602671
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    # populate without collected facts
    var_0 = h_p_u_x_hardware_0.populate()
    # populate with collected facts
    var_1 = h_p_u_x_hardware_0.populate({'ansible_architecture': '9000/800'})


# Generated at 2022-06-24 22:02:28.337814
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware('.known_hosts.lock')
    var_0 = h_p_u_x_hardware_0.get_hw_facts()
    print(var_0)


# Generated at 2022-06-24 22:02:32.489166
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    cwd_0 = os.getcwd()
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)


# Generated at 2022-06-24 22:02:33.438204
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    assert_equals = test_case_0()

# Generated at 2022-06-24 22:02:41.446261
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    data_0 = {}
    data_0['ansible_architecture'] = 'ia64'
    data_0['ansible_distribution_version'] = "B.11.23"
    var_0 = h_p_u_x_hardware_0.get_hw_facts(data_0)
    data_1 = {}
    data_1['ansible_architecture'] = 'ia64'
    data_1['ansible_distribution_version'] = "B.11.31"
    var_1 = h_p_u_x_hardware_0.get_hw_facts(data_1)


# Generated at 2022-06-24 22:02:45.347702
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    tested_hw_collector = HPUXHardwareCollector()
    assert tested_hw_collector.platform == 'HP-UX'
    assert set(tested_hw_collector.required_facts) == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:02:48.844441
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:03:20.736378
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    h_p_u_x_hardware_collector_0.populate()


# Generated at 2022-06-24 22:03:25.725460
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
  h_p_u_x_hardware_0 = HPUXHardware()
  var_0 = h_p_u_x_hardware_0.get_cpu_facts()
  # Testing all branches in the function
  test_case_0()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 22:03:29.363895
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_0 = HPUXHardwareCollector({'distribution': 'B.11.31', 'ansible_architecture': 'ia64', 'platform': 'HP-UX'}, {})
    h_p_u_x_hardware_0.main({'distribution': 'B.11.31', 'ansible_architecture': 'ia64', 'platform': 'HP-UX'}, {})


import pytest

pytest.main([__file__, '-v', '-s'])

# Generated at 2022-06-24 22:03:32.949435
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:03:42.131142
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    # Try to access protected member _fact_class of HPUXHardwareCollector
    print(repr(h_p_u_x_hardware_collector_0._fact_class))
    # Try to access protected member _platform of HPUXHardwareCollector
    print(repr(h_p_u_x_hardware_collector_0._platform))

# Generated at 2022-06-24 22:03:48.358835
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    # Test case with default arguments
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()
    print('var_0 is ',var_0)


# Generated at 2022-06-24 22:03:54.531434
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '.known_hosts.lock'

    # Testing for known_hosts.lock
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    get_memory_facts_0 = test_HPUXHardware_get_memory_facts()
    get_cpu_facts_0 = test_HPUXHardware_get_cpu_facts()
    var_0 = h_p_u_x_hardware_0.get_hw_facts(get_cpu_facts_0, get_memory_facts_0)
    if isinstance(var_0, dict):
        return True
    else:
        return False


# Generated at 2022-06-24 22:03:58.768501
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:01.806014
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '4eH4m'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:06.546554
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:25.856019
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:05:29.893990
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    # Test using unittest function
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:05:33.042548
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_1 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_1)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    return var_0



# Generated at 2022-06-24 22:05:37.082086
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()

# Generated at 2022-06-24 22:05:38.894018
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    out_0 = test_case_0()


# Generated at 2022-06-24 22:05:42.727885
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:05:46.696276
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:47.757309
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:05:51.874532
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:05:56.054230
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware('.known_hosts.lock')
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:08:28.101454
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # RC = 1, out = '', err = ''
    str_0 = '.known_hosts.lock'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    rc_0, out_0, err_0 = h_p_u_x_hardware_0.module.run_command("model")
    var_0 = h_p_u_x_hardware_0.get_hw_facts()
    assert var_0 == (rc_0, out_0, err_0)


# Generated at 2022-06-24 22:08:29.533051
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    assert callable(HPUXHardware.get_cpu_facts)


# Generated at 2022-06-24 22:08:38.763078
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    # Check class name
    assert h_p_u_x_hardware_collector_0.__class__.__name__ == 'HPUXHardwareCollector'
    # Check parent class
    assert h_p_u_x_hardware_collector_0.__class__.__base__.__name__ == 'HardwareCollector'
    # Check instance
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)
    # Check required_facts
    assert h_p_u_x_hardware_collector_0._required_facts == set(['platform', 'distribution'])
    # Check platform
    assert h_p_u_x_hardware