

# Generated at 2022-06-24 21:58:46.533508
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Since this method is marked as 'private' we don't take it
    # into account while testing
    pass


# Generated at 2022-06-24 21:58:51.560550
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None, collected_facts=None)
    HPUXHardware.get_hw_facts(h_p_u_x_hardware_0, collected_facts=None)


# Generated at 2022-06-24 21:58:53.354303
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


if __name__ == "__main__":
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 21:58:54.912524
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_HPUXHardware_obj = HPUXHardware()

    test_HPUXHardware_obj.get_cpu_facts()


# Generated at 2022-06-24 21:59:07.104165
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    ansible_facts = dict()
    ansible_facts['ansible_architecture'] = 'ia64'
    ansible_facts['ansible_distribution_version'] = 'B.11.31'
    ansible_facts['ansible_memtotal_mb'] = 10
    ansible_facts['ansible_processor'] = 'Intel(R) Xeon(R) CPU E5-2640 v2 @ 2.00GHz'
    ansible_facts['ansible_processor_cores'] = 16
    ansible_facts['ansible_processor_count'] = 4
    ansible_facts['ansible_product_serial'] = 'ABCDEF'
    h_p_u_x_hardware_0.populate(ansible_facts)


# Generated at 2022-06-24 21:59:10.523475
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 21:59:14.825153
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    collected_facts = {
        "ansible_architecture": "9000/800",
    }
    test_memory_facts = {
        "memfree_mb": 48,
        "memtotal_mb": 512
    }
    result = h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts)
    assert result == test_memory_facts
    h_p_u_x_hardware_1 = HPUXHardware(module=None)
    collected_facts = {
        "ansible_architecture": "9000/785",
    }

# Generated at 2022-06-24 21:59:20.332891
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '0\n', '')
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:59:29.757157
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    h_p_u_x_hardware = HPUXHardware()

    memory_facts = h_p_u_x_hardware.get_memory_facts()

    assert memory_facts['memfree_mb'] is None or type(memory_facts['memfree_mb']) is int
    assert memory_facts['memtotal_mb'] is None or type(memory_facts['memtotal_mb']) is int
    assert memory_facts['swapfree_mb'] is None or type(memory_facts['swapfree_mb']) is int
    assert memory_facts['swaptotal_mb'] is None or type(memory_facts['swaptotal_mb']) is int


# Generated at 2022-06-24 21:59:39.860620
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    HPUXHardware_0 = HPUXHardware()
    HPUXHardware_0.module = AnsibleModule(
        argument_spec = dict(
            filter = dict(type='str'),
        ),
        supports_check_mode=False,
    )
    HPUXHardware_0.module.params = {'filter': 'fqdn=heapp056.unxi.local'}
    HPUXHardware_0.populate()
    HPUXHardware_0.get_cpu_facts(collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})

if __name__ == '__main__':
    from ansible.module_utils.facts.hardware.hpu_x import *

# Generated at 2022-06-24 21:59:57.199004
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Check if initialization method _init_facts_class of class HPUXHardwareCollector is working properly
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    bool_0 = False
    assert h_p_u_x_hardware_collector_0._init_facts_class(bool_0) is None
    # Check if initialization method _init_facts_class of class HPUXHardwareCollector is working properly
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    bool_0 = True
    h_p_u_x_hardware_1 = HPUXHardware(True)
    assert h_p_u_x_hardware_collector_1._init_facts_class(bool_0) is h_p_u

# Generated at 2022-06-24 21:59:59.961868
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

# Generated at 2022-06-24 22:00:04.598387
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    if os.access("/dev/kmem", os.W_OK):
        bool_0 = False
        h_p_u_x_hardware_0 = HPUXHardware(bool_0)
        var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:08.847639
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    var_0 = h_p_u_x_hardware_collector_0.required_facts()
    var_1 = h_p_u_x_hardware_collector_0.platform()
    h_p_u_x_hardware_collector_0.collect()

test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:00:14.395688
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:00:19.431088
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    if getattr(h_p_u_x_hardware_0, "memory_facts", None) is None:
        pass
    else:
        raise Exception("assertion failed")

# Generated at 2022-06-24 22:00:23.453939
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    assert (h_p_u_x_hardware_collector_0.platform == 'HP-UX')


# Generated at 2022-06-24 22:00:27.437652
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)

    bool_0 = False
    h_p_u_x_hardware_0.populate(bool_0)

# Generated at 2022-06-24 22:00:33.684800
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


if __name__ == '__main__':
    test_case_0()
    test_HPUXHardware_get_memory_facts()

# Generated at 2022-06-24 22:00:38.910049
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Test with a single thread
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)

    # Test with two threads
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)

# Generated at 2022-06-24 22:01:01.374626
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)


# Generated at 2022-06-24 22:01:03.896539
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)


# Generated at 2022-06-24 22:01:07.874300
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    bool_1 = False
    dict_0 = h_p_u_x_hardware_0.populate(bool_1)


# Generated at 2022-06-24 22:01:10.946894
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.populate({})


# Generated at 2022-06-24 22:01:13.457007
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)


# Generated at 2022-06-24 22:01:17.441513
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector_0 = HPUXHardwareCollector()

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:01:22.271708
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {'ansible_architecture': '9000/800'}
    h_p_u_x_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:01:24.111160
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware(False)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:29.893468
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    assert h_p_u_x_hardware_0.get_hw_facts() == {'model': 'ia64 hp server Integrity server rx6600', 'firmware_version': 'B.11.31.1502', 'product_serial': 'US8C6B36K6'}, 'Failed to get HP-UX hardware facts'


# Generated at 2022-06-24 22:01:38.188088
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:02:01.779463
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert var_0 == {}

    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_1 = h_p_u_x_hardware_0.get_memory_facts()
    assert var_1 == {}


# Generated at 2022-06-24 22:02:11.720787
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    str_0 = "processor"
    str_1 = "processor_cores"
    str_2 = "processor_count"
    dict_0 = {str_0: "Intel(R) Itanium(R) Processor 9340", str_1: 12, str_2: 2}
    str_3 = "ansible_architecture"
    str_4 = "9000/800"
    dict_1 = {str_3: str_4}
    dict_2 = h_p_u_x_hardware_0.get_memory_facts(dict_1, dict_0)
    int_0 = 16777216

# Generated at 2022-06-24 22:02:12.854643
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = None
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)

# Generated at 2022-06-24 22:02:16.703950
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = True
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    assert bool_0 == h_p_u_x_hardware_collector_0._module.check_mode
    assert set() == h_p_u_x_hardware_collector_0.required_facts

# Generated at 2022-06-24 22:02:19.482824
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:22.303257
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:02:23.892977
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    # Test with enumerated arguments
    test_case_0()


# Generated at 2022-06-24 22:02:32.259921
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}

    # Testing bad condition
    collected_facts_0['ansible_architecture'] = 'ia64'
    collected_facts_0['ansible_distribution_version'] = 'B.11.23'
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)
    assert var_0 == {}, var_0


# Generated at 2022-06-24 22:02:38.888893
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.collector = 'ahmet'
    assert h_p_u_x_hardware_0.populate() == {'firmware_version': 'HPUX', 'product_serial': 'ahmet', 'model': 'ahmet', 
    'memory_mb': 'ahmet', 'processor_count': 'ahmet', 'processor_cores': 'ahmet', 'processor': 'ahmet', 'swap_mb': 'ahmet'}


# Generated at 2022-06-24 22:02:43.185601
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = len(HPUXHardware.get_hw_facts()) > 0
    assert (bool_0), "Method get_hw_facts did not return a valid result"


# Generated at 2022-06-24 22:03:16.007589
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()
    assert var_0 == dict([('processor_count', int()), ('processor_cores', int()), ('processor', str())])


# Generated at 2022-06-24 22:03:17.958895
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(None)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:24.064538
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = {'ansible_architecture': '9000/800'}
    var_1 = h_p_u_x_hardware_0.get_memory_facts(var_0)


# Generated at 2022-06-24 22:03:24.689834
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_case_0()



# Generated at 2022-06-24 22:03:34.323005
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    assert ('processor_count' in var_0) == True
    assert ('swaptotal_mb' in var_0) == True
    assert ('memfree_mb' in var_0) == True
    assert ('firmware_version' in var_0) == True
    assert ('memtotal_mb' in var_0) == True
    assert ('hw_memtotal_mb' in var_0) == True
    assert ('processor_cores' in var_0) == True
    assert ('processor' in var_0) == True
    assert ('model' in var_0) == True
    assert var_0['hw_memtotal_mb'] == var_0['memtotal_mb']
    assert var_0['memfree_mb'] == var_0['memfree_mb']

# Generated at 2022-06-24 22:03:38.215293
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Constructor
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:03:45.877487
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    collected_facts = {'ansible_architecture': '9000/800'}
    h_p_u_x_hardware_0 = HPUXHardware(False)
    h_p_u_x_hardware_0.module = MockModule()
    h_p_u_x_hardware_0.module.run_command = MockMethod(return_value=(0, '2', ''))
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts)
    out = h_p_u_x_hardware_0.module.run_command.called
    assert out == 2


# Generated at 2022-06-24 22:03:48.671520
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:03:51.909884
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}
    return_value_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:03:57.407089
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # input parameters
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts)
    # Correct data
    assert var_0['memtotal_mb'] == 8192
    assert var_0['swaptotal_mb'] == 2048
    # Wrong data
    assert var_0['memtotal_mb'] != 7628
    assert var_0['swaptotal_mb'] != 1284


# Generated at 2022-06-24 22:05:06.600031
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

# Generated at 2022-06-24 22:05:09.359773
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    result_0 = h_p_u_x_hardware_0.populate()
    assert isinstance(result_0, dict)


# Generated at 2022-06-24 22:05:13.284031
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # function for getting the hw facts for hpux platform
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:05:17.580349
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.populate()

    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:19.653874
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)


# Generated at 2022-06-24 22:05:24.702162
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_collector_1 = HPUXHardwareCollector(None)
    h_p_u_x_hardware_1 = HPUXHardware(hardware_collector_1)

    assert h_p_u_x_hardware_1.get_memory_facts() == {'memtotal_mb': None, 'swaptotal_mb': None, 'swapfree_mb': None, 'memfree_mb': None}

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardware_get_memory_facts()

# Generated at 2022-06-24 22:05:31.315831
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_1 = HPUXHardware(bool_0)
    h_p_u_x_hardware_2 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_1.populate()
    h_p_u_x_hardware_2.populate()
    h_p_u_x_hardware_3 = HPUXHardware(bool_0)
    h_p_u_x_hardware_3.populate()
    collected_facts = {}

# Generated at 2022-06-24 22:05:35.093730
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_1 = True
    h_p_u_x_hardware_1 = HPUXHardware(bool_1)
    # TODO: implement test
    #var_3 = h_p_u_x_hardware_1.populate()
    #assert var_3 == 'Unknown'


# Generated at 2022-06-24 22:05:39.495711
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.populate()

# Generated at 2022-06-24 22:05:44.239409
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = True
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector) is True


# Generated at 2022-06-24 22:08:19.100158
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware = HPUXHardware(bool_0)
    h_p_u_x_hardware.get_memory_facts()


# Generated at 2022-06-24 22:08:21.408709
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert not HPUXHardwareCollector()


# Generated at 2022-06-24 22:08:25.539327
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware(None)
    collected_facts_0 = {}
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_0)

