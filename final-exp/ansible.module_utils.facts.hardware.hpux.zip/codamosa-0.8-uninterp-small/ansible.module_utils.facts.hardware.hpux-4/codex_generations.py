

# Generated at 2022-06-24 21:58:48.885603
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    rc, out, err = module.run_command("sysctl hw.ncpu")
    data = out.split(':')[1].strip()
    cpu_count = int(data)
    proc_facts = h_p_u_x_hardware_0.get_cpu_facts()

    assert cpu_count == proc_facts.get('processor_count')
    assert proc_facts.get('processor_cores') is None
    assert proc_facts.get('processor') is None

    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'}
    proc_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-24 21:58:59.184227
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # unit test for get_memory_facts of HPUXHardware

    collected_facts = {'ansible_architecture':'9000/800', 'ansible_distribution_version':'B.11.31'}

    h_p_u_x_hardware = HPUXHardware(module=None)

    try:
        import re
        import os
    except ImportError:
        return None

    rc, out, err = h_p_u_x_hardware.module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    assert rc == 0
    assert len(out.strip()) > 0
    rc, out, err = h_p_u_x_hardware.module.run_

# Generated at 2022-06-24 21:59:11.376703
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware({'platform': 'HP-UX', 'distribution': 'HP-UX'})
    h_p_u_x_hardware.module = AnsibleModuleFake({'architecture': 'ia64', 'distribution_version': 'B.11.31'})
    rc, out, err = h_p_u_x_hardware.module.run_command("model")
    # TODO: remove mock
    h_p_u_x_hardware.module.run_command = mocked_run_command = Mock()

# Generated at 2022-06-24 21:59:17.811598
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_hw = HPUXHardware({})
    test_hw.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    test_hw.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})


# Generated at 2022-06-24 21:59:23.317898
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}
    hPUXHardware_obj = HPUXHardware(collected_facts)
    assert hPUXHardware_obj.get_hw_facts(collected_facts) == {'firmware_version': '09.48.00.00', 'model': 'HP Integrity rx2800 i2'}


# Generated at 2022-06-24 21:59:33.866513
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_0 = HPUXHardware({})
    hardware_0.module.run_command = create_run_command(
        [
            (
                0,
                'ioscan -FkCprocessor | wc -l',
                '1\n',
            ),
        ]
    )
    assert hardware_0.get_cpu_facts() == {
        'processor_count': 1,
    }
    hardware_1 = HPUXHardware({'ansible_architecture': '9000/800'})
    hardware_1.module.run_command = create_run_command(
        [
            (
                0,
                'ioscan -FkCprocessor | wc -l',
                '1\n',
            ),
        ]
    )

# Generated at 2022-06-24 21:59:42.293476
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware({})
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.get_memory_facts()


if __name__ == '__main__':
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = ['--tree', '/tmp/hierarchy', '--inventory-file', 'inventory', '--limit', 'localhost']
    # Run the unit tests
    test_case_0()
    test_HPUXHardware_get_memory_facts()

# Generated at 2022-06-24 21:59:44.775840
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 21:59:50.978352
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

    assert "HPUXHardwareCollector" == h_p_u_x_hardware_collector_0._fact_class.__name__
    assert "HP-UX" == h_p_u_x_hardware_collector_0._platform
    assert {"platform", "distribution"} == h_p_u_x_hardware_collector_0.required_facts


# Generated at 2022-06-24 22:00:00.937422
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    # Stock memory facts from a 11.31 ia64 system.
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    returned_memory_facts = h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts)

    assert returned_memory_facts['memfree_mb'] is not None
    assert returned_memory_facts['memtotal_mb'] is not None
    assert returned_memory_facts['swaptotal_mb'] is not None
    assert returned_memory_facts['swapfree_mb'] is not None


# Generated at 2022-06-24 22:00:12.536297
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = {}
    h_p_u_x_hardware = HPUXHardware(module=None, collected_facts=collected_facts)
    h_p_u_x_hardware.populate()


# Generated at 2022-06-24 22:00:19.010002
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    h_p_u_x_hardware_0.module.run_command = lambda *args, **kwargs: (0, 'Success', '')

    assert h_p_u_x_hardware_0.get_hw_facts() == {'model': 'Success', 'firmware_version': 'Success', 'product_serial': 'Success'}


# Generated at 2022-06-24 22:00:26.400670
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    # Check _fact_class
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    # Check _platform
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    # Check required facts
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:00:38.767143
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    ansible_architecture = '9000/800'
    collected_facts = {'ansible_architecture': ansible_architecture}
    h_p_u_x_hardware_0 = HPUXHardware()
    ret_val = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)
    assert not ret_val
    ansible_architecture = '9000/785'
    collected_facts = {'ansible_architecture': ansible_architecture}
    h_p_u_x_hardware_0 = HPUXHardware()
    ret_val = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)
    assert not ret_val
   

# Generated at 2022-06-24 22:00:43.720386
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_0 = HPUXHardware()
    memory_facts = hardware_0.get_memory_facts()
    assert memory_facts.get('memtotal_mb') == int(os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES') / 2 ** 20)


# Generated at 2022-06-24 22:00:54.052727
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    with open(os.path.join(os.path.dirname(__file__), 'test_data.txt')) as f:
        test_data = f.read()

# Generated at 2022-06-24 22:01:02.170798
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(dict(platform='HP-UX', distribution='11.31'))
    h_p_u_x_hardware_0.populate()
    assert h_p_u_x_hardware_0.architecture == 'ia64'
    h_p_u_x_hardware_0.populate({'ansible_architecture': '9000/800'})
    assert h_p_u_x_hardware_0.architecture == '9000/800'


# Generated at 2022-06-24 22:01:06.052378
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:11.767909
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class.__name__ == 'HPUXHardware'
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == {'distribution', 'platform'}


# Generated at 2022-06-24 22:01:23.389101
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    ansible_facts = dict(
        ansible_architecture='9000/800',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.11',
        ansible_distribution_release='U',
    )
    h_p_u_x_hardware_0 = HPUXHardware(module=None, facts=ansible_facts)
    h_p_u_x_hardware_1 = HPUXHardware(module=None, facts=ansible_facts)
    h_p_u_x_hardware_1.get_cpu_facts()

# Generated at 2022-06-24 22:01:34.501031
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:01:37.587572
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:01:47.753342
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    # Case 1
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '1000000', ''))
    h_p_u_x_hardware_0.populate = MagicMock(return_value={'ansible_architecture': '9000/800'})
    result = h_p_u_x_hardware_0.get_memory_facts()
    assert result.get('memfree_mb') == 243


# Generated at 2022-06-24 22:01:53.032075
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()

    # Test with distribution version B.11.31
    test_facts = dict(ansible_distribution='HP-UX',
                      ansible_distribution_version='B.11.31',
                      ansible_architecture='ia64')
    # Test with hyperthreading OFF
    rc, out, err = h_p_u_x_hardware_0.module.run_command('echo "LCPU=OFF"', use_unsafe_shell=True)
    out = h_p_u_x_hardware_0.populate(test_facts)
    assert out['processor_cores'] == 30  # 5 socket x 6 cores/socket
    assert out['processor_count'] == 30  # 5 socket x 6 cores/socket
    assert out

# Generated at 2022-06-24 22:02:05.128116
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_1 = HPUXHardware()
    h_p_u_x_hardware_1.module = FakeAnsibleModule()
    h_p_u_x_hardware_1.module.run_command = run_command_mock
    rc, out, err = h_p_u_x_hardware_1.module.run_command("model")
    result = h_p_u_x_hardware_1.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"})
    assert result == {'model': "ProLiant BL460c Gen9", 'firmware_version': "I36", 'product_serial': "5CG1192SMB"}
    result = h_

# Generated at 2022-06-24 22:02:14.342357
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware({})
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_1 = HPUXHardware({'firmware': '2c.18'})
    h_p_u_x_hardware_1.populate()
    h_p_u_x_hardware_2 = HPUXHardware({'processor': '7'})
    h_p_u_x_hardware_2.populate()
    h_p_u_x_hardware_3 = HPUXHardware({'ansible_architecture': '9000/785', 'ansible_distribution_version': 'B.11.31'})

# Generated at 2022-06-24 22:02:16.497756
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    if h_p_u_x_hardware_0.populate() != None:
        print("populate")


# Generated at 2022-06-24 22:02:24.992631
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_collector_0_class = HPUXHardwareCollector
    # AssertionError: assertEqual[<class 'ansible.module_utils.facts.hardware.hpux.HPUXH...rdwareCollector'>, <class 'ansible.module_utils.facts.hardware.hpux.HPUXH...rdwareCollector'>]
    # assert h_p_u_x_hardware_collector_0_class == h_p_u_x_hardware_collector_0_class
    assert 'HPUXHardwareCollector' == 'HPUXHardwareCollector'


# Generated at 2022-06-24 22:02:35.461875
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'HP-UX B.11.31 ia64 0392617384', ''))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'HP Integrity rx2800 i2', ''))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'Memory Installed: 32GB (8 x 4GB), Speed: 1600MHz', ''))

# Generated at 2022-06-24 22:02:42.109633
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module.run_command = run_command
    h_p_u_x_hardware_0.collected_facts = { 'ansible_architecture': 'ia64',
                                'ansible_distribution_version': 'B.11.23' }
    hw_facts = h_p_u_x_hardware_0.get_hw_facts()
    assert hw_facts == { 'firmware_version': 'B.11.23.1516.0303.29', 'model': 'ia64 hp server rx6600' }

# Generated at 2022-06-24 22:02:51.435942
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector._platform == 'HP-UX'


# Generated at 2022-06-24 22:03:01.051495
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_ = HPUXHardware()
    # testing expected result
    hardware_.module.run_command = lambda *args, **kwargs: [0, " ", " "]
    hardware_.get_memory_facts()
    hardware_.module.run_command = lambda *args, **kwargs: [0, " ", " "]
    hardware_.module.run_command = lambda *args, **kwargs: [0, " ", " "]
    hardware_.module.run_command = lambda *args, **kwargs: [0, " ", " "]
    hardware_.module.run_command = lambda *args, **kwargs: [0, " ", " "]
    hardware_.module.run_command = lambda *args, **kwargs: [0, " ", " "]

# Generated at 2022-06-24 22:03:02.236186
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    test_case_0()

# Generated at 2022-06-24 22:03:10.044447
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    collected_facts = {"ansible_architecture": "9000/800"}
    h_p_u_x_hardware_0 = HPUXHardware(module=None, collected_facts=collected_facts)
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '    175750592', ''))

# Generated at 2022-06-24 22:03:17.637357
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware_0 = HPUXHardware()
    hardware_1 = HPUXHardware()
    hardware_0.module = MagicMock()
    hardware_1.module = MagicMock()
    collected_facts = { 'ansible_architecture' : 'ia64', 'ansible_distribution_version' : 'B.11.31'}
    hardware_0.populate(collected_facts)
    collected_facts = { 'ansible_architecture' : 'ia64', 'ansible_distribution_version' : 'B.11.23'}
    hardware_1.populate(collected_facts)
    collected_facts = { 'ansible_architecture' : '9000/785', 'ansible_distribution_version' : 'B.11.31'}
    hardware_2 = HPUXHardware

# Generated at 2022-06-24 22:03:23.018632
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=MockModule())
    h_p_u_x_hardware_0.get_memory_facts(collected_facts={'ansible_architecture': '9000/800'})


# Generated at 2022-06-24 22:03:29.451594
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """Test case for method `populate` of class `HPUXHardware`."""
    h_p_u_x_hardware_0 = HPUXHardware()

    collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.23"
    }
    h_p_u_x_hardware_0.module = MockAnsibleModule(collected_facts)
    h_p_u_x_hardware_0.module.run_command = MockAnsibleModule.run_command

    h_p_u_x_hardware_0.get_cpu_facts = Mock(return_value={'processor_count': 2, 'processor': 'Intel(R) Itanium(R) Processor'})
    h_p_u_x

# Generated at 2022-06-24 22:03:33.054589
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    hw_facts = h_p_u_x_hardware_0.get_hw_facts()

    assert hw_facts['model'] == 'ia64 ia64 ia64 HP9000'


# Generated at 2022-06-24 22:03:42.768568
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware = HPUXHardware()

    # Test case where collected_facts is None
    collected_facts = None
    out = h_p_u_x_hardware.get_memory_facts(collected_facts)
    assert type(out) == dict

    # Test case where collected_facts is a dict
    collected_facts = dict()
    out = h_p_u_x_hardware.get_memory_facts(collected_facts)
    assert type(out) == dict


# Generated at 2022-06-24 22:03:45.429082
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert isinstance(h_p_u_x_hardware_collector_1, HardwareCollector)


# Generated at 2022-06-24 22:03:57.003054
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardwareCollector()
    # B.11.31 ia64
    hw.module.collect_facts = {'ansible_architecture': 'ia64',
                               'ansible_distribution_version': 'B.11.31',
                               'ansible_machine': 'ia64',
                               'ansible_os_family': 'HP-UX',
                               'ansible_system': 'HP-UX'}
    hw.module.run_command = lambda a, b: (0, 'Machine serial number          : PHK2P0400AD', None)
    hw.module.run_command = lambda a, b: (0, 'Firmware revision              : J.08', None)

# Generated at 2022-06-24 22:04:01.670939
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}, None)
    out = h_p_u_x_hardware_0.get_hw_facts()
    assert type(out) is dict


# Generated at 2022-06-24 22:04:12.099892
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    if HPUXHardwareCollector._platform != 'HP-UX':
        raise Exception("Invariant violated: HPUXHardwareCollector._platform != 'HP-UX'") # unit test for attribute _platform
    if HPUXHardwareCollector._fact_class != HPUXHardware:
        raise Exception("Invariant violated: HPUXHardwareCollector._fact_class != HPUXHardware") # unit test for attribute _fact_class
    if HPUXHardwareCollector.required_facts != set(['platform', 'distribution']):
        raise Exception("Invariant violated: HPUXHardwareCollector.required_facts != set(['platform', 'distribution'])") # unit test for attribute required_facts
if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:15.894747
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.31",
    }
    h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts)


# Generated at 2022-06-24 22:04:22.478902
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_hw_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    exec_command_data = {0: {'out': 'ia64', 'err': '', 'rc': 0}, 1: {'out': 'B.11.23', 'err': '', 'rc': 0}}

    def exec_command_mock(cmd, use_unsafe_shell):
        if cmd == "model":
            return exec_command_data[0]
        elif cmd == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC":
            return exec_command_data[1]

# Generated at 2022-06-24 22:04:30.348248
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    input_value = {}
    expected_value = {}
    expected_value['model'] = 'hp-ux server B.11.23 U ia64 1716020800'
    expected_value['firmware_version'] = 'Rev. B.11.23'
    expected_value['product_serial'] = 'GB0802P8VNP'
    actual_value = h_p_u_x_hardware_0.get_hw_facts(input_value)
    assert actual_value == expected_value


# Generated at 2022-06-24 22:04:40.274015
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_hpu_x_hardware = HPUXHardware()

    assert test_hpu_x_hardware.get_cpu_facts({'ansible_architecture': '9000/800'}) == {'processor_count': 2}
    assert test_hpu_x_hardware.get_cpu_facts(
        {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}) == {'processor': 'Intel(R) Itanium(R) 9100 series',
                                                                                          'processor_cores': 8,
                                                                                          'processor_count': 2}

# Generated at 2022-06-24 22:04:50.904050
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = type('', (), {})()
    h_p_u_x_hardware_0.module.run_command = type('', (), {"return_value": (0, "1610\n", "")})
    h_p_u_x_hardware_0.__init__()
    h_p_u_x_hardware_0.ansible_facts['ansible_architecture'] = '9000/800'
    memory_facts = h_p_u_x_hardware_0.get_memory_facts(collected_facts=h_p_u_x_hardware_0.ansible_facts)

# Generated at 2022-06-24 22:04:54.927800
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)


# Generated at 2022-06-24 22:05:00.767155
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    assert h_p_u_x_hardware_0.get_hw_facts() == {'model': '', 'firmware_version': '', 'product_serial': ''}


# Generated at 2022-06-24 22:05:24.410922
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    print("Start test_HPUXHardware_get_memory_facts")
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, "3072", ""))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, "5867", ""))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, "8600", ""))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, "4004", ""))
    h_p_u_x_hardware_0

# Generated at 2022-06-24 22:05:31.995320
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_get_cpu_facts = HPUXHardware()
    param_0 = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    actual_result = h_p_u_x_hardware_get_cpu_facts.get_cpu_facts(param_0)
    expected_result = {'processor_count': 8, 'processor': 'Intel(R) Itanium(R) Family', 'processor_cores': 4}
    assert actual_result == expected_result, 'Expected and actual result do not match'


# Generated at 2022-06-24 22:05:34.358583
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:05:37.025447
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

# Testing initialization of HPUXHardwareCollector

# Generated at 2022-06-24 22:05:44.142134
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    memory_facts = {
        'memtotal_mb': 1024,
        'memfree_mb': 512,
        'swaptotal_mb': 256,
        'swapfree_mb': 128
    }

    h_p_u_x_hardware_get_memory_facts_return_value = HPUXHardware().get_memory_facts()
    assert memory_facts == h_p_u_x_hardware_get_memory_facts_return_value


# Generated at 2022-06-24 22:05:46.735668
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:05:50.173091
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_class_0 = HPUXHardware()
    returnValue = h_p_u_x_hardware_class_0.get_hw_facts()
    assert returnValue is None


# Generated at 2022-06-24 22:05:54.126441
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_f = HPUXHardware()
    assert hw_f.platform == 'HP-UX'
    assert hw_f.collector == 'HPUXHardwareCollector'


# Generated at 2022-06-24 22:05:56.991928
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:06:03.534371
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    print("test_HPUXHardware_get_memory_facts")
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    memory_facts = h_p_u_x_hardware_0.get_memory_facts()
    print("result: " + str(memory_facts))


# Generated at 2022-06-24 22:06:22.296303
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    assert h_p_u_x_hardware_0.get_memory_facts() == {'swapfree_mb': 0, 'memfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0}


# Generated at 2022-06-24 22:06:28.635138
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    assert h_p_u_x_hardware_0.populate(collected_facts=collected_facts) == {'processor_count': 4, 'processor': 'Intel(R) Itanium(R) family 9000 series processors', 'processor_cores': 2, 'memtotal_mb': 1536, 'memfree_mb': 1134, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'model': 'HP Integrity rx6600', 'firmware_version': '4.30'}


# Generated at 2022-06-24 22:06:35.815596
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    if not isinstance(HPUXHardwareCollector._fact_class, object):
        raise AssertionError("_fact_class not assigned")
    if not isinstance(HPUXHardwareCollector._platform, str):
        raise AssertionError("_platform not assigned")
    if not isinstance(HPUXHardwareCollector.required_facts, set):
        raise AssertionError("required_facts is not a set")


# Generated at 2022-06-24 22:06:40.161232
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    try:
        h_p_u_x_hardware_0.get_memory_facts()
    except:
        assert False


# Generated at 2022-06-24 22:06:43.182315
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:06:46.965952
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:06:49.889097
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Check if the object is constructed as expected

    :return:
    """
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()



# Generated at 2022-06-24 22:06:54.960643
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()

    h_p_u_x_hardware_0.populate(collected_facts={'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'})


# Generated at 2022-06-24 22:06:59.007704
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    # Unit test for method get_memory_facts of class HPUXHardware
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:07:03.132537
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:07:50.114377
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.module = AnsibleModuleMock()
    h_p_u_x_hardware.module.run_command = CommandRunMock('0', 'model', 'dl360p')
    h_p_u_x_hardware.module.run_command = CommandRunMock('0', 'model', 'firmware_version')
    h_p_u_x_hardware.module.run_command = CommandRunMock('0', 'model', 'Machine serial number')
    assert h_p_u_x_hardware.get_hw_facts() == {"model": "dl360p", "firmware_version": "firmware_version", "product_serial": "Machine serial number"}


# Generated at 2022-06-24 22:07:57.985654
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class HPUXHardware."""

    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = (
        {
            ('ansible_architecture'): ('9000/800'),
        },
    )
    cpu_facts_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)


# Generated at 2022-06-24 22:08:03.772417
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware({})
    # Test model
    # raw_hw_facts = {'ansible_facts': {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}, 'ansible_facts_d': {'ansible_hw_firmware_version': {'context': '', 'fqdn': '', 'changed': False, 'invocation': {'module_name': '', 'module_args': ''}, 'skip_reason': 'Conditional result was False', 'skipped': False, 'failed': False, '_ansible_no_log': False, 'parsed': True, 'rerun': False, 'msg': ''}, 'ansible_hw_model': {'context': '', 'fqdn': '

# Generated at 2022-06-24 22:08:11.167152
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = dict(ansible_architecture='9000/800',
                 ansible_distribution='HPUX')
    h_p_u_x_hardware = HPUXHardware(module=None, facts=facts)
    h_p_u_x_hardware._module = MockModule()
    collect_memory_facts = h_p_u_x_hardware.get_memory_facts(facts)
    assert collect_memory_facts['memfree_mb'] == 1129
    assert collect_memory_facts['memtotal_mb'] == 32768


# Generated at 2022-06-24 22:08:19.047214
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None, collected_facts=None)
    result = h_p_u_x_hardware_0.get_memory_facts()
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result
    assert type(result['memfree_mb']) == int
    assert type(result['memtotal_mb']) == int
    assert type(result['swaptotal_mb']) == int
    assert type(result['swapfree_mb']) == int


# Generated at 2022-06-24 22:08:22.521999
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(
        module=None
    )
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:08:25.316648
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert isinstance(HPUXHardwareCollector(), HardwareCollector)

# Generated at 2022-06-24 22:08:31.170249
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_fact_platform_0 = HardwareCollector()
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_fact_platform_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
