

# Generated at 2022-06-24 21:58:49.801019
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    assert h_p_u_x_hardware_0.get_cpu_facts() == {'processor_count': 0}


# Generated at 2022-06-24 21:59:00.078770
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {
        "platform": "HP-UX",
        "distribution": "HP-UX",
        "os_family": "unix",
        "distribution_major_version": "11",
        "architecture": "ia64",
        "distribution_version": "B.11.23",
        "ansible_architecture": "ia64"
    }

    h_p_u_x_hardware_0 = HPUXHardware({
        "collector": HPUXHardwareCollector(),
        "module": None
    }, collected_facts)

    h_p_u_x_hardware_0.populate()
    output_0 = h_p_u_x_hardware_0.get_cpu_facts()

# Generated at 2022-06-24 21:59:05.865872
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_0 = HPUXHardware()
    collected_facts_0 = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    out, err = hardware_0.get_cpu_facts(collected_facts=collected_facts_0)
    assert out['processor_count'] == 4


# Generated at 2022-06-24 21:59:18.233640
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    # No error if ansible_architecture is 9000/800
    h_p_u_x_hardware_0._module.params = {'gather_subset': '!all', 'filter': 'ansible_architecture'}
    h_p_u_x_hardware_0._module.params['gather_subset'] = '!all'
    h_p_u_x_hardware_0._module.params['filter'] = 'ansible_architecture'
    h_p_u_x_hardware_0._module.ansible_facts = {'ansible_architecture': '9000/800'}
    h_p_u_x_hardware_0.get_cpu_facts()
   

# Generated at 2022-06-24 21:59:21.037296
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_1 is not None


# Generated at 2022-06-24 21:59:28.442375
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    rc, out, err = h_p_u_x_hardware_0.module.run_command('echo "123"', use_unsafe_shell=True)
    if rc == 0:
        assert h_p_u_x_hardware_0.get_memory_facts() == {'swapfree_mb': 1, 'memfree_mb': 1, 'swaptotal_mb': 0, 'memtotal_mb': 1}


# Generated at 2022-06-24 21:59:34.619390
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert isinstance(h_p_u_x_hardware_collector_0, HardwareCollector)
    assert h_p_u_x_hardware_collector_0.platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-24 21:59:45.341105
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    rc, out, err = module.run_command("model")
    model = out.strip()
    rc, out, err = module.run_command("uname -r")
    ansible_distribution_version = out.strip()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': ansible_distribution_version}
    if ansible_distribution_version == "B.11.23":
        separator = '='

# Generated at 2022-06-24 21:59:54.193437
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    p_form = 'HP-UX'
    p_version = 'B.11.31'
    p_architecture = 'ia64'
    collected_facts = {'platform': p_form, 'distribution_version': p_version, 'architecture': p_architecture}
    h_p_u_x_hardware_0 = HPUXHardware(collected_facts, False)
    h_p_u_x_hardware_facts = h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_facts.get('processor') == 'Intel(R) Itanium(R) Processor'
    h_p_u_x_hardware_facts.get('model') == 'IA64 hp rx8640 Server'
    h_p_u_x

# Generated at 2022-06-24 22:00:01.150314
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_0.get_memory_facts(collected_facts={'ansible_architecture': 'ia64'})
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_0.get_memory_facts(collected_facts={'ansible_architecture': '9000/800'})


# Generated at 2022-06-24 22:00:22.119958
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    assert h_p_u_x_hardware_0.get_hw_facts() != {}
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    assert h_p_u_x_hardware_0.get_hw_facts() != {}
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    h_p_u_x_hardware_0 = HPUXHardware(module=None, collected_facts=collected_facts)
    assert h_p_u_x_hardware_0.get_hw_facts() != {}

# Generated at 2022-06-24 22:00:23.500906
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    if not HPUXHardwareCollector.__doc__:
        print("Class HPUXHardwareCollector has no doc string")

# Generated at 2022-06-24 22:00:24.885205
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = get_hw_facts()


# Generated at 2022-06-24 22:00:37.667188
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    assert h_p_u_x_hardware_0.get_memory_facts(collected_facts) == {'swaptotal_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 511, 'memfree_mb': 511}
    collected_facts = {'ansible_architecture': 'ia64'}
    assert h_p_u_x_hardware_0.get_memory_facts(collected_facts) == {'swaptotal_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 16384, 'memfree_mb': 511}


# Generated at 2022-06-24 22:00:43.139089
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {}
    assert h_p_u_x_hardware_0.get_memory_facts(collected_facts) == {'swapfree_mb': 1036, 'memtotal_mb': 8192, 'memfree_mb': 7945, 'swaptotal_mb': 1036}


# Generated at 2022-06-24 22:00:45.314145
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()



# Generated at 2022-06-24 22:00:54.926041
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    fixture_primary_facts = {
        'os_family': None,
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23',
        'ansible_facts': {
            'ansible_distribution': 'HP-UX',
            'ansible_distribution_version': 'B.11.23',
            'ansible_os_family': 'HP-UX',
        }
    }

# Generated at 2022-06-24 22:00:59.354930
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    if h_p_u_x_hardware_collector_0.__class__ is HPUXHardwareCollector:
        print("Test #0 Passed for constructor of HPUXHardwareCollector.")
    else:
        print("Test #0 Failed for constructor of HPUXHardwareCollector.")


# Generated at 2022-06-24 22:01:04.261717
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    print(h_p_u_x_hardware_collector_0)

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:01:12.881061
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.module = get_module()
    h_p_u_x_hardware_get_hw_facts_ret_val = h_p_u_x_hardware.get_hw_facts()
    assert h_p_u_x_hardware_get_hw_facts_ret_val['model'] == 'ia64 hp Integrity rx2660'
    assert h_p_u_x_hardware_get_hw_facts_ret_val['firmware_version'] == '5.4-7'
    assert h_p_u_x_hardware_get_hw_facts_ret_val['product_serial'] == ''


# Generated at 2022-06-24 22:01:31.318495
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command = MagicMock()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'test_out', 'test_err')
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:39.316898
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_distribution_version': 'B.11.23',
                       'ansible_architecture': 'ia64'}
    result = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert result['processor'] == 'Intel (R) Itanium (R)'
    assert result['processor_cores'] == 1
    assert result['processor_count'] == 2



# Generated at 2022-06-24 22:01:42.781954
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:01:52.051479
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    rc, out, err = h_p_u_x_hardware_0.module.run_command("model")
    model = out.strip()
    rc, out, err = h_p_u_x_hardware_0.module.run_command("uname -m")
    arch = out.strip()
    rc, out, err = h_p_u_x_hardware_0.module.run_command("uname -r")
    rel = out.strip()
    collected_facts = {'ansible_architecture': arch, 'ansible_distribution_version': rel}
    if arch == 'ia64':
        if rel == "B.11.23":
            rc, out, err = h_p_u_

# Generated at 2022-06-24 22:01:56.060128
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_1



# Generated at 2022-06-24 22:02:04.783870
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': '9000/800',
    }

    # Call method
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)

    # Check results
    assert cpu_facts == {
        'processor_count': '1'
    }



# Generated at 2022-06-24 22:02:06.498745
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # case 0
    h_p_u_x_hardware_0 = HPUXHardware()


# Generated at 2022-06-24 22:02:11.053397
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware({'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.23'})
    assert h_p_u_x_hardware_0.populate()['processor_count'] > 0


# Generated at 2022-06-24 22:02:18.765148
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()
    # Test for correct processor count for HPPA
    assert h_p_u_x_hardware_0.facts['processor_count'] == 1
    # Test for correct processor count for HP-UX ia64 architecture
    h_p_u_x_hardware_0.facts['ansible_architecture'] = 'ia64'
    h_p_u_x_hardware_0.facts['ansible_distribution_version'] = 'B.11.23'
    h_p_u_x_hardware_0.get_cpu_facts()
    assert h_p_u_x_hardware_0.facts['processor_count'] == 1

# Unit

# Generated at 2022-06-24 22:02:26.332855
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = {"file": "file"}
    h_p_u_x_hardware_0._module = {"run_command": "run_command"}
    h_p_u_x_hardware_0.run_command = {"run_command": "run_command"}
    # Execute the function being tested
    out = h_p_u_x_hardware_0.get_memory_facts()
    # Verify the results
    assert(out.get('memtotal_mb') == None)


# Generated at 2022-06-24 22:02:45.842852
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    result = h_p_u_x_hardware_0.get_memory_facts()
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result


# Generated at 2022-06-24 22:02:47.060931
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


test_case_0()


# Generated at 2022-06-24 22:02:48.715121
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()


# Generated at 2022-06-24 22:02:51.313494
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module)
    str_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts={})
    assert len(str_0) >= 2



# Generated at 2022-06-24 22:02:57.313523
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    collected_facts = {'ansible_architecture': '9000/800',
                       'distribution': 'HP-UX',
                       'platform': 'HP-UX',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.31',
                       'ansible_os_family': 'Unix',
                       'ansible_system': 'HP-UX'}
    h_p_u_x_hardware.collect(collected_facts=collected_facts)
    assert h_p_u_x_hardware.ansible_facts['processor_cores'] == 1
    assert h_p_

# Generated at 2022-06-24 22:03:02.737060
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()
    # Test with no arguments
    h_p_u_x_hardware_0.get_cpu_facts()
    h_p_u_x_hardware_0.populate()
    # Test with arguments
    collected_facts = dict()
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)


# Generated at 2022-06-24 22:03:09.707370
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    h_p_u_x_hardware_0.module.params['gather_subset'] = []
    h_p_u_x_hardware_0.module.params['gather_timeout'] = 5
    h_p_u_x_hardware_0.populate()
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts()
    assert cpu_facts


# Generated at 2022-06-24 22:03:17.084266
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Test case header
    test_case_num = 0

    # Test case 0: No arg
    test_case_0_hpux_hardware_get_cpu_facts_0 = HPUXHardware()
    test_case_0_expected_result = dict(
        processor='Intel Itanium2',
        processor_cores=8,
        processor_count=16
    )
    test_case_0_result = test_case_0_hpux_hardware_get_cpu_facts_0.get_cpu_facts(collected_facts=dict(
                                                                                ansible_architecture='ia64',
                                                                                ansible_distribution_version='B.11.23'
                                                                                                ))

# Generated at 2022-06-24 22:03:19.096607
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector()


# Generated at 2022-06-24 22:03:21.614380
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:03:40.290613
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    print("In get_cpu_facts() for HP-UX")
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.get_cpu_facts(None)



# Generated at 2022-06-24 22:03:43.443753
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h._fact_class == HPUXHardware
    assert h._platform == 'HP-UX'
    assert h.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:03:50.966486
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HPUXHardware = HPUXHardware()
    collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.23"
    }
    expected_results = {'firmware_version': 'B.11.31.0004', 'model': 'IA64 rx2600aa', 'product_serial': '123456789A'}
    results = HPUXHardware.get_hw_facts(collected_facts=collected_facts)
    assert (results == expected_results)

    collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.31"
    }

# Generated at 2022-06-24 22:03:58.678119
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware = HPUXHardware(module=None)

    rc, out, err = h_p_u_x_hardware.module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    data = int(re.sub(' +', ' ', out).split(' ')[5].strip())
    assert h_p_u_x_hardware.get_memory_facts().get('memfree_mb') == pagesize * data // 1024 // 1024

# Generated at 2022-06-24 22:04:03.912897
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts={u'ansible_architecture': u'9000/800'})
    assert 'processor' not in cpu_facts
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-24 22:04:13.169942
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware({'platform': 'HP-UX'}, {})
    h_p_u_x_hardware_0.populate({'ansible_architecture': '9000/800'})
    h_p_u_x_hardware_0.populate({'ansible_architecture': '9000/785'})
    h_p_u_x_hardware_0.populate({'ansible_architecture': 'ia64'})
    h_p_u_x_hardware_0.populate({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})

# Generated at 2022-06-24 22:04:18.754591
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])
    assert h_p_u_x_hardware_collector_0._supported_facts == HPUXHardware._supported_facts

# Generated at 2022-06-24 22:04:22.645350
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector._fact_class == HPUXHardware
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:04:29.177361
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:37.586931
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    input_data = {'ansible_facts': {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}}
    collected_facts = input_data.get('ansible_facts')
    h_p_u_x_hardware_0 = HPUXHardware(module=None, collected_facts=collected_facts)
    HPUXHardware.populate = HPUXHardware.get_cpu_facts
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:05:03.731220
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_object = HPUXHardware()
    collected_facts = { "ansible_architecture": "ia64"}
    h_p_u_x_hardware_object.get_hw_facts(collected_facts)


# Generated at 2022-06-24 22:05:09.155936
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)

    rc, out, err = h_p_u_x_hardware_0.module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    assert rc == 0
    assert out == 'Firmware revision = O.71.12.E'


# Generated at 2022-06-24 22:05:16.639739
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_obj_0 = HPUXHardware()
    collected_facts = {
        "ansible_architecture": "9000/800",
        "ansible_distribution": "HP-UX",
        "ansible_distribution_version": "B.11.23"
    }
    h_p_u_x_hardware_obj_0.populate(collected_facts)
    cpu_facts = h_p_u_x_hardware_obj_0.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-24 22:05:23.036550
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX',
        'ansible_architecture': 'ia64'
    }
    h_p_u_x_hardware_0 = HPUXHardware(collected_facts=collected_facts)
    h_p_u_x_hardware_0.module = FakeAnsibleModule()
    h_p_u_x_hardware_0.module.run_command = run_command
    h_p_u_x_hardware_0.get_hw_facts()



# Generated at 2022-06-24 22:05:29.773084
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    h_p_u_x_hardware._module.run_command = lambda args, **kwargs: (0, 'Firmware revision', '')
    assert h_p_u_x_hardware.get_hw_facts() == {'firmware_version': 'revision'}


# Generated at 2022-06-24 22:05:33.162251
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()

# Generated at 2022-06-24 22:05:35.300531
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware = HPUXHardware()
    assert h_p_u_x_hardware.get_cpu_facts() == {}


# Generated at 2022-06-24 22:05:45.607077
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    ansible_facts = {}
    ansible_facts['ansible_architecture'] = '9000/800'
    ansible_facts['ansible_distribution_version'] = 'B.11.23'
    h_p_u_x_hardware_0._module = mock.Mock()
    h_p_u_x_hardware_0._module.run_command = mock.Mock(return_value=(1, 'out', 'err'))
    h_p_u_x_hardware_0.get_cpu_facts(ansible_facts)


# Generated at 2022-06-24 22:05:49.518419
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    HPUXHardware_instance_0 = HPUXHardware(ansible_module=None)
    memfree_mb = HPUXHardware_instance_0.get_memory_facts()['memfree_mb']



# Generated at 2022-06-24 22:06:00.718387
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware()
    assert (h_p_u_x_hardware.get_hw_facts() == {'model': 'test_out_strip', 'firmware_version': 'test_out_split_1_strip', 'product_serial': 'test_out_split_1_strip'})
    assert (h_p_u_x_hardware.get_hw_facts(collected_facts={'ansible_architecture': 'ia64'}) == {'model': 'test_out_strip', 'firmware_version': 'test_out_split_1_strip', 'product_serial': 'test_out_split_1_strip'})

# Generated at 2022-06-24 22:06:32.222092
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:06:39.629560
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    input_facts = {
        'ansible_architecture': '9000/800',
        'ansible_architecture_type': 'PA-RISC'
    }
    expected_facts_0 = {'processor_count': 2}
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(dict(platform='HP-UX', distribution='B.11.31'))
    h_p_u_x_hardware_0.populate(collected_facts=input_facts)
    model_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=None)
    assert model_0 == expected_facts_0

# Generated at 2022-06-24 22:06:42.476352
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware = HPUXHardware()
    data = {
        "ansible_architecture": 'ia64',
        "ansible_distribution_version": 'B.11.23'
    }
    output = h_p_u_x_hardware.get_memory_facts(collected_facts=data)
    assert output


# Generated at 2022-06-24 22:06:45.979670
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module={})
    h_p_u_x_hardware_1 = h_p_u_x_hardware_0
    h_p_u_x_hardware_1.module = {'run_command': run_command}
    result = h_p_u_x_hardware_1.get_memory_facts()
    assert result['swaptotal_mb'] == 596



# Generated at 2022-06-24 22:06:56.258090
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(None)
    rc, out, err = h_p_u_x_hardware_0.module.run_command("model")
    h_p_u_x_hardware_0.collected_facts['ansible_architecture'] = 'ia64'
    h_p_u_x_hardware_0.collected_facts['ansible_distribution_version'] = 'B.11.23'
    rc, out, err = h_p_u_x_hardware_0.module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    separator = '='
    rc, out, err = h_

# Generated at 2022-06-24 22:07:05.895635
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    results = HPUXHardware().populate()
    assert results['memtotal_mb'] >= 0
    assert results['memfree_mb'] >= 0
    assert results['swapfree_mb'] >= 0
    assert results['swaptotal_mb'] >= 0
    assert results['processor_count'] >= 0
    assert results['processor_cores'] >= 0
    assert results['processor'] == 'Intel'
    assert results['firmware_version'] == 'B.11.31.1606.0.0.33.9'
    assert results['product_serial'] == 'USEU5310107'
    assert results['model'] == 'HP Integrity Superdome 2'


test_case_0()
test_HPUXHardware_populate()

# Generated at 2022-06-24 22:07:15.941843
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution": "HP-UX",
        "ansible_distribution_version": "B.11.23"
    }
    # Returned value from function
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    h_p_u_x_hardware_0.populate()
    return_value = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts)
    # Expected value
    expected_value = {
        "firmware_version": None,
        "model": "ia64 hp server rx2660",
        "product_serial": "CNU1143ZCN"
    }
   

# Generated at 2022-06-24 22:07:22.183949
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {'platform': 'HP-UX'}
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:07:28.045335
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command.return_value = ('', '', '')
    h_p_u_x_hardware_0.populate({})


# Generated at 2022-06-24 22:07:33.633739
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0.platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])
    assert h_p_u_x_hardware_collector_0.fact_class == HPUXHardware

# Generated at 2022-06-24 22:08:19.311752
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector

# Unit Test for HPUXHardwareCollector.populate()

# Generated at 2022-06-24 22:08:29.826014
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    ansible_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    h_p_u_x_hardware_0.populate(collected_facts=ansible_facts)
    parametrized_method_results = h_p_u_x_hardware_0.get_hw_facts(collected_facts=ansible_facts)
    assert parametrized_method_results['model'] == 'ia64 hp server rx2660'
    assert parametrized_method_results['firmware_version'] == 'HPHW-B.11.23.0.'
