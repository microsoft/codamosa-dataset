

# Generated at 2022-06-24 21:58:47.888193
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

# Test class HPUXHardwareCollector with parameter

# Generated at 2022-06-24 21:58:51.416291
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_obj = HPUXHardware()
    assert h_p_u_x_hardware_obj.get_cpu_facts() == {'processor': 'Intel(R) Xeon(R) CPU E5-2695 v4 @ 2.10GHz',
                                                    'processor_cores': 16,
                                                    'processor_count': 61,
                                                    'processor_threads_per_core': 1}, "get_cpu_facts method is not returning the expected value"



# Generated at 2022-06-24 21:58:57.446749
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {u'ansible_distribution_version': u'B.11.31', u'ansible_architecture': u'ia64', u'platform': u'HP-UX'}

    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor': 'Intel(R) Itanium(R) 9300 series', 'processor_cores': 4, 'processor_count': 2}

    collected_facts = {u'ansible_architecture': u'9000/800', u'platform': u'HP-UX'}

    cpu_facts = h_p_u_x_hardware_0.get_

# Generated at 2022-06-24 21:59:02.818396
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware({'platform': 'HP-UX', 'architecture': 'ia64', 'distribution': 'HPUX', 'distribution_version': 'B.11.23'})
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:59:08.711867
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware()
    collected_facts_0 = {'platform': 'HP-UX', 'ansible_architecture': 'ia64'}
    h_p_u_x_hardware.collector = HPUXHardwareCollector()
    h_p_u_x_hardware.collector.module = MagicMock(name='module')
    h_p_u_x_hardware.collector.module.run_command = MagicMock(name='run_command')
    h_p_u_x_hardware.collector.module.run_command.return_value = (0, 'model\n9000/800/E25\n', '')

# Generated at 2022-06-24 21:59:18.332639
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware, 'Wrong value for HPUXHardwareCollector._fact_class'
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX', 'Wrong value for HPUXHardwareCollector._platform'
    assert h_p_u_x_hardware_collector_0.required_facts == {'platform', 'distribution'}, 'Wrong value for HPUXHardwareCollector.required_facts'

# Generated at 2022-06-24 21:59:30.108342
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = {}
    facts_memory = {}

    hw = HPUXHardware(module=None)

    facts['ansible_architecture'] = "9000/785"
    facts_memory = hw.get_memory_facts(collected_facts=facts)
    assert facts_memory['memfree_mb'] == 155854
    assert facts_memory['memtotal_mb'] == 258759
    assert facts_memory['swaptotal_mb'] == 16384
    assert facts_memory['swapfree_mb'] == 16384

    facts['ansible_architecture'] = "ia64"
    facts['ansible_distribution_version'] = "B.11.23"
    facts_memory = hw.get_memory_facts(collected_facts=facts)
    assert facts_memory['memfree_mb']

# Generated at 2022-06-24 21:59:40.185389
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    print("Test if CPU facts are calculated correctly")
    h_p_u_x_hardware = HPUXHardware()

    collected_facts = {
        'ansible_architecture': '9000/800'
    }
    cpu_facts = h_p_u_x_hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2

    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    cpu_facts = h_p_u_x_hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] > 0
    print("Test passed")

#

# Generated at 2022-06-24 21:59:44.475591
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])

#System runtime test

# Generated at 2022-06-24 21:59:51.780882
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {'platform': 'Linux',
                       'range': '1..255',
                       'ansible_architecture': 'ia64',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.31'}

    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate(collected_facts)
    h_p_u_x_hardware_0.get_hw_facts(collected_facts)


# Generated at 2022-06-24 22:00:16.127572
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware = HPUXHardware()
    cpu_facts = h_p_u_x_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == "Intel(R) Xeon(R) CPU E5-2640 v3 @ 2.60GHz"
    assert cpu_facts['processor_cores'] == 48
    assert cpu_facts['processor_count'] == 48


# Generated at 2022-06-24 22:00:22.042343
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module.run_command = run_command_mock
    h_p_u_x_hardware_0.populate()
    assert h_p_u_x_hardware_0.facts['model'] == 'ia64 hp server rx2660'
    assert h_p_u_x_hardware_0.facts['firmware_version'] == 'B.11.31.3'
    assert h_p_u_x_hardware_0.facts['product_serial'] == 'US1234567890'


# Generated at 2022-06-24 22:00:23.747942
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert 'HardwareCollector' in str(HPUXHardwareCollector)



# Generated at 2022-06-24 22:00:26.549296
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()

    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:00:31.669991
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_1 = HPUXHardware()

    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:40.042235
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = mock.Mock()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'B.11.23\n', '')

    assert h_p_u_x_hardware_0.get_cpu_facts() == {}

    h_p_u_x_hardware_0.module.run_command.assert_called_with('uname -r', use_unsafe_shell=True)



# Generated at 2022-06-24 22:00:45.266238
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = dict(platform='HP-UX', distribution='B.11.23')
    h_p_u_x_hardware_0 = HPUXHardware(collected_facts)
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)


# Generated at 2022-06-24 22:00:54.886826
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Populate a facts dict.
    facts = dict()
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    h_p_u_x_hardware_0.populate(facts)

    # Verify contents of ansible_facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'processor' in facts
    assert 'swapfree_mb' in facts
    assert 'ansible_processor' in facts
    assert 'ansible_processor_cores' in facts
    assert 'ansible_processor_vcpus' in facts

# Generated at 2022-06-24 22:00:59.651034
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    hardware = HPUXHardware()
    memory_facts = hardware.get_memory_facts()
    assert type(memory_facts['swaptotal_mb']) == int
    assert type(memory_facts['swapfree_mb']) == int
    assert type(memory_facts['memfree_mb']) == int
    assert type(memory_facts['memtotal_mb']) == int


# Generated at 2022-06-24 22:01:02.820377
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXHardware
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-24 22:01:26.923513
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert True == True


# Generated at 2022-06-24 22:01:39.063817
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Initialize a HPUXHardware object
    h_p_u_x_hardware_0 = HPUXHardware()
    
    # Read ansible_facts from 'ansible/test/unit/module_utils/facts/hardware/test_HPUXHardware.py'
    #
    # Sample format of test file:
    #
    # ansible_facts = {
    #    'ansible_architecture': '9000/800',
    # }
    #
    # Warning: To work properly, ansible_facts dict must be in the format shown above.
    # Facts must also be read from a file named 'test_<path to the class getting tested>.py', in this case 'test_HPUXHardware.py'

# Generated at 2022-06-24 22:01:44.744768
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    h_p_u_x_hardware_0.populate(collected_facts={u'ansible_architecture': u'9000/800'})
    h_p_u_x_hardware_0.get_cpu_facts()
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts={u'ansible_architecture': u'ia64'})
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts={u'ansible_architecture': u'ia64', u'ansible_distribution_version': u'B.11.23'})

# Generated at 2022-06-24 22:01:49.734923
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    h_p_u_x_hardware_0.get_memory_facts(collected_facts)


# Generated at 2022-06-24 22:01:51.364395
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:01:57.913946
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_case_0_h_p_u_x_hardware_collector = HPUXHardwareCollector()
    test_case_0_h_p_u_x_hardware = test_case_0_h_p_u_x_hardware_collector.collect()[0]
    test_case_0_h_p_u_x_hardware.populate()


# Generated at 2022-06-24 22:02:01.482321
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)


# Generated at 2022-06-24 22:02:11.470847
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    helper_func_0a = dict({'ansible_architecture': '9000/800'})
    helper_func_0b = dict({'ansible_architecture': '9000/785'})
    helper_func_0c = dict({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    helper_func_0d = dict({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})

    # Testing with:
    # ansible_architecture=9000/800
    n_p_u_x_hardware_0 = HPUXHardware()
    n_p_u_x_hardware_0.module = get_module_mock()
    n_

# Generated at 2022-06-24 22:02:14.258424
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert not bool(h_p_u_x_hardware_collector_1)


# Generated at 2022-06-24 22:02:17.803204
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31',
    }

    h_p_u_x_hardware_0 = HPUXHardware(collected_facts)

    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:49.664891
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:53.727341
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    collected_facts_0 = {}
    collected_facts_0['ansible_architecture'] = 'ia64'
    collected_facts_0['ansible_distribution_version'] = 'B.11.23'
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts_0)


# Generated at 2022-06-24 22:02:59.758405
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    list_0 = []
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(list_0)
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:03:02.699812
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:05.955009
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    # Test str length
    assert len(h_p_u_x_hardware_0.populate()) > 0


# Generated at 2022-06-24 22:03:12.734219
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    # dict object
    var_0 = h_p_u_x_hardware_collector_0.collect()
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_0 = h_p_u_x_hardware_0.populate()
    var_0 = h_p_u_x_hardware_collector_0.get_platform()
    # int object
    var_1 = h_p_u_x_hardware_collector_0.sort_priority



# Generated at 2022-06-24 22:03:16.125237
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:21.563034
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    list_0 = []
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(list_0)

# Test case for method get_cpu_facts

# Generated at 2022-06-24 22:03:29.746439
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    list_0 = []
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(list_0, None)
    assert h_p_u_x_hardware_collector_0.required_facts == {'distribution', 'platform'}, 'required facts is wrong'
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX', 'platform is wrong'
    assert h_p_u_x_hardware_collector_0.name == 'HPUXHardwareCollector', 'name is wrong'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware, 'fact class is wrong'

# Generated at 2022-06-24 22:03:32.713180
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == "__main__":
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:45.799541
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:48.059248
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware([])
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:04:58.274822
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # test case 1
    list_1 = ['distribution', 'platform']
    hpuxhardware_collector_1 = HPUXHardwareCollector(list_1)
    var_3 = hpuxhardware_collector_1.platform
    var_4 = hpuxhardware_collector_1.required_facts
    # test case 2
    list_2 = ['distribution', 'platform']
    hpuxhardware_collector_2 = HPUXHardwareCollector(list_2)
    var_5 = hpuxhardware_collector_2.platform
    var_6 = hpuxhardware_collector_2.required_facts
    # test case 3
    list_3 = ['distribution', 'platform']
    hpuxhardware_collector_3 = HPUXHardwareCollector(list_3)
   

# Generated at 2022-06-24 22:05:01.607769
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:06.602683
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    list_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()
    assert var_0 == {}



# Generated at 2022-06-24 22:05:11.392604
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    list_1 = []
    h_p_u_x_hardware_1 = HPUXHardware(list_1)
    assert isinstance(h_p_u_x_hardware_1.get_memory_facts(), dict)

# Generated at 2022-06-24 22:05:16.941369
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_0 = h_p_u_x_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:05:19.264009
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    try:
        h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 22:05:25.912597
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    ansible_architecture_0 = '9000/785'
    ansible_architecture_1 = '9000/800'
    ansible_architecture_2 = 'ia64'
    ansible_architecture_3 = 'ia64'
    ansible_distribution_version_0 = 'B.11.23'
    ansible_architecture_4 = 'ia64'
    ansible_distribution_version_1 = 'B.11.31'

# Generated at 2022-06-24 22:05:28.717436
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_0 = h_p_u_x_hardware_0.populate()
    assert len(var_0) == 2


# Generated at 2022-06-24 22:06:35.998737
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    var_0 = h_p_u_x_hardware_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:06:40.327223
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    assert h_p_u_x_hardware_0.get_hw_facts() == {}


# Generated at 2022-06-24 22:06:44.811903
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    list_1 = []
    h_p_u_x_hardware_1 = HPUXHardware(list_1)
    h_p_u_x_hardware_1.populate()
    assert 'processor_cores' in h_p_u_x_hardware_1.get_cpu_facts()
    assert 'processor_count' in h_p_u_x_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:06:50.102431
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class HPUXHardware
    """
    hardware_0 = HPUXHardware()
    collected_facts_0 = {}
    hardware_0.populate(collected_facts_0)
    var_0 = hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:06:54.273630
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)

    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:06:57.638166
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    list_2 = []
    h_p_u_x_hardware_2 = HPUXHardware(list_2)
    var_2 = h_p_u_x_hardware_2.get_cpu_facts()


# Generated at 2022-06-24 22:06:59.136942
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()

# Generated at 2022-06-24 22:07:02.844149
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:07:07.994904
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    list_0 = []
    h_p_u_x_hardware_0 = HPUXHardware(list_0)
    var_1 = h_p_u_x_hardware_0.populate()
    assert var_1 == {'memtotal_mb': 1024, 'memfree_mb': 24, 'swaptotal_mb': 0, 'swapfree_mb': 0}


# Generated at 2022-06-24 22:07:10.609966
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.get_cpu_facts()
