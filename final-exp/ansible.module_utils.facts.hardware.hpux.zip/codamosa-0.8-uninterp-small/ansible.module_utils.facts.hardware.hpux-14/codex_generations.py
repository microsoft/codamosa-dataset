

# Generated at 2022-06-24 21:58:42.580809
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 21:58:54.924186
# Unit test for method populate of class HPUXHardware

# Generated at 2022-06-24 21:59:00.200633
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    # Unit test for method populate() of class HPUXHardwareCollector
    # Test with empty argument dictionary
    h_p_u_x_hardware_collector_0.populate()
    # Test with argument dictionary
    dict_0 = {}
    dict_0['ansible_architecture'] = 'ia64'
    dict_0['ansible_distribution_version'] = 'B.11.31'
    h_p_u_x_hardware_collector_0.populate(dict_0)
    dict_0['ansible_architecture'] = 'ia64'

# Generated at 2022-06-24 21:59:04.130360
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 21:59:12.203987
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_2 = False
    h_p_u_x_hardware_1 = HPUXHardware(bool_2)
    collected_facts_0 = {'ansible_architecture': '9000/800'}
    var_2 = h_p_u_x_hardware_1.get_cpu_facts(collected_facts_0)
    assert var_2 == {'processor_count': 0}, 'CPU processor_count is %s' % var_2['processor_count']


# Generated at 2022-06-24 21:59:19.558200
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    arg_0 = 1
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(arg_0)
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-24 21:59:22.355732
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(False)
    assert h_p_u_x_hardware_0.get_memory_facts() == {}


# Generated at 2022-06-24 21:59:23.660707
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    # set up class object
    bool_0 = False
    HPUXHardwareCollector(bool_0)

# Generated at 2022-06-24 21:59:25.238642
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = None
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)

# Generated at 2022-06-24 21:59:30.237238
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    h_p_u_x_hardware_collector_0.platform = 'platform'
    h_p_u_x_hardware_collector_0.required_facts = ['platform']


# Generated at 2022-06-24 21:59:47.909368
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_obj_0 = HPUXHardware()
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    h_p_u_x_hardware_obj_0.populate(collected_facts=collected_facts)
    test_facts = h_p_u_x_hardware_obj_0.get_hw_facts()
    assert 'firmware_version' in test_facts
    assert test_facts['firmware_version'] == 'V7.41'


# Generated at 2022-06-24 21:59:54.360557
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.get_hw_facts(data)
    data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.get_hw_facts(data)


# Generated at 2022-06-24 22:00:00.573514
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    rc, out, err = h_p_u_x_hardware_0.module.run_command.return_value
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'Superdome Fire X (41)', '')
    h_p_u_x_hardware_0.module.run_command.return_value = (0, "machinfo:Firmware Revision = <H 01021718>\n", '')
    h_p_u_x_hardware_0.module.run_command.return_value = (0, "machinfo:Machine serial number = HSC0517098", '')
    h_p_u_x_hardware_0

# Generated at 2022-06-24 22:00:05.704063
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'model', ''))
    h_p_u_x_hardware_0.get_hw_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    h_p_u_x_hardware_0.module.run_command.assert_called_with("model")

# Generated at 2022-06-24 22:00:17.610130
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """Test get_cpu_facts of HPUXHardware class"""
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MockModule()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '1', '')
    h_p_u_x_hardware_0.module.params = {'gather_subset': ['!all', '!min']}

    # Testing with 'ansible_architecture'
    h_p_u_x_hardware_0.populate({'ansible_architecture': '9000/785'})
    expected_dict = {'processor_count': 1}
    assert h_p_u_x_hardware_0

# Generated at 2022-06-24 22:00:22.470111
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    ##
    # Test a normal return
    ##

    ##
    # Test a normal return
    ##

    # Test with an argument

    assert isinstance(h_p_u_x_hardware_0.get_cpu_facts(), dict)


# Generated at 2022-06-24 22:00:28.843903
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': ""}
    expected = {'processor_count': 64, 'processor': 'PA-RISC 1.1 (hppa64)', 'model': '9000/800/J6240',
                'processor_cores': 4, 'memtotal_mb': 2048, 'swaptotal_mb': 101, 'swapfree_mb': 101,
                'memfree_mb': 12, 'firmware_version': 'B.11.23', 'product_serial': 'SASW8X1B27J00WP'}
    actual = hardware.populate(collected_facts)

# Generated at 2022-06-24 22:00:35.799166
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    # Run method get_cpu_facts of class HPUXHardware
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)
    assert cpu_facts[u'processor_count'] == 2


# Generated at 2022-06-24 22:00:39.922371
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    mem_facts = h_p_u_x_hardware_0.get_memory_facts()
    assert len(list(mem_facts.keys())) == 4


# Generated at 2022-06-24 22:00:42.758032
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware = HPUXHardware()
    assert h_p_u_x_hardware.populate() is None


# Generated at 2022-06-24 22:00:57.058369
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    ansible_facts = dict(ansible_architecture='9000/800')
    rc, out, err = h_p_u_x_hardware_0.module.run_command("ioscan -FkCprocessor | wc -l")
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(ansible_facts)
    assert int(out.strip()) == cpu_facts['processor_count']



# Generated at 2022-06-24 22:00:59.513641
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
   assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'


# Generated at 2022-06-24 22:01:10.063771
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    h_p_u_x_hardware_0.module.run_command = Mock()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'Model number: HP Integrity rx2800 i2', '')
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'Firmware revision = 01.13', '')
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'Machine serial number =', '')
   

# Generated at 2022-06-24 22:01:22.067771
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    h_p_u_x_hardware_0.populate(collected_facts=collected_facts)
    assert h_p_u_x_hardware_0.cpu_facts['processor_count'] == 4
    assert h_p_u_x_hardware_0.cpu_facts['processor'] == 'PA-RISC 2.0'
    assert h_p_u_x_hardware_0.hw_facts['model'] == 'Integrity rx2620'
    assert h_p_u_x_hardware_0.hw_facts['firmware_version'] == 'B.11.31'
   

# Generated at 2022-06-24 22:01:24.902337
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    result = h_p_u_x_hardware_0.get_memory_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:01:29.705884
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    coll_facts = {'ansible_architecture': '9000/800',
                  'ansible_distribution_version': 'B.11.31'}
    h_p_u_x_hardware = HPUXHardware(module=None)
    h_p_u_x_hardware.get_cpu_facts(collected_facts=coll_facts)


# Generated at 2022-06-24 22:01:42.117871
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware({})
    # Test with architecture 9000/800
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '2', ''))
    h_p_u_x_hardware_0.module.params = {'gather_subset': ['!all', 'min']}
    h_p_u_x_hardware_0.module.params = {'gather_timeout': 5}
    h_p_u_x_hardware_0.module.params = {'gather_subset': ['all']}
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:01:47.745075
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    # Return value of run_command is (rc, out, err)
    mock_rc = 0
    mock_out = '2'
    mock_err = ''
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    mock_run_command = {'9000/800': 'ioscan -FkCprocessor | wc -l', '9000/785': 'ioscan -FkCprocessor | wc -l', 'ia64': '/usr/contrib/bin/machinfo | grep \'Number of CPUs\''}


# Generated at 2022-06-24 22:01:55.036818
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware(
        module=AnsibleModule(
            argument_spec={},
            supports_check_mode=False,
            check_invalid_arguments=False,
        )
    )
    h_p_u_x_hardware_0.collect_platform_subset = MagicMock(return_value={'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'})
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '20', None))
    h_p_u_x_hardware_0.collect_subset = MagicMock(return_value=MagicMock())
    h_p_u

# Generated at 2022-06-24 22:02:06.100604
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_1 = HPUXHardware()
    h_p_u_x_hardware_2 = HPUXHardware()
    h_p_u_x_hardware_3 = HPUXHardware()
    h_p_u_x_hardware_4 = HPUXHardware()
    h_p_u_x_hardware_5 = HPUXHardware()
    h_p_u_x_hardware_6 = HPUXHardware()
    h_p_u_x_hardware_7 = HPUXHardware()
    h_p_u_x_hardware_8 = HPUXHardware()
    h_p_u_x_hardware_9 = HPUXHardware()

# Generated at 2022-06-24 22:02:19.124529
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_1 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_1._fact_class == HPUXHardware
    assert h_p_u_x_hardware_1._platform == 'HP-UX'

# Generated at 2022-06-24 22:02:20.213010
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(_fact_class=None)

# Generated at 2022-06-24 22:02:30.795826
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(None)
    collected_facts = json.loads(open('h-p-u-x-hardware_get_hw_facts_0.json').read())

    h_p_u_x_hardware_0.module.run_command = run_command_sim

    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts)
    print(repr(var_0))
    assert var_0 == {'firmware_version': 'J37 v2.21 2014-05-16_17:26', 'product_serial': 'CZC3461PHY', 'model': 'POWER8_V2'}


# Generated at 2022-06-24 22:02:39.560675
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    #
    # set h_p_u_x_hardware_collector_0._platform
    h_p_u_x_hardware_collector_0._platform = 'Linux'
    #
    # set h_p_u_x_hardware_collector_0._fact_class
    h_p_u_x_hardware_collector_0._fact_class = None
    #
    # set h_p_u_x_hardware_collector_0._required_facts
    h_p_u_x_hardware_collector_0._required_facts = set()
    bool_1 = h_p_u_x_hardware_collect

# Generated at 2022-06-24 22:02:44.033218
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    bool_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:46.730484
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    h_p_u_x_hardware_0 = HPUXHardware(collected_facts)
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts)


# Generated at 2022-06-24 22:02:56.315867
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.populate()
    # get_cpu_facts() execution testing
    # get_cpu_facts() of HPUXHardware
    h_p_u_x_hardware_0.get_cpu_facts()
    # get_cpu_facts() parameters testing
    collected_facts = {}
    # get_cpu_facts() execution testing
    # get_cpu_facts() of HPUXHardware
    h_p_u_x_hardware_1 = HPUXHardware(collected_facts)
    h_p_u_x_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:03:01.468356
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)

    var_0 = 'ansible_architecture'
    var_0 = "9000/785"

    var_1 = h_p_u_x_hardware_0.get_memory_facts(var_0)
    assert sys.getsizeof(var_1) <= sys.getsizeof('test_string')


# Generated at 2022-06-24 22:03:09.617456
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = None
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}
    str_0 = 'ansible_architecture'
    str_1 = 'ia64'
    var_2 = str_1
    collected_facts_0.update({str_0: var_2})
    str_0 = 'ansible_distribution_version'
    str_1 = 'B.11.31'
    var_2 = str_1
    collected_facts_0.update({str_0: var_2})
    var_3 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)
    assert isinstance(var_3, dict)


# Generated at 2022-06-24 22:03:13.230237
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    expected_result = ('HPUXHardwareCollector', 'HardwareCollector')

    class_under_test = HPUXHardwareCollector()
    result = class_under_test.__class__.__mro__

    assert result == expected_result, "'%s' should be '%s'" % (result, expected_result)

# Generated at 2022-06-24 22:03:34.084719
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Test with an empty argument
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:03:39.528396
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'

# Generated at 2022-06-24 22:03:43.401785
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.populate()
    dictionary_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:03:44.839171
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()


# Generated at 2022-06-24 22:03:48.189653
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:55.258832
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.get_hw_facts()
    h_p_u_x_hardware_0.get_cpu_facts()
    h_p_u_x_hardware_0.get_memory_facts()
    collected_facts_0 = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31', 'platform': 'HP-UX', 'distribution': 'HP-UX'}
    h_p_u_x_hardware_0.populate(collected_facts_0)

# Generated at 2022-06-24 22:04:00.745352
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    os_platform = 'HP-UX'
    os_name = 'HP-UX'
    os_major_version = 11
    os_minor_version = 31
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector(os_platform, os_name, os_major_version, os_minor_version)


# Generated at 2022-06-24 22:04:10.392444
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.module = ansible_module
    rc, out, err = ansible_module.run_command("model")
    h_p_u_x_hardware_0.module.architecture = "ia64"
    h_p_u_x_hardware_0.module.distribution_version = "B.11.23"
    rc, out, err = ansible_module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)

# Generated at 2022-06-24 22:04:12.905135
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    var_0 = h_p_u_x_hardware_collector_0.update()


# Generated at 2022-06-24 22:04:15.863897
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    # TODO: assert something

if __name__ == '__main__':
    test_case_0()

    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:05:03.682267
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    assert True == True


# Generated at 2022-06-24 22:05:07.961502
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(bool())
    assert h_p_u_x_hardware_0.get_memory_facts() == {'memfree_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 0}


# Generated at 2022-06-24 22:05:14.627861
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_collector_0.collected_facts = {u'distribution_version': u'B.11.31', 'platform': 'HP-UX', u'distribution': u'HP-UX'}
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    h_p_u_x_hardware_0.get_hw_facts()

# Generated at 2022-06-24 22:05:18.206095
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:05:20.693830
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = False
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)


# Generated at 2022-06-24 22:05:23.342463
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:05:27.436816
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(None)
    var_1 = h_p_u_x_hardware_0.get_memory_facts()
    assert (isinstance(var_1, dict))


# Generated at 2022-06-24 22:05:30.488111
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:32.651551
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


test_case_0()
test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:05:40.133247
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:07:09.163347
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}
    collected_facts_0['ansible_architecture'] = 'ia64'
    collected_facts_0['ansible_distribution_version'] = 'B.11.23'
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)


# Generated at 2022-06-24 22:07:15.149476
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware(None)
    if (h_p_u_x_hardware_0.get_cpu_facts()) is None:
        # The condition should not be reached.
        raise Exception('Assertion error: "The condition should not be reached."')


# Generated at 2022-06-24 22:07:19.546013
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Collecting facts
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    bool_0 = 'ansible_architecture'
    bool_1 = '9000/800'
    collected_facts_0 = dict([])
    collected_facts_0[bool_0] = bool_1
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts_0)


# Generated at 2022-06-24 22:07:24.426142
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.populate()

# Generated at 2022-06-24 22:07:27.791703
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:07:37.158216
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(False)
    h_p_u_x_hardware_1 = HPUXHardware(True)
    h_p_u_x_hardware_2 = HPUXHardware(0)
    h_p_u_x_hardware_3 = HPUXHardware(1)
    h_p_u_x_hardware_4 = HPUXHardware('')
    h_p_u_x_hardware_5 = HPUXHardware('a')
    h_p_u_x_hardware_6 = HPUXHardware(b'a')
    h_p_u_x_hardware_7 = HPUXHardware(b'2')

# Generated at 2022-06-24 22:07:43.476529
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_0)


# Generated at 2022-06-24 22:07:45.730361
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:07:54.496928
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)

    var_2 = {"ansible_architecture" : "ia64", "ansible_distribution_version" : "B.11.23"}
    var_1 = h_p_u_x_hardware_0.populate(var_2)
    var_3 = {"ansible_architecture" : "ia64", "ansible_distribution_version" : "B.11.31"}
    var_4 = h_p_u_x_hardware_0.populate(var_3)


if __name__ == '__main__':
    test_case_0()
    test_HPUXHardware_populate()

# Generated at 2022-06-24 22:07:59.704646
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == "__main__":
    try:
        test_case_0()
    except AssertionError:
        pass
    except:
        raise
    test_HPUXHardwareCollector()