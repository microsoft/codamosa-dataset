

# Generated at 2022-06-24 21:58:49.803255
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_1 = 'M-~&%s\t5W5wE]0W'
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    str_2 = 'F-~&%s\t5W5wE]0W'


# Generated at 2022-06-24 21:58:52.466569
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    str_0 = 'f1Q\t&\x7f,o\x7f4'


# Generated at 2022-06-24 21:59:01.240372
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collected_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX'
    }
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(collected_facts=collected_facts)
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 21:59:13.718933
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    list_0 = []
    list_0.append('')
    str_0 = '/usr/contrib/bin/machinfo | grep \'socket[s]?$\' | tail -1'
    list_0.append(str_0)
    str_1 = '/usr/contrib/bin/machinfo | grep -e \'[0-9] core\' | tail -1'
    list_0.append(str_1)
    str_2 = '/usr/contrib/bin/machinfo | grep Intel'
    list_0.append(str_2)
    str_3 = 'grep Physical /var/adm/syslog/syslog.log'
    list_0.append(str_3)
    list_

# Generated at 2022-06-24 21:59:20.288194
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_get_memory_facts = HPUXHardware()
    h_p_u_x_hardware_get_memory_facts.module = MagicMock()
    h_p_u_x_hardware_get_memory_facts.module.run_command.return_value = (0, "int", "")
    h_p_u_x_hardware_get_memory_facts.get_memory_facts()


# Generated at 2022-06-24 21:59:28.631530
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0.required_facts == {'platform', 'distribution'}

if __name__ == "__main__":
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 21:59:38.367140
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    (h_p_u_x_hardware_collector_2, h_p_u_x_hardware_0) = (None, None)
    str_1 = 'M-~&%s\t5W5wE]0W'
    str_0 = 'M-~&%s\t5W5wE]0W'
    (h_p_u_x_hardware_collector_0, h_p_u_x_hardware_1) = (None, None)
    for i_0 in range(26):
        (h_p_u_x_hardware_collector_0, h_p_u_x_hardware_1) = (HPUXHardwareCollector(), HPUXHardware())

# Generated at 2022-06-24 21:59:48.880720
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Input data for test case
    hpu_x_hardware_0 = HPUXHardware()
    str_0 = '#Dp4!4\x08|\x05\x05\x0e\x1c'

# Generated at 2022-06-24 21:59:55.063010
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    mock_module_0 = Mock(name='module_0',
        run_command=MagicMock(return_value=(0, 'model_out_0', 'model_err_0')),
        )
    h_p_u_x_hardware_0 = HPUXHardware(mock_module_0)
    collected_facts_0 = {}
    str_0 = 'hw_facts_0'
    return_value_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)
    assert str_0 == return_value_0


# Generated at 2022-06-24 22:00:04.480750
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=MagicMock())
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '\n', None)
    str_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert str_0 == {'memfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0}


# Generated at 2022-06-24 22:00:19.950691
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    rc, out, err = h_p_u_x_hardware_0.module.run_command("machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    ret = {"processor_count": int(out.strip().split('=')[1])}
    assert h_p_u_x_hardware_0.get_cpu_facts() == ret


# Generated at 2022-06-24 22:00:32.131876
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0_ansible_facts = {}
    h_p_u_x_hardware_0_ansible_facts['ansible_architecture'] = 'ia64'
    h_p_u_x_hardware_0_ansible_facts['ansible_distribution_version'] = 'B.11.31'
    h_p_u_x_hardware_0.module.run_command = mock_run_command
    h_p_u_x_hardware_0.module.fail_json = mock_fail_json
    h_p_u_x_hardware_0.module.exit_json = mock_exit_json
    h_p_u_x_hardware_

# Generated at 2022-06-24 22:00:35.500809
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpux_hardware_0 = HPUXHardware()
    hpux_hardware_0.populate()
    hpux_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:42.012085
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware._module = ansible_module_mock()
    out_put = h_p_u_x_hardware.get_hw_facts()

    assert out_put.get("model") == "ia64 hp server"
    assert out_put.get("firmware_version") == "v2.34"
    assert out_put.get("product_serial") == "123456789"



# Generated at 2022-06-24 22:00:47.604923
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-24 22:00:54.193950
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    name = 'HP-UX'
    required_facts = ['platform', 'distribution']
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == name
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:00:59.168605
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert True == True

## Unit test for method HPUXHardwareCollector::collect()
#def test_collect_0(capsys):
    #h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    #capsys.readouterr()
    #assert "No facts gathered" in out


# Generated at 2022-06-24 22:01:08.869523
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    # Test with a nonexistent file
    with os.fdopen(os.open(os.devnull, os.O_RDWR)) as f_p:
        with open('/dev/null', 'w') as f_p_1:
            h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, "", ""))
            h_p_u_x_hardware_0.module.run_command.return_value = (0, "", "")
            assert h_p_u_x_hardware_0.get_memory_facts() == {}


# Generated at 2022-06-24 22:01:11.194103
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()



# Generated at 2022-06-24 22:01:23.066829
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_1 = HPUXHardware()

    h_p_u_x_hardware_0._module = h_p_u_x_hardware_1._module = MagicMock()
    h_p_u_x_hardware_0._module.run_command = MagicMock(return_value=(1, """
            total   used   free   shared buffers     cached
Mem:      996524  995392    1132          0    13332    772872
-/+ buffers/cache:    138188   858336
Swap:     489544     4744   489000


            """, ""))

# Generated at 2022-06-24 22:01:37.303993
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 4.133641839962503e-08
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:42.505308
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    # print h_p_u_x_hardware_0.get_memory_facts()

if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv[1:])

# Generated at 2022-06-24 22:01:46.249101
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 796.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:52.050927
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = {"ansible_architecture": "ia64", "ansible_distribution_version": "B.11.23"}
    h_p_u_x_hardware_0._collected_facts = collected_facts_0
    var_0 = h_p_u_x_hardware_0.get_hw_facts()



# Generated at 2022-06-24 22:01:56.477204
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.populate()



# Generated at 2022-06-24 22:01:59.402321
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = 9956.0
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)


# Generated at 2022-06-24 22:02:03.227676
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert_expectations(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)


# Generated at 2022-06-24 22:02:05.836011
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    map_0 = h_p_u_x_hardware_0.get_cpu_facts()
    assert  'processor_cores' in map_0.keys()


# Generated at 2022-06-24 22:02:08.507260
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:02:11.675337
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == '__main__':
  test_HPUXHardwareCollector()
  test_case_0()

# Generated at 2022-06-24 22:02:26.042715
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert var_0 == {'memtotal_mb': 1655, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'memfree_mb': 1562}


# Generated at 2022-06-24 22:02:33.809512
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = 1646.0
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:02:35.974451
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:38.104619
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(True)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()
    assert var_0 is not None

# Generated at 2022-06-24 22:02:41.686040
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    data = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31', 'ansible_system': 'HP-UX'}
    h_p_u_x_hardware_0 = HPUXHardware(data)
    h_p_u_x_hardware_0.get_cpu_facts()

# Generated at 2022-06-24 22:02:45.572889
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:48.713062
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:51.732933
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = 735.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:02:57.389356
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_2 = HPUXHardware(1646.0)
    var_1 = h_p_u_x_hardware_2.get_hw_facts()
    assert var_1.get('firmware_version') == "7.2.1"
    assert var_1.get('product_serial') == "CNU9077JZP"


# Generated at 2022-06-24 22:03:03.043222
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Test with valid values for collected_facts
    h_p_u_x_hardware_1 = HPUXHardware()
    var_1 = h_p_u_x_hardware_1.get_cpu_facts()
    assert len(var_1) >= 2

    # Test with valid values for collected_facts
    h_p_u_x_hardware_2 = HPUXHardware()
    var_2 = h_p_u_x_hardware_2.get_cpu_facts()
    assert len(var_2) >= 2


# Generated at 2022-06-24 22:03:26.704880
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.module = AnsibleModule()
    h_p_u_x_hardware_0.module.run_command = MagicMock()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, "abcd", "")
    collected_facts_0 = {"ansible_architecture": "ia64"}
    h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)


# Generated at 2022-06-24 22:03:29.247088
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:03:32.704470
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()

# Generated at 2022-06-24 22:03:36.591770
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    # Provide a valid argument for collected_facts
    float_1 = 1646.0
    h_p_u_x_hardware_1 = HPUXHardware(float_1)
    var_0 = h_p_u_x_hardware_1.populate()
    print(var_0)
    var_1 = h_p_u_x_hardware_0.get_cpu_facts(var_0)


# Generated at 2022-06-24 22:03:48.154234
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 957.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = {}
    collected_facts_0['ansible_architecture'] = '9000/800'
    try:
        var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts_0)
    except Exception:
        var_0 = None
    float_1 = 2235.0
    h_p_u_x_hardware_1 = HPUXHardware(float_1)
    collected_facts_1 = {}
    collected_facts_1['ansible_architecture'] = 'ia64'

# Generated at 2022-06-24 22:03:50.560099
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1651.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)

    assert h_p_u_x_hardware_0.get_hw_facts() is None



# Generated at 2022-06-24 22:03:53.694413
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()

    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:03:56.103203
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    var_0 = HPUXHardwareCollector()
    assert(var_0.facts == [])


# Generated at 2022-06-24 22:03:57.035372
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    test_case_0()

# Generated at 2022-06-24 22:04:01.468979
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = {}
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)


# Generated at 2022-06-24 22:04:22.342378
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:04:26.975147
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:04:31.540616
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:34.458171
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = test_case_0()
    #TODO: more tests


# Generated at 2022-06-24 22:04:42.038103
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 1088.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.module = Mock()
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=('', 0, ''))
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    if (int(var_0['memtotal_mb']) == 2048) and (int(var_0['swaptotal_mb']) == 1024) and (int(var_0['swapfree_mb']) == 680) and (int(var_0['memfree_mb']) == 872):
            var_1 = True
    else:
            var

# Generated at 2022-06-24 22:04:46.757553
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:51.252449
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:04:55.288724
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    print(h_p_u_x_hardware_0.get_cpu_facts())


# Generated at 2022-06-24 22:05:02.175546
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Init data for test
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    # Execute method
    result = h_p_u_x_hardware_0.get_cpu_facts()
    # Verify test
    var_0 = 0
    assert var_0 == result


# Generated at 2022-06-24 22:05:07.529929
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = {}
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)
    assert var_0 == {}


# Generated at 2022-06-24 22:05:26.866510
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:27.869739
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert True



# Generated at 2022-06-24 22:05:31.220516
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:05:32.246563
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    print("1")


# Generated at 2022-06-24 22:05:35.462136
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:39.487716
# Unit test for method populate of class HPUXHardware

# Generated at 2022-06-24 22:05:48.383066
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

# print(os.access("/dev/kmem", os.R_OK))
# os.chmod("/dev/kmem", 0o777)

# print(os.access("/dev/kmem", os.R_OK))
# rc, out, err = module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'")
# print(rc)
# print(out)
# print(err)

# Generated at 2022-06-24 22:05:59.351139
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    __builtin__.__dict__['collected_facts'] = {}
    __builtin__.__dict__['collected_facts']['ansible_architecture'] = "ia64"
    __builtin__.__dict__['collected_facts']['ansible_distribution_version'] = "B.11.23"
    __builtin__.__dict__['collected_facts']['ansible_architecture'] = "ia64"
    __builtin__.__dict__['collected_facts']['ansible_distribution_version'] = "B.11.23"

# Generated at 2022-06-24 22:06:07.118013
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    exp_val_0 = {}
    exp_val_0['processor_count'] = 2
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)
    assert var_0 == exp_val_0


# Generated at 2022-06-24 22:06:09.811994
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    ret_val = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:06:42.856014
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    float_0 = 1646.0
    float_1 = 1646.0
    float_3 = 1646.0
    float_4 = 1646.0
    float_5 = 1646.0
    float_6 = 1646.0
    float_7 = 1646.0
    float_8 = 1646.0
    float_2 = 1646.0

# Generated at 2022-06-24 22:06:45.178875
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = 1646.0
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)

    print("")
    print("Testing instance")
    print(h_p_u_x_hardware_collector_0)
    print("")

# Generated at 2022-06-24 22:06:51.193143
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    var_1 = h_p_u_x_hardware_collector_0._platform
    assert var_1 == 'HP-UX'
    var_2 = h_p_u_x_hardware_collector_0.required_facts
    assert var_2 == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:06:57.771057
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_1 = 1646.0
    h_p_u_x_hardware_1 = HPUXHardware(float_1)
    var_1 = h_p_u_x_hardware_1.populate()
    assert var_1 == {'processor': 'Intel(R) Itanium(R) Processor 9100 series', 'processor_cores': 2, 'processor_count': 2, 'memtotal_mb': 16000, 'memfree_mb': 239}


# Generated at 2022-06-24 22:07:08.035862
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts_0 = {'64s', '32s', '64sd'}
    collected_facts_1 = {'64s', '64sd', '32s'}
    collected_facts_2 = {'64s', '64sd'}
    collected_facts_3 = {'64s', '64s', '64s'}
    collected_facts_4 = {'64s'}
    collected_facts_5 = {'64s'}
    collected_facts_6 = {'64s', '32s'}
    collected_facts_7 = {'64s'}
    collected_facts_8 = {'64s', '32s'}
    collected_

# Generated at 2022-06-24 22:07:14.127370
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:07:16.493019
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Assert that all expected operations were called
    assert False, "A test for method get_memory_facts of class HPUXHardware"


# Generated at 2022-06-24 22:07:26.908480
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_1 = 1646.0
    h_p_u_x_hardware_1 = HPUXHardware(float_1)
    result_0 = h_p_u_x_hardware_1.get_memory_facts()
    var_1 = getattr(result_0, 'memfree_mb', None)
    assert var_1 is not None
    var_2 = getattr(result_0, 'swapfree_mb', None)
    assert var_2 is not None
    var_3 = getattr(result_0, 'memtotal_mb', None)
    assert var_3 is not None



# Generated at 2022-06-24 22:07:29.130317
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:07:32.207914
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_1 = 1585.0
    h_p_u_x_hardware_1 = HPUXHardware(float_1)
    h_p_u_x_hardware_1.populate()

# Generated at 2022-06-24 22:07:59.081649
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:08:03.339173
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:08:06.970129
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = 4.0
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    assert h_p_u_x_hardware_collector_0 != None

# Generated at 2022-06-24 22:08:13.821957
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = 1646.0
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-24 22:08:15.342394
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert 'HPUXHardwareCollector' in globals(), "Class HPUXHardwareCollector not found!"


# Generated at 2022-06-24 22:08:19.583977
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = 1646.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:08:26.040329
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 2339.62
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})


# Generated at 2022-06-24 22:08:33.907098
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    #
    # Test case for get_memory_facts, when collected_facts['ansible_architecture'] == '9000/800'
    #
    float_0 = 804.0
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts)
    #
    # Test case for get_memory_facts, when collected_facts['ansible_architecture'] == 'ia64'
    #
    float_1 = 459.0