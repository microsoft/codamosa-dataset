

# Generated at 2022-06-24 21:58:48.044852
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x___0 = HPUXHardware()
    h_p_u_x___0.populate()


# Generated at 2022-06-24 21:58:55.809300
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(mock_module_0, out_0, err_0, rc_0)
    h_p_u_x_hardware_0.populate()
    assert h_p_u_x_hardware_0.memory['memfree_mb'] == 616
    assert h_p_u_x_hardware_0.memory['memtotal_mb'] == 7680
    assert h_p_u_x_hardware_0.memory['swapfree_mb'] == 608
    assert h_p_u_x_hardware_0.memory['swaptotal_mb'] == 16384


# Generated at 2022-06-24 21:59:01.134140
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts()
    assert cpu_facts['processor_count'] >= 1
    assert cpu_facts['processor']


# Generated at 2022-06-24 21:59:04.194417
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 21:59:05.313457
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    pass


# Generated at 2022-06-24 21:59:17.653794
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    '''
    - populate:
        - processor_count
        - processor_cores
        - processor
        - memfree_mb
        - memtotal_mb
        - swapfree_mb
        - swaptotal_mb
        - model
        - firmware
    '''
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0._module = {
        'run_command': return_run_command_0
    }
    h_p_u_x_hardware_0.populate(collected_facts={'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'})
    assert h_p_u_x_hardware_0._facts['processor_count'] == 2

# Generated at 2022-06-24 21:59:21.499183
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    try:
        h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    except:
        print("Constructor test failed.")


# Generated at 2022-06-24 21:59:26.141135
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Initialize a HPUXHardware object.
    h_p_u_x_hardware_0 = HPUXHardware()

    # Call the get_memory_facts method of HP-UX hardware object.
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:59:29.054002
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'foo', '')
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 21:59:39.037914
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_1 = HPUXHardware()
    h_p_u_x_hardware_1.module = MagicMock(spec=['run_command'])

# Generated at 2022-06-24 21:59:52.902129
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-24 21:59:57.725352
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_1 = HPUXHardware({'ansible_architecture': '9000/800'})
    var_1 = h_p_u_x_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:00:04.255056
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Unit tests for method HPUXHardware.populate.
    """
    h_p_u_x_hardware_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_0)
    var_0 = h_p_u_x_hardware_0.populate()
    assert var_0 is None

# Generated at 2022-06-24 22:00:09.319572
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()



# Generated at 2022-06-24 22:00:17.513020
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    h_p_u_x_hardware_0.populate()
    # Test for method get_memory_facts of class HPUXHardware
    var_1 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:23.225021
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_1)
    var_0 = h_p_u_x_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:00:29.665635
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    h_p_u_x_hardware_1 = HPUXHardware(h_p_u_x_hardware_collector_1)
    var_1 = h_p_u_x_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:00:31.727625
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:00:33.360587
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    out = HPUXHardware.get_cpu_facts()


# Generated at 2022-06-24 22:00:40.002942
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    collected_facts_0 = FakeFacts()
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_0)



# Generated at 2022-06-24 22:01:01.256554
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:01:07.964723
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    h_p_u_x_hardware_1 = HPUXHardware(h_p_u_x_hardware_collector_1)
    collected_facts_1 = {'ansible_architecture': '9000/800'}
    var_1 = h_p_u_x_hardware_1.get_cpu_facts(collected_facts=collected_facts_1)


# Generated at 2022-06-24 22:01:13.699945
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    if h_p_u_x_hardware_0.populate() != None:
        raise RuntimeError('Test failed')
    if h_p_u_x_hardware_0.get_cpu_facts() != None:
        raise RuntimeError('Test failed')
    if h_p_u_x_hardware_0.get_memory_facts() != None:
        raise RuntimeError('Test failed')
    if h_p_u_x_hardware_0.get_hw_facts() != None:
        raise RuntimeError('Test failed')
    return 0


# Generated at 2022-06-24 22:01:16.707176
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # AssertionError: No configuration found for platform 'HP-UX'
    assert True


# Generated at 2022-06-24 22:01:23.080350
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    print("test_HPUXHardware_get_memory_facts")
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:33.492210
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    collected_facts_0 = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    var_0 = h_p_u_x_hardware_0.populate(collected_facts=collected_facts_0)
    assert var_0.get('model') == 'ia64 hp server rx4640'
    assert var_0.get('processor_cores') == 16

# Generated at 2022-06-24 22:01:36.637659
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var = h_p_u_x_hardware_0.get_cpu_facts()
    assert  1 == len(var)


# Generated at 2022-06-24 22:01:42.027267
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:46.919055
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    h_p_u_x_hardware_1 = HPUXHardware(h_p_u_x_hardware_collector_1)
    var_0 = h_p_u_x_hardware_1.get_hw_facts()


# Generated at 2022-06-24 22:01:54.557642
# Unit test for method populate of class HPUXHardware

# Generated at 2022-06-24 22:02:16.438275
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:02:17.706223
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:02:21.471163
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:28.767970
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    h_p_u_x_hardware = HPUXHardware(h_p_u_x_hardware_collector)
    out = h_p_u_x_hardware.get_memory_facts()
    assert out['swaptotal_mb'] >= 0
    assert out['swapfree_mb'] >= 0
    assert out['memfree_mb'] >= 0
    assert out['memtotal_mb'] > 0


# Generated at 2022-06-24 22:02:34.376163
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:39.130644
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    if h_p_u_x_hardware_0.populate(collected_facts={'platform': 'HP-UX', 'distribution': 'HP-UX', 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}).get('firmware_version') is None:
        raise Exception('firmware_version key should be present')


# Generated at 2022-06-24 22:02:50.059169
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Define test data for constructor of class HPUXHardwareCollector"""
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert isinstance(h_p_u_x_hardware_collector_0.required_facts, set)
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])
    return


# Generated at 2022-06-24 22:02:53.194147
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    h_p_u_x_hardware_1 = HPUXHardware(h_p_u_x_hardware_collector_1)
    var_1 = h_p_u_x_hardware_1.populate()


# Generated at 2022-06-24 22:02:58.509797
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts={'ansible_architecture': '9000/800'})
    var_1 = h_p_u_x_hardware_0.get_memory_facts(collected_facts={'ansible_architecture': 'ia64'})


# Generated at 2022-06-24 22:03:02.697960
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_1 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:03:41.472940
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    memory_facts = None
    out = h_p_u_x_hardware_0.get_hw_facts(memory_facts)


# Generated at 2022-06-24 22:03:49.386624
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    # Test case when ansible_architecture is equal to 9000/800.
    collected_facts = {'ansible_architecture': '9000/800'}
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)

    # Test case when ansible_architecture is equal to 9000/785.
    collected_facts = {'ansible_architecture': '9000/785'}
    h_p_u_x_hardware_collector_1 = HPUXHardware

# Generated at 2022-06-24 22:03:51.616423
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    # AssertionError: The argument types in HPUXHardware.get_cpu_facts() are incompatible


# Generated at 2022-06-24 22:03:54.946852
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert var_0 is None

# Generated at 2022-06-24 22:04:00.413576
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:05.492435
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    h_p_u_x_hardware_1 = HPUXHardware(h_p_u_x_hardware_collector_1)
    var_1 = h_p_u_x_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:04:06.038586
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    assert var_0 == 'fake'


# Generated at 2022-06-24 22:04:12.207083
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts_0 = {
        'platform': 'HP-UX',
        'distribution': 'B.11.31',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
    }

    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts_0)



# Generated at 2022-06-24 22:04:15.709985
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:04:18.105474
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:40.009549
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    h_p_u_x_hardware = HPUXHardware(h_p_u_x_hardware_collector)
    assert isinstance(h_p_u_x_hardware.get_hw_facts(), dict)


# Generated at 2022-06-24 22:05:46.656073
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.populate()
    var_1 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:53.173428
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    # Testing on 9000/785 with PA-RISC B.11.23
    collected_facts_0 = {'ansible_architecture': '9000/785',
                         'ansible_distribution': 'HP-UX',
                         'ansible_distribution_version': 'B.11.23'}
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts_0)
    assert var_0['memfree_mb'] == 42
    assert var_0['memtotal_mb'] == 10

# Generated at 2022-06-24 22:05:55.096836
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    var_1 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:58.588617
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_1._fact_class.__name__ == 'HPUXHardware'


# Generated at 2022-06-24 22:06:04.846077
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:06:11.918305
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    h_p_u_x_hardware_1 = HPUXHardware(h_p_u_x_hardware_collector_1)
    h_p_u_x_hardware_1.module.run_command.return_value = (0, '1', '')
    var_1 = h_p_u_x_hardware_1.get_cpu_facts()
    assert var_1 == {'processor_count': 1}


# Generated at 2022-06-24 22:06:19.630731
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_collector_0 = mock.MagicMock()
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '', '')
    h_p_u_x_hardware_collector_0.get_platform_and_distribution.return_value = ('HP-UX', 'B.11.31')

# Generated at 2022-06-24 22:06:26.325950
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:06:27.785901
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()