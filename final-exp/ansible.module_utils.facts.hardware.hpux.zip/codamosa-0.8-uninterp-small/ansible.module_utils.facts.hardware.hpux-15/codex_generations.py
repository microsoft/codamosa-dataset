

# Generated at 2022-06-24 21:58:49.401798
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    n_m_f = HPUXHardware()
    assert n_m_f.get_memory_facts() == {'swaptotal_mb': 0, 'memfree_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 0}
    assert n_m_f.get_memory_facts(collected_facts= {'ansible_distribution': 'HP-UX', 'ansible_architecture': '9000/785'}) == {'swaptotal_mb': 0, 'memfree_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 0}

# Generated at 2022-06-24 21:58:56.638905
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware_get_cpu_facts = h_p_u_x_hardware.get_cpu_facts()
    assert isinstance(h_p_u_x_hardware_get_cpu_facts, dict)


# Generated at 2022-06-24 21:59:08.956457
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_1 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '', '')
    h_p_u_x_hardware_1.module = MagicMock()
    h_p_u_x_hardware_1.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_1.module

# Generated at 2022-06-24 21:59:20.377840
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_object_0 = HPUXHardware()
    collected_facts = {u'processor': [u'hp9000/785', u'hp9000/800']}
    h_p_u_x_hardware_object_0.get_cpu_facts(collected_facts=collected_facts)
    collected_facts = {u'ansible_architecture': u'9000/800'}
    h_p_u_x_hardware_object_0.get_cpu_facts(collected_facts=collected_facts)
    collected_facts = {u'ansible_architecture': u'9000/785'}
    h_p_u_x_hardware_object_0.get_cpu_facts(collected_facts=collected_facts)
   

# Generated at 2022-06-24 21:59:24.018785
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    assert_equal(h_p_u_x_hardware_0.get_memory_facts(), {'memfree_mb': 0, 'memtotal_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0})


# Generated at 2022-06-24 21:59:25.800898
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector


test_HPUXHardwareCollector()
test_case_0()

# Generated at 2022-06-24 21:59:26.626774
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    test_HPUXHardwareCollector_0 = HPUXHardwareCollector()

# Generated at 2022-06-24 21:59:36.939053
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    rc, out, err = h_p_u_x_hardware_0.module.run_command("model")
    h_p_u_x_hardware_0.facts['ansible_architecture'] = 'ia64'
    h_p_u_x_hardware_0.facts['ansible_distribution_version'] = "B.11.23"
    result = h_p_u_x_hardware_0.get_hw_facts()
    assert isinstance(result, dict)
    assert "model" in result and result["model"] == out.strip()
    assert "firmware_version" in result and re.match(r"^(?!.*Machinfo:)$", result["firmware_version"])

# Generated at 2022-06-24 21:59:42.011075
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {
        "ansible_architecture":'ia64',
        "ansible_distribution_version":'B.11.31'
    }
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)


# Generated at 2022-06-24 21:59:45.341425
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert len(cpu_facts.keys()) == 3



# Generated at 2022-06-24 22:00:00.023030
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    ansible_facts = {'ansible_distribution_version': 'B.11.23', 'ansible_architecture': 'ia64'}
    h_p_u_x_hardware_0 = HPUXHardware(ansible_facts)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:00:03.674828
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    # Arrange and act
    h_p_u_x_hardware = HPUXHardware(bool)
    fact_value = h_p_u_x_hardware.populate()

    # Assert
    assert fact_value == {}

# Generated at 2022-06-24 22:00:08.309732
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:18.554157
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = dict()
    collected_facts_0['ansible_architecture'] = '9000/785'
    cpu_facts_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_0)
    var_0 = cpu_facts_0.get('processor_count')
    try:
        assert (var_0 == 1)
    except AssertionError as e:
        raise (e)


# Generated at 2022-06-24 22:00:20.798501
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:31.456683
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}
    collected_facts_0['ansible_architecture'] = 'ia64'
    collected_facts_0['ansible_distribution_version'] = 'B.11.23'
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)
    assert var_0['firmware_version'] == 'B.11.23'
    assert var_0['model'] == 'ia64 hp server rx2620'


# Generated at 2022-06-24 22:00:35.174132
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:42.081159
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.module.run_command = lambda cmd, **args: (0, "", "")
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert var_0 == {'memfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0}


# Generated at 2022-06-24 22:00:44.357860
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_instance = HPUXHardwareCollector()

# Generated at 2022-06-24 22:00:49.320934
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:01:10.068496
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:01:10.668853
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    pass

# Generated at 2022-06-24 22:01:15.862516
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = True
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)


if __name__ == "__main__":
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:01:23.354085
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = False
    bool_1 = bool(0)
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.populate()
    assert var_0 == {}
    h_p_u_x_hardware_1 = HPUXHardware(bool_1)
    h_p_u_x_hardware_1.get_hw_facts()
    h_p_u_x_hardware_1.get_memory_facts()



# Generated at 2022-06-24 22:01:26.966076
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    h_p_u_x_hardware_0.get_hw_facts(collected_facts)


# Generated at 2022-06-24 22:01:34.013563
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """test_HPUXHardware_get_hw_facts"""
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()

# Generated at 2022-06-24 22:01:35.207106
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    assert False, 'Test not implemented'


# Generated at 2022-06-24 22:01:39.066828
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    hw_facts = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:01:44.960558
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = True
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    var_0 = type(h_p_u_x_hardware_collector_0)
    assert type(var_0) == type
    var_1 = h_p_u_x_hardware_collector_0._fact_class
    assert type(var_1) == HPUXHardware

# Generated at 2022-06-24 22:01:51.313076
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    ansible_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution_version='B.11.31'
    )
    h_p_u_x_hardware_0 = HPUXHardware(ansible_facts)
    var_0 = h_p_u_x_hardware_0.get_hw_facts(ansible_facts)
    assert var_0 == {'firmware_version': 'I64', 'model': 'Integrity Superdome 2 8S'}


# Generated at 2022-06-24 22:02:51.137820
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = True
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    h_p_u_x_hardware_collector_0.collect()

# Generated at 2022-06-24 22:02:57.107114
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    pass
    # Test args: bool
    h_p_u_x_hardware_0 = HPUXHardware()
    # Test args: tuple
    h_p_u_x_hardware_1 = HPUXHardware()
    var_1 = h_p_u_x_hardware_0.populate(tuple())
    # Test args: dict
    h_p_u_x_hardware_2 = HPUXHardware()
    var_2 = h_p_u_x_hardware_0.populate({})
    # Test args: string
    h_p_u_x_hardware_3 = HPUXHardware()
    var_3 = h_p_u_x_hardware_1.populate('')
    # Test args: int
    h_p_u_x_

# Generated at 2022-06-24 22:03:03.113900
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    test_vals = {'ansible_architecture': 'ia64'}
    expected = {'firmware': 'B.11.31',
                'firmware_version': '9.34',
                'model': 'Integrity rx2800 i2',
                'product_serial': '0A5595'}
    result = h_p_u_x_hardware_0.get_hw_facts(test_vals)

    assert result == expected


# Generated at 2022-06-24 22:03:07.347173
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts(None)


if __name__ == "__main__":
    test_case_0()
    test_HPUXHardware_get_memory_facts()

# Generated at 2022-06-24 22:03:12.739261
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = dict()
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts_0)


# Generated at 2022-06-24 22:03:14.244778
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()



# Generated at 2022-06-24 22:03:17.228153
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = dict()
    dict_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_0)


# Generated at 2022-06-24 22:03:18.353393
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert type(HPUXHardwareCollector()) == HPUXHardwareCollector

# Generated at 2022-06-24 22:03:22.696299
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()

# Generated at 2022-06-24 22:03:26.732941
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = False
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}

    # Test with no parameters
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:05:49.553797
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = True
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    assert isinstance(h_p_u_x_hardware_collector_0._fact_class, type) == True
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'

# Generated at 2022-06-24 22:05:54.627058
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    h_p_u_x_hardware_0.get_memory_facts()

test_case_0()
test_HPUXHardware_get_memory_facts()

# Generated at 2022-06-24 22:06:03.935241
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    #
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    #
    rc_0, out_0, err_0 = h_p_u_x_hardware_0.module.run_command('model')
    #
    h_p_u_x_hardware_0.module.run_command.assert_called_once_with('model')
    #
    collected_facts = { 'ansible_architecture': 'ia64' }
    #
    h_p_u_x_hardware_0.get_hw_facts(collected_facts)


# Generated at 2022-06-24 22:06:08.044273
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:06:14.212665
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    result = h_p_u_x_hardware_0.get_memory_facts()
    assert result


# Generated at 2022-06-24 22:06:18.815475
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    bool_0 = True
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert not h_p_u_x_hardware_collector_0._allow_fqdn
    assert h_p_u_x_hardware_collector_0.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-24 22:06:22.050065
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HPUXHardware_0 = HPUXHardware(True)
    HPUXHardware_0.get_hw_facts()


# Generated at 2022-06-24 22:06:27.703853
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}
    collected_facts_0 = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31')
    var_0 = h_p_u_x_hardware_0.get_hw_facts()
    var_1 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts_0)


# Generated at 2022-06-24 22:06:36.233011
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    collected_facts_0 = {}
    bool_1 = True
    h_p_u_x_hardware_0.module = AnsibleModule(
        argument_spec = {
        },
        supports_check_mode = bool_1
    )
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '9', ''))

# Generated at 2022-06-24 22:06:40.448634
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    assert 1 == h_p_u_x_hardware_0.get_hw_facts()
