

# Generated at 2022-06-24 21:58:46.177270
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    print('Testing get_hw_facts of class HPUXHardware')

    h_p_u_x_hardware_instance = HPUXHardware()
    h_p_u_x_hardware_instance.module = AnsibleModule(
        argument_spec = dict()
    )

    collected_facts = {
        'ansible_architecture': str(),
        'ansible_distribution_version': str()
    }
    h_p_u_x_hardware_instance.module.run_command = MagicMock()
    h_p_u_x_hardware_instance.module.run_command.return_value = int(), str(), str()

    h_p_u_x_hardware_instance.get_cpu_facts = MagicMock()

# Generated at 2022-06-24 21:58:47.934405
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(module=None, collected_facts=None)
    h_p_u_x_hardware_0.populate()
    pass


# Generated at 2022-06-24 21:58:49.741428
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    HPUXHardware#get_memory_facts() basic test case
    """
    hpu_xhardware_0 = HPUXHardware({}, {})
    hpu_xhardware_0.get_memory_facts()


# Generated at 2022-06-24 21:58:59.708699
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Create a fact collection
    fact_collection = {}
    # Create an instance of HPUXHardware
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_0.populate_from_facts(fact_collection)
    # Populate the fact collection with platform, distribution and architecture facts.
    # The platform fact is mandatory to check the CPU facts.
    fact_collection["platform"] = "HP-UX"
    fact_collection["distribution"] = "B.11.31"
    fact_collection["architecture"] = "ia64"
    # Check HP-UX CPUs
    h_p_u_x_hardware_0.get_cpu_facts(fact_collection)
   

# Generated at 2022-06-24 21:59:01.739398
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert isinstance(HPUXHardwareCollector(), HPUXHardwareCollector)


# Generated at 2022-06-24 21:59:14.224995
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0_cpu_facts = {
        'processor_count': 0,
        'processor': 'Intel(R) Xeon(R) CPU E5-4640 0 @ 2.40GHz',
        'processor_cores': 0
    }

    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_0.module.run_command.side_effect = [
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', '')
    ]

# Generated at 2022-06-24 21:59:15.520716
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    pass


# Generated at 2022-06-24 21:59:18.330523
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    # Init
    hpu_xhard_ware = HPUXHardware()

    # Test
    hpu_xhard_ware.get_hw_facts()



# Generated at 2022-06-24 21:59:24.827839
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    h_p_u_x_hardware = h_p_u_x_hardware_collector.collect()

    print("[*]  memory:", h_p_u_x_hardware.memory)
    print("[*]  cpu:", h_p_u_x_hardware.cpu)
    print("[*]  system:", h_p_u_x_hardware.system)

if __name__ == "__main__":
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 21:59:35.445161
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # instance of class HPUXHardware
    h_p_u_x_hardware_0 = HPUXHardware()

    # call of method populate
    h_p_u_x_hardware_0.populate()

    # Test the method get_cpu_facts of class HPUXHardware
    #
    # Nothing to test here, it's a simple wrapper
    #
    # Test the method get_memory_facts of class HPUXHardware
    #
    # Nothing to test here, it's a simple wrapper
    #
    # Test the method get_hw_facts of class HPUXHardware
    #
    # Nothing to test here, it's a simple wrapper
    #
    # Test the method populate_sysctl_facts of class HPUXHardware
    #
    # Nothing to test here, it's a simple wrapper
    #

# Generated at 2022-06-24 21:59:52.645937
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    pagesize = 4096
    rc, out, err = run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    data = int(re.sub(' +', ' ', out).split(' ')[5].strip())
    memory_facts = {}
    memory_facts['memfree_mb'] = pagesize * data // 1024 // 1024
    h_p_u_x_hardware_0 = HPUXHardware(0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert var_0['memfree_mb'] == memory_facts['memfree_mb']


# Generated at 2022-06-24 21:59:54.882039
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()


# Generated at 2022-06-24 21:59:58.020991
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector("./ansible_collections/ansible/builtin/plugins/module_utils/network/fortios/facts/__init__.py")


# Generated at 2022-06-24 22:00:05.148252
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    h_p_u_x_hardware_0 = HPUXHardware(collected_facts)
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=collected_facts)



# Generated at 2022-06-24 22:00:08.788370
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._collector_name == 'HPUXHardwareCollector'

# Generated at 2022-06-24 22:00:20.291744
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 5
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.module = MockModule()
    h_p_u_x_hardware_0.module.run_command = MockAnsibleModule()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'ioscan -FkCprocessor | wc -l', '')
    vars_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert vars_0['processor_count'] == 1


# Generated at 2022-06-24 22:00:25.159497
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    # All parameters (collected_facts) required to implement this test are not provided.
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:37.968251
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    result = h_p_u_x_hardware_0.get_memory_facts(collected_facts)
    assert(result['swaptotal_mb'] > 0)
    assert(result['swapfree_mb'] > 0)
    assert(result['memfree_mb'] > 0)
    assert(result['memtotal_mb'] > 0)
    collected_facts = {'ansible_architecture': '9000/800'}
    int_1 = 114
    h_p_u_x_hardware_1 = HPUX

# Generated at 2022-06-24 22:00:45.837960
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts)
    if (var_0 != {}):
        raise Exception("Test case 0 for method HPUXHardware.get_memory_facts failed")


# Generated at 2022-06-24 22:00:49.985895
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)

    h_p_u_x_hardware_0.get_hw_facts()
    assert True


# Generated at 2022-06-24 22:01:12.781444
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.module = mock.Mock()
    str_0 = "model"
    h_p_u_x_hardware_0.module.run_command.return_value = (0, "ia64 hp server rx2660", "")
    str_1 = "ansible_architecture"
    str_2 = "ia64"
    str_3 = "ansible_distribution_version"
    str_4 = "B.11.23"
    mock_collected_facts_0 = {str_1: str_2, str_3: str_4}
    str_5 = "Firmware revision"
    h_p_

# Generated at 2022-06-24 22:01:21.277460
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_1 = 114
    h_p_u_x_hw_collector_0 = HPUXHardwareCollector(int_1)
    assert h_p_u_x_hw_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hw_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hw_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:01:24.301612
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    python_0 = ['ansible_architecture']
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(python_0)
    print(var_0)

# Generated at 2022-06-24 22:01:35.948416
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts_0 = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts_0)

    collected_facts_1 = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    var_1 = h_p_u_x_hardware_0.get_memory_facts(collected_facts_1)


# Generated at 2022-06-24 22:01:40.122259
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = 112
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts=None)


# Generated at 2022-06-24 22:01:40.706176
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    pass

# Generated at 2022-06-24 22:01:49.822174
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    int_0 = 4096
    int_1 = int_0 * 768
    str_0 = "                                                                                                                                                                                            "
    int_2 = int_1 // 1024
    int_3 = int_2 // 1024
    str_1 = "1"
    str_2 = "    768                       "
    str_3 = "   "
    str_4 = str_3 + str_2 + str_1
    str_5 = str_0 + str_4
    int_4 = h_p_u_x_hardware_0.populate()



# Generated at 2022-06-24 22:01:52.396358
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    memory_facts_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:56.980591
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == '__main__':
    test_HPUXHardware()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:02:06.143287
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    int_1 = 51
    h_p_u_x_hardware_1 = HPUXHardware(int_1)
    int_2 = 13
    h_p_u_x_hardware_2 = HPUXHardware(int_2)
    h_p_u_x_hardware_2.get_cpu_facts()
    h_p_u_x_hardware_1.get_cpu_facts()
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:32.574843
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    pass


# Generated at 2022-06-24 22:02:35.584635
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:40.282689
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts_0 = {'ansible_distribution_version': str('B.11.31'), 'ansible_architecture': str('ia64')}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:02:47.589447
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = 7
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.module = MagicMock(return_value=None)
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'SunOS', '')
    var_0 = h_p_u_x_hardware_0.get_hw_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:02:50.663223
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_1 = 114
    h_p_u_x_hardware_1 = HPUXHardware(int_1)
    h_p_u_x_hardware_1.get_hw_facts()


# Generated at 2022-06-24 22:02:55.562474
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.populate()
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:58.623211
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


if __name__ == "__main__":
    for function in dir():
        if function.startswith('test_'):
            eval(function)()

# Generated at 2022-06-24 22:03:04.115243
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts_0 = dict()
    collected_facts_0['ansible_architecture'] = '9000/800'
    collected_facts_0['ansible_distribution_version'] = 'B.11.31'
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:03:07.018278
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    int_0 = 596
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:03:09.400962
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 126
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:03:27.061665
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    # Input data
    collected_facts = {}
    # Invoke method
    result = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)
    assert 0 == 0 # Output data


# Generated at 2022-06-24 22:03:35.108610
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    rc_0, out_0, err_0 = h_p_u_x_hardware_0.module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    data_0 = int(re.sub(' +', ' ', out_0).split(' ')[5].strip())
    var_0 = pagesize * data_0 // 1024 // 1024
    rc_1, out_1, err_1 = h_p_u_x_hardware_0.module.run_command("/usr/contrib/bin/machinfo | grep Memory", use_unsafe_shell=True)

# Generated at 2022-06-24 22:03:39.440158
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:43.938989
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts = dict()
    collected_facts['ansible_architecture'] = '9000/785'
    h_p_u_x_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 22:03:50.118030
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_1 = HPUXHardware(int_0)
    h_p_u_x_hardware_2 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts(h_p_u_x_hardware_1, h_p_u_x_hardware_2)


# Generated at 2022-06-24 22:03:56.136424
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = {'ansible_facts': {'ansible_memory_mb': {'nocache': {'free': 0, 'used': 0}, 'real': {'free': 0, 'used': 0}}, 'ansible_swapfree_mb': 0, 'ansible_swaptotal_mb': 0}}
    var_1 = h_p_u_x_hardware_0.get_memory_facts(var_0)
    assert var_1 == {'swaptotal_mb': 0, 'swapfree_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}

# Generated at 2022-06-24 22:03:58.629143
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_0 = 114
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(int_0)

# Generated at 2022-06-24 22:04:03.677794
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    int_0 = 43
    h_p_u_x_hardware_0 = HPUXHardware(int_0)

    f = open('/etc/machine-info', 'r')
    data = f.readlines()
    data  = [x.strip() for x in data]
    data = [x.split('=') for x in data]
    data = {key:value for (key,value) in data}
    data['ansible_distribution_version'] = "B.11.23"

    var_0 = h_p_u_x_hardware_0.get_hw_facts(data)



# Generated at 2022-06-24 22:04:13.088279
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)

    # Test for the architecture 9000/800
    collected_facts_0 = {'ansible_architecture' : '9000/800'}
    cpu_facts_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_0)
    assert cpu_facts_0['processor_count'] == 4
    # Test for the architecture 9000/785
    collected_facts_1 = {'ansible_architecture' : '9000/785'}
    cpu_facts_1 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_1)
    assert cpu_facts

# Generated at 2022-06-24 22:04:16.400594
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    collected_facts_0 = {'ansible_architecture': '9000/800'}
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts_0)


# Generated at 2022-06-24 22:04:55.545905
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collected_facts = set()
    in_0 = HPUXHardwareCollector(collected_facts)
    assert isinstance(in_0, HPUXHardwareCollector)


# Generated at 2022-06-24 22:05:02.756928
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_0 = 2
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(int_0)
    var_0 = h_p_u_x_hardware_collector_0.collect()
    var_1 = h_p_u_x_hardware_collector_0.required_facts
    var_2 = h_p_u_x_hardware_collector_0._platform

# Generated at 2022-06-24 22:05:06.259385
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(0)
    var_0 = h_p_u_x_hardware_collector_0.collect()

# Generated at 2022-06-24 22:05:13.484871
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    d = {}
    d['ansible_architecture'] = 'ia64'
    d['ansible_distribution_version'] = 'B.11.31'
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts=d)


# Generated at 2022-06-24 22:05:18.457889
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_1 = HPUXHardware(114)
    var_0 = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    var_1 = h_p_u_x_hardware_1.get_memory_facts(var_0)


# Generated at 2022-06-24 22:05:25.475485
# Unit test for method get_memory_facts of class HPUXHardware

# Generated at 2022-06-24 22:05:28.906049
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    a_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:05:34.123441
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    int_0 = 15
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    dict_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert not dict_0


# Generated at 2022-06-24 22:05:44.547054
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    my_dict_0 = {}
    my_dict_0['architecture'] = 'ia64'
    my_dict_0['distribution'] = 'HP-UX'
    my_dict_0['distribution_version'] = 'B.11.31'
    var_0 = h_p_u_x_hardware_0.populate(collected_facts=my_dict_0)
    assert var_0['processor_cores'] == 32
    assert var_0['swaptotal_mb'] == 512
    assert var_0['processor_count'] == 1


# Generated at 2022-06-24 22:05:48.802066
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(114)
    int_0 = 114
    h_p_u_x_hardware_0.get_hw_facts(int_0)


# Generated at 2022-06-24 22:07:10.386697
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    int_0 = 114
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(int_0)
    var_0 = h_p_u_x_hardware_collector_0.collect()

# Test for negative test case for function populate

# Generated at 2022-06-24 22:07:14.939952
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:07:17.595675
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:07:24.734701
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    arg_0 = 140
    h_p_u_x_hardware_0 = HPUXHardware(arg_0)
    h_p_u_x_hardware_0.module = MagicMock(return_value=six.StringIO("Memory = 2048 MB\n"))
    h_p_u_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:07:26.225652
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector._platform == 'HP-UX'

# Generated at 2022-06-24 22:07:31.138023
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Input parameters tests
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    # set up the mocks
    var_1 = [0, '', '']
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=var_1)
    # invoke the method
    var_2 = h_p_u_x_hardware_0.get_hw_facts()
    # assertions
    assert var_2 == {}
    # cleanup
    # no need to cleanup


# Generated at 2022-06-24 22:07:32.384087
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var = HPUXHardware(None)
    var.get_memory_facts()


# Generated at 2022-06-24 22:07:37.335738
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:07:42.078802
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 114
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:07:49.601638
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    int_0 = 10
    h_p_u_x_hardware_0 = HPUXHardware(int_0)
    dict_0 = dict()
    dict_0['ansible_architecture'] = '9000/800'
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(dict_0)
    dict_1 = dict()
    dict_1['ansible_architecture'] = '9000/785'
    var_1 = h_p_u_x_hardware_0.get_cpu_facts(dict_1)
    dict_2 = dict()
    dict_2['ansible_architecture'] = 'ia64'
    dict_2['ansible_distribution_version'] = 'B.11.23'
    var_2 = h