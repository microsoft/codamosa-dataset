

# Generated at 2022-06-24 21:58:56.478494
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '', '')
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '', '')
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '', '')
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '', '')

# Generated at 2022-06-24 21:59:08.789216
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()


# Generated at 2022-06-24 21:59:20.243997
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=mocked_module_0)
    mocked_module_0.ansible_facts = {'ansible_architecture': '9000/800'}
    mocked_run_command_0 = ({'stdout': '4', 'rc': 0, 'stderr': ''})
    mocked_module_0.run_command = lambda *args, **kwargs: mocked_run_command_0
    assert h_p_u_x_hardware_0.get_cpu_facts() == {'processor_count': 4}
    mocked_run_command_0 = ({'stdout': '4', 'rc': 0, 'stderr': ''})
    mocked_module_0.run_command = lambda *args, **kwargs: mocked_run_

# Generated at 2022-06-24 21:59:31.114097
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_data = {
        "ansible_distribution": "HP-UX",
        "ansible_distribution_version": "B.11.31",
        "ansible_architecture": "ia64"
    }
    h_p_u_x_hardware_0 = HPUXHardware(module=None, facts={})
    h_p_u_x_hardware_1 = HPUXHardware(module=None, facts={})

    h_p_u_x_hardware_1.populate(collected_facts=test_data)
    rc, out, err = h_p_u_x_hardware_0.module.run_command("/usr/contrib/bin/machinfo | grep Memory", use_unsafe_shell=True)

# Generated at 2022-06-24 21:59:34.372087
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware({})
    _ = h_p_u_x_hardware.get_hw_facts()


# Generated at 2022-06-24 21:59:43.135402
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_case_0()
    h_p_u_x_hardware_1 = HPUXHardware()
    h_p_u_x_hardware_1.collected_facts = {'ansible_architecture': '9000/800'}
    h_p_u_x_hardware_1.get_cpu_facts()
    h_p_u_x_hardware_1.collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    h_p_u_x_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 21:59:46.304633
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 21:59:48.086210
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    obj = HPUXHardware()
    obj.get_memory_facts()


# Generated at 2022-06-24 21:59:55.891759
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    fixture_facts = {
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
        'ansible_architecture': 'ia64',
        'ansible_kernel': 'HP-UX',
    }

# Generated at 2022-06-24 21:59:59.503500
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:00:20.286857
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    model="B.11.31.1611"
    distribution="HPUX"
    distribution_version="B.11.31"
    architecture="ia64"
    platform="HP-UX"
    h_p_u_x_hardware_0 = HPUXHardware({'distribution': distribution, 'architecture': architecture, 'platform': platform, 'distribution_version': distribution_version, 'model': model})
    collected_facts = {}
    collected_facts['distribution'] = distribution
    collected_facts['architecture'] = architecture
    collected_facts['platform'] = platform
    collected_facts['distribution_version'] = distribution_version


# Generated at 2022-06-24 22:00:24.027730
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_1._platform == 'HP-UX'


# Generated at 2022-06-24 22:00:32.783656
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])
test_case_0()
test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:00:42.496184
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock(name="module")
    h_p_u_x_hardware_0.module.run_command = MagicMock(name="run_command")

# Generated at 2022-06-24 22:00:46.325620
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=AnsibleModule(argument_spec={}))
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:00:52.033954
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_1 = HPUXHardware()
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    result = {}
    result['processor_count'] = 10
    assert h_p_u_x_hardware_1.get_cpu_facts(collected_facts) == result


# Generated at 2022-06-24 22:01:02.462842
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector._platform is 'HP-UX', 'Expected value HP-UX but got ' + HPUXHardwareCollector._platform
    assert HPUXHardwareCollector._fact_class is HPUXHardware, 'Expected value HPUXHardware but got ' + HPUXHardwareCollector._fact_class.__name__

# Generated at 2022-06-24 22:01:05.080362
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:01:08.882579
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'



# Generated at 2022-06-24 22:01:11.193786
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.get_hw_facts()


# Generated at 2022-06-24 22:01:22.371477
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()

# Generated at 2022-06-24 22:01:24.306154
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(-3079.617)
    h_p_u_x_hardware_0.populate()

# Generated at 2022-06-24 22:01:25.202469
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    HPUXHardware(0)


# Generated at 2022-06-24 22:01:28.521677
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:01:36.927862
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(None)
    var_1 = h_p_u_x_hardware_0.populate([])
    var_2 = h_p_u_x_hardware_0.get_cpu_facts()
    var_3 = h_p_u_x_hardware_0.get_hw_facts()
    var_4 = h_p_u_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:01:42.651494
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    if type(h_p_u_x_hardware_collector_0) == type(None):
        raise Exception('Unexpected None class while testing HPUXHardwareCollector constructor')


if __name__ == '__main__':
    test_case_0()
    # test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:01:43.278236
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    pass

# Generated at 2022-06-24 22:01:52.452604
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -6877.36753
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.module = Mock()
    h_p_u_x_hardware_0.module.run_command.return_value = (1, 'str_0', 'str_1')
    collected_facts_0 = dict()
    collected_facts_0['ansible_architecture'] = 'ia64'
    collected_facts_0['ansible_distribution_version'] = 'B.11.23'
    h_p_u_x_hardware_0.collected_facts = collected_facts_0
    var_0 = h_p_u_x_hardware_0.get_hw_facts()

# Generated at 2022-06-24 22:01:57.043697
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:02:01.482795
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    try:
        h_p_u_x_hardware_0.get_memory_facts()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 22:02:21.119885
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    #Create an instance of class HPUXHardware
    h_p_u_x_hardware_0 = HPUXHardware(1)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:21.741403
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_case_0()


# Generated at 2022-06-24 22:02:31.881539
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = 179.0
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)
    float_1 = -27.1516
    h_p_u_x_hardware_collector_0.required_facts = set(['platform', 'distribution'])
    h_p_u_x_hardware_collector_0.platform = 'HP-UX'
    h_p_u_x_hardware_collector_0.fact_class = HPUXHardware
    h_p_u_x_hardware_collector_0.fact_class(float_1).get_cpu_facts()


# Generated at 2022-06-24 22:02:35.297502
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:38.768671
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -2499.4587
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    result = h_p_u_x_hardware_0.get_hw_facts()
    assert result == {}
    assert type(result) is dict


# Generated at 2022-06-24 22:02:41.957710
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    print("var_0 = HPUXHardwareCollector()")
    var_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:02:45.842374
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    str_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:50.402239
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Init an object of HPUXHardware class
    float_0 = -0.49082
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    # Get hw facts from the object
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:54.439508
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -9786.8652
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:59.759753
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()
    assert h_p_u_x_hardware_0.get_hw_facts() == {'model': '', 'firmware_version': '', 'product_serial': ''}


# Generated at 2022-06-24 22:03:39.140144
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == '__main__':
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:03:47.820839
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    ansible_architecture = '9000/800'
    ansible_distribution = 'HP-UX'
    ansible_distribution_release = 'B.11.31'
    ansible_distribution_version = 'B.11.31'
    ansible_memtotal_mb = 38959
    ansible_os_family = 'HP-UX'
    ansible_platform = 'HP-UX'
    ansible_system = 'IA64'

    float_0 = -18983.507

# Generated at 2022-06-24 22:03:49.422841
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:53.251761
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    # Declaration of the HPUXHardware class
    float_0 = -3079.617

    # Call to HPUXHardware init
    h_p_u_x_hardware_0 = HPUXHardware(float_0)

    # Call to get_hw_facts
    h_p_u_x_hardware_0.get_hw_facts()



# Generated at 2022-06-24 22:03:58.030758
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()

# Generated at 2022-06-24 22:04:01.092645
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = 0.3
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:04:09.063372
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert isinstance(var_0, dict)
    assert isinstance(var_0['memfree_mb'], int)
    assert isinstance(var_0['swapfree_mb'], int)
    assert isinstance(var_0['memtotal_mb'], int)
    assert isinstance(var_0['swaptotal_mb'], int)


# Generated at 2022-06-24 22:04:12.420571
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    float_0 = -3079.617
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(float_0)

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:16.345885
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Check for required facts
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    var_1 = h_p_u_x_hardware_collector_0.required_facts
    print(var_0)
    print(var_1)


if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:22.850861
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    # Testing with ansible_architecture = x86_64
    ansible_architecture_0 = 'x86_64'
    setattr(h_p_u_x_hardware_0.module, 'ansible_architecture', ansible_architecture_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()
    # Testing with ansible_architecture = ia64
    ansible_architecture_1 = 'ia64'
    setattr(h_p_u_x_hardware_0.module, 'ansible_architecture', ansible_architecture_1)
    #

# Generated at 2022-06-24 22:05:43.538459
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:47.038888
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_2 = dict()
    h_p_u_x_hardware_0.populate(var_2)


# Generated at 2022-06-24 22:05:50.827367
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -2826.212
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:05:56.418735
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.get_hw_facts(('model', 'firmware_version'))


# Generated at 2022-06-24 22:05:59.534811
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    float_0 = 1.24923
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:06:03.647499
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_0 = -1.179
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:06:05.454095
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    float_1 = -1068.66
    h_p_u_x_hardware_1 = HPUXHardware(float_1)
    h_p_u_x_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:06:08.290134
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:06:14.559025
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    bool_0 = h_p_u_x_hardware_0.get_cpu_facts()
    assert bool_0


# Generated at 2022-06-24 22:06:19.134934
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    float_0 = -3079.617
    h_p_u_x_hardware_0 = HPUXHardware(float_0)
    var_0 = h_p_u_x_hardware_0.populate()
