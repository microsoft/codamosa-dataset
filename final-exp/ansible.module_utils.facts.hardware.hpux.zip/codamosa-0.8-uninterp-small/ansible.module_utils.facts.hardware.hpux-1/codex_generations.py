

# Generated at 2022-06-24 21:58:48.513746
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'

# Generated at 2022-06-24 21:58:58.853569
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    result = HPUXHardware.get_cpu_facts(HPUXHardware(), {'ansible_architecture': '9000/800'})
    assert result == {'processor_count': 16}
    result = HPUXHardware.get_cpu_facts(HPUXHardware(), {'ansible_architecture': '9000/785'})
    assert result == {'processor_count': 16}
    result = HPUXHardware.get_cpu_facts(HPUXHardware(), {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert result == {'processor': 'Intel Itanium Family 1, Stepping 6', 'processor_count': 16, 'processor_cores': 4}

# Generated at 2022-06-24 21:59:05.537880
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 21:59:17.448914
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test = HPUXHardware({}, {})
    # Set function as static
    test.get_memory_facts = staticmethod(test.get_memory_facts)
    result = test.get_memory_facts()
    assert result is not None
    assert isinstance(result, dict)
    assert 'memfree_mb' in result
    assert isinstance(result['memfree_mb'], int)
    assert 'memtotal_mb' in result
    assert isinstance(result['memtotal_mb'], int)
    assert 'swapfree_mb' in result
    assert isinstance(result['swapfree_mb'], int)
    assert 'swaptotal_mb' in result
    assert isinstance(result['swaptotal_mb'], int)


# Generated at 2022-06-24 21:59:24.494269
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    mem = h_p_u_x_hardware_0.get_memory_facts()
    assert mem['memtotal_mb'] > 0
    assert mem['memfree_mb'] > 0
    assert mem['swaptotal_mb'] > 0
    assert mem['swapfree_mb'] > 0


# Generated at 2022-06-24 21:59:26.424883
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 21:59:31.143301
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    if isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector):
        print("test_HPUXHardwareCollector: PASS")
    else:
        print("test_HPUXHardwareCollector: FAIL")


# Generated at 2022-06-24 21:59:34.421360
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:59:42.533843
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Here is the place to put test data
    HPUXHardware_get_memory_facts_testdata = {'ansible_architecture': '9000/800',
                                              'ansible_distribution_version': 'B.11.31'}
    h_p_u_x_hardware_get_memory_facts_0 = HPUXHardware(HPUXHardware_get_memory_facts_testdata)
    h_p_u_x_hardware_get_memory_facts_res_0 = h_p_u_x_hardware_get_memory_facts_0.get_memory_facts()
    assert h_p_u_x_hardware_get_memory_facts_res_0 == {}


# Generated at 2022-06-24 21:59:46.168300
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware({})
    assert h_p_u_x_hardware_0.get_cpu_facts() == {}


# Generated at 2022-06-24 21:59:58.244453
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    pass


# Generated at 2022-06-24 22:00:06.174663
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_0 = HPUXHardware()

    hardware_0.module.run_command = MagicMock(
        return_value=(0, "Physical: 4194304 Kbytes\n", ""))
    hardware_0.module.run_command.assert_called_with(
        "grep Physical /var/adm/syslog/syslog.log",
    )
    assert hardware_0.get_memory_facts() == {
        'memfree_mb': 8800,
        'memtotal_mb': 4096,
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
        }

# Generated at 2022-06-24 22:00:10.677668
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_1._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector_1._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_1.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-24 22:00:14.500338
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module.run_command = MagicMock(return_value=(0, '', ''))
    hardware.get_memory_facts()


# Generated at 2022-06-24 22:00:21.264349
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    test_module_0 = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    test_module_0.check_mode = False
    test_module_0.params = dict()
    test_module_0.run_command = MagicMock(side_effect=[(0, "11\n", ""), (0, "525288", ""), (0, "11\n", ""), (0, "525288", ""), (0, "11\n", ""), (0, "525288", "")])
    test_module_0.module = MagicMock()
    test_module_0.run_command.return_value = (0, "11\n", "")
    test_module

# Generated at 2022-06-24 22:00:31.117908
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    h_p_u_x_hardware_0 = HPUXHardware(collected_facts=collected_facts)
    if h_p_u_x_hardware_0.get_memory_facts() == {'swaptotal_mb': 128, 'memfree_mb': 23, 'memtotal_mb': 3959, 'swapfree_mb': 128}:
        h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:00:37.819021
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_collector_0 = HPUXHardwareCollector()
    h_p_u_x_hardware_0 = hardware_collector_0.fetch_all()
    assert isinstance(h_p_u_x_hardware_0, dict)
    assert 'processor_count' in h_p_u_x_hardware_0
    assert 'processor' in h_p_u_x_hardware_0


# Generated at 2022-06-24 22:00:40.699082
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    # Test with actual data
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:00:51.898225
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_obj = HPUXHardware()
    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': '9000/800',
    }

    test_obj.module.run_command = lambda x, use_unsafe_shell=False: (0,
                                                                     '  4096\n',
                                                                     '')
    re_sub = re.sub
    re_sub.side_effect = lambda *args, **kwargs: re_sub(*args, **kwargs)
    re_sub.side_effect = lambda x, y, z: '  4096\n'
    int_ = int
    int_.side_effect = lambda x: int(x)
    int_.side_effect = lambda x: 4096

# Generated at 2022-06-24 22:00:59.316665
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    inventory_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    hpu = HPUXHardware()
    facts = hpu.get_hw_facts(inventory_facts)
    assert facts.get('model') == 'ia64 hp server rx6600'


# Generated at 2022-06-24 22:01:10.489681
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_2 = HPUXHardware({})
    var_3 = {}
    var_4 = var_2.get_cpu_facts(var_3)


# Generated at 2022-06-24 22:01:18.290704
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = {}
    var_1['ansible_architecture'] = 'ia64'
    var_1['ansible_distribution_version'] = 'B.11.31'
    var_2 = h_p_u_x_hardware_0.get_memory_facts(var_1)


# Generated at 2022-06-24 22:01:24.632420
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_2 = {}
    var_2['ansible_architecture'] = "9000/800"
    var_1 = h_p_u_x_hardware_0.get_memory_facts(var_2)
    assert var_1 == {'swaptotal_mb': 0, 'memfree_mb': 225184, 'memtotal_mb': 524288, 'swapfree_mb': 0}


# Generated at 2022-06-24 22:01:27.915471
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = h_p_u_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:01:33.183881
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = h_p_u_x_hardware_0.populate()
    var_1 = h_p_u_x_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:01:44.416142
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    collected_facts = {}
    collected_facts['platform'] = 'HP-UX'
    collected_facts['distribution'] = 'HP-UX'
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_os_family'] = 'HP-UX'
    collected_facts['ansible_distribution_version'] = "B.11.31"
    collected_facts['ansible_distribution_release'] = "B.11.31"
    collected_facts['ansible_distribution_major_version'] = "B"
    collected_facts['ansible_distribution'] = "HP-UX"
    var_5 = h_p_u_x_

# Generated at 2022-06-24 22:01:49.428695
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    var_1 = {}
    h_p_u_x_hardware_1 = HPUXHardware(var_1)
    var_1 = None
    h_p_u_x_hardware_2 = HPUXHardware(var_1)
    var_2 = h_p_u_x_hardware_2.get_memory_facts(collected_facts=None)


# Generated at 2022-06-24 22:01:53.265530
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collected_facts = {'platform': 'HP-UX', 'distribution': 'HP-UX'}
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(collected_facts)
    var_2 = h_p_u_x_hardware_collector_0.collect()
    var_2.populate()

# Generated at 2022-06-24 22:01:58.316153
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    # Test for function call get_hw_facts()
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:01.829029
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware({})
    var_1 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:17.607099
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    var_5 = HPUXHardwareCollector()

if __name__ == '__main__':
    import sys
    import pytest
    libpath = os.path.dirname(__file__)
    sys.path.append(libpath)
    from test_utils import list_test_cases
    testcases = list_test_cases(__name__)
    result = pytest.main(testcases)
    sys.exit(result)

# Generated at 2022-06-24 22:02:19.732879
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_2 = {}
    h_p_u_x_hardware_1 = HPUXHardware(var_2)
    var_3 = h_p_u_x_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:02:20.170551
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    assert 0 == 0

# Generated at 2022-06-24 22:02:23.376972
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_2 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_2)
    var_3 = {}
    var_3['ansible_architecture'] = 'ia64'
    var_3['ansible_distribution_version'] = 'B.11.31'
    var_4 = h_p_u_x_hardware_0.get_hw_facts(var_3)


# Generated at 2022-06-24 22:02:25.944600
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_2 = {}
    h_p_u_x_hardware_1 = HPUXHardware(var_2)
    var_3 = {}
    var_3['ansible_architecture'] = '9000/800'
    return_val_0 = h_p_u_x_hardware_1.get_memory_facts(collected_facts=var_3)

# Generated at 2022-06-24 22:02:27.453882
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)

    assert h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:33.763415
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0.platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])
    assert h_p_u_x_hardware_collector_0.fact_class == HPUXHardware

# Generated at 2022-06-24 22:02:35.492237
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    if var_1 is not None:
        var_1.get_cpu_facts()
        var_1.get_memory_facts()
        var_1.get_hw_facts()
    assert var_1 is not None

# Generated at 2022-06-24 22:02:41.213581
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    h_p_u_x_hardware_0.module.run_command.return_value = (0, '1', '')
    collected_facts = {'ansible_architecture': '9000/785'}
    var_2 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)

    assert var_2.get('processor_count') == 1


# Generated at 2022-06-24 22:02:42.696385
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    var_10 = {}
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(var_10)


# Generated at 2022-06-24 22:02:56.893317
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    var_2 = {}
    h_p_u_x_hardware_1 = HPUXHardware(var_2)
    # populate method call
    assert True == h_p_u_x_hardware_1.populate()


# Generated at 2022-06-24 22:02:59.879656
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:03:02.809847
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:03:07.954182
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    expected_hardware_platform = 'HP-UX'
    expected_fact_class = HPUXHardware

    test_hardware_collector = HPUXHardwareCollector()

    assert test_hardware_collector.hardware_platform() == expected_hardware_platform
    assert test_hardware_collector.fact_class() == expected_fact_class
    assert test_hardware_collector.required_facts() == HPUXHardwareCollector.required_facts

# Generated at 2022-06-24 22:03:14.104977
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    var_0 = {}
    var_1 = {}
    var_1['ansible_architecture'] = 'ia64'
    var_1['ansible_distribution_version'] = 'B.11.31'
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_2 = h_p_u_x_hardware_0.populate(var_1)

# Generated at 2022-06-24 22:03:17.113886
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_8 = {}
    h_p_u_x_hardware_8 = HPUXHardware(var_8)
    var_9 = h_p_u_x_hardware_8.populate()
    var_10 = h_p_u_x_hardware_8.get_cpu_facts(var_9)


# Generated at 2022-06-24 22:03:28.494681
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Test for cases where distribution is not equal to None
    # Test for cases where distribution version is equal to 'B.11.31'
    var_2 = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    h_p_u_x_hardware_1 = HPUXHardware(var_2)
    var_3 = {}
    h_p_u_x_hardware_1.get_cpu_facts(var_3)
    # Test for cases where distribution version is equal to 'B.11.23'
    var_4 = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

# Generated at 2022-06-24 22:03:35.161458
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = {}
    var_2 = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23',
    }
    var_3 = h_p_u_x_hardware_0.get_hw_facts(var_2)
    assert var_3 == var_1


# Generated at 2022-06-24 22:03:42.531699
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    var_h_p_u_x_hardware_collector = HPUXHardwareCollector()
    var_h_p_u_x_hardware_collector.collect()
    var_h_p_u_x_hardware_collector.populate_facts()

if __name__ == '__main__':
    # unit tests for HPUXHardwareCollector:
    # test_case_0()
    # test_HPUXHardwareCollector()
    pass

# Generated at 2022-06-24 22:03:45.231850
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:01.805300
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = None
    h_p_u_x_hardware_0.populate(var_1)

# Generated at 2022-06-24 22:04:03.247052
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    var_2 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:04:10.843192
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    var_0 = {'ansible_distribution': 'HP-UX', 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(var_0)
    var_1 = h_p_u_x_hardware_collector_0.collect()
    assert var_1 is not None
    del h_p_u_x_hardware_collector_0


# Generated at 2022-06-24 22:04:16.509638
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    try:
        var_1 = {}
        h_p_u_x_hardware_0 = HPUXHardware(var_1)
        var_2 = h_p_u_x_hardware_0.get_hw_facts()
    except:
        var_3 = {}
    finally:
        var_4 = {}
        h_p_u_x_hardware_1 = HPUXHardware(var_4)
        h_p_u_x_hardware_1.module = None
        var_5 = h_p_u_x_hardware_1.get_hw_facts()


# Generated at 2022-06-24 22:04:17.381037
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    obj = HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:22.609975
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware({})
    var_2 = HPUXHardwareCollector._fact_class({})
    var_2.populate()
    var_2.get_cpu_facts()
    h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:04:24.612977
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    var_2 = HPUXHardwareCollector()

# Generated at 2022-06-24 22:04:29.484646
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    h_p_u_x_hardware_0.populate()
    var_1 = None
    var_2 = h_p_u_x_hardware_0.get_hw_facts(var_1)


# Generated at 2022-06-24 22:04:31.181507
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:04:38.115286
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_3 = {}
    h_p_u_x_hardware_1 = HPUXHardware(var_3)
    var_3 = {}
    var_2 = h_p_u_x_hardware_1.get_cpu_facts(var_3)
    assert isinstance(var_2, dict)
    assert 'processor' not in var_2
    assert 'processor_cores' not in var_2
    assert 'processor_count' not in var_2


# Generated at 2022-06-24 22:05:18.943954
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = {"ansible_facts": {"ansible_distribution_version": "B.11.31", "ansible_architecture": "ia64"}}
    var_2 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=var_1)


# Generated at 2022-06-24 22:05:25.758359
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    var_1 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)
    assert var_1 == {
        'processor': 'Itanium 2',
        'processor_count': 8,
        'processor_cores': 8
    }

    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    var_1 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)

# Generated at 2022-06-24 22:05:33.810518
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = h_p_u_x_hardware_0.get_cpu_facts()
    assert var_1 and True or False, "Expected (True) and got (False)"
    var_2 = h_p_u_x_hardware_0.get_cpu_facts()
    var_3 = {'processor_count': 2, 'processor': 'Intel(R) Itanium(R) 9000 processor series', 'processor_cores': 1}

# Generated at 2022-06-24 22:05:41.627679
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_13 = HPUXHardware({})
    var_14 = {'ansible_architecture': '9000/800'}
    var_15 = var_13.get_cpu_facts(var_14)

    assert var_15['processor_count'] == 0

    var_16 = HPUXHardware({})
    var_17 = {'ansible_architecture': 'ia64'}
    var_18 = var_16.get_cpu_facts(var_17)


# Generated at 2022-06-24 22:05:47.726615
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = h_p_u_x_hardware_0.populate()
    var_2 = h_p_u_x_hardware_0.get_cpu_facts(var_1)
    var_3 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:48.912472
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:05:53.966497
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_2 = {}
    h_p_u_x_hardware_1 = HPUXHardware(var_2)
    var_3 = h_p_u_x_hardware_1.get_memory_facts()
    print("Memory: %s " % var_3)


# Generated at 2022-06-24 22:05:59.122357
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    var_0 = {u'ansible_architecture': u'9000/785'}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = {}
    var_2 = h_p_u_x_hardware_0.get_cpu_facts(var_1)


# Generated at 2022-06-24 22:06:05.449311
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    try:
        var_0 = {}
        h_p_u_x_hardware = HPUXHardware(var_0)
        # Call method get_memory_facts of class HPUXHardware
        var_1 = h_p_u_x_hardware.get_memory_facts()
    except Exception as e:
        print(e.message)


# Generated at 2022-06-24 22:06:10.651711
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_1 = {}
    var_2 = {}
    var_2['ansible_architecture'] = 'ia64'
    var_2['ansible_distribution_version'] = 'B.11.31'
    h_p_u_x_hardware_1 = HPUXHardware(var_1)
    var_3 = h_p_u_x_hardware_1.get_memory_facts(var_2)


# Generated at 2022-06-24 22:06:48.508801
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    var_2 = {}
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(var_2)

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:06:55.619937
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_6 = "b.11.31"
    var_7 = "ia64"
    var_5 = {'ansible_architecture': var_7, 'ansible_distribution_version': var_6, 'platform': 'HP-UX', 'ansible_os_family': 'HP-UX'}
    h_p_u_x_hardware_1 = HPUXHardware(var_5)
    h_p_u_x_hardware_1.get_hw_facts()


# Generated at 2022-06-24 22:06:59.182302
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_2 = {}
    h_p_u_x_hardware_1 = HPUXHardware(var_2)
    var_3 = h_p_u_x_hardware_1.get_hw_facts()


# Generated at 2022-06-24 22:07:05.474373
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_3 = {}
    h_p_u_x_hardware_1 = HPUXHardware(var_3)
    var_4 = {}
    var_4 = h_p_u_x_hardware_1.get_memory_facts()
    assert var_4 == {'swapfree_mb': 0, 'memfree_mb': 864, 'memtotal_mb': 7680, 'swaptotal_mb': 0}



# Generated at 2022-06-24 22:07:09.786160
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_2 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_2)
    var_3 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:07:16.823664
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = h_p_u_x_hardware_0.get_memory_facts()
    assert var_1 == {'memfree_mb': 'unknown', 'swapfree_mb': 'unknown', 'swaptotal_mb': 'unknown', 'memtotal_mb': 'unknown'}


# Generated at 2022-06-24 22:07:24.476356
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {"ansible_architecture": "ia64", "ansible_distribution_version": "B.11.23"}
    var_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = h_p_u_x_hardware_0.get_hw_facts(collected_facts)


# Generated at 2022-06-24 22:07:26.305174
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    assert test_case_0() == None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:07:32.366653
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    var_0 = {}
    var_1 = {}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts(var_1)


# Generated at 2022-06-24 22:07:35.262057
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    var_0 = {'ansible_architecture': 'ia64'}
    h_p_u_x_hardware_0 = HPUXHardware(var_0)
    var_1 = h_p_u_x_hardware_0.populate()
