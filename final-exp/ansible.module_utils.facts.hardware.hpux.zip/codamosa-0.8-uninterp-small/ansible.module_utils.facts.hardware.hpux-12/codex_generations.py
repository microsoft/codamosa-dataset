

# Generated at 2022-06-24 21:58:41.768666
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    try:
        assert True == True
    except:
        print("Test case skiped - get_cpu_facts method is not implemented.")


# Generated at 2022-06-24 21:58:48.014584
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    cpu_hpu_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

    h_p_u_x_hardware_0 = HPUXHardware(cpu_hpu_facts)
    hpu_facts = h_p_u_x_hardware_0.populate()
    assert hpu_facts['processor_cores'] == 16
    assert hpu_facts['processor_count'] == 4
    assert hpu_facts['processor'] == 'Intel(R) Itanium 2 Processor 9000 series'
    assert hpu_facts['memtotal_mb'] == 67108864
    assert hpu_facts['swaptotal_mb'] == 78732
    assert hpu_facts['swapfree_mb'] == 78732
    assert hpu

# Generated at 2022-06-24 21:58:49.265043
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    test_case_0()

# Generated at 2022-06-24 21:58:58.107462
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    h_p_u_x_hardware_0 = HPUXHardware(collected_facts)
    assert h_p_u_x_hardware_0.get_memory_facts(collected_facts) == {'memfree_mb': 103500, 'memtotal_mb': 103500, 'swapfree_mb': 0, 'swaptotal_mb': 0}


# Generated at 2022-06-24 21:59:02.356265
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 21:59:03.993361
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUXHardware(False, False)


# Generated at 2022-06-24 21:59:12.610105
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    bool_0 = True
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(bool_0)
    h_p_u_x_hardware_0 = HPUXHardware(h_p_u_x_hardware_collector_0)

    data = h_p_u_x_hardware_0.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert data['processor_count'] == 2


# Generated at 2022-06-24 21:59:23.021904
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    m_le_v_memory_facts_0 = {}
    m_le_v_hw_facts_0 = {}
    m_le_v_cpu_facts_0 = {}
    c_l_l_collected_facts_0 = {}
    c_l_l_collected_facts_1 = {}
    c_l_l_collected_facts_0['ansible_distribution_version'] = 'B.11.23'
    c_l_l_collected_facts_0['ansible_architecture'] = 'ia64'
    c_l_l_collected_facts_1['ansible_architecture'] = '9000/800'


# Generated at 2022-06-24 21:59:26.141943
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware(None, "kraken")
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 21:59:32.033376
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Unit test for method get_memory_facts of class HPUXHardware
    bool_0 = True
    h_p_u_x_hardware_0 = HPUXHardware(bool_0)
    # stdout from swapinfo -m -d -f -q
    int_0 = 10
    h_p_u_x_hardware_0.module.run_command = mock_ansible_module_run_command1
    dict_0 = h_p_u_x_hardware_0.get_memory_facts()
    assert dict_0 == {'memtotal_mb': int_0, 'memfree_mb': int_0, 'swaptotal_mb': int_0, 'swapfree_mb': int_0}


# Generated at 2022-06-24 21:59:46.215424
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '\x1eZ|\x13\x1e\x1fK\x10AD\x1e|\x02'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    dict_0 = {'cpu_sockets': '\x00' * 104}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(dict_0)


# Generated at 2022-06-24 21:59:51.822450
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '%%\\x0b=\x15\x06\x0c\x0b\x1d'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    var_0 = h_p_u_x_hardware_collector_0._fact_class()
    var_1 = h_p_u_x_hardware_collector_0._platform


# Generated at 2022-06-24 21:59:57.383222
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '\x04!\x06'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    var_0 = h_p_u_x_hardware_collector_0._fact_class


# Generated at 2022-06-24 22:00:03.464570
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    # Unit test setup
    str_0 = '-\x0b'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)

    # Invoke method
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()

    # Unit test teardown
    pass


# Generated at 2022-06-24 22:00:05.246499
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '\x1f'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:09.199303
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = '|\x03&,{+$'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:00:15.140949
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    assert isinstance(h_p_u_x_hardware_collector_0, HPUXHardwareCollector)


# Generated at 2022-06-24 22:00:18.965521
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_1 = 'HPUXHardware'
    h_p_u_x_hardware_1 = HPUXHardware(str_1)
    h_p_u_x_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:00:24.126073
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_1 = '//*\x0c?+\x0c'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_1)
    assert str(h_p_u_x_hardware_collector_0.platform) == "//*\x0c?+\x0c"


# Generated at 2022-06-24 22:00:29.298923
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:00:50.654533
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '&?\\\x0c+ff'
    set_0 = {'ansible_architecture', 'ansible_distribution_version'}
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    str_1 = h_p_u_x_hardware_collector_0.platform
    var_0 = h_p_u_x_hardware_collector_0.required_facts
    str_2 = h_p_u_x_hardware_collector_0.fact_class


# Generated at 2022-06-24 22:00:54.051757
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    data = {'ansible_architecture': '9000/800'}
    h_p_u_x_hardware_1 = HPUXHardware('abc123')
    var_1 = h_p_u_x_hardware_1.get_memory_facts(data)


# Generated at 2022-06-24 22:00:56.824076
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = 'f4fa9c'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)

test_case_0()
test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:01:05.279799
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = {}
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    ansible_architecture_0 = '9000/785'
    str_1 = {'ansible_architecture': ansible_architecture_0}
    cpu_facts_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts = str_1)
    assert cpu_facts_0.__class__.__name__ is 'dict'
    assert cpu_facts_0 == {'processor_count': 0}


# Generated at 2022-06-24 22:01:13.786287
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    os_0 = 'x\x90\x19\xa2'
    module_0 = '|\x19S\xdb5\x15\x1b\x7f'
    mem_total_mb = '\x84\x1e\x11\x04\x19\x0e\x95\x9a\x1a\x00\x8f\x1a\x01\x02\x04\x06\x17\x9f\x83\x11\x1b'

# Generated at 2022-06-24 22:01:19.102075
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_var_0 = 'RhdkZXNjCg=='
    h_p_u_x_hardware_collector_var_0 = HPUXHardwareCollector(str_var_0)


# Generated at 2022-06-24 22:01:20.861879
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()


# Generated at 2022-06-24 22:01:23.550941
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    str_0 = '|Q)'
    var_0 = h_p_u_x_hardware_0.get_memory_facts(str_0)

# Generated at 2022-06-24 22:01:24.796896
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    f_0 = HardwareCollector()
    assert isinstance(f_0, HardwareCollector)


# Generated at 2022-06-24 22:01:36.509306
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = 'sFo`c%^I'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = "B.11.31"
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-24 22:02:03.226621
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_case_0()


# Generated at 2022-06-24 22:02:07.013428
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:02:14.036410
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    command_output_0 = 'nvidia'
    h_p_u_x_hardware_0 = HPUXHardware(command_output_0)
    args = {'ansible_distribution_version':"B.11.23",'ansible_architecture':'ia64'}
    # Test with no command outputs
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(args)
    assert var_0 == {'processor': 'Intel Itanium 2', 'processor_count': 2, 'processor_cores': 2}


# Generated at 2022-06-24 22:02:21.321511
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(str_0)
    # Unit test for function run()
    str_0 = '&?\\\x0c+ff'
    dict_0 = {'x&?\\\x0c+ff': str_0}
    # Unit test for function populate()
    str_0 = '&?\\\x0c+ff'
    dict_0 = h_p_u_x_hardware_collector_0.populate(str_0)
    str_0 = '&?\\\x0c+ff'
    dict_0 = {'x&?\\\x0c+ff': str_0}

# Generated at 2022-06-24 22:02:24.405681
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    collected_facts_0 = {}
    collected_facts_0['ansible_architecture'] = '9000/785'
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_0)


# Generated at 2022-06-24 22:02:28.508616
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '+&\\\x1c\xc7$ '
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:31.926233
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:02:36.658929
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '/6'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    str_1 = '"a'
    var_0 = h_p_u_x_hardware_0.get_hw_facts(str_1)
    should_be_0 = ' '
    assert should_be_0 == var_0


# Generated at 2022-06-24 22:02:42.119731
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    out_0 = 'a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a'

# Generated at 2022-06-24 22:02:48.490064
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)

    collected_facts_0 = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23'
    }

    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)


# Generated at 2022-06-24 22:03:15.257971
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:03:21.086408
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str0)
    var_0 = h_p_u_x_hardware_0.populate()
    h_p_u_x_hardware_1 = HPUXHardware('&?\\\x0c+ff', var_0)
    var_1 = h_p_u_x_hardware_1.get_memory_facts(var_0)


# Generated at 2022-06-24 22:03:30.538064
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    path = os.path.dirname(__file__)
    syslog_file = os.path.join(path, 'files', 'syslog.log')
    os.environ['SYSLOG_FILE'] = syslog_file
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()
    try:
        assert isinstance(var_0, dict)
    except AssertionError:
        raise AssertionError('Expected dict got {0}'.format(type(var_0)))
    try:
        assert var_0['processor_count'] == 2
    except AssertionError:
        raise AssertionError

# Generated at 2022-06-24 22:03:34.668290
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()
    assert var_0 == {}, 'Populate is not empty'


# Generated at 2022-06-24 22:03:45.430868
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = 'O6UdiX6Y'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)

    collected_facts_0 = {'ansible_architecture' : 'ia64', 'ansible_distribution_version' : 'B.11.23'}
    var_0 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_0)

    collected_facts_1 = {'ansible_architecture' : 'ia64', 'ansible_distribution_version' : 'B.11.31'}
    var_1 = h_p_u_x_hardware_0.get_hw_facts(collected_facts_1)


# Generated at 2022-06-24 22:03:53.662076
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '5w5'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    collected_facts_0 = {'platform': 'HP-UX', 'distribution': 'B.11.31'}
    collected_facts_1 = {'platform': 'HP-UX', 'distribution': 'B.11.11'}
    collected_facts_2 = {'platform': 'HP-UX', 'distribution': 'B.11.23'}
    collected_facts_3 = {'platform': 'HP-UX', 'distribution': 'B.11.00'}
    collected_facts_4 = {'platform': 'HP-UX', 'distribution': 'B.11.31'}

# Generated at 2022-06-24 22:04:00.328332
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '!F!\x1d'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    collected_facts = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 22:04:05.420595
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    # Create a new instance of HPUXHardwareCollector
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector();
    assert h_p_u_x_hardware_collector_0._fact_class is HPUXHardware
    assert h_p_u_x_hardware_collector_0._platform is 'HP-UX'

# Generated at 2022-06-24 22:04:10.558117
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '+1Fp!+\x1c'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()

if __name__=='__main__':
    test_case_0()
    test_HPUXHardware_get_hw_facts()

# Generated at 2022-06-24 22:04:13.796665
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Check initialization of the class
    hpux_hardware_collector = HPUXHardwareCollector({})
    assert(hpux_hardware_collector.platform == 'HP-UX')
    assert(hpux_hardware_collector.required_facts == set(['platform', 'distribution']))
    assert(isinstance(hpux_hardware_collector.get_platform_facts(), HPUXHardware))

# Generated at 2022-06-24 22:04:56.407250
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '=b.+'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    collected_facts_0 = {'ansible_architecture': '9000/785'}
    cpu_facts_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts_0)
    collected_facts_1 = {'ansible_architecture': '9000/785'}
    h_p_u_x_hardware_1 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_1.get_cpu_facts(collected_facts=collected_facts_1)


# Generated at 2022-06-24 22:05:02.881965
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = 'W8Q[\xa3\x1d\x1f\x8dpp\xad'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = None
    var_1 = h_p_u_x_hardware_0.get_memory_facts(var_0)


# Generated at 2022-06-24 22:05:07.463406
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    h_p_u_x_hardware_0 = HPUXHardware(module)
    var_0 = h_p_u_x_hardware_0.get_hw_facts()


# Generated at 2022-06-24 22:05:13.325667
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:05:14.810988
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    hardware.module = MockModule()
    hardware.get_cpu_facts()


# Generated at 2022-06-24 22:05:20.853598
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = '&?\\\r+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    collected_facts_0 = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)



# Generated at 2022-06-24 22:05:26.623491
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    #assert var_0 == ???


# Generated at 2022-06-24 22:05:31.779921
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    str_0 = 'G,H'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    str_1 = 'a'*20000 # NULL character not allowed
    collected_facts_0 = {str_0: str_1}
    var_0 = h_p_u_x_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:05:34.824436
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '$;\x04'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    h_p_u_x_hardware_0.get_hw_facts()

# Generated at 2022-06-24 22:05:39.636909
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    platform = 'HP-UX'
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector(platform)

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardwareCollector()

# Generated at 2022-06-24 22:06:06.212303
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '|0X'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    str_1 = 'q3/V'
    var_0 = h_p_u_x_hardware_0.get_memory_facts(collected_facts=str_1)


# Generated at 2022-06-24 22:06:14.560792
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = 'n?#xG@'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()
    assert var_0 == {'memory': {'swaptotal_mb': 7168, 'swapfree_mb': 7168, 'memtotal_mb': 7680, 'memfree_mb': 5059}, 'cpu': {'processor_count': 2, 'processor_cores': 32, 'processor': 'Intel(R) Xeon(R) CPU E5-2630 v3 @ 2.40GHz'}}
    str_0 = '9[h>%'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h

# Generated at 2022-06-24 22:06:23.267400
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '  Qp: '
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()
    h_p_u_x_hardware_1 = HPUXHardware(str_0)
    var_1 = h_p_u_x_hardware_1.get_memory_facts()

if __name__ == '__main__':
    test_case_0()
    test_HPUXHardware_get_memory_facts()

# Generated at 2022-06-24 22:06:32.165655
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = '\x0c'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    str_1 = ''
    h_p_u_x_hardware_1 = h_p_u_x_hardware_0.populate(str_1)
    int_0 = 1
    int_1 = 2
    str_2 = 'HPUXHardware.populate'
    assert_equal(len(h_p_u_x_hardware_1), int_0, str_2)
    str_3 = 'HPUXHardware.populate'
    str_4 = 'HPUXHardware.populate'

# Generated at 2022-06-24 22:06:40.751561
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()
    var_1 = h_p_u_x_hardware_0.get_memory_facts(var_0)
    assert var_1 == {'swaptotal_mb': 0, 'memtotal_mb': 16, 'memfree_mb': 1, 'swapfree_mb': 0}


# Generated at 2022-06-24 22:06:44.008124
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:06:49.669870
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    str_0 = '&?\\\x0c+ff'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.get_memory_facts()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:06:54.234563
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    str_0 = 'YB\x7f\x15\x10'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    var_0 = h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 22:07:04.559872
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    import pytest
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    str_0 = '\t'
    var_0 = h_p_u_x_hardware_collector_0.collect(str_0, False)
    str_1 = '-f\x7f\x1d'
    var_1 = h_p_u_x_hardware_collector_0.collect(str_1, False)
    str_2 = '\x1f'
    var_2 = h_p_u_x_hardware_collector_0.collect(str_2, False)
    str_3 = '-~\x0f'

# Generated at 2022-06-24 22:07:12.448293
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    str_0 = '\x00\xc7\xae\xb3\xe2\xd3\xee\x1d\xaa\x8d\xae\xf3\xc0\x1f\x9e'
    h_p_u_x_hardware_0 = HPUXHardware(str_0)
    dict_0 = {'ansible_architecture': 'ia64'}
    int_0 = h_p_u_x_hardware_0.get_hw_facts(dict_0)
