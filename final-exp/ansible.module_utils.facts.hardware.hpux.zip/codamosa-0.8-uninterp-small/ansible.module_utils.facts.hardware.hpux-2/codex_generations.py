

# Generated at 2022-06-24 21:58:47.111448
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    rc, out, err = h_p_u_x_hardware_0.module.run_command('echo -e "swapfile_size: 6824576\nphysical_memory_mb: 64\nswap_mb: 6824576"')
    collected_facts = {'ansible_architecture': '9000/800'}
    result = h_p_u_x_hardware_0.get_memory_facts(collected_facts)
    assert result['swapfree_mb'] == 27
    assert result['swaptotal_mb'] == 6824576
    assert result['memfree_mb'] == 0
    assert result['memtotal_mb'] == 64


# Generated at 2022-06-24 21:58:49.822365
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {
        "ansible_architecture": "9000/800",
        "ansible_distribution_version": "B.11.23"
    }
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor_count': 2}


# Generated at 2022-06-24 21:58:51.002904
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.populate()


# Generated at 2022-06-24 21:58:57.346755
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'model_out', ''))
    h_p_u_x_hardware_0.module.run_command.assert_any_call("model")
    assert h_p_u_x_hardware_0.get_hw_facts() == {'model': 'model_out'}


# Generated at 2022-06-24 21:59:00.490117
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.get_memory_facts()


# Generated at 2022-06-24 21:59:12.783076
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    rc = 0
    out = ' '.join([
        'phys_mem_pages/D',
        'b 1',
        'f',
        '200000'
    ])
    err = ''
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    collected_facts['ansible_distribution_version'] = 'B.11.23'

    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(rc, out, err))

    h_p_u_x_hardware_0.get_memory_facts(collected_facts=collected_facts)

# Generated at 2022-06-24 21:59:23.122568
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    # Test 'ansible_architecture' value
    assert h_p_u_x_hardware_collector_0.facts['ansible_architecture'] == 'ia64'

    # Test 'ansible_distribution' value
    assert h_p_u_x_hardware_collector_0.facts['ansible_distribution'] == 'HP-UX'

    # Test 'ansible_distribution_major_version' value
    assert h_p_u_x_hardware_collector_0.facts['ansible_distribution_major_version'] == 'B.11.'

    # Test 'ansible_distribution_release' value
    assert h_p_u_x_hardware_collector_

# Generated at 2022-06-24 21:59:26.192086
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware = HPUXHardware(module=MockModule())

    h_p_u_x_hardware.get_cpu_facts()



# Generated at 2022-06-24 21:59:29.167015
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware.module = FakeModule()
    h_p_u_x_hardware.populate()


# Generated at 2022-06-24 21:59:36.009130
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    print('HPUXHardware.get_hw_facts(collected_facts=collected_facts)')
    print(HPUXHardware.get_hw_facts(h_p_u_x_hardware_0, collected_facts=collected_facts))


# Generated at 2022-06-24 21:59:56.788222
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert (isinstance(HPUXHardwareCollector._fact_class, HPUXHardware))
    assert (HPUXHardwareCollector._platform == 'HP-UX')
    assert (HPUXHardwareCollector.required_facts == {'platform', 'distribution'})


# Generated at 2022-06-24 22:00:07.338688
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    data = {
        'ansible_facts': {
            'ansible_architecture': 'ia64',
            'ansible_distribution_version': 'B.11.23'
        }
    }
    h_p_u_x_hardware_0 = HPUXHardware(module=parsed_args_0, facts=data['ansible_facts'])
    data['ansible_facts']['ansible_architecture'] = 'aix'
    data['ansible_facts']['ansible_distribution_version'] = '7.1'
    h_p_u_x_hardware_1 = HPUXHardware(module=parsed_args_0, facts=data['ansible_facts'])

    h_p_u_x_hardware_0.get_hw_facts

# Generated at 2022-06-24 22:00:18.320182
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    result = h_p_u_x_hardware.populate(collected_facts)
    assert result['memfree_mb'] >= 0
    assert result['memtotal_mb'] >= 0
    assert result['swapfree_mb'] >= 0
    assert result['swaptotal_mb'] >= 0
    assert result['processor_count'] >= 0
    assert result['model'] is not None


# Generated at 2022-06-24 22:00:25.791795
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    h_p_u_x_hardware_0.module.run_command = MagicMock()
    h_p_u_x_hardware_0.module.run_command().stdout = 'model'
    h_p_u_x_hardware_0.module.run_command().stderr = 'stderr'
    h_p_u_x_hardware_0.module.run_command().rc = 0

    ansible_facts = {'ansible_architecture': 'ia64'}
    ansible_facts = dict(ansible_facts, **{'ansible_distribution_version': 'B.11.23'})
    h_p_u_x_hardware_0.module.run_command

# Generated at 2022-06-24 22:00:38.353674
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_major_version': 'B.11.23',
        'ansible_distribution_version': 'B.11.23'
    }
    h_p_u_x_hardware_0 = HPUXHardware(facts=facts)
    (hw_facts, ignored_errors) = h_p_u_x_hardware_0.populate()

# Generated at 2022-06-24 22:00:49.857628
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module.run_command = Mock(return_value=(0, 'swap total:  10240K    alloc:  11264K    free:   -1024K', ''))
    h_p_u_x_hardware_0.module.run_command = Mock(return_value=(0, 'swap total:  10240K    alloc:  11264K    free:   -1024K', ''))
    h_p_u_x_hardware_0.module.run_command = Mock(return_value=(0, 'swap total:  10240K    alloc:  11264K    free:   -1024K', ''))

# Generated at 2022-06-24 22:00:55.518171
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = dict(os=dict(distribution=dict(name='HP-UX', version='B.11.31')))
    hpux_get_cpu_facts = HPUXHardwareCollector(module=mocked_module, facts=facts)
    hpux_get_memory_facts = HPUXHardwareCollector(module=mocked_module, facts=facts)
    hpux_get_hw_facts = HPUXHardwareCollector(module=mocked_module, facts=facts)


# Generated at 2022-06-24 22:00:58.032698
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    with pytest.raises(NotImplementedError):
        h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:01:02.122492
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0 = hardware_0.get_hw_facts()
    assert h_p_u_x_hardware_0['model'] == 'ia64 hp server rx2600'

# Generated at 2022-06-24 22:01:09.388879
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware_0 = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

    hw_facts = hardware_0.get_hw_facts(collected_facts=collected_facts)
    assert isinstance(hw_facts, dict)
    assert 'firmware_version' in hw_facts
    assert 'model' in hw_facts
    assert 'product_serial' in hw_facts


# Generated at 2022-06-24 22:02:06.003079
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert (h_p_u_x_hardware_collector_0.required_facts == set(['platform', 'distribution']))
    assert (h_p_u_x_hardware_collector_0._platform == 'HP-UX')


# Generated at 2022-06-24 22:02:15.045794
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_get_cpu_facts_0 = HPUXHardware()
    collected_facts = {"ansible_architecture": "9000/800"}
    h_p_u_x_hardware_get_cpu_facts_0.get_cpu_facts(collected_facts=collected_facts)
    collected_facts = {"ansible_architecture": "9000/785"}
    h_p_u_x_hardware_get_cpu_facts_0.get_cpu_facts(collected_facts=collected_facts)
    collected_facts = {"ansible_architecture": "ia64", "ansible_distribution_version": "B.11.23"}
    h_p_u_x_hardware_get_cpu_facts_0.get_cpu_facts

# Generated at 2022-06-24 22:02:16.097915
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert isinstance(HPUXHardwareCollector(), HardwareCollector)


# Generated at 2022-06-24 22:02:22.117358
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, 'Physical:    2114752 Kbytes', ''))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    h_p_u_x_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-24 22:02:25.160162
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_object_0 = HPUXHardware()
    res = test_object_0.get_memory_facts()
    assert res[0] is False


# Generated at 2022-06-24 22:02:29.238248
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    assert h_p_u_x_hardware_0.get_hw_facts() == {'model': 'rp3440', 'firmware_version': 'B.11.23'}


# Generated at 2022-06-24 22:02:36.496294
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware = HPUXHardware()
    collected_facts = {
        u'ansible_architecture': u'9000/800',
        u'ansible_distribution_version': u'B.11.23'
    }
    h_p_u_x_hardware.populate(collected_facts)
    cpu_facts = h_p_u_x_hardware.get_cpu_facts(collected_facts)
    assert(cpu_facts['processor_count'] == 1)


# Generated at 2022-06-24 22:02:39.890492
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()

    # Input parameters
    collected_facts = {'ansible_architecture': '9000/800'}

    # Expected return value
    expected_result = {'swaptotal_mb': 0, 'memtotal_mb': 262144, 'memfree_mb': 0, 'swapfree_mb': 0}

    # Invoke method
    result = hardware.get_memory_facts(collected_facts)

    assert result == expected_result



# Generated at 2022-06-24 22:02:42.292135
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()

# Generated at 2022-06-24 22:02:51.776256
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    facts = {'ansible_architecture': '9000/785'}

    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts=facts)
    if cpu_facts.get("processor_count") is not None:
        assert cpu_facts.get("processor_count") == -1
    else:
        assert cpu_facts.get("processor_count") == 0
    assert cpu_facts.get("processor") == ""
    assert cpu_facts.get("processor_cores") == ""

    facts = {'ansible_architecture': 'ia64'}
    facts['ansible_distribution_version'] = "B.11.23"

    cpu_facts = h_p

# Generated at 2022-06-24 22:05:08.521043
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    h_p_u_x_hardware = HPUXHardware(test_module, test_module.params)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = {'swapfree_mb': 0, 'swaptotal_mb': 25600, 'memtotal_mb': 16384, 'memfree_mb': 0}
    result = h_p_u_x_hardware.get_memory_facts(collected_facts=collected_facts)
    if result != memory_facts:
        test_module.fail_json(
            msg="Unit test for method 'get_memory_facts' of class 'HPUXHardware' failed")


# Generated at 2022-06-24 22:05:16.368820
# Unit test for method get_cpu_facts of class HPUXHardware

# Generated at 2022-06-24 22:05:17.401794
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()



# Generated at 2022-06-24 22:05:19.873671
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware = HPUXHardware(module=object)
    h_p_u_x_hardware.populate()


# Generated at 2022-06-24 22:05:23.954916
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector._fact_class == HPUXHardware
    assert h_p_u_x_hardware_collector._platform == 'HP-UX'
    assert h_p_u_x_hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-24 22:05:28.819425
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    if (os.name == 'posix'):
        h_p_u_x_hardware_collector_1 = HPUXHardwareCollector()
    else:
        h_p_u_x_hardware_collector_1 = h_p_u_x_hardware_collector_1


# Generated at 2022-06-24 22:05:38.906482
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    
    # Test 1: When distribution version is B.11.31 and architecture is ia64
    distribution_version = 'B.11.31'
    architecture = 'ia64'
    collected_facts = {'ansible_distribution_version': distribution_version, 'ansible_architecture': architecture}
    assert h_p_u_x_hardware_0.get_cpu_facts(collected_facts) ==  {'processor_count': 2, 'processor_cores': 4, 'processor': 'Intel(R) Xeon(R) CPU E5645 @ 2.40GHz'}
    
    # Test 2: When distribution version is B.11.23 and architecture is ia64
    distribution_version = 'B.11.23'
   

# Generated at 2022-06-24 22:05:42.660120
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    h_p_u_x_hardware_0.get_memory_facts(collected_facts)


# Generated at 2022-06-24 22:05:47.535980
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware(module=None)
    gathered_facts = {'ansible_architecture': '9000/800'}
    # Unit test with correct args
    h_p_u_x_hardware_0.get_memory_facts(collected_facts=gathered_facts)


# Generated at 2022-06-24 22:05:50.854448
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware({}, dict(ansible_architecture='9000/800'))
    h_p_u_x_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:07:24.539818
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_case = HPUXHardware()
    hw_facts = test_case.get_hw_facts()
    assert hw_facts['model']

# Generated at 2022-06-24 22:07:27.496606
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector = HPUXHardwareCollector()
    h_p_u_x_hardware_collector.collect()
    h_p_u_x_hardware_collector.get_significant_data()

# Generated at 2022-06-24 22:07:36.364506
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MockModule()
    h_p_u_x_hardware_0.module.run_command = Mock(
        side_effect=[
            ('0', '/usr/bin/vmstat | tail -1', ''),
            ('0', 'grep Physical /var/adm/syslog/syslog.log', ''),
            ('0', 'phys_mem_pages/D', '0'),
            ('0', '/usr/sbin/swapinfo -m -d -f -q', ''),
            ('0', '/usr/sbin/swapinfo -m -d -f | egrep ^dev|^fs', '')
        ]
    )
    h_p_u_

# Generated at 2022-06-24 22:07:38.798104
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h_p_u_x_hardware = HPUXHardware()
    h_p_u_x_hardware_populate = h_p_u_x_hardware.populate()


# Generated at 2022-06-24 22:07:49.637943
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_p_u_x_hardware_0 = HPUXHardware()

    # Test 0:
    # Test with collected_facts = {}
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts = {})
    assert cpu_facts == {'processor': '', 'processor_count': None, 'processor_cores': None}

    # Test 1:
    # Test with collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': None}
    cpu_facts = h_p_u_x_hardware_0.get_cpu_facts(collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': None})

# Generated at 2022-06-24 22:07:51.020579
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()


# Generated at 2022-06-24 22:07:53.943428
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector_obj = HPUXHardwareCollector()
    assert hardware_collector_obj.platform == 'HP-UX'

# Generated at 2022-06-24 22:08:01.915521
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    h_p_u_x_hardware_0 = HPUXHardware()
    h_p_u_x_hardware_0.module = MagicMock()
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'test_model')
    h_p_u_x_hardware_0.populate = MagicMock()
    h_p_u_x_hardware_0.populate.return_value = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}
    h_p_u_x_hardware_0.module.run_command.return_value = (0, 'test_firmware_version')
    h_p_u_x_hardware_0.module

# Generated at 2022-06-24 22:08:06.050290
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpu = HPUXHardware()

    data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }

    assert hpu.get_hw_facts(data) == {}


# Generated at 2022-06-24 22:08:10.643348
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_p_u_x_hardware_collector_0 = HPUXHardwareCollector()
    assert h_p_u_x_hardware_collector_0._fact_class.platform == 'HP-UX'
    assert h_p_u_x_hardware_collector_0._platform == 'HP-UX'

