

# Generated at 2022-06-20 17:17:56.638875
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardwareCollector = HPUXHardwareCollector()
    assert hardwareCollector._platform == 'HP-UX'
    assert hardwareCollector._fact_class == HPUXHardware
    assert hardwareCollector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-20 17:18:02.595621
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware({})

    # unit test for PA-RISC
    assert hw.get_cpu_facts({'arch': '9000/785'}) == {'processor_count': 4}

    # unit test for Itanium
    assert hw.get_cpu_facts({'arch': 'ia64'}) == {'processor_count': 2, 'processor': u'Intel(R) Itanium(R) Processor 2', 'processor_cores': 2}


# Generated at 2022-06-20 17:18:05.101069
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    hardware._module = MockModule()

    assert hardware.populate() is not None

# Generated at 2022-06-20 17:18:16.623017
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Init class
    class ModuleFake:
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = list()
            self.run_command_rc = list()
            self.run_command_out = list()
            self.run_command_err = list()

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_count += 1
            self.run_command_args.append(cmd)
            return (self.run_command_rc.pop(0), self.run_command_out.pop(0), self.run_command_err.pop(0))

    module = ModuleFake()

# Generated at 2022-06-20 17:18:28.227214
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    rc, out, err = hardware.module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    out = "         0     348     562    1864098    316760       0      0        0      0"
    hardware.module.run_command.return_value = (0, out, '')
    rc, out, err = hardware.module.run_command("/usr/sbin/swapinfo -m -d -f -q")
    out = "2048"
    hardware.module.run_command.return_value = (0, out, '')

# Generated at 2022-06-20 17:18:37.790858
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hpux_hardware = HPUXHardware(module)

    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_architecture': '9000/785',
                       'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23',
                       'ansible_distribution_version': 'B.11.31',
                       }
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts=collected_facts)

    # Check if facts are empty
    assert(len(cpu_facts) == 0)

    # Add some facts to the collected_facts
    # For PA-RISC

# Generated at 2022-06-20 17:18:45.932827
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hw_facts = hardware.get_hw_facts()
    assert 'firmware_version' in hw_facts, "'firmware_version' is not in hw_facts"
    assert 'model' in hw_facts, "'model' is not in hw_facts"
    assert 'product_serial' in hw_facts, "'product_serial' is not in hw_facts"


# Generated at 2022-06-20 17:18:47.801831
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector(module=None)
    assert hardware_collector is not None

# Generated at 2022-06-20 17:18:52.259378
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware(None)
    data = hardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert data['model']
    assert data['firmware_version']
    assert data['product_serial']



# Generated at 2022-06-20 17:19:02.377262
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = {}
    collected_facts = {
        'ansible_architecture': '9000/800'
    }
    m = HPUXHardware({})
    assert m.get_cpu_facts(collected_facts=collected_facts) == cpu_facts

    collected_facts = {
        'ansible_architecture': '9000/785'
    }
    cpu_facts = {'processor_count': 6}
    assert m.get_cpu_facts(collected_facts=collected_facts) == cpu_facts

    collected_facts = {
        'ansible_architecture': 'ia64'
    }
    cpu_facts = {'processor_cores': 1,
                 'processor_count': 1,
                 'processor': 'Itanium'}
    assert m.get_cpu_

# Generated at 2022-06-20 17:19:19.482416
# Unit test for method populate of class HPUXHardware

# Generated at 2022-06-20 17:19:31.954287
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hwobj = HPUXHardware(module=module)

    # Test with distribution version B.11.23
    hwobj.module.params = {'ansible_facts': {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'},
                           'ansible_module_hw': True}
    result = hwobj.get_cpu_facts()
    assert 'processor_count' in result
    assert 'processor' in result
    assert 'processor_cores' in result

    # Test with distribution version B.11.31

# Generated at 2022-06-20 17:19:44.634981
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({'module_setup': True})

    # Simulate ia64 with B.11.23
    hw.module.params['ansible_architecture'] = 'ia64'
    hw.module.params['ansible_distribution_version'] = "B.11.23"
    hw.module.run_command = lambda *args, **kwargs: (0, "hp9000 K360 1.0 ia64 B.11.23 U ia64  1148346028", "")
    out = hw.get_hw_facts()

    assert out['firmware_version'] == 'K360 1.0'
    assert out['product_serial'] == '1148346028'

    # Simulate ia64 with B.11.31
    hw.module.params

# Generated at 2022-06-20 17:19:53.653894
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m = HPUXHardware({
        'platform': 'HP-UX',
        'distribution': 'HP_UX',
        'distribution_release': 'B.11.31',
        'ansible_architecture': 'ia64',
    })

    rc, out, err = m.module.run_command("echo -e '0\n0\n0\n0' > /sys/devices/system/cpu/cpu*/topology/thread_siblings_list")
    assert rc == 0

    cpu_facts = m.get_cpu_facts()

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'

# Generated at 2022-06-20 17:19:54.563449
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-20 17:20:00.150745
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    mod = AnsibleModuleMock()
    hardwareCollector = HPUXHardwareCollector(module=mod)
    assert hardwareCollector.module == mod
    assert hardwareCollector._fact_class == HPUXHardware
    assert hardwareCollector._platform == 'HP-UX'
    assert hardwareCollector.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-20 17:20:08.096670
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    # Test HP-UX platform
    collected_facts = {'platform': 'HP-UX', 'distribution': 'HP-UX'}
    hw_collector = HPUXHardwareCollector(module=None, collected_facts=collected_facts)
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:20:15.628891
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.required_facts == set(['platform', 'distribution']), 'required facts does not match'
    assert collector._fact_class == HPUXHardware, 'fact class does not match'
    assert collector._platform == 'HP-UX', 'platform does not match'
    assert isinstance(collector.collect(), dict), 'result  is not a dictionary'

# Generated at 2022-06-20 17:20:25.512763
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('Module', (object,), {'run_command': lambda self, a, b=None, c=None: (0, u"foo", None)})
    hw = HPUXHardware(module=module)
    rc, out, err = module.run_command("/usr/sbin/swapinfo -m -d -f -q")
    mock_swaptotal_mb = int(out.strip())

# Generated at 2022-06-20 17:20:35.836991
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux = HPUXHardware()

    # Command for test
    out_1 = '1'
    # Command for test
    out_2 = 'Memory  = 1024 MB'
    # Command for test
    out_3 = 'Memory    = 2048 MB'
    # Command for test
    out_4 = '/boot (/dev/vg00/lvol3)          8240512      8240576        23552'
    # Command for test
    out_5 = '/ (/dev/vg00/lvol1)            393414165    393416704       151040'
    # Command for test
    out_6 = 'Intel(R) Xeon(R) CPU           E5-2667 0 @ 3.30GHz'
    # Command for test

# Generated at 2022-06-20 17:20:50.305090
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    m = HPUXHardware({})
    # Test syslog message
    with open("/var/adm/syslog/syslog.log", "w") as f:
        f.write("<5> Jan 12 00:00:00 ABCD abc: Physical: 12345678 Kbytes, Logical: 12345678 Kbytes\n")
    result = m.get_memory_facts()
    # Remove log message
    with open("/var/adm/syslog/syslog.log", "w") as f:
        f.write("")
    assert result['memtotal_mb'] == 1228

    # Test adb
    if os.access("/dev/kmem", os.R_OK):
        data = "'0t12345\n'"
        m = HPUXHardware({})
        result = m.get_

# Generated at 2022-06-20 17:20:52.295338
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_facts = HPUXHardware(dict(), None)
    assert hardware_facts.platform == 'HP-UX'

# Generated at 2022-06-20 17:20:54.786993
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert isinstance(x, HPUXHardwareCollector)


# Generated at 2022-06-20 17:21:03.080256
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = type('AnsibleModule', (object,), {
        'params': {},
        'run_command': run_command_mock,
    })()
    test_module.fail_json = fail_json
    test_module.exit_json = exit_json
    hardware = HPUXHardware(test_module)
    hardware.get_hw_facts({'distribution': 'B.11.23', 'ansible_architecture': 'ia64'})



# Generated at 2022-06-20 17:21:11.204537
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
    }
    hardware_facts = hardware.populate(collected_facts)
    assert hardware_facts['processor'] == 'Itanium 2'
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 1229
    assert hardware_facts['swaptotal_mb'] == 3072

# Generated at 2022-06-20 17:21:23.660251
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpuxtestdata import HPUXHardwareTestData
    from ansible.module_utils.facts.hardware.hpuxtestdata import HPUXHardwareTestDataV23
    from ansible.module_utils.facts.hardware.hpuxtestdata import HPUXHardwareTestDataV31
    from ansible.module_utils.facts.hardware.hpuxtestdata import HPUXHardwareTestDataMissingSerial
    test_data = HPUXHardwareTestData().read()
    hpuxtestdata = HPUXHardwareTestData()
    hpuxtestdata_v23 = HPUXHardwareTestDataV23()
    hpuxtestdata_v31 = HPUXHardwareTestDataV31()
    hpuxtestdata_missingserial = HPUXHardware

# Generated at 2022-06-20 17:21:34.403921
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Create mocks
    ansible_module = FakeAnsibleModule()
    hw = FakeHPUXHardware(ansible_module)
    # Run method
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    # assert
    assert cpu_facts['processor_count'] == 2

    # Create mocks
    ansible_module = FakeAnsibleModule()
    hw = FakeHPUXHardware(ansible_module)
    # Run method
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    # assert

# Generated at 2022-06-20 17:21:39.981619
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector.load_collector(None, 'HP-UX', {'platform': 'HP-UX', 'distribution': 'HP-UX'})
    assert hardware_collector.__class__.__name__ == 'HPUXHardwareCollector'

# Generated at 2022-06-20 17:21:43.195387
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    '''
    Test the constructor
    '''
    # pylint: disable=R0902
    hardware = HPUXHardware(dict())
    assert hardware.platform == 'HP-UX'



# Generated at 2022-06-20 17:21:47.856368
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux = HPUXHardware(module='ansible.module_utils.facts.hardware.hpux.HPUXHardware')

    assert hpux is not None
    assert hpux.module is not None
    assert hpux.platform is not None
    assert hpux.platform == 'HP-UX'



# Generated at 2022-06-20 17:22:08.328535
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    HPUX = HPUXHardware(module)
    rc, out, err = module.run_command("model")
    model = out.strip()
    rc, out, err = module.run_command("uname -m")
    ansible_architecture = out.strip()
    cpu_facts = HPUX.get_cpu_facts()
    memory_facts = HPUX.get_memory_facts()
    hw_facts = HPUX.get_hw_facts()
    collected_facts = {'ansible_architecture': ansible_architecture,
                       'ansible_distribution_version': 'B.11.31',
                       'platform': 'HP-UX'}

# Generated at 2022-06-20 17:22:15.234070
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    hw_obj = HPUXHardware(module)
    assert 'model' in hw_obj.get_hw_facts()
    rc, out, err = module.run_command.call_args[0]
    assert rc == 0
    assert err == ''
    assert out == 'rp3440'


# Fake AnsibleModule class for unit testing method get_hw_facts of class HPUXHardware

# Generated at 2022-06-20 17:22:17.445499
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware(dict())
    hardware.module = MockModule()
    hardware.populate()



# Generated at 2022-06-20 17:22:27.601985
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    architecture = ['9000/800', '9000/785', 'ia64', '9000/897']
    distribution_version = ['B.11.23', 'B.11.31']
    for arch in architecture:
        collected_facts = {}
        collected_facts['ansible_architecture'] = arch
        if arch == 'ia64':
            for dist in distribution_version:
                collected_facts['ansible_distribution_version'] = dist
                hardware.get_cpu_facts(collected_facts)
        else:
            hardware.get_cpu_facts(collected_facts)



# Generated at 2022-06-20 17:22:37.651943
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    # Create instances of class HPUXHardware
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)

    # Create a list of dicts containing the parameters used to create the mock stack
    syslog_data = [{'content': 'Jul  5 05:48:58 myhost boot: Physical: 225976 Kbytes, Logical: 1456320 Kbytes'},
                   {'content': 'Jul  5 05:48:58 myhost boot: Physical: 225976 Kbytes, Logical: 1456320 Kbytes'}]


# Generated at 2022-06-20 17:22:43.199623
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:22:50.241743
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HardwareCollector.platform = 'HP-UX'
    HardwareCollector.distribution = 'B.11.31'
    HardwareCollector.architecture = 'ia64'
    hwc = HPUXHardwareCollector()
    assert hwc._platform == 'HP-UX'
    assert hwc._fact_class == HPUXHardware
    assert hwc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:22:58.332108
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_hardware = HPUXHardware(dict())

    # Populate when ansible_facts contain distribution_version B.11.23 and architecture 9000/800
    rc1, out1, err1 = hpux_hardware.module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    rc2, out2, err2 = hpux_hardware.module.run_command("/usr/contrib/bin/machinfo | grep 'processor family'", use_unsafe_shell=True)

    hpux_hardware.populate(collected_facts={'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'})

# Generated at 2022-06-20 17:23:07.430379
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({})

    assert h.platform == 'HP-UX'
    assert 'ansible_memfree_mb' in h
    assert 'ansible_memtotal_mb' in h
    assert 'ansible_swapfree_mb' in h
    assert 'ansible_swaptotal_mb' in h
    assert 'ansible_processor' in h
    assert 'ansible_processor_cores' in h
    assert 'ansible_processor_count' in h
    assert 'ansible_model' in h
    assert 'ansible_firmware' in h
    assert h.populate()


# Generated at 2022-06-20 17:23:11.723705
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardwareCollector

    obj = HPUXHardwareCollector()
    assert obj.platform == 'HP-UX'
    assert obj._fact_class == HPUXHardware


# Generated at 2022-06-20 17:23:29.386945
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({'platform': 'HP-UX'}, {'ansible_architecture': 'ia64',
                                                   'ansible_distribution_version': 'B.11.23'})
    hardware_facts = hardware.get_hw_facts()
    assert hardware_facts['firmware_version'] == '8.70'
    assert hardware_facts['model'] == 'ia64 HP Integrity rx2800 i2'
    assert hardware_facts['product_serial'] == 'USCHU0294L'

# Generated at 2022-06-20 17:23:35.129712
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'rp3440', ''))
    hw = HPUXHardware(module)
    assert hw.get_hw_facts() == {'model': 'rp3440'}



# Generated at 2022-06-20 17:23:38.237402
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    assert hardware_obj


# Generated at 2022-06-20 17:23:46.099537
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule
    module.params = {}

    hw = HPUXHardware(module)

    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    out = hw.populate(collected_facts)
    assert out['processor_count'] == 148
    assert out['processor'] == 'Intel(R) Itanium(R) CPU 9300 @ 1.60GHz'
    assert out['processor_cores'] == 80
    assert out['processor_vcpus'] == 148
    assert out['processor_threads_per_core'] == '1'
    assert out['memfree_mb'] == 11594
    assert out['memtotal_mb'] == 324444

# Generated at 2022-06-20 17:23:51.681742
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert hasattr(x, 'collected_facts')
    assert x.collected_facts == {}
    assert x.required_facts == {'platform', 'distribution'}
    assert x.platform == 'HP-UX'
    assert x.fact_class == HPUXHardware

# Generated at 2022-06-20 17:24:02.197765
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    # Get an instance of HPUXHardware class
    hw = HPUXHardware(module)
    rc, out, err = module.run_command("echo -e '/usr/contrib/bin/machinfo | grep -i socket'")
    if rc == 0 and out:
        rc, out, err = module.run_command("/usr/contrib/bin/machinfo | grep -i socket")
        if out:
            ansible_facts = {'ansible_architecture': 'ia64',
                             'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-20 17:24:08.184176
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = MockModule()
    hw.module.run_command.return_value = (0, 'B.11.31 ia64', '')
    hw.get_hw_facts()
    assert hw.facts['firmware_version'] == 'B.11.31 ia64'


# Generated at 2022-06-20 17:24:11.829202
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {}
    expected_required_facts = set(['platform', 'distribution'])
    h = HPUXHardwareCollector(facts)
    assert h.required_facts == expected_required_facts

# Generated at 2022-06-20 17:24:16.694408
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    def new_HPUXHardware(module):
        return HPUXHardware(module)
    hw_collector = HPUXHardwareCollector(new_HPUXHardware)
    assert isinstance(hw_collector, HardwareCollector)
    assert isinstance(hw_collector._fact_class, HPUXHardware)


# Generated at 2022-06-20 17:24:18.322540
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:24:32.246788
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HPUXHardware.get_hw_facts()

# Generated at 2022-06-20 17:24:37.000823
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_facts = HPUXHardware(dict(platform='HP-UX'))
    memory_facts = hardware_facts.get_memory_facts()
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-20 17:24:38.974816
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModuleMock()
    hw = HPUXHardware(module)
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:24:41.752983
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector._platform == 'HP-UX'

# Generated at 2022-06-20 17:24:44.339366
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    har = HPUXHardware(module)

    assert har is not None

# Generated at 2022-06-20 17:24:47.769549
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'
    assert hw.system == 'Hardware'



# Generated at 2022-06-20 17:25:00.094051
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': 'all'}
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31',
        ansible_machine='ia64'
    )
    hpux_hw = HPUXHardware(module)
    hardware_facts = hpux_hw.populate(collected_facts=collected_facts)
    assert hardware_facts.get('processor_count') == 2
    assert hardware_facts.get('processor_cores') == 8
    assert hardware_facts.get('processor') == 'Intel(R) Itanium(R) Processor 9500'

# Generated at 2022-06-20 17:25:02.233494
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({})
    assert hw.platform == 'HP-UX'
# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-20 17:25:07.938664
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Constructor test for class HPUXHardwareCollector
    """
    hpux_obj = HPUXHardwareCollector()
    assert hpux_obj._fact_class == HPUXHardware
    assert hpux_obj._platform == 'HP-UX'
    assert hpux_obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:25:09.528398
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-20 17:25:30.619475
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    mod = AnsibleModule({})
    facts_collection = [{'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}]
    result = HPUXHardware(mod).get_cpu_facts(facts_collection)
    assert isinstance(result, dict)
    assert 'processor' in result
    assert isinstance(result['processor'], str)
    assert 'processor_count' in result
    assert isinstance(result['processor_count'], int)
    assert 'processor_cores' in result
    assert isinstance(result['processor_cores'], int)



# Generated at 2022-06-20 17:25:42.512354
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('test_module', (object,), {})()
    module.run_command = lambda a, b=None: (0, 'test_out', 'test_err')

    hardware_collector = HPUXHardwareCollector()
    hardware_collector.facts = {
        'platform': 'HP-UX',
        'distribution': 'B.11.23'
    }

    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }

    cls = hardware_collector._fact_class
    hw_facts = cls(module).get_hw_facts(collected_facts=collected_facts)
    assert hw_facts.get('model') == 'test_out'
    assert h

# Generated at 2022-06-20 17:25:45.420691
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._platform == "HP-UX"
    assert hardware_collector._fact_class is HPUXHardware

# Generated at 2022-06-20 17:25:54.137120
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    tested_object = HPUXHardware()
    fake_vmstat = "procs -----------memory---------- ---swap-- -----io---- --system-- -----cpu-----\n" \
                  " r  b   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st"
    fake_vmstat += "\n 0  0      0 1286852 205440 618920    0    0     0     0    0    0  0  0 100  0  0"
    fake_swapinfo = "device           1M-blocks     free      %used    Priority\n" \
                    "/dev/vg00/lvol2          50         0       100          0\n" \
                    "Total                    50         0       100"

# Generated at 2022-06-20 17:26:02.714157
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64'}
    m = h.get_memory_facts(collected_facts)
    assert isinstance(m['memfree_mb'], int)
    assert isinstance(m['memtotal_mb'], int)
    assert isinstance(m['swaptotal_mb'], int)
    assert isinstance(m['swapfree_mb'], int)



# Generated at 2022-06-20 17:26:09.927166
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(dict())
    # Test case 1
    collected_facts = {'ansible_architecture': '9000/800'}
    expected_facts = {'processor_count': 2}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts == expected_facts
    # Test case 2
    collected_facts = {'ansible_architecture': '9000/785'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts == expected_facts
    # Test case 3
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}

# Generated at 2022-06-20 17:26:20.131326
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware({})
    hardware.get_cpu_facts = lambda x: {"processor_count": 1, "processor": "Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz", "processor_cores": 2}
    hardware.get_memory_facts = lambda: {"memfree_mb": 32, "memtotal_mb": 1024, "swaptotal_mb": 10, "swapfree_mb": 5}
    hardware.get_hw_facts = lambda: {"model": "HP-UX x1 B.11.23 U ia64", "firmware_version": "J58 V9.23", "product_serial": ""}
    result = hardware.populate()
    assert result['memfree_mb'] == 32
    assert result['memtotal_mb'] == 1024
    assert result

# Generated at 2022-06-20 17:26:31.568032
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # data for test
    collected_facts = {'ansible_architecture': '9000/785'}
    hw = HPUXHardware()
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2

    collected_facts = {'ansible_architecture': 'ia64'}
    hw = HPUXHardware()
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'Intel'
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-20 17:26:43.007208
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    data_input_1 = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'D.10.20'
    }
    data_output_1 = {'processor_count': 2}
    # data_input_2 = {'ansible_architecture': 'ia64'}
    # data_output_2 = {'processor_count': 2, 'processor': 'Intel(R) Xeon(R) CPU           E5450  @ 3.00GHz', 'processor_cores': 4}
    data_input_3 = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }

# Generated at 2022-06-20 17:26:49.577037
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-20 17:27:15.248201
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    from ..plugins.loader import get_all_plugin_loaders
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_argument_spec = dict(
        ansible_architecture='9000/800',
        ansible_distribution_version='B.11.31',
    )

    test_module = basic.AnsibleModule(
        argument_spec=test_argument_spec,
        supports_check_mode=False
    )

    test_HPUXHardware = HPUXHardware(module=test_module)

    result = test_HPUXHardware.get_cpu_facts(collected_facts=test_argument_spec)
    assert result


# Generated at 2022-06-20 17:27:20.243145
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUX = HPUXHardwareCollector()
    assert HPUX._fact_class == HPUXHardware
    assert HPUX._platform == 'HP-UX'
    assert HPUX.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:27:22.227925
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Constructor of class HPUXHardwareCollector can be called.
    """
    HPUXHardwareCollector()

# Generated at 2022-06-20 17:27:31.137600
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, "abc", "")
    hw = HPUXHardware(mock_module)
    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': "B.11.31"
    }
    expected_result = {
        'model': 'abc',
        'firmware_version': 'abc',
        'product_serial': 'abc'
    }
    assert expected_result == hw.get_hw_facts(collected_facts)



# Generated at 2022-06-20 17:27:39.965191
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
   hpux_hw = HPUXHardware()
   collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
   facts = hpux_hw.populate(collected_facts)
   assert facts['processor'] == 'Intel(R) Itanium(R) Processor 9300 series'
   assert facts['processor_cores'] == 4
   assert facts['processor_count'] == 4
   assert facts['memfree_mb'] == 53381
   assert facts['memtotal_mb'] == 81920
   assert facts['swapfree_mb'] == 0
   assert facts['swaptotal_mb'] == 0
   assert facts['firmware_version'] == 'v2.15 Rev.'