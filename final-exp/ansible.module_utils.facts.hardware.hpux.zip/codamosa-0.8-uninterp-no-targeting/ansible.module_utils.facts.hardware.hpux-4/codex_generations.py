

# Generated at 2022-06-20 17:18:02.680394
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class MockModule:
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))

    class MockClass:
        def __init__(self, module):
            self.module = module

    mock_module = MockModule()
    mock_class = MockClass(mock_module)

    # Test if method return dictionnary with processor_count when ansible_architecture is 9000/800 or 9000/785
    mock_module.run_command.return_value = (0, '3', '')
    mock_class.populate = Mock(return_value={'ansible_architecture': '9000/800'})
    facts = mock_class.get_cpu_facts()
    assert facts['processor_count'] == 3

    # Test if method return dictionnary with processor

# Generated at 2022-06-20 17:18:06.612063
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(None)
    cpu_facts = hardware.get_cpu_facts()
    if cpu_facts['processor_count']:
        assert isinstance(cpu_facts, dict)

# Generated at 2022-06-20 17:18:17.897114
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = MockModule({'ansible_architecture': 'ia64'})
    hw.module.run_command = Mock(return_value=(0, 'machine', ''))
    hw.get_hw_facts()
    hw.module.run_command.assert_called_with('model')
    assert hw.facts['model'] == 'machine'

    hw = HPUXHardware()
    hw.module = MockModule({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})

# Generated at 2022-06-20 17:18:20.560860
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({})
    assert h.platform == 'HP-UX'


# Generated at 2022-06-20 17:18:28.065712
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({'platform': 'HP-UX', 'distribution': 'B.11.31'})
    assert hardware.platform == 'HP-UX'
    assert hardware.memory_facts == 'memfree_mb, memtotal_mb, swapfree_mb, swaptotal_mb'
    assert hardware.cpu_facts == 'processor, processor_cores, processor_count'
    assert hardware.other_facts == 'model, firmware'


if __name__ == '__main__':
    test_HPUXHardware()

# Generated at 2022-06-20 17:18:37.648990
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_module = AnsibleModule(argument_spec={'gather_subset': dict(type='list',
                                                                     elements='str',
                                                                     required=True)})
    test_module.exit_json = exit_json

    test_obj = HPUXHardware()
    test_obj.module = test_module
    HPUX_machinfo_B1131_output = "/usr/contrib/bin/machinfo output B.11.31"
    HPUX_machinfo_B1123_output = "/usr/contrib/bin/machinfo output B.11.23"
    HPUX_machinfo_B1124_output = "/usr/contrib/bin/machinfo output B.11.23"

# Generated at 2022-06-20 17:18:50.266133
# Unit test for method populate of class HPUXHardware

# Generated at 2022-06-20 17:19:01.248960
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = mock.Mock(return_value=('', '', 0))
    module.params = {'key': 'value'}

    h = HPUXHardware(module)

    facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31',
        'platform': 'HP-UX'
    }

    result = h.populate(facts)

    # From HPUXHardware.get_cpu_facts
    module.run_command.assert_called_with("/usr/contrib/bin/machinfo | egrep 'socket[s]?$' | tail -1", use_unsafe_shell=True)

    # From

# Generated at 2022-06-20 17:19:03.729526
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector(None)
    assert collector is not None


# Generated at 2022-06-20 17:19:13.906912
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Get the test data
    data = get_test_data("test_HPUXHardware_get_memory_facts")

    # Create an instance of class HPUXHardware
    hphw = HPUXHardware(data)

    # Test method get_memory_facts
    test_data = hphw.get_memory_facts()

    # Assert test data
    for key, value in data.get("processors_memory").iteritems():
        assert test_data.get("memtotal_mb") == value, \
            "Expected: %s, Actual: %s" % (value, test_data.get("memtotal_mb"))



# Generated at 2022-06-20 17:19:27.801479
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpuxHardwareCollector = HPUXHardwareCollector()
    assert hpuxHardwareCollector._fact_class == HPUXHardware
    assert hpuxHardwareCollector._platform == 'HP-UX'
    assert hpuxHardwareCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:19:31.993969
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({}, {})
    assert h is not None
    assert h.platform == 'HP-UX'
    assert h.processor_cores is None
    assert h.memtotal_mb is None
    assert h.processor is None


# Generated at 2022-06-20 17:19:36.488824
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector.collect()
    assert (hw._platform == 'HP-UX')
    assert (hw._fact_class == HPUXHardware)

# Generated at 2022-06-20 17:19:44.066007
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict(module=None, ansible_facts=dict(ansible_architecture='ia64',
                                                           ansible_distribution_version='B.11.31',
                                                           ansible_distribution='HP-UX')))
    assert hw._platform == 'HP-UX'
    assert hw._fact_class == HPUXHardware
    assert hw._required_facts == {'platform', 'distribution'}


# Unit tests for HPUXHardware class' methods

# Generated at 2022-06-20 17:19:49.204010
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    Constructor of HPUXHardware
    """
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module)
    assert hardware.platform == 'HP-UX'
    assert hardware.distribution == 'HP-UX'
    assert hardware.module == module


# Unit test class HPUXHardware

# Generated at 2022-06-20 17:19:55.156438
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list')
    })

    # Test B.11.31 ia64

# Generated at 2022-06-20 17:20:02.225488
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeANSIModule()
    module.run_command = lambda *args: (0, '/bin/sh: ioscan: not found', '')
    hpux_hardware = HPUXHardware(module)

    # test that no cores are defined
    collected_facts = {}
    data = hpux_hardware.get_cpu_facts(collected_facts=collected_facts)
    assert not data

    # test with ioscan present
    collected_facts = {'ansible_architecture': '9000/800'}
    module.run_command = lambda *args: (0, '1', '')
    data = hpux_hardware.get_cpu_facts(collected_facts=collected_facts)
    assert data['processor_count'] == 1

    # test with ioscan return an error

# Generated at 2022-06-20 17:20:09.719136
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = dict()
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    hw = HPUXHardware()
    hw.module = MockModule()
    hw.populate(collected_facts=collected_facts)
    fw = hw.get_hw_facts()
    assert fw == dict(firmware_version='', product_serial='')


# Generated at 2022-06-20 17:20:22.696614
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collected_facts = {'firmware_version': 'B.11.31.1918',
                                'product_serial': '',
                                'model': 'ia64 hp server rx8640',
                                'architecture': 'ia64',
                                'distribution': 'HP-UX',
                                'distribution_version': 'B.11.31'}

    hardware = HPUXHardwareCollector(module=None, collected_facts=hardware_collected_facts)

    # Test constructor
    assert isinstance(hardware, HardwareCollector)
    assert hardware.facts['platform'] == 'HP-UX'
    assert hardware.facts['memory']['memtotal_mb'] == 268435456
    assert hardware.facts['memory']['memfree_mb'] == 25444480
    assert hardware

# Generated at 2022-06-20 17:20:25.528412
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector()
    assert hwc is not None

# Generated at 2022-06-20 17:20:45.472798
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import sys
    import platform
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils._text import to_bytes

    facts = {'ansible_architecture': platform.machine(), 'ansible_distribution_version': platform.release()}

    dummy_module = type('ansible.module_utils.facts.hardware.hpux.HPUXHardware', (object,), {'run_command': run_dummy_command})

    h = HPUXHardware(dummy_module)
    h.populate(facts)
    res = h.get_cpu_facts(facts)

    sys.stdout.write("Expected CPU Facts: %s \n" % res)

# Generated at 2022-06-20 17:20:55.030468
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module, 'get_memory_facts')
    collected_facts = { 'ansible_architecture': '9000/800' }
    hardware.module.run_command = FakeRunCommand(return_value=('', '175987', ''))
    hardware.populate()
    assert module.exit_args['failed'] is True
    assert 'Unable to get memory facts' in module.exit_args['msg']

    module = FakeAnsibleModule()
    hardware = HPUXHardware(module, 'get_memory_facts')
    collected_facts = { 'ansible_architecture': '9000/800' }
    hardware.module.run_command = FakeRunCommand(return_value=('', '\n', ''))
    hardware.populate()

# Generated at 2022-06-20 17:20:58.435309
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwcollector = HPUXHardwareCollector()
    assert hwcollector.fact_class == HPUXHardware
    assert hwcollector.platform == 'HP-UX'

# Generated at 2022-06-20 17:21:03.182169
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw._fact_class == HPUXHardware

# Generated at 2022-06-20 17:21:09.180559
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    hcol = HPUXHardwareCollector(facts)
    result = hcol.collect()
    assert result['ansible_hw_processor_firmware_version']
    assert result['ansible_hw_processor_product_serial']

# Generated at 2022-06-20 17:21:22.706290
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Define collected facts
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
        'ansible_hostname': 'hostname.domain',
        'ansible_machine': 'ia64',
        'ansible_system': 'HP-UX'
    }

    # Define collected module_utils results
    cmd_output = [
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        ''
    ]
   

# Generated at 2022-06-20 17:21:33.686813
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Test method get_memory_facts of class HPUXHardware.
    """
    test_instance = HPUXHardware()
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    test_instance.get_memory_facts(collected_facts)

    collected_facts = {'ansible_architecture': '9000/800'}
    rc, out, err = test_instance.module.run_command("grep Physical /var/adm/syslog/syslog.log")

# Generated at 2022-06-20 17:21:41.164931
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({'ansible_architecture': 'ia64'})
    assert hw.platform == 'HP-UX'
    # All following assertions check that default values of attributes are empty dicts
    assert hw.cpu == {}
    assert hw.memory == {}
    assert hw.dmi == {}
    assert hw.identity == {}

# Generated at 2022-06-20 17:21:46.814839
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'architecture': 'ia64', 'platform': 'HP-UX', 'distribution': 'HP-UX',
             'distribution_version': 'B.11.31'}
    collector = HPUXHardwareCollector(facts)
    assert isinstance(collector, HPUXHardwareCollector)
    assert isinstance(collector.collect(), HPUXHardware)

# Generated at 2022-06-20 17:21:58.500951
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test = HPUXHardware({}, {})
    collected_facts = {'platform': 'HP-UX', 'ansible_architecture': 'ia64'}
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    test.get_cpu_facts(collected_facts=collected_facts)
    assert test.facts['processor_count'] == 2
    assert test.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert test.facts['processor_cores'] == 2
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    test.get_cpu_facts(collected_facts=collected_facts)
    assert test.facts['processor_count'] == 32

# Generated at 2022-06-20 17:22:08.150167
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector()
    assert hardware.platform == 'HP-UX'
    assert hardware._fact_class == HPUXHardware
    assert hardware._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 17:22:14.189405
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.hardware.hpuux import HPUXHardwareCollector
    hhc = HPUXHardwareCollector()
    assert hhc
    assert hhc.fact_class == HPUXHardware
    assert hhc.platform == 'HP-UX'
    assert hhc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:22:22.198477
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test case with system B.11.31
    collected_facts = {'ansible_distribution': 'HP-UX',
                       'ansible_distribution_major_version': 'B.11',
                       'ansible_distribution_release': 'B.11.31',
                       'ansible_distribution_version': 'B.11.31',
                       'ansible_architecture': 'ia64',
                       'ansible_machine': '9000/800'}

    hpu = HPUXHardware(module=None)
    res = hpu.get_memory_facts(collected_facts=collected_facts)

    assert res['memtotal_mb'] == 16384
    assert res['memfree_mb'] == 16384
    assert res['swaptotal_mb'] == 21504

# Generated at 2022-06-20 17:22:26.764613
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert HPUXHardwareCollector._fact_class == HPUXHardware
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:22:33.590719
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = mock.MagicMock()

    hardware = HPUXHardware(module=module)

    pagesize = 4096
    data = 10000
    rc = 0
    out = str(data)
    err = None
    module.run_command.return_value = (rc, out, err)

    result = hardware.get_memory_facts()

    module.run_command.assert_called_once_with("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    assert result == {'memfree_mb': pagesize * data // 1024 // 1024}

# Generated at 2022-06-20 17:22:37.651608
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Unit test requires a module
    with open(os.devnull, 'w') as f:
        mod = AnsibleModule(argument_spec={})

    # Test creation of HPUXHardwareCollector class
    assert HPUXHardwareCollector(mod)


# Generated at 2022-06-20 17:22:49.741452
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_facts = HPUXHardware({}, [])
    assert hardware_facts.populate() == {
        'memfree_mb': hardware_facts.memfree_mb,
        'memtotal_mb': hardware_facts.memtotal_mb,
        'swapfree_mb': hardware_facts.swapfree_mb,
        'swaptotal_mb': hardware_facts.swaptotal_mb,
        'processor': hardware_facts.processor,
        'processor_cores': hardware_facts.processor_cores,
        'processor_count': hardware_facts.processor_count,
        'model': hardware_facts.model,
        'firmware': hardware_facts.firmware
    }

# Generated at 2022-06-20 17:22:51.915703
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    mod = FakeModule()
    hardware = HPUXHardware(module=mod)
    assert hardware.platform == 'HP-UX'



# Generated at 2022-06-20 17:22:55.898543
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    def get_cpu_facts(self):
        return self.get_cpu_facts()
    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    h = HPUXHardware(get_cpu_facts, facts)
    cpu_facts = h.get_cpu_facts(facts)
    assert len(cpu_facts.keys()) == 3
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) processor 9115 @ 1.60GHz'
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-20 17:23:03.465210
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_test=HPUXHardware()
    ansible_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_test.populate(ansible_facts)
    data_test = hw_test.get_hw_facts(ansible_facts)
    print(data_test)
    assert data_test

if __name__ == '__main__':
    test_HPUXHardware_get_hw_facts()

# Generated at 2022-06-20 17:23:16.515815
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec=dict())
    harware = HPUXHardware(module)
    assert harware.platform == 'HP-UX'
    assert not harware.get_cpu_facts()
    assert not harware.get_memory_facts()
    assert not harware.get_hw_facts()



# Generated at 2022-06-20 17:23:22.073712
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    set_module_args({})
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hpu_hw = HPUXHardware(module)

    cpu_facts = hpu_hw.get_cpu_facts()
    assert cpu_facts.has_key('processor_count')
    assert cpu_facts.has_key('processor_cores')
    assert cpu_facts.has_key('processor')
    assert cpu_facts['processor'].startswith('Intel')


# Generated at 2022-06-20 17:23:24.970250
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwcol = HPUXHardwareCollector()
    assert hwcol._fact_class == HPUXHardware
    assert hwcol.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:23:38.394090
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = DummyAnsibleModule()
    hardware = HPUXHardware(module)

    # Test for HP-UX 11.31 ia64
    collected_facts = {'platform': 'HP-UX',
                       'distribution': 'HP-UX',
                       'distribution_version': 'B.11.31',
                       'ansible_architecture': 'ia64'}
    memory_facts = hardware.get_memory_facts(collected_facts)
    assert memory_facts['memfree_mb'] == 597
    assert memory_facts['memtotal_mb'] == 7563
    assert memory_facts['swaptotal_mb'] == 616
    assert memory_facts['swapfree_mb'] == 212

    # Test for HP-UX 11.31 ia64

# Generated at 2022-06-20 17:23:46.211991
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test data and expected result
    test_data = {
        'ansible_architecture': '9000/785',
        'ansible_distribution_version': 'B.11.31',
    }
    test_out = {
        'swaptotal_mb': 320,
        'swapfree_mb': 320,
        'memfree_mb': 895,
        'memtotal_mb': 15894
    }

    module = Mock(params={})
    module.run_command.return_value = (0, '', '')
    # Create Mock object for class Hardware
    hw = HPUXHardware(module)
    hw.collect_platform_subset_facts = Mock()
    hw.collect_platform_subset_facts.return_value = test_data
    # Test the method get_

# Generated at 2022-06-20 17:23:51.277262
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_test = HPUXHardware(dict())
    hardware_test.module = MockModule()
    out_test = "procs              memory            page                        disks                           traps              cpu\n" \
               " r b w    avm   fre  re  at  pi  po  fr   de   sr cd0  cd1  f0  f1  f2  f3  in   sy  cs us sy id wa st\n" \
               " 1 0 0 16884816 558124  0  0  0  0  0  0    0    0   0    0    0   0   0   0   0 1343 1389 13  0  0  1  0"
    hardware_test.module.run_command = Mock(return_value=(0, out_test, ""))
    facts = hardware_test.get_memory_

# Generated at 2022-06-20 17:24:01.925609
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    def run_command_succeed(self, cmd, *args, **kwargs):
        cmd_test_outputs = {
            "model": "ia64 hp integrity bl860c i2",
            "machinfo": """Machine serial number  =  US123456789
Firmware revision = 11.31
System Firmware Version =  B.11.31.0.2
System ROM date/time =  16-Jan-2011, 17:37:11
CPU serial number =  US908712345
System Model Name = HP Integrity BL860c i2
Firmware Features:
    Integrated BMC controller
    Integrated ILO3 controller
    4GB NVMEMSIMM (non-removable)
    USB Flash Disk"""
        }
        return 0, cmd_test_outputs[cmd], ""

    hardware = HPUXHardware

# Generated at 2022-06-20 17:24:14.053115
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert cpu_facts == {'processor_count': 5}
    cpu_facts = HPUXHardware.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64',
                                                            'ansible_distribution_version': 'B.11.23'})
    assert cpu_facts == {'processor_count': 6, 'processor': 'Intel(R) Itanium(R) Processor 9320', 'processor_cores': 6}

# Generated at 2022-06-20 17:24:16.357208
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    result = HPUXHardwareCollector()
    assert result._platform == 'HP-UX'
    assert result._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 17:24:27.091887
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware()
    collected_facts = {
        'platform': 'HP-UX',
        'distribution_major_version': 'B.11',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    result = hw.populate(collected_facts)
    assert result['processor_count'] == 2
    assert result['processor_cores'] == 1
    assert result['processor'] == 'Intel(R) Itanium(R) Family'
    assert result['memfree_mb'] == 6718
    assert result['memtotal_mb'] == 21257
    assert result['swaptotal_mb'] == 2
    assert result['swapfree_mb'] == 2

# Generated at 2022-06-20 17:24:36.600746
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware.get_hw_facts()
    assert isinstance(hw_facts, dict)

# Generated at 2022-06-20 17:24:37.590232
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector(None)

# Generated at 2022-06-20 17:24:47.791667
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {}
    hardware = HPUXHardware(module=None)

    # Test B.11.31 on ia64
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2643 0 @ 3.30GHz'

    # Test B.11.23 on ia64
    collected_facts['ansible_architecture'] = 'ia64'

# Generated at 2022-06-20 17:24:52.084389
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule(
        dict(
            ansible_architecture='9000/800',
        )
    )
    hardware = HPUXHardware(module=module)
    # Uncomment to generate test data
    # hardware.get_memory_facts()
    out = hardware.get_memory_facts()
    # import json; print(json.dumps(out, indent=4))
    assert out['memtotal_mb'] == 3479
    assert out['memfree_mb'] == 95
    assert out['swaptotal_mb'] == 0
    assert out['swapfree_mb'] == 0



# Generated at 2022-06-20 17:25:03.293624
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = AnsibleModuleMock()
    # Expected call for command used in get_hw_facts
    hw.module.run_command.add_cmd(['model'], 'ia64 hp server rx2600')
    # Expected call for command used in get_hw_facts
    hw.module.run_command.add_cmd(['/usr/contrib/bin/machinfo |grep -i \'Firmware revision\' | grep -v BMC'], 'Firmware revision = P68')
    # Expected call for command used in get_hw_facts
    hw.module.run_command.add_cmd(['/usr/contrib/bin/machinfo |grep -i \'Machine serial number\' '], 'Machine serial number = USXXXXXXX')


# Generated at 2022-06-20 17:25:07.444096
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw._fact_class == HPUXHardware
    assert hw._platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:25:09.406320
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()

# Generated at 2022-06-20 17:25:18.601001
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    HPUXHW = HPUXHardwareCollector
    facts = {}

    # Case 1: default values
    facts['ansible_architecture'] = 'ia64'
    facts['ansible_distribution_version'] = 'B.11.23'
    hw = HPUXHW.fetch_facts(facts)
    memory_facts = hw.data['ansible_facts']['ansible_memfree_mb']
    assert memory_facts < 3000



# Generated at 2022-06-20 17:25:27.354548
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({'ansible_architecture': 'ia64'})
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx6600'
    assert hw_facts['firmware_version'] == 'B.11.31.1104'
    assert hw_facts['product_serial'] == 'US123456'

# Generated at 2022-06-20 17:25:39.201251
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = type('test_module', (object,), dict(run_command=lambda self, args: (0, '', '')))()
    test_module.params = dict(gather_subset="!all,!min")
    test_module.check_mode = False
    test_module.params['gather_subset'] = '!all,network'
    test_module.exit_json = lambda **kwargs: None
    test_HPUXHardware = HPUXHardware(module=test_module)
    result = test_HPUXHardware.get_cpu_facts(collected_facts={
            "ansible_architecture": "9000/800"
        })
    assert result == {
        'processor_count': 1
    }

# Generated at 2022-06-20 17:25:47.625642
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts = set(['platform', 'distribution'])
    hdfact = HPUXHardwareCollector(required_facts)
    assert hdfact._fact_class == HPUXHardware
    assert hdfact._platform == 'HP-UX'

# Generated at 2022-06-20 17:25:55.727799
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({'ansible_architecture': 'ia64'})

    # TODO: Update when the module is able to run on HP-UX
    hw_facts = hw.get_hw_facts({'ansible_hostname': '30C1', 'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.23'})

    assert hw_facts['model'] == 'ia64 hp server rx8640'
    assert hw_facts['firmware_version'] == '3.20'
    assert hw_facts['product_serial'] == 'CZH33807KJ'


# Generated at 2022-06-20 17:26:03.325523
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    m_run_command = lambda x, **kwargs: (1, 'hojoho', 'error')
    module = {'run_command': m_run_command}
    module['ansible_facts'] = {'ansible_distribution_version': 'B.11.23'}
    h = HPUXHardware(module)
    data = h.get_hw_facts()
    assert data == {'model': 'hojoho', 'firmware_version': 'error'}

# Generated at 2022-06-20 17:26:09.792064
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware(dict())

    rc_cpu_facts = hardware.get_cpu_facts()
    assert rc_cpu_facts['processor_count'] == 16
    assert rc_cpu_facts['processor'] == 'Intel(R) Itanium(R) 9100 series processor @ 1.60GHz'
    assert rc_cpu_facts['processor_cores'] == 8

# Generated at 2022-06-20 17:26:18.412106
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec={
        },
        supports_check_mode=False,
    )
    hp_hw = HPUXHardware(module)
    facts = hp_hw.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'model' in facts
    assert 'firmware' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts

# Generated at 2022-06-20 17:26:30.892304
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # create instance of HPUXHardware
    hardware = HPUXHardware({'module': True})

    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    hardware_facts = hardware.populate(collected_facts=collected_facts)

    assert hardware_facts['processor_count'] == 8
    assert hardware_facts['processor'] == 'Itanium 2'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 15970
    assert hardware_facts['swaptotal_mb'] == 3840
    assert hardware_facts['memfree_mb'] == 5992

# Generated at 2022-06-20 17:26:42.001256
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    hw.module = True
    facts = hw.get_memory_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert facts['memtotal_mb'] == 487200
    assert facts['memfree_mb'] == 44
    assert facts['swaptotal_mb'] == 262072
    assert facts['swapfree_mb'] == 0
    facts = hw.get_memory_facts({'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'})
    assert facts['memtotal_mb'] == 128000
    assert facts['memfree_mb'] == 1280



# Generated at 2022-06-20 17:26:53.384084
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """Tests for correctness of facts returned by method get_hw_facts of class HPUXHardware."""
    # ARRANGE
    module_utils = 'ansible.module_utils.facts.hardware.hpux.HPUXHardware'
    hp_ux_hw = HPUXHardware(module_utils, 'HP-UX', None)
    hp_ux_hw.module.run_command = MagicMock(side_effect=[(0, 'ia64', ''), (0, 'B.11.31', ''), (0, 'HP-UX', '')])
    hp_ux_hw.get_cpu_facts = MagicMock()
    # ACT
    hw_facts = hp_ux_hw.get_hw_facts()
    # ASSERT

# Generated at 2022-06-20 17:26:57.164284
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert h.platform == 'HP-UX'

    h = HPUXHardware({'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'})
    assert h.platform == 'HP-UX'

    h = HPUXHardware({'ansible_architecture': '9000/785'})
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 17:27:05.278878
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    hardware = HPUXHardwareCollector(module=module, collected_facts=collected_facts)
    hardware_instance = hardware.collect()[0]
    hw_facts = hardware_instance.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'HP Integrity rx2660'
    assert hw_facts['firmware_version'] == 'T54.04.03'

# Generated at 2022-06-20 17:27:17.396002
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
  memory_facts = HPUXHardware().get_memory_facts()
  assert isinstance(memory_facts, dict)
  assert 'memfree_mb' in memory_facts
  assert 'memtotal_mb' in memory_facts
  assert 'swaptotal_mb' in memory_facts
  assert 'swapfree_mb' in memory_facts

# Generated at 2022-06-20 17:27:27.887477
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    hardware = HPUXHardware(module)
    hardware.collect_platform_facts = mock_collect_platform_facts
    hardware.collect_distribution_facts = mock_collect_distribution_facts

    # Test get_cpu_facts method with 9000/800 architecture
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    module.run_command = mock_run_command
    module.run_command.return_value = (0, '1', '')
    # cpu_facts = hardware.get_cpu_facts(collected_facts=facts)
    cpu_facts = hardware.populate(collected_facts=facts)
   

# Generated at 2022-06-20 17:27:30.500717
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module=module)

# Generated at 2022-06-20 17:27:34.179965
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    hw_obj = HPUXHardware()
    hw_obj.module = module
    hw_obj.get_memory_facts()



# Generated at 2022-06-20 17:27:40.767277
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware(None)

    collected_facts = {'ansible_facts': {}}

    hw_facts = {}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts['ansible_facts'])
    memory_facts = hw.get_memory_facts()
    hw_facts = hw.get_hw_facts()
    hw_facts.update(cpu_facts)
    hw_facts.update(memory_facts)

    assert hw_facts == hw.populate(collected_facts=collected_facts['ansible_facts'])
