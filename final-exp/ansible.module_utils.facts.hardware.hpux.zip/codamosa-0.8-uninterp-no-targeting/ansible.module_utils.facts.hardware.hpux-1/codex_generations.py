

# Generated at 2022-06-20 17:18:01.972021
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    import json
    hpu = HPUXHardware({})
    data = {
        'ansible_facts': {
            'ansible_architecture': '9000/800',
            'ansible_distribution_version': 'B.11.31'
        },
        'changed': False
    }

    with open('test/unit/module_utils/facts/hardware/hpux/test_1.json') as json_data:
        test_dict = json.load(json_data)

    # Test with get_memory_facts in release B.11.23
    data['ansible_facts']['ansible_architecture'] = 'ia64'

# Generated at 2022-06-20 17:18:05.883479
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.get_platform() == "HP-UX"
    assert hw.get_required_facts() == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:18:17.211358
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpu = HPUXHardware()
    collected_facts = {u'ansible_architecture': u'9000/800', u'ansible_distribution': u'HP-UX', u'ansible_pkg_mgr': u'SD-UX', u'ansible_distribution_version': u'B.11.31'}
    data = hpu.populate(collected_facts)
    hpu = HPUXHardware()
    collected_facts = {u'ansible_architecture': u'ia64', u'ansible_distribution': u'HP-UX', u'ansible_pkg_mgr': u'SD-UX', u'ansible_distribution_version': u'B.11.31'}
    data = hpu.populate(collected_facts)

# Generated at 2022-06-20 17:18:23.376087
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    from module_utils.facts import Hardware

    class TestHP(Hardware):
        platform = 'HP-UX'

    h = TestHP()
    h.module.run_command = lambda command, check_rc=True, use_unsafe_shell=False: None
    h.populate()

    assert isinstance(h.facts, dict)


# Generated at 2022-06-20 17:18:26.634329
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware(module=None)

    assert hardware_obj is not None

# Generated at 2022-06-20 17:18:36.521990
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """Unit test for method get_hw_facts of class HPUXHardware
    """
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    hwinfo = HPUXHardware(module)

    rc, out, err = module.run_command("echo 'HP Integrity rx8640 Server (1 processor)   CPU: Itanium 9140 (2.2 GHz)   Memory: 2048 MB   OS-ROM: B.11.32   POST: D.14.00.00'")
    hw_facts = hwinfo.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hw_facts["model"] == "HP Integrity rx8640 Server (1 processor)"
   

# Generated at 2022-06-20 17:18:41.822948
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    rc, out, err = hw.module.run_command("model")
    hw_facts = hw.get_hw_facts()

    assert hw_facts['model'] == out.strip()


# Generated at 2022-06-20 17:18:46.450682
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class is not None
    assert hardware_collector._fact_class.platform == 'HP-UX'

    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:18:55.694186
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """Unit test for method get_hw_facts of class HPUXHardware"""
    from ansible.module_utils.facts import FactCollector

    test = FactCollector(['HPUXHardware'])

    def mock_module(**kwargs):
        class M(object):
            def __init__(self, **kwargs):
                self.params = kwargs

            def run_command(self, *args, **kwargs):
                return (0, 'output', 'error')

        return M(**kwargs)

    test.module = mock_module(platform='HP-UX')
    test.module.run_command = mock_module(
        platform='HP-UX').run_command
    hw = HPUXHardware(test.module)

# Generated at 2022-06-20 17:19:06.443109
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw_mock = HPUXHardware({})
    assert hw_mock.platform == 'HP-UX'

    #Testing get_cpu_facts
    collected_facts_mock = {'ansible_architecture': 'ia64',
                            'ansible_distribution_version': 'B.11.31'}
    hw_mock.get_cpu_facts(collected_facts=collected_facts_mock)
    assert hw_mock.facts['processor_count'] == 4
    assert hw_mock.facts['processor_cores'] == 4
    assert hw_mock.facts['processor'] == "Intel Itanium 9300 series"


# Generated at 2022-06-20 17:19:21.324967
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_obj = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hardware_obj.module = MockModule()
    hardware_obj.get_cpu_facts(collected_facts)
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Xeon(TM) CPU         5150  @ 2.66GHz'
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware_obj.get

# Generated at 2022-06-20 17:19:33.034804
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    collected_facts = {'ansible_distribution_version': 'B.11.31',
                       'ansible_architecture': 'ia64'}
    hardware_facts = hardware.populate(collected_facts)

    assert hardware_facts['processor_count'] == 16
    assert hardware_facts['processor_cores'] == 48
    assert hardware_facts['processor'] == 'Intel(r) Itanium 2 processor'
    assert hardware_facts['memtotal_mb'] == 131072
    assert hardware_facts['memfree_mb'] == 63140
    assert hardware_facts['swaptotal_mb'] == 2047
    assert hardware_facts['swapfree_mb'] == 2047
    assert hardware_facts['model'] == 'ia64 hp server rx6600'

# Generated at 2022-06-20 17:19:45.709794
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = DummyModule()
    hardware = HPUXHardware(module=module)

    # We use collected facts to test populate since we don't have ansible_facts on HP-UX
    collected_facts = {
        'distribution': 'HP-UX',
        'distribution_major_version': '11',
        'distribution_release': 'B.11.31',
        'architecture': 'ia64',
        'os_family': 'HP-UX',
    }
    result = hardware.populate(collected_facts=collected_facts)

    assert result['ansible_processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert result['ansible_processor_cores'] == 8
    assert result['ansible_processor_count'] == 4

# Generated at 2022-06-20 17:19:53.900821
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpu = HPUXHardware({'ansible_facts': {'distribution_major_version': '11.31', 'architecture': 'ia64'}})
    hw_facts = hpu.get_hw_facts()
    assert 'firmware_version' in hw_facts
    assert 'product_serial' in hw_facts
    hpu = HPUXHardware({'ansible_facts': {'distribution_major_version': '11.31', 'architecture': '9000/800'}})
    hw_facts = hpu.get_hw_facts()
    assert 'firmware_version' not in hw_facts
    assert 'product_serial' not in hw_facts


# Generated at 2022-06-20 17:20:01.539152
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test get_memory_facts with old version of machinfo
    module = FakeModule({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    hw = HPUXHardware(module)


# Generated at 2022-06-20 17:20:10.686996
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    This function is used for testing HPUXHardware class.
    """
    # Constructor test without any data.
    hardware_obj = HPUXHardware({})
    assert hardware_obj
    assert hardware_obj.populate() == {
        'processor': '',
        'processor_cores': '',
        'processor_count': '',
        'memfree_mb': '',
        'memtotal_mb': '',
        'swapfree_mb': '',
        'swaptotal_mb': '',
        'model': '',
        'firmware': ''
    }

# Generated at 2022-06-20 17:20:24.401771
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    # memory_facts1_mock_data
    # This dict contains the following output values
    #
    # /usr/bin/vmstat | tail -1:
    #       procs   memory      page            disk          faults          cpu
    # r  b   w   swpd   free   in   act   out  pi  po  fr   de  sr  s0  s1  s3  s4  s5  s6  s7  in   sy  cs us sy id
    # 0  3  16 759028 200552  187  678   96   2   0   0   11   0   0   0   1   2   0   0   0   1   85  20  1  2 97
    #
    # grep Physical /var/

# Generated at 2022-06-20 17:20:35.409870
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = FakeAnsibleModule()
    test_module.params = {'gather_subset': 'all'}

# Generated at 2022-06-20 17:20:38.630382
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware({'platform': 'HP-UX', 'architecture': 'ia64'})
    # TODO
    #hardware.populate()
    assert True

# Generated at 2022-06-20 17:20:47.865096
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    mod = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    mock_collector = HPUXHardwareCollector(mod)
    mock_hpux_hardware = HPUXHardware(mock_collector)
    distribution_name = "HP-UX"
    distribution_version = "B.11.31"
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': distribution_name,
        'ansible_distribution_version': distribution_version,
    }
    collected_facts_old = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': distribution_name,
        'ansible_distribution_version': "B.11.23",
    }
    expected_hw

# Generated at 2022-06-20 17:21:06.605120
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = HPUXHardware()

    # Normal call
    facts = {}
    facts['ansible_architecture'] = '9000/800'
    facts['ansible_distribution_version'] = 'B.11.23'
    module.populate(facts)

    # Call with one processor (e.g. VM)
    facts = {}
    facts['ansible_architecture'] = 'ia64'
    facts['ansible_distribution_version'] = 'B.11.23'
    module.populate(facts)

    # Call with one processor (e.g. VM) with B.11.31 release
    facts = {}
    facts['ansible_architecture'] = 'ia64'
    facts['ansible_distribution_version'] = 'B.11.31'

# Generated at 2022-06-20 17:21:12.835701
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hpux_hw = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23',
        'ansible_system_vendor': 'HP'
    }
    hardware_facts = hpux_hw.populate(collected_facts)

    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'PA-RISC 2.0'
    assert hardware_facts['model'] == 'HP 9000/800'
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['memtotal_mb'] == 32768
    assert hardware_facts['memfree_mb'] == 13544

# Generated at 2022-06-20 17:21:26.001843
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hw = HPUXHardware(module)
    collected_facts = {'platform': 'HP-UX', 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

    # Test if output of command /usr/sbin/swapinfo -m -d -f -q is valid
    def mock_run_command(cmd, check_rc=False):
        if cmd == "/usr/sbin/swapinfo -m -d -f -q":
            return 0, "2048", None
        else:
            return 0, "", None
    hw.module.run_command = mock_run_command

    # Test output of command /usr/contrib/bin/machinfo | grep Memory

# Generated at 2022-06-20 17:21:32.646146
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_hardware = HPUXHardware(dict())
    hpux_hardware.module = MagicMock()
    hpux_hardware.module.run_command.return_value = (0,
                                                     '1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20\n21\n22\n23\n24\n25\n26\n27\n28\n29\n30\n31\n', '')
    hpux_hardware.module.exit_json = MagicMock()

    hpux_hardware.populate()

# Generated at 2022-06-20 17:21:39.482394
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hardware.module = dict()
    hardware.module['run_command'] = run_command_mock_helper
    hardware.collect()

    # Test that the result has the mandatory fields
    assert set(['model', 'firmware_version', 'product_serial']).issubset(hardware.facts.keys())


# Generated at 2022-06-20 17:21:50.123023
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware({})
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    rc, out, err = hw.module.run_command("/usr/contrib/bin/machinfo | egrep 'socket[s]?$' | tail -1", use_unsafe_shell=True)
    cpu_facts = {'processor_count': int(out.strip().split(" ")[0])}
    memory_facts = {}
    rc, out, err = hw.module.run_command("/usr/contrib/bin/machinfo | grep -e '[0-9] core' | tail -1", use_unsafe_shell=True)

# Generated at 2022-06-20 17:22:02.568602
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})

    # Test with valid data
    hw = HPUXHardware(module=test_module)
    ansible_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hw.get_cpu_facts(collected_facts=ansible_facts)

    assert cpu_facts['processor_count'] == 20

    ansible_facts = {'ansible_architecture': '9000/785'}
    cpu_facts = hw.get_cpu_facts(collected_facts=ansible_facts)

    assert cpu_facts['processor_count'] == 20

    ansible_facts = {'ansible_architecture': 'ia64'}

# Generated at 2022-06-20 17:22:05.975882
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = dict(platform='HP-UX', distribution='B.11.23')
    hardware_obj = HPUXHardware(facts)
    assert hardware_obj.platform == 'HP-UX'
    assert hardware_obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:22:18.643906
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware({'ansible_facts': {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'}})
    hardware.module.run_command = mocked_run_command


# Generated at 2022-06-20 17:22:30.150369
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    hpux_hw_obj = HPUXHardware(module)

    rc = 0
    out = ('HP Integrity rx8640 Server,'
           '  HP-UX B.11.31 U ia64        1864937030 two-user license')
    err = ''
    hpux_hw_obj.module.run_command = Mock(return_value=(rc, out, err))

    def test_result(return_dict):
        assert return_dict['model'] == 'HP Integrity rx8640 Server'


# Generated at 2022-06-20 17:22:43.141866
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    ansible_module_mock = MockAnsibleModule()
    ansible_module_mock.params = {}
    obj = HPUXHardware(ansible_module_mock)
    assert obj.platform == 'HP-UX'
    assert obj.module.__class__.__name__ == ansible_module_mock.__class__.__name__

# Generated at 2022-06-20 17:22:52.121634
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.hardware.hpux import HPUXHardwareCollector
    from ansible.module_utils.facts.collector.hardware.hpux import HPUXHardware
    hc = HPUXHardwareCollector(None, None)
    # Check that constructor works
    assert isinstance(hc, HPUXHardwareCollector)
    assert hc.required_facts == {'platform', 'distribution'}
    assert isinstance(hc.fact_class, HPUXHardware)

# Generated at 2022-06-20 17:22:59.394692
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    facts = dict(platform='Linux', distribution='SUSE')
    # ansible_distribution_version is not defined
    # ansible_architecture is not defined
    instance = HPUXHardware(facts=facts)
    assert instance.platform == 'HP-UX'
    assert not instance.populate()

    facts = dict(platform='Linux', distribution='SUSE', ansible_distribution_version=None, ansible_architecture=None)
    instance = HPUXHardware(facts=facts)
    assert instance.platform == 'HP-UX'
    assert not instance.populate()

    facts = dict(platform='Linux', distribution='SUSE', ansible_distribution_version='B.11.23', ansible_architecture='ia64')
    instance = HPUXHardware(facts=facts)
    assert instance.platform

# Generated at 2022-06-20 17:23:02.811289
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    from ansible_collections.community.general.plugins.module_utils.facts.collector.hpux_hardware import HPUXHardware
    hpux_hw = HPUXHardware({})
    assert hpux_hw.facts == {}

# Generated at 2022-06-20 17:23:15.499523
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw_obj = HPUXHardware()
    fact_data = {'platform': 'HP-UX',
                 'platform_version': 'B.11.31',
                 'machine': 'ia64',
                 'hostname': 'hostname.example.com',
                 'architecture': 'ia64',
                 'distribution': 'HP-UX',
                 'distribution_version': 'B.11.31'}

    ansible_facts_data = {'ansible_architecture': 'ia64',
                          'ansible_distribution': 'HP-UX',
                          'ansible_distribution_version': 'B.11.31'}

    facts_data = hw_obj.populate(collected_facts=ansible_facts_data)
    assert facts_data['processor']
    assert facts_data

# Generated at 2022-06-20 17:23:23.171355
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    h = HPUXHardware(module)
    module.run_command = MagicMock(return_value=(0, '/dev/vg01/swap00  0       0       0 -\n'
                                                       '/dev/vg01/swap01  0       0       0 -\n', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/swapinfo')
    module.run_command = MagicMock(return_value=(0, 'Physmem:   2098352K (1087904K packed) real,    102040K (    8096K packed) swap', ''))
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_

# Generated at 2022-06-20 17:23:31.513832
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector
    assert HPUXHardwareCollector == type(hpux_hardware_collector)
    assert hpux_hardware_collector.platform == "HP-UX"
    assert hpux_hardware_collector._required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-20 17:23:33.151291
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()

    assert hhc.required_facts == set(['platform', 'distribution'])
    assert hhc._fact_class == HPUXHardware
    assert hhc._platform == 'HP-UX'

# Generated at 2022-06-20 17:23:43.396390
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_get_cpu_facts = HPUXHardware(dict())

    collected_facts = {"ansible_architecture": "9000/800", "ansible_distribution": "HPUX", "ansible_distribution_major_version": "11"}
    cpu_facts = test_get_cpu_facts.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 0  # if ansible_architecture is 9000/800 or 9000/785, ioscan | wc -l return 0

    collected_facts = {"ansible_architecture": "ia64", "ansible_distribution": "HPUX", "ansible_distribution_major_version": "11"}
    collected_facts['ansible_distribution_version'] = "B.11.23"
    cpu_facts

# Generated at 2022-06-20 17:23:46.067942
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert hasattr(collector, '_platform')
    assert hasattr(collector, '_fact_class')
    assert HPUXHardware == collector._fact_class
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-20 17:23:55.818806
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_collector = HPUXHardwareCollector()
    assert h_collector._fact_class == HPUXHardware
    assert h_collector._platform == 'HP-UX'
    assert h_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:23:57.956360
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'


# Generated at 2022-06-20 17:24:06.169623
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        ),
        supports_check_mode=True
    )

    hw = HPUXHardware({'module': module})

    # ia64 systems
    module.exit_json(changed=False, ansible_facts=dict(
        ansible_architecture='ia64',
        ansible_distribution_version='B.11.23'
    ))
    cpu_facts = hw.get_cpu_facts()

    assert 'processor_count' in cpu_facts
    assert isinstance(cpu_facts['processor_count'], int)
    assert 'processor' in cpu_facts
    assert isinstance(cpu_facts['processor'], str)
    assert 'processor_cores' in cpu_

# Generated at 2022-06-20 17:24:17.877641
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """This unit test tries to populate HPUXHardware object to check if
    it does not return empty dictionary and if specific keys are present and
    not None
    """

    # Create HPUXHardware object
    harware_facts_obj = HPUXHardware()
    facts_dict = harware_facts_obj.populate()

    # Check if facts_dict is not empty
    assert facts_dict
    required_keys = set(['memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb',
                         'processor', 'processor_cores', 'processor_count', 'model', 'firmware_version'])
    # Check if specific keys of HPUXHardware.populate() are present and are not None
    assert required_keys.issubset(set(facts_dict.keys()))
   

# Generated at 2022-06-20 17:24:20.036667
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware(dict())
    assert hardware_obj.platform == 'HP-UX'


# Generated at 2022-06-20 17:24:30.250028
# Unit test for method get_cpu_facts of class HPUXHardware

# Generated at 2022-06-20 17:24:40.403086
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Test get_hw_facts
    module = type('', (), {'run_command': run_command_fake_get_hw_facts})
    hardware = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'HP Integrity rx2620'
    assert hw_facts['firmware_version'] == 'B.11.23.17'
    assert hw_facts['product_serial'] == 'MXK8021P84'



# Generated at 2022-06-20 17:24:43.438988
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert x.platform == 'HP-UX'
    assert len(x.required_facts) == 2


# Generated at 2022-06-20 17:24:51.006799
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpuxhw = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    result = hpuxhw.populate(collected_facts=collected_facts)
    assert result['processor'] == 'Intel(R) Xeon(R) CPU X5560 @ 2.80GHz'
    assert result['model'] == 'ia64 hp server rx4640'
    assert result['processor_count'] == 1
    assert result['processor_cores'] == 1
    assert result['firmware_version'] == 'B.11.31.1411'
    assert result['product_serial'] == 'AFKW63400X9'
    assert result['memfree_mb'] == 16375

# Generated at 2022-06-20 17:25:01.357791
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(dict(ansible_facts=dict(ansible_architecture='ia64',
                                                    ansible_distribution_version='B.11.31')))
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 16
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2640 0 @ 2.50GHz'
    assert 'ansible_processor_threads_per_core' not in cpu_facts
    assert 'ansible_processor_threads_per_cpu' not in cpu_facts


# Generated at 2022-06-20 17:25:17.432335
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    hardware_facts = hardware.populate(collected_facts=collected_facts)
    assert hardware_facts['processor'] == 'Intel Itanium 2'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1


# Generated at 2022-06-20 17:25:23.323112
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = {'processor': 'Intel Itanium 2 processor 9100 series',
                 'processor_count': 2,
                 'processor_cores': 4}
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    hw = HPUXHardware("module")
    hw.get_cpu_facts(collected_facts=collected_facts)

    assert hw.facts['processor'] == cpu_facts['processor']
    assert hw.facts['processor_count'] == cpu_facts['processor_count']
    assert hw.facts['processor_cores'] == cpu_facts['processor_cores']

# Generated at 2022-06-20 17:25:25.090481
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.populate()

# Generated at 2022-06-20 17:25:31.077243
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({'ansible_architecture': '9000/785',
                             'ansible_distribution_version': 'B.11.31',
                             'ansible_system': 'HP-UX'})
    hardware._module = type('FakeModule', (object,), dict(run_command=run_command))
    expected = {
        'memfree_mb': 0, 'processor_cores': 2, 'swaptotal_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'processor_count': 0,
        'processor': None, 'model': 'HP Integrity rx4640', 'firmware': '03.0B.00'
    }
    assert hardware.populate() == expected



# Generated at 2022-06-20 17:25:43.061389
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = Mock()
    module.run_command.side_effect = [(0, "2", ""), (0, "4", ""), (0, "19", ""), (0, "8", ""), (0, "16", "")]

    hardware = HPUXHardware(module)
    facts = hardware.populate()

    # Out of 4 big cores and 2 small cores we have 8 logical cores
    assert facts['processor_cores'] == 8
    # We have 2 processors with 4 cores each
    assert facts['processor_count'] == 2

    assert facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert facts['memtotal_mb'] == 3072
    assert facts['memfree_mb'] == 1080
    assert facts['swaptotal_mb'] == 4

# Generated at 2022-06-20 17:25:48.850606
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    cpu_facts = hardware.get_cpu_facts({'ansible_architecture': 'ia64',
                                        'ansible_distribution_version': 'B.11.23'})
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9345'
    assert cpu_facts['processor_cores'] == 2
    return 0


# Generated at 2022-06-20 17:25:53.449400
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        ),
        supports_check_mode=True
    )
    fa = HPUXHardware(module=module)
    facts = fa.populate()
    memory_facts = fa.get_memory_facts()
    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-20 17:26:00.987742
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # Setup module
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=['all'], type='list'),
        filters=dict(required=False, type='list', default=[])
    ))

    # Setup class
    hw = HPUXHardware(module)

    # Test the constructor
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:26:07.257138
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    collected_facts = dict(ansible_architecture='ia64',
                           ansible_distribution_version='B.11.23')
    hardware_collector = HPUXHardware(module=module)
    hardware_collector.populate()
    hw_facts = hardware_collector.hw_facts
    assert hw_facts['firmware_version'] == "V2.06"
    assert hw_facts['product_serial'] == "L4000-SMF0107"



# Generated at 2022-06-20 17:26:18.653342
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)

    # define a custom fact_collector
    class FakeHPUXHardwareCollector(HPUXHardwareCollector):
        @staticmethod
        def populate(hw, collected_facts=None, collected_facts_from_platform=None, override_facts=None):
            data = {'ansible_system': 'hpux',
                    'ansible_architecture': 'ia64',
                    'ansible_distribution': 'HP-UX',
                    'ansible_distribution_version': 'B.11.31.2021'}
            collected_facts.update(data)

    fake_collector = FakeHPUXHardwareCollector()
    facts = hw.populate(fact_collector=fake_collector)

# Generated at 2022-06-20 17:26:54.494787
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module = type('', (), {})()
    hardware.module.run_command = lambda command, use_unsafe_shell=False: (0, '', '')
    facts = hardware.get_memory_facts({'ansible_architecture': 'ia64'})
    assert facts == {'memfree_mb': 0, 'memtotal_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0}

    hardware.module.run_command = lambda command, use_unsafe_shell=False: (0, '', 'Physical: 6472704 Kbytes')
    facts = hardware.get_memory_facts({'ansible_architecture': '9000/800'})

# Generated at 2022-06-20 17:26:55.901864
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:26:59.591020
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Create a HPUXHardware object for testing
    hardware_obj = HPUXHardware(dict())

    # Execute the populate method
    hardware_obj.populate(dict())

# Generated at 2022-06-20 17:27:00.429003
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-20 17:27:07.054410
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware()
    h.populate()
    f = h.get_facts()
    assert f['processor_count'] == 16
    assert f['processor_cores'] == 16
    assert f['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert f['memfree_mb'] == 4122
    assert f['memtotal_mb'] == 24414
    assert f['swapfree_mb'] == 8143
    assert f['swaptotal_mb'] == 25600
    assert f['model'] == 'ia64 hp Server rx8640'
    assert f['firmware_version'] == 'B.11.31.1204'

# Generated at 2022-06-20 17:27:11.717842
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-20 17:27:13.563013
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)



# Generated at 2022-06-20 17:27:20.619117
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    facts = HPUXHardware().get_memory_facts()
    assert isinstance(facts['memfree_mb'], int)
    assert isinstance(facts['memtotal_mb'], int)
    assert isinstance(facts['swapfree_mb'], int)
    assert isinstance(facts['swaptotal_mb'], int)

# Generated at 2022-06-20 17:27:31.268300
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    hardware.module = MockModule()
    hardware.populate(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"})

    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == "Intel Itanium 2 9500"
    assert hardware.facts['processor_cores'] == 2

    hardware = HPUXHardware()
    hardware.module = MockModule()
    hardware.populate(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"})

    assert hardware.facts['processor_count'] == 2

# Generated at 2022-06-20 17:27:40.104080
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module)
    hardware.module.run_command.return_value = (0, 'rp4440', '')
    out = hardware.get_hw_facts()
    assert out['model'] == 'rp4440'

    # /usr/contrib/bin/machinfo exist
    module = AnsibleModuleMock()
    module.exit_json = exit_json
    module.run_command.return_value = (0, 'HP-UX B.11.31', '')
    module.get_bin_path.return_value = '/usr/contrib/bin/machinfo'
    module.file_exists.return_value = True
    hardware = HPUXHardware(module)