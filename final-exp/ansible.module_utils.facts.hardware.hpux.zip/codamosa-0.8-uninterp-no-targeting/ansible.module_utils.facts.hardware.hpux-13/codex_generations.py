

# Generated at 2022-06-20 17:18:01.200987
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hwinfo = HPUXHardware()
    hwinfo.module = module
    hwinfo.populate(collected_facts)
    assert {'memfree_mb': 4377, 'memtotal_mb': 12411, 'swapfree_mb': 6473, 'swaptotal_mb': 6496} == hwinfo.get_memory_facts(collected_facts)


# Generated at 2022-06-20 17:18:07.959985
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.platform == 'HP-UX'
    assert h.required_facts == {'platform', 'distribution'}, 'required_facts non-expected value'
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector._fact_class == HPUXHardware, '_fact_class non-expected value'

# Generated at 2022-06-20 17:18:10.881669
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    a = HPUXHardwareCollector()
    assert a._fact_class is HPUXHardware
    assert a._platform == 'HP-UX'
    assert list(a.required_facts) == ['platform', 'distribution']

# Generated at 2022-06-20 17:18:16.517405
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.23'
    )
    hw = HPUXHardwareCollector(None, collected_facts)
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-20 17:18:28.148411
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_module = MockModule()
    test_module.params = {'gather_timeout': 0}
    test_HPUXHardware = HPUXHardware(module=test_module)

    test_HPUXHardware.populate()
    assert test_HPUXHardware.facts == {'memtotal_mb': 8192, 'processor': 'Intel(R) Xeon(R) CPU E5-2630 v3 @ 2.40GHz', 'memfree_mb': 564, 'processor_cores': 12, 'swaptotal_mb': 0, 'processor_count': 2, 'model': 'ia64 hp server rx8640', 'swapfree_mb': 0, 'firmware_version': 'v2.09', 'product_serial': 'USCHW1934XG'}


# Generated at 2022-06-20 17:18:34.501106
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    facts = hardware.populate()
    assert facts['processor_count'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['model']
    assert facts['firmware_version']



# Generated at 2022-06-20 17:18:41.409902
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h_obj = HPUXHardware()
    h_obj.module.get_bin_path = lambda *args, **kwargs: '/usr/contrib/bin/machinfo'
    h_obj.module.run_command = lambda *args, **kwargs: (0, '8\n', '')
    cpu_facts = h_obj.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert cpu_facts == {'processor_count': 8, 'processor': 'Intel Itanium 2'}
    h_obj.module.run_command = lambda *args, **kwargs: (0, '', 'command not found')

# Generated at 2022-06-20 17:18:46.222056
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """Unit test for HPUXHardware()"""

    hpu_hw = HPUXHardware({})
    assert hpu_hw is not None
    assert hpu_hw.populate() == {}


# === UNIT TESTS FOR THE HPUXHardware CLASS ===

# Generated at 2022-06-20 17:18:54.795869
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class ModuleMock(object):
        class RunCommandMock(object):
            rc = 0
            stdout = 'ia64'
            stderr = ''

        def __init__(self):
            self.run_command = self.RunCommandMock()

    class FactsMock(object):
        def __init__(self):
            self.ansible_facts = {}

    class TestHPUXHardware(HPUXHardware):
        module = ModuleMock()
        facts = FactsMock()

    fake_hardware = TestHPUXHardware()
    hw_facts = fake_hardware.get_hw_facts()

    assert hw_facts == {'firmware_version': '', 'model': '', 'product_serial': ''}

# Generated at 2022-06-20 17:18:58.356761
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert isinstance(hardware_collector.fact_class, HPUXHardware)

# Generated at 2022-06-20 17:19:16.734921
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test = HPUXHardware()

    cpu_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX'
    }

    test_hw_facts = test.get_hw_facts(collected_facts=cpu_facts)
    assert test_hw_facts['serial'] == 'SN12345ABC'
    assert test_hw_facts['firmware_version'] == '1264'


# Generated at 2022-06-20 17:19:20.248065
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector({})
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:19:21.925572
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector is not None

# Generated at 2022-06-20 17:19:28.769300
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    m = HPUXHardware({'module_utils': 'ansible.module_utils.facts'},{'ansible_architecture': 'ia64'})
    data = {'ansible_distribution_version': 'B.11.31'}
    m.populate(collected_facts=data)
    assert m.populate()['memtotal_mb'] != 0

# Generated at 2022-06-20 17:19:36.683387
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    harware = HPUXHardware(module)
    # In case of big-endian architecture set by default
    collected_big_endian = {"ansible_architecture": "9000/800"}
    # Memory values in MB
    collected_big_endian['ansible_memtotal_mb'] = 1024
    collected_big_endian['ansible_memfree_mb'] = 512
    collected_big_endian['ansible_swaptotal_mb'] = 2048
    collected_big_endian['ansible_swapfree_mb'] = 1024
    # CPU values
    collected_big_endian['ansible_processor_count'] = 1
    collected_big_endian['ansible_processor'] = 'PA-RISC 2.0 (1.25 GHz)'
    # In

# Generated at 2022-06-20 17:19:42.397349
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    module.run_command = MagicMock(return_value=(0, 'HP-UX', ''))
    hw_facts = hardware.get_hw_facts()
    assert hw_facts['model'] == hardware.platform
    assert hw_facts['firmware_version']

# Generated at 2022-06-20 17:19:46.058080
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector(module=None)
    assert hardware.hardware is None
    assert hardware._fact_class is HPUXHardware
    assert hardware._platform == 'HP-UX'
    assert hardware.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:19:54.582403
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    hardware = HPUXHardware()

    hardware.module = AnsibleModuleMock()


# Generated at 2022-06-20 17:19:56.585894
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware('module')
    assert hardware_obj.platform == 'HP-UX'


# Generated at 2022-06-20 17:19:58.887919
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    module.exit_json(ansible_facts = {'hardware': hardware.populate()})


# Generated at 2022-06-20 17:20:22.594476
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = HPUXHardware(module).populate()

    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor'] == "Intel(R) Xeon(R) CPU E5-4640 0 @ 2.40GHz"
    assert hardware_facts['memfree_mb'] == 1535
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['memtotal_mb'] == 30720
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['model'] == 'hp Integrity rx2620'
    assert hardware_facts['firmware_version'] == 'B.11.31.1811'

# Generated at 2022-06-20 17:20:34.773442
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    h_facts = HPUXHardware(module=module)

    module.run_command = MagicMock(return_value=(0, '1', ''))
    cpu_facts = h_facts.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1

    module.run_command = MagicMock(return_value=(0, 'Intel', ''))
    cpu_facts = h_facts.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64'})
    assert cpu_facts['processor'] == 'Intel'

    module.run_command = MagicMock(return_value=(0, '1', ''))

# Generated at 2022-06-20 17:20:45.513675
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (object,), dict(run_command=lambda *args, **kwargs: (0, "", "")))
    hs = HPUXHardware()
    hs.module = module
    assert hs.get_memory_facts() == {'memtotal_mb': 32, 'swaptotal_mb': 0, 'memfree_mb': 32, 'swapfree_mb': 0}

    # IA64
    module = type('', (object,), dict(run_command=lambda *args, **kwargs: (0, "", "")))
    hs = HPUXHardware()
    hs.module = module

# Generated at 2022-06-20 17:20:55.030310
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '2', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23'
    }

    hw = HPUXHardware(module)
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    cpu_correct = {
        'processor_count': 2,
        'processor_cores': 2
    }
    assert cpu_facts == cpu_correct


# Generated at 2022-06-20 17:21:06.535373
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']
    hw_facts = hw.get_hw_facts()
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']

test_HPUXHardware_get_hw_facts()


# Generated at 2022-06-20 17:21:11.704557
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hw = HPUXHardwareCollector()
    assert hpux_hw.platform == 'HP-UX'
    assert hpux_hw._fact_class == HPUXHardware
    assert hpux_hw.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:21:23.995346
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = None
    module = 'ansible.module_utils.facts.hardware.hpux.HPUXHardware'
    model_rhel7 = "ProLiant DL380 Gen9"
    model_rhel8 = "ProLiant DL580 Gen9"
    model_hpux = "ia64 hp server rx2800 i4"
    firmware_rhel7 = "I27"
    firmware_rhel8 = "I49"
    firmware_hpux = "v2.31"
    serial_rhel7 = "SGH303ZB91"
    serial_rhel8 = "SGH303ZB71"
    serial_hpux = "USCH8048LOJ"
    hw_facts_hpux = HPUXHardware(module)

# Generated at 2022-06-20 17:21:29.795207
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    This test case verifies if the constructor for class HPUXHardwareCollector works as expected or not.
    """
    test = HPUXHardwareCollector()
    assert test._fact_class == HPUXHardware
    assert test._platform == 'HP-UX'
    assert test.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 17:21:32.925461
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Create an instance of HPUXHardwareCollector
    """
    hpux_hw_collector = HPUXHardwareCollector()
    assert isinstance(hpux_hw_collector, HPUXHardwareCollector)

# Generated at 2022-06-20 17:21:33.809148
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUXHardware().populate()

# Generated at 2022-06-20 17:21:54.407403
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = AnsibleModule(
        argument_spec={},
    )

    test_HPUXHardware = HPUXHardware(module=test_module)
    # unit test for PA-RISC
    test_HPUXHardware.module.run_command = mock_run_command_PA_RISC
    memory_facts = test_HPUXHardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 2048
    assert memory_facts['swaptotal_mb'] == 2160
    assert memory_facts['memfree_mb'] == 100
    assert memory_facts['swapfree_mb'] == 100


# Generated at 2022-06-20 17:21:55.759503
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector()

# Generated at 2022-06-20 17:22:02.033238
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({})
    hw_facts = hw.get_hw_facts({'ansible_distribution': 'HP-UX'})
    assert type(hw_facts['firmware_version']) == str
    assert type(hw_facts['model']) == str
    assert type(hw_facts['product_serial']) == str



# Generated at 2022-06-20 17:22:08.206118
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # empty call to get the module imported (loads platform-dependent code)
    HPUXHardware({})
    # invalid calls
    for collected_facts in [None, {}, {'platform': 'Linux'}]:
        # no exception should be raised
        HPUXHardware.populate(None, collected_facts)
    # valid calls
    for collected_facts in [{'platform': 'HP-UX'}, {'ansible_facts': {'ansible_platform': 'HP-UX'}}]:
        # no exception should be raised
        hw = HPUXHardware.populate(None, collected_facts)
        # TODO: assert that the returned dict has the expected contents

# Generated at 2022-06-20 17:22:12.985216
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()
    assert HPUXHardwareCollector._fact_class == HPUXHardware
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 17:22:17.921450
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware(dict())
    hardware.module.run_command = mock_run_command
    memory_facts = hardware.get_memory_facts(dict())
    assert memory_facts == {'memfree_mb': 10, 'memtotal_mb': 5, 'swaptotal_mb': 7, 'swapfree_mb': 9}



# Generated at 2022-06-20 17:22:24.024513
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    uname_a_result = \
"""HP-UX foo B.11.31 U ia64  1280531051 unlimited-user license
"""

    uname_s_result = 'HP-UX'


# Generated at 2022-06-20 17:22:29.794779
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    m = HPUXHardware({'ANSIBLE_SYSTEM_MODEL': '', 'ANSIBLE_SYSTEM_FULL_NAME': '', 'ANSIBLE_SYSTEM_VERSION': ''})

    # Replace methods to avoid calling function
    def get_hw_facts(self, collected_facts=None):
        collected_facts = collected_facts or {}
        hw_facts = {}
        for k, v in collected_facts.items():
            if k.startswith('ansible_hw_'):
                hw_facts[k] = v
        return hw_facts
    m.get_hw_facts = get_hw_facts.__get__(m, HPUXHardware)

    # get_hw_facts return ansible facts

# Generated at 2022-06-20 17:22:34.613850
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware()

    memory = hardware.get_memory_facts()

    assert memory.get('memtotal_mb') is not None
    assert memory.get('memfree_mb') is not None
    assert memory.get('swaptotal_mb') is not None
    assert memory.get('swapfree_mb') is not None

# Generated at 2022-06-20 17:22:44.856835
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MockModule()
    hpux_hardware = HPUXHardware(module)

    # mock data when machinfo and syslog are working
    hpux_hardware.module.run_command = Mock(return_value=(0, "Firmware revision   : v2.61  @(#) $Revision: v2.61 $", ""))

    facts_data = hpux_hardware.get_hw_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"})
    assert facts_data.get('firmware_version') == 'v2.61'


# Generated at 2022-06-20 17:23:00.573663
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 17:23:12.713638
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Unit test case to test HPUXHardware class.
    """
    facts = dict(platform='HP-UX')
    module = Mock(params=dict(gather_subset='all'), exit_json=Mock(return_value=True))
    set_module_args(dict(gather_subset='all'))
    hardware = HPUXHardware(module)
    hardware.populate(facts=facts)
    assert hardware.memfree_mb == 'NA'
    assert hardware.memtotal_mb == 'NA'
    assert hardware.swapfree_mb == 'NA'
    assert hardware.swaptotal_mb == 'NA'
    assert hardware.processor == 'NA'
    assert hardware.processor_cores == 'NA'
    assert hardware.processor_count == 'NA'

# Generated at 2022-06-20 17:23:15.049488
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector_class = HPUXHardwareCollector()
    hardware_collector_class.get_facts()

# Generated at 2022-06-20 17:23:22.996036
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    module = AnsibleModule(
        argument_spec=dict()
    )

    hw = HPUXHardware(module)

    # Test with a system that sends mamory details to syslog
    syslog = [
        "memory type=Physical size=193948 Kbytes",
        "memory type=Logical size=479213 Kbytes",
        "memory type=Physical size=193948 Kbytes",
    ]
    with patch('ansible.module_utils.facts.hardware.hpux.open') as mock_open:
        mock_open.return_value.__enter__.return_value.read.return_value = "\n".join(syslog)
        memory_facts = hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 191

    # Test with a system where the sys

# Generated at 2022-06-20 17:23:32.313046
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    ansible_facts = {'platform': 'HP-UX',
                     'distribution': 'B.11.23'}
    module = MockModule()
    hardware = HPUXHardware(module)
    hardware.get_hw_facts(collected_facts=ansible_facts)
    assert hardware.facts['model'] == 'ia64 hp server rx2600'
    assert hardware.facts['firmware_version'] == '01.16'



# Generated at 2022-06-20 17:23:42.322353
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = dict({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31', 'ansible_distribution': 'HPUX'})
    hardware_facts_to_check = dict({'processor_count': 2, 'processor': 'Intel Itanium2 family 9000 series processors @ 1600 MHz', 'processor_cores': 2, 'memtotal_mb': 16384, 'memfree_mb': 2895, 'swaptotal_mb': 2048, 'swapfree_mb': 2041})
    hw = HPUXHardware(module=None)
    hardware_facts.update(hw.populate(collected_facts=hardware_facts))
    assert hardware_facts == hardware_facts_to_check

# Generated at 2022-06-20 17:23:54.374958
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)
    collected_facts = dict(
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31',
        ansible_architecture='ia64',
        ansible_system='HP-UX',
    )
    hardware_facts = hardware.populate(collected_facts=collected_facts)

# Generated at 2022-06-20 17:23:56.904093
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = MockModule()
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()
    assert module.fail_json.called

# Generated at 2022-06-20 17:24:05.583849
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command.side_effect = [(0, "1", "")]
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
        }
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 1

    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version']

# Generated at 2022-06-20 17:24:10.230084
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])
    assert hw._fact_class == HPUXHardware

# Generated at 2022-06-20 17:24:28.747074
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('testmodule', (object,), dict(run_command=lambda *args, **kwargs: (0, '', '')))()
    # B.11.11
    collected_facts = dict(ansible_architecture="9000/790", ansible_distribution_version="B.11.11")
    h = HPUXHardware(module)
    cpu_facts = h.get_cpu_facts(collected_facts)
    assert cpu_facts['processor'] == 'PA-RISC 2.0'
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_count'] == 127
    # B.11.23
    collected_facts = dict(ansible_architecture="ia64", ansible_distribution_version="B.11.23")
    h = HPUX

# Generated at 2022-06-20 17:24:39.185876
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    print("test_HPUXHardware_get_memory_facts")
    input_collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    input_out = 'Memory = 4096 MB'
    hw = HPUXHardware(None, '', input_collected_facts)
    hw.module.run_command = Mock(return_value=(0, input_out, ''))
    assert hw.get_memory_facts()['memtotal_mb'] == int(input_out.split(' ')[2])
    assert hw.get_memory_facts()['swaptotal_mb'] == 0

# Generated at 2022-06-20 17:24:43.334185
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    m = HPUXHardwareCollector.factory()
    hardware = m()
    hardware.distribution = 'hpux'
    hardware.architecture = '9000/800'
    hardware.module.run_command = module_run_command
    hardware.get_memory_facts()

# Generated at 2022-06-20 17:24:50.985131
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = (0, "1024", "")
    hardware.collect_platform_subset_facts = MagicMock()
    hardware.collect_platform_subset_facts.return_value = dict(ansible_architecture='9000/800', ansible_distribution_version='B.11.31')
    facts = hardware.populate()
    assert facts['memtotal_mb'] == 0
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0

from ansible.module_utils.facts.hardware.hpu_hpux import HPUXHardware, test_HPUXHardware_populate

# Generated at 2022-06-20 17:25:02.860224
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # First we create a mock module
    module = AnsibleModule(
        argument_spec = dict()
    )
    # Then we create a mock ansible fact with the following informations
    ansible_fact = dict()
    ansible_fact['ansible_architecture'] = '9000/800'
    # Then we create an instance of HPUXHardware with the arguments of the mock module and the mock ansible fact
    hpux_hw = HPUXHardware(module=module, ansible_facts=ansible_fact)
    # Then we use this instance to call the method get_cpu_facts
    rc, out, err = module.run_command("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)
    expected_result = {'processor_count': int(out.strip())}
   

# Generated at 2022-06-20 17:25:12.422058
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    class TestModule(object):
        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''
    module = TestModule()
    class TestHPUXHardware(HPUXHardware):
        module = module
    hw = TestHPUXHardware()
    hw.platform = 'HP-UX'
    hw.distribution = 'HP-UX'
    hw.get_memory_facts = lambda : {'memfree_mb': 1, 'memtotal_mb': 2, 'swapfree_mb': 3, 'swaptotal_mb': 4}
    hw.get_cpu_facts = lambda : {'processor_count': 1, 'processor_cores': 2, 'processor': 'test_processor'}


# Generated at 2022-06-20 17:25:21.882002
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Set up arguments for tests
    collected_facts = {}
    # Execute
    hpu = HPUXHardware()
    cpu_facts = hpu.get_cpu_facts(collected_facts=collected_facts)
    # Assertion
    assert cpu_facts == {}

    collected_facts = {'ansible_architecture': '9000/800'}
    # Execute
    cpu_facts = hpu.get_cpu_facts(collected_facts=collected_facts)
    # Assertion
    assert cpu_facts == {'processor_count': 0}

    collected_facts = {'ansible_architecture': '9000/785'}
    # Execute
    cpu_facts = hpu.get_cpu_facts(collected_facts=collected_facts)
    # Assertion

# Generated at 2022-06-20 17:25:31.820998
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    mock_module = MockModule()
    memory_facts = {'memfree_mb': 123,
                    'memtotal_mb': 456,
                    'swapfree_mb': 789,
                    'swaptotal_mb': 1023}
    cpu_facts = {'processor_count': 2,
                 'processor': 'Itanium',
                 'processor_cores': 4}
    hw_facts = {'model': 'B160L',
                'firmware_version': 'B.11.23',
                'serial_number': '1234'}

    # Adding facts for test
    facts = dict(memory_facts, **cpu_facts)
    facts.update(hw_facts)
    mock_module.run_command.return_value = (0, '', '')


# Generated at 2022-06-20 17:25:39.071187
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """This function is to test the constructor of class HPUXHardwareCollector"""
    hpx_hw = HPUXHardwareCollector()
    assert isinstance(hpx_hw, HardwareCollector)
    assert hpx_hw._platform == 'HP-UX'
    assert hpx_hw.required_facts == set(['platform', 'distribution'])
    assert hpx_hw._fact_class == HPUXHardware



# Generated at 2022-06-20 17:25:45.834104
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(
        argument_spec = dict()
    )
    collectors = [HPUXHardwareCollector]
    obj = HPUXHardware(module=module, collectors=collectors)
    assert type(obj.platform) is str
    assert type(obj.facts) is dict
    assert type(obj.data) is dict
    assert type(obj.collectors) is list
    assert type(obj.module) is AnsibleModule


# Generated at 2022-06-20 17:25:56.118610
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module)
    assert hardware.module == module

# Generated at 2022-06-20 17:26:04.378433
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (object,), {
        'run_command': lambda self, args: (0, '     8 153934 43868  181118    590    205    722  58520', '')
    })
    hphw = HPUXHardware(module)
    facts = hphw.get_memory_facts()
    assert facts['memfree_mb'] == 720
    assert facts['memtotal_mb'] == 38287
    assert facts['swaptotal_mb'] == 181118


# Generated at 2022-06-20 17:26:17.020415
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    result = HPUXHardwareCollector._fact_class(dict(ansible_architecture="9000/800", ansible_distribution_version='B.11.23')).get_cpu_facts()
    assert result == {'processor_count': 2}
    result = HPUXHardwareCollector._fact_class(dict(ansible_architecture="9000/785", ansible_distribution_version='B.11.23')).get_cpu_facts()
    assert result == {'processor_count': 2}
    result = HPUXHardwareCollector._fact_class(dict(ansible_architecture="ia64", ansible_distribution_version='B.11.23')).get_cpu_facts()

# Generated at 2022-06-20 17:26:21.760416
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts = dict()
    module = dict(
        params=dict(
        ),
        run_command=run_command_mock,
        check_mode=False
    )
    hardware_object = HPUXHardware(module)
    result = hardware_object.get_hw_facts(facts)
    assert result == {'model': 'IA64 rx2800 i2', 'firmware_version': "B.11.23.2087.13.0.2.2",
                     'product_serial': 'ABC123'}



# Generated at 2022-06-20 17:26:24.999260
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware(dict(platform='HP-UX', distribution='B.11.31'))

    assert h.platform == 'HP-UX'
    assert h.fact_class == HPUXHardware



# Generated at 2022-06-20 17:26:33.573039
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils import basic
    collect_test_data = basic.AnsibleModule(argument_spec={}, supports_check_mode=False)
    test_hw = HPUXHardware(collect_test_data)

    def mock_command(self, args, use_unsafe_shell=False):
        class MockException(Exception):
            pass

        if 'vmstat' in args:
            return (0, '0 0 0 0 0 0 0 0 0 0 0', '')
        if 'kmem' in args:
            return (0, 'phys_mem_pages/D = 0x0000000000100000', '')
        if 'swapinfo' in args:
            return (0, '0', '')

# Generated at 2022-06-20 17:26:43.760330
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    class ModuleFake(object):
        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "/usr/bin/vmstat | tail -1":
                vmstat_output = " r b w  swap  free  re  mf pi po fr de sr s0 s1 s2 s3 in sy cs us sy id 0 0 0 " \
                                "3574508 482872 5587 0 3 3 0 0 0 0 72 0 0 0 0 2164 536 2182 0 " \
                                "0 99"
                return 0, vmstat_output, ""

            if cmd == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'":
                return 0, "2729472", ""
           

# Generated at 2022-06-20 17:26:54.508960
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import pytest
    from units.compat.mock import MagicMock, patch
    from ansible.module_utils.facts.hardware.hpu_ux import HPUXHardware
    from ansible.module_utils.facts.collector import FactsCollector

    module = MagicMock()
    module.run_command.return_value = (0, "", "")
    hpu = HPUXHardware(module=module)
    hpu.collector = FactsCollector(module=module, platform='HP-UX')
    hpu.collector.get_ansible_facts.return_value = {'os_family': 'HP-UX'}
    rc, out, err = module.run_command.return_value
    hpu.get_memory_facts()


# Generated at 2022-06-20 17:26:59.015433
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Mock collected_facts
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.params = {}
    collected_facts = {u'ansible_architecture': '9000/800', u'ansible_distribution_version': 'B.11.23', u'ansible_distribution': 'HP-UX'}
    # Create and run test instance of method
    h = HPUXHardware(module=module)

    cpu_facts = h.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts.get('processor_count') == 10
    assert cpu_facts.get('processor_cores') == 10


# Generated at 2022-06-20 17:27:05.963323
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_hw = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    hpux_hw.populate()
    assert hpux_hw.facts['processor_count'] == 2
    assert hpux_hw.facts['processor'] == 'Intel(R) Itanium(R) Processor 9500 series'
    assert hpux_hw.facts['processor_cores'] == 32
    assert hpux_hw.facts['memtotal_mb'] == 24576
    assert hpux_hw.facts['swaptotal_mb'] == 6144
    assert hpux_hw.facts['firmware_version'] == 'B.11.31'


# Generated at 2022-06-20 17:27:26.306754
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeHPUXAnsibleModule()

    hw = HPUXHardware(module)
    collected_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX',
        'distribution_version': 'B.11.31',
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
    }

    # HPUXHardwareCollector.get_hw_facts should call hw.get_hw_facts with the 'collected_facts' provided
    module.run_command.assert_called_with("model")

# Generated at 2022-06-20 17:27:37.622028
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeModule()

    # B.11.31 ia64, machinfo with `cores`
    module.ansible_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    module.run_command = lambda cmd, pty: fake_run_command(cmd, module.run_command_mock_result, test_machinfo_cores)

    hpux_hardware = HPUXHardware(module)
    result = hpux_hardware.get_cpu_facts()

    assert result['processor'] == 'Intel(R) Itanium(R) Processor'
    assert result['processor_cores'] == 2
    assert result['processor_count'] == 2

    # B.11.31 ia64, machinfo with `socket`


# Generated at 2022-06-20 17:27:40.802017
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware({'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'})
    facts = hw.get_memory_facts()
    assert facts['swaptotal_mb'] == 0
