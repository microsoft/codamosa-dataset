

# Generated at 2022-06-20 17:17:52.390693
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector()
    assert hwc._fact_class == HPUXHardware

# Generated at 2022-06-20 17:17:54.985829
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    module = CustomModule()
    hpux_hw = HPUXHardware(module)

    assert hpux_hw.platform == 'HP-UX'


# Generated at 2022-06-20 17:18:04.453271
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_object = HPUXHardware()

    def mock_run_command(self, args, use_unsafe_shell=False):
        if args == 'model':
            out = 'ia64 hp server rx4640'
            return 0, out, None
        elif args == '/usr/contrib/bin/machinfo |grep -i Firmware revision | grep -v BMC':
            out = 'Firmware revision = : 0.0.0.0'
            return 0, out, None
        elif args == '/usr/contrib/bin/machinfo |grep -i Machine serial number ':
            out = 'Machine serial number = : 123456789'
            return 0, out, None

    test_object.get_hw_facts = mock_run_command
    assert test_object.get_hw_facts

# Generated at 2022-06-20 17:18:15.370162
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_collector = HPUXHardwareCollector(module=module)
    hardware_collector.collect()
    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=module.params['ansible_facts'])
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) CPU 9340 @ 1.60GHz'
    assert cpu_facts['processor_cores'] == 8
    cpu_facts = hardware.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert cpu_facts['processor_count'] == 1



# Generated at 2022-06-20 17:18:23.217593
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule({})
    hpux_hw = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    res = hpux_hw.get_memory_facts(collected_facts=collected_facts)
    assert res.get('memtotal_mb') is not None
    assert res.get('swaptotal_mb') == 0

# Generated at 2022-06-20 17:18:34.892192
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    collected_facts = {
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23',
        'ansible_architecture': 'ia64',
        'ansible_machine': 'ia64',
        'ansible_os_family': 'HP-UX'
    }
    instance = HPUXHardware(module, collected_facts)
    instance.module.run_command = mock.Mock(return_value=(0, '', ''))
    instance.get_cpu_facts(collected_facts)

# Generated at 2022-06-20 17:18:37.658343
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module=module)
    hw.populate()


# Generated at 2022-06-20 17:18:39.006595
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    assert issubclass(HPUXHardware, Hardware)


# Generated at 2022-06-20 17:18:51.255211
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    facts = module.ansible_facts
    hardware = HPUXHardware(module)
    hardware.populate(facts)
    assert facts['processor'] == 'Intel(R) Itanium(R) 9300 series CPU @ 1.73GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_count'] == 4
    assert facts['memtotal_mb'] == 66504
    assert facts['memfree_mb'] == 39071
    assert facts['swaptotal_mb'] == 6727
    assert facts['swapfree_mb'] == 6700
    assert facts['model'] == 'ia64 hp 9000 Superdome'
    assert facts['firmware'] == 'HP-UX Superdome B.11.31 U ia64'


# Generated at 2022-06-20 17:18:57.720183
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = type('module', (object,), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    collected_facts = type('Facts', (object,), {})()
    collected_facts.ansible_architecture = 'ia64'
    collected_facts.ansible_distribution_version = 'B.11.31'
    HPUXHardware(module).populate(collected_facts)

# Generated at 2022-06-20 17:19:14.439534
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({})
    collected_facts = {'platform': 'HP-UX', 'ansible_architecture': 'ia64'}
    result = hardware.get_hw_facts(collected_facts)
    assert result['firmware_version'] == 'HPI 1.35'
    assert result['product_serial'] == 'CZF15203J1'
    assert result['model'] == 'ia64 hp integrity bl860c'



# Generated at 2022-06-20 17:19:18.066954
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # GIVEN
    class MockModule(object):
        pass
    module = MockModule()
    module.params = {'gather_subset': 'all'}

    # WHEN
    HPUXHardwareCollector(module)

    # THEN



# Generated at 2022-06-20 17:19:31.347399
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    hardware = HPUXHardware(module)
    collected_facts = {}
    collected_facts['platform'] = 'HP-UX'
    collected_facts['ansible_architecture'] = '9000/800'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    hardware.populate(collected_facts=collected_facts)
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 5
    assert hardware.facts['processor'] == 'Intel(r) Itanium(r) Processor 9320'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 509

# Generated at 2022-06-20 17:19:44.073036
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = type('', (), {})
    test_module.run_command = lambda x: [0, '1\n', '']
    test_module.params = type('', (), {})
    test_module.params.update({'fact_path': '', 'gather_subset': 'all'})
    facts = HPUXHardwareCollector(test_module).collect()
    assert 'processor_count' in facts

    test_module.run_command = lambda x: [0, '2\n', '']
    test_module.params = type('', (), {})
    test_module.params.update({'fact_path': '', 'gather_subset': 'all'})
    facts = HPUXHardwareCollector(test_module).collect()
    assert 'processor_cores' in facts

# Generated at 2022-06-20 17:19:47.895377
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = FakeAnsibleModule()
    hardware_facts = HPUXHardware()
    hardware_facts.populate()


if __name__ == '__main__':
    test_HPUXHardware()

# Generated at 2022-06-20 17:19:55.319694
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    module.params = {'gather_subset': ['all']}
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31',
    )
    hwCollector = HPUXHardwareCollector(module=module)
    hwFacts = hwCollector.collect(module=module, collected_facts=collected_facts)
    assert hwFacts['processor_count'] == 4
    assert hwFacts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert hwFacts['processor_cores'] == 4
    assert hwFacts['memfree_mb'] == 4

# Generated at 2022-06-20 17:20:08.398672
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """Unit test for the get_memory_facts of HPUXHardware"""

    class TestModule(object):
        def __init__(self):
            self.run_command_counter = 0
            self.RUN_COMMAND_RESULT = [0, "100", ""]

        def run_command(self, module_args, use_unsafe_shell=False):
            self.run_command_counter += 1
            # Test different values of the memfree output
            if self.run_command_counter == 1:
                self.RUN_COMMAND_RESULT[1] = "100"
            if self.run_command_counter == 2:
                self.RUN_COMMAND_RESULT[1] = "200"

            return self.RUN_COMMAND_RESULT

    hardware = HPUXHardware

# Generated at 2022-06-20 17:20:21.451714
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    memory_facts = {'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0}
    hpu = HPUXHardware({'ansible_architecture': 'ia64'})

    rc, out, err = hpu.module.run_command("/usr/sbin/swapinfo -m -d -f -q")
    memory_facts['swaptotal_mb'] = int(out.strip())
    rc, out, err = hpu.module.run_command("/usr/sbin/swapinfo -m -d -f | egrep '^dev|^fs'", use_unsafe_shell=True)
    swap = 0

# Generated at 2022-06-20 17:20:27.801289
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModuleMock()
    hphw = HPUXHardware(module=module)

    # Check that the platform is set correctly
    assert hphw.platform == 'HP-UX'

    assert hphw.populate() == {}



# Generated at 2022-06-20 17:20:29.319413
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = HPUXHardware(dict())
    assert type(module) == HPUXHardware

# Generated at 2022-06-20 17:20:46.162784
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_facts = HPUXHardwareCollector.collect()

    keys = [
            'memfree_mb',
            'memtotal_mb',
            'swapfree_mb',
            'swaptotal_mb',
            'processor',
            'processor_cores',
            'processor_count',
            'model',
            'firmware_version'
           ]

    for k in keys:
        assert k in hardware_facts


# Generated at 2022-06-20 17:20:51.134454
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        ),
        supports_check_mode=True
    )

    hardware_collector = HPUXHardwareCollector(module=module)
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:20:54.979793
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    # When required facts are missing from the parameter 'collected_facts' raises UnsupportedHardwareException
    hw.get_facts(collected_facts={})

# Generated at 2022-06-20 17:20:57.303657
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Test specific code for get_cpu_facts of class HPUXHardware
    pass


# Generated at 2022-06-20 17:21:03.915630
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    module.run_command = MagicMock(return_value=(0, '3', ''))
    hardware_facts = hardware.populate(collected_facts={'ansible_architecture': '9000/800'})
    assert hardware_facts['processor_count'] == 3

# Generated at 2022-06-20 17:21:11.603306
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hw = HPUXHardware()
    hw.module = module
    hw.populate()

    assert hw.module.run_command.call_count == 7
    hw.module.run_command.assert_any_call("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)
    hw.module.run_command.assert_any_call("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    hw.module.run_command.assert_any_call("grep Physical /var/adm/syslog/syslog.log")

# Generated at 2022-06-20 17:21:16.991302
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    ansible_architecture = '9000/785'
    module = MagicMock(ansible_architecture=ansible_architecture)
    hardware = HPUXHardware(module=module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 32

# Generated at 2022-06-20 17:21:26.330848
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class ModuleStub:
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "", ""

    class TestFacts:
        def __init__(self):
            self.ansible_facts = {'ansible_architecture': 'ia64'}

    collected_facts = TestFacts()
    module = ModuleStub()

    hphardware = HPUXHardware(module)
    hphardware.populate(collected_facts.ansible_facts)

    hphardware.get_memory_facts()

# Generated at 2022-06-20 17:21:30.209158
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_class = HPUXHardware(None)
    d = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    test_class.get_hw_facts(collected_facts=d)

# Generated at 2022-06-20 17:21:40.898675
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module=test_module)

    # Test for 9000/800
    test_module.run_command = MagicMock()
    collected_facts = {'ansible_architecture': '9000/800'}
    test_module.run_command.return_value = (0, '1', '')
    result = hw.get_cpu_facts(collected_facts)
    assert result == {'processor_count': 1}

    # Test for 9000/785
    test_module.run_command = MagicMock()
    collected_facts = {'ansible_architecture': '9000/785'}
    test_module.run_command.return_value = (0, '1', '')
    result = hw

# Generated at 2022-06-20 17:21:58.336617
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == "HP-UX"
    assert hw.populate()['memtotal_mb'] > 0
    assert hw.populate()['memfree_mb'] > 0
    assert hw.populate()['processor_cores'] > 0
    assert hw.populate()['memtotal_mb'] >= hw.populate()['memfree_mb']
    assert hw.populate()['swaptotal_mb'] >= hw.populate()['swapfree_mb']

# Generated at 2022-06-20 17:22:07.436944
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts import FactCollector

    class ModuleFake:
        def __init__(self):
            self._ansible_facts = {}
            self._ansible_facts['architecture'] = 'ia64'
            self._ansible_facts['distribution'] = 'HP-UX'
            self._ansible_facts['distribution_version'] = 'B.11.31'
        def run_command(self, cmd, use_unsafe_shell=False):
            # Method run_command always returns a tuple
            return 1, '', ''

    class FactsCollectorFake:
        def __init__(self):
            self.collectors = [HPUXHardwareCollector]
            self.collected_facts = {}
            self.collected_facts['platform'] = 'HP-UX'


# Generated at 2022-06-20 17:22:16.981657
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec={}
    )
    facts = dict(
        distribution='HP-UX',
        ansible_architecture='ia64',
        ansible_distribution_version='B.11.31'
    )
    hw_fact_ret = dict(
        firmware_version="HPI C.03.10",
        product_serial="CNU123456"
    )

    # Unit test with default values
    obj = HPUXHardware(module)
    hw_facts = obj.get_hw_facts(facts)
    assert hw_facts == hw_fact_ret



# Generated at 2022-06-20 17:22:21.996351
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.exit_json = lambda x: x
    test_module.run_command = mock.Mock(return_value=(0, '', ''))

    test_HPUXHardware = HPUXHardware(test_module)
    test_facts = test_HPUXHardware.populate()
    assert test_facts['memtotal_mb'] == test_facts['memfree_mb'] + test_facts['swaptotal_mb']

# Generated at 2022-06-20 17:22:32.107484
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    req_facts = set(['platform', 'distribution'])
    collected_facts = {'ansible_architecture': '9000/785',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.31'}
    hw = HPUXHardware(req_facts, collected_facts)
    assert hw.platform == 'HP-UX'

    # Facts that should be available to HPUXHardware
    available_facts = set([
        'processor',
        'processor_cores',
        'processor_count',
        'memfree_mb',
        'memtotal_mb',
        'swapfree_mb',
        'swaptotal_mb',
        'model',
        'firmware'
    ])

    assert hw.available_facts

# Generated at 2022-06-20 17:22:36.272002
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    hw = HPUXHardwareCollector(module=module)
    hw.populate()

    assert(hw.facts['memtotal_mb'] >= 0)
    assert(hw.facts['swaptotal_mb'] >= 0)

# Generated at 2022-06-20 17:22:49.404846
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Create an instance of class HPUXHardware
    test_HPUXHardware = HPUXHardware()
    # test_HPUXHardware._module = MockModule(ansible_facts={'ansible_architecture': '9000/800'})
    # test_HPUXHardware.get_cpu_facts()
    # test_HPUXHardware._module = MockModule(ansible_facts={'ansible_architecture': '9000/785'})
    # test_HPUXHardware.get_cpu_facts()
    # test_HPUXHardware._module = MockModule(ansible_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    # test_HPUXHardware.get_cpu_facts()
    # test_HPU

# Generated at 2022-06-20 17:22:54.014899
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Intialize Hardware object
    h = HPUXHardware({'ANSIBLE_MODULE_ARGS': {'gather_subset': 'all', 'gather_timeout': 10}})
    # Call get_memory_facts
    h.get_memory_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})

# Generated at 2022-06-20 17:23:00.039166
# Unit test for method get_memory_facts of class HPUXHardware

# Generated at 2022-06-20 17:23:09.127131
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class TestModule(object):
        def run_command(self, command, use_unsafe_shell=True):
            return (0, 'system is a Itanium ia64\n', '')
    hw = HPUXHardware(TestModule())
    result = hw.get_hw_facts({'ansible_architecture': 'ia64'})
    assert result['model'] == 'Itanium ia64'
    assert result['firmware_version'] == 'HP-UX B.11.31 U ia64 1436027989'
    assert result['product_serial'] == 'ABCDEFABCDEFABCDEFABCDEF'

# Generated at 2022-06-20 17:23:36.766406
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    hw = HPUXHardware(module)
    # Test collecting facts on HP-UX 11.31
    collected_facts = dict(ansible_architecture='ia64',
                           ansible_distribution_version='B.11.31')
    cpu_facts = hw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor_count'] == 2
    # Test collecting facts on HP-UX B.11.23
    collected_facts = dict(ansible_architecture='ia64',
                           ansible_distribution_version='B.11.23')
    cpu_facts = hw.get_cpu_facts(collected_facts)

# Generated at 2022-06-20 17:23:38.347072
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware().populate()
    assert hardware_facts['processor_count'] == hardware_facts['processor_cores'] * hardware_facts['processor_count']

# Generated at 2022-06-20 17:23:46.185523
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import ansible.module_utils.facts.hardware.hpux
    from ansible.module_utils.facts.collector import FactsCollector

    ansible.module_utils.facts.hardware.hpux.HPUXHardware.module = AnsibleFakeModule()

    facts_collector = FactsCollector()
    collected_facts = facts_collector.collect(["hardware"], gather_subset=["!all", "!min"], min_facts=dict())

    hpux = ansible.module_utils.facts.hardware.hpux.HPUXHardware('HP-UX', collected_facts['ansible_architecture'], collected_facts['ansible_distribution'], collected_facts['ansible_distribution_version'])

# Generated at 2022-06-20 17:23:55.674013
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = MockModule()
    hw._get_distribution = Mock(return_value='HP-UX')
    hw._get_platform = Mock(return_value='ia64')
    hw._get_distribution_version = Mock(return_value='B.11.23')
    hw._get_architecture = Mock(return_value='ia64')
    hw.get_hw_facts()
    assert 'firmware_version' in hw.all_facts
    assert 'product_serial' in hw.all_facts


# Generated at 2022-06-20 17:24:04.235694
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_facts = HPUXHardware()
    assert hpux_facts.platform == 'HP-UX'
    assert hpux_facts.populate() == {
        'memtotal_mb': 1024,
        'processor': 'Intel(R) Itanium(R) Processor',
        'processor_count': 4,
        'processor_cores': 2,
        'memfree_mb': 896,
        'swapfree_mb': 0,
        'swaptotal_mb': 1,
        'model': 'HP 9000 rp2470',
        'firmware_version': 'B.11.11',
        'product_serial': '123456789'
    }



# Generated at 2022-06-20 17:24:12.265380
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'B132L', None)
    hw = HPUXHardware()
    hw.module = module
    result = hw.get_hw_facts()
    assert(result['model'] == 'B132L')
    assert(result['firmware_version'] == 'C.7.8.0')
    assert(result['product_serial'] == 'ABCDEFG')


# Generated at 2022-06-20 17:24:17.091355
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    hpux_hardware = HPUXHardware()
    hpux_hardware_data = HPUXHardwareCollector.collect(hpux_hardware, {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'})

    assert hpux_hardware_data['processor_count'] == 2

# Generated at 2022-06-20 17:24:24.544098
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (), {})()
    setattr(module, 'run_command', lambda *args, **kwargs: (0, " ", ""))
    hardware = HPUXHardware(module=module)
    facts = hardware.get_memory_facts()
    assert facts['memfree_mb']
    assert facts['memtotal_mb']
    assert facts['swaptotal_mb']
    assert facts['swapfree_mb']

# Generated at 2022-06-20 17:24:29.697598
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MockModule()
    hphw = HPUXHardware(module=module)
    rc, out, err = hphw.module.run_command("model")
    hw_facts = hphw.get_hw_facts()
    assert out.strip() == hw_facts['model']



# Generated at 2022-06-20 17:24:40.847267
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_collector = HPUXHardwareCollector()
    hardware = hardware_collector._fact_class({})

    hardware_facts = hardware.populate()

    assert hardware_facts.get('processor') is not None
    assert hardware_facts.get('processor_cores') is not None
    assert hardware_facts.get('processor_count') is not None
    assert hardware_facts.get('memfree_mb') is not None
    assert hardware_facts.get('memtotal_mb') is not None
    assert hardware_facts.get('swapfree_mb') is not None
    assert hardware_facts.get('swaptotal_mb') is not None
    assert hardware_facts.get('model') is not None
    assert hardware_facts.get('firmware') is not None

# Generated at 2022-06-20 17:25:21.522294
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    facts = {}
    facts = hardware_obj.populate(facts)

    assert facts['processor'] == 'Intel Itanium processor'
    assert facts['processor_count'] == 8
    assert facts['processor_cores'] == 4
    assert facts['memtotal_mb'] == 16392
    assert facts['memfree_mb'] == 4007
    assert facts['swaptotal_mb'] == 7892
    assert facts['swapfree_mb'] == 5498
    assert facts['ansible_architecture'] == 'ia64'
    assert facts['ansible_distribution'] == 'hpux'
    assert facts['ansible_distribution_version'] == 'B.11.31'

# Generated at 2022-06-20 17:25:23.616265
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware(dict(ansible_facts=dict(ansible_architecture='ia64',
                                              ansible_distribution_version='B.11.31')))
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:25:30.118739
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # setup the test
    module = AnsibleModule({
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.23"})

    # get the class object
    obj = HPUXHardware(module=module)

    # test method
    hw_facts = obj.get_hw_facts()

    # validate results
    module.exit_json(changed=False, ansible_facts={'hardware': hw_facts})



# Generated at 2022-06-20 17:25:37.993671
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hpuxtopas import HPUXHardware
    h = HPUXHardware()
    # Test with collected_facts = None
    cpu_facts = h.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts



# Generated at 2022-06-20 17:25:42.250843
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:25:50.705611
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    chipset = 'pa-risc'
    cpu = HPUXHardware(module=module, chipset=chipset)
    facts = {}
    facts['ansible_distribution_release'] = 'B.11.31'
    facts['ansible_distribution_version'] = 'B.11.23'
    facts['ansible_architecture'] = 'ia64'
    cpu_facts = cpu.get_cpu_facts(facts)
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9350'
    assert cpu_facts['processor_cores'] == 4

# Generated at 2022-06-20 17:25:57.726641
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts import FactManager

    manager = FactManager()
    hw = HPUXHardware(dict(manager.module._entries))

# Generated at 2022-06-20 17:25:59.843008
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector(None)
    assert h._fact_class.platform == 'HP-UX'

# Generated at 2022-06-20 17:26:02.438626
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_fact_loader = HPUXHardwareCollector()
    assert hpux_fact_loader.platform == 'HP-UX'

# Generated at 2022-06-20 17:26:04.931429
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module_mock = AnsibleModuleMock()
    hardware = HPUXHardware(module=module_mock)
    hardware.populate()


# Generated at 2022-06-20 17:27:11.177514
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    obj = HPUXHardwareCollector()
    assert repr(obj) == '<HPUXHardwareCollector>'
    assert obj.required_facts == set(['platform', 'distribution'])
    assert obj.platform == 'HP-UX'
    assert obj.fact_class == HPUXHardware


# Generated at 2022-06-20 17:27:14.462678
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hc = HPUXHardwareCollector()
    h = hc.collect()[0]
    cpu_facts = h.get_cpu_facts()
    assert type(cpu_facts['processor_count']) == int


# Generated at 2022-06-20 17:27:26.520714
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_hardware_ins = HPUXHardware(dict())
    hpux_hardware_ins.module.run_command = _run_command
    hpux_hardware_ins.module.fail_json = _fail_json

    collected_facts = {
        'architecture': 'ia64',
        'distribution_version': 'B.11.23'
    }
    hpux_hardware_ins.populate(collected_facts)

    collected_facts = {
        'architecture': 'ia64',
        'distribution_version': 'B.11.31'
    }
    hpux_hardware_ins.populate(collected_facts)

    collected_facts = {
        'architecture': '9000/800'
    }
    hpux_hardware_ins.populate

# Generated at 2022-06-20 17:27:36.750571
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Testing get_hw_facts() method with B.11.23
    module = AnsibleModule(argument_spec={})
    set_module_args(dict(
        ansible_facts=dict(
            distribution="HP-UX",
            distribution_version="B.11.23",
            ansible_architecture="ia64")
    ))
    module.exit_json(changed=False, ansible_facts=dict(
        ansible_distribution="HP-UX",
        ansible_distribution_version="B.11.23",
        ansible_architecture="ia64"
    ))
    hpu = HPUXHardware(module)