

# Generated at 2022-06-20 17:18:03.097375
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    collected_facts = dict(platform='HP-UX',
                           distribution=dict(version='B.11.31', major_version='B', minor_version='11', id='HP-UX'))

    # Test on ia64
    collected_facts['ansible_architecture'] = 'ia64'
    # Test on B.11.23_64
    collected_facts['ansible_distribution_version'] = "B.11.23"
    hw._module = MockModule()
    hw.get_cpu_facts(collected_facts)
    # Test on B.11.23_64
    collected_facts['ansible_distribution_version'] = "B.11.31"
    hw._module = MockModule()

# Generated at 2022-06-20 17:18:14.021708
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {
        'ansible_architecture': '9000/785',
        'ansible_distribution_version': 'B.11.11',
    }
    hardware = HPUXHardware(module=None, collected_facts=collected_facts)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor_count' in cpu_facts

    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    hardware = HPUXHardware(module=None, collected_facts=collected_facts)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor_cores' in cpu_facts



# Generated at 2022-06-20 17:18:17.527603
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware(dict())
    assert isinstance(h.facts, dict)
    assert isinstance(h.module, object)


# Generated at 2022-06-20 17:18:28.800954
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    # emulate output from vmstat command
    class Vmstat(object):
        def __init__(self, code=0, out='', err=''):
            self.code = code
            self.out = out
            self.err = err

        def run_command(self, cmd, data=None, check_rc=True, use_unsafe_shell=True):
            return self.code, self.out, self.err

    # emulate output from grep command
    class Grep(object):
        def __init__(self, code=0, out='', err=''):
            self.code = code
            self.out = out
            self.err = err


# Generated at 2022-06-20 17:18:31.765700
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = HPUXHardware(module)
    assert hardware_obj.platform == 'HP-UX'



# Generated at 2022-06-20 17:18:43.234097
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    '''
    Test HPUXHardware.populate()
    '''

    # Test with ansible_architecture='9000/800'
    HPUXHardware._get_cpu_facts = MagicMock(
        return_value={'processor_count': 2, 'processor_cores': 0, 'processor': 'Intel(R) Itanium(R) Processor'})
    HPUXHardware._get_memory_facts = MagicMock(
        return_value={'memfree_mb': 259, 'memtotal_mb': 1024, 'swapfree_mb': 0, 'swaptotal_mb': 0})
    HPUXHardware._get_hw_facts = MagicMock(return_value={'model': 'ia64 hp server rx2600', 'firmware_version': '01.54'})

# Generated at 2022-06-20 17:18:54.415969
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Test case 1 - HP-UX 11.31 ia64
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution="HP-UX",
        ansible_distribution_version="B.11.31",
        platform='HP-UX'
    )
    expected_result = dict(
        model="hp rx2800 i4",
        firmware_version="3.00",
        product_serial="123ABC",
        ansible_architecture='ia64',
        ansible_distribution="HP-UX",
        ansible_distribution_version="B.11.31",
        platform='HP-UX'
    )
    module = AnsibleModuleMock(collected_facts=collected_facts)
    hardware = HPUXHardware(module)

# Generated at 2022-06-20 17:19:03.390147
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module)
    # Mock out the commands and responses
    module.run_command.side_effect = [(0, "HP-UX bdf B.11.31 U ia64 5146552799", ""),
                                      (0, "HP-UX bdf B.11.23 U ia64 5146552799", ""),
                                      (0, "", ""),
                                      (0, "", ""),
                                      (0, "", "")]
    assert hardware.get_hw_facts() == {'model': 'HP-UX bdf B.11.31 U ia64 5146552799'}
    assert hardware.get_hw_facts() == {}
    assert hardware.get_hw_facts() == {}
    assert hardware.get_hw

# Generated at 2022-06-20 17:19:15.463699
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware({}, {})
    hardware.module = {}
    hardware.module.run_command = lambda x, **kwargs: (0, "", "")
    hardware.module.get_bin_path = lambda x: "/bin/%s" % x
    hardware.module.check_requiremets = lambda x: True
    hardware.module.get_required_version = lambda x: True
    hardware.module.get_required_platform = lambda x: True

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"}

# Generated at 2022-06-20 17:19:23.418075
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware_facts_instance = HPUXHardware(module)
    collected_facts = dict(ansible_architecture='9000/785',ansible_distribution='HP-UX',ansible_distribution_version='B.11.31')
    hardware_facts = hardware_facts_instance.populate(collected_facts=collected_facts)
    assert hardware_facts.get('firmware_version') == '02.52'
    assert hardware_facts.get('model') == 'rp3440'
    assert hardware_facts.get('memtotal_mb') == '2048'
    assert hardware_facts.get('swaptotal_mb') == '3'

# Generated at 2022-06-20 17:19:45.754314
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Constructor test case.
    """
    def mock_module_run_command(self, cmd):
        return 123, "cmd", "err"

    def mock_facts(self):
        facts = {}
        facts['platform'] = 'HP-UX'
        facts['distribution'] = 'a'
        facts['distribution_version'] = 'b'
        return facts

    fake_module = type('FakeModule', (object,), {
        'run_command': mock_module_run_command,
        '_COLLECT_FACTS': {
            'server': False,
            'hardware': True
        }
    })
    fake_module.facts = mock_facts

    # test
    collector = HPUXHardwareCollector(fake_module)

    assert collector.platform == 'HP-UX'

# Generated at 2022-06-20 17:19:50.061092
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    hardware.populate()

# Generated at 2022-06-20 17:19:55.307535
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware({})
    results = hw.get_memory_facts()
    assert 'memfree_mb' in results
    assert 'memtotal_mb' in results
    assert 'swaptotal_mb' in results
    assert 'swapfree_mb' in results



# Generated at 2022-06-20 17:20:02.331297
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module)

    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-20 17:20:12.039023
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    mock_module = Mock()
    facts = dict(ansible_fqdn='vm1.example.org', ansible_architecture='9000/800')
    hw = HPUXHardware(mock_module)
    assert hw.populate() == dict(processor_count=2,
                                 memfree_mb=304,
                                 memtotal_mb=8192,
                                 swapfree_mb=10048,
                                 swaptotal_mb=10048,
                                 model='ia64 hp server rx2660',
                                 firmware_version='1.10',
                                 product_serial='USC12119V1')



# Generated at 2022-06-20 17:20:21.132661
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({})
    collected_facts = {'ansible_distribution': 'HP-UX', 'ansible_architecture': 'ia64'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['firmware_version'] == 'B.11.11.0813'
    assert hw_facts['product_serial'] == 'USCN01861Q'

# Generated at 2022-06-20 17:20:33.731332
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # test with an HP-UX B.11.23 ia64
    hw = HPUXHardware(dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23'))
    cpu_facts = hw.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel Itanium 2'
    assert cpu_facts['processor_cores'] == 1
    # test with an HP-UX B.11.31 ia64
    hw = HPUXHardware(dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31'))
    cpu_facts

# Generated at 2022-06-20 17:20:35.257876
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:20:45.348796
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_instance = HPUXHardware()
    hw_information = hardware_instance.populate()

    assert hw_information['processor_count'] == 2
    assert hw_information['processor_cores'] == 4
    assert hw_information['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hw_information['memtotal_mb'] == 60928
    assert hw_information['memfree_mb'] == 918
    assert hw_information['swapfree_mb'] == 1140
    assert hw_information['swaptotal_mb'] == 12288
    assert hw_information['model'] == 'ia64 hp server rx7620'
    assert hw_information['firmware_version'] == '1244'


# Generated at 2022-06-20 17:20:52.024768
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h = HPUXHardware()
    h.module = MockModule()
    h.fact_class = MockFactClass()
    h.collector = MockCollector()
    # if machine is ia64
    # if machine is B.11.23
    h.collector.facts = {'ansible_distribution_version': 'B.11.23', 'ansible_architecture': 'ia64'}
    assert h.get_hw_facts(collected_facts={'ansible_architecture': 'ia64'}) == {'firmware_version': '3.1.1',
                                                                                'model': 'HP Integrity rx7640 Server'}
    # if machine is B.11.31

# Generated at 2022-06-20 17:21:04.804336
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
    }
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = (0, "9", "")
    hardware.populate(collected_facts)

# Generated at 2022-06-20 17:21:11.845362
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {'ansible_architecture': 'ia64'}
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}
    hardware_collector = HPUXHardwareCollector(module=module)
    hardware = hardware_collector.collect(facts)

    assert hardware.get_cpu_facts(collected_facts=facts) == {'processor': 'Intel(R) Itanium(R) Processor 9350', 'processor_cores': 8, 'processor_count': 8}
    assert hardware.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'}) == {'processor_count': 12}

# Generated at 2022-06-20 17:21:24.088385
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # HPUXHardware class from Ansible's hpux_facts module
    obj = HPUXHardware()
    # assert that all variables are initialized with expected values
    assert obj.platform == 'HP-UX'
    assert obj.memfree_mb == 0
    assert obj.memtotal_mb == 0
    assert obj.swapfree_mb == 0
    assert obj.swaptotal_mb == 0
    assert obj.processor == ''
    assert obj.processor_cores == 0
    assert obj.processor_count == 0
    assert obj.model == ''
    assert obj.firmware == ''
    # assert that all the required methods of class Hardware are implemented in class HPUXHardware
    assert obj.populate() == obj.get_cpu_facts() or obj.get_memory_facts() or obj.get_hw_facts()




# Generated at 2022-06-20 17:21:33.140719
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test case for get_cpu_facts of class HPUXHardware
    """
    # Arrange
    result = {}
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware_collector = HPUXHardwareCollector()

    # Act
    # Collect method put {'processor_count': 16}
    hardware_collector._collect()

    result = hardware_collector.get_cpu_facts(collected_facts)

    # Assert
    assert result.get('processor_count') == 16, "Expected 16, got %s" % result.get('processor_count')


# Generated at 2022-06-20 17:21:38.024813
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware().get_hw_facts()
    assert 'model' in hw_facts
    assert 'firmware_version' in hw_facts



# Generated at 2022-06-20 17:21:41.995305
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware(dict())
    assert h.platform == 'HP-UX'
    assert h.facts == {}

    # test the populate() method
    h.populate()
    assert h.facts['platform'] == 'HP-UX'

# Generated at 2022-06-20 17:21:51.928806
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hpu = HPUXHardware(module)
    # For HP-UX (B.11.31) test
    collected_facts = {'ansible_distribution_version': 'B.11.31'}
    assert hpu.get_hw_facts(collected_facts) == {'model': 'ia64 hp server', 'product_serial': 'CZC565045H', 'firmware_version': 'v3.60'}
    # For HP-UX (B.11.23) test
    collected_facts = {'ansible_distribution_version': 'B.11.23'}

# Generated at 2022-06-20 17:22:03.971914
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)

    rc, out, err = module.run_command("/usr/contrib/bin/machinfo")
    if err:
        #  If machinfo not available use default facts
        rc, out, err = module.run_command("model")

# Generated at 2022-06-20 17:22:16.777065
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """Testing method get_hw_facts of class HPUXHardware"""
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = HPUXHardware()
    hardware.module = module
    answer = {}

    # No value
    rc, out, err = run_command_mock(["model"])
    answer['model'] = out.strip()
    rc, out, err = run_command_mock(["/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", "", ""])
    answer['firmware_version'] = out.split(':')[1].strip()

# Generated at 2022-06-20 17:22:28.247815
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_mach = HPUXHardware(dict(ansible_facts=dict(ansible_architecture='ia64'), ansible_version='2.5.0', module_name='setup'))
    assert test_mach.get_hw_facts(collected_facts=dict(ansible_distribution_version='B.11.23')) == dict(model='ia64', firmware_version='xdv.B.61.08.06.0')
    assert test_mach.get_hw_facts(collected_facts=dict(ansible_distribution_version='B.11.31')) == dict(model='ia64', firmware_version='PU2.2')

# Generated at 2022-06-20 17:22:46.302020
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    Validate constructor of HPUXHardware class
    """
    module_args = {}
    module_mock = MockHPUXModule(module_args)
    hphw = HPUXHardware(module_mock)
    assert hphw.platform == "HP-UX"
    assert type(hphw.module) == MockHPUXModule



# Generated at 2022-06-20 17:22:49.117198
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    # Test constructor
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:22:54.756866
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    ''' Unit test for method get_cpu_facts of class HPUXHardware '''
    HPUX_HW = HPUXHardware()
    cpu_facts = HPUX_HW.get_cpu_facts()
    if cpu_facts.get('processor_count') is None:
        assert cpu_facts.get('processor_cores') is None
        return
    assert cpu_facts.get('processor_count') >= cpu_facts.get('processor_cores')


# Generated at 2022-06-20 17:23:07.223047
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = HPUXHardware()
    rc_out_err = {'out': None, 'rc': None, 'err': None}
    module.module = type('AnsibleModuleMock', (object,), {'run_command': rc_out_err})

# Generated at 2022-06-20 17:23:18.527690
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class TestModule:
        def run_command(self, command, use_unsafe_shell):
            if command == "/usr/bin/vmstat | tail -1":
                return (0, " procs -----------memory---------- ---swap-- -----io---- -system-- ------cpu-----", "")
            elif command == "grep Physical /var/adm/syslog/syslog.log":
                return (0, "Aug 31 10:39:10  pureblood syslogd: Physical: 524288 Kbytes init", "")
            elif command == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'":
                return (0, "16384", "")

# Generated at 2022-06-20 17:23:24.467324
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    module = AnsibleModule(argument_spec=dict())
    hw = HPUXHardwareCollector(module=module).collect()[0]
    facts = dict(ansible_facts=dict(hardware=hw))
    assert facts['ansible_facts']['hardware']['platform'] == 'HP-UX'

# Generated at 2022-06-20 17:23:31.145904
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    h = HPUXHardware(None)
    response = h.populate(collected_facts)
    assert response['processor'] == 'Intel(R) Itanium(R) Processor 9740'
    assert response['processor_cores'] == 12
    assert response['processor_count'] == 1
    assert response['memfree_mb'] == '1769'
    assert response['memtotal_mb'] == '2559'
    assert response['swaptotal_mb'] == '0'
    assert response['swapfree_mb'] == '0'
    assert response['model'] == 'ia64 hp server rx8640'

# Generated at 2022-06-20 17:23:33.604667
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h = HPUXHardware()
    facts = h.populate()
    assert facts['memtotal_mb']
    assert facts['swaptotal_mb']

# Generated at 2022-06-20 17:23:43.622134
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # parametrize the testcase
    HW = HPUXHardware({'ansible_architecture': '9000/800'})
    mem_facts = HW.get_memory_facts({})
    cpu_facts = HW.get_cpu_facts({})
    required_memory_facts = ['memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb']
    required_cpu_facts = ['processor_cores', 'processor_count', 'processor']
    assert all(x in mem_facts for x in required_memory_facts)
    assert all(x in cpu_facts for x in required_cpu_facts)

    HW = HPUXHardware({'ansible_architecture': 'ia64'})

# Generated at 2022-06-20 17:23:46.007953
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    '''
    Unit test for constructor of class HPUXHardware
    '''
    test_obj = HPUXHardware()
    assert test_obj.facts == {'processor': None, 'firmware_version': None}


# Generated at 2022-06-20 17:24:08.753018
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    # Create an instance of class HPUXHardware
    obj_HPUXHardware = HPUXHardware(module=None)

    # Call method populate of class HPUXHardware
    output = obj_HPUXHardware.populate(collected_facts={'platform': 'HP-UX', 'ansible_architecture': '9000/800'})

    assert output['memfree_mb'] == '54028'
    assert output['memtotal_mb'] == '48238'
    assert output['swapfree_mb'] == '3964'
    assert output['swaptotal_mb'] == '12034'
    assert output['processor'] == 'PA-RISC 2.0'
    assert output['processor_cores'] == '1'
    assert output['processor_count'] == '2'

# Generated at 2022-06-20 17:24:19.438937
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hardware_facts = HPUXHardware(module)
    rc, out, err = module.run_command.return_value
    rc2, out2, err2 = module.run_command.return_value
    rc3, out3, err3 = module.run_command.return_value
    rc4, out4, err4 = module.run_command.return_value
    rc5, out5, err5 = module.run_command.return_value
    rc6, out6, err6 = module.run_command.return_value
    rc7, out7, err7 = module.run_command.return_value
    rc8, out8, err8 = module.run_command.return_value
    rc9, out9, err9 = module.run_command.return_value

# Generated at 2022-06-20 17:24:24.544561
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = HPUXHardware(module=module)

    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-20 17:24:31.762100
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.hardware.hpux.HPUXHardware import HPUXHardware
    from ansible.module_utils.facts.hardware.hpux.HPUXHardwareCollector import HPUXHardwareCollector
    from ansible.module_utils.facts.hardware.hpux.HPUXHardware import HPUXHardware
    from ansible.module_utils.facts.hardware.hpux.HPUXHardwareCollector import HPUXHardwareCollector

    module = DummyModule()
    hw = HPUXHardware(module)
    collect = Collector(module)
    hwcollector = HPUXHardwareCollector(module, collect)
    hw.populate()

# Generated at 2022-06-20 17:24:42.967034
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import unittest
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule:
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, *args, **kwargs):
            return 0, self.params.get('out'), ''

    class MockFactCollector(BaseFactCollector):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-20 17:24:47.003329
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {}
    hw_collector = HPUXHardwareCollector(module=None, facts=facts)
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 17:24:48.683673
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hh = HPUXHardware()
    assert hh.platform == 'HP-UX'


# Generated at 2022-06-20 17:24:50.508915
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware(dict())
    assert h.platform == 'HP-UX'


# Generated at 2022-06-20 17:24:59.710291
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    import platform
    import unittest
    hw = HPUXHardware()
    hw.module = unittest.mock.MagicMock()
    hw.module.run_command = unittest.mock.MagicMock()
    hw.module.run_command.return_value = (0, platform.machine(), '')

    result = hw.get_hw_facts()
    hw.module.run_command.assert_called_with('model')
    assert(result['model'] == platform.machine())

# Generated at 2022-06-20 17:25:01.021822
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-20 17:25:18.769357
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    # Test for method get_hw_facts of class HPUXHardware if it returns the
    # correct model/firmware version and product serial number
    def create_adapter(collected_facts=None):
        collected_facts = collected_facts or {}
        options = dict()
        options['ansible_collected_facts'] = collected_facts
        adapter = HPUXHardware(create_module=True,
                               argument_spec=options['ansible_collected_facts'])
        adapter.module = adapter
        adapter.module.check_mode = False
        return adapter

    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23',
    }

    adapter = create_

# Generated at 2022-06-20 17:25:22.243494
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_collector = HPUXHardwareCollector()
    assert h_collector._platform == 'HP-UX'
    assert h_collector._fact_class == HPUXHardware

# Generated at 2022-06-20 17:25:25.930549
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('testmodule', (), dict(
        run_command=lambda _: (0, 'out', 'err'),
        params={}
        ))()

    hw = HPUXHardware(module)
    hw.get_cpu_facts()



# Generated at 2022-06-20 17:25:32.495807
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m = HPUXHardware()
    cf = {'ansible_architecture': 'ia64'}
    assert m.get_cpu_facts(collected_facts=cf) == {'processor_cores': 8, 'processor_count': 1, 'processor': 'Intel(R) Itanium(R) Processor'}
    cf = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    assert m.get_cpu_facts(collected_facts=cf) == {'processor_cores': 8, 'processor_count': 1, 'processor': 'Intel(R) Itanium(R) Processor'}
    cf = {'ansible_architecture': '9000/800'}

# Generated at 2022-06-20 17:25:39.059895
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = DummyAnsibleModule()
    harware_collector = HPUXHardwareCollector(module)
    # Check attributes
    assert harware_collector._fact_class == HPUXHardware
    assert harware_collector._platform == 'HP-UX'
    assert harware_collector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-20 17:25:41.623317
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_fact_instance = HPUXHardware()
    assert hardware_fact_instance.platform == HPUXHardwareCollector._platform



# Generated at 2022-06-20 17:25:46.038048
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({})
    assert hardware.get_memory_facts.__name__ == 'get_memory_facts'
    assert hardware.get_cpu_facts.__name__ == 'get_cpu_facts'
    assert hardware.get_hw_facts.__name__ == 'get_hw_facts'

# Generated at 2022-06-20 17:25:53.109631
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    module.params = {}
    hardware = HPUXHardware(module)
    collected_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX',
        'distribution_version': 'B.11.31'
    }
    facts = hardware.populate(collected_facts)
    assert 'model' in facts
    assert 'firmware_version' in facts
    assert 'processor_count' in facts
    assert 'processor_cores' in facts



# Generated at 2022-06-20 17:26:04.466783
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    fake_module = get_mock_module()
    fake_module.run_command = get_mock_run_command(cpu_facts,
                                                   memory_facts,
                                                   hw_facts)

    hpux_hw = HPUXHardware(fake_module)
    hpux_hw.populate()

    # Checking populated facts are set with the good values
    for key, value in cpu_facts.items():
        assert hpux_hw.facts[key] == value
    for key, value in memory_facts.items():
        assert hpux_hw.facts[key] == value
    for key, value in hw_facts.items():
        assert hpux_hw.facts[key] == value


# Generated at 2022-06-20 17:26:15.878062
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hs = HPUXHardwareCollector()
    hs.module = FakeModule()
    hs._fact_class = FakeHPUXHardware
    hs._fact_class._platform = hs._platform
    hs.collect()
    assert hs.ansible_facts['processor_count']['HP-UX'] == 1
    assert hs.ansible_facts['processor']['HP-UX'] == 'PA-RISC 2.0 (1.1 GHz)'
    assert hs.ansible_facts['memtotal_mb']['HP-UX'] == 2047
    assert hs.ansible_facts['processor_count']['HP-UX'] == 1



# Generated at 2022-06-20 17:26:53.383697
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(dict(
        ansible_distribution_version='B.11.23',
        ansible_architecture='ia64',
        ansible_version='2.4',
        ansible_processor_count=64))
    collected_facts = {'ansible_distribution_version': 'B.11.23', 'ansible_architecture': 'ia64', 'ansible_processor_count': 64}
    assert hardware.get_cpu_facts(collected_facts=collected_facts) == {'processor': 'Intel(R) Itanium(R) processor', 'processor_count': 48, 'processor_cores': 48}

# Generated at 2022-06-20 17:26:57.648229
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    fake_data_for_memory_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    hardware = HPUXHardware(None, fake_data_for_memory_facts)
    print(hardware.get_memory_facts())



# Generated at 2022-06-20 17:27:00.787309
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpuxhw = HPUXHardware()
    cpu_facts = hpuxhw.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert isinstance(cpu_facts, dict)



# Generated at 2022-06-20 17:27:01.918458
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware()

    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 17:27:13.720080
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule('HPUX')
    hardware = HPUXHardware(module)

    rc, out, err = module.run_command.call_args[0]
    assert rc == "model"
    rc, out, err = module.run_command.call_args[0]
    assert rc == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC"
    rc, out, err = module.run_command.call_args[0]
    assert rc == "/usr/contrib/bin/machinfo |grep -i 'Machine serial number' "



# Generated at 2022-06-20 17:27:20.462674
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Init module
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=False,
                           )
    module.exit_json = exit_json
    module.run_command = run_command

    # Init HPUXHardware
    hw = HPUXHardware(module)
    hw.populate()



# Generated at 2022-06-20 17:27:24.514708
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardwareCollector = HPUXHardwareCollector()
    assert hardwareCollector._fact_class == HPUXHardware
    assert hardwareCollector._platform == 'HP-UX'
    assert hardwareCollector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-20 17:27:28.900724
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    expected = {'processor_count': 4, 'processor': 'Intel(R) Itanium(R) Processor 9100 series'}
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    hardware_obj = HPUXHardware()
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts == expected


# Generated at 2022-06-20 17:27:35.136117
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    '''
    Test method get_memory_facts of class HPUXHardware
    '''
    hardware = HPUXHardware({
        'module': {
            'run_command': lambda *args, **kwargs: (0, " ", " ")
        }
    })
    hardware.get_memory_facts()
    assert hardware.facts == {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}

# Generated at 2022-06-20 17:27:37.011156
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardwareCollector.collect(dict(platform='HP-UX'), dict())
    assert hardware.platform == 'HP-UX'