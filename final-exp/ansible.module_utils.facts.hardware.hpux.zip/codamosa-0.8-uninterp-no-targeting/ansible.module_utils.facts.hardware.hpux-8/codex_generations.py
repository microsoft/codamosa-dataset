

# Generated at 2022-06-20 17:17:57.949686
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    module.params = {
        'gather_subset': 'all'
    }
    module.run_command = run_command
    module._ansible_module_wrapped = module
    hardware_facts = HPUXHardware(module).populate()
    for key in hardware_facts:
        assert hardware_facts[key] is not None, "key %s is not set " % key



# Generated at 2022-06-20 17:18:01.137832
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module=module)
    assert isinstance(hw, HPUXHardware)
    assert isinstance(hw, Hardware)



# Generated at 2022-06-20 17:18:12.238588
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpux_hw = HPUXHardware()
    hpux_hw.module.run_command = MockFunction()
    hpux_hw.module.run_command.set_results([0, '9000/823', ''])
    hpux_hw.module.get_bin_path = MockFunction()
    hpux_hw.module.get_bin_path.set_results('/usr/contrib/bin/machinfo')
    result = hpux_hw.get_hw_facts({'ansible_distribution_version': "B.11.23"})
    assert result == {'firmware_version': 'B.11.23.01.17', 'product_serial': '123456'}

    hpux_hw = HPUXHardware()
    hpux_hw.module.run_command = MockFunction()


# Generated at 2022-06-20 17:18:16.946809
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:18:22.208960
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # This constructor will normally be invoked by AnsibleModule
    hw = HPUXHardwareCollector(dict(ansible_facts=dict(platform='HP-UX', ansible_architecture='ia64', ansible_distribution='HP-UX')))
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:18:27.170925
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_obj = HPUXHardwareCollector()
    assert hardware_obj._platform == 'HP-UX'
    assert hardware_obj._fact_class._platform == 'HP-UX'
    assert hardware_obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:18:36.953050
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware(dict(ansible_facts=dict()))
    hardware.module = AnsibleModuleMock()

    hardware.module.run_command.return_value = (0, 'ia64', '')
    hardware.module.run_command.return_value = (0, 'B.11.23', '')
    hardware.module.run_command.return_value = (0, 'Superdome X', '')
    hardware.module.run_command.return_value = (0, 'Firmware revision                    = OA 3.76', '')
    hardware.module.run_command.return_value = (0, 'Machine serial number                = SERIALNUMBER', '')

    collected_facts = dict()
    hw = hardware.get_hw_facts()
    assert hw['firmware_version']

# Generated at 2022-06-20 17:18:49.840319
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.side_effect = [(0, '', ''), (0, '', ''), (0, '', ''), (0, '', ''), (0, '', ''), (0, '', '')]
    set_module_args(dict(gather_subset='all'))
    result = HPUXHardware(module).populate()
    assert result.get('memfree_mb') is not None
    assert result.get('swapfree_mb') is not None
    assert result.get('memtotal_mb') is not None
    assert result.get('swaptotal_mb') is not None
    assert result.get('processor_count') is not None
   

# Generated at 2022-06-20 17:18:55.841609
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, "N4000-2 PA-RISC  B.11.11  U  1299885432", ""
    mock_module = MockModule()
    hardware = HPUXHardware(mock_module)
    hw_facts = hardware.get_hw_facts()
    assert hw_facts == {'model': 'N4000-2 PA-RISC  B.11.11  U  1299885432'}


# Generated at 2022-06-20 17:19:06.537632
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware({'platform': 'HP-UX', 'distribution': 'HP-UX'})

    hardware.module.run_command = lambda *args, **kargs: ('', '', '')

    # set some fake memory data
    hardware.module.run_command.side_effect = [('', '', ''),
                                               ('', '1865', ''),
                                               ('', '16777216', ''),
                                               ('', '16382', ''),
                                               ('', '16337', '')]

    # run get_memory_facts to populate memory facts
    memory_facts = hardware.get_memory_facts()

    # assert returned memory facts
    assert memory_facts['memfree_mb'] == 1865
    assert memory_facts['memtotal_mb'] == 16777216
    assert memory_

# Generated at 2022-06-20 17:19:22.579147
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)

    rc = hardware_obj.populate()
    assert rc['processor'] == 'Intel(R) Itanium(R) Processor 9440'
    assert rc['processor_cores'] == 4
    assert rc['processor_count'] == 1
    assert rc['model'] == 'ia64 hp server rx6600'
    assert rc['firmware_version'] == 'HPRC_02.17'
    assert rc['memfree_mb'] == 2047
    assert rc['memtotal_mb'] == 4095
    assert rc['swapfree_mb'] == 0
    assert rc['swaptotal_mb'] == 4096

# Generated at 2022-06-20 17:19:28.118530
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = AnsibleModule({'ansible_architecture': 'ia64',
                               'ansible_distribution_version': 'B.11.31'})
    hw.get_hw_facts({})

# Generated at 2022-06-20 17:19:32.791235
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector({'platform': 'HP-UX'})
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == {'platform', 'distribution'}
    assert hardware_collector.fact_class == HPUXHardware


# Generated at 2022-06-20 17:19:37.086147
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_obj = HPUXHardwareCollector()
    assert hw_obj.required_facts == HPUXHardwareCollector.required_facts

# Generated at 2022-06-20 17:19:46.708669
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({})
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX'
    }
    hphw = HPUXHardware(module)
    assert hphw.populate(collected_facts) == {'processor_cores': 2, 'processor_count': 2, 'memfree_mb': 125,
                                              'memtotal_mb': 8191, 'swaptotal_mb': 0, 'swapfree_mb': 0,
                                              'firmware': None, 'model': '9000/800', 'processor': None}

# Generated at 2022-06-20 17:19:52.819062
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    mod = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    hw = HPUXHardware(module=mod)
    hw_facts = hw.get_hw_facts(collected_facts=dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23'))
    assert 'model' in hw_facts
    assert 'firmware_version' in hw_facts
    assert 'product_serial' not in hw_facts

# Generated at 2022-06-20 17:20:00.725547
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('AnsibleModule', (object,), dict(
        params={},
        check_mode=False,
        run_command=lambda *args, **kwargs: (0, "", ""),
    ))

    collected_facts = dict(
        ansible_architecture='9000/800',
        ansible_distribution_version='B.11.23'
    )
    hardware = HPUXHardware(module=module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'


# Generated at 2022-06-20 17:20:13.010826
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()

    collected_facts = {'ansible_architecture': '9000/785'}
    hardware.populate(collected_facts)
    hardware.get_memory_facts(collected_facts)
    assert hardware.memtotal_mb == 1048576
    assert hardware.memfree_mb == 1363
    assert hardware.swaptotal_mb == 0
    assert hardware.swapfree_mb == 0

    collected_facts = {'ansible_architecture': 'ia64'}
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    hardware.populate(collected_facts)
    hardware.get_memory_facts(collected_facts)
    assert hardware.memtotal_mb == 1048576
    assert hardware.memfree_mb == 13

# Generated at 2022-06-20 17:20:24.642619
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = {
        "ansible_architecture": "9000/800",
        "ansible_distribution_version": "B.11.23"
    }
    module = AnsibleModuleMock({
        "ansible_architecture": "9000/800",
        "ansible_distribution_version": "B.11.23"
    })
    hardware = HPUXHardware(module)
    hardware.get_cpu_facts = MagicMock()
    hardware.get_cpu_facts.return_value = {
        "processor_count": 2
    }
    hardware.get_memory_facts = MagicMock()
    hardware.get_memory_facts.return_value = {
        "memtotal_mb": 32768,
        "memfree_mb": 1024
    }
    hardware.get_

# Generated at 2022-06-20 17:20:27.076273
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert isinstance(h, HardwareCollector)

# Generated at 2022-06-20 17:20:38.205287
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware({})
    assert hw.platform == 'HP-UX'



# Generated at 2022-06-20 17:20:43.046589
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    sample_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX'
    }
    hardware = HPUXHardware(sample_facts)
    facts = hardware.get_cpu_facts(sample_facts)
    assert 'processor_count' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts

# Generated at 2022-06-20 17:20:50.533459
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list')})
    facts = module.params['gather_subset']

    hpux = HPUXHardware(module)
    hpux.populate()
    facts_out = hpux.get_facts()

    assert facts_out['processor_count'] == 6
    assert facts_out['memfree_mb']
    assert facts_out['memtotal_mb']
    assert facts_out['swaptotal_mb']
    assert facts_out['swapfree_mb']
    assert facts_out['model']
    assert facts_out['processor']


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-20 17:21:03.719973
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = MockModule()
    hardware = HPUXHardware(module=module)

    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    # machinfo return string '4 cores' in release B.11.31 > 1204
    hardware.get_cpu_facts(collected_facts=collected_facts)
    assert(module.run_command.call_count == 4)
    assert(module.run_command.call_args_list[0][0][0] == '/usr/contrib/bin/machinfo | egrep \'socket[s]?$\' | tail -1')

# Generated at 2022-06-20 17:21:10.709936
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    os_version = "B.11.31"
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    hw = HPUXHardware()
    hw.module = test_module
    cpu_facts = hw.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': os_version})
    assert cpu_facts.get('processor_count') == 2
    assert cpu_facts.get('processor') == 'Intel(R) Xeon(R) CPU E5-2620 0 @ 2.00GHz'
    assert cpu_facts.get('processor_cores') == 10

# Generated at 2022-06-20 17:21:23.388539
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, "", "")

    class FakeCollector(HardwareCollector):
        def __init__(self, module):
            self.module = module
            self.facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31')

    obj = HPUXHardware(FakeModule())
    obj.populate(collected_facts=FakeCollector(FakeModule()).collect())
    # Controled output
    assert obj.memory['memtotal_mb'] == 39742

# Generated at 2022-06-20 17:21:33.849261
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    parameters = {'module_name': 'setup', 'module_args': "{}", 'become': None, 'become_method': None,
                  'become_user': None, 'check_mode': False, 'remote_user': 'root', 'verbosity': 0,
                  '_ansible_socket': None, '_ansible_no_log': False}

    module = AnsibleModule(**parameters)
    module.run_command = MagicMock(return_value=(0, "HP Integrity rx2660", None))
    collection = HPUXHardwareCollector(module)
    facts = collection.collect()
    assert 'HP Integrity rx2660' == facts['model']
    assert 'firmware_version' in facts
    assert 'product_serial' in facts

# Generated at 2022-06-20 17:21:42.519449
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    ansible_facts = {'platform': 'HP-UX', 'distribution_version': '0'}
    hardware_collector = HPUXHardwareCollector(ansible_facts, None)
    assert HardwareCollector == hardware_collector.__class__
    assert HPUXHardware == hardware_collector._fact_class
    assert 'HP-UX' == hardware_collector._platform
    assert set(['platform', 'distribution_version']) == hardware_collector.required_facts

# Generated at 2022-06-20 17:21:52.221455
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeANSIModule()
    hardware = HPUXHardware(module=module)
    rc, out, err = module.run_command("/usr/sbin/swapinfo -m -d -f -q")
    total_swap = int(out.strip())
    rc, out, err = module.run_command("/usr/sbin/swapinfo -m -d -f | egrep '^dev|^fs'", use_unsafe_shell=True)
    swap = 0
    for line in out.strip().splitlines():
        swap += int(re.sub(' +', ' ', line).split(' ')[3].strip())
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': "B.11.31"}
    memory_facts

# Generated at 2022-06-20 17:22:02.348126
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    testModule = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(testModule)
    hardware.module.run_command = MagicMock(return_value=(0, '/dev/vgapp/lvol4 524283120 464962048 59321072  90%    /apps', ''))
    hardware.get_memory_facts()
    hardware.module.run_command.assert_any_call('/usr/bin/vmstat | tail -1', use_unsafe_shell=True)
    testModule.fail_json.assert_called_once_with(msg='Error getting memory facts')


# Generated at 2022-06-20 17:22:28.340379
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert x._fact_class == HPUXHardware
    assert x._platform == 'HP-UX'

# Generated at 2022-06-20 17:22:34.917693
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    facts = {'ansible_distribution_version': 'B.11.23'}
    rc, out, err = module.run_command("grep Physical /var/adm/syslog/syslog.log")
    data = re.search('.*Physical: ([0-9]*) Kbytes.*', out).groups()[0].strip()
    assert hardware_obj.get_memory_facts(facts)['memtotal_mb'] == int(data) // 1024



# Generated at 2022-06-20 17:22:36.157506
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert x.collect() is not None

# Generated at 2022-06-20 17:22:49.361394
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    def run_module(*args):
        # Test running a module with arguments
        module_args = dict(
            args=args,
        )
        module = FakeModule(**module_args)
        hpux_hardw = HPUXHardware()
        hpux_hardw.module = module
        return hpux_hardw.populate()

    # Test run_command method
    def run_command(cmd, use_unsafe_shell=False):
        return 1, b"", b""

    # Test populated facts per server type
    facts = {}
    # Test server 800
    for arch in ['9000/800', '9000/785']:
        facts['ansible_architecture'] = arch
        facts['ansible_distribution_version'] = 'B.11.31'

# Generated at 2022-06-20 17:22:57.756319
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=('', True, ''))
    module.params = {'fact_path': '/etc/ansible/facts.d'}

    hpux_hw = HPUXHardware(module)
    mem_facts = hpux_hw.get_memory_facts({'ansible_architecture': 'ia64'})
    assert isinstance(mem_facts, dict) is True
    assert ('memfree_mb' in mem_facts.keys()) is True
    assert ('memtotal_mb' in mem_facts.keys()) is True
    assert ('swaptotal_mb' in mem_facts.keys()) is True
    assert ('swapfree_mb' in mem_facts.keys()) is True



# Generated at 2022-06-20 17:23:04.476610
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test get_hw_facts method return facts.
    """

    hw_facts = {
        'model': 'HP9000 rp4440    9000/890',
        'firmware_version': 'C.7.8',
        'product_serial': 'JAE142100KB',
    }
    hpux = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hpux.populate()
    assert hpux.get_hw_facts(collected_facts) == hw_facts



# Generated at 2022-06-20 17:23:11.292549
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.params['filter'] = ['!.*']
    module.exit_json = exit_json
    hardware_facts = HPUXHardware(module=module)
    memory = hardware_facts.get_memory_facts()
    assert memory['memtotal_mb'] > 0
    assert 'memfree_mb' in memory
    assert 'swaptotal_mb' in memory
    assert 'swapfree_mb' in memory

# Generated at 2022-06-20 17:23:19.256653
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpeux import HPUXHardware
    h = HPUXHardware({'module_setup': True, 'gather_subset': '!all'})
    collected_facts = {
        'ansible_architecture': '9000/800',
    }
    assert h.get_memory_facts(collected_facts=collected_facts) == {'memtotal_mb': 8192, 'memfree_mb': 4203, 'swapfree_mb': 0, 'swaptotal_mb': 0}

# Generated at 2022-06-20 17:23:29.578496
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['firmware_version'] in ['11.31']
    assert hardware_obj.facts['memtotal_mb'] == 4 * 1024
    assert hardware_obj.facts['memfree_mb'] == 4000
    assert hardware_obj.facts['swaptotal_mb'] == 32
    assert hardware_obj.facts['swapfree_mb'] == 32
    assert hardware_obj.facts['processor_count'] == 2
    assert hardware_obj.facts['processor_cores'] == 8
    assert hardware_obj.facts['model'] == 'ia64 hp server rx2660'
    assert hardware_obj.facts['product_serial'] == 'US12345'

# Generated at 2022-06-20 17:23:41.464054
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils import basic
    import pytest

    module = basic.AnsibleModule(argument_spec=dict())
    module.run_command = lambda cmd, use_unsafe_shell: (0, '', '')

    # Test case 1
    module.run_command = lambda cmd, use_unsafe_shell: (0, '', '')

    hw = HPUXHardware()
    hw.module = module
    memory_facts = hw.get_memory_facts()
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0

    # Test case 2

# Generated at 2022-06-20 17:24:18.995888
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({})
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts == {'firmware_version': 'HP-UX_B.11.23_IA_PA-RISC_64',
                        'model': 'HP Integrity rx2600'}
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hardware.get_hw_facts(collected_facts)

# Generated at 2022-06-20 17:24:29.719270
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()

    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Itanium 2 processor 9570'
    collected_facts = {
        'ansible_architecture': '9000/785',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31',
    }

# Generated at 2022-06-20 17:24:37.263710
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    collected_facts = {
        'ansible_architecture': "9000/800",
    }

    hardware_facts = HPUXHardware(None)
    facts = hardware_facts.get_memory_facts(collected_facts)
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts

# Generated at 2022-06-20 17:24:38.183483
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    m = HPUXHardwareCollector()

# Generated at 2022-06-20 17:24:38.984320
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-20 17:24:48.019076
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Set of facts to test with
    uname_facts = dict(
        platform='HP-UX'
    )
    # code under test
    hardware = HPUXHardware(dict(module=None, uname_facts=uname_facts))
    hardware.facts['ansible_architecture'] = '9000/800'
    collected_facts = dict(ansible_architecture='9000/800')
    # Mock methods called by the code under test
    hardware.get_cpu_facts = lambda **kwargs: dict(processor_count=1, processor_cores=2)
    hardware.module.run_command = lambda cmd, **kwargs: (0, "1 0 0 0 0 0 0 0 0 0", None)

# Generated at 2022-06-20 17:25:00.362424
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hp import HPUXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts.cache import FactCache
    from ansible.module_utils.facts.hardware.hp import HPUXHardwareCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector
    import json
    import mock

    sut = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

    #Act
    result = sut.populate(collected_facts=collected_facts)
    #Assert
    print

# Generated at 2022-06-20 17:25:10.768041
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = MockModule()
    hardware = HPUXHardware(module)

    os_release = 11.23
    facts = {'ansible_architecture': "ia64", 'ansible_distribution_version': os_release}
    cpu_facts = hardware.get_cpu_facts(collected_facts=facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9350'

    os_release = 11.31
    facts = {'ansible_architecture': "ia64", 'ansible_distribution_version': os_release}
    cpu_facts = hardware.get_cpu_facts(collected_facts=facts)
    assert cpu_facts['processor_count']

# Generated at 2022-06-20 17:25:20.277495
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m = HPUXHardware(dict(ansible_facts=dict(distribution='HP-UX', platform='HP-UX', ansible_architecture='9000/800')))
    assert m.get_cpu_facts() == dict(processor_count=4)
    m = HPUXHardware(dict(ansible_facts=dict(distribution='HP-UX', platform='HP-UX', ansible_architecture='ia64')))
    assert m.get_cpu_facts() == dict(processor_count=1, processor_cores=8, processor='Intel(R) Itanium(R) 2 9300 series')


# Generated at 2022-06-20 17:25:30.408224
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = mock.MagicMock()

# Generated at 2022-06-20 17:26:06.000147
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec=dict())

    class CollectedFacts:
        ansible_architecture = 'ia64'
        ansible_distribution_version = "B.11.23"

    hw_facts = HPUXHardware(module)
    collected_facts = CollectedFacts()

    hw_facts = HPUXHardware(module)
    res = hw_facts.get_hw_facts(collected_facts)

    assert(res['model'])
    assert(res['firmware_version'])
    assert(res['product_serial'])



# Generated at 2022-06-20 17:26:11.632165
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    assert issubclass(HPUXHardwareCollector, HardwareCollector)
    assert HPUXHardwareCollector.platform == 'HP-UX'
    assert HPUXHardwareCollector._fact_class == HPUXHardware
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:26:17.811672
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    harware_collector = HPUXHardwareCollector()
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert harware_collector._platform == 'HP-UX'
    assert HPUXHardwareCollector.__module__ == 'ansible.module_utils.facts.hardware.hpux'
    assert harware_collector._fact_class == HPUXHardware
    assert harware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:26:30.534893
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Prepare argument data for method
    raw_facts = {}
    raw_facts['ansible_architecture'] = '9000/800'

    # If a argument is not present or None, it will be replaced by default value
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    result = hw.get_cpu_facts(raw_facts)
    assert result['processor_count'] == 4

    raw_facts['ansible_architecture'] = 'ia64'
    raw_facts['ansible_distribution_version'] = 'B.11.31'
    result = hw.get_cpu_facts(raw_facts)

# Generated at 2022-06-20 17:26:36.389065
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw_facts = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts.get_hw_facts(collected_facts=collected_facts)



# Generated at 2022-06-20 17:26:45.333036
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # Test HPUXHardware class without parameters
    hardware_obj = HPUXHardware()
    platform = 'HP-UX'
    # Check if all class atributes are set correctly
    assert hardware_obj.platform == platform
    # Check if memory facts are empty due to missing collected facts
    assert hardware_obj.get_memory_facts() == {}
    # Check if processor facts are empty due to missing collected facts
    assert hardware_obj.get_cpu_facts() == {}
    # Check if hw facts are empty due to missing collected facts
    assert hardware_obj.get_hw_facts() == {}
    # Check if the populate method return the correct dictionary

# Generated at 2022-06-20 17:26:54.508853
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()

    hardware.module = FakeAnsibleModule()
    hardware.module.run_command.return_value = 0, "12", ""
    hardware.module.run_command.return_value = 0, "80", ""

    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }

    facts = hardware.populate(collected_facts)

    assert facts['processor_count'] == 2
    assert facts['processor'] == 'Intel(r) Itanium(r) Processor'
    assert facts['processor_cores'] == 26
    assert facts['memfree_mb'] == 4
    assert facts

# Generated at 2022-06-20 17:26:58.729080
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('MockModule', (object,), {'run_command': mock_run_command})
    hardware = HPUXHardware(module)
    out = "  r b w    swap  free  re  mf pi po fr de sr m1 m2 m3 in sy cs us sy id   0  0  0  44556  4996   5   2  6  2  0  0  0  0  0  0  0  0  0 99 99  0"
    hw_facts = hardware.get_memory_facts()
    assert hw_facts['swaptotal_mb'] == 44556
    assert hw_facts['swapfree_mb'] == 4996
    assert hw_facts['memfree_mb'] == 4996

# Generated at 2022-06-20 17:27:06.314914
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = FakeAnsibleModule()
    # Add facts from ansible_facts
    module.params = {'ansible_facts': {'ansible_architecture': 'ia64',
                                       'ansible_distribution_version': 'B.11.23'}}
    hw = HPUXHardware(module)
    assert hw.ansible_facts.keys() == {'ansible_architecture', 'ansible_distribution_version'}



# Generated at 2022-06-20 17:27:12.833738
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    fake_collector_class = HPUXHardwareCollector()
    fake_collector = HPUXHardwareCollector(fact_class=fake_collector_class._fact_class,
                                           platform=fake_collector_class._platform,
                                           config=fake_collector_class._config)
    assert fake_collector._fact_class is HPUXHardware