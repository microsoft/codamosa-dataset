

# Generated at 2022-06-20 17:17:55.756679
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    facts_collector = HPUXHardwareCollector(module=module)
    assert facts_collector.fact_class == HPUXHardware
    assert facts_collector.platform == 'HP-UX'


# Generated at 2022-06-20 17:18:05.025379
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hostname = 'testhost'
    collected_facts = {
        "ansible_distribution_version": "B.11.31",
        "ansible_architecture": "ia64",
        "ansible_distribution_major_version": "B.11"
    }
    module = MockModule()

    # Create object with valid parameters
    obj = HPUXHardware(module=module, collected_facts=collected_facts)
    obj.get_cpu_facts()

    # Check arguments sent to method ansible.module_utils.basic.AnsibleModule.run_command
    assert module.run_command.call_count == 4
    args, kwargs = module.run_command.call_args_list[0]

# Generated at 2022-06-20 17:18:15.680554
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware(None)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': "B.11.23"
    }
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['swaptotal_mb'] == 8192
    collected_facts['ansible_architecture'] = '9000/800'
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memtotal_mb'] == 65536
    assert memory_facts['swaptotal_mb'] == 8192

# Generated at 2022-06-20 17:18:17.624716
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    data = HPUXHardware(dict(platform='HP-UX'))
    assert data.platform == 'HP-UX'

# Generated at 2022-06-20 17:18:20.666522
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    assert hw.module is module

# Generated at 2022-06-20 17:18:28.800532
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Initialize class variables
    facts = {u'ansible_architecture': u'9000/800',
             u'ansible_distribution': u'HP-UX',
             u'ansible_distribution_major_version': u'B.11',
             u'ansible_distribution_version': u'B.11.23'}
    module = None

    # Initialize class
    hpux_hw = HPUXHardware(module)

    # Run method
    populate = hpux_hw.populate(facts)
    assert populate



# Generated at 2022-06-20 17:18:38.208590
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw_facts = HPUXHardware()
    #
    #  mock for ia64 system B.11.23
    #
    mock_collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    mem = hw_facts.get_memory_facts(collected_facts=mock_collected_facts)
    assert mem == {'memfree_mb': 57, 'memtotal_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0}
    #
    #  mock for pa-risc system
    #
    mock_collected_facts = {'ansible_architecture': '9000/800'}

# Generated at 2022-06-20 17:18:48.859421
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # GIVEN
    module = Mock()
    hw = HPUXHardware(module=module)
    module.run_command.return_value = (0, '', '')
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution_version': 'B.11.23'}

    # WHEN
    hw.populate(collected_facts=collected_facts)

    # THEN
    module.run_command.assert_any_call('ioscan -FkCprocessor | wc -l', use_unsafe_shell=True)



# Generated at 2022-06-20 17:18:56.433588
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware({'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'})
    assert h.platform == 'HP-UX'
    assert h.get_cpu_facts() == {'processor_count': 2}
    assert h.get_memory_facts() == {
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
    }
    assert h.get_hw_facts() == {'model': 'hp 9000/800', 'firmware_version': None, 'product_serial': None}



# Generated at 2022-06-20 17:18:59.291285
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    my_obj = HPUXHardwareCollector(module)
    assert my_obj.platform == 'HP-UX'

# Generated at 2022-06-20 17:19:19.064493
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test method get_hw_facts of HPUXHardware class
    """
    module = AnsibleModule(argument_spec={})

    hw = HPUXHardware(module=module)

    # Test with machinfo for distribution B.11.23 and B.11.31
    collected_facts = dict(ansible_distribution_version='B.11.23')

    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'v1.6'
    assert hw_facts['product_serial'] == 'B00000000000'

    collected_facts = dict(ansible_distribution_version='B.11.31')

# Generated at 2022-06-20 17:19:23.726680
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    This is just a basic test for the constructor of class HPUXHardware
    """
    # Check if the constructor works
    hpux_hardware = HPUXHardware({}, None)
    assert isinstance(hpux_hardware, HPUXHardware)

# Generated at 2022-06-20 17:19:34.484408
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    rc_mock = MagicMock(return_value=(0, '', ''))
    module.run_command = rc_mock

# Generated at 2022-06-20 17:19:46.759356
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class TestModule:

        def __init__(self, params=None):
            self.params = params

        def run_command(self, command, use_unsafe_shell=None):
            if 'get_mem_info' in command:
                out = """
                Mem:
                total used free shared buffers cached
                Mem:  3295908 2234864 1061044        0  198720  912440
                -/+ buffers/cache: 1213704 2082200
                Swap:
                total used free
                Swap:  1044216        0 1044216"""
                return 0, out, []

# Generated at 2022-06-20 17:19:54.875175
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hw = HPUXHardware(module=module)
    hw.collect()

    # check mem
    assert isinstance(hw.memfree_mb, int)
    assert hw.memfree_mb >= 0
    assert isinstance(hw.memtotal_mb, int)
    assert hw.memtotal_mb >= 0
    assert isinstance(hw.swapfree_mb, int)
    assert hw.swapfree_mb >= 0
    assert isinstance(hw.swaptotal_mb, int)
    assert hw.swaptotal_mb >= 0

    # check cpu
    assert isinstance(hw.processor_cores, int)
    assert hw.processor_cores >= 0
   

# Generated at 2022-06-20 17:20:05.709782
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('MockModule', (object,), {'run_command': run_command})()
    h = HPUXHardware(module)
    r = h.get_hw_facts()
    assert r.get('firmware') == 'B.11.11'
    assert r.get('firmware_version') == 'B.11.11'
    assert r.get('product') == 'rp3440'
    assert r.get('product_serial') == 'ABC-1234'

    def run_command(self, cmd, data=None, use_unsafe_shell=None, binary_data=False):
        return (0, '', '')

# Generated at 2022-06-20 17:20:12.694842
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collection = HPUXHardwareCollector(dict({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}))
    hardware_instance = collection._create_hardware_instance()
    result = hardware_instance.get_hw_facts()
    assert result == {'model': 'hp Integrity rx2600', 'firmware_version': 'B.11.31.3380'}

# Generated at 2022-06-20 17:20:18.421311
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardwareCollector
    assert hardware.get_memory_facts() == {'memfree_mb': 431, 'memtotal_mb': 8192, 'swaptotal_mb': 0, 'swapfree_mb': 0}


# Generated at 2022-06-20 17:20:23.429264
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = HPUXHardware()
    module.distribution = 'HP-UX'
    module.architecture = 'ia64'
    module.distribution_version = 'B.11.31'
    assert module.get_cpu_facts() == {'processor': 'Intel(R) Itanium(R) Processor', 'processor_cores': 160, 'processor_count': 4}

# Generated at 2022-06-20 17:20:35.176688
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ioscan -FkCprocessor | wc -l":
                return 0, "4", ""
            elif cmd == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
                return 0, "Number of CPUs: 2", ""
            elif cmd == "/usr/contrib/bin/machinfo | grep 'processor family'":
                return 0, "processor family = Intel(R) Itanium(R) processor", ""
            elif cmd == "/usr/contrib/bin/machinfo | grep 'socket[s]?$' | tail -1":
                return 0

# Generated at 2022-06-20 17:20:43.388886
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    pass

# Generated at 2022-06-20 17:20:52.598643
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = [{'firmware_version': '23.10', 'product_serial': 'CZH3061WQQ'}]
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    instance = HPUXHardware(dict())
    instance.module = type('', (object,), {'run_command': lambda x: (0, hw_facts[0]['firmware_version']+'\n', '')})()
    results = instance.get_hw_facts(collected_facts)
    for i in hw_facts:
        for key in i:
            assert test_HPUXHardware_get_hw_facts.__name__, results[key] == i[key]

# Unit

# Generated at 2022-06-20 17:21:01.907348
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64'}
    result = hardware.get_memory_facts(collected_facts)
    id = '"' + re.escape('HPUXHardware get_memory_facts') + '"'
    fail_json({'failed': True, id: '', 'msg': 'get_memory_facts result is {}'.format(result)})


# Generated at 2022-06-20 17:21:07.299867
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware({'module_setup': True})
    hardware.module.run_command = MagicMock(return_value=(0, 'data', ''))

    assert hardware.get_memory_facts() == {'memfree_mb': 8192, 'memtotal_mb': 12288, 'swapfree_mb': 4214, 'swaptotal_mb': 4214}


# Generated at 2022-06-20 17:21:09.717405
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    assert hw is not None

# Generated at 2022-06-20 17:21:14.028637
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts = set(['platform', 'distribution'])
    hpux_hwc = HPUXHardwareCollector()
    assert hpux_hwc.required_facts == required_facts

# Generated at 2022-06-20 17:21:17.709437
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModuleMock()
    klass = HPUXHardware(module)
    assert isinstance(klass, HPUXHardware)



# Generated at 2022-06-20 17:21:25.835350
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    out = "ia64 hp9000/785  0.0.0/0.0.0.0\n"
    module = type('', (), {})()
    module.run_command = type('', (), {})()
    module.run_command.return_value = 0, out, ""
    class_ = HPUXHardware(module=module)

    facts = class_.get_hw_facts()
    assert facts['model'] == 'ia64 hp9000/785'


# Generated at 2022-06-20 17:21:32.686032
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw_facts = HPUXHardware(module).get_hw_facts()

    assert hw_facts
    if hw_facts['product_serial'] is not None:
        assert len(hw_facts['product_serial']) == 11
    if hw_facts['firmware_version'] is not None:
        assert hw_facts['firmware_version'][0] in ['1', '2']



# Generated at 2022-06-20 17:21:45.490057
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    fact_path = os.path.dirname(os.path.realpath(__file__)) + '/../../' + 'facts/'
    hpux_ia64_facts_file = fact_path + 'hpux_ia64_facts.json'
    hpux_parisc_facts_file = fact_path + 'hpux_pa-risc_facts.json'
    result_ia64 = {
        "processor_cores": 1,
        "processor_count" : 2,
        "processor": "Intel(R) Itanium(R) Processor 9345"
    }
    result_parisc = {
        "processor_count":  2
    }
    HPUXHardware.module = MagicMock()

# Generated at 2022-06-20 17:22:04.847191
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeModule()
    hw = HPUXHardware(module)
    hw_facts = hw.get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx5670'
    assert hw_facts['firmware_version'] == 'v2.31'
    assert hw_facts['product_serial'] == 'BAD00000000000'



# Generated at 2022-06-20 17:22:17.555460
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    facts_module = HPUXHardware(module=module)
    collected_facts = dict(ansible_facts=dict(ansible_distribution="HP-UX", ansible_architecture="ia64"))

    # Test empty
    hw_facts = facts_module.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts == dict(model="Superdome 2", firmware_version="v5.5.5", product_serial="HP-UX")

    # Test ansible_architecture=ia64 ansible_distribution_version=B.11.23

# Generated at 2022-06-20 17:22:21.875135
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector.get_platform() == 'HP-UX'
    assert HPUXHardwareCollector.get_fact_class() == HPUXHardware
    assert HPUXHardwareCollector.get_required_facts() == {'platform', 'distribution'}

# Generated at 2022-06-20 17:22:32.107485
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()

    facts = hardware.populate({
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    })

    assert facts['processor_count'] == 4
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor Family (1.30 GHz, 2 MB)'
    assert facts['processor_cores'] == 4
    assert facts['memfree_mb'] == 543
    assert facts['memtotal_mb'] == 4915
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['model'] == 'ia64 hp server rx2660'
    assert facts['firmware_version'] == 'B.11.23'



# Generated at 2022-06-20 17:22:33.719264
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware({})
    assert hardware.populate()['processor_count'] == 0

# Generated at 2022-06-20 17:22:44.964102
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModuleMock
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hw.get_memory_facts(collected_facts=collected_facts)
    expected_memory_facts = {'memfree_mb': 629,
                             'memtotal_mb': 42276,
                             'swaptotal_mb': 17385,
                             'swapfree_mb': 17385}
    assert memory_facts == expected_memory_facts
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    memory_facts = hw.get_memory_facts(collected_facts=collected_facts)


# Generated at 2022-06-20 17:22:50.350600
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module=module)
    hardware_info = hardware_obj.populate({'platform': 'HP-UX', 'architecture': 'ia64',
                                           'distribution_version': 'B.11.23'})
    assert hardware_info['processor_count'] == 1
    assert hardware_info['processor'] == 'Intel(r) Itanium 2 9000 series'
    assert hardware_info['processor_cores'] == 4
    assert hardware_info['memtotal_mb'] == 8192
    assert hardware_info['memfree_mb'] == 207
    assert hardware_info['swaptotal_mb'] == 8192
    assert hardware_info['swapfree_mb'] == 3543


# Generated at 2022-06-20 17:22:57.660805
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = HPUXHardware(module=module).populate()
    assert hardware_facts.get('processor')
    assert hardware_facts.get('processor_count')
    assert hardware_facts.get('processor_cores')
    assert hardware_facts.get('memtotal_mb')
    assert hardware_facts.get('memfree_mb')
    assert hardware_facts.get('swaptotal_mb')
    assert hardware_facts.get('swapfree_mb')
    assert hardware_facts.get('model')
    assert hardware_facts.get('firmware_version')
    assert hardware_facts.get('product_serial')

# Generated at 2022-06-20 17:23:01.248903
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({})
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31')
    hardware = HPUXHardware(module)
    hardware.populate(collected_facts)



# Generated at 2022-06-20 17:23:13.819740
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, None, None))

    test_HPUXHardware = HPUXHardware(module=test_module)

    # Get memory facts for PA-RISC
    out = test_HPUXHardware.get_memory_facts()
    assert out['memfree_mb'] == 0
    assert out['memtotal_mb'] == 0

    # Test memory facts for Ia64

# Generated at 2022-06-20 17:23:49.233225
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Initialize module
    module = AnsibleModule(
        argument_spec=dict()
    )
    # Init HPUXHardware class
    hphw = HPUXHardware(module)
    # Prepare fact dictionary
    fact_dict = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    # call method populate of the class
    hphw.populate(fact_dict)
    # Check the results
    assert hphw.facts['memfree_mb']
    assert hphw.facts['memtotal_mb']
    assert hphw.facts['swapfree_mb']
    assert hphw.facts['swaptotal_mb']
    assert hphw.facts['processor']
    assert hphw.facts

# Generated at 2022-06-20 17:23:51.626604
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-20 17:23:54.439082
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector("/path/to/ansible_module")
    assert hardware_collector.platform == 'HP-UX', 'platform should be HP-UX'

# Generated at 2022-06-20 17:23:57.803160
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.fact_class == HPUXHardware
    assert collector.platform == 'HP-UX'
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:24:06.084666
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Create instance of HPUXHardware
    my_HPUXHardware = HPUXHardware(dict())
    # Set attribute _facts_cache of HPUXHardware to known values
    my_HPUXHardware._facts_cache = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31',
    }
    # Execute method populate
    my_HPUXHardware.populate()
    # Assert results
    assert my_HPUXHardware._facts_cache['processor_count'] == 4
    assert my_HPUXHardware._facts_cache['processor'] == 'Intel(R) Itanium 2 9000 Series Processor'
    assert my_HPUXHardware._facts_cache['memfree_mb'] == 136772
    assert my_HPUXHardware

# Generated at 2022-06-20 17:24:09.334542
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector._fact_class is HPUXHardware

# Generated at 2022-06-20 17:24:18.682496
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor_count'] in (1, 2, 4, 8, 16, 32)
    assert cpu_facts['processor'] in ('Intel Itanium 2', 'Intel Itanium 9100', 'Intel Itanium 9300',
                                      'Intel Itanium 9560', 'Intel Itanium 9700', 'Intel Itanium 9700',
                                      'Intel Itanium TL9200', 'Intel Itanium TL9200LP')
    assert cpu_facts['processor_cores'] in (1, 2, 4, 8, 16)



# Generated at 2022-06-20 17:24:21.375139
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX', hardware.platform


# Generated at 2022-06-20 17:24:23.068016
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()

    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:24:31.314856
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    hardware_obj = HPUXHardware(module)
    # Test values for get_cpu_facts with m series
    try:
        hardware_obj.module.run_command.return_value = (0, "4", None)
        hardware_obj.populate({'ansible_architecture': '9000/800'})
    except:pass
    cpu_facts_m_series = hardware_obj.get_cpu_facts({'ansible_architecture': '9000/800'})
    assert cpu_facts_m_series == {'processor_count': 4}
    # Test values for get_cpu_facts with IA64

# Generated at 2022-06-20 17:25:42.101943
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    m = HPUXHardware(dict(ansible_system='HP-UX'))
    hw_facts = m.get_hw_facts()
    assert hw_facts['model'] == '9000/800'
    m = HPUXHardware(dict(ansible_system='HP-UX', ansible_architecture='ia64'))
    hw_facts = m.get_hw_facts()
    assert hw_facts['model'] == '9000/800'


# Generated at 2022-06-20 17:25:51.608714
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    hw = HPUXHardware()
    cpu_facts = hw.get_cpu_facts({'ansible_distribution_version': "B.11.23", 'ansible_architecture': "ia64"})
    assert cpu_facts == {'processor_count': 2}
    cpu_facts = hw.get_cpu_facts({'ansible_distribution_version': "B.11.23", 'ansible_architecture': "9000/785"})
    assert cpu_facts == {'processor_count': 4}
    cpu_facts = hw.get_cpu_facts({'ansible_distribution_version': "B.11.31", 'ansible_architecture': "ia64"})
    assert cpu

# Generated at 2022-06-20 17:25:58.210940
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(dict(ANSIBLE_MODULE_ARGS=dict(gather_subset='!all,!min', gather_timeout=10)))
    facts = module.params['ANSIBLE_MODULE_ARGS']
    h = HPUXHardware(module)
    facts.update(h.populate())
    rc, out, err = module.run_command("model")
    assert facts['model'] == out.strip()
    rc, out, err = module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    assert facts['firmware_version'] == out.split(separator)[1].strip()

# Generated at 2022-06-20 17:26:07.929014
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw_facts = {}

    memory_facts = {'memfree_mb': 467,
                    'memtotal_mb': 652,
                    'swaptotal_mb': 963,
                    'swapfree_mb': 963}

    hardware = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    hardware.module.run_command = lambda *args, **kwargs: (0, "87917        853    57344    80544    5411", "")
    hardware.collect_platform_facts = lambda: hw_facts
    hardware.collect_file_facts = lambda: hw_facts
    hardware.get_cpu_facts = lambda: hw_facts
    hardware.get_hw_facts = lambda: h

# Generated at 2022-06-20 17:26:19.263589
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    class TestModule(object):
        def __init__(self):
            self.run_command = MockFunction()

        def run_command(self):
            return [0, "/usr/contrib/bin/machinfo\nIntel(R) Itanium(R) Processor Family (1.6 GHz, 4 MB)\nMemory = 16384 MB\nRegion size = 256 MB\n\nNumber of CPUs = 4\nInstalled CPUs = 4\n\nLogical processors per socket = 4\nLogical processors per core = 1\nHyperthreading = ON\n\nNumber of sockets = 1\nModel = zx6000\nMachine serial number = FOO1234567", '']

    module = TestModule()

    output = dict()
    HPUXHardware(module).populate(output)

    assert output['processor_count'] == 4

# Generated at 2022-06-20 17:26:31.420631
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {'ansible_architecture': '9000/800'}
    hpux_hw = HPUXHardware({'module': type('Module', (object,), {'run_command': lambda self, cmd, use_unsafe_shell: (0, '8', '')})})
    processor_count = hpux_hw.get_cpu_facts(collected_facts)['processor_count']
    assert processor_count == 8
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hpux_hw = HPUXHardware({'module': type('Module', (object,), {'run_command': lambda self, cmd, use_unsafe_shell: ('0', '4', '')})})
    processor_count

# Generated at 2022-06-20 17:26:42.855834
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    # Given: a dictionary with a ansible_architecture key with ia64 value,
    # and a ansible_distribution_version key with value B.11.23.
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }

    # When: the get_hw_facts method is invoked
    hpux_hardware = HPUXHardware()
    hw_facts = hpux_hardware.get_hw_facts(collected_facts=collected_facts)

    # Then: the correct hardware facts should be returned

# Generated at 2022-06-20 17:26:53.637898
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = HPUXHardware()
    memory_facts = {
        'ansible_facts': {
            'ansible_architecture': '9000/800',
            'ansible_memfree_mb': {'real': 25396, 'swap': 0},
            'ansible_memtotal_mb': {'real': 671752, 'swap': 2097148},
            'ansible_swapfree_mb': 2097148,
            'ansible_swaptotal_mb': 2097148,
        }
    }

    cpu_facts = {
        'ansible_facts': {
            'ansible_architecture': '9000/800',
            'ansible_processor_cores': 4,
            'ansible_processor_count': 4,
        }
    }


# Generated at 2022-06-20 17:26:58.838080
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleStub(platform="HP-UX")
    module.run_command = run_command_stub
    hardware = HPUXHardware(module)
    hw_facts = hardware.get_hw_facts()
    assert hw_facts['model'] == 'HP-UX_B.11.31_ia64'
    assert hw_facts['firmware_version'] == 'B.11.31.1902'



# Generated at 2022-06-20 17:27:03.932256
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MagicMock()
    hw = HPUXHardware(module)

    # Test when we have a valid value
    module.run_command.return_value = (0, 'B180', '')
    hw.get_hw_facts()
    assert hw.facts['model'] == 'B180'

    # Test when we don't have a valid value
    module.run_command.return_value = (1, '', '')
    hw.get_hw_facts()
    assert hw.facts['model'] == 'Unknown'