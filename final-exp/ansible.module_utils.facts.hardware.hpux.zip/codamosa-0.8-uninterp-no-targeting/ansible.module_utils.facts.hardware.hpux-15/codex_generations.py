

# Generated at 2022-06-20 17:17:55.594556
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    testobj = HPUXHardware(None)
    data = {'ansible_architecture': 'ia64'}
    out = testobj.get_hw_facts(collected_facts=data)
    assert out['model'] == "ia64 hp server rx7620"
    assert out['firmware_version'] == "v2.70"
    assert out['product_serial'] == "US1234567890"



# Generated at 2022-06-20 17:18:04.933245
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule({})
    module.params = {}
    module.run_command = Mock(return_value=('0', 'out', 'err'))
    hw = HPUXHardware(module)
    hw.module.run_command = Mock(return_value=('0', 'out', 'err'))
    # Test for release PA-RISC 11.31
    hw.module.get_bin_path = Mock(return_value="/usr/contrib/bin/machinfo")
    hw.module.facts = dict(ansible_architecture='9000/800',
                           ansible_distribution='HP-UX',
                           ansible_distribution_version='B.11.31')
    cpu_facts = hw.get_cpu_facts()

# Generated at 2022-06-20 17:18:16.408308
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule({})
    data = {}
    hpux_hardware = HPUXHardware(module)
    result = hpux_hardware.populate(collected_facts=data)
    assert isinstance(result, dict)
    assert result['processor_count'] == 2
    assert result['processor_cores'] == 2
    assert result['processor'] == 'Intel(R) Xeon(R) CPU            E5506  @ 2.13GHz'
    assert result['memtotal_mb'] == 4096
    assert result['memfree_mb'] == 2775
    assert result['swaptotal_mb'] == 8191
    assert result['swapfree_mb'] == 8191
    assert result['model'] == 'ia64 hp server rx2600'

# Generated at 2022-06-20 17:18:20.774336
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hw = HPUXHardware(module=module)
    assert hw.platform == 'HP-UX'



# Generated at 2022-06-20 17:18:24.283767
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector()
    assert hc._fact_class is HPUXHardware
    assert hc._platform is 'HP-UX'
    assert hc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:18:34.893936
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    test_obj = HPUXHardware()
    result = test_obj.get_hw_facts(collected_facts)
    assert result == {}
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    result = test_obj.get_hw_facts(collected_facts)
    assert result == {}
    collected_facts = {'ansible_architecture': '9000/785'}
    result = test_obj.get_hw_facts(collected_facts)
    assert result == {}


# Generated at 2022-06-20 17:18:41.448200
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module)
    hardware.populate()

    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware.facts['model'] == 'ia64 hp integrity rx6600'
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 15089
    assert hardware.facts['swaptotal_mb'] == 128
    assert hardware.facts['swapfree_mb'] == 128
    assert hardware.facts['firmware_version'] == 'v4  21.3a'

# Generated at 2022-06-20 17:18:42.644110
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    mod = AnsibleModule(argument_spec=dict())
    host = HPUXHardware(module=mod)
    assert host.platform == 'HP-UX'


# Generated at 2022-06-20 17:18:47.755302
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware(dict(module=dict(run_command=run_command_mock)))
    hw_facts = hardware.get_hw_facts({'ansible_distribution': 'HP-UX'})

    assert 'model' in hw_facts
    assert 'firmware' in hw_facts


# Generated at 2022-06-20 17:18:49.744110
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware()
    assert hardware_obj.platform == 'HP-UX'


# Generated at 2022-06-20 17:19:01.399877
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpx = HPUXHardwareCollector()
    assert hpx.fact_class == HPUXHardware
    assert hpx.platform == 'HP-UX'
    assert hpx.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 17:19:09.718664
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HPUXHardware.module = None
    HPUXHardware.module = MockModule()
    HPUXHardware.module.run_command.return_value = (0, "i2", "")
    hpux_hardware = HPUXHardware({})

    HPUXHardware.module.run_command.assert_called_with("model")
    assert hpux_hardware.data['model'] == 'i2'


# Generated at 2022-06-20 17:19:19.062770
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {
        'platform': 'HP-UX',
        'architecture': 'ia64',
        'distribution': 'HP-UX',
        'system': 'HP-UX',
        'distribution_version': 'B.11.31',
        'distribution_release': '11.31',
    }
    hardware = HPUXHardware(ansible_facts=facts, module=None)
    cpu_facts = hardware.get_cpu_facts()
#    assert cpu_facts.get('processor_count') == 32
    assert cpu_facts.get('processor_cores') == 32
    assert cpu_facts.get('processor') == 'Intel(R) Itanium(R) CPU P8900  @ 2.40GHz'


# Generated at 2022-06-20 17:19:21.304521
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hw = HPUXHardware()
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:19:33.003197
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardwareCollector(None)
    # Normal case
    hw_facts_collected = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23',
        'ansible_distribution_major_version': 'B.11'
    }
    hw_facts = hw.populate(collected_facts=hw_facts_collected)
    assert hw_facts.get('processor') is not None
    assert hw_facts.get('processor_cores') is not None
    assert hw_facts.get('processor_count') is not None
    assert hw_facts.get('firmware_version') is not None

# Generated at 2022-06-20 17:19:37.732662
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModuleMock()
    hardware_collector = HPUXHardwareCollector(module=module)
    assert hardware_collector._fact_class == HPUXHardware



# Generated at 2022-06-20 17:19:44.066064
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    hardware = HPUXHardware()
    cpu_facts = hardware.get_cpu_facts(collected_facts)

    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0
    assert cpu_facts['processor'] is not None


# Generated at 2022-06-20 17:19:45.406261
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-20 17:19:47.723931
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    fact = HPUXHardwareCollector().collect()[0]
    assert fact.platform == 'HP-UX'

# Generated at 2022-06-20 17:19:53.313856
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts)
    assert hw_facts is not None
    assert hw_facts['firmware_version'] == 'B.11.11.0351.2023'
    assert hw_facts['model'] == 'ia64 hp Integrity rx2800 i2 Server'


# Generated at 2022-06-20 17:20:13.900330
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'ia64', '')
    facts = HPUXHardware()
    facts.module = module
    assert facts.get_hw_facts() == {'model': 'ia64'}
    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'ia64', '')
    assert facts.get_hw_facts({'ansible_architecture': 'ia64'}) == {'model': 'ia64'}
    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'B.11.23', '')

# Generated at 2022-06-20 17:20:19.095237
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX'
    }
    collector = HPUXHardwareCollector(facts=facts, module=None)
    assert str(collector) == 'HP-UX Hardware Facts Collector'

# Generated at 2022-06-20 17:20:31.722330
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    # Create an instance of class HPUXHardware
    hpu = HPUXHardware()

    # Create a dict containing facts collected on HP-UX platform
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.23'}

    # Create another dict containing expected results
    expected_results = {'processor': 'Intel Itanium 2 9000 series (9040)',
                        'processor_cores': '4',
                        'processor_count': '2',
                        'memfree_mb': '245',
                        'memtotal_mb': '5024',
                        'swapfree_mb': '0',
                        'swaptotal_mb': '0'}

    # Call method populate with the created dict as a

# Generated at 2022-06-20 17:20:38.249380
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hpux_hardware_facts = HPUXHardware(module)

    assert hpux_hardware_facts.platform == 'HP-UX'
    assert set(hpux_hardware_facts.processor.keys()) == set(['architecture', 'models', 'count', 'cores', 'cpu_threads'])
    assert set(hpux_hardware_facts.memory.keys()) == set(['memtotal', 'memfree', 'swaptotal', 'swapfree'])
    assert set(hpux_hardware_facts.system.keys()) == set(['firmware', 'system', 'uuid', 'serialnumber'])



# Generated at 2022-06-20 17:20:47.529908
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware(dict(module=dict()))
    hardware.module.run_command = lambda *args, **kwargs: (0, "", "")

# Generated at 2022-06-20 17:20:50.126074
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    obj = HPUXHardwareCollector()
    assert obj.__class__ == HPUXHardwareCollector
    assert obj._fact_class == HPUXHardware
    assert obj._platform == 'HP-UX'
    assert obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:21:03.133561
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class ModuleStub:

        def __init__(self):
            self.run_command_called = False
            self.run_command_args = None
            self.run_command_kwargs = None

        def run_command(self, *args, **kwargs):
            self.run_command_called = True
            self.run_command_args = args
            self.run_command_kwargs = kwargs
            return 0, 'HP Integrity BL860c i2', ''

    class FactsCollectorStub:

        def __init__(self):
            self.get_all_facts_called = False

        def get_all_facts(self):
            self.get_all_facts_called = True

# Generated at 2022-06-20 17:21:05.006752
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_facts = HPUXHardware()
    assert hardware_facts.platform == 'HP-UX'


# Generated at 2022-06-20 17:21:10.497948
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command = lambda *a, **kw: (0, 'out', '')
    obj = HPUXHardware(TestModule())
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    result = obj.get_hw_facts(collected_facts=collected_facts)
    assert result == {'model': 'out', 'firmware_version': '1.29'}

# Generated at 2022-06-20 17:21:23.335187
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_facts = dict()
    hpux_facts['platform'] = 'HP-UX'
    hpux_facts['distribution'] = 'HP-UX'
    hpux_facts['module_hw'] = True
    hpux_facts['ansible_architecture'] = 'ia64'
    hpux_facts['ansible_distribution_version'] = 'B.11.23'
    hw = HPUXHardware(module=None)
    hw.populate(collected_facts=hpux_facts)
    assert hw.facts['memfree_mb'] > 0
    assert hw.facts['memtotal_mb'] > 0
    assert hw.facts['swaptotal_mb'] > 0
    assert hw.facts['swapfree_mb'] > 0

# Generated at 2022-06-20 17:21:43.536343
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hardware = HPUXHardware(module=module)
    # Test output with ia64 architecture
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor '

# Generated at 2022-06-20 17:21:52.733800
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    import platform
    import sys
    import ansible.module_utils.facts.hardware.hpux
    import ansible.module_utils.facts.hardware.base

    if sys.version_info.major < 3:
        builtin_module_name = '__builtin__'
    else:
        builtin_module_name = 'builtins'

    facts = {
        'platform': platform.system(),
        'distribution': 'HP-UX'
    }

    hardware_collector = HPUXHardwareCollector(module=None, facts=facts)
    assert isinstance(hardware_collector._fact_class, ansible.module_utils.facts.hardware.hpux.HPUXHardware)
    assert hardware_collector._fact_class.platform == 'HP-UX'

    assert ansible.module_utils

# Generated at 2022-06-20 17:21:59.420430
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec=dict())
    hw = HPUXHardware(module)
    assert hw.module == module
    assert hw.facts == {}
    assert hw.platform == 'HP-UX'
    assert hw.subplatform == ''
    assert hw.collector._fact_class == hw.__class__


# Generated at 2022-06-20 17:22:07.661456
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware_obj = HPUXHardware(module)

    gathered_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    module.run_command = FakeRunCommand(0, "Physical: 11840K bytes", '', '')

    result = hardware_obj.get_memory_facts(collected_facts=gathered_facts)
    assert result['memtotal_mb'] == 11
    assert result['memfree_mb'] == 0
    assert result['swaptotal_mb'] == 0
    assert result['swapfree_mb'] == 0

    gathered_facts = {'ansible_architecture': '9000/800'}

# Generated at 2022-06-20 17:22:18.806108
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31',
        ansible_machine='ia64',
        ansible_processor_vcpus=64,
        ansible_processor_cores=64,
        ansible_processor_count=64,
        ansible_processor='IA-64 Intel(R) Itanium',
    )
    hardware.populate(collected_facts=collected_facts)

# Generated at 2022-06-20 17:22:30.148575
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    module.params['gather_subset'] = ['all']

    hw = HPUXHardware(module)
    hw.populate()
    assert hw.facts['processor_count'] == 4
    assert hw.facts['processor'] == 'Intel(R) Itanium(R) CPU'
    assert hw.facts['processor_cores'] == 4
    assert hw.facts['memfree_mb'] == 1649
    assert hw.facts['memtotal_mb'] == 15606
    assert hw.facts['swaptotal_mb'] == 262140
    assert hw.facts['swapfree_mb'] == 0

# Generated at 2022-06-20 17:22:34.514622
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    fact = HPUXHardware(module)
    collected_facts = dict(platform='HP-UX', ansible_distribution='HP-UX', ansible_distribution_version='B.11.23', ansible_architecture='ia64')
    fact.populate(collected_facts)
    expected = dict(processor='Intel(R) Itanium(R) Processor 9340', processor_cores=2, processor_count=2)
    assert fact.get_cpu_facts(collected_facts) == expected

# Generated at 2022-06-20 17:22:39.963629
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    mock_module = type('AnsibleModule', (object,), {})
    mock_module.check_mode = False
    mock_module.exit_json = lambda *args: None
    mock_module.run_command = lambda *args, **kwargs: (0, '', '')

    hw_facts = HPUXHardware(mock_module)
    assert isinstance(hw_facts, HPUXHardware)

    for fact in ['memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb', 'processor', 'processor_cores',
                 'processor_count', 'model', 'firmware']:
        assert fact in hw_facts.populate()

# Generated at 2022-06-20 17:22:47.072624
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware(None)
    hardware._module = type('module', (object,), {'run_command': run_command})
    hardware.collect()
    assert hardware.get_hw_facts() == {'model': 'HP-UX server', 'firmware_version': 'Firmware Revision',
                                          'product_serial': 'Machine Serial Number'}



# Generated at 2022-06-20 17:22:49.836022
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = HPUXHardware()
    assert module.platform == "HP-UX"


# Generated at 2022-06-20 17:23:29.048633
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hp_m = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    hp_m.populate()
    assert hp_m.facts['processor_count'] == 2
    assert hp_m.facts['processor_cores'] == 2
    assert hp_m.facts['processor'] == 'Intel(R) Itanium 2'
    assert hp_m.facts['memtotal_mb'] == 23594
    assert hp_m.facts['swaptotal_mb'] == 131072
    assert hp_m.facts['swapfree_mb'] == 131072
    assert hp_m.facts['memfree_mb'] == 1646
    assert hp_m.facts['model'] == 'ia64 hp server rx2800 i2'

# Generated at 2022-06-20 17:23:31.723638
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 17:23:36.418630
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Create object for HPUXHardwareCollector with required arguments
    HPUX_hw_co = HPUXHardwareCollector(None)
    # Check whether __init__ method works as expected
    assert HPUX_hw_co.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-20 17:23:44.325741
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=False)

    hpuxtest = HPUXHardware(module=module)
    collected_facts = {
        'ansible_architecture': "9000/785",
        'ansible_distribution_version': "B.11.31"
    }
    cpu_facts_test = {
        'processor_count': 2,
        'processor': 'Intel(R) Itanium(R) Processor'
    }
    cpu_facts = hpuxtest.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == cpu_facts_test



# Generated at 2022-06-20 17:23:47.025720
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpu_hw = HPUXHardware()
    assert hpu_hw.platform == 'HP-UX'


# Generated at 2022-06-20 17:23:50.074943
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    assert hardware.platform == 'HP-UX'


# Generated at 2022-06-20 17:24:00.955365
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor_count': 2}
    collected_facts['ansible_architecture'] = '9000/785'
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor_count': 2}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    cpu_facts = hw.get

# Generated at 2022-06-20 17:24:12.906352
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    class TestModule(object):
        def __init__(self, run_command_results):
            self.run_command_results = run_command_results
            self.params = {'gather_subset': [], 'filter': ''}

        def run_command(self, cmd, check_rc=True, use_unsafe_shell=False):
            return self.run_command_results.pop(0)


# Generated at 2022-06-20 17:24:16.825189
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = type('AnsibleModule', (object,), {})
    hw_obj = HPUXHardware()
    hw_obj.module = module
    facts = hw_obj.populate()
    assert isinstance(facts, dict)


# Generated at 2022-06-20 17:24:24.239798
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31'
    })
    hardware.module = MagicMock()

    hardware.module.run_command.return_value = (
        0,
        '4',
        ''
    )
    hardware.module.run_command.return_value = (
        0,
        'Intel(R) Itanium(R) Processor 9320',
        ''
    )
    hardware.module.run_command.return_value = (
        0,
        '',
        ''
    )
    hardware.module.run_command.return_value = (
        0,
        '',
        ''
    )

    output = hardware.get_cpu_facts()

# Generated at 2022-06-20 17:25:05.176827
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            hostname=dict(),
            ansible_distribution=dict(default='HP-UX'),
            ansible_distribution_version=dict(default='B.11.31'),
            ansible_architecture=dict(default='ia64')
        )
    )
    # Set get_memory_facts function output
    hw_facts = HPUXHardware(module)
    hw_facts.populate()
    assert 'memfree_mb' in hw_facts.populate()
    assert 'memtotal_mb' in hw_facts.populate()
    assert 'swaptotal_mb' in hw_facts.populate()
    assert 'swapfree_mb' in hw_facts.populate()


# Generated at 2022-06-20 17:25:13.773811
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class FakeModule:
        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ioscan -FkCprocessor | wc -l":
                return 0, '12', None
            if cmd == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
                return 0, 'Number of CPUs = 4', None
            if cmd == "/usr/contrib/bin/machinfo | grep 'processor family'":
                return 0, 'processor family  Intel(r) Itanium(r) 2 family processor 9100 series', None
            return 1, None, None
    class FakeFact:
        def __init__(self, an_architecture, an_os_version):
            self.ansible_architecture = an_architecture
            self.ansible_distribution

# Generated at 2022-06-20 17:25:15.077868
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-20 17:25:20.087287
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.collector import FactsCollector

    test_module = MockModule()
    test_hardware = HPUXHardware(test_module)
    test_collector = FactsCollector(test_module, test_hardware)

    test_hardware.get_memory_facts(collected_facts=test_collector.collect())


# Generated at 2022-06-20 17:25:30.304150
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    mocked_module = MagicMock(return_value=module)
    mocked_module.run_command = MagicMock(return_value=(0,"1",""))
    h = HPUXHardware(mocked_module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    h.get_cpu_facts = MagicMock(return_value={'processor_count': 1, 'processor': 'cpu1', 'processor_cores': 1})
    h.get_memory_facts = MagicMock(return_value={'memfree_mb': 10, 'memtotal_mb': 20, 'swaptotal_mb': 30, 'swapfree_mb': 40})
    h.get_

# Generated at 2022-06-20 17:25:38.122308
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(default='', required=False),
        ),
        supports_check_mode=True,
    )

    hw = HPUXHardwareCollector(module=module, params=dict(filter='*'))
    mc = hw.collect(module=module)

    assert mc == {
        'processor': '4.00 GHz',
        'processor_cores': 2,
        'processor_count': 2
    }

# Generated at 2022-06-20 17:25:48.603192
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list')
        }
    )
    facts = HPUXHardware(module).populate()
    assert facts['processor_count'] == 1
    assert facts['processor_cores'] == 1
    assert facts['processor'] == 'Itanium 2'

    facts = dict(ansible_facts=dict(
        ansible_architecture="ia64",
        ansible_distribution_version='B.11.23'
    ))
    facts = HPUXHardware(module, facts=facts).populate()
    assert facts['processor_count'] == 32
    assert facts['processor_cores'] == 32
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor'

    facts

# Generated at 2022-06-20 17:25:51.847539
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeModule()
    h = HPUXHardware(module, {})
    h.distribution = 'B.11.31'
    h.architecture = 'ia64'
    res = h.get_hw_facts()
    assert 'model' in res


# Generated at 2022-06-20 17:26:00.938937
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode = True,
    )

    h = HPUXHardware(module=module)

    facts = dict(
        ansible_architecture='ia64',
        ansible_distribution_version='B.11.23',
    )

    hw_facts = h.get_hw_facts(facts)

    module.exit_json(
        ansible_facts=dict(
            ansible_hw_facts=hw_facts,
        ),
        changed=True
    )


# Generated at 2022-06-20 17:26:09.171907
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    mock_module = MockAnsibleModule()
    hardware_facts = HPUXHardware()
    hardware_facts.module = mock_module

    # Trying to get cpu architecture
    mock_module.run_command.return_value = (0, '', '')
    cpu_info = hardware_facts.get_cpu_facts()

    # First filter which cpu architecture is used
    if cpu_info.get('processor') == 'Intel(R) Itanium 2':
        assert cpu_info.get('processor_cores') == 4
        assert cpu_info.get('processor_count') == 2
        assert cpu_info.get('processor') == 'Intel(R) Itanium 2'

# Generated at 2022-06-20 17:27:17.433888
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module_mock = AnsibleModule(argument_spec={})
    module_mock.run_command = create_ansible_mock(rc=0, out="B.11.23\n", err='')
    hardware = HPUXHardware(module_mock)
    module_mock.run_command = create_ansible_mock(rc=0, out="Integrity rx6600 server (1.0)\n", err='')
    hw_facts = hardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})

# Generated at 2022-06-20 17:27:26.184072
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (object,), {
        'run_command': lambda args, **kargs: (0, 'data', None)
    })

    fact_class = HPUXHardware(module)
    fact_class._platform = 'HP-UX'

    memory_facts = fact_class.get_memory_facts({'ansible_architecture': '9000/800',
                                                'ansible_distribution_version': 'B.11.23'})
    assert memory_facts == {'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0}

# Generated at 2022-06-20 17:27:30.500247
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'platform': 'HP-UX', 'distribution': 'HP-UX'}
    hw = HPUXHardwareCollector(facts)
    assert hw is not None
    assert hw.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 17:27:39.413138
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    cpu_info_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hardware_obj = HPUXHardware(dict(), cpu_info_facts)
    hardware_obj.module = MagicMock()
    hardware_obj.module.run_command = MagicMock(return_value=(0, '', ''))
    hardware_obj.get_memory_facts()