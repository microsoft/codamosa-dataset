

# Generated at 2022-06-20 17:18:00.049216
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Unit test for method populate of class HPUXHardware
    """
    module = type('', (), {})
    module.run_command = run_command
    module.fail_json = lambda *args, **kwargs: False
    hpu = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': '9000/785',
                       'ansible_distribution_version': 'B.11.31',
                       'ansible_os_family': 'unix',
                       'platform': 'HP-UX'}
    hpu.populate(collected_facts)



# Generated at 2022-06-20 17:18:01.845359
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_hw = HPUXHardware(None)

    assert hpux_hw.platform == 'HP-UX'


# Generated at 2022-06-20 17:18:07.543526
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    fake_module = type('module', (object,), {})()
    fake_module.run_command = lambda *a, **kw: (0, '', '')
    hardware = HPUXHardware(fake_module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] > 0



# Generated at 2022-06-20 17:18:11.170147
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    d = HPUXHardwareCollector()
    assert d.fact_class == HPUXHardware
    assert d.fact_subclass == "Hardware"
    assert d.platform == 'HP-UX'
    assert d.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:18:14.856262
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_hpux = HPUXHardware(module)

    # Check class variables
    assert hardware_hpux.platform == 'HP-UX'
    assert hardware_hpux.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:18:23.873330
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts=set(['platform', 'distribution'])
    hw_collector = HPUXHardwareCollector()
    for name in dir(hw_collector):
        if name == 'required_facts':
            assert hw_collector.__dict__[name] == required_facts
        elif name == '_fact_class':
            assert hw_collector.__dict__[name] == HPUXHardware
        elif name == '_platform':
            assert hw_collector.__dict__[name] == 'HP-UX'


# Generated at 2022-06-20 17:18:35.187046
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # set expected return values
    expected_fact_file_content = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    expected_facts = {
        'processor': 'Intel(R) Xeon(R) CPU E7-2870 2.40GHz',
        'processor_count': 2,
        'processor_cores': 4
    }

    # set values for b.11.31

# Generated at 2022-06-20 17:18:41.831436
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(side_effect=[(0, 'n4000', ''), (0, 'B.11.31', '')])
    test_module.run_command = MagicMock(side_effect=[(0, 'Server BL870c i4', ''),
                                                     (0, 'Firmware revision = 3.31', ''),
                                                     (0, 'Machine serial number = JOHNDOE', '')])
    result = HPUXHardware().get_hw_facts()
    assert result['model'] == 'Server BL870c i4'
    assert result['product_serial'] == 'JOHNDOE'
    assert result['firmware_version'] == '3.31'



# Generated at 2022-06-20 17:18:49.501347
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Test for HP-UX IA64 running B.11.23
    hw_full_fact= {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_1 = {'processor_count': 2, 'processor_cores': 32, 'processor': 'Intel(R) Itanium(R) Processor 9350'}
    assert(HPUXHardware().get_cpu_facts(collected_facts=hw_full_fact) == cpu_1)
    # Test for HP-UX IA64 running B.11.31
    hw_full_fact= {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-20 17:18:56.290712
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hpuxtest = HPUXHardware(module)
    rc, out, err = module.run_command('echo "B5942.16.00.07.1"')
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hpuxtest.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'B5942.16.00.07.1'



# Generated at 2022-06-20 17:19:10.461401
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockANSibleModule()
    set_module_args(dict(
                     gather_subset=['all'],
                     filter=['*'],
                     fact_path='/etc/ansible/facts.d'
    ))
    hardware_facts = HPUXHardware.populate()
    assert hardware_facts['ansible_processor_count'] == 1
    assert hardware_facts['ansible_processor_cores'] == 1


# Generated at 2022-06-20 17:19:20.289372
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    This function returns data for testing method HPUXHardware.get_memory_facts
    """
    # Return data for test

# Generated at 2022-06-20 17:19:27.535456
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert isinstance(hw_collector, HardwareCollector)
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.__class__._fact_class == HPUXHardware
    assert hw_collector.__class__._platform == 'HP-UX'

# Generated at 2022-06-20 17:19:39.469101
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpu_hw = HPUXHardware()
    facts = {}
    facts['ansible_architecture'] = '9000/800'
    facts['ansible_distribution_version'] = 'B.11.31'
    facts['ansible_distribution'] = 'HP-UX'
    data = hpu_hw.get_hw_facts(facts)
    assert data == {'ansible_architecture': '9000/800',
                    'ansible_distribution_version': 'B.11.31',
                    'ansible_distribution': 'HP-UX',
                    'model': 'ia64 hp server rx2800 i2',
                    'firmware_version': '5.5.5.80.0',
                    'product_serial': 'JPG3800X9X'
                    }


# Generated at 2022-06-20 17:19:44.296011
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-20 17:19:50.739817
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = {'ansible_architecture': '9000/800',
             'ansible_distribution_version': 'B.11.23'}
    hw = HPUXHardware({})
    mem = hw.get_memory_facts(facts)
    assert mem['memfree_mb'] == '?'
    assert mem['memtotal_mb'] == '?'
    assert mem['swapfree_mb'] == '?'
    assert mem['swaptotal_mb'] == '?'

# Generated at 2022-06-20 17:19:58.516939
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import tempfile
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.module.exit_json = exit_json
    hardware.get_cpu_facts({'ansible_architecture': 'ia64',
                            'ansible_distribution_version': 'B.11.23'})
    hardware.get_cpu_facts({'ansible_architecture': 'ia64',
                            'ansible_distribution_version': 'B.11.31'})
    hardware.get_cpu_facts({'ansible_architecture': 'ia64',
                            'ansible_distribution_version': 'B.11.31'})

# Generated at 2022-06-20 17:20:03.450333
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec=dict())

    # create an instance of HPUXHardware
    hw = HPUXHardware(module)

    # check the properties of HPUXHardware
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-20 17:20:12.749391
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    out = """
processor_count=4
platform=HP-UX
processor=Intel(R) Itanium(R)
processor_cores=4
    """
    test = HPUXHardware()
    collected_facs = {'ansible_architecture': 'ia64'}
    collected_facs['ansible_distribution'] = 'HP-UX'
    collected_facs['ansible_distribution_version'] = 'B.11.31'
    result = test.get_cpu_facts(collected_facts=collected_facs)
    assert result == eval(out)



# Generated at 2022-06-20 17:20:22.967967
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    collected_facts = dict(
        platform='HP-UX',
        distribution_major_version=11,
        distribution_version='B.11.31',
        ansible_architecture='ia64',
    )
    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9310'



# Generated at 2022-06-20 17:20:36.693846
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test get_hw_facts method of HPUXHardware class.
    """
    fake_module = FakeModule(platform='HP-UX', distribution='HPUX')
    fake_HPUXHardware = HPUXHardware(fake_module)

    fake_module.run_command.return_value = (0, 'Fake model', '')
    hw_facts = fake_HPUXHardware.get_hw_facts()

    assert hw_facts['model'] == 'Fake model'
    assert hw_facts['firmware_version'] == 'I46 11/19/2014'
    assert hw_facts['product_serial'] == 'ABC123456789'



# Generated at 2022-06-20 17:20:40.646322
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({
        'distribution': 'HP-UX',
        'distribution_version': 'B.11.31',
        'ansible_architecture': 'ia64'
    })

    hardware.get_hw_facts()


# Generated at 2022-06-20 17:20:49.318646
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Unit test for method HPUXHardware.populate
    """
    hpux_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hardware_facts = HPUXHardware(dict(module=None)).populate(collected_facts=hpux_facts)
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'Intel(R) Xeon(R) CPU E7-8893 v4  @ 2.40GHz'
    assert hardware_facts['processor_cores'] == 22
    assert hardware_facts['memfree_mb'] == 7132
    assert hardware_facts['memtotal_mb'] == 144780
    assert hardware_facts['swaptotal_mb'] == 20040
    assert hardware_facts

# Generated at 2022-06-20 17:20:52.936009
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    result1 = hardware.get_memory_facts()
    assert result1['memtotal_mb']
    assert result1['swaptotal_mb']
    assert result1['memfree_mb']
    assert result1['swapfree_mb']

# Generated at 2022-06-20 17:21:06.033303
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts import FactCollector

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    collected_facts = dict(
        ansible_architecture='9000/800',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31',
        ansible_os_family='UNIX')

    hw = HPUXHardware(module)
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)

    assert isinstance(cpu_facts, dict)
    assert cpu_facts.get('processor') == 'Intel(r) Itanium(r) Processor'
    assert cpu_facts.get('processor_cores') == 7
    assert cpu_facts.get('processor_count')

# Generated at 2022-06-20 17:21:08.032512
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware(dict(platform='HP-UX', distribution='HP-UX'))
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-20 17:21:21.033675
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware()
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.44'
    }

    hw_facts = hw.populate(collected_facts)

    assert hw_facts.get('ansible_architecture') == '9000/800'
    assert hw_facts.get('ansible_distribution_version') == 'B.11.44'
    assert hw_facts.get('processor_count')
    assert hw_facts.get('memtotal_mb')
    assert hw_facts.get('swapfree_mb')
    assert hw_facts.get('swaptotal_mb')



# Generated at 2022-06-20 17:21:32.276548
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()

    # FIXME: ia64 and itanium modules not available
    #ia64_module = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

    parisc_module = {'ansible_architecture': '9000/800'}
    #ia64_collected_facts = hardware.get_memory_facts(collected_facts=ia64_module)
    parisc_collected_facts = hardware.get_memory_facts(collected_facts=parisc_module)

    #assert ia64_collected_facts['memtotal_mb'] > 0
    #assert ia64_collected_facts['memfree_mb'] > 0
    #assert ia64_collected_facts['swaptotal_mb

# Generated at 2022-06-20 17:21:39.014199
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Import needed for unit testing
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    h = HPUXHardware()
    h.module = MagicMock()
    h.module.run_command.return_value = (0, 'IA64 hp server rx8620  HVERSION "B.11.31 U ia64 19073618760"  IODVERSION "B.11.31.06 ia64"\n', '')
    a = h.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"})
    assert a.get('model') == 'IA64 hp server rx8620'
    assert a.get('firmware_version') == 'B.11.31.06'
   

# Generated at 2022-06-20 17:21:46.580568
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Unit test for method get_cpu_facts of class HPUXHardware
    """
    hpu = HPUXHardware()
    cpu_facts_result = {
        'processor': 'Intel(R) Xeon(R) CPU E7-2860 0 @ 2.26GHz',
        'processor_cores': 1,
        'processor_count': 1
    }
    cpu_facts = hpu.get_cpu_facts()
    assert cpu_facts == cpu_facts_result


# Generated at 2022-06-20 17:22:04.679725
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 17:22:16.273238
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware()
    hw_facts = hw.populate()
    assert "memfree_mb" in hw_facts
    assert not hw_facts.get('memtotal_mb') is None
    assert not hw_facts.get('swapfree_mb') is None
    assert not hw_facts.get('swaptotal_mb') is None
    assert "processor" in hw_facts
    assert not hw_facts.get('processor_cores') is None
    assert "processor_count" in hw_facts
    assert not hw_facts.get('model') is None
    assert not hw_facts.get('firmware_version') is None

# Generated at 2022-06-20 17:22:22.252924
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware(module=None)
    assert hardware.populate() == {
        'processor': 'Intel(R) Itanium(R) Processor',
        'processor_cores': 0,
        'processor_count': 4,
        'memfree_mb': 0,
        'memtotal_mb': 2048,
        'swapfree_mb': 0,
        'swaptotal_mb': 512,
        'firmware_version': 'V6.4.0.4',
        'model': 'ia64 hp integrity rx2660',
        'product_serial': 'B7E8752#OC'}

# Generated at 2022-06-20 17:22:26.078779
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()
    assert hhc.fact_class == HPUXHardware
    assert hhc.platform == 'HP-UX'
    assert hhc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:22:35.297684
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hpux_hardware_fact = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    cpu_facts = hpux_hardware_fact.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 10
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9560'
    collected_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31'
    }
   

# Generated at 2022-06-20 17:22:47.473854
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # initialize HPUXHardware object
    hhw = HPUXHardware()

    # mock out the module class
    hhw.module = MockModule()

    # Mocking out the 'run_command' class method
    hhw.module.run_command = MockRunCommand()

    # Mock command execution
    hhw.module.run_command.execute_command("model")
    # Command will return the following output
    out = "HP-UX B.11.31 U ia64 1604182268 unlimited-user license"
    hhw.module.run_command.set_command("model", out, 0, None)
    rc = hhw.module.run_command.execute_command("model")
    assert rc['rc'] == 0
    assert rc['stdout'] == out
    assert rc['stderr'] == 'None'



# Generated at 2022-06-20 17:22:57.153364
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    # Function to be unit-tested
    _fact_class = HPUXHardware
    _platform = 'HP-UX'

    # Empty facts
    my_hpuxhw = _fact_class()
    assert my_hpuxhw.platform == _platform
    assert my_hpuxhw.get_facts() == {}

    # Filled facts
    my_hpuxhw = _fact_class(dict(ansible_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"}))
    assert my_hpuxhw.platform == _platform
    assert my_hpuxhw.get_facts() != {}

# Generated at 2022-06-20 17:23:01.182343
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware(dict())
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"}
    hardware_facts.populate(collected_facts)
    return hardware_facts.facts

# Generated at 2022-06-20 17:23:13.775243
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Test method HPUXHardware.get_hw_facts
    """

    fake_module = FakeModule('ansible_architecture=ia64\nansible_distribution_version=B.11.23')

    hw_facts = HPUXHardware.get_hw_facts(fake_module)
    assert hw_facts['firmware_version'] == '2011.04.0'
    assert hw_facts['model'] == 'ia64 hp server rx4640'
    hw_facts = HPUXHardware.get_hw_facts(fake_module, 'ansible_distribution_version=B.11.31')
    assert hw_facts['firmware_version'] == '7SE.01.00.01.22'

# Generated at 2022-06-20 17:23:22.389539
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"}
    hardware_obj = HPUXHardware(module)
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts)
    assert cpu_facts.get('processor_count') and cpu_facts.get('processor') and cpu_facts.get('processor_cores')

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}
    hardware_obj = HPUXHardware(module)
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts)
    assert cpu

# Generated at 2022-06-20 17:23:41.264467
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self, params=None, output=None):
            self.params = params
            self.output = output

        def run_command(self, params, use_unsafe_shell=False):
            return self.output

    class MockFacts():
        def __init__(self, params=None):
            self.ansible_architecture = params["ansible_architecture"]
            self.ansible_distribution_version = params["ansible_distribution_version"]

    params = {"ansible_architecture": "ia64", "ansible_distribution_version": "B.11.23"}
    mock_facts = MockFacts(params)

# Generated at 2022-06-20 17:23:52.988226
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Mock class module
    module = get_module_mock({'ANSIBLE_MODULE_ARGS': {}})
    # Mock class Hardware
    hardware = HPUXHardware(module)
    hw_facts = hardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hw_facts['firmware_version'] == '0.0.2'
    assert hw_facts['model'] == 'ia64 hp server rx2660'
    assert hw_facts['product_serial'] == 'CZH306824V'

    hw_facts = hardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})

# Generated at 2022-06-20 17:23:55.613629
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()
    assert hhc.fact_class == HPUXHardware
    assert hhc.platform == 'HP-UX'
    assert hhc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:23:59.108849
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hh = HPUXHardware({'distribution': 'HP-UX'})
    assert hh is not None
    assert isinstance(hh, HPUXHardware)
    assert isinstance(hh, Hardware)

# Generated at 2022-06-20 17:24:03.165913
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hw = HPUXHardwareCollector()
    assert hpux_hw.platform == 'HP-UX'
    assert hpux_hw.required_facts == set(['platform', 'distribution'])
    assert hpux_hw._fact_class == HPUXHardware
    assert hpux_hw._platform == 'HP-UX'

# Generated at 2022-06-20 17:24:09.019875
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts = {'ansible_distribution': 'HP-UX', 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    module = FakeModule()
    hpux_hardware_object = HPUXHardware(module=module, facts=facts)
    expected = {'model': 'HP Integrity Superdome 2 4s', 'firmware_version': 'L61 v4.50',
                'product_serial': 'SB3H2243F8'}
    result = hpux_hardware_object.get_hw_facts()
    assert sorted(expected) == sorted(result)



# Generated at 2022-06-20 17:24:10.323494
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """
    Test the constructor of class HPUXHardware
    """
    HPUXHardware()



# Generated at 2022-06-20 17:24:16.912732
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Initialization
    module = FakeAnsibleModule()
    module.run_command = MagicMock()
    result = dict()
    result['model'] = 'HP Integrity rx2620'
    module.run_command.return_value = (0, result['model'], '')

    # Processing
    hpuxhw = HPUXHardware(module)
    hpuxhw.get_hw_facts()

    # Verification
    assert hpuxhw.facts == result


# Generated at 2022-06-20 17:24:26.968491
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test case to test get_cpu_facts method of class HPUXHardware
    """
    # Test data
    cpu_facts = {
        'processor_cores': 2,
        'processor_count': 4,
        'processor': 'Intel(R) Itanium(R) CPU   9350  @ 2.00GHz'
    }
    # Initialize class to test
    test_class = HPUXHardware()
    # Call method to test
    collected_facts = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    result = test_class.get_cpu_facts(collected_facts=collected_facts)
    assert result == cpu_facts



# Generated at 2022-06-20 17:24:39.140050
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware(dict(module=dict()), dict())
    collected_facts = dict(ansible_architecture="ia64", ansible_distribution_version="B.11.23")
    hardware.populate(collected_facts)
    assert hardware._facts == dict(processor_count=1, processor="Intel Itanium 2", processor_cores=1)

    hardware = HPUXHardware(dict(module=dict()), dict())
    collected_facts = dict(ansible_architecture="9000/800", ansible_distribution_version="B.11.11")
    hardware.populate(collected_facts)
    assert hardware._facts['processor_count'] == 1

    hardware = HPUXHardware(dict(module=dict()), dict())

# Generated at 2022-06-20 17:24:57.666868
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware.get_cpu_facts(dict(ansible_architecture='9000/800'))
    assert cpu_facts['processor_count'] == 2
    cpu_facts = HPUXHardware.get_cpu_facts(dict(ansible_architecture='9000/785'))
    assert cpu_facts['processor_count'] == 2
    cpu_facts = HPUXHardware.get_cpu_facts(dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23'))
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) 9300 series'
    cpu_facts = HPUXHardware.get_cpu_

# Generated at 2022-06-20 17:25:03.032676
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert isinstance(hw_collector, HPUXHardwareCollector)
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:25:12.301429
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hpux_hardware = HPUXHardware(module)
    # Mock collected_facts so that we can test with different architectures
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}

    memory_facts = hpux_hardware.get_memory_facts(collected_facts=collected_facts)
    assert collected_facts['ansible_architecture'] == 'ia64'
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0


# Generated at 2022-06-20 17:25:21.724683
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = MockModule()
    test_module.run_command = Mock(side_effect=[(0, '/usr/bin/vmstat | tail -1 out', ''),
                                                (0, 'grep Physical /var/adm/syslog/syslog.log out', ''),
                                                (0, 'phys_mem_pages/D | adb -k /stand/vmunix /dev/kmem | tail -1 | awk \'{print $2}\' out', ''),
                                                (0, 'Memory out out', ''),
                                                (0, '/usr/sbin/swapinfo -m -d -f -q out', ''),
                                                (0, '/usr/sbin/swapinfo -m -d -f | egrep \'^dev|^fs\' out', '')])



# Generated at 2022-06-20 17:25:31.665775
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Test :meth:`ansible.module_utils.facts.hardware.hpux.HPUXHardware.populate`
    """
    module = MockModule()
    pc = HPUXHardwareCollector(module=module)
    facts_dict = HPUXHardware(module).populate()
    assert facts_dict['processor'] == 'Intel(R) Xeon(R) CPU E5410 @ 2.33GHz'
    assert facts_dict['processor_cores'] == 12
    assert facts_dict['processor_count'] == 2
    assert facts_dict['memtotal_mb'] == 524288
    assert facts_dict['memfree_mb'] == 52408
    assert facts_dict['swaptotal_mb'] == 2047
    assert facts_dict['swapfree_mb'] == 1778
    assert facts_

# Generated at 2022-06-20 17:25:37.993233
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module=module)
    assert hardware.platform == 'HP-UX'
    assert isinstance(hardware.cpu, dict)
    assert isinstance(hardware.memory, dict)
    assert isinstance(hardware.module, AnsibleModuleMock)



# Generated at 2022-06-20 17:25:39.998776
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_obj = HPUXHardware()
    assert hardware_obj.platform == 'HP-UX'

# Generated at 2022-06-20 17:25:45.505307
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    mod = AnsibleModule(
        argument_spec={'gather_subset': dict(type='list')},
        supports_check_mode=False)
    facts = HPUXHardware(mod).populate()
    assert facts.get('processor_count') > 0
    assert facts.get('processor_cores') > 0
    assert facts.get('memtotal_mb') > 0

# Generated at 2022-06-20 17:25:48.891294
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardwareCollector().get_facts().get('hardware')
    assert hardware.get('model')
    assert hardware.get('firmware_version')
    if hardware.get('product_serial'):
        assert hardware.get('product_serial')


# Generated at 2022-06-20 17:25:53.010803
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, "", "")

    hpux_hw = HPUXHardware(module=module)
    hpux_hw.get_memory_facts()

    assert hpux_hw.facts['memtotal_mb'] == hpux_hw.facts['swaptotal_mb'] + hpux_hw.facts['memfree_mb']

# Generated at 2022-06-20 17:26:17.723253
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    test_data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'test', '')

    test = HPUXHardware(module)

# Generated at 2022-06-20 17:26:23.239954
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpuxhardware = HPUXHardwareCollector()
    assert hpuxhardware._fact_class == HPUXHardware
    assert hpuxhardware._platform == 'HP-UX'
    assert hpuxhardware.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:26:30.682226
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.exit_json = exit_json
    module.fail_json = fail_json
    hw = HPUXHardware()
    if hw.is_platform_supported():
        hw.populate()
        facts = hw.get_facts()
        module.exit_json(changed=False, ansible_facts=facts)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 17:26:42.201352
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    result = hardware.populate()
    assert result.get('processor') == 'Intel(R) Xeon(R) CPU E5-2690 0 @ 2.90GHz'
    assert result.get('processor_cores') == 16
    assert result.get('processor_count') == 2
    assert result.get('memtotal_mb') == 16384
    assert result.get('memfree_mb') == 5084
    assert result.get('swaptotal_mb') == 0
    assert result.get('swapfree_mb') == 0
    assert result.get('model') == 'ia64 hp server rx2800 i2'
    assert result.get('firmware_version') == 'v5.7.1'



# Generated at 2022-06-20 17:26:44.189154
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    '''
    Unit test for class HPUXHardware
    '''
    hh = HPUXHardware()
    assert(not hh.populate())


# Generated at 2022-06-20 17:26:50.960655
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    """Test HP-UXHardware class constructor"""
    module = type('obj', (object,), {'run_command': run_command, '_fetch_file': _fetch_file, 'NO_SHARED_MEMORY_SUPPORT': True})
    hw = HPUXHardware(module)
    assert hw.platform == 'HP-UX'



# Generated at 2022-06-20 17:26:59.170312
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    import ansible.module_utils.facts.hardware.hpux

    facts = {}
    hardware = HPUXHardware(facts)
    collected_facts = {'ansible_distribution': 'HP-UX', 'ansible_architecture': 'ia64'}
    hardware.populate(collected_facts)

    assert hardware.populate(collected_facts) == {'model': 'ia64 hp server rx2800 i2',
                                                  'firmware_version': 'B.11.23',
                                                  'product_serial': 'MXE302W8ZMT'}

# Generated at 2022-06-20 17:27:03.933421
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    collect_facts = False
    fake_module = type('FakeModule', (object,), dict(
        get_bin_path=lambda x, y: None,
        run_command=lambda x, *args, **kwargs: (0, None, None)
    ))
    fake_module = fake_module()
    hardware = HPUXHardware(fake_module, collect_facts)

    assert hardware is not None
    assert hardware.module is fake_module
    assert hardware.collect_facts == collect_facts

# Generated at 2022-06-20 17:27:15.415371
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'ia64', ''))
    module.run_command = MagicMock(return_value=(0, 'HP-UX', ''))
    module.run_command = MagicMock(return_value=(0, 'B.11.23', ''))
    module.run_command = MagicMock(return_value=(0, '9000/785', ''))
    module.run_command = MagicMock(return_value=(0, '9000/800', ''))
    module.run_command = MagicMock(return_value=(0, 'HP-UX 11.31 ia64', ''))

# Generated at 2022-06-20 17:27:18.591450
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hpux_hw = HPUXHardware({'ansible_architecture': '9000/800'})

