

# Generated at 2022-06-20 17:18:00.199494
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.mock_command('/usr/bin/vmstat')
    module.mock_command('/usr/contrib/bin/machinfo')
    module.mock_command('/usr/sbin/swapinfo -m -d -f -q')
    module.mock_command('/usr/sbin/swapinfo -m -d -f | egrep \'^dev|^fs\'', """
        dev: 0Mb
        fs:  0Mb
        dev: 0Mb
        fs:  0Mb
        dev: 0Mb
        fs:  0Mb
    """)

# Generated at 2022-06-20 17:18:10.914027
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h = HPUXHardware()

    memory_facts = {'system': 'HP-UX', 'architecture': '9000/800'}
    facts = h.get_cpu_facts(memory_facts)
    assert facts['processor_count'] == 2

    memory_facts = {'system': 'HP-UX', 'architecture': '9000/785'}
    facts = h.get_cpu_facts(memory_facts)
    assert facts['processor_count'] == 2

    memory_facts = {'system': 'HP-UX', 'architecture': 'ia64', 'distribution_release': 'B.11.31'}
    facts = h.get_cpu_facts(memory_facts)
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 8

# Generated at 2022-06-20 17:18:12.536432
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    h = HPUXHardware()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-20 17:18:20.653216
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts_dict = {'ansible_facts': {'ansible_architecture': 'ia64',
                                    'ansible_distribution': 'HP-UX',
                                    'ansible_distribution_version': 'B.11.23'}}
    HPUXHardwareObject = HPUXHardware(None, None, facts_dict)
    hw_facts = HPUXHardwareObject.get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp blade BL860c'
    assert hw_facts['firmware_version'] == '6.2.2 Build 05032031'
    assert hw_facts['product_serial'] == 'CZC0112T7T'


# Generated at 2022-06-20 17:18:28.993535
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "HP9000/844", ""))
    hardware = HPUXHardware(module)
    hw_facts = hardware.get_hw_facts()
    assert hw_facts['model'] == 'HP9000/844'
    module.run_command = MagicMock(return_value=(0, "Firmware revision = HPUX", ""))
    hw_facts = hardware.get_hw_facts()
    assert hw_facts['firmware_version'] == 'HPUX'


# Generated at 2022-06-20 17:18:39.026709
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module=module)
    hardware_collector.collect()
    hardware_facts = hardware_collector.get_facts()

    assert hardware_facts['memfree_mb'] == '1012'
    assert hardware_facts['memtotal_mb'] == '4096'
    assert hardware_facts['processor_count'] == '2'
    assert hardware_facts['processor_cores'] == '1'
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor 9350'
    assert hardware_facts['model'] == 'HP rx2660'
    assert hardware_facts['firmware_version'] == '6.0'

# Generated at 2022-06-20 17:18:51.601478
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts_collector = HPUXHardware(module=module)
    facts = facts_collector.populate()

    assert facts['processor'] in ['Intel(R) Itanium(R) 9500 series processors',
                                  'Intel(R) Itanium(R) 9300 series processors',
                                  'Intel(R) Itanium(R) 9100 series processors',
                                  'Intel(R) Itanium(R) 2 processors',
                                  'Intel(R) Itanium(R) processors']
    assert facts['processor_cores'] == 2
    assert facts['processor_count'] == 2
    assert facts['model'] in ['HP Integrity Superdome', 'HP Integrity rx2620', 'HP Integrity rx6600', 'HP 9000']
    assert facts['firmware_version']

# Generated at 2022-06-20 17:19:02.100058
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.hpux import HPUXHardwareCollector
    from ansible.module_utils.facts.collector import Collector

    hw = HPUXHardware(dict(ansible_facts=dict()), module=None)
    # Test case: B.11.31
    module_output = {'ansible_distribution_version': 'B.11.31',
                     'ansible_architecture': 'ia64'}

# Generated at 2022-06-20 17:19:14.888261
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = FakeModule()
    HardwareCollector.set_module(module)
    hpux_hw = HPUXHardwareCollector.collect()
    assert module.run_command.call_count == 5
    assert hpux_hw.memfree_mb == 12
    assert hpux_hw.memtotal_mb == 20
    assert hpux_hw.swaptotal_mb == 30
    assert hpux_hw.swapfree_mb == 25
    assert hpux_hw.model == 'HP Integrity Server rx2660'
    assert hpux_hw.processor == 'Intel(R) Itanium(R) Processor'
    assert hpux_hw.processor_cores == 2
    assert hpux_hw.processor_count == 2
    assert hpux_hw.firmware_version == 'h'

# Generated at 2022-06-20 17:19:16.566999
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({})
    assert hardware.platform == 'HP-UX'



# Generated at 2022-06-20 17:19:30.796305
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:19:43.193338
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import pytest
    module = pytest.init(python_version='2.7.15')
    hardware_object = HPUXHardware(module=module, collected_facts={})
    hardware_object.module.run_command = lambda x: (0, '9', '')
    hardware_object.module.run_command = lambda x: (0, '4096', '')
    hardware_object.module.run_command = lambda x: (0, 'Physical: 1052 Kbytes\n', '')
    hardware_object.module.run_command = lambda x: (0, 'dev/vg00/swap         1234MB    1234MB    1234MB    1234MB', '')

# Generated at 2022-06-20 17:19:48.106468
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector()
    assert hwc._platform == 'HP-UX', 'Test HPUXHardwareCollector object platform attribute'
    assert hwc._fact_class == HPUXHardware, 'Test HPUXHardwareCollector object fact_class attribute'
    assert hwc.required_facts == set(['platform', 'distribution'])
    # check if subclass
    assert isinstance(hwc, HardwareCollector), 'Test HPUXHardwareCollector is subclass of HardwareCollector'

# Generated at 2022-06-20 17:19:58.299147
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import os
    import subprocess
    from ansible.module_utils.facts.hardware.hpuux import HPUXHardware
    hpuux_hw = HPUXHardware(dict(), subprocess, os)
    rc, out, err = hpuux_hw.module.run_command("cat  test_hpuux_get_memory_facts.log")
    facts = hpuux_hw.get_memory_facts()
    assert facts == {'memfree_mb': 4816, 'memtotal_mb': 16391, 'swapfree_mb': 14060, 'swaptotal_mb': 14060}


# Generated at 2022-06-20 17:20:11.367401
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    my_hw = HPUXHardware()

    # basic test:
    assert my_hw.get_cpu_facts() == {'processor_count': None, 'processor': None, 'processor_cores': None}

    # test ioscan (as it is currently done)
    my_hw.module = type('module', (object,), {
        'run_command': lambda self, args, use_unsafe_shell=False: (0, "4", "")
    })()
    assert my_hw.get_cpu_facts() == {'processor_count': 4, 'processor': None, 'processor_cores': None}

    # test machinfo

# Generated at 2022-06-20 17:20:20.953570
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    HardwareCollector.collectors = [HPUXHardwareCollector]
    h = HPUXHardware(module)
    h.populate()
    assert module.exit_json.called
    assert module.exit_json.call_count == 1

    for fact in ['processor_cores', 'processor', 'processor_count',
                 'model', 'memfree_mb', 'memtotal_mb',
                 'swapfree_mb', 'swaptotal_mb']:
        assert module.exit_json.call_args[0][1].get(fact)



# Generated at 2022-06-20 17:20:31.808167
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Unit test execution method :
    - create a test class instance
    - execute get_hw_facts method
    - assert result
    """
    # Creating test class instance
    test_HPUXHardware = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}, {})
    # Executing get_hw_facts method
    data = test_HPUXHardware.get_hw_facts()
    # Test if result is as expected
    assert data.get('firmware_version') is not None and data.get('product_serial') is not None



# Generated at 2022-06-20 17:20:35.056284
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    facts = {'ansible_architecture': 'ia64'}
    hardware = HPUXHardware(module=module)
    out = hardware.get_memory_facts(collected_facts=facts)


# Generated at 2022-06-20 17:20:40.202079
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Instantiate a HPUXHardwareCollector
    hw = HPUXHardwareCollector(None)

    print('hw._fact_class : {0}'.format(hw._fact_class))
    print('hw._platform : {0}'.format(hw._platform))


# Instantiate a HPUXHardwareCollector

# Generated at 2022-06-20 17:20:49.013450
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    # Test with empty dict as collected_facts (distribution_version is None)
    hardware = HPUXHardware(None)
    cpu_facts = hardware.get_cpu_facts()
    assert isinstance(cpu_facts, dict)
    assert not cpu_facts

    # Test with dict as collected_facts (distribution_version is B.11.23)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hardware = HPUXHardware(None)
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert isinstance(cpu_facts, dict)
    assert cpu_facts['processor_count'] == 1

    # Test with dict as collected_facts (distribution_version is B.11

# Generated at 2022-06-20 17:21:07.090494
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    collected_facts = {
        "ansible_architecture": "9000/800",
        "distribution": "HP-UX",
        "distribution_major_version": "11.31"
    }
    hpux_hardware = HPUXHardware(module)
    result = hpux_hardware.populate(collected_facts=collected_facts)
    assert result['ansible_processor_cores'] == 4
    assert result['ansible_processor_count'] == 2
    assert result['ansible_memtotal_mb'] == 16384
    assert result['ansible_memfree_mb'] == 906
    assert result['ansible_swaptotal_mb'] == 2048
    assert result['ansible_swapfree_mb'] == 1062

# Generated at 2022-06-20 17:21:15.327051
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Confirms that it correctly relates a valid model number to a
    model name
    """
    hw = HPUXHardware()

    collected_facts = {}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)

    assert isinstance(hw_facts, dict)
    assert hw_facts['model'] == 'ia64 hp server rx6600'



# Generated at 2022-06-20 17:21:24.666208
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    host_local_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX',
        'architecture': 'ia64',
    }
    hardware_collector = HPUXHardwareCollector(module=None, facts=host_local_facts)

    assert hardware_collector.facts == host_local_facts
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 17:21:25.984254
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()


# Generated at 2022-06-20 17:21:35.395177
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    mock_module = MockModule(platform='HP-UX')
    facts = HPUXHardware(mock_module).populate()
    assert facts['processor_count'] == 8
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert facts['processor_cores'] == 4
    assert facts['memtotal_mb'] == 12288
    assert facts['memfree_mb'] == 1488
    assert facts['swaptotal_mb'] == 2048
    assert facts['swapfree_mb'] == 0
    assert facts['model'] == '9000/800/C8000'
    assert facts['firmware_version'] == 'v2.02 (HP-UX B.11.23 ia64) 11/30/2017'

# Mock ansible module for unit test

# Generated at 2022-06-20 17:21:47.497176
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    out_get_memory_facts = """
 memtotal_mb: 16384
 memfree_mb: 1780
 swaptotal_mb: 16384
 swapfree_mb: 13440
    """

    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=('rc', 'out', 'err'))

        def fail_json(self, *args, **kwargs):
            raise

    hardware = HPUXHardware(MockModule())

    rc, out, err = hardware.module.run_command.side_effect = [
        ('rc', '16384', 'err'),
        ('rc', '1780', 'err'),
        ('rc', '16384', 'err'),
        ('rc', '13440', 'err')
    ]

    assert hardware.get_memory

# Generated at 2022-06-20 17:21:51.745835
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collector = HPUXHardwareCollector()
    hardware = collector.get_facts()
    assert hardware['processor_count'] == 2
    assert hardware['processor'] == 'Intel(R) Itanium(R) I4980M'
    assert hardware['processor_cores'] == 16
    assert hardware['memfree_mb'] > 0
    assert hardware['swaptotal_mb'] > 0

# Generated at 2022-06-20 17:22:03.929886
# Unit test for method get_hw_facts of class HPUXHardware

# Generated at 2022-06-20 17:22:16.687818
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test method get_cpu_facts() of class HPUXHardware
    """
    hpx_hardware = HPUXHardware()

    # IA64 - 1 core
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
    }
    expected_facts = {
        'processor_count': 1,
        'processor': 'Intel(R) Itanium(R) Processor 9340  (1.60GHz, 131072KB Cache) 1.60GHz',
        'processor_cores': 1
    }
    hpx_hardware.module.run_command = lambda x, **kwargs: (0,  '', '')
    facts = hpx_hardware.get_cpu_facts(collected_facts)


# Generated at 2022-06-20 17:22:19.048324
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'

# Generated at 2022-06-20 17:22:26.587857
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware = HPUXHardware(module)
    hardware.populate()

# Generated at 2022-06-20 17:22:33.425420
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_test = HPUXHardware()
    hw_test.module = "name"
    expected = {"firmware_version": "I49 v2.94", "product_serial": "100001C0A9A"}
    mocked_hw_facts = {"ansible_architecture": "ia64", "ansible_distribution_version": "B.11.31"}
    hw_facts = hw_test.get_hw_facts(collected_facts=mocked_hw_facts)
    assert hw_facts == expected



# Generated at 2022-06-20 17:22:44.964161
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware(dict(ansible_architecture='9000/800',
                                       ansible_distribution_version='B.11.23'), None).populate()
    assert hardware_facts == {'processor': 'Intel(R) Itanium(R) processor 9150',
                              'processor_cores': 2,
                              'processor_count': 1,
                              'swaptotal_mb': 0,
                              'memfree_mb': 1935,
                              'memtotal_mb': 3072}

    hardware_facts = HPUXHardware(dict(ansible_architecture='9000/785',
                                       ansible_distribution_version='B.11.23'), None).populate()

# Generated at 2022-06-20 17:22:49.665174
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware({}, {}, {'platform': 'HP-UX', 'ansible_architecture': '9000/800'}, {})
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts.get('processor') is not None
    assert cpu_facts.get('processor_cores') is not None
    assert cpu_facts.get('processor_count') is not None
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts.get('processor') is not None
    assert cpu_facts.get('processor_cores') is not None
    assert cpu_facts.get('processor_count') is not None

# Generated at 2022-06-20 17:22:50.589440
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    assert HPUXHardware


# Generated at 2022-06-20 17:22:58.556171
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module=module)
    hw_facts = hardware_obj.populate()
    model = hw_facts.get('model')
    print("Hardware facts %s " % hw_facts)
    if hw_facts:
        if hw_facts.get('ansible_architecture') in ['9000/800', '9000/785']:
            assert hw_facts.get('memory_mb') == hw_facts.get('memtotal_mb')
        else:
            assert hw_facts.get('processor_count') == hw_facts.get('processor_cores')
        assert hw_facts.get('firmware_version')
        assert hw_facts.get('product_serial')

# Generated at 2022-06-20 17:23:01.076889
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware({'ansible_architecture': '9000/800'})
    assert hardware.platform == 'HP-UX'


# Generated at 2022-06-20 17:23:11.040777
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()

    # Test with PA-RISC
    collected_facts = {
        'ansible_architecture': '9000/800'
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1

    # Test with ia64
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1



# Generated at 2022-06-20 17:23:21.365703
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    h = HPUXHardware()
    assert h.get_cpu_facts()['processor_count'] == 16
    assert h.get_cpu_facts()['processor_cores'] == 16
    assert h.get_cpu_facts()['processor'] == 'Intel(R) Itanium(R) Processor 9500 series'
    assert h.get_memory_facts()['memfree_mb'] == 1215
    assert h.get_memory_facts()['memtotal_mb'] == 7680
    assert h.get_memory_facts()['swapfree_mb'] == 892
    assert h.get_memory_facts()['swaptotal_mb'] == 32000
    assert h.get_hw_facts()['firmware_version'] == 'HP-UX 11i'

# Generated at 2022-06-20 17:23:29.896875
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m_module = MockModule()
    m_module.params = {}
    HPUXHardware.module = m_module
    hw = HPUXHardware()
    # Test with IA64
    m_module.run_command.return_value = (0, "B.11.23", "")
    m_module.ansible_facts = {'ansible_architecture': 'ia64',
                              'ansible_distribution_version': "B.11.23"}
    result = hw.get_cpu_facts()
    assert result['processor_count'] == 2
    assert result['processor'] == "Itanium 2"
    assert result['processor_cores'] == 1
    # Test with 9000/800 and B.11.31

# Generated at 2022-06-20 17:23:39.859447
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    collected_facts = {
        "ansible_distribution": "HP-UX",
        "ansible_distribution_version": "B.11.31",
        "ansible_architecture": "ia64",
    }
    hardware_facts_instance = HPUXHardware(module=None, collected_facts=collected_facts)

# Generated at 2022-06-20 17:23:40.898268
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # TODO: Implement HP-UX hardware test for method populate once hpux checks are added
    pass

# Generated at 2022-06-20 17:23:52.248702
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # For test we change values of
    # - platform
    # - distribution
    # To simulate a "HPUX" platform

    # Test with platform name "HP-UX" and distribution version "B.11.31"
    res = HPUXHardwareCollector({'platform': 'HP-UX', 'distribution': 'B.11.31'})
    res2 = HPUXHardwareCollector({'platform': 'HP-UX', 'distribution': 'B.11.31'})
    res3 = HPUXHardwareCollector({'platform': 'HP-UX', 'distribution': 'B.11.31'})

    # Result must be False for all cases

# Generated at 2022-06-20 17:24:01.335848
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockAnsibleModule("cpu", "mem", "hw")
    hw = HPUXHardware(module=module)
    hw.get_cpu_facts = Mock(return_value={"processor_count": 4})
    hw.get_memory_facts = Mock(return_value={"memtotal_mb": 1024})
    hw.get_hw_facts = Mock(return_value={"firmware": "B.11.31"})
    facts = hw.populate()
    assert facts["processor_count"] == 4
    assert facts["memtotal_mb"] == 1024
    assert facts["firmware"] == "B.11.31"



# Generated at 2022-06-20 17:24:04.305936
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw._platform == 'HP-UX'
    assert isinstance(hw._fact_class, HPUXHardware)

# Generated at 2022-06-20 17:24:16.222006
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('', (HPUXHardware,), {})
    module.get_memory_facts = lambda *args: {}
    module.get_cpu_facts = lambda *args: {}
    module.module = type('', (), {})
    module.run_command = lambda *args: [0, "HP rp7440 (PA-RISC) server\n", ""]

# Generated at 2022-06-20 17:24:22.816170
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """HPUXHardware - populate method unit test"""
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    h = HPUXHardware()
    facts = h.populate(collected_facts=collected_facts)
    assert facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert facts['processor_cores'] == 24
    assert facts['processor_count'] == 2
    assert facts['memtotal_mb'] == 49152
    assert facts['memfree_mb'] == 46400
    assert facts['swaptotal_mb'] == 8191

# Generated at 2022-06-20 17:24:30.358928
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw.module = DummyModule()
    hw.module.run_command.return_value = (0, 'ia64', None)
    hw.module.run_command.return_value = (0, 'Model:', None)
    hw.module.run_command.return_value = (0, 'Firmware Revision:', None)
    hw.module.run_command.return_value = (0, 'Machine Serial Number:', None)
    assert hw.get_hw_facts() == {'firmware_version': 'Revision', 'model': 'Model', 'product_serial': 'Number'}



# Generated at 2022-06-20 17:24:32.246326
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-20 17:24:39.684087
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    testmod = 'ansible.module_utils.facts.hardware.hpux'
    test_class = 'HPUXHardware'
    test_obj = HPUXHardware({'module': {'run_command': run_command_mock}})

    # test_collector_without_required_facts
    def test_collector_without_required_facts(facts):
        collector = HPUXHardwareCollector(module=MagicMock(), facts=facts)
        with pytest.raises(SkipCollector):
            collector.collect()

    # test_populate_without_required_facts
    def test_populate_without_required_facts(facts):
        with pytest.raises(Exception):
            test_obj.populate(facts)

    facts = {}

# Generated at 2022-06-20 17:25:05.757968
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Test for B.11.11
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.11',
        ansible_facts=dict(
            platform='HP-UX'
        ),
        platform='HP-UX'
    )
    hpuxhw = HPUXHardware(collected_facts)
    hpuxhw.get_hw_facts(collected_facts)
    assert collected_facts['model'] == 'rp3410'
    assert collected_facts['firmware_version'] == 'B.11.11'
    assert collected_facts['product_serial'] == '11A5146962'
    # Test for B.11.23

# Generated at 2022-06-20 17:25:14.062863
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Create a module to pass to HPUXHardware.get_cpu_facts()
    module = AnsibleModule(argument_spec={})

    # Create a class to store arguments for cpu_facts()
    class Args:
        collected_facts = {}

    # Create instance of HPUXHardware
    hpux_hw = HPUXHardware(module)

    # Assign fake values to instance attributes
    hpux_hw.module = module
    hpux_hw.hpux_hw_args = Args()
    hpux_hw.hpux_hw_args.collected_facts = {'ansible_architecture': '9000/800',
                                            'ansible_distribution_version': 'B.11.23'}

    # Create a class to store return values for cpu_facts()

# Generated at 2022-06-20 17:25:23.263585
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw_obj = HPUXHardware()

    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hw_obj.get_cpu_facts(collected_facts=collected_facts)
    # verify cpu_facts['processor_count']
    assert cpu_facts['processor_count'] == 2
    # verify cpu_facts['processor_cores']
    assert cpu_facts['processor_cores'] == 10
    # verify cpu_facts['processor_cores']
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E7-2870  @ 2.40GHz'
    return True


# Generated at 2022-06-20 17:25:33.826896
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('', (object, ), {'run_command': lambda self, a, b=None, c=None: None, 'get_bin_path': lambda self, x: None})
    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hardware = HPUXHardware(module, facts)
    hardware.processor_cores = None
    hardware.processor_count = None
    hardware.processor = None
    hardware.platform = 'HP-UX'
    hardware.get_cpu_facts(facts)

    assert hardware.processor_cores == 16
    assert hardware.processor_count == 8
    assert hardware.processor == 'Intel(R) Itanium(R) Processor'


# Generated at 2022-06-20 17:25:41.901904
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_facts = HPUXHardwareCollector
    hostname = 'test.example.com'
    distribution_version = 'B.11.31'
    ansible_facts = {'distribution': 'HP-UX', 'hostname': hostname, 'distribution_version': distribution_version}
    collectors = hardware_facts.collect_from(ansible_facts, hostname)
    assert isinstance(collectors, list)
    assert len(collectors) == 1
    assert isinstance(collectors[0], HPUXHardwareCollector)

# Generated at 2022-06-20 17:25:45.909943
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware_class_instance = HPUXHardware()
    hardware_class_instance.populate()
    assert hardware_class_instance.platform == 'HP-UX'
    hardware_class_instance.get_cpu_facts()
    hardware_class_instance.get_memory_facts()

# Generated at 2022-06-20 17:25:49.240688
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module=module)
    hardware.get_hw_facts(collected_facts={'ansible_architecture': 'ia64'})
    hardware.get_hw_facts()



# Generated at 2022-06-20 17:25:51.809152
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hw = HPUXHardware(module)
    facts = hw.populate()
    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-20 17:25:58.319100
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module_args = {'path': 'tests/unit'}
    module = FakeModule(module_args)

    hw = HPUXHardware(module)


# Generated at 2022-06-20 17:26:07.984620
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = Mock(return_value=(0, "Dynamic Host Configuration Protocol (DHCP)", ""))
            self.run_command = Mock(return_value=(0, "9000/785", ""))
            self.fail_json = Mock()

    class MockFacts(object):
        def __init__(self):
            self.ansible_facts = {
                'ansible_architecture': '9000/785'
            }

    m = MockModule()
    f = MockFacts()
    h = HPUXHardware()
    h.module = m
    h.populate(collected_facts=f.ansible_facts)
    assert h.processor == 'PA-RISC 1.1'
   

# Generated at 2022-06-20 17:26:40.197925
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():

    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = "/usr/sbin/swapinfo"
    mock_module.run_command.return_value = (0, "0", None)
    hardware = HPUXHardware(mock_module)
    facts = hardware.populate()
    assert "swaptotal_mb" in facts.keys()

test_HPUXHardware()

# Generated at 2022-06-20 17:26:46.133238
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    params = {'MODULE_COMMON_ARGS': '',
              'TASK_VARS': {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'},
              'COLLECTED_VARS': {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'},
              'FORCE_COLOR': False}
    test_hw_obj = HPUXHardware(params, False)
    test_hw_obj.module.run_command = MagicMock(return_value=(0,'0','0'))
    test_hw_obj.get_memory_facts()

# Generated at 2022-06-20 17:26:47.335164
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.facts == {}
    assert hardware_collector.collect() != []

# Generated at 2022-06-20 17:26:55.817587
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    my_test = HPUXHardware(dict())
    my_test.module.run_command = lambda *args, **kwargs: (0, "grep Physical /var/adm/syslog/syslog.log")
    my_test.module.run_command = lambda *args, **kwargs: (0, "phys_mem_pages/D")
    my_test.module.run_command = lambda *args, **kwargs: (0, "Memory:     1032976 Kbytes")
    my_test.module.run_command = lambda *args, **kwargs: (0, "swapinfo -m -d -f -q")

# Generated at 2022-06-20 17:27:04.829043
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts_dict = {
        'platform': 'HP-UX',
        'distribution': {
            'major_version': '11',
            'full_name': 'HPUX',
            'minor_version': '31'
        }
    }

    hpux_hw_collector = HPUXHardwareCollector(facts_dict)
    assert hpux_hw_collector.facts['distribution']['major_version'] == '11'
    assert hpux_hw_collector.facts['distribution']['full_name'] == 'HPUX'
    assert hpux_hw_collector.facts['distribution']['minor_version'] == '31'


# Generated at 2022-06-20 17:27:07.603837
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    hardware = HPUXHardware()
    assert hardware.platform == 'HP-UX'

# Generated at 2022-06-20 17:27:16.682838
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_hardware = HPUXHardware({'module_setup': True}, {}, {}, None)
    result = test_hardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert(result['firmware_version'] == '1.22')
    assert(result['model'] == 'ia64 hp server rx2660')
    assert(result['product_serial'] == 'not available')

    result = test_hardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert(result['firmware_version'] == '1.26')

# Generated at 2022-06-20 17:27:20.296516
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.facts == {}
    assert hardware_collector._platform == 'HP-UX'

# Generated at 2022-06-20 17:27:23.624005
# Unit test for constructor of class HPUXHardware
def test_HPUXHardware():
    module = HPUXHardware()
    assert module.platform == 'HP-UX'
    assert module.get_memory_facts()
    assert module.get_cpu_facts()
    assert module.get_hw_facts()

# Generated at 2022-06-20 17:27:31.130534
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module)
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31')
    result = hardware_obj.populate(collected_facts=collected_facts)
    assert 'processor' in result
    assert result['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert 'product_serial' in result
    assert result['product_serial'] == 'LTP94901UY'
    assert 'firmware_version' in result
    assert result['firmware_version'] == 'v3.33'
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result