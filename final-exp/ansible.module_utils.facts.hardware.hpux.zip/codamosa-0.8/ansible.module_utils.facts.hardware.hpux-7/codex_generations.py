

# Generated at 2022-06-11 02:33:07.203789
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    m = HPUXHardware()
    # Test with machinfo
    m.module.run_command = mock_run_command(
        'ia64',
        'B.11.31',
        '1 socket(s)',
        '4 core(s)',
        'Intel(R) Itanium(R) Processor 9320',
        '"Firmware revision" = "01.31"',
        'Machine serial number = SGXXXXXXXXXX'
    )
    m.get_cpu_facts = mock_get_cpu_facts()
    m.get_memory_facts = mock_get_memory_facts()
    m.get_hw_facts = mock_get_hw_facts()

# Generated at 2022-06-11 02:33:12.692533
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hc = HPUXHardwareCollector()
    assert hpux_hc._platform == 'HP-UX'
    assert hpux_hc.required_facts == {'platform', 'distribution'}

    # Test that we have an instance of class HPUXHardware
    assert isinstance(hpux_hc.get_facts(), HPUXHardware)

# Generated at 2022-06-11 02:33:16.246254
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({}, {})
    hardware_facts = hardware.get_cpu_facts({'ansible_architecture': '9000/800'})
    assert hardware_facts['processor_count'] == 4

# Generated at 2022-06-11 02:33:25.165449
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Create a ModuleExecutorToRunCommandWithStdoutMock to handle run_command().
    # The class is defined at the end of this file.
    h = HPUXHardware({'run_command': ModuleExecutorToRunCommandWithStdoutMock()})

    # Test that the method recognizes an HP-UX system correctly.
    os_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': '9000/800', # The system is a HP-UX 900/800.
        'ansible_distribution': 'HP-UX'
    }
    result = h.get_memory_facts(collected_facts=os_facts)
    assert result['memfree_mb'] == 1120
    assert result['memtotal_mb'] == 10240
    assert result['swaptotal_mb']

# Generated at 2022-06-11 02:33:33.618283
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collected_facts = dict(platform='HP-UX',
                           distribution='HP-UX',
                           ansible_architecture='ia64',
                           ansible_distribution_version='B.11.31')
    facts = HPUXHardwareCollector(module=None, collected_facts=collected_facts).collect()
    fact_class = facts[0]
    assert fact_class.__class__.__name__ == 'HPUXHardware'
    assert fact_class.platform == 'HP-UX'
    assert fact_class.processor_count == 6
    assert fact_class.processor_cores == 28
    assert fact_class.processor == 'Intel(R) Itanium(R) Processor 9350'
    assert fact_class.memtotal_mb == 1157
    assert fact_class.memfree_mb == 379


# Generated at 2022-06-11 02:33:45.360468
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Unit test for method get_cpu_facts of class HPUXHardware.
    """
    test_object = HPUXHardware(dict(), dict())

    # Test case 1
    test_facts = dict()
    test_facts['distribution_version'] = 'B.11.31'
    test_facts['architecture'] = 'ia64'
    result = test_object.get_cpu_facts(collected_facts=test_facts)
    assert result.get('processor_count') == 4
    assert result.get('processor') == 'Intel(R) Itanium(R) Processor 9320'
    assert result.get('processor_cores') == 8

    # Test case 2
    test_facts = dict()
    test_facts['distribution_version'] = 'B.11.23'

# Generated at 2022-06-11 02:33:48.203878
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware.get_memory_facts()

# Generated at 2022-06-11 02:33:53.841867
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    hw.module = AnsibleModule(argument_spec={})
    hw.module.run_command = run_command
    memory = hw.get_memory_facts()
    assert memory['memtotal_mb'] == 8192
    assert memory['memfree_mb'] == 498
    assert memory['swaptotal_mb'] == 4095
    assert memory['swapfree_mb'] == 2687


# Generated at 2022-06-11 02:33:58.088287
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Test to verify constructor of class HPUXHardwareCollector"""
    hw_facts = HPUXHardwareCollector.collect(None, None)
    assert hw_facts.__class__.__name__ == 'HPUXHardware'
# End of Unit test for constructor of class HPUXHardwareCollector


# Generated at 2022-06-11 02:34:01.507066
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(
        argument_spec={},
    )
    try:
        collector = HPUXHardwareCollector(module=module)
        print(collector)
    except:
        module.fail_json(msg="Failed to initialize collector")


# Generated at 2022-06-11 02:34:14.537166
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    is_hpux = HPUXHardwareCollector.detect(module=module)
    assert is_hpux



# Generated at 2022-06-11 02:34:22.004215
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector.__class__.__name__ == 'HPUXHardwareCollector'
    assert hpux_hardware_collector._platform == 'HP-UX'
    assert hpux_hardware_collector.required_facts == {'distribution', 'platform'}
    assert hpux_hardware_collector._fact_class == HPUXHardware


# Generated at 2022-06-11 02:34:28.053474
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class MockModule:
        def run_command(cmd, use_unsafe_shell):
            return 0, "", ""

    cls = HPUXHardware(MockModule())
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'}
    cls.get_memory_facts(collected_facts)

# Generated at 2022-06-11 02:34:37.199044
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())

    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=dict(ansible_architecture="9000/800", ansible_distribution_version="B.11.31"))
    assert cpu_facts['processor'] == "Intel(R) Itanium(R) Processor 9320"
    assert cpu_facts['processor_cores'] == 32
    assert cpu_facts['processor_count'] == 16


# Generated at 2022-06-11 02:34:41.497608
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    f = HPUXHardwareCollector(None, {'platform': 'HP-UX', 'distribution': 'HP-UX'})
    assert(f.platform == 'HP-UX')
    assert(f.required_facts == set(['platform', 'distribution']))
    assert(f.fact_class == HPUXHardware)
    assert(f.fact_subclasses == {})
    assert(f.iterable_facts == set([]))

# Generated at 2022-06-11 02:34:43.704380
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardwareCollector = HPUXHardwareCollector()

    assert hardwareCollector._platform == 'HP-UX'
    assert hardwareCollector._fact_class == HPUXHardware

# Generated at 2022-06-11 02:34:55.415557
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    out1 = 'ki  free  buff  cache  si   so     bi    bo   in   cs us sy id wa st      128    328      0    260      0      0      0      0    1   6  0  0  0  0  0  0'
    out2 = '128.0M of memory'
    out3 = '234.0M of swap'
    out4 = 'dev  fs       free       used   capacity  priority'
    out5 = '/dev/vg00/lvol1   /          8292    6        5%'
    out6 = 'Memory:  8192 MB'
    out7 = 'Memory:=8192 MB'
    out8 = 'Free memory             :    538 MB (   13% of installed memory)'
    out9 = 'Physical memory   =  524288 Kbytes'
    out

# Generated at 2022-06-11 02:34:59.142057
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {}
    HPUXHardwareCollector(facts=facts)
    assert facts['virtual'] == 'physical'
    assert facts['system_vendor']['name'] == 'Hewlett-Packard'

# Generated at 2022-06-11 02:35:08.028671
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    '''
    test class HPUXHardware with method get_cpu_facts.
    '''
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    hpx_hw = HPUXHardware(module)
    os_facts = dict(ansible_architecture='ia64',
                    ansible_distribution_version='B.11.23')
    # Test with B.11.23
    hpx_hw.collect_facts = Mock(return_value=os_facts)
    rc, out, err = hpx_hw.module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)

# Generated at 2022-06-11 02:35:10.940023
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    This is a dummy test to check the constructor of the class HPUXHardwareCollector
    """
    assert HPUXHardwareCollector(dict())

# Generated at 2022-06-11 02:35:44.596582
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(
            ansible_architecture=dict(type='str'),
            ansible_distribution_version=dict(type='str'),
        ),
    )
    hardware = HPUXHardware(module=module)

    collected_facts = dict(
        ansible_architecture='9000/800',
        ansible_distribution_version='B.11.31',
    )
    cpu_facts = dict(
        processor_count=2,
        processor_cores=8,
        processor='Itel(R) XEON(R) CPU E7-8890 v4 @ 2.20GHz',
    )

    # Params and expected results

# Generated at 2022-06-11 02:35:52.217357
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Test with B.11.23_IA
    module = FakeAnsibleModule({'architecture': 'ia64', 'distribution_version': 'B.11.23'})
    mock_collector = HPUXHardwareCollector(module=module)
    mock_collector.collect()
    facts = mock_collector.get_facts()
    test_populate_with_B11232(facts)
    # Test with B.11.31_IA
    module = FakeAnsibleModule({'architecture': 'ia64', 'distribution_version': 'B.11.31'})
    mock_collector = HPUXHardwareCollector(module=module)
    mock_collector.collect()
    facts = mock_collector.get_facts()
    test_populate_with_B11231(facts)

# Generated at 2022-06-11 02:35:53.976269
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    try:
        HPUXHardwareCollector()
    except NameError:
        raise AssertionError()


# Generated at 2022-06-11 02:35:58.692572
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {'platform': 'HP-UX', 'distribution': 'HP-UX', 'ansible_architecture': '9000/785', 'ansible_distribution_version': 'B.11.31'}

    x = HPUXHardware(None)
    cpu_facts = x.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-11 02:36:01.976894
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    test_hardware_collector = HPUXHardwareCollector()
    assert test_hardware_collector.platform == 'HP-UX'

# Generated at 2022-06-11 02:36:13.831739
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module_mock = AnsibleModuleMock(
        params=dict(gather_subset='!all,!min')
    )
    class CollectionMock(object):
        """Facade object so we can mock collected_facts.
        """
        def __init__(self):
            self.value = {
                'ansible_architecture': 'ia64',
                'ansible_distribution_version': 'B.11.31'
            }
        def get(self, key, default=None):
            return self.value.get(key, default)
    class ModuleUtilsHPUXHardwareMock(object):
        def __init__(self):
            self.value = {
                u'ansible_architecture': u'ia64'
            }


# Generated at 2022-06-11 02:36:24.974016
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import ansible.module_utils.facts.hardware.hp_ux.hp_ux_hardware as hp_ux_hardware
    hardware = hp_ux_hardware.HPUXHardware()
    collected_facts = {"ansible_architecture": "9000/800"}
    result = hardware.get_cpu_facts(collected_facts)
    assert result == {'processor_count': 2}
    collected_facts = {"ansible_architecture": "ia64"}
    collected_facts["ansible_distribution_version"] = "B.11.23"
    result = hardware.get_cpu_facts(collected_facts)

# Generated at 2022-06-11 02:36:36.613359
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({'platform': 'HP-UX', 'distribution': 'B.11.31'})

    rc, out, err = hardware.module.run_command.return_value = 0, '  BK705AA', None
    rc, out, err = hardware.module.run_command.return_value = 0, '  BK705AA', None
    rc, out, err = hardware.module.run_command.return_value = 0, '    Firmware revision = I40', None
    rc, out, err = hardware.module.run_command.return_value = 0, '    Machine serial number: BK705AA', None
    rc, out, err = hardware.module.run_command.return_value = 0, '  BK705AA', None
    hardware.get_hw_facts()
    data = hardware

# Generated at 2022-06-11 02:36:50.290555
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Return values
    data = {}
    data['ansible_architecture'] = 'ia64'
    data['ansible_distribution_version'] = 'B.11.23'
    cpu_facts = {}
    cpu_facts['processor_count'] = 1
    cpu_facts['processor'] = 'Intel(R) Itanium(R) Processor'
    cpu_facts['processor_cores'] = 1

    # Set up the mocks
    class MockModule(object):
        def run_command(self, cmd, **kwargs):
            rc = 0
            if cmd == "/usr/contrib/bin/machinfo | grep -i 'Firmware revision' | grep -v BMC":
                out = 'Firmware revision: v1.1.0'

# Generated at 2022-06-11 02:36:55.194152
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    args = {'collected_facts': {'ansible_architecture': 'ia64',
                                'ansible_distribution_version': 'B.11.23'}}
    hhp = HPUXHardware(module=None, **args)
    facts = hhp.populate()
    assert 'firmware_version' in facts

# Generated at 2022-06-11 02:37:13.554395
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-11 02:37:21.850597
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = HPUXHardware(module=module)

    collected_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31',
    }

# Generated at 2022-06-11 02:37:32.249478
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    hardware_facts = hardware.populate()
    assert 'memfree_mb' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'processor' in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'processor_count' in hardware_facts
    assert 'model' in hardware_facts
    assert 'firmware_version' in hardware_facts



# Generated at 2022-06-11 02:37:35.273066
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware.get_cpu_facts()
    assert cpu_facts.get('processor') and cpu_facts.get('processor_count') and cpu_facts.get('processor_cores')

# Generated at 2022-06-11 02:37:45.634937
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # test null case
    hardware = HPUXHardware()
    hardware.populate()
    assert hardware.data == {'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'processor': '', 'processor_cores': 0, 'processor_count': 0, 'model': '', 'firmware': ''}
    # test example
    hardware = HPUXHardware()
    hardware.module = Mock()
    hardware.module.run_command.return_value = (0, '0', '')
    hardware.populate({'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'})
    assert hardware.data['processor_count'] == 1

# Generated at 2022-06-11 02:37:52.277724
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    fake_module = type('module', (), {'run_command': lambda *x: (0, '', ''), 'get_bin_path': lambda *x: ''})()
    h = HPUXHardware(fake_module)

# Generated at 2022-06-11 02:38:03.802454
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module, dict(
        ansible_architecture='9000/785',
    ))

    assert hardware.get_cpu_facts() == {'processor_count': 2, }
    assert hardware.get_cpu_facts(collected_facts=dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')) == {'processor': 'Intel(R) Itanium(R) Processor',
                                                                                                                                                 'processor_count': 6,
                                                                                                                                                 'processor_cores': 6}


# Generated at 2022-06-11 02:38:04.994517
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()

# Generated at 2022-06-11 02:38:08.954952
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.platform == 'HP-UX'
    assert h.required_facts == set(['platform', 'distribution'])
    assert isinstance(h.collect(), dict)

# Generated at 2022-06-11 02:38:18.676209
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    def run_command(cmd, use_unsafe_shell=False):
        if re.match(r'.*(vmstat|swapinfo).*', cmd):
            return (0, "", "")
        elif re.match(r'.*(grep Physical).*', cmd):
            return (0, "physical memory = 2906 MB", "")
        elif cmd == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'":
            return (0, "73728", "")
        else:
            return (1, "", "")

    module.run_command = run_command
    hardware = HPUXHardware

# Generated at 2022-06-11 02:38:42.675031
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    arch = 'ia64'
    facts = {'ansible_architecture': arch, 'ansible_distribution_version': 'B.11.23'}
    hw = HPUXHardware(module)
    cpu_facts = hw.get_cpu_facts(facts)

    if arch == 'ia64':
        assert cpu_facts['processor'] == 'Intel(R) Itanium 2 processor 9000 series'
        assert cpu_facts['processor_cores'] == 4
        assert cpu_facts['processor_count'] == 2
    else:
        assert cpu_facts['processor_count'] == 2
        assert 'processor' not in cpu_facts



# Generated at 2022-06-11 02:38:52.013929
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    class MockModule(object):
        def __init__(self, platform, distro_version):
            self.platform = platform
            self.distro_version = distro_version

        def run_command(self, cmd, use_unsafe_shell=False):
            self.cmd = cmd
            self.use_unsafe_shell = use_unsafe_shell
            return (0, '', '')

    # platform PA-RISC, distro = B.11.31
    test_module = MockModule('HP-UX', 'B.11.31')
    test_HPUXHardware = HPUXHardware(module=test_module)

    hw_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31'
    }

# Generated at 2022-06-11 02:38:55.250991
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    config = {'required_facts': ['platform', 'distribution']}
    obj = HPUXHardwareCollector(config)
    assert obj.fact_class == HPUXHardware
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-11 02:38:58.430824
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = HPUXHardwareCollector._create_fake_module_obj()
    hardware_collector = HPUXHardwareCollector(module=module)
    assert hardware_collector._fact_class == HPUXHardware

# Generated at 2022-06-11 02:39:05.695797
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h = HPUXHardware()
    # Test mode ia64
    h.module.run_command = MockRunner(0, 'B.11.31', '')
    # Test /usr/contrib/bin/machinfo does not return cores strings
    h.module.run_command = MockRunner(0, '0', '')
    h.module.run_command = MockRunner(0, '4 Intel(R) Itanium(R) processors', '')
    h.module.run_command = MockRunner(0, '2', '')
    h.module.run_command = MockRunner(0, 'Intel(R) Itanium(R) Processor 9350  1.60 GHz', '')
    h.module.run_command = MockRunner(0, 'ON', '')

# Generated at 2022-06-11 02:39:17.012606
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.hardware.hpproc import HPUXHardware
    mock_module = MagicMock()
    mock_module.run_command.return_value = None
    hpux_hw = HPUXHardware(mock_module)

    test_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX'
    }

    # On PA-RISC
    hpux_hw.populate(test_facts)
    assert hpux_hw.cpu['processor'] == 'PA-RISC'
    assert hpux_hw.cpu['processor_count'] == 2

    # On Itanium

# Generated at 2022-06-11 02:39:29.035314
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware import HPUXHardware
    from ansible.module_utils.facts.machine import Machine

    class AnsibleModuleFake(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_result = (0, 0, 0)
            self.run_command_args = {}

        def run_command(self, *args, **kwargs):
            self.run_command_called = True
            self.run_command_args.update(kwargs)
            return self.run_command_result

    m = AnsibleModuleFake()

    # Testing HP-UX B.11.11 9000/800

# Generated at 2022-06-11 02:39:32.823683
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardwareCollector
    collector = HPUXHardwareCollector()

    assert collector.platform == 'HP-UX'
    assert collector._fact_class == HPUXHardware
    assert collector.required_facts == {'platform', 'distribution'}



# Generated at 2022-06-11 02:39:34.234541
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert issubclass(HPUXHardwareCollector, HardwareCollector) is True

# Generated at 2022-06-11 02:39:43.945438
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Test of method get_memory_facts of class HPUXHardware
    """
    hp_hardware = HPUXHardware()
    out_pagefree = "   0       0       0       0       0       0       0       0       0     125     251     234       1       0       0"
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    out_phys_mem_pages = "phys_mem_pages/D       0x9c600000 1504816"
    # Try/except added because it's impossible to test this part of code without being root

# Generated at 2022-06-11 02:40:10.072643
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    data = {'ansible_architecture': '9000/800'}
    hw = HPUXHardware(data, 'ansible_module')
    hw.module.run_command = fake_run_command
    assert hw.get_memory_facts() == {'memtotal_mb': 8192, 'swapfree_mb': 0, 'memfree_mb': 8192, 'swaptotal_mb': 0}

    hw = HPUXHardware({'ansible_architecture': 'ia64'}, 'ansible_module')
    hw.module.run_command = fake_run_command
    assert hw.get_memory_facts() == {'memtotal_mb': 49152, 'swapfree_mb': 0, 'memfree_mb': 49152, 'swaptotal_mb': 0}



# Generated at 2022-06-11 02:40:19.852291
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    mod_kwargs = dict({'collected_facts': {'ansible_architecture': '9000/800'}})
    test_class = HPUXHardware(module=module, **mod_kwargs)
    test_class.run()
    assert 'processor' in test_class.facts
    assert 'processor_cores' in test_class.facts
    assert 'processor_count' in test_class.facts
    assert test_class.facts['processor_count'] == 7

    module = FakeAnsibleModule()
    mod_kwargs = dict({'collected_facts': {'ansible_architecture': 'ia64',
                                           'ansible_distribution_version': 'B.11.23'}})

# Generated at 2022-06-11 02:40:30.529908
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    hpu = HPUXHardware(module=module)
    hpu.module.run_command = MagicMock(return_value=(0, '', ''))

    # Testing for ia64 architecture
    hpu.get_memory_facts({'ansible_architecture': 'ia64'})
    out = hpu.module.run_command.call_args[0][0]
    assert out == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'"

    # Testing for 9000/800 architecture
    hpu.get_memory_facts({'ansible_architecture': '9000/800'})

# Generated at 2022-06-11 02:40:36.319658
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hardware.module.run_command = mock_run_command
    hardware.module.params['gather_subset'] = ['!all']
    hardware.populate()
    ret = hardware.get_hw_facts({'ansible_architecture': 'ia64'})

    assert ret['model'] == 'HP Integrity rx2800 i4'
    assert ret['firmware_version'] == 'J15'

# Generated at 2022-06-11 02:40:45.880833
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """Unit test method get_hw_facts of class HPUXHardware"""

    _facts = dict(platform='HP-UX', distribution='B.11.31')

    _values_1 = dict(model='ia64 hp server rx6600', firmware_version='HPRP-03', product_serial='CZ3367YZ5H')
    _values_2 = dict(model='ia64 hp server rx6600', firmware_version='HPRP-03', product_serial=None)

    _mock_run_command = _mock_object(HPUXHardware)

    _mock_run_command.return_value = 0, 'HPRP-03', ''
    _instance = HPUXHardware(_facts)
    _facts.update(_instance.get_hw_facts())


# Generated at 2022-06-11 02:40:53.752196
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpuxtestdata import HPUXTestData
    test_data = HPUXTestData()
    test_hardware = test_data.get_hardware()
    hw_memory_facts_actual = test_hardware.get_memory_facts()
    hw_memory_facts_expected = test_data.get_hardware_memory_facts()
    assert hw_memory_facts_expected == hw_memory_facts_actual


# Generated at 2022-06-11 02:41:01.318387
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h = HPUXHardware({'platform': 'HP-UX'})
    facts = h.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert facts['model'] == 'hp rx2800 i2'
    assert facts['firmware_version'] == '1.07'
    facts = h.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert facts['model'] == 'hp rx2800 i2'
    assert facts['firmware_version'] == '1.07'



# Generated at 2022-06-11 02:41:03.335139
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class is HPUXHardware

# Generated at 2022-06-11 02:41:06.511615
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert(hw.fact_class() == HPUXHardware)
    assert(hw.platform() == 'HP-UX')
    assert(hw.required_facts() == set(['platform', 'distribution']))

# Generated at 2022-06-11 02:41:15.640461
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    hardware.module = AnsibleModule(argument_spec={})

    hardware.module.run_command = Mock(return_value=("0", "2", ""))
    hardware.module.run_command = Mock(return_value=("0", "64", ""))
    hardware.module.run_command = Mock(return_value=("0", "6000 MHz PA_RISC 2.0 processor", ""))

    cpu_facts = hardware.get_cpu_facts({'ansible_architecture': "9000/800"})

    assert cpu_facts == {'processor_count': 2, 'processor_cores': 64, 'processor': '6000 MHz PA_RISC 2.0 processor'}



# Generated at 2022-06-11 02:41:56.291966
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    assert hw.get_cpu_facts(collected_facts) == {'processor_count': 2}
    collected_facts = {'ansible_architecture': '9000/785'}
    assert hw.get_cpu_facts(collected_facts) == {'processor_count': 2}
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    assert hw.get_cpu_facts(collected_facts) == {'processor_count': 1, 'processor': 'Intel(R) Itanium(R) Processor 9000 series',
                                                 'processor_cores': 1}
    collected

# Generated at 2022-06-11 02:42:07.780826
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    processor_count = hardware.get_cpu_facts({'ansible_architecture': '9000/800'})
    assert processor_count['processor_count'] > 0
    processor_cores = hardware.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"})
    assert processor_cores['processor_cores'] > 0
    processor_cores_ht = hardware.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23", "ansible_processor": "Intel(R) Xeon(R) CPU           X7350  @ 2.93GHz", "ansible_processor_count": 2})
    assert processor_cores_

# Generated at 2022-06-11 02:42:09.596835
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector()
    assert hc._platform == 'HP-UX'
    assert hc._fact_class == HPUXHardware
    assert hc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:42:16.997704
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class HP_UX_Module:
        def run_command(self, cmd, use_unsafe_shell):
            return 0, '', ''

    # First test with a 9000/800 architecture
    hux_facts = HPUXHardware(HP_UX_Module())
    cpu_facts = hux_facts.get_cpu_facts({'architecture': '9000/800'})
    assert cpu_facts['processor_count'] == 4

    # Then test with an ia64 architecture and release B.11.23
    cpu_facts = hux_facts.get_cpu_facts({'architecture': 'ia64', 'distribution_version': 'B.11.23'})
    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) 2 Processor'

# Generated at 2022-06-11 02:42:27.566168
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({})
    platform = 'ia64'
    facts = {
        'ansible_architecture': platform,
        'ansible_facts': {'distribution': 'HP-UX', 'distribution_release': 'B.11.23'},
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23'
    }
    # Test with a ia64 platform and release B.11.23
    cpu_facts = hardware.get_cpu_facts(collected_facts=facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9180'
    assert cpu_facts['processor_cores'] == 8
    # Test with a ia64

# Generated at 2022-06-11 02:42:37.006568
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = MockModule()
    hpu_hw_cls = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hpu_hw_cls.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 1

    hpu_hw_cls = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hpu_hw_cls.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2



# Generated at 2022-06-11 02:42:42.717380
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    class d(dict):

        def __getitem__(self, key):
            return None

    data = d()

    data['ansible_architecture'] = '9000/800'
    data['ansible_distribution_version'] = 'B.11.31'

    p = HPUXHardware()
    p.module = MockHPModule()

    cpu_facts = p.get_cpu_facts(collected_facts=data)

    assert cpu_facts['processor_count'] == 1
    assert 'processor' in cpu_facts
    assert cpu_facts['processor_cores'] == 1

    data['ansible_architecture'] = 'ia64'

    cpu_facts = p.get_cpu_facts(collected_facts=data)

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts