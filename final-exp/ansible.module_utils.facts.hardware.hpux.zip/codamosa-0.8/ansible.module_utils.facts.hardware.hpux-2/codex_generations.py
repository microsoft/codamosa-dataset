

# Generated at 2022-06-11 02:32:58.769491
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()
    assert(hhc._fact_class == HPUXHardware)
    assert(hhc._platform == 'HP-UX')
    assert(hhc.required_facts == set(['platform', 'distribution']))
    assert('HPUXHardwareCollector' in str(HPUXHardwareCollector.__doc__))

# Generated at 2022-06-11 02:33:05.894260
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    memory_facts_obj = HPUXHardware()
    memory_facts = memory_facts_obj.get_memory_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert memory_facts['memfree_mb']
    assert memory_facts['memtotal_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swapfree_mb']

# Generated at 2022-06-11 02:33:11.964528
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts = set(['platform', 'distribution'])
    collected_facts = {'platform': 'HP-UX', 'distribution': 'HP-UX'}
    hw = HPUXHardwareCollector(collected_facts=collected_facts)
    assert set(hw.required_facts) == required_facts
    assert hw.platform == 'HP-UX'
    assert hw._fact_class is HPUXHardware

# Generated at 2022-06-11 02:33:21.260283
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    def get_module_mock(params):
        module = AnsibleModule(
            argument_spec=params,
            supports_check_mode=True
        )
        module.run_command = MagicMock(return_value=(0, 'test_output', ''))
        return module

    params = dict(
    )

    test_module = get_module_mock(params)
    output = HPUXHardware(test_module).get_hw_facts()
    assert output.get('model') == 'test_output'
    assert output.get('firmware_version') == 'test_output'
    assert output.get('product_serial') == 'test_output'



# Generated at 2022-06-11 02:33:23.665632
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware(None)
    assert isinstance(hw.get_cpu_facts(), dict)

# Generated at 2022-06-11 02:33:27.381442
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Return a HPUXHardwareCollector instance
    """
    facts = dict()
    facts['platform'] = "HP-UX"
    hw_obj = HPUXHardwareCollector(facts, False)
    return hw_obj

# Generated at 2022-06-11 02:33:40.929184
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule({})
    test_obj = HPUXHardware()
    test_obj.module = module
    vmstat_data = "procs  memory page                                                                           disks  faults cpu\n r    b avm fre  re  pi  po  fr   sr da0 s7 s6 s5 s4 s3 s2 s1  in  sy  cs us sy id\n 0  185  877  105   0   0   0   0   0   0   0   0   0   0   0   0  21  13  18  0  0 100"

# Generated at 2022-06-11 02:33:50.277114
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    facts = hw.populate()

    assert facts['processor_cores']  # will raise KeyError if missing
    assert facts['processor_count']  # will raise KeyError if missing
    assert facts['processor']  # will raise KeyError if missing
    assert facts['memtotal_mb']  # will raise KeyError if missing
    assert facts['memfree_mb']  # will raise KeyError if missing
    assert facts['swaptotal_mb']  # will raise KeyError if missing
    assert facts['swapfree_mb']  # will raise KeyError if missing
    assert facts['model']  # will raise KeyError if missing
    assert facts['firmware_version']  # will raise KeyError if missing

# Generated at 2022-06-11 02:33:53.949620
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """ Constructor HPUXHardwareCollector Test"""
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector._fact_class == HPUXHardware

# Generated at 2022-06-11 02:33:57.056860
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardwarecollector = HPUXHardwareCollector()
    assert hardwarecollector.required_facts == set(['platform', 'distribution'])
    assert hardwarecollector._platform == 'HP-UX'

# Generated at 2022-06-11 02:34:14.620452
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """Check if the method get_cpu_facts returns expected results"""
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)

    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2, "Failed to get cpu processor_count"

    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = "B.11.23"
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2, "Failed to get cpu processor_count"

# Generated at 2022-06-11 02:34:26.936822
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    os.environ['LANG'] = 'C'
    # Test on ia64 with B.11.31 HP-UX
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0,
                                                 "0\n",
                                                 "0"))
    module.run_command = MagicMock(return_value=(0,
                                                 'socket = 1\nprocessor family : Intel(R) Itanium(R) processor\nlogical # of processors : 32\ncpu MHz : 1900.000\ncores per socket : 1\nmedia : icache 32 KB dcache 32 KB\n',
                                                 "0"))

# Generated at 2022-06-11 02:34:39.861396
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.collector import CollectedFacts
    module = AnsibleModule_HPUXHardware()
    collected_facts = CollectedFacts(module)
    _platform = 'HP-UX'
    collected_facts.add('platform', _platform)
    _os_version = 'B.11.31'
    collected_facts.add('distribution_version', _os_version)
    _architecture = 'ia64'
    collected_facts.add('architecture', _architecture)

    # OS is not HP-UX
    assert not HPUXHardware._get_cpu_facts(collected_facts=collected_facts)
    collected_facts.add('platform', 'Linux')
    assert not HPUXHardware._get_cpu_facts(collected_facts=collected_facts)

# Generated at 2022-06-11 02:34:49.794166
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    a = HPUXHardware()
    a.module.run_command = lambda *args, **kwargs: (0, '', '')
    a.module.run_command = lambda *args, **kwargs: (0, '9', '')
    a.module.run_command = lambda *args, **kwargs: (0, 'processor family	: Intel(R) Itanium(R) family', '')
    a.module.run_command = lambda *args, **kwargs: (0, '4', '')
    b = a.get_cpu_facts(collected_facts={'ansible_architecture': '9000/785', 'ansible_distribution_version': 'B.11.31'})
    assert b['processor_count'] == 9
    assert b['processor_cores'] == 4
    assert b

# Generated at 2022-06-11 02:35:00.465681
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class TestModule(object):
        params = dict()

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
            return (0, "", "")

    test_module = TestModule()
    hpux_hardware = HPUXHardware(test_module)
    facts = hpux_hardware.get_memory_facts()
    assert facts['memfree_mb'] == 0

# Generated at 2022-06-11 02:35:02.725651
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hw_collector = HPUXHardwareCollector()
    assert hpux_hw_collector.platform == 'HP-UX'

# Generated at 2022-06-11 02:35:09.711958
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import pytest
    from ansible.module_utils import facts


    module = ansible_module_mock()
    module.run_command = run_command_mock
    module.facts = facts.Facts(module)
    # Check HP-UX BACKWARD COMPATIBILITY
    module.facts.ansible_distribution = 'HP-UX'
    # Check HP-UX 11.31
    module.facts.ansible_distribution_version = 'B.11.31'
    # Check machinfo contains cores
    module.run_command.return_value = (0, '1', '')

    hardware = HPUXHardware(module)
    result = hardware.get_cpu_facts()
    assert result.get('processor_count') == 1
    assert result.get('processor_cores') == 14

# Generated at 2022-06-11 02:35:14.767096
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware().get_cpu_facts()
    assert cpu_facts['processor_count'] is not None
    assert cpu_facts['processor'] is not None
    assert cpu_facts['processor_cores'] is not None

# Generated at 2022-06-11 02:35:24.086299
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '1', ''))
    hw = HPUXHardware(module)
    facts = hw.get_memory_facts()
    assert facts == {}
    module.run_command = MagicMock(return_value=(0, '1', ''))
    facts = hw.get_memory_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert not facts



# Generated at 2022-06-11 02:35:34.796291
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h = HPUXHardware(dict())
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'B.11.31'}
    facts = h.populate(collected_facts)
    assert facts['processor_count'] == 8
    assert facts['processor'] == 'Intel(r) Itanium(r) processor'
    assert facts['processor_cores'] == 6
    assert facts['memfree_mb'] == 528
    assert facts['memtotal_mb'] == 4608
    assert facts['swaptotal_mb'] == 4608
    assert facts['swapfree_mb'] == 4608
    assert facts['model'] == 'ia64 hp server rx6600'

# Generated at 2022-06-11 02:35:50.633988
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpuux import HPUXHardware
    hpux_hardware = HPUXHardware()
    hpux_hardware.module = True
    hpux_hardware.module.run_command = lambda a, b: ('', '', '')
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hpux_hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts



# Generated at 2022-06-11 02:36:02.199828
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    obj = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64'}
    assert obj.get_memory_facts(collected_facts) == {'memfree_mb': 32, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 1018}
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    assert obj.get_memory_facts(collected_facts) == {'memfree_mb': 32, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 1018}

# Unit test fo method get_cpu_facts of class HPUXHardware

# Generated at 2022-06-11 02:36:12.146108
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=(0, 'hp 9000', ''))
    hardware = HPUXHardware(module)
    hardware.module.run_command = MagicMock(
        side_effect=[(0, 'Firmware revision = J.22', ''), (0, 'Machine serial number = US12345678', '')]
    )
    assert hardware.get_hw_facts() == {
        'model': 'hp 9000',
        'firmware_version': 'J.22',
        'product_serial': 'US12345678'
    }



# Generated at 2022-06-11 02:36:23.638951
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    my_obj = HPUXHardware()
    my_obj.module = AnsibleModule(argument_spec={})
    # System with B.11.31
    collected_facts_1 = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

    rc, out, err = my_obj.module.run_command("/usr/contrib/bin/machinfo | egrep 'socket[s]?$' | tail -1", use_unsafe_shell=True)
    count_processor_1 = int(out.strip().split(" ")[0])

# Generated at 2022-06-11 02:36:26.801505
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('Module', (object,), {'run_command':  lambda *args: (0, '', '')})()
    facts = HPUXHardware(module=module).get_cpu_facts()
    assert 'processor_count' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts


# Generated at 2022-06-11 02:36:31.356958
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector(None, None, {})
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-11 02:36:39.858688
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = HPUXHardware(module).populate()

    assert isinstance(hardware_facts, dict), 'populate method of HPUXHardware class did not return a dictionary'
    assert hardware_facts['processor_count'] >= 1, 'populate method of HPUXHardware class did not return a valid processor_count value'
    assert hardware_facts['processor'] != '', 'populate method of HPUXHardware class did not return a valid processor value'
    assert hardware_facts['memtotal_mb'] >= 1, 'populate method of HPUXHardware class did not return a valid memtotal_mb value'
    assert hardware_facts['memfree_mb'] >= 1, 'populate method of HPUXHardware class did not return a valid memfree_mb value'
    assert hardware_facts

# Generated at 2022-06-11 02:36:53.131767
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Create a fake ansible_facts object which will be used in the test
    fake_ansible_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    hardware = HPUXHardware(module=None)

    # Create a cpu_facts object which will be used in the test as expected result
    cpu_facts_extract_mock = {
        'processor_count': 2,
        'processor': 'Intel(R) Itanium(R) Processor 9100',
        'processor_cores': 8
    }

    # Create a mem_facts object which will be used in the test as expected result

# Generated at 2022-06-11 02:37:04.331048
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    module = AnsibleModule(argument_spec={})
    module.params = {}
    ansible_facts = {'ansible_architecture': '9000/800',
                     'ansible_distribution': 'HP-UX',
                     'ansible_distribution_version': 'B.11.11.2016.11.05.42',
                     'ansible_distribution_major_version': '11',
                     'ansible_distribution_release': 'B.11.11.2016.11.05.42'}

    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=ansible_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PA-RISC 2.0'



# Generated at 2022-06-11 02:37:12.585883
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUX = HPUXHardware()
    mem_facts = {'memfree_mb': 1022, 'memtotal_mb': 1023, 'swapfree_mb': 1, 'swaptotal_mb': 2}
    cpu_facts = {'processor_count': 4, 'processor_cores': 1, 'processor': 'Intel(R) Itanium(R) CPU  9310 @ 1.60GHz'}
    hw_facts = {'model': 'ia64 hp server rx6600', 'firmware_version': 'B.11.31.3015', 'product_serial': 'MXB8030H0V'}

    fact_list = HPUX.populate()
    assert mem_facts == {name: fact_list[name] for name in mem_facts}

# Generated at 2022-06-11 02:37:37.647012
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hw_facts["model"] == "Integrity Superdome 2"
    assert hw_facts["firmware_version"] == "4.36"
    hw_facts = HPUXHardware.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert hw_facts["model"] == "Integrity Superdome 2"
    assert hw_facts["firmware_version"] == "4.36"
    assert hw_facts["product_serial"] == "US12345678"


# Generated at 2022-06-11 02:37:47.306643
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    testobj = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution_version': 'B.11.31'}
    # ioscan return 1 core
    testobj.module.run_command = lambda *args, **kwargs: (0, '1', '')
    rc, out, err = testobj.populate(collected_facts=collected_facts)
    assert rc == 0
    assert out.get('processor_count') in [1]
    assert out.get('processor') in ['HP 9000/800/L2000 processor']
    assert out.get('processor_cores') in [1]
    collected_facts.update({'ansible_architecture': '9000/785'})
    # ioscan return 2 cores


# Generated at 2022-06-11 02:37:56.644876
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():

    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module, 'HP-UX')
    collected_facts = {'ansible_distribution_version': 'B.11.23',
                       'ansible_architecture': 'ia64'}
    # Test the hw_facts dictionary returned the method with his values
    assert hw.get_hw_facts(collected_facts=collected_facts) == {'firmware_version': 'I26',
                                                                'model': 'ia64 HP Integrity rx2800 i2',
                                                                'product_serial': '01234567'}



# Generated at 2022-06-11 02:38:09.489666
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class TestModule(object):
        def __init__(self, rc, out, err, dist_version):
            self.rc = rc
            self.out = out
            self.err = err
            self.dist_version = dist_version

        def run_command(self, command, use_unsafe_shell=True):
            if command == 'ioscan -FkCprocessor | wc -l':
                return self.rc, self.out, self.err
            elif command.startswith('/usr/contrib/bin/machinfo'):
                if self.dist_version == 'B.11.23':
                    return self.rc, self.out, self.err

# Generated at 2022-06-11 02:38:13.888992
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(dict(ANSIBLE_MODULE_ARGS={}))
    hw.module.run_command = lambda *args, **kwargs: (0, '"HP 9000 rp3440"', '')
    hw.get_hw_facts()
    assert "HP 9000 rp3440" == hw.model


# Generated at 2022-06-11 02:38:22.860222
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mock_module = type('AnsibleModule', (object,), {'run_command': Mock()})()
    module_instance = HPUXHardware(mock_module)
    module_instance.get_memory_facts(collected_facts=dict(ansible_architecture='9000/785'))
    module_instance.module.run_command.assert_any_call("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    module_instance.module.run_command.assert_any_call("grep Physical /var/adm/syslog/syslog.log")

# Generated at 2022-06-11 02:38:33.004450
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock(return_value=(0, '123', ''))
    hardware.module.run_command.side_effect = [(0, "123", ""), (0, '123456', ''), (0, "123", ""), (0, "7", ""), (0, "test", "")]
    hardware.get_memory_facts()
    hardware.module.run_command.assert_any_call('/usr/bin/vmstat | tail -1', use_unsafe_shell=True)
    hardware.module.run_command.assert_any_call('grep Physical /var/adm/syslog/syslog.log')

# Generated at 2022-06-11 02:38:39.011531
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardwarecollector_obj = HPUXHardwareCollector()
    assert hardwarecollector_obj
    assert hardwarecollector_obj.platform == 'HP-UX'
    assert hardwarecollector_obj.required_facts == set(['platform', 'distribution'])
    assert hardwarecollector_obj._fact_class is HPUXHardware

# Generated at 2022-06-11 02:38:50.767242
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware()
    h.module = FakeAnsibleModule()

    # Everything is ok
    h.module.run_command.side_effect = [
        (0, '16000', ''),
        (0, 'Phys:  49607088 Kbytes', ''),
        (0, '    4652 total', ''),
        (0, '    2944 - /opt', ''),
        (0, '     176 - /stand', ''),
        (0, '     936 - /tmp', ''),
    ]

    memory_facts = h.get_memory_facts()
    assert memory_facts['memfree_mb'] == 16000 * 4096 // 1024 // 1024
    assert memory_facts['memtotal_mb'] == 49607088 // 1024
    assert memory_facts['swaptotal_mb'] == 4

# Generated at 2022-06-11 02:38:53.500639
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    facts = HPUXHardware(module).populate()
    assert isinstance(facts, dict)

# Generated at 2022-06-11 02:39:14.338412
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hdx = HPUXHardwareCollector()
    assert hdx.platform == 'HP-UX'
    assert hdx.required_facts == set(['platform', 'distribution'])
    assert hdx.fact_class == HPUXHardware


# Generated at 2022-06-11 02:39:17.511469
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = HPUXHardwareCollector(module=module)
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXHardware
    assert collector._facts == {}



# Generated at 2022-06-11 02:39:22.603984
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({'platform': 'HP-UX', 'distribution': 'B.11.23'})
    assert hw.get_hw_facts() == {'model': 'ia64', 'firmware_version': 'Core 0.15.1', 'product_serial': 'P00000'}

# Generated at 2022-06-11 02:39:32.896753
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    pagesize = 4096
    memory_facts = HPUXHardware(dict(module=dict(run_command=lambda x: (0, '', '')))).get_memory_facts()
    assert memory_facts['memfree_mb'] == int(pagesize * int(re.sub(' +', ' ', ('9 241 23 1540 0 0 1 9 0').strip()).split(' ')[5].strip()) // 1024 // 1024)
    rc, out, err = HPUXHardware(dict(module=dict(run_command=lambda x: (0, '', '')))).module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'",use_unsafe_shell=True)

# Generated at 2022-06-11 02:39:39.373135
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts = set(['platform', 'distribution', 'architecture'])
    hwc = HPUXHardwareCollector(dict(), required_facts)
    assert hwc.required_facts == required_facts
    assert hwc._platform == 'HP-UX'
    assert hwc._fact_class == HPUXHardware
    assert isinstance(hwc._fact_class, object)

# Generated at 2022-06-11 02:39:49.550174
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # we mock facts, to test the right behavior in each cases
    ansible_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    # Testing match of string on syslog
    os.environ['ANSIBLE_LIBRARY'] = '../module_utils/hardware'
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    set_module_args(dict())
    hardware = HPUXHardware(module=module)
    hardware.module.run_command = MagicMock(return_value=(1, '', ''))
    memory_facts = hardware.get_memory_facts()

# Generated at 2022-06-11 02:39:59.411101
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    sample_get_hw_facts = {
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_major_version': 'B.11.31',
        'ansible_distribution_version': 'B.11.31',
        'ansible_architecture': 'ia64',
        'ansible_os_family': 'HP-UX',
        'ansible_kernel': 'HP-UX',
        'ansible_system': 'IA64N'
    }
    hw = HPUXHardware(dict(sample_get_hw_facts))
    hw_facts = hw.get_hw_facts(sample_get_hw_facts)
    assert hw_facts['model'] == 'Integrity rx2800 i2'
    assert hw_facts['firmware_version']

# Generated at 2022-06-11 02:40:11.104112
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpu = HPUXHardware(dict(ansible_architecture='ia64'))
    cpu_facts = hpu.get_cpu_facts(dict(ansible_distribution_version='B.11.23'))
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert cpu_facts['processor_cores'] == 64
    assert cpu_facts['processor_count'] == 2

    cpu_facts = hpu.get_cpu_facts(dict(ansible_distribution_version='B.11.31'))
    assert cpu_facts['processor_cores'] == 24 or cpu_facts['processor_cores'] == 12
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-11 02:40:20.649071
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Method get_hw_facts of class HPUXHardware unit test.
    """
    class TestModule:
        def __init__(self):
            self.run_command = lambda arg1, arg2: (0, '', '')

    hardware = HPUXHardware(TestModule())

    collected_facts = {}

    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    result = hardware.get_hw_facts(collected_facts=collected_facts)
    expected = {}

    assert result == expected

    collected_facts['ansible_distribution_version'] = 'B.11.31'
    result = hardware.get_hw_facts(collected_facts=collected_facts)

# Generated at 2022-06-11 02:40:31.288469
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    def get_cpu_facts(collected_facts):
        cpu_facts = {}
        if collected_facts.get('ansible_architecture') in ['9000/800', '9000/785']:
            cpu_facts['processor_count'] = 6
        else:
            cpu_facts['processor_count'] = 1
            cpu_facts['processor_cores'] = 2
        return cpu_facts

    class MockHPUXHardware(HPUXHardware):
        def get_cpu_facts(self, collected_facts=None):
            return get_cpu_facts(collected_facts)

    class MockModule():
        def run_command(self, cmd, use_unsafe_shell=False):
            output

# Generated at 2022-06-11 02:41:11.947251
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardwareCollector = HPUXHardwareCollector()
    assert hardwareCollector.platform == 'HP-UX'
    assert hardwareCollector._fact_class == HPUXHardware
    assert 'platform' in hardwareCollector.required_facts
    assert 'distribution' in hardwareCollector.required_facts

# Generated at 2022-06-11 02:41:14.184084
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector is not None

# Generated at 2022-06-11 02:41:23.575806
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os

    hw_facts_output = 'model 9000/785\nFirmware revision = C.10.25'
    hw_facts_output_ia64 = 'model: HP Integrity rx2660 Firmware revision = C.10.25'


# Generated at 2022-06-11 02:41:25.846656
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    obj = HPUXHardwareCollector()
    assert obj.__class__.__name__ == 'HPUXHardwareCollector'

# Generated at 2022-06-11 02:41:36.074269
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    hardware = HPUXHardware(module)
    fact_collected = {'ansible_architecture': '9000/800'}
    expected = {'processor_count': 4}
    hardware.module.run_command = run_command_mock
    hardware.module.run_command.return_value = (0, "4\n", "")
    result = hardware.get_cpu_facts(fact_collected)
    assert result == expected
    fact_collected = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    expected = {
        'processor': 'Intel(r) Itanium(r) Processor',
        'processor_count': 1,
        'processor_cores': 2
    }


# Generated at 2022-06-11 02:41:39.188086
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    obj = HPUXHardwareCollector(None)
    assert obj
    assert obj.platform == 'HP-UX'
    assert obj.required_facts == set(['platform', 'distribution'])
    assert obj.collect() is None

# Generated at 2022-06-11 02:41:48.849528
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()

    hw.module.run_command = lambda cmd, use_unsafe_shell=False: (0, 'ia64', '')
    hw.module.get_bin_path = lambda cmd, required=False, opt_dirs=None: '/usr/contrib/bin/machinfo'
    hw.module.run_command = lambda cmd, use_unsafe_shell=False: (0, 'HP-UX B.11.31 U ia64 4508395240', '')
    hw.distribution = {
        'name': 'HP-UX',
        'version': 'B.11.31'
    }


# Generated at 2022-06-11 02:41:59.484692
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # For B.11.23
    collected_facts = {'platform': 'HP-UX',
                       'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.23'}
    cpu_info = HPUXHardware(module=None, collected_facts=collected_facts).get_cpu_facts()
    # For B.11.31
    collected_facts = {'platform': 'HP-UX',
                       'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}
    cpu_info = HPUXHardware(module=None, collected_facts=collected_facts).get_cpu_facts()
    # For B.11.31 core

# Generated at 2022-06-11 02:42:05.816263
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = None
    hardware_facts = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware_facts.get_cpu_facts(collected_facts=collected_facts)
    assert 'processor' not in cpu_facts
    assert cpu_facts['processor_count'] == 2
    assert 'processor_cores' not in cpu_facts

# Generated at 2022-06-11 02:42:14.963470
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module_mock = Mock()
    module_mock.run_command.side_effect = [(0, '12345', None),
                                           (0, '1472 0 0', None),
                                           (0, 'Physical: 64424509440 Kbytes', None),
                                           (0, '1234', None),
                                           (0, 'fs     /dev/vg00/lv01  1585   3586        -   -     -', None)]

    hw = HPUXHardware(module_mock)
    collected_facts = dict(ansible_architecture='9000/800', ansible_distribution='HP-UX')
    results = hw.get_memory_facts(collected_facts=collected_facts)
    assert results['memfree_mb'] == 16384
    assert results