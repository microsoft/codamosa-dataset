

# Generated at 2022-06-11 02:32:53.725036
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # unit test for facter HPUXHardwareCollector
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:32:58.200474
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector(None)
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector.optional_facts == set()

# Generated at 2022-06-11 02:33:05.391048
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpux_hw_facts = HPUXHardware()
    cpu_facts = hpux_hw_facts.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800', 'ansible_distribution_release': 'B.11.31'})
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 4
    assert 'processor' in cpu_facts


# Generated at 2022-06-11 02:33:12.759220
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class AnsibleModuleMock():
        def __init__(self):
            self.run_command_vals = []

        def run_command(self, cmd, use_unsafe_shell):
            self.run_command_vals.append(cmd)
            if cmd == "/usr/bin/vmstat | tail -1":
                return (0, "      8         0        13", "err")
            if cmd == "grep Physical /var/adm/syslog/syslog.log":
                return (0, "Feb 15 11:44:44 hpvm1 init: Physical: 44716 Kbytes", "err")

# Generated at 2022-06-11 02:33:22.905572
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    # Create an instance of the HPUXHardware class
    hpux_hw = HPUXHardware({})

    # Check get_cpu_facts return value
    res = hpux_hw.get_cpu_facts({'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'})
    assert res['processor_count'] == 4
    assert res['processor'] == 'unknown'
    assert res['processor_cores'] == 0

    # Check get_cpu_facts return value
    res = hpux_hw.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX',
                                 'ansible_distribution_version': 'B.11.23'})
    assert res['processor_count'] == 4

# Generated at 2022-06-11 02:33:32.634272
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    # Unit test with module_utils.facts.hardware.base.Hardware
    hardware_mock = Hardware(module)
    # Unit test with module_utils.facts.hardware.hpux.HPUXHardware
    hpux_hardware_mock = HPUXHardware(module)

    collected_facts = {'ansible_architecture': '9000/785'}
    cpu_facts_expected = {'processor_count': 2}
    cpu_facts = hpux_hardware_mock.get_cpu_facts(collected_facts)
    assertEqual(cpu_facts, cpu_facts_expected)

    collected_facts = {'ansible_architecture': 'ia64'}

# Generated at 2022-06-11 02:33:38.500659
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    mock_module = type('AnsibleModule', (object, ), {})()
    mock_module.run_command = lambda _: (0, 'A', '')
    hardware = HPUXHardware(mock_module)

    hw_facts = hardware.get_hw_facts()

    assert hw_facts['model'] == 'A'

# Generated at 2022-06-11 02:33:49.136575
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # create mock facts
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }
    # create mock instance of class HPUXHardware
    hw = HPUXHardware(module=None)
    hw.architecture = 'ia64'
    hw.distribution_version = 'B.11.31'
    # run test
    result = hw.get_memory_facts(collected_facts=collected_facts)
    # check result
    assert type(result) is dict
    assert 'memfree_mb' in result
    assert type(result['memfree_mb']) is int
    assert 'memtotal_mb' in result
    assert type(result['memtotal_mb']) is int
   

# Generated at 2022-06-11 02:33:54.034279
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    hardware_collector = HPUXHardwareCollector(module=module, facts={})
    hardware = hardware_collector.collect()
    assert hardware.get_cpu_facts() == {'processor_count': 1, 'processor_cores': 1}


# Generated at 2022-06-11 02:33:57.153418
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpuxHWCollector = HPUXHardwareCollector()
    assert hpuxHWCollector.platform == "HP-UX"
    assert hpuxHWCollector._fact_class == HPUXHardware

# Generated at 2022-06-11 02:34:08.712311
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()

    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:34:15.645615
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # data valid for ia64 and PA-RISC
    module = MagicMock()
    hardware = HPUXHardware(module)
    module.run_command.return_value = 0, "", ""
    hardware.get_cpu_facts()
    module.run_command.assert_any_call("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    module.run_command.assert_any_call("/usr/contrib/bin/machinfo | grep 'processor family'", use_unsafe_shell=True)
    module.run_command.assert_any_call("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)


# Generated at 2022-06-11 02:34:28.232487
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    hardware = HPUXHardware(module)

    rc, out, err = module.run_command("model")
    model = out.strip()
    rc, out, err = module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    if rc == 0 and out:
        firmware = out.split('=')[1].strip()

    if rc == 0:
        if out:
            hw_facts = hardware.get_hw_facts()
            assert hw_facts['firmware_version'] == firmware
            assert hw_facts['model'] == model

# Generated at 2022-06-11 02:34:41.022291
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    HPUXHardware.module = MagicMock()
    HPUXHardware.module.run_command.return_value = (0, '4096 2', None)
    HPUXHardware.module.run_command.return_value = (0, '1280000', None)
    HPUXHardware.module.run_command.return_value = (0, '227533', None)
    HPUXHardware.module.run_command.return_value = (0, 'dev 	   2048M 	    871M 	   1177M 	  34% 	/', None)
    HPUXHardware.module.run_command.return_value = (0, 'fs 	   2048M 	    708M 	   1340M 	  34% 	/stand', None)

    facts = HPU

# Generated at 2022-06-11 02:34:47.772755
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware()
    hardware_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) processor 9340'
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 8

# Generated at 2022-06-11 02:35:00.890975
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hpux_hw = HPUXHardware(module=module)
    facts = {}
    facts['ansible_architecture'] = '9000/800'
    facts['ansible_distribution_version'] = "B.11.31"
    collected_facts = hpux_hw.get_memory_facts(collected_facts=facts)
    assert type(collected_facts['memfree_mb']) is int
    assert type(collected_facts['memtotal_mb']) is int
    assert type(collected_facts['swapfree_mb']) is int
    assert type(collected_facts['swaptotal_mb']) is int
    assert collected_facts['swaptotal_mb'] >= collected_facts['swapfree_mb']
    assert collected_facts

# Generated at 2022-06-11 02:35:10.550720
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts_list = []
    h = HPUXHardwareCollector()
    hardware_facts = h._fact_class()

    # Testing get_cpu_facts method with gathered facts
    el = hardware_facts.populate(facts_list)
    assert 'processor_count' in el
    assert 'processor' in el
    assert 'processor_cores' in el
    processor_count = el['processor_count']
    processor = el['processor']
    processor_cores = el['processor_cores']

    # Testing get_cpu_facts method without gathered facts
    el = hardware_facts.populate()
    assert 'processor_count' in el
    assert 'processor' in el
    assert 'processor_cores' in el
    assert processor_count == el['processor_count']
    assert processor == el['processor']
    assert processor

# Generated at 2022-06-11 02:35:18.557668
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Set up dummy module and facts
    module = DummyAnsibleModule()
    facts = {}
    assert HPUXHardwareCollector(module, facts)._platform == 'HP-UX'
    assert HPUXHardwareCollector(module, facts)._fact_class == HPUXHardware
    assert HPUXHardwareCollector(module, facts).required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:35:30.860777
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Some data structures (long, dict) used to test
    data1 = {u'ansible_architecture': u'ia64', u'ansible_all_ipv4_addresses': [u'10.232.73.18', u'127.0.0.1'], u'ansible_distribution': u'HP-UX', u'ansible_distribution_version': u'B.11.31'}
    data2 = {u'ansible_architecture': u'9000/800', u'ansible_all_ipv4_addresses': [u'10.232.73.18', u'127.0.0.1'], u'ansible_distribution': u'HP-UX', u'ansible_distribution_version': u'B.11.31'}

# Generated at 2022-06-11 02:35:41.842873
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = type("test_ansible_module", (object,), {"run_command": run_command_simulate})
    # pylint: disable=W0612
    result = HPUXHardware(module).populate()
    assert result == {'processor': 'Intel(R) Xeon(R) CPU E5-2667 v3 @ 3.20GHz',
                      'processor_cores': 12,
                      'processor_count': 2,
                      'memfree_mb': 26156,
                      'memtotal_mb': 189735,
                      'swapfree_mb': 0,
                      'swaptotal_mb': 0,
                      'model': 'ia64 HP 9000 rp3440',
                      'firmware_version': 'HPUX 11i v3-3.3'}


# Generated at 2022-06-11 02:36:08.043948
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(dict(module=dict()))
    hardware.module = MockModule()
    architectural_data = {}
    hardware.module.run_command = Mock(return_value=(0, '', ''))

    # Test for 9000/800
    architectural_data['ansible_architecture'] = '9000/800'
    hardware.get_cpu_facts(collected_facts=architectural_data)
    hardware.module.run_command.assert_called_once_with("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)
    hardware.module.run_command.reset_mock()

    # Test for 9000/785
    architectural_data['ansible_architecture'] = '9000/785'

# Generated at 2022-06-11 02:36:14.924507
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """Unit test for method get_memory_facts of class HPUXHardware
    """
    class DummyModule:
        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, "", ""
    module = DummyModule()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    assert HPUXHardware(module).get_memory_facts(collected_facts)['memtotal_mb'] == 14216


# Generated at 2022-06-11 02:36:19.283940
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardwareCollector._fact_class.get_hw_facts()
    assert 'model' in hw_facts
    assert 'firmware' in hw_facts
    assert 'model' in hw_facts

# Generated at 2022-06-11 02:36:24.169648
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test = HPUXHardware()
    test.module = AnsibleModule
    test.module.run_command = lambda *args, **kwargs: (0, "", "")
    test.module.check_mode = False
    test.module.debug = False
    test.module.warn = False

    assert test.get_memory_facts() == {}

# Generated at 2022-06-11 02:36:33.716478
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('AnsibleModule', (object,), {})()
    modutil = type('AnsibleModuleUtil', (object,), {})
    module.run_command = lambda x, **kw: ('', '', '')
    module.exit_json = lambda x: True
    hardware = HPUXHardware(module, modutil)

    facts = hardware.get_cpu_facts()
    assert facts['processor'] == 'Intel(R) Itanium(R) Dual-Core Processor 9340'
    assert facts['processor_cores'] == 8
    assert facts['processor_count'] == 1



# Generated at 2022-06-11 02:36:45.310637
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # objective is to test get_cpu_facts function of HPUXHardware class
    # create an instance of HPUXHardware class
    # call get_cpu_facts function of HPUXHardware class with sample data
    # check if result matches expected output
    cpu_collected_facts = {'ansible_architecture': '9000/800'}
    hpuxtestinstance = HPUXHardware()
    hpuxtestinstance.module = None
    hpuxtestinstance.run_command = None
    out = hpuxtestinstance.get_cpu_facts(cpu_collected_facts)
    assert out == {'processor_count': 2}


# Generated at 2022-06-11 02:36:52.303952
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    harware = HPUXHardware(module)
    facts = {'ansible_architecture': 'ia64',
             'ansible_distribution_version': 'B.11.31'}
    data = harware.get_memory_facts(collected_facts=facts)
    assert data['memfree_mb'] == 0 or data['memfree_mb'] > 0

# Generated at 2022-06-11 02:37:01.021354
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_obj = HPUXHardware(module)

    # Test for PA-RISC processor (B.11.31)

# Generated at 2022-06-11 02:37:01.557950
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    pass

# Generated at 2022-06-11 02:37:10.188511
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    try:
        from ansible.module_utils.facts import hardware as hw
        from ansible.module_utils.facts.hardware import Hardware
        from ansible.module_utils.facts.hardware.hpux_hpux import HPUXHardware
        from ansible.module_utils.facts.hardware.hpux_hpux import HPUXHardwareCollector
    except ImportError:
        sys.exit("You need to install Ansible for the test")
    hw_fact = HPUXHardware()
    hw_fact.module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 02:37:46.826057
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    class TestHPUXHardware(unittest.TestCase):
        def setUp(self):
            self.hw = HPUXHardware()

        def test_no_vmstat_output(self):
            self.hw.module = MockModule(rc=1, out=b'')
            memory_facts = self.hw.get_memory_facts()
            self.assertEqual(memory_facts, {})

        def test_no_vmstat_output_2(self):
            self.hw.module = MockModule(rc=1, out=b'')
            memory_facts = self.hw.get_memory_facts()

# Generated at 2022-06-11 02:37:52.669961
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    hpuxCollector = HPUXHardwareCollector()
    hpuxCollector._module = module
    hpuxCollector._platform = 'HP-UX'
    hpuxCollector._facts_class = HPUXHardware
    hpuxCollector._required_facts = set(['platform', 'distribution'])

# Generated at 2022-06-11 02:38:04.401326
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class module():
        def __init__(self):
            self.run_command = self.run_command_success

        def run_command_success(self, command, use_unsafe_shell=True):
            """ Dummy run_command function for unit test """
            data = {}
            if command == "ioscan -FkCprocessor | wc -l":
                data['rc'] = 0
                if os.environ.get('ANSIBLE_PAX_COLLECTOR_TEST_OS_VERSION', None) == "B.11.23":
                    data['stdout'] = "1"
                if os.environ.get('ANSIBLE_PAX_COLLECTOR_TEST_OS_VERSION', None) == "B.11.31":
                    data['stdout'] = "4"

# Generated at 2022-06-11 02:38:14.145980
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_hw = HPUXHardware({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    test_faits = {}
    test_faits['ansible_architecture'] = 'ia64'
    test_faits['ansible_distribution_version'] = 'B.11.31'
    res = test_hw.get_cpu_facts(collected_facts=test_faits)
    assert res.get('processor_cores') == 20


# Generated at 2022-06-11 02:38:25.442179
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = DummyAnsibleModule()
    test_module.load_fixture('machinfo_B1131.json')
    test_hw = HPUXHardware(test_module)
    cpu_facts = test_hw.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_count'] == 24
    assert cpu_facts['processor'] == 'Intel(r) Itanium(r) Processor 9350'

    test_module.load_fixture('machinfo_B1123.json')
    test_hw = HPUXHardware(test_module)
    cpu_facts = test_hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == 4

# Generated at 2022-06-11 02:38:34.611419
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    ansible_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.23'
    )
    hardware = HPUXHardware(dict(), ansible_facts)

    facts = hardware.populate()

    assert facts.get('processor').strip() == 'Intel(R) Itanium(R) Processor 9300 series'
    assert facts.get('processor_cores') == 4
    assert facts.get('processor_count') == 2
    assert facts.get('memtotal_mb') == 34056
    assert facts.get('memfree_mb') == 18942
    assert facts.get('swaptotal_mb') == 16384
    assert facts.get('swapfree_mb') == 16384

# Generated at 2022-06-11 02:38:43.522325
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    data = {'platform': 'HP-UX'}
    hpux = HPUXHardware()
    hpux.module = MagicMock()
    rc = 0
    out = '4'
    err = ''
    hpux.module.run_command.return_value = rc, out, err
    cpu_facts_1 = hpux.get_cpu_facts(data)
    assert cpu_facts_1['processor_count'] == 4
    cpu_facts_2 = hpux.get_cpu_facts({'platform': 'HP-UX'})
    assert cpu_facts_2['processor_count'] == 4


# Generated at 2022-06-11 02:38:47.103608
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    inst = HPUXHardwareCollector()

    assert inst._platform == 'HP-UX'
    assert inst._fact_class == HPUXHardware
    assert inst.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:38:50.686647
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({'platform': 'HP-UX'})
    assert hardware._get_hw_facts() == {'model': 'rp', 'firmware_version': 'B.11.31.1803', 'product_serial': 'A1K7733X'}



# Generated at 2022-06-11 02:39:01.397500
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware(dict(ANSIBLE_MODULE_ARGS={'gather_subset': 'all', 'gather_timeout': 10}))
    hardware.module = FakeAnsibleModule()
    hardware.module.run_command = FakeRunCommand(hardware)
    hardware.module.get_bin_path = FakeGetBinPath()
    hardware.module.run_command.register_commands({'vmstat': ' '})
    hardware.module.run_command.register_commands({'swapinfo': '100'})
    hardware.module.run_command.register_commands({'swapinfo': 'dev -1 100 0'})

# Generated at 2022-06-11 02:39:59.536822
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Unit test for method get_hw_facts of class HPUXHardware
    Test if the correct hardware information is returned by the correct
    method.
    """
    hpu = HPUXHardware()
    results = hpu.get_hw_facts({'ansible_architecture': 'ia64',
                                'ansible_distribution_version': 'B.11.23',
                                'platform': 'HP-UX'})
    assert results['model'] == 'ia64 hp server rx4640'
    assert results['firmware_version'] == 'V4.23'
    assert results['product_serial'] == 'SGH285WDZ2'

# Generated at 2022-06-11 02:40:11.144367
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware({'ansible_architecture': '9000/800'})

    hardware.module.run_command = mock.MagicMock()
    hardware.module.run_command.side_effect = [(0, '2048 1234', ''),
                                               (0, 'Memory:  3538 MB', ''),
                                               (0, 'total: 2147483648', ''),
                                               (0, 'Free:612780', ''),
                                               (0, 'dev: blocks      free', ''),
                                               (0, '/dev/vg00/lvol5  87972   87972', ''),
                                               (0, 'fs: blocks      free', ''),
                                               (0, '/dev/vg00/lvol6 87972 87972', '')]

# Generated at 2022-06-11 02:40:11.733941
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    pass

# Generated at 2022-06-11 02:40:18.372624
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module=module)
    hardware_collector.collect()
    hardware_facts = hardware_collector.get_facts()
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['memtotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0


# Generated at 2022-06-11 02:40:29.596363
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 02:40:39.813295
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hw = HPUXHardware(module=module)
    facts = hw.get_memory_facts({'ansible_architecture': 'ia64'})
    assert facts['memfree_mb'] == 71151
    assert facts['memtotal_mb'] == 185886
    assert facts['swaptotal_mb'] == 185832
    assert facts['swapfree_mb'] == 184624

    facts = hw.get_memory_facts({'ansible_architecture': '9000/800'})
    assert facts['memfree_mb'] == 52392
    assert facts['memtotal_mb'] == 155496
    assert facts['swaptotal_mb'] == 155492
    assert facts['swapfree_mb'] == 154256


# Generated at 2022-06-11 02:40:47.880006
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hpux_hardware = HPUXHardware(module)
    # Call the method with ia64
    hpux_hardware.module.ansible_facts['ansible_architecture'] = 'ia64'
    hpux_hardware.module.ansible_facts['ansible_distribution_version'] = 'B.11.23'
    memory_facts = hpux_hardware.get_memory_facts()
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    # Call the method with ia64

# Generated at 2022-06-11 02:40:53.092259
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = object()
    collected_facts = {'platform': 'HP-UX', 'distribution_version': 'B.11.31'}
    hw_collector = HPUXHardwareCollector(module, collected_facts)
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector._fact_class == HPUXHardware

# Generated at 2022-06-11 02:40:58.359729
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class Os:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
    class CollectedFacts:
        def __init__(self, arch='ia64', dist_ver='B.11.23'):
            self.arch = arch
            self.dist_ver = dist_ver
    class Module:
        def __init__(self, os):
            self.run_command = lambda x, y: (os.rc, os.out, os.err)
    class HPUXHW:
        def __init__(self, module, cf):
            self.module = module
            self.collected_facts = cf

    # Good parsing

# Generated at 2022-06-11 02:41:01.369755
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    hw.module = MockModule()
    hw.module.run_command.return_value = (0, '1024 100 0\n', '')
    hw.get_memory_facts()