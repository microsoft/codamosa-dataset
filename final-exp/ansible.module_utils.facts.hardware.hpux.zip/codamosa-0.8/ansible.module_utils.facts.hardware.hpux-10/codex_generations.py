

# Generated at 2022-06-11 02:33:02.839038
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        )
    )
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution_version='B.11.23'
    )
    expected_facts = {
        'firmware_version': 'v2.11 (08/27/12)',
        'model': 'ia64 hp server rx8640',
        'product_serial': 'USC230075P'
    }
    hpux_hw = HPUXHardwareCollector.fetch_all(module=module, collected_facts=collected_facts)
    assert hpux_hw.get_facts() == expected_facts


# Unit test

# Generated at 2022-06-11 02:33:13.169431
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'platform': 'HP-UX', 'distribution': 'B.11.31'}
    hardware_collector = HPUXHardwareCollector(facts)
    assert hardware_collector
    # Test that class object is of type HardwareCollector
    assert isinstance(hardware_collector, HardwareCollector)
    # Test that class object is of type HPUXHardwareCollector
    assert isinstance(hardware_collector, HPUXHardwareCollector)
    # Test that _fact_class variable is of type HPUXHardware
    assert hardware_collector._fact_class is HPUXHardware
    # Test that _platform variable is HP-UX
    assert hardware_collector._platform == 'HP-UX'
    # Test that required_facts variable is as required for HP-UX

# Generated at 2022-06-11 02:33:19.017406
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({'distribution': 'HP-UX', 'architecture': 'ia64'})
    setattr(hardware, 'module', True)
    actual_data = hardware.get_hw_facts()
    expected_data = {'model': '', 'firmware_version': '', 'product_serial': ''}
    assert actual_data == expected_data



# Generated at 2022-06-11 02:33:25.055704
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    module.params['ansible_architecture'] = 'ia64'
    hardware = HPUXHardware(module=module)

    hardware_facts = hardware.get_hw_facts()
    assert hardware_facts['model'] == 'ia64 hp server'



# Generated at 2022-06-11 02:33:29.046898
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Test for required_facts == {'distribution': ('platform'},
    # where 'platform' will be ignored
    hpux_hw_collector = HPUXHardwareCollector({'distribution': 'HP-UX'})
    assert hpux_hw_collector._required_facts == set(['distribution'])

# Generated at 2022-06-11 02:33:42.183374
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware(dict(), dict())

    hardware.module.run_command = (lambda x, **y: (0, 'processor B', ''))
    hardware.module.run_command = (lambda x, **y: (0, 'core C', ''))
    hardware.module.run_command = (lambda x, **y: (0, 'core D', ''))
    hardware.module.run_command = (lambda x, **y: (0, 'core E', ''))
    hardware.module.run_command = (lambda x, **y: (0, 'core F', ''))
    hardware.module.run_command = (lambda x, **y: (0, 'core G', ''))
    hardware.module.run_command = (lambda x, **y: (0, 'core H', ''))
    hardware.module

# Generated at 2022-06-11 02:33:49.766663
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == u'ia64 hp Integrity rx2800 i2'
    assert hw_facts['firmware_version'] == '4.6'



# Generated at 2022-06-11 02:33:54.272338
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    data = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    module = MockAnsibleModule(data)
    hpux = HPUXHardware(module)
    result = hpux.get_cpu_facts()
    assert result == {'processor_count': 3}


# Generated at 2022-06-11 02:34:03.153337
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    _HPUXHardware = HPUXHardware()

    # populate when ansible_architecture is 9000/800
    collected_facts = {
        "ansible_architecture": "9000/800",
        "ansible_distribution_version": "B.11.31"
    }
    _HPUXHardware.populate(collected_facts=collected_facts)

    # populate when ansible_architecture is 9000/785
    collected_facts = {
        "ansible_architecture": "9000/785",
        "ansible_distribution_version": "B.11.31"
    }
    _HPUXHardware.populate(collected_facts=collected_facts)

    # populate when ansible_architecture is ia64

# Generated at 2022-06-11 02:34:12.144831
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = MockModule()
    hardware = HPUXHardware(module=module)

    # Set of data collected from /usr/contrib/bin/machinfo on HP-UX B.11.31 1204 IA64
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) processor 9282'
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 16

# Generated at 2022-06-11 02:34:33.854586
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    import sys
    import platform
    import ansible.module_utils.facts.hardware.hpuxtohpux
    hc = ansible.module_utils.facts.hardware.hpuxtohpux.HPUXHardwareCollector()
    assert isinstance(hc, HPUXHardwareCollector)

    # Unit tests for is_required() method
    facts = {'platform': 'HP-UX'}
    assert hc.is_required(facts) == True
    facts['platform'] = 'Linux'
    assert hc.is_required(facts) == False
    facts['platform'] = 'HP-UX'
    facts['distribution'] = 'B.11.11'
    assert hc.is_required(facts) == True
    facts['distribution'] = 'B.11.31'
    assert hc

# Generated at 2022-06-11 02:34:40.927419
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    cpu_facts = {}
    cpu_facts['ansible_distribution'] = 'HP-UX'
    cpu_facts['ansible_architecture'] = '9000/800'
    assert hardware.get_cpu_facts(collected_facts=cpu_facts) == {'processor_count': 8}
    cpu_facts['ansible_architecture'] = '9000/785'
    assert hardware.get_cpu_facts(collected_facts=cpu_facts) == {'processor_count': 4}
    cpu_facts['ansible_architecture'] = 'ia64'
    cpu_facts['ansible_distribution_version'] = 'B.11.31'

# Generated at 2022-06-11 02:34:50.345237
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h = HPUXHardware(dict())
    rc, out, err = h.module.run_command("ioscan -FkCprocessor | wc -l")
    processors = int(out)
    rc, out, err = h.module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'")
    data = out.strip().split('=')
    sockets = int(data[1])
    rc, out, err = h.module.run_command("/usr/contrib/bin/machinfo | grep 'logical'")
    data = out.strip().split(" ")
    cores = int(data[0])
    rc, out, err = h.module.run_command("/usr/contrib/bin/machinfo | grep 'processor family'")

# Generated at 2022-06-11 02:35:03.160182
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list')
        }
    )

    hpux_hw = HPUXHardware(module)
    hardware_facts = hpux_hw.populate()
    assert hardware_facts['memtotal_mb'] == hardware_facts['memfree_mb'] + hardware_facts['swaptotal_mb']
    assert hardware_facts['processor_count'] == hardware_facts['processor_cores']
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_facts['firmware_version'] == 'v2.20   (release)'
    assert hardware_facts['model'] == 'HP Integrity Superdome'
    assert hardware_facts['product_serial'] == 'CHXXXXXXX'


# Generated at 2022-06-11 02:35:08.141407
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts_expected = {'processor_count': 4, 'processor_cores': 16, 'processor': 'Intel(R) Itanium(R) Family'}
    hpu = HPUXHardware()
    cpu_facts_actual = hpu.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert cpu_facts_expected == cpu_facts_actual


# Generated at 2022-06-11 02:35:09.513571
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-11 02:35:12.000028
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    '''HPUXHardwareCollector should load with no issues'''
    assert HPUXHardwareCollector

# Generated at 2022-06-11 02:35:25.824917
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    hw.module = MockAnsibleModule()
    hw.module.run_command = MockRunCommand()
    hw.module.run_command.return_value = (0, "ansible_architecture=9000/800", "")
    hw.module.run_command.return_value = (0, "ansible_architecture=9000/785", "")
    hw.module.run_command.return_value = (0, "ansible_architecture=ia64", "")
    hw.module.run_command.return_value = (0, "ansible_distribution_version=B.11.23", "")

# Generated at 2022-06-11 02:35:32.895839
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.31",
    }
    hw.populate(collected_facts=facts)
    assert hw.memtotal_mb == 16384
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0


# Generated at 2022-06-11 02:35:43.344172
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    h = HPUXHardware(module)

    rc, out, err = module.run_command.call_args[0]
    assert module.run_command.call_count == 1
    assert rc == "model"
    assert out == "HP-UX"

    rc, out, err = module.run_command.call_args[0]
    assert module.run_command.call_count == 1
    assert rc == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC"
    assert out == "Firmware revision = B.11.31"

    rc, out, err = module.run_command.call_args[0]
    assert module.run_command.call_count == 1

# Generated at 2022-06-11 02:35:56.199472
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """ Return a set of facts from the HPUXHardware class. """
    hw = HPUXHardware(None)
    facts = hw.populate()
    assert len(facts.keys()) > 0


# Generated at 2022-06-11 02:36:03.643806
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpux_hardware = HPUXHardware()

    # Test B.11.31
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31')
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9300 Series'

    # Test B.11.23
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')

# Generated at 2022-06-11 02:36:14.964686
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    with patch.object(HPUXHardware, 'get_cpu_facts') as get_cpu_facts_mock:
        with patch.object(HPUXHardware, 'get_memory_facts') as get_memory_facts_mock:
            with patch.object(HPUXHardware, 'get_hw_facts') as get_hw_facts_mock:
                get_cpu_facts_mock.return_value = {'processor': 'mock_processor'}
                get_memory_facts_mock.return_value = {'memfree_mb': 'mock_total_mem'}
                get_hw_facts_mock.return_value = {'model': 'mock_model'}
                hardware.populate

# Generated at 2022-06-11 02:36:23.345657
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts = HPUXHardware(module).populate()
    assert('processor_count' in facts)
    assert('processor_cores' in facts)
    assert('memfree_mb' in facts)
    assert('memtotal_mb' in facts)
    assert('processor' in facts)
    assert('swaptotal_mb' in facts)
    assert('swapfree_mb' in facts)
    assert('model' in facts)
    assert('firmware' in facts)

# Generated at 2022-06-11 02:36:29.075216
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.utils import FactsParams, AnsibleFact
    import pytest

    params = FactsParams()
    params.get_ansible_facts = True
    module = AnsibleFact(params, '/dev/null', None, None, None)

    rc, out, err = module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    data = int(re.sub(' +', ' ', out).split(' ')[5].strip())

    instance = HPUXHardware()
    result = instance.get_memory_facts()
    assert (result['memfree_mb'] == data * 4 * 1024)

# Generated at 2022-06-11 02:36:38.724855
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule({'ansible_architecture': 'ia64'})
    hpux_hw = HPUXHardware(module=module)
    result = hpux_hw.get_cpu_facts(collected_facts={'ansible_distribution_version': 'B.11.23'})
    assert result == {'processor_count': 4}
    module = AnsibleModule({'ansible_architecture': 'ia64'})
    hpux_hw = HPUXHardware(module=module)
    result = hpux_hw.get_cpu_facts(collected_facts={'ansible_distribution_version': 'B.11.31'})
    assert result['processor_count'] == 2
    assert result['processor_cores'] == 2

# Generated at 2022-06-11 02:36:43.896697
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    Constructor test for class HPUXHardwareCollector
    """
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.platform == 'HP-UX'

# Generated at 2022-06-11 02:36:55.494351
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = FakeAnsibleModule()
    hw = HPUXHardwareCollector(module=module).collect()[0]
    assert hw.data['processor_count'] == 2
    assert hw.data['processor_cores'] == 2
    assert hw.data['processor'] == 'Intel Itanium 2'
    assert hw.data['memtotal_mb'] == 16384
    assert hw.data['swaptotal_mb'] == 512
    assert hw.data['memfree_mb'] == 16376
    assert hw.data['swapfree_mb'] == 0
    assert hw.data['model'] == 'ia64 hp server rx8620'
    assert hw.data['firmware_version'] == 'v5.5'

# Generated at 2022-06-11 02:36:56.888764
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 02:37:06.467217
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(None)
    collected_facts = {}
    collected_facts['ansible_architecture'] = '9000/800'
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = "B.11.23"
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == "Intel(R) Itanium(R) 9100 series CPU @ 1.60GHz"
    collected_

# Generated at 2022-06-11 02:37:28.358514
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({'module_setup': True})
    facts = hw.get_hw_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version':'B.11.23'})
    assert facts == {'model': 'rp3440', 'firmware_version': 'v2.00', 'product_serial': 'USXXXXXXXX'}

# Generated at 2022-06-11 02:37:35.432177
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    collected_facts = {'ansible_architecture': 'ia64'}
    # ret = {'processor_cores': 2, 'processor_count': 2, 'processor': 'Intel(R) Itanium(R) Processor 9310'}
    ret = HPUXHardware().get_cpu_facts(collected_facts=collected_facts)
    assert type(ret) == dict
    assert ret['processor_cores'] == 2
    assert ret['processor_count'] == 2


# Generated at 2022-06-11 02:37:46.051373
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class HPUXHardware
    """
    class MockModule(object):
        """
        Mock class for AnsibleModule
        """
        def __init__(self, **kwargs):
            self.params = kwargs


# Generated at 2022-06-11 02:37:57.446702
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware(module=None).get_cpu_facts({"ansible_architecture": "9000/785"})
    assert cpu_facts.get("processor_count") == 2
    cpu_facts = HPUXHardware(module=None).get_cpu_facts({"ansible_architecture": "9000/800"})
    assert cpu_facts.get("processor_count") == 2
    cpu_facts = HPUXHardware(module=None).get_cpu_facts({"ansible_architecture": "ia64", "ansible_distribution_version": "B.11.23"})
    assert cpu_facts.get("processor") == 'Intel(R) Itanium(R) Processor 9320'
    assert cpu_facts.get("processor_cores") == 2
    assert cpu_facts

# Generated at 2022-06-11 02:38:10.342710
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})

    # Initialize HPUXHardware object
    hpux_hw = HPUXHardware(module)

    # Initialize dict of collected facts
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution_version='B.11.23'
    )

    # Run code to be tested
    results = hpux_hw.get_hw_facts(collected_facts)

    # Fail the module if we get an error
    if results.get('failed'):
        module.fail_json(msg=results)

    # Check if the firmware_version is set
    assert results.get('firmware_version')

    # Check if the product_serial is set
    assert results.get('product_serial')

# Generated at 2022-06-11 02:38:11.505626
# Unit test for method get_memory_facts of class HPUXHardware

# Generated at 2022-06-11 02:38:22.418863
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.params = {'gather_subset': ['all']}
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution': 'HP-UX'}

    # setting up a machinfo on a ia64

# Generated at 2022-06-11 02:38:32.578118
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    HPUXHardware - get_hw_facts unit test
    """
    mod_args = dict()
    mod_args['ansible_facts'] = dict()
    mod_args['ansible_facts']['ansible_architecture'] = 'ia64'
    mod_args['ansible_facts']['ansible_distribution_version'] = 'B.11.23'
    mod_args['ansible_facts']['ansible_collect_timeout'] = 10
    mod_args['ansible_facts']['ansible_connection'] = 'local'
    mod_args['ansible_facts']['ansible_python_version'] = '2.7'
    mod_args['ansible_facts']['ansible_user_id'] = 'root'

# Generated at 2022-06-11 02:38:40.226868
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    platform = 'HP-UX'
    req_facts = set(['platform', 'distribution'])
    fact_class = HPUXHardware
    hpux_hw = HPUXHardwareCollector(platform, req_facts, fact_class)

    assert(hpux_hw.platform == platform)
    assert(hpux_hw.required_facts == req_facts)
    assert(hpux_hw._fact_class == fact_class)

# Generated at 2022-06-11 02:38:43.265457
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Unit test for constructor of class HPUXHardwareCollector"""
    obj = HPUXHardwareCollector()
    assert obj.platform == 'HP-UX'

# Generated at 2022-06-11 02:39:00.805401
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()

    hpu = HPUXHardware(module=module)
    hw_facts = hpu.get_hw_facts()
    expected_hw_facts = {'firmware_version': '', 'model': 'rp5470', 'product_serial': '2085d21a1a.a'}
    assert hw_facts == expected_hw_facts

# Unit test class for HPUXHardware class

# Generated at 2022-06-11 02:39:06.651391
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    mod_args = dict(
        platform='HP-UX',
        distribution='B.11.31'
    )

    hardware_collect = HPUXHardwareCollector(module=None, facts=mod_args)
    assert hardware_collect._platform == 'HP-UX'
    assert hardware_collect._fact_class == HPUXHardware
    assert hardware_collect.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:39:17.774700
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import sys
    module = sys.modules['ansible.module_utils.facts.hardware.hpux.hpux_hardware']
    hpux = module.HPUXHardware()
    ansible_architecture = '9000/800'
    collected_facts = {'ansible_architecture': ansible_architecture}
    hardware_facts = hpux.get_memory_facts(collected_facts=collected_facts)
    assert hardware_facts['memtotal_mb'] == 0
    ansible_architecture = 'ia64'
    collected_facts = {'ansible_architecture': ansible_architecture,
                       'ansible_distribution_version': 'B.11.23'}
    hardware_facts = hpux.get_memory_facts(collected_facts=collected_facts)

# Generated at 2022-06-11 02:39:23.824351
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts.get('processor') == 'Intel(R) Itanium(R) Processor'


# Generated at 2022-06-11 02:39:29.212869
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """ Test if required_facts is set correctly. """
    # pylint: disable=protected-access
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])
    assert HPUXHardwareCollector._fact_class == HPUXHardware

# Generated at 2022-06-11 02:39:35.951330
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Setup Facts
    TestFacts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }
    # Setup module
    TestModule = type(
        'DummyModule',
        (object,),
        {
            'run_command': lambda a, b: (0, '', '') if a[0] == 'who -b' else (1, '', '')
        }
    )
    # Setup hardware object
    hardware = HPUXHardwareCollector(TestModule, TestFacts)
    # Populate the facts
    hardware.populate()
    # Get the facts
    facts = hardware.facts
    # Processors count

# Generated at 2022-06-11 02:39:39.906908
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(None)
    facts = hw.get_hw_facts()
    assert 'model' in facts
    assert 'firmware_version' in facts or 'product_serial' in facts


# Generated at 2022-06-11 02:39:50.533701
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '', '')

    setattr(module,
            '_ansible_is_hpux', MagicMock(return_value=True))
    setattr(module,
            '_ansible_is_ipf', MagicMock(return_value=False))
    setattr(module,
            '_ansible_is_ia64', MagicMock(return_value=True))
    module.run_command.return_value = (0, '', '')

    hardware = HPUXHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts.get('memfree_mb') == 0

# Generated at 2022-06-11 02:39:54.289518
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_fact = HPUXHardwareCollector()
    assert hw_fact._platform == 'HP-UX'
    assert hw_fact._fact_class == HPUXHardware
    assert hw_fact.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:40:02.813787
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    hw = HPUXHardware(module)

    def run(command):
        if command == "model":
            return 0, "HP-UX Server", ""
        elif command == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC":
            return 0, "Firmware revision: 4.42", ""
        elif command == "/usr/contrib/bin/machinfo |grep -i 'Machine serial number' ":
            return 0, "Machine serial number: 111111111", ""
        else:
            raise Exception("Unexpected command: " + command)

    hw.module.run_command = run

# Generated at 2022-06-11 02:40:18.411768
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'


# Generated at 2022-06-11 02:40:21.335862
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpc = HPUXHardwareCollector()
    assert hpc._fact_class == HPUXHardware
    assert hpc._platform == 'HP-UX'

# Generated at 2022-06-11 02:40:31.966691
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    a = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    b = HPUXHardware().get_cpu_facts(collected_facts=a)
    assert b['processor_cores'] == 3
    assert b['processor_count'] == 2
    assert b['processor'] == 'Intel(R) Itanium(R) Processor 9320'

    a = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    b = HPUXHardware().get_cpu_facts(collected_facts=a)
    assert b['processor_cores'] == 2
    assert b['processor_count'] == 12

# Generated at 2022-06-11 02:40:33.926523
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-11 02:40:36.816008
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector
    assert x._platform == 'HP-UX'
    assert x.required_facts == set(['platform', 'distribution'])
    assert x._fact_class == HPUXHardware

# Generated at 2022-06-11 02:40:45.396225
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    hardware.module = FakeAnsibleModule()
    hardware.module.run_command.return_value = 0, "8", ""
    hardware.populate()
    assert hardware.facts['processor_count'] == 8
    hardware.module.run_command.return_value = 0, "24", ""
    hardware.populate()
    assert hardware.facts['processor_cores'] == 8
    hardware.module.run_command.return_value = 0, "Intel(R) Itanium(R) Processor 9320", ""
    hardware.populate()
    assert hardware.facts['processor'] == "Intel(R) Itanium(R) Processor 9320"


# Generated at 2022-06-11 02:40:49.870343
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector is not None

# Generated at 2022-06-11 02:40:54.767553
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.hardware.hpu_ux.collector import HPUXHardwareCollector
    import ansible.module_utils.facts.hardware.hpu_ux
    __import__('ansible.module_utils.facts.hardware.hpu_ux')
    print(hasattr(ansible.module_utils.facts.hardware.hpu_ux, "HPUXHardwareCollector"))
    hwcoll = HPUXHardwareCollector()

# Generated at 2022-06-11 02:41:03.699183
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class MockModule(object):

        def __init__(self):
            self.run_command_args = []
            self.run_command_kwargs = []
            self.run_command_returns = [
                (0, 'S2350', '')
            ]

        def run_command(self, *args, **kwargs):
            self.run_command_args.append(args)
            self.run_command_kwargs.append(kwargs)
            return self.run_command_returns.pop(0)

    module = MockModule()
    #
    # Initialisation
    #
    hw = HPUXHardware()
    hw.module = module
    res = hw.get_hw_facts()
    assert res == {'model': 'S2350'}, res



# Generated at 2022-06-11 02:41:06.203089
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.platform == 'HP-UX'
    assert collector.fact_class == HPUXHardware



# Generated at 2022-06-11 02:41:25.974550
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hw = HPUXHardware(module)
    hw.get_memory_facts()

# Generated at 2022-06-11 02:41:36.153597
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw_facts = HPUXHardware()
    test_facts = {}
    test_facts['ansible_architecture'] = 'ia64'
    test_facts['ansible_system'] = 'HPUX'
    # test with old model
    test_facts['ansible_distribution_version'] = 'B.11.23'

    # Test old ioscan output
    rc, out, err = hw_facts.module.run_command("ioscan -FkCprocessor | wc -l")
    test_facts['ansible_processor_count'] = int(out.strip())

    # Test old machinfo output
    rc, out, err = hw_facts.module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'")

# Generated at 2022-06-11 02:41:45.662844
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpux_hardware = HPUXHardware()
    facts = {'ansible_architecture': 'ia64'}
    facts['ansible_distribution_version'] = "B.11.23"
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts=facts)
    assert 'processor_count' in cpu_facts and cpu_facts['processor_count'] == 4
    assert 'processor' in cpu_facts and cpu_facts['processor'].startswith('Intel')
    assert 'processor_cores' in cpu_facts and cpu_facts['processor_cores'] == 4
    facts['ansible_distribution_version'] = "B.11.31"
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts=facts)

# Generated at 2022-06-11 02:41:48.880253
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    fc = HPUXHardwareCollector(None, None)

    assert fc._platform == 'HP-UX'
    assert fc._fact_class == HPUXHardware
    assert fc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:41:50.329967
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-11 02:42:01.539897
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeModule({
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    })
    hw = HPUXHardware(module)
    memory_facts = hw.get_hw_facts()

    assert memory_facts['firmware_version'] == 'J56.75'
    assert memory_facts['product_serial'] == 'PAUG1831B5C'

    module = FakeModule({
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.31'
    })
    hw = HPUXHardware(module)
    memory_facts = hw.get_hw_facts()


# Generated at 2022-06-11 02:42:11.950759
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module_args = dict(
        gather_subset=[],
        filter=[]
    )
    # Basic module execution
    set_module_args(module_args)
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    machine_type_B11_23 = [
            'hpsim64',
            'hpux.ia64',
            'HP-UX',
            'B.11.23'
            ]
    machine_type_B11_31 = [
            'hpsim64',
            'hpux.ia64',
            'HP-UX',
            'B.11.31'
            ]

# Generated at 2022-06-11 02:42:14.591415
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    hardware_facts = hardware.get_cpu_facts(collected_facts)
    assert hardware_facts['processor_count'] == 0

# Generated at 2022-06-11 02:42:19.861891
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class HPUXHardware
    """
    import sys
    import os
    # sys.path.append( os.path.dirname(os.path.realpath(__file__)) + '/../../')
    # from test.units.compat.mock import patch, Mock

    # sys.modules['ansible'] = Mock()
    # del sys.modules['ansible.module_utils.facts.hardware.base']
    # del sys.modules['ansible.module_utils.facts.hardware.hpux']
    # del sys.modules['ansible.module_utils.facts.hardware.hpux'].HPUXHardware
    # sys.modules['ansible.module_utils.facts.hardware.hpux'].HPUXHardware = HPUXHardware

   

# Generated at 2022-06-11 02:42:23.783896
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.__class__.__name__ == 'HPUXHardwareCollector'
    assert collector.platform == 'HP-UX'
    assert collector.required_facts == set(['platform', 'distribution'])
