

# Generated at 2022-06-11 02:33:02.621594
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpux = HPUXHardware({'module_name': ''})
    for ar in ['9000/800', '9000/785']:
        hpux.module.run_command = Mock()
        hpux.module.run_command.return_value = (0, 4, '')
        hpux.get_cpu_facts({'ansible_architecture': ar})
        assert hpux.facts['processor_count'] == 4

    hpux.module.run_command = Mock()
    hpux.module.run_command.return_value = (0, '2 socket(s)', '')
    hpux.get_cpu_facts({'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert hpux.facts['processor_count'] == 2


# Generated at 2022-06-11 02:33:06.439015
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {
        'platform': 'HP-UX',
        'distribution': 'B.11.23',
        'ansible_architecture': 'ia64'
    }
    h_col = HPUXHardwareCollector(facts, {}, {}, {}, {})
    assert h_col.facts is not None

# Generated at 2022-06-11 02:33:10.482397
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Arrange
    collector = HPUXHardwareCollector()

    # Assert
    assert collector._fact_class == HPUXHardware
    assert collector._platform == 'HP-UX'
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:33:14.760119
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """Check that the constructor of HPUXHardwareCollector works without errors """

    collector = HPUXHardwareCollector()
    assert collector.platform == "HP-UX"
    assert collector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-11 02:33:24.170390
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModuleMock()
    hpux_hw = HPUXHardware(module=module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23',
    }
    # Test if cpu facts are collected for machine without cpu cores count
    # for release B.11.23
    out = hpux_hw.populate(collected_facts=collected_facts)
    assert out['processor_count'] == 1
    assert out['processor_cores'] == 2
    assert out['processor'] == 'Intel(r) Itanium 2'
    # Test swappages
    assert out['swapfree_mb'] == 0
    assert out['swaptotal_mb']

# Generated at 2022-06-11 02:33:33.076201
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    hardware_obj = HPUXHardware(module=module)
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')
    hardware_obj.populate(collected_facts=collected_facts)
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts=collected_facts)
    memory_facts = hardware_obj.get_memory_facts()
    hw_facts = hardware_obj.get_hw_facts()
    ansible_facts = dict()
    ansible_facts.update(cpu_facts)
    ansible_facts.update(memory_facts)
    ansible_facts.update(hw_facts)
    assert ansible

# Generated at 2022-06-11 02:33:45.156807
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    fact_subset = dict(platform='HP-UX', distribution='HP-UX')
    hardware = HPUXHardware(module=MockModule, facts=fact_subset)
    hardware.get_cpu_facts = Mock(return_value={'processor': 'blabla', 'processor_cores': '4', 'processor_count': '4'})
    hardware.get_memory_facts = Mock(return_value={'memfree_mb': '10', 'memtotal_mb': '20', 'swapfree_mb': '20', 'swaptotal_mb': '30'})
    hardware.get_hw_facts = Mock(return_value={'model': 'HP ENI', 'firmware': 'blabla'})


# Generated at 2022-06-11 02:33:52.576133
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    h = HPUXHardware({'ansible_system': 'HP-UX', 'ansible_architecture': 'ia64'})

    test_collected_facts = {
        'ansible_distribution': u'HP-UX',
        'ansible_distribution_version': u'B.11.31',
        'ansible_architecture': u'ia64'
    }

    assert h.get_cpu_facts(test_collected_facts) == {
        u'processor': u'Intel Xeon CPU E7-4830 @ 2.13GHz',
        u'processor_cores': 18,
        u'processor_count': 2
    }

# Generated at 2022-06-11 02:33:55.019012
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    print(hpux_hardware_collector.__class__.__name__)

# Generated at 2022-06-11 02:33:58.041065
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector.platform == 'HP-UX'
    assert isinstance(hw_collector._fact_class(dict()), HPUXHardware)

# Generated at 2022-06-11 02:34:13.666630
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins  # pylint: disable=import-error
    else:
        import builtins  # pylint: disable=import-error
    setattr(builtins, '__salt__', {})
    setattr(builtins, '__grains__', {})
    # data test
    test_facts_cpu = {
        'processor_count': 7,
        'processor': 'Intel(r) Itanium(r) Processor',
        'processor_cores': 8
    }
    # test with ia64 architecture
    test_collect_facts = {'ansible_distribution_version': "B.11.31"}
    HPUX_test = HPUXHardware()
    result_get_cpu_facts_

# Generated at 2022-06-11 02:34:16.808130
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector1 = HPUXHardwareCollector()
    assert hardware_collector1.fact_class == HPUXHardware
    assert hardware_collector1.platform == 'HP-UX'

# Generated at 2022-06-11 02:34:29.341527
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """
    Ensure if method HPUXHardware.get_memory_facts()
    return facts about memory
    """
    from ansible.module_utils.facts import get_module_facts
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    # setup
    hpux_facts = HPUXHardware()
    # mock facts
    hpux_facts.collect_as_dict()["ansible_architecture"] = "ia64"
    hpux_facts.collect_as_dict()["ansible_distribution_version"] = "B.11.11"
    # execution
    hpux_memory_facts = hpux_facts.get_memory_facts()
    # expected result

# Generated at 2022-06-11 02:34:36.038574
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class is HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector._required_facts == {'platform', 'distribution'}
    assert hardware_collector.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-11 02:34:47.182469
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class FakeModule:
        class FakeRunCommand:
            def __init__(self, module, shell=False):
                self.params = {
                    'chdir': None,
                    'creates': None,
                    'executable': None,
                    'removes': None,
                    'shel': shell,
                    'warn': True,
                }
                self.module = module


# Generated at 2022-06-11 02:35:00.282042
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import json

    module = AnsibleModule({})
    my_hp = HPUXHardware(module=module)

    syslog = """
    Jun 21 20:43:42 cmf-kvm-sppt-vagrant syslogd: Physical: 61248 Kbytes
    Jun 21 20:43:42 cmf-kvm-sppt-vagrant syslogd: Swap:   61188 Kbytes
    Jun 21 20:43:42 cmf-kvm-sppt-vagrant syslogd: Virtual:  65816 Kbytes
    """

    machinfo = """
    Memory = 2048 MB
    Physical = 2048 MB
    Virtual = 24576 MB
    Swap = 2048 MB
    """


# Generated at 2022-06-11 02:35:08.085601
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # setup data to be returned by ansible module
    collected_facts = dict()
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.31'

    # initialize test class
    test_class = HPUXHardware()
    test_class.module = ModuleStub()

    # initialize ansible result
    result = dict()

    # run the code under test
    result = test_class.get_cpu_facts(collected_facts)

    # verify the results
    assert result['processor_count'] == 48
    assert result['processor'] == 'Intel(R) Itanium(R) processor'
    assert result['processor_cores'] == 24



# Generated at 2022-06-11 02:35:22.407895
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = None
    hardware = HPUXHardwareCollector(module)
    test_facts = {'ansible_architecture': 'ia64',
                  'ansible_distribution_version': 'B.11.23'}
    out = hardware._fact_class.get_memory_facts(test_facts)
    assert out == {'swaptotal_mb': 16,
                   'memfree_mb': 456,
                   'memtotal_mb': 4096,
                   'swapfree_mb': 0}
    test_facts = {'ansible_architecture': 'ia64',
                  'ansible_distribution_version': 'B.11.31'}
    out = hardware._fact_class.get_memory_facts(test_facts)

# Generated at 2022-06-11 02:35:30.560809
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hpux_hw = HPUXHardware({}, {'ansible_architecture': 'ia64',
                                'ansible_distribution_version': 'B.11.31'})
    memory_facts = hpux_hw.get_memory_facts()
    assert memory_facts['memfree_mb'] == 'unknown'
    assert memory_facts['memtotal_mb'] == 'unknown'
    assert memory_facts['swaptotal_mb'] == 'unknown'
    assert memory_facts['swapfree_mb'] == 'unknown'



# Generated at 2022-06-11 02:35:42.116625
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    facts = HPUXHardware(module).get_cpu_facts({'ansible_architecture': '9000/785', 'ansible_distribution_version': 'B.11.31'})
    assert facts['processor_cores'] == 2
    assert facts['processor_count'] == 12
    assert facts['processor'] == 'Intel(r) Xeon(r) CPU X7560 @ 2.26GHz'
    facts = HPUXHardware(module).get_cpu_facts({'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'})
    assert facts['processor_cores'] == 1
    assert facts['processor_count'] == 4

# Generated at 2022-06-11 02:36:01.350392
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    HPUX = HPUXHardware({})
    HPUX.module = MockModule('ansible_architecture=ia64 ansible_distribution_version=B.11.23')
    HPUX.module.run_command = Mock(return_value=(0, "2", ""))
    res = HPUX.populate()

# Generated at 2022-06-11 02:36:13.349786
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule({})
    hpuxtest = HPUXHardware({})
    hpuxtest.module = module
    rc, out, err = hpuxtest.module.run_command("model")
    hw_facts = hpuxtest.get_hw_facts()
    assert hw_facts['model'] == out.strip()
    rc, out, err = hpuxtest.module.run_command("sysdef | grep -i 'Firmware'", use_unsafe_shell=True)
    rc, out, err = hpuxtest.module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision'", use_unsafe_shell=True)

# Generated at 2022-06-11 02:36:18.118397
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware().get_cpu_facts(collected_facts={'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'})
    assert cpu_facts.get('processor_count') == 2

# Generated at 2022-06-11 02:36:25.970281
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class ModuleStub:
        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "model":
                return (0, "HP 9000/800 HPCI", None)
            if cmd == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC":
                return (0, "Firmware revision: v4.33/10.15", None)
            if cmd == "/usr/contrib/bin/machinfo |grep -i 'Machine serial number' ":
                return (0, "Machine serial number: US123456789", None)

    module = ModuleStub()
    hpu = HPUXHardware()
    hpu.module = module

# Generated at 2022-06-11 02:36:30.958729
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()

    assert hhc._fact_class.platform == 'HP-UX'
    assert hhc._platform == 'HP-UX'
    assert hhc.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-11 02:36:39.631420
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Test get_cpu_facts method of class HPUXHardware
    """

    dev_null = open(os.devnull, "r")
    module = type("AnsibleModule", (object,), {"run_command": lambda *args, **kwargs: (0, "Hello", dev_null)})
    hw = HPUXHardware(module)

    # Case1: test get_cpu_facts with no facts
    result = hw.get_cpu_facts()
    assert result == {}

    # Case2: test get_cpu_facts for pa-risc, facts in collected_facts
    result = hw.get_cpu_facts({
        "ansible_architecture": "9000/800",
        "ansible_distribution_version": "B.11.23"
    })

# Generated at 2022-06-11 02:36:50.118545
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    host_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31',
                  'ansible_processor_vcpus': '4'}
    hw = HPUXHardware(module=None)
    cpu_facts = hw.get_cpu_facts(collected_facts=host_facts)
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) 64'


# Generated at 2022-06-11 02:36:51.268127
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hp = HPUXHardwareCollector()
    assert hp._platform == 'HP-UX'

# Generated at 2022-06-11 02:37:02.686585
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = HPUXHardware()
    hardware_facts.module = FakeModule()
    hardware_facts.populate()
    assert isinstance(hardware_facts.data, dict)
    assert hardware_facts.data == {'processor_cores': 4,
                                   'processor_count': 1,
                                   'swapfree_mb': 1401,
                                   'swaptotal_mb': 1408,
                                   'memtotal_mb': 499,
                                   'memfree_mb': 15,
                                   'model': 'ia64 hp server rx2800 i2',
                                   'firmware_version': 'B.11.23.1402',
                                   'product_serial': 'US-1234-5678'}

# Generated at 2022-06-11 02:37:05.429029
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    This test doesn't actually execute the command, it just checks if the module
    code will run in the environment.
    """
    module = get_module_mock()
    h = HPUXHardware(module=module)
    h.populate()

# Generated at 2022-06-11 02:37:33.433946
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class MockModule(object):
        def run_command(self, command, check_rc=True, data=None, binary_data=False, use_unsafe_shell=False):
            if command == "/usr/bin/vmstat | tail -1":
                return (0, "  1   0   0", "")
            if command == "grep Physical /var/adm/syslog/syslog.log":
                return (0, "Jan 18 00:26:52  lana unix: Physical: 646592 Kbytes", "")
            if command == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'":
                return (0, "8192", "")

# Generated at 2022-06-11 02:37:38.093903
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    hardware.populate(collected_facts)


# Generated at 2022-06-11 02:37:47.534139
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Test for get_memory_facts method of class HPUXHardware to
    # return correct memory facts on ia64 architecture
    class HW_facts(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class Module(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class R_mock(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class R_mock_swapinfo(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)


# Generated at 2022-06-11 02:37:56.149636
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hpux = HPUXHardware(module)
    memory_facts = hpux.get_memory_facts()
    memfree_mb = memory_facts.get('memfree_mb')
    memtotal_mb = memory_facts.get('memtotal_mb')
    swaptotal_mb = memory_facts.get('swaptotal_mb')
    swapfree_mb = memory_facts.get('swapfree_mb')
    assert memfree_mb
    assert memtotal_mb
    assert swaptotal_mb
    assert swapfree_mb

# Generated at 2022-06-11 02:38:01.354296
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class HPUXHardware(Hardware):

        platform = 'HP-UX'

        def populate(self, collected_facts=None):
            hardware_facts = {}
            hardware_facts = self.get_hw_facts()
            return hardware_facts

    hardware = HPUXHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['model'] == 'ia64'
    assert hardware_facts['product_serial'] == 'ABCDEFGHIJK'
    assert hardware_facts['firmware_version'] == 'v2.64 (10/03/08)'


# Generated at 2022-06-11 02:38:14.700666
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    m = HPUXHardware(dict())  # empty module parameters

    # unit tests for B.11.23
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    expected_cpu_facts = {'processor_count': 4, 'processor': 'Intel(R) Itanium(R) Processor', 'processor_cores': 4}
    assert m.get_cpu_facts(collected_facts) == expected_cpu_facts

    # unit tests for B.11.31
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-11 02:38:21.649796
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    h = HPUXHardware()
    facts = h.populate()
    assert facts['processor_cores']
    assert facts['processor_count']
    assert facts['processor']
    assert facts['model']
    assert facts['firmware_version']
    assert facts['product_serial']
    assert facts['memtotal_mb']
    assert facts['swaptotal_mb']
    assert facts['memfree_mb']
    assert facts['swapfree_mb']


# Generated at 2022-06-11 02:38:26.269772
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts_dict = {'platform': 'HP-UX',
                  'distribution': 'HP-UX'}
    h = HPUXHardwareCollector(facts_dict)
    assert h._platform == 'HP-UX'
    assert h._fact_class == HPUXHardware



# Generated at 2022-06-11 02:38:34.978599
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()

    collected_facts = dict(ansible_architecture='9000/800')
    out = hardware.get_memory_facts(collected_facts=collected_facts)
    assert out == {
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0
    }

    collected_facts = dict(ansible_architecture='ia64')
    out = hardware.get_memory_facts(collected_facts=collected_facts)
    assert out == {
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0
    }


# Generated at 2022-06-11 02:38:43.482443
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class MockModule(object):
        def run_command(self, command):
            out = '                memory               memory\n' \
                  'pages            total            free            pin  virtual    persistent    reserved\n' \
                  '255993        3615344         173576               0        0            0            0'
            return 0, out, ''

    h = HPUXHardware(MockModule())
    memory_facts = h.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 3615344 // 1024 // 1024
    assert memory_facts['memfree_mb'] == 173576 // 1024 // 1024

# Generated at 2022-06-11 02:39:16.693936
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    h = HPUXHardware()
    memory_facts = h.get_memory_facts()
    print(memory_facts)
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts

# Generated at 2022-06-11 02:39:21.902757
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
  module = AnsibleModule(argument_spec={})
  hwcollector = HPUXHardwareCollector(module=module)
  assert hwcollector.module == module
  assert hwcollector._platform == 'HP-UX'
  assert hwcollector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:39:26.066035
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hu = HPUXHardware()
    hw_facts = hu.populate()
    assert 'memfree_mb' in hw_facts
    assert 'memtotal_mb' in hw_facts
    assert 'swapfree_mb' in hw_facts
    assert 'swaptotal_mb' in hw_facts
    assert 'processor' in hw_facts
    assert 'processor_count' in hw_facts
    assert 'processor_cores' in hw_facts
    assert 'model' in hw_facts
    assert 'firmware_version' in hw_facts


if __name__ == '__main__':
    from ansible.module_utils.basic import *

    main()

# Generated at 2022-06-11 02:39:34.697304
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module=module)
    collected_facts = {
        'ansible_system': 'HP-UX',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_release': 'B.11.31',
        'ansible_distribution_version': 'B.11.31',
        'ansible_architecture': 'ia64',
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9640L'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 4

# Generated at 2022-06-11 02:39:40.366585
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    config = '{"required_facts": ["platform", "distribution"]}'
    required_facts = set(['platform', 'distribution'])
    facts_platform = "HP-UX"
    hhc = HPUXHardwareCollector(config)
    assert hhc.required_facts == required_facts
    assert hhc.facts_platform == facts_platform

# Generated at 2022-06-11 02:39:51.143872
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Dictionary about system facts for HP-UX
    # ansible_distribution: HP-UX
    # ansible_distribution_major_version: '11'
    # ansible_distribution_version: 'B.11.31'
    # ansible_os_family: Unix
    # ansible_system: HP-UX
    # ansible_system_vendor: Hewlett-Packard
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 02:39:53.410058
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector._fact_class == HPUXHardware
    assert collector._platform == 'HP-UX'

# Generated at 2022-06-11 02:39:56.442324
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = PhonyAnsibleModule(dict(platform='HP-UX', architecture='ia64', distribution_version='B.11.23'))
    hardware = HPUXHardware(module)

    collected_facts = dict(platform='HP-UX', architecture='ia64', distribution_version='B.11.23')
    memory = hardware.get_memory_facts(collected_facts)
    assert memory['memtotal_mb'] == 2048


# Generated at 2022-06-11 02:39:58.084424
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw._platform == 'HP-UX', "Platform name is incorrect"

# Generated at 2022-06-11 02:40:05.051334
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = HPUXHardware(dict(ansible_architecture="ia64", ansible_distribution_version="B.11.23")).get_hw_facts()
    assert hw_facts['model']
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']
    hw_facts = HPUXHardware(dict(ansible_architecture="ia64", ansible_distribution_version="B.11.31")).get_hw_facts()
    assert hw_facts['model']
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']
    hw_facts = HPUXHardware(dict(ansible_architecture="9000/800")).get_hw_facts()
    assert hw

# Generated at 2022-06-11 02:41:20.073792
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.hpx import HPUXHardware
    from ansible.module_utils.facts.hardware.hpx import HardwareCollector
    class MockModule(object):
        def run_command(self, command, use_unsafe_shell=False):
            return 0, "", ""
        def get_bin_path(self, command):
            return "/usr/bin"
    class MockHardwareCollector(HardwareCollector):
        def collect(self, module=None, collected_facts=None):
            return {
                'ansible_architecture': '9000/800',
                'ansible_distribution_version': 'B.11.31',
            }
    class MockHardware(HPUXHardware):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-11 02:41:25.640920
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={
            "collected_facts": {"required": False, "type": "dict"}
        })

    # ia64
    facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware(module=module, collected_facts=facts)
    facts = hardware.get_cpu_facts(collected_facts=facts)
    assert 'processor_count' in facts
    assert 'processor_cores' in facts
    assert 'processor' in facts
    assert facts['processor'] == 'Intel(R) Itanium(R) processor 9057'



# Generated at 2022-06-11 02:41:28.233032
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(dict(platform='HP-UX',
                           distribution='B.11.23'))
    assert hw.get_hw_facts() == {}

# Generated at 2022-06-11 02:41:33.356485
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hpuxtest = HPUXHardware()
    mem_facts = hpuxtest.get_memory_facts()
    assert mem_facts['memtotal_mb'] >= mem_facts['memfree_mb']
    if not mem_facts['swaptotal_mb']:
        assert mem_facts['swapfree_mb'] == mem_facts['swaptotal_mb']

# Generated at 2022-06-11 02:41:36.697662
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector('Test Module')
    assert collector._platform == 'HP-UX'
    assert collector._fact_class == HPUXHardware
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:41:41.636965
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class HPUXHardwareTest(HPUXHardware):
        """ Class in which we mock run_command to test get_memory_facts """

        def run_command(self, cmd, check_rc=True, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt=None, environ_update=None):
            output = ''
            if cmd == "/usr/bin/vmstat | tail -1":
                output = '  0   0   0 16683392    4556      4    0    0     0     0     0'

# Generated at 2022-06-11 02:41:48.024522
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hphw = HPUXHardware()
    hphw.module = module
    memory_facts = hphw.get_hw_facts({'platform': 'HP-UX', 'distribution_version': 'B.11.31'})
    assert memory_facts == {'model': 'ia64', 'firmware_version': 'B.11.31.2606.1.1', 'product_serial': 'CNU360106T'}

# Generated at 2022-06-11 02:41:57.755766
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    print('get_memory_facts')
    # First test with a bad architecture
    collected_facts = {"ansible_architecture": "FAKE"}
    hardware = HPUXHardware()
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts["memtotal_mb"] > 0
    # Second test with good architecture
    collected_facts = {"ansible_architecture": "9000/785"}
    hardware = HPUXHardware()
    memory_facts = hardware.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts["memtotal_mb"] > 0
    # Third test with ia64 architecture
    collected_facts = {"ansible_architecture": 'ia64'}
    hardware = HPUXHardware()
    memory

# Generated at 2022-06-11 02:42:09.186793
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))))
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    h = HPUXHardware()
    collected_facts={}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    cpu_facts = h.get_cpu_facts(collected_facts)
    # test with cpu facts = {}
    assert cpu_facts['processor_count'] == 4

# Generated at 2022-06-11 02:42:17.988667
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware()
    hardware.module.run_command = Mock(return_value=[0, "", ""])
    hardware.module.get_bin_path = Mock(return_value="/usr/contrib/bin")
    hardware.module.params = {'gather_subset': 'all'}
    hardware.module.params['gather_subset'] = ['all']
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    result = hardware.populate(collected_facts)
    assert result['ansible_processor_cores'] == 8
    assert result['ansible_processor_count'] == 8
    assert result['ansible_processor'] == 'Intel(R) Itanium(R) Processor 9350'
