

# Generated at 2022-06-11 02:33:05.028920
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Create an instance of HPUXHardware
    hardware = HPUXHardware({'platform': 'HP-UX', 'distribution': 'HP-UX'})
    # Define what the function should return
    hardware.module.run_command.side_effect = [
        # model() command
        (0, 'BL860c i2', ''),
        # /usr/contrib/bin/machinfo command
        (0, 'Firmware revision      : A.01.17\nMachine serial number    : serial_num', ''),
        # /usr/contrib/bin/machinfo command
        (0, 'Firmware revision      = A.01.17\nMachine serial number    = serial_num', ''),
    ]
    # Call the method

# Generated at 2022-06-11 02:33:07.701665
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    inst = HPUXHardwareCollector()
    assert inst.platform == 'HP-UX'
    assert inst.required_facts == {'platform', 'distribution'}
    assert inst.optional_facts == set([])

# Generated at 2022-06-11 02:33:16.982869
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})

    h = HPUXHardware(module=module)

    model = 'HP rp7400'
    firmware_version = '7.86'
    rc, out, err = module.run_command("model")
    assert h.get_hw_facts()['model'] == model
    assert h.get_hw_facts({'ansible_architecture': 'ia64'})['firmware_version'] == firmware_version
    assert h.get_hw_facts({'ansible_architecture': 'ia64'})['product_serial'] == '17A9B9AC8D'



# Generated at 2022-06-11 02:33:20.257863
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test = HPUXHardware(dict(ansible_architecture='9000/800'))
    result = test.get_cpu_facts()
    if result['processor_count'] == 2:
        return True
    return False



# Generated at 2022-06-11 02:33:30.944554
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # For an HP-UX system with 32 GB physical memory.
    memfree_out = """
$ /usr/bin/vmstat | tail -1
    0    0      0     1      0  173119  13895      0      0      0    0      0    0      0     0      0     0      0     0      0     0      0     0      0     0      0     0      0     0      0     0      0     0      0     0      0     0      0     0      0   245    143
"""
    memtotal_out = """
$ grep Physical /var/adm/syslog/syslog.log
Jul  4 15:35:18 host1 vmunix: Physical: 33037284 Kbytes
"""

# Generated at 2022-06-11 02:33:33.509690
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collectors

    facts_dict = collectors.get_collector_facts(dict(), Collector)
    hw_collector = HPUXHardwareCollector(facts_dict=facts_dict)

# Generated at 2022-06-11 02:33:45.306870
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    def mock_run_command(module, command):
        if command == "/usr/contrib/bin/machinfo | grep Memory":
            return 0, 'Memory:            16384 MB', ''
        elif command == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'":
            return 0, '16384', ''
        elif command == "grep Physical /var/adm/syslog/syslog.log":
            return 0, 'physical memory: 16384 Kbytes', ''
        elif command == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'":
            return 1, '', ''

# Generated at 2022-06-11 02:33:46.956891
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 02:33:53.691341
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_object = HPUXHardware()
    facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23',
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX'
    }
    test_object.module = mock.MagicMock()
    test_object.module.run_command.return_value = (0, "Firmware revision = P89 v2.63", "")
    test_object.module.run_command.return_value = (0, "Machine serial number = CZ29601SGW", "")
    assert test_object.get_hw_facts(collected_facts=facts)['firmware_version'] == 'P89 v2.63'
    assert test

# Generated at 2022-06-11 02:33:57.949486
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.__class__.__name__ == 'HPUXHardwareCollector'
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-11 02:34:15.908292
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    facts = dict(platform='HP-UX', distribution='B.11.31')
    hw = HPUXHardware(facts=facts)
    hw.module = None
    hw.populate()

    assert hw.ansible_facts['processor_count'] == 2
    assert hw.ansible_facts['processor_cores'] == 24
    assert hw.ansible_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2650 v4 @ 2.20GHz'
    assert hw.ansible_facts['memtotal_mb'] == 66560
    assert hw.ansible_facts['memfree_mb'] == 12561
    assert hw.ansible_facts['swaptotal_mb'] == 8192
    assert hw.ansible_facts['swapfree_mb'] == 8

# Generated at 2022-06-11 02:34:28.415583
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    collected_facts = {'platform': 'HP-UX', 'ansible_architecture': 'ia64'}
    collected_facts.update({'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'})
    hw.populate(collected_facts)
    hw.get_hw_facts(collected_facts)

    collected_facts.update({'ansible_distribution_version': 'B.11.23'})
    hw.populate(collected_facts)
    hw.get_hw_facts(collected_facts)

    collected_facts.update({'ansible_architecture': '9000/800'})
    hw.populate(collected_facts)
    hw.get

# Generated at 2022-06-11 02:34:30.667390
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    HPUXHardware.get_memory_facts()


# Generated at 2022-06-11 02:34:38.270505
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    m = HPUXHardware({'platform': 'HP-UX', 'distribution': 'HP-UX'})
    rc, out, err = m.module.run_command("model")
    assert m.get_hw_facts()['model'] == out.strip()
    assert m.get_hw_facts()['firmware_version'] == '5.0'
    assert m.get_hw_facts()['product_serial'] == '1234567890'



# Generated at 2022-06-11 02:34:46.943276
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HPUXHardwareCollector.has_required_facts(module.params, module.deprecated_facts):
        module.fail_json(msg='Missing required facts or fact gathering disabled')

    hardware = HPUXHardware(module, collected_facts={'ansible_architecture': 'parisc'})

    hardware.populate()

    assert hardware.facts['processor'] == u'1.20 gigahertz PA-RISC 8700'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memfree_mb'] == 919

# Generated at 2022-06-11 02:34:49.692861
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.platform == 'HP-UX'

# Generated at 2022-06-11 02:34:54.733637
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """This is a test for the constructor of class HPUXHardwareCollector"""
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector.platform == 'HP-UX'

# Generated at 2022-06-11 02:35:05.724443
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    fake_module = FakeModule()
    test_class = HPUXHardware()
    test_class.module = fake_module
    test_data = {'ansible_architecture': '9000/785', 'ansible_distribution_version': '11.31'}
    cpu_facts = test_class.get_cpu_facts(collected_facts=test_data)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(r) Itanium(r) Processor 9320'
    assert cpu_facts['processor_cores'] == 12
    test_data = {'ansible_architecture': '9000/800', 'ansible_distribution_version': '11.31'}

# Generated at 2022-06-11 02:35:07.607483
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector()
    assert hc is not None

# Generated at 2022-06-11 02:35:11.744168
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts_dict = {'platform': 'HP-UX'}
    hw = HPUXHardwareCollector(module=None, facts=facts_dict)
    assert hw.platform == 'HP-UX'

# Generated at 2022-06-11 02:35:44.958085
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hpux_hw = HPUXHardware()
    assert hpux_hw.populate() == {}



# Generated at 2022-06-11 02:35:52.508383
# Unit test for method get_hw_facts of class HPUXHardware

# Generated at 2022-06-11 02:35:59.191325
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    HPUXHardware - populate()
    """
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)

    # Set a test value for ansible_machine, ansible_architecture and ansible_distribution_version
    module.ansible_machine = "9000/785"
    module.ansible_architecture = "9000/785"
    module.ansible_distribution_version = "B.11.31"

    # Set test value for ioscan -FkCprocessor
    hardware.module.run_command = MagicMock(return_value=(0, "10", ""))
    # Set test value for /usr/contrib/bin/machinfo

# Generated at 2022-06-11 02:36:06.352938
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Check required_facts
    hw = HPUXHardwareCollector()
    required_facts = set(['platform', 'distribution'])
    assert hw.required_facts == required_facts

    # Check _fact_class
    assert hw._fact_class == HPUXHardware

    # Check _platform
    assert hw._platform == 'HP-UX'

# Generated at 2022-06-11 02:36:14.398085
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hpux_hardware = HPUXHardware({'ansible_architecture': '9000/800'})
    hpux_hardware.module.run_command = lambda cmd, use_unsafe_shell=False: (0, "", "")
    hpux_hardware.module.run_command = lambda cmd, use_unsafe_shell=False: (0, "19200   0   8", "")
    assert hpux_hardware.get_memory_facts()['memfree_mb'] == 64
    hpux_hardware.module.run_command = lambda cmd, use_unsafe_shell=False: (0, "/dev/vg01/lvol1       6348800 -      1626496      4722304          -    0%", "")

# Generated at 2022-06-11 02:36:21.692873
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = dict(platform='HP-UX', distribution='HP-UX')
    h = HPUXHardwareCollector(facts=facts)
    h_facts = h.collect()
    assert h_facts.memtotal_mb == h_facts.memfree_mb + h_facts.swaptotal_mb + h_facts.swapfree_mb
    assert h_facts.processor_count == h_facts.processor_cores * h_facts.processor_count

# Generated at 2022-06-11 02:36:26.526458
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts = HPUXHardwareCollector.required_facts
    assert isinstance(required_facts, set)
    hw = HPUXHardwareCollector()
    assert hw._fact_class == HPUXHardware
    assert hw._platform == 'HP-UX'

# Generated at 2022-06-11 02:36:35.506667
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Unit test for method get_hw_facts of class HPUXHardware
    """
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.collector import Collector
    test_object = Collector()
    test_object.module = Collector()
    test_object.module.run_command = lambda cmd: (0, "hp rx6600", "")
    result = HPUXHardware().get_hw_facts()
    assert result == {'model': 'hp rx6600'}, f"Real output is {result}"

# Generated at 2022-06-11 02:36:41.271158
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector_obj = HPUXHardwareCollector()
    assert hardware_collector_obj.required_facts == set(['platform', 'distribution'])
    assert hardware_collector_obj._platform == 'HP-UX'
    assert hardware_collector_obj._fact_class == HPUXHardware


# Generated at 2022-06-11 02:36:43.478281
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert isinstance(x, HardwareCollector)


# Generated at 2022-06-11 02:37:22.267629
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # GIVEN: class instanciation
    h = HPUXHardware({})

    # WHEN: memtotal_mb, memfree_mb, swaptotal_mb, swapfree_mb are retrieved
    facts = h.get_memory_facts()

    # THEN: no exception is raised and values are number
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert type(facts['memtotal_mb']) is int
    assert type(facts['memfree_mb']) is int
    assert type(facts['swaptotal_mb']) is int
    assert type(facts['swapfree_mb']) is int

# Generated at 2022-06-11 02:37:34.735549
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    HPUXHardware - unit test for method populate.
    """
    hw = HPUXHardware(module=None)

    rc, out, err = hw.module.run_command("/usr/contrib/bin/machinfo | grep 'Number of CPUs'", use_unsafe_shell=True)
    out = int(out.strip().split('=')[1])

    rc, out, err = hw.module.run_command("/usr/contrib/bin/machinfo | grep 'processor family'", use_unsafe_shell=True)
    out = re.search('.*(Intel.*)', out).groups()[0].strip()


# Generated at 2022-06-11 02:37:45.246521
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Given
    module_mock = MagicMock(run_command=MagicMock(return_value=(0, '', '')))
    arch_mock = MagicMock(
        get_ansible_facts=MagicMock(
            return_value={
                'ansible_architecture': 'ia64',
                'ansible_distribution_version': 'B.11.23'
            }
        )
    )
    hpux_hardware_mock = HPUXHardware(module=module_mock)
    hpux_hardware_mock.architecture = arch_mock

    # When
    result = hpux_hardware_mock.get_cpu_facts()

    # Then
    assert result == {}

    # Given

# Generated at 2022-06-11 02:37:49.154797
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('', (object,), {})
    setattr(module, 'run_command', None)
    facts = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/785'}
    expected_result = {'processor_count': 2}
    cpu_stats = facts.get_cpu_facts(collected_facts)
    assert cpu_stats == expected_result



# Generated at 2022-06-11 02:37:54.272497
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    m = HPUXHardwareCollector({'platform': 'HP-UX', 'distribution': 'HP-UX'})
    assert(m._platform == 'HP-UX')
    assert(issubclass(m._fact_class, HPUXHardware))
    assert(m.required_facts == {'platform', 'distribution'})

# Generated at 2022-06-11 02:37:58.188962
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class TestModule(object):
        def run_command(self, *args, **kwargs):
            return 0, '', ''

    hw = HPUXHardware(TestModule())
    hw.get_hw_facts()

# Generated at 2022-06-11 02:38:10.116155
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    #module = AnsibleModule(argument_spec={})
    HPUXHardware.module = MagicMock()
    HPUXHardware.module.run_command.return_value = (0, '1\n', '')
    hardware = HPUXHardware(HPUXHardware.module)
    hardware.platform = 'HP-UX'
    hardware.distribution_version = 'B.11.23'
    arch = hardware.distribution_major_version
    collected_facts = {'ansible_architecture': arch,
                       'ansible_distribution_version': hardware.distribution_version}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1



# Generated at 2022-06-11 02:38:19.850543
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    _module = None
    _facts = dict(processor_count=2, ansible_architecture='ia64')

    # without collected facts
    hw = HPUXHardware(_module)
    got_mem_facts = hw.get_memory_facts()
    assert got_mem_facts['memtotal_mb'] == 2048
    got_mem_facts = hw.get_memory_facts(collected_facts=_facts)
    assert got_mem_facts['memtotal_mb'] == 2048

    # with collected facts
    _facts['ansible_architecture'] = '9000/800'
    hw = HPUXHardware(_module)
    got_mem_facts = hw.get_memory_facts(collected_facts=_facts)
    assert got_mem_facts['memtotal_mb'] == 2048



# Generated at 2022-06-11 02:38:24.054215
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    har_obj = HPUXHardwareCollector()
    assert har_obj is not None
    assert har_obj._fact_class == HPUXHardware
    assert har_obj._platform == 'HP-UX'


# Generated at 2022-06-11 02:38:33.039943
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params = {}
    hpux_hardware = HPUXHardware(test_module)
    test_cpu_facts = {
        'processor': 'Intel(R) Itanium(R) Processor',
        'processor_cores': 64,
        'processor_count': 2,
    }
    cpu_facts = hpux_hardware.get_cpu_facts(test_cpu_facts)
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['processor_cores'] == 64
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-11 02:39:44.246441
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    hw_facts = HPUXHardware(dict(ansible_facts=dict(
        ansible_architecture= 'ia64',
        ansible_distribution_version= 'B.11.23'
        )))
    hw_facts.populate()
    """
    # It is not possible to test with 'B.11.31' because ioscan command is not available in docker
    hw_facts = HPUXHardware(dict(ansible_facts=dict(
        ansible_architecture = '9000/800'
    )))
    hw_facts.populate()
    assert hw_facts._facts['model'] == '9000/800'
    assert hw_facts._facts['firmware_version'] == ''

# Generated at 2022-06-11 02:39:46.588992
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h._fact_class == HPUXHardware
    assert h._platform == 'HP-UX'

# Generated at 2022-06-11 02:39:50.437862
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector._platform == 'HP-UX'
    assert collector._fact_class == HPUXHardware
    assert collector.required_facts == {'platform', 'distribution'}



# Generated at 2022-06-11 02:39:57.819969
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    input_dict = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

    expected_dict = {
        'processor_count': 12,
        'processor': 'Intel(r) Itanium(r) Processor Family 2.40GHz',
        'processor_cores': 6
    }

    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    cpu_facts = hardware.get_cpu_facts(collected_facts=input_dict)
    assert cpu_facts == expected_dict


# Generated at 2022-06-11 02:40:04.895302
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, "9000/800", ''))
    hw = HPUXHardware()
    hw.module = module

    rc, out, err = module.run_command("model")
    if rc != 0:
        raise Exception("Command execution failed:" + err)

    out = out.strip()
    rc, out, err = module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    if rc != 0:
        raise Exception("Command execution failed:" + err)

    out = out.split(':')[1].strip()

# Generated at 2022-06-11 02:40:15.902424
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
  module = Mock()
  module.run_command = Mock(return_value=(0, 'HP-UX rp4440 B.11.31 U ia64 019939301141', ''))
  hpuxhw = HPUXHardware(module)
  assert isinstance(hpuxhw, HPUXHardware)
  hw_facts = hpuxhw.get_hw_facts()
  assert len(hw_facts) == 2
  assert hw_facts['model'] == 'HP-UX rp4440 B.11.31 U ia64 019939301141'
  assert hw_facts['firmware_version'] == '1204'
  assert hw_facts['product_serial'] == 'CZ3123X0F0'


# Generated at 2022-06-11 02:40:19.140270
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:40:23.139333
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.fact_class is HPUXHardware
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-11 02:40:29.800708
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)

    rc, out, err = module.run_command("model")
    hw_facts = hardware.populate({'ansible_architecture': 'ia64',
                                  'ansible_distribution': 'HP-UX',
                                  'ansible_distribution_version': 'B.11.31'})
    assert hw_facts['model'] == out.strip()

# Generated at 2022-06-11 02:40:37.838817
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hpx = HPUXHardware()
    facts = hpx.populate()
    assert facts['processor'] == 'Intel(R) Itanium Processor'
    assert facts['processor_cores'] == 2
    assert facts['processor_count'] == 4
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 1578
    assert facts['swaptotal_mb'] == 992
    assert facts['swapfree_mb'] == 992
    assert facts['model'] == 'ia64 hp Integrity rx2660 Server'

# Generated at 2022-06-11 02:41:23.722696
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.31'}
    hw_facts = HPUXHardware(module=None).get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'P78 V2.32'
    assert hw_facts['model'] == 'HP rx2800 i2'
    assert hw_facts['product_serial'] == 'USCHU0ZR9Q'
    collected_facts['ansible_distribution_version'] = "B.11.23"

# Generated at 2022-06-11 02:41:31.659620
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    facts = hw.collect()

    assert type(facts) is dict
    assert type(facts.get('processor_count')) is int
    assert type(facts.get('processor_cores')) is int
    assert type(facts.get('memtotal_mb')) is int
    assert type(facts.get('memfree_mb')) is int
    assert type(facts.get('swaptotal_mb')) is int
    assert type(facts.get('swapfree_mb')) is int
    assert type(facts.get('model')) is str

# Generated at 2022-06-11 02:41:34.330468
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    x = HPUXHardwareCollector()
    assert x.fact_class == _fact_class
    assert x.platform == _platform
    assert x.required_facts == required_facts

# Generated at 2022-06-11 02:41:40.746707
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(dict(ansible_distribution='HP-UX'))
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31')
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert cpu_facts['processor_cores'] == 8



# Generated at 2022-06-11 02:41:42.852025
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    result = HPUXHardwareCollector()
    assert result.platform == 'HP-UX'
    assert result.fact_class == HPUXHardware

# Generated at 2022-06-11 02:41:51.642684
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class AnsibleModuleMock:
        def run_command(self, command, use_unsafe_shell=False):
           if command == '/usr/sbin/swapinfo -m -d -f -q':
               return 0, '1234', ''
           if command == '/usr/sbin/swapinfo -m -d -f | egrep \'^dev|^fs\'':
               return 0, '5678', ''
           if command == 'grep Physical /var/adm/syslog/syslog.log':
               return 0, 'Physical: 6758272 Kbytes', ''
           if command == '/usr/bin/vmstat | tail -1':
               return 0, '12819480 12819480 12819480 12819480', ''

# Generated at 2022-06-11 02:41:53.052319
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """ Constructor test """
    HPUXHardwareCollector()

# Generated at 2022-06-11 02:42:04.759916
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # Method populate is normally called by the HardwareCollector which takes care of passing collected facts.
    # Here we have to set the platform and collected facts manually.

    collected_facts = {'platform': 'HP-UX'}
    hw = HPUXHardware(collected_facts=collected_facts)

    facts = hw.populate()

    assert isinstance(facts, dict)
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'model' in facts
    assert 'firmware_version' in facts



# Generated at 2022-06-11 02:42:09.669998
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('', (), {})()
    module.run_command = lambda cmd, **args: (0, 'A500', None)
    h = HPUXHardware(module)
    hw_facts = h.get_hw_facts()

    assert hw_facts['model'] == 'A500'


# Generated at 2022-06-11 02:42:12.354918
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector is not None
    assert isinstance(collector._fact_class, HPUXHardware)
    assert collector._platform == 'HP-UX'
    assert collector.required_facts == set(['platform', 'distribution'])
