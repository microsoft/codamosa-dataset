

# Generated at 2022-06-11 02:33:05.804434
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {'ansible_architecture': 'ia64',
             'ansible_distribution_version': 'B.11.31'}
    h = HPUXHardware(None)
    assert h.get_cpu_facts() == {'processor_count': 2,
                                 'processor_cores': 8,
                                 'processor': 'Intel(r) Itanium(r) processor (1.6 GHz, 24 MB)'}
    facts = {'ansible_architecture': '9000/800',
             'ansible_distribution_version': 'B.11.23'}
    h = HPUXHardware(None)
    assert h.get_cpu_facts() == {'processor_count': 2}


# Generated at 2022-06-11 02:33:07.766829
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector(None)
    assert isinstance(hc._fact_class, HPUXHardware)

# Generated at 2022-06-11 02:33:10.848552
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h._platform == 'HP-UX'
    assert isinstance(h._fact_class, HPUXHardware)

# Generated at 2022-06-11 02:33:18.425075
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Test with empty params
    hardware_collector = HPUXHardwareCollector({})
    # Test facts_module
    assert hardware_collector.facts_module == 'ansible.module_utils.facts.hardware.hpux'
    # Test fact_class
    assert hardware_collector.fact_class == HPUXHardware
    # Test platform
    assert hardware_collector.platform == 'HP-UX'
    # Test required_facts
    assert hardware_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-11 02:33:20.118181
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector.collect() == set(['HPUXHardware'])

# Generated at 2022-06-11 02:33:23.149201
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    hw._module.run_command = lambda cmd: (0, "Test", "")
    hw.get_hw_facts()

# Generated at 2022-06-11 02:33:31.930313
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    module = MockModule()
    hpuxhardware = HPUXHardware(module)
    collected_facts = {'platform': 'HP-UX', 'ansible_architecture': 'ia64', 'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.31'}
    assert hpuxhardware.get_hw_facts(collected_facts) == {'model': 'ia64 hp server rx3616', 'firmware_version': 'v0.43',
                                                         'product_serial': 'USE90103TH'}



# Generated at 2022-06-11 02:33:38.730401
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwCollector = HPUXHardwareCollector()
    assert hwCollector._fact_class == HPUXHardware
    assert hwCollector._platform == 'HP-UX'
    assert hwCollector.required_facts == set(['platform', 'distribution'])
    assert hwCollector.optional_facts == set([])

# Constructor test for class HPUXHardwareCollector

# Generated at 2022-06-11 02:33:43.650089
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:33:46.967729
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector._fact_class == HPUXHardware

if __name__ == "__main__":
    test_HPUXHardwareCollector()

# Generated at 2022-06-11 02:34:04.224935
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    import json

    data = {
      "ansible_facts": {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.31"
      },
      "changed": false,
      "failed": false,
      "invocation": {
        "module_args": {
          "gather_subset": [
            "all"
          ],
          "gather_timeout": 10
        }
      }
    }
    host = HPUXHardware(module=None)
    collect_facts = HPUXHardwareCollector(module=None)
    memory_facts = host.get_memory_facts(data['ansible_facts'])
    assert json.dumps(memory_facts['memfree_mb']) == '2'

# Generated at 2022-06-11 02:34:10.734219
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    harware = HPUXHardware(module=module)

    # Test with default parameters
    result = harware.get_memory_facts({})
    expected = {'memtotal_mb': 16384, 'swaptotal_mb': 1, 'swapfree_mb': 0, 'memfree_mb': 10}
    assert result == expected

# Generated at 2022-06-11 02:34:17.105153
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hw = _HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    hw_facts = hw.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'v4.55'

# Generated at 2022-06-11 02:34:29.726831
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    import platform

    # Set up test information
    hardware = HPUXHardware()
    hardware.module = AnsibleModuleStub()
    hardware.module.run_command.return_value = (0, 'ia64', '')
    hardware.module.run_command.return_value = (0, 'B.11.31', '')
    hardware.module.run_command.return_value = (0, 'HP Integrity server rx2660', '')
    hardware.module.run_command.return_value = (0, 'Firmware revision: A.11.32.01', '')
    hardware.module.run_command.return_value = (0, 'Machine serial number: example', '')
    ansible_facts = hardware.pop

# Generated at 2022-06-11 02:34:42.351068
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock()
    hpx_hw = HPUXHardware(module=module)

    # test model
    module.run_command.return_value = (0, 'HP Integrity rx2620', '')
    assert hpx_hw.get_hw_facts().get('model') == 'HP Integrity rx2620'

    # test firmware version
    module.run_command.side_effect = [
        (0, 'Firmware revision                        = 2016.01.07', ''),
        (0, 'Machine serial number                    = CZC23324TD', '')]
    assert hpx_hw.get_hw_facts().get('firmware_version') == '2016.01.07'

# Generated at 2022-06-11 02:34:53.628880
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = None
    collected_facts = dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23')
    hardware = HPUXHardware(module=module)
    hardware_facts = hardware.populate(collected_facts=collected_facts)
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor'

# Generated at 2022-06-11 02:34:58.385208
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwc = HPUXHardwareCollector()
    assert hwc.platform == 'HP-UX'
    assert hwc.required_facts == set(['platform', 'distribution'])
    assert hwc._fact_class == HPUXHardware


# Generated at 2022-06-11 02:35:01.642401
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector(None)
    assert hhc
    assert isinstance(hhc, HPUXHardwareCollector)


# Generated at 2022-06-11 02:35:04.974146
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """This is a basic test for the constructor of the class"""
    hpux_hw_obj = HPUXHardwareCollector()
    assert hpux_hw_obj
    assert isinstance(hpux_hw_obj, HPUXHardwareCollector)


# Generated at 2022-06-11 02:35:10.307945
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hw_collector = HPUXHardwareCollector()
    assert hpux_hw_collector._fact_class == HPUXHardware
    assert hpux_hw_collector._platform == 'HP-UX'
    assert hpux_hw_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:35:44.452750
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_file_path = os.path.dirname(os.path.realpath(__file__))
    with open(test_file_path + '/data/HPUXHardware_get_memory_facts_vmstat_machinfo.txt', 'r') as f:
        vmstat = f.read().splitlines()
    with open(test_file_path + '/data/HPUXHardware_get_memory_facts_machinfo.txt', 'r') as f:
        machinfo = f.read().splitlines()
    with open(test_file_path + '/data/HPUXHardware_get_memory_facts_swapinfo.txt', 'r') as f:
        swapinfo = f.read().splitlines()

# Generated at 2022-06-11 02:35:52.165384
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {'platform': 'HP-UX', 'ansible_architecture': '9000/800'}
    hp_hw = HPUXHardware(module=None, facts=facts)
    rc, out, err = hp_hw.module.run_command("ioscan -FkCprocessor | wc -l")
    cpu_facts = hp_hw.get_cpu_facts(facts)
    assert cpu_facts['processor_count'] == int(out.strip())

    facts = {'platform': 'HP-UX', 'ansible_architecture': '9000/785'}
    hp_hw = HPUXHardware(module=None, facts=facts)
    rc, out, err = hp_hw.module.run_command("ioscan -FkCprocessor | wc -l")
    cpu_facts = hp_

# Generated at 2022-06-11 02:36:04.038048
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_mem_free = 480752
    test_mem_total = 3045120
    test_swap_free = 40960
    test_swap_total = 40960
    test_collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    test_hw = HPUXHardware()
    test_hw_facts = test_hw.get_memory_facts(collected_facts=test_collected_facts)
    assert test_hw_facts['memfree_mb'] == test_mem_free
    assert test_hw_facts['memtotal_mb'] == test_mem_total
    assert test_hw_facts['swapfree_mb'] == test_swap_free
    assert test_hw_facts['swaptotal_mb']

# Generated at 2022-06-11 02:36:15.157527
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Generate a fake module
    from collections import namedtuple
    module = namedtuple("AnsibleModule", ["run_command", "fail_json"])
    setattr(module, "run_command", lambda x: (0, "", ""))
    setattr(module, "fail_json", lambda x: None)
    # Create an instance of the class
    hw_gather = HPUXHardware(module)

    # Get vmstat output
    rc, out, err = module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)

    # Get memory facts
    memory_facts = hw_gather.get_memory_facts()

    # Check memory_facts keys
    keys_set = set(memory_facts.keys())
    keys_set_target = set

# Generated at 2022-06-11 02:36:25.799046
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)

    collected_facts = {'ansible_architecture': '9000/800'}
    hardware.module.run_command = Mock(return_value=(0, '2', ''))
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hardware.module.run_command = Mock(side_effect=[(0, 'Intel Itanium 2', ''), (0, '1', ''), (0, '2', ''), (0, 'Intel(R) Itanium(R) Processor 9350', '')])

# Generated at 2022-06-11 02:36:34.931017
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModuleHelper(
        argument_spec = dict()
    )

    hardware_collector = HPUXHardwareCollector(module=module)
    hardware_facts_instance = hardware_collector._fact_class(module)
    hardware_facts = hardware_facts_instance.get_memory_facts()

    assert isinstance(hardware_facts, dict)
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

# Generated at 2022-06-11 02:36:37.892971
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts_test = HPUXHardware.get_cpu_facts(collected_facts=None)
    assert cpu_facts_test == {}


# Generated at 2022-06-11 02:36:46.133548
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}
    out = module.get_memory_facts(collected_facts=collected_facts)
    assert out['memtotal_mb'] == 4194304
    assert out['memfree_mb'] == 0
    assert out['swaptotal_mb'] == 40960
    assert out['swapfree_mb'] == 20480

# Generated at 2022-06-11 02:36:55.521610
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    hw.module = MockModule()
    hw.module.run_command = MockHPUXRunCommand()
    hw.get_memory_facts()
    expected_memtotal_mb = 47864
    expected_memfree_mb = 40504
    expected_swaptotal_mb = 2302
    expected_swapfree_mb = 899
    assert hw.memtotal_mb == expected_memtotal_mb
    assert hw.memfree_mb == expected_memfree_mb
    assert hw.swaptotal_mb == expected_swaptotal_mb
    assert hw.swapfree_mb == expected_swapfree_mb



# Generated at 2022-06-11 02:37:05.619053
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware({'module_setup': True})
    # Scenario 1:
    hw.get_memory_facts({'ansible_architecture': None})
    hw.get_memory_facts({'ansible_architecture': 'x86_64'})
    hw.get_memory_facts({'ansible_architecture': 'i386'})
    # Scenario 2:
    hw.get_memory_facts({'ansible_architecture': '9000/800'})
    hw.get_memory_facts({'ansible_architecture': '9000/785'})
    # Scenario 3:
    hw.get_memory_facts({'ansible_architecture': 'ia64'})

# Generated at 2022-06-11 02:37:43.051296
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    import tempfile
    import os

    # Create a temp directory
    tmpdir = tempfile.gettempdir()

    # Create a file
    file_name = os.path.join(tmpdir, 'syslog.log')
    file = open(file_name, "w")
    file.write("""Oct 14 14:02:25 localhost syslogd: restart (pid 1234)\nOct 14 14:02:25 localhost Physical: 786432 Kbytes\n""")
    file.close()

    # Take os facts

# Generated at 2022-06-11 02:37:44.381204
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 02:37:56.884921
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    def test_module_run_command(cmd, *args, **kwargs):
        if cmd ==  "model":
            out = "B.11.11. U  9000/800"
        elif cmd == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC":
            out = "Firmware revision: v1.0"
        elif cmd == "/usr/contrib/bin/machinfo |grep -i 'Machine serial number' ":
            out = "Machine serial number : ABCDEFG"
        return 0, out, ''
    module = type("AnsibleModule", (object,), {"run_command": test_module_run_command})()

# Generated at 2022-06-11 02:38:05.115631
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = FakeAnsibleModule('HP-UX')
    test_module.run_command = MockRunCommand()
    test_module.command_results = test_module.run_command.results
    setattr(test_module, '_ansible_debug', True)
    mem_facts = HPUXHardware(test_module).get_memory_facts()
    assert mem_facts['memfree_mb'] == 1607
    assert mem_facts['memtotal_mb'] == 2869



# Generated at 2022-06-11 02:38:09.548007
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.required_facts == {'platform', 'distribution'}
    assert hw._platform == 'HP-UX'
    assert hw._fact_class == HPUXHardware


# Generated at 2022-06-11 02:38:19.370320
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    tmp = HPUXHardware()

    # Valid CPU model
    facts = {'ansible_distribution_version': 'B.11.23',
             'ansible_architecture': 'ia64'}
    out = tmp.get_cpu_facts(collected_facts=facts)
    assert out.get('processor_count') == 2
    assert out.get('processor') == 'Intel(R) Itanium(R) Processor 9140'
    assert out.get('processor_cores') == 16

    # Invalid CPU model
    facts = {'ansible_distribution_version': 'B.11.23',
             'ansible_architecture': 'ia65'}
    out = tmp.get_cpu_facts(collected_facts=facts)
    assert out.get('processor_count') is None

# Generated at 2022-06-11 02:38:30.417134
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware = HPUXHardware(dict(), dict())
    hardware.module = MockModule()
    hardware.get_cpu_facts = Mock(return_value=dict(
        processor_count=0,
        processor='',
        processor_cores=0
    ))
    hardware.get_memory_facts = Mock(return_value=dict(
        memfree_mb=1024,
        memtotal_mb=2048,
        swapfree_mb=10,
        swaptotal_mb=100
    ))
    hardware.get_hw_facts = Mock(return_value=dict(
        model='model',
        firmware_version='version',
        product_serial='serial'
    ))

    facts = hardware.populate()


# Generated at 2022-06-11 02:38:42.721695
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    hw.module = FakeAnsibleModule()
    collected = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    result = hw.get_cpu_facts(collected_facts=collected)
    assert result['processor'] == 'Intel(R) Itanium(R) Processor 9300 series'
    assert result['processor_count'] == 48
    assert result['processor_cores'] == 12
    collected = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    result = hw.get_cpu_facts(collected_facts=collected)

# Generated at 2022-06-11 02:38:52.040477
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = {'platform': 'HP-UX', 'distribution_version': 'B.11.31', 'distribution': 'HP-UX',
                       'distribution_major_version': 'B.11', 'architecture': 'ia64'}
    hpux_hw = HPUXHardware()
    hpux_hw.module = MagicMock()
    hpux_hw.module.run_command.return_value = (0,  "Number of CPUs = 2", None)
    hpux_hw.get_hw_facts = MagicMock()
    hpux_hw.get_hw_facts.return_value = {'model': 'rp3440', 'firmware_version': 'B.11.31.1511'}
    hpux_hw.get_memory_facts = MagicMock()
    hpux

# Generated at 2022-06-11 02:38:58.257512
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list')
        },
        supports_check_mode=True)

    hw = HPUXHardware()
    hw.module = module
    hw.get_hw_facts()

    module.exit_json(msg='Hello from AnsibleModule', changed=True, ansible_facts=dict(ansible_hw=hw.populate()))



# Generated at 2022-06-11 02:39:20.268107
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.system.system import System
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.architecture import Architecture
    from ansible.module_utils.facts.virtual.virtual import Virtual

    def run_command(*args, **kwargs):
        return (0, 'foo', 'bar')

    mem_facts = {
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'memfree_mb': 0,
        'memtotal_mb': 0,
    }

    module = type('AnsibleModule', (), {'run_command': run_command})


# Generated at 2022-06-11 02:39:25.371222
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = MockAnsibleModule()
    test_hardware = HPUXHardware(module=test_module)
    test_hardware.get_hw_facts()

    # Assert
    for value in ['model', 'firmware_version']:
        assert value in test_module.params


# Generated at 2022-06-11 02:39:34.363330
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Setup facts
    import sys
    if sys.version_info[0] < 3:
        from ansible.module_utils.facts import default_collector
        default_collector.collect()
    else:
        from ansible.module_utils.facts.collector import default_collector
        default_collector.collect()

    # Test B.11.23
    if os.path.lexists('/usr/contrib/bin/machinfo'):
        hw = HPUXHardware()
        hw._module.run_command = lambda x, **kwargs: (0, '', '')
        facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

# Generated at 2022-06-11 02:39:39.655047
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {}
    # on HP-UX platform
    HPUXHardwareCollector(facts)
    # on a different platform
    facts['platform'] = 'NOT-HP-UX'
    with pytest.raises(HPUXHardwareCollector):
        HPUXHardwareCollector(facts)

# Generated at 2022-06-11 02:39:48.274335
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_module = AnsibleModule(
        argument_spec=dict()
    )
    test_HPUX_hw = HPUXHardware(module=test_module)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': "B.11.31"}
    cpu_facts = test_HPUX_hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 93xx'
    assert cpu_facts['processor_cores'] == 6
    assert cpu_facts['processor_count'] == 1



# Generated at 2022-06-11 02:39:58.259826
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    def run_command(module, cmd):
        vmstat = """pgpgin/s  ppgout/s
        0.0     0.0"""
        machinfo = """Memory:
					Total:								 2048 MB
					Free:								 1556 MB"""
        swapinfo = """    device          total:    used:   free:"""
        ansible_module = MagicMock()
        ansible_module.run_command.return_value = (0, vmstat, '')
        if "vmstat" in cmd:
            return ansible_module.run_command(cmd)
        ansible_module.run_command.return_value = (0, machinfo, '')
        if "machinfo" in cmd:
            return ansible_

# Generated at 2022-06-11 02:40:05.114122
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware()
    hw.module = FakeAnsibleModule()

# Generated at 2022-06-11 02:40:16.418654
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """Unit test for method get_memory_facts of class HPUXHardware"""
    mock_module = Mock()
    data_out_1 = '   958  2310    32      0   5806     0     0     0     0     0'
    data_out_2 = 'Physical: 653732 Kbytes'
    data_out_3 = 'Memory: 515 MB (532864 KB)'
    data_out_4 = '        total       used       free     shared    buffers     cached'
    data_out_5 = 'Mem:             20       3923          0          0          0          0'
    mem_data = {'ansible_architecture': '9000/800'}

# Generated at 2022-06-11 02:40:27.070298
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware()

    hardware.module.run_command = MagicMock()

    # set return values for mocked methods
    hardware.module.run_command.return_value = (0, 'Integrity rx2620', '')
    hardware.module.run_command.return_value = (0, 'Firmware Revision: 3.84                           ', '')
    hardware.module.run_command.return_value = (0, 'Machine Serial Number:  US123456 ', '')

    # call get_hw_facts
    hw_facts = hardware.get_hw_facts()

    # check return values
    assert hw_facts['model'] == 'Integrity rx2620'

# Generated at 2022-06-11 02:40:37.927090
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    def run_command_mock(module, cmd, *args, **kwargs):
        if cmd == 'ioscan -FkCprocessor | wc -l':
            return (0, b'8', None)
        elif cmd == '/usr/contrib/bin/machinfo | grep "Number of CPUs"':
            return (0, b'Number of CPUs = 8', None)
        elif cmd == '/usr/contrib/bin/machinfo | grep "processor family"':
            return (0, b'processor family : Intel(R) Xeon(R) CPU E5-2630 v3 @ 2.40GHz', None)
        elif cmd == "model":
            return (0, b'SuperServer', None)

# Generated at 2022-06-11 02:41:05.679430
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = type('', (object,), {
        'run_command': lambda *a, **kw: (0, '', ''),
        'get_bin_path': lambda *a, **kw: '/usr/bin/foo',
    })

    # with ia64 architecture and B.11.23
    hw = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    }
    cpu_facts = hw.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {
        'processor_count': 1,
        'processor_cores': 1,
        'processor': 'Itanium 2'
    }

    # with ia64 architecture

# Generated at 2022-06-11 02:41:09.730976
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw_facts = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_release': 'B.11.31'}
    result = hw_facts.get_memory_facts(collected_facts)

    assert result['memtotal_mb'] > 0



# Generated at 2022-06-11 02:41:14.724958
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = {}
    hw_collector = HPUXHardwareCollector(module)
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:41:23.929693
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hp_ux import HPUXHardware
    import sys
    import pytest

    return_data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }


# Generated at 2022-06-11 02:41:28.275300
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_col = HPUXHardwareCollector()
    assert hw_col._platform == 'HP-UX'
    assert hw_col._fact_class == HPUXHardware
    assert hw_col.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-11 02:41:31.351602
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware({'module_setup': True})
    assert hw.populate({'ansible_architecture': '9000/800'})['processor_count'] == 2

# Generated at 2022-06-11 02:41:41.006481
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    mock_module = MockModule()
    mock_module.run_command.side_effect = [
        (0, "9000/800\n", ""),
        (0, "RX2600\n", ""),
        (0, "7.9\n", ""),
    ]

    hw = HPUXHardware(mock_module)
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)

    assert hw_facts['firmware_version'] == '7.9'
    #assert hw_facts['product_serial'] == '7.9'

# Generated at 2022-06-11 02:41:50.440442
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    HPUXHardware - get_cpu_facts test cases
    """
    module = AnsibleModule(argument_spec={})
    hpux_hardware = HPUXHardware()

    hpux_hardware.module = module

    # Test ia64 with release B.11.23
    data = {'ansible_architecture': 'ia64'}
    cpu_facts = hpux_hardware.get_cpu_facts(data)
    assert cpu_facts['processor_count'] == 3
    assert cpu_facts['processor'] == 'Intel Itanium 2'
    assert cpu_facts['processor_cores'] == 2

    # Test ia64 with release B.11.31
    data = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.31"}


# Generated at 2022-06-11 02:42:00.399101
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    facts_dict = HPUXHardware(module).populate()
    assert facts_dict['processor_count'] == 1
    assert facts_dict['processor_cores'] == 1
    assert facts_dict['model'] == '9000/800/L2000-48'
    assert facts_dict['firmware_version'] == 'B.11.11'
    assert facts_dict['memtotal_mb'] == 2610
    assert facts_dict['memfree_mb'] == 943
    assert facts_dict['swaptotal_mb'] == 9294
    assert facts_dict['swapfree_mb'] == 9294

# Mock AnsibleModule class for testing methods of class HPUXHardware

# Generated at 2022-06-11 02:42:07.042635
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    given_facts = {'platform': 'HP-UX', 'ansible_architecture': 'ia64',
                   'ansible_distribution_version': 'B.11.23'}
    test_hw_facts = HPUXHardware._get_hw_facts(given_facts)

    expected_hw_facts = {'firmware_version': '9.11', 'product_serial': '1265501000'}
    assert test_hw_facts == expected_hw_facts

# Generated at 2022-06-11 02:42:41.705958
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hwcollector = HPUXHardwareCollector(dict({'platform': 'HP-UX'}))
    assert hwcollector.platform == 'HP-UX'
    assert hwcollector.required_facts == {'platform', 'distribution'}
    assert hwcollector._fact_class == HPUXHardware
