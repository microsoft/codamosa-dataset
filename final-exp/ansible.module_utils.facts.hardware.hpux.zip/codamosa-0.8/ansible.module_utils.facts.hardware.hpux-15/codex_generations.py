

# Generated at 2022-06-11 02:32:58.135259
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock()
    os = OSCommandMock()
    hp_ux_hw = HPUXHardware(module)
    hp_ux_hw.module = module
    hp_ux_hw.module.run_command = os.run_command

    os.rc = True
    os.out = "model"
    os.err = "error"
    hp_ux_hw.get_hw_facts()
    assert hp_ux_hw.facts['model'] == 'model'


# Generated at 2022-06-11 02:33:09.317558
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # create a temp file
    from tempfile import mkstemp
    import os
    import ansible.module_utils.facts.hardware.hpux as hpux
    options = {'ansible_facts': {'ansible_architecture': 'ia64',
                                 'ansible_distribution_version': 'B.11.31'},
               'module_name': 'test',
               'module_args': {},
               'module_executable': '/usr/bin/python'}
    # initialize HPUXHardware class
    hw = hpux.HPUXHardware(module=None, options=options)
    fake_stdout = "model 9000/844\nFirmware Revision: MPC---.03\nMachine Serial Number: PAV0104T\n"
    _, tmpfile = mkstemp()


# Generated at 2022-06-11 02:33:19.393411
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hpu_obj = HPUXHardware()

    collected_facts = {'ansible_architecture': 'ia64'}
    cpu_facts = hpu_obj.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == {'processor': 'Intel(R) Itanium(R) Processor 9100 series', 'processor_cores': 4, 'processor_count': 8}

    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hpu_obj.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2



# Generated at 2022-06-11 02:33:30.770792
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    instance = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = instance.get_cpu_facts(collected_facts)
    assert(cpu_facts['processor_count'] == 24)
    assert(cpu_facts['processor_cores'] == 4)
    assert(cpu_facts['processor'] == 'Intel(R) Itanium(R) processor 9560')
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = instance.get_cpu_facts(collected_facts)
    assert(cpu_facts['processor_count'] == 2)

# Generated at 2022-06-11 02:33:36.177491
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module=module)
    hardware.get_hw_facts()
    module.exit_json(changed=False, ansible_facts=dict(hw_facts=hw_facts))



# Generated at 2022-06-11 02:33:41.592730
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    obj = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.31'}
    hardware_facts = obj.get_hw_facts(collected_facts)
    assert hardware_facts == {'model': 'IA64 hp server rx2660',
                              'firmware_version': '3.2.1',
                              'product_serial': 'USC14102658'}

# Generated at 2022-06-11 02:33:49.429309
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Create a dummy instance of HP-UXHardware class and populate its cache
    hardware = HPUXHardware()
    hardware.populate()

    cpu_facts = hardware.get_cpu_facts()

    assert type(cpu_facts['processor_count']) == int
    assert type(cpu_facts['processor_cores']) == int
    assert type(cpu_facts['processor']) == str


# Generated at 2022-06-11 02:33:55.949136
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    hwc = HPUXHardwareCollector()
    assert issubclass(HPUXHardwareCollector, BaseFactCollector)
    assert issubclass(HPUXHardwareCollector, Collector)
    assert HPUXHardwareCollector._platform == 'HP-UX'
    assert HPUXHardwareCollector._fact_class == HPUXHardware
    assert HPUXHardwareCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:33:59.134345
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpxhw = HPUXHardwareCollector()
    assert HPUXHardwareCollector.__name__ == hpxhw.__class__.__name__
    assert HPUXHardwareCollector.__module__ == hpxhw.__class__.__module__

# Generated at 2022-06-11 02:34:11.182518
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution_version': 'B.11.11'}

    hpux = HPUXHardware(dict())
    cpu_facts = hpux.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'PA-8900 CPU'
    assert cpu_facts['processor_cores'] == 1

    collected_facts = {'ansible_architecture': '9000/785',
                       'ansible_distribution_version': 'B.11.11'}

    hpux = HPUXHardware(dict())
    cpu_facts = hpux.get_cpu_facts(collected_facts=collected_facts)

   

# Generated at 2022-06-11 02:34:31.981834
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({})
    # Test case for type of cpu
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor'] == 'Intel Itanium (Merced)'
    # Test case for type of cpu
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor'] == 'Intel Itanium (Poulson)'
    # Test case for type of cpu

# Generated at 2022-06-11 02:34:37.690112
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hw_collector = HPUXHardwareCollector()
    assert hpux_hw_collector._platform == 'HP-UX'
    assert hpux_hw_collector.required_facts == set(['platform', 'distribution'])
    assert hpux_hw_collector._fact_class == HPUXHardware


# Generated at 2022-06-11 02:34:48.306596
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw_test = HPUXHardware({})
    # Test 32-bit hardware platform
    rc, out, err = hw_test.module.run_command("echo '9000/800' | uname -p")
    # Test kernel string for HP-UX B.11.23
    rc, out, err = hw_test.module.run_command("echo 'B.11.23' | uname -r")
    rc, out, err = hw_test.module.run_command("echo 'Physical: 491520 Kbytes, Lockable: 491520 Kbytes, High Physical: 0 Kbytes, High Lockable: 0 Kbytes' | grep Physical")

# Generated at 2022-06-11 02:35:01.476445
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    sut = HPUXHardware()
    sut.module = module

    # HPUX 11.31
    module.run_command.return_value = [0, "Intel(R) Core(TM) i5-9300H CPU @ 2.40GHz", ""]
    collected_facts = {
        'ansible_architecture': "ia64",
        'ansible_distribution_version': "B.11.31",
    }

    # machinfo return cores string B.11.31 > 1204
    module.run_command.return_value = [0, "4 core", ""]

# Generated at 2022-06-11 02:35:12.231717
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpuxtest.utils import MockRunner, MockModule
    mock_runner = MockRunner()
    mock_runner.expect_commands({
        '/usr/bin/vmstat': {
            'rc': 1,
        },
    })
    mock_module = MockModule()
    hardware = HPUXHardware(mock_module)
    hardware.module = mock_module
    memory_facts = hardware.get_memory_facts()
    assert {} == memory_facts
    mock_module.run_command = mock_runner.run_command
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-11 02:35:20.557216
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    facts = {'ansible_architecture': 'ia64'}
    h = HPUXHardware(module, facts)
    hw_facts = h.get_hw_facts(facts)
    assert 'model' in hw_facts
    assert 'firmware_version' in hw_facts
    assert 'product_serial' in hw_facts



# Generated at 2022-06-11 02:35:25.273370
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """This is to test the constructor of class HPUXHardwareCollector."""
    hc = HPUXHardwareCollector()
    assert hc.required_facts == set(['platform', 'distribution'])
    assert hc._platform == 'HP-UX'

# Generated at 2022-06-11 02:35:34.413418
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    collected_facts = {'ansible_architecture': '9000/785', 'ansible_distribution_version': 'B.11.23'}
    hardware = HPUXHardware(dict(), collected_facts)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 65536
    assert hardware_facts['memfree_mb'] == 4867
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['model'] == 'HP rp8420'

# Generated at 2022-06-11 02:35:39.693734
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    fact_collector = HPUXHardwareCollector()
    assert fact_collector._fact_class == HPUXHardware
    assert fact_collector._fact_class.platform == 'HP-UX'
    assert fact_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-11 02:35:41.700014
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 02:35:52.737378
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpux_hw = HPUXHardware()
    out = hpux_hw.get_hw_facts()
    assert out is not None


# Generated at 2022-06-11 02:35:59.323422
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpux_hardware = HPUXHardware()
    hpux_hardware.module = AnsibleModule(argument_spec={})
    hpux_hardware.module.run_command = Mock(return_value=(1, 'MOCK OUT', 'MOCK ERR'))
    # Test collection of facts on HP-RISC architecture
    hpux_hardware.module.run_command = Mock(return_value=(0, '8', ''))
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 8
    # Test collection of facts on Itanium architecture

# Generated at 2022-06-11 02:36:07.427515
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    hardware = HPUXHardware({'ansible_architecture': 'ia64'})
    data = hardware.get_hw_facts({'ansible_distribution_version': 'B.11.23'})
    assert data['firmware_version'] == ''
    assert data['product_serial'] == '9989789'



# Generated at 2022-06-11 02:36:16.769728
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw_facts = dict()
    hw = HPUXHardware()
    collected_facts = dict()
    collected_facts['ansible_architecture'] = '9000/800'
    collected_facts['ansible_distribution'] = 'HP-UX'
    collected_facts['ansible_distribution_version'] = 'B.11.23'

    # Populate facts with method HPUXHardware.populate
    hw_facts = hw.populate(collected_facts=collected_facts)
    # Compare results
    assert hw_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert hw_facts['processor_cores'] == 4
    assert hw_facts['processor_count'] == 2

    # Test method HPUXHardware.get_cpu_facts


# Generated at 2022-06-11 02:36:23.719307
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_object = HPUXHardware()
    test_object.module = MagicMock()
    test_object.module.run_command.return_value = (0, " 2", "")
    collected_facts = {
        'ansible_architecture': '9000/800'
    }
    returned_facts = {
        'processor_count': 2
    }

    assert test_object.get_cpu_facts(collected_facts) == returned_facts

# Generated at 2022-06-11 02:36:29.227763
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-11 02:36:37.436203
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    '''
    Test for method get_hw_facts of class HPUXHardware
    '''
    hw = HPUXHardware()
    hw.module.run_command = MagicMock(return_value=(0, 'test_model', ''))
    hw.get_sys_distribution = MagicMock(return_value='test_distro')
    hw.get_machine_architecture = MagicMock(return_value='test_arch')
    assert hw.get_hw_facts() == {'model': 'test_model', 'firmware_version': 'test_firm', 'product_serial': 'test_serial'}

# Generated at 2022-06-11 02:36:38.559547
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    pass    # Nothing to test here

# Generated at 2022-06-11 02:36:52.056718
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Unit test for method get_cpu_facts of class HPUXHardware
    Parameterized on facts
    """


# Generated at 2022-06-11 02:37:03.885409
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = None
    # Test for HP PA-RISC
    hpux_cpu_facts = {'ansible_architecture': '9000/800'}
    assert HPUXHardware._get_cpu_facts(module, collected_facts=hpux_cpu_facts) == {
        'processor_count': int(2)
    }
    # Test for HP IA-64
    hpux_cpu_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.23"}
    assert HPUXHardware._get_cpu_facts(module, collected_facts=hpux_cpu_facts) == {
        'processor': 'Intel(R) Itanium(R)',
        'processor_count': int(1),
        'processor_cores': 2
    }




# Generated at 2022-06-11 02:37:20.470792
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    behaviour = {'mock_options': {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'},
        'mock_run_command': (0, "12 = xxxx", ""),
        'mock_run_command2': (0, "2", ""),
        'mock_run_command3': (0, "32", ""),
        'mock_run_command4': (0, "nn = yyyy", ""),
        'mock_run_command5': (0, "nnn = zzzz", ""),
        'mock_run_command6': (0, "Intel Itanium 9300", "")}
    test_fact = HPUXHardware()

# Generated at 2022-06-11 02:37:27.729243
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware_collector = HPUXHardwareCollector(module=module)
    hardware_class = HPUXHardware(module=module)
    hardware_facts = hardware_class.populate()
    print(json.dumps(hardware_facts, indent=4))


# Generated at 2022-06-11 02:37:37.916719
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_module = type('', (object,), {})()
    test_module.run_command = lambda *args, **kwargs: (0, ' ', '')
    test_module.fail_json = lambda *args, **kwargs: {'failed': True, 'msg': 'failed'}
    test_module.exit_json = lambda *args, **kwargs: {'changed': True, 'ansible_facts': {'memfree_mb': 1, 'memtotal_mb': 2, 'swaptotal_mb': 3, 'swapfree_mb': 4}}
    test_module.check_mode = False
    test_module.user = 'root'

    test_architecture = '9000/800'
    test_hardware = HPUXHardware(test_module)
    test_hardware.module.check_

# Generated at 2022-06-11 02:37:42.879021
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # set module_utils/facts/hardware/hpux.py module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # generate facts
    hw = HPUXHardware(module)
    module.exit_json(ansible_facts=hw.populate())

# Generated at 2022-06-11 02:37:55.505176
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    data = HPUXHardwareCollector.get_device_data('Linux')
    # assert False
    # assert data.platform == 'Linux'
    # assert data.device == '/dev/sda'
    # assert data.partitions == {'1': {'mount': '/boot', 'device': '/dev/sda1', 'sectors': '2031615', 'sectorsize': 512, 'start': '2048', 'size': '1000', 'fstype': 'ext4', 'end': '2031616'}, '2': {'mount': '/', 'device': '/dev/sda2', 'sectors': '19533823', 'sectorsize': 512, 'start': '2031616', 'size': '9766', 'fstype': 'ext4', 'end': '20734440'}}
    # assert data

# Generated at 2022-06-11 02:37:59.935038
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """ This is a simple test of the constructor of HPUXHardwareCollector """
    hphwc = HPUXHardwareCollector()
    assert isinstance(hphwc, HardwareCollector)
    assert hphwc.fact_class == HPUXHardware
    assert hphwc.platform == 'HP-UX'
    assert hphwc.required_facts == set(['platform', 'distribution'])
    assert hphwc.priority == 21

# Generated at 2022-06-11 02:38:13.894343
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts = HPUXHardware(dict()).get_cpu_facts(collected_facts={"ansible_architecture": 'ia64',
                                                                    "ansible_distribution_version": "B.11.23"})
    assert cpu_facts['processor'] == 'Intel(R) Itanium 2 processor 9300 series'
    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor_cores'] == 8
    cpu_facts = HPUXHardware(dict()).get_cpu_facts(collected_facts={"ansible_architecture": 'ia64',
                                                                    "ansible_distribution_version": "B.11.31"})
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) 9300 Series processor'

# Generated at 2022-06-11 02:38:17.995155
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == {'platform', 'distribution'}
    assert hardware_collector.optional_facts == set()


# Generated at 2022-06-11 02:38:19.709657
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector(None)
    assert isinstance(h, HPUXHardwareCollector)

# Generated at 2022-06-11 02:38:24.274198
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    """
    This function is to test the constructor of the class
    :return:
    """
    hg = HPUXHardwareCollector(None, "HP-UX", None)
    assert isinstance(hg, HPUXHardwareCollector)


# Generated at 2022-06-11 02:38:38.220735
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h_col = HPUXHardwareCollector()
    assert isinstance(h_col, HardwareCollector)
    assert h_col.platform == 'HP-UX'


# Generated at 2022-06-11 02:38:40.132426
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.facts == ['all']


# Generated at 2022-06-11 02:38:43.547205
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector()
    if hardware._platform == 'HP-UX':
        print(True)
    else:
        print(False)


# Generated at 2022-06-11 02:38:51.868886
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Test with a subclass of HPUXHardwareCollector used as object
    hw_collector = HPUXHardwareCollector()

    # Test class attributes
    assert HPUXHardwareCollector._fact_class == HPUXHardware
    assert HPUXHardwareCollector._platform == 'HP-UX'

    # Test instance attributes
    assert set(HPUXHardwareCollector.required_facts) == set(['platform', 'distribution'])

    # Test inherited instance attributes
    assert hw_collector.platform == 'HP-UX'
    assert hw_collector.fact_class == HPUXHardware
    assert hw_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:38:53.273087
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw is not None

# Generated at 2022-06-11 02:38:54.983795
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    m = HPUXHardware({})
    assert isinstance(m.get_memory_facts(), dict)



# Generated at 2022-06-11 02:39:03.334998
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    facts = {}
    hw = HPUXHardware(facts, {})
    hw_facts = hw.populate(facts)
    assert hw_facts.get('processor_count') == 1
    assert hw_facts.get('processor_cores') == 12
    assert hw_facts.get('memtotal_mb') >= 2048
    assert hw_facts.get('memfree_mb') <= 2048
    assert hw_facts.get('swaptotal_mb') >= 2048
    assert hw_facts.get('swapfree_mb') <= 2048
    assert hw_facts.get('model') != ''
    assert hw_facts.get('firmware_version') != ''

# Generated at 2022-06-11 02:39:15.225569
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand().run_command
    obj = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = obj.get_memory_facts(collected_facts)
    assert (memory_facts['swaptotal_mb'] == 0)
    assert (memory_facts['swapfree_mb'] == 0)
    assert (memory_facts['memtotal_mb'] == 6144)
    assert (memory_facts['memfree_mb'] == 2750)

    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = obj.get_memory_facts(collected_facts)

# Generated at 2022-06-11 02:39:23.223948
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts = dict(ansible_architecture='ia64',
                 ansible_distribution='HP-UX',
                 ansible_distribution_version='B.11.31')
    module = MockModule(facts=facts)
    hpux_hw = HPUXHardware(module)

    data = hpux_hw.get_hw_facts()
    assert data['model'] == 'ia64 hp server rx2660'
    assert data['firmware_version'].startswith('H')
    assert data['product_serial'] == 'US12345678'

# Generated at 2022-06-11 02:39:33.333988
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw_facts = HPUXHardware(dict(ansible_distribution='HP-UX', ansible_architecture='ia64', ansible_distribution_version='B.11.11'))
    data = hw_facts.get_memory_facts()
    assert data.get('memfree_mb') == 238
    assert data.get('memtotal_mb') == 955
    assert data.get('swapfree_mb') == 955
    assert data.get('swaptotal_mb') == 955
    hw_facts = HPUXHardware(dict(ansible_distribution='HP-UX', ansible_architecture='ia64', ansible_distribution_version='B.11.31'))
    data = hw_facts.get_memory_facts()

# Generated at 2022-06-11 02:40:03.105139
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'

# Generated at 2022-06-11 02:40:11.766962
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule({'use_unsafe_shell': True})
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31',
                       'platform': 'HP-UX'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] >= 1
    assert cpu_facts['processor_cores'] >= 1
    assert cpu_facts['processor'] != ''


# Generated at 2022-06-11 02:40:21.024426
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    import platform
    import ansible.module_utils
    from ansible.module_utils.facts import *
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts.plugins.hardware import HPUXHardwareCollector

    facts = {}
    facts['platform'] = platform.system()
    if facts['platform'] == 'HP-UX':
        facts['distribution'] = "B.11.31"
        facts['architecture'] = "ia64"

    fake_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        bypass_checks=True)
    collector = HPUXHardwareCollector(fake_module)

    assert collector.platform == 'HP-UX'

# Generated at 2022-06-11 02:40:24.541782
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector()
    assert hc.fact_class == HPUXHardware
    assert hc._platform == 'HP-UX'
    assert hc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:40:29.093429
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    huxhc = HPUXHardwareCollector()
    assert huxhc._fact_class == HPUXHardware
    assert huxhc._platform == 'HP-UX'
    assert huxhc.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:40:35.015234
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts = {'ansible_architecture': 'ia64',
             'ansible_distribution_version': 'B.11.23'}
    HPUXHardwareCollector(facts).get_hw_facts()

    facts = {'ansible_architecture': 'ia64',
             'ansible_distribution_version': 'B.11.31'}
    HPUXHardwareCollector(facts).get_hw_facts()


# Generated at 2022-06-11 02:40:44.843916
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_cases = [{'out': 'Xeon 2.4 Ghz', 'firmware_version': 'Version J20', 'product_serial': 'FGH858A9X5'},
                 {'out': 'Xeon 2.4 Ghz', 'firmware_version': 'Version J20', 'product_serial': None},
                 {'out': 'Itanium 2.4 Ghz', 'firmware_version': 'Version J20', 'product_serial': 'FGH858A9X5'},
                 {'out': 'Itanium 2.4 Ghz', 'firmware_version': 'Version J20', 'product_serial': None}]
    hpuxtest = HPUXHardware(dict())
    hpuxtest.module = MockModule(hpuxtest)


# Generated at 2022-06-11 02:40:55.571170
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Mocking of class HPUXHardware
    hw = HPUXHardware(module)

    # Mocking of method get_hw_facts of class HPUXHardware
    def get_hw_facts():
        # Mocked function return value
        return {'firmware_version': 'firmware', 'product_serial': 'serial'}

    # Mocking original method get_hw_facts of class HPUXHardware
    hw.get_hw_facts = get_hw_facts

    # Test
    result = hw.get_hw_facts()
    assert result == {'firmware_version': 'firmware', 'product_serial': 'serial'}



# Generated at 2022-06-11 02:41:00.473117
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'platform': 'HP-UX', 'distribution': 'HP-UX', 'distribution_version': None}
    hw = HPUXHardwareCollector(facts=facts)
    assert isinstance(hw, HardwareCollector)
    assert isinstance(hw, HPUXHardwareCollector)
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-11 02:41:09.817040
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module=module)

    # B.11.23 release
    facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX',
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23',
    }

    hardware.populate(facts)

    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Family Processor 9100 Series'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 4

    # B.11.31 release

# Generated at 2022-06-11 02:42:03.949436
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._platform == "HP-UX"

# Generated at 2022-06-11 02:42:13.798561
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    from ansible.module_utils.facts.collector import apply_defaults
    from ansible.module_utils.facts.collector import get_collector
    facts_list = [
        "ansible_architecture",
        "ansible_distribution",
        "ansible_distribution_version"
    ]
    hw = get_collector('hardware', 'HPUXHardwareCollector',
                       facts_list)
    hw_instance = apply_defaults(hw, facts_list)
    results = hw_instance.populate()
    assert 'memfree_mb' in results
    assert 'memtotal_mb' in results
    assert 'swapfree_mb' in results
    assert 'swaptotal_mb' in results
    assert 'processor' in results
    assert 'processor_cores' in results

# Generated at 2022-06-11 02:42:17.460993
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.fact_class == HPUXHardware
    assert h.platform == 'HP-UX'
    assert h.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-11 02:42:28.472732
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """Unit test for method get_memory_facts of class HPUXHardware """
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware

    class HPUXHardware_get_memory_facts_with_mock(HPUXHardware):
        """ Class HPUXHardware_get_memory_facts_with_mock extends HPUXHardware
        with a run_command method that returns a mocked response for vmstat,
        machinfo and swapinfo comands.
        """
        vmstat_command = re.compile(r"/usr/bin/vmstat .*")
        machinfo_command = re.compile(r"/usr/contrib/bin/machinfo .*")
        swapinfo_command = re.compile(r"/usr/sbin/swapinfo .*")


# Generated at 2022-06-11 02:42:38.081588
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mem_size = 200
    pagesize = 4096
    free_pages = 400
    free_mem = (free_pages * pagesize) // 1024 // 1024
    module_args = {}
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    mock_collector = MagicMock(platform='HP-UX')
    mock_collector.get_platform = MagicMock(return_value='HP-UX')
    mock_collector.get_filesystems = MagicMock(return_value=[])
    mock_collector.get_all_block_devices = MagicMock(return_value=[])
    mock_collector.get_interfaces = MagicMock(return_value=[])
