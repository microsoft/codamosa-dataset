

# Generated at 2022-06-11 02:33:05.184710
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hpux = HPUXHardware()
    hpux.module = module
    collected_facts = {}
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    hpux.populate(collected_facts)
    hpux.get_memory_facts(collected_facts)

    assert hpux.facts['memtotal_mb'] != None
    assert hpux.facts['swapfree_mb'] != None


# Generated at 2022-06-11 02:33:16.032673
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    import ansible.module_utils.facts.hardware.hp_ux
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.facts.hardware.hp_ux
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.facts.hardware.hp_ux
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.facts.hardware.hp_ux
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.facts.hardware.hp_ux
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.facts.hardware.hp_ux
    from ansible.module_utils.facts import FactCollector
   

# Generated at 2022-06-11 02:33:18.634587
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw.platform == 'HP-UX'
    assert hw.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:33:26.576426
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Arrange
    hpux_hw = HPUXHardware()
    hpux_hw.module = MockModule()
    hpux_hw.module.run_command.side_effect = [('0', '', ''),
                                              ('0', 'p6700sx', ''),
                                              ('0', 'Firmware Revision = B.11.31.1810', ''),
                                              ('0', 'Machine Serial Number = SGH132SK41P', '')]

    # Act
    hw_facts = hpux_hw.get_hw_facts()

    # Assert
    assert hw_facts.get('model') == 'p6700sx'
    assert hw_facts.get('firmware_version') == 'B.11.31.1810'

# Generated at 2022-06-11 02:33:39.896259
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = MockModule()
    harware = HPUXHardware(module)
    module.run_command.side_effect = [
        (0, "978", ""),
        (0, "1280", ""),
        (0, "total:  7235796", ""),
        (0, "fs:     7235796", ""),
    ]
    memory_facts = harware.get_memory_facts()
    assert memory_facts['swaptotal_mb'] == 7235796 / 1024
    assert memory_facts['swapfree_mb'] == 7235796 / 1024
    assert memory_facts['memfree_mb'] == 978 * 4096 / 1024 / 1024
    assert memory_facts['memtotal_mb'] == 1280 * 4096 / 1024 / 1024



# Generated at 2022-06-11 02:33:50.200025
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    # Mock module
    class MockModule():
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
            self.get_bin_path = lambda x: 'bin'

    # Collected facts
    collected_facts = {'platform': 'HP-UX',
                       'architecture': 'ia64',
                       'distribution': 'HP-UX',
                       'distribution_version': 'B.11.31'}

    # Populate instance of HPUXHardware
    hw = HPUXHardware(MockModule())
    hardware_facts = hw.populate(collected_facts=collected_facts)

    # Check method populate return a dict with the key processor_count
    assert 'processor_count' in hardware_facts

    # Check method populate return a dict with the key processor

# Generated at 2022-06-11 02:34:00.694229
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    h = HPUXHardware()
    h.module = FakeAnsibleModule()
    h.module.run_command = FakeRunCommand()
    h.module.run_command.results[0] = "/usr/bin/vmstat | tail -1", "0 0 0 0 0 11256 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0", "", 0
    h.module.run_command.results[1] = "grep Physical /var/adm/syslog/syslog.log", "", "", 1
    h.module.run_command.results[2] = "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'", "0xffffff000",

# Generated at 2022-06-11 02:34:05.655431
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    result = HPUXHardwareCollector()
    assert result
    assert isinstance(result, HardwareCollector)
    assert result._platform == 'HP-UX'
    assert result.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:34:09.480604
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = HPUXHardware().populate()
    module.exit_json(changed=False, ansible_facts=hardware_facts)


# Generated at 2022-06-11 02:34:14.693937
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = dict(
        distribution='HP-UX',
        platform='HP-UX',
        some_fact='fact_value'
    )
    hw = HPUXHardwareCollector(facts=facts, module=None)
    assert hw.facts == facts
    assert hw.module == None
    assert hw.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:34:27.293046
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = HPUXHardwareCollector()
    assert module is not None

# Generated at 2022-06-11 02:34:40.193237
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    p = HPUXHardwareCollector()
    ansible_facts = {
        'system_vendor': {
            'manufacturer': 'Hewlett-Packard',
            'product': 'HP Integrity rx2660'
        },
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_major_version': '11',
        'ansible_distribution_version': 'B.11.23',
        'ansible_architecture': 'ia64'
    }
    h = p.collect(ansible_facts, None)
    h.populate()
    assert h.platform == 'HP-UX'
    assert h.memfree_mb
    assert h.memtotal_mb
    assert h.swapfree_mb
    assert h.swaptotal_mb

# Generated at 2022-06-11 02:34:45.971260
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    TestFacts = get_fixtures('get_hw_facts')
    module = get_module(TestFacts['input'])
    facts = HPUXHardware(module).get_hw_facts(collected_facts=TestFacts['get_hw_facts']['collected_facts'])
    assert facts == TestFacts['get_hw_facts']['expected']


# Generated at 2022-06-11 02:34:58.629014
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_ansible_module = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.23'
    )
    test_result = dict(
        processor_count=3,
        processor='Intel(R) Itanium(R) Processor 9300 Series',
        processor_cores=32,
        memtotal_mb=11264,
        memfree_mb=5380,
        swaptotal_mb=160,
        swapfree_mb=116,
        model='ia64 hp server rx6600',
        firmware_version='v2.70',
        product_serial='US1234ABCD'
    )

# Generated at 2022-06-11 02:35:02.548137
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()

    assert(hw_collector.platform == 'HP-UX')
    assert(hw_collector.required_facts == set(['platform', 'distribution']))



# Generated at 2022-06-11 02:35:09.622014
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    for line in ['/dev/vg00/lvol2          917500     439500     470000      53%    /',
                 '/dev/vg00/lvol3          917500     439500     470000      53%    /var',
                 '/dev/vg00/lvol4          917500     439500     470000      53%    /opt',
                 '/dev/vg00/lvol5          917500     439500     470000      53%    /tmp']:
        hardware.module.run_command.return_value = (0, '%s\n' % line, '')

# Generated at 2022-06-11 02:35:14.707020
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h.platform == 'HP-UX'
    assert h.fact_class == HPUXHardware
    assert h.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-11 02:35:27.906531
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Return facts HP-UX CPU related facts

    Return CPU related facts from differents version of HP-UX.
    """
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    h = HPUXHardware({})

    def hw_get_cpu_facts(ansible_architecture, ansible_distribution_version):
        return h.get_cpu_facts({'ansible_architecture': ansible_architecture,
                                'ansible_distribution_version': ansible_distribution_version})

    def get_cpu_facts_B1131(ansible_architecture):
        return hw_get_cpu_facts(ansible_architecture, 'B.11.31')


# Generated at 2022-06-11 02:35:39.485484
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    collected_facts = {}
    collected_facts['ansible_facts'] = {'ansible_architecture': 'ia64'}
    hardware.module = MagicMock()
    hardware.module.run_command.side_effect = [collected_facts['ansible_facts']['ansible_architecture'], 0,
                                               'my model', 0, '', '', 0, 'Firmware revision = v1.0', 0, 'Machine serial number = 1234567890', 0]
    hw_facts = hardware.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'POWER9'
    assert hw_facts['firmware_version'] == 'v1.0'

# Generated at 2022-06-11 02:35:45.453894
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800'}

    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2

    collected_facts = {'ansible_architecture': 'ia64'}

    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Itanium 2'


# Generated at 2022-06-11 02:36:25.279423
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    """Test HPUXHardware.get_memory_facts()
    """
    # Initializing a subsclass instance of HPUXHardware to perform unit tests on
    class testHPUXHardware(HPUXHardware):
        def __init__(self, module):
            self.module = module

    # Initializing a test for the method get_memory_facts of class HPUXHardware
    def test_get_memory_facts(testHardware):
        testHPUXHardwareObj = testHPUXHardware(testHPUXHardware)
        testHardware.assertEqual(type(testHPUXHardwareObj.get_memory_facts()), type({}))

    testHardware = unittest.TestCase()
    test_get_memory_facts(testHardware)



# Generated at 2022-06-11 02:36:32.649478
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HPUXHardware_instance = HPUXHardware(None, {'ansible_architecture': 'ia64', 'ansible_distribution_version': "B.11.34"})
    assert HPUXHardware_instance.get_hw_facts() == \
        {'model': 'HP-UX ia64',
         'product_serial': '123456',
         'firmware_version': 'C.11.23'}


# Generated at 2022-06-11 02:36:40.505807
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware()
    hw.module = FakeAnsibleModule()

    # For PA-RISC architecture, fact processor_count is the number of lines returned by ioscan command
    hw.module.run_command('ioscan -FkCprocessor', check_rc=True)
    hw.module.run_command_environ_update.return_value = (0, "3", None)

    # For IA-64 architecture, fact processor_count is the number of cpu found in /usr/contrib/bin/machinfo
    hw.module.run_command('/usr/contrib/bin/machinfo | grep "Number of CPUs"', check_rc=True)
    hw.module.run_command_environ_update.return_value = (0, "Number of CPUs = 2", None)

# Generated at 2022-06-11 02:36:53.361154
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpux_hw = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64'}
    hpux_hw.module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        check_invalid_arguments=False,
        bypass_checks=True
    )
    hpux_hw.module.run_command = Mock()
    hpux_hw.module.run_command.return_value = (0, '2', '')
    hpux_hw.populate(collected_facts)
    # processor
    hpux_hw.module.run_command.assert_any_call("/usr/contrib/bin/machinfo | grep Intel |cut -d' ' -f4-", use_unsafe_shell=True)
    # processor

# Generated at 2022-06-11 02:36:57.185370
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_facts = HPUXHardware(dict(ansible_architecture='9000/800', ansible_distribution_version='B.11.23'))
    assert hardware_facts.get_cpu_facts() == {'processor_count': 1}

# Generated at 2022-06-11 02:37:00.401100
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = MockModule()
    facts = HPUXHardware(module).populate()
    assert facts['processor_count'] > 0


# Generated at 2022-06-11 02:37:07.857170
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeModule({'ansible_architecture': '9000/800'})
    harware = HPUXHardware(module)
    fact = {'ansible_architecture': '9000/800'}
    cpu_facts = harware.get_cpu_facts(collected_facts=fact)
    assert cpu_facts['processor_count'] == 2
    fact = {'ansible_architecture': 'ia64'}
    cpu_facts = harware.get_cpu_facts(collected_facts=fact)
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'
    assert cpu_facts['ansible_processor_cores'] == 1

# Generated at 2022-06-11 02:37:18.602974
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    instance = HPUXHardware()
    collected_facts = {
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }

    result = instance.populate(collected_facts)
    assert result['processor_count'] == int(os.environ['HPUX_TEST_PROCESSOR_COUNT'])
    collected_facts = {
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.23'
    }

    result = instance.populate(collected_facts)
    assert result['processor_count'] == int(os.environ['HPUX_TEST_PROCESSOR_COUNT'])



# Generated at 2022-06-11 02:37:22.885137
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw = HPUXHardwareCollector()
    assert hw._fact_class == HPUXHardware
    assert hw._platform == 'HP-UX'
    assert set(hw.required_facts) == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:37:27.727361
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    assert HPUXHardware(None, None).get_memory_facts() == {'memtotal_mb': 512, 'memfree_mb': 2, 'swaptotal_mb': 10, 'swapfree_mb': 5}



# Generated at 2022-06-11 02:38:40.633896
# Unit test for method get_memory_facts of class HPUXHardware

# Generated at 2022-06-11 02:38:48.104618
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    conf_file = 'unittests/fixtures/ansible_facts.d/hw/hw.fact'
    hw_facts = HPUXHardware(conf_file).get_hw_facts()
    assert hw_facts['model'] == 'ia64 hp server rx7620'
    assert hw_facts['firmware_version'] == 'v1.09'
    assert hw_facts['product_serial'] == 'US096A9LZP'


# Generated at 2022-06-11 02:38:58.226810
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    # Create an instance of HPUXHardware
    h = HPUXHardware(module=None)

    # Create a mock set of collected_facts

# Generated at 2022-06-11 02:39:03.522715
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = HPUXHardware({})
    collected_facts = {'ansible_distribution_version': 'B.11.23', 'ansible_architecture': 'ia64', 'platform': 'HP-UX'}
    hw_facts = module.get_hw_facts(collected_facts)
    assert hw_facts['firmware_version'] == 'HPD8'
    assert hw_facts['product_serial'] == 'SECS7L1S'

# Generated at 2022-06-11 02:39:11.208864
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    collected_facts = dict(
        platform='HP-UX',
        ansible_architecture='ia64')

    hw = HPUXHardware(dict(module=None))
    hw_facts = hw.get_hw_facts(collected_facts=collected_facts)

    assert hw_facts['model'] == 'ia64'
    assert hw_facts['firmware_version']
    assert hw_facts['product_serial']

# Generated at 2022-06-11 02:39:19.487624
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '12', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/dmesg')
    hardware = HPUXHardware(module=module)
    hardware.module.run_command = MagicMock(return_value=(1, '', ''))
    hardware.module.get_bin_path = MagicMock(return_value='/usr/contrib/bin/machinfo')
    hardware.module.run_command = MagicMock(return_value=(0, '', ''))
    hardware.module.get_bin_path = MagicMock(return_value='grep')
    hardware_facts = hardware.populate()
    assert hardware

# Generated at 2022-06-11 02:39:28.715523
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    """
    Dummy method to test
    :return:
    """
    input_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    module = type('', (), {})()
    module.run_command = run_command_fix
    hw = HPUXHardware(module)
    result = hw.get_hw_facts(collected_facts=input_facts)
    assert result['firmware_version'] == 'v2.47 (IE) '



# Generated at 2022-06-11 02:39:32.257899
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:39:42.792202
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HPUXHardwareCollector(module=module)

    hardware_collector.populate()


# Generated at 2022-06-11 02:39:49.502890
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """ Test for HPUXHardware.get_cpu_facts """
    collected_facts = {"ansible_architecture":"9000/800" }

    hardware = HPUXHardware(module=None, collected_facts=collected_facts)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == 'HP PA-RISC'


# Generated at 2022-06-11 02:42:05.219885
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_fact = HPUXHardware(dict())
    data_dict = dict(ansible_architecture="ia64", ansible_distribution_version="B.11.23")
    hw_fact.populate({'ansible_facts': data_dict})
    assert hw_fact.get_hw_facts(collected_facts={'ansible_facts': data_dict}) == dict(model='hp rx8640', firmware_version='B.11.23.0709.1102', product_serial='PM511BX32G')

    hw_fact = HPUXHardware(dict())
    data_dict = dict(ansible_architecture="ia64", ansible_distribution_version="B.11.31")
    hw_fact.populate({'ansible_facts': data_dict})


# Generated at 2022-06-11 02:42:14.560827
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware()
    rc, out, err = hw.module.run_command("model")
    data = out.strip()
    rc, out, err = hw.module.run_command("/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC", use_unsafe_shell=True)
    data_firmware = out.split(':')[1].strip()
    rc, out, err = hw.module.run_command("/usr/contrib/bin/machinfo |grep -i 'Machine serial number' ", use_unsafe_shell=True)
    data_serial = out.split(':')[1].strip()

# Generated at 2022-06-11 02:42:24.751275
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Check that get_cpu_facts method return correct facts
    """
    facts = HPUXHardware().get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})

    assert facts['processor'] == 'PA-RISC 2.0'
    assert facts['processor_cores'] == 1
    assert facts['processor_count'] == 1

    facts = HPUXHardware().get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})

    assert facts['processor'] == 'Intel Itanium 2'
    assert facts['processor_cores'] == 1
    assert facts['processor_count'] == 1


# Generated at 2022-06-11 02:42:35.635538
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware_hpux = HPUXHardware({})
    rc, out, err = hardware_hpux.module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'", use_unsafe_shell=True)
    memory_facts = {'ansible_architecture': '9000/800'}
    if not err:
        data = out
    # If any error occurs with adb, return 0
    if err:
        data = '0'
    memory_facts['ansible_memtotal_mb'] = int(data) / 256
    assert hardware_hpux.get_memory_facts(memory_facts)['memtotal_mb'] == memory_facts['ansible_memtotal_mb']




# Generated at 2022-06-11 02:42:43.760735
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Create and initialize the HP-UX hardware object
    hw_obj = HPUXHardware()

    # Create a context manager to mock the content of '/var/adm/syslog/syslog.log'
    with open('test/test_HPUXHardware/mem_phys_adm_log', 'w') as f:
        f.write("""Sep  3 12:30:15 dev-db1 vmunix: Physical: 59392 Kbytes""")

    # Create a context manager to mock the content of '/dev/kmem'
    with open('test/test_HPUXHardware/mem_phys_kmem', 'w') as f:
        f.write("""phys_mem_pages/D: 570814""")

    # Create a context manager to mock the content of '/var/adm/syslog/syslog.log