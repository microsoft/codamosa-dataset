

# Generated at 2022-06-11 02:32:54.358740
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert type(h) is HPUXHardwareCollector
    assert h.platform == 'HP-UX'

# Generated at 2022-06-11 02:33:06.280793
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts import Ticket374
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector

    def mock_run_command(self, cmd, use_unsafe_shell=False):
        if cmd == "model":
            return 0, 'ia64 hp server rx2660', ''
        elif cmd == "/usr/contrib/bin/machinfo |grep -i 'Firmware revision' | grep -v BMC":
            return 0, 'Firmware revision: v2.1', ''

# Generated at 2022-06-11 02:33:12.915473
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_data = {"ansible_architecture": "ia64",
                 "ansible_distribution": "HP-UX",
                 "ansible_distribution_version": "B.11.31"}
    hw = HPUXHardware(None, test_data)
    hw_facts = hw.get_hw_facts()
    assert "model" in hw_facts
    assert "firmware_version" in hw_facts


# Generated at 2022-06-11 02:33:23.025734
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():

    # Testing with swapper space
    h_facts = HPUXHardwareCollector()
    h_facts.module = MagicMock()
    h_facts.module.run_command.return_value = (0, "", "")
    h_facts.module.run_command.side_effect = [(0, "", ""), (0, "", ""), (0, "    256", ""), (0, "dev      17954592         0  17954592         0   100%    /var/adm/swap", ""), (0, "dev      17954592         0  17954592         0   100%    /var/adm/swap", "")]
    h_facts.collected_facts = dict(ansible_architecture='ia64')

# Generated at 2022-06-11 02:33:27.235162
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = { 'platform': 'HP-UX', 'distribution': 'B.11.31' }
    hpux_hw = HPUXHardwareCollector()
    instance = hpux_hw.collect(facts, None)
    assert(instance is not None)


# Generated at 2022-06-11 02:33:35.215056
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    ansible_facts = dict(ansible_distribution_version='B.11.31')
    hpux_hw = HPUXHardware(module=dict())
    hpux_hw.populate()
    assert hpux_hw.get_hw_facts(collected_facts=ansible_facts) == dict(model='ia64', firmware_version='v1.2.3')


# Generated at 2022-06-11 02:33:46.625979
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = type('', (object,), dict(run_command=lambda x, unsafe=True: ["0", "model B.11.23 U ia64", "", ""]))()
    result = HPUXHardware(module).get_hw_facts()
    assert result == {"model": "B.11.23 U ia64",
                      "firmware_version": "HPRC C.1.1",
                      "product_serial": "REDACTED"}

    module = type('', (object,), dict(run_command=lambda x, unsafe=True: ["0", "model B.11.31 U ia64", "", ""]))()
    result = HPUXHardware(module).get_hw_facts()

# Generated at 2022-06-11 02:33:53.507793
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    host_name = 'test_host'
    module = AnsibleModule(argument_spec=dict())
    hardware = HPUXHardware(module)

    # Testing HPUXHardware with ansible_architecture 9000/800
    hardware.module.run_command = Mock(return_value=(0, '409600', ''))
    hardware.module.run_command = Mock(return_value=(0, ' 4194304', ''))
    hardware.module.run_command = Mock(return_value=(0, '', ''))
    hardware.module.run_command = Mock(return_value=(0, '4194304', ''))
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX'}

# Generated at 2022-06-11 02:34:02.735616
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class _module(object):
        def run_command(self, command, use_unsafe_shell=False):
            if command == 'ioscan -FkCprocessor | wc -l':
                return 0, '2', None
            elif command == '/usr/contrib/bin/machinfo | grep \'Number of CPUs\'':
                return 0, 'Number of CPUs = 2', None
            elif command == '/usr/contrib/bin/machinfo | grep \'processor family\'':
                return 0, 'processor family = Intel(R) Xeon(R) CPU E5-2640 v2 @ 2.00GHz', None
            elif command == '/usr/contrib/bin/machinfo | grep \'Number of CPUs\' | grep -v grep':
                return 0, 'Number of CPUs = 2', None

# Generated at 2022-06-11 02:34:08.441600
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(" ",{"platform":"HP-UX"})

    collected_facts = {
        'ansible_distribution_version': 'B.11.23',
        'ansible_architecture': 'ia64'
    }
    hardware.get_cpu_facts(collected_facts)


# Generated at 2022-06-11 02:34:26.639393
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # Unit test for method get_memory_facts of class HPUXHardware
    class module:
        def run_command(self, cmd):
            if cmd == "/usr/bin/vmstat | tail -1":
                return 0, "  425   896    896  1655   617 424068", ""
            if cmd == "grep Physical /var/adm/syslog/syslog.log":
                return 0, "Dic 22 13:59:01 xxxxxx syslogd: Physical: 2088680 Kbytes", ""
            if cmd == "echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'":
                return 0, "1000000", ""

# Generated at 2022-06-11 02:34:39.588942
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    test_HPUXhardware = HPUXHardware()

    # get_memory_facts without parameter
    result_get_memory_facts_without_parameter = test_HPUXhardware.get_memory_facts()
    expected_result_get_memory_facts_without_parameter = {'memfree_mb': 3068, 'memtotal_mb': 3236, 'swapfree_mb': 2040, 'swaptotal_mb': 2040}

    # Test the result of method get_memory_facts without parameter
    assert result_get_memory_facts_without_parameter == expected_result_get_memory_facts_without_parameter

    # get_memory_facts with parameter

# Generated at 2022-06-11 02:34:43.813242
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.fact_class._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:34:55.591960
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():

    class HPUXHardwareModule(object):
        def __init__(self, module):
            self.module = module

        def run_command(self, cmd, use_unsafe_shell):
            test_dir = os.path.dirname(__file__)
            tests_dir = os.path.dirname(test_dir)
            fixtures_dir = os.path.join(tests_dir, 'fixtures')
            if cmd == "ioscan -FkCprocessor | wc -l":
                out = open(os.path.join(fixtures_dir, "hpux_resource_mgr_output.txt")).read()
                err = ""
                rc = 0

# Generated at 2022-06-11 02:35:06.242212
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    This unittest test the HPUXHardware.populate method
    """
    # Create a new HPUXHardware object
    hardware = HPUXHardware(dict())

    # Unit test with good required facts platform = HP-UX and distribution = B.11.31
    collected_facts = {'platform': 'HP-UX', 'distribution': 'B.11.31', 'architecture': 'ia64'}
    hardware_info = hardware.populate(collected_facts)
    assert hardware_info['processor'] == 'Intel(R) Itanium(R) Processor 9260'
    assert hardware_info['processor_cores'] == 14
    assert hardware_info['processor_count'] == 4
    assert hardware_info['memtotal_mb'] == 398220
    assert hardware_info['memfree_mb'] == 2248


# Generated at 2022-06-11 02:35:20.786879
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Declare an object of class HPUXHardware
    hpxhw = HPUXHardware
    hpxhw.module = None

    # Declare a dictionary to pass to get_cpu facts method
    collected_facts = {'ansible_system_vendor': 'HP-UX',
                       'ansible_architecture': 'ia64',
                       'ansible_distribution_version': "B.11.23",
                       'ansible_distribution': 'HP-UX'}

    # Call the get_cpu_facts method of class HPUXHardware
    hw_facts = hpxhw.get_hw_facts(collected_facts)

    # Declare the expected result

# Generated at 2022-06-11 02:35:32.479332
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    register_collector(HPUXHardwareCollector)
    ansible_facts = dict(ansible_architecture='ia64',
                         ansible_distribution='HPUX',
                         ansible_distribution_version='B.11.23')
    collected_facts = dict(ansible_architecture='ia64',
                           ansible_distribution='HPUX',
                           ansible_distribution_version='B.11.23')
    pending_facts = {}
    hpux_hw_facts = HPUXHardware(pending_facts, ansible_facts, collected_facts)
    hw_facts = hpux_hw_facts.populate()


# Generated at 2022-06-11 02:35:41.641259
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """ Test method get_cpu_facts of class HPUXHardware """
    hpux_hardware = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/800',
                       'ansible_distribution_version': 'B.11.31'}
    cpu_facts = hpux_hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9100 series'
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 128


# Generated at 2022-06-11 02:35:49.371249
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = type('', (), {})()
    test_module.run_command = lambda *_: (0, 'B180', '')
    test_module.get_bin_path = lambda _: ''

    collected_facts = {
        'platform': 'HP-UX',
        'ansible_architecture': 'ia64',
    }

    test_obj = HPUXHardware(module=test_module)
    hw_facts = test_obj.get_hw_facts(collected_facts)
    assert hw_facts['model'] == 'B180'


# Generated at 2022-06-11 02:36:01.974763
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock()

    model = "IA64 hp rx6600"
    out = ""
    err = ""
    rc = 0
    hardware.module.run_command.return_value = rc, out, err
    hardware.get_hw_facts()
    assert hardware.module.run_command.call_count == 2
    args, kwargs = hardware.module.run_command.call_args
    assert args[0] == "model"

    out = "Firmware revision      =    B.11.31.0600"
    err = ""
    rc = 0
    hardware.module.run_command.return_value = rc, out, err
    hardware.get_hw_facts()
    assert hardware

# Generated at 2022-06-11 02:36:23.219391
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_data = "ioscan -FkCprocessor | wc -l"
    test_answer = "8"

    # Create test object HPUXHardware
    test_HPUXHardware_obj = HPUXHardware({'ansible_architecture': 'ia64'})
    test_HPUXHardware_obj.module.run_command = lambda a: (0, test_answer, "")

    test_HPUXHardware_obj.get_cpu_facts({'ansible_architecture': 'ia64'})
    result = test_HPUXHardware_obj.processor_count
    assert result == 8


# Generated at 2022-06-11 02:36:33.713920
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    facts = {'platform': 'HP-UX', 'distribution': 'HP-UX'}
    module = type('Module', (), {})
    module.run_command = lambda x, y=None, z=None: ""
    module.exit_json = lambda: ""
    module.fail_json = lambda x: ""
    module.params = {}
    res = HPUXHardware(module, facts).get_memory_facts()
    assert 'memtotal_mb' in res
    assert 'memfree_mb' in res
    assert 'swaptotal_mb' in res
    assert 'swapfree_mb' in res



# Generated at 2022-06-11 02:36:47.691177
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class FakeModuleUtilArgs:
        def __init__(self):
            self.params = {'architecture': 'ia64'}
            self.module_name = ''

    class FakeModule:
        def __init__(self):
            self.check_mode = False
            self.debug = False
            self.fail_json = False
            self.run_command = None
            self.no_log = False
            self.log = lambda x: False
            self.fail_json = False
            self.params = {'architecture': 'ia64'}
            self.argument_spec = {'architecture': {}}
            self.supports_check_mode = False
            self._socket_path = ''

    hardware = HPUXHardware(FakeModuleUtilArgs())
    hardware.module = FakeModule()



# Generated at 2022-06-11 02:36:57.922479
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hpx = HPUXHardware()
    hpx.module = MagicMock()
    hpx.module.run_command = MagicMock(return_value=[0, "", ""])
    hpx.module.run_command.side_effect = [(0, "", ""), (0, "I64", ""), (0, "1", ""), (0, "", ""), (0, "", ""), ]
    cpu_facts = {"processor_count": 1, "processor_cores": 1, "processor": 'I64'}
    assert cpu_facts == hpx.get_cpu_facts()

# Generated at 2022-06-11 02:37:04.893562
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Initialize HPUXHardwareCollector
    h = HPUXHardwareCollector()

    # Check it's instance of HardwareCollector class
    assert isinstance(h, HardwareCollector)

    # Check the value of _fact_class
    assert h._fact_class == HPUXHardware

    # Check the value of _platform
    assert h._platform == 'HP-UX'

    # Check the value of required_facts
    assert h.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-11 02:37:06.324224
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # This method should return a dict
    assert isinstance(HPUXHardware(None).populate(), dict)



# Generated at 2022-06-11 02:37:09.398268
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Constructor HPUXHardwareCollector should return a object of class HardwareCollector
    result = HPUXHardwareCollector()
    assert(isinstance(result, HardwareCollector))


# Generated at 2022-06-11 02:37:19.674526
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    required_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_major_version': '11', 'ansible_distribution_version': 'B.11.31'}

    class TestModule(object):
        def run_command(self, command, use_unsafe_shell=False):
            if command == "ioscan -FkCprocessor | wc -l":
                return (0, "8", None)
            elif command == "/usr/contrib/bin/machinfo | grep 'Number of CPUs'":
                return (0, "Number of CPUs = 8", None)

# Generated at 2022-06-11 02:37:32.983868
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    collected_facts = {
        'architecture': '9000/800',
        'distribution': 'HP-UX',
        'distribution_release': 'B.11.31',
        'distribution_version': 'B.11.31'
    }
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 16
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9340'
    assert cpu_facts['processor_cores'] == 16

# Generated at 2022-06-11 02:37:43.806732
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, '100', ''))

    hw = HPUXHardware(module=module)
    collected_facts = {'ansible_architecture': '9000/800'}
    memory_facts = hw.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 39
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0

    module.run_command = Mock(return_value=(0, '100', ''))
    collected_facts = {'ansible_architecture': 'ia64'}
    memory_facts = hw.get_memory_facts(collected_facts=collected_facts)


# Generated at 2022-06-11 02:38:15.382258
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    mock_module = MockModule({'ansible_architecture': '9000/800'})
    hardware_helper = HPUXHardware(mock_module)
    hardware_helper._module.run_command = Mock(return_value=(0, '16', ''))
    cpu_facts = hardware_helper.get_cpu_facts()
    assert cpu_facts['processor_count'] == 16
    assert cpu_facts['processor_cores'] == 16


# Generated at 2022-06-11 02:38:16.779512
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    if __name__ == "__main__":
        HPUXHardwareCollector()

# Generated at 2022-06-11 02:38:19.464360
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhardware_collector = HPUXHardwareCollector(None)
    assert hhardware_collector._platform == 'HP-UX'

# Generated at 2022-06-11 02:38:30.497528
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    module.params = {'gather_subset': 'all'}
    module.run_command = Mock(return_value=(0, '', ''))
    module.file_exists = Mock(return_value=True)
    module.get_bin_path = Mock(return_value='/bin/foo3')

    # Test with ansible_architecture = 9000/800 or 9000/785

# Generated at 2022-06-11 02:38:38.706510
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module = AnsibleModuleMock()
    hardware.module.run_command.return_value = (0, '\n','',0)
    if hardware.get_memory_facts() == {'memfree_mb': 84, 'memtotal_mb': 318, 'swapfree_mb': 0, 'swaptotal_mb': 0}:
        return 0
    else:
        return 1


# Generated at 2022-06-11 02:38:43.954201
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()

    collecter = HPUXHardwareCollector(module)
    hardware = collecter.collect()

    # Test the method
    hardware.get_hw_facts()

    assert hardware.facts['model'] == 'ia64 hp server rx6600'
    assert hardware.facts['firmware_version'] == '01000a'
    assert hardware.facts['product_serial'] == 'ABCD'



# Generated at 2022-06-11 02:38:49.238302
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mem_dict = HPUXHardware.get_memory_facts(HPUXHardware, {})
    assert isinstance(mem_dict, dict)
    assert 'memfree_mb' in mem_dict
    assert 'memtotal_mb' in mem_dict
    assert 'swapfree_mb' in mem_dict
    assert 'swaptotal_mb' in mem_dict


# Generated at 2022-06-11 02:38:50.503509
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hc = HPUXHardwareCollector()
    hc.populate()

# Generated at 2022-06-11 02:38:57.227574
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all', '!min'], type='list')
    })
    kernel_version = platform.release()
    os_version = platform.linux_distribution()[1]
    obj = HPUXHardwareCollector(module=module)
    assert obj.platform == 'HP-UX'
    assert obj.kernel_version == kernel_version
    assert obj.os_version == os_version

# Generated at 2022-06-11 02:39:05.112022
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hw = HPUXHardware(module)
    # Make the test on PA RISC
    def test_memory_facts(collected_facts):
        assert hw.get_memory_facts(collected_facts).get('memtotal_mb') is not None
        assert hw.get_memory_facts(collected_facts).get('memfree_mb') is not None
        assert hw.get_memory_facts(collected_facts).get('swapfree_mb') is not None
        assert hw.get_memory_facts(collected_facts).get('swaptotal_mb') is not None

    collected_facts = dict(ansible_architecture='9000/800', ansible_distribution='HP-UX', ansible_distribution_version='B.11.23')

# Generated at 2022-06-11 02:39:52.214797
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._platform == 'HP-UX'

# Generated at 2022-06-11 02:40:00.280764
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, '', '')
    hpux = HPUXHardware(mock_module)

    mock_module.run_command.return_value = (0, '1', '')
    mock_module.params = {'gather_subset': ['all']}
    facts = hpux.populate()
    assert facts['processor_count'] == 1

    mock_module.run_command.return_value = (0, '', 'erro')
    mock_module.params = {'gather_subset': ['all']}
    facts = hpux.populate()
    assert facts['processor_count'] == -1

# Generated at 2022-06-11 02:40:07.980078
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = None
    hardware = HPUXHardware(module, 'https://localhost')
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    result = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert result == {'processor': 'Intel(R) Itanium(R) Processor T9700', 'processor_cores': 8, 'processor_count': 2}


# Generated at 2022-06-11 02:40:16.709260
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule({})

    facts_dict = {'ansible_architecture': 'ia64'}
    test_class = HPUXHardware(module)

    rc, out, err = module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'",
                                      use_unsafe_shell=True)
    module.exit_json(changed=False, ansible_facts={'ansible_memtotal_mb': int(out.strip()) / 256})


# Generated at 2022-06-11 02:40:20.794318
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()
    assert hhc.platform == 'HP-UX'
    assert hhc._fact_class == HPUXHardware
    assert hhc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:40:23.404264
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HardwareCollector.collector_registry = {}
    assert isinstance(HPUXHardwareCollector.collector_registry['HP-UX'], HPUXHardwareCollector)

# Generated at 2022-06-11 02:40:32.140943
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # Setup
    collected_facts = {'platform': 'HP-UX',
                       'distribution': 'HP-UX'}

    hw_facts = {'model': 'HP9000/800',
                'firmware_version': '3.3',
                'product_serial': ''}

    test_HPUXHardware = HPUXHardware()
    test_HPUXHardware.module = MockAnsibleModule()

    # Test: run without exception
    hw_facts_returned = test_HPUXHardware.get_hw_facts()

    # Check
    assert hw_facts == hw_facts_returned



# Generated at 2022-06-11 02:40:35.630486
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():

    hc = HPUXHardwareCollector()
    assert isinstance(hc, HPUXHardwareCollector)
    assert hc._platform == 'HP-UX'
    assert hc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:40:40.109897
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardwareCollector()
    hardware.populate()

    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] > 0
    assert hardware.facts['memfree_mb'] > 0

# Generated at 2022-06-11 02:40:42.746173
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Constructor:
    collector = HPUXHardwareCollector()
    assert collector._fact_class is not None



# Generated at 2022-06-11 02:41:42.178452
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    facts = {}
    facts['ansible_architecture'] = 'ia64'
    facts['ansible_distribution_version'] = 'B.11.23'
    hardware.module.exit_json = lambda x: 0
    hardware.module.run_command = lambda a, b: (0, 'Separator = ', '')
    hw_facts = hardware.get_hw_facts(facts)
    assert 'firmware_version' in hw_facts
    assert 'product_serial' in hw_facts
    hardware.module.run_command = lambda a, b: (1, '', '')
    hw_facts = hardware.get_hw_facts(facts)
    assert 'firmware_version' not in hw_facts

# Generated at 2022-06-11 02:41:51.257008
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    m = HPUXHardware(dict())
    # Test memory facts for PA-RISC platform
    collected_facts = {'ansible_architecture': '9000/800'}
    m.get_memory_facts(collected_facts)
    # Test memory facts for Itanium platform
    collected_facts = {'ansible_architecture': 'ia64'}
    # Test memory facts for release B.11.23
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    m.get_memory_facts(collected_facts)
    # Test memory facts for release B.11.31
    collected_facts['ansible_distribution_version'] = 'B.11.31'
    m.get_memory_facts(collected_facts)



# Generated at 2022-06-11 02:41:59.990641
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    fact_class = HPUXHardware({})
    fact_class.module.run_command = mock_run_command(command=None)
    collected_facts = {}
    collected_facts["ansible_distribution_version"] = "B.11.31"
    collected_facts["ansible_architecture"] = "ia64"
    expected = {'memfree_mb': 133, 'memtotal_mb': 3848, 'swaptotal_mb': 2707, 'swapfree_mb': 2707}
    assert fact_class.get_memory_facts(collected_facts) == expected


# Generated at 2022-06-11 02:42:10.733414
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Good case
    module = _get_module_type(platform='HP-UX', distribution_version='B.11.23')
    hardware = HPUXHardware(module)
    cpu_facts = {'processor_count': 2}
    assert hardware.get_cpu_facts() == cpu_facts

    module = _get_module_type(platform='HP-UX', distribution_version='B.11.31')
    hardware = HPUXHardware(module)
    cpu_facts = {'processor_count': 2}
    assert hardware.get_cpu_facts() == cpu_facts

    # Bad cases
    module = _get_module_type(platform='linux', distribution_version='B.11.23')
    hardware = HPUXHardware(module)
    cpu_facts = {}
    assert hardware.get_cpu_facts() == cpu

# Generated at 2022-06-11 02:42:17.705516
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    mock_get_memory_facts = (
        (
            dict(ansible_architecture='9000/800',
                 platform='HP-UX',
                 distribution='HP-UX'),
            dict(memfree_mb=812, memtotal_mb=2479, swaptotal_mb=2048, swapfree_mb=0),
        ),
        (
            dict(ansible_architecture='ia64',
                 platform='HP-UX',
                 distribution='HP-UX'),
            dict(memfree_mb=-1, memtotal_mb=-1, swaptotal_mb=-1, swapfree_mb=-1),
        ),
    )


# Generated at 2022-06-11 02:42:23.286271
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h = HPUXHardware()
    facts = {}
    cpu_facts = {}
    facts['ansible_architecture'] = '9000/800'
    cpu_facts['processor_count'] = '2'
    cpu_facts.update(h.get_cpu_facts(facts))
    assert cpu_facts == {'processor_count': 2}



# Generated at 2022-06-11 02:42:28.965146
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw_facts = {}
    collected_facts = {'ansible_architecture': 'ia64'}
    h = HPUXHardware()
    hw_facts = h.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['model'] == 'ia64'
    assert hw_facts['firmware_version'] == '11.23'

# Generated at 2022-06-11 02:42:38.453413
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
    )

    mock_collector = Mock(HPUXHardwareCollector)
    mock_collector.module = module
    hpux_hw = HPUXHardware(mock_collector)
    assert hpux_hw.from_fact_cache() == {}

    # test with param data
    data = '512'
    hpux_hw.get_memory_facts(collected_facts={'ansible_architecture': '9000/800'})
    get_command_output = hpux_hw.module.run_command.call_args_list
    assert get_command_output[0][0][0] == '/usr/bin/vmstat'