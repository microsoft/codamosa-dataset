

# Generated at 2022-06-11 02:33:02.332173
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}
    hardware = HPUXHardware(None)
    result = hardware.get_cpu_facts(collected_facts)
    assert result['processor_count'] == 1
    assert result['processor'] == 'Intel(R) Itanium(R) Processor'
    assert result['processor_cores'] == 1


# Generated at 2022-06-11 02:33:06.102034
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector.platform == 'HP-UX'
    assert hardware_collector.fact_class == HPUXHardware
    assert hardware_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:33:17.177225
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    hw = HPUXHardware(module)

    # Architecture 9000/800
    facts_800 = {'ansible_architecture': '9000/800'}
    # Architecture 9000/785
    facts_785 = {'ansible_architecture': '9000/785'}
    # Architecture ia64
    facts_ia64 = {'ansible_architecture': 'ia64'}
    # Distribution B.11.23
    facts_ia64_B_11_23 = {'ansible_distribution_version': 'B.11.23'}
    # Distribution B.11.31
    facts_ia64_B_11_31 = {'ansible_distribution_version': 'B.11.31'}

    cpu_facts_800 = h

# Generated at 2022-06-11 02:33:18.185646
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-11 02:33:26.328134
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, 'ia64', '')
    mock_facts = dict(distribution='HP-UX', ansible_machine='ia64', ansible_architecture='ia64',
                      ansible_distribution='HP-UX')
    with patch('ansible.module_utils.facts.hardware.hpux.HPUXHardware._get_hw_facts') as mock_hw_facts:
        mock_hw_facts.return_value = dict(product_serial='CZC501TZT6', firmware_version='B.11.31')
        fact = HPUXHardware(mock_module, mock_facts)
        hw_facts = fact._get_hw_facts()

# Generated at 2022-06-11 02:33:29.025520
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collector = HPUXHardwareCollector()
    assert collector.facts['platform'] == 'HP-UX'



# Generated at 2022-06-11 02:33:36.057452
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (), {
        'run_command': lambda *args, **kwargs: ('', 'Mem: 163204k av, 147692k used, 15512k free\n', ''),
    })
    hardware = HPUXHardware({}, module)
    assert hardware.get_memory_facts() == {'memfree_mb': 15, 'memtotal_mb': 159}

# Generated at 2022-06-11 02:33:47.281188
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    def mock_run_command(self, commands, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        if commands.startswith("model"):
            return 0, 'ProLiant DL380 G5', ''
        if commands.startswith("/usr/contrib/bin/machinfo"):
            if 'firmware' in commands:
                return 0, 'Firmware Revision=07.34', ''
            if 'serial' in commands:
                return 0, 'Machine Serial Number=22222222-2222-2222-2222-222222222222', ''
        return 1, '', ''

    hardware = HPUXHardware

# Generated at 2022-06-11 02:33:53.709847
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    # We cannot test the function if we cannot use /dev/kmem
    if not os.access("/dev/kmem", os.R_OK):
        module.fail_json(msg="Cannot access /dev/kmem")

    hardware = HPUXHardware(module)
    hardware.populate()
    hardware_facts = hardware.get_memory_facts()
    rc, out, err = module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'",
                                           use_unsafe_shell=True)
    if not err:
        data = out

# Generated at 2022-06-11 02:34:02.860119
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default=None, required=False)
        )
    )

    test_HPUXChecks = HPUXHardware(module=test_module)

    out1 = test_HPUXChecks.populate()
    assert out1['processor'] == "Intel(R) Xeon(R) CPU E5-4627 v2 @ 3.30GHz"
    assert out1['processor_cores'] == 20
    assert out1['processor_count'] == 5
    assert out1['memtotal_mb'] == 63988
    assert out1['memfree_mb'] == 25891
    assert out1['swaptotal_mb'] == 16384

# Generated at 2022-06-11 02:34:22.891917
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Test with PA-RISC
    hw = HPUXHardware({
        'platform': 'HP-UX',
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
    })

    # Method run_command should return true and the number of cpu
    hw._module.run_command = lambda command: (0, '1', '')

    # The method get_cpu_facts should return cpu count
    result = hw.get_cpu_facts()
    assert result == {'processor_count': 1}

    # Test with Itanium

# Generated at 2022-06-11 02:34:28.051692
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec=dict())
    har = HPUXHardwareCollector(module)
    assert har.platform == 'HP-UX'
    assert har.required_facts == set(['platform', 'distribution'])

# Unit tests for method populate of class HPUXHardwareCollector

# Generated at 2022-06-11 02:34:34.387442
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hpux_hw = HPUXHardware(module)
    facts = hpux_hw.get_cpu_facts()
    assert 'processor_count' in facts
    module.exit_json(changed=False)


# Generated at 2022-06-11 02:34:41.603214
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    fake_module = type('FakeModule', (object,), {'run_command': lambda self, args, check_rc=True: (0, args, '')})
    hpux_hw = HPUXHardware(fake_module)
    hw_facts = {"ansible_architecture": "9000/785"}
    facts = hpux_hw.populate(hw_facts)
    assert(facts['processor_count'] == 16)
    assert(facts['processor_cores'] == 4)
    assert('processor' in facts)
    assert('firmware' in facts)
    hw_facts["ansible_architecture"] = "ia64"
    hw_facts["ansible_distribution_version"] = "B.11.23"
    facts = hpux_hw.populate(hw_facts)
   

# Generated at 2022-06-11 02:34:46.754710
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hpu = HPUXHardware(module)
    collected_facts = {}
    collected_facts['ansible_architecture'] = ['ia64']
    collected_facts['ansible_distribution_version'] = ['B.11.23']
    data = hpu.get_memory_facts(collected_facts)
    assert data['swapfree_mb'] == 0



# Generated at 2022-06-11 02:34:55.648229
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    required_facts = set(['platform', 'distribution'])
    _fact_class = HPUXHardware
    _platform = 'HP-UX'
    hpc = HPUXHardwareCollector(required_facts,_fact_class, _platform)
    assert hpc.platform == 'HP-UX'
    assert hpc.fact_class == HPUXHardware
    assert hpc.required_facts == set(['platform', 'distribution'])
    assert hpc.collect() == HPUXHardwareCollector._fact_class(HPUXHardwareCollector)

# Generated at 2022-06-11 02:35:01.419598
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])
    assert hardware_collector.platform == 'HP-UX'

# Generated at 2022-06-11 02:35:10.878903
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware(dict(), True)
    facts = hw.get_hw_facts(collected_facts=dict(ansible_architecture='ia64', ansible_distribution_version='B.11.23'))
    assert facts['model'] == 'ia64 hp server rx2660'
    assert facts['firmware_version'] == 'v3.51'
    facts = hw.get_hw_facts(collected_facts=dict(ansible_architecture='ia64', ansible_distribution_version='B.11.31'))
    assert facts['model'] == 'ia64 hp server rx2660'
    assert facts['firmware_version'] == 'v5.12'

# Generated at 2022-06-11 02:35:25.039689
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command = self.run_command_MOCK

        def run_command_MOCK(self, command, use_unsafe_shell=True):
            return (0, out, '')

    class TestFacts(object):
        def __init__(self):
            self.ansible_architecture = None
            self.ansible_distribution_version = None

    hw_facts = HPUXHardware()
    hw_facts.module = TestModule()
    hw_facts.facts = TestFacts()


    # test for parisc
    for arch in ('9000/785', '9000/800'):
        hw_facts.facts.ansible_architecture = arch

# Generated at 2022-06-11 02:35:35.355259
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware_facts = HPUXHardware()
    hardware_facts.module = AnsibleModuleMock()

    # Test for ia64 architecture with B.11.31 version of HP-UX
    # machinfo return cores
    hardware_facts.module.run_command = run_command_mock('./tests/hpux_cpu_facts_1.txt')
    assert hardware_facts.get_cpu_facts() == {
        "processor_cores": 4,
        "processor": "Intel(R) Itanium(R) Processor 9340",
        "processor_count": 4
    }

    # Test for ia64 architecture with B.11.31 version of HP-UX
    # machinfo return sockets

# Generated at 2022-06-11 02:35:47.329707
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUX = HPUXHardwareCollector(None)
    assert HPUX._fact_class is HPUXHardware
    assert HPUX._platform == 'HP-UX'
    assert HPUX.required_facts == set(['platform', 'distribution'])
    assert HPUX.optional_facts == set()

# Generated at 2022-06-11 02:35:59.205089
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Initialization of the class with a fake module
    hphardware = HPUXHardware(False)
    # Initialization of collected_facts

# Generated at 2022-06-11 02:36:12.096497
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.hpu_ux import HPUXHardware

    module = MockModule()
    hardware = HPUXHardware(module)
    # Test for normal case
    rc, out, err = hardware.module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'", use_unsafe_shell=True)
    out = '1234'
    expected_result = {
        'memfree_mb': 0,
        'memtotal_mb': 1234 / 256,
        'swaptotal_mb': 0,
        'swapfree_mb': 0
    }
    result = hardware.get_memory_facts()
    assert result == expected_result
    #

# Generated at 2022-06-11 02:36:15.564164
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_collector = HPUXHardwareCollector()
    assert hpux_collector.platform == 'HP-UX'
    assert hpux_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:36:26.076836
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hpuxtest = HPUXHardware()
    hpuxtest.collector = HPUXHardwareCollector(None)
    hpuxtest.collector.facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23',
        'platform': 'HP-UX',
    }

    rc, out, err = hpuxtest.module.run_command("model")
    expected_result = {
        'firmware_version': '235C',
        'model': out.strip()
    }

    hw_facts = hpuxtest.get_hw_facts()
    assert hw_facts['firmware_version'] == expected_result['firmware_version']

# Generated at 2022-06-11 02:36:31.961247
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()

    assert hw_collector is not None
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector._fact_class == HPUXHardware
    assert hw_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:36:40.174130
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class Module:
        def __init__(self, cmd, inst_out, inst_err, inst_rc):
            self.cmd = cmd
            self.inst_out = inst_out
            self.inst_err = inst_err
            self.inst_rc = inst_rc

        def run_command(self, cmd, use_unsafe_shell=False):
            self.cmd = cmd
            return self.inst_rc, self.inst_out, self.inst_err

    hw_obj = HPUXHardware()

    module = Module(None, 'ia64\nhostname\n', '', 0)
    hw_obj.module = module
    collected_facts = {'ansible_distribution_version': 'B.11.31', 'ansible_architecture': 'ia64'}
    hw_

# Generated at 2022-06-11 02:36:43.233457
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector(dict())
    assert type(h).__name__ == 'HPUXHardwareCollector'

# Generated at 2022-06-11 02:36:49.431160
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector_obj = HPUXHardwareCollector()
    assert hardware_collector_obj._fact_class is HPUXHardware
    assert hardware_collector_obj._platform == 'HP-UX'
    assert hardware_collector_obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:37:00.637533
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    hw = HPUXHardware(module=module)
    rc, out, err = module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'",
                                      use_unsafe_shell=True)
    if not err and out:
        collected_facts = {'ansible_architecture': '9000/800'}
        result = hw.get_memory_facts(collected_facts)
        assert result.get('memtotal_mb') == int(out) / 256
        assert result.get('memfree_mb')

# Generated at 2022-06-11 02:37:16.852628
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    method populate of class HPUXHardware
    """
    hw = HPUXHardware()
    hw.module = AnsibleModuleMock()
    hw.populate()

# Generated at 2022-06-11 02:37:20.480273
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector(module=dict())

    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:37:24.765074
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hux = HPUXHardwareCollector()
    assert hux.__class__.__name__ == "HPUXHardwareCollector"
    assert hux._platform == "HP-UX"


# Generated at 2022-06-11 02:37:36.381009
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Unit test is only for input and output of method, not logic of method
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(type='list', required=False),
            'gather_timeout': dict(type='int', required=False),
            'filter': dict(type='list', required=False),
        }
    )

    # For simplicity, these are the raw outputs that would be gathered
    # from each supported platform
    hpux_9000_800_data = {
        'ansible_architecture': '9000/800'
    }

    hpux_9000_785_data = {
        'ansible_architecture': '9000/785'
    }


# Generated at 2022-06-11 02:37:44.047875
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware_facts = {
        'platform': 'HP-UX',
        'distribution': 'HP-UX'
    }

    test_object = HPUXHardware(module=None, collected_facts=hardware_facts)
    rc, out, err = test_object.module.run_command("uname -a")
    assert out.strip() == 'HP-UX servername B.11.31 U ia64 176573254 unlimited-user license'
    assert test_object.get_hw_facts() == {'model': 'ia64'}

# Generated at 2022-06-11 02:37:52.218896
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hw = HPUXHardware({})
    rc, out, err = hw.module.run_command("/bin/echo 'IA64 hp server rx7620'")
    hw.module.run_command = lambda *args, **kwargs: (rc, out, err)
    out = hw.get_hw_facts()
    assert out['model'] == 'IA64 hp server rx7620'


# Generated at 2022-06-11 02:37:58.520295
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    from ansible.module_utils.facts.hardware.hpu import HPUXHardwareCollector
    from ansible.module_utils.facts.hardware.hpu import HPUXHardware

    h = HPUXHardwareCollector()
    assert h.__dict__['_fact_class'] == HPUXHardware
    assert h.__dict__['_platform'] == 'HP-UX'
    assert h.__dict__['required_facts'] == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:38:11.291847
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware()
    hardware.module = AnsibleModule(argument_spec={})

    hardware.module.collect_facts = Mock(return_value={
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.23'
    })
    hardware.module.run_command = Mock(return_value=(0, '', ''))
    output = hardware.get_hw_facts()
    assert output == {'model': '', 'firmware_version': '', 'product_serial': ''}

    hardware.module.run_command = Mock(return_value=(0, '', ''))

# Generated at 2022-06-11 02:38:15.381921
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    cpu_facts = HPUXHardware(module).get_cpu_facts()
    assert cpu_facts == {u'processor': u'Intel(R) Itanium(R) Processor 9100 series',
                         u'processor_count': 2, u'processor_cores': 1}


# Generated at 2022-06-11 02:38:19.609120
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module_args = {}
    h = HPUXHardwareCollector(module_args=module_args)
    h._collect()
    print(h.get_facts())


if __name__ == '__main__':
    test_HPUXHardwareCollector()

# Generated at 2022-06-11 02:38:38.125663
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    obj = HPUXHardwareCollector()
    assert obj.fact_class == HPUXHardware
    assert obj.platform == 'HP-UX'
    assert obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:38:44.428254
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    module.params['system'] = 'HP-UX'
    module.params['major_release'] = 'B.11.31'
    module.params['architecture'] = 'ia64'
    hardware = HPUXHardware(module)
    hardware_facts = hardware.get_hw_facts()
    assert hardware_facts['firmware_version'] == 'P89 v75.10'
    assert hardware_facts['product_serial'] == '12345'


# Generated at 2022-06-11 02:38:53.015284
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    facts = {'ansible_architecture': 'ia64',
             'ansible_distribution': 'HP-UX',
             'ansible_distribution_version': 'B.11.32'}
    hardware = HPUXHardware(module)
    hardware.populate(facts)
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 24
    assert hardware.facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert hardware.facts['memfree_mb'] == 1787
    assert hardware.facts['memtotal_mb'] == 84324
    assert hardware.facts['swaptotal_mb'] == 1023
    assert hardware.facts['swapfree_mb'] == 1023
    assert hardware.facts['model']

# Generated at 2022-06-11 02:38:58.833750
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    collected_facts = {'platform': 'HP-UX', 'distribution': 'B.11.31'}
    hw_collector = HPUXHardwareCollector(None, collected_facts, None)
    assert hw_collector.required_facts == set(['platform', 'distribution'])
    assert hw_collector._platform == 'HP-UX'
    assert hw_collector._fact_class == HPUXHardware



# Generated at 2022-06-11 02:39:04.544526
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = {'platform': 'HP-UX', 'distribution': 'B.11.31'}
    hpux_hw_collector = HPUXHardwareCollector(facts, None)
    assert isinstance(hpux_hw_collector._fact_class, HPUXHardware)
    assert hpux_hw_collector._platform == 'HP-UX'
    assert hpux_hw_collector._fact_class.platform == 'HP-UX'
    assert hpux_hw_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:39:06.271631
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HardwareCollector()
    HPUXHardwareCollector()


# Generated at 2022-06-11 02:39:09.108666
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hhc = HPUXHardwareCollector()
    assert hhc.collect() == {}

# Generated at 2022-06-11 02:39:18.699341
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mod = FakeModule()
    hw = HPUXHardware(module=mod)
    pagesize = 4096
    rc, out, err = mod.run_command("/usr/bin/vmstat | tail -1")
    data = int(re.sub(' +', ' ', out).split(' ')[5].strip())
    memfree_mb = pagesize * data // 1024 // 1024
    rc, out, err = mod.run_command("/usr/contrib/bin/machinfo | grep Memory")
    data = re.search(r'Memory[\ :=]*([0-9]*).*MB.*', out).groups()[0].strip()
    memtotal_mb = int(data)
    rc, out, err = mod.run_command("/usr/sbin/swapinfo -m -d -f -q")

# Generated at 2022-06-11 02:39:22.551309
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    h = HPUXHardwareCollector()
    assert h._fact_class == HPUXHardware
    assert h._platform == 'HP-UX'
    assert h.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-11 02:39:32.859235
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    Test case for method populate of class HPUXHardware
    """

    import sys
    import types
    import unittest
    from ansible.module_utils.facts import hardware

    class _AnsibleModule:

        _module = 'ansible.module_utils.facts.hardware.hpux'

        def __init__(self, platform=None, distribution=None):
            self.platform = platform
            self.distribution = distribution
            self.params = {}
            self.facts = {}
            self.run_command_patcher = None

        def run_command(self, *args, **kwargs):

            class _CommandResult:

                def __init__(self, rc, stdout, stderr):
                    self.rc = rc
                    self.stdout = stdout
                    self.stderr = st

# Generated at 2022-06-11 02:39:51.328444
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    harware_collector = HPUXHardwareCollector(None)
    assert harware_collector.platform == 'HP-UX'
    assert harware_collector.required_facts == frozenset(['platform', 'distribution'])
    assert harware_collector.fact_class == HPUXHardware

# Generated at 2022-06-11 02:39:55.816416
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    m = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    try:
        m.get_memory_facts(collected_facts=collected_facts)
    except Exception as e:
        print(str(e))

# Generated at 2022-06-11 02:40:01.172172
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    data = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HPUX',
        'ansible_distribution_version': 'B.11.23'
    }
    hardware = HPUXHardware(data)
    facts = hardware.get_hw_facts()
    assert facts['model'] == "hpsim"
    assert facts['firmware_version'] == "v3.70"



# Generated at 2022-06-11 02:40:05.752204
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    cpu_facts_test = {'processor_count': 4, 'processor': 'Itanium 9350', 'processor_cores': 2}
    hardware_test = HPUXHardware(dict())
    assert cpu_facts_test == hardware_test.get_cpu_facts()



# Generated at 2022-06-11 02:40:16.892675
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware({}, {})
    hardware.module = FakeModule()
    hardware.module.run_command = lambda *args, **kwargs: (0, 'ia64', '')
    hardware.module.run_command.return_value = (0, 'ia64', '')
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor'

# Generated at 2022-06-11 02:40:27.625964
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware()
    hardware.module = AnsibleModule(argument_spec=dict())

    hardware.module.run_command = MagicMock(return_value=(0, '', ''))

    cpu_facts = hardware.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'})
    assert cpu_facts['processor'] == 'Intel(R) Itanium(R) Processor 9320'
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 24

    cpu_facts = hardware.get_cpu_facts(collected_facts={'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert cpu

# Generated at 2022-06-11 02:40:31.160351
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware = HPUXHardwareCollector()
    assert hardware.fact_class == HPUXHardware
    assert hardware.platform == 'HP-UX'
    assert hardware.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:40:41.105606
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts = HPUXHardware(module)
    collected_facts = {
        'ansible_architecture': '9000/800'
    }
    module.run_command = MagicMock(return_value=(0, '4096', ''))
    memory_facts = hardware_facts.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 1
    collected_facts['ansible_architecture'] = 'ia64'
    collected_facts['ansible_distribution_version'] = 'B.11.23'
    memory_facts = hardware_facts.get_memory_facts(collected_facts=collected_facts)
    assert memory_facts['memfree_mb'] == 1
    collected_

# Generated at 2022-06-11 02:40:45.522972
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware_obj = HPUXHardware(dict(platform='HP-UX', distribution='B.11.31', ansible_architecture='ia64'))
    assert hardware_obj.get_hw_facts() == dict(model='ia64', firmware_version='B.11.31', product_serial='123456789')


# Generated at 2022-06-11 02:40:55.793374
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = HPUXHardware()
    rc, out, err = hardware.module.run_command("iostat -T d -c 5 2 | head -2 | tail -1")
    collected_facts = {'ansible_architecture':'ia64', 'ansible_distribution_version':'B.11.31'}
    cpu_facts = hardware.get_cpu_facts(collected_facts)
    assert(cpu_facts['processor_count'] == int(out.strip().split(' ')[3]))
    assert(cpu_facts['processor_cores'] == int(out.strip().split(' ')[7]))
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
   

# Generated at 2022-06-11 02:41:18.004433
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = FakeAnsibleModule()
    hardware = HPUXHardware(module)
    hardware.module.run_command = run_command
    hardware.get_hw_facts = get_output

    rc, out, err = hardware.get_hw_facts()
    assert rc == 0
    assert out.get('model') == "ia64 hp server rx2800 i2"
    assert out.get('firmware_version') == "HP-UX_B.11.31_U_1106_1204_2622079"
    assert out.get('product_serial') == "CZJ8170L6P"



# Generated at 2022-06-11 02:41:22.608357
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Create a new HPUXHardwareCollector object
    hw = HPUXHardwareCollector()

    # check required class attributes values
    assert hw._fact_class == HPUXHardware
    assert hw._platform == 'HP-UX'
    assert isinstance(hw.required_facts, set)
    assert hw.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:41:32.718310
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hpx_hw_facts = HPUXHardware(dict())
    # populate memory facts
    rc, out, err = hpx_hw_facts.module.run_command("/usr/sbin/swapinfo -m -d -f | egrep '^dev|^fs'", use_unsafe_shell=True)
    hpx_hw_facts.module.params['memfree_mb'] = 10
    hpx_hw_facts.module.params['memtotal_mb'] = 1000
    hpx_hw_facts.module.params['processor_cores'] = 0
    hpx_hw_facts.module.params['processor_count'] = 0
    hpx_hw_facts.module.params['processor'] = ''
    hpx_hw_facts.module.params['model'] = ''

# Generated at 2022-06-11 02:41:35.273694
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector._fact_class is HPUXHardware
    assert hardware_collector._platform is 'HP-UX'

# Generated at 2022-06-11 02:41:36.696991
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    assert HPUXHardwareCollector.platform == 'HP-UX'

# Generated at 2022-06-11 02:41:41.638149
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    class MockModule(object):
        def run_command(self, cmd):
            if cmd == 'ioscan -FkCprocessor | wc -l':
                return 1, '2', ''
            if cmd == '/usr/contrib/bin/machinfo | grep  "Number of CPUs"':
                return 1, 'Number of CPUs: 4', ''
            if cmd == '/usr/contrib/bin/machinfo | grep "processor family"':
                return 1, 'processor family: Intel(R) Itanium(R) processor family', ''

    m = MockModule()
    hw = HPUXHardware(m)
    facts = {}

    rc, out, err = hw.get_cpu_facts(collected_facts={'ansible_architecture': '9000/800'})
    assert rc['processor_count']

# Generated at 2022-06-11 02:41:50.895389
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():

    # ia64
    module = MockModule()
    module.run_command = Mock(side_effect=Exception('Some error'))

    module.run_command = Mock(return_value=(1, 'error', 'error'))

    hw = HPUXHardware(module)
    hw.module.run_command = Mock(return_value=(0, '', ''))
    hw.distribution = 'HP-UX'
    hw.get_cpu_facts = Mock(return_value={'processor_count': 1, 'processor_cores': 1, 'processor': 'test'})
    hw.get_memory_facts = Mock(return_value={'memfree_mb': 1, 'memtotal_mb': 1, 'swaptotal_mb': 1, 'swapfree_mb': 1})
    hw.get

# Generated at 2022-06-11 02:41:53.778060
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hardware = HPUXHardware(dict())
    facts = hardware.populate()
    assert 'processor_count' in facts
    assert 'processor_cores' in facts
    assert 'processor' in facts



# Generated at 2022-06-11 02:42:03.752178
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModuleMock({
        'platform': 'Linux',
        'distribution': 'Debian'
    })
    hardware_facts = HPUXHardware(module)
    hw_facts = hardware_facts.get_hw_facts({'ansible_architecture': 'ia64'})
    assert 'model' in hw_facts and hw_facts['model'] == 'ia64'
    assert 'firmware_version' in hw_facts and hw_facts['firmware_version'] == '1209'
    assert 'product_serial' in hw_facts and hw_facts['product_serial'] == '123456789'



# Generated at 2022-06-11 02:42:12.740746
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hw = HPUXHardware()
    collected_facts = {'ansible_architecture': '9000/785', 'ansible_distribution': 'hpux'}
    hardware_facts = hw.populate(collected_facts=collected_facts)
    expected = {'processor_count': 2, 'processor_cores': 2,
                'processor': 'Intel(R) Itanium(R) 9300 Series Processor',
                'model': 'ia64 hp Integrity rx2800 i4',
                'memtotal_mb': 64000, 'memfree_mb': 63995, 'swaptotal_mb': 25600, 'swapfree_mb': 25600}
    assert hardware_facts == expected

# Generated at 2022-06-11 02:42:37.903672
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hw = HPUXHardware(None)

    hw.module.run_command = lambda x: (0, '8192', '')
    mem_facts = hw.get_memory_facts({'ansible_architecture': '9000/800'})
    assert mem_facts['memfree_mb'] == 8

    hw.module.run_command = lambda x: (0, '12345', '')
    mem_facts = hw.get_memory_facts({'ansible_architecture': '9000/800'})
    assert mem_facts['memtotal_mb'] == 12

    hw.module.run_command = lambda x: (0, '8192', '')
    mem_facts = hw.get_memory_facts({'ansible_architecture': 'ia64'})

# Generated at 2022-06-11 02:42:46.701254
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    """
    AnsibleModule for unit test for method populate of class HPUXHardware
    """
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list')
        }
    )
    gathered_facts = {}
    instance = HPUXHardware()
    populated_facts = instance.populate()

    rc, out, err = module.run_command("/usr/bin/vmstat | tail -1", use_unsafe_shell=True)
    data = int(re.sub(' +', ' ', out).split(' ')[5].strip()) * 4096 // 1024 // 1024
    assert populated_facts['memfree_mb'] == data