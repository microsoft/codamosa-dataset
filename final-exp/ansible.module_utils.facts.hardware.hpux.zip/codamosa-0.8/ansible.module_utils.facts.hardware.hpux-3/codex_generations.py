

# Generated at 2022-06-11 02:33:04.373471
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware(dict(ANSIBLE_MODULE_ARGS=dict(content='HPUXHardwareClass')))
    hardware.module = DummyAnsibleModule()
    hardware.module.run_command = run_command
    hw_facts = hardware.get_hw_facts({'ansible_distribution': 'HPUX', 'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'})
    assert hw_facts['model'] == 'ia64'
    assert hw_facts['firmware_version'] == '09.22'
    assert hw_facts['product_serial'] == 'ABCDEFG'


# Generated at 2022-06-11 02:33:15.392881
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class HPUXHardwareMock():
        def __init__(self, module_mock):
            self.module = module_mock

        def populated(self, collected_facts=None):
            return self.populate(collected_facts=collected_facts)

    class ModuleMock():
        def __init__(self, params):
            self.params = params
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    # base test
    module_mock = ModuleMock({})

    # execute

# Generated at 2022-06-11 02:33:24.592749
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """ This test makes sure that method get_cpu_facts for class
    HPUXHardware returns correct values for each architecture
    where this method is called """

    def get_collected_facts():
        return {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.31'}

    hardware_obj = HPUXHardware(None)
    hardware_obj.module.run_command = lambda *args, **kwargs: (0, "2", None)
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts=get_collected_facts())
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-11 02:33:38.840278
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    out = []
    err = []
    rc = 0
    module = object()
    path = '/usr/contrib/bin/machinfo'

    # Test case 1
    # return values
    rc_return = 0
    out_return = """
PAGE SIZE  :  4096 BYTES
NUMBER OF PAGES   :    8192000
NUMBER OF PHYSICAL PAGES   :    8192000
MEMORY SIZE  :  32 GB

"""
    err_return = []
    # expected values
    expected = {'memtotal_mb': 32768, 'memfree_mb': 0}

    # Call test function
    hw = HPUXHardware(module)
    actual = hw._get_memory_facts(path, rc_return, out_return, err_return)

    # Check returned value

# Generated at 2022-06-11 02:33:43.913827
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mock_module = type('mock_module', (object,),
                       dict(run_command=lambda x, **kwargs: ('0', '', '')))
    mock_facts = {}
    hw = HPUXHardware(mock_module, mock_facts)
    mem_facts = hw.get_memory_facts(collected_facts=mock_facts)
    assert mem_facts['memtotal_mb'] == 3000
    assert mem_facts['memfree_mb'] == 30

# Generated at 2022-06-11 02:33:49.084202
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    facts = dict(platform="HP-UX", distribution="11.31")
    hardware_collector = HPUXHardwareCollector(facts)
    assert hardware_collector.platform == "HP-UX"
    assert hardware_collector.required_facts == {'platform', 'distribution'}
    assert hardware_collector._fact_class == HPUXHardware


# Generated at 2022-06-11 02:33:52.319107
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware = HPUXHardware(module=module)
    hardware.populate()
    assert hardware.get_memory_facts()


# Generated at 2022-06-11 02:33:56.006185
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector({'platform':'HP-UX', 'distribution':'B.11.23'})
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:34:04.029835
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    facts = {}
    collector = HPUXHardwareCollector()
    hw = HPUXHardware(facts)
    hw.module = AnsibleModuleStub(set(['platform', 'distribution']), facts)
    hw.module.run_command = RunCommandStub()

# Generated at 2022-06-11 02:34:07.014571
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    result = HPUXHardwareCollector()
    assert result._fact_class == HPUXHardware
    assert result._platform == 'HP-UX'


# Generated at 2022-06-11 02:34:22.115108
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    module = AnsibleModule(argument_spec={})
    ohc = HPUXHardwareCollector(module=module)

    assert ohc.platform == 'HP-UX'
    assert ohc.required_facts == {'platform', 'distribution'}
    assert isinstance(ohc._fact_class, HPUXHardware)



# Generated at 2022-06-11 02:34:31.630007
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    HPUXHardware_get_cpu_facts_result = {
      "processor_cores": 2,
      "processor": "Intel Itanium2",
      "processor_count": 2
    }
    test_collected_facts = {
        "ansible_architecture": "ia64",
        "ansible_distribution_version": "B.11.23"
    }
    hardware = HPUXHardware()

    assert HPUXHardware_get_cpu_facts_result == hardware.get_cpu_facts(test_collected_facts)



# Generated at 2022-06-11 02:34:43.661097
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # B.11.31, IA64
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution_version='B.11.31'
    )

    hpux_hw = HPUXHardware(module)

    cpu_facts = hpux_hw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2670 v3 @ 2.30GHz'
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2

    # B.11.31, IA64 (with HyperThreading)

# Generated at 2022-06-11 02:34:55.355623
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)

    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.23'
    )
    hardware.populate(collected_facts)
    # Verify results
    assert collected_facts['memory_mb']['memfree_mb'] == 1260
    assert collected_facts['processor'][0]['model'] == 'Intel(R) Itanium(R) Processor'

    # New version, new tests
    collected_facts = dict(
        ansible_architecture='ia64',
        ansible_distribution='HP-UX',
        ansible_distribution_version='B.11.31'
    )

# Generated at 2022-06-11 02:34:56.546353
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()

# Generated at 2022-06-11 02:35:06.771565
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Creation of a class HPUXHardware test object
    hw_obj = HPUXHardware()
    # Addition of a test fonction to the object
    hw_obj.module.run_command = run_command
    # Calling of the methode get_cpu_facts
    cpu_facts = hw_obj.get_cpu_facts({'ansible_architecture': '9000/800', 'ansible_distribution': 'HP-UX', 'ansible_distribution_version': 'B.11.31'})
    assert cpu_facts['processor_count'] == 10
    assert cpu_facts['processor_cores'] == 10
    assert cpu_facts['processor'] == 'Intel(r) Itanium(r) processor 9500 series (1.53 GHz, 37.5 MB)'
    cpu_facts = hw_obj

# Generated at 2022-06-11 02:35:10.878971
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    hpux = HPUXHardwareCollector(module=module).collect()[0]  # noqa

    assert hpux.get_hw_facts() == {}



# Generated at 2022-06-11 02:35:13.942335
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    hardware_facts = Hardware()
    hardware_facts.collect()
    hardware_facts.populate()

# Generated at 2022-06-11 02:35:27.201962
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class MockModule:
        def run_command(self, cmd, data=None, check_rc=True):
            if cmd.startswith("model"):
                out = "HP rp3440"
                return 0, out, ""
            elif cmd.startswith("/usr/contrib/bin/machinfo"):
                out = """Memory = 2048 MB (2097152)
Firmware revision = B.11.31
Machine serial number = US3456789"""
                return 0, out, ""
            return 0, "", ""

    module = MockModule()
    key = 0
    # Testing collect_facts
    hardware = HPUXHardware(module)
    facts = hardware.populate()
    # Testing collect_facts with alternate machinfo format

# Generated at 2022-06-11 02:35:36.633028
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    # Creating a module mock
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    result = {
        'ansible_facts': {
            'ansible_architecture': '9000/800',
            'ansible_distribution_version': 'B.11.23',
            'ansible_distribution': 'HP-UX'
        }
    }
    module.run_command = Mock(return_value=(0, 8, None))
    # Creating a class object mock
    hpux = HPUXHardware(module)
    hpux.populate()

    # Testing if the method returns a dictionary
    assert isinstance(hpux.get_cpu_facts(result['ansible_facts']), dict)

    # Testing if the method returns a dictionary with the processor number


# Generated at 2022-06-11 02:35:54.804641
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector_obj = HPUXHardwareCollector()
    assert hardware_collector_obj._platform == 'HP-UX'
    assert hardware_collector_obj._fact_class.platform == 'HP-UX'
    assert hardware_collector_obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:36:01.762976
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware({})
    info = hardware.get_hw_facts({'platform': 'HP-UX'})
    # Assert that the serial number is not empty
    assert info['product_serial'] != ''
    # Assert that the model is not empty
    assert info['model'] != ''
    # Assert that the firmware is not empty
    assert info['firmware_version'] != ''

# Generated at 2022-06-11 02:36:02.940471
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    HPUXHardwareCollector()


# Generated at 2022-06-11 02:36:09.190280
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    ansible_facts = {'ansible_architecture': 'ia64',
                     'ansible_distribution_version': 'B.11.31'}
    hardware_obj = HPUXHardware(module=None, collected_facts=ansible_facts)
    if os.access("/dev/kmem", os.R_OK):
        rc, out, err = hardware_obj.module.run_command("echo 'phys_mem_pages/D' | adb -k /stand/vmunix /dev/kmem | tail -1 | awk '{print $2}'",
                                                       use_unsafe_shell=True)
        mem_value = int(out) / 256
        memory_facts = hardware_obj.get_memory_facts()
        assert memory_facts['memtotal_mb'] == mem_value

# Generated at 2022-06-11 02:36:19.805071
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23', 'ansible_pkg_mgr': 'swinstall', 'ansible_distribution': 'HP-UX'}
    cpu_facts = HPUXHardware(module=None).get_cpu_facts(collected_facts=facts)

    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert 'processor' in cpu_facts

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-11 02:36:27.906879
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    # First example
    raw_meminfo = """
memory          total        used        free      shared     buffers
Mem:          25932        9356       16576          0         932
Swap:         24992           0       24992
"""
    hpu = HPUXHardware()
    hpu.module.run_command = MagicMock(return_value=(0, raw_meminfo, ""))
    hpu.module.get_bin_path = MagicMock(return_value=True)
    hpu.module.collect_file_facts = MagicMock(return_value='')
    hpu.get_memory_facts() == {'swapfree_mb': 25, 'memfree_mb': 17,
                               'swaptotal_mb': 25, 'memtotal_mb': 26}

    # Second example
    raw_mem

# Generated at 2022-06-11 02:36:38.261944
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    hardware = HPUXHardware()
    hardware.module = FakeModule()

# Generated at 2022-06-11 02:36:51.803550
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    hw = HPUXHardware(module=module)
    assert hw.get_cpu_facts() == {}

    module = AnsibleModuleMock(facts={'platform': 'HP-UX', 'architecture': '9000/800'})
    hw = HPUXHardware(module=module)
    assert hw.get_cpu_facts() == {'processor_count': 2}

    module = AnsibleModuleMock(facts={'platform': 'HP-UX', 'architecture': 'ia64'})
    hw = HPUXHardware(module=module)
    assert hw.get_cpu_facts() == {}


# Generated at 2022-06-11 02:37:03.644528
# Unit test for method get_cpu_facts of class HPUXHardware

# Generated at 2022-06-11 02:37:07.325048
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    inst = HPUXHardwareCollector({'platform': 'HP-UX'})
    assert inst.fact_class == HPUXHardware
    assert inst.platform == 'HP-UX'
    assert inst.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:37:27.091563
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    # Create instance of class HPUXHardwareCollector
    hw_collector = HPUXHardwareCollector()

    assert 'HP-UX' == hw_collector._platform
    assert 'HPUXHardware' == hw_collector._fact_class.__name__

# Generated at 2022-06-11 02:37:37.578706
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    class ModuleStub:
        def __init__(self, status_code=0, return_value=None, cmd=None):
            self.status_code = status_code
            self.return_value = return_value
            self.cmd = cmd

        def run_command(self, cmd, use_unsafe_shell=True):
            self.cmd = cmd
            return self.status_code, self.return_value, ''

    pagesize = 4096
    mem_facts = {}
    h = HPUXHardware()
    h.module = ModuleStub()
    h.module.run_command = lambda x, use_unsafe_shell=True: (0, '914', '')
    mem_facts = h.get_memory_facts()

# Generated at 2022-06-11 02:37:38.604055
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HPUXHardware.get_hw_facts()

# Generated at 2022-06-11 02:37:43.144532
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hardware_collector = HPUXHardwareCollector()
    assert hardware_collector is not None
    assert hardware_collector._fact_class == HPUXHardware
    assert hardware_collector._platform == 'HP-UX'
    assert hardware_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-11 02:37:55.757668
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    #unit test functionnal only with python2.7 and pytest modules
    #see https://docs.pytest.org/en/latest/
    #and https://pytest-mock.readthedocs.io/en/latest/
    #
    #sudo pip install pytest pytest-mock
    #pytest test_HPUXHardware_get_cpu_facts.py
    #
    #
    from ansible.module_utils.facts.hardware.hpux import HPUXHardware
    from ansible.module_utils.facts.hardware.hpux import HPUXHardwareCollector
    from ansible.module_utils.facts.collections import Hardware
    import pytest
    import sys
    import os
    import platform

    # mock the ansible module

# Generated at 2022-06-11 02:38:09.371263
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mock_module = DummyAnsibleModule()
    mock_module.ansible_facts = {'ansible_architecture': 'ia64',
                                 'ansible_distribution_version': 'B.11.23'}
    memory_facts = HPUXHardware(mock_module).get_memory_facts()
    assert memory_facts['memtotal_mb'] == 123456
    assert memory_facts['memfree_mb'] == 7890
    assert memory_facts['swaptotal_mb'] == 7890
    assert memory_facts['swapfree_mb'] == 7890
    mock_module.ansible_facts = {'ansible_architecture': 'ia64',
                                 'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-11 02:38:19.275585
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = HPUXHardware(module)
    cpu_facts = {}

    # case 1
    collected_facts = {'ansible_architecture': '9000/800'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 16

    # case 2
    collected_facts = {'ansible_architecture': '9000/785'}
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts['processor_count'] == 16

    # case 3

# Generated at 2022-06-11 02:38:27.844223
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    test_module = HPUXHardware()
    test_module.module.run_command = lambda *args, **kargs: (0, "some_model", "")
    result = test_module.get_hw_facts({'ansible_architecture': 'ia64',
                                       'ansible_distribution_version': 'B.11.23'})
    assert result['model'] == 'some_model'
    assert result['firmware_version'] == '2.69'
    assert result['product_serial'] == '0x00000000'



# Generated at 2022-06-11 02:38:35.578691
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    hw = HPUXHardware({})
    ia64 = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}
    parisc = {'ansible_architecture': '9000/800'}
    s700 = {'ansible_architecture': '9000/785'}
    # get_cpu_facts tested with hppa and ia64 return values
    assert hw.get_cpu_facts(ia64) == {'processor': 'Intel(R) Itanium(R) processor 9100 series',
                                      'processor_cores': 4, 'processor_count': 4}
    assert hw.get_cpu_facts(parisc) == {'processor_count': 2}

# Generated at 2022-06-11 02:38:45.374056
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = type('', (), {})()
    module.run_command = type('', (), {})()
    module.run_command.return_value = (0, '1234', '')
    facts = {}
    test = HPUXHardware(module, facts=facts)
    assert test.get_memory_facts() == {}
    module.run_command.return_value = (0, '', '')
    facts = {'ansible_architecture': '9000/800', 'ansible_memtotal_mb': '1234'}
    test = HPUXHardware(module, facts=facts)
    test.module.run_command.return_value = (0, 'Physical: 1024 Kbytes', '')

# Generated at 2022-06-11 02:39:03.644549
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    class MockModule(object):

        def __init__(self):
            self.run_command_results = []

        def run_command(self, command, use_unsafe_shell=True):
            item = self.run_command_results.pop(0)
            return item[0], item[1], item[2]

    module = MockModule()
    module.run_command_results = [
        [0, "9000/800", ""]
    ]

    hw = HPUXHardware()
    hw.module = module
    hw.populate()

    assert(hw.facts['model'] == '9000/800')

    module.run_command_results = [
        [0, "9000/785", ""]
    ]

    hw = HPUXHardware()

# Generated at 2022-06-11 02:39:08.554446
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpg = HPUXHardwareCollector()
    assert hpg.platform == 'HP-UX'
    assert hpg.fact_class == HPUXHardware
    assert hpg.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-11 02:39:15.426187
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = run_command
    # Mock
    collected_facts = {'ansible_architecture': '9000/800'}
    # End mock
    hw = HPUXHardware(module)
    module.exit_json(changed=False, ansible_facts={'cache': {}, 'ansible_hardware': hw.populate(collected_facts)})


# Generated at 2022-06-11 02:39:19.026112
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    HPUX_HARDWARE = HPUXHardware()
    MEMORY_FACTS = HPUX_HARDWARE.get_memory_facts()
    assert MEMORY_FACTS is not None
    assert MEMORY_FACTS.get('memtotal_mb') is not None

# Generated at 2022-06-11 02:39:22.815440
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    mem_facts = HPUXHardware(None).get_memory_facts()
    assert mem_facts.get('memtotal_mb')
    assert mem_facts.get('swaptotal_mb')


# Generated at 2022-06-11 02:39:33.058470
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """Return cpu facts for all HP-UX systems"""
    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command = lambda *args, **kwargs: ('', '', '')
            self.fail_json = lambda *args, **kwargs: self.failed
        def fail_json(self, msg):
            self.failed = True

    cpu_facts = {}

    mock = MockModule()
    mock.params['gather_subset'] = ['all']
    mock.params['gather_timeout'] = 10

    # Without machinfo
    cpu_facts = HPUXHardware(mock).get_cpu_facts()
    assert cpu_facts['processor_count'] == 4

    # With machinfo

# Generated at 2022-06-11 02:39:39.079711
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))

    hwinfo = HPUXHardware()
    hwinfo.module = module
    hw_facts = hwinfo.get_hw_facts()
    assert hwinfo.get_hw_facts() == hw_facts


# Generated at 2022-06-11 02:39:42.281138
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    hardware = HPUXHardware(dict())
    hardware.module.run_command = lambda *args, **kwargs: ('', 'HP9000/800\n', '')
    hardware.get_hw_facts()
    assert hardware.facts['model'] == 'HP9000/800'

# Generated at 2022-06-11 02:39:52.793617
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h = HPUXHardware(dict(ANSIBLE_MODULE_ARGS={'gather_subset': '!all'}))

    # Test for PA-RISC CPU
    pa_risc_collected_facts = {
        'ansible_architecture': '9000/800'
    }
    assert h.get_cpu_facts(collected_facts=pa_risc_collected_facts) == {'processor_count': 2}

    # Test for IA64 CPU
    ia64_collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution_version': 'B.11.31'
    }

# Generated at 2022-06-11 02:40:00.789030
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )

    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution_version': 'B.11.31'}

    hw = HPUXHardware({'module': module})
    facts = hw.get_hw_facts(collected_facts=collected_facts)

    assert facts['model'] == 'hp server rx6600'
    assert facts['firmware_version'] == '01.34'
    assert facts['product_serial'] == 'CZH305321B'



# Generated at 2022-06-11 02:40:22.465322
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    """
    Method to test get_cpu_facts of the HPUXHardware class.
    """

    # Create instance of class HPUXHardware
    obj = HPUXHardware({})

    # Get CPU facts for older PA-RISC systems (B.11.11, B.11.23)
    #
    # Case 1: The architecture is 9000/800. We run ioscan and get the number of
    # CPU cores. The processor type is undefined.
    collected_facts = {
        'ansible_architecture': '9000/800'
    }
    obj.module.run_command = stub_run_command
    obj.module.run_command.return_value = (0, '12', '')
    cpu_facts = obj.get_cpu_facts(collected_facts=collected_facts)
    assert cpu

# Generated at 2022-06-11 02:40:33.013471
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = HPUXHardware(module)
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    assert hw.get_cpu_facts(collected_facts) == {'processor': 'Intel(R) Itanium(R) processor', 'processor_cores': 240,
                                                 'processor_count': 2}
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}

# Generated at 2022-06-11 02:40:43.474928
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_obj = HPUXHardware(module)
    # collect_facts = False
    collected_facts = {
        'distribution': 'HP-UX',
        'distribution_version': 'B.11.31'
    }
    expected_cpu_facts = {}
    cpu_facts = hardware_obj.get_cpu_facts(collected_facts=collected_facts)
    assert cpu_facts == expected_cpu_facts
    # collect_facts = True
    collected_facts = {
        'ansible_architecture': 'ia64',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }

# Generated at 2022-06-11 02:40:54.684406
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    # mock the module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    module._ansible_facts = {
        'ansible_architecture': '9000/800',
        'ansible_distribution': 'HP-UX',
        'ansible_distribution_version': 'B.11.31'
    }

    hardware_collector = HPUXHardwareCollector(module=module)
    hardware_facts = hardware_collector.collect(module._ansible_facts, module)
    hardware_facts = hardware_facts['ansible_facts']
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['processor_cores'] == 8

# Generated at 2022-06-11 02:40:57.770739
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hw_collector = HPUXHardwareCollector()
    assert hw_collector is not None
    assert hw_collector._fact_class is not None
    assert hw_collector._platform is not None
    assert len(hw_collector.required_facts) > 0

# Generated at 2022-06-11 02:41:03.498754
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fact_instance = HPUXHardware()
    fact_instance.module = module
    fact_instance.populate({})
    facts = fact_instance.get_hw_facts()
    assert facts.get('model')
    assert facts.get("firmware_version") == "B.11.23"
    assert facts.get("product_serial") == "ABC0234"



# Generated at 2022-06-11 02:41:11.227023
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module_args = dict()
    module_args['ansible_architecture'] = 'ia64'
    module_args['ansible_distribution_version'] = 'B.11.31'
    hpux_module = AnsibleModule(argument_spec=module_args)
    hpux_hw = HPUXHardware(module=hpux_module)
    facts = hpux_hw.get_memory_facts()
    assert facts
    assert facts['swaptotal_mb'] == 512
    assert facts['memtotal_mb'] == 8192
    assert facts['swapfree_mb'] == 512
    assert facts['memfree_mb'] == 3884 


# Generated at 2022-06-11 02:41:16.159247
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    test_data = {
        'ansible_architecture': '9000/800',
        'ansible_distribution_version': 'B.11.23',
    }
    proc_count = HPUXHardware(provided_facts=test_data).get_cpu_facts()['processor_count']
    assert proc_count > 0

# Generated at 2022-06-11 02:41:20.159361
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = FakeAnsibleModule()
    Hardware = HPUXHardware()

    if Hardware.get_cpu_facts()['processor_count']:
        assert Hardware.get_cpu_facts()['processor_count'] > 0



# Generated at 2022-06-11 02:41:24.291743
# Unit test for constructor of class HPUXHardwareCollector
def test_HPUXHardwareCollector():
    hpux_hardware_collector = HPUXHardwareCollector()
    assert hpux_hardware_collector._fact_class is HPUXHardware
    assert 'platform' in hpux_hardware_collector._collected_facts
    assert 'distribution' in hpux_hardware_collector._collected_facts


# Generated at 2022-06-11 02:41:56.248787
# Unit test for method get_memory_facts of class HPUXHardware
def test_HPUXHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['all'], type='list')))
    module.exit_json(ansible_facts=dict(HPUXHardware().populate(
        collected_facts=dict(ansible_architecture='9000/800', ansible_distribution='HP-UX'))))



# Generated at 2022-06-11 02:42:06.140106
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    # set the values of the required facts for the given platform
    collected_facts = {'platform': 'HP-UX', 'distribution': 'HP-UX', 'ansible_architecture': 'ia64'}
    hardware = HPUXHardware(module=None)
    # get HP-UX HW facts
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts['firmware_version'] == 'B.11.31.1412'
    assert hw_facts['product_serial'] == 'CN7350S4S4'
    assert hw_facts['model'] == 'HP Integrity rx2800 i4'

# Generated at 2022-06-11 02:42:15.175122
# Unit test for method get_cpu_facts of class HPUXHardware
def test_HPUXHardware_get_cpu_facts():
    h = HPUXHardware()
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.23'}
    res = h.get_cpu_facts(collected_facts=collected_facts)
    assert res['processor_count'] == 20
    collected_facts = {'ansible_architecture': '9000/800', 'ansible_distribution_version': 'B.11.23'}
    res = h.get_cpu_facts(collected_facts=collected_facts)
    assert res['processor_count'] == 1
    collected_facts = {'ansible_architecture': 'ia64', 'ansible_distribution_version': 'B.11.31'}

# Generated at 2022-06-11 02:42:25.238603
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    HPUXHardware._module = MagicMock(run_command=MagicMock(return_value=(0, 'ia64', '')))
    HPUXHardware._module.run_command = MagicMock(return_value=(0, 'proliant bl460c', ''))
    HPUXHardware._module.run_command.side_effect = [(0, 'ia64', ''),
                                                    (0, 'proliant bl460c', ''),
                                                    (0, 'firmware_version: 2011.10.06', ''),
                                                    (0, 'firmware_version', ''),
                                                    (0, 'Machine serial number: SGH504H1VY', ''),
                                                    (0, 'Machine serial number', '')]

    hw = HPUXHardware(MagicMock())
    collected

# Generated at 2022-06-11 02:42:33.686142
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    module = MockModule()
    hardware = HPUXHardware(module)
    collected_facts = {'ansible_architecture': 'ia64',
                       'ansible_distribution': 'HP-UX',
                       'ansible_distribution_version': 'B.11.23',
                       }
    hw_facts = hardware.get_hw_facts(collected_facts=collected_facts)
    assert hw_facts == {'model': 'ia64 hp server',
                        'firmware_version': 'B.11.23',
                        }



# Generated at 2022-06-11 02:42:35.996649
# Unit test for method get_hw_facts of class HPUXHardware
def test_HPUXHardware_get_hw_facts():
    h = HPUXHardware({})
    facts = dict(ansible_architecture='ia64')
    h.populate(facts)
    assert h.facts == dict()

# Generated at 2022-06-11 02:42:39.168871
# Unit test for method populate of class HPUXHardware
def test_HPUXHardware_populate():
    module = MockModule()
    hardware = HPUXHardware(module=module)

    rc, out, err = module.run_command("ioscan -FkCprocessor | wc -l", use_unsafe_shell=True)

    assert out.strip() == str(hardware.facts['processor_count'])