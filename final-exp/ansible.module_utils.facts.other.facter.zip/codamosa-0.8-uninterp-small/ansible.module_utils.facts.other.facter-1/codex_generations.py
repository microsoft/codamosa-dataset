

# Generated at 2022-06-24 23:11:21.774176
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import FactCollector
    import ansible.module_utils.facts.namespace as ansible_namespace

    class TestModule(object):

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'cfacter':
                return '/bin/cfacter'
            elif executable == 'facter':
                return '/bin/facter'
            else:
                return None


# Generated at 2022-06-24 23:11:23.875184
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.collect()


# Generated at 2022-06-24 23:11:29.840431
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    facter_path = facter_fact_collector_1.find_facter(None)
    assert facter_path is not None


# Generated at 2022-06-24 23:11:31.949260
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    return_value = facter_fact_collector_0.get_facter_output()
    assert return_value is None


# Generated at 2022-06-24 23:11:38.422783
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    fixture_data = {
    }

    fixture_data['test_case_0'] = {}
    fixture_data['test_case_0']['module'] = MockModule()

    fixture_data['test_case_0']['exp_rc'] = None
    fixture_data['test_case_0']['exp_out'] = None
    fixture_data['test_case_0']['exp_err'] = None

    fixture_data['test_case_0']['exp_rc_cfacter'] = None
    fixture_data['test_case_0']['exp_out_cfacter'] = None
    fixture_data['test_case_0']['exp_err_cfacter'] = None

    fixture_data['test_case_0']['exp_rc_facter'] = None
    fixture_

# Generated at 2022-06-24 23:11:42.325999
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectionFailedError

    facter_fact_collector_0 = FacterFactCollector()
    module_0 = 1
    try:
        facter_fact_collector_0.collect(module=module_0)
    except CollectionFailedError:
        pass


# Generated at 2022-06-24 23:11:43.700467
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.collect()

# Generated at 2022-06-24 23:11:48.752612
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:11:50.623937
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() is None

# Generated at 2022-06-24 23:11:54.905077
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:12:01.630730
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:12:10.897045
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    class FakeModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, *args, **kwargs):
            return '/opt/puppetlabs/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_0_key":"facter_0_val"}', ""

    fake_module_0 = FakeModule()
    assert facter_fact_collector_0.get_facter_output(fake_module_0) == '{"facter_0_key":"facter_0_val"}'

    class FakeModule(object):
        def __init__(self):
            pass


# Generated at 2022-06-24 23:12:21.205999
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector(namespace='facter')
    facter_dict_0 = facter_fact_collector_0.collect()

    facter_fact_collector_1 = FacterFactCollector()
    facter_dict_1 = facter_fact_collector_1.collect()

    facter_fact_collector_2 = FacterFactCollector()
    facter_dict_2 = facter_fact_collector_2.collect()

    facter_fact_collector_3 = FacterFactCollector()
    facter_dict_3 = facter_fact_collector_3.collect()

    assert isinstance(facter_dict_0, (dict))
    assert isinstance(facter_dict_1, (dict))

# Generated at 2022-06-24 23:12:24.658390
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector(collectors=None, namespace=None)
    assert facter_fact_collector_0.find_facter() == 'facter'


# Generated at 2022-06-24 23:12:28.387605
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()

    if facter_fact_collector.find_facter(module='module') is not None:
        pass
    else:
        assert False



# Generated at 2022-06-24 23:12:30.015049
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    assert False


# Generated at 2022-06-24 23:12:35.747285
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    module = None
    actual_result = facter_fact_collector.get_facter_output(module)
    expected_result = None
    assert actual_result == expected_result, "Expected: %s, Actual: %s" % (expected_result, actual_result)

# Generated at 2022-06-24 23:12:42.351493
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output(None) is None

if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_get_facter_output()

# Generated at 2022-06-24 23:12:44.894381
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """Test method collect of class FacterFactCollector"""
    facter_fact_collector_0 = FacterFactCollector()
    actual = facter_fact_collector_0.collect()
    assert actual == {}


# Generated at 2022-06-24 23:12:49.667838
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    module = None
    facter_fact_collector_1.find_facter(module)


# Generated at 2022-06-24 23:13:03.585380
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class CustomModuleMock(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args_list = []
            self.run_command_return_value = [0, "Test return", ""]
            self.get_bin_path_count = 0
            self.get_bin_path_args_list = []
            self.get_bin_path_return_value = "/bin/facter"

        def run_command(self, args):
            self.run_command_count += 1
            self.run_command_args_list.append(args)
            return self.run_command_return_value

        def get_bin_path(self, executable, opt_dirs=[]):
            self.get_bin_path_count += 1
            self.get

# Generated at 2022-06-24 23:13:08.720720
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    result_1 = facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:13:11.115503
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_dict = facter_fact_collector_0.collect()
    assert facter_dict is not None


# Generated at 2022-06-24 23:13:17.244499
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    find_facter_path = find_facter()
    assert isinstance(facter_fact_collector_1.find_facter(), type(find_facter_path))


# Generated at 2022-06-24 23:13:22.829353
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import AnsibleModuleStub

    facter_fact_collector_0 = FacterFactCollector()

    ansible_module_0 = AnsibleModuleStub()

    return_value_0 = facter_fact_collector_0.find_facter(ansible_module_0)

    assert return_value_0 is None

    #
    # cleanup - done manually in this test case, because we don't want to rely on
    # AnsibleModuleStub.cleanup() removal of temp files
    #
    ansible_module_0.exit_json_called = False
    ansible_module_0.fail_json_called = False
    ansible_module_0._ansible_module = None
    ansible_module_0.params = None
    ansible_module

# Generated at 2022-06-24 23:13:30.131323
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import AnsibleFallbackNotFound

    # Tests where facter is not installed should not error.
    module_0 = AnsibleFallbackNotFound()
    module_0.get_bin_path = lambda *args, **kwargs: None

    facter_fact_collector_0 = FacterFactCollector()
    ans = facter_fact_collector_0.collect(module=module_0)

    assert ans == {}


# Generated at 2022-06-24 23:13:38.773529
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test: Nominal case.  This test case uses the same Ruby version and
    #       facter version as used in Travis CI to test Ansible:
    #
    # Version: ruby 2.1.9p490 (2016-03-30 revision 54437) [x86_64-linux]
    # Version: facter 2.4.4
    #
    # If a change to the underlying Ruby or facter causes the JSON formatter to
    # change and break this test, it may be necessary to update the test to reflect
    # the facter version that later ships with the Ruby version.
    #
    # Initialize facter_fact_collector_0
    facter_fact_collector_0 = FacterFactCollector()

    # Create a module object for use by get_facter_output
    # Create an instance of the module_

# Generated at 2022-06-24 23:13:43.852252
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    facter_fact_collector_1 = FacterFactCollector()
    m_1 = MockModuleWithAttrs()
    r_1 = facter_fact_collector_1.find_facter(m_1)

    assert r_1 == '/usr/bin/facter'
# end test_FacterFactCollector_find_facter


# Generated at 2022-06-24 23:13:53.083014
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    import ansible_module_mock
    facter_fact_collector_0.module = ansible_module_mock.MockModule()
    facter_fact_collector_0.module.get_bin_path = lambda *args, **kwargs: 'facter'
    facter_fact_collector_0.module.run_command = lambda *args, **kwargs: (0, '{"is_virtual":true}', '')
    assert facter_fact_collector_0.get_facter_output(facter_fact_collector_0.module) == '{"is_virtual":true}'


# Generated at 2022-06-24 23:13:58.609796
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create a FacterFactCollector instance
    facter_fact_collector_0 = FacterFactCollector()
    # Initialize the module mock object
    # Initialize parameter 'module'
    module = None
    # Invoke method
    c_retval = facter_fact_collector_0.get_facter_output(module)
    # Check return value
    assert c_retval is None



# Generated at 2022-06-24 23:14:05.657245
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    y = facter_fact_collector_0.get_facter_output(None)


# Generated at 2022-06-24 23:14:08.091141
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    result = facter_fact_collector_0.collect(facter_fact_collector_1)

# Generated at 2022-06-24 23:14:10.433892
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    # Just use the default module which should have facter installed
    module_0 = None
    facter_output_0 = facter_fact_collector_0.get_facter_output(module_0)
    assert json.loads(facter_output_0)



# Generated at 2022-06-24 23:14:20.458094
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """Check whether run_facter method returns correct output"""

    # Module is an object with only the following functions requried:
    #  get_bin_path which returns the first executable found
    #  run_command which executes a command and returns (rc, out, err)
    #  to mock a run_command, we need a method which returns (rc, out, err) based on
    #  command run

    class fake_module:
        def get_bin_path(self, bin_name, opt_dirs=None):
            return '/opt/puppetlabs/bin/' + bin_name
        def run_command(self, cmd, args='', check_rc=False):
            # TODO: decide what to do with check_rc
            print('Command run: %s %s' % (cmd, args))

# Generated at 2022-06-24 23:14:23.687173
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    rc, out, err = module.run_command("which facter")
    assert rc == 0
    assert facter_fact_collector_0.find_facter("ansible.module_utils.facts.collector.BaseFactCollector") == rc

# Generated at 2022-06-24 23:14:32.205780
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    # Setup the test
    name = 'facter'
    path = '/usr/bin/facter'

    # Mock the module
    module = ModuleMock()

    # Instantiate the object and call the method
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.module = module
    output = facter_fact_collector.run_facter(module, path)
    facts = json.loads(output[1])

    # Assertions
    assert output[0] == 0
    assert output[2] == ''
    assert 'architecture' in facts
    assert 'facterversion' in facts
    assert 'kernel' in facts
    assert 'kernelmajversion' in facts
    assert 'kernelrelease' in facts
    assert 'kernelversion' in facts

# Generated at 2022-06-24 23:14:34.381148
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    assert FactFacterCollector().find_facter('module') is not None

# Generated at 2022-06-24 23:14:36.815867
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector.find_facter(None)
    assert facter_path is not None


# Generated at 2022-06-24 23:14:43.693561
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:14:44.557018
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
  facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:14:56.892965
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    test_facter = dict()
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output(test_facter)
    assert(True)


# Generated at 2022-06-24 23:14:59.026203
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:15:03.865416
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output() == None


# Generated at 2022-06-24 23:15:06.966958
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    collected_facts_1 = {}
    collected_facts_2 = facter_fact_collector_1.collect(collected_facts=collected_facts_1)
    assert collected_facts_2 == {}, 'Test Failed: collected_facts_2 is not {}'



# Generated at 2022-06-24 23:15:12.400334
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    ansible_module_0 = AnsibleModule(
        argument_spec={}
    )
    facter_fact_collector_1.find_facter(ansible_module_0)


# Generated at 2022-06-24 23:15:18.820754
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    FacterFactCollector_run_facter_0 = FacterFactCollector()
    assert FacterFactCollector_run_facter_0.run_facter() == 'FacterFactCollector.run_facter'


# Generated at 2022-06-24 23:15:25.685816
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facts = facter_fact_collector_1.collect()
    assert facts == {'facter': {'ipaddress': '10.79.157.76', 'kernel': 'Darwin', 'macaddress': '00:0c:29:4e:4c:79'}}

# AnsibleModule test case

# Generated at 2022-06-24 23:15:31.081252
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    try:
        assert False, "Expected NotImplementedError, but no exception was raised"
    except NotImplementedError as e:
        pass


# Generated at 2022-06-24 23:15:37.500905
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    module_0 = ansible_facter_0
    facter_fact_collector_0.get_facter_output(module_0)
    facter_fact_collector_1.get_facter_output(module_0)


# Generated at 2022-06-24 23:15:44.464606
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()

    # Make sure the facter_path is None when the command is not found
    class TestModule:
        def get_bin_path(self, name, **kwargs):
            return None

    test_module = TestModule()
    facter_path = facter_fact_collector.find_facter(test_module)

    assert not facter_path, \
        "FacterFactCollector.find_facter returned a value when it expected None"


# Generated at 2022-06-24 23:16:10.172205
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    class ModuleStub():
        def get_bin_path(self, executable, opt_dirs=None):
            if executable == 'facter':
                return '/usr/bin/facter'
            if executable == 'cfacter':
                return None

        def run_command(self, command):
            if command == '/usr/bin/facter --puppet --json':
                return 0, '{}', ''
            if command == '/usr/bin/facter --puppet --json --external-dir /opt/puppetlabs/facter/facts.d':
                return 0, '{}', ''
            if command == '/usr/bin/cfacter --puppet --json':
                return 0, '{}', ''

    module_stub = ModuleSt

# Generated at 2022-06-24 23:16:12.860494
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_base = FacterFactCollector()
    facter_fact_collector_base.get_facter_output(module)

# Generated at 2022-06-24 23:16:13.887071
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    test_case = FacterFactCollector()


# Generated at 2022-06-24 23:16:17.707995
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO: Implement test_FacterFactCollector_get_facter_output
    pass


# Generated at 2022-06-24 23:16:18.673133
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()


# Generated at 2022-06-24 23:16:20.735004
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()



# Generated at 2022-06-24 23:16:22.205802
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:16:24.764254
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # TODO: create a class mock for module
    module = None
    facter_fact_collector = FacterFactCollector()
    ret_val = facter_fact_collector.find_facter(module)


# Generated at 2022-06-24 23:16:28.135501
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Arrange
    facter_fact_collector = FacterFactCollector()

    # Act
    result = facter_fact_collector.get_facter_output(None)

    # Assert
    assert (result is None)



# Generated at 2022-06-24 23:16:33.283395
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts_0 = {}
    collected_facts_0.update({})
    facts_dict_0 = facter_fact_collector_0.collect(collected_facts=collected_facts_0)
    print("Facter Fact Dict: %s" % facts_dict_0)


# Generated at 2022-06-24 23:17:26.206464
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = MockModule()
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.find_facter = Mock(return_value='/usr/bin/facter')
    facter_fact_collector.run_facter = Mock(return_value=(0, 'facter json output', ''))

    result = facter_fact_collector.get_facter_output(module)
    assert result == 'facter json output'


# Generated at 2022-06-24 23:17:32.135952
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    out = facter_fact_collector_0.get_facter_output()
    return out

if __name__ == '__main__':
    test_case_0()
    # test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()
    # test_case_5()
    # test_case_6()
    # test_case_7()
    # test_case_8()
    # test_FacterFactCollector_get_facter_output()

# Generated at 2022-06-24 23:17:38.544659
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_collector_mock = Mock()
    facter_collector_mock.run_command.return_value = (0, '{ "architecture" : "i386" }', '')
    facter_collector_mock.get_bin_path.return_value = '/usr/local/bin/facter'
    facter_result = facter_fact_collector.get_facter_output(facter_collector_mock)
    assert facter_result == '{ "architecture" : "i386" }'


# Generated at 2022-06-24 23:17:40.805376
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

    # Test if no argument was passed
    assert facter_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:17:49.380174
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Instantiating Facter Fact Collector
    facter_fact_collector = FacterFactCollector()
    print("Testing find_facter() ", end='')
    facter_path = facter_fact_collector.find_facter()
    # If Facter is not installed
    if facter_path is None:
        print("FAILED")
        return
    # If Facter is installed, but ruby-json dependency is not satisfied
    if facter_path:
        if facter_path.endswith('facter'):
            print("FAILED")
            return
    print("PASSED")


# Generated at 2022-06-24 23:17:51.908987
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    output = facter_fact_collector.get_facter_output()
    assert output == None


# Generated at 2022-06-24 23:18:00.705223
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts = dict()
    module = None

    # call method FacterFactCollector.get_facter_output with arguments module=module
    facter_output = facter_fact_collector_0.get_facter_output(module=module)

    # call method FacterFactCollector.collect with arguments module=module, collected_facts=collected_facts
    facter_dict = facter_fact_collector_0.collect(module=module, collected_facts=collected_facts)

    # No assert
    pass


# Generated at 2022-06-24 23:18:02.889874
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output(None)



# Generated at 2022-06-24 23:18:03.959558
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    # TODO: write unit test


# Generated at 2022-06-24 23:18:06.153358
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector.find_facter(None)
    assert facter_path is not None


# Generated at 2022-06-24 23:19:56.098280
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    mock_module = MockModule({}, {}, {}, {}, None)
    facter_fact_collector_0 = FacterFactCollector()
    facter_path_0 = facter_fact_collector_0.find_facter(mock_module)
    return facter_path_0 == '/bin/facter'


# Generated at 2022-06-24 23:20:06.455274
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class ModuleMock(object):
        # Mocks the method get_bin_path()

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/opt/puppetlabs/bin/facter'
            else:
                return None

        # Mocks the method run_command()

        def run_command(self, cmd):
            return 0, json.dumps({'facter_mock_key': 'facter_mock_value'}), ''

    class FacterFactCollectorMock(FacterFactCollector):

        def __init__(self):
            super(FacterFactCollectorMock, self).__init__()
            self.module = ModuleMock()


# Generated at 2022-06-24 23:20:09.427869
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    param_0 = None
    facter_fact_collector.find_facter(param_0)


# Generated at 2022-06-24 23:20:13.034208
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1 is not None
    # TODO: tests


# Generated at 2022-06-24 23:20:17.044016
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert False  # TODO: implement your test here


# Generated at 2022-06-24 23:20:20.512735
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector_0 = FactsCollector()
    facter_fact_collector_0 = FacterFactCollector(collectors=[facts_collector_0])
    facter_fact_collector_0.collect()

# Generated at 2022-06-24 23:20:28.280302
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # test for signature (module)
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = '/opt/puppetlabs/bin/facter'
    facter_fact_collector_0 = FacterFactCollector()
    result = facter_fact_collector_0.get_facter_output(module_mock)
    assert result == '{}\n'


# Generated at 2022-06-24 23:20:31.262877
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # arrange
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = None

    # act
    facter_path = facter_fact_collector_0.find_facter(module_0)

    # assert
    # TODO: check the value of facter_path



# Generated at 2022-06-24 23:20:35.484323
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:20:38.410319
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    print("\n")
    facter_fact_collector = FacterFactCollector()
    facter_dict = facter_fact_collector.get_facter_output()
    print(facter_dict)
