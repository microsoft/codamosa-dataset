

# Generated at 2022-06-24 23:11:19.468859
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    import os
    import shutil

    # Do this so we dont hit the system facter command
    # and maybe not have the JSON fact installed
    facter_bin_path = "/tmp/facter_ansible_test"
    facter_script = b"""#!/bin/sh
printf "{"
printf "\"virtual\":\"physical\""
printf "}"
"""

    with open(facter_bin_path, 'wb') as facter_fh:
        facter_fh.write(facter_script)

    os.chmod(facter_bin_path, 0o755)

    class MockModule:
        def get_bin_path(self, exe, opt_dirs=None):
            return facter_bin_path


# Generated at 2022-06-24 23:11:22.050710
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.find_facter() is None


# Generated at 2022-06-24 23:11:24.474027
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output(None)


# Generated at 2022-06-24 23:11:27.130905
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facter_dict_1 = {}
    assert facter_dict_1 == facter_fact_collector_1.collect()

# Generated at 2022-06-24 23:11:28.562754
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector


# Generated at 2022-06-24 23:11:30.630669
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module = None
    assert facter_fact_collector_0.get_facter_output(module) == None


# Generated at 2022-06-24 23:11:39.639337
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    # method find_facter accepts missing module arguement - would fail without stub
    facter_fact_collector_0.find_facter()

    # method find_facter rejects invalid types for module arguement - would fail without stub
    try:
        facter_fact_collector_0.find_facter(module='invalid')
    except TypeError:
        pass



# Generated at 2022-06-24 23:11:42.573982
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    test_module_0 = None
    assert facter_fact_collector_0.get_facter_output(test_module_0) is None



# Generated at 2022-06-24 23:11:48.251852
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect() is None


# Generated at 2022-06-24 23:11:50.826201
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_collect_0 = FacterFactCollector()

    # Test with valid input
    facter_fact_collector_collect_0.collect()



# Generated at 2022-06-24 23:12:01.068467
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = "/usr/bin/facter"
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.find_facter(mock_module) == "/usr/bin/facter"


# Generated at 2022-06-24 23:12:05.732979
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = None
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output(module_0) == None


# Generated at 2022-06-24 23:12:06.410019
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    # DONE: write some tests for this method

    return None

# Generated at 2022-06-24 23:12:09.764216
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    collected_facts = {}
    module = None
    result = facter_fact_collector_1.collect(module=module, collected_facts=collected_facts)
    print(result)


# Generated at 2022-06-24 23:12:13.516547
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    m0 = MockModule_0()
    facter_path_0 = facter_fact_collector_0.find_facter(m0)
    assert facter_path_0 is '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-24 23:12:18.775509
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    from ansible.module_utils.facts.collector import MockModule
    mock_module = MockModule('/test/test_FacterFactCollector_find_facter')
    assert facter_fact_collector_0.find_facter(mock_module) is None


# Generated at 2022-06-24 23:12:27.132284
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # FIXME: IMO, this is too complex, and we should not need to mock/stub
    # so many things...
    module_1 = MagicMock()
    module_1.get_bin_path.return_value = "/bin/facter"

# Generated at 2022-06-24 23:12:29.601577
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass

# Generated at 2022-06-24 23:12:30.664875
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:12:33.661962
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    # TODO: implement test
    assert facter_fact_collector.find_facter(None) == None



# Generated at 2022-06-24 23:12:39.640321
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test if return type is dictionary
    assert isinstance(FacterFactCollector().collect(), dict)

# Generated at 2022-06-24 23:12:48.099287
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class Module0():
        def __init__(self):
            self.params = {'warn': False, '_ansible_verbosity': 0, '_ansible_check_mode': False, '_ansible_no_log': False}
            self.check_mode = False
            self.debug = False
            self.environment = {'HOME': '/root', 'TERM': 'xterm', 'USER': 'root', 'LANG': 'en_US.UTF-8', 'PATH': '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin', 'HOSTNAME': 'localhost', 'PWD': '/', 'SHLVL': '2', 'OLDPWD': '/tmp'}

# Generated at 2022-06-24 23:12:49.030046
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # FIXME
    pass


# Generated at 2022-06-24 23:12:53.759412
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()

    # AssertionError: "'module' is a required argument"
    try:
        facter_fact_collector_0.run_facter()
        assert False, "Expected the call to fail"
    except AssertionError as e:
        assert str(e) == "'module' is a required argument"


# Generated at 2022-06-24 23:12:56.057290
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:13:05.815999
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Create a mock module object
    mock_module = MockModule()
    facter_fact_collector_0 = FacterFactCollector()
    # Test that find_facter, when the 'facter' and 'cfacter' bin paths are not found, returns None
    assert facter_fact_collector_0.find_facter(mock_module) is None
    # Set the 'facter' and 'cfacter' bin paths of mock_module to return a path
    mock_module.run_command.return_value = (0, '/path/to/facter', '')
    # Test that find_facter, when the 'cfacter' bin path is not found, returns '/path/to/facter'

# Generated at 2022-06-24 23:13:13.042046
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    mock_module = MockModule()

    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.find_facter = Mock(return_value=None)
    mock_module.run_command = Mock(return_value=(0, "JSON DATA", ""))
    facter_output = facter_fact_collector.get_facter_output(mock_module)

    assert facter_fact_collector.find_facter.call_count == 1
    assert facter_output == "JSON DATA"

    mock_module = MockModule()

    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.find_facter = Mock(return_value=None)

# Generated at 2022-06-24 23:13:14.853533
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.find_facter() == None


# Generated at 2022-06-24 23:13:22.344613
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector(collectors=[])
    facter_fact_collector_2 = FacterFactCollector(namespace=PrefixFactNamespace())

    # The method read should be return None since the method
    # find_facter return None
    assert facter_fact_collector_0.find_facter(module=dict()) is None

    # The method read should be return None since the method
    # find_facter return None
    assert facter_fact_collector_1.find_facter(module=dict()) is None

    # The method read should be return None since the method
    # find_facter return None

# Generated at 2022-06-24 23:13:29.995824
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    facter_fact_collector = FacterFactCollector()
    class DummyModule(object):
        def get_bin_path(self, command, opt_dirs=None):
            return '/usr/bin/facter'
        def run_command(self, command):
            return (0, '{"os": {"family": "RedHat", "name": "CentOS", "release": {"full": "7.5.1804", "major": "7", "minor": "5"}, "selinux": {"config_mode": "enforcing", "current_mode": "enforcing", "enabled": true, "enforced": true, "policy_version": "28", "type": "targeted"}}}', '')
    facter_output = facter_

# Generated at 2022-06-24 23:13:47.399927
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # parametrized test, no arg value means use default
    # this test uses the default argument values
    # and will run once no matter the parametrization.
    # this is the default now.
    params = (
        (None, None, ),  # case 0
    )
    def do_test(param_tuple):
        (ansible_module_mock, ) = param_tuple
        facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:13:50.381300
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_get_facter_output_0 = FacterFactCollector()



# Generated at 2022-06-24 23:13:54.069797
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    print('%s collect: %s' % (facter_fact_collector_0.name, facter_fact_collector_0.collect()))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:14:03.518925
# Unit test for method get_facter_output of class FacterFactCollector

# Generated at 2022-06-24 23:14:05.845535
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    str_0 = facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:14:09.680516
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0_find_facter_0 = facter_fact_collector_0.find_facter()
    assert facter_fact_collector_0_find_facter_0 is not None


# Generated at 2022-06-24 23:14:13.644190
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.find_facter(module=None) is None


# Generated at 2022-06-24 23:14:22.141467
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # make sure we have an importable module
    from ansible.module_utils.facts.collector import BaseFactCollector
    facter_fact_collector_3 = FacterFactCollector()
    class ModuleUtilMock(object):
        def run_command(self, command):
            return (0, '{"fact1": "value1", "fact2": "value2"}', None)
        def get_bin_path(self, command, opt_dirs=None):
            return '/path/to/facter'
    module_util_mock = ModuleUtilMock()
    assert facter_fact_collector_3.run_facter(module_util_mock, '/path/to/facter') == (0, '{"fact1": "value1", "fact2": "value2"}', None)


# Generated at 2022-06-24 23:14:29.990717
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_1 = FacterFactCollector()
    module_1 = FacterFactCollector()
    facter_path_1 = '/usr/local/bin/cfacter'
    rc_1, out_1, err_1 = facter_fact_collector_1.run_facter(module_1, facter_path_1)
    assert rc_1 == 0
    assert out_1 == '{}\n'
    assert err_1 == ''

# Generated at 2022-06-24 23:14:35.525974
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() == None


# Generated at 2022-06-24 23:14:55.191714
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass


# Generated at 2022-06-24 23:15:04.003908
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    class Module(object):

        def get_bin_path(self, arg_0, arg_1=None):

            # if arg_0 == 'cfacter':
            #     return '/opt/puppetlabs/bin/cfacter'
            # else:
            #     return '/opt/puppetlabs/bin/facter'
            return None


# Generated at 2022-06-24 23:15:05.465131
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:15:14.774049
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    f_f_c_1_facter_facts = facter_fact_collector_1.collect()
    # TODO: check that f_f_c_1_facter_facts is not empty?
    print('f_f_c_1_facter_facts: %s' % (f_f_c_1_facter_facts))


if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:15:16.926982
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    assert(facter_fact_collector_0.get_facter_output is not None)


# Generated at 2022-06-24 23:15:26.975721
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from unittest import mock
    from ansible.module_utils.facts.utils import get_file_content
    facter_fact_collector_0_obj = FacterFactCollector()
    facter_fact_collector_0_module = mock.MagicMock()
    facter_fact_collector_0_module.run_command.return_value = [0, get_file_content('test/unit/unit/module_utils/facts/test_collector/facter_output'), ""]
    assert facter_fact_collector_0_obj.get_facter_output(facter_fact_collector_0_module) == get_file_content('test/unit/unit/module_utils/facts/test_collector/facter_output')


# Generated at 2022-06-24 23:15:31.760214
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output()


# Generated at 2022-06-24 23:15:41.402228
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    params = dict()
    fixture_path = os.path.join(FIXTURE_DIR, 'facter_out')
    with open(fixture_path, 'r') as fixture_file:
        params['stdout'] = fixture_file.read()
    params['stdout_lines'] = params['stdout'].splitlines()
    params['stderr'] = ''
    params['changed'] = False
    params['failed'] = False
    params['rc'] = 0

    mock_module = MockModule(**params)

    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.find_facter = Mock(return_value='/usr/bin/facter')

# Generated at 2022-06-24 23:15:46.109090
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.fact_ids == set(['facter'])
    assert isinstance(facter_fact_collector_0.namespace, PrefixFactNamespace)
    assert facter_fact_collector_0.namespace.namespace_name == 'facter'
    assert facter_fact_collector_0.namespace.prefix == 'facter_'

# Generated at 2022-06-24 23:15:50.180707
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_dict_0 = facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:16:33.704306
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    result_0 = facter_fact_collector_0.collect(module=None)


# Generated at 2022-06-24 23:16:44.471823
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    def fake_find_facter():
        return '/usr/bin/facter'
    def fake_get_bin_path(arg_1):
        assert arg_1 == 'facter'
        return '/usr/bin/facter'
    def fake_run_command(arg_1):
        assert arg_1 == '/usr/bin/facter --puppet --json'
        return None, "{}", None
    class MockModule(object):
        def __init__(self):
            self.fake_run_command=fake_run_command
            self.fake_get_bin_path=fake_get_bin_path
        def get_bin_path(self, arg):
            return self.fake_get_bin_path(arg)
        def run_command(self, arg):
            return self.fake_run_command

# Generated at 2022-06-24 23:16:45.464981
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    try:
        facter_fact_collector_0 = FacterFactCollector()
    except:
        assert True


# Generated at 2022-06-24 23:16:48.920958
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    collected_facts = facter_fact_collector.collect()
    assert collected_facts == {}

# Generated at 2022-06-24 23:16:53.327178
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()

    # TODO: use mock.patch here
    class Module(object):
        def get_bin_path(self, bin, opt_dirs=None):
            return 'get_bin_path'

        def run_command(self, cmd):
            return 0, 'run_command', ''

    facter_fact_collector_1.get_facter_output(Module())


# Generated at 2022-06-24 23:17:02.659309
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create a stub module
    module_stub = AnsibleModuleStub('linux', 'ansible_system', 'x86_64')

    # Create a list of stub facts
    collected_facts_stub = {}

    # Create a stub FacterFactCollector
    facter_fact_collector_stub = FacterFactCollector(collectors=None, namespace=None)

    # Create a stub facter
    facter_stub = '{"facter":{"version":"2.4.6"}}'

    # Configure stubs
    def stub_find_facter(module):
        return True

    def stub_run_facter(module, facter_path):
        return 0, facter_stub, ''

    facter_fact_collector_stub.find_facter = stub_find_facter


# Generated at 2022-06-24 23:17:11.442236
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    from ansible.module_utils.basic import AnsibleModule

    facter_fact_collector_0 = FacterFactCollector()

    class MockAnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = args[0]
            self.args = args
            self.kwargs = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception("fail_json called")

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


# Generated at 2022-06-24 23:17:14.522389
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    x = BaseFactCollector()
    f = BaseFactCollector.find_facter(x, None)
    assert f is None, "f is None."



# Generated at 2022-06-24 23:17:14.953501
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass

# Generated at 2022-06-24 23:17:25.320286
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    test_module = FakeModule()

    facter_fact_collector_1 = FacterFactCollector()
    facter_output = """{
        "operatingsystem": "RedHat",
        "cpu": "Intel(R) Xeon(R) CPU E5-2690 v2 @ 3.00GHz",
        "puppetversion": "3.4.3"
    }"""

    facter_fact_collector_1.get_facter_output = FakeFacter(facter_output)

    facter_facts = facter_fact_collector_1.collect(module=test_module)

    assert facter_facts['facter_operatingsystem'] == 'RedHat'

# Generated at 2022-06-24 23:19:10.304363
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    mock_module = type('', (), {})()
    mock_module.get_bin_path = None
    mock_module.run_command = None
    facter_fact_collector.get_facter_output(mock_module)

# Generated at 2022-06-24 23:19:13.968073
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    # Create a fixture for the TestModule class
    mock_test_module_fixture_1 = Mock()

    # Call the method under test
    facter_fact_collector_1 = FacterFactCollector()
    result = facter_fact_collector_1.find_facter(mock_test_module_fixture_1)

    # Check that the result is as expected
    assert result == '/usr/bin/facter'



# Generated at 2022-06-24 23:19:20.255910
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test without a module parameter
    # This will fail if it tries to execute facter because the module_utils
    # class isn't defined.  See:
    # https://github.com/ansible/ansible/issues/22913
    facter_fact_collector_0 = FacterFactCollector()
    facter_output_0 = facter_fact_collector_0.get_facter_output(None)
    assert facter_output_0 is None

# Generated at 2022-06-24 23:19:26.180125
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # create a module instance
    module = AnsibleModule(argument_spec={})

    # get the path of facter or cfacter command
    facter_path = module.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
    cfacter_path = module.get_bin_path('cfacter', opt_dirs=['/opt/puppetlabs/bin'])

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class FacterFactCollectorTest(unittest.TestCase):
        def runTest(self):
            # Prefer to use cfacter if available
            if cfacter_path is not None:
                self.assertEqual(facter_path, cfacter_path)

# Generated at 2022-06-24 23:19:36.732410
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class fake_module_0():
        def __init__(self, search_paths):
            self.search_paths = search_paths
            self.params = {}
            self.args = {}
        def fail_json(self, msg):
            raise Exception()
        def get_bin_path(self, path, opt_dirs=None, required=False, check_sudo=False, vim=None):
            try:
                return search_paths[path]
            except KeyError:
                raise Exception()
    search_paths = {
        'facter': '/opt/puppetlabs/bin/facter',
        'cfacter': '/opt/puppetlabs/bin/cfacter',
    }
    fake_module_0_

# Generated at 2022-06-24 23:19:41.194536
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    test_cases = [[{'ansible_facter': {'facter_foo': 'bar',
                                      'facter_baz': 'quux'}}]]
    for test_case in test_cases:
        assert facter_fact_collector_0.collect() == test_case


# Generated at 2022-06-24 23:19:43.215294
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output(module) == None


# Generated at 2022-06-24 23:19:49.265005
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = AnsibleModule(argument_spec=dict())
    module_0.params['path'] = ['/usr/bin', '/usr/sbin']
    result_0 = facter_fact_collector_0.get_facter_output(module_0)
    assert result_0 == None

# Generated at 2022-06-24 23:19:55.673206
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    module_1 = None
    if True:  # Just to get rid of the warning
        facter_fact_collector_1.FacterFactCollector__metaclass__.__name__ = '__test__'
        facter_fact_collector_1.FacterFactCollector__module = module_1
        # Can't set attributes on a class
        #facter_fact_collector_1.__module = module_1
        #facter_fact_collector_1.collector_name = '__test__'
        #facter_fact_collector_1.collectors = {'__test__': module_1}

    facter_fact_collector_1.get_facter_output(module_1)


# Unit test

# Generated at 2022-06-24 23:20:02.122757
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    test_module_0 = {'get_bin_path': get_bin_path_0,
                     'run_command': run_command_0}

    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter(test_module_0, '/opt/puppetlabs/bin/cfacter')

