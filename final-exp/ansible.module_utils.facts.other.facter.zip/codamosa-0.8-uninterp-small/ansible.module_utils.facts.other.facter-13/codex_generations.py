

# Generated at 2022-06-24 23:11:21.940512
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:11:25.734920
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.find_facter(testcase_get_bin_path_data)


# Generated at 2022-06-24 23:11:26.373650
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    pass


# Generated at 2022-06-24 23:11:28.440472
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:11:32.400946
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    class fake_module:
        def get_bin_path(self, binary_name, opt_dirs=None):
            return '/usr/bin/facter'
    module_0 = fake_module()
    assert facter_fact_collector_1.find_facter(module_0) == '/usr/bin/facter'


# Generated at 2022-06-24 23:11:36.649485
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    result = facter_fact_collector_0.find_facter('module')
    assert result is not False

# Generated at 2022-06-24 23:11:41.744600
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance

    facter_fact_collector_1 = get_collector_instance('FacterFactCollector')
    facter_fact_collector_1.run_facter(None, '')


# Generated at 2022-06-24 23:11:46.563887
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    def run_facter(facter_path):
        return 0, '{ "os.version": "6.7.2874.34", "kernel.version": "2.4.7-10" }', None
    facter_fact_collector.run_facter = run_facter
    def find_facter(module):
        return True
    facter_fact_collector.find_facter = find_facter
    class ModuleObj:
        pass
    module_obj = ModuleObj()
    facter_fact_collector.get_facter_output(module_obj)


# Generated at 2022-06-24 23:11:49.214023
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = None
    facter_fact_collector_0 = FacterFactCollector()

    facter_output = facter_fact_collector_0.get_facter_output(module)


# Generated at 2022-06-24 23:11:59.843141
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    """
    This function is used to test the get_facter_output of class FacterFactCollector.
    """
    mock_module_1 = MockAnsibleModule
    mock_module_1.get_bin_path.return_value = '/opt/puppetlabs/bin/facter'
    mock_module_1.run_command.return_value = (0, "", '')
    facter_fact_collector_2 = FacterFactCollector()
    result_facter_output = facter_fact_collector_2.get_facter_output(mock_module_1)
    assert result_facter_output == ''

    mock_module_2 = MockAnsibleModule

# Generated at 2022-06-24 23:12:05.116235
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()
    assert(facter_fact_collector.run_facter(None, "/usr/bin/facter") is None)

# Generated at 2022-06-24 23:12:06.934844
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output()

# Generated at 2022-06-24 23:12:10.306383
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector_collect = facter_fact_collector.collect()
    assert facter_fact_collector_collect == {}, "Test Failed: dict() != dict()"


# Generated at 2022-06-24 23:12:11.420187
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass


# Generated at 2022-06-24 23:12:20.694910
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = object()
    modules_0 = object()
    collector_0 = FacterFactCollector(collectors=modules_0)
    module_0.get_bin_path = lambda x=None, opt_dirs=None: 'cfacter'
    modules_0.run_command = lambda x=None, encoding=None, errors=None, rc_verbosity=None, binary=None: ('command_0', 'stdout_0', 'stderr_0')
    result_0 = facter_fact_collector_0.get_facter_output(module_0)
    assert result_0 is None



# Generated at 2022-06-24 23:12:28.522647
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils._text import to_bytes

    # Mock module class
    class MockModule:
        def __init__(self):
            self.params = { }

        def get_bin_path(self, arg1, opt_dirs=None):
            return '/path/to/facter'

    facter_fact_collector = FacterFactCollector()

    # Make sure we return find_facter
    assert facter_fact_collector.find_facter(MockModule()) == '/path/to/facter'


# Generated at 2022-06-24 23:12:31.763367
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:12:34.158188
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_obj_0 = FacterFactCollector()
    facter_fact_collector_obj_0.get_facter_output()

# Generated at 2022-06-24 23:12:37.779296
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    pass


# Generated at 2022-06-24 23:12:38.868935
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:12:54.725270
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import _setup_collector, _remove_collector
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    namespace = PrefixFactNamespace(namespace_name='facter', prefix='facter_')
    facter_fact_collector_0 = FacterFactCollector(namespace=namespace)

    assert facter_fact_collector_0.name == 'facter'

    assert facter_fact_collector_0._fact_ids == set(['facter'])

    _setup_collector(facter_fact_collector_0, namespace=namespace)


# Generated at 2022-06-24 23:13:01.516918
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_module_0 = FakeAnsibleModule()
    ansible_module_0.get_bin_path_return_value = '/usr/local/bin/facter'
    facter_fact_collector_1 = FacterFactCollector()
    ansible_module_1 = FakeAnsibleModule()
    ansible_module_1.get_bin_path_return_value = None
    facter_fact_collector_2 = FacterFactCollector()
    ansible_module_2 = FakeAnsibleModule()
    ansible_module_2.get_bin_path_return_value = '/usr/local/bin/facter'
    facter_fact_collector_3 = FacterFactCollector()
    ansible_

# Generated at 2022-06-24 23:13:02.081380
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    pass

# Generated at 2022-06-24 23:13:12.299378
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    def get_bin_path(self, exe=None, opt_dirs=[]):
        return "/usr/bin/facter"

    class Module(object):
        def __init__(self):
            self.run_command_result = (0, '{"facter_uptime": {"seconds": 17984, "hours": 5, "days": 0, "uptime": "5 hours", "uptime_seconds": 17984}}')
        
        def run_command(self, value):
            return self.run_command_result
    
        def get_bin_path(self, exe=None, opt_dirs=[]):
            return "/usr/bin/facter"
    
    module = Module()
    facter_fact_collector_0 = FacterFactCollector()
    result = facter_fact

# Generated at 2022-06-24 23:13:15.176943
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:13:19.223189
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

# Generated at 2022-06-24 23:13:23.778487
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    module = Mock()
    module.get_bin_path = Mock(return_value='/opt/puppetlabs/bin/cfacter')
    result_0 = facter_fact_collector_1.find_facter(module)
    assert result_0 == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-24 23:13:26.508087
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    fake_module_0 = FakeModule()
    facter_fact_collector_0 = FacterFactCollector()

    facter_fact_collector_0.collect(module=fake_module_0, collected_facts=None)

# Generated at 2022-06-24 23:13:37.555488
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    '''Test get_facter_output of class FacterFactCollector '''
    if not HAS_FACTERLIB:
        raise unittest.SkipTest('Skipping because `facter` is not installed.')

    facter_fact_collector_0 = FacterFactCollector()
    module = MagicMock()
    facter_path_0 = '/usr/bin/facter'
    module.get_bin_path.return_value = facter_path_0
    rc_0 = 0

# Generated at 2022-06-24 23:13:43.415851
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    #case for non-empty facter_path
    rc_ref,out_ref, err_ref = facter_fact_collector_0.run_facter("/usr/bin/facter")
    assert rc_ref == 0
    assert out_ref == ''
    assert err_ref == ''


# Generated at 2022-06-24 23:14:00.192737
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0_obj = FacterFactCollector()
    facter_fact_collector_0_obj._module = 'fake_module'
    facter_fact_collector_0_obj._module.get_bin_path = lambda a, b: 'cfacter'
    facter_fact_collector_0_obj._module.run_command = lambda a: (0, '{ "facter_testcase": "TestCase"}', '')
    assert facter_fact_collector_0_obj.get_facter_output('fake_module') == '{ "facter_testcase": "TestCase"}'


# Generated at 2022-06-24 23:14:08.059464
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
  EXPECTED_RESULT = '/bin/facter'

  def mock_get_bin_path(binary, opt_dirs=None):
    if binary == 'cfacter':
      return '/bin/facter'
    return None

  mock_module = MagicMock()
  mock_module.get_bin_path.side_effect = mock_get_bin_path

  facter_fact_collector = FacterFactCollector()

  result = facter_fact_collector.find_facter(mock_module)

  assert result == EXPECTED_RESULT


# Generated at 2022-06-24 23:14:14.536695
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    # Note: extra whitespace will be trimmed by the call to get_bin_path()
    #       that find_facter() uses.
    assert facter_fact_collector_1.find_facter(None) == None


# Generated at 2022-06-24 23:14:22.704117
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = '/opt/puppetlabs/bin/facter'
    mock_module.run_command.return_value = 0, '{"somename": "somevalue"}', None

    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output(mock_module)

    mock_module.get_bin_path.assert_called_with('facter', opt_dirs=['/opt/puppetlabs/bin'])
    mock_module.run_command.assert_called_with('/opt/puppetlabs/bin/facter --puppet --json')

    # TODO: add more assertions for the return values

# Generated at 2022-06-24 23:14:32.169594
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    import tempfile


# Generated at 2022-06-24 23:14:38.463538
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()

    def run_command_mock(binary_path, extra_args=[]):
        cmd = binary_path + " " + " ".join(extra_args)
        if cmd == "facter --puppet --json":
            return 0, "", ""
        return 0, "", ""

    facter_fact_collector.run_facter = run_command_mock
    assert facter_fact_collector.get_facter_output(None) is None

# Generated at 2022-06-24 23:14:42.187696
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()


# Generated at 2022-06-24 23:14:49.066670
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    str_0 = 'command not found: cfacter'
    str_1 = 'FactCollectorError: No command found for {0!r}'
    str_2 = 'command not found: facter'
    str_3 = 'command not found: facter'

    class Module_0:
        rc = 0
        out = b''
        err = b''

    class Module_1:
        rc = 0
        out = b''
        err = str_0.encode("utf-8")

    class Module_2:
        rc = 0
        out = b''
        err = str_1.encode("utf-8")

    class Module_3:
        rc = 0
        out = b''
        err = str_2.encode

# Generated at 2022-06-24 23:14:57.943885
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.utils import set_module_args
    from ansible.module_utils.facts.utils import get_module_path

    # Initialize a FacterFactCollector
    facter_fact_collector_0 = FacterFactCollector()

    # Get a module
    set_module_args(dict(
        filter=dict(
            ids=['facter']
        )
    ))
    module_path = get_module_path('ansible.builtin.facter')
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.load_fixtures(module_path)

    # Call get_facter_output
    actual = facter_fact_collector_0.get_facter_output(module)
    
    # Check the

# Generated at 2022-06-24 23:15:01.368391
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = FakeModule()
    results = facter_fact_collector_0.get_facter_output(module_0)
    assert results == '{a: b}'


# Generated at 2022-06-24 23:15:23.987929
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.collect() == {}

# Generated at 2022-06-24 23:15:29.841742
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = None
    facter_path_0 = facter_fact_collector_0.find_facter(module_0)
    rc_0, out_0, err_0 = facter_fact_collector_0.run_facter(module_0, facter_path_0)
    print('rc_0 = ' + str(rc_0))
    print('out_0 = ' + str(out_0))
    print('err_0 = ' + str(err_0))


# Generated at 2022-06-24 23:15:31.671042
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:15:40.603204
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_obj = FacterFactCollector()
    # 'module' is a mock object used for testing purpose
    module = 'UsedinUnitTest'
    expected_output = "json_output"
    # run_facter method is mocked to avoid any external call
    facter_fact_collector_obj.run_facter = lambda module, facter_path: (0, expected_output, None)
    # find_facter method is mocked to avoid any external call
    facter_fact_collector_obj.find_facter = lambda module: "/usr/bin/facter"
    assert facter_fact_collector_obj.get_facter_output(module) == expected_output

# Generated at 2022-06-24 23:15:42.361362
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    value = facter_fact_collector_0.find_facter(module=None)
    assert value is None


# Generated at 2022-06-24 23:15:45.597467
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # TODO: update this to find the facter binary and test both
    # cases (facter vs cfacter)
    ffc = FacterFactCollector()
    assert ffc.find_facter("ansible_module") is None


# Generated at 2022-06-24 23:15:51.424911
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()

    # Test with module as None
    assert facter_fact_collector_1.find_facter(None) == None

    # TODO: add test cases for functional method find_facter of class FacterFactCollector


# Generated at 2022-06-24 23:15:56.159984
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    def run_facter(self, module, facter_path):
        return 0, '{}', ''

    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter = run_facter.__get__(facter_fact_collector_0)
    output = facter_fact_collector_0.collect(module=None)
    assert output == {}


# Generated at 2022-06-24 23:15:58.200597
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:16:01.025312
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter(module=None) is None


# Generated at 2022-06-24 23:16:48.383281
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

  # This is not implemented yet
  assert False

# Generated at 2022-06-24 23:16:50.649983
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ffc = FacterFactCollector()
    fpath = ffc.find_facter(None)
    assert fpath


# Generated at 2022-06-24 23:16:51.889536
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert 'facter' not in facter_fact_collector_0.collect()
    #TODO: write a better test


# Generated at 2022-06-24 23:17:02.576746
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()

# Generated at 2022-06-24 23:17:07.794391
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    args = {}
    if facter_fact_collector_0.get_facter_output(args) != None:
        raise AssertionError()


# Generated at 2022-06-24 23:17:16.024262
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    facter_fact_collector_1 = FacterFactCollector()

    class MockModule:
        def get_bin_path(self, arg1, arg2):
            return to_bytes(u'/usr/bin/facter')

    mock_module_0 = MockModule()
    facter_fact_collector_1.find_facter(mock_module_0)


# Generated at 2022-06-24 23:17:22.359009
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    # No module passed to get_facter_output
    assert facter_fact_collector_0.get_facter_output(None) is None

    # TODO: find a way to mock a module and test get_facter_output
    # print facter_fact_collector_0.get_facter_output(module)

# Generated at 2022-06-24 23:17:23.372292
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:17:27.344059
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    mock_module_0 = Mock()

    attr_value_0 = facter_fact_collector_0.find_facter(mock_module_0)
    assert attr_value_0 == '/usr/local/bin/facter'



# Generated at 2022-06-24 23:17:36.241706
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()
    ansible_module = AnsibleModule(argument_spec={})
    facter_path = facter_fact_collector.find_facter(ansible_module)
    assert facter_path is not None
    rc, out, err = facter_fact_collector.run_facter(ansible_module, facter_path)
    assert rc == 0
    assert out is not None
    assert err is None


# Generated at 2022-06-24 23:19:31.515152
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()


# Generated at 2022-06-24 23:19:35.911836
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import FactsParams

    facter_fact_collector_0 = FacterFactCollector(FactsParams(module=None))
    facts_params_0 = FactsParams(module=None)
    args = []
    options = {}

    # Test invocation with a plain module object
    assert facter_fact_collector_0.run_facter(facts_params_0.module, *args) == (0, '', '')


# Generated at 2022-06-24 23:19:39.740382
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert True



# Generated at 2022-06-24 23:19:49.088154
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # Stub module so we can trap get_bin_path()
    mock_module = MockAnsibleModule()
    facter_fact_collector_0.module = mock_module

    mock_module.get_bin_path.side_effect = [None, '/opt/puppetlabs/bin/cfacter' ]
    assert facter_fact_collector_0.find_facter(mock_module) == None

    mock_module.get_bin_path.side_effect = ['/opt/puppetlabs/bin/facter', '/opt/puppetlabs/bin/cfacter' ]

# Generated at 2022-06-24 23:19:50.900672
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    find_facter_path = facter_fact_collector.find_facter()


# Generated at 2022-06-24 23:20:00.931386
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class AnsibleModule_0(object):
        def __init__(self):
            self.params = {'opt_dirs': ['/opt/puppetlabs/bin'], 'bin_ansible_call': 'cfacter',
                           '_uses_shell': True, '_raw_params': 'cfacter --puppet --json', 'ansible_command_timeout': 10}
        def get_bin_path(self, arg0, **kwargs):
            return '/opt/puppetlabs/bin/cfacter'
    module_0 = AnsibleModule_0()
    assert facter_fact_collector_0.find_facter(module_0) == \
           '/opt/puppetlabs/bin/cfacter'

# Generated at 2022-06-24 23:20:10.139858
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule():
        def get_bin_path(self, path, opt_dirs=None):
            if path == 'facter':
                return '/opt/puppetlabs/bin/facter'
            if path == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
    mod = MockModule()
    facter_fact_collector_0 = FacterFactCollector()
    returned_val = facter_fact_collector_0.find_facter(mod)

    result = '/opt/puppetlabs/bin/cfacter'

    assert returned_val == result


# Generated at 2022-06-24 23:20:18.494689
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = 'String value for module_0'
    test_0 = facter_fact_collector_0.get_facter_output(module_0)
    test_1 = facter_fact_collector_0.get_facter_output(module_0)
    test_2 = facter_fact_collector_0.get_facter_output(module_0)


# Generated at 2022-06-24 23:20:20.281040
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:20:28.356940
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    fixture_data = ''
    with open(os.path.join(fixture_path, 'test_get_facter_output')) as f:
        fixture_data = f.read()

    assert FacterFactCollector.get_facter_output(fixture_data) == ['a', 'set', 'of', 'space', 'delimited', 'terms']