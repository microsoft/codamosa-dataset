

# Generated at 2022-06-24 23:11:14.603288
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Unit test for method get_facter_output of class FacterFactCollector
    # TODO: improve this test - Does it return None if all good?
    facter_fact_collector_1 = FacterFactCollector()
    expected_result = None # TBD
    actual_result = False
    # TODO: Might have to move the method inside the class...
    assert actual_result in expected_result


# Generated at 2022-06-24 23:11:22.065157
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()

    # if facter is installed, and we can use --json because
    # ruby-json is ALSO installed, include facter data in the JSON
    # Assertion that calls module.run_command(facter_path + " --puppet --json")
    # raises AnsibleActionFail, which is a subclass of AnsibleError
    # that is expected, so we catch it.
    # TODO: Better fix needed here, run_command calls should probably
    # be mocked, and there should be a way to check that they are called.
    try:
        facter_fact_collector.run_facter()
    except AnsibleActionFail:
        pass



# Generated at 2022-06-24 23:11:22.991612
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()


# Generated at 2022-06-24 23:11:34.107036
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import collector
    facter_fact_collector_0 = FacterFactCollector(collector.FacterFactCollector(), PrefixFactNamespace(namespace_name='facter', prefix='facter_'))

    # Set up mock of module
    class MockModule(object):
        class MockParams(object):
            def __init__(self):
                self.get_bin_path = Mock(side_effect=[None, 'facter'])
            def get_bin_path(self, args, opt_dirs):
                return
        params = MockParams()
    mock_module_0 = MockModule()
    mock

# Generated at 2022-06-24 23:11:37.785473
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    facter_fact_collector_1 = FacterFactCollector()
    module_3 = MockModule_3()
    facter_fact_collector_1.get_facter_output(module_3)


# Generated at 2022-06-24 23:11:41.407808
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:11:44.365515
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    facter_dict = {}

    facter_dict = facter_fact_collector.collect()

    # The facter_dict should be of type dict
    assert isinstance(facter_dict, dict)


# Generated at 2022-06-24 23:11:48.416637
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    FacterFactCollector_collect_0 = FacterFactCollector()
    assert isinstance(FacterFactCollector_collect_0.collect(), dict)


# Generated at 2022-06-24 23:11:54.888565
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    result = facter_fact_collector.collect()
    print(result)
    assert(result)

test_FacterFactCollector_collect()
print("Successfully collected all the things")

# Generated at 2022-06-24 23:12:00.009348
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # TODO: consider mocking out the module object, which is currently
    # not a trivial undertaking

    # TODO: consider also mocking out get_bin_path

    facter_fact_collector_0 = FacterFactCollector()

    # TODO: consider creating a test_module object to pass in
    # TODO: consider creating facter and/or cfacter binaries in /tmp
    # to test for
    assert facter_fact_collector_0.find_facter(None) is None

# Generated at 2022-06-24 23:12:07.225871
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter(facter_path)


# Generated at 2022-06-24 23:12:10.589443
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    returned_1 = facter_fact_collector_1.find_facter(module)
    assert returned_1 is not None and returned_1 == '/usr/bin/facter', returned_1


# Generated at 2022-06-24 23:12:12.566772
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:12:15.638502
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()
    rc, out, err = facter_fact_collector.run_facter(None, None)
    assert rc == None and out == None and err == None

# Generated at 2022-06-24 23:12:20.113638
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = None
    expected_value_0 = None
    actual_value_0 = facter_fact_collector_0.find_facter(module_0)
    assert actual_value_0 == expected_value_0


# Generated at 2022-06-24 23:12:23.343077
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    res = facter_fact_collector_1.find_facter()
    assert res is None


# Generated at 2022-06-24 23:12:29.740973
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Set-up objects
    facter_fact_collector = FacterFactCollector()

    # First test case -- no module specified
    module = None
    facter_output = facter_fact_collector.get_facter_output(module)

    # Test assertion
    facter_output_expected = None
    assert facter_output == facter_output_expected

    # Second test case -- no facter binary specified
    module = object()
    facter_output = facter_fact_collector.get_facter_output(module)

    # Test assertion
    facter_output_expected = None
    assert facter_output == facter_output_expected

    # Third test case -- facter binary found, json output is ok
    module = object()

# Generated at 2022-06-24 23:12:32.347085
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_dict = facter_fact_collector_0.collect()
    assert facter_dict is not None

# Generated at 2022-06-24 23:12:33.806994
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:12:36.715564
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = MockModule_0()
    assert facter_fact_collector_0.get_facter_output(module_0) != None


# Generated at 2022-06-24 23:12:49.160816
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    pass

# Generated at 2022-06-24 23:12:53.104508
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    assert facter_fact_collector_0.find_facter(module_0) is None


# Generated at 2022-06-24 23:12:56.800594
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    print('facter_fact_collector_1 dict: %s' % facter_fact_collector_1.collect())


# Generated at 2022-06-24 23:13:03.547992
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # FIXME: mock module.get_bin_path?  Its not exporting correctly
    # need to mock module.get_bin_path, since it's not importing correctly
    # out, err, rc = facter_fact_collector_0.find_facter()
    # assert_equals()


# Generated at 2022-06-24 23:13:08.720659
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    # TODO: Incomplete test
    assert facter_fact_collector_1


# Generated at 2022-06-24 23:13:13.774946
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    factCollectorInstance = get_collector_instance(FacterFactCollector)
    facter_fact_collector_0 = FacterFactCollector()
    # Test with a dummy module
    class MyModule:
        def __init__(self):
            pass
        def get_bin_path(self, binary, opt_dirs=None):
            return None
        def run_command(self, cmd):
            return 0, None, None
    module = MyModule()
    assert facter_fact_collector_0.get_facter_output(module) is None


# Generated at 2022-06-24 23:13:21.855966
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class module_0(object):
        _output = ''
        _result = dict(
            rc=0,
            stdout='''{
  "ansible_kernel": "Linux",
  "ansible_system": "Linux"
}\n''',
            stderr=''
        )
        def __init__(self, *args):
            pass
        def get_bin_path(self, *args):
            return '/usr/bin/facter'
        def run_command(self, *args):
            return module_0._result.get('rc'), module_0._result.get('stdout'), module_0._result.get('stderr')
    rc_0, out_0, err_0 = facter_fact_collector

# Generated at 2022-06-24 23:13:28.970360
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    fake_mock_module = MagicMock()
    facter_fact_collector_0.find_facter = MagicMock(return_value=None)

    returned_val0 = facter_fact_collector_0.get_facter_output(fake_mock_module)

    assert returned_val0 is None

    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.find_facter = MagicMock(return_value='/usr/bin/facter')

    fake_mock_module = MagicMock()
    facter_fact_collector_1.run_facter = MagicMock(return_value=(1, '', ''))


# Generated at 2022-06-24 23:13:31.397000
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.find_facter(module)


# Generated at 2022-06-24 23:13:34.385054
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.find_facter('module') == None


# Generated at 2022-06-24 23:13:58.038609
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    # try:
    #     facter_fact_collector_1 = facter_fact_collector_0.get_facter_output(module=None)
    # except Exception:
    #     pass
    # else:
    #     pass


# Generated at 2022-06-24 23:14:00.213279
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() == None


# Generated at 2022-06-24 23:14:07.367857
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    collected_facts_1 = facter_fact_collector_1.collect()
    # Testing if it is of the correct type
    assert isinstance(collected_facts_1, dict)
    # Testing the contents of the return
    assert collected_facts_1.keys() == ['ansible_facter']
    assert collected_facts_1['ansible_facter'].keys() == ['system32']
    assert collected_facts_1['ansible_facter']['system32'] == 'true'

# Generated at 2022-06-24 23:14:10.646827
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    module_3 = None
    facter_output_3 = facter_fact_collector_1.get_facter_output(module_3)
    assert facter_output_3 is None


# Generated at 2022-06-24 23:14:19.833937
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_0 = {'ansible_facts': {}}
    facter_fact_collector_1 = FacterFactCollector()
    ansible_1 = {'ansible_facts': {}}
    ansible_1['ansible_facts']['facter'] = {}
    facter_fact_collector_2 = FacterFactCollector()
    ansible_2 = {'ansible_facts': {}}
    ansible_2['ansible_facts']['facter'] = {}
    facter_fact_collector_2.collector_results['facter'] = {}

test_case_0()
test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:14:20.953650
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()


# Generated at 2022-06-24 23:14:24.362789
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    args = {}
    kwargs = {}
    if 'ansible_facts' not in kwargs:
        kwargs['ansible_facts'] = {}
    FacterFactCollector.collect(**kwargs)
    assert 'facter_operatingsystem' in kwargs['ansible_facts']


# Generated at 2022-06-24 23:14:27.609163
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector._find_facter()
    assert facter_path is not None


# Generated at 2022-06-24 23:14:29.213398
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # Test for find_facter.
    # Test for find_facter.


# Generated at 2022-06-24 23:14:34.159047
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class module_mock:
        def get_bin_path(self, arg0, arg1):
            return '/bin/facter'

        def run_command(self, arg0):
            return {}

    module_mock_0 = module_mock()
    assert facter_fact_collector_0.run_facter(module_mock_0, '/bin/facter') == {}


# Generated at 2022-06-24 23:15:18.913904
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class test_ansible_module:
        def get_bin_path(self, argument_0):
            return get_bin_path_0
        def fail_json(self, argument_0, argument_1):
            assert False, "message"
    get_bin_path_0 = "./facter"
    test_ansible_module_0 = test_ansible_module()
    facter_path_0 = facter_fact_collector_0.find_facter(test_ansible_module_0)
    assert facter_path_0 == "./facter"


# Generated at 2022-06-24 23:15:27.575834
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import unittest
    import mock

    # Mock the module object.
    module = mock.MagicMock()
    module.run_command.return_value = 0, '{}', ''

    facter_fact_collector_0 = FacterFactCollector()

    # To handle deprecation errors
    with unittest.mock.patch('ansible.module_utils.facts.collector.ansible_module', module):
        output = facter_fact_collector_0.get_facter_output(mock.MagicMock)
        assert output == '{}'

# Generated at 2022-06-24 23:15:31.719887
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_mock = None
    assert facter_fact_collector_0.get_facter_output(module_mock) is None



# Generated at 2022-06-24 23:15:41.372851
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    mocker = Mocker()

    facter_fact_collector_1 = FacterFactCollector()

    mock_module_1 = mocker.mock()
    mock_module_1.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
    mocker.result(None)
    mocker.count(0, None)

    with mocker:
        assert facter_fact_collector_1.get_facter_output(mock_module_1) is None

    mock_module_2 = mocker.mock()
    facter_path_2 = '/usr/bin/facter'
    mock_module_2.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
    mocker.result

# Generated at 2022-06-24 23:15:47.112882
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    # Create instance of FacterFactCollector
    facter_fact_collector_0 = FacterFactCollector()

    # Create instance of AnsibleModule
    module = AnsibleModule()

    # Create instance of AnsibleModule
    facter_path = '/usr/local/bin/facter'
    actual_rc, actual_out, actual_err = facter_fact_collector_0.run_facter(module, facter_path)

    expected_rc = 0
    expected_out = ''
    expected_err = ''

    assert actual_rc == expected_rc
    assert actual_out == expected_out
    assert actual_err == expected_err

# Generated at 2022-06-24 23:15:50.925390
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output() == None




# Generated at 2022-06-24 23:15:57.493251
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = MockModule()

    facter_fact_collector_0 = FacterFactCollector()
    facter_path = '/usr/bin/facter'

    # Testing when rc == 0
    module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    rc, out, err = facter_fact_collector_0.run_facter(module, facter_path)
    assert rc == 0
    assert out == 'out'
    assert err == 'err'

    # Testing when rc != 0
    module.run_command = MagicMock(return_value=(1, 'out', 'err'))
    rc, out, err = facter_fact_collector_0.run_facter(module, facter_path)
    assert rc == 1

# Generated at 2022-06-24 23:16:01.304493
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Test with a normal path in PATH
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = None
    assert facter_fact_collector_0.find_facter(module_0) is not None


# Generated at 2022-06-24 23:16:08.900736
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # this is a pseudo ansible module which has the required methods to run get_facter_output
    module_mock = CreateModuleMock()

    # this is a pseudo version of what a get_bin_path call would return
    module_mock.return_value = 'test/facter'
    module_mock.run_command_return_value = ('return code', 'output', 'error')

    # test with a requirement for cfacter
    facter_fact_collector = FacterFactCollector()
    result = facter_fact_collector.get_facter_output(module_mock)
    assert result == 'output'

    # test with a requirement for facter
    facter_fact_collector = FacterFactCollector()
    module_mock.return_value = None

# Generated at 2022-06-24 23:16:12.750223
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() == None


# Generated at 2022-06-24 23:17:49.568891
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()
    facter_path = "/opt/puppetlabs/bin/facter"
    # If rc != 0, method should return None
    assert facter_fact_collector.run_facter(None,facter_path)[0] != 0
    assert facter_fact_collector.run_facter(None,facter_path)[1] is None
    assert facter_fact_collector.run_facter(None,facter_path)[2] is None
    assert facter_fact_collector.run_facter(None,facter_path)[0] == 0


# Generated at 2022-06-24 23:17:56.546859
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts import ModuleDataCollector

    # Create 0 fake module
    module_0 = ModuleDataCollector()

    # Create 1 instance of class FacterFactCollector
    facter_fact_collector_0 = FacterFactCollector()

    # Try to fake '/opt/puppetlabs/bin/facter' in sys.module_loader._module_cache
    # FIXME: This is fake and need a mechanism to save real binary path
    module_0.set_bin_path('facter', '/opt/puppetlabs/bin/facter')

    # Call method run_facter of facter_fact_collector_0 with parameters module_0
    return facter_fact_collector_0.run_facter(module_0, '/opt/puppetlabs/bin/facter')

# Generated at 2022-06-24 23:18:04.231842
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    sub_mock = __import__(__name__ + ".mock_modules.ansible_module_mock", None, None, ["MockModule"]).MockModule()
    sub_mock.params = dict()
    sub_mock.params['filters'] = dict()

    facter_fact_collector_1 = FacterFactCollector()

    result = facter_fact_collector_1.get_facter_output(sub_mock)
    assert result is None

# Generated at 2022-06-24 23:18:10.984644
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()

    class MockModule:
        def run_command(self, facter_path):
            pass
    mock_module_0 = MockModule()
    facter_path_0 = '/usr/sbin/cfacter'
    rc_0, out_0, err_0 = facter_fact_collector_0.run_facter(mock_module_0, facter_path_0)

    class MockModule:
        def run_command(self, facter_path):
            pass
    mock_module_1 = MockModule()
    facter_path_1 = '/usr/sbin/facter'

# Generated at 2022-06-24 23:18:12.537678
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facter_dict_1 = facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:18:16.685749
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    module_1 = None
    facter_fact_collector_1.get_facter_output = lambda *args, **kwargs: module_1
    assert facter_fact_collector_1.get_facter_output(module=module_1) is None



# Generated at 2022-06-24 23:18:24.696019
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    collected_facts = dict()
    facter_fact_collector = FacterFactCollector()
    class MockModule:
        def __init__(self):
            self.expected_results = (0, "", "")
            self.run_command_count = 0
        def get_bin_path(self, name, opt_dirs=()):
            return
        def run_command(self, command):
            self.run_command_count += 1
            return self.expected_results
    m = MockModule()
    m.run_facter_path = "/bin/facter"
    m.expected_results = (0, "", "")

    (rc, out, err) = facter_fact_collector.run_facter(m, m.run_facter_path)

    assert rc == 0

# Generated at 2022-06-24 23:18:30.260597
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create simple facter collector
    facter_fact_collector = FacterFactCollector()

    # Create module object
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Get facter output
    facter_output = facter_fact_collector.get_facter_output(module)

    # Assert if it is not empty
    assert facter_output is not None

    # Test collecting facter facts
    collected_facter_facts = facter_fact_collector.collect(module=module)

    # Assert if facter_facts key exists
    assert collected_facter_facts is not None

    # Create simple facter collector
    facter_fact_collector = FacterFactCollector()

    # Create module object

# Generated at 2022-06-24 23:18:31.222530
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    assert isinstance(FacterFactCollector().collect(), dict)


# Generated at 2022-06-24 23:18:33.688834
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    print("facter_fact_collector_0.collect() = " + repr(facter_fact_collector_0.collect()))

