

# Generated at 2022-06-24 23:11:20.174630
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    class module:
        def __init__(self):
            self.params = {'ansible_ssh_common_args': '3'}

        def get_bin_path(self, dir, opt_dirs):
            return '/path/to/facter'

    facter_fact_collector_0.module = module()
    assert facter_fact_collector_0.find_facter(facter_fact_collector_0.module) == '/path/to/facter'


# Generated at 2022-06-24 23:11:22.839954
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output() == None


# Generated at 2022-06-24 23:11:30.872624
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    facter_fact_collector = FacterFactCollector()

    mock_module = MagicMock()

    mock_module.get_bin_path.return_value = "fake_bin/facter"

    mock_module.run_command.return_value = (0, '{ "facter_version": "3.10.1", "kernel": "Linux", "os": { "name": "Ubuntu", "release": { "major": "16", "full": "16.04" } } }', 'stdout')

    facter_fact_collector.run_facter(mock_module, "fake_bin/facter")

    mock_module.run_command.assert_called_with("fake_bin/facter --puppet --json")


# Generated at 2022-06-24 23:11:43.032221
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:11:48.022903
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

    # Run function collect
    # No exception thrown



# Generated at 2022-06-24 23:11:49.731638
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter('module0') is None


# Generated at 2022-06-24 23:11:54.718379
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output(None) is None

# Generated at 2022-06-24 23:11:55.616067
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    pass



# Generated at 2022-06-24 23:12:01.668900
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Testing with python 2.6
    facter_fact_collector_0 = FacterFactCollector()

    class TestModule:
        def get_bin_path(self, test_1, opt_dirs_=None):
            from os.path import join as os_path
            from os import environ as os_environ
            from os import pathsep as os_pathsep
            from os import getenv as os_getenv
            if not test_1 or not (test_1 == 'facter' or test_1 == 'cfacter'):
                return None

            if opt_dirs_ is not None:
                path_dirs = os_environ['PATH'].split(os_pathsep)


# Generated at 2022-06-24 23:12:07.092594
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    assert isinstance(facter_fact_collector_1, FacterFactCollector)
    assert facter_fact_collector_1.name == 'facter'
    assert facter_fact_collector_1._fact_ids == {'facter'}
    assert facter_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:12:13.157954
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import module_utils.facts.collector.facter as FacterFactCollector
    f = FacterFactCollector.FacterFactCollector()
    m = FacterFactCollector.__name__
    m = FacterFactCollector.__name__
    assert(f.find_facter(m) != None)
    


# Generated at 2022-06-24 23:12:22.240340
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import unittest.mock as mock
    m_module = mock.MagicMock(name='m_module')
    m_module.get_bin_path.return_value = '/opt/puppetlabs/bin/cfacter'
    module = mock.MagicMock(name='module')
    module.get_bin_path.return_value = '/opt/puppetlabs/bin/cfacter'
    facter_fact_collector_0 = FacterFactCollector()
    facter_path = facter_fact_collector_0.find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'



# Generated at 2022-06-24 23:12:24.114700
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:12:25.976420
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test with a real facter binary on disk
    # This is the "normal" case
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:12:35.708109
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.system.facter import FacterFactCollector
    from ansible.module_utils.facts import ansible_collections_path
    import os
    import shutil
    import tempfile
    import sys
    
    backup_path = sys.path
    temp_dir = tempfile.mkdtemp(prefix='tmp_FacterFactCollector_find_facter_')
    sys.path = [temp_dir]


# Generated at 2022-06-24 23:12:36.532946
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    pass


# Generated at 2022-06-24 23:12:40.330412
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    # Unit test for method find_facter of class FacterFactCollector
    # TODO: implement this test case
    #assert facter_fact_collector_0.find_facter() == dummy_result


# Generated at 2022-06-24 23:12:42.434153
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass

# Generated at 2022-06-24 23:12:44.429507
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() == None


# Generated at 2022-06-24 23:12:53.397671
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = Mock()
    module_0.get_bin_path.return_value = '/opt/puppetlabs/bin/facter'
    return_value_0 = facter_fact_collector_0.find_facter(module=module_0)
    module_0.get_bin_path.assert_called_with('facter', opt_dirs=['/opt/puppetlabs/bin'])
    assert return_value_0 is not None


# Generated at 2022-06-24 23:13:02.874788
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    def mock_get_bin_path(bin_name, opt_dirs=None):
        return '/opt/puppetlabs/bin/facter'

    FacterFactCollector.find_facter(mock_get_bin_path)


# Generated at 2022-06-24 23:13:13.412052
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    facts_module = ModuleFacts(name='my_facter',
                               verbose=True,
                               custom_collections=None,
                               namespace=PrefixFactNamespace(namespace_name='facter',
                                                             prefix='facter_'))
    facter_fact_collector = FacterFactCollector(collectors=None,
                                                namespace=PrefixFactNamespace(namespace_name='facter',
                                                                              prefix='facter_'))

# Generated at 2022-06-24 23:13:21.285390
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_1 = FacterFactCollector()

    # This actually looks like a real module, but it is not.  See the
    # file: ansible/test/units/module_utils/facts/test_facter.py
    # for more details.
    test_module_0 = ansible_module_0 = None

    facter_path = "/bin/facter"

    result = facter_fact_collector_1.run_facter(test_module_0, facter_path)

    assert result is not None

# Generated at 2022-06-24 23:13:25.811565
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts_0 = facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:13:27.889042
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.run_facter is not None


# Generated at 2022-06-24 23:13:36.290332
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_module_0 = MockModule()
    ansible_module_0.bin_path = MockModule.bin_path
    f_bin_path = MockFunction()
    f_bin_path.side_effect = [None, None, None, None, '/tmp/does_not_exist']
    ansible_module_0.get_bin_path = f_bin_path
    result = facter_fact_collector_0.find_facter(ansible_module_0)
    assert result == '/tmp/does_not_exist'


# Generated at 2022-06-24 23:13:39.567807
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    assert FacterFactCollector().find_facter('/usr/bin/facter') == '/usr/bin/facter'


# Generated at 2022-06-24 23:13:40.543307
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    pass


# Generated at 2022-06-24 23:13:43.563492
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    # TODO: add test data
    # TODO: add assertions


# Generated at 2022-06-24 23:13:53.047858
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    def test_module_0():
        def get_bin_path_0(arg_arg_0, arg_opt_dirs_0=None):
            return 'facter_path'
        class TestAnsibleModule_0():
            def __init__(self, arg_argument_spec_0, arg_supports_check_mode_0, arg_bypass_checks_0=None):
                pass
            def get_bin_path(self, arg_arg_0, arg_opt_dirs_0=None):
                return get_bin_path_0(arg_arg_0, arg_opt_dirs_0=arg_opt_dirs_0)
            def run_command(self, arg_arg_0):
                pass
       

# Generated at 2022-06-24 23:14:07.994555
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = MockModule()
    assert facter_fact_collector_0.find_facter(module_0) == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-24 23:14:14.536359
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector._module = None
    facter_output = facter_fact_collector.get_facter_output(facter_fact_collector._module)
    assert facter_output is None


# Generated at 2022-06-24 23:14:16.628426
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    print(facter_fact_collector.get_facter_output())

# Generated at 2022-06-24 23:14:17.861927
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    assert True

# Generated at 2022-06-24 23:14:21.530198
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    # Testing for 'not None' for parameter 'module'
    assert True
    # Testing for 'not None' for parameter 'facter_path'
    assert True
    # Testing for 'not None' for parameter 'module.run_command'
    assert True


# Generated at 2022-06-24 23:14:27.608099
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector.facter.facter_collector_mock
    facter_fact_collector_0 = FacterFactCollector()
    module_0_mock = ansible.module_utils.facts.collector.facter.facter_collector_mock.ModuleMock()
    module_0_mock.params = dict()
    module_0_mock.params['opt_dirs'] = ['facter_opt_dirs_value']
    facter_0_call_result = facter_fact_collector_0.find_facter(module_0_mock)
    assert facter_0_call_result == 'facter_bin_path_value'


# Generated at 2022-06-24 23:14:35.169650
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()

# Generated at 2022-06-24 23:14:38.841556
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_2 = FacterFactCollector()
    collected_facts_3 = {}
    facter_fact_collector_2.collect(None, collected_facts_3)

if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:14:40.530939
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    # TODO: implement this test
    raise NotImplementedError()


# Generated at 2022-06-24 23:14:47.663838
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    # Set up test input arguments for method get_facter_output of class FacterFactCollector
    facter_fact_collector_0.module = None

    # Call method get_facter_output of class FacterFactCollector
    try:
        facter_fact_collector_0.get_facter_output(facter_fact_collector_0.module)
    except Exception as e:
        print("Exception caught in get_facter_output of class FacterFactCollector: " + repr(e))

test_FacterFactCollector_get_facter_output()

# Generated at 2022-06-24 23:15:13.966162
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    # Get a mocked module and run the get_facter_output() method
    class MockedModule:
        def get_bin_path(self, bin_name, opt_dirs=[]):
            return "bin/facter"

# Generated at 2022-06-24 23:15:14.715764
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # TODO: figure out how to mock module_utils
    return False


# Generated at 2022-06-24 23:15:17.403536
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    find_facter_0_result = facter_fact_collector_0.find_facter()
    assert not find_facter_0_result


# Generated at 2022-06-24 23:15:26.462750
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    facter_fact_collector_1 = FacterFactCollector()

    class Module(object):
        @staticmethod
        def get_bin_path(name):
            if name == "cfacter":
                return "/usr/bin/cfacter"
            else:
                if name == "facter":
                    return "/usr/bin/facter"
                else:
                    return None

        @staticmethod
        def run_command(cmd):
            return 1, "", "Error cannot run command"

    module_1 = Module()

    return facter_fact_collector_1.get_facter_output(module_1)


# Generated at 2022-06-24 23:15:34.378678
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.facts import FactManager
    from ansible.module_utils.facts.collector import BaseFactCollector
    facter_fact_collector_1 = FacterFactCollector()
    base_fact_collector_0 = BaseFactCollector()
    assert facter_fact_collector_1.find_facter(base_fact_collector_0) is None
    fact_manager_0 = FactManager(collectors=None, hostname='localhost', module=base_fact_collector_0)
    fact_manager_0.collect(collected_facts=None)
    assert facter_fact_collector_1.find_facter(base_fact_collector_0) is not None


# Generated at 2022-06-24 23:15:45.057570
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_module_0 = AnsibleModule
    # Set module.run_command.return_value
    ansible_module_0.run_command.return_value = (
        2, 'stdout_value', 'stderr_value'
    )
    ansible_module_0.get_bin_path.return_value = '/test/bin/path'

    # Call method
    facter_output = facter_fact_collector_0.get_facter_output(ansible_module_0)

    assert facter_output == None

# Generated at 2022-06-24 23:15:49.894831
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

    assert True is facter_fact_collector_0.collect() is None


# Generated at 2022-06-24 23:15:50.651367
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()


# Generated at 2022-06-24 23:15:53.579276
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter(module=None) is None


# Generated at 2022-06-24 23:16:01.823929
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = MockModule()
    facter_path_0 = '/usr/bin/facter'

    rc_0, out_0, err_0 = facter_fact_collector_0.run_facter(module_0, facter_path_0)
    assert rc_0 == 0
    assert out_0 == '{"ruby": {"platform": "x86_64-linux"}}'
    assert err_0 == ''

# Generated at 2022-06-24 23:16:55.452268
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    facter_fact_collector_0 = FacterFactCollector()
    def module(bin_path_mock):
        if bin_path_mock == u'facter':
            return '/usr/bin/facter'
        elif bin_path_mock == u'cfacter':
            return None

    facter_fact_collector_0.collect(module=module)


# Generated at 2022-06-24 23:17:00.031294
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    # FIXME: test case 0
    # FIXME: AnsibleModule
    # FIXME: get_bin_path



# Generated at 2022-06-24 23:17:06.859550
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create a FacterFactCollector instance
    facter_fact_collector = FacterFactCollector()

    # Create a module
    module = AnsibleModuleMock()
    # Set the module bin path to /usr/bin
    module.BIN_PATH = '/usr/bin'

    assert facter_fact_collector.get_facter_output(module) is None


# Generated at 2022-06-24 23:17:10.871828
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ffc = FacterFactCollector()
    assert ffc.find_facter(None) == None

# Generated at 2022-06-24 23:17:19.135940
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test with a mocked module
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import ModuleUtils
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six.moves import StringIO

    class MockedModule(basic.AnsibleModule):
        def __init__(self):
            self.params = {}
            self.connection = Connection()

    module = MockedModule()
    module.run_command = ModuleUtils.run_command

    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.run_facter = ModuleUtils.run_command
    output = facter_fact_collector.get_facter

# Generated at 2022-06-24 23:17:24.468135
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    FactCollectorBase = FacterFactCollector()
    assert FactCollectorBase.get_facter_output("./facter") is not None

if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_get_facter_output()

# Generated at 2022-06-24 23:17:28.414462
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # TODO: make a module mock
    # result = facter_fact_collector_0.find_facter(module=None)
    # assert result['rc'] == 0


# Generated at 2022-06-24 23:17:38.593946
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    import module_utils.facts.collector.facter

    # FIXME: mock the find_facter method and the run_facter method

    #mock_facter_fact_collector = Mock(module_utils.facts.collector.facter.FacterFactCollector)
    #mock_facter_fact_collector.find_facter.return_value = '/opt/puppetlabs/bin/cfacter'
    #mock_facter_fact_collector.run_facter.return_value = (0, '/opt/puppetlabs/bin/cfacter --puppet --json returned valid json', None)

    #assertEqual(sorted(mock_facter_fact_collector.get_facter_output().keys()), ['facter_cfacter', 'facter_kernelmajversion',

# Generated at 2022-06-24 23:17:41.094345
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter(module=None) == '/opt/puppetlabs/bin/facter'



# Generated at 2022-06-24 23:17:45.672623
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    # TODO: implement test


# Generated at 2022-06-24 23:19:49.690852
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.run_command = MagicMock(return_value=(0, 'ok', ''))
    ansible_module.get_bin_path = MagicMock(return_value='/usr/local/bin/facter')
    facter_fact_collector_0.collect(ansible_module)



# Generated at 2022-06-24 23:19:51.247911
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert len(facter_fact_collector_0.collect()) == 0

# Generated at 2022-06-24 23:19:55.715300
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.find_facter()


# Generated at 2022-06-24 23:20:03.580396
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    fake_module = MagicMock()
    facter_fact_collector = FacterFactCollector()

    # Test with return value of fake_module.get_bin_path = None
    fake_module.get_bin_path.return_value = None
    with patch('ansible.module_utils.facts.collector.FacterFactCollector.find_facter') as mock_find_facter:
        mock_find_facter.return_value = None
        assert facter_fact_collector.find_facter(fake_module) == None


# Generated at 2022-06-24 23:20:06.595099
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule:
        def get_bin_path(self, arg, opt_dirs=None):
            return 'moar_bin_path'

    mock_module_0 = MockModule()

    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter(mock_module_0) == 'moar_bin_path'

# Generated at 2022-06-24 23:20:11.734243
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Mock module
    module = MockModule()

    # Mock facter binary path
    def mock_get_bin_path(path, opt_dirs=None):
        return '/usr/local/bin/facter'
    module.get_bin_path = mock_get_bin_path

    facter_fact_collector_0 = FacterFactCollector()
    result = facter_fact_collector_0.find_facter(module)

    assert result == '/usr/local/bin/facter'



# Generated at 2022-06-24 23:20:14.985408
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:20:18.068445
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    FacterFactCollector_instance = FacterFactCollector()
    assert FacterFactCollector_instance.get_facter_output(module=None) is None


# Generated at 2022-06-24 23:20:22.940785
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:20:31.147273
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_output = """{
        "uptime": {
            "seconds": 3376
        }
    }"""
    facter_fact_collector_1 = FacterFactCollector()
    # TODO: this is a good testcase for mocking
    facter_fact_collector_1.run_facter = lambda module, facter_path: (0, facter_output, '')
    assert facter_fact_collector_1.run_facter(None, None) == (0, facter_output, '')