

# Generated at 2022-06-24 23:11:15.806582
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # collect facts by using mock facts and mock module
    facter_fact_collector_1 = FacterFactCollector()

    class MockModule:
        def get_bin_path(self, executable, opt_dirs=None):
            return None
        def run_command(self, command):
            if command == "facter --puppet --json":
                return 0, '{"test_key":"test_value"}', ''
            else:
                raise Exception
    module = MockModule()

    rc, out, err = facter_fact_collector_1.run_facter(module, "facter")

    assert rc == 0
    assert out == '{"test_key":"test_value"}'
    assert err == ''


# Generated at 2022-06-24 23:11:19.928321
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_1 = FacterFactCollector()
    module = AnsibleModuleStub()
    facter_path = AnsibleModuleStub.find_facter(module)
    rc, out, err = facter_fact_collector_1.run_facter(module, facter_path)


# Generated at 2022-06-24 23:11:23.656245
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector.find_facter()
    print(facter_path)

test_case_0()
test_FacterFactCollector_find_facter()

# Generated at 2022-06-24 23:11:26.681917
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    # Test case: module=None
    assert facter_fact_collector_0.get_facter_output(None) is None


# Generated at 2022-06-24 23:11:30.912828
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    facter_path=facter_fact_collector_0.find_facter(module)

    # Test if facter_path is not None
    assert facter_path is not None


# Generated at 2022-06-24 23:11:39.021629
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    FacterFactCollector.run_facter = run_facter
    FacterFactCollector.get_facter_output = get_facter_output
    facter_fact_collector_0 = FacterFactCollector()

    # testing with a specific value
    rc = facter_fact_collector_0.find_facter('module')
    assert rc == 'test'


# Generated at 2022-06-24 23:11:44.957525
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector.facter

    facter_fact_collector_get_facter_output = ansible.module_utils.facts.collector.facter.FacterFactCollector()
    mocker.patch.object(facter_fact_collector_get_facter_output, 'find_facter')
    facter_fact_collector_get_facter_output.find_facter.return_value = 'test'
    mocker.patch.object(facter_fact_collector_get_facter_output, 'run_facter')
    facter_fact_collector_get_facter_output.run_facter.return_value = (0, 'test', 'test')
    return facter_fact

# Generated at 2022-06-24 23:11:54.444195
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:11:58.781075
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()

    print(facter_fact_collector_0.find_facter('facter_fact_collector_0'))

# Test case for class FacterFactCollector

# Generated at 2022-06-24 23:12:06.295334
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import ansible_collections as ac
    from ansible.module_utils.facts.collector import BaseFactCollector

    facter_fact_collector_0 = FacterFactCollector()
    module = ac
    # Test call to FacterFactCollector.find_facter() with valid module parameters
    facter_path = facter_fact_collector_0.find_facter(module)
    assert facter_path is not None


# Generated at 2022-06-24 23:12:17.400730
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()

    module = None
    facter_path = facter_fact_collector.find_facter(module)
    rc, out, err = facter_fact_collector.run_facter(module, facter_path)



# Generated at 2022-06-24 23:12:24.426888
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    class DummyModule(object):
        def get_bin_path(self, arg0, opt_dirs):
            return 'facter'
        def run_command(self, arg0):
            return 0, '{"id": "a", "id": "b"}', ''
    module = DummyModule()

    expected = '{"id": "a", "id": "b"}'
    actual = facter_fact_collector_0.get_facter_output(module)
    assert expected == actual

# Generated at 2022-06-24 23:12:35.517504
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Make a fake module and class
    class FakeModule(object):
        # Make a fake run_command
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            # Demo of how we can return a subprocess.Popen
            # for the Popen's communicate to return
            class FakePopen(object):
                def communicate(self):
                    return (b'', b'')
            return 0, FakePopen(), b''

        # Make a fake get_bin_path
        def get_bin_path(self, *args, **kwargs):
            return '/bin/facter'
    fake_module = FakeModule()

    # Create an instance of FacterFactCollector
    facter_fact_collector_1 = Facter

# Generated at 2022-06-24 23:12:40.125319
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    module_0 = MockModule()
    assert facter_fact_collector_1.get_facter_output(module_0) == '__ansible_facter_output__'


# Generated at 2022-06-24 23:12:48.352675
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    module_2 = Mock()
    module_2.exists.return_value = None
    module_2.get_bin_path.return_value = None

# Generated at 2022-06-24 23:12:51.614349
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    # Test empty case
    facter_fact_collector.collect()

# Test with invalid fact names to test fact_name_filter

# Generated at 2022-06-24 23:12:56.149091
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    facter_path_1 = facter_fact_collector_1.find_facter(None)
    assert facter_path_1 is None


# Generated at 2022-06-24 23:13:01.302484
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.get_facter_output("/usr/bin/facter --puppet --json")

# Generated at 2022-06-24 23:13:02.520809
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:13:06.708034
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() == None

# Generated at 2022-06-24 23:13:23.627045
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    print("Running test_FacterFactCollector_get_facter_output ...")
    facter_fact_collector_0 = FacterFactCollector()
    class module_0:
        def get_bin_path(arg_0, arg_1):
            return None
        def run_command(arg_0, arg_1):
            return None
    facter_fact_collector_0.get_facter_output(module_0)


# Generated at 2022-06-24 23:13:27.893441
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter()


# Generated at 2022-06-24 23:13:33.877255
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''
    Class FacterFactCollector
    Unit test for method find_facter of class FacterFactCollector
    '''
    facter_fact_collector_0 = FacterFactCollector()

    module_0 = None

    # Call method
    find_facter_0 = facter_fact_collector_0.find_facter(module_0)

    # Check method result
    assert find_facter_0 is None

    # Check for exceptions
    assert find_facter_0 is not None

    # Method run_facter
    # Unit test for method run_facter of class FacterFactCollector
    # Parameters
    facter_path = None

    # Call method

# Generated at 2022-06-24 23:13:35.428490
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    ffc = FacterFactCollector()
    ffc.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:13:40.629472
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    test_module = MockModule()

    # TODO: incomplete test case
    #facter_fact_collector_1.get_facter_output(test_module)


# Generated at 2022-06-24 23:13:44.737193
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    facter_dict = facter_fact_collector.collect()
    assert (isinstance(facter_dict, dict))
    # Assert that facter_dict is non-empty
    assert (not len(facter_dict.keys()) == 0)

# Generated at 2022-06-24 23:13:47.082076
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    assert facter_fact_collector_0.find_facter is not None


# Generated at 2022-06-24 23:13:48.206409
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:13:51.988437
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1=FacterFactCollector()
    assert facter_fact_collector_1.find_facter(module=None)==None


# Generated at 2022-06-24 23:14:00.082175
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.modules.system.facter import FacterFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    facter_path = "/bin/facter"
    path = "/Users/user/ansible/test/integration/targets/localhost/FacterFactCollector/facter/run_facter"
    with open(path, "r") as run_facter_file:
        run_facter_lines = run_facter_file.readlines()

    run_facter_list = []
    for run_facter_line in run_facter_lines:
        run_facter_list.append(run_facter_line.rstrip("\n"))

    expected_result = tuple(run_facter_list)
    actual_result = FacterFactCollect

# Generated at 2022-06-24 23:14:22.666632
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    collected_facts_1 = facter_fact_collector_1.collect()



# Generated at 2022-06-24 23:14:32.169359
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()

    # Test with a module that has facter installed
    from ansible.module_utils.facts.test_module_0 import TestModule
    module_0 = TestModule(module_name='ansible.module_utils.facts.test_module_0',
                          module_path='/home/david/workspace/ansible/lib/ansible/module_utils/facts/test_module_0.py',
                          facts={})

    returned_output = facter_fact_collector_1.get_facter_output(module_0)

    # Verify the output is not None
    assert returned_output is not None

    # Test with a module that does not have facter installed
    from ansible.module_utils.facts.test_module_1 import Test

# Generated at 2022-06-24 23:14:35.088331
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output(None) is None


# Generated at 2022-06-24 23:14:42.143310
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = object()
    def module_run_command_0(arg0_0, arg0_1):
        return (0, 0, 0)
    def module_run_command_1(arg0_0, arg0_1, opt_dirs_0=None):
        return (0, 0, 0)
    module_0.run_command = module_run_command_0
    module_0.get_bin_path = module_run_command_1
    assert facter_fact_collector_0.get_facter_output(module_0) is None
    # FIXME: expects '0', is returning 'None'


# Generated at 2022-06-24 23:14:49.048196
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class Module:
        def get_bin_path(self, arg1, arg2=None):
            if arg1 == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            return None
        def run_command(self, arg1):
            if arg1 == '/opt/puppetlabs/bin/cfacter --puppet --json':
                return (0, '{"os":{"family":"RedHat"},"languages":{"ruby":{"version":"2.3.3"}}}', '')
            return (1, '', 'command not found: facter')
    module_0 = Module()

# Generated at 2022-06-24 23:14:57.915747
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    facts_collector = get_collector_instance('facter')
    try:
        from ansible.module_utils.facts import ansible_facts
        ansible_module = ansible_facts(name='ansible_module', debug=True)
    except Exception:
        import ansible.module_utils
        ansible_module = ansible.module_utils.AnsibleModule(name='ansible_module', debug=True, argument_spec={})

    facter_fact_collector_1 = FacterFactCollector(collectors=[facts_collector])

    # Testing the returned value of "run_facter"
    # We can call it with a wrong PATH and check
    # if what we expect is returned
    ansible_module.run

# Generated at 2022-06-24 23:14:59.735883
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    collector = FacterFactCollector()

    assert collector.find_facter(module) == None



# Generated at 2022-06-24 23:15:03.345264
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    assert False, "Test not implemented"

# Generated at 2022-06-24 23:15:03.953270
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    pass


# Generated at 2022-06-24 23:15:09.702670
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    module_0 = Mock()
    # case_0
    setattr(module_0, "get_bin_path", Mock(side_effect=lambda command, opt_dirs=None: command))
    setattr(module_0, "run_command", Mock(side_effect=lambda call_data, cwd=None, use_unsafe_shell=False, environ_update=None, umask=None, encoding=None: (0, "fake_out", "fake_err")))
    result_0 = facter_fact_collector_1.get_facter_output(module_0)
    assert result_0 == "fake_out"
    # case_1

# Generated at 2022-06-24 23:15:40.391437
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()

    # Create a mock module object
    class MockModule(object):
        def __init__(self):
            self.params = {}

        # Mock the get_bin_path method
        # There are two different results based on the path
        def get_bin_path(self, executable, opt_dirs=[]):
            # Define the first result to be returned
            # get_bin_path is called with executable = 'facter'
            first = {'facter': '/opt/puppetlabs/bin/facter',
                     'cfacter': '/opt/puppetlabs/bin/cfacter'}

            # Define the second result to be returned
            # get_bin_path is called with executable = 'cfacter'

# Generated at 2022-06-24 23:15:46.394870
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Mock the module fixture
    module_0 = MockAnsibleModule

    # Mock the find_facter method of FacterFactCollector class
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.find_facter = Mock(return_value='/foo/bar')
    return_output = facter_fact_collector_0.get_facter_output(module_0)

    # Assert that the get_facter_output return value is expected
    assert return_output == '{ "facter_foo": "bar", "facter_baz": "bar" }\n'


# Generated at 2022-06-24 23:15:49.992246
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

    assert  facter_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:15:58.789839
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_dict = {}

# Generated at 2022-06-24 23:16:01.223078
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:16:03.618384
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    result = facter_fact_collector.collect()
    result == None

# HotSpot test for method collect of class FacterFactCollector

# Generated at 2022-06-24 23:16:05.676817
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.find_facter()


# Generated at 2022-06-24 23:16:07.419829
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()

    # TODO: implement this unit test
    assert False


# Generated at 2022-06-24 23:16:17.397948
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Create an empty module
    module = mock.Mock()

    # Create an instance of FacterFactCollector
    facter_fact_collector_0 = FacterFactCollector()

    # Set values of variables used in the test
    facter_path = '/usr/bin/facter'

    # Mock the get_bin_path method
    facter_fact_collector_0.module.get_bin_path = mock.Mock()
    facter_fact_collector_0.module.get_bin_path.return_value = facter_path

    # Mock the run_command method
    facter_fact_collector_0.module.run_command = mock.Mock()

# Generated at 2022-06-24 23:16:19.281626
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    collector_0 = FacterFactCollector()
    module_0 = ansible_module_0
    facter_output_0 = collector_0.get_facter_output(module_0)
    assert facter_output_0 is not None


# Generated at 2022-06-24 23:17:13.813013
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    try:
        facter_fact_collector.get_facter_output()
    except Exception:
        assert False



# Generated at 2022-06-24 23:17:24.692217
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import AnsibleModule
    module = AnsibleModule()


# Generated at 2022-06-24 23:17:29.865305
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    test_module = None

    # Call method find_facter of FacterFactCollector
    facter_path = facter_fact_collector_0.find_facter(test_module)

    assert facter_path == None
    assert facter_path == None
    assert facter_path == None
    assert facter_path == None

    return


# Generated at 2022-06-24 23:17:33.006425
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output() != None


# Generated at 2022-06-24 23:17:38.384477
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_find_facter_0 = FacterFactCollector()
    with mock.patch(
            'ansible.module_utils.facts.collector.FacterFactCollector.find_facter',
            return_value='/opt/puppetlabs/bin/cfacter'):
        res = facter_fact_collector_find_facter_0.find_facter(ansible_module_0)
    assert res == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-24 23:17:48.128283
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts = dict()
    result_0 = facter_fact_collector_0.collect(collected_facts=collected_facts)
    result_1 = facter_fact_collector_0.collect(collected_facts=collected_facts)
    result_2 = facter_fact_collector_0.collect(collected_facts=collected_facts)
    result_3 = facter_fact_collector_0.collect(collected_facts=collected_facts)
    result_4 = facter_fact_collector_0.collect(collected_facts=collected_facts)
    result_5 = facter_fact_collector_0.collect(collected_facts=collected_facts)

# Generated at 2022-06-24 23:17:54.184274
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = object()
    facter_path_0 = '/opt/puppetlabs/bin/cfacter'

    rc, out, err = facter_fact_collector_0.run_facter(module_0, facter_path_0)

    assert rc == 0
    assert out is not None
    assert err == ''


# Generated at 2022-06-24 23:17:59.878254
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import ModuleUtilsFacts
    module_utils_facts_instance = ModuleUtilsFacts()
    facter_fact_collector_instance = FacterFactCollector()

    facter_output = facter_fact_collector_instance.get_facter_output(module_utils_facts_instance)
    assert facter_output is not None


# Generated at 2022-06-24 23:18:02.244120
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_dict = facter_fact_collector_0.collect()
    assert facter_dict == {}


# Generated at 2022-06-24 23:18:05.356692
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    find_facter_0 = FacterFactCollector()

    # TODO: implement test.
    #       See examples/test_modules/ansible_test/_ansible_module_generators.py
    #       for an example.
    find_facter_0.find_facter()



# Generated at 2022-06-24 23:20:17.191909
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Testing module os
    try:
        import os
        module = os
    except Exception:
        module = None

    # Testing class FacterFactCollector
    try:
        from ansible.module_utils.facts.collector import FacterFactCollector
        facter_fact_collector_1 = FacterFactCollector()
    except Exception:
        facter_fact_collector_1 = None

    # Using mock and monkeypatch to replace the get_bin_path and run_command methods of module os
    def fake_get_bin_path(self, exe, opt_dirs=None):
        return '/usr/local/bin/facter'


# Generated at 2022-06-24 23:20:18.229639
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()

# Generated at 2022-06-24 23:20:22.427294
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.virtual.facter import find_facter
    facter_fact_collector_1 = FacterFactCollector()
    # FIXME: find a better way to test this
    assert facter_fact_collector_1.find_facter is find_facter


# Generated at 2022-06-24 23:20:33.176803
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    facter_fact_collector_0 = FacterFactCollector()

    # assert facter_fact_collector_0._fact_ids == set(['facter'])


# Generated at 2022-06-24 23:20:39.144581
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.find_facter = MagicMock()
    facter_fact_collector.find_facter.return_value = None
    result = facter_fact_collector.get_facter_output()
    assert result is None


# Generated at 2022-06-24 23:20:43.425655
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    collector = FacterFactCollector()
    module = _MockModule()

    cfacter_path = module.get_bin_path('cfacter', opt_dirs=['/opt/puppetlabs/bin'])
    facter_path = module.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])

    # If cfacter is available and facter is not, then facter is preferred
    if cfacter_path is not None and facter_path is None:
        facter_path = cfacter_path

    assert facter_path == collector.find_facter(module)


# Generated at 2022-06-24 23:20:44.623161
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    result = facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:20:45.799590
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output()

# Generated at 2022-06-24 23:20:50.586177
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    arg_0 = None
    arg_1 = '/opt/puppetlabs/bin/cfacter'
    arg_2 = 'cfacter'
    arg_3 = None
    arg_4 = '/opt/puppetlabs/bin'
    arg_5 = 'cfacter'
    arg_6 = None
    arg_7 = '/opt/puppetlabs/bin'
    arg_8 = 'cfacter'
    arg_9 = None
    arg_10 = '/opt/puppetlabs/bin'
    # execute method run_facter of class FacterFactCollector

# Generated at 2022-06-24 23:20:53.772353
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter(module, facter_path)
