

# Generated at 2022-06-24 23:11:17.977658
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    # A call to find_facter()
    facter_path_0 = facter_fact_collector_0.find_facter(module_0)


# Generated at 2022-06-24 23:11:20.393478
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """ Unit testing for collect method of class FacterFactCollector """
    #
    # TODO: Write this unit test
    #
    pass


# Generated at 2022-06-24 23:11:23.070274
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()

    assert facter_fact_collector_1.get_facter_output() is None

# Generated at 2022-06-24 23:11:34.105118
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Note that this is _NOT_ a real module. It is a mock obj from pytest
    module = MockModule()

    # We need to stub some methods on the module so that we are able
    # to mock the find_facte_path, and run_facter functions.

    def mock_find_facter(self, module):
        return "/opt/puppetlabs/bin/facter"

    # This function will return the contents of the file
    # test/unittests/facter_facts.txt.
    def mock_run_facter(self, module, facter_path):
        module.run_command = mock_run_command
       

# Generated at 2022-06-24 23:11:36.465856
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:11:40.292974
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() is not None


# Generated at 2022-06-24 23:11:42.366103
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    path = facter_fact_collector_1.find_facter()
    assert path


# Generated at 2022-06-24 23:11:42.866021
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    pass

# Generated at 2022-06-24 23:11:49.634001
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Arrange
    facter_fact_collector = FacterFactCollector()

    # Act
    facter_path = facter_fact_collector.find_facter()

    # Assert
    assert facter_path is not None
    assert len(facter_path) > 0


# Generated at 2022-06-24 23:11:54.792050
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:12:03.254460
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    fake_module_0 = FakeModule()

    def get_bin_path_0(name, opt_dirs=None):
        return name

    fake_module_0.get_bin_path = get_bin_path_0
    facter_fact_collector_0 = FacterFactCollector()
    facter_path = facter_fact_collector_0.find_facter(fake_module_0)
    expected_0 = 'facter'
    assert facter_path == expected_0


# Generated at 2022-06-24 23:12:10.737559
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collection import Facts

    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.collect = None
    facter_fact = Facts()
    facter_fact_collector.collect(facter_fact)



# Generated at 2022-06-24 23:12:19.772232
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector_get_facter_output_facter_path = facter_fact_collector.find_facter('module')
    facter_fact_collector_get_facter_output_output = facter_fact_collector.get_facter_output('module')

    assert facter_fact_collector_get_facter_output_facter_path is not None
    assert facter_fact_collector_get_facter_output_output is not None


# Generated at 2022-06-24 23:12:24.624197
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector.find_facter()


# Generated at 2022-06-24 23:12:35.653263
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import sys
    import imp
    import tmpdir_factory

    mod = imp.new_module('mock_ansible_module')
    sys.modules['ansible.module_utils.basic'] = mod
    mod.module = mod

    import ansible.module_utils.facts.collectors.facter

    def mock_get_bin_path(binary, opt_dirs=None):
        return None

    mock_module = mod.ModuleStub(bin_path={'facter/cfacter': '/opt/puppetlabs/bin/facter',
                                           'facter': '/opt/puppetlabs/bin/facter'})

    facter_fact_collector_0 = ansible.module_utils.facts.collectors.facter.FacterFactCollector()
    facter_fact

# Generated at 2022-06-24 23:12:43.349250
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_2 = FacterFactCollector()
    ansible_module_0 = AnsibleModule(argument_spec = dict())
    ansible_module_0.params['ansible_facts'] = dict()
    facter_path_0 = facter_fact_collector_2.find_facter(ansible_module_0)
    assert facter_path_0 == '/usr/bin/facter'


# Generated at 2022-06-24 23:12:47.832927
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    # Test with invalid module
    facter_fact_collector_1 = FacterFactCollector()
    output = facter_fact_collector_1.collect()
    assert(output == {})

    # Test with valid module
    facter_fact_collector_2 = FacterFactCollector()
    # TODO: add module back to test
    #output = facter_fact_collector_2.collect(module=module)
    # TODO: add assertion back to test
    #assert(True)

    return

# Generated at 2022-06-24 23:12:50.293573
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:12:57.202071
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    module = AnsibleModuleMock()
    module.get_bin_path = MagicMock(return_value="/bin/facter")

    facter_path = facter_fact_collector.find_facter(module)

    assert facter_path == "/bin/facter"


# Generated at 2022-06-24 23:13:02.118187
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    collector = FacterFactCollector()
    module = MockModule('/usr/bin/facter', '{"a":"b"}')
    assert collector.get_facter_output(module) == '{"a":"b"}'

# Generated at 2022-06-24 23:13:13.629219
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class MockedModule():
        def __init__(self):
            self.run_command_list = []

        def get_bin_path(self, path, *kwargs):
            self.run_command_result = ['ansible_bin_path']
            self.run_command_list.append(path)
            return self.run_command_result

    class MockedCollectors():
        def __init__(self):
            self.run_command_list = []

        def get_bin_path(self, path, *kwargs):
            self.run_command_result = ['ansible_bin_path']
            self.run_command_list.append(path)
            return self.run_command_result


# Generated at 2022-06-24 23:13:17.246111
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    FacterFactCollector_run_facter = FacterFactCollector().run_facter
    assert FacterFactCollector_run_facter() == (0, '', '')


# Generated at 2022-06-24 23:13:19.836280
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # TODO: Use mock
    FacterFactCollector().collect()

# Generated at 2022-06-24 23:13:22.311739
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    list_1 = []
    facter_fact_collector_1.collect(list_1)



# Generated at 2022-06-24 23:13:27.815035
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # init FacterFactCollector
    facter_fact_collector_0 = FacterFactCollector()
    # init module
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    # call method find_facter with module_0 as parameter
    find_facter_ret_val = facter_fact_collector_0.find_facter(module_0)
    # assert find_facter_ret_val is not None
    assert find_facter_ret_val is not None


# Generated at 2022-06-24 23:13:33.994725
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class Module:
        def get_bin_path(self, path, opt_dirs=[]):
            return path
    module_0 = Module()
    str_1 = facter_fact_collector_0.find_facter(module_0)
    exp = 'facter'
    assert str_1 == exp


# Generated at 2022-06-24 23:13:40.388755
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    mock_module_0 = MagicMock()
    mock_module_1 = MagicMock()
    mock_module_2 = MagicMock()
    mock_module_3 = MagicMock()
    mock_module_4 = MagicMock()
    mock_collected_facts_0 = MagicMock()
    mock_collector_0 = MagicMock()
    mock_run_command_0 = MagicMock()
    mock_join_0 = MagicMock(return_value="/bin")
    mock_get_bin_path_0 = MagicMock(side_effect=[
        '/opt/puppetlabs/bin/cfacter', '/opt/puppetlabs/bin/facter'])

# Generated at 2022-06-24 23:13:42.811530
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    collector0 = FacterFactCollector()

    assert(collector0.collect() == {})

# Generated at 2022-06-24 23:13:52.739461
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()

    # Case 0: No 'facter' or 'cfacter' executable in path or alternative directory
    facter_path_0 = facter_fact_collector_1.find_facter(None)
    assert facter_path_0 is None

    # Case 1: 'cfacter' available
    facter_path_1 = facter_fact_collector_1.find_facter(None)
    assert facter_path_1 is None

    # Case 2: 'facter' available
    facter_path_2 = facter_fact_collector_1.find_facter(None)
    assert facter_path_2 is None


# Generated at 2022-06-24 23:13:53.990706
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:14:07.172431
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    fact_collector = FacterFactCollector()
    facter_output = fact_collector.get_facter_output()

# Generated at 2022-06-24 23:14:10.944178
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    try:
        assert (facter_fact_collector_0.find_facter is not None)
    except AssertionError:
        print('Expected valid expression or syntax, got', facter_fact_collector_0.find_facter)


# Generated at 2022-06-24 23:14:14.087441
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # TODO: Mock the module, and figure out how to mock the module.run_command()
    # call so we can fake return values from facter
    assert False

# Generated at 2022-06-24 23:14:20.380661
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    facter_fact_collector_0 = FacterFactCollector()
    # Testing an edge case, if the system does not have facter.
    # On my system, facter is installed in /usr/bin/facter
    module_1 = AnsibleModule(argument_spec={})
    module_1.get_bin_path = lambda a, b: None
    facter_path = facter_fact_collector_0.find_facter(module_1)
    if facter_path is not None:
        exit(1)
    print(facter_path)


# Generated at 2022-06-24 23:14:23.376586
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

    collected_facts = {}

    facter_fact_collector_1.collect(collected_facts=collected_facts)

    facter_fact_collector_1.collect()



# Generated at 2022-06-24 23:14:33.131409
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_1 = FacterFactCollector()

    from ansible.module_utils.facts.collector import AnsibleModule

    ansible_module_1 = AnsibleModule(
        argument_spec = dict()
    )

    ansible_module_1.params = dict()
    ansible_module_1.params['path'] = None
    ansible_module_1.run_command = run_command_0
    ansible_module_1.get_bin_path = get_bin_path_0

    facter_path_1 = facter_fact_collector_1.find_facter(ansible_module_1)


# Generated at 2022-06-24 23:14:36.695106
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''
    test case for find_facter of FacterFactCollector.
    '''

    facter_fact_collector_0 = FacterFactCollector()  # pylint: disable=too-many-function-args
    assert facter_fact_collector_0.find_facter(None) == None



# Generated at 2022-06-24 23:14:42.349678
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_2 = FacterFactCollector()
    facter_fact_collector_3 = FacterFactCollector()
    facter_fact_collector_4 = FacterFactCollector()
    facter_fact_collector_5 = FacterFactCollector()
    facter_fact_collector_6 = FacterFactCollector()
    facter_fact_collector_7 = FacterFactCollector()
    facter_fact_collector_8 = FacterFactCollector()


# Generated at 2022-06-24 23:14:44.279627
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.collect() is None


# Generated at 2022-06-24 23:14:49.985979
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TempModule:
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/some/path/facter'
            elif name == 'cfacter':
                return '/some/path/cfacter'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/some/path/facter --puppet --json':
                return 0, '{"result":"not None"}', ''
            else:
                return 1, '', 'Test: Unexpected command run'

    temp_module_0 = TempModule()
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:15:18.416361
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO: if I understand this right, this is to be consumed by a Mock Module...
    #       IOW, we are not testing get_facter_output.  We are testing our mock
    #       module, whatever it does, and whatever it returns by mocking the return
    #       of get_facter_output.  BUT, I dont know how to mock...
    #       and I want to know that get_facter_output does what I think it does
    #       before I mock it.
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output() == None


# test_case_0()

# Generated at 2022-06-24 23:15:28.230024
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    # Test with non-existing path
    try:
        class bogus_module(object):
            def get_bin_path(self, arg1, arg2):
                return '/bogus_path/facter'
            def run_command(self, arg1):
                return 0, 'a', 'b'
        facter_output_0 = facter_fact_collector_0.get_facter_output(bogus_module())
    except OSError:
        pass
    except Exception as e:
        raise AssertionError('Unexpected exception raised:', str(e)) from e


# Generated at 2022-06-24 23:15:36.256246
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    ffc = FacterFactCollector()
    collected_facts = dict()
    facter_facts = ffc.collect(collected_facts=collected_facts)
    assert isinstance(facter_facts, dict)

    if facter_facts:
        assert isinstance(facter_facts['facter_aio_agent_version'], str)
        assert isinstance(facter_facts['facter_facterversion'], str)
        assert isinstance(facter_facts['facter_ipaddress_eth0'], str)


# Generated at 2022-06-24 23:15:39.612124
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    ansible_module = ansible.module_utils.basic.AnsibleModule
    facter_path = facter_fact_collector.find_facter(ansible_module)
    assert facter_path is None

# Generated at 2022-06-24 23:15:42.361679
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.name == 'facter'
    assert facter_fact_collector_0._fact_ids == set(['facter'])
    assert 'facter' in facter_fact_collector_0.collect()
    assert facter_fact_collector_0.collect()['facter']['osfamily'] == 'RedHat'


# Generated at 2022-06-24 23:15:48.964144
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # set module argparse arguments
    module = type(str('AnsibleModule'), (object, ), {
        'get_bin_path': lambda self, path, opt_dirs=[] : '/usr/bin/facter' if path == 'facter' else None,
    })

    ins = FacterFactCollector()
    assert ins.find_facter(module) == '/usr/bin/facter'

# Generated at 2022-06-24 23:15:53.744773
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()


# Generated at 2022-06-24 23:16:00.221895
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.collect()
    assert facter_fact_collector_1.name == 'facter'


if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:16:02.115104
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    # FIXME: Does a mock module exist?


# Generated at 2022-06-24 23:16:09.557809
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_module_0 = get_random_module()
    random_bin_path = "".join(get_random_string_list(3))
    get_bin_path_return = None
    random_bin_path_part_0 = "".join(get_random_string_list(10))
    random_bin_path_part_1 = "".join(get_random_string_list(10))
    random_command = random_bin_path + " --puppet --json"
    random_return_code = get_random_int()
    random_output = '\n'.join(get_random_string_list(1))
    random_error = get_random_string()

# Generated at 2022-06-24 23:17:00.549505
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # Example args: (module, facter_path='/opt/puppetlabs/bin/facter')
    # Return: (rc, out, err)
    # Return type: (int, str, str)
    assert facter_fact_collector_0.run_facter() == (0, '', '')


# Generated at 2022-06-24 23:17:03.394266
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output(None) == None

# Generated at 2022-06-24 23:17:07.893349
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ffc = FacterFactCollector()
    ffc.find_facter = lambda module: '/usr/bin/facter'
    assert ffc.find_facter(None) == '/usr/bin/facter'


# Generated at 2022-06-24 23:17:10.030752
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    rv = facter_fact_collector_1.collect()
    assert isinstance(rv, dict)


# Generated at 2022-06-24 23:17:17.014679
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    print('Test #1: method get_facter_output')
    facter_fact_collector = FacterFactCollector()
    facter_output = facter_fact_collector.get_facter_output(None)
    print('facter_output = {0}'.format(facter_output))
    if facter_output:
        print('facter_output = {0}'.format(json.dumps(facter_output, indent=2)))
    else:
        print('facter_output = None')
    print()


# Generated at 2022-06-24 23:17:27.675307
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()

    # testing with a crude mock
    class MockModule(object):
        def __init__(self):
            self.params = {'facter_path': '/usr/bin/facter'}

        def get_bin_path(self, prog, opt_dirs):
            return self.params.get('facter_path')

        def run_command(self, facter_path):
            return (facter_path,)

    facter_path = '/usr/bin/facter'
    module_0 = MockModule()
    module_1 = MockModule()
    module_1.params['facter_path'] = '/usr/bin/ruby'
    module_2 = MockModule()
    module_2.params['facter_path'] = ''

    # always

# Generated at 2022-06-24 23:17:36.560969
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_2 = FacterFactCollector()

    class MockModule(object):
        def __init__(self, run_command_results):
            self.run_command_results = run_command_results
            self.run_command_calls = []

        def run_command(self, command):
            self.run_command_calls.append(command)
            return self.run_command_results.pop(0)

    module_mock = MockModule([(0, "mock_out", ""), (0, "mock_out", "")])

    facter_fact_collector_2.find_facter = lambda a: "/opt/puppetlabs/bin/facter"

# Generated at 2022-06-24 23:17:38.550311
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()


# Generated at 2022-06-24 23:17:43.051031
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    # Create a basic module object
    module = AnsibleModule(argument_spec=dict())

    # Create a facter fact collector object
    facter_fact_collector = FacterFactCollector()

    # Check that find_facter returns expected result
    assert facter_fact_collector.find_facter(module) == module.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])


# Generated at 2022-06-24 23:17:44.516792
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:19:34.901356
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    facter_output = facter_fact_collector_0.get_facter_output(None)
    assert facter_output == None



# Generated at 2022-06-24 23:19:44.187749
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    import tempfile
    import shutil

    class MockModule():
        def __init__(self, return_code=0, return_value="", return_error=""):
            self._return_code=return_code
            self._return_value_str=str(return_value)
            self._return_value_bytes=bytes(self._return_value_str,"utf-8")
            self._return_error_str=str(return_error)
            self._return_error_bytes=bytes(self._return_error_str,"utf-8")

            self._write_to_file_called = False
            self._write_to_file_file_path = None
            self._write_to_file_data = None
            self._write_to_file_mode = None

            self._makedirs_called = False
            self

# Generated at 2022-06-24 23:19:46.608301
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output('module_replacement') is None


# Generated at 2022-06-24 23:19:50.672925
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    mock_module_0 = MockModule()
    mock_module_0.get_bin_path = Mock(return_value=None)
    expected_result = None
    result = facter_fact_collector_0.find_facter(mock_module_0)
    assert result == expected_result


# Generated at 2022-06-24 23:20:00.917077
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    facter_fact_collector_1 = FacterFactCollector()

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary_name, opt_dirs=[]):
            return self.binary_path

        def run_command(self, module, facter_path):
            return self.returncode, self.out, self.err

    class MockModule_1(MockModule):
        # Mock for non-existent facter
        binary_path = None
        returncode = 0
        out = ''
        err = ''

        def __init__(self):
            self.params = {}

    class MockModule_2(MockModule):
        # Mock for existing facter
        binary_path = '/usr/bin/facter'
        returncode

# Generated at 2022-06-24 23:20:11.141335
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()

    class MockModule:
        def get_bin_path(self, program, opt_dirs = None):
            if program == 'facter':
                return '/usr/bin/facter'
            if program == 'cfacter':
                return None
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test_key": "facter_test_value"}', ''
            else:
                return None, '', ''

    facter_output_0 = facter_fact_collector_1.get_facter_output(MockModule())
## TODO: check for valid facter_output_0


# Generated at 2022-06-24 23:20:17.687162
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    ffc = FacterFactCollector()
    module = MockModule()
    module.run_command.return_value = (0, '{"architecture":"x86_64","domain":"example.com"}', '')
    assert ffc.find_facter(module)
    ffc.get_facter_output(module)


# Generated at 2022-06-24 23:20:18.134709
# Unit test for method find_facter of class FacterFactCollector

# Generated at 2022-06-24 23:20:30.197398
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    import sys
    import os
    import re

    path_to_module = sys.modules[__name__].__file__
    path_to_tests = path_to_module
    while os.path.basename(path_to_tests) != 'test':
        path_to_tests = os.path.dirname(path_to_tests)

    path_to_ansible_module_utils = re.sub('/test/units', '/lib/ansible/module_utils', path_to_tests)

    sys.path.insert(0, path_to_ansible_module_utils)

    from ansible.module_utils.facts import default_collectors, Collector

    class MockModule(object):
        def __init__(self, path_to_facter):
            self._path_to_facter = path_to

# Generated at 2022-06-24 23:20:34.754480
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    assert FacterFactCollector.find_facter() == 'facter'
