

# Generated at 2022-06-24 23:11:20.086597
# Unit test for method get_facter_output of class FacterFactCollector

# Generated at 2022-06-24 23:11:24.526920
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_collect = FacterFactCollector()
    facter_output = '{"facter_a": "fact"}'
    try:
        facter_fact_collector_collect.get_facter_output = lambda x: facter_output
        facter_fact_collector_collect.collect()
    except:
        pass

# Generated at 2022-06-24 23:11:29.378548
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    # unimplemented test
    assert facter_fact_collector.find_facter() == None


# Generated at 2022-06-24 23:11:35.294158
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    class obj_0:
        def _ansible_version(self, _parse=False):
            return '2.1.0.0'
        def get_bin_path(self, _name, _warn=None, _opt_dirs=None):
            return 'out/bin/file.bin'
        def run_command(self, _command, data=None, _check_rc=True, executable=None, _use_unsafe_shell=False, _tmp_path=None, _in_data=None, _silent_codes=None, _binary_data=False, _path_prefix=None, _cwd=None, _raise_exc=False):
            out = 'out'
            err = 'err'
            rc = 0
            return

# Generated at 2022-06-24 23:11:39.206540
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    facter_path = facter_fact_collector_1.find_facter(module)


# Generated at 2022-06-24 23:11:41.626068
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output('module_0') == 'None'


# Generated at 2022-06-24 23:11:46.349855
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # NOTE: mock module is NOT in Ansible default module path
    # so we need to make sure it is importable
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import ansible.module_utils.facts.test_modules.mock_module as mock_module_0
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter(mock_module_0) is None
    # FIXME: should we test with other possible paths here?



# Generated at 2022-06-24 23:11:47.334416
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    fixture = FacterFactCollector()
    fixture.collect()

# Generated at 2022-06-24 23:11:50.562397
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    test_module_0 = MockModule()
    test_module_0.run_command = Mock(return_value=(None, 'bin/cfacter', None))
    assert facter_fact_collector_0.find_facter(test_module_0) == 'bin/cfacter'



# Generated at 2022-06-24 23:11:52.363228
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:12:06.090058
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # See if we can collect facts from 'facter'
    facter_fact_collector_0 = FacterFactCollector()
    # Returned value should be of type 'dict'
    assert(isinstance(facter_fact_collector_0.collect(), dict))
    # facter_fact_collector_0.collect() should return a non-empty 'dict'
    assert(facter_fact_collector_0.collect() != {})


# Generated at 2022-06-24 23:12:14.234937
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    facter_fact_collector = FacterFactCollector()

    # This is a fake module, but it will be used by the facter fact collector
    # to look for facter binary location and to run facter and then parse
    # the json result.
    class FakeModule(object):

        def __init__(self):
            self.module_builtin = ansible.module_utils.basic

        def get_bin_path(self, executable, opt_dirs=None, required=False):

            if executable == 'facter':
                return '/usr/bin/facter'


# Generated at 2022-06-24 23:12:24.391768
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()

    # mock a moduleable object
    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return 'facter_path'

        def run_command(self, *args, **kwargs):
            return (0, "{\"facter_1\":\"a\", \"facter_2\":\"b\"}")

    facter_module_obj = MockModule()
    facter_rc, facter_out, facter_err = facter_fact_collector.run_facter(facter_module_obj, 'facter_path')

    assert facter_rc == 0
    assert facter_out == "{\"facter_1\":\"a\", \"facter_2\":\"b\"}"

# Generated at 2022-06-24 23:12:28.454421
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    data = 'cfacter'
    assert facter_fact_collector_1.find_facter(data) == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-24 23:12:29.986459
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.find_facter() is not None

# Generated at 2022-06-24 23:12:33.157557
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    # TODO: Add functionality to test collect method
    res = facter_fact_collector_0.collect()

    assert type(res) is dict

# Generated at 2022-06-24 23:12:37.964056
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:12:44.298372
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    # tests that the collector does not fail in the absence of a module
    facter_fact_collector_1.collect()

    # TODO: This test is currently disabled as it is not a unit test.
    # It probably should be replaced by a pytest fixture that gives
    # a fake module
    #
    # tests that the collection of facts is possible with a module
    # facter_fact_collector_2 = FacterFactCollector(module=AnsibleModule(
    #    argument_spec={}
    #))
    # facter_fact_collector_2.collect()


# Generated at 2022-06-24 23:12:48.552151
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    result = facter_fact_collector_1.collect()

# Generated at 2022-06-24 23:12:56.741755
# Unit test for method find_facter of class FacterFactCollector

# Generated at 2022-06-24 23:13:09.738315
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_module_0 = AnsibleModule()
    assert facter_fact_collector_0.find_facter(ansible_module_0) is not None


# Generated at 2022-06-24 23:13:21.286247
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class module_object:
        def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=True):
            if command == '/opt/puppetlabs/bin/facter --puppet --json':
                return 0, '{"test":"test"}', ''
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == 'facter':
                return '/opt/puppetlabs/bin/facter'
    module = module_object()
    facter_fact_collector_0._module = module

    # call the method being tested
    facter_fact_collector_0.collect()

    # verify the results are

# Generated at 2022-06-24 23:13:23.040901
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    assert facter_fact_collector_0.run_facter(None, None) == (None, None, None)


# Generated at 2022-06-24 23:13:30.531189
# Unit test for method get_facter_output of class FacterFactCollector

# Generated at 2022-06-24 23:13:34.256825
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # TODO: implement assert_raises
    try:
        facter_fact_collector_0.find_facter()
    except:
        pass


# Generated at 2022-06-24 23:13:36.093990
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    result = facter_fact_collector.collect()


# Generated at 2022-06-24 23:13:41.121085
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''
    Unit test for method find_facter of class FacterFactCollector
    '''
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.find_facter == None


# Generated at 2022-06-24 23:13:48.310059
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-24 23:13:56.234918
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_2 = FacterFactCollector()
    assert facter_fact_collector_0.collect() is None
    assert facter_fact_collector_1.collect() is None
    assert facter_fact_collector_2.collect() is None

# Generated at 2022-06-24 23:14:05.196862
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()

    # find_facter(module=None)
    try:
        facter_fact_collector.find_facter(module=None)
    except Exception as e:
        if 'Argument module does not have expected type <module' in str(e):
            pass
    else:
        assert False

    # find_facter(module=module)
    try:
        facter_fact_collector.find_facter(module=BaseFactCollector())
    except Exception as e:
        if 'Argument module does not have expected type <module' in str(e):
            pass
    else:
        assert False


# Generated at 2022-06-24 23:14:18.631144
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()


    # Test case 1
    facter_path_1 = facter_fact_collector_1.find_facter(module=None)
    assert facter_path_1 == '/usr/bin/facter'


# Generated at 2022-06-24 23:14:21.061558
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() is None


# Generated at 2022-06-24 23:14:27.708840
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    def _side_effect(path):
        if path == '/usr/bin/facter --puppet --json':
            return 0, '/usr/bin\n', ''
        elif path == '/bin/facter --puppet --json':
            return 0, '/bin\n', ''
        elif path == '/usr/bin/facter':
            return 0, '', ''

    def _side_effect_get_bin_path(path, paths):
        if path == 'facter' and '/opt/puppetlabs/bin' in paths:
            return '/bin/facter'

    module = MagicMock()
    module.run_command = MagicMock(side_effect=_side_effect)
    module.get_bin_path = MagicMock(side_effect=_side_effect_get_bin_path)


# Generated at 2022-06-24 23:14:35.256384
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_path = facter_fact_collector_0.find_facter()
    xml_tests.assertEquals(facter_path is None)

    xml_tests.assertEquals(facter_fact_collector_0.find_facter(module=None) is None)

    class MockModule(object):
        def __init__(self, **kwargs):
            self.run_command_kwargs = kwargs
            self.run_command_return_value = ('', '')

        def run_command(self, cmd, *args, **kwargs):
            for k in self.run_command_kwargs:
                self.run_command_kwargs[k] = kwargs[k]
            return self.run_command

# Generated at 2022-06-24 23:14:38.648639
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_1 = mock.Mock()
    module_1.get_bin_path.return_value = 'facter'
    facter_fact_collector_0.find_facter(module_1)


# Generated at 2022-06-24 23:14:44.592559
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Setup
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector is not None

    # Exercise

# Generated at 2022-06-24 23:14:52.790021
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO: Write unit tests
    # FacterFactCollector_0 = FacterFactCollector()
    # if FacterFactCollector_0.get_facter_output(module):
    #    print("Successfully ran get_facter_output of FacterFactCollector")
    # else:
    #    print("get_facter_output of FacterFactCollector failed")
    pass


# Generated at 2022-06-24 23:14:56.075082
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    ansible_module = MagicMock()
    ansible_module.get_bin_path.return_value = "usr/bin/cfacter"
    ansible_module.run_command.return_value = (0, "[{ \"virtual\":\"physical\" },{ \"name\":\"FACTER-42\" }]", None)
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect(ansible_module)



# Generated at 2022-06-24 23:14:59.184990
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collectors = [{'name': 'first_collector'}, {'name': 'second_collector'}]


# Generated at 2022-06-24 23:15:03.043611
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO: use mock module
    return



# Generated at 2022-06-24 23:15:22.015545
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_module_0 = AnsibleModule()
    facter_path_0 = '/usr/bin/facter'
    return_value_0 = facter_fact_collector_0.run_facter(ansible_module_0, facter_path_0)
    assert isinstance(return_value_0, tuple)
    assert return_value_0[0] == 0
    assert isinstance(return_value_0[1], str)
    assert not return_value_0[1]
    assert isinstance(return_value_0[2], str)
    assert not return_value_0[2]


# Generated at 2022-06-24 23:15:24.215523
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter(None, None)


# Generated at 2022-06-24 23:15:31.131527
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    class module0(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'
        def run_command(self, *args, **kwargs):
            return 0, '{"OS":{"name":"Windows","family":"windows","version":"8.1"},"OS-EXTENDED":{"shells":["/bin/sh","/bin/bash","/usr/bin/sh","/usr/bin/bash"]},"PATH":["/usr/local/sbin","/usr/local/bin","/usr/sbin","/usr/bind","/usr/bin","/sbin","/bin"]}', ''
    ansible_facts_0 = facter_fact_collector_0.get_facter_output(module0())



# Generated at 2022-06-24 23:15:34.120193
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()

# Generated at 2022-06-24 23:15:40.097413
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
  import ansible.module_utils.facts.collector.facter
  collect_funcs = { 'facter': ansible.module_utils.facts.collector.facter, 'test':test_FacterFactCollector_get_facter_output }
  facter_fact_collector = FacterFactCollector(collectors=collect_funcs)
  assert facter_fact_collector.get_facter_output(module) == 'test_FacterFactCollector_get_facter_output_result'

# Generated at 2022-06-24 23:15:45.871099
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    """
    Test find_facter of class FacterFactCollector
    """
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.find_facter(None) == 'facter'

    facter_fact_collector_2 = FacterFactCollector()
    facter_fact_collector_2._bin_paths = {'facter': 'test_facter_bin_path'}
    assert facter_fact_collector_2.find_facter(None) == 'test_facter_bin_path'


# Generated at 2022-06-24 23:15:54.342094
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    def mock_get_bin_path(name, *a, **kw):
        if name == "cfacter":
            return "/foo/cfacter"
        elif name == "facter":
            return "/foo/facter"
        return None

    module = lambda: None
    module.get_bin_path = mock_get_bin_path

    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.find_facter(module) == "/foo/cfacter"


# Generated at 2022-06-24 23:15:58.226653
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    _facter_path = '/opt/puppetlabs/bin/facter'
    assert facter_fact_collector_1.find_facter(_facter_path) == '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-24 23:16:06.965732
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()

    # Test case:
    # 'module_1' is a module object
    # 'module_1' has attribute bin_path which is a dictionary containing
    # 'facter' and 'cfacter' entries where the value of each entry is a string
    # representing a file path
    module_1 = MockAnsibleModule()
    module_1.bin_path = {'facter': 'C:\\Program Files\\puppetlabs\\puppet\\bin\\facter.bat', \
                         'cfacter': 'C:\\Program Files\\puppetlabs\\puppet\\bin\\cfacter.bat'}
    # Test assertion 1:
    # find_facter() should return 'C:\\Program Files\\puppetlabs\\puppet\\bin\\cfacter.bat

# Generated at 2022-06-24 23:16:12.598514
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

    # Test no args
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:16:37.453846
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

    assert facter_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:16:39.721640
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    #assert facter_fact_collector_0.find_facter() is not None


# Generated at 2022-06-24 23:16:41.929713
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module = AnsibleModule(argument_spec={})
    facter_path = facter_fact_collector_0.find_facter(module)
    assert facter_fact_collector_0.run_facter(module, facter_path) is not None

# Generated at 2022-06-24 23:16:43.721967
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter('/usr/bin/facter') == '/usr/bin/facter'


# Generated at 2022-06-24 23:16:47.454750
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
# Initialize the class
    facter_fact_collector = FacterFactCollector()
# Invoke method
    facter_fact_collector.collect()
# Assertions
# FIXME: assert something about result


# Generated at 2022-06-24 23:16:49.080393
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:16:54.298912
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO: complete this test
    pass


# Generated at 2022-06-24 23:17:01.114829
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    ffc = FacterFactCollector()
    # inject a fake find_facter to test that it is called
    ffc.find_facter = lambda x: '/foo/bar'
    # inject a fake run_facter to test that it is called
    ffc.run_facter = lambda x, y: (0, '', '')

    assert ffc.get_facter_output(True) == ''


# Generated at 2022-06-24 23:17:04.686518
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    _result = facter_fact_collector_0.find_facter()


# Generated at 2022-06-24 23:17:09.393721
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()

    # TODO: We may want to re-write this to not be a system call
    #       but instead check the actual paths
    test_cmd = "which facter"

    facter_fact_collector.find_facter()

# Generated at 2022-06-24 23:17:56.673070
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output(module = None)


# Generated at 2022-06-24 23:18:05.818388
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts = {}

    # Call method collect of class FacterFactCollector
    ret = facter_fact_collector_0.collect()

    # Assertion of facter
    if 'facter' in ret:
        raise AssertionError("assertion error, facter does not exist in returned facts")

    # Assertion of all other fact_ids in ret, shouldn't be any other facts
    for fact_id in ret:
        if fact_id != 'facter':
            raise AssertionError("assertion error, fact %s should not exist in returned facts" %fact_id)

    # Test with a module provided
    # Test with a module provided
    class TestModule:
        def __init__(self):
            self.params = {}

# Generated at 2022-06-24 23:18:08.280529
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts = dict()
    assert facter_fact_collector_0.collect(module=None, collected_facts=collected_facts) is None


# Generated at 2022-06-24 23:18:12.417940
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    mock_module_0 = MockModule()
    assert facter_fact_collector_1.get_facter_output(mock_module_0) == None


# Generated at 2022-06-24 23:18:20.039621
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    import sys
    import io
    import unittest

    class MockModule:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self._result = (0, '', '')

        def get_bin_path(self, *args, **kwargs):
            return '/path/to/bin/facter'

        def run_command(self, *args, **kwargs):
            return self._result

    class TestCase(unittest.TestCase):
        def run_facter_test(self, facter_path, args, rc=0, out='', err=''):
            # setup
            module = MockModule()
            facter_fact_collector_0 = FacterFactCollector()

            # test
            # - return

# Generated at 2022-06-24 23:18:29.477570
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Instantiate a mock module object.
    module = MockModule()
    module.get_bin_path.return_value = "/fake/path"

    # Instantiate a FacterFactCollector object.
    facter_fact_collector = FacterFactCollector()

    # Expect subprocess.check_output to be called with 
    # arguments = ("/fake/path --puppet --json",) and 
    # keyword arguments = {}
    facter_fact_collector.run_command.return_value = (0, "{ fact: 'value' }", "")
    facter_output = facter_fact_collector.get_facter_output(module)
    assert facter_output == "{ fact: 'value' }"

    # Expect subprocess.check_output to be called with 
    # arguments = ("/fake

# Generated at 2022-06-24 23:18:31.251716
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    # Simple test for collect.
    collected_facts_1 = facter_fact_collector_1.collect()
    assert collected_facts_1 is not None


# Generated at 2022-06-24 23:18:41.815163
# Unit test for method run_facter of class FacterFactCollector

# Generated at 2022-06-24 23:18:42.241745
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass

# Generated at 2022-06-24 23:18:43.659696
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    paste_collector_0 = FacterFactCollector()
    assert paste_collector_0.find_facter() is None


# Generated at 2022-06-24 23:20:36.883322
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()


# Generated at 2022-06-24 23:20:38.878295
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    assert (facter_fact_collector_1.collect() == {})


# Generated at 2022-06-24 23:20:44.146029
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module = mock.MagicMock()
    module.run_command.return_value = (0, '{}', '')
    assert facter_fact_collector_0.find_facter(module) is not None
    # FIXME: improve the test
    assert facter_fact_collector_0.run_facter(module, facter_fact_collector_0.find_facter(module)) == (0, '{}', '')
    assert facter_fact_collector_0.get_facter_output(module) == '{}'
    module.run_command.assert_called_with('/opt/puppetlabs/bin/cfacter --puppet --json')


# Generated at 2022-06-24 23:20:48.884923
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Setup mocks
    module = Mock()

    # Setup return values
    module.get_bin_path.return_value = '/usr/bin/facter'
    module.run_command.return_value = (0, '{"operating_system":"RedHat"}', None)

    facter_fact_collector_1 = FacterFactCollector()

    output = facter_fact_collector_1.get_facter_output(module)
    assert output == '{"operating_system":"RedHat"}'



# Generated at 2022-06-24 23:20:54.871538
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facts_dict = dict()
    # Set up mock module object
    mock_module = FacterFactCollectorMockModule()
    result = facter_fact_collector_0.collect(mock_module, facts_dict)


# Generated at 2022-06-24 23:21:01.397504
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    """
    Test FacterFactCollector.find_facter
    """
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = None
    # Failure case:
    # Returns None if facter_path isn't found
    # assert facter_fact_collector_0.find_facter(module_0) is None
    # Success case:
    # Returns facter_path if facter_path is found
    assert facter_fact_collector_0.find_facter(module_0) is not None


# Generated at 2022-06-24 23:21:07.692529
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    facter_dict_0 = facter_fact_collector_0.collect()
    facter_dict_1 = facter_fact_collector_1.collect()
    assert (facter_dict_0 == facter_dict_1)

test_case_0()
test_FacterFactCollector_collect()