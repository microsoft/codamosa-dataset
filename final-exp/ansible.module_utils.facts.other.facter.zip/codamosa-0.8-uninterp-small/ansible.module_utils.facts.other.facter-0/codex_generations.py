

# Generated at 2022-06-24 23:11:13.100362
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    pass


# Generated at 2022-06-24 23:11:23.437464
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    dummy_module_0 = DummyModule()
    # DummyModule's get_bin_path gets called with 'facter' and '/opt/puppetlabs/bin'
    # and returns '/opt/puppetlabs/bin/facter'
    # Also get_bin_path gets called with 'cfacter' and '/opt/puppetlabs/bin'
    # and returns '/opt/puppetlabs/bin/cfacter'
    dummy_module_0.get_bin_path = MockDummyModuleGetBinPath()
    # Dummy module's get_bin_path method gets called with 'facter' and '/opt/puppetlabs/bin'
    # and return '/opt/puppetlabs/bin/facter'
    assert facter

# Generated at 2022-06-24 23:11:29.280790
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output(module=None) is None

# Generated at 2022-06-24 23:11:33.936618
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    
    # 1. no module arg - so output is none
    facter_output = facter_fact_collector_0.get_facter_output(None)
    assert facter_output is None
    
    # 2. Puppet is not installed
    facter_output = facter_fact_collector_0.get_facter_output(FacterFactCollectorTestHelper())
    assert facter_output is None


# Generated at 2022-06-24 23:11:38.663982
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_test = FacterFactCollector()
    mock_module = MockModule()
    mock_module.get_bin_path = Mock(return_value="/opt/puppetlabs/bin/facter")
    mock_module.run_command = Mock(return_value=(0, '{"some_fact": "abc"}', ''))
    result = facter_fact_collector_test.run_facter(mock_module, "/opt/puppetlabs/bin/facter")
    assert len(result) == 3


# Generated at 2022-06-24 23:11:39.839713
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()



# Generated at 2022-06-24 23:11:46.353012
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import mock
    from mock import MagicMock, patch
    facter_fact_collector_1 = FacterFactCollector()

    class ModuleStub:
        def get_bin_path(self, arg1, opt_dirs=None):
            return 'str'
    module_stub = ModuleStub()

    # Mock module_utils.facts.collector.ModuleUtilsFactsCollector._run_command
    mock_ModuleUtilsFactsCollector__run_command = MagicMock(return_value=(0,'str','str'))
    with patch.multiple(FacterFactCollector, _run_command=mock_ModuleUtilsFactsCollector__run_command):
        assert facter_fact_collector_1.run_facter(module_stub, 'str') == (0,'str','str')


# Generated at 2022-06-24 23:11:54.570367
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    a_fact_namespace = PrefixFactNamespace(namespace_name='a', prefix='a_')
    b_fact_namespace = PrefixFactNamespace(namespace_name='b', prefix='b_')

    class MockModule(object):

        def __init__(self):
            self.params = self

        @staticmethod
        def get_bin_path(app, opt_dirs=[]):
            if app == 'facter':
                return '/opt/puppetlabs/bin/facter'
            elif app == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'

        @staticmethod
        def run_command(cmd):
            output = None

# Generated at 2022-06-24 23:11:58.191883
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert sign(facter_fact_collector_0.find_facter()) == -1


# Generated at 2022-06-24 23:12:03.074710
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    mock_module = MagicMock()
    module_path = facter_fact_collector_0.get_facter_output(mock_module)
    assert module_path != None


# Generated at 2022-06-24 23:12:13.435227
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    facter_fact_collector = FacterFactCollector()

    assert facter_fact_collector.name == 'facter'
    assert facter_fact_collector._fact_ids == set(['facter'])

    assert isinstance(facter_fact_collector.namespace, PrefixFactNamespace)
    assert facter_fact_collector.namespace.namespace_name == 'facter'
    assert facter_fact_collector.namespace.prefix == 'facter_'

    assert facter_fact_collector.collect() == {}


# Generated at 2022-06-24 23:12:17.917021
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    # Test of a basic case :
    # test_0 method of an instance is supposed to return None by default.
    assert facter_fact_collector_0.get_facter_output(None) == None


# Generated at 2022-06-24 23:12:20.325593
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_2 = FacterFactCollector()
    assert facter_fact_collector_2.get_facter_output() == None

# Generated at 2022-06-24 23:12:23.828176
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    facts_dict = {}
    assert facter_fact_collector_0.get_facter_output(facts_dict) is None


# Generated at 2022-06-24 23:12:25.976435
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = MockModule
    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector.find_facter(module)


# Generated at 2022-06-24 23:12:37.585762
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    test_module = MockModule()
    # Use cfacter if available
    cfacter_path = "/opt/puppetlabs/bin/cfacter"
    test_module.get_bin_path.return_value = cfacter_path
    test_module.run_command.return_value = (0, "", "")

    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter(test_module, cfacter_path)

    assert test_module.get_bin_path.call_count == 2
    test_module.get_bin_path.assert_called_with(
        'cfacter', opt_dirs=['/opt/puppetlabs/bin']
    )

    assert test_module.run_command.call_count == 1


# Generated at 2022-06-24 23:12:39.640247
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter(module=None) is None


# Generated at 2022-06-24 23:12:43.502498
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.collect() is not None


# Generated at 2022-06-24 23:12:47.586836
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    class module_0:
        @staticmethod
        def get_bin_path(arg_0, opt_dirs):
            return "/opt/puppetlabs/bin/facter"

    assert facter_fact_collector_0.find_facter(module_0) == "/opt/puppetlabs/bin/facter"


# Generated at 2022-06-24 23:12:52.535529
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = MockModule()
    facter_path_0 = facter_fact_collector_0.find_facter(module=module_0)
    assert facter_path_0 == '/usr/bin/facter'


# Generated at 2022-06-24 23:13:01.491835
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

    facter_fact_collector_0.collect()



# Generated at 2022-06-24 23:13:06.109727
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()
    facter_path = '/opt/puppetlabs/bin/facter'
    facter_args = '--puppet --json'
    # execute run_facter method of class FacterFactCollector
    rc, out, err = facter_fact_collector.run_facter(None, facter_path + ' ' + facter_args)
    # get results and check them
    assert rc == 0
    result = json.loads(out)
    assert 'ruby' in result


# Generated at 2022-06-24 23:13:08.357499
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    fixture = [
        FacterFactCollector(),
        {},
        False
    ]
    fixture[0].get_facter_output(*fixture[1:])

# Generated at 2022-06-24 23:13:09.690762
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # TODO: Implement a proper unit test
    pass


# Generated at 2022-06-24 23:13:15.641160
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    result = facter_fact_collector_0.find_facter(module=None)
    assert result == None


# Generated at 2022-06-24 23:13:21.125914
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    facter_path = None
    facter_path = facter_fact_collector.find_facter(None)
    # assert facter_path is None


# Generated at 2022-06-24 23:13:25.985087
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    module = None
    facter_output = facter_fact_collector.get_facter_output(module)


# Generated at 2022-06-24 23:13:30.519460
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output(module) is not None

# Generated at 2022-06-24 23:13:38.950420
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Check that method collect of class FacterFactCollector
    # will return the expected set of fact ids

    # Setup: create a FacterFactCollector object
    facter_fact_collector_0 = FacterFactCollector()

    # Exercise: call the collect method
    collected_facts = facter_fact_collector_0.collect()

    # Verify: that the expected set of fact ids was returned
    assert isinstance(collected_facts, dict)

# Generated at 2022-06-24 23:13:42.028085
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector

    assert facter_fact_collector.name == 'facter'


# Generated at 2022-06-24 23:13:56.951330
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.run_facter(module=None, facter_path=None) == (None, None, None)


# Generated at 2022-06-24 23:14:01.458211
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()

    # Run facter --json
    rc, out, err = facter_fact_collector.run_facter()

    # Return code is 0, json output is displayed
    assert rc == 0
    assert out is not None


# Generated at 2022-06-24 23:14:07.532845
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect() == {}
    assert facter_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:14:10.773377
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    ret = facter_fact_collector_0.find_facter()
    pass


# Generated at 2022-06-24 23:14:14.087446
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

    result = facter_fact_collector_0.collect()

    # verify the result
    assert True



# Generated at 2022-06-24 23:14:20.688342
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    # Define test object
    facter_fact_collector_1 = FacterFactCollector()

    test_module_1 = MockModule()

    test_module_1.command_results = [
        (0, None, None),  # command: which facter
        (0, "bogus --json output", None),  # command: facter --json
    ]

    expected_result_1 = {}

    actual_result_1 = facter_fact_collector_1.collect(module=test_module_1)

    assert actual_result_1 == expected_result_1


# Generated at 2022-06-24 23:14:21.491574
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:14:26.263907
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()
    # TODO: Define valid inputs
    valid_inputs = []
    # Pass a mock object in place of module
    # TODO: Create a test object of type AnsibleModule and set valid
    # attributes of the object
    test_mod = ""
    # TODO: Set valid values for module_args
    args = ""
    result = facter_fact_collector.run_facter(test_mod, args)
    # TODO: Evaluate valid result
    assert result is not ""

# Generated at 2022-06-24 23:14:27.239767
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    pass


# Generated at 2022-06-24 23:14:28.738478
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.find_facter()

# Generated at 2022-06-24 23:14:49.056419
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    assert True

# Generated at 2022-06-24 23:14:50.683473
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    @return Nothing
    """
    pass


# Generated at 2022-06-24 23:14:53.996186
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()

    # TODO: write me
    assert False

# Generated at 2022-06-24 23:14:55.150922
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

# Generated at 2022-06-24 23:14:58.249904
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # FacterFactCollector cannot be instantiated - module_utils.facts.collector.BaseFactCollector is an abstract class
    facter_fact_collector_0 = FacterFactCollector()
    # FacterFactCollector.get_facter_output no docstring


# Generated at 2022-06-24 23:15:01.054832
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # TODO: check correct return value using pytest assert
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()


# Generated at 2022-06-24 23:15:04.979980
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class module_0():
        def get_bin_path(self, arg_0, arg_1=None):
            return '/usr/bin/facter'
    module_0 = module_0()
    assert facter_fact_collector_0.find_facter(module=module_0) == '/usr/bin/facter'


# Generated at 2022-06-24 23:15:10.360267
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Get an instance of one of the class we are testing
    facter_fact_collector_0 = FacterFactCollector()

    # Only Test using a mocked find_facter method
    def find_facter_0(module):
        return None

    # If a mocked method get used, it is passed the instance of the class
    facter_fact_collector_0.find_facter = find_facter_0

    # Pass a mock module to the tested method
    # FIXME: should this be a mock object from the mock module?
    module = None

    facter_output = facter_fact_collector_0.get_facter_output(module)

    assert facter_output == None
 
    # Only Test using a mocked find_facter method
    def find_facter_1(module):
        return

# Generated at 2022-06-24 23:15:17.920791
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test case 0

    facter_fact_collector = FacterFactCollector()
    class TestModule(object):
        def get_bin_path(self, path, opt_dirs=None):
            return "test_path"

        def run_command(self, path):
            return 0, "test_out", "test_err"

    facter_fact_collector.get_facter_output(TestModule())

# Generated at 2022-06-24 23:15:23.236461
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    # Setup test case
    facter_fact_collector_1 = FacterFactCollector()

    # Call method collect of class FacterFactCollector
    ret = facter_fact_collector_1.collect()

    assert ret == {}, 'Returned unexpected value'

# Generated at 2022-06-24 23:16:05.125069
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    FacterFactCollector_0 = FacterFactCollector()
    FacterFactCollector_0.find_facter()


# Generated at 2022-06-24 23:16:09.738495
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = AnsibleModule()

    # Testing the find_facter method with an invalid path
    setattr(module_0, '_ansible_syspaths', ['/home/ansible'])
    
    # We should not find facter in the custom path
    facter_path = facter_fact_collector_0.find_facter(module_0)
    assert facter_path == None


# Generated at 2022-06-24 23:16:11.786851
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:16:19.051589
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # instantiate FacterFactCollector object
    facter_fact_collector_0 = FacterFactCollector()
    # all fields should be empty
    assert facter_fact_collector_0.namespace == PrefixFactNamespace(namespace_name='facter', prefix='facter_')
    assert facter_fact_collector_0._fact_ids == set(['facter'])
    assert facter_fact_collector_0.name == 'facter'

    _module = AnsibleModuleMockup()
    _module.run_command.return_value = 0, "", ""
    # test with puppet installed but no ruby-json
    _module.get_bin_path.return_value = '/usr/local/bin/puppet'

# Generated at 2022-06-24 23:16:24.186622
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    print("facter_fact_collector_0 = FacterFactCollector()")
    # 'facter' is a dict
    print("facter_fact_collector_0.collect()")

if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:16:25.281411
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()



# Generated at 2022-06-24 23:16:28.719705
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts_0 = dict()

    # Testing the execution of method collect
    facts_dict_0 = facter_fact_collector_0.collect(collected_facts=collected_facts_0)

# Generated at 2022-06-24 23:16:29.926908
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()



# Generated at 2022-06-24 23:16:37.251483
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import ResolvingCollector
    from ansible.module_utils.facts.utils import ModuleWrapper

    facter_fact_collector_0 = FacterFactCollector()

    # unit test for both return type and return value:
    #    return value should be a json dict, with one key/value
    #    pair in this case
    assert isinstance(facter_fact_collector_0.get_facter_output(ModuleWrapper('/bin/echo')), str)

    facter_fact_collector_1 = FacterFactCollector()

    collecting_fact_collector = ResolvingCollector(fact_collectors=[facter_fact_collector_1])

    # unit test for both return type and return value:
    #    return value should be a json dict, with

# Generated at 2022-06-24 23:16:48.119206
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Define fixture stubs
    ansible_module_stub_returning_none = lambda: None
    setattr(ansible_module_stub_returning_none, 'get_bin_path', lambda path, opt_dirs: None)
    ansible_module_stub_returning_path = lambda: None
    setattr(ansible_module_stub_returning_path, 'get_bin_path', lambda path, opt_dirs: "/usr/bin/facter")
    ansible_module_stub_returning_path_with_cfacter = lambda: None
    setattr(ansible_module_stub_returning_path_with_cfacter, 'get_bin_path', lambda path, opt_dirs: "/usr/bin/cfacter")
    ansible_module_stub_return

# Generated at 2022-06-24 23:18:27.963402
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # set up_0
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = None

    # exercise
    facter_fact_collector_0.collect(module_0)

    # verify
    assert True


# Generated at 2022-06-24 23:18:29.134265
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

    assert True



# Generated at 2022-06-24 23:18:31.618902
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Instantiate a FacterFactCollector class
    facter_fact_collector_0 = FacterFactCollector()
    # Assert that facter_path is a None object
    assert facter_fact_collector_0.find_facter != None


# Generated at 2022-06-24 23:18:32.573369
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:18:39.217997
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    # set up mock module object
    mock_module = MockModule()

    facter_fact_collector_0 = FacterFactCollector()

    facter_dict = facter_fact_collector_0.collect(module=mock_module)
    assert len(facter_dict) > 0


# Generated at 2022-06-24 23:18:41.566820
# Unit test for method get_facter_output of class FacterFactCollector

# Generated at 2022-06-24 23:18:43.113912
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    test_case = 0
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.find_facter() == None


# Generated at 2022-06-24 23:18:44.892559
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output('module')


# Generated at 2022-06-24 23:18:53.453776
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    module_1_mock = MagicMock()
    module_1_mock.get_bin_path.return_value = '/usr/local/bin/facter'
    module_1_mock.run_command.return_value = (0, '{}', '')
    result_1 = facter_fact_collector_1.get_facter_output(module_1_mock)
    assert result_1 is not None

    facter_fact_collector_2 = FacterFactCollector()
    module_2_mock = MagicMock()
    module_2_mock.get_bin_path.return_value = None

# Generated at 2022-06-24 23:18:54.519178
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
