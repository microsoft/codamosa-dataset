

# Generated at 2022-06-24 23:11:16.820255
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    actual_result = facter_fact_collector.find_facter(facter_fact_collector)
    expected_result = None
    assert actual_result == expected_result


# Generated at 2022-06-24 23:11:18.853148
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    result = facter_fact_collector_0.find_facter()


# Generated at 2022-06-24 23:11:20.623145
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector is not None


# Generated at 2022-06-24 23:11:29.518976
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import ModuleCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.virt_hardware import VirtHardwareFactCollector
    from ansible.module_utils.facts.virtual import VirtualFactCollector
    from ansible.module_utils.facts.system.perf import PerfFactCollector

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # Setup
    module = MagicMock()

    # Test

# Generated at 2022-06-24 23:11:31.883309
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    collected_facts = {}
    module_1 = None
    facter_fact_collector_1.get_facter_output(module_1)


# Generated at 2022-06-24 23:11:35.844511
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # TODO: Implement method find_facter of class FacterFactCollector for unit test
    pass


# Generated at 2022-06-24 23:11:43.309217
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = object()
    fake_facter_output = "fake_facter_output"

    mock_run_facter = object()
    mock_run_facter.return_value = 0, fake_facter_output, None
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter = mock_run_facter

    retval = facter_fact_collector_0.get_facter_output(module)

    assert retval == fake_facter_output


# Generated at 2022-06-24 23:11:47.000889
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:11:50.947442
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_facts_0 = {}

    facter_facts_0 = facter_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:11:57.017598
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

    try:
        facter_fact_collector_1.collect()
    except ValueError as err:
        print(err)
        assert False

test_case_0()
test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:12:06.173957
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
  # For this test case we have to create an instance of class ModuleStub
  module_stub = ModuleStub()
  # Then we have to create an instance of class FacterFactCollector
  facter_fact_collector = FacterFactCollector()
  # And call get_facter_output on this instance
  facter_fact_collector.get_facter_output(module_stub)


# Generated at 2022-06-24 23:12:11.419688
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output({'get_bin_path': lambda *a: '/bin/facter', 'run_command': lambda *a: (0, '{"a":1,"b":2,"c":3,"d":4}', '')}) == '{"a":1,"b":2,"c":3,"d":4}'

# Generated at 2022-06-24 23:12:22.933644
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    # A simple test to show how the a test works

    # Arrange
    facter_fact_collector = FacterFactCollector()

    # Act
    facter_path = facter_fact_collector.find_facter(AnsibleModule())

    # Assert
    assert facter_path == '/usr/bin/facter'

    # A simple test to show how the a test works

    # Arrange
    facter_fact_collector = FacterFactCollector()

    # Act
    facter_path = facter_fact_collector.find_facter(AnsibleModule(
        dict(params=dict(some_param='some_value')))
    )

    # Assert
    assert facter_path == '/usr/bin/facter'

    # A simple test to show how the a test

# Generated at 2022-06-24 23:12:28.856925
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collectors
    collectors = get_collectors()
    facter_fact_collector = next((facter_fact_collector for facter_fact_collector in collectors if isinstance(facter_fact_collector, FacterFactCollector)), None)
    return facter_fact_collector.find_facter({})


# Generated at 2022-06-24 23:12:38.560418
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Setup
    import ansible.module_utils.facts.collector

    class AnsibleModuleMock():

        def __init__(self):
            self.run_command_call_count = 0

        def get_bin_path(self, path, opt_dirs):
            return path

        def run_command(self, cmd, check_rc=True, close_fds=True, use_unsafe_shell=True, executable=None, data=None):
            self.run_command_call_count += 1
            rc = 0
            out = '{"foo": "bar"}'
            err = ''
            return rc, out, err

    facter_fact_collector = FacterFactCollector()
    ansible_module_mock = AnsibleModuleMock()

    # Exercise
    facter_output = facter

# Generated at 2022-06-24 23:12:48.643786
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()


# Generated at 2022-06-24 23:12:50.277067
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    assert facter_fact_collector_0.find_facter is not None


# Generated at 2022-06-24 23:12:55.916072
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts = {}
    result = facter_fact_collector_0.collect(collected_facts)
    assert (result == {})


# Generated at 2022-06-24 23:13:00.663018
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.find_facter(module)


# Generated at 2022-06-24 23:13:03.112644
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facts = {}
    facter_fact_collector_0 = FacterFactCollector()
    facter_path_0 = facter_fact_collector_0.find_facter(facts)


# Generated at 2022-06-24 23:13:10.234713
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    collect = FacterFactCollector()
    collect.get_facter_output('')

# Generated at 2022-06-24 23:13:18.661438
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    mock_module = MagicMock()
    mock_module.run_command.side_effect = [
        (0, "facter_output", "")
    ]

    facter_fact_collector_0 = FacterFactCollector()
    rc, out, err = facter_fact_collector_0.run_facter(mock_module, "path/to/facter")
    assert True



# Generated at 2022-06-24 23:13:25.539630
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Setup
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.set_module = mock.Mock()
    mock_module_1 = mock.Mock()

# Generated at 2022-06-24 23:13:29.293559
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector = FacterFactCollector()
    module = object
    facter_path = '/usr/local/bin/facter'
    rc, out, err = facter_fact_collector.run_facter(module, facter_path)
    assert rc == 0
    assert out == '{}\n'
    assert err == ''


# Generated at 2022-06-24 23:13:31.355790
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    result_0 = facter_fact_collector_0.collect()

# Generated at 2022-06-24 23:13:39.021710
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    valid_facter_bin = '/usr/bin/facter'
    # should return rc = 0 and output in json format
    rc, out, err = facter_fact_collector_0.run_facter(None, '/usr/bin/facter')
    assert rc == 0
    assert json.loads(out)
    # should return None
    valid_facter_bin = '/usr/bin/facter_no_such_path'
    rc, out, err = facter_fact_collector_0.run_facter(None, valid_facter_bin)
    assert rc == 1
    assert not out
    assert err


# Generated at 2022-06-24 23:13:47.216648
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    ########################################################
    # Unit test of FacterFactCollector.collect()
    ########################################################

    def test_facter_collector_run_facter(self, module, facter_path):
        return 0, "dummy_facter_output", ""

    # Run tests
    facter_fact_collector_0 = FacterFactCollector()

    facter_fact_collector_0.run_facter = test_facter_collector_run_facter

    rc, out, err = facter_fact_collector_0.run_facter(None, "dummy_facter")
    assert(rc == 0 and out == "dummy_facter_output" and err == "")

    # Run collect
    facter_result = facter_fact_collector_0.collect()

# Generated at 2022-06-24 23:13:50.860115
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() is None


# Generated at 2022-06-24 23:13:56.772749
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()

    # Try to find the 'facter' and 'cfacter' executables.

    # Facter should not be found.
    output_1 = facter_fact_collector_1.find_facter(module=None)
    expected_1 = None

    assert(output_1 == expected_1)


# Generated at 2022-06-24 23:14:06.484716
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import ModuleWrapper
    from ansible.module_utils.facts import cache
    import os
    import tempfile
    import json

    # make a temporary directory to serve as a module_utils/facts base dir
    tmpdir = tempfile.mkdtemp()
    os.makedirs(tmpdir + '/module_utils/facts/ansible')

    cache_dir = tmpdir + '/module_utils/facts/ansible/module_cache'
    os.makedirs(cache_dir)

    # create a cache file with fake facter data
    cache_file = cache_dir + '/facter.cache'

# Generated at 2022-06-24 23:14:24.321622
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    # test if the system has facter installed
    facter_path_1 = facter_fact_collector_1.find_facter()
    if facter_path_1 is not None:
        print(facter_path_1)
        # test if the system has cfacter installed
        facter_path_2 = facter_fact_collector_1.find_facter('cfacter')
        if facter_path_2 is not None:
            print(facter_path_2)
        else:
            print('Not cfacter installed')
    else:
        print('Not facter installed')


# Generated at 2022-06-24 23:14:27.813176
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:14:28.984768
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()


# Generated at 2022-06-24 23:14:36.126911
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    test_collector = FacterFactCollector()
    test_collect_dict = dict(
        ansible_python_interpreter='/usr/bin/python',
        ansible_user_id='root',
        facter_facterversion='3.7.3',
        facter_is_virtual=True,
        facter_operatingsystem='Ubuntu',
        facter_osfamily='Debian',
        facter_uptime_days='1',
        facter_uptime_hours='1',
        ansible_python_version='2.7.12',
        facter_lsbdistcodename='xenial',
        facter_puppetversion='4.7.0'
    )
    assert test_collector.collect() == test_collect_dict


# Generated at 2022-06-24 23:14:37.928293
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    ffc = FacterFactCollector()
    result = ffc.collect()

    assert isinstance(result, dict)


# Generated at 2022-06-24 23:14:48.373076
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import ansible_support
    from ansible.module_utils.facts.collectors.facter import FacterFactCollector

    # This is what get_facter_output should be returning
    # {
    #   "ansible_support": {
    #     "python_version": "2.7.11"
    #   },
    #   "facterversion": "3.6.3"
    # }

    # Create a mock of the AnsibleSupport class that returns
    # python_version: 2.7.11
    class MockAnsibleSupport(ansible_support.AnsibleSupport):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-24 23:14:50.721304
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector(collectors=None, namespace=None)
    facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:14:57.949389
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    mock_module_0 = MagicMock()
    mock_module_0.run_command.return_value = (0, '{"string": "a", "int": 1}\n', '')
    mock_module_0.get_bin_path.return_value = '/usr/bin/facter'

    # test some values
    facter_output = facter_fact_collector_0.get_facter_output(mock_module_0)
    assert facter_output == '{"string": "a", "int": 1}\n'

# Generated at 2022-06-24 23:15:01.368208
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # Find if facter is installed
    print("This should be true because facter is definitely installed")
    print(facter_fact_collector_0.find_facter(True))



# Generated at 2022-06-24 23:15:02.968841
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:15:27.503602
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.collect() is not None


# Generated at 2022-06-24 23:15:38.743074
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_2 = FacterFactCollector()

    # TODO: mock the module
    # TODO: mock the facter output
    facter_fact_collector_1.get_facter_output = Mock(return_value='{"facter_fact_a": "value_a", "facter_fact_b": "value_b"}')
    facter_fact_collector_2.get_facter_output = Mock(return_value='{}')

    facter_facts = facter_fact_collector_1.collect()

    assert facter_facts == {'facter_fact_a': 'value_a', 'facter_fact_b': 'value_b'}

    facter_facts = facter

# Generated at 2022-06-24 23:15:43.164324
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0_0 = FacterFactCollector()
    facter_fact_collector_0_0.find_facter = Mock(side_effect=[None])
    facter_fact_collector_0_0.get_facter_output = Mock(side_effect=[None])
    facter_fact_collector_0_0.collected_facts = {'facter': {'system_uptime': {'days': 0, 'hours': 4, 'seconds': 14855, 'uptime': '4:24 hours', 'seconds_uptime': 14855}},
    'ansible_python_version': '2.7.5 (default, Jun 24 2015, 00:41:19) \n[GCC 4.8.3 20140911 (Red Hat 4.8.3-9)]'}


# Generated at 2022-06-24 23:15:50.422210
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    f = FacterFactCollector()
    # TODO: write a real test!
    try:
        f.get_facter_output(None)
    except SystemExit as e:
        assert e.code == 1


# Generated at 2022-06-24 23:15:54.744958
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    module = MockModule()
    module.get_bin_path = Mock(return_value='/usr/bin/facter')
    assert facter_fact_collector_0.find_facter(module) == '/usr/bin/facter'


# Generated at 2022-06-24 23:15:56.988260
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    result = facter_fact_collector.collect()
    assert result

# Generated at 2022-06-24 23:16:05.794921
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()

    class Module:
        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == "facter":
                return "/opt/puppetlabs/bin/facter"
            elif executable == "cfacter":
                return None

        def run_command(self, command):
            return 0, "{\"facter_one\": 1}", ""

    module = Module()
    facter_output = facter_fact_collector.get_facter_output(module)
    assert facter_output is not None
    assert facter_output == "{\"facter_one\": 1}"

    facter_fact_collector_2 = FacterFactCollector()


# Generated at 2022-06-24 23:16:08.577018
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    module = ModuleStub()
    facter_path = facter_fact_collector.find_facter(module)
    assert facter_path == 'facter_bin_path'


# Generated at 2022-06-24 23:16:15.694668
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.find_facter = lambda: 'facter_path'
    facter_fact_collector_1.run_facter = lambda module, facter_path: (0, 'facter_output', '')
    assert facter_fact_collector_1.get_facter_output('module') == 'facter_output'


# Generated at 2022-06-24 23:16:18.421876
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Setup Mock objects
    # Execute code to be tested
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_0.collect()
    facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:17:18.894727
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts = {}
    ansible_net_facts = facter_fact_collector_0.collect(collected_facts=collected_facts)
    assert ansible_net_facts == {}


# Generated at 2022-06-24 23:17:24.428503
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    sys.modules['ansible'] = MockAnsibleModule()
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.get_facter_output(MockAnsibleModule()) is not None


# Generated at 2022-06-24 23:17:30.580375
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    # FIXME: Write test case
    #       TODO: Fill in caller function parameters
    #       TODO: Change return value to correct type and value
    #       TODO: Fill in caller function parameters
    #       TODO: Change return value to correct type and value
    #       TODO: Fill in caller function parameters
    #       TODO: Change return value to correct type and value

    # Call method find_facter of class FacterFactCollector
    assert facter_fact_collector_0.find_facter() == None


# Generated at 2022-06-24 23:17:33.536777
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output(None)

test_FacterFactCollector_get_facter_output()

# Generated at 2022-06-24 23:17:39.182829
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

    # FIXME: should probably mock the module object here...
    facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:17:40.580119
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    #
    # Need to implement a mock module class with a run_command method.
    #
    pass

# Generated at 2022-06-24 23:17:50.147255
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    module_0 = MockModule()
    setattr(module_0, 'get_bin_path', Mock(return_value='/usr/bin/facter'))

    # 1st call, returns a json string that can be encoded
    setattr(module_0, 'run_command', Mock(return_value=(0, '{"facter_a":"2","facter_b":"5"}', '')))
    module_1 = MockModule()
    setattr(module_1, 'get_bin_path', Mock(return_value='/usr/bin/facter'))

    # 2nd call, returns a bad json string that can not be encoded

# Generated at 2022-06-24 23:17:57.589997
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """
    test_FacterFactCollector_run_facter
    See also test_case_0.
    """

    facter_fact_collector_0 = FacterFactCollector()

    # Testing with a required module_utils.facts.collector.BaseFactCollector.module attribute of None
    assert facter_fact_collector_0.run_facter(None, 'fake_facter_path') is None


# Generated at 2022-06-24 23:18:01.289858
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    # No test as this function is expected to fail
    pass


# Generated at 2022-06-24 23:18:04.298978
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    c = FacterFactCollector()
    m = MockModule()
    fp = '/usr/bin/facter'
    expected_rc = 0
    expected_out = "some json output"
    expected_err = ""

    m.run_command_result = (expected_rc, expected_out, expected_err)
    rc, out, err = c.run_facter(m, fp)
    assert rc == expected_rc
    assert out == expected_out
    assert err == expected_err


# Generated at 2022-06-24 23:20:15.340712
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # TO DO: mock a module object and test with it


# Generated at 2022-06-24 23:20:18.409309
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

    assert facter_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:20:21.222610
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Populate the fixture
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output()


# Generated at 2022-06-24 23:20:23.965211
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # asser for edge case 1
    # assert for edge case 2


# Generated at 2022-06-24 23:20:28.996315
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()

    module = MockModule()

    facter_path = facter_fact_collector.find_facter(module)
    if not facter_path:
        return None

    rc, out, err = facter_fact_collector.run_facter(module, facter_path)

    if rc != 0:
        return None

    return out


# Generated at 2022-06-24 23:20:34.421228
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facts_dict = facter_fact_collector_0.collect()
    print(facts_dict)


# Generated at 2022-06-24 23:20:38.701552
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    module = MockModule()
    facter_path = facter_fact_collector.find_facter(module)
    assert facter_path
    assert facter_path == 'facter_path'


# Generated at 2022-06-24 23:20:44.696728
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    fi_obj = FacterFactCollector()
    obj = FacterFactCollector()
    assert obj.find_facter(fi_obj) == None
    obj = FacterFactCollector()


# Generated at 2022-06-24 23:20:47.613326
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    rc, out, err = facter_fact_collector_0.run_command('which facter')
    facter_path = out.replace('\n','')
    assert facter_path == '/opt/puppetlabs/bin/facter'



# Generated at 2022-06-24 23:20:53.213572
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()
