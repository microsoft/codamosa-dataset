

# Generated at 2022-06-24 23:11:20.001907
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class MockModule(object):
        def __init__(self, expected_return_value):
            self.expected_return_value = expected_return_value
            self.run_command_rc = 0
            self.run_command_output = None
        def get_bin_path(self, arg, opt_dirs):
            self.arg = arg
            self.opt_dirs = opt_dirs
            return "/usr/bin/facter"

        def run_command(self, arg):
            if self.run_command_rc != 0:
                raise Exception('run_command failed')
            return self.run_command_rc, self.run_command_output, "stderr"


# Generated at 2022-06-24 23:11:25.547353
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    facter_fact_collector_0.collect(module=module)
    facter_fact_collector_1.collect(module=module)


# Generated at 2022-06-24 23:11:27.090176
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert False

# Generated at 2022-06-24 23:11:29.135272
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.get_facter_output is not None


# Generated at 2022-06-24 23:11:30.947610
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    facter_facts_1 = facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:11:36.908676
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()
    ret = facter_fact_collector_1.collect(module=None)
    assert ret == {}
    return


# Generated at 2022-06-24 23:11:44.793269
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    data = """
    {
        "blah": {
            "foo": {
                "bar": "baz"
            }
        }
    }
    """
    facter_fact_collector_1 = FacterFactCollector()
    expected = data
    got = facter_fact_collector_1.get_facter_output(facter_output=data)
    if got != expected:
        print('Expected')
        print(expected)
        print('Got')
        print(got)
        raise Exception('FacterFactCollector.get_facter_output did not return expected')


# Generated at 2022-06-24 23:11:52.402968
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    # TODO: There is no module object passed in, so this will fail
    # I think we need to mock this out somehow, since we cannot assume that
    # facter is installed during testing.
    result = facter_fact_collector_0.find_facter(None)
    if result:
        print("value: {:s}".format(repr(result)))
    else:
        print("value: {:s}".format(repr(result)))
    assert result is not None


# Generated at 2022-06-24 23:11:55.624581
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import AnsibleModule
    module = AnsibleModule(argument_spec={})
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter(module, '/opt/puppetlabs/bin/facter')


# Generated at 2022-06-24 23:12:01.668960
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()
    class FakeModule0:
        def get_bin_path(self, path0, opt_dirs0):
            return '/usr/bin/facter'
        def run_command(self, command0):
            return (0, 'some_string', '')
    assert facter_fact_collector_1.get_facter_output(FakeModule0()) == 'some_string'
    class FakeModule1:
        def get_bin_path(self, path0, opt_dirs0):
            return '/usr/bin/facter'
        def run_command(self, command0):
            return (-1, '', '')
    assert facter_fact_collector_1.get_facter_output(FakeModule1()) == None

#

# Generated at 2022-06-24 23:12:11.803764
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_ = FacterFactCollector()
    assert facter_fact_collector_.collect() == {}


# Sample test case
# Note that the test case expects facts to contain keys/values from facter.
# The test would fail if you invoked it against a system that does not have facter installed
# because in such case, the collect method would return empty dictionary.

# Generated at 2022-06-24 23:12:21.246465
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    # Local classes
    class GetBinPathMock(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
        def __call__(self, bin_path, opt_dirs):
            return self.rc, self.out, self.err

    # Setup
    facter_fact_collector_0 = FacterFactCollector()
    facter_bin_path_1 = "/opt/puppetlabs/bin/facter"
    cfacter_bin_path_1 = "/opt/puppetlabs/bin/cfacter"
    facter_bin_path_2 = "/usr/bin/facter"
    cfacter_bin_path_2 = "/usr/bin/cfacter"
    facter_bin_

# Generated at 2022-06-24 23:12:31.060982
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_1 = FacterFactCollector()

    try:
        from ansible.module_utils import basic
    except ImportError:
        module = None
    else:
        # create a new module object
        basic_module_1 = basic.AnsibleModule(
            argument_spec = dict(),
            supports_check_mode=True
        )
        module = basic_module_1

    # call method collect on object facter_fact_collector with arguments: module
    # The try block will be ignored until there is error handling
    # example to ignore the try block:
    #   try:
    #       1/0
    #   except ZeroDivisionError:
    #       pass
    #   else:
    #       Cannot get here as the exception is raised
    return_value_1 = facter_

# Generated at 2022-06-24 23:12:42.589492
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Setup a mock module
    class MockModule:
        def get_bin_path(self, bin_name, opt_dirs=None):
            # If bin_name is 'facter' or 'cfacter' return '/usr/bin/facter'
            if bin_name in ['facter', 'cfacter']:
                return '/usr/bin/facter'
            return None
        def run_command(self, args, check_rc=True, close_fds=True, cwd=None, use_unsafe_shell=False, executable=None):
            return 0, '{ "some_fact": "some_value" }', ''
    facter_fact_collector = FacterFactCollector()
    assert '{ "some_fact": "some_value" }' == facter_fact_collector.get_facter

# Generated at 2022-06-24 23:12:48.631868
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    f = FacterFactCollector()
    class Module(object):
        def run_command(self):
            return 0, '{"ansible_facts": "test", "ansible_facter": "test"}', 'test'

        def get_bin_path(self):
            return None

    module = Module()

    f.run_facter = lambda self, module, facter_path: (0, '{"ansible_facts": "test", "ansible_facter": "test"}', 'test')

    # Test 1
    assert type(f.get_facter_output(module)) is str
    # Test 2
    assert f.get_facter_output(module) == '{"ansible_facts": "test", "ansible_facter": "test"}'



# Generated at 2022-06-24 23:12:52.145556
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    module = None
    collected_facts = None
    facter_fact_collector_0.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-24 23:12:56.484230
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    assert facter_fact_collector_0.find_facter(module_0) == '/opt/puppetlabs/bin/facter'
    assert facter_fact_collector_0.find_facter(module_1) is None


# Generated at 2022-06-24 23:13:01.373206
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    # Test case
    assert facter_fact_collector_1.find_facter() == None

# Generated at 2022-06-24 23:13:11.040182
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    mock_module_1 = MockModule()
    mock_module_1.params = dict()
    mock_module_1.params['facter_path'] = '/usr/bin/facter'
    mock_module_1.get_bin_path = Mock(side_effect = ['/usr/bin/facter', None])
    assert facter_fact_collector_1.find_facter(module = mock_module_1) == '/usr/bin/facter'
    assert facter_fact_collector_1.find_facter(module = mock_module_1) == None


# Generated at 2022-06-24 23:13:17.547755
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    ansibullet_Module_0 = ansibullet_module_0()
    str_1 = facter_fact_collector_0.get_facter_output(ansibullet_Module_0)



# Generated at 2022-06-24 23:13:30.210908
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Testing find_facter function
    # Input:  None
    # Expected output:  None
    find_facter_result = FacterFactCollector.find_facter(None)
    assert find_facter_result == None

    # Testing run_facter function with invalid facter path
    # Input:  None
    # Expected output:  None
    run_facter_result = FacterFactCollector.run_facter(None, None)
    assert run_facter_result == (None, None, None)

    # Testing get_facter_output function with invalid facter path
    # Input:  None
    # Expected output:  None
    get_facter_output_result = FacterFactCollector.get_facter_output(None)
    assert get_facter_output_result == None

# Generated at 2022-06-24 23:13:32.895725
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    result = facter_fact_collector.collect(module=None, collected_facts=None)
    assert result == {}


# Generated at 2022-06-24 23:13:37.319239
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    print("Test 0: Testing method get_facter_output of FacterFactCollector.")

    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.get_facter_output()

test_case_0()
#test_FacterFactCollector_get_facter_output()

# Generated at 2022-06-24 23:13:42.560721
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Get an instance of FacterFactCollector
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector is not None

    assert facter_fact_collector.get_facter_output('module') is None
    return 0


# Generated at 2022-06-24 23:13:47.803774
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_module_0 = AnsibleModuleStub()
    assert facter_fact_collector_0.find_facter(ansible_module_0) is None


# Generated at 2022-06-24 23:13:52.933043
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import timeout
    import pytest

    facter_fact_collector_0 = FacterFactCollector(collectors=None, namespace=None)

    with pytest.raises(timeout.TimeoutError):
        facter_fact_collector_0.collect()

# Generated at 2022-06-24 23:13:58.493631
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    class Module:
        def get_bin_path(self, arg1, opt_dirs=None):
            return '/opt/puppetlabs/bin/facter'
        def run_command(self, arg1):
            return 1, '', ''
    facter_fact_collector_0.get_facter_output(Module())


# Generated at 2022-06-24 23:14:02.406775
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    res = facter_fact_collector_0.get_facter_output()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 23:14:12.249758
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    (facter_fact_collector_0,
     module_0,
     opt_dirs_0) = (FacterFactCollector(),
                    Mock(),
                    ["/opt/puppetlabs/bin"])
    get_bin_path_0 = module_0.get_bin_path
    get_bin_path_0.side_effect = lambda x, opt_dirs=None: getattr(get_bin_path_0, 'return_value') if get_bin_path_0.call_count == 2 else None
    get_bin_path_0.return_value = None
    assert facter_fact_collector_0.find_facter(module_0) is None


# Generated at 2022-06-24 23:14:15.762782
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_path = facter_fact_collector_0.find_facter(module)
    assert facter_path is not None


# Generated at 2022-06-24 23:14:28.612050
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    facter_fact_collector = FacterFactCollector()
    facter_var = facter_fact_collector.get_facter_output(None)
    assert facter_var is None


# Generated at 2022-06-24 23:14:33.398313
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    ffc = FacterFactCollector()
    class module_mock:
        def get_bin_path(self, arg1, arg2):
            return '/bin/facter'
        def run_command(self, arg1):
            return 0, '{a: 1}', 'err'
    module_mock_instance = module_mock()
    assert ffc.get_facter_output(module_mock_instance) == '{a: 1}'



# Generated at 2022-06-24 23:14:36.261839
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

    # If a module is passed to the get_facter_output function, the return
    # value should not be None.
    assert facter_fact_collector_0.get_facter_output(module='a_string') is not None


# Generated at 2022-06-24 23:14:38.402589
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    pass

if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_get_facter_output()

# Generated at 2022-06-24 23:14:44.197331
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    param_0 = None
    test_0 = facter_fact_collector_0.get_facter_output(param_0)
    assert test_0 is None



# Generated at 2022-06-24 23:14:47.211722
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()
    find_facter_output = facter_fact_collector.find_facter(None)
    assert find_facter_output is not None
    assert isinstance(find_facter_output, str)


# Generated at 2022-06-24 23:14:51.104959
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:15:00.894229
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()

# Generated at 2022-06-24 23:15:08.326704
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    # Prerequisite for the case:
    # - assert that facter_fact_collector_0.get_facter_output
    #   returns a dict with facts
    # - set value for facter_fact_collector_0.namespace
    #   to 'facter'
    facter_facts_dict = facter_fact_collector_0.collect()
    assert isinstance(facter_facts_dict, dict)
    # Make a copy of the source dict, remove the special key
    # 'ansible_facter' and then assert if 
    # facter_fact_collector_0.namespace is a prefix of all keys.
    facter_facts_dict_prefix = dict(facter_facts_dict)
    facter_facts

# Generated at 2022-06-24 23:15:17.285342
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import collector

    facter_fact_collector = FacterFactCollector()

    # test no path provided
    result = facter_fact_collector.find_facter(None)
    assert result is None

    # test invalid path provided
    result = facter_fact_collector.find_facter(collector.BaseFactCollector())
    assert result is None

    # test valid path provided with cfacter available
    facter_fact_collector = FacterFactCollector()


# Generated at 2022-06-24 23:15:39.859099
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:15:41.846378
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    assert (facter_fact_collector.collect(collected_facts={'facter': True}) == {})

# Generated at 2022-06-24 23:15:43.880131
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.collect()

# Generated at 2022-06-24 23:15:52.859572
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts_0 = {}
    collected_facts_0['ansible_module'] = ''
    expected_0 = None
    actual_0 = facter_fact_collector_0.get_facter_output(collected_facts_0['ansible_module'])
    assert actual_0 == expected_0



# Generated at 2022-06-24 23:16:01.374369
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Create a FacterFactCollector instance
    facter_fact_collector_0 = FacterFactCollector()

    # Modify the following variables to meet your test case needs
    mock_module_0 = None
    expected_return = None

    print("*** START test_FacterFactCollector_get_facter_output ***")
    print("mock_module_0 = {}".format(mock_module_0))

    # Call the method to test
    actual_return = facter_fact_collector_0.get_facter_output(mock_module_0)

    print("actual_return_val = {}".format(actual_return))
    print("expected_return_val = {}".format(expected_return))

    assert actual_return == expected_return

# Generated at 2022-06-24 23:16:05.603918
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()

    # Test with invalid values (None, 0, False, any string, etc.)
    # for all params

    # Test run_facter with missing module
    try:
        facter_fact_collector_0.run_facter(None, None)
    except Exception as e:
        assert e is not None

    # Test run_facter with missing facter_path
    try:
        facter_fact_collector_0.run_facter(None, None)
    except Exception as e:
        assert e is not None


# Generated at 2022-06-24 23:16:10.855081
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    try:
        from unittest import mock
    except ImportError as e:
        import mock

    # Mock module
    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, "", "")

    facter_fact_collector_0 = FacterFactCollector()
    rc, out, err = facter_fact_collector_0.run_facter(module=module_mock, facter_path='facter')

    assert rc == 0
    assert out == ""
    assert err == ""

# Generated at 2022-06-24 23:16:18.450171
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    class FacterFactCollectorMock(FacterFactCollector):
        def __init__(self, collectors=None, namespace=None):
            super(FacterFactCollectorMock, self).__init__(collectors, namespace)

        def find_facter(self, module):
            return '/opt/puppetlabs/bin/facter'

    class ModuleMock(object):
        def __init__(self):
            self.run_command_result = (0, open('./test_data/facter_json_output.json').read(), '')

        def get_bin_path(self, cmd, **kwargs):
            return '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-24 23:16:20.499876
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector_1 = FacterFactCollector()



# Generated at 2022-06-24 23:16:24.406320
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    facter_fact_collector = FacterFactCollector()

    facter_fact_collector.get_facter_output = lambda module: None

    try:
        facter_fact_collector.get_facter_output('module')
    except Exception as e:
        assert(isinstance(e, SystemExit))


# Generated at 2022-06-24 23:17:15.984540
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # TODO: write unit test
    pass

# Generated at 2022-06-24 23:17:17.802993
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # NOTE: This method requires a module type object, so we need to mock that up
    # TODO: mock the module
    pass

# Generated at 2022-06-24 23:17:22.300208
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_1.collect()


# Generated at 2022-06-24 23:17:24.696038
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    facter_dict = facter_fact_collector_0.collect()
    print(facter_dict)

if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_collect()

# Generated at 2022-06-24 23:17:26.836997
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_1 = FacterFactCollector()
    assert facter_fact_collector_1.find_facter is not None


if __name__ == '__main__':
    test_case_0()
    test_FacterFactCollector_find_facter()

# Generated at 2022-06-24 23:17:32.124199
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.get_facter_output('module') == None


# Generated at 2022-06-24 23:17:36.857725
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()

    # Test with valid value for ansible module argument `module`
    # Test with valid value for ansible module argument `opt_dirs`
    # Test with valid value for ansible module argument `subdirs`
    # Test with valid value for ansible module argument `default`
    # TODO: add tests


# Generated at 2022-06-24 23:17:38.587895
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()



# Generated at 2022-06-24 23:17:41.610735
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_1 = FacterFactCollector()
    facter_fact_collector_2 = FacterFactCollector()
    facter_fact_collector_3 = FacterFactCollector()


# Generated at 2022-06-24 23:17:45.305561
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    assert True


# Generated at 2022-06-24 23:19:46.606322
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    pass


# Generated at 2022-06-24 23:19:49.320770
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    collected_facts = None
    module = None
    facter_fact_collector_0.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-24 23:19:54.810289
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    """
    Test the case where in script arg 'facter' is present.
    """
    # Stub data
    module = MagicMock()
    module.get_bin_path = MagicMock(return_value="/usr/bin/facter")
    facter_fact_collector_0 = FacterFactCollector()
    facter_fact_collector_0.run_facter = MagicMock(return_value=(0, '{"a":"b"}', ''))

    result = facter_fact_collector_0.get_facter_output(module)
    assert type(result) is str
    assert result == '{"a":"b"}'


# Generated at 2022-06-24 23:19:59.842660
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    test_ansible_module = type('TestAnsibleModule', (object,), {})
    test_ansible_module.run_command = lambda x: (0, '{}', '')
    test_ansible_module.get_bin_path = lambda x: '/bin/facter'
    facter_fact_collector = FacterFactCollector()
    output = facter_fact_collector.get_facter_output(test_ansible_module)
    assert output == '{}'



# Generated at 2022-06-24 23:20:06.892457
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    class ModuleStub:
        def get_bin_path(self, arg0, **kwargs):
            return None
    module_stub = ModuleStub()
    assert facter_fact_collector_0.find_facter(module_stub) is None



# Generated at 2022-06-24 23:20:12.903888
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector_0 = FacterFactCollector()
    assert facter_fact_collector_0.find_facter() is None


# Generated at 2022-06-24 23:20:18.521110
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()

# Generated at 2022-06-24 23:20:20.907681
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # This test is a stub as we don't want to require facter just to get
    # the tests working
    pass


# Generated at 2022-06-24 23:20:22.904632
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_output = FacterFactCollector().get_facter_output(module=None)
    assert isinstance(facter_output, type(None))


# Generated at 2022-06-24 23:20:29.975542
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector_0 = FacterFactCollector()
    ansible_module_0 = AnsibleModule()
    ansible_module_6 = AnsibleModule()
    facter_fact_collector_0.collect(ansible_module_6)
    assert facter_fact_collector_0.collect(ansible_module_0) == {}
