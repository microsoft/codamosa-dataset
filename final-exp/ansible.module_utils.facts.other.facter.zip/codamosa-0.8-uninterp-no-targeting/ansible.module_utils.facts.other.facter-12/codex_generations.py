

# Generated at 2022-06-20 18:30:32.732787
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()

    def get_facter_output(self):
        facter_path = self.find_facter(self)
        if not facter_path:
            return None

        rc, out, err = self.run_facter(self, facter_path)

        if rc != 0:
            return None

        return out

    def find_facter(self, module):
        facter_path = module.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
        cfacter_path = module.get_bin_path('cfacter', opt_dirs=['/opt/puppetlabs/bin'])

        # Prefer to use cfacter if available

# Generated at 2022-06-20 18:30:44.441911
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    class MockModule(object):
        def get_bin_path(self, path, opt_dirs):
            return "/path/to/" + path

    facter_collector = FacterFactCollector()

    assert facter_collector.find_facter(MockModule()) == "/path/to/cfacter"

    class MockModule1(object):
        def get_bin_path(self, path, opt_dirs):
            if path == "cfacter":
                return None
            return "/path/to/" + path

    assert facter_collector.find_facter(MockModule1()) == "/path/to/facter"


# Generated at 2022-06-20 18:30:48.232645
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert 'facter' in facter_collector._fact_ids


# Generated at 2022-06-20 18:30:52.814109
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts import get_collector_instance
    facter_collector = get_collector_instance('facter')
    assert isinstance(facter_collector, FacterFactCollector)
    assert facter_collector.name == 'facter'
    assert facter_collector._fact_ids == set(['facter'])

# Generated at 2022-06-20 18:31:03.855923
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    cf = FacterFactCollector()
    class MockModule(object):
        def __init__(self):
            self.mock_bin_paths = {'facter': "/usr/bin/facter", 'cfacter': "/usr/bin/cfacter"}

        def get_bin_path(self, *args, **kwargs):
            return self.mock_bin_paths.get(*args, **kwargs)

        def run_command(self, *args, **kwargs):
            return 0, b'{"facter1": "value1"}', ''

    mock_module = MockModule()

    # Test run_facter
    assert cf.find_facter(mock_module) == "/usr/bin/cfacter"

# Generated at 2022-06-20 18:31:14.178600
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector as facts_collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    result = facts_collector.collect(
        module=None,
        collected_facts=None,
        namespace='ansible_local',
        filter_namespaces=True,
        collectors=[FacterFactCollector],
        preprocess_plugins=[],
        postprocess_plugins=[]
    )

    if result.get('ansible_local', None) is not None:
        facter_output = result['ansible_local'].get('facter_fact', None)

        if facter_output is not None:
            facter_dict = {}


# Generated at 2022-06-20 18:31:22.238748
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facter import FacterFactCollector

    class fake_module(object):

        def __init__(self):
            self.params = {}
            self.rc = None
            self.out = None
            self.err = None

        def fail_json(self, **kwargs):
            raise Exception('This is a fake fail_json')


# Generated at 2022-06-20 18:31:34.567099
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys

    script = '''
    import sys
    import json

    print(json.dumps({'fact1': 'value1', 'fact2': 'value2'}))
    '''

    from ansible.module_utils.facts.collector import DummyModule
    module = DummyModule(argument_spec={})

    facter_path = 'facter'
    if sys.platform.startswith('win'):
        facter_path = 'facter.bat'

    collector = FacterFactCollector()
    collector.run_facter = lambda module, facter_path: (0, script, "")
    facter_output = collector.get_facter_output(module)
    assert facter_output == script


# Generated at 2022-06-20 18:31:40.270094
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    import ansible.module_utils.basic as basic
    basic._ANSIBLE_ARGS = basic.AnsibleOptions()
    basic._ANSIBLE_ARGS.module_name = 'setup'
    basic._ANSIBLE_ARGS.module_path.append('../unit/')

    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-20 18:31:42.644121
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector
    assert facter_collector.name == 'facter'
    assert facter_collector.fact_ids == {'facter'}

# Generated at 2022-06-20 18:31:46.966811
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    fact_collector = FacterFactCollector(collectors=None, namespace=None)
    assert fact_collector.name == 'facter'



# Generated at 2022-06-20 18:31:54.330792
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    If a module is given, the collect method should run with the default 'facter'
    facter_path, and an empty facter_dict should be returned.
    """
    # instantiate a FacterFactCollector object
    fact_collector = FacterFactCollector()
    module = None
    collected_facts = {}
    ret = fact_collector.collect(module=module, collected_facts=collected_facts)
    # should get an empty facter_dict
    assert ret == {}


# Generated at 2022-06-20 18:32:02.469251
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ffc = FacterFactCollector()

    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            return '/bin/{}'.format(name)

    facter_path = ffc.find_facter(MockModule())

    assert facter_path == '/bin/cfacter'


# Generated at 2022-06-20 18:32:05.048454
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    module = ''
    fact_collector = FacterFactCollector(module)
    assert fact_collector



# Generated at 2022-06-20 18:32:15.197752
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    # Get the class object of class FacterFactCollector
    facter_fact_collector_class = FacterFactCollector()

    # Create an object of class FacterFactCollector
    facter_fact_collector = facter_fact_collector_class()

    # Create an object of class AnsibleModule
    mock_ansible_module = MagicMock()

    # Mock object called by facter_fact_collector.find_facter()
    # Set the return value of method "get_bin_path" to a string
    mock_ansible_module.get_bin_path.return_value = "./bin/facter"

    # Call method find_facter of class FacterFactCollector

# Generated at 2022-06-20 18:32:24.175581
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import mock
    m = mock.Mock()

    m.get_bin_path.return_value = None
    ffc = FacterFactCollector()

    assert ffc.find_facter(m) is None

    m.get_bin_path.return_value = '/bin/facter'
    assert ffc.find_facter(m) == '/bin/facter'

    m.get_bin_path.return_value = None
    ffc._module_cache[m.name]['list_of_binaries'] = ['facter', 'cfacter']
    assert ffc.find_facter(m) == '/bin/cfacter'

# Unit test to test the fetching of facter output from the OS

# Generated at 2022-06-20 18:32:35.976911
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ansible_collector

    # exclude all the collectors
    ansible_collector.exclude_collectors = ['*']
    options = dict(
        collectors=['ansible'],
        extra_options=dict(
            ansible_collectors_ignore=['*'],
            ansible_collection='ansible.module_utils.facts.collectors.facter',
        ),
    )
    fact_collector = get_collector_instance(options, None)
    fact_collector._module = MockAnsibleModule()
    fact_collector._module.get_bin_path.return_value = None


# Generated at 2022-06-20 18:32:45.218882
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    ff = FacterFactCollector()

    assert ff.run_facter(None, ff.find_facter(BaseFactCollector())) == (None, None, None)

    mock_module = BaseFactCollector()
    mock_module.run_command = lambda x, cwd=None: (0, to_bytes('{}'), to_bytes(''))

# Generated at 2022-06-20 18:32:57.477326
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import shutil
    try:
        os.mkdir('/tmp/ansible_facts')
    except OSError:
        pass
    shutil.copy('/usr/bin/facter','/tmp/ansible_facts/facter')
    shutil.copy('/usr/lib64/ruby/gems/2.6.0/gems/json-2.1.0/lib/json/common.rb','/tmp/ansible_facts/common.rb')
    shutil.copy('/usr/lib64/ruby/gems/2.6.0/gems/json-2.1.0/lib/json.rb','/tmp/ansible_facts/json.rb')

# Generated at 2022-06-20 18:33:03.014507
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    c = FacterFactCollector()
    assert c.name == 'facter'
    assert c.collectors is None
    assert c._fact_ids == set(['facter'])
    assert isinstance(c.namespace, PrefixFactNamespace)
    assert c.namespace.namespace_name == 'facter'
    assert c.namespace.prefix == 'facter_'

# Generated at 2022-06-20 18:33:19.304583
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import tempfile

    path = tempfile.mkdtemp(prefix='facter_')


# Generated at 2022-06-20 18:33:27.306789
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.utils import override_module_docstring

    test_namespace = Namespace('test_namespace', 'tns_')

    class TestCollector(Collector):
        name = 'test_collector'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    fact_collector_to_test = FacterFactCollector(namespace=test_namespace)

    override_module_docstring(fact_collector_to_test, 'test_collector', 'test')

    # Note that this mirrors previous facter behavior, where there isnt
    # a '

# Generated at 2022-06-20 18:33:39.651877
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    #FIXME: use mock for module
    class DummyModuleObject:
        def get_bin_path(self, name, opt_dirs=None):
            if "cfacter" == name:
                return "/opt/puppetlabs/bin/cfacter"

            elif "facter" == name:
                return "/usr/bin/facter"

            return None

        def run_command(self, cmd):
            if cmd.endswith("cfacter --puppet --json"):
                return 0, "", ""
            elif cmd.endswith("facter --puppet --json"):
                return 0, "", ""

            return 1, "", ""

    module = DummyModuleObject()

    facter_fact_collector = FacterFactCollector()
    # Cfacter not available
    facter_output

# Generated at 2022-06-20 18:33:42.384716
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
  facter = FacterFactCollector()
  assert facter.name == 'facter'
  assert facter._fact_ids == set(['facter'])


# Generated at 2022-06-20 18:33:49.931501
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = FakeModuleUtils(bin_paths={
        'facter': '/tmp/facter',
        'cfacter': '/tmp/cfacter',
    })

    collector = FacterFactCollector()

    # Prefer to use cfacter if available
    facter = collector.find_facter(module)
    assert(facter == '/tmp/cfacter')

    # Use fall back to facter if cfacter is not available
    module.bin_paths['cfacter'] = None
    facter = collector.find_facter(module)
    assert(facter == '/tmp/facter')

    # Return None if facter is not available
    module.bin_paths['facter'] = None
    facter = collector.find_facter(module)
    assert(facter is None)


# Generated at 2022-06-20 18:33:58.053013
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    """
    Generates a dummy module for get_bin_path to return expected value for
    facter or cfacter, and tests the find_facter method returns that value
    """
    
    import os
    
    # Dummy class for get_bin_path
    class DummyModule:
        def get_bin_path(self, binary, opt_dirs=None):
            if binary == "facter":
                return os.path.join("/", "usr", "bin", "facter")
            elif binary == "cfacter":
                return os.path.join("/", "opt", "puppetlabs", "bin", "cfacter")
    
    module = DummyModule()
    
    cfacter_path = os.path.join("/", "opt", "puppetlabs", "bin", "cfacter")

# Generated at 2022-06-20 18:34:09.130589
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    from ansible.module_utils.facts.collector import ModuleExecutor
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.collector
    import ansible.module_utils.common.process

    _collector = FacterFactCollector()

    class MockModuleExecutor(ModuleExecutor):
        def __init__(self, *args, **kwargs):
            ModuleExecutor.__init__(self, *args, **kwargs)

        def run_command(self, cmd):
            return to_bytes(0), 'facter', to_bytes('')

    class MockModuleParams(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs


# Generated at 2022-06-20 18:34:13.157688
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # If no versions of facter is installed, we should return None
    facter_path = FacterFactCollector().find_facter(None)
    assert facter_path is None

# Generated at 2022-06-20 18:34:20.786154
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils import basic
    rh1 = basic.AnsibleModule(argument_spec={})
    rh2 = basic.AnsibleModule(argument_spec={})
    rh2.run_command = lambda x: (0, x, '')
    rh1.get_bin_path = lambda x, y: x
    rh2.get_bin_path = lambda x, y: x
    rh1.run_command = lambda x: (1, '', '')
    rh3 = basic.AnsibleModule(argument_spec={})
    rh3.get_bin_path = lambda x, y: None
    assert(FacterFactCollector().run_facter(rh1, 'facter') == (1, '', ''))

# Generated at 2022-06-20 18:34:29.780403
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    # set up module
    module = AnsibleModule()

    # set up options for module
    module.params = {}
    module.params['collect_default_facts'] = False
    module.params['gather_subset'] = ['facter']

    # write the fake json file
    with open('/tmp/ansible_facts.json', 'w') as fp:
        fp.write('{"cmdline": {"facter": "--puppet --json"}}')

    # create facter facts
    facter_facts = FacterFactCollector()

    # parse the file
    facter_facts.parse(module)

    # set collector

# Generated at 2022-06-20 18:34:44.622725
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert facter_collector.collectors == None
    assert facter_collector.namespace.namespace_name == 'facter'
    assert facter_collector.namespace.prefix == 'facter_'


# Generated at 2022-06-20 18:34:45.722800
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == "facter"
    assert ffc._fact_ids == { 'facter' }

# Generated at 2022-06-20 18:34:56.731823
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector

    # Mock class AnsibleModule so we can use its instance method get_bin_path()
    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False,
                     supports_check_mode=False, required_if=None):
            class ReturnValues:
                def get_bin_path(self, binary, opt_dirs=[]):
                    if binary == 'facter':
                        return '/opt/puppetlabs/puppet/bin/facter'
                    elif binary == 'cfacter':
                        return '/opt/puppetlabs/puppet/bin/cfacter'

# Generated at 2022-06-20 18:35:00.692207
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector()
    assert(facter_fact_collector is not None)
    assert(facter_fact_collector.name == 'facter')
    # Note that the items in this set are unique, and occur only once, not multiple times
    assert(facter_fact_collector._fact_ids == set(['facter']))

# Generated at 2022-06-20 18:35:13.151175
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.test.test_facter import TestFacter
    from ansible.module_utils.facts.test.test_facter import TestFacterNoJson

    fact_collector = Collector(collectors=[FacterFactCollector()])

    # test ansible_facter exists
    module = TestFacter(dict(ANSIBLE_FACTER='facter_path'))
    facter_fact_collector = fact_collector.collector['facter']
    facter_fact_collector.find_facter = lambda module: module.ANSIBLE_FACTER

# Generated at 2022-06-20 18:35:20.942811
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    class FakeModule:
        def get_bin_path(self, name, opt_dirs):
            if name == 'facter':
                return '/bin/facter'
            else:
                return None
    module = FakeModule()
    facter_collector = FacterFactCollector()
    if facter_collector.find_facter(module) is None:
        raise Exception('test_FacterFactCollector_find_facter failed!')

# Generated at 2022-06-20 18:35:25.009659
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = ansible.module_utils.facts.ansible_facts.AnsibleModuleMock()
    module.exists.return_value = True
    module.which.side_effect = [None, '/usr/sbin/facter']
    FacterFactCollector(collectors=None, namespace=None).find_facter(module)

# Generated at 2022-06-20 18:35:35.096933
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # unit test helper
    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path

    # Setup
    mock_module = MockModule(bin_path=None)

    # Execute
    result = FacterFactCollector().find_facter(mock_module)

    # Assert
    assert result == mock_module.bin_path
    # Teardown

    # Setup
    mock_module.bin_path = "/usr/bin/facter"
    # Execute
    result = FacterFactCollector().find_facter(mock_module)

    # Assert
    assert result == mock_module.bin_path
    # Teard

# Generated at 2022-06-20 18:35:46.313967
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils import facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule:
        def __init__(self, facter_path=None, facter_rc=0):
            self.facter_path = facter_path
            self.facter_rc = facter_rc

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, cmd):
            if self.facter_rc != 0:
                return self.facter_rc, '', 'facter fail'


# Generated at 2022-06-20 18:35:56.009543
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    def mock_run_command(self, cmd, environ_update=None):
        return 0, '{"facter_1": "value1"}', ''
    ansible.module_utils.facts.collector.ModuleUtil.run_command = \
        mock_run_command

    facter_collector = FacterFactCollector()
    module = ansible.module_utils.facts.collector.ModuleUtil()
    rc, out, err = facter_collector.run_facter(module, '/bin/facter')
    assert rc == 0
    assert out == '{"facter_1": "value1"}'
    assert err == ''


# Generated at 2022-06-20 18:36:29.429403
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_text
    from io import BytesIO

    input_lines = (b'{"some": "value"}', b'{"fqdn": "foo.example.com"}')
    class FakeModule():
        def run_command(self, cmd):
            (fact_program, _) = cmd.split(" --puppet --json")
            rc = 0
            if fact_program == "/opt/puppetlabs/bin/cfacter":
                rc = 256
            out = BytesIO(input_lines[0] + b"\n" + b"\n".join(input_lines[1:]))
            return rc, out, b""

# Generated at 2022-06-20 18:36:41.004601
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.system

    class MockModule(object):

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg1, **kwargs):
            return arg1

        def run_command(self, arg1):
            if arg1 == 'facter --puppet --json':
                return 0, '{"a": 1, "b": "ok"}', None
            elif arg1 == 'cfacter --puppet --json':
                return 0, '{"c": 1, "d": "ok"}', None
            elif arg1 == 'facter':
                return 0, None, None

# Generated at 2022-06-20 18:36:42.128474
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Arrange
    obj = FacterFactCollector()

    # Act
    is_installed = obj.find_facter(None)

    # Assert
    assert is_installed is None

# Generated at 2022-06-20 18:36:51.309577
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class TestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, cmd, *args, **kwargs):
            return 0, '{"key": "value"}', ''

    test_module = TestModule()

    fact_collector = FacterFactCollector()
    facter_output = fact_collector.get_facter_output(test_module)

    assert facter_output is not None
    assert facter_output == '{"key": "value"}'

# Generated at 2022-06-20 18:36:59.685990
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule:
        def run_command(self, argv):
            self.called_with = argv
            return 0, json.dumps({'ansible_facts': {'facter': {}}}), ''

        def get_bin_path(self, app, opt_dirs=[]):
            if app == 'facter':
                return '/usr/bin/env facter'
            if app == 'cfacter':
                return '/usr/bin/env cfacter'
            return False

    module = MockModule()
    fc = FacterFactCollector()

    rc = fc.get_facter_output(module)

    assert module.called_with == '/usr/bin/env facter --puppet --json'
    assert rc is not None
    assert ('ansible_facts' in rc)

# Generated at 2022-06-20 18:37:09.825444
# Unit test for method find_facter of class FacterFactCollector

# Generated at 2022-06-20 18:37:10.668536
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    assert False

# Generated at 2022-06-20 18:37:13.310528
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_collector = FacterFactCollector()
    assert facter_collector.find_facter(None) == None

# Generated at 2022-06-20 18:37:22.044234
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import os
    import sys
    import types
    import unittest

    # Mock the module input argument
    # We only need the get_bin_path method
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = None

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'facter':
                return '/usr/bin/facter'
            elif binary == 'cfacter':
                return None
            else:
                return None

        def run_command(self, command):
            return 0, '{"os":{"family":"RedHat"}}', ''

    mock_module = MockModule()

    # The values below are what is expected after running collect()

# Generated at 2022-06-20 18:37:30.647068
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    class TestModule:
        def get_bin_path(self, name, opt_dirs):
            assert name in ('facter', 'cfacter')
            assert opt_dirs == ['/opt/puppetlabs/bin']

            # Prefer to use cfacter if available
            if 'cfacter' in name:
                return '/opt/puppetlabs/bin/cfacter'

            # Otherwise fallback to facter
            return '/opt/puppetlabs/bin/facter'

    module = TestModule()
    collector = FacterFactCollector()

    facter_path = collector.find_facter(module)

    assert '/opt/puppetlabs/bin/cfacter' == facter_path


# Generated at 2022-06-20 18:38:24.759785
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return args[0]

    class MockFactCollector:
        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors
            self.namespace = namespace

    mock_module = MockModule()
    mock_fact_collector = MockFactCollector()

    fact_collector = FacterFactCollector()
    facter_path = fact_collector.find_facter(mock_module)

    assert facter_path == 'facter' or facter_path == 'cfacter'

# Generated at 2022-06-20 18:38:34.666222
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    #mock_module = MagicMock()
    #mock_module = Mock()
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule()

# Generated at 2022-06-20 18:38:46.749891
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    class AnsibleModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'

        def run_command(self, command):
            if '--puppet' in command:
                return 0, '{ "os": {"name" : "TestOS" } }', ''

            return -1, '', ''

    facter_facts = FacterFactCollector(namespace='facter')

    assert facter_facts.run_facter(AnsibleModule(), facter_facts.find_facter(AnsibleModule())) == (0, '{ "os": {"name" : "TestOS" } }', '')

# Generated at 2022-06-20 18:38:54.975328
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test with invalid module inputs
    ffc = FacterFactCollector()
    assert ffc.collect(module=None) == {}

    # Test with invalid json
    module = MockModule()
    module.run_command.return_value = (0, "{{}", "")
    assert ffc.collect(module=module) == {}

    # Test with valid json
    module.run_command.return_value = (0, "[{\"fact\":\"value\"}]", "")
    assert ffc.collect(module=module) == {"fact": "value"}

# Generated at 2022-06-20 18:39:06.464097
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Setup
    import sys
    import tempfile
    import os
    from ansible.module_utils._text import to_bytes
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts.util import FactsUtil
    from ansible.module_utils.facts.collector import BaseFactCollector

    facts = {}
    os.environ = {}

    # Test execution
    fact_collector = FacterFactCollector()
    collected_facts = FactsUtil(fact_collector)


# Generated at 2022-06-20 18:39:13.468170
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_path = '/usr/bin/facter'
    status_code = 0
    stdout = '{"facter": 1, "facter2": 2}'
    stderr = ''

    class ModuleMock(object):
        def get_bin_path(*args, **kwargs):
            return facter_path

        def run_command(*args, **kwargs):
            return (status_code, stdout, stderr)

    module = ModuleMock()
    facter = FacterFactCollector()

    rc, out, err = facter.run_facter(module, facter_path)

    assert rc == status_code
    assert out == stdout
    assert err == stderr

# Generated at 2022-06-20 18:39:18.295081
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''FacterFactCollector_find_facter test'''
    ffc = FacterFactCollector()
    # Module.get_bin_path() always returns None
    assert ffc.find_facter(None) is None


# Generated at 2022-06-20 18:39:19.572193
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc is not None

# Generated at 2022-06-20 18:39:24.694726
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import pytest
    import json

    class MockModule:
        def __init__(self):
            self.params = None
            self.bin_path_cache = dict()
            self.run_command_cache = dict()

        def get_bin_path(self, bin_path, opt_dirs=None):
            if bin_path not in self.bin_path_cache:
                return None
            return self.bin_path_cache.get(bin_path)

        def run_command(self, command):
            if command not in self.run_command_cache:
                return None, None, None
            return self.run_command_cache.get(command)


# Generated at 2022-06-20 18:39:30.560248
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector(namespace='facter')
    assert ffc is not None
    assert ffc.name == 'facter'
    assert len(ffc._fact_ids) == 1
    assert 'facter' in ffc._fact_ids
    assert isinstance(ffc._namespace, PrefixFactNamespace)
    assert ffc._namespace.namespace_name == 'facter'
    assert ffc._namespace.prefix == 'facter_'