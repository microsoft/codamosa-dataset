

# Generated at 2022-06-20 18:30:30.141261
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    module = MockModule()
    facter = FacterFactCollector(collectors=[])

    facts = FactsCollector(collectors=[facter])

    expected_facts = {'facter': {}}
    facts_dict = facts.collect(module)
    assert facts_dict == expected_facts


# Generated at 2022-06-20 18:30:38.628097
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector

    module = ansible.module_utils.facts.collector.get_module()
    facter = FacterFactCollector()
    rc, out, err = facter.run_facter(module, '/usr/bin/facter')
    assert rc == 0
    assert len(out) > 0


# Generated at 2022-06-20 18:30:42.507469
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    MF = MockModule()
    FFC = FacterFactCollector()
    FFC.find_facter(MF)
    MF.get_bin_path.assert_called_with('cfacter', opt_dirs=['/opt/puppetlabs/bin'])


# Generated at 2022-06-20 18:30:43.307529
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    pass

# Generated at 2022-06-20 18:30:54.026190
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import subprocess
    from ansible.module_utils.facts.collector import FactsCollector
    import tempfile

    def init_gather_subset(self, module):
        self.module = module

    def mock_get_bin_path(self, binary, opt_dirs=[]):
        if binary == 'cfacter':
            return '/opt/puppetlabs/bin/cfacter'
        if binary == 'facter':
            return '/usr/bin/facter'

    class FakeModule:
        def __init__(self):
            self.run_command = subprocess.check_call
            self.exit_json = False

        def get_bin_path(self, binary, opt_dirs=[]):
            return mock_get_bin_path(self, binary, opt_dirs)


# Generated at 2022-06-20 18:30:59.902289
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    module = {
        'get_bin_path': lambda path, opt_dirs: '/usr/bin/facter'
    }

    facter_collector = FacterFactCollector()
    result = facter_collector.find_facter(module)

    assert(result == '/usr/bin/facter')

# Generated at 2022-06-20 18:31:06.265372
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = Mock()
    module.run_command = Mock(return_value=[0, '{ "domainname": "example.com" }', ''])
    module.get_bin_path = Mock(return_value='/bin/facter')
    collector = FacterFactCollector()
    collected_facts = {}
    facter_output = collector.get_facter_output(module)
    assert facter_output is not None
    facter_dict = json.loads(facter_output)
    assert facter_dict == {u'domainname': u'example.com'}


# Generated at 2022-06-20 18:31:10.744558
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = None
    facter_path = 'facter'
    ffc = FacterFactCollector()
    rc, out, err = ffc.run_facter(module, facter_path)
    assert rc == 0

# Generated at 2022-06-20 18:31:22.970603
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # This test cannot be run using ansible-test because ansible-test does not
    # support side effects.

    # Stub out the get_bin_path method to return the path of the facter
    # executable on the local system.
    class Module():
        def get_bin_path(self, name, **kwargs):
            return "facter"

    # Call the FacterFactCollector method, find_facter
    ffc = FacterFactCollector(namespace=None)
    facter_path = ffc.find_facter(Module())

    # Assert that the find_facter method returns the path to the facter
    # executable on the local system.
    assert facter_path == "facter"

# Generated at 2022-06-20 18:31:33.162817
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    results = {
        'rc': 0,
        'out': '{"a":"1","b":"2"}',
        'err': ''
    }

    class TestModule:
        def get_bin_path(self, app):
            return app

        def run_command(self, cmd):
            return (results['rc'], results['out'], results['err'])

    collector = FacterFactCollector()
    rc, out, err = collector.run_facter(TestModule(), '/bin/facter')
    assert rc == results['rc']
    assert out == results['out']
    assert err == results['err']

# Generated at 2022-06-20 18:31:43.186926
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_name_for_class

    assert get_collector_name_for_class(FacterFactCollector) == 'facter'
    assert isinstance(get_collector_instance(get_collector_name_for_class(FacterFactCollector)), FacterFactCollector)

# Generated at 2022-06-20 18:31:54.099389
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.test_utils import TestModule

    ansible_module = TestModule()
    collector = Collector(namespace='ansible',
                          collectors=[FacterFactCollector()])

    facter_output = collector._fact_collectors['facter'].get_facter_output(ansible_module)
    if facter_output is not None:
        facter_dict = json.loads(facter_output)
        assert isinstance(facter_dict, dict)
        return

    no_facter_list = []

# Generated at 2022-06-20 18:31:56.557181
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = None

    return


# Generated at 2022-06-20 18:32:06.881720
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    '''
    Verify that run_facter() returns correct data.
    '''
    # Create a FacterFactCollector object
    facter_fact_collector = FacterFactCollector(collectors=None,
                                                namespace=None)

    # Change method 'run_command' of module_utils.facts.module so that it returns
    # a tuple of out, err and rc.
    module = MockAnsibleModule()
    module.run_command = lambda path: ('{"test": "facter"}',
                                       '',
                                       0)

    # Call FacterFactCollector.run_facter() and verify output
    rc, out, err = facter_fact_collector.run_facter(module, 'path')
    assert rc == 0
    assert out == '{"test": "facter"}'


# Generated at 2022-06-20 18:32:16.211383
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''
    Unit test for method find_facter of class FacterFactCollector
    '''
    path_finder = FacterFactCollector().find_facter

    assert path_finder.__doc__ == '''
        Return the path of facter executable, or None if it is not installed.
        '''

    import os
    import tempfile
    module_utils_path = os.path.join(tempfile.mkdtemp(), 'ansible', 'module_utils')
    os.makedirs(module_utils_path)
    os.makedirs(os.path.join(module_utils_path, 'facts'))
    path_finder.module_utils_path = []
    path_finder.module_utils_path.append(module_utils_path)


# Generated at 2022-06-20 18:32:17.590387
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    obj = FacterFactCollector()
    assert obj.name == 'facter'
    assert obj._fact_ids == {'facter'}

# Generated at 2022-06-20 18:32:24.230346
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_path = "/opt/puppetlabs/bin/facter"
    ffc = FacterFactCollector()
    ffc._fact_ids.add("facter_testing")
    assert ffc.find_facter(None) == facter_path, "Facter path was incorrect!"
    assert ffc.get_facter_output(None) == None, "Facter output was incorrect!"


if __name__ == '__main__':
    test_FacterFactCollector()

# Generated at 2022-06-20 18:32:36.029021
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    #mock module
    mock_module = MockAnsibleModuleForFacter()
    # mock get_bin_path
    mock_module.get_bin_path = MockGetBinPath()
    # mock run_command
    mock_module.run_command = MockRunCommand()
    # mock BaseFactCollector.collect
    mock_collect = MockBaseFactCollectorCollect()
    # mock PrefixFactNamespace
    mock_namespace = MockPrefixFactNamespace()

    #facter_output is empty
    mock_get_facter_output_return = None
    facter_collector = FacterFactCollector(namespace=mock_namespace)
    facter_collector.get_facter_output = MockGetFacter(mock_get_facter_output_return)
    assert facter_collect

# Generated at 2022-06-20 18:32:45.253296
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import ModuleCollector

    class TestModule:
        def get_bin_path(self, command, opt_dirs=None, required=False):
            return '/bin/' + command

        def run_command(self, cmd):
            assert '/bin/cfacter' == cmd

# Generated at 2022-06-20 18:32:57.580917
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    import ansible.module_utils.facts.collector.facter as facter
    # Create a FacterFactCollector object
    facter_obj = facter.FacterFactCollector()

    # check with facter installed
    facter_obj.module.get_bin_path = lambda x, opt_dirs=[] : '/usr/bin/facter'
    assert '/usr/bin/facter' == facter_obj.find_facter(facter_obj.module)

    # check with facter and cfacter installed
    facter_obj.module.get_bin_path = lambda x, opt_dirs=[] : '/opt/puppetlabs/bin/cfacter' if x == 'cfacter' else '/usr/bin/facter'
    assert '/opt/puppetlabs/bin/cfacter' == fact

# Generated at 2022-06-20 18:33:06.857196
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import (
        BaseFactCollector,
    )
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collectors.facter import (
        FacterFactCollector
    )

    collectors = [FacterFactCollector()]
    # The CollectedFacts objects will be used to store and retrieve data
    # to and from the collector
    gathered_facts = FactCollector(collectors=collectors)

    # The FakeModule is used to mock the AnsibleModule object in the
    # CollectedFacts object

# Generated at 2022-06-20 18:33:18.862924
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class TestModule(object):
        def run_command(self, cmd):
            self.cmd = cmd
        def get_bin_path(self, bin, opt_dirs=None):
            if bin in ('cfacter', 'facter'):
                return "/usr/bin/%s" % bin

    m = TestModule()
    ffc = FacterFactCollector()

    # Test with valid cfacter output
    assert ffc.run_facter(m, '/usr/bin/cfacter')[1] == '{}'
    # Test with valid facter output
    assert ffc.run_facter(m, '/usr/bin/facter')[1] == '{}'

    # Test with facter output after removal of 'ruby-json'
    # In this case, the JSON output is not printed
    assert f

# Generated at 2022-06-20 18:33:27.049005
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    import tempfile


# Generated at 2022-06-20 18:33:36.071514
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import FacterFactCollector
    collector = FacterFactCollector()

    # Test with a fake module that returns no facter output
    fake_module = FakeModule(
        run_command_return_values=[(1, "fake_facter_output", None)])
    assert collector.run_facter(fake_module, "fake_facter_path") == (1, "fake_facter_output", None), \
        "FacterFactCollector.run_facter should return the output of the ansible module's run_command"


# Generated at 2022-06-20 18:33:46.816030
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = None

    # Any other executable in PATH is returned
    facter_path = "/other/bin/facter"
    def mock_run_command(path):
        if "get_bin_path" in path:
            return (0, facter_path, None)
        else:
            return (0, "1.2.1", None)

    module_facts = {
        "ansible_facter_version": "1.2.1"
    }

    class FakeModule:
        def __init__(self):
            self.run_command = mock_run_command
            self.facts = module_facts

    f = FacterFactCollector()
    assert f.find_facter(FakeModule()) == facter_path

    # The path in OPT_DIRS is returned

# Generated at 2022-06-20 18:33:54.224951
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import FactCollector

    ffc = FacterFactCollector()
    fact_collector = FactCollector(fact_collectors=[ffc], namespace=PrefixFactNamespace())

    # Stubbing method get_bin_path
    ffc.get_bin_path = lambda x, y: None

    assert ffc.get_facter_output(fact_collector) is None

# Generated at 2022-06-20 18:34:06.422163
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Test for facter/cfacter in standard path, as well as in puppet path
    ffc = FacterFactCollector()
    ffc.module.get_bin_path = lambda x, opt_dirs=None: None

    facter_path = ffc.find_facter(ffc.module)
    assert facter_path is None

    ffc.module.get_bin_path = lambda x, opt_dirs=None: x
    facter_path = ffc.find_facter(ffc.module)
    assert facter_path is not None

    ffc.module.get_bin_path = lambda x, opt_dirs=['/opt/puppetlabs/bin']: x
    cfacter_path = ffc.find_facter(ffc.module)

# Generated at 2022-06-20 18:34:18.176983
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class TestModule(object):
        def __init__(self):
            self.bin_path = '/bin/usr/facter'
        def get_bin_path(self, cmd, opt_dirs=None):
            if opt_dirs:
                return None
            return self.bin_path

    class TestCollector(FacterFactCollector):
        def __init__(self):
            self.fact_ids = set(['facter'])
        def run_facter(self, module, facter_path):
            if facter_path == TestModule.bin_path:
                return 0, '{"facter_test_key": "facter_test_value"}', ''
            else:
                return 1, '', 'No facter'

    def test_facter_exist():
        m = TestModule()


# Generated at 2022-06-20 18:34:24.776990
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    collector = FacterFactCollector(collectors=None, namespace=None)
    module = AnsibleModule(argument_spec=dict())
    facter_path = collector.find_facter(module)
    rc, out, err = collector.run_facter(module, facter_path)
    module.exit_json(rc=rc, stdout=out, stderr=err)


# Generated at 2022-06-20 18:34:33.006155
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_module = mock.MagicMock()
    facter_module.get_bin_path.return_value = "/usr/bin/cfacter"

# Generated at 2022-06-20 18:34:53.544767
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import tempfile
    import pytest

    class module(object):
        def get_bin_path(self, path, opt_dirs=None):
            return "/usr/bin/" + path

        def run_command(self, cmd, check_rc=True, close_fds=True):
            return 0, '{"foo": "bar"}', ""

    # This requires facter to be installed, and if facter is installed, and we can use --json because
    # ruby-json is ALSO installed, include facter data in the JSON
    ffc = FacterFactCollector()
    assert ffc.run_facter(module(), "/usr/bin/facter") == (0, '{"foo": "bar"}', "")

# Generated at 2022-06-20 18:35:01.838952
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    def get_bin_path(name, opt_dirs=[]):
        if name == 'cfacter':
            return '/opt/puppetlabs/bin/cfacter'
        elif name == 'facter':
            return '/usr/bin/facter'
        else:
            return None

    ffc = FacterFactCollector(collectors=None, namespace=None)
    # Case where cfacter is available
    facter_path = ffc.find_facter(get_bin_path=get_bin_path)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'
    # Case where cfacter is not available but facter is
    facter_path = ffc.find_facter(get_bin_path=get_bin_path)

# Generated at 2022-06-20 18:35:13.739777
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    try:
        import json
        import ansible.module_utils.facts.collector
        import ansible.module_utils.facts.namespace
        import ansible.module_utils.facts.facter
    except ImportError as err:
        raise SkipTest(err)

    # create fake module object to pass to the Facter fact collector
    from ansible.module_utils._text import to_bytes
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['facter']
            self.debug = True
            self.fail_json = False

        def get_bin_path(self, app, opt_dirs=[]):
            if app == 'facter' or app == 'cfacter':
                return app
            else:
                return

# Generated at 2022-06-20 18:35:17.544567
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc is not None
    assert ffc.name == 'facter'
    assert ffc._fact_ids == set(['facter'])
    assert isinstance(ffc.collect(), dict)

# Generated at 2022-06-20 18:35:23.442796
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    facter_collector = FacterFactCollector()

    assert isinstance(facter_collector, BaseFactCollector)
    assert facter_collector._namespace == PrefixFactNamespace('facter', 'facter_')

# Generated at 2022-06-20 18:35:34.328089
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class Module(object):
        class RunCommandException(Exception):
            pass

        def __init__(self, facter_bin_path, cfacter_bin_path, get_bin_path_exception):
            self.facter_bin_path = facter_bin_path
            self.cfacter_bin_path = cfacter_bin_path
            self.get_bin_path_exception = get_bin_path_exception

        def get_bin_path(self, facter, opt_dirs):
            if self.get_bin_path_exception is None:
                if facter == 'facter':
                    return self.facter_bin_path
                elif facter == 'cfacter':
                    return self.cfacter_bin_path
            else:
                raise self.get_bin_path_ex

# Generated at 2022-06-20 18:35:44.891319
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = AnsibleModuleMock({}, {})
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/usr/local/bin/facter'

    module = AnsibleModuleMock({}, {'facter_path': '/opt/puppetlabs/bin/facter'})
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/facter'

    module = AnsibleModuleMock({}, {'facter_path': '/bin/facter'})
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/bin/facter'


# Generated at 2022-06-20 18:35:50.807518
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    ffc = FacterFactCollector()
    facter_path = "/bin/facter"
    module = mock_module()
    fc_facter_output = ffc.get_facter_output(module)

    module.get_bin_path.assert_called_once_with('facter')
    module.run_command.assert_called_once_with(facter_path + " --puppet --json")

    assert fc_facter_output == "facter output"


# Generated at 2022-06-20 18:36:00.072156
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.collector import TestCollectedFacts

    fact_collector = FacterFactCollector()
    collected_facts = CollectedFacts(None, None, None)
    test_module = TestModule(None)

    collected_facts.add(TestCollectedFacts('geoserver_host', 'myhostname.domain.com'))

    fact_result = fact_collector.get_facter_output(test_module)

    assert fact_result



# Generated at 2022-06-20 18:36:10.198537
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    class ModuleMock(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'


# Generated at 2022-06-20 18:36:42.672996
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts import loader
    from ansible.module_utils.facts.collector import get_collector_names

    facter_fact_collector = None
    for fact_collector in loader.all_collectors:
        if getattr(fact_collector, 'name', None) == 'facter':
            facter_fact_collector = fact_collector
            break

    if facter_fact_collector is None:
        raise AssertionError('No Facter fact collector available')

    real_facter_path = facter_fact_collector.find_facter(None)
    if real_facter_path is None:
        raise AssertionError('No facter available')

    return_code, stdout, stderr = facter_fact_collector.run_facter

# Generated at 2022-06-20 18:36:51.949699
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    f = FacterFactCollector()
    class MockModule(object):
        def run_command(self, shell_command):
            return 0, "", "",

        def get_bin_path(self, utility, opt_dirs=[]):
            if utility == 'facter':
                return '/opt/something/facter'
            if utility == 'cfacter':
                return '/opt/something/cfacter'
            return None

    assert f.find_facter(MockModule()) == '/opt/something/cfacter'


# Generated at 2022-06-20 18:37:00.079128
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    '''Unit test for method collect of class FacterFactCollector'''

    # Create a module mock, since the json.loads method is mocked in the
    # get_facter_output mock, the returned value is passed to the collect
    # method as is.
    module_mock = MagicMock()

    # Create a FacterFactCollector class instance
    facter_fact_collector = FacterFactCollector()

    # Create a mocked run_facter method
    facter_fact_collector.run_facter = MagicMock(return_value=(0, '{}', ''))

    # Create a mocked get_facter_output method
    facter_fact_collector.get_facter_output = \
        MagicMock(return_value="{}")

    facts_dict = facter_fact_collector

# Generated at 2022-06-20 18:37:07.893053
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    module = mock()
    when(module).get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin']).thenReturn(None)
    when(module).get_bin_path('cfacter', opt_dirs=['/opt/puppetlabs/bin']).thenReturn('/opt/puppetlabs/bin/cfacter')
    facter = FacterFactCollector()
    assert facter.find_facter(module) == '/opt/puppetlabs/bin/cfacter'
    when(module).get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin']).thenReturn('/opt/puppetlabs/bin/facter')

# Generated at 2022-06-20 18:37:09.171968
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    collect_method = FacterFactCollector()
    assert collect_method.collect() is not None

# Generated at 2022-06-20 18:37:18.463586
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    FacterFactCollector.collect(module, collected_facts)
    """
    # Test with empty module and collected_facts
    ffc = FacterFactCollector()
    result = ffc.collect()
    assert result == dict()

    # Test with mocked module and collected_facts
    ffc2 = FacterFactCollector()
    ffc2.find_facter = lambda module: '/usr/bin/facter'
    ffc2.run_facter = lambda module, facter_path: (0, '{"test_key": "test_value"}', '')
    result = ffc2.collect(None, None)
    assert result == dict(facter_test_key='test_value')

# Generated at 2022-06-20 18:37:25.256880
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import os
    import platform

    # Generate dummy module
    class ModuleMock:
        def __init__(self):
            self.defines = {}

        def get_bin_path(self, executable, opt_dirs=None, required=False):
            # Mock out the facter executable
            if executable == 'facter':
                return os.path.join(os.path.expanduser('~'), '.facter2/bin/facter')
            elif executable == 'cfacter':
                return os.path.join(os.path.expanduser('~'), '.facter2/bin/cfacter')
            else:
                return None

        def run_command(self, path):
            # Fake the output from facter
            from subprocess import Popen, PIPE

# Generated at 2022-06-20 18:37:32.434705
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import Facts

    from ansible.module_utils.facts import ansible_collections

# Generated at 2022-06-20 18:37:43.705590
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule():
        def get_bin_path(self, arg1, opt_dirs=[]):
            return '/bin/facter'

        def run_command(self, arg1):
            if arg1 == 'facter --puppet --json':
                return (0, '{"facter_a": "aaa", "facter_b": "bbb"}', '')
            return (1, '', 'Command failed')

    ffc = FacterFactCollector()

    module = MockModule()

    # Test 1. If facter is installed, and we can use --json because
    # ruby-json is ALSO installed, include facter data in the JSON
    actual_output = ffc.get_facter_output(module)

# Generated at 2022-06-20 18:37:49.825201
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    #import ansible.module_utils.facts.collectors.facter
    #refactor collector to expose its namespace so that
    #fqcn does not need to be used in tests
    #collector_cls = ansible.module_utils.facts.collectors.facter.FacterFactCollector
    from ansible.module_utils.facts.collectors import FacterFactCollector
    collector = FacterFactCollector()

    mocked_module = MagicMock()
    mocked_collector = MagicMock()

    mocked_module.get_bin_path.return_value = "/bin/facter"
    mocked_module.run_command.return_value = (0, "json_output", "")

    collector.collect(mocked_module, mocked_collector)

# Generated at 2022-06-20 18:38:43.533868
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.namespace
    ansible.module_utils.facts.namespace.PrefixFactNamespace = PrefixFactNamespace
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.BaseFactCollector = BaseFactCollector

    module = MockModule()
    f = FacterFactCollector()
    assert f.collect(module) == {'facter_test': 'value'}


# Mock class to mimic ansible.module_utils.basic.AnsibleModule()

# Generated at 2022-06-20 18:38:51.166848
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = FakeAnsibleModule()

    facter_path = "/opt/puppetlabs/bin/facter --puppet --json"

# Generated at 2022-06-20 18:39:01.671834
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector

    # test on system with facter installed
    facter_path = ansible.module_utils.facts.collector.BaseFactCollector.find_executable('facter', ['/usr/bin'])
    assert facter_path is not None, "facter must be installed on system for this test"

    collector = FacterFactCollector()
    assert collector.get_facter_output(None) is None, "get_facter_output() must return None if module isn't supplied"

    rc, out, err = collector.run_facter(None, facter_path)
    assert rc, "run_facter() must return a successful return code (0)"
    assert out, "run_facter() must return some output when facter is installed"

# Generated at 2022-06-20 18:39:07.049417
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.name == 'facter'
    assert 'facter' in facter_fact_collector._fact_ids
    assert facter_fact_collector.collect() == {}


# Generated at 2022-06-20 18:39:11.408123
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    x = FacterFactCollector()
    assert isinstance(x, FacterFactCollector)
    assert isinstance(x, BaseFactCollector)
    assert hasattr(x, 'name')
    assert hasattr(x, '_fact_ids')
    assert x.name == 'facter'
    assert x._fact_ids == set(['facter'])



# Generated at 2022-06-20 18:39:13.022889
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert f.name == "facter"

# Generated at 2022-06-20 18:39:23.893165
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module_mock = {}

# Generated at 2022-06-20 18:39:29.514370
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """
    Make sure the FacterFactCollector.run_facter() method saves the output
    from the facter command in the instance variable volatile_facts
    """
    from ansible.module_utils.facts.collector import FactsCollector

    constants = {
        'FACTER_BINARY': 'facter',
        'FACTER_BINARY_ARGS': '--puppet --json',
    }
    fake_module = type('FakeModule', (), {
        'get_bin_path': lambda self, _, opt_dirs: '/usr/bin/facter',
        'run_command': lambda self, cmd: (0, '{"kernelversion": "4.2.0-42-generic"}', ''),
    })()


# Generated at 2022-06-20 18:39:31.848406
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    ffc = FacterFactCollector()
    ffc.run_facter(None, '/usr/bin/facter')

# Generated at 2022-06-20 18:39:39.699615
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Test that get_facter_output returns None when facter is not installed
    class TestModule:
        def get_bin_path(self,cmd, opt_dirs=[]):
            return None

    f = FacterFactCollector()
    test_module = TestModule()
    result = f.get_facter_output(test_module)
    assert result is None

    # Test that get_facter_output returns the JSON output of facter when facter is installed
    class TestModule:
        def get_bin_path(self,cmd, opt_dirs=[]):
            return "/bin/facter"
        def run_command(self,cmd):
            return 0, "{\"internalfact\": \"true\"}", None

    f = FacterFactCollector()
    test_module = TestModule()
    result = f