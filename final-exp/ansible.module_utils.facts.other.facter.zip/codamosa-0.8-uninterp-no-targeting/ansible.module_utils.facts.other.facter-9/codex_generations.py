

# Generated at 2022-06-20 18:30:33.024260
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector.system import SystemCollector

    # Create SystemCollector
    system_collector = SystemCollector()
    collectors = [system_collector]
    facter_collector = FacterFactCollector(collectors=collectors)

    # Create ansible_module
    class FakeModule:

        def get_bin_path(self, app):
            return '/usr/bin/' + app

        def run_command(self, cmd):
            return 0, '', ''

    ansible_module = FakeModule()
    facter_output = facter_collector.get_facter_output(ansible_module)

    assert facter_output is not None

if __name__ == "__main__":
    test_FacterFactCollector_get_facter_output()

# Generated at 2022-06-20 18:30:41.808324
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors

    class MockModule:
        def __init__(self, facter_bin_path):
            self.facter_bin_path = facter_bin_path
        
        def get_bin_path(self, executable, opt_dirs=None, required=False):
            if executable == 'facter' or executable == 'cfacter':
                return self.facter_bin_path
            else:
                return None

    class MockFactsCollector:
        def __init__(self):
            pass

        def find_facter(self, module):
            facter_path = module.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
            cfacter

# Generated at 2022-06-20 18:30:54.979960
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Initialize the object for testing
    facter_fact_collector = FacterFactCollector()
    # Import the AnsibleModule class
    from ansible.module_utils.facts import AnsibleModule
    # Create a AnsibleModule class object to provide inputs to test method
    ansible_module_object = AnsibleModule()
    # Find a proper facter_path for Module instance
    facter_path = facter_fact_collector.find_facter(ansible_module_object)
    # Execute method run_facter of class FacterFactCollector
    # using the inputs obtained above
    rc, out, err = facter_fact_collector.run_facter(ansible_module_object, facter_path)
    # Verify the outputs
    assert (rc == 0)
    assert (out is not None)


# Generated at 2022-06-20 18:31:05.058291
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # To run all tests, use 'ansible-test units --python'
    import ansible.module_utils.facts.collector.facter

    # Mock the module
    class MockModule:
        def __init__(self):
            self.run_command_call_count = 0

        def run_command(self, cmd):
            self.run_command_call_count += 1
            if self.run_command_call_count < 3:
                return (1, "", "")
            return (0, '{ "os": {"name": "RedHat"}}', "")

        def get_bin_path(self, bin_name, opt_dirs=None):
            return "/some/path/" + bin_name

    mock_module = MockModule()


# Generated at 2022-06-20 18:31:08.037092
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_obj = FacterFactCollector(namespace='ansible_facter')
    assert facter_obj is not None

# Generated at 2022-06-20 18:31:16.171948
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector.FacterFactCollector as ffacter
    from ansible.module_utils.facts.utils import ModuleWrapper
    from ansible.module_utils.facts import namespace
    import tempfile
    import os


# Generated at 2022-06-20 18:31:23.580481
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    fname = 'facter'
    assert fname == ffc.name, 'TEST FAIL: json2 fact_collector name not set'
    assert 'facter_' == ffc.namespace.prefix, 'TEST FAIL: json2 fact_collector namespace not set'
    assert 'facter' == ffc.namespace.namespace_name, 'TEST FAIL: json2 fact_collector namespace_name not set'


# Generated at 2022-06-20 18:31:34.956243
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.six import PY3
    fact_collector_test_class = FacterFactCollector()
    from ansible.module_utils.facts.module_utils._text import to_text
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.collectors.all as ansible_module_utils_facts_collectors_all
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.module_common as ansible_module_utils_facts_module_common
    ansible_module_utils_facts_module_common.ANSIBLE_VERSION = "2.6.17"
    ansible_module_utils_facts_module_common.ANSIBLE_MODULE_VERSION = "2.6.17"
    ansible_module_utils_facts

# Generated at 2022-06-20 18:31:46.203183
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Mock the module object
    class ModuleMock():
        def get_bin_path(self, cmd, opt_dirs=None):
            return '/opt/puppetlabs/bin/facter'
    module = ModuleMock()

    # Mock the facter fact collector
    facterfactcollector = FacterFactCollector()

    # Test that the first match is found
    facter_path = facterfactcollector.find_facter(module)
    assert(facter_path == '/opt/puppetlabs/bin/facter')

    # Mock the module object
    class ModuleMock():
        def get_bin_path(self, cmd, opt_dirs=None):
            return '/opt/puppetlabs/bin/cfacter'
    module = ModuleMock()

    # Mock the facter fact collector

# Generated at 2022-06-20 18:31:49.015440
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    fct = FacterFactCollector()
    assert fct.name == 'facter'
    assert fct._fact_ids == {'facter'}
    assert isinstance(fct._namespace, PrefixFactNamespace)


# Generated at 2022-06-20 18:31:59.838918
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector

    real_get_bin_path = ansible.module_utils.facts.collector.get_bin_path


# Generated at 2022-06-20 18:32:04.111113
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = None
    collector = FacterFactCollector()
    facter_out = collector.get_facter_output(module)
    assert facter_out is None

# Generated at 2022-06-20 18:32:14.513626
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils import basic
    import io


# Generated at 2022-06-20 18:32:24.359663
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-20 18:32:36.186931
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    try:
         from ansible.module_utils.facts import ansible_collections
    except ImportError:
         from ansible.module_utils.facts import ansible_collection_mock as ansible_collections

    # Note:  Override the dummy module in this test because we don't want to actually
    # run the facter command
    class FakeModule():
        def get_bin_path(self, x, opt_dirs=None):
            return '/usr/bin/facter'


# Generated at 2022-06-20 18:32:43.699377
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os

    class MockModule(object):
        def __init__(self):
            self.params = None
            self.path = None

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return os.path.join('/tmp', executable)

    module = MockModule()

    collectors = None
    namespace = None
    test_subject = FacterFactCollector(collectors=collectors, namespace=namespace)

    if test_subject.find_facter(module) is not None:
        assert True
    else:
        assert False



# Generated at 2022-06-20 18:32:48.739117
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # Create a fact module as if we were on a Linux system
    fact_module = BaseFactCollector(collectors=None, namespace=namespace)

    # Create a Facter Collector
    facter_collector = FacterFactCollector(collectors=None, namespace=None)

    # Fire a dummy facter command on a Linux system
    cmd = "/usr/local/bin/facter --json "
    rc, out, err = facter_collector.run_facter(fact_module, cmd)

    # Assert that we received a valid json structure

# Generated at 2022-06-20 18:32:58.020958
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import FactCollector

    class TestModule(object):
        class TestRunCommand(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def run_command(self, cmd, cwd=None, use_unsafe_shell=False,
                            encoding='utf-8', errors='surrogate_then_replace',
                            warn_only=False, executable=None, data=None):
                return self.rc, self.out, self.err

        def init_command(self, rc, out, err):
            self.run_command = self.TestRunCommand(rc, out, err)

    module = TestModule()

    # Test that facter not found will return None
    module

# Generated at 2022-06-20 18:33:04.505856
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import TestModule
    testmodule = TestModule()

    facter_path = FacterFactCollector().find_facter(testmodule)
    rc, out, err = FacterFactCollector().run_facter(testmodule, facter_path)

    assert rc == 0
    assert len(err) == 0
    assert len(out) > 0


# Generated at 2022-06-20 18:33:11.912017
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc is not None
    assert ffc.name == 'facter'
    assert ffc._fact_ids == {'facter'}
    assert isinstance(ffc._namespace, PrefixFactNamespace)
    assert ffc._namespace.namespace_name == 'facter'
    assert ffc._namespace.prefix == 'facter_'
    assert ffc._collectors == {}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 18:33:22.525220
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    constructor_test_1 = FacterFactCollector()
    assert isinstance(constructor_test_1, FacterFactCollector)
    assert constructor_test_1.name == 'facter'
    assert constructor_test_1.depends == set()
    assert constructor_test_1._fact_ids == set(['facter'])

# Generated at 2022-06-20 18:33:28.751471
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import MockModule
    import subprocess

    class MockSubProcess(object):
        def __init__(self):
            self.rc = 0
            self.stdout = None
            self.stderr = None

        def set_rc(self, rc):
            self.rc = rc

        def set_stdout(self, out):
            self.stdout = out

        def set_stderr(self, err):
            self.stderr = err

        def communicate(self):
            return (self.stdout, self.stderr)

        def poll(self):
            return self.rc


# Generated at 2022-06-20 18:33:40.770879
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os.path
    import tempfile
    import shutil
    import textwrap
    import json

    # Make a fake facter file
    fd, facter_path = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-20 18:33:43.891894
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    fact_collector = FacterFactCollector()
    assert fact_collector.name == 'facter'
    assert 'facter' in fact_collector._fact_ids


# Generated at 2022-06-20 18:33:50.551886
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    class ModuleMock(object):
        """ Mock module main class """
        def __init__(self):
            self.paths = ['/bin', '/usr/bin', '/sbin', '/usr/sbin']
        def get_bin_path(self, name, opt_dirs=[]):
            """ Mock get_bin_path method """
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            return None
        def run_command(self, cmd):
            """ Mock run_command method """
            return 0, '{"facter_a":{"fact1":"val1","fact2":"val2"}}', ''

    fac_col = FacterFactCollector()

    module = ModuleMock()

# Generated at 2022-06-20 18:33:54.878989
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = FakeModule({})
    facter_path = FacterFactCollector().find_facter(module)
    rc, out, err = FacterFactCollector().run_facter(module, facter_path)
    assert rc == 0
    assert out
    assert not err


# Generated at 2022-06-20 18:34:06.848142
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    # TODO: refactor to use a MockModule class
    class MockModule:
        def __init__(self):
            self.bin_path = lambda x, opt_dirs: None

    module = MockModule()

    facter_collector = FacterFactCollector()
    facter_path = facter_collector.find_facter(module)
    assert facter_path is None
    assert facter_collector.run_facter(module, facter_path) == (None, None, None)

    module.bin_path = lambda x, opt_dirs: None
    module.bin_path = lambda x, opt_dirs: '/opt/puppetlabs/bin/facter'
    facter_collector = FacterFactCollector()


# Generated at 2022-06-20 18:34:14.618851
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert f.name == 'facter'
    assert len(f._fact_ids) == 1
    assert 'facter' in f._fact_ids
    assert isinstance(f.namespace, PrefixFactNamespace)
    assert f.namespace.namespace_name == 'facter'
    assert f.namespace.prefix == 'facter_'

# Generated at 2022-06-20 18:34:25.157095
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-20 18:34:28.251595
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    m = FakeModule()

    facter_path = FacterFactCollector.find_facter(m)
    assert facter_path == '/usr/bin/facter'


# Generated at 2022-06-20 18:34:41.165123
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    fact_collector = FacterFactCollector()
    assert fact_collector.name == 'facter'
    assert fact_collector._fact_ids == set(['facter'])

# Generated at 2022-06-20 18:34:53.134662
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NestedDictPrefixFactNamespace
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import StringIO

    if not PY3:
        from ansible.module_utils.six import BytesIO as StringIO

    class TestModule(object):

        def __init__(self):
            self.params = {}
            self.exception = None


# Generated at 2022-06-20 18:35:01.632423
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Mock module
    class FakeAnsibleModule:
        def run_command(self, *args, **kwargs):
            import json


# Generated at 2022-06-20 18:35:11.363169
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = MockModule()
    facter_collector = FacterFactCollector()
    facter_path = facter_collector.find_facter(module)
    facter_output = facter_collector.get_facter_output(module)

    # facter_output should be a string
    assert isinstance(facter_output, str)

    # facter_output should contain the command used to fetch it
    assert "{0} --puppet --json".format(facter_path) in facter_output

# Mock module to test FacterFactCollector

# Generated at 2022-06-20 18:35:23.050537
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil

    def create_fake_facter_script(dirname, name):
        script_path = os.path.join(dirname, name)
        with open(script_path, 'wb') as script_file:
            script_file.write(b'#!/bin/sh\n')
            script_file.write(b'echo Fake Facter\n')
        os.chmod(script_path, 0o755)

    facter_path = None
    facter_install_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 18:35:27.416534
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = MockModule()
    ffc = FacterFactCollector(module=module)
    result = ffc.collect()
    assert result['facter_osfamily'] == 'RedHat'


# Generated at 2022-06-20 18:35:36.344608
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector.php_fact_collector import FacterFactCollector

    from ansible.module_utils.facts.php import ModuleStub
    from ansible.module_utils.six import StringIO

    module = ModuleStub()
    facter_path = "/opt/puppetlabs/bin/facter"
    facter_output  = "Facter Package"
    module_run_command_out = (0, facter_output, "")
    module.run_command = lambda facter_path: module_run_command_out

    m = FacterFactCollector(module=module)

    facter_output = m.get_facter_output(module)

    assert(facter_output == facter_output)

# Generated at 2022-06-20 18:35:47.671160
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    import sys

    # allow running test without installing the module
    basedir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(basedir)

    # test the FacterFactCollector class
    facter_dict = FacterFactCollector().collect()
    assert facter_dict.get('facter_puppetversion', None) is not None

# Generated at 2022-06-20 18:35:52.950752
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    ffc = FacterFactCollector()
    class TestModule:
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return "test_bin_path"
        @staticmethod
        def run_command(*args, **kwargs):
            return 0, "test_output", "test_error"
    tm = TestModule()
    assert(ffc.get_facter_output(tm) == "test_output")


# Generated at 2022-06-20 18:36:03.569413
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collectors.facter as facter_collector
    facter_collector.FacterFactCollector.run_facter = lambda x, y: (0, '{"success": "this is a test"}', '')
    facter_collector.BaseFactCollector._instance_cache['facter'] = None
    facter_collector.BaseFactCollector.collect_all()
    fact_dict = facter_collector.BaseFactCollector.get_fact_dict()
    assert json.dumps(fact_dict, sort_keys=True) == '{"ansible_facts": {"facter_success": "this is a test"}, "changed": false}'

# Generated at 2022-06-20 18:36:31.278153
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = "facter_path"
    module_mock.run_command.return_value = (0, '{"hostname": "hostname", "osfamily": "RedHat", "ipaddress": "127.0.0.1"}', '')
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.collect(module=module_mock)

# Generated at 2022-06-20 18:36:42.631524
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts.collector.system import SystemFactCollector

    # Create a mock module
    module = collect_facts.get_module_mock(ansible_facts={})

    # Instantiate a FacterFactCollector object
    collector = FacterFactCollector()

    # mock the facter path
    fake_path = '/usr/local/bin/facter'
    with collect_facts.mock.patch('ansible.module_utils.facts.collector.facter.FacterFactCollector.find_facter') as mock_find_facter:
        mock_find_facter.return_value = fake_path

        # mock the raw facter output

# Generated at 2022-06-20 18:36:48.979112
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-20 18:36:57.763231
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeModule:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=None):
            if name == "cfacter":
                return self.bin_path
            elif opt_dirs == ['/opt/puppetlabs/bin'] and name == "facter":
                return self.bin_path
            return None

        def run_command(self, cmd):
            if self.bin_path == "/usr/bin/cfacter":
                if cmd == "/usr/bin/cfacter --puppet --json":
                    return 0, '{"facter_a":"a","facter_b":"b"}\n', ''


# Generated at 2022-06-20 18:37:05.712336
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # pylint: disable=too-few-public-methods
    class Module:
        def get_bin_path(self, cmd, opt_dirs=None):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return (0, '{"facter_os": {"name": "RedHat"}}', '')
    ffc = FacterFactCollector()
    assert ffc.get_facter_output(Module()) == '{"facter_os": {"name": "RedHat"}}'


# Generated at 2022-06-20 18:37:16.439720
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts import _set_collectors
    from ansible.module_utils.facts.collector import get_collector_namespaces

    def prepare_mock_module():
        module = Mock()
        module.get_bin_path.side_effect = lambda name, **kwargs: '/usr/bin/{}'.format(name)
        return module

    def prepare_mock_facter_with_json():
        mock_facter = Mock()
        mock_facter.run_command.return_value = (0, '{"foo":"bar"}', None)
        return mock_facter

    def prepare_mock_facter_without_json():
        mock_facter = Mock()
        mock_facter.run_command.return_value = (1, None, None)
        return mock

# Generated at 2022-06-20 18:37:23.441565
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import sys
    import tempfile
    parent_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    sys.path.append(parent_path)
    from ansible.module_utils.common.collections import ImmutableDict

    f = tempfile.NamedTemporaryFile()

# Generated at 2022-06-20 18:37:31.566396
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    from ansible.module_utils._text import to_bytes

    # TODO: we should really have a test where we *dont* have
    # cfacter/facter on the PATH, but for now this is sufficient

    # No module passed to run_facter, an error should be raised
    try:
        facter_path = FacterFactCollector().find_facter(None)
        FacterFactCollector().run_facter(None, facter_path)
    except ansible.module_utils.facts.collector.FactCollectorError:
        pass
    except Exception:
        assert False

    # Facter installed, but no json output possible, we

# Generated at 2022-06-20 18:37:42.678883
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    import os
    import tempfile

    # get_facter_output returns None if module is None
    ffc = FacterFactCollector()
    result = ffc.get_facter_output(None)
    assert result is None

    # get_facter_output returns None if module.get_bin_path returns None
    # to test that, we need to override the real get_bin_path method to return None
    # To do that, we will replace the module.get_bin_path method with a dummy function
    # that always returns None
    # We then run get_facter_output and ensure it returns None
    #
    # To do that, we need to create a fake module object
    

# Generated at 2022-06-20 18:37:50.973823
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    class MockModule(object):
        def get_bin_path(self, executable, opt_dirs=None):
            return '/usr/bin/facter'
        def run_command(self, executable):
            if executable == '/usr/bin/facter --puppet --json':
                return 0, '{"foo":"bar"}', ""
            else:
                raise Exception("Invalid executable!")

    class MockCollectedFacts(object):
        def __init__(self):
            self.namespaces = {}

    module = MockModule()

    facter_collector = FacterFactCollector()
    collected_facts = MockCollectedFacts()

    new_facts = facter_collector.collect(module, collected_facts)

    assert 'facter_foo' in new_facts
    assert new_facts['facter_foo']

# Generated at 2022-06-20 18:38:37.444112
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = AnsibleModuleMock()
    collector = FacterFactCollector()
    facter_path = collector.find_facter(module)
    if facter_path is None:
        return
    rc, out, err = collector.run_facter(module, facter_path)
    assert isinstance(rc, int)
    assert isinstance(out, basestring)
    assert isinstance(err, basestring)


# Generated at 2022-06-20 18:38:48.108913
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = {}

    class FakeObject(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
    module.run_command = lambda x: FakeObject(0, '{"ansible_lsb":{"major_release":"12", "distrib_id":"Fedora"}}', '')
    module.get_bin_path = lambda x,y: 'foo_bin'

    ffc = FacterFactCollector()
    collected_facts = ffc.collect(module=module)

    assert collected_facts
    assert collected_facts['ansible_lsb']
    assert collected_facts['ansible_lsb']['distrib_id'] == 'Fedora'

# Generated at 2022-06-20 18:38:54.495121
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ff = FacterFactCollector()
    class module(object):
        @staticmethod
        def get_bin_path(command, opt_dirs=None):
            return '/opt/puppetlabs/bin' + '/' + command
    ff.find_facter(module)


# Generated at 2022-06-20 18:38:58.199987
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector

    fact_col = ansible.module_utils.facts.collector.FacterFactCollector()
    assert fact_col.find_facter(None) is None, "expected no facter binary to be found"


# Generated at 2022-06-20 18:39:04.003050
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    collector = FacterFactCollector()
    assert collector.name == 'facter'
    assert collector._fact_ids == set(['facter'])
    assert isinstance(collector._namespace, PrefixFactNamespace)
    assert collector._namespace.namespace_name == 'facter'
    assert collector._namespace._prefix == 'facter_'



# Generated at 2022-06-20 18:39:13.130317
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # testing collection of facter facts
    class FakeModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path
            self.facter_json = '''{
                "machine": {
                    "uniqueid": "d2ea0e7d-b2e0-435f-978f-a7b5eac0ac35",
                    "processor0": "AMD64 Family 16 Model 5 Stepping 2, AuthenticAMD",
                    "processor1": "AMD64 Family 16 Model 5 Stepping 2, AuthenticAMD",
                    "processor2": "AMD64 Family 16 Model 5 Stepping 2, AuthenticAMD",
                    "processor3": "AMD64 Family 16 Model 5 Stepping 2, AuthenticAMD"
                }
            }'''
            self.facter_err = ''

# Generated at 2022-06-20 18:39:24.006766
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector as collector
    from ansible.module_utils.facts import Namespace

    # set up test environment
    module_mock = type('module_mock', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '{"fact1": "value1"}', '')
    })
    module_mock.get_bin_path = lambda self, name, opt_dirs=[] : '/usr/bin/facter'
    module = module_mock()

    # execute test code
    facter_collector = FacterFactCollector()
    actual = facter_collector.collect(module)

    # validate results
    expected = {
        'facter_fact1': 'value1'
    }
    assert expected == actual

# Generated at 2022-06-20 18:39:29.573726
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import sys
    import os
    # save current sys.modules
    saved_modules = sys.modules.copy()
    module_path = os.path.join(os.path.dirname(__file__), '../module_utils')
    sys.modules['ansible.module_utils.facts'] = __import__('module_utils.facts', fromlist=['core'])
    sys.modules['ansible.module_utils.facts.namespace'] = __import__('module_utils.facts.namespace', fromlist=['core'])
    sys.modules['ansible.module_utils.facts.collector'] = __import__('module_utils.facts.collector', fromlist=['core'])
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-20 18:39:37.999476
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    module = MockModule()

    # mock things in module.run_command
    module.run_command.return_value = (0, '{"blah": true}', 'Facter ran!')

    # mock get_bin_path
    module.get_bin_path.return_value = '/mock/facter'

    fact_collector = FacterFactCollector()
    collected_facts = fact_collector.collect(module=module, collected_facts={})

    assert collected_facts == {'facter': {'blah': True}}



# Generated at 2022-06-20 18:39:45.459456
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    iface = FacterFactCollector()

    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule(run_command_unsafe=run_command_unsafe)

    facter_path = iface.find_facter(mock_module)

    iface.run_facter(mock_module, facter_path)

    mock_module.run_command.assert_called_with(
        'which facter && facter --version | grep -q ^2.4'
        )
