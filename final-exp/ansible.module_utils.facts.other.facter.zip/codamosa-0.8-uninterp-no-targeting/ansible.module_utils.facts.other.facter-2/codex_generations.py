

# Generated at 2022-06-20 18:30:33.847314
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    '''
    This function tests the get_facter_output function of class FacterFactCollector
    '''
    class MockModule:
        def __init__(self, facter_path):
            '''
            This function is the constructor of the MockModule class
            '''
            self.facter_path = facter_path

        def get_bin_path(self, name, opt_dirs=None):
            '''
            This function returns the path according to the name of the file
            '''
            if name == 'facter':
                return self.facter_path

        def run_command(self, command):
            '''
            This function returns the command that is run, output, and error
            '''

# Generated at 2022-06-20 18:30:41.913928
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facts_module = {
        'import_module': lambda path: None,
        'get_bin_path': lambda name: None,
        'run_command': lambda cmd: None,
    }
    ffc = FacterFactCollector(namespace=None,
                              collectors=[],
                              module=facts_module)
    assert ffc.name == 'facter'
    assert ffc._fact_ids == {'facter'}


# Generated at 2022-06-20 18:30:54.980847
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import sys
    import unittest
    import os.path

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

    _module = AnsibleModuleStub()
    _fact_collector = FacterFactCollector(collectors='', namespace='')

    # valid data
    _rc, _out, _err = _fact_collector.run_facter(_module, '/bin/facter')
    assert(_rc == 0)
    assert(_out is not None)

    # invalid data
    _rc, _out, _err = _fact_collector.run_facter(_module, '/bin/facter-test')
    assert(_rc == 1)
    assert(_out is None)

    _fact

# Generated at 2022-06-20 18:31:03.036860
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    # Test case for finding cfacter.
    def mock_module_run(module, command):
        return 0, '/opt/puppetlabs/bin/cfacter' + ' --puppet --json', ''

    f = FacterFactCollector()
    f.module = type('', (object,), {'run_command': mock_module_run})
    f.collect()
    assert f.facter_path == '/opt/puppetlabs/bin/cfacter'

    # Test case for finding facter.
    def mock_module_run(module, command):
        return 0, '/opt/puppetlabs/bin/facter' + ' --puppet --json', ''

    f = FacterFactCollector()
    f.module = type('', (object,), {'run_command': mock_module_run})


# Generated at 2022-06-20 18:31:05.095351
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter = FacterFactCollector()
    assert facter.name == 'facter'
    assert facter._fact_ids == set(['facter'])



# Generated at 2022-06-20 18:31:08.251770
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == 'facter'
    assert ffc._fact_ids == set(['facter'])



# Generated at 2022-06-20 18:31:14.745766
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''
    Test the method find_facter of class FacterFactCollector
    '''
    class DummyModule(object):
        '''
        Dummy class for unit test
        '''
        def get_bin_path(self, name, opt_dirs=None):
            '''
            Dummy method that returns name of binary path
            '''
            return name

    x = FacterFactCollector()
    facter_path = x.find_facter(DummyModule())

    assert facter_path is not None
    assert facter_path == 'facter'


# Generated at 2022-06-20 18:31:22.643717
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Setup class for testing
    import re
    import sys
    import tempfile

    from ansible.module_utils.facts.collector import CollectorException
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self):
            self.params = {}


# Generated at 2022-06-20 18:31:30.678118
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = None
    facter_path = "/opt/puppetlabs/bin/facter"
    facter_fact_collector = FacterFactCollector()
    rc, out, err = facter_fact_collector.run_facter(module, facter_path)
    assert rc == 0
    assert out is not None
    assert err == ''

# Generated at 2022-06-20 18:31:38.106667
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class FakeModule:
        def get_bin_path(self, path, opt_dirs=[]):
            return path

    # Create an instance of the FacterFactCollector class
    instance = FacterFactCollector(namespace='foo')

    # Create a fake module
    module = FakeModule()

    # If the FacterFactCollector instance can find the binary facter,
    # then the return value of the method find_facter of class FacterFactCollector
    # will be the string 'facter', otherwise, it will be None.
    result = instance.find_facter(module)

    assert result == 'facter'

# Generated at 2022-06-20 18:31:47.220583
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter = FacterFactCollector()

    class ModuleDummy:
        def __init__(self):
            self.facter_path = None

        def get_bin_path(self, executable, opt_dirs=[]):
            return self.facter_path

    module_dummy = ModuleDummy()

    # Test that get_facter_output returns None if get_bin_path returns None
    module_dummy.facter_path = None
    facter_output = facter.get_facter_output(module_dummy)
    assert facter_output is None

    # Test that get_facter_output returns None if run_command returns an error
    module_dummy.facter_path = '/bin/facter'

# Generated at 2022-06-20 18:31:51.185902
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = Mock()
    facter_path = 'mock_path'
    module.run_command.return_value = (0, 'return_out', 'return_err')

    facter_collector = FacterFactCollector()
    facter_collector.run_facter(module, facter_path)

    assert module.run_command.call_count == 1
    assert list(module.run_command.call_args)[0][0] == facter_path + " --puppet --json"


# Generated at 2022-06-20 18:31:58.121738
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():

    from ansible.module_utils.facts.collector import NamespacePrefixingFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    collectors = [1, 2]
    namespace = PrefixFactNamespace(namespace_name='facter', prefix='facter_')

    assert NamespacePrefixingFactCollector.__name__ == FacterFactCollector.__bases__[0].__name__
    assert facter.fact_ids == set(['facter'])
    assert facter.name == 'facter'
    assert facter.collectors == collectors
    assert facter.namespace == namespace


# Generated at 2022-06-20 18:32:02.847841
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert facter_collector.collectors is None
    assert isinstance(facter_collector.namespace, PrefixFactNamespace)

# Generated at 2022-06-20 18:32:13.809924
# Unit test for method find_facter of class FacterFactCollector

# Generated at 2022-06-20 18:32:24.566753
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeModule:
        class FakeRunCommandResult:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def __iter__(self):
                yield self.rc
                yield self.out
                yield self.err

            def __getitem__(self, index):
                return self.__iter__()[index]

        def __init__(self, facter_path, retcode, stdout, stderr):
            self.facter_path = facter_path
            self.retcode = retcode
            self.stdout = stdout
            self.stderr = stderr


# Generated at 2022-06-20 18:32:27.613016
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == 'facter'
    assert ffc.collector_set == set(['facter'])

# Generated at 2022-06-20 18:32:37.071855
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule(object):
        def get_bin_path(self, executable, opt_dirs=None):
            if executable == "facter":
                return "/opt/puppetlabs/bin/facter"
            elif executable == "cfacter":
                return None
            else:
                raise ValueError("Unexpected executable argument {0}".format(executable))

    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector.find_facter(MockModule())
    assert facter_path == "/opt/puppetlabs/bin/facter"


# Generated at 2022-06-20 18:32:45.743828
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    m = MockModule()

    ffc = FacterFactCollector()
    
    # Test the case where find_facter returns None
    m.find_bin_path.side_effect = None
    ffc.find_facter = lambda _: None

    assert ffc.collect(m) == {}

    # Test the case where find_facter does not return None
    m.find_bin_path.side_effect = ['facter_path']
    ffc.find_facter = lambda _: 'facter_path'

    # Test the case run_facter returns a rc != 0
    m.run_command.side_effect = [1, None]
    ffc.run_facter = lambda _, f: (1, None, None)

    assert ffc.collect(m) == {}

    # Test the case

# Generated at 2022-06-20 18:32:57.028074
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, '{"os":{"family":"RedHat"}}', None)
    facter_collector = FacterFactCollector()
    facter_facts = facter_collector.collect(mock_module)
    mock_module.get_bin_path.assert_called_once_with('facter', opt_dirs=['/opt/puppetlabs/bin'])
    mock_module.run_command.assert_called_once_with(mock_module.get_bin_path.return_value + ' --puppet --json')
    assert facter_facts['facter_os_family'] == 'RedHat'



# Generated at 2022-06-20 18:33:13.448233
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """
    Test to ensure that run_facter method extracts json information
    for the current host from Facter
    """
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestFacterFactCollector(FacterFactCollector):
        def __init__(self, module):
            self.module = module

    test_facter_fact_collector = TestFacterFactCollector(module=None)
    facter_path = '/usr/bin/facter'
    rc, out, err = test_facter_fact_collector.run_facter(None, facter_path)

    import json
    actual_facter_dict = json.loads(out)

    out_keys = actual_facter

# Generated at 2022-06-20 18:33:23.218491
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    class MyModule:
        def get_bin_path(self, binary, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, command):
            return (0, '[{ "kernel": "Linux" }]', '')

    ffc = FacterFactCollector()
    ansible_facts = FactsCollector(None, MyModule())
    ansible_facts.collect()
    ansible_facts.collect_facter_facts(ffc)
    assert ansible_facts.get('facter') == {'kernel': 'Linux'}

# Generated at 2022-06-20 18:33:26.711929
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector()
    assert(facter_fact_collector is not None)
    assert(facter_fact_collector.name == 'facter')

# Generated at 2022-06-20 18:33:31.021336
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_col = FacterFactCollector()
    assert 'facter' == facter_col.name
    assert facter_col._fact_ids == set('facter')
    assert 'facter_' == facter_col.namespace._prefix


# Generated at 2022-06-20 18:33:42.823963
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = type('FakeModule', tuple(), {
        'get_bin_path': lambda foo, bar: bar,
        'run_command': lambda foo: (0, '', '')
    })
    module.run_command = lambda *args: (0, '{}', '')
    ffc = FacterFactCollector()
    module = module()
    assert ffc.collect(module=module) == {}
    module.run_command = lambda *args: (1, None, '')
    assert ffc.collect(module=module) == {}
    ffc = FacterFactCollector(namespace=PrefixFactNamespace(namespace_name='facter',
                                                            prefix='facter_'))
    assert ffc.collect(module=module) == {}

# Generated at 2022-06-20 18:33:50.129559
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Create a class object
    f = FacterFactCollector()

    # Create a module object
    class TestModule:
        def __init__(self):
            self.params = None

        def run_command(self, args):
            return (0, '{"system_uptime":{"seconds":7221327,"hours":200,"days":8,"uptime":"8 days","seconds_with_frac":7221327.92},"operatingsystem":"SLES"}', '')

        def get_bin_path(self, cmd, opt_dirs=None, required=False):
            return 'facter'

    m = TestModule()

    # Run the run_facter method
    rc, out, err = f.run_facter(m, 'facter')

    assert rc == 0

# Generated at 2022-06-20 18:33:58.155017
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class TestModule(object):
        """docstring for TestModule"""

        def __init__(self):
            self._fact_path = None
            self._facter_path = None

        def get_bin_path(self, bin_path, opt_dirs=None):
            if bin_path == 'facter':
                return self._facter_path

            if self._fact_path is None:
                return None

            return bin_path


        # mock method module.run_command

# Generated at 2022-06-20 18:34:09.134960
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-20 18:34:13.158324
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    facter_dict = dict()
    collecter = FacterFactCollector()
    assert collecter.collect(module, facter_dict) == dict()

# Generated at 2022-06-20 18:34:20.785902
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.facts import get_facts
    from ansible.module_utils.facts.system_environment import generic_environment_facts
    from ansible.module_utils.facts.virtual.system_profiler import SystemProfilerFactCollector
    testnamespace = PrefixFactNamespace(namespace_name='facter',
                                        prefix='facter_')
    testnamespace2 = PrefixFactNamespace(namespace_name='ansible_system',
                                        prefix='ansible_system_')
    fc = FacterFactCollector(namespace=testnamespace)
    spfc = SystemProfilerFactCollector(namespace=testnamespace2)
    genenv_facts = generic_environment_facts()
   

# Generated at 2022-06-20 18:34:40.934829
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ModuleFacts

    class MockModule(object):

        def __init__(self, facter_output=''):
            self._facter_output = facter_output

        def get_bin_path(self, command, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, command):
            # only return the facter output that is passed in to the constructor
            return (0, self._facter_output, '')

    test_output = '{"operatingsystem":"CentOS","osfamily":"RedHat","virtual":"openvz"}'


# Generated at 2022-06-20 18:34:47.079067
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    class TestModule:
        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/usr/bin/facter'
            elif executable == 'cfacter':
                return None
            return None
        def run_command(self, command):
            if command == '/usr/bin/facter --puppet --json':
                output = '{"hello": "world", "facterversion": "2.4.4", "uptime": {"seconds": "145775"}, "id": "vagrant"}'
                return 0, output, None
            return 0, '', None

    # test facts gathering
    ff = FacterFactCollector()
    facts = ff.collect(module=TestModule())

# Generated at 2022-06-20 18:34:51.117315
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = None

    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector.find_facter(module)

    assert facter_path is not None


# Generated at 2022-06-20 18:35:00.692317
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    from ansible.module_utils.common.collections import ImmutableDict

    class FakeModule(object):
        def __init__(self):
            self.defines = ImmutableDict()

        def get_bin_path(self, path, opt_dirs=None):
            return

    class FakeModuleWithFacter(object):
        def __init__(self):
            self.defines = ImmutableDict()

        def get_bin_path(self, path, opt_dirs=None):
            return "/opt/puppetlabs/bin/facter"

    class FakeModuleWithCfacter(object):
        def __init__(self):
            self.defines = ImmutableDict()


# Generated at 2022-06-20 18:35:13.156796
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # TO-DO: Fix and enable tests
    return
    # Run the following unit tests only if facter is installed
    facter_path = module.get_bin_path('facter')
    if facter_path:
        # Create and intialize a Facter fact collector object
        facter_fact_collector = FacterFactCollector()
        # TO-DO: Fix and enable tests
        # Validate the fact collect method with facter installed
        assert facter_fact_collector.collect() is not None

        # TO-DO: Fix and enable tests
        # Validate the facter fact collector object namespace
        assert facter_fact_collector.namespace.namespace_name == 'facter'
        assert facter_fact_collector.namespace.prefix == 'facter_'



# Generated at 2022-06-20 18:35:18.898122
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    assert FacterFactCollector.name == 'facter'
    assert FacterFactCollector._fact_ids == set(['facter'])
    assert FacterFactCollector._namespace.namespace_name == 'facter'
    assert FacterFactCollector._namespace.prefix == 'facter_'


# Generated at 2022-06-20 18:35:27.173763
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    import os.path
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class TestFacterFactCollector(FacterFactCollector):
        def __init__(self, module=None, collectors=None, namespace=None):
            self.results = {}
            self.runt_facter = self.run_facter
            self.results['facter'] = self.runt_facter(module, '/usr/bin/facter')

# Generated at 2022-06-20 18:35:33.933549
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert facter_collector._fact_ids == set(['facter'])
    assert isinstance(facter_collector._namespace, PrefixFactNamespace)
    assert facter_collector._namespace.prefix == 'facter_'
    assert facter_collector._namespace.namespace_name == 'facter'
    assert facter_collector.collectors is None


# Generated at 2022-06-20 18:35:41.288255
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    """ Unit test for method find_facter of class FacterFactCollector """
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.namespace as namespace

    fact_collector = FacterFactCollector(namespace=namespace.BaseFactNamespace)

    class TestModule:

        @staticmethod
        def get_bin_path(name, **kwargs):
            return None

    fact_collector.find_facter(TestModule)
    assert fact_collector



# Generated at 2022-06-20 18:35:49.797316
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """ Unit test for method run_facter of class FacterFactCollector """

    class FakeModule:
        def get_bin_path(self, bin_path, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, command):
            return 0, '{"facter_test1": "value1"}', ''

    collector = FacterFactCollector()
    output = collector.run_facter(FakeModule(), collector.find_facter(FakeModule()))
    assert output[0] == 0
    assert output[1] == '{"facter_test1": "value1"}'
    assert output[2] == ''


# Generated at 2022-06-20 18:36:18.337447
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import FactsCollector

    # Note: module is None in unit tests of this class
    facter_fact_collector = FacterFactCollector()

    facter_fact_collector.get_facter_output = lambda module: '{"facter_test": "test"}'
    facter_fact_collector.find_facter = lambda module: '/usr/bin/facter'

    ansible_collections.ansible.posix.plugins.module_utils.network.f5.facts.base.load_params = lambda module: {}

    facter_data = facter_fact_collector.collect()
    assert 'facter_test' in facter_data

# Generated at 2022-06-20 18:36:21.656390
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    collector = FacterFactCollector()

    assert collector.name == 'facter'
    assert collector._fact_ids == {'facter'}

# Generated at 2022-06-20 18:36:27.621637
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    # Testing if class FacterFactCollector is has the attributes of BaseFactCollector
    ffc = FacterFactCollector()
    assert hasattr(ffc, '_fact_ids')
    assert hasattr(ffc, '__name__')
    assert hasattr(ffc, 'name')
    assert hasattr(ffc, 'collectors')
    assert hasattr(ffc, 'namespace')

# Generated at 2022-06-20 18:36:39.281684
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create placeholder module object
    class FakeModule(object):
        def get_bin_path(self, path_string, opt_dirs):
            return '/bin/facter'

# Generated at 2022-06-20 18:36:47.404787
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.facter import FacterFactCollector

    my_sys_paths = ['/usr/bin', '/opt/puppetlabs/bin']
    module = basic.AnsibleModule(argument_spec={})

    module.run_command = lambda *args, **kwargs: (0, '/usr/bin/facter', '')
    module.get_bin_path = lambda *args, **kwargs: (module.run_command()[1:])[0]
    BaseFactCollector.namespace_class = lambda *args, **kwargs: PrefixFactNamespace

# Generated at 2022-06-20 18:36:56.856356
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils import facts

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.tmpdir = None
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, arg, opt_dirs=[]):
            # Pretend we're on a Puppet Enterprise 3.8.7 system
            if arg == 'facter':
                return '/opt/puppetlabs/puppet/bin/facter'
            elif arg == 'cfacter':
                return '/opt/puppetlabs/puppet/bin/cfacter'
            else:
                return None

        def run_command(self, arg):
            if 'cfacter' in arg:
                stdout = ''
                stderr = ''

# Generated at 2022-06-20 18:37:07.047537
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.fact_collector import collect_facter_facts
    import tempfile

    for cmdname in ['cfacter', 'facter']:
        with tempfile.NamedTemporaryFile(prefix='ansible_test_%s' % cmdname) as t1:
            module = ModuleStub()
            t1.write('#! /bin/sh\n')
            t1.write('echo {"%s": "test"}\n' % cmdname)
            t1.flush()

            facter_path = collect_facter_facts.FacterFactCollector.find_facter(module)
            assert t1.name == facter_path
            t1.close()


# Generated at 2022-06-20 18:37:15.841551
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    '''Unit test of FacterFactCollector constructor'''

    ffc = FacterFactCollector()
    assert ffc.name == 'facter'
    assert ffc.collectors is None
    assert ffc.namespace.namespace_name == 'facter'
    assert ffc.namespace.prefix == 'facter_'

    ffc = FacterFactCollector(collectors=None, namespace='foo')
    assert ffc.name == 'facter'
    assert ffc.collectors is None
    assert ffc.namespace.namespace_name == 'facter'
    assert ffc.namespace.prefix == 'facter_'

# Generated at 2022-06-20 18:37:23.080536
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Test with a valid facter path, and valid output to stdout.
    # This should return the output.
    module = FakeModule(path=['/bin/facter'])
    facter_fact_collector = FacterFactCollector()
    rc, out, err = facter_fact_collector.run_facter(module, '/bin/facter')
    assert rc == 0
    assert err == ''
    assert 'aurelien' in out

    # Test with a valid facter path, and an error on stderr.
    # This should return the error.
    module = FakeModule(path=['/bin/facter'])
    facter_fact_collector = FacterFactCollector()

# Generated at 2022-06-20 18:37:31.376106
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    class MockModule(object):
        def __init__(self, return_value):
            self.return_value = return_value
        def get_bin_path(self, path, opt_dirs=None):
            if path == 'facter':
                return '/bin/facter'
            else:
                return None
        def run_command(self, command):
            if self.return_value is None:
                return 1, '', 'dev/null does not exist'
            else:
                return 0, self.return_value, ''

    # Note that this mirrors previous facter behavior, where there isnt
    # a 'ansible_facter' key in the main fact dict, but instead, 'facter_whatever'
    # items are added to the main dict.
    facter_dict = {}


# Generated at 2022-06-20 18:38:27.131375
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collectors.facter as facter_collector
    import ansible.module_utils.facts.namespace as ns

    import ansible.module_utils.facts.collector as c
    import ansible.module_utils.facts.system.platform as platform

    import ansible.module_utils.facts.system as system
    import ansible.module_utils.facts.system.distribution as distribution

    import ansible.module_utils.facts.kernel as kernel

    # Create a fake module for test_FacterFactCollector_run_facter
    class TestModule:
        def __init__(self):
            self.platform = "Linux"
            self.system = "Linux"
            self.name = "Linux"
            self.distribution = "Kali-Linux"
            self.dist

# Generated at 2022-06-20 18:38:33.688644
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector.facter as facter
    ansible_module_mock = AnsibleModuleMock()
    facter_fact_collector_mock = FacterFactCollector()
    module = facter_fact_collector_mock.run_facter(ansible_module_mock, "/opt/puppetlabs/bin/facter")
    assert module[0] == 0
    assert module[1] == "outdata"
    assert module[2] == "errdata"


# Generated at 2022-06-20 18:38:37.989585
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    f = FacterFactCollector()
    f._module = type('', (), {})()
    f._module.get_bin_path = lambda self, path, opt_dirs=None: path
    assert f.get_facter_output(f._module) == ''

# Generated at 2022-06-20 18:38:39.691511
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == "facter"

# Generated at 2022-06-20 18:38:48.886327
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    collectors = None
    namespace = None
    module_mock = ansible.module_utils.facts.collector.BaseFactCollector()
    test_obj = FacterFactCollector(collectors=collectors,
                                   namespace=namespace)
    facter_path = "/usr/bin/facter"
    module_mock.get_bin_path = lambda *args, **kwargs: facter_path
    test_obj.find_facter = lambda *args, **kwargs: module_mock
    return_value = test_obj.find_facter(module_mock)
    assert return_value == facter_path


# Generated at 2022-06-20 18:39:00.496832
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import sys
    import unittest
    import ansible.module_utils.facts.collector

    # If all this parsing of sys.modules makes you want to stab yourself in the face,
    # welcome to my world, friend. This is how you deal with dynamic module loading.
    if not "ansible.module_utils.facts.collector" in sys.modules:
        ansible.module_utils.facts.collector = __import__('ansible.module_utils.facts.collector')

    module = sys.modules['ansible.module_utils.facts.collector']
    if not "BaseFactCollector" in module.__dict__:
        BaseFactCollector = getattr(module, "BaseFactCollector")

    # If the user is running facter 2.x, it should be a hash and not a list.

# Generated at 2022-06-20 18:39:01.983499
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    fact_collector = FacterFactCollector()
    # test collect method of FacterFactCollector class

# Generated at 2022-06-20 18:39:06.738383
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ns = PrefixFactNamespace(namespace_name='facter',
                                        prefix='facter_')
    f = FacterFactCollector(namespace=ns)

    assert f.name == 'facter'


# Generated at 2022-06-20 18:39:13.866993
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    class Module(object):

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/opt_dir/facter'
            elif executable == 'cfacter':
                return '/opt_dir/cfacter'

    class CollectedFacts(object):

        def __init__(self):
            self.ansible_facts = {'ansible_facter': {}}

    module = Module()
    collected_facts = CollectedFacts()

    fact_collector = FacterFactCollector()
    facter_path = fact_collector.find_facter(module)

    assert facter_path == "/opt_dir/cfacter"


# Generated at 2022-06-20 18:39:24.153703
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.test.test_facter import (
        FAKE_MODULE,
        get_test_facter_data,
    )
    test_facter_data = get_test_facter_data()
    facter_collector = FacterFactCollector(
        collectors=[BaseFactCollector],
        namespace=None
    )
    facter_collector.fact_class.initialize(facter_collector)
    facter_collector.fact_class.get_facter_output_mock.return_value = test_facter_data
    facter_collector.collect(module=FAKE_MODULE)