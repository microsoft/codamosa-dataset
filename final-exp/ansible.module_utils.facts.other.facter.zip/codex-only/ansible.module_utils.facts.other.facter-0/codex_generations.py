

# Generated at 2022-06-23 00:16:51.933222
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    # test the constructor without arguments
    ffc = FacterFactCollector()
    assert ffc.name == "facter"
    assert ffc._fact_ids is not None
    assert ffc.name in ffc._fact_ids

    # test the constructor with arguments
    collectors = []
    namespace = PrefixFactNamespace(namespace_name='facter', prefix='facter_')
    ffc = FacterFactCollector(collectors=collectors, namespace=namespace)
    assert ffc.name == "facter"
    assert ffc._fact_ids is not None
    assert ffc.name in ffc._fact_ids
    assert ffc.namespace.name == "facter"
    assert ffc.namespace.prefix == "facter_"

# Generated at 2022-06-23 00:17:03.146918
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import sys
    import os
    import unittest
    # FIXME: do we have a way to mock this module in tests?
    sys.modules['ansible.module_utils.facts.collector'] = sys.modules['ansible.module_utils.facts.collector']

    # FIXME: do we have a way to mock this module in tests?
    sys.modules['ansible.module_utils.facts.namespace'] = sys.modules['ansible.module_utils.facts.namespace']

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.facter import FacterFactCollector


# Generated at 2022-06-23 00:17:07.568787
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert f.name == 'facter'
    assert f._fact_ids == set(['facter'])
    assert isinstance(f._namespace, PrefixFactNamespace)
    assert f._namespace.namespace_name == 'facter'
    assert f._namespace.prefix == 'facter_'


# Generated at 2022-06-23 00:17:17.606334
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    def run_facter(module, facter_path):
        rc, out, err = 0, '{"facter":{"test_key":"test_value"}}', ''
        return rc, out, err

    class FakeModule(object):
        def run_command(self, command):
            return 0, '{"facter":{"test_key":"test_value"}}', ''

    collector = FacterFactCollector()
    collector.run_facter = run_facter

    module = FakeModule()

    rc, out, err = collector.run_facter(module, 'path/to/facter')

    assert rc == 0
    assert err == ''
    assert out == '{"facter":{"test_key":"test_value"}}'


# Generated at 2022-06-23 00:17:28.029833
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class DummyFacter(BaseFactCollector):
        name = 'facter'
        _fact_ids = set(['facter'])
        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='facter',
                                            prefix='facter_')
            super(DummyFacter, self).__init__(collectors=collectors,
                                              namespace=namespace)

        def find_facter(self, module):
            return "/dir/to/facter"


# Generated at 2022-06-23 00:17:31.296583
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    collector = FacterFactCollector()
    assert collector.run_facter(None, None) == (0, None, None)

# Generated at 2022-06-23 00:17:42.069686
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    import os
    import tempfile
    import subprocess

    # Test data
    sub_dir_1 = 'dir_1'
    sub_dir_2 = 'dir_2'
    facter_path = '/usr/bin/facter'
    cfacter_path = '/usr/bin/cfacter'
    facter_version = '2.4.6'
    facter_output = '{ "facter_version": "' + facter_version + '" }'

    # Create a directory to be used as temporary directory in
    # get_facter_output method
    tmp_path = tempfile.mkdtemp()

    # Create a directory for the search for binary 'facter'
    facter_dir_1 = os.path.join(tmp_path, sub_dir_1)
    os.mk

# Generated at 2022-06-23 00:17:48.789753
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class FakeModule(object):
        def get_bin_path(self, bin_name, opt_dirs=[]):
            return "/usr/bin/facter"

        def run_command(self, cmd):
            return 0, "{ \"architecture\": \"i386\" }", ""

    module = FakeModule()
    ffc = FacterFactCollector()
    facter_output = ffc.get_facter_output(module)
    assert facter_output == "{ \"architecture\": \"i386\" }"

# Generated at 2022-06-23 00:17:54.352108
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    collector = FacterFactCollector()
    assert collector is not None
    assert collector.find_facter is not None
    assert collector.run_facter is not None
    assert collector.get_facter_output is not None
    assert collector.collect is not None
    assert collector.get_facter_output is not None
    assert collector._fact_ids == set(['facter'])


# Generated at 2022-06-23 00:18:00.691082
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    import unittest

    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch

    # Ensure that method FacterFactCollector.get_facter_output() returns None
    # if facter is not installed
    def test_returns_none_if_facter_is_not_installed(self):
        facter_fact_collector = FacterFactCollector()
        facter_fact_collector.find_facter = Mock(return_value=None)
        self.assertIsNone(facter_fact_collector.get_facter_output(None))

    # Ensure that method FacterFactCollector.get_facter_output() returns None
    # if facter is installed but facter failed to run

# Generated at 2022-06-23 00:18:01.926607
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    _collector = FacterFactCollector([])
    assert _collector.collect() == {}


# Generated at 2022-06-23 00:18:12.286512
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    collector = FacterFactCollector()
    del ansible.module_utils.facts.collector
    del ansible.module_utils.facts.namespace

    class ModuleMock():
        def run_command(cmd):
            return 0, '{"foo": "bar"}', None
        get_bin_path = lambda self, command, opt_dirs: command

    module = ModuleMock()
    rc, out, err = collector.run_facter(module, 'facter')
    assert rc == 0
    assert out == '{"foo": "bar"}'
    assert err is None


# Generated at 2022-06-23 00:18:18.015668
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    facts_dict = dict()
    fact_collector = FactsCollector(namespace=Namespace(),
                                    collected_facts=facts_dict)

# Generated at 2022-06-23 00:18:29.399452
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """
    FacterFactCollector.run_facter() is used in
    FacterFactCollector.collect() and returns three values:
    returncode, output, error

    mock objects of class FacterFactCollector are generated and their
    method run_facter() is called to check the return values.

    returncode should be 0 in all cases.
    """
    import mock
    import tempfile

    # define the return codes and output values
    return_code = 0

# Generated at 2022-06-23 00:18:38.173909
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule():
        # get_bin_path() stub
        def get_bin_path(self, bin_path, opt_dirs=[]):
            # Return facter path if facter command is passed
            # Return None if invalid command is passed
            if bin_path == 'facter':
                return '/opt/puppetlabs/bin/facter'
            elif bin_path == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

        # run_command() stub
        def run_command(self, command):
            if command == '/opt/puppetlabs/bin/cfacter --puppet --json':
                return 0, '{"memoryfree": "12.21 GB", "ipaddress": "192.168.0.31"}', ''
            el

# Generated at 2022-06-23 00:18:41.832588
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ff = FacterFactCollector()
    assert(ff.name == 'facter')
# end of test_FacterFactCollector()

# Generated at 2022-06-23 00:18:45.749271
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector(collectors=None, namespace=None)

    # FIXME: This does not work because of the way that the unittest module works.
    # assert facter_collector.name == 'FacterFactCollector'


# Generated at 2022-06-23 00:18:55.992212
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''Test method find_facter of class FacterFactCollector'''
    # TODO: must be mock

    class MockModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, name, opt_dirs=None, required=False):
            return self.facter_path

    nopath_facter = MockModule(None)
    collector = FacterFactCollector()

    assert collector.find_facter(nopath_facter) is None

    path_facter = MockModule('/bin/facter')
    assert collector.find_facter(path_facter) == '/bin/facter'


# Generated at 2022-06-23 00:18:58.222359
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = None
    collector = FacterFactCollector()
    facter_path = collector.find_facter(module)
    assert facter_path is not None


# Generated at 2022-06-23 00:19:09.057643
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class FakeModule:
        class FakeOpt:
            def get(self, option, default=None):
                return None

        def get_opt(self):
            fake_opt = FakeModule.FakeOpt()
            return fake_opt

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'facter':
                return '/usr/bin/facter'
            return None

    facter_collector = FacterFactCollector()

    module = FakeModule()
    facter_path = facter_collector.find_facter(module)
    assert facter_path == '/usr/bin/facter'

    module.get_bin_path = lambda binary, opt_dirs=[] : None
    facter_path = facter_collector.find_facter(module)
   

# Generated at 2022-06-23 00:19:17.175388
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    class DummyModule():

        def __init__(self):
            self.run_command_returns = [0, '/usr/bin/facter', None]

        def run_command(self, command_list, use_unsafe_shell=False):
            return self.run_command_returns

        def get_bin_path(self, exe, opt_dirs=[]):
            return '/usr/bin/facter'

    module_mock = DummyModule()
    facter_collector = FacterFactCollector()

    assert facter_collector.find_facter(module_mock) == '/usr/bin/facter'



# Generated at 2022-06-23 00:19:28.686200
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts import ModuleFactsCollector

    def test_module(module_name):
        class TestModule(ModuleFactsCollector):
            def fail_json(self, msg, **kwargs):
                pass

            def exit_json(self, **kwargs):
                pass

        return TestModule(module_name)

    test_module = test_module('test_module')

    def get_bin_path(module_name, opt_dirs):
        return "/opt/puppetlabs/bin/facter"

    def run_facter(module_name, opt_dirs):
        return 0, "", ""

    test_module.run_command = run_facter
    test_module.get_bin_path = get_bin_path

    facter_collector = FacterFactCollect

# Generated at 2022-06-23 00:19:39.781179
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    import tempfile
    import shutil

    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.BaseFactCollector = \
        BaseFactCollector = FacterFactCollector

    class Module(object):
        class RunCommandError(Exception):
            pass

        def __init__(self, tmpdir, facter_bin):
            self.tmpdir = tmpdir
            self.facter_bin = facter_bin

        def run_command(self, facter_cmd):
            if facter_cmd != self.facter_bin:
                return 1, '', 'Command "{0}"'.format(facter_cmd)
            elif not os.path.exists(self.facter_bin):
                return 1, '', 'Facter not found'


# Generated at 2022-06-23 00:19:50.858731
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector.system.facter import FacterFactCollector

    def mock_run_command(cmd):
        return 0, json.dumps({'facter1': 'value1', 'facter2': 'value2'}), None

    class FakeModule():
        def __init__(self):
            pass

        def get_bin_path(self, binary):
            return '/usr/bin/facter'

        def run_command(self, arg):
            return mock_run_command(arg)

    m = FakeModule()
    f = FacterFactCollector()
    r = f.run_facter(m, '/usr/bin/facter')
    assert 0 == r[0]

# Generated at 2022-06-23 00:20:01.592038
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():

    # No args for constructor --> use default values for class attributes
    facter_collector = FacterFactCollector()

    # Attributes are read-only
    try:
        facter_collector.name = 'test_FacterFactCollector'
        assert False
    except:
        pass
    try:
        facter_collector.fact_ids = set(['facter'])
        assert False
    except:
        pass
    try:
        facter_collector.collectors = None
        assert False
    except:
        pass
    try:
        facter_collector._fact_ids = set(['facter'])
        assert False
    except:
        pass

    # Accessors
    assert facter_collector.name == 'facter'

# Generated at 2022-06-23 00:20:07.020709
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule():
        def get_bin_path(*args, **kwargs):
            if args[1] == 'facter':
                return '/opt/puppetlabs/facter/bin/facter'
            if args[1] == 'cfacter':
                return '/opt/puppetlabs/facter/bin/cfacter'
            return None

    ff = FacterFactCollector()
    m = MockModule()
    s = ff.find_facter(m)
    assert(s == '/opt/puppetlabs/facter/bin/cfacter')
    return



# Generated at 2022-06-23 00:20:09.050271
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
  facter_fact_collector = FacterFactCollector()
  assert facter_fact_collector.name == 'facter'

# Generated at 2022-06-23 00:20:15.070038
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # the method find_facter uses the ansible module to search for the binary
    # ansible.module_utils.basic.AnsibleModule has not been implemented
    # and returns None when invoked as below
    # FIXME: this unit test is not working 
    module = AnsibleModule()
    ffc = FacterFactCollector()
    assert ffc.find_facter(module) == None

# Generated at 2022-06-23 00:20:21.484538
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    '''Unit test for method get_facter_output of class FacterFactCollector'''

    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return 'facter'

        @staticmethod
        def run_command(cmd):
            return 0, '{}', ''

    module = MockModule()

    facter_output = FacterFactCollector().get_facter_output(module)

    assert facter_output == '{}'

# Generated at 2022-06-23 00:20:27.550771
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    if sys.version_info[0] == 2:
        module = __import__('ansible.module_utils.facts.system.facter')
    elif sys.version_info[0] == 3:
        module = __import__('ansible.module_utils.facts.system.facter'.replace('.', ''))
    facter = FacterFactCollector()
    print(facter.get_facter_output(module))


# Generated at 2022-06-23 00:20:38.247092
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils import basic
    import os, tempfile, shutil
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Create directory to hold fake binaries
    test_dir = tempfile.mkdtemp()
    facter = os.path.join(test_dir, 'facter')
    cfacter = os.path.join(test_dir, 'cfacter')
    # Create fake binaries
    os.open(facter, os.O_CREAT)
    os.open(cfacter, os.O_CREAT)
    # Make the fake binaries executable
    os.chmod(facter, 0o755)
    os.chmod

# Generated at 2022-06-23 00:20:49.367465
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os

    class MockModule(object):
        def __init__(self):
            self.run_command_return_value = (0, '{ "somekey": "somevalue" }')

        def run_command(self, cmd):
            return self.run_command_return_value

    mock_module = MockModule()

    facter_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..',
                                           'lib/ansible/module_utils/facts/facter/output.txt'))

    facter_collector = FacterFactCollector()

    # When the return code is 0, the method should return the command output

# Generated at 2022-06-23 00:20:54.053595
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert isinstance(ffc, FacterFactCollector)

# Unit test to check if Facter is present in the system
# This test needs to be in the same file as FacterFactCollector /
# FacterFactCollector constructor, because the test need to be included
# in the unit test code coverage report.
# Please read readme.md file in the tests/unit/module_utils/facts/collectors
# directory for more details

# Generated at 2022-06-23 00:20:57.683147
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    mod = FacterFactCollector()
    facter_path = mod.find_facter(None)

    assert facter_path is not None


# Generated at 2022-06-23 00:21:05.788256
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import stubs
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Create a namespace
    namespace = PrefixFactNamespace(namespace_name='facter',
                                    prefix='facter_')

    # Instantiate a FacterFactCollector
    fact_collector = FacterFactCollector(namespace=namespace)

    # Create a base fact collector stub
    base_fact_collector = BaseFactCollector()
    base_fact_collector.collectors = [fact_collector]

    # Create a module stub
    module_stub = stubs.StubModuleUtilsFactory()

    # Create a facter stub

# Generated at 2022-06-23 00:21:17.415127
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence


# Generated at 2022-06-23 00:21:20.182361
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert f.name == 'facter'
    assert isinstance(f.collect(), dict)
    assert isinstance(f.collect(collected_facts=dict()), dict)

# Generated at 2022-06-23 00:21:28.777409
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector

    collector = ansible.module_utils.facts.collector.FacterFactCollector()
    facter_path = '/tmp/does_not_exist'

    # test if facter executable exists
    rc, out, err = collector.run_facter(None, facter_path)
    assert rc == 127
    assert out is None
    assert err is None

    # test for exception
    collector.run_facter = None
    rc, out, err = collector.run_facter(None, facter_path)
    assert rc == 1
    assert out is None
    assert err is None

# Generated at 2022-06-23 00:21:36.478651
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = FakeAnsibleModule()
    facter_path = '/usr/bin/facter'
    module.run_command_results = (0, '{"facter_foo": "bar", "facter_bar": "baz"}', '')
    ffc = FacterFactCollector()
    ffc.find_facter = lambda x: facter_path
    ffc.run_facter = lambda module, facter_path: module.run_command(facter_path + " --puppet --json")
    assert ffc.get_facter_output(module) == '{"facter_foo": "bar", "facter_bar": "baz"}'
    module.run_command_results = (1, '', 'Failed to run facter')
    assert ffc.get_facter_output(module)

# Generated at 2022-06-23 00:21:38.793086
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'

# Generated at 2022-06-23 00:21:49.911421
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module:
       def get_bin_path(self, name, opt_dirs=None):
           return "/opt/puppetlabs/bin/" + name


# Generated at 2022-06-23 00:22:00.953094
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    import ansible.module_utils.facts.module_common as facts_module_common

    class ModuleFailException(Exception):
        def __init__(self, rc=None, out=None, err=None):
            self.rc = rc
            self.out = out
            self.err = err

    class MockModule:
        def __init__(self):
            self.bin_path = '/usr/bin'
            self.facts = {}
            self.params = {}

        def fail_json(self, rc=None, out=None, err=None):
            raise ModuleFailException(rc, out, err)

        def get_bin_path(self, executable, opt_dirs=None, required=False):
            return self.bin_path + '/' + executable


# Generated at 2022-06-23 00:22:11.768158
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import platform
    import os.path

    class mock_module:
        def __init__(self):
            self.platform = platform.system()

        def get_bin_path(self, executable, opt_dirs=None):
            if executable == 'facter':
                if self.platform == 'Windows':
                    return os.path.abspath('C:\Program Files\Puppet Labs\Puppet\facter\bin')
                else:
                    return os.path.abspath('/usr/bin/facter')
            elif executable == 'cfacter':
                if self.platform == 'Windows':
                    return os.path.abspath('C:\Program Files\Puppet Labs\Puppet\facter\bin')

# Generated at 2022-06-23 00:22:13.631764
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert f is not None


# Generated at 2022-06-23 00:22:24.781357
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils import basic

    c_inst = get_collector_instance('facter')

    # get_bin_path() behaviour is tested in the test case for method find_facter
    # method. Here we simply mock the method.
    def mock_get_bin_path(module, executable, opt_dirs=[]):
        return '/usr/bin/' + executable

    module = basic.AnsibleModule(argument_spec=dict())
    module.get_bin_path = mock_get_bin_path

    # No facter or cfacter is installed on the system.
    c_inst.run_facter(module, None)

   

# Generated at 2022-06-23 00:22:35.856572
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    collector = FacterFactCollector()

    class Module:
        def get_bin_path(self, arg1, arg2=None):
            if arg2 is not None:
                if arg2[0] == '/opt/puppetlabs/bin':
                    return '/opt/puppetlabs/bin/cfacter'

            return '/usr/bin/facter'

    module = Module()
    assert collector.find_facter(module) == '/usr/bin/facter'

    class Module:
        def get_bin_path(self, arg1, arg2=None):
            return '/usr/bin/facter'

    module = Module()
    assert collector.find_facter(module) == '/usr/bin/facter'


# Generated at 2022-06-23 00:22:42.604942
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collector = FacterFactCollector()

    assert isinstance(fact_collector, BaseFactCollector)
    assert fact_collector.namespace == PrefixFactNamespace('facter', 'facter_')
    assert fact_collector._fact_ids == set(['facter'])

# Generated at 2022-06-23 00:22:52.957593
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import get_collector_instance
    from ansible.module_utils.facts.collector import Collector
    import mock
    import os

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, app, opt_dirs=[]):
            path = os.devnull
            if app == 'facter':
                path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    'test_facter.sh')
            return path

        def run_command(self, cmd):
            return 0, cmd, ''

    module = MockModule()
    namespace = PrefixFactNamespace(namespace_name='facter',
                                    prefix='facter_')

# Generated at 2022-06-23 00:22:58.662470
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert facter_collector._fact_ids == set(['facter'])
    assert len(facter_collector.namespace._namespace_prefix) == 1
    assert facter_collector.namespace._namespace_prefix[0] == 'facter_'

# Generated at 2022-06-23 00:23:07.726810
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import ModuleStub
    from ansible.module_utils._text import to_bytes

    class MockedModuleStub(ModuleStub):
        def get_bin_path(self, exe, opt_dirs=[]):
            if exe == 'facter':
                return '/opt/puppetlabs/bin/facter'
            elif exe == 'cfacter':
                return None
            else:
                return None

    facter_collector = FacterFactCollector(namespace=None)
    assert facter_collector.find_facter(MockedModuleStub()) == '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-23 00:23:17.899609
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    collector = FacterFactCollector()

    # Find facter
    path = '/usr/bin/facter'
    module = FakeAnsibleModule(paths=[path])
    assert collector.find_facter(module) == path
    module = FakeAnsibleModule(paths=[])
    assert collector.find_facter(module) is None

    # Find cfacter
    path = '/opt/puppetlabs/bin/facter'
    module = FakeAnsibleModule(paths=[path])
    assert collector.find_facter(module) == path
    module = FakeAnsibleModule(paths=[])
    assert collector.find_facter(module) is None

    # Find cfacter if both facter and cfacter are available.

# Generated at 2022-06-23 00:23:27.387057
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {'facter_json':True}

        def get_bin_path(self, cmd, opt_dirs=[]):
            return "/opt/puppetlabs/bin/facter"

        def run_command(self, cmd):
            return 0, "{\"architecture\":\"amd64\",\"augeasversion\":\"1.4.0\"}", ""

    module = MockModule()

    # Create a Facter fact collector
    facter = FacterFactCollector()

    rc, out, err = facter.run_facter(module, "/opt/puppetlabs/bin/facter")
    assert rc == 0

# Generated at 2022-06-23 00:23:32.065455
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class module:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
    ffc = FacterFactCollector()
    assert ffc.find_facter(module()) == '/usr/bin/facter'


# Generated at 2022-06-23 00:23:40.568906
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Create a dummy module that returns paths to facter and cfacter
    class DummyModule():
        def get_bin_path(self, program, opt_dirs=None):
            if program == 'facter':
                return '/path/to/facter'
            elif program == 'cfacter':
                return '/path/to/cfacter'

    test_module = DummyModule()
    test_collector = FacterFactCollector()

    assert test_collector.find_facter(test_module) == '/path/to/cfacter'


# Generated at 2022-06-23 00:23:50.399371
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    # Generate a class instance
    collector = FacterFactCollector()

    # Generate a module
    class module():

        def __init__(self):
            # Generate a class instance of ModuleUtil which has a run_command method
            class module_util():
                def run_command(self, command):
                    # Mock run_command method
                    print('mock run_command method')

                    if command.startswith('facter'):
                      return 0, json.dumps({'myfact':'myvalue'}), ''
                    elif command.startswith('cfacter'):
                      return 0, json.dumps({'myfact':'myvalue'}), ''
                    else:
                      return 1, '', ''

            self.module_util = module_util()


# Generated at 2022-06-23 00:24:02.336206
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import AnsibleModuleFake

    facter_path = "/opt/puppetlabs/bin/facter"
    facter_cmd = facter_path + " --puppet --json"
    facter_stdout = """{"kernel": "Linux", "somefact": "somevalue"}"""
    facter_rc = 0

    module = AnsibleModuleFake()
    module.run_command.return_value = facter_rc, facter_stdout, ""

    collector = FacterFactCollector()
    rc, out, err = collector.run_facter(module, facter_path)

    module.run_command.assert_called_once_with(facter_cmd)
    assert rc == facter_rc
    assert out == facter_stdout

# Generated at 2022-06-23 00:24:13.408725
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    os.environ['PATH'] = '/usr/bin:/bin'
    facter_dict = {}
    facter_dict['ansible_os_family'] = 'RedHat'
    facter_dict['os']['family'] = 'RedHat'
    facter_dict['os']['architecture'] = 'x86_64'
    facter_dict['os']['hardware'] = 'x86_64'
    facter_dict['os']['name'] = 'CentOS'
    facter_dict['os']['release']['full'] = '7.3.1611'
    facter_dict['os']['release']['major'] = '7'
    facter_dict['os']['release']['minor'] = '3'
    facter

# Generated at 2022-06-23 00:24:19.787487
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    # Test that __init__() of class FacterFactCollector sets _fact_ids and namespace
    facter_collector = FacterFactCollector()
    assert facter_collector._fact_ids == {'facter'}
    assert facter_collector.namespace._namespace_name == 'facter'
    assert facter_collector.namespace._prefix == 'facter_'

# Generated at 2022-06-23 00:24:25.885099
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    try:
        test_obj = FacterFactCollector()
    except Exception as e:
        assert False, "Failed to create FacterFactCollector object: " + str(e)

    module = None
    try:
        test_obj.collect(module)
    except Exception as e:
        assert False, "Failed to collect facts: " + str(e)

# Generated at 2022-06-23 00:24:26.742729
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    assert FacterFactCollectorNul().run_facter('/bin/true', '/bin/true') == (0, '', '')


# Generated at 2022-06-23 00:24:37.865190
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    p = FacterFactCollector()
    class module:
        def run_command(self, command):
            if command == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_os": {"name": "name", "family": "family", "release": {"major": "major"}}}', None
            elif command == '/usr/bin/cfacter --puppet --json':
                return 0, '{"facter_os": {"name": "name", "family": "family", "release": {"major": "major"}}}', None
            else:
                return 1, None, None
        def get_bin_path(self, command, opt_dirs=None):
            if command == 'cfacter':
                return '/usr/bin/cfacter'
            elif command == 'facter':
                return

# Generated at 2022-06-23 00:24:49.072405
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import os.path
    import sys

    if os.path.exists('/etc/redhat-release'):
        facter_path = '/usr/bin/facter'
        facter_json_output = '{"operatingsystem":"RedHat"}'
    elif os.path.exists('/etc/debian_version'):
        facter_path = '/usr/bin/facter'
        facter_json_output = '{"operatingsystem":"Debian"}'
    else:
        facter_path = None
        facter_json_output = None


# Generated at 2022-06-23 00:24:59.479081
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeModule(object):
        (rc, out, err) = (0, 'facter output', '')

        def get_bin_path(self, foo, opt_dirs=[]):
            return 'facter_path'

        def run_command(self, foo):
            return (self.rc, self.out, self.err)

    module = FakeModule()
    facter_collector = FacterFactCollector()

    # facter_path found and output is ok
    assert facter_collector.get_facter_output(module) == 'facter output'

    # facter_path not found
    module.get_bin_path = lambda *a, **kw: None
    assert facter_collector.get_facter_output(module) is None

    # facter_path found but command fails


# Generated at 2022-06-23 00:25:10.941724
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    class DummyModule(object):

        def __init__(self, path='/bin'):
            self.path = path

        def get_bin_path(self, *args, **kwargs):
            return self.path

    # cfacter/facter exists in PATH
    m = DummyModule()
    f = FacterFactCollector()
    assert '/bin/cfacter' == f.find_facter(m)

    # facter exists in PATH, but not cfacter
    m = DummyModule(path='/bin/facter')
    f = FacterFactCollector()
    assert '/bin/facter' == f.find_facter(m)

    # cfacter exists in /opt/puppetlabs/bin
    m = DummyModule()
    f = FacterFactCollector()

# Generated at 2022-06-23 00:25:18.840755
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module(object):
        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/facter"

        def run_command(self, *args, **kwargs):
            return 0, "{\"testkey\":\"testvalue\"}", None

    module = Module()
    fact_collector = FacterFactCollector()
    facter_output = fact_collector.get_facter_output(module)

    assert facter_output is not None
    assert facter_output == "{\"testkey\":\"testvalue\"}"

# Generated at 2022-06-23 00:25:29.891000
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''
    Test find_facter method of FacterFactCollector for various return values and
    input parameters.
    '''
    from ansible.module_utils.facts import Facts
    # test with no facter installed
    test_Facts_object = Facts(
        module_args=None,
        inject=None,
        callback=None,
        runner=None,
        odd_ignore_types=None,
        cache=None,
        collector='Facter',
        collectors=None,
        verbosity=None,
        serializer=None,
        serializers=None,
        extra_data=None)
    test_Facts_object.get_bin_path = lambda x, opt_dirs: None
    test_FacterFactCollector = FacterFactCollector()
    result = test_FacterFactCollector

# Generated at 2022-06-23 00:25:39.783292
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.facts.collector import Collector

    module_name = 'ansible_test'
    command_name = module_name
    command_path = os.path.join(tempfile.mkdtemp(), command_name)

# Generated at 2022-06-23 00:25:50.509291
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import mock

    cfacter_path = '/opt/puppetlabs/bin/cfacter'
    facter_path = '/opt/puppetlabs/bin/facter'

    module = mock.Mock()
    module.get_bin_path = mock.Mock(side_effect=[None, facter_path])
    ansible.module_utils.facts.collector.FacterFactCollector.__init__ = mock.Mock()
    facter = ansible.module_utils.facts.collector.FacterFactCollector(module)

    assert facter.find_facter(module) is None
    assert facter.find_facter(module) == facter_path


# Generated at 2022-06-23 00:25:56.982793
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_dict = {"facter_some_fact": "fact_value_1", "facter_another_fact": "fact_value_2"}
    module_mock = MockModule(out=json.dumps(facter_dict))
    facter_collector = FacterFactCollector()
    expected_facter_dict = facter_collector.collect(module=module_mock)
    assert expected_facter_dict == facter_dict


# Generated at 2022-06-23 00:26:07.869808
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module_args = dict(
        path='/usr/bin:/bin:/usr/sbin:/sbin'
    )
    mocked_module = type('AnsibleModule', (object,), module_args)

    module = mocked_module()
    facter_collector = FacterFactCollector()

    facter_path = facter_collector.find_facter(module)
    if facter_path is None:
        print("Facter not found, skipping test")
        return

    rc, out, err = facter_collector.run_facter(module, facter_path)

    exit_code = 0
    if err:
        exit_code = 1

    try:
        facter_dict = json.loads(out)
        assert facter_dict is not None
    except Exception:
        pass

   

# Generated at 2022-06-23 00:26:13.715842
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = type('Module', (object,), {
        'get_bin_path': mock_get_bin_path,
        'run_command': mock_run_command,
    })
    facter_collector = FacterFactCollector(None, None)
    assert facter_collector.find_facter(mock_module) == '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-23 00:26:25.157208
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import collector
    import os.path
    import tempfile


# Generated at 2022-06-23 00:26:25.785013
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    pass

# Generated at 2022-06-23 00:26:36.666764
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    module = type('AnsibleModule', (object,), {
        'run_command': lambda *args: (0, json.dumps({'a': 'b'}), ''),
        'get_bin_path': lambda *args: '/path/to/facter'})

    module_instance = module()
    collectors = Collector(module_instance)
    fact_collector = ansible.module_utils.facts.collectors.facter.FacterFactCollector(collectors,
                                                                                      ansible.module_utils.facts.namespace)


# Generated at 2022-06-23 00:26:40.338158
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = None
    facter_path = FacterFactCollector(collectors=None, namespace=None).find_facter(module)
    assert facter_path is None



# Generated at 2022-06-23 00:26:50.248833
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector

    module = ansible.module_utils.facts.collector
    facter_path = '/bin/facter'

    class FakeModule:
        def __init__(self):
            self.rc = 0
            self.success = True
            self.out = None
            self.err = None
            self.bin_path = facter_path

        def run_command(self, command):
            self.rc = 0
            self.success = True