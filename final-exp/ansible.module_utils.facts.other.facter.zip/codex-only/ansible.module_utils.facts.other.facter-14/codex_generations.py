

# Generated at 2022-06-23 00:16:56.742335
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():

    # Test return value of collect when there is facter output
    def get_facter_output(self, module):
        return '{"test_facter_key": "test_facter_value"}'

    # Test return value when there is no facter output
    def get_facter_output_none(self, module):
        return None

    # Test return value of find_facter when facter is found
    def find_facter(self, module):
        return 'facter'

    # Test return value of find_facter when facter is not found
    def find_facter_none(self, module):
        return None

    # Mock Module class
    class MockModule:
        def get_bin_path(self, name, opt_dirs=None):
            return name

    facter_collector = FacterFactCollect

# Generated at 2022-06-23 00:17:01.017278
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = None
    facter_path = "/bin/facter"
    ffc = FacterFactCollector()
    rc, out, _ = ffc.run_facter(module, facter_path)
    assert rc == 0

# Generated at 2022-06-23 00:17:09.821868
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """Unit test for FacterFactCollector.collect method
    """

    import sys
    if sys.hexversion < 0x2070000:
        # unittest2 is needed to run unit tests with Python 2.6
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test the Facter fact collector class with a mock facts collector
    class MockFactsCollector(BaseFactCollector):
        def collect(self, module, collected_facts=None):
            return { 'facts': 'somefacts' }


# Generated at 2022-06-23 00:17:12.258029
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ns = PrefixFactNamespace(namespace_name='facter',
                             prefix='facter_')

    facter_collector = FacterFactCollector(namespace=ns)
    assert facter_collector.namespace == ns
    assert facter_collector.name == 'facter'

# Generated at 2022-06-23 00:17:23.621877
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-23 00:17:34.003747
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import MemoryCollector
    from ansible.module_utils.facts import array_prepend
    from ansible.module_utils.facts.utils import get_file_lines

    class MockAnsibleModule:
        def __init__(self):
            self.params = dict()
            self.facts = dict()
            self.ansible_facts = dict()
            self.fail_json = None

        def get_bin_path(self, binname, opt_dirs=[]):
            return '/bin/' + binname


# Generated at 2022-06-23 00:17:39.301943
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ffc = FacterFactCollector()
    test_find_facter = ffc.find_facter(['/usr/bin/facter', '/usr/bin/cfacter'])
    assert test_find_facter == '/usr/bin/facter'


# Generated at 2022-06-23 00:17:47.109614
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = MockAnsibleModule()
    facter_path = module.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
    if not facter_path:
        print('Facter not found, test cannot run')
        return

    collector = FacterFactCollector()
    rc, out, err = collector.run_facter(module, facter_path)

    # FIXME: what good is this check? We are checking that facter is installed,
    # and if it is, the test should be a no-op then.
    if rc == 0:
        facter_dict = json.loads(out)
        assert 'hostname' in facter_dict
    else:
        print('Facter not installed, test cannot run')


# Generated at 2022-06-23 00:17:56.174106
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector.facter.collector_facter import FacterFactCollector
    class FakeModule:
        def run_command(self, c):
            return 0, '{"rubyversion" : "1.2.3"}', ''

        def get_bin_path(self, b):
            return '/usr/bin/facter'

    cf = FacterFactCollector()

    rc, out, err = cf.run_facter(FakeModule(), '/usr/bin/facter')
    assert (rc, out, err) == (0, '{"rubyversion" : "1.2.3"}', '')

# Generated at 2022-06-23 00:18:05.062668
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    ffc = FacterFactCollector()

    class ModuleMock(object):

        def __init__(self):
            pass

        # All of these are for get_bin_path
        def set_bin_path(self, path):
            self.bin_path = path

        def get_bin_path(self, path, opt_dirs=None):
            return self.bin_path

        # for run_command
        def set_run_command_rc(self, rc):
            self.run_command_rc = rc

        def set_run_command_out(self, out):
            self.run_command_out = out

        def run_command(self, path):
            return self.run_command_rc, self.run_command_out, ''

    # mock_module will be an instance of ModuleMock()

# Generated at 2022-06-23 00:18:16.415613
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create an instance of class FacterFactCollector,
    # with the method get_facter_output to be tested
    facter_collector = FacterFactCollector()

    # Create a mock AnsibleModule,
    # with the function get_bin_path to be mocked
    class AnsibleModule:
        def get_bin_path(self, *args):
            return '/usr/bin/facter'

        def run_command(self, *args):
            return 0, '{"SystemRelease": "7.3.1611"}', ''

    # Create an instance of class AnsibleModule,
    # with the function get_bin_path mocked
    module = AnsibleModule()

    # Invoke the function run_facter of class FacterFactCollector,
    # with the param AnsibleModule mocked

# Generated at 2022-06-23 00:18:27.709599
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import unittest
    from ansible.module_utils.facts import get_collector_object
    class MyModule:
        def get_bin_path(self, name, opt_dirs=None):
            if name == "cfacter":
                return "/opt/puppetlabs/bin/cfacter"
            else:
                return "/usr/bin/facter"
    class MockFactCollector(FacterFactCollector):
        def _init__(self, module):
            self.facter_path=self.find_facter(module)
    class TestFacterFactCollector(unittest.TestCase):
        def test_default(self):
            module = MyModule()
            fc = MockFactCollector(module)

# Generated at 2022-06-23 00:18:32.366509
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts import namespace
    collector = FacterFactCollector()
    assert collector.name == 'facter'
    assert collector.namespace == namespace.PrefixFactNamespace(namespace_name='facter',
                                                                prefix='facter_')
    assert collector.find_facter(module=None) is None


# Generated at 2022-06-23 00:18:37.699624
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_native

    facter_collector = get_collector_instance(namespace='facter',
                                              collectors=['facter'])

    if facter_collector.find_facter(fake_module):

        rc, out, err = facter_collector.run_facter(fake_module,
                                                   facter_collector.find_facter(fake_module))
        if rc == 0:
            try:
                facter_out = json.loads(out)
            except Exception:
                # FIXME: maybe raise a FactCollectorError with some info attrs?
                pass
            assert len(facter_out) > 0

# Generated at 2022-06-23 00:18:39.293435
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
  FacterFactCollector()

# Generated at 2022-06-23 00:18:50.966693
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    # We create a mock class of ansible.module_utils.basic
    class MockModuleUtilsBasic:
        # This method is called when you call run_command
        # of our mock object, it simply returns the value
        # of rc, out and err if they are defined or the
        # default value otherwise
        def run_command(self, command):
            if rc is not None:
                return rc, out, err
            else:
                return 0, None, None

        def get_bin_path(self, bin, opt_dirs=[]):
            return 'path/to/bin'

    # Test case where facter returns a fact
    module = MockModuleUtilsBasic()
    facter_path = 'path/to/bin'
    collector = FacterFactCollector()
    rc = 0

# Generated at 2022-06-23 00:18:56.510697
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert f.name == 'facter'
    assert f.fact_ids == set(['facter'])
    assert isinstance(f.namespace, PrefixFactNamespace)
    assert f.namespace.namespace_name == 'facter'
    assert f.namespace.prefix == 'facter_'
    assert f.collectors == []

# Generated at 2022-06-23 00:19:06.980311
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # unit testing class, so just importing as required
    module = 'ansible.module_utils.facts.collector.facter'
    module = __import__(module, fromlist=['FacterFactCollector'])

    facter = module.FacterFactCollector()
    facter_check = facter.find_facter('ansible.module_utils.facts.collector.facter')

    # facter and cfacter directory paths
    facter_dir = '/usr/bin/facter'
    cfacter_dir = '/opt/puppetlabs/bin/cfacter'

    assert facter_check is not None, "facter/cfacter is not installed"
    assert facter_check == facter_dir or facter_check == cfacter_dir, "facter/cfacter is not installed"

# Unit test

# Generated at 2022-06-23 00:19:16.894048
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import platform
    assert True == True

    # Since this test method is being run by python, it has no module,
    # and no access to ansible variables. We have to assume certain paths
    # are still the same even if python is different.
    facter_path = "/opt/puppetlabs/bin/facter"
    cfacter_path = "/opt/puppetlabs/bin/cfacter"

    # TODO: test cfacter output, it looks different.
    # ‘architecture’: ‘amd64’,
    # ‘cfacterversion’: ‘2.4.4’,
    # ‘hardwaremodel’: ‘x86_64’,
    # ‘kernel’: ‘linux’,
    # ‘kernelmajversion’:

# Generated at 2022-06-23 00:19:28.655786
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    import sys
    if sys.version_info[0] == 2:
        from mock import MagicMock
    else:
        from unittest.mock import MagicMock

    class MockedModule:
        def get_bin_path(self, _, opt_dirs=None):
            return "/usr/bin/facter"

        def __init__(self):
            self.run_command = MagicMock(return_value=(0, '{"a": "b"}', ""))

        def fail_json(self, msg):
            raise Exception(msg)

    module = MockedModule()

    fact_collector = FacterFactCollector(module=module)

    rc, out, err = fact_collector.run_facter(module, "/usr/bin/facter")

    assert rc == 0

# Generated at 2022-06-23 00:19:31.868037
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == "facter"
    assert ffc._fact_ids == {"facter"}
    assert ffc.find_facter == FacterFactCollector.find_facter


# Generated at 2022-06-23 00:19:42.387177
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import collector

    module = MockModule()

    module.run_command.return_value = (0, get_file_content('facter_stdout.json'), '')
    fact_collector = FacterFactCollector()

    facter_output = fact_collector.get_facter_output(module)
    module.run_command.assert_called_with('/usr/bin/facter  --puppet --json')
    assert get_file_content('facter_stdout.json') == facter_output

# Generated at 2022-06-23 00:19:48.588557
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    m = AnsibleModule(argument_spec={}, supports_check_mode=False)
    ff = FacterFactCollector(module=m)
    facter_dict = ff.get_facter_output(m)
    assert isinstance(facter_dict, string_types)
    facter_dict_2 = json.loads(facter_dict)
    assert isinstance(facter_dict_2, dict)



# Generated at 2022-06-23 00:19:50.422465
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    collector = FacterFactCollector()
    assert collector.find_facter is not None


# Generated at 2022-06-23 00:20:01.216205
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import FakeModule

    module = FakeModule()
    fact_collector = FacterFactCollector()

    # No out put when facter command fail
    module.run_command.return_value = 1, '{"test_facter": "test_facter"}', ''
    facter_facts = fact_collector.collect(module)
    assert {} == facter_facts

    module.run_command.return_value = 0, '{"test_facter": "test_facter"}', ''
    facter_facts = fact_collector.collect(module)
    assert 1 == len(facter_facts)
    assert 'facter_test_facter' in facter_facts
    assert 'test_facter' == facter_facts['facter_test_facter']

# Generated at 2022-06-23 00:20:08.125886
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """Check the method collect of class FacterFactCollector.

    The method collect of class FacterFactCollector must return a dict with
    facts when Facter is installed and it is possible to run it.

    """
    import os

    module = os.path.join(os.path.dirname(__file__), 'facter_test.py')

    # The fixtures in tests/fixtures/ansible_facts/ are only loaded
    # when the hostname of the machine running the test is
    # test-ansible-facts.sh. If it is another hostname, then the default
    # fixtures are used, which do not contain the facter_test.py. In
    # order to have the same behavior, we must force the hostname to
    # test-ansible-facts.sh.

# Generated at 2022-06-23 00:20:10.279773
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    fact = FacterFactCollector()
    if fact.find_facter is not None:
        assert fact.find_facter() is not None

# Generated at 2022-06-23 00:20:21.560931
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    import ansible.module_utils.facts.collectors

    # First, we need to create an instance of a AnsibleModule,
    # because we'll need to call methods of it (like get_bin_path)
    # In this test, we'll use a AnsibleModule defined in a Module
    # Utils' Facts Collection module:
    module = ansible.module_utils.facts.collectors.AnsibleModuleMock()

    # Now the instance of AnsibleModule is ready, so we can use it
    # in the constructor. We'll call the constructor with the
    # collector we want to test:

# Generated at 2022-06-23 00:20:30.616631
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import datetime
    import mock
    import os.path
    import stat
    import tempfile
    import time
    import textwrap
    import collections

    import ansible.module_utils.facts.collectors.facter as facter_module

    # Create a tmpfile with a date different from the date in the template
    # This is needed to be able to detect that some facts have been updated.
    # Facter facts have a timestamp, so a facter run with the same facts but
    # a different timestamp shall return different information. Different
    # timestamps have to be different enough to ensure that the file is
    # created after the template is modified.
    tmp_facts_file = tempfile.NamedTemporaryFile(prefix='ansible_test_facts_')
    tmp_facts_file_name = tmp_facts_file.name
    tmp

# Generated at 2022-06-23 00:20:36.637954
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/bin/facter'
    class MockFactCollector(FacterFactCollector):
        def __init__(self):
            pass
    f = MockFactCollector()
    assert(f.find_facter(MockModule()) == '/bin/facter')


# Generated at 2022-06-23 00:20:43.465546
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = MagicMock()
    _out = "---\nsome.fact: value\n"
    module.run_command.return_value = (0, _out, _out)
    facter_path = "/path/to/bin/facter"
    collector = FacterFactCollector()

    rc, out, err = collector.run_facter(module, facter_path)

    module.run_command.assert_called_with(facter_path + " --puppet --json")
    assert rc == 0
    assert out == _out
    assert err == _out

# Generated at 2022-06-23 00:20:49.495297
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Testing get_facter_output of FacterFactCollector
    mock_module = MockModule({
        'run_command': lambda *_: (0, '{"somekey": "somevalue"}', None)
    })
    collected_facts = {}

    fact_collector = FacterFactCollector()
    facter_dict = fact_collector.collect(collected_facts=collected_facts,
                                         module=mock_module)
    assert facter_dict["facter_somekey"] == "somevalue"



# Generated at 2022-06-23 00:20:53.899007
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = MockModule()
    facter_path = '/opt/puppetlabs/bin/cfacter'
    facter = FacterFactCollector(None, None)
    rc, out, err = facter.run_facter(module, facter_path)
    assert rc == 0
    assert out == json.dumps({'fact_one': 'one', 'fact_two': 'two'})
    assert err is None



# Generated at 2022-06-23 00:20:59.355556
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.name == 'facter'
    # FIXME: assert facter_fact_collector.fact_ids == set(['facter'])
    assert isinstance(facter_fact_collector.namespace, PrefixFactNamespace)

# Generated at 2022-06-23 00:21:06.753527
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import mock

    # Create a mock module object
    mock_module = mock.MagicMock()

    # Create an instance of the FacterFactCollector class
    facter_fact_collector = FacterFactCollector()

    # The facter_fact_collector class has an attribute called name
    # Set name attribute of facter_fact_collector instance to 'facter'
    facter_fact_collector.name = 'facter'

    # The _fact_ids set of facter_fact_collector instance contains 'facter'
    assert 'facter' in facter_fact_collector._fact_ids

    # Get the facter_fact_collector instance's method get_facter_output
    # Mock that method

# Generated at 2022-06-23 00:21:18.343974
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    m = mock.Mock()
    m.run_command = mock.Mock(return_value=(0, '{"facter_key": "facter_value"}', ''))

    c = FacterFactCollector()
    c.find_facter = mock.Mock(return_value="/bin/facter")
    c.run_facter = mock.Mock(return_value=(0, '{"facter_key": "facter_value"}', ''))

    f = c.collect(module=m)
    assert f == {"facter_key": "facter_value"}

    # Non-zero exit code
    m.run_command = mock.Mock(return_value=(1, "err", "err"))

    f = c.collect(module=m)
    assert f is None

# Generated at 2022-06-23 00:21:27.213278
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import sys
    import os

    sys.path.append(os.path.join(sys.path[0], os.path.pardir))
    from test.unit.module_utils.facts.test_common import AnsibleModuleMock

    module = AnsibleModuleMock()

    facter_fact_collector = FacterFactCollector()
    facter_facts = facter_fact_collector.collect(module=module)
    assert facter_facts is not None

    assert 'facter_kernel' in facter_facts
    assert 'facter_ipaddress' in facter_facts
    assert 'facter_os' in facter_facts

# Generated at 2022-06-23 00:21:28.117392
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    FacterFactCollector()


# Generated at 2022-06-23 00:21:35.835354
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    import os

    # create a temporary module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, command: (0, json.dumps({'ifconfig': 'foo'}), None),
        'get_bin_path': lambda self, cmd: os.path.join('/', 'tmp', 'facter')
    })

    collector = FacterFactCollector()
    rc, out, err = collector.run_facter(module, os.path.join('/', 'tmp', 'facter'))

    assert isinstance(rc, int)
    assert isinstance(out, basestring)
    assert isinstance(err, basestring) or err is None

    # TODO: assert rc, out, err


# Generated at 2022-06-23 00:21:40.868709
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert facter_collector.namespace == 'facter_'
    assert facter_collector._fact_ids == {'facter'}
    assert facter_collector.collectors is None

# Generated at 2022-06-23 00:21:51.401265
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    class TestModule(object):
        def get_bin_path(self, binary):
            # We know this is the right binary because we can find it on disk, in fact we fetched it earlier
            return "/tmp/ansible-facter-test-facter"

        def run_command(self, command):
            rc, out, err = 0, json.dumps({"foo": "bar", "baz": 12}), ""
            return rc, out, err

    ffc = FacterFactCollector()

    rc, out, err = ffc.run_facter(TestModule(), "/tmp/ansible-facter-test-facter")

    assert rc == 0
    assert out == json.dumps({"foo": "bar", "baz": 12})
    assert err == ""



# Generated at 2022-06-23 00:22:03.042064
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import pytest

    class MockModule(object):
        def __init__(self, bin_path_return, facts_output):
            self.bin_path_return = bin_path_return
            self.facts_output = facts_output

        def get_bin_path(self, _, opt_dirs=None):
            return self.bin_path_return

        def run_command(self, command):
            return 0, self.facts_output, None

    # If facter is not installed then we should get an empty json
    mock_module = MockModule(bin_path_return=None, facts_output='')
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.collect(module=mock_module) == {}

    # If facter is installed but there is no

# Generated at 2022-06-23 00:22:13.718671
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class DummyModule:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            elif name == 'facter' and opt_dirs and opt_dirs[0] == '/opt/puppetlabs/bin':
                return '/opt/puppetlabs/bin/facter'
            elif name == 'facter':
                return '/opt/bin/facter'
            return None

    m = DummyModule()
    assert FacterFactCollector().find_facter(m) == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-23 00:22:22.641537
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def get_bin_path(self, cmd, opt_dirs=None):
            return "/usr/bin/facter"

        def run_command(self, args):
            return 0, '{"operatingsystem": "Ubuntu", "domain": "", "fqdn": "test"}', ""

    module = MockModule()
    collector = FacterFactCollector()
    facter_output = collector.get_facter_output(module)
    assert facter_output == '{"operatingsystem": "Ubuntu", "domain": "", "fqdn": "test"}'

# Generated at 2022-06-23 00:22:33.742550
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    try:
        from ansible import module_utils
        from ansible.module_utils.facts.virtual.base import BaseVirtual
    except ImportError:
        return

    module = BaseVirtual('facts_d', '', '')
    module.run_command = mock_run_command()

    facter_output_value = '{"uptime": {"days": 3, "hours": 4, "seconds": 37, "uptime": "3 days", "seconds_with_frac": 3.5069444444444444e+06, "uptime_hours": 76, "hours_with_frac": 76, "uptime_days": 3}, "virtual": "physical"}'


# Generated at 2022-06-23 00:22:40.137617
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # test without path
    module = MagicMock()
    module.get_bin_path.return_value = None
    facter_collector = FacterFactCollector()
    assert(facter_collector.find_facter(module) is None)

    # test with path
    module.get_bin_path.return_value = 'facter'
    assert(facter_collector.find_facter(module) == 'facter')


# Generated at 2022-06-23 00:22:50.835963
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import sys
    import os
    import tempfile
    import shutil

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import which

    # Note that this mirrors previous facter behavior, where there isnt
    # a 'ansible_facter' key in the main fact dict, but instead, 'facter_whatever'
    # items are added to the main dict.

    # TODO: mock module run_command

    p = sys.version_info
    if p[0] != 2:  # skip Python 3
        return True

    if os.getuid() != 0:  # skip if not root
        return True

    print('INFO: test_FacterFactCollector_run_facter')

    # FacterFactCollector uses PrefixFactNamespace

# Generated at 2022-06-23 00:22:55.914190
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module(object):
        def get_bin_path(self, _, opt_dirs=None):
            return '/bin/facter'

        def run_command(self, command):
            return 0, '{"a":"b","c":"d"}', ''

    c = FacterFactCollector()
    assert '/bin/facter' == c.find_facter(Module())

# Generated at 2022-06-23 00:23:05.995136
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils
    from ansible.module_utils.facts import collector

    # mock the module to use
    module = ansible.module_utils.basic.AnsibleModule(
    )

    # stub get_bin_path for puppet, facter and cfacter
    module.get_bin_path = lambda name, **kwargs: {
        'puppet': '/usr/bin/puppet',
        'facter': '/usr/bin/facter',
        'cfacter': '/usr/bin/cfacter'
    }.get(name, '')

    # init facter Collector and call find_facter
    c = collector.FacterFactCollector()
    assert '/usr/bin/cfacter' == c.find_facter(module)

# Generated at 2022-06-23 00:23:07.902389
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    instance = FacterFactCollector()
    assert isinstance(instance, FacterFactCollector)

# Generated at 2022-06-23 00:23:17.719493
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_all_collector_instances

    collector = get_collector_instance('facter')
    facter_path = collector.find_facter(None)
    rc, out, err = collector.run_facter(None, facter_path)
    assert rc == 0

    collectors = get_all_collector_instances()
    for collector in collectors:
        if collector.name == 'facter':
            facter_path = collector.find_facter(None)
            rc, out, err = collector.run_facter(None, facter_path)
            assert rc == 0



# Generated at 2022-06-23 00:23:27.912471
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def __init__(self):
            self.run_command_params = dict()

        def get_bin_path(self, executable, opt_dirs=None):
            if executable == "facter":
                return '../../facter/spec/fixtures/facter_mock_bin'
            if executable == "cfacter":
                return '../../facter/spec/fixtures/cfacter_mock_bin'
            return None

        def run_command(self, command):
            self.run_command_params = dict(command=command)
            return 0, "", ""

    module = MockModule()

    facter = FacterFactCollector()

    facter_data = facter.get_facter_output(module)

# Generated at 2022-06-23 00:23:29.500499
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert 'facter' == ffc.name


# Generated at 2022-06-23 00:23:37.351080
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    # Test if find_facter can not find facter
    facter_path = FacterFactCollector().find_facter(module=None)
    assert facter_path is None

    # Test if find_facter can find facter
    facter_path = FacterFactCollector().find_facter(module=MockModule())
    assert facter_path == '/bin/facter'

    # Test if find_facter can find facter in opt_dirs
    facter_path = FacterFactCollector().find_facter(module=MockModule(extra_bin_path=['/opt/puppetlabs/bin']))
    assert facter_path == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-23 00:23:40.568345
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter = FacterFactCollector();
    assert facter.name == "facter"
    assert facter._fact_ids == set(['facter'])


# Generated at 2022-06-23 00:23:45.959340
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    fact_collector = FacterFactCollector()
    assert fact_collector.name == 'facter'
    assert fact_collector._fact_ids == {'facter'}

    assert isinstance(fact_collector._namespace, PrefixFactNamespace)
    assert fact_collector._namespace._namespace_name == 'facter'
    assert fact_collector._namespace.prefix == 'facter_'

# Generated at 2022-06-23 00:23:46.748192
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    pass

# Generated at 2022-06-23 00:23:50.685739
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    test_namespace = 'facter'
    test_prefix = 'facter_'
    collector = FacterFactCollector(namespace=test_namespace, prefix=test_prefix)
    assert collector.name == 'facter'
    assert test_prefix in collector.namespace.prefix
    assert test_namespace in collector.namespace._namespace_name

# Generated at 2022-06-23 00:23:51.541766
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # TODO
    assert False

# Generated at 2022-06-23 00:24:03.862743
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_namespace

    facts_collector = FacterFactCollector(namespace=get_collector_namespace())
    class MockModule:
        def get_bin_path(self, foo, opt_dirs):
            return "/bin/facter"
        def run_command(self, foo):
            return 0, json.dumps(dict(architecture="x86_64")), ""
    module = MockModule()
    facter_output = facts_collector.get_facter_output(module)
    assert facter_output == '{"architecture": "x86_64"}'

    class AnotherMockModule:
        def get_bin_path(self, foo, opt_dirs):
            return None

# Generated at 2022-06-23 00:24:07.968152
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facts = FacterFactCollector()
    assert isinstance(facts, FacterFactCollector)
    assert isinstance(facts.namespace, PrefixFactNamespace)
    assert facts.namespace.prefix == 'facter_'
    assert facts.namespace.namespace_name == 'facter'

# Generated at 2022-06-23 00:24:19.952862
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts

    module = ansible_facts.AnsibleFactsModule(
        argument_spec = dict(ansible_facts=dict(type='bool'))
    )

    # Run facter and convert output JSON to a dict
    facter_dict = FacterFactCollector().collect(module=module)
    assert 'facter' in facter_dict
    assert isinstance(facter_dict['facter'], dict)

    # If facter is not installed, the facter dict should be empty
    # If FacterFactCollector().get_facter_output returns None,
    # then the facter dict should be empty.
    FacterFactCollector().get_facter_output = lambda self, module: None

# Generated at 2022-06-23 00:24:22.263044
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ffc = FacterFactCollector()
    assert ffc.find_facter(None) is None

# Generated at 2022-06-23 00:24:23.680964
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    # NOTE: cannot test this module as we rely on ruby-json being installed
    pass

# Generated at 2022-06-23 00:24:35.195833
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module_mock = MockModule()
    facter_path = 'facter_path'

    def call_run_facter(module):
        # Get a FacterFactCollector instance without any collectors to avoid
        # recursive calls
        facter_collector = FacterFactCollector(collectors=[])
        return facter_collector.run_facter(module, facter_path)

    def call_run_facter_missing_facter():
        # Get a FacterFactCollector instance without any collectors to avoid
        # recursive calls
        facter_collector = FacterFactCollector(collectors=[])
        return facter_collector.run_facter(module_mock, None)

    # The facter_path is missing
    rc, out, err = call_run_facter_missing_facter()

# Generated at 2022-06-23 00:24:45.844892
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """Unit test for method collect of class FacterFactCollector"""

    # define a mock module
    class MockModule(object):
        def __init__(self, module_name='dummy', result_dict=None):
            self._module_name = module_name
            self._result_dict = result_dict

        def get_bin_path(self, executable, opt_dirs=None):
            return "/usr/bin/{}".format(executable)

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"key":"value"}', ''
            else:
                return 0, '', ''

    # create a FacterFactCollector object
    ffc = FacterFactCollector()

    # create mock module
    mm = MockModule()

# Generated at 2022-06-23 00:24:49.162702
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    f = FacterFactCollector()
    assert f.find_facter({'get_bin_path': lambda a, b: 'bin_path'}) == 'bin_path'

# Generated at 2022-06-23 00:24:52.160576
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert facter_collector._fact_ids == {'facter'}

# Generated at 2022-06-23 00:25:03.206648
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.utils.module_docs import get_docstring

    mod_name = 'facter'
    mod_path = 'ansible.module_utils.facts.facter'
    # Obtain the module (it will be alter during test)
    module = get_docstring(mod_name, mod_path, verbose=False)

    # Initialize a class FacterFactCollector
    facter = FacterFactCollector(module)

    # Check the case when facter_path is None
    facter_path = None
    rc, out, err = facter.run_facter(module, facter_path)
    assert rc is None and out is None and err is None

    # Check the case when facter_path is not "/bin/facter"
    facter_path = '/bin/facter'
    rc

# Generated at 2022-06-23 00:25:04.573783
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    bfc = FacterFactCollector()
    assert bfc

# Generated at 2022-06-23 00:25:16.053396
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import tempfile
    import os
    import os.path
    import sys
    import json

    # For Python 2.6
    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        import unittest2 as unittest
    else:
        import unittest

    class RunFacterTestCase(unittest.TestCase):

        def setUp(self):
            # Create a temp directory and facter script
            self.tmpDir = tempfile.mkdtemp()

            facterScript = os.path.join(self.tmpDir, 'facter')
            facterScriptContents = '#!/bin/sh\n'

# Generated at 2022-06-23 00:25:26.804050
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Create a mock module
    mock_module = MockModule()
    mock_module.params = {"test_arg1": "test_arg1_value"}

    # Set up the path to the facter fact collector
    facter_path = "/opt/puppetlabs/bin/facter"

    # Set up the expected return values for the mock call to run_command
    expected_rc = 0
    expected_out = '{"test_fact": "test_value"}'
    expected_err = ''

    # Create the facter fact collector
    facter_fact_collector = FacterFactCollector()

    # Mock the method call to run_command, returning the values set up for expected_rc, expected_out, and expected_err

# Generated at 2022-06-23 00:25:36.879520
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import json
    import tempfile

    facts_dict = dict(ansible_facts={'facter_operatingsystem': 'Darwin', 'facter_osfamily': 'Darwin'})

    facter = FacterFactCollector()

    # test standard case
    with tempfile.NamedTemporaryFile() as facter_json:
        facter_json.write(json.dumps(facts_dict['ansible_facts']))
        facter_json.flush()
        assert facter.run_facter(None, '/does/not/exist') == (256, '', '')
        assert facter.run_facter(None, facter_json.name) == (0, json.dumps(facts_dict['ansible_facts']), '')
        assert facter.collect() == facter.collect() == facts

# Generated at 2022-06-23 00:25:38.230731
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    collector = FacterFactCollector()
    assert collector.collect() == {}

# Generated at 2022-06-23 00:25:49.134271
# Unit test for constructor of class FacterFactCollector

# Generated at 2022-06-23 00:25:52.184675
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import collector

    facts = collector.collect(['facter'], module=None)

    assert 'facter_domain' in facts
    assert 'facter_architecture' in facts


# Generated at 2022-06-23 00:25:54.047247
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts.collector import Namespace
    fact_collector = FacterFactCollector(namespace=Namespace)
    assert fact_collector.name == 'facter'

# Generated at 2022-06-23 00:26:05.203122
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # EMPTY STATE!!!
    # This is not strictly necessary, as this is a unit test for the run_facter method. However, we
    # are forced to mock up the MOCK_MODULE return values for get_bin_path and run_command.
    # It's nothing that would EVER run in a production context anyway.
    FacterFactCollector.find_facter = lambda self, module: module.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
    FacterFactCollector.run_facter = lambda self, module, facter_path: module.run_command(facter_path + " --puppet --json")

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    module = PrefixFactNamespace()

# Generated at 2022-06-23 00:26:07.828927
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    fact = FacterFactCollector()
    # return facter info
    my_dict = {"facter":{"operatingsystem":"CentOS","os":{"family":"RedHat","name":"CentOS","release":{"full":"7.6.1810","major":"7","minor":"6"}},"osfamily":"RedHat","virtual":"physical"}}
    assert fact.collect() == my_dict

# Generated at 2022-06-23 00:26:12.848210
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic


# Generated at 2022-06-23 00:26:20.491998
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert isinstance(f, FacterFactCollector)
    assert hasattr(f, 'name')
    assert hasattr(f, '_fact_ids')
    assert hasattr(f, 'collector')
    assert hasattr(f, 'collectors')
    assert hasattr(f, 'namespace')
    assert isinstance(f.namespace, PrefixFactNamespace)
    assert hasattr(f.namespace, '_prefix')
    assert f.namespace._prefix == 'facter_'

# Generated at 2022-06-23 00:26:31.631913
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.utils import AnsibleModuleMock
    from ansible.module_utils.facts.utils import AnsibleModuleMockSync
    from ansible.module_utils.facts.utils import ModuleTestCase
    import sys

    try:
        import json
    except ImportError:
        import simplejson as json
    import os.path
    import subprocess

    class MockAnsibleModule(AnsibleModuleMock):

        def get_bin_path(self, executable, opt_dirs=[]):
            return executable

        def run_command(self, cmd):
            args = cmd.split()[1:]
            if args[0] == '--puppet' and args[1] == '--json':
                if sys.version_info[0:2] <= (2, 6):
                    return 0

# Generated at 2022-06-23 00:26:38.346693
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    test_mod_params = {'run_command': {'rc': 0,
                                       'out': '{"foo":"bar"}\n',
                                       'err': ''}}
    test_mod = FakeAnsibleModule(**test_mod_params)
    test_collector = FacterFactCollector()
    test_facts = test_collector.collect(module=test_mod)
    assert test_facts == {'facter_foo': 'bar'}


# Generated at 2022-06-23 00:26:49.194104
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    mod = MockModule(paths={'/opt/puppetlabs/bin/cfacter': None})
    mod.get_bin_path = mod.paths.get
    mod.paths['/opt/puppetlabs/bin/facter'] = '/opt/puppetlabs/bin/facter'
    facter_path = FacterFactCollector().find_facter(mod)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'

    mod = MockModule(paths={'/opt/puppetlabs/bin/facter': None,
                            '/opt/puppetlabs/bin/cfacter': None})
    mod.get_bin_path = mod.paths.get
    facter_path = FacterFactCollector().find_facter(mod)
    assert facter