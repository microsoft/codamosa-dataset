

# Generated at 2022-06-23 00:16:52.764767
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    obj = FacterFactCollector()
    assert type(obj.name) == str
    assert obj.name == 'facter'

    assert type(obj.namespace) == PrefixFactNamespace
    assert obj.namespace.prefix == 'facter_'
    assert obj.namespace.namespace_name == 'facter'

    assert type(obj.collectors) == list
    assert len(obj.collectors) == 0

    assert type(obj._fact_ids) == set
    assert list(obj._fact_ids) == ['facter']

# Generated at 2022-06-23 00:17:03.931085
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import module_utils.facts.collector.facter

    ffc = module_utils.facts.collector.facter.FacterFactCollector()
    
    class mo:
        def get_bin_path(self, bin_name, opt_dirs=[]):
            if bin_name == "facter":
                return "/opt/puppetlabs/puppet/bin/facter"
            if bin_name == "cfacter":
                return "/opt/puppetlabs/puppet/bin/cfacter"
            return None

    module = mo()
    
    fcp = "/opt/puppetlabs/puppet/bin/facter"
    fcp2 = "/opt/puppetlabs/puppet/bin/cfacter"

# Generated at 2022-06-23 00:17:06.572400
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    from ansible.module_utils.facts.collector import ModuleStub

    m = ModuleStub()

    f = FacterFactCollector()
    assert f.get_facter_output(m) is not None

# Generated at 2022-06-23 00:17:11.098758
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"fact":"42"}', ''

    module = Module()
    collector = FacterFactCollector()

    assert collector.get_facter_output(module) == '{"fact":"42"}'

# Generated at 2022-06-23 00:17:19.968060
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = '/usr/bin/facter'

    fact_collector = FacterFactCollector(namespace=None)

    facter_path = fact_collector.find_facter(mock_module)

    assert facter_path == '/usr/bin/facter'
    mock_module.get_bin_path.assert_called_once_with('cfacter', opt_dirs=['/opt/puppetlabs/bin'])


# Generated at 2022-06-23 00:17:25.465310
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    result = None
    class MockFacterFactCollector(FacterFactCollector):
        def run_facter(self, module, facter_path):
            nonlocal result
            result = (module, facter_path)
            return (0, 'test_out', 'test_err')
    MockFacterFactCollector().run_facter(1, 2)
    assert result == (1, 2)

# Generated at 2022-06-23 00:17:31.506271
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Since the method returns a string, the return value can only be
    # compared to a string
    collector = FacterFactCollector(namespace=None)
    module = object()
    module.get_bin_path = lambda x: x + '_bin_path'
    assert collector.find_facter(module) == 'cfacter_bin_path'


# Generated at 2022-06-23 00:17:39.571701
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector.facter import FacterFactCollector

    module = MockModule()

    facter_path = MockPath('/usr/bin/facter')
    module.get_bin_path.return_value = facter_path

    module.run_command.return_value = (0, '{"facter_foo":"bar"}', '')

    assert FacterFactCollector().run_facter(module, facter_path) == (0, '{"facter_foo":"bar"}', '')


# Generated at 2022-06-23 00:17:47.226163
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleBase

    class FakeModule(ModuleBase):
        def get_bin_path(self, app, opt_dirs=None):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"a": "b"}', ''
    module = FakeModule()
    facter_collector = get_collector_instance('facter')
    facterDict = facter_collector.get_facter_output(module)
    assert(facterDict == '{"a": "b"}')

    class FakeModule1(FakeModule):
        def run_command(self, cmd):
            raise Exception("run_command failed!")
    module1

# Generated at 2022-06-23 00:17:57.949868
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Create a temporary module to use.
    import tempfile
    fp, fd = tempfile.mkstemp()
    fp = open(fp, 'w')
    fp.write("#! /bin/sh\n")
    fp.write('''
if [ "$1" = "--puppet" ]; then
    echo "2"
fi
if [ "$2" = "--json" ]; then
    echo '{ "fact": "test" }'
fi
''')
    fp.close()
    import shutil
    import os
    import ansible
    from ansible.compat.six.moves import StringIO

    class ModuleTest:
        def __init__(self):
            self.path = {}
            self.params = {}
            self.ansible_version = ansible.__version

# Generated at 2022-06-23 00:18:04.516371
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = mock.Mock()

    module.get_bin_path.return_value = 'cfacter'
    assert FacterFactCollector().find_facter(module) == 'cfacter'

    module.get_bin_path.return_value = None
    module.get_bin_path.return_value = 'facter'
    assert FacterFactCollector().find_facter(module) == 'facter'

    module.get_bin_path.return_value = None
    assert FacterFactCollector().find_facter(module) is None


# Generated at 2022-06-23 00:18:09.805842
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    """
    Test method get_facter_output of class FacterFactCollector by mocking the
    module and allowing it to return a different path for facter binary
    """
    class Module():
        def __init__(self):
            self.rc = 0
            self.out = ""
            self.err = ""

        def run_command(self, command):
            if "facter" in command:
                self.out = '{"testing":"JSON"}'
            return self.rc, self.out, self.err

        def get_bin_path(self, command, opt_dirs=None):
            if command == "facter":
                return "/path/to/facter"
            else:
                return None

    test_module = Module()

    test_collector = FacterFactCollector()
    # get the output of

# Generated at 2022-06-23 00:18:14.162605
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Build a ModuleStub to avoid executing real code.
    class ModuleStub(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_output = '{"a":"b"}'
            self.run_command_error = ''

        def run_command(self, cmd):
            return (self.run_command_rc, self.run_command_output, self.run_command_error)

        def get_bin_path(self, arg, opt_dirs=None):
            return '/fake/facter'

    def assert_facter_dict(facter_dict, expected_facter_dict):
        assert facter_dict == expected_facter_dict

    # Test facter execution ok
    # Test facter_path ok (command exists)

# Generated at 2022-06-23 00:18:16.859182
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    obj = FacterFactCollector()
    assert obj.name == 'facter'
    assert obj.namespace.name == 'facter'
    assert obj.namespace.prefix == 'facter_'



# Generated at 2022-06-23 00:18:27.953002
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    collected_facts = {}
    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.facts = collected_facts

        def run_command(self, cmd, ignore_rc=False):
            return 0, "{\"virtual\":\"xenpv\"}", ""

        def get_bin_path(self, name, opt_dirs=[]):
            return "/usr/bin/" + name

    module_mock = ModuleMock()

    ff = FacterFactCollector()
    ff.collect(module_mock)

    assert(collected_facts is not None)
    assert("facter_virtual" in collected_facts)
    assert("facter_virtual" in collected_facts)
    assert(collected_facts["facter_virtual"] == "xenpv")

# Generated at 2022-06-23 00:18:35.732327
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collectors

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    fact_collector = collectors.get_collector('FacterFactCollector')
    fact_collector._collectors = []
    fact_collector._namespace = None

    def find_facter(module):
        return '/path/to/facter'

    def run_facter(module, facter_path):
        return 0, '{"test": ["foo", "bar"]}', ''

    fact_collector.find_facter = find_facter
    fact_collector.run_facter = run_facter

    fact_collector.collect(module=module)

    assert module

# Generated at 2022-06-23 00:18:47.915587
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import collections
    import sys

    import pytest
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    from ansible.module_utils.facts.collector import module_precedence

    # Required for mock_module
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_url_content
    from ansible.module_utils.facts.utils import is_executable

    # mock_module is required for mocking 'ansible.module_utils.facts.utils.module_precedence'
    # Importing this module (ansible.module_utils.facts.collector) causes the execution of


# Generated at 2022-06-23 00:18:58.096302
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    import sys

    if sys.version_info[0] > 2:
        basestring_type = str
    else:
        basestring_type = basestring

    from ansible.module_utils.facts.collector import BaseFactCollector

    # Python 2.6 does not have the unittest.mock module
    try:
        from unittest.mock import patch, Mock, MagicMock
    except ImportError:
        from mock import patch, Mock, MagicMock

    with patch.object(FacterFactCollector, 'find_facter', return_value=None):
        ff = FacterFactCollector()
        facter_output = ff.get_facter_output(module=None)
        assert facter_output is None


# Generated at 2022-06-23 00:19:06.898157
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeAnsibleModule(object):
        def get_bin_path(self, *args):
            return '/path/to/facter'

        def run_command(self, *args):
            return 0, json.dumps({'test_fact': 'test_fact_value'}), ''

    fake_module = FakeAnsibleModule()
    fact_collector = FacterFactCollector(namespace=None)
    facter_output = fact_collector.get_facter_output(fake_module)
    assert facter_output == json.dumps({'test_fact': 'test_fact_value'})

# Generated at 2022-06-23 00:19:08.878017
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    assert FacterFactCollector.get_facter_output(None) is None



# Generated at 2022-06-23 00:19:18.239684
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Because class AnsibleModule is a mock object,
    # I cannot use a simple class definition.
    # Also, I cannot do unit test of class AnsibleModule
    # because of circular reference.
    class AnsibleModule:
        def get_bin_path(self, *args, **kwargs):
            return None

    # create instance of FacterFactCollector
    ffc = FacterFactCollector()

    # test correct path
    am = AnsibleModule()
    am.get_bin_path = lambda *args, **kwargs: '/usr/bin/facter'
    facter_path = ffc.find_facter(am)
    assert facter_path == '/usr/bin/facter'

    # test wrong path

# Generated at 2022-06-23 00:19:25.001273
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, path: (0, '{"testkey":"testval1"}', ''),
        'get_bin_path': lambda self, name, opt_dirs: 'testbinpath',
    })()
    facter_dict = FacterFactCollector().get_facter_output(module)
    assert facter_dict['testkey'] == 'testval1'


# Generated at 2022-06-23 00:19:32.576601
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class TestModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name not in ['facter', 'cfacter']:
                return None
            return '/opt/puppetlabs/bin/{}'.format(name)

    module = TestModule()
    collector = FacterFactCollector(collectors=None, namespace=None)

    facter_path = collector.find_facter(module)

    assert facter_path == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-23 00:19:44.324732
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.test_utils.test_module import MockModule
    from ansible.module_utils.facts.test_utils.test_module import MockCommand
    import json
    import ansible_mock

    # Testing the case in which there is no facter installation
    m = MockModule()
    m.get_bin_path.return_value = None

    ffc = FacterFactCollector()
    facter_output = ffc.get_facter_output(m)

    m.get_bin_path.assert_called_once_with('facter', opt_dirs=['/opt/puppetlabs/bin'])
    assert facter_output == None

    # Testing the case in which facter is installed but facter --json fails
    m.get_bin_path.side_effect

# Generated at 2022-06-23 00:19:55.449953
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ansible_collections

    module = ansible_collections.ansible.community.tests.unit.compat.unittest.mock.MagicMock()

# Generated at 2022-06-23 00:20:04.701659
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import tempfile

    fd, path = tempfile.mkstemp(prefix="facter_test_")
    f = os.fdopen(fd, 'w')
    f.write('#!/bin/sh\necho -n "{\"a\": [1, 2], \"b\": {\"c\": 3, \"d\": \"4\"}}"')
    f.close()
    os.chmod(path, stat.S_IREAD | stat.S_IWRITE | stat.S_IEXEC)

    m = AnsibleModule(argument_spec = dict())
    m.params = {'path' : path }

    # Run the method which is tested here
    (rc, out, err) = FacterFactCollector().run_facter(m, path)

    # Remove temporary file
    os.remove(path)

   

# Generated at 2022-06-23 00:20:06.185524
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    collector = FacterFactCollector()
    assert collector.name == 'facter'
    assert collector

# Generated at 2022-06-23 00:20:16.450971
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, '{"ansible": "facts"}', '')

    facter_collector = FacterFactCollector()
    rc, out, err = facter_collector.run_facter(module, facter_collector.find_facter(module))
    assert rc == 0
    assert err == ''
    assert json.loads(out) == {"ansible": "facts"}

    module.run_command = lambda *args, **kwargs: (1, '', 'facter failed')

    facter_collector = FacterFactCollector()
    rc, out, err = facter_collector

# Generated at 2022-06-23 00:20:23.192344
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_path = 'facter'
    mock_module = MockModule()
    facter_collector = FacterFactCollector(collectors=None, namespace=None)
    mock_module.get_bin_path.return_value = facter_path
    facter_collector.run_facter(mock_module, facter_path)
    mock_module.run_command.assert_called_once_with(facter_path + " --puppet --json")

# Generated at 2022-06-23 00:20:31.263572
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils import basic

    module_io = StringIO()
    basic._ANSIBLE_ARGS = None
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        add_file_common_args=True
    )
    fc = FacterFactCollector()

    def mock_run_facter(module, facter_path):
        facter_output_path = 'test/units/module_utils/facts/facter_output_mocked_data.txt'
        facter_output = get_file_lines(facter_output_path)

# Generated at 2022-06-23 00:20:41.549732
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content

    # Load the facts from the collection
    test_file = 'test/unit/module_utils/facts/test_FacterFactCollector_run_facter.json'
    collected_facts = json.loads(get_file_content(test_file))

    # Expected path of cfacter
    cfacter_path = '/opt/puppetlabs/bin/cfacter'

    # Expected path of facter
    facter_path = '/opt/puppetlabs/bin/facter'

    # Expected cfacter output

# Generated at 2022-06-23 00:20:52.468444
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.filesystem import FileSystemCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import pdb
    import tempfile

    fd, temp_file = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-23 00:21:02.834693
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.platform.facter import FacterFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    facter_collector = FacterFactCollector(namespace=PrefixFactNamespace(namespace_name='facter', prefix='facter_'))
    facter_path = facter_collector.find_facter(module)
    # Set ansible_facter_valid fact to True if facter is installed
    if facter_path is not None:
        rc, out, err = facter_collector.run_facter(module, facter_path)


# Generated at 2022-06-23 00:21:13.540463
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import collector

    from ansible.module_utils.facts.system.facter import FacterFactCollector

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.facter

    class MockModule:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        class MockRunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def run_command(self, cmd):
                return self.rc, self.out, self.err

        run_command

# Generated at 2022-06-23 00:21:20.802098
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert facter_collector._fact_ids == {'facter'}
    assert facter_collector.namespace.__class__.__name__ == "PrefixFactNamespace"
    assert facter_collector.namespace.namespace_name == 'facter'
    assert facter_collector.namespace.prefix == 'facter_'


# Generated at 2022-06-23 00:21:24.304546
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()

    assert ffc.name == 'facter'
    assert len(ffc._fact_ids) == 1
    assert 'facter' in ffc._fact_ids



# Generated at 2022-06-23 00:21:28.490452
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    namespace = PrefixFactNamespace(namespace_name='facter', prefix='facter_')
    assert isinstance(ffc, BaseFactCollector)
    assert ffc.name == 'facter'
    assert ffc.namespace == namespace


# Generated at 2022-06-23 00:21:36.311570
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_path = "/opt/puppetlabs/bin/facter"

# Generated at 2022-06-23 00:21:47.798641
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector.legacy import DummyModule

    ffc = FacterFactCollector()

    facter_path, cfacter_path = '/usr/bin/facter', '/usr/bin/cfacter'
    module = DummyModule(facter_path=facter_path, cfacter_path=cfacter_path)
    assert ffc.find_facter(module) == cfacter_path

    cfacter_path = None
    module = DummyModule(facter_path=facter_path, cfacter_path=cfacter_path)
    assert ffc.find_facter(module) == facter_path

    facter_path = None
    module = DummyModule(facter_path=facter_path, cfacter_path=cfacter_path)
    assert f

# Generated at 2022-06-23 00:21:58.770704
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector.sysconfig import SysconfigFactCollector
    from ansible.module_utils.facts.collector.systemd import SystemdFactCollector
    from ansible.module_utils.facts.collector.pkg_resources import PkgResourcesFactCollector

    # Create some fake data for the following collectors.
    collected_facts = {
        'pkg_resources': {},
        'systemd': {},
        'sysconfig': {},
    }

    # Create the collectors in this order to make sure the FacterFactCollector
    # is created last.
    collectors = [
        SysconfigFactCollector(),
        SystemdFactCollector(),
        PkgResourcesFactCollector(),
    ]


# Generated at 2022-06-23 00:22:09.507333
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    import ansible.module_utils.facts.collector

    # Simulate module object
    class ModuleStub:
        def __init__(self, bin_path_result):
            self.bin_path_result = bin_path_result

        def get_bin_path(self, executable, opt_dirs=[]):
            return self.bin_path_result

        def run_command(self, cmd):
            if cmd == "facter --json":
                rc = 0
            else:
                rc = 1


# Generated at 2022-06-23 00:22:20.972063
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.six import PY3 as py3
    from ansible.module_utils.six import StringIO

    class FakeModule(object):
        def __init__(self):
            self.mock = None

        def get_bin_path(self, *args, **kwargs):
            if self.mock:
                return self.mock
            else:
                return '/usr/bin/facter'

    def create_fake_file(name, path, content=b"", mode=0o444):
        FakeFile = type('FakeFile', (object,), {})
        fakefile = FakeFile()
        fakefile.name = name
        fakefile.path = path
        fakefile.content = content
        fakefile.mode = mode
        return fakefile


# Generated at 2022-06-23 00:22:29.298504
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    module = ansible.module_utils.facts.collector
    c = FacterFactCollector(collectors=[], namespace=None)
    assert isinstance(c, FacterFactCollector)

    class module:
        def get_bin_path(self, a, opt_dirs=[]):
            return 'ls'
        def run_command(self, a):
            return 0, "cmd stdout", "cmd stderr"
    assert c.get_facter_output(module) == "cmd stdout"

# Generated at 2022-06-23 00:22:31.709705
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == 'facter'
    assert ffc._fact_ids == set(['facter'])

# Generated at 2022-06-23 00:22:42.908039
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import mock
    import __builtin__

    # Mock module
    mock_module = mock.Mock()
    old_import = __builtin__.__import__

    # Mock a default return value of None and a json.loads raise
    try:
        __builtin__.__import__ = mock.Mock(return_value=None)
        json.loads = mock.Mock(side_effect=Exception)
        facter_dict = FacterFactCollector().collect(mock_module)
        assert facter_dict == {}
    finally:
        __builtin__.__import__ = old_import

    # Mock a valid return

# Generated at 2022-06-23 00:22:44.802750
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    c = FacterFactCollector()
    assert c.name == 'facter'


# Generated at 2022-06-23 00:22:55.438933
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    class FakeModule:
        def __init__(self, module_name, bin_path):
            self.__dict__ = module_name['ansible_facts']
            self.bin_path = bin_path

        def get_bin_path(self, command, opt_dirs=[]):
            return self.bin_path


# Generated at 2022-06-23 00:22:59.137945
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO: Mock out the module and run_command

    collector = FacterFactCollector()
    output = collector.get_facter_output(None)
    assert output is None

    # We aren't testing the rest of the FacterFactCollector here

# Generated at 2022-06-23 00:23:09.233084
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import os
    import tempfile
    import textwrap

    class MyException(Exception):
        pass

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.fail_json_calls = 0
            self.bin_path_results = {}
            self.run_command_results = {}

        def get_bin_path(self, binary, opt_dirs=None):
            if binary in self.bin_path_results:
                return self.bin_path_results[binary]
            else:
                return None

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls += 1
            if cmd in self.run_command_results:
                return self.run_command_results[cmd]

# Generated at 2022-06-23 00:23:19.370809
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
  from ansible.module_utils.facts.collector import ModuleUtilsModule
  import sys

  ffc = FacterFactCollector(None, None)
  class FakeModule:
    def get_bin_path(self, path, opt_dirs=[]):
      if path == 'facter':
        return '/usr/bin/facter'
      elif path == 'cfacter':
        if sys.version_info[0] == 2:
          return unicode('/usr/bin/cfacter')
        else:
          return '/usr/bin/cfacter'
      raise Exception("Unknown path requested in test")

  fake_module1 = FakeModule()
  facter_path = ffc.find_facter(fake_module1)
  assert facter_path == '/usr/bin/cfacter'


# Generated at 2022-06-23 00:23:29.822787
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import tempfile
    from ansible.module_utils.facts.collector import AnsibleModuleStub

    facter_json = '{"facter_fact_2": "facter_fact_2", "facter_fact_1": "facter_fact_1", "facter_fact_0": "facter_fact_0"}'

    class FakeModule(AnsibleModuleStub):
        def __init__(self):
            self._facter_bin = self.write_facter_bin(facter_json)
            self.mock_bin_path = self.mock_bin_path_for_facter(self._facter_bin)

        def write_facter_bin(self, facter_json):
            fake_facter_bin = tempfile.NamedTemporaryFile()
            fake_facter

# Generated at 2022-06-23 00:23:37.562921
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    fact_collector = FacterFactCollector()
    fact_collector.find_facter = mock.MagicMock()
    fact_collector.find_facter.return_value = None
    fact_collector.get_facter_output(module=None)

    fact_collector.find_facter.return_value = '/usr/bin/facter'
    fact_collector.run_facter = mock.MagicMock()
    fact_collector.run_facter.return_value = (0, '{"fact1_key":"fact1_value", "fact2_key":"fact1_value"}', 'facter: error: --json is not supported on your platform')
    fact_collector.get_facter_output(module=None)

# Generated at 2022-06-23 00:23:48.562151
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    ansible_module = 'get_facter_output'
    ansible_bin_path = None
    # Expected facter output strings

# Generated at 2022-06-23 00:23:51.934415
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == 'facter'
    assert set(['facter']) == ffc._fact_ids

    # Make sure the collection method returns a dict
    assert isinstance(ffc.collect(), dict)

# Generated at 2022-06-23 00:24:04.294335
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-23 00:24:05.875201
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    ffactc = FacterFactCollector()
    print(ffactc.get_facter_output(None))

# Generated at 2022-06-23 00:24:18.185357
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # mock the method get_bin_path of class AnsibleModule
    class AnsibleModuleMock(object):
        @staticmethod
        def get_bin_path(name, opt_dirs=None):
            if name == 'facter' and opt_dirs is None:
                return 'fake_facter_bin'
            if name == 'facter' and opt_dirs == ['/opt/puppetlabs/bin']:
                return None
            if name == 'cfacter' and opt_dirs == ['/opt/puppetlabs/bin']:
                return 'fake_cfacter_bin'
    # mock a class FacterFactCollector
    class FacterFactCollectorMock(FacterFactCollector):
        def __init__(self):
            pass
    # get the method find_facter of class F

# Generated at 2022-06-23 00:24:28.922405
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    # Create a new Facter fact collector
    fact_collector = FacterFactCollector()

    # Create a new ansible_module_utils.facts.collector.BaseFactCollector
    # instance, needed for the collect method of FacterFactCollector
    base_fact_collector = ansible.module_utils.facts.collector.BaseFactCollector()
    base_fact_collector.setup_module_object(module=None)

    # Create a new PrefixFactNamespace instance, needed to be assigned to the
    # namespace attribute of the FacterFactCollector instance

# Generated at 2022-06-23 00:24:38.291174
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    namespace = PrefixFactNamespace(namespace_name='facter',
                                    prefix='facter_')
    fact_collector = FacterFactCollector(namespace)

    assert fact_collector.name == 'facter'

    # Check that the collection of facts is stored in a specific namespace
    assert isinstance(fact_collector._collected_facts, PrefixFactNamespace)
    assert fact_collector._collected_facts.name == namespace.name
    assert fact_collector._collected_facts.prefix == namespace.prefix

    # Check that the collector has no children collectors
    assert fact_collector._collectors == []

# Generated at 2022-06-23 00:24:45.580963
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    """Test case for constructor of class FacterFactCollector"""

    facter_collector = FacterFactCollector()
    assert facter_collector
    assert facter_collector.name == 'facter'
    assert facter_collector._fact_ids == {'facter'}
    assert isinstance(facter_collector.namespace, PrefixFactNamespace)
    assert facter_collector.namespace.prefix == 'facter_'
    assert facter_collector.namespace.namespace_name == 'facter'

# Generated at 2022-06-23 00:24:52.019604
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():

    fact_collector = FacterFactCollector()
    assert fact_collector.name == 'facter'
    assert fact_collector._fact_ids == set(['facter'])
    assert isinstance(fact_collector.namespace, PrefixFactNamespace)
    assert fact_collector.namespace.namespace_name == 'facter'
    assert fact_collector.namespace.prefix == 'facter_'

# Generated at 2022-06-23 00:24:54.988386
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == "facter"
    assert str(ffc._fact_ids) == "{'facter'}"

# Generated at 2022-06-23 00:24:57.659600
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    collector = FacterFactCollector()
    assert collector.name == 'facter'
    assert collector._fact_ids == {'facter'}



# Generated at 2022-06-23 00:24:59.736884
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    a = FacterFactCollector()
    assert a.name == 'facter'
    assert a._fact_ids == set(['facter'])

# Generated at 2022-06-23 00:25:11.533615
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    
    class MockModule():

        def __init__(self, conf):
            self.conf = conf

        def get_bin_path(self, cmd, path=None, opt_dirs=None):
            path = self.conf['path']
            if path is None and 'facter' in cmd and 'facter_path' in self.conf:
                path = self.conf['facter_path']
            return path


# Generated at 2022-06-23 00:25:17.217288
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def get_bin_path(self, path, opt_dirs=None):
            return '/tmp/bogus.path'

    facter_collector = FacterFactCollector()
    assert facter_collector.find_facter(MockModule()) == '/tmp/bogus.path'


# Generated at 2022-06-23 00:25:18.640152
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert f.name == 'facter'

# Generated at 2022-06-23 00:25:29.374942
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    import pytest
    import platform
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, Mock
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args


# Generated at 2022-06-23 00:25:32.636544
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import FactCollector
    facter_path = FacterFactCollector.find_facter(FactCollector.module)
    assert facter_path != None


# Generated at 2022-06-23 00:25:41.889824
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    Test that we return the expected type and structure when
    we call the collect() method of the FacterFactCollector.
    """
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):
        def __init__(self, facter_dict):
            self.facter_dict = facter_dict
            self.params = {'gather_subset': ['all']}
            self.exit_json = lambda: True

        def get_bin_path(self, name, opt_dirs=[]):
            return '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-23 00:25:52.522963
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule:
        def __init__(self):
            self.rc = None
            self.output = None
            self.error = None
            self.run_command_return = None

        def run_command(self, command, check_rc=True, environ_update=None,
                        data=None, binary_data=False, prompt=None,
                        new_stdin=None, giveup_on_prompt=False, stdin=None,
                        close_fds=None, executable=None, path_prefix=None,
                        cwd=None, use_unsafe_shell=False, prompt_retry_check=True):
            return self.run_command_return

        def get_bin_path(self, exe, required=True, opt_dirs=None):
            base = exe[:3]

# Generated at 2022-06-23 00:26:03.500893
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    if sys.version_info[0] > 2:
        import unittest.mock as mock
    else:
        import mock

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, return_value, cmd_return_value=None):
            self.run_value = return_value
            self.cmd_return_value = cmd_return_value

        def get_bin_path(self, *args, **kwargs):
            return self.run_value

        def run_command(self, *args, **kwargs):
            return self.cmd_return_value



# Generated at 2022-06-23 00:26:14.192795
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector

    class CollectorA(BaseFactCollector):
        name = 'collectora'
        _fact_ids = set(['a', 'b'])

        def collect(self, module=None, collected_facts=None):
            fact_dict = {}
            fact_dict['a'] = '1'
            fact_dict['b'] = '2'
            return fact_dict

    class CollectorB(BaseFactCollector):
        name = 'collectorb'
        _fact_ids = set(['b', 'c'])

        def collect(self, module=None, collected_facts=None):
            fact_dict = {}
            fact_dict['b'] = '2'
            fact_dict['c'] = '3'
            return fact

# Generated at 2022-06-23 00:26:18.204979
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    # Test with no collectors and a namespace
    FacterFactCollector(namespace='test')

    # Test with collectors and a namespace
    FacterFactCollector(collectors=['a', 'b', 'c'], namespace='test')

# Generated at 2022-06-23 00:26:29.589565
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    class ModuleStub:
        def get_bin_path(self, binary, opt_dirs=[]):
            return './facter'


# Generated at 2022-06-23 00:26:40.621511
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.virt_who_hypervisor.facter_collector
    from ansible.module_utils._text import to_bytes

    class FakeAnsibleModule():
        params = dict(
            facts_facter_binary="/bin/facter"
        )
        def get_bin_path(self, binary, opt_dirs):
            return self.params['facts_facter_binary']
        def run_command(self, cmd):
            class FakeResult():
                def __init__(self, cmd):
                    self.cmd = cmd
                def command(self):
                    return self.cmd
                def __getitem__(self,name):
                    return self.__dict__[name]
                def __setitem__(self,name,value):
                    self.__dict__[name] = value

# Generated at 2022-06-23 00:26:48.061610
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    # Verify that we have the right number of fact ids
    ffc = FacterFactCollector()
    assert len(ffc._fact_ids) == 1
    assert 'facter' in ffc._fact_ids

    # Verify that we have the right number of facts
    facts = FacterFactCollector().collect()
    assert len(facts) == 8

    # Verify that we have the right number of fact ids
    ffc = FacterFactCollector(namespace='moo')
    assert len(ffc._fact_ids) == 1
    assert 'moo_facter' in ffc._fact_ids

    # Verify that we have the right number of facts
    facts = FacterFactCollector(namespace='moo').collect()
    assert len(facts) == 8