

# Generated at 2022-06-23 00:16:54.997072
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # create a temporary ansible module, we don't need the real test.module fixture,
    # since it doesn't have a run_command method we can mock
    import ansible
    def _run_command(self, cmd):
        """ mock for the run_command method """
        class _RC:
            """ mock for an ansible run_command return value """
            def __init__(self, rc, stdout, stderr):
                self.rc = rc
                self.stdout = stdout
                self.stderr = stderr

        if cmd == ['facter', '--json']:
            return _RC(0, u'{"kernel": "Linux"}\n', '')

# Generated at 2022-06-23 00:16:56.623224
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facts = FacterFactCollector().collect()
    assert facts is not None
    assert 'facter_os' in facts
    assert 'facter_os' in facts

# Generated at 2022-06-23 00:17:07.216051
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class ModuleFake:

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'cfacter':
                return None
            elif name == 'facter':
                return '/usr/bin/facter'
            else:
                return None

        def run_command(self, cmd):
            return 0, '{ "os": { "release": { "full": "17.04", "major": "17" } } }', ''

    # Test on a fake module
    module_fake = ModuleFake()

    # Get the FacterFactCollector object
    ffc = FacterFactCollector(namespace=PrefixFactNamespace())

# Generated at 2022-06-23 00:17:17.924555
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import module_utils.facts.collectors.facter as facter
    module = lambda **kwargs: dict(params=kwargs)
    module.run_command = lambda command: ('', kwargs, '')
    ffc = facter.FacterFactCollector()
    # case when facter cannot be found in path
    ffc.find_facter = lambda module: None
    assert ffc.run_facter(module(), '') == (1, None, None)
    # case when facter is found but --json option doesn't work
    ffc.find_facter = lambda module: "/usr/bin/facter"
    assert ffc.run_facter(module(), '')[0] != 0
    # case when facter is found and --json option works

# Generated at 2022-06-23 00:17:29.717337
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import sys
    import collections
    import os.path
    import os

    class MockModule(object):
        """Simple mock to mimic AnsibleModule"""
        def __init__(self, params=collections.defaultdict(lambda: "value")):
            self.params = params

        def get_bin_path(self, app, opt_dirs=[]):
            if app == 'cfacter' and sys.platform.startswith('linux'):
                return os.path.join(os.path.dirname(os.path.realpath(__file__)), 'cfacter')
            return None

        def run_command(self, args):
            args_list = args.split(" ")
            # check if cfacter was executed with right arguments

# Generated at 2022-06-23 00:17:32.174310
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_obj = FacterFactCollector()
    assert facter_obj is not None
    assert facter_obj.name == 'facter'
    # TODO: assert the fact_ids
    # TODO: assert the namespace

# Generated at 2022-06-23 00:17:39.394752
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, '{"operatingsystem": "Debian"}', '')
    facter_path = '/usr/bin/facter'
    expected_result = {'operatingsystem': 'Debian'}
    assert FacterFactCollector().run_facter(module_mock, facter_path) == expected_result


# Generated at 2022-06-23 00:17:47.158896
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class FakeModule:
        def __init__(self):
            self.fail_json_called = False
            self.exit_args = None

        def get_bin_path(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            self.fail_json_called = True
            self.exit_args = kwargs

    fake_module = FakeModule()

    facter_collector = FacterFactCollector()

    # Test when get_bin_path returns None that fail_json is not called and
    # None is returned.
    fake_module.get_bin_path = lambda *args, **kwargs: None
    assert facter_collector.find_facter(module=fake_module) is None
    assert not fake_module.fail_json_called

# Generated at 2022-06-23 00:17:49.074674
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    pass

# Unit test  for method collect of class FacterFactCollector

# Generated at 2022-06-23 00:17:54.254690
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # use a empty module for testing
    module = MagicMock()
    module.run_command.return_value = (0, '{ "ansible_facts" : {} }', '')
    output = FacterFactCollector().get_facter_output(module)
    assert(output is not None)
    assert(len(output) > 0)



# Generated at 2022-06-23 00:18:03.840826
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes
    class FakeModule:
        def __init__(self, **kwargs):
            self._fake_args = kwargs


# Generated at 2022-06-23 00:18:15.936530
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class MockModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path
        def get_bin_path(self, cmd, opt_dirs=None):
            return self.facter_path

    class MockModuleExec(object):
        def __init__(self, cmd):
            self.cmd = cmd
        def run_command(self, cmd):
            if cmd == self.cmd:
                rc = 0
                out = '{"foo":"bar"}'
                err = ''
            else:
                rc = 1
                out = ''
                err = "failed to run {}".format(cmd)
            return rc, out, err

    # Test that find_facter returns a path when facter is installed

# Generated at 2022-06-23 00:18:27.183746
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule(object):
        def __init__(self, facter_path, cfacter_path):
            self._facter_path = facter_path
            self._cfacter_path = cfacter_path

        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return self._facter_path

            if name == 'cfacter':
                return self._cfacter_path

            return None


    # by default return cfacter_path if both are present
    collector = FacterFactCollector(namespace=None)
    assert collector.find_facter(MockModule(facter_path='/path/to/facter',
                                            cfacter_path='/path/to/cfacter')) == '/path/to/cfacter'

    #

# Generated at 2022-06-23 00:18:33.598960
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts import FacterFactCollector

    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.COLLECTORS = []

    fact_collector = FacterFactCollector()
    fact_collector.facter_path = "/bin/true"

    test_run_facter = fact_collector.run_facter(None, fact_collector.facter_path)
    assert test_run_facter[0] == 0
    assert test_run_facter[1] == ""

# Generated at 2022-06-23 00:18:45.230083
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Placeholder test function to allow early development
    # and verification of the FacterFactCollector.find_facter()
    # method. This will not be a good unit test because it
    # tests too many things.
    test_get_bin_path_returns = [
        "/usr/bin/facter",
        "/usr/sbin/facter",
        "/usr/local/bin/facter",
    ]
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    module = basic.AnsibleModule(argument_spec=dict())
    collector.module = module
    FacterFactCollector.module = module

# Generated at 2022-06-23 00:18:53.770493
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import Collectors
    collectors = Collectors()
    facter = FacterFactCollector()

    from ansible.module_utils.facts.utils.facts_module import FactsModule
    from ansible.module_utils.facts import utils
    module = utils.get_module()

    rc, out, err = facter.run_facter(module, facter.find_facter(module))
    assert rc == 0
    assert out != ""
    assert err == ""


# Generated at 2022-06-23 00:18:56.209260
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.name == 'facter'

# Generated at 2022-06-23 00:19:05.663894
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.facter

    module = ansible.module_utils.facts.collector.BaseFactCollector({})
    ffactor = ansible.module_utils.facts.collectors.facter.FacterFactCollector({}, module)

    facter_path = ffactor.find_facter(module)
    if not facter_path:
        exit(0)

    rc, out, err = ffactor.run_facter(module, facter_path)

    print("facter version: ", out)

    if rc != 0:
        exit(1)
    else:
        exit(0)

# Generated at 2022-06-23 00:19:11.228814
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = type('AnsibleModule', (object,), dict(get_bin_path=lambda s, x, y: x,
                                                   run_command=lambda s, x: (0, '{"foo":"bar"}', '')))()
    facter_facts_collector = FacterFactCollector()
    facts = facter_facts_collector.collect(module=module)
    assert facts['facter_foo'] == 'bar'

# Generated at 2022-06-23 00:19:19.962953
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils._text import to_bytes

    class TestModule:
        def run_command(self, args):
            cmd = args[0]
            if cmd == 'facter --json' or cmd == 'cfacter --json':
                return 0, "ansible_facts:\n  foo: bar", ''
            elif cmd == 'facter --puppet' or cmd == 'cfacter --puppet':
                return 0, "ansible_facts:\n  foo: bar", ''
            elif cmd == 'facter --puppet --json' or cmd == 'cfacter --puppet --json':
                return 0, "ansible_facts:\n  foo: bar", ''

# Generated at 2022-06-23 00:19:31.163973
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test the situation when facter is not installed
    ffc = FacterFactCollector()
    facter_output = ffc.get_facter_output(dict())
    assert(facter_output is None)

    # Test the situation when facter is installed
    ffc = FacterFactCollector()
    facter_output = ffc.get_facter_output(dict(find_bin_path=find_bin_path))
    assert(facter_output is not None)
    assert(facter_output.startswith('{'))
    assert(facter_output.endswith('}'))


# Fake find_bin_path method to make sure facter is detected in test_FacterFactCollector_get_facter_output

# Generated at 2022-06-23 00:19:42.861974
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import namespace

    class MockModule:
        def __init__(self):
            self.bin_path_cache = {}
            self.call_cache = {}
            self.bin_path_cache['facter'] = 'facter'
            self.bin_path_cache['cfacter'] = 'cfacter'

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path_cache.get(*args, **kwargs)

        def run_command(self, cmd, *args, **kwargs):
            if getattr(self, 'call_cache').get(cmd):
                return self.call_cache[cmd]

            return 0, "", ""

    facter = F

# Generated at 2022-06-23 00:19:50.327605
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Arrange
    cfacter_path = "/opt/puppetlabs/bin/cfacter"
    facter_path = "/usr/local/bin/facter"
    ff = FacterFactCollector()
    ff.get_bin_path = lambda x, y: cfacter_path if x == "cfacter" else facter_path

    # Act
    actual_facter_path = ff.find_facter(None)

    # Assert
    assert(actual_facter_path == cfacter_path)


# Generated at 2022-06-23 00:20:01.094949
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # mock module
    class MockModule(object):
        def __init__(self, params=None):
            if params is None:
                self.params = {}
            else:
                self.params = params
            self.run_command_rc = None
            self.run_command_out = None
            self.run_command_err = None
            self.run_command_invoked = False

        def get_bin_path(self, path, opt_dirs=[]):
            # Dummy implementation
            return path

        def run_command(self, cmd):
            self.run_command_invoked = True
            return self.run_command_rc, self.run_command_out, self.run_command_err

    module = MockModule()

    # Create instance of class under test
    facter_fact_collector

# Generated at 2022-06-23 00:20:08.565349
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    class MockModule:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            if err == '':
                return '/some/path'
            else:
                return None

        def run_command(self, command):
            return self.rc, self.out, self.err

    def mock_get_facter_output(module):
        return out

    out = '{"facter": true}\n'
    err = ''
    rc = 0
    c = FacterFactCollector()
    c.get_facter_output = mock_get_facter_output
    module = MockModule(rc, out, err)

    #

# Generated at 2022-06-23 00:20:11.079896
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    c = FacterFactCollector()
    assert c.name == 'facter'
    assert c._fact_ids == set(['facter'])



# Generated at 2022-06-23 00:20:22.713936
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def __init__(self):
            self.fail_json = removed
            self.run_command = self.fake_run_command
        def get_bin_path(self, cmd, opt_dirs=[]):
            return "/usr/bin/" + cmd


# Generated at 2022-06-23 00:20:28.459580
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():

    collectors = None
    namespace = 'namespace_name'

    facter_fact_collector = FacterFactCollector(collectors, namespace)

    assert facter_fact_collector.collectors == collectors
    assert facter_fact_collector.namespace.namespace_name == namespace
    assert facter_fact_collector.name == 'facter'
    assert facter_fact_collector._fact_ids == set(['facter'])

# Generated at 2022-06-23 00:20:37.944348
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    import tempfile

    # create a temporary module, since we can't use the paramiko ones.
    class FakeModule:
        def __init__(self, params=None):
            self.params = params
            if not params:
                self.params = {}

            self.tmpdir = tempfile.mkdtemp()
            self.tmpfile = os.path.join(self.tmpdir, 'facter.json')

        def get_bin_path(self, name, opt_dirs=None):
            return None

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            stdout = '{"puppetversion":"4.10.12"}'
            return 0, stdout, ""

    module = FakeModule()

# Generated at 2022-06-23 00:20:45.963840
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector as facts_collector
    import ansible.module_utils.facts.system as facts_system
    import ansible.module_utils.facts.network as facts_network
    from ansible.module_utils.basic import AnsibleModule as AnsibleModule_orig
    import ansible.module_utils.facts.namespace as facts_namespace

    AnsibleModule = AnsibleModule_orig

    class AnsibleModule_mock(AnsibleModule):
        def __init__(self,argument_spec, bypass_checks=False, no_log=True,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None,
                     required_one_of=None, add_file_common_args=False):
            pass

# Generated at 2022-06-23 00:20:54.762117
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.posix.facter
    import ansible.module_utils.facts.collectors.posix.facter.ansible_test_fake_module
    # Set the facter binary to a fake binary that outputs valid json
    ansible.module_utils.facts.collectors.posix.facter.FACTER_BINARY = '/usr/bin/ansible_test_fake_facter_output_json'
    facter_collector = ansible.module_utils.facts.collectors.posix.facter.FacterFactCollector()
    fake_module = ansible.module_utils.facts.collectors.posix.facter.ansible_test_fake_module.FakeModule()
    facter_output

# Generated at 2022-06-23 00:21:04.280059
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector, \
        GenericFactCollector
    from ansible.module_utils.facts import ansible_collector

    class MockModule(object):
        def __init__(self, rc, out, err):
            self._rc = rc
            self._out = out
            self._err = err

        def get_bin_path(self, binary, opt_dirs=None):
            if binary == 'facter':
                return '/usr/bin/facter'
            elif binary == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

        def run_command(self, command, check_rc=True):
            if command == '/usr/bin/facter --puppet --json':
                return

# Generated at 2022-06-23 00:21:15.721639
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    candidate_paths = [
        # System binary search path
        '/usr/bin/facter',
        '/usr/bin/cfacter',

        # Puppet Enterprise
        '/opt/puppetlabs/bin/facter',
        '/opt/puppetlabs/bin/cfacter'
    ]

    # Mock the module
    module = MockModule()

    # Mock the module.get_bin_path method
    module.get_bin_path = Mock(side_effect=lambda b_name, _: next(x for x in candidate_paths if b_name in x))

    # Instantiate the class and create the object
    f = FacterFactCollector()

    # Assert the result is the first candidate path
    assert(f.find_facter(module) == candidate_paths[0])

# Generated at 2022-06-23 00:21:18.822299
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    import sys
    ffc = FacterFactCollector(namespace=sys.modules[__name__])
    assert ffc.name == 'facter'
    assert ffc._fact_ids == {'facter'}

# Generated at 2022-06-23 00:21:29.430443
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import module_fixture
    from ansible.module_utils.facts.collector import GetData

    facter_path = "/opt/puppetlabs/bin/facter"
    cfacter_path = "/opt/puppetlabs/bin/cfacter"

    # with facter and cfacter available, find_facter should return cfacter path
    mock_module = module_fixture('facter')
    mock_module.mock_bin_path(facter_path, True)
    mock_module.mock_bin_path(cfacter_path, True)
    get_data = GetData(module=mock_module)
    facter_fact_collector = FacterFactCollector(collectors=[], namespace=None)
    assert facter_fact_collector.find_

# Generated at 2022-06-23 00:21:39.655041
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils import basic
    p = basic.AnsibleModule(
        argument_spec=dict(),
    )
    facter_dict = {'fqdn': 'test.example.org'}

    class FacterModuleFake(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, binary, opt_dirs=None):
            return '/bin/facter'

        def run_command(self, command):
            return 0, json.dumps(facter_dict), ''

    module = FacterModuleFake(p)
    fact_collector = FacterFactCollector()
    results = fact_collector.collect(module=module)
    assert results['facter_fqdn'] == facter_dict['fqdn']



# Generated at 2022-06-23 00:21:50.618636
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """Unit tests for method run_facter of class FacterFactCollector"""
    from ansible.module_utils.facts.collector import FactsCollector
    class UnusedModule(object):
        def __init__(self):
            self.fail_json = None

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'facter':
                return '/fake/facter'
            if name == 'cfacter':
                return '/fake/cfacter'


# Generated at 2022-06-23 00:22:01.891317
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Test if cfacter is used as facter if installed
    import tempfile
    import shutil
    import os


# Generated at 2022-06-23 00:22:12.425824
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    """
    Test that the find_facter method returns the correct path
    """
    class MockModule(object):
        def __init__(self):
            self.bin_paths = {
                'facter': '/opt/puppetlabs/bin/facter',
                'cfacter': '/opt/puppetlabs/bin/cfacter',
                }
        def get_bin_path(self, executable, required=False, opt_dirs=None):
            return self.bin_paths.get(executable)

    module = MockModule()
    assert FacterFactCollector().find_facter(module) == '/opt/puppetlabs/bin/cfacter'
    module.bin_paths['cfacter'] = None

# Generated at 2022-06-23 00:22:24.105575
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import default_collectors

    facter_collector = get_collector_instance(FacterFactCollector, None)
    facter_path = facter_collector.find_facter(None)
    rc, out, err = facter_collector.run_facter(None, facter_path)
    assert(rc == 0)
    assert(err == '')

    facts = Facts(None, None, _collectors=default_collectors)
    facter_output = facter_collector.get_facter_output(facts.module)
    facter_dict = json.loads(facter_output)

# Generated at 2022-06-23 00:22:35.203342
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    class MockModule():
        def __init__(self):
            self.command_results = {
                'which facter':  ['facter_path'],
                'which cfacter': ['cfacter_path']
            }

        def get_bin_path(self, command, **kwargs):
            if command is 'facter':
                return self.command_results.get('which facter')
            if command is 'cfacter':
                return self.command_results.get('which cfacter')

    # GIVEN a facter fact collector
    facter_collector = FacterFactCollector()
    module = MockModule()

    # WHEN calling find_facter and facter is installed
    facter_path = facter_collector.find_facter(module)

    # THEN find_facter should return the path to fact

# Generated at 2022-06-23 00:22:38.317777
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    f = FacterFactCollector()
    assert isinstance(f, FacterFactCollector)
    assert f.name == "facter"
    assert type(f._fact_ids) is set

# Generated at 2022-06-23 00:22:45.654248
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    facter_obj = FacterFactCollector()
    assert isinstance(facter_obj, BaseFactCollector)
    assert isinstance(facter_obj, Collector)
    assert isinstance(facter_obj.namespace, PrefixFactNamespace)


# Generated at 2022-06-23 00:22:55.958329
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class fake_module(object):
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_fail = False
            self.run_command_fail_command = None
            self.run_command_if_exists_error = False
            self.run_command_if_exists_check_calls = 0
            self.run_command_if_exists_check = [None]

        def get_bin_path(self, command, opt_dirs=[]):
            if self.run_command_if_exists_error:
                raise Exception("Fake")

            if command in self.run_command_if_exists_check[self.run_command_if_exists_check_calls]:
                self.run_command_if_exists_check_c

# Generated at 2022-06-23 00:23:03.310770
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    assert FacterFactCollector.name == 'facter'
    assert FacterFactCollector._fact_ids == {'facter'}

    ff = FacterFactCollector()
    assert ff.name == 'facter'
    assert ff._fact_ids == {'facter'}
    assert ff.collectors == None
    assert ff.namespace._namespace_name == 'facter'
    assert ff.namespace._prefix == 'facter_'

    nff = FacterFactCollector(namespace='test_')
    assert nff.namespace._prefix == 'test_'

# Generated at 2022-06-23 00:23:14.036041
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    import tempfile
    import ansible.module_utils.facts.collectors.facter as l_facter
    import ansible.module_utils.facts.collectors.base as l_base
    from ansible.module_utils.facts import ansible_collector

    import ansible.module_utils.basic as ansible_basic
    class MockOptions(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = []
    class MockAnsibleModule(ansible_basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.options = MockOptions()
            self.check_mode = False
            self.exit_json = Mock(return_value=None)

# Generated at 2022-06-23 00:23:24.455095
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts

    ansible.module_utils.facts.collector.BaseFactCollector.collectors = []
    ansible.module_utils.facts.collector.BaseFactCollector.namespace = ansible.module_utils.facts.namespace.BaseFactNamespace()
    ansible.module_utils.facts.collector.BaseFactCollector._fact_cache = {}

    mock_module = ansible.module_utils.facts.namespace._MockModule()
    facter_fact_collector = FacterFactCollector()

    facter_dict = facter_fact_collector.collect(module=mock_module)

    assert "facter_kernel" in facter_

# Generated at 2022-06-23 00:23:33.287251
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    class FakeModule:
        def get_bin_path(self, program, opt_dirs=[]):
            if program == 'facter':
                return '/some/path/to/facter'
            elif program == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    cc = FacterFactCollector(namespace=PrefixFactNamespace(namespace_name='facter',
                                                           prefix='facter_'))
    assert cc.find_facter(FakeModule()) == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-23 00:23:40.836306
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    facter_path = '/opt/puppetlabs/bin/facter'
    facter_collector = FacterFactCollector()
    module_mock = MockModule(facter_path)
    rc, out, err = facter_collector.run_facter(module_mock, facter_path)
    assert rc == 0
    assert out == '{"uptime": "0 days", "uptime_seconds": 0}\n'
    assert err == ''


# Generated at 2022-06-23 00:23:50.589240
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    module_mock = ansible.module_utils.facts.collector.ModuleMock()
    module_mock.add_bin_path(bins=['facter'])

    collector = FacterFactCollector(namespace=ansible.module_utils.facts.namespace.PrefixFactNamespace(
        namespace_name='facter',
        prefix='facter_'
    ))

    facter_output = collector.get_facter_output(module_mock)

    if facter_output is None:
        print("facter not installed or could not run")
        return

    # TODO: this test will fail if facter is installed, but ruby-json isnt.
    # Should we setup a

# Generated at 2022-06-23 00:23:52.099434
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.collect()

# Generated at 2022-06-23 00:23:55.427443
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts import collector
    collector.main()



# Generated at 2022-06-23 00:24:01.117465
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    Unit test for method collect
    """

    # Create a FacterFactCollector instance
    facter_collector = FacterFactCollector()

    # Create a module instance for testing
    module = None

    # If the method collect returns facts, the test case is passed
    if facter_collector.collect(module) is not None:
        assert True
    else:
        assert False

# Generated at 2022-06-23 00:24:12.631499
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeAnsibleModule(object):
        def __init__(self, out, rc, err):
            self.out = out
            self.rc = rc
            self.err = err

        def get_bin_path(self, executable, opt_dirs=None):
            if executable != 'facter':
                return None

            return self.out

        def run_command(self, cmd, path_prefix=None, check_rc=True):
            return self.rc, self.out, self.err

    # Test check_run_command_failures
    def test_rc_fail(out, rc):
        module = FakeAnsibleModule(out, rc, None)
        facter = FacterFactCollector(None)
        return facter.get_facter_output(module)

    assert test_rc_fail

# Generated at 2022-06-23 00:24:24.432190
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    # Note we just mock the module object, it's not really from AnsibleModule
    import mock

    module = mock.Mock()
    module.get_bin_path.return_value = None

    facts = ansible.module_utils.facts.collector.FacterFactCollector()
    assert facts.find_facter(module) is None

    module.get_bin_path.return_value = 'foo'
    assert facts.find_facter(module) == 'foo'

    # This is kinda redundant since get_bin_path is already mocked...
    module.get_bin_path.return_value = '/opt/puppetlabs/bin/cfacter'
    facts = ansible.module_utils.facts.collector.FacterFactCollector()
    assert facts

# Generated at 2022-06-23 00:24:28.250502
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    c = FacterFactCollector()
    assert c.name == 'facter'
    assert c._fact_ids == set(['facter'])
    assert c.namespace.namespace_name == 'facter'
    assert c.namespace.prefix == 'facter_'

# Generated at 2022-06-23 00:24:39.631905
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    test_facter_path = '/opt/puppetlabs/bin/facter'

    # Test find_facter() with no path
    t = FacterFactCollector()

    m = MockModule()
    m.params = {}
    m.params['PATH'] = ''
    assert not t.find_facter(m)

    # Test find_facter() with facter in path
    t = FacterFactCollector()

    def mgetbinpath_facter(k,v):
        return 'test_facter'

    m = MockModule()
    m.params = {}
    m.params['PATH'] = '/usr/bin/'
    m.get_bin_path = mgetbinpath_facter
    assert t.find_facter(m) == 'test_facter'

    # Test find_

# Generated at 2022-06-23 00:24:41.939873
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    collector = FacterFactCollector()
    assert collector.name == 'facter'
    assert collector._fact_ids == set(['facter'])

# Generated at 2022-06-23 00:24:52.767029
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    test_module = type('', (), {})()

    test_module.run_command = lambda x: (0, "", "")
    test_module.get_bin_path = lambda x, y: '/usr/bin/facter'

    obj = FacterFactCollector()

    # Facter must be installed
    assert obj.run_facter(test_module, None) == (1, "", "")
    # Facter command must succeed
    assert obj.run_facter(test_module, '') == (1, "", "")

    test_module.run_command = lambda x: (1, "", "")

    # Facter command must succeed
    assert obj.run_facter(test_module, '/usr/bin/facter') == (1, "", "")

# Generated at 2022-06-23 00:24:54.458222
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    obj = FacterFactCollector()
    assert 'facter' == obj.find_facter(None)

# Generated at 2022-06-23 00:25:01.396389
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import module_utils.facts.collector
    collector = module_utils.facts.collector.FacterFactCollector()

    class Module():
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'cfacter':
                return "test"
            return None

    module = Module()
    assert(collector.find_facter(module) == "test")
    assert(collector.find_facter(module) is None)



# Generated at 2022-06-23 00:25:12.874510
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """
    This unittest covers the method run_facter of class FactCollector
    """
    import unittest
    import mock

    class MockModule(object):
        def run_command(self, params):
            print(params)
            return 0, '{"hostname":"hostmock","lsb":{"distcodename":"cosmic","distdescription":"Ubuntu 18.04.1 LTS","distid":"Ubuntu","distrelease":"18.04","distshortcut":"bionic","majdistrelease":"18.04","release":"18.04"}}', None


    class MockFactCollector(FacterFactCollector):
        def run_facter(self, module, facter_path):
            return 0, '{"hostname": "hostmock"}', None


    mock_module = MockModule()
    facter_

# Generated at 2022-06-23 00:25:19.028052
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = {'get_bin_path': lambda executable, opt_dirs=None: os.path.join(os.path.dirname(__file__), executable) }
    collector = FacterFactCollector()

    facter_path = collector.find_facter(module)
    rc, out, err = collector.run_facter(module, facter_path)
    assert rc == 0
    assert len(out) > 0

# Generated at 2022-06-23 00:25:30.134471
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    # mock module, facter is not available
    module = MockModule(
        **{
            'get_bin_path.side_effect': lambda cmd, opt_dirs: None
        }
    )
    facter_fact_collector = FacterFactCollector()
    assert {} == facter_fact_collector.collect(module=module)

    # mock module, facter is available
    module = MockModule(
        **{
            'get_bin_path.side_effect': lambda cmd, opt_dirs: 'path/to/facter'
        }
    )

    facter_fact_collector = FacterFactCollector()

    # mock module.run_command, facter run failed

# Generated at 2022-06-23 00:25:39.975942
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collectors.facter import FacterFactCollector
    from ansible.module_utils.facts.fake import FakeModule
    module = FakeModule(paths_ansible_config=['/etc/ansible'],
                        paths_module_utils=['/usr/share/ansible/module_utils'])
    module.run_command = lambda *args: (0, '{"ansible_facts": "something"}', '')
    f = FacterFactCollector()
    f.find_facter = lambda module: module.get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
    assert 'ansible_facts' in f.run_facter(module, '/usr/bin/facter')[1]

# Generated at 2022-06-23 00:25:47.365654
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    collector = FacterFactCollector()
    # Unit test for unavailability of facter
    assert collector.get_facter_output(None) == None

    class MockModule(object):
        def get_bin_path(self, *args):
            return args[0]

        def run_command(self, *args):
            return (0, '{"a":1,"b":2}', '')

    # Unit test for availability of facter
    assert collector.get_facter_output(MockModule()) == '{"a":1,"b":2}'

# Generated at 2022-06-23 00:25:49.284253
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc
    assert ffc.name == 'facter'

# Generated at 2022-06-23 00:25:50.667589
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    result = FacterFactCollector()
    assert result is not None


# Generated at 2022-06-23 00:25:55.913698
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import collector

    ansible.module_utils.facts.collector = collector
    ansible.module_utils.facts.collector.BaseFactCollector = BaseFactCollector

    # Import module
    modules = ['facter']
    for mod in modules:
        importlib.import_module('ansible.module_utils.facts.collector.%s' % mod)

    c = ansible.module_utils.facts.collector.FacterFactCollector()
    r = c.find_facter(ansible.module_utils.facts.collector)
    print(r)


# Generated at 2022-06-23 00:25:59.567358
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    fc = FacterFactCollector()
    assert fc.find_facter({
        'get_bin_path': lambda x, opt_dirs=None: x,
    }) == 'facter'



# Generated at 2022-06-23 00:26:11.102474
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    m = FacterFactCollector()
    m.find_facter('/usr/bin/facter')
    m.run_facter('/usr/bin/facter')
    m.get_facter_output('/usr/bin/facter')
    m.collect('/usr/bin/facter')
    class Mod(object):
        # copy the user environment
        environ = os.environ.copy()
        data = dict()

        def get_bin_path(self, cmd, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{ "test": "success" }', ''

    class CollectedFacts(object):
        facts = dict()

    facter = FacterFactCollector()
    mod = Mod()

# Generated at 2022-06-23 00:26:21.706807
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import os

    # Load test variables
    # All of these are stored in the 'test/fixtures/facter/ansible_facts.fact' file
    # FIXME: use a fixture instead
    fact_file = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'fixtures', 'facts', 'ansible_facts.fact')
    with open(fact_file, 'r') as facts_file:
        test_facts = json.load(facts_file)

    import ansible.module_utils.facts.collector

    module = ansible.module_utils.facts.collector.get_ansible_module()
    test_FacterFactCollector = FacterFactCollector()


# Generated at 2022-06-23 00:26:26.072181
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return 'mocked'

    ffc = FacterFactCollector()
    assert ffc.find_facter(MockModule()) == 'mocked'

# Generated at 2022-06-23 00:26:35.519124
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    ffc = FacterFactCollector()
    mock_module = MockModule('path/to/facter')
    mock_module.return_value = None
    mock_module.get_bin_path.return_value = '/path/to/facter'
    mock_module.run_command.return_value = (0, '{}', '')
    ffc.get_facter_output(mock_module)
    mock_module.get_bin_path.assert_called_with('facter', opt_dirs=['/opt/puppetlabs/bin'])
    mock_module.run_command.assert_called_with('/path/to/facter --puppet --json')


# Generated at 2022-06-23 00:26:43.952781
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():

    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.name == 'facter'
    assert len(facter_fact_collector._fact_ids) == 1
    assert 'facter' in facter_fact_collector._fact_ids

    assert facter_fact_collector.collectors is None
    assert 'facter_' == facter_fact_collector.namespace.prefix
    assert 'facter' == facter_fact_collector.namespace.namespace_name

# Generated at 2022-06-23 00:26:46.837975
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    collectors = None
    namespace = None
    facter_fact_collector = FacterFactCollector(collectors=collectors, namespace=namespace)

    assert facter_fact_collector.name == 'facter'