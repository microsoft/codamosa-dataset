

# Generated at 2022-06-23 00:16:53.786695
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # make sure we can capture stdout from an external binary
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={}, supports_check_mode=False)
    f = FacterFactCollector()
    rc, out, err = f.run_facter(m, "/bin/ls")
    assert rc == 0
    assert out is not None
    assert err is None
    assert len(out) > 0
    assert out.find("setup.py") > -1


# Generated at 2022-06-23 00:16:58.984555
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # FIXME: this test method depends on a temporary facter_output file in the current dir,
    #        and it should instead use a file in tmpdir
    test_facter_output = open('facter_output', 'r').read()
    test_facter_path = '/usr/bin/facter'

    test_module = MockModule()
    test_module.get_bin_path.return_value = test_facter_path

    facter_fact_collector = FacterFactCollector()

    facter_output = facter_fact_collector.get_facter_output(test_module)

    assert facter_output == test_facter_output


# Generated at 2022-06-23 00:17:07.491048
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    #
    # Ansible: Unit testing arguments
    #

    #
    # Module arguments
    #

    #
    # Ansible facts
    #

    ansible_facts = {}

    #
    # Ansible Module return values
    #

    ansible_module = AnsibleModule(argument_spec=dict())
    ansible_module.exit_json = MagicMock(return_value=None)

    #
    # Unit test
    #

    fact_collector = FacterFactCollector()

    facter_dict = fact_collector.collect(module=ansible_module, collected_facts=ansible_facts)

    assert facter_dict is not None

# Generated at 2022-06-23 00:17:13.188367
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts.collector import Namespace
    f = FacterFactCollector()
    assert f.name == 'facter'
    assert f._fact_ids == set(['facter'])
    assert isinstance(f.namespace, Namespace)
    assert f.namespace.namespace == 'facter'
    assert f.namespace.prefix == 'facter_'

# Generated at 2022-06-23 00:17:23.907188
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Mocks
    def find_facter(self, module):
        return '/opt/puppetlabs/bin/facter'

    def run_facter(self, module, facter_path):
        return 0, '{"facter": "output"}', None
    # Test
    from ansible.module_utils.facts import facts
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collector = FacterFactCollector()
    fact_collector.find_facter = find_facter.__get__(fact_collector)
    fact_collector.run_facter = run_facter.__get__(fact_collector)
    module = ansible.module_utils.facts.collector.BaseFactCollector

# Generated at 2022-06-23 00:17:31.938964
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class _module(object):
        def get_bin_path(self, arg, opt_dirs=None):
            if arg == 'facter':
                return '/opt/puppetlabs/bin/facter'
            elif arg == 'cfacter':
                return None

    ffc = FacterFactCollector()
    module = _module()
    facter_path = ffc.find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-23 00:17:32.410941
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    pass

# Generated at 2022-06-23 00:17:41.468479
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Create a mock module object
    class MockModuleObj():

        def get_bin_path(self, exe, opt_dirs=[]):
            if exe == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            elif exe == 'facter':
                return '/usr/bin/facter'
            else:
                return None

    ff = FacterFactCollector()
    facter_path = ff.find_facter(MockModuleObj())
    assert facter_path == '/opt/puppetlabs/bin/cfacter'



# Generated at 2022-06-23 00:17:50.482743
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    # In a module, FacterFactCollector is instantiated with following arguments:
    #  - collectors=None
    #  - namespace=None
    # In test, we instantiate with:
    #   - collectors=set([])
    #   - namespace=BaseFactNamespace()

    facter_fact_collector = FacterFactCollector(collectors=set([]), namespace=BaseFactNamespace())

    assert facter_fact_collector.name == 'facter'
    assert facter_fact_collector._fact_ids == set(['facter'])
    assert isinstance(facter_fact_collector.namespace, PrefixFactNamespace)
    assert facter_fact_collector.namespace.name == 'facter'

# Generated at 2022-06-23 00:17:53.837535
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    try:
        from ansible.module_utils.facts import collector
        collector.collectors['facter'] = FacterFactCollector()
    except ImportError:
        pass


# Generated at 2022-06-23 00:17:57.989554
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create a mock module
    module = MockModule()
    module.run_command = Mock(return_value=(0, "", ""))

    facter_collector = FacterFactCollector()
    results = facter_collector.get_facter_output(module)

    assert results == ""

# Generated at 2022-06-23 00:18:06.315260
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import json
    import os
    import sys
    import unittest

    class FakeModule(object):
            def get_bin_path(self, executable, opt_dirs=None):
                """Returns the path of an executable or None if it couldn't be found
                """
                return self.executable_path

            def run_command(self, command):
                """
                Executes a command on the remote host.
                :param command: Command to execute after connecting to the remote host.
                :param executable: The shell executable or is None to indicate the default shell.
                :return: A tuple containing the return code (integer), stdout (byte string) and
                stderr (byte string)
                """
                return self.return_code, self.stdout, self.stderr


# Generated at 2022-06-23 00:18:09.758967
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create new FacterFactCollector object
    #fact_collector = FacterFactCollector()
    #facter_dict = fact_collector.collect()
    #print(facter_dict)
    pass

# Generated at 2022-06-23 00:18:17.756151
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import Module
    from ansible.module_utils.facts.collector import DictModuleArgs
    facter_collector = FacterFactCollector(namespace='ansible', collectors=['facter'])
    module = Module(argument_spec=DictModuleArgs(), supports_check_mode=False)
    facter_path = facter_collector.find_facter(module)
    rc, out, err = facter_collector.run_facter(module, facter_path)
    assert rc == 0


# Generated at 2022-06-23 00:18:28.056337
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseCollectorCache
    from ansible.module_utils.facts.utils import variable

    facter_fact_collector = FacterFactCollector()

    module_mock = variable.ModuleMock()
    module_mock.get_bin_path.return_value = '/opt/puppetlabs/bin/facter'
    module_mock.run_command.return_value = (0, '{"fact1":"value1","fact2":"value2"}', '')

    facter_facts = facter_fact_collector.get_facter_output(module_mock)

    assert facter_facts == '{"fact1":"value1","fact2":"value2"}'


# Generated at 2022-06-23 00:18:35.779218
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    class FakeModule:
        def __init__(self):
            pass

        def get_bin_path(self, executable, opt_dirs=()):
            return '/usr/bin/' + executable

        def run_command(self, executable):
            if executable == '/usr/bin/cfacter --puppet --json':
                return 0, json.dumps({'puppetversion': '4.4.0', 'python': {'version': {'major': 2}} }), ''
            else:
                return 0, json.dumps({'facterversion': '1.6.18', 'python': {'version': {'major': 2}} }), ''

    module = FakeModule()

    facter = FacterFactCollector()

    facts = facter.collect(module)


# Generated at 2022-06-23 00:18:39.147081
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Check that FacterFactCollector.collect() returns a dict
    fact_collector = FacterFactCollector()
    assert isinstance(fact_collector.collect(None), dict)



# Generated at 2022-06-23 00:18:50.842882
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    # Create instance of class FacterFactCollector
    facter_fact_collector = FacterFactCollector()

    # Create mock_module object
    class mock_module(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = []

        def get_bin_path(self, app, opt_dirs=[]):
            if app == 'facter':
                return '/usr/bin/facter'
            elif app == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

    # Get bin path to facter
    facter_path = facter_fact_collector.find_facter(mock_module())

    # Result should be /usr/bin/cfacter

# Generated at 2022-06-23 00:19:01.604786
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    import mock
    import types

    # Create a mock for ansible.module_utils.facts.namespace.PrefixFactNamespace
    mock_namespace = mock.Mock()

    # Create a mock for ansible.module_utils.facts.collector.BaseFactCollector
    mock_base_facts_collector = mock.Mock()

    # Instantiate an object of class FacterFactCollector
    facter_facts_collector = FacterFactCollector(
        collectors=None,
        namespace=mock_namespace)

    # Checks the type of facter_facts_collector
    assert isinstance(facter_facts_collector, types.InstanceType)

    # Checks the attributes of object
    assert hasattr(facter_facts_collector, 'name')

# Generated at 2022-06-23 00:19:08.960366
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    ns = ansible.module_utils.facts.namespace.PrefixFactNamespace(namespace_name='facter',
                                                                  prefix='facter_')
    module = ansible.module_utils.facts.collector.BaseFactCollector(namespace=ns)
    obj = FacterFactCollector()
    facter_output = obj.get_facter_output(module)
    assert facter_output != None

# Generated at 2022-06-23 00:19:18.312917
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_collector = FacterFactCollector()
    assert facter_collector.name == 'facter'
    assert facter_collector.find_facter('/usr/bin/facter') == '/usr/bin/facter'
    assert facter_collector.find_facter('/bin/facter') == '/bin/facter'
    assert facter_collector.find_facter('/usr/bin/cfacter') == '/usr/bin/cfacter'
    assert facter_collector.find_facter('/bin/cfacter') == '/bin/cfacter'
    assert facter_collector.find_facter('/opt/puppetlabs/bin/facter') == '/opt/puppetlabs/bin/facter'

# Generated at 2022-06-23 00:19:22.964611
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    instance = FacterFactCollector()
    assert isinstance(instance, BaseFactCollector)
    assert isinstance(instance.namespace, PrefixFactNamespace)

# Generated at 2022-06-23 00:19:29.253544
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector_with_namespace = FacterFactCollector(namespace=PrefixFactNamespace(namespace_name='facter', prefix='facter_'))

    if facter_fact_collector.name != 'facter':
        print("test_FacterFactCollector FAILED")


# Generated at 2022-06-23 00:19:37.304811
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    '''
    collect()
    '''

    collector = FacterFactCollector

    def get_bin_path(name, opt_dirs=[]):
        return '/usr/bin/facter'

    m = type('m', (object,), {'get_bin_path': get_bin_path})()

    def run_command(cmd, **kwargs):
        return (0, '{ "foo": "bar" }', '')

    m.run_command = run_command

    result = collector.collect(m)

    assert result['facter_foo'] == 'bar'

# Generated at 2022-06-23 00:19:48.212057
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Create test object
    try:
        from ansible.module_utils.facts.collector.system import SystemFactCollector
        sut = FacterFactCollector(collectors=[SystemFactCollector])
    except ImportError:
        # In case system fact collector is not present, we need not to run the test
        return

    # Construct the test object
    try:
        module = sut._get_module()
        assert module is not None
    except Exception:
        assert False, "Failed to create module stub for testing."

    # Find facter
    try:
        assert sut.find_facter(module) is not None
    except Exception as e:
        assert False, "Failed to find facter. {}".format(e)



# Generated at 2022-06-23 00:19:59.108527
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """ test the FacterFactCollector.collect() method """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_collector

    module_mock = basic.AnsibleModule(argument_spec=dict())
    module_mock.run_command = lambda *args, **kwargs: (0, '{"a": 1, "b": "c"}', '')
    module_mock.get_bin_path = lambda *args, **kwargs: '/usr/bin/facter'

    facter_collector = FacterFactCollector()
    facter_facts = facter_collector.collect(module=module_mock, collected_facts=ansible_collector)

    assert facter_facts is not None
    assert isinstance(facter_facts, dict)

   

# Generated at 2022-06-23 00:20:04.776408
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = AnsibleModuleMock()
    facter_path = '/usr/bin/facter'
    facter_output = '{"foo":"bar","baz":"true"}\n'

    rc, out, err = FacterFactCollector().run_facter(module, facter_path)
    assert rc == 0
    assert out == facter_output
    assert err == ''
    module.run_command.assert_called_once_with('/usr/bin/facter --puppet --json')



# Generated at 2022-06-23 00:20:07.214288
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()

    assert ffc.name == 'facter'
    assert ffc._fact_ids == set(['facter'])

    # TODO: add more asserts to test the other attrs

# Generated at 2022-06-23 00:20:16.964719
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    mod_utils = MockModuleUtils()
    facter_collector = FacterFactCollector()

    module = MockModule()
    module.get_bin_path = mod_utils.get_bin_path

    assert facter_collector.find_facter(module) == "/usr/bin/cfacter"

    module.get_bin_path = mod_utils.get_bin_path_cfacter_fail

    assert facter_collector.find_facter(module) == "/usr/bin/facter"

    # cfacter is not installed
    module.get_bin_path = mod_utils.get_bin_path_cfacter_facter_fail

    assert facter_collector.find_facter(module) is None



# Generated at 2022-06-23 00:20:24.618487
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector(collectors=None, namespace=None)
    assert facter_fact_collector
    assert facter_fact_collector.name == 'facter'
    assert facter_fact_collector._fact_ids == {'facter'}
    assert isinstance(facter_fact_collector._namespace, PrefixFactNamespace)
    assert facter_fact_collector._namespace.namespace_name == 'facter'
    assert facter_fact_collector._namespace.prefix == 'facter_'

# Generated at 2022-06-23 00:20:26.371009
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    # Happy path test
    c = FacterFactCollector()
    assert c is not None


# Generated at 2022-06-23 00:20:37.046665
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector.facter import FacterFactCollector

    module = AnsibleModule(argument_spec=dict())
    facter_collector = FacterFactCollector()

    # Test with facter installed, and cfacter not installed
    module.run_command = lambda x: (0, '', '')
    assert facter_collector.find_facter(module) == '/bin/facter'

    # Test with cfacter installed, and facter not installed
    module.run_command = lambda x: (1, '', '')
    assert facter_collector.find_facter(module) == '/bin/cfacter'

    # Test with both facter and

# Generated at 2022-06-23 00:20:41.836113
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import sys
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic

    def writeFactFile(filePath, fileContent):
        with open(filePath, 'w') as fact_file:
            fact_file.write(fileContent)

    testDir = os.environ.get('TEST_DIR', '/tmp/.ansible')

    fact_target = 'os'
    fact_source = 'FacterFactCollector'

    if not os.path.exists(testDir):
        os.makedirs(testDir)

    testFacterPath = '%s/facter' % testDir
    testFacterFactFile = '%s/facter.facts' % testDir

    # Need to make sure the test dir

# Generated at 2022-06-23 00:20:52.644404
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.facts import *

    def get_bin_path_mock(binary, opt_dirs=None):
        if binary == 'facter':
            return '/usr/bin/facter'
        elif binary == 'cfacter':
            return '/usr/bin/cfacter'

    # Create mock module and mock module.run_command()
    module = basic.AnsibleModule(argument_spec={})
    module.get_bin_path = get_bin_path_mock

    # Create facter fact collector
    facterFactCollector = FacterFactCollector()

# Generated at 2022-06-23 00:21:02.995631
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    import sys
    import tempfile
    import six
    import ansible.module_utils.facts.collector

    mypath = os.path.dirname(os.path.abspath(__file__))

    # Create a temp file for the faked facter output
    tmpfd, tmpfilename = tempfile.mkstemp()
    with os.fdopen(tmpfd, "w+") as f:
        f.write("""{"myvar":"myvalue"}""")
    os.chmod(tmpfilename, 0o755)

    # Try to use the real facter location
    facter_path = ansible.module_utils.facts.collector.FacterFactCollector().find_facter({})
    facter_version = None
    facter_version_output = None

# Generated at 2022-06-23 00:21:13.737051
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance, BaseFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.netinfo import NetInfoCollector
    from ansible.module_utils.facts.system import SystemCollector
    from ansible.module_utils.facts.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.puppet import PuppetFactCollector
    from ansible.module_utils.facts.zfs import ZfsFactCollector
    from ansible.module_utils.facts.ip_filters import I

# Generated at 2022-06-23 00:21:22.188806
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def get_bin_path(self, app, opt_dirs=[]):
            if app == 'facter':
                return '/usr/bin/facter'
            elif app == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'

    module = TestModule()

    ff = FacterFactCollector()

    assert ff.find_facter(module) == '/usr/bin/facter'


# Generated at 2022-06-23 00:21:31.820765
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.path_exists_map = {
                'cfacter': True,
                '/opt/puppetlabs/bin/cfacter': True,
                'facter': True,
                '/opt/puppetlabs/bin/facter': True
            }
            self.run_command_map = {
                'facter --puppet --json': (0, '{"f1":"v1"}', None)
            }

        def get_bin_path(self, name, opt_dirs=[]):
            path = '/opt/puppetlabs/bin/{}'.format(name)
            if name in self.path_exists_map and self.path_exists_map[name]:
                return path
           

# Generated at 2022-06-23 00:21:42.396514
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # noinspection PyUnresolvedReferences
    module = MagicMock(get_bin_path=lambda x: '/path/to/facter')

    # noinspection PyUnresolvedReferences
    module.run_command = lambda x: (0, '{"ansible_facter": {"foo": "bar"}}', '')

    namespace = PrefixFactNamespace(namespace_name='facter', prefix='facter_')
    collector = FacterFactCollector(namespace=namespace)

    expected_output = {
        'ansible_facter': {
            'foo': 'bar'
        },
        'facter_ansible_facter': {
            'foo': 'bar'
        },
        'facter_foo': 'bar',
    }

    assert collector.collect(module=module) == expected_output

# Generated at 2022-06-23 00:21:52.132590
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    class TestModule:
        def get_bin_path(self, bin, opt_dirs=[]):
            return "/bin/facter"
        def run_command(self, cmd):
            return 24, "", ""
    class TestCollector:
        def collect(self, module, fact_dict):
            return {"facter": "test_value"}
    collector = TestCollector()
    fact_collector = FacterFactCollector(collectors=[collector])
    module = TestModule()
    fact_collector.run_facter(module, "/bin/facter")
    fact_dict = fact_collector.collect(module, {})
    assert 'facter_test_value' in fact_dict


# Generated at 2022-06-23 00:21:56.927431
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_facts = FacterFactCollector()
    assert facter_facts.name == 'facter'
    prefix_fact_namespace = PrefixFactNamespace(namespace_name='facter',
                                                prefix='facter_')
    assert facter_facts.namespace == prefix_fact_namespace

# Generated at 2022-06-23 00:22:08.246562
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os.path
    import sys

    # make our simple test module
    def get_bin_path(self, executable, opt_dirs=[]):
        if executable == 'facter':
            return '/usr/bin/facter'
        return None
    setattr(FacterFactCollector, 'get_bin_path', get_bin_path)

    # create our test case
    class MyTest(object):
        def __init__(self, result):
            self.result = result
        def assertEqual(self, a, b):
            assert a == b
        def assertTrue(self, a):
            assert a
        def assertFalse(self, a):
            assert not a
    test = MyTest(None)

    # run the test
    mod = FacterFactCollector()
    facter_path = mod

# Generated at 2022-06-23 00:22:19.482903
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import sys
    import os
    import time
    import logging
    import shutil
    import tempfile
    from ansible.module_utils.facts import TO_TEXT

    class FakeModule(object):
        def __init__(self):
            self.logger = logging.getLogger()
            self.fail_json = None
            self.exit_json = None
            self.params = None

        #
        # Run a command on the local machine, return rc, stdout, and stderr
        #
        def run_command(self, cmd):
            return 1, 'out', 'err'

        #
        # Find a the location of a named executable on the current system
        #
        def get_bin_path(self, name, opt_dirs):
            return None

    #
    # Build a fake facter in

# Generated at 2022-06-23 00:22:23.588278
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.name == 'facter'
    assert facter_fact_collector._fact_ids == set(['facter'])


# Generated at 2022-06-23 00:22:34.668653
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import sys
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_if_exists

    class ModuleMock(object):
        def get_bin_path(self, executable, opt_dirs=None, required=False):
            # Fixups
            if sys.platform == 'darwin':
                executable += '.osx'

            # Bits

# Generated at 2022-06-23 00:22:36.005700
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_obj = FacterFactCollector()
    assert facter_obj is not None

# Generated at 2022-06-23 00:22:46.164366
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    facter_dict = {}

    facter = FacterFactCollector()

    # Test with empty data
    assert facter.collect(module, facter_dict) == facter_dict

    module = 'ansible_module'
    facter_dict = {'ansible_module': None}

    facter = FacterFactCollector()

    # Test with empty data
    assert facter.collect(module, facter_dict) == facter_dict

    module = 'ansible_module'

    facter = FacterFactCollector()

    # Test with empty data
    assert facter.collect(module) == facter_dict

    assert facter.collect(module, facter_dict) == facter_dict

# Generated at 2022-06-23 00:22:47.987070
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Useful to test a "normal" output and an error output.
    pass


# Generated at 2022-06-23 00:22:58.110745
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.network.base import NetworkCollector

    class TestFacterModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/facter'

        def run_command(self, command):
            if command == '/bin/facter --puppet --json':
                return (0, '{"key": "value"}', 'error')
            else:
                return (0, '', '')

    test_collector = FacterFactCollector(collectors=[NetworkCollector])
    facter_dict = test_collector.get_facter_output(TestFacterModule())

    assert facter_dict == '{"key": "value"}'

# Generated at 2022-06-23 00:23:01.543635
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()

    assert(ffc.name == 'facter')

    assert(ffc.namespace._namespace_name == 'facter')
    assert(ffc.namespace._prefix == 'facter_')


# Generated at 2022-06-23 00:23:12.290845
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import PrivateFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    import tempfile

    module_mock = Mock()
    module_mock.get_bin_path.return_value = 'facter.sh'
    module_mock.run_command.return_value = (0,
                                            to_bytes(json.dumps({'kernel': 'Linux'})),
                                            to_bytes(''))

# Generated at 2022-06-23 00:23:17.548252
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_fact_collector = FacterFactCollector()
    assert facter_fact_collector.name == 'facter'
    assert facter_fact_collector._fact_ids == set(['facter'])
    assert facter_fact_collector.namespace.name == 'facter'
    assert facter_fact_collector.namespace.prefix == 'facter_'

# Generated at 2022-06-23 00:23:27.742228
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import unittest
    import sys
    import os

    class TestModule(object):
        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, executable):
            if executable == '/usr/bin/facter --puppet --json':
                return 0, '{"hostname": "example.com", "kernel": "Linux", "id": "xyz"}', ''
            else:
                return 1, '', ''

    class TestFacterFactCollector(FacterFactCollector):
        def find_facter(self, module):
            return '/usr/bin/facter'

    test_facter_fact_collector = TestFacterFactCollector()
    test_module = TestModule()

    result = test_facter_

# Generated at 2022-06-23 00:23:36.759203
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Test where facter --json fails (-1 exit code, empty stdout/stderr)
    facter_output = {
        'stdout': b'',
        'stderr': b'',
        'rc': -1
    }

    class module_mock:
        def run_command(self, command):
            return facter_output['rc'], facter_output['stdout'], facter_output['stderr']

    facter_path = "/usr/bin/facter"

    facter_obj = FacterFactCollector()
    facter_rc, facter_out, facter_err = facter_obj.run_facter(module_mock(), facter_path)

    assert facter_rc == facter_output['rc']
    assert facter_out == facter_output

# Generated at 2022-06-23 00:23:43.201502
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = mock.Mock()
    module.run_command.return_value = (0, '{}', '')
    module.get_bin_path = mock.Mock()
    module.get_bin_path.return_value = "/usr/bin/facter"

    ffc = FacterFactCollector()
    assert ffc.collect() == {}


# Generated at 2022-06-23 00:23:52.028687
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts.utils import MockModule

    # Create mock module
    mock_module = MockModule()

    # Create our facter collector
    facter_collector = FacterFactCollector()

    # Test various situations
    facter_path = facter_collector.find_facter(mock_module)
    assert facter_path is None

    mock_module.bin_path = lambda program, opt_dirs=None: '/bin/' + program
    facter_path = facter_collector.find_facter(mock_module)
    assert facter_path == '/bin/facter'


# Generated at 2022-06-23 00:24:04.380787
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {'facter': '/usr/bin/facter'}
            self.bin_path = '/usr/bin/facter'

        def get_bin_path(self, path, opt_dirs=[]):
            return self.bin_path

    facter = FacterFactCollector()
    m = MockAnsibleModule()
    assert facter.find_facter(m) == '/usr/bin/facter'
    m.bin_path = '/opt/puppetlabs/bin/cfacter'
    assert facter.find_facter(m) == '/opt/puppetlabs/bin/cfacter'
    m.bin_path = '/opt/puppetlabs/bin/facter'
    assert fact

# Generated at 2022-06-23 00:24:10.470090
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    facter_facts = FacterFactCollector()
    assert facter_facts.name == 'facter'
    assert set(facter_facts.fact_ids) == set(['facter'])
    assert isinstance(facter_facts.namespace, PrefixFactNamespace)
    assert facter_facts.namespace.namespace_name == 'facter'
    assert facter_facts.namespace.prefix == 'facter_'

# Generated at 2022-06-23 00:24:18.244304
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    from ansible.module_utils.facts import namespace_loader

    fact_collector = namespace_loader.get('facter')
    assert isinstance(fact_collector, FacterFactCollector)
    assert set(fact_collector.fact_ids) == set(['facter'])
    assert fact_collector.namespace.namespace_name == 'facter'
    assert fact_collector.namespace.prefix == 'facter_'



# Generated at 2022-06-23 00:24:22.637812
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def __init__(self):
            self.params = {'facterbin': 'facter'}

        def run_command(self, args):
            if self.params['facterbin'] == 'facter':
                return 0, b'{"domain": "example.com", "fqdn": "foo.example.com"}', b''
            if self.params['facterbin'] == 'cfacter':
                return 0, b'{"foo": "bar", "baz": [ "baz1", "baz2" ]}', b''
            else:
                return 0, b'{"this_is": "json"}', b''


# Generated at 2022-06-23 00:24:33.380599
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import find_collector_classes

    class test_module:
        bin_path = None

        def get_bin_path(self, cmd, opt_dirs=None, required=False):
            return self.bin_path

        def run_command(self, *args, **kwargs):
            return 0, args[0], None

    collector_classes = find_collector_classes()
    facter_collectors = [c for c in collector_classes if c.name == 'facter']
    assert len(facter_collectors) == 1

    facter_collector = facter_collectors[0]()
    facter_collector.collectors = []

    # ensure a non-f

# Generated at 2022-06-23 00:24:44.935139
# Unit test for method get_facter_output of class FacterFactCollector

# Generated at 2022-06-23 00:24:56.142020
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def __init__(self, facter_path, out, err, rc):
            self.facter_path = facter_path
            self.out = out
            self.err = err
            self.rc = rc

        def get_bin_path(self, bin_name, opt_dirs=None):
            return self.facter_path

        def run_command(self, command):
            return self.rc, self.out, self.err

    # Happy path: facter exists and --json worked
    fac_collector = FacterFactCollector()
    facter_path = dict(bin_path='/path/to/facter')

# Generated at 2022-06-23 00:25:07.142248
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # first, try when facter_path is not found
    module_args = {
        'bin_path': None,
        'run_command': lambda *args, **kwargs: (False, None, None),
    }
    facter_collector = FacterFactCollector()
    rc, out, err = facter_collector.run_facter(module_args, 'facter_path')
    assert rc is None
    assert out is None
    assert err is None

    # then, try when facter_path is found
    module_args = {
        'bin_path': None,
        'run_command': lambda *args, **kwargs: (True, 'random_facts', ''),
    }
    facter_collector = FacterFactCollector()
    rc, out, err = facter_collector

# Generated at 2022-06-23 00:25:13.342137
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    data = b'{ "facterversion": "3.5.1", "virtual": "kvm" }'
    mock_module = dict()
    mock_module.run_command = lambda x: (0, data, b'')

    ff = FacterFactCollector()
    rc, out, err = ff.run_facter(mock_module, '/usr/bin/facter')

    assert rc == 0
    assert out == data

# Generated at 2022-06-23 00:25:24.227562
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from mock import patch

    class TestModule(object):
        def __init__(self):
            self.paths = []

        def get_bin_path(self, name, opt_dirs=None, required=False):
            for path in self.paths:
                if name in path:
                    return path
            return None

    with patch('ansible.module_utils.facts.collector.which') as which_mock:
        module = TestModule()
        which_mock.return_value = module
        facter_fact_collector = FacterFactCollector()

        module.paths = ['facter', '/usr/bin/facter']
        assert facter_fact_collector.find_facter(module) == '/usr/bin/facter'


# Generated at 2022-06-23 00:25:34.884783
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """Unit test for method run_facter of class FacterFactCollector"""
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts import ansible_module

    module = ansible_module
    facter_collector_object = FacterFactCollector()
    actual_return_value = facter_collector_object.run_facter(module, facter_collector_object.find_facter(module))

# Generated at 2022-06-23 00:25:38.512057
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance

    facter_collector = get_collector_instance('facter')

    facter_output = facter_collector.get_facter_output(None)

    assert facter_output is not None

# Generated at 2022-06-23 00:25:49.396090
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    mock_module = ansible.module_utils.facts.utils.get_mock_module()
    mock_module.get_bin_path.return_value = None

    facter_fact_collector = FacterFactCollector()
    result = facter_fact_collector.collect(module=mock_module)
    assert result == {}

    mock_module.get_bin_path.return_value = 'facter'
    mock_module.run_command.return_value = (0, '{}', '')
    facter_fact_collector = FacterFactCollector()

# Generated at 2022-06-23 00:25:52.181514
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    fact_collector = FacterFactCollector()
    assert fact_collector.name == 'facter'
    assert fact_collector._fact_ids == {'facter'}



# Generated at 2022-06-23 00:25:58.223435
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    facts_collector = get_collector_instance(
        get_collector_names()[0])
    facts_collector._module = MockModule()
    assert facts_collector.get_facter_output() is not None

# Mock class for module

# Generated at 2022-06-23 00:26:09.400353
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import collect_facts

    facter_dict = collect_facts(module=None)

    if facter_dict.get('facter'):
        import tempfile
        import shutil
        import os
        import json

        tempdir = tempfile.mkdtemp()
        tempfile_path = os.path.join(tempdir, 'facter')

        with open(tempfile_path, 'w+') as tempfile:
            facter_json = json.dumps(facter_dict.get('facter'))

            tempfile.write('#!/usr/bin/env python\n')
            tempfile.write('import json\n')
            tempfile.write('import sys\n')


# Generated at 2022-06-23 00:26:13.715772
# Unit test for constructor of class FacterFactCollector
def test_FacterFactCollector():
    ffc = FacterFactCollector()
    assert ffc.name == 'facter'
    assert ffc._fact_ids.__len__() == 1
    assert ffc._fact_ids.__contains__('facter')
    assert isinstance(ffc.namespace, PrefixFactNamespace)

# Generated at 2022-06-23 00:26:25.156499
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Test when facter is not found
    facter_coll = FacterFactCollector()
    assert facter_coll.get_facter_output(module) is None

    # Test when no facter output is returned
    def mock_module_run_cmd(cmd, check_rc=True, close_fds=True, executable=None, data=None):
        return 0, '', ''
    setattr(module, 'run_command', mock_module_run_cmd)

    facter_coll = FacterFactCollector()
    assert facter_coll.get_facter_output(module) is None

    # Test when facter output is returned

# Generated at 2022-06-23 00:26:32.585915
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command_failure = True

    ffc = FacterFactCollector(collectors=None, namespace=None)
    ffc.collect(module=mock_module, collected_facts=None)

    # AnsibleModule.run_command is called with 'facter --puppet --json'
    assert mock_module.run_command_failure == False
    assert mock_module.run_command_input[0] == 'facter --puppet --json'


# Generated at 2022-06-23 00:26:44.174744
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.utils import get_file_content

    test_values_facter_stdout = """
    {
      "facterversion": "1.7.4",
      "operatingsystem": "CentOS",
      "osfamily": "RedHat",
      "kernel": "Linux"
    }
    """

    test_values_facter_stdout_bad_json = """
    {
      "facterversion": "1.7.4",
      "operatingsystem": "CentOS",
      "osfamily": "RedHat",
      "kernel": "Linux"
    """

    os_path_exists_mock = Mock()
    os_path_exists_mock.configure_m

# Generated at 2022-06-23 00:26:52.942226
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import FacterFactCollector
    from ansible.module_utils.facts.collector import _get_module_object
    facter_collector = FacterFactCollector()
    module = _get_module_object('module_utils.facts.facter', 'Facter')
    facter_output = facter_collector.get_facter_output(module)
    facter_output_dict = json.loads(facter_output)
    facter_secondary_output = facter_collector.get_facter_output(mock_module)

mock_module = None
if __name__ == '__main__':
    test_FacterFactCollector_get_facter_output()