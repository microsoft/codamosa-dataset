

# Generated at 2022-06-11 03:46:25.091199
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collections import FactCollector

    # Helper class to access protected method _get_collector_class
    class CollectorTest(FactCollector):
        def _get_collector_class(self, name):
            return super(CollectorTest, self)._get_collector_class(name)

    # get_facter_output return None
    module = None
    collector_obj = CollectorTest()
    fact_collector = collector_obj._get_collector_class('facter')
    facter_obj = fact_collector(namespace='test')
    assert facter_obj.get_facter_output(module) is None

    # get_facter_output return facter_output
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 03:46:28.364143
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    m_module = FakeModule()
    c = FacterFactCollector()
    facter_path = c.find_facter(m_module)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-11 03:46:31.387778
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = FakeModule()
    facter_collector = FacterFactCollector()

    assert facter_collector.find_facter(module) == '/usr/bin/cfacter'


# Generated at 2022-06-11 03:46:41.999591
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''
    Unit test to test method find_facter of class FacterFactCollector.
    '''
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.namespace import GlobalFactNamespace
    from ansible.module_utils.facts.parser import get_parser

    module = get_parser()

    # Use a local version of the fact module.
    for collector in get_collectors(module):
        module.collectors.append(collector)

    global_ns = GlobalFactNamespace(module=module)

    facter_instance = module.collectors[0]

    assert facter_instance.find_facter(module) is None

    facter_instance.name = 'cfacter'

# Generated at 2022-06-11 03:46:51.352068
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile

    class MockFileWithFacter(MockFile):
        def collect(self, module, collected_facts=None):
            return "facter"

    # Create MockModule
    def get_bin_path(self, arg, opt_dirs=[]):
        return "facter"
    module = MockModule()
    module.get_bin_path = get_bin_path

    # Create MockFile

# Generated at 2022-06-11 03:47:01.777824
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a BaseFactCollector object
    BaseFactCollector.clear_cache()
    fact_collector = BaseFactCollector()

    # Create a FacterFactCollector object
    fact_collector.collectors = []
    fact_collector.namespace = PrefixFactNamespace(
        namespace_name='facter', prefix='facter_')
    fact_collector.collectors.append(
        FacterFactCollector(collectors=fact_collector.collectors,
                            namespace=fact_collector.namespace))
    # Create a fake module
    class FakeModule:
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-11 03:47:04.185571
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    r = FacterFactCollector()
    r.get_facter_output("127.0.0.1")


# Generated at 2022-06-11 03:47:12.745960
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    # Assign a new module object to module
    module = ansible.module_utils.facts.collector.ModuleStub()
    # Create a FacterFactCollector
    facter_collector = FacterFactCollector(module)
    # Set module.run_command to our stub method
    def run_command_stub(path):
        return None, None, None
    # module.run_command becomes a stub method
    module.run_command = run_command_stub
    # Get facter_output
    facter_output = facter_collector.get_facter_output(module)
    # Check that facter_output is None
    assert facter_output is None
    # Assign a new module object to module
    module = ansible.module_

# Generated at 2022-06-11 03:47:18.587880
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockModule:
        def get_bin_path(self, executable, opt_dirs=''):
            return '/usr/bin/facter'

    mock_module = MockModule()
    ff = get_collector_instance(FacterFactCollector)

    result = ff.find_facter(mock_module)
    assert result == '/usr/bin/facter'


# Generated at 2022-06-11 03:47:28.658231
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Create a test loader for a test module
    test_loader = BaseTestLoader()

    # Create a test module
    test_module = test_loader.load_module('ansible.module_utils.facts.system.facter_collector')

    # Create a test collector
    test_fact_collector = FacterFactCollector()

    # Test the case where facter is not in the path
    test_loader.bin_paths = []
    assert test_fact_collector.find_facter(test_module) is None

    # Test the case where facter is in the path
    test_loader.bin_paths = ['/usr/bin']
    assert test_fact_collector.find_facter(test_module) == '/usr/bin/facter'

    # Test the case where cfacter is in the path and

# Generated at 2022-06-11 03:47:40.294269
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    import tempfile
    from contextlib import contextmanager

    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch

    class MockAnsibleModule(object):

        @contextmanager
        def tempfile(self):
            yield tempfile.NamedTemporaryFile()

        @contextmanager
        def tempdir(self):
            yield tempfile.TemporaryDirectory()

        def run_command(self, *_):
            return 0, "", ""

        def get_bin_path(self, *paths):
            return None


# Generated at 2022-06-11 03:47:49.741475
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module:
        def __init__(self, run_command_return_value):
            self.run_command_return_value = run_command_return_value

        def get_bin_path(self, binary, opt_dirs):
            if binary == 'facter' or binary == 'cfacter':
                return '/opt/puppetlabs/bin/' + binary

            return None

        def run_command(self, cmd):
            return self.run_command_return_value

    # test_case_1: cfacter exists
    get_bin_path_index = 0
    def get_bin_path_func_1(a1, a2):
        if get_bin_path_index == 0:
            get_bin_path_index += 1
            return '/opt/puppetlabs/bin/cfacter'

# Generated at 2022-06-11 03:47:57.185890
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    '''
    Unit test for method collect of class FacterFactCollector
    '''
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.facts import Facts, get_shared_facts_instance
    fac_factcollector_instance = get_collector_instance('FacterFactCollector')
    facts = fac_factcollector_instance.collect()
    shared_facts_instance = get_shared_facts_instance()
    fac_factnamespace_instance = FactNamespace()
    fac_factnamespace_instance.name = 'facter'
    fac_factnamespace_instance._facts = facts

# Generated at 2022-06-11 03:47:58.902106
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    collector = FacterFactCollector()
    assert collector.find_facter(None) == None

# Generated at 2022-06-11 03:48:04.879472
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    facter_collector = FacterFactCollector()
    facts = facter_collector.collect(module=module)
    assert 'ansible_facter' not in facts
    assert 'facter_domain' in facts
    assert 'facter_os' in facts
    assert 'facter_os.distro.codename' in facts

# Unit test AnsibleModule

# Generated at 2022-06-11 03:48:08.921768
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = MockModule()
    facter_path = FacterFactCollector().find_facter(module)
    facter_output = FacterFactCollector().get_facter_output(module)
    assert facter_output
    assert '{"system_uptime":{"seconds":' in facter_output


# Generated at 2022-06-11 03:48:13.355382
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
  module = None
  collected_facts = None

  collector = FacterFactCollector(collectors=None, namespace=None)
  facter_dict = collector.collect(module, collected_facts)
  print("facter_dict = ", facter_dict)

if __name__ == '__main__':
  test_FacterFactCollector_collect()

# Generated at 2022-06-11 03:48:19.975676
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    fact_collector = FacterFactCollector()

    class ModuleMock:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

    assert fact_collector.find_facter(ModuleMock()) == '/usr/bin/cfacter'


# Generated at 2022-06-11 03:48:27.403309
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = AnsibleModuleMock()

    facter_path = '/usr/bin/facter'
    facter_output = '\n'.join((
        '{"operatingsystem":"CentOS","uptime_seconds":162493,"lsbdistcodename":"Core","osfamily":"RedHat"}',
    ))

    # Note: AnsibleModuleMock will return facter_path as the path to facter
    # when called with get_bin_path('facter', opt_dirs=['/opt/puppetlabs/bin'])
    # and will return facter_output when called with run_command(facter_path + " --puppet --json").
    #
    # It will return None if called with get_bin_path with any different arguments.
    #
    # We use that to mock facter and the facter

# Generated at 2022-06-11 03:48:32.177336
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    mock_module = Mock()
    mock_module.get_bin_path.return_value = None

    facts = FacterFactCollector()

    assert facts.get_facter_output(mock_module) is None
    mock_module.get_bin_path.assert_called_with('facter', opt_dirs=['/opt/puppetlabs/bin'])



# Generated at 2022-06-11 03:48:40.631690
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class FakeModule(object):
        def get_bin_path(self, bin_name, opt_dirs=None):
            return bin_name

    module = FakeModule()
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == "facter"


# Generated at 2022-06-11 03:48:49.695754
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    """Test that get_facter_output return a string when facter is installed"""
    facter = FacterFactCollector()

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=None):
            """Return a path to a fake facter"""
            return self.bin_path

        def run_command(self, executable):
            """Return a mocked facter output"""
            return 0, '{ "test_facter_fact": "test_facter_fact_value" }', ''

    mock_facter = MockModule('/usr/bin/facter')
    facter_output = facter.get_facter_output(mock_facter)
    assert facter_output

# Generated at 2022-06-11 03:48:58.811659
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create a instance of FacterFactCollector
    facter_fact_collector = FacterFactCollector()

    # Create a fake module so we can call find_facter
    class module_mock:
        def run_command(self, command_list):
          self.command_list = command_list
          return 0, output, ""

        def get_bin_path(self, bin_name, opt_dirs=None):
            return '/opt/puppetlabs/bin/facter'

    # Create a module mock instance
    module_mock_instance = module_mock()

    # Call find_facter.
    facter_path = facter_fact_collector.find_facter(module_mock_instance)

    # Validate the facter path returned is the expected one.
    assert facter_

# Generated at 2022-06-11 03:49:07.669238
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def __init__(self):
            self.run_command_errors = []
            self.run_command_results = []
            self.get_bin_path_results = []

        def run_command(self, cmd):
            self.run_command_results.append(cmd)
            if len(self.run_command_errors) > 0:
                return self.run_command_errors.pop(0)
            return self.run_command_results.pop(0)

        def get_bin_path(self, cmd, opt_dirs):
            if len(self.get_bin_path_results) > 0:
                return self.get_bin_path_results.pop(0)
            return None


# Generated at 2022-06-11 03:49:16.806134
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    paths = [
        '/opt/puppetlabs/bin/cfacter',
        '/opt/puppetlabs/bin/facter',
        '/usr/bin/facter',
    ]

    class ModuleMock:
        def get_bin_path(self, executable, opt_dirs=None):
            for executablePath in paths:
                if executable in executablePath:
                    return executablePath
            return None

    class AnsibleModuleMock:
        def __init__(self, argument_spec):
            pass
        def get_bin_path(self, executable, opt_dirs=None):
            for executablePath in paths:
                if executable in executablePath:
                    return executablePath
            return None
        def run_command(self, command):
            return


# Generated at 2022-06-11 03:49:21.172244
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    obj = FacterFactCollector()
    class FakeModule():
        def get_bin_path(self, *args, **kwargs):
            return '/opt/puppetlabs/bin/facter'
    module = FakeModule()
    result = obj.find_facter(module)
    assert result == '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-11 03:49:30.907112
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    from ansible.module_utils.facts import ansible_collections
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    MOCK_COLLECTION = 'acme.collections.mock'
    MOCK_COLLECTION_PATH = '%s.%s' % (ansible_collections, MOCK_COLLECTION)

    TEST_DATA = {
        'ansible_facter': json.loads('{"facterversion": "3.11.2", "kernel": "Linux"}'),
        'facter_facterversion': '3.11.2',
        'facter_kernel': 'Linux'
    }

    class ModuleMock():

        def __init__(self):
            self.params = {}
            self.paths = {}


# Generated at 2022-06-11 03:49:32.513040
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    Test for FacterFactCollector.collect
    """
    assert False


# Generated at 2022-06-11 03:49:34.216679
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    res = FacterFactCollector.collect()

    assert '{}' == res



# Generated at 2022-06-11 03:49:45.349686
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile

    # An empty module, so we do not require any imports
    module = MockModule()
    module.returnValues = {
        'get_bin_path': (
            (['facter', '/opt/puppetlabs/bin'], None),
            (['cfacter', '/opt/puppetlabs/bin'], '/opt/puppetlabs/bin/cfacter'),
        )
    }

    # Our fake cfacter path
    fake_path = '/opt/puppetlabs/bin/cfacter'

    # Now instantiate our class
    ffc = FacterFactCollector()
    assert ffc.find_facter(module) == fake_path

    # No cfacter,

# Generated at 2022-06-11 03:50:03.524997
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-11 03:50:08.255539
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import FactsCollector

    facter = FacterFactCollector()
    module = AnsibleModule(argument_spec=dict())

    facter_path = facter.find_facter(module)
    assert facter_path is not None
    assert facter_path.endswith('facter') or facter_path.endswith('cfacter')

# Generated at 2022-06-11 03:50:17.348986
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import CollectorsFactory
    from ansible.module_utils.facts.utils import get_file_content

    class DummyModule(object):
        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/facter"

        def run_command(self, facter_path):
            return 0, get_file_content(__file__, "facter-output.json"), ''

    class DummyCollectorsFactory(CollectorsFactory):
        def _get_collector_classes(self):
            return [FacterFactCollector]

        def _create_collectors(self, namespaces):
            return self.collectors

    factory = DummyCollectorsFactory()
    collectors = factory.create_collectors()

    facter_fact_collector

# Generated at 2022-06-11 03:50:25.961526
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts
    import ansible.module_utils.facts.system
    from ansible.module_utils.facts.system.facter import FacterFactCollector

    class MockModule(object):
        def __init__(self):
            self.called = 0
            self.params = {}

        def get_bin_path(self, name, opt_dirs=None):
            self.called += 1
            return True

        def run_command(self, name):
            self.called += 1
            return True, '{}', ''

    # Preconditions

# Generated at 2022-06-11 03:50:31.801932
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class MockModule(object):
        def __init__(self):
            self.run_command = None

        def get_bin_path(self, path, opt_dirs=[]):
            if path == 'facter':
                self.run_command = self.run_command_facter
            elif path == 'cfacter':
                self.run_command = self.run_command_cfacter

            if path == 'facter' or path == 'cfacter':
                return path

            return None

        def run_command_facter(self, command):
            if command == 'facter --puppet --json':
                return 0, json.dumps({'facter': '1.0'}), ''


# Generated at 2022-06-11 03:50:41.805824
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # set up mock module
    module_mock = ansible.module_utils.basic.AnsibleModule(
        argument_spec={}
    )

    module_mock.get_bin_path = Mock(return_value=True)
    module_mock.run_command = Mock(return_value=(
        0,
        json.dumps({"somefact": "somevalue"}),
        ""))

    # set up mock collecter
    collecter_mock = FacterFactCollector(
        collectors=None,
        namespace=None
    )

    collecter_mock.find_facter = Mock(return_value=True)

    facter_results = collecter_mock.collect(module_mock)
    assert facter_results['somefact'] == "somevalue"

# Generated at 2022-06-11 03:50:47.078394
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    fake_module = type('', (object,), {'get_bin_path': get_bin_path, 'run_command': run_command})

    case_no_facter_path = {'get_bin_path': None, 'run_command': (0, '', '')}

    case_facter_exists = {'get_bin_path': '/usr/bin/facter', 'run_command': (0, '', '')}

    cases = [case_no_facter_path, case_facter_exists]

    for case in cases:
        facter_collector = FacterFactCollector()
        assert facter_collector.get_facter_output(fake_module(case)) is None


# Generated at 2022-06-11 03:50:56.951351
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import mock
    import unittest

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs


        def get_bin_path(self, name, opt_dirs=[]):
            if self.params['fail_bin_path']:
                return None
            else:
                return self.params['fake_bin_path']


        def run_command(self, cmd):
            return self.params['fake_rc'], self.params['fake_out'], self.params['fake_err']



# Generated at 2022-06-11 03:51:04.321291
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_collector = FacterFactCollector(namespace=None)

    class FakeModule(object):
        """Fake module used for testing"""
        def __init__(self):
            self.bin_path = '/usr/bin:/bin'

        def get_bin_path(self, name, opt_dirs, required=False):
            if name == 'facter':
                return '/bin/facter'
            else:
                return None

    module = FakeModule()

    facter_path = facter_collector.find_facter(module)
    assert facter_path == '/bin/facter'

    module.get_bin_path = lambda name, opt_dirs, required: None
    facter_path = facter_collector.find_facter(module)
    assert facter_path is None



# Generated at 2022-06-11 03:51:14.185290
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils._text import to_bytes

    testModule = TestModule()
    facter_collector = FacterFactCollector([], namespace=None)
    testModule.run_command = lambda args, kwargs: (0, to_bytes('{"fact1": "value1", "fact2": "value2"}'), None)
    facter_output = facter_collector.get_facter_output(testModule)

    assert facter_output == '{"fact1": "value1", "fact2": "value2"}'

    testModule.run_command = lambda args, kwargs: (1, None, None)
    facter_output = fact

# Generated at 2022-06-11 03:51:39.178753
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Define some useful variables
    FactCollector = FacterFactCollector()
    ansible_facts = {}
    ansible_facts['ansible_local'] = {}
    ansible_facts['ansible_local']['facter_path'] = "/usr/bin/facter"
    ansible_facts['ansible_local']['facter_output'] = "{\"facter_collection\":{}}"
    # Call the collect method of the FacterFactCollector to get the fact
    facter_dict = FactCollector.collect(ansible_facts)
    assert facter_dict == {"facter_collection": {}}


# Generated at 2022-06-11 03:51:45.739796
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module():
        def __init__(self):
            class BinInfo():
                def __init__(self, return_value):
                    self.bin_path = return_value
            # returns path for facter
            self.get_bin_path = lambda directory, opt_dirs: BinInfo(directory)
            # runs facter
            self.run_command = lambda facts: (0, json.dumps({'osfamily': 'RedHat'}), '')

    m = Module()
    fc = FacterFactCollector()
    output = fc.get_facter_output(m)
    assert output is not None

# Generated at 2022-06-11 03:51:54.621720
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    ffc = FacterFactCollector()

    class MockModule:
        def __init__(self, module_name='setup'):
            self.module_name = module_name

        def run_command(self, cmd, args='', check_rc=True):
            if cmd == 'which puppet':
                return 0, '/usr/bin/puppet', ''
            elif cmd == '/usr/bin/puppet config print bindir':
                return 0, '/opt/puppet/bin', ''
            else:
                return 1, '', ''


# Generated at 2022-06-11 03:51:59.091407
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeModule:
        def __init__(self):
            self.rc = 0
            self.out = 'fake_output'
            self.err = 'fake_err'

        def get_bin_path(self, prog, opt_dirs=None):
            return prog

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class FakeAnsibleModule:
        def __init__(self):
            self.facts = dict()

        def exit_json(self, ansible_facts=dict(), *args, **kwargs):
            self.facts = ansible_facts

    module = FakeModule()
    f = FacterFactCollector()
    f.run_facter = lambda m, p: (module.rc, module.out, module.err)

# Generated at 2022-06-11 03:52:04.370204
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_fact_collector = FacterFactCollector()

    class ModuleMock:
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/opt/puppetlabs/bin/facter'

    assert facter_fact_collector.find_facter(ModuleMock) == '/opt/puppetlabs/bin/facter'



# Generated at 2022-06-11 03:52:12.213048
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors

    # Mock module
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            return '/bin/' + name

        def run_command(self, command):
            return 0, json.dumps({"kernel": "Linux"}), None

    # Mock ansible.module_utils.facts.collectors.FacterFactCollector
    class FactCollector(ansible.module_utils.facts.collectors.FacterFactCollector):
        def __init__(self, *args, **kwargs):
            super(FactCollector, self).__init__(*args, **kwargs)

        def find_facter(self, module):
            return module.get_

# Generated at 2022-06-11 03:52:21.644271
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import sys
    import unittest
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import timeout

    class TestModule:
        def __init__(self):
            self.params = dict()
            self.args = dict()
        def get_bin_path(self, arg, opt_dirs):
            return '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-11 03:52:29.299848
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import TestModuleUtils
    from ansible.module_utils import basic

    class TestModule(basic.AnsibleModule, TestModuleUtils):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(argument_spec={})
            self.base_dir = None

        def get_bin_path(self, arg, opt_dirs=[]):
            return None

    tmodule = TestModule()
    assert None == FacterFactCollector(collectors=[]).find_facter(tmodule)

    tmodule = TestModule()
    tmodule.get_bin_path = lambda a, b: None

# Generated at 2022-06-11 03:52:34.906566
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class TestModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/facter'

    def test_find_facter_called_with_module(facter):
        assert facter.find_facter(TestModule()) == '/bin/facter'

    facter = FacterFactCollector()
    test_find_facter_called_with_module(facter)


# Generated at 2022-06-11 03:52:45.189953
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Arrange
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import get_module_instance
    import mock

    facter_collector_instance = get_collector_instance('facter')
    facter_collector_instance._fact_ids = set(['facter'])

    # mock a module object
    mock_module = mock.MagicMock()

    # mock up facts.get_module_instance()
    mock_module_inst = mock.MagicMock(
        get_bin_path=mock.MagicMock(return_value='/usr/bin/facter')
    )

    get_module_instance.return_value = mock_module_inst

    # mock up to run_command()
    mock_module.run_command

# Generated at 2022-06-11 03:53:36.094939
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule:
        def __init__(self):
            self.module_args = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'cfacter':
                return "/opt/puppetlabs/bin/facter"
            elif arg == 'facter':
                return "/usr/bin/facter"
            else:
                return None

    module = MockModule()
    collector = FacterFactCollector()
    assert collector.find_facter(module) == "/opt/puppetlabs/bin/facter"


# Generated at 2022-06-11 03:53:38.238085
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Create a mock module that will return False for all commands
    module = MockModule()

    # Create a mock fact collector with the c

# Generated at 2022-06-11 03:53:44.324845
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import __builtin__
    class FakeModule():
        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/usr/bin/facter'
            elif executable == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    ff = FacterFactCollector()
    assert ff.find_facter(FakeModule()) == '/opt/puppetlabs/bin/cfacter'



# Generated at 2022-06-11 03:53:52.924325
# Unit test for method get_facter_output of class FacterFactCollector

# Generated at 2022-06-11 03:54:01.815490
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.utils import ModuleFacts, get_collector_instance
    class MockModule:
        def __init__(self):
            self.params = {
                'bin_path': '/opt/puppetlabs/bin'
            }

        def get_bin_path(self, path, opt_dirs=None):
            return '/opt/puppetlabs/bin/facter'

        def run_command(self, command):
            return 0, '{"kernel": "Linux", "fqdn": "myfqdn.com"}', ''

    module = MockModule()
    fact_collector = get_collector_instance('facter', module)

    # get_facter_output() should return the output of facter command

# Generated at 2022-06-11 03:54:08.229234
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    test_module = MagicMock()
    facter_path = '/opt/puppetlabs/bin/facter'
    test_module.get_bin_path.return_value = facter_path
    test_module.run_command.return_value = (0, b'{"test": "test_facts"}', '')
    test_collector = FacterFactCollector()

    rc, out, err = test_collector.run_facter(test_module, facter_path)

    assert(rc == 0)
    assert(out == b'{"test": "test_facts"}')
    assert(err == '')


# Generated at 2022-06-11 03:54:11.139478
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    collected_facts = None
    fc = FacterFactCollector()
    assert fc.collect(module, collected_facts) == {}

# Generated at 2022-06-11 03:54:19.346641
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collectors.facter as facter
    import ansible.module_utils.facts.collectors.network as network
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ModuleFactCollector

    class MyModule(basic.AnsibleModule):

        def __init__(self, *args, **kwargs):
            basic.AnsibleModule.__init__(self, *args, **kwargs)

        def get_bin_path(self, cmd, opt_dirs=None):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_processor0": "AMD A6-5400B APU with Radeon(tm) HD Graphics"}', ''

    collector = facter.Facter

# Generated at 2022-06-11 03:54:24.902904
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector

    load_collector = ansible.module_utils.facts.collector.load_collectors


    module = basic.AnsibleModule(argument_spec={})
    module.run_command = basic.AnsibleModule.run_command

    collectors_list = load_collector(module)

    assert module.run_command == basic.AnsibleModule.run_command
    assert 'facter' in [collector.name for collector in collectors_list]

# Generated at 2022-06-11 03:54:32.878721
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # If the facts collector is made with no params then it should use the default
    # module path and default module glob
    facts = FactCollector(None)

    # Test no results
    assert facts.find_facter('/usr/bin', ['does-not-exist']) == None

    # Test finding the first command in the path
    assert facts.find_facter('/usr/bin', ['ls', 'date']) == '/usr/bin/ls'

    # Test with a sub path
    assert facts.find_facter('/usr/bin:/bin', ['ls', 'date']) == '/usr/bin/ls'

    # Test with a multi path
    assert facts.find_facter(['/bin', '/usr/bin'], ['ls', 'date']) == '/bin/ls'

# Generated at 2022-06-11 03:56:09.663061
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'
        def run_command(self, facter_path):
            return 0, b'{"a": "b"}', None
    mock_module = MockModule()
    facter_fact_collector.get_facter_output(mock_module)

# Generated at 2022-06-11 03:56:16.690517
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    module, have_facter, facter_dict = (None, None, None)

    def find_facter(module):
        if have_facter:
            return '/usr/bin/facter'
        else:
            return None

    def run_facter(module, facter_path):
        if have_facter:
            facter_output = json.dumps(facter_dict)
            return 0, facter_output, None
        else:
            return 1, None, None

    with FactsCollector() as collectors:
        # Test with have_facter == True
        have_facter = True