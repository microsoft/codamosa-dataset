

# Generated at 2022-06-11 03:46:26.833807
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    class MockModule(object):
        def __init__(self, bin_path=None):
            self._bin_path = bin_path

        def get_bin_path(self, *args, **kwargs):
            return self._bin_path

        def run_command(self, cmd):
            self.cmd = cmd
            return 0, '', ''

    # test with facter 2.x
    module_1 = MockModule(bin_path='/usr/bin/facter')
    facter_cmd = '  /usr/bin/facter  --puppet  --json '
    fact_collect = FacterFactCollector()
    fact_collect.run_facter(module_1, '/usr/bin/facter')

# Generated at 2022-06-11 03:46:30.366947
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = MockModule(path=['/usr/bin'])
    facter = FacterFactCollector()
    facter_path = facter.find_facter(module)
    assert facter_path == '/usr/bin/facter'


# Generated at 2022-06-11 03:46:40.299227
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils import basic

    _ansible_module = basic.AnsibleModule(argument_spec={})

    _ansible_module.run_command = lambda *args, **kwargs: (0, '{"test": "test"}', '')

    _ansible_module.get_bin_path = lambda *args, **kwargs: '/bin/facter'

    _ansible_module.get_distribution = lambda *args, **kwargs: 'Ubuntu'

    facter = FacterFactCollector()

    assert facter.get_facter_output(_ansible_module) == '{"test": "test"}'

    assert facter.collect(_ansible_module) == {'test': 'test'}

# Generated at 2022-06-11 03:46:50.065592
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    """
    Method find_facter of class FacterFactCollector
    """

    from ansible.module_utils.facts import Module
    from ansible.module_utils import common
    from ansible.module_utils.facts.collector import AnsibleCollector

    am = AnsibleCollector(module=Module())
    ns = am.get_namespace(ns_name='test')
    ffc = FacterFactCollector(namespace=ns)
    facter_path = '/opt/puppetlabs/bin'
    cfacter_path = '/opt/puppetlabs/bin'

    common.IS_HAS_OPT_DIRS = True
    ffc.get_bin_path = lambda x, opt_dirs=None: facter_path
    common.IS_HAS_OPT_DIRS = False

# Generated at 2022-06-11 03:47:00.084875
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # empty module
    class TestModule():
        def __init__():
            pass

    # empty module
    module = TestModule()
    """
    # test case 1: None
    module = TestModule()
    module.run_command = lambda x: (0, None, None)
    ff = FacterFactCollector()
    assert ff.get_facter_output(module) == None
    """

    # test case 2: empty
    module = TestModule()
    module.run_command = lambda x: (0, '', '')
    ff = FacterFactCollector()
    assert ff.get_facter_output(module) == None

    # test case 3: empty
    module = TestModule()
    module.run_command = lambda x: (1, '', '')
    ff = FacterFactCollector()

# Generated at 2022-06-11 03:47:10.170420
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    Test to ensure that FacterFactCollector.collect() returns expected data
    """

# Generated at 2022-06-11 03:47:20.206264
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    myFacter = FacterFactCollector()
    myFacter.find_facter = lambda x: 'facter'
    myFacter.run_facter = lambda x, y: (0, '{"facter_dummy":"dummy"}', '')

    # TODO: There is no way to unit test the whole code if we need to pass a real AnsibleModule.
    #       The ideal scenario here would be to mock the AnsibleModule.
    #       We could use the ansible.module_utils.facts.namespace or ansible.module_utils.facts.collector classes
    #       to achieve this, but it would require refactoring the code to be able to pass an AnsibleModule.
    #       It's not a unit test for the FacterFactCollector class, but a unit test for the whole method collect.
    result = my

# Generated at 2022-06-11 03:47:26.334373
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    module = MagicMock()
    facter_path = '/usr/bin/facter'

    module.get_bin_path.return_value = facter_path

    collector = FacterFactCollector()

    assert collector.find_facter(module) == facter_path

    # test what happens when facter not installed
    module.get_bin_path.return_value = None
    assert collector.find_facter(module) is None



# Generated at 2022-06-11 03:47:35.348274
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import sys
    import mock
    import tempfile
    import os

    try:
        # Python 3
        from io import StringIO
    except ImportError:
        # Python 2
        from StringIO import StringIO

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFileWriteCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.facts import FactNamespace
    from ansible.module_utils.facts.facts import CachingFileWriteFactNamespace
    from ansible.module_utils.facts.facts import PrefixFactNamespace
    from ansible.module_utils.facts import namespace_manager

# Generated at 2022-06-11 03:47:42.489741
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module(object):
        def __init__(self):
            self.params = {}
            self.bin_path = None

        def get_bin_path(self, facter, opt_dirs=None):
            if self.bin_path is None:
                return None
            return self.bin_path

        def run_command(self, command):
            return self.rc, self.out, self.err

    class Collector(object):
        def __init__(self, module=None, collected_facts=None):
            self.module = module
            self.collected_facts = collected_facts

    class Collectors(object):
        def __init__(self, collectors=None):
            self.collectors = collectors

        def __iter__(self):
            return iter(self.collectors)


# Generated at 2022-06-11 03:47:54.421218
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import ModuleUtilsLegacyFacts
    import ansible.module_utils.facts.collector
    import os

    test_file = os.path.join(os.path.dirname(__file__), 'FacterFactCollector.test_find_facter')


# Generated at 2022-06-11 03:48:03.574639
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    facter_dict = {}

    facter_output = '{"aio_agent_version":"2.2.0","facterversion":"3.3.0"}'

    def run_facter_mock(facter_path):
        rc = 0
        out = facter_output
        err = ''
        return rc, out, err

    # mock TestableFacterFactCollector
    class TestableFacterFactCollector(FacterFactCollector):
        def run_facter(self, facter_path):
            return run_facter_mock(facter_path)

    # test when facter_output is not None
    tffc = TestableFacterFactCollector()
    facter_dict = tffc.collect(module)
    assert facter_dict['facterversion']

# Generated at 2022-06-11 03:48:13.309963
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.system.facter import FacterFactCollector 
    from ansible.module_utils.facts.system.base import BaseFactCollector
    import os
    import sys

    class FakeModule:

        def __init__(self, collect_default=None):
            if collect_default is None:
                collect_default = {}

            if sys.version_info[0] >= 3 and isinstance(collect_default, bytes):
                collect_default = collect_default.decode('utf-8')

            self.collect_default = collect_default

        def run_command(self, facter_path):
            print(facter_path)
            return 0, json.dumps({'foo' : 'bar', 'baz' : 'blah'}), None


# Generated at 2022-06-11 03:48:23.183107
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def __init__(self, rslt):
            self._rslt = rslt

        def get_bin_path(self, binary, opt_dirs=None):
            return self._rslt

        def run_command(self, cmd):
            return self._rslt

    # test facter not found
    test_module = MockModule(None)
    test_collector = FacterFactCollector()
    assert test_collector.get_facter_output(test_module) == None

    # Test cfacter not found
    test_module = MockModule('facter')
    assert test_collector.get_facter_output(test_module) == None

    # Test facter run error
    test_module = MockModule('facter')
    assert test_collector.get_facter

# Generated at 2022-06-11 03:48:25.339306
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = MockModule()
    collector = FacterFactCollector()
    assert collector.find_facter(module) == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-11 03:48:34.705739
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import tempfile
    from ansible.utils.path import unfrackpath

    # Create a temporary directory to simulate a module_utils dir
    tempdir = tempfile.mkdtemp()
    facter_location = tempdir + '/facter'

    with open(facter_location, 'w') as f:
        f.write('''#!/usr/bin/python

print "{"
print "\"facter_architecture\": \"x86_64\","
print "\"facter_domain\": \"corp.ansible.com\""
print "}"
''')

    module_args = dict(
        _ansible_tmpdir=unfrackpath(tempdir),
        _ansible_no_log=True,
    )

    from ansible.module_utils.facts.collector import AnsibleModule

# Generated at 2022-06-11 03:48:44.155184
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, out, err="", rc=0):
            self.out = out
            self.rc = rc

        def get_bin_path(self, exe, opt_dirs=None, required=False):
            return exe

    # find_facter should return the cfacter binary if it exists
    cfacter_module = FakeModule('/bin/cfacter')
    facter_module = FakeModule('/bin/facter')


# Generated at 2022-06-11 03:48:49.110602
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    module = ansible.module_utils.facts.system.SystemFactCollector.get_module()

# Generated at 2022-06-11 03:48:52.218324
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = MockModule()
    collector = FacterFactCollector()
    facter_output = collector.get_facter_output(module)
    assert facter_output == '{"a": true, "b": false}'


# Generated at 2022-06-11 03:49:01.009889
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import namespace_manager

    # Use a real AnsibleModule object
    module = AnsibleModule(argument_spec={})

    # Create mock class for method get_bin_path
    class MockModule(object):
        def get_bin_path(self, binary, opt_dirs=[]):
            return "/usr/bin/facter"

        def run_command(self, facter_cmd):
            if facter_cmd == "/usr/bin/facter --puppet --json":
                rc = 0

# Generated at 2022-06-11 03:49:12.564540
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    f = FacterFactCollector()
    ansible_module_instance = AnsibleModuleStub()
    facter_output = f.get_facter_output(ansible_module_instance)
    assert facter_output is not None
    facter_dict = f.collect(ansible_module_instance)
    assert facter_dict is not None
    assert 'domains' in facter_dict
    assert 'networking' in facter_dict
    assert 'ipaddress' in facter_dict
    assert 'fqdn' in facter_dict


# Generated at 2022-06-11 03:49:18.442389
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    test_facter_facts_data = """
        {
            "facter_name_of_fact": "value of fact",
            "another_facter_fact": "value of another fact"
        }
    """

    def fake_facter_executable(module):
        class MockPopen(object):
            def __init__(self, cmd, **kwargs):
                pass


# Generated at 2022-06-11 03:49:28.567967
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import collections
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts
    import ansible.module_utils

    collector = FacterFactCollector()

    # Mock a module
    module = collections.namedtuple('module', ['run_command', 'get_bin_path'])

    # Mock get_bin_path method of module
    def get_bin_path(na, opts):
        if na == 'facter':
            return '/usr/bin/facter'
        else:
            return None

    # Mock run_command method of module
    def run_command(na):
        return 0, '', ''

    module.run_command = run_command
    module.get_bin_path = get_bin_path

    result = collector.find_facter(module)



# Generated at 2022-06-11 03:49:37.764529
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    test_facter_path = '/opt/puppetlabs/puppet/bin/facter'
    test_cfacter_path = '/opt/puppetlabs/puppet/bin/cfacter'
    module = MockModule()

    # There is neither a facter nor a cfacter command, so the default is a
    # none return
    module.commands.update({
        'which facter': None,
        'which cfacter': None
    })
    fact_module = FacterFactCollector(module)
    assert fact_module.find_facter(module) is None

    # There is a cfacter command, so we expect the cfacter path
    module.commands.update({
        'which facter': None,
        'which cfacter': test_cfacter_path
    })
    fact_module = Facter

# Generated at 2022-06-11 03:49:48.385177
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module(object):
        class Run_Command_Error(Exception):
            pass

        @staticmethod
        def get_bin_path(command=None, opt_dirs=None, required=True):
            if command == 'facter':
                return 'bin/facter'
            elif command == 'cfacter':
                return None

        @staticmethod
        def run_command(command=None):
            raise Module.Run_Command_Error('oops')

    class MyFacterFactCollector(FacterFactCollector):
        def __init__(self, collectors=None, namespace=None):
            super(MyFacterFactCollector, self).__init__(collectors, namespace)

        def run_facter(self, module, facter_path):
            if facter_path == 'bin/facter':
                return

# Generated at 2022-06-11 03:49:51.970295
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    collector = FacterFactCollector()
    module_mock = Mock()
    module_mock.run_command().return_value = (0, '{"system_uptime_days": 5, "gid": 0, "uptime_seconds": 6718}', '')
    facter_dict = collector.collect(module_mock)
    assert facter_dict == {
        'facter_system_uptime_days': 5,
        'facter_gid': 0,
        'facter_uptime_seconds': 6718
        }


# Generated at 2022-06-11 03:50:01.507788
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # This parameter is not used by this method.
    collected_facts = {}
    # Module definition
    module = AnsibleModule(argument_spec=dict())
    # Fake method return value, used for testing purpose
    module.run_command = MagicMock(return_value=(0, "{\"facter\": {\"test\": \"test\"}}", "test"))
    # Fake method return value, used for testing purpose
    module.get_bin_path = MagicMock(return_value=True)
    # FactCollector instanciation
    facter_collector = FacterFactCollector()
    # Method collect execution
    module_facts = facter_collector.collect(module=module, collected_facts=collected_facts)
    assert module_facts['facter'] is not None
    assert module_facts['facter']['test']

# Generated at 2022-06-11 03:50:04.152933
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    FFC = FacterFactCollector()
    FFC.collect()

if __name__ == '__main__':
    test_FacterFactCollector_collect()

# Generated at 2022-06-11 03:50:09.739343
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import mock
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    module_mock = mock.MagicMock()

    facter_path = FacterFactCollector().find_facter(module_mock)
    rc, out, err = FacterFactCollector().run_facter(module_mock, facter_path)

    assert rc == 0
    assert out is not None
    assert err is not None

# Generated at 2022-06-11 03:50:10.817929
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass


# Generated at 2022-06-11 03:50:29.625000
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create an instance of FacterFactCollector class
    facter_fact_collector = FacterFactCollector()

    # Create a class type object which represents the ansible module
    class ModuleMock:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=None):
            # Return facter binary path if the executable is facter
            if executable == "facter":
                return "/usr/bin/facter"

            return None

        def run_command(self, command):
            # Return valid JSON if the command is valid
            if command == "/usr/bin/facter --puppet --json":
                return 0, "{\"test\": \"success\"}", ""

            # Return valid JSON via cfacter if the command is valid

# Generated at 2022-06-11 03:50:34.648446
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Patch get_bin_path function to return various values
    # and verify that find_facter behaves as expected.
    # It should return the path for cfacter binary if it is present.
    # Otherwise, it should return the path for facter binary if that is present.
    # And if neither of those exist, it should return None.

    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    facter_collector = FacterFactCollector(namespace=PrefixFactNamespace(namespace_name='facter',
                                                                      prefix='facter_'))

    # Mock module
    import mock

    module = mock.Mock()

    # Case 1: Check both binaries are present
    module.get_

# Generated at 2022-06-11 03:50:39.299020
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    facter_collector = get_collector_instance(FacterFactCollector)

    assert facter_collector.find_facter(BaseFactCollector) is None



# Generated at 2022-06-11 03:50:48.887851
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import tempfile
    import os
    import sys
    # TO FIX: This try-catch hack is needed to use the same test in ansible-test and ansible
    try:
        from ansible.module_utils.facts.collector.python_distribution import PythonDistribution
    except ImportError:
        from ansible.module_utils.facts.python_distribution import PythonDistribution
    try:
        from ansible.module_utils.facts.collector.distribution import Distribution
    except ImportError:
        from ansible.module_utils.facts.distribution import Distribution
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    from ansible.module_utils.six import BytesIO, StringIO

# Generated at 2022-06-11 03:50:53.829610
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_path = '/usr/bin/facter'
    cfacter_path = '/usr/bin/cfacter'
    module = MockModule(PATH_INFO=facter_path + ":" + cfacter_path)
    collector = FacterFactCollector()
    test_result = collector.find_facter(module)
    assert test_result == cfacter_path


# Generated at 2022-06-11 03:50:59.203199
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule:
        @staticmethod
        def get_bin_path(bin_name, opt_dirs=None):
            if bin_name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            elif opt_dirs == ['/opt/puppetlabs/bin'] and bin_name == 'facter':
                return '/opt/puppetlabs/bin/facter'
            return None

    facter_path = '/opt/puppetlabs/bin/cfacter'
    module = MockModule()
    ff = FacterFactCollector()
    assert ff.find_facter(module) == facter_path


# Generated at 2022-06-11 03:51:05.973313
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceManager
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    NM = NamespaceManager()

    class MockFacterModule():
        def __init__(self):
            self._paths = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name in self._paths:
                return self._paths[name]
            else:
                return None


# Generated at 2022-06-11 03:51:16.021490
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import ModuleCollector

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.test.test_namespace import FakeModule

    def fake_run_facter(module, facter_path):
        return 0, "{ \"a_fact\": \"value\" }", ""

    m = FakeModule()
    m._module = m

    # Monkeypatch run_facter
    FacterFactCollector.run_facter = fake_run_facter

    # For this test, we will collect directly, rather than through the ModuleCollector
    # We must register ourselves, since the ModuleCollect

# Generated at 2022-06-11 03:51:23.882268
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import FactCollector, ModuleUtilsLegacy
    import os
    import sys

    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts import ModuleUtilsLegacy

    module = FactCollector.module
    module.run_command = MagicMock(return_value=(0, '', ''))

    facter_path = FacterFactCollector.find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/facter'

    # If we cannot find facter, None is returned
    module.run_command = MagicMock(return_value=(1, '', ''))
    facter_path = FacterFactCollector.find_facter(module)
    assert facter_path is None

# Generated at 2022-06-11 03:51:29.273151
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = ModuleStub()
    facter_collector = FacterFactCollector()
    facter_collector.find_facter = lambda module: True
    facter_collector.run_facter = lambda module, facter_path: (0, '{"some": "output"}', '')

    assert facter_collector.get_facter_output(module) == '{"some": "output"}'


# Generated at 2022-06-11 03:51:59.970036
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = MagicMock()
    facter_path = 'facter_path'
    result_facter = "b'{\"kernel\": \"Linux\", \"osfamily\": \"RedHat\"}'"
    module.run_command.return_value = 0, result_facter, ''

    facter_fact_collector = FacterFactCollector()
    facter_fact_collector._collectors = None
    facter_fact_collector._namespace = None

    # Test for puppet facts
    result_rc, result_out, result_err = facter_fact_collector.run_facter(module, facter_path)
    module.run_command.assert_called_once_with('facter_path --puppet --json')
    assert result_rc == 0
    assert result_out == result_facter
   

# Generated at 2022-06-11 03:52:04.464668
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    collector = FacterFactCollector()
    class TestModule(object):
        def get_bin_path(self, exe, opt_dirs=[]):
            return '/bin/' + exe
    module = TestModule()
    assert collector.find_facter(module) == '/bin/cfacter'


# Generated at 2022-06-11 03:52:12.265202
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    import sys
    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import CachingCollector

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, opt_dirs=[]):
            if self.params['return_facter_path'] is True:
                return FacterFactCollector.find_facter(self)
            else:
                return None


# Generated at 2022-06-11 03:52:19.654044
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Dummy module object
    module = type('', (object,), {'get_bin_path' : get_bin_path})
    module.run_command = run_command

    facter_collector = FacterFactCollector()
    facter_collector.collect(module)

    assert module.run_command.call_count == 2
    assert module.run_command.call_args_list[0][0][0] == 'facter --puppet --json'
    assert module.run_command.call_args_list[1][0][0] == 'cfacter --puppet --json'


# Generated at 2022-06-11 03:52:27.648036
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance

    facter = get_collector_instance('FacterFactCollector')

    class DummyModule():

        def __init__(self, root_dir):
            self.root_dir = root_dir

        def get_bin_path(self, executable, opt_dirs=[]):
            return executable if executable == 'facter' else None

    assert facter.find_facter(DummyModule('/root/dir1')) == 'facter'
    assert facter.find_facter(DummyModule('/root/dir2')) == 'facter'
    assert facter.find_facter(DummyModule('/root/dir3')) == 'facter'


# Generated at 2022-06-11 03:52:34.840185
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # GIVEN
    # To store collected facts
    facts = dict()
    # To store ansible_module fixture
    ansible_module = None
    # To store the FacterFactCollector instance to test
    facter_fact_collector = None

    # WHEN
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.collect(ansible_module, facts)

    # THEN
    assert facter_fact_collector is not None
    assert facts is not None
    assert 'facter' not in facts
    assert isinstance(facts, dict)

# Generated at 2022-06-11 03:52:45.152800
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector as c
    import ansible.module_utils.facts.namespace as  ns
    import ansible.module_utils.facts.utils as u


# Generated at 2022-06-11 03:52:48.408484
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # initialize FacterFactCollector
    facter_fact_collector = FacterFactCollector()
    # method collect returns a dictionary of facter facts
    assert isinstance(facter_fact_collector.collect(), dict)

# Generated at 2022-06-11 03:52:52.761310
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    test_module = object
    test_module.run_command = lambda x: (0, '{"test":"test"}', None)
    test_module.get_bin_path = lambda *args,**kwargs: 'test_bin_path'
    test_collector = FacterFactCollector()
    assert test_collector.get_facter_output(test_module) == '{"test":"test"}'

# Generated at 2022-06-11 03:52:56.897734
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # GIVEN
    class ModuleMock(object):
        def get_bin_path(self, *args, **kwargs):
            return None

    collector = FacterFactCollector()

    # WHEN
    facter_path = collector.find_facter(ModuleMock())

    # THEN
    assert facter_path is None



# Generated at 2022-06-11 03:53:59.618086
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import sys
    import json

    # Dummy module
    class DummyModule():
        class DummySubClass():
            def __init__(self):
                self.path = '/opt/puppetlabs/bin'
        def __init__(self):
            self.params = self.DummySubClass()

        def get_bin_path(self, cmd, opt_dirs=None):
            return '/opt/puppetlabs/bin/facter'

        def run_command(self, cmd):
            return 0, '{"a":"b"}', None

    module = DummyModule()
    fact_collector = FacterFactCollector()
    assert fact_collector.collect(module=module) == json.loads('{"a":"b"}')

test_FacterFactCollector_collect()

# Generated at 2022-06-11 03:54:03.920524
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts_parsers import AnsibleFactsParser
    import pytest
    import sys

    class AnsibleModuleMock(object):

        def __init__(self):
            self.debug = False
            self.check_mode = False
            self.files = {}
            self.params = {}

    class AnsibleModuleMockNoFacter(object):

        def __init__(self):
            self.debug = False
            self.check_mode = False
            self.files = {}
            self.params = {}

        def get_bin_path(self, binary, opt_dirs=None):
            return None

    class AnsibleModuleMockFacterError(object):

        def __init__(self):
            self.debug = False
            self.check_mode = False

# Generated at 2022-06-11 03:54:09.368854
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class FakeModule(object):
        def get_bin_path(self, module, opt_dirs=None):
            return '/opt/puppetlabs/bin/facter'

    class FakeFactCollector(object):
        def __init__(self, collectors=None, namespace=None):
            pass

    facter = FacterFactCollector(collectors=FakeFactCollector())
    module = FakeModule()
    facter_path = facter.find_facter(module)

    assert facter_path == '/opt/puppetlabs/bin/facter'

# Generated at 2022-06-11 03:54:18.216234
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    import sys
    import tempfile
    test_fixture_path = os.path.join(os.path.dirname(__file__), 'facter_fixture.json')
    facter_bin_path = tempfile.mkdtemp()
    facter_bin = os.path.join(facter_bin_path, 'facter')
    assert os.path.exists(facter_bin_path)
    assert not os.path.exists(facter_bin)

    # Create a facter binary
    with open(facter_bin, 'w') as f:
        f.write('''#!/bin/sh
                cat {0}
                exit 0
                '''.format(test_fixture_path))


# Generated at 2022-06-11 03:54:26.313999
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.namespace as namespace

    namespace = PrefixFactNamespace(namespace_name='facter',
                                    prefix='facter_')
    ffct = FacterFactCollector(namespace=namespace)

    # Unit test for the condition when no rubygems is installed
    assert ffct.find_facter({}) is None

    # Unit test for the condition when no facter is installed
    class module:
        def get_bin_path(self, string, opt_dirs=None):
            return None
    assert ffct.find_facter(module) is None

    # Unit test for the condition when facter is installed but not rubygems
    facter_path = "/usr/bin/facter"

# Generated at 2022-06-11 03:54:34.292412
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    def find_facter(module):
        return 'facter_path'

    def run_facter(module, facter_path):
        rc, out, err = 0, json.dumps({'ipaddress': '10.0.0.1'}), ''
        return rc, out, err

    class Module(object):
        pass

    module = Module()
    facter_dict = {}

    facter_collector = FacterFactCollector()
    facter_collector.find_facter = find_facter
    facter_collector.run_facter = run_facter

    facter_dict = facter_collector.get_facter_output(module)
    assert facter_dict['ipaddress'] == '10.0.0.1'

# Generated at 2022-06-11 03:54:42.309713
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    Returns collected facts
    """
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    import os
    import tempfile
    import shutil
    import sys

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    class FacterFactCollectorUtils(FacterFactCollector):
        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='facter',
                                            prefix='facter_')

# Generated at 2022-06-11 03:54:51.159174
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    f = FacterFactCollector()
    assert f.find_facter({}) is None
    assert f.find_facter({'get_bin_path': lambda x: None}) is None
    assert f.find_facter({'get_bin_path': lambda x: '/usr/bin/facter'}) == '/usr/bin/facter'
    assert f.find_facter({'get_bin_path': lambda x, y: "/usr/bin/cfacter"}) == '/usr/bin/cfacter'
    assert f.find_facter({'get_bin_path': lambda x, y: "/opt/puppetlabs/bin/cfacter"}) == '/opt/puppetlabs/bin/cfacter'

# Generated at 2022-06-11 03:54:56.697852
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts import FacterFactCollector
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.find_facter = lambda x: '/usr/bin/facter'
    facter_fact_collector.run_facter = lambda x, y: (0, '{"test": "test"}', '')
    assert facter_fact_collector.get_facter_output(None) == '{"test": "test"}'

# Generated at 2022-06-11 03:55:05.748319
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    class FakeModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path
            self.facter_result = None

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter' or name == 'cfacter':
                return self.facter_path

        def run_command(self, cmd):
            if cmd == self.facter_path + " --puppet --json":
                if self.facter_result is not None:
                    return 0, self.facter_result, ''
                else:
                    return 1, '', ''
            else:
                assert(False)
