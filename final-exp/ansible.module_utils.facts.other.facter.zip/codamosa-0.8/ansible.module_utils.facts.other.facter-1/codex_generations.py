

# Generated at 2022-06-11 03:46:26.352271
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.basic

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = {}
            self.check_mode = False
            self.no_log = False
            self.fail_json = ansible.module_utils.basic.fail_json
            self.exit_json = ansible.module_utils.basic.exit_json
            self.run_command = ansible.module_utils.basic.run_command
            self.get_bin_path = ansible.module_utils.basic.get_bin_path
            for attribute in kwargs:
                setattr(self, attribute, kwargs[attribute])

    module = TestModule()

    # TODO: This assertion should be replaced by an

# Generated at 2022-06-11 03:46:36.620721
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.ansible_collection_loader
    class Module:
        def __init__(self, bin_path):
            self.bin_path = bin_path
        def get_bin_path(self, bin, opt_dirs=None):
            return self.bin_path
    class AnsibleModule:
        def __init__(self, module):
            self.module = module
        def run_command(self, command):
            if command == '/usr/bin/facter --puppet --json':
                return 0, "{ 'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS' }", ''

# Generated at 2022-06-11 03:46:38.219479
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # FIXME: mock the module.run_command method to return a good result
    pass

# Generated at 2022-06-11 03:46:48.384338
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import sys
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import which

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = self.exit_json = lambda **kwargs: sys.exit(0)
            self.run_command = lambda *args: (0, '', '')
            self.get_bin_path = lambda cmd, opt_dirs: which(cmd, opt_dirs)
            self.check_mode = False
            self.no_log = lambda _: None

# Generated at 2022-06-11 03:46:49.606276
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    """
    FIXME: TEST NEEDED
    """
    pass


# Generated at 2022-06-11 03:46:59.333396
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create test module object for testing
    class TestModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, executable, opt_dirs=None):
            return self.facter_path

        def run_command(self, command):
            return 0, '{}', ''

    class TestFacterFactCollector(FacterFactCollector):
        def find_facter(self, module):
            return module.get_bin_path('facter')

    # Verify result when facter path is not set
    with TestModule(None) as test_module:
        with TestFacterFactCollector() as test_fact_collector:
            assert test_fact_collector.collect(module=test_module) == {}



# Generated at 2022-06-11 03:47:09.600407
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Simulate a module
    class Module(object):
        def __init__(self):
            self.path = ['/opt/puppetlabs/bin/']
            self.bin_path = {
                'facter': '/opt/puppetlabs/bin/facter',
                'cfacter': '/opt/puppetlabs/bin/cfacter',
            }

        def get_bin_path(self, binary, opt_dirs=None):
            # Return the path to the binary based on the value of
            # opt_dirs parameter. Return None if binary not found.
            if opt_dirs is None or not opt_dirs:
                return self.bin_path.get(binary)

            # Add the binary to the first path in the list
            path = opt_dirs[0] + '/' + binary


# Generated at 2022-06-11 03:47:15.356433
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import Module
    from ansible.module_utils.facts.collector import OptionParser
    from ansible.module_utils.facts.collector import AnsibleModule

    option_parser = OptionParser()
    options, args = option_parser.parse_args([])
    module = AnsibleModule(add_argument_spec=False)
    module.run_command = lambda x, **kwargs: (0, "", "")
    module.get_bin_path = lambda x, **kwargs: "/usr/local/bin/facter"

    facter_collector = FacterFactCollector()

    # If facter is not installed, then return None
    module.run_command = lambda x, **kwargs: (1, "", "")
    assert facter_collector.get_

# Generated at 2022-06-11 03:47:25.325782
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Setup and initialize FacterFactCollector
    facter_fact_collector = FacterFactCollector(namespace='fake_facter')

    # Create a mock class for module
    class MockModule:
        def run_command(self, command):
            return 0, json_data, ''

        def get_bin_path(self, command, **kwargs):
            return '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-11 03:47:34.571813
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import os
    import tempfile

    module = None

    # Create a fake facter plugin:
    plugin_name = "facter_test_collector.rb"
    plugin_content = """
Facter.add("facter_test_collector") do
        setcode do
                'facter_test_collector_value'
        end
end
"""
    plugin_path = os.path.join(tempfile.gettempdir(), plugin_name)

    with open(plugin_path, 'w') as plugin_fd:
        plugin_fd.write(plugin_content)


# Generated at 2022-06-11 03:47:42.800056
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts import ansible_environment
    from ansible.module_utils.facts import ansible_distribution
    from ansible.module_utils.facts import ansible_distribution_major_version
    from ansible.module_utils.facts import ansible_distribution_release

    collectors = [ansible_collections, ansible_environment, ansible_distribution, ansible_distribution_major_version, ansible_distribution_release]

    facter_dict = FacterFactCollector(collectors=collectors).collect()
    assert len(facter_dict) > 0

# Generated at 2022-06-11 03:47:52.697988
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_path = "facter --puppet --json"
    rc_json, out_json, err_json = 0, '{"facter": "json"}', ''
    rc_text, out_text, err_text = 0, 'facter text', ''

    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            return facter_path

        def run_command(self, *args, **kwargs):
            if args[0] == facter_path:
                return rc_json, out_json, err_json
            elif args[0] == facter_path[:-4]:
                return rc_text, out_text, err_text
            else:
                raise Exception("Unknown command: " + args[0])

    # Setup and run facts about facter


# Generated at 2022-06-11 03:47:55.711669
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    '''Test method FacterFactCollector.find_facter.'''
    facter_collector = FacterFactCollector()
    assert facter_collector._find_bin(None, 'facter', ['/opt/puppetlabs/bin']) is None

# Generated at 2022-06-11 03:48:02.864203
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    class MockModule():
        def run_command(command):
            if command == '/opt/puppetlabs/bin/cfacter --puppet --json':
                return 0, '{"id":"value"}', ''
            else:
                return 1, '', 'facter: command not found'

        def get_bin_path(bin, opt_dirs):
            return '/opt/puppetlabs/bin/' + bin

    assert facter_fact_collector.get_facter_output(MockModule) == '{"id":"value"}'

# Generated at 2022-06-11 03:48:12.665365
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.facts.base import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    module = BaseFactCollector()
    facter_collector = FacterFactCollector()

    # Mock object for ansible.module_utils.facts.base.BaseFactCollector class
    class MockBaseFactCollector:
        def __init__(self):
            self.bin_path = None
            self.run_command = None
            self.rc = None
            self.out = None
            self.err = None


# Generated at 2022-06-11 03:48:21.602004
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class Module(object):
        def get_bin_path(self, name, opt_dirs=None):
            return opt_dirs[0]

        def run_command(self, cmd):
            return 0, '{ "result": "success" }', None

    namespace.init()

    mod = Module()

    kls = FacterFactCollector()
    out = kls.get_facter_output(mod)
    assert out == '{ "result": "success" }'

# Generated at 2022-06-11 03:48:28.261899
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    collector = FacterFactCollector()
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            return None
        def run_command(self, cmd):
            if cmd == '/opt/puppetlabs/bin/cfacter --puppet --json':
                return (0, '{"test_fact":"test_fact_value"}', '')
            return (1, '', '')
    module = MockModule()
    facter_output = collector.get_facter_output(module)
    assert facter_output == '{"test_fact":"test_fact_value"}'


# Generated at 2022-06-11 03:48:37.823905
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import Collector
    ffc = FacterFactCollector
    collector = Collector()

    get_bin_path_results = {
        'test1': None,
        'test2': '/tmp/test',
        'test3': '/tmp/test2',
    }

    run_command_results = [
        (0, '{"facter_test1": "test1"}', ''),
        (1, '', ''),
        (0, '{"facter_test3": "test3"}', ''),
    ]


# Generated at 2022-06-11 03:48:47.220863
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    collector = FacterFactCollector()

    class Options:
        def __init__(self):
            self.host_pattern = None

    class Module:
        def __init__(self):
            self.params = Options()

    class Runner:
        def __init__(self):
            self.module = Module()

    class AnsibleModule:
        def __init__(self):
            self.runner = Runner()

    ansible_module = AnsibleModule()

    facter_path = "/opt/puppetlabs/bin/facter"
    facter_path_exists = True

    ansible_module.run_command = lambda x, **kwargs: (0, "", "")
    ansible_module.get_bin_path = lambda x, **kwargs: facter_path_exists and facter_path

# Generated at 2022-06-11 03:48:50.120814
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    collector = FacterFactCollector()
    mock_module = FakeModule()

    collector.find_facter(mock_module)

    assert mock_module.get_bin_path_args[0] == 'facter'


# Generated at 2022-06-11 03:49:02.603519
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_lines
    facter_collector = get_collector_instance('facter')

    # This patch is in place to simulate a puppet install without facter installed
    # We need to create a 'facter' function in order to play with the find_facter method
    def facter(module, opt_dirs=[]):
        facter_path = module.get_bin_path('facter', opt_dirs=opt_dirs)
        return facter_path

    # Test 1: when facter binary is not found in puppet installation path
    # expected result: return None
    facter_path = facter_collector.find_facter(facter)
    assert facter

# Generated at 2022-06-11 03:49:12.374361
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import mock
    import collections

    # create an instance of FacterFactCollector
    facter_fact_collector = FacterFactCollector()

    # create a mock module
    mock_module = mock.MagicMock(name='module')

    # create mock os.path.exists object
    mock_path_exists = mock.MagicMock(name='os.path.exists')
    mock_path_exists.return_value = True

    # mock out os.path.exists
    mock_module.get_bin_path.side_effect = lambda param: {'cfacter': '/opt/puppetlabs/bin/cfacter', 'facter': '/usr/bin/facter'}[param]

    # create mock run_command object

# Generated at 2022-06-11 03:49:18.175999
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import sys
    import os
    import pytest
    import platform

    if platform.system() != 'Linux':
        pytest.skip('Cannot test find_facter() on a non-Linux platform')

    collectors = []
    namespace = None
    facter_collector = FacterFactCollector(collectors, namespace)
    os.environ['PATH'] = '/tmp/does/not/exist'
    module_mock = MockModule()
    result = facter_collector.find_facter(module_mock)
    assert result is None, "Can not find facter!"

    os.environ['PATH'] = ':'.join([os.environ['PATH'], '/opt/puppetlabs/bin'])
    sys.modules['distro'] = MockDistro()
    module_mock = MockModule()

# Generated at 2022-06-11 03:49:24.086110
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    testModule = DummyModule()
    facter_path = FacterFactCollector().find_facter(testModule)
    assert facter_path
    rc, out, err = FacterFactCollector().run_facter(testModule, facter_path)
    assert rc == 0
    assert out
    assert not err
    facter_output = FacterFactCollector().get_facter_output(testModule)
    assert facter_output is not None


# Generated at 2022-06-11 03:49:29.548529
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_collector = FacterFactCollector()

    class fake_module:
        def get_bin_path(self, *args, **kwargs):
            return '/path/to/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"foo": "bar"}', ''

    return facter_collector.get_facter_output(fake_module())

# Generated at 2022-06-11 03:49:35.636131
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeModule:
        def get_bin_path(self, arg1, arg2=None):
            return True
        def run_command(self, arg):
            return True, "", ""
    facterFactCollector = FacterFactCollector(module=FakeModule())
    facterFactCollector.find_facter=lambda: False
    assert(facterFactCollector.get_facter_output() == None)
    facterFactCollector.find_facter=lambda: True
    facterFactCollector.run_facter=lambda: 1, "", ""
    assert(facterFactCollector.get_facter_output() == None)
    facterFactCollector.run_facter=lambda: 0, "", ""
    assert(facterFactCollector.get_facter_output() == '')


# Generated at 2022-06-11 03:49:46.628272
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import ansible_managed
    from ansible.module_utils.facts import ansible_virtualization_type

    class Facter(FacterFactCollector):
        def run_facter(self, module, facter_path):
            # simulate the default fact list
            return 0, '{"hostname":"host","architecture":"x86_64"}', ""

    class Module(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None


# Generated at 2022-06-11 03:49:49.368788
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    """
    This test cannot be run on its own, since the module_utils require the
    module param. The test is integrated in test_facter.py
    """
    raise NotImplementedError

# Generated at 2022-06-11 03:49:57.631187
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-11 03:50:06.889553
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    facter_dict = {}

# Generated at 2022-06-11 03:50:24.600727
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_path = "/fake/path"

    facter_output = "Test output"

    # Create a fake module class
    class FakeModule:
        def __init__(self):
            # This will get populated
            self.rc = None
            self.out = None
            self.err = None

        def get_bin_path(self, binname, opt_dirs=None):
            # For testing, just return the fake facter path
            return facter_path

        def run_command(self, cmd):
            self.cmd = cmd
            self.rc = 0
            self.out = facter_output
            self.err = ""
            return self.rc, self.out, self.err

    facter = FacterFactCollector()

    module = FakeModule()

    # Should return a dict of the facter

# Generated at 2022-06-11 03:50:26.332610
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    facter_dict = FacterFactCollector.collect()
    assert facter_dict is not None

# Generated at 2022-06-11 03:50:33.423159
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import collect_subset_of_facts
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts import ansible_collector

    fact_collector = collect_subset_of_facts(get_collector_class('facter'))
    ansible_collector.add_collector(fact_collector)

    get_collector_names()

    fact_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-11 03:50:43.408939
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    collector = FacterFactCollector()
    # mock class os_family
    class os_family:
        family = 'debian'
    # mock class module
    class module:
        def get_bin_path(path, opt_dirs=['/opt/puppetlabs/bin']):
            return path

# Generated at 2022-06-11 03:50:53.273231
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import sys
    import os
    import tempfile
    TEST_DIR = os.path.abspath(os.path.dirname(__file__))
    TEST_DIR = os.path.abspath(os.path.join(TEST_DIR, '..'))
    MODULE_UTILS_PATH = os.path.join(TEST_DIR, 'module_utils')
    sys.path.insert(0, MODULE_UTILS_PATH)

    from ansible_module_utils.basic import AnsibleModule

    # Test 1: Both facter and cfacter are not available.
    module = AnsibleModule(
        argument_spec = dict(),
    )
    facter_finder = FacterFactCollector()
    assert facter_finder.find_facter(module) is None

    # Test 2: cfacter is available,

# Generated at 2022-06-11 03:50:59.592718
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector

    def mock_get_bin_path(self, executable, opt_dirs=[]):
        return '/usr/bin/facter'

    class MockModule:
        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{ "foo": "bar", "baz": { "qux": "hipsum" } }', ""

    module = MockModule()
    ansible.module_utils.facts.collector.ModuleUtils.get_bin_path = mock_get_bin_path
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output(module)
   

# Generated at 2022-06-11 03:51:05.060829
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import tempfile

    ansible_module = FacterFactCollector()
    d = tempfile.gettempdir()
    facter_path = os.path.join(d, "facter")
    f = open(facter_path, "w")
    f.write("#!/bin/bash\necho '{\"foo\":\"bar\"}'")
    f.close()
    os.chmod(facter_path, 0o755)

    result = ansible_module.get_facter_output(ansible_module)
    assert result == "{\"foo\":\"bar\"}"



# Generated at 2022-06-11 03:51:06.893568
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = None
    facter_path = FacterFactCollector().find_facter(module)
    print(facter_path)



# Generated at 2022-06-11 03:51:15.474368
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    '''
    Test method get_facter_output of class FacterFactCollector.
    '''
    from ansible.module_utils.facts.collector import BaseFactCollector

    test_obj = FacterFactCollector()
    # test normal behavior
    try:
        import ansible.module_utils.facts.system.linux
    except:
        pass
    else:
        base_obj = BaseFactCollector()
        base_obj.subset = '!all'
        module = ansible.module_utils.facts.system.linux.LinuxFactCollector(base_obj).subset_collect()
        test_obj.get_facter_output(module)

# Generated at 2022-06-11 03:51:23.648698
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import os
    import sys
    import tempfile
    import shutil

    def get_input_file_contents(input_file):
        return input_file.read()

    class TestFacter(BaseFactCollector):
        name = 'test_facter'

        def get_facter_output(self, module):
            return None


# Generated at 2022-06-11 03:51:48.829683
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ListOfCollectors
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import PrefixFactNamespace
    from ansible.module_utils.facts.collector import TestModule
    from ansible.vars.manager import VariableManager

    module = TestModule()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    namespace = Namespace(namespace_name='facter', prefix='facter_')

    # Test 1: Simple case, find facter

# Generated at 2022-06-11 03:51:57.482897
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # create class instance, to test with
    fact_collector_class_instance = FacterFactCollector()
    # create mock of module
    class ModuleClass():
        # create mock of method 'get_bin_path', to test with
        def get_bin_path(self, command_name, opt_dirs=[]):
            if command_name == 'cfacter':
                # mock of 'cfacter' command
                return "/usr/bin/cfacter"
            if command_name == 'facter':
                # mock of 'facter' command
                return "/usr/bin/facter"
            if command_name == 'false':
                # mock of 'false' command
                return "/usr/bin/false"

# Generated at 2022-06-11 03:52:06.950808
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import add_collector
    from ansible.module_utils.facts import get_collector_instance

    # Add this collector
    add_collector(FacterFactCollector)

    # Get an instance of the new collector
    facter_collector = get_collector_instance('facter')

    # define a fake module
    fake_module = type('AnsibleModule', (), {})

    # define a fake module.get_bin_path
    def fake_get_bin_path(self, module_name, opt_dirs=None):
        if module_name == 'facter':
            return '/usr/bin/facter'
        return None
    # add the fake get_bin_path method to fake module object
    fake_module.get_bin_path = fake_

# Generated at 2022-06-11 03:52:13.485985
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import os
    import sys

    # use an 'ansible' module object to mock out module API
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, name, opt_dirs=[]):
            # This is hacky, but good enough to test here.
            if sys.platform == 'darwin':
                return '/opt/local/bin/facter'
            elif sys.platform == 'win32':
                return 'C:\\Windows\\system32\\facter.bat'
            else:
                return '/usr/local/bin/facter'


# Generated at 2022-06-11 03:52:22.738021
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import ModuleCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.facter import FacterFactCollector

    # Setup mocks
    class MockModule(object):
        def __init__(self, facter_path):
            self.params = {}
            self.bin_path = facter_path

        def get_bin_path(self, executable, opt_dirs=[]):
            return self.bin_path


# Generated at 2022-06-11 03:52:29.953823
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            return '/usr/bin/%s' % name
    class MockGetBinPath(object):
        def __init__(self, returning):
            self.returning = returning

        def get_bin_path(self, name, opt_dirs=None):
            return self.returning
    # TODO: I don't know how to test this with the mocker fixture,
    # so right now this test is still brittle, but with the exception
    # of the get_bin_path method.

    # Neither facter nor cfacter can be found
    module = MockGetBinPath(None)
    assert FacterFactCollector().find_facter(module) is None

    # Only facter can be found
    module

# Generated at 2022-06-11 03:52:32.467873
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter = FacterFactCollector()
    module = MockModule()
    assert facter.find_facter(module) == '/usr/bin/facter'


# Generated at 2022-06-11 03:52:43.088525
# Unit test for method run_facter of class FacterFactCollector

# Generated at 2022-06-11 03:52:51.769150
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import FactsLoader
    from ansible.module_utils.facts.utils import get_file_content
    import os

    fn = get_file_content(os.path.join(os.path.dirname(__file__), 'fixtures', 'ansible_facter2.json'))
    loader = FactsLoader()
    # populate facts cache with the content of the json file
    loader._construct_facts_cache(fn)
    facts = loader._facts_cache
    collectors = []
    facter = get_collector_instance(FacterFactCollector, collectors, facts)
    assert facter.find_facter(facter) is not None

# Generated at 2022-06-11 03:53:00.701280
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    # Test with facter installed
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.collector import FacterFactCollector
    
    # get full path of facter command on the system
    facter_found_path = BaseFactCollector.find_executable('facter')

    # dummy class to test BaseFactCollector method run_facter

# Generated at 2022-06-11 03:54:00.853039
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import copy
    import os
    import sys
    import tempfile

    collector = FacterFactCollector()
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class MyModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=[]):
            if name in self.bin_path:
                return self.bin_path[name]
            elif not os.path.isabs(name) and self.bin_path:
                # Check all of the bin_paths
                for bin_path in self.bin_path:
                    if name in self.bin_path[bin_path]:
                        return self

# Generated at 2022-06-11 03:54:08.808543
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    class FakeModule(object):
        def __init__(self, args=None):
            self.params = dict()

            if args is not None:
                self.params['facter'] = args

        def run_command(self, bin_path, opt_dirs=['/opt/puppetlabs/bin']):
            if 'facter-fails-with-exit-1' in bin_path:
                return 1, None, None

            if 'facter-fails-with-exit-2' in bin_path:
                return 2, None, None


# Generated at 2022-06-11 03:54:17.917734
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    ffc = FacterFactCollector(collectors=None, namespace=None)

    # Test data for get_facter_output method
    m2 = MagicMock()
    m2.run_command.return_value = 0, '{"facter_version": "3.5.1"}', ''

    # Test case1: facter is installed and we can use --json
    ffc.get_facter_output = MagicMock(return_value = m2.run_command.return_value)
    assert ffc.collect(module) == {"facter_version": "3.5.1"}

    # Test data for get_facter_output method
    m1 = MagicMock()

# Generated at 2022-06-11 03:54:25.961620
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class TestModule:
        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/local/bin/' + executable

    ffc = FacterFactCollector()
    module = TestModule()
    facter_path = ffc.find_facter(module)
    assert facter_path == '/usr/local/bin/cfacter', 'Facter should be at /usr/local/bin/cfacter'

    class TestModule:
        def get_bin_path(self, executable, opt_dirs=[]):
            return None

    ffc = FacterFactCollector()
    module = TestModule()
    facter_path = ffc.find_facter(module)
    assert facter_path == None, 'Facter not found, should return None'



# Generated at 2022-06-11 03:54:30.955837
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    class FakeModule(object):
        def get_bin_path(*args, **kwargs):
            return False

        def run_command(*args, **kwargs):
            def result():
                return 1, 'mock', 'mock'
            return result()

    collector = FacterFactCollector()
    result = collector.collect(module=FakeModule())

    # Mock method run_command returns empty dict, so result of collect should
    # be an empty dict
    assert result == {}

# Generated at 2022-06-11 03:54:39.187420
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # The code below is in support of the unit test for this method.
    # It is not part of the real implementation.
    class MockModule(object):
        def get_bin_path(self, arg1, opt_dirs):
            if arg1 == 'facter':
                # Only return the path if cfacter does not exist
                if opt_dirs[0] != '/opt/puppetlabs/bin/cfacter':
                    return '/usr/bin/facter'
            if arg1 == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
    mock_module = MockModule()

    # This is the real part of the unit test
    collector = FacterFactCollector()
    facter_path = collector.find_facter(mock_module)
    assert facter_path is not None

# Generated at 2022-06-11 03:54:46.534732
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import json
    import mock
    facts_to_return = {
        'facter_1': 'value1',
        'facter_2': 'value2',
    }

    class TestModule():
        def run_command(self):
            return 0, json.dumps(facts_to_return, sort_keys=True, indent=4, separators=(',', ': ')), None

        def get_bin_path(self, cmd, opt_dirs=[]):
            return '/usr/bin/' + cmd

    module = TestModule()
    fact_collector = FacterFactCollector()
    out = fact_collector.collect(module=module)

    assert out == facts_to_return

# Generated at 2022-06-11 03:54:55.150012
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import injector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):

        def __init__(self):
            self.params = None

        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/facter"


# Generated at 2022-06-11 03:55:04.425957
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.facter import FacterFactCollector
    from ansible.module_utils._text import to_bytes

    if sys.version_info >= (2, 7):
        from unittest.mock import patch, MagicMock
    else:
        from mock import patch, MagicMock

    class MockModule:
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, prog, opt_dirs):
            return None


# Generated at 2022-06-11 03:55:11.733162
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    import os
    import io
    import unittest.mock as mock

    class MockModule:
        def __init__(self, *args, **kwargs):
            self.params = {}

        def __getitem__(self, item):
            return self.params[item]

        def __setitem__(self, key, value):
            self.params[key] = value

        def fail_json(self, *args, **kwargs):
            raise Exception

        def run_command(self, cmd, check_rc=True):
            data = b'{"facter_architecture":"amd64"}'
            return (0, data, None)
