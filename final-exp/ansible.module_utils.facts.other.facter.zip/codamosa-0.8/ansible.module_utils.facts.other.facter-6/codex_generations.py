

# Generated at 2022-06-11 03:46:26.584119
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    collector = FacterFactCollector()

    class FakeModule(object):
        def __init__(self):
            self.bin_path_cache = {}
            self.called_commands = {}
            self.called_commands_args = {}

        def get_bin_path(self, command, opt_dirs=[], required=False):
            if command in self.bin_path_cache:
                return self.bin_path_cache[command]
            return None

        def run_command(self, command, check_rc=True, environ_update=None):
            self.called_commands[command] = True
            self.called_commands_args[command] = environ_update
            return 0, '', ''


# Generated at 2022-06-11 03:46:36.778036
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils import facts
    from ansible.module_utils._text import to_bytes
    module = facts.AnsibleModuleMock()

    class FacterFact:
        """
        Class for mocking methods in FacterFactCollector class
        """
        def get_facter_output(self, module):
            return '{"system_uptime":{"seconds":"86903"},"is_virtual":false}'

    facter_fact = FacterFact()

    facter_collector = FacterFactCollector()
    facter_collector.get_facter_output = facter_fact.get_facter_output
    facter_collector.collect(module=module)
    assert to_bytes("facter_system_uptime") in facter_collector.namespace._fact_cache._dict


# Generated at 2022-06-11 03:46:47.186297
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    """Test get_facter_output of FacterFactCollector."""
    # pylint: disable=unused-variable
    module_name = 'test_module'
    module_path = '/path/to/%s' % module_name
    mock_module = MagicMock(name=module_name, path_name=module_path)
    mock_module.run_command.return_value = (0, 'facter_output', '')
    mock_module.get_bin_path.return_value = True

    collector = FacterFactCollector()
    facter_output = collector.get_facter_output(module=mock_module)

    assert facter_output == 'facter_output'
    mock_module.run_command.assert_called_with(True + " --puppet --json")
   

# Generated at 2022-06-11 03:46:54.006739
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import FactsParams
    from ansible.module_utils.facts.collector import FactsCollector
    # The module is mocked by the AnsibleModule class
    class AnsibleModule:
        def get_bin_path(self, tool, opt_dirs=None):
            if tool == 'facter':
                return 'facter_path'
            elif tool == 'cfacter':
                return 'cfacter_path'
            else:
                return None
        def run_command(self, cmd):
            if cmd.startswith("facter_path") or cmd.startswith("cfacter_path"):
                return 0, "output", "error"
            else:
                return 1, "", "error"
    # get_bin_path and run_command methods are mocked


# Generated at 2022-06-11 03:47:04.864958
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = None
    facter_dict = { 'test_key': 'test_value' }
    facter_output = None

    class FakeModule():
        class FakeAnsibleModule():
            def __init__(self):
                self.params = {}

            def run_command(self, command):
                if 'facter --puppet --json' in command:
                    return 0, facter_output, ''
                elif 'facter -p' in command:
                    return 0, json.dumps(facter_dict), ''

        def __init__(self, *args, **kwargs):
            self.params = {}

            self.ansible_module = self.FakeAnsibleModule()


# Generated at 2022-06-11 03:47:10.957483
# Unit test for method get_facter_output of class FacterFactCollector

# Generated at 2022-06-11 03:47:18.998671
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    f = FacterFactCollector()
    class TestableModule(object):

        def get_bin_path(self, bin, opt_dirs=None):
            return '/bin/'+bin
    m = TestableModule()

    # Case where facter is found
    assert '/bin/facter' == f.find_facter(m)

    # Case where facter is not found
    m2 = TestableModule()
    m2.get_bin_path = lambda bin, opt_dirs: None
    assert None == f.find_facter(m2)

# Unit tests for method run_facter of class FacterFactCollector

# Generated at 2022-06-11 03:47:29.096350
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    """
    Unit test for method get_facter_output of class FacterFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible_fact_collector_mock import AnsibleFactCollectorMock

    f = get_collector_instance(FacterFactCollector)
    # Module is not None, native facter is not installed (None)
    assert f.get_facter_output(AnsibleFactCollectorMock()) is None

    # Module is not None, native facter is installed
    assert f.get_facter_output(AnsibleFactCollectorMock(facter_bin=True)) == 'facter_output'

    # Module is None
    f

# Generated at 2022-06-11 03:47:34.183029
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_module

    module = get_module()
    facter_fact_collector = get_collector_instance(FacterFactCollector)

    facter_path = facter_fact_collector.find_facter(module)
    assert facter_path is not None


# Generated at 2022-06-11 03:47:39.561424
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    """
    This function returns a dict containing ansible facts to use in testing
    :return:
    """
    facter_path = 'path/to/facter'
    facter_output = '{ "osfamily": "RedHat", "facterversion": "2.4.4" }'
    module = FakeAnsibleModule(
        module_args={}
    )

    ff = FacterFactCollector()
    rc, out, err = ff.run_facter(module, facter_path)

    assert rc == 0
    assert out == facter_output
    assert err == ''



# Generated at 2022-06-11 03:47:51.924606
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_output = b''
    with open("/tmp/ansible_test_facter.fact", "wb") as fp:
        fp.write(facter_output)
        fp.close()

    facter = FacterFactCollector()

    class FakeModule(object):
        def __init__(self):
            self.bin_path = "/tmp"
        def get_bin_path(self, *args, **kwargs):
            return "/tmp/ansible_test_facter.fact"
        def run_command(self, *args, **kwargs):
            return (0, b"/tmp/ansible_test_facter.fact", "")

    module = FakeModule()
    get_facter_output = facter.get_facter_output(module)

    assert get_facter

# Generated at 2022-06-11 03:47:52.667492
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO
    return

# Generated at 2022-06-11 03:47:55.053432
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Instantiate class
    facter_collector = FacterFactCollector()

    # Test method
    result = facter_collector.find_facter(module=None)

    # Assert
    assert result is None

# Generated at 2022-06-11 03:48:01.481887
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = Mock(**{
        'get_bin_path.return_value': 'facter',
        'run_command.return_value': (0, '{"facter_architecture":"x86_64"}', ''),
        '_fail_json.return_value': ''
    })

    facter_collector = FacterFactCollector()
    facter_output = facter_collector.get_facter_output(module)

    assert facter_output == '{"facter_architecture":"x86_64"}'


# Generated at 2022-06-11 03:48:04.169399
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_path = FacterFactCollector().find_facter(module)

    assert facter_path == '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-11 03:48:11.678727
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    data = {
        'some_fact': 'some_value',
        'some_other_fact': 'some_other_value'
    }
    class MockedModule():
        def get_bin_path(self, path, opt_dirs=[]):
            return path
        def run_command(self, command):
            return 0, json.dumps(data), ''

    module = MockedModule()
    facter_fact_collector = FacterFactCollector()
    facts = facter_fact_collector.collect(module=module)
    assert facts == {'facter': data}


# Generated at 2022-06-11 03:48:21.755843
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import mock

    import ansible.module_utils.facts.collector

    module_mock = mock.MagicMock()
    module_mock.get_bin_path.return_value = None
    fact_collector_obj = ansible.module_utils.facts.collector.FacterFactCollector()
    facter_output = fact_collector_obj.get_facter_output(module_mock)
    assert facter_output is None

    module_mock.get_bin_path.return_value = '/bin/facter'
    module_mock.run_command.return_value = (0, '{"hostname": "localhost"}', None)
    facter_output = fact_collector_obj.get_facter_output(module_mock)

# Generated at 2022-06-11 03:48:29.303731
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts import ModuleFactCollector

    module = AnsibleModule(
        argument_spec = dict(
            ansible_facts=dict(required=False, type='dict'),
        )
    )

    # Create Facter fact collector with no other collectors
    fact_collector = FacterFactCollector([])

    # Test that get_facter_output() returns None when facter is not installed
    assert(fact_collector.get_facter_output(module) is None)

    # Test that get_facter_output() returns the expected output when facter is run
    # and it succeeds.
    import os
    import sys
    import tempfile

    # Create a fake directory to be used as the temp directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 03:48:38.743198
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def __init__(self, cmd_output_lines):
            self.cmd_output_lines = cmd_output_lines

        def get_bin_path(self, cmd, opt_dirs=None):
            return 'facter' if cmd == 'facter' else 'cfacter'

        def run_command(self, cmd, *args, **kwargs):
            if (cmd == 'facter --puppet --json' or cmd == 'cfacter --puppet --json'):
                return 0, "\n".join(self.cmd_output_lines), ''
            else:
                return 1, '', 'Unknown command'

    class MockFactNamespace(object):
        def __init__(self, name):
            self.name = name
    # With facter installed

# Generated at 2022-06-11 03:48:46.818698
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # __init__ of the unit under test
    facter = FacterFactCollector()

    # Mock module
    module = type("module", (object,), {})
    module.run_command = lambda x, y=None: [0, json.dumps({'ansible_facts':'some facts'}), '']
    module.get_bin_path = lambda x, y=None: '/usr/bin/facter'
    facter_output = facter.get_facter_output(module)

    assert facter_output == json.dumps({'ansible_facts':'some facts'})

# Test for method collect of class FacterFactCollector

# Generated at 2022-06-11 03:49:00.225132
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class  TestFacterFactCollector(FacterFactCollector):
        def find_facter(self, module):
            return './facter'

        def run_facter(self, module, facter_path):

            if facter_path == './facter':
                return 1, '', 'ERROR: no facter'

            return 0, '{"test":"test_value"}', ''

    test_fact_collector = TestFacterFactCollector()
    test_module = None

    result = test_fact_collector.get_facter_output(test_module)
    assert result is None

    result = test_fact_collector.get_facter_output(test_module)
    assert result == '{"test":"test_value"}'

# Generated at 2022-06-11 03:49:03.410403
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Initialize a module
    module = AnsibleModule(argument_spec={})

    # Initialize a FacterFactCollector
    facter_collector = FacterFactCollector()

    # Call method collect of FacterFactCollector
    facter_collector.collect(module=module)

# Generated at 2022-06-11 03:49:13.233850
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import \
        FacterFactCollector
    from ansible.module_utils._text import to_bytes

    class FakeModule:
        def __init__(self, facter_path=None):
            self.facter_path = facter_path

        def get_bin_path(self, name, opt_dirs=[]):
            if name == "facter":
                return self.facter_path
            elif name == "cfacter":
                return self.facter_path

        def run_command(self, cmd):
            if self.facter_path:
                return (0,
                        to_bytes(
                            json.dumps({"operatingsystem": "RedHat"})),
                        None)

# Generated at 2022-06-11 03:49:19.250332
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    facter_collector = FacterFactCollector()

    class Module:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return "/usr/bin/facter"
            elif name == 'cfacter':
                return None

    module = Module()
    facter_path = facter_collector.find_facter(module)
    assert facter_path == "/usr/bin/facter"

    class Module:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return None
            elif name == 'cfacter':
                return "/opt/puppetlabs/bin/cfacter"

    module = Module()
    facter_path = facter_collector.find_

# Generated at 2022-06-11 03:49:29.307751
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import shutil
    import tempfile
    import contextlib
    import os

    # Here we mock the ansible module
    class FakeModule:
        env = {}

        # The module's get_bin_path, so in this case we get the file from the
        # temporary dir
        def get_bin_path(self, *args, **kwargs):
            return os.path.join(dirpath, 'facter')


    @contextlib.contextmanager
    def facter_environment():
        # We define the temporary directory and the facter binary we are going
        # to use for the tests
        facter_binary = b'#!/bin/bash\n'
        global dirpath
        dirpath = tempfile.mkdtemp()
        facter_path = os.path.join(dirpath, 'facter')

# Generated at 2022-06-11 03:49:38.909734
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class ModuleMock():
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

    class CollectorMock():
        def __init__(self, *args, **kwargs):
            pass

    # If the find_facter method finds facter available, the method must return '/usr/bin/facter'
    # cfacter_path is None
    ffc = FacterFactCollector()
    result = ffc.find_facter(ModuleMock())
    assert result == '/usr/bin/facter'

    # If the find_facter method finds facter available and cfacter available,
    # the method must return '/usr/bin/cfacter'
    # cfacter_path is not None

# Generated at 2022-06-11 03:49:49.316852
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    class MockModule:
        class_called = False
        func_called = False
        rc = 0
        out = None
        err = None
        bin_path_dict = None

        def __init__(self):
            self.class_called = True
            self.bin_path_dict = {}
            self.bin_path_dict['facter'] = '/usr/bin/facter'
            self.bin_path_dict['cfacter'] = '/usr/bin/cfacter'

        def get_bin_path(self, bin_path_name, opt_dirs=None):
            self.func_called = True
            return self.bin_path_dict.get(bin_path_name, None)

        def run_command(self, command):
            self.func_called = True

# Generated at 2022-06-11 03:49:57.504775
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts import default_collectors

    facter_fact_collector = FacterFactCollector(collectors=None,
                                                namespace=None)

    # Check the facts collector searching into "/opt/puppetlabs/bin" first
    module_stub = AnsibleModuleStub()
    module_stub.run_command.side_effect = [
        (0, '/opt/puppetlabs/bin/facter', ''),
        (0, json.dumps({'fqdn': 'test_host.example.com'}), '')
    ]
    facter_facts = facter_fact_collector.get_facter_output(module_stub)

# Generated at 2022-06-11 03:50:01.907816
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    factcollector = FacterFactCollector()

    class TestModule():
        def get_bin_path(self, _, opt_dirs=None):
            return opt_dirs[0]

    test_module = TestModule()
    assert factcollector.find_facter(test_module) == '/opt/puppetlabs/bin/cfacter'



# Generated at 2022-06-11 03:50:08.570564
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.BaseFactCollector = lambda x, y: {
        'lspci': {'aaa': 'aaa_value'},
        'lsblk': {'bbb': 'bbb_value'},
    }

    facter_dict = FacterFactCollector().collect()

    assert facter_dict == {
        'facter_aaa': 'aaa_value',
        'facter_bbb': 'bbb_value',
    }

# Generated at 2022-06-11 03:50:21.175128
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class FakeModule():
        def get_bin_path(self, cmd, opt_dirs):
            return "/bin/%s" % cmd

    ff = FacterFactCollector()

    assert ff.find_facter(FakeModule()) == "/bin/cfacter"

# Generated at 2022-06-11 03:50:30.114394
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-11 03:50:30.980468
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass


# Generated at 2022-06-11 03:50:40.979487
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = type('', (), {})()
    class Bunch:
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    def run_command_mock(bin_path, check_rc=True, close_fds=True, data=None, executable=None,
                         data_encoding=None, remove_quotes=False, env=None):
        cmd = bin_path.split(' ')
        assert cmd[0] == '/opt/puppetlabs/bin/facter' or cmd[0] == '/opt/puppetlabs/bin/cfacter'
        assert cmd[1] == '--puppet'
        assert cmd[2] == '--json'

        if cmd[0] == '/opt/puppetlabs/bin/cfacter':
            return 0

# Generated at 2022-06-11 03:50:45.685549
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os
    module = type('str', (object,), {'run_command': lambda self, x: (0, os.devnull, '')})()
    facter_path = '/bin/facter'
    rc, out, err = FacterFactCollector().run_facter(module, facter_path)
    assert rc == 0
    assert out == ''
    assert err == ''

# Generated at 2022-06-11 03:50:47.300775
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    a = FacterFactCollector()
    a.find_facter(None)

# Generated at 2022-06-11 03:50:57.067322
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():

    class TestModule:
        def __init__(self):
            self.run_command_results = [
                [0, '{"test": "foo"}', ''],
                [0, '{"test": "foo"}', ''],
                [1, '', '']
            ]

        def get_bin_path(self, name, opt_dirs=None):
            return 'facter_path'

        def run_command(self, command):
            return self.run_command_results.pop(0)

    class TestFacterFactCollector(FacterFactCollector):
        def __init__(self):
            self.find_facter_results = [
                'facter_path',
                ''
            ]


# Generated at 2022-06-11 03:50:58.803011
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ''' return None as no facter is installed '''
    assert FacterFactCollector().find_facter(None) is None

# Generated at 2022-06-11 03:51:05.720634
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class Module:
        def get_bin_path(self, path, opt_dirs=None):
            return '/opt/puppetlabs/bin/facter'


# Generated at 2022-06-11 03:51:15.637220
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collectors

    ansible.module_utils.facts.collectors.BIN_PATH_CACHE['facter'] = '/usr/bin/facter'
    ansible.module_utils.facts.collectors.BIN_PATH_CACHE['cfacter'] = '/opt/puppetlabs/bin/cfacter'

    fc = FacterFactCollector()

    # if cfacter is available, prefer it
    facter_path = fc.find_facter({})
    assert facter_path == '/opt/puppetlabs/bin/cfacter'

    ansible.module_utils.facts.collectors.BIN_PATH_CACHE['cfacter'] = None
    facter_path = fc.find_facter({})

# Generated at 2022-06-11 03:51:45.739784
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import sys

    class TestAnsibleModule():
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all']
            self.params['gather_timeout'] = 5
            self.params['filter'] = '*'
            self.params['_ansible_verbosity'] = 0
            self.params['_ansible_syslog_facility'] = 'LOG_USER'
            self.params['_ansible_socket'] = None

        def fail_json(self, *args, **kwargs):
            sys.exit(1)

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter' or name == 'cfacter':
                return '/bin/true'
            return None


# Generated at 2022-06-11 03:51:54.619506
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import module_utils.facts.collector

    # Create a Mock module to pass to run_facter
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/' + name

        def run_command(self, cmd):
            return 0, '{ "fact1": "value", "fact2": "value2" }', ''

    mock_module = MockModule()

    # Create a Mock module to pass to run_facter
    facter_collector = module_utils.facts.collector.FacterFactCollector()

    rc, out, err = facter_collector.run_facter(mock_module, '/bin/facter')

    assert rc == 0
    assert err == ''

# Generated at 2022-06-11 03:51:59.091198
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    class FakeModule:
        def get_bin_path(self, *args, **kwargs):
            return '/bin/echo'

        def run_command(self, *args, **kwargs):
            return 0, 'OK', ''

    module = FakeModule()
    collector = FacterFactCollector()

    # when no facter installed
    rc, out, err = collector.run_facter(module, collector.find_facter(module))
    assert rc == 0
    assert out == 'OK'

    # when facter installed
    old_env = os.environ

# Generated at 2022-06-11 03:52:08.669010
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import collected_facts
    from ansible.module_utils._text import to_bytes

    module_mock = get_collector_instance('ansible', 'module_utils.facts.collector', 'ModuleUtilsFactsCollector')
    test_collection_path = ('./unit/data/facts/FacterFactCollector/source/')

# Generated at 2022-06-11 03:52:18.885915
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import mock

    class Module:
        def __init__(self):
            pass

        def get_bin_path(self, a, opt_dirs):
            return [True]

        def run_command(self, b):
            return [True]

    class Collected_facts:
        def __init__(self):
            pass

    module_inst = Module()
    collected_facts_inst = Collected_facts()

    facterdict = {'ansible_facter': {'facter': {'is_virtual': True},
                                     'variable': 'ansible_facter'}}
    with mock.patch('json.loads', return_value=facterdict) as mock_json_load:
        facter_fact_collector_inst = FacterFactCollector()
        assert facter_fact_collector_inst

# Generated at 2022-06-11 03:52:23.551388
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    ffc = FacterFactCollector()

    facter_path = ffc.find_facter(None)
    assert facter_path is not None

    rc, out, err = ffc.run_facter(None, facter_path)
    assert rc == 0
    assert out is not None

    facter_output = ffc.get_facter_output(None)
    assert facter_output is not None

# Generated at 2022-06-11 03:52:30.310095
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts import utils

# Generated at 2022-06-11 03:52:40.428683
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    import mock
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Instance of class FacterFactCollector
    ff = FacterFactCollector()

    # get_bin_path mock
    mock_module_get_bin_path = mock.MagicMock(return_value='/usr/bin/facter')
    module.get_bin_path = mock_module_get_bin_path

    # run_command mock
    mock_module_run_command = mock.MagicMock(return_value=(0, '{"operatingsystem": "Fedora"}', None))

# Generated at 2022-06-11 03:52:50.573504
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil
    class mock_module(object):
        def __init__(self, path):
            self.path = path
        def get_bin_path(self, name, check_mode=False, opt_dirs=[]):
            if name == 'facter':
                return os.path.join(self.path, "facter")
            elif name == 'cfacter':
                return os.path.join(self.path, "cfacter")
            else:
                return None

    with tempfile.TemporaryDirectory() as td:
        m = mock_module(td)
        f = FacterFactCollector()
        assert f.find_facter(m) is None

        open(os.path.join(td, "cfacter"), "a").close()
        assert f

# Generated at 2022-06-11 03:52:56.653548
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.system.distribution
    collector = FacterFactCollector([ansible.module_utils.facts.collector,
                                     ansible.module_utils.facts.system.facter])
    facter_path = collector.find_facter(ansible.module_utils.facts.utils)
    assert facter_path is None

# Generated at 2022-06-11 03:54:01.035856
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.utils import ModuleUtilsMock
    from ansible.module_utils.facts.collector import BaseFactCollector
    fact = FacterFactCollector(collectors=[BaseFactCollector])
    module = ModuleUtilsMock(name='ansible.module_utils.facts.linux',
                             bin_path={'facter': None})
    assert fact.find_facter(module) is None
    module = ModuleUtilsMock(name='ansible.module_utils.facts.linux',
                             bin_path={'facter': '/bin/facter'})
    assert fact.find_facter(module) == '/bin/facter'

# Generated at 2022-06-11 03:54:08.937227
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.utils import FactsLoader
    from ansible.module_utils.facts import collected_facts
    from ansible.module_utils.facts.utils import FactCollectorException

    loader = FactsLoader()
    loader.set_fact_cache(collected_facts)
    fact_collector = loader.get_fact_collector_class("facter")

    class DummyModule:
        def run_command(self, command):
            if command == 'facter --puppet --json':
                return 0, '{"os":{"name":"CentOS"}}', ''
            elif command == 'cfacter --puppet --json':
                return 0, '{"os":{"name":"CentOS"}}', ''


# Generated at 2022-06-11 03:54:17.991302
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.utils import get_file_content
    import os

    class MockModule:
        def __init__(self):
            self.called_commands = []
            self.path_exists_results = []

        def get_bin_path(self, cmd, required=False, opt_dirs=[]):
            facter_path = os.path.join(os.getcwd(), 'facter')
            if not os.path.exists(facter_path):
                os.mkdir(facter_path)

            return facter_path


# Generated at 2022-06-11 03:54:22.832763
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    def mock_run_facter(self, module, facter_path):
        return 0, '{"facter_a": 1, "facter_b": true}', ''


    FacterFactCollector.run_facter = mock_run_facter
    facter_dict = FacterFactCollector().get_facter_output('')

    assert facter_dict == '{"facter_a": 1, "facter_b": true}'



# Generated at 2022-06-11 03:54:30.068768
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeModule():
        def run_command(self, command):
            return 0, '{"kernel": "test_kernel", "operatingsystem": "test_os"}', None

        def get_bin_path(self, binary, opt_dirs=None):
            return 'test'

    module = FakeModule()
    facter_fact_collector = FacterFactCollector()
    facter_fact_collector.get_facter_output(module)
    assert facter_fact_collector.namespace._cache['facter_kernel'] == 'test_kernel'
    assert facter_fact_collector.namespace._cache['facter_operatingsystem'] == 'test_os'

# Generated at 2022-06-11 03:54:38.392118
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils import basic
    import collections

    # Create a global module object to eliminate module import
    # for method collect in class FacterFactCollector
    setattr(basic, 'AnsibleModule', basic.AnsibleModule)

    # Create a instance of class FacterFactCollector
    fact_collector = FacterFactCollector()

    # Create a FakeModule object. The method 'get_bin_path' of
    # FakeModule return "/usr/bin"
    fake_module = FakeModule(return_value="/usr/bin")

    # Run method collect
    facter_dict = fact_collector.collect(fake_module)

    # Assert the result is expected
    assert type(facter_dict) is collections.OrderedDict
    assert facter_dict == fake_module.return_value




# Generated at 2022-06-11 03:54:46.692365
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class ModuleTest:
        def get_bin_path(self, _):
            return './resources/facter_success.py'

        def run_command(self, _):
            return 0, '{"facter_test": "test"}', ''

    module = ModuleTest()
    facter_fact_collector = FacterFactCollector()

    rc, out, err = facter_fact_collector.run_facter(module, './resources/facter_success.py')
    assert rc == 0
    assert out == '{"facter_test": "test"}'
    assert err == ''

    rc, out, err = facter_fact_collector.run_facter(module, './resources/facter_fail.py')
    assert rc == 1
    assert out == ''
    assert err == 'ERROR'

# Generated at 2022-06-11 03:54:55.260540
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import MockSubProcess

    # Use a simplified version of the file defined in the 'files' list in
    # the file ansible.module_utils.facts.collector.
    # This file contains constants used by the function 'get_bin_path'
    class MockFile_bin_list(object):
        @classmethod
        def split(self, path):
            return ['path/to/bin', 'path/to/sbin', '/bin',
                    '/usr/bin', '/usr/sbin', '/sbin']

    # Configuration of the MockModule class

# Generated at 2022-06-11 03:55:04.542182
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, app, opt_dirs=None):
            return "/opt/puppetlabs/bin/facter"

        def run_command(self, cmd, check_rc=True):
            return (self.rc, self.out, self.err)

    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            self.exit_json = lambda **kwargs: kwargs
            self.fail_json = lambda **kwargs: kwargs

   

# Generated at 2022-06-11 03:55:11.818542
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import sys
    import pytest
    from ansible.module_utils.facts.collector import AnsibleModuleMock
    from ansible.module_utils.facts.collector import AnsibleModuleNoFacterPathMock
    from ansible.module_utils.facts.collector import AnsibleModuleReturnCodeOneMock
    from ansible.module_utils.facts.collector import AnsibleModuleReturnCodeTwoMock
    from ansible.module_utils.facts.collector import AnsibleModuleErrorMock

    with pytest.raises(SystemExit):
        module = AnsibleModuleMock()
        facter_path = FacterFactCollector().find_facter(module)
        facter_output = FacterFactCollector().get_facter_output(module)
        assert(facter_output is not None)