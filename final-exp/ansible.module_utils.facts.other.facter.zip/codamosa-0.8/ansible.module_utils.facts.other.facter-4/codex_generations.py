

# Generated at 2022-06-11 03:46:19.844641
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import unittest

    class FakeModule:
        def get_bin_path(self, path, opt_dirs=None):
            if path == 'facter':
                return '/facter-path'
            elif path == 'cfacter':
                return '/cfacter-path'
            return None

    module = FakeModule()

    facter_collector = FacterFactCollector()
    assert facter_collector.find_facter(module) == '/cfacter-path'

# Generated at 2022-06-11 03:46:30.415771
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # returning None when facter is not present
    def run_mock(args, check_rc=True, close_fds=True):
        return 1, '', ''
    class ModuleMock(object):
        def __init__(self):
            self.run_command = run_mock
        def get_bin_path(self, arg, opt_dirs=None):
            return None
    mod = ModuleMock()
    mod.run_command = run_mock
    ff = FacterFactCollector()
    facter_output = ff.get_facter_output(mod)
    assert facter_output is None

    # returning None when facter is present but JSON is not available
    def run_mock(args, check_rc=True, close_fds=True):
        return 0, '', ''


# Generated at 2022-06-11 03:46:41.105890
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.facts import ModuleUtilsFactsCollector

    def check_call_default(cmd, *args, **kwargs):
        return (0, "/opt/puppetlabs/bin/facter", None)

    def check_call_legacy(cmd, *args, **kwargs):
        return (0, "/path/to/facter", None)

    # Check that the default path is returned
    module = mock.Mock(**{'get_bin_path.return_value': None})
    module.check_call = check_call_default
    facter = FacterFactCollector(collectors=[ModuleUtilsFactsCollector])
    facter_path = facter.find_facter(module)

# Generated at 2022-06-11 03:46:47.807207
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    class MockModule:

        @classmethod
        def run_command(cls, command):
            return 0, '{"path":"/etc/ansible/facts.d"}', ''

        @classmethod
        def get_bin_path(cls, binname, opt_dirs=[]):
            return binname

    facter_output = FacterFactCollector().get_facter_output(MockModule)
    assert facter_output == '{"path":"/etc/ansible/facts.d"}'

# Generated at 2022-06-11 03:46:54.217796
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.fact_collector import get_collector_instance

    module = None
    fact_collector = get_collector_instance(FacterFactCollector)
    fact_collector.collect(module=module)
    collected_facts = Facts().get_facts()
    assert 'facter_facterversion' in collected_facts
    assert 'facter_operatingsystem' in collected_facts
    assert 'facter_ipaddress' in collected_facts
    assert 'facter_kernel' in collected_facts
    assert 'facter_path' in collected_facts
    assert 'facter_concat_basedir' in collected_facts
    assert 'facter_id' in collected_facts

# Generated at 2022-06-11 03:46:56.011731
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    """
    Test for method FacterFactCollector.collect
    """
    pass

# Generated at 2022-06-11 03:47:06.665943
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_lines
    facter_path = '/usr/bin/facter'
    cfacter_path = '/usr/bin/cfacter'

    # facter not found
    ffc = FacterFactCollector()
    assert ffc.find_facter({}) is None

    # facter found and expected
    mock_file_name = '/usr/bin/mockfacter'
    with open(mock_file_name, 'w') as mock_facter:
        mock_facter.write('#!/bin/sh\necho "facter"')
    import os
    os.chmod(mock_file_name, 0o755)
    ffc = Facter

# Generated at 2022-06-11 03:47:10.639281
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    module = MockAnsibleModule()
    fact_collector = FacterFactCollector()
    facter_path = fact_collector.find_facter(module)

    rc, out, err = fact_collector.run_facter(module, facter_path)
    assert(rc == 0)
    assert(out != None)
    assert(err == None)


# Generated at 2022-06-11 03:47:20.765933
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Setup mocks for ansible.module_utils.facts.collector.BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import collections

    BaseFactCollector.__repr__ = lambda x: '<BaseFactCollector>'

    fact_dict = {'test_fact': 'test_value'}


# Generated at 2022-06-11 03:47:30.784437
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import pytest
    import os
    import sys
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector

    # test_config_dir will be used to install a mocked facter binary
    test_config_dir = tempfile.mkdtemp()

    @pytest.fixture(scope="session", autouse=True)
    def ansible_config_dir(request):
        """ Set ANSIBLE_CONFIG_DIRECTORY to point to the test config dir
        """
        if 'ANSIBLE_CONFIG_DIRECTORY' in os.environ:
            del os.environ['ANSIBLE_CONFIG_DIRECTORY']

        os.environ["ANSIBLE_CONFIG_DIRECTORY"] = test_config_dir

       

# Generated at 2022-06-11 03:47:35.089722
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    module = AnsibleModule(argument_spec={})
    collector = FacterFactCollector()
    assert collector.get_facter_output(module) is None


# Generated at 2022-06-11 03:47:42.160998
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    ffc = get_collector_instance('FacterFactCollector')

# Generated at 2022-06-11 03:47:46.136432
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    ff = FacterFactCollector("ignore", "ignore")
    my_module = type('Module', (object,), {'get_bin_path': get_bin_path})
    assert ff.find_facter(my_module) == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-11 03:47:47.389267
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # TODO: implement unit test
    return

# Generated at 2022-06-11 03:47:55.289693
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # facter is present, ruby-json is present
    facter_collector = FacterFactCollector()
    out = facter_collector.get_facter_output(module='facter --puppet --json')
    assert 'ansible_system' in out
    assert 'fqdn' in out

    # facter is absent
    facter_collector = FacterFactCollector()
    out = facter_collector.get_facter_output(module='')
    assert out is None 

    # facter is present, ruby-json is absent
    facter_collector = FacterFactCollector()
    out = facter_collector.get_facter_output(module='facter --puppet')
    assert out is None

# Generated at 2022-06-11 03:48:04.648973
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    class ModuleMock:
        def __init__(self):
            self.params = dict(
                ANSIBLE_MODULE_ARGS=dict(
                    gather_subset=['!all', 'network'],
                )
            )

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == "facter":
                return "/bin/facter"
            elif executable == "cfacter":
                return "/bin/cfacter"
            else:
                return None

        def run_command(self, cmd):
            return 0, json.dumps(dict(
                a="b",
                c="d",
                e="f",
            )), ""

    module = ModuleMock()
    # Run class collect method

# Generated at 2022-06-11 03:48:14.516406
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts import module_utils
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Test get_facter_output for good and bad paths.
    class TestModuleUtils(object):
        class TestModule(object):
            def get_bin_path(self, arg, opt_dirs=''):
                bin_paths = {
                    'facter': '/bin/facter',
                    'cfacter': '/opt/puppetlabs/bin/facter',
                    'does_not_exist': None
                }
                return bin_paths[arg]


# Generated at 2022-06-11 03:48:24.127614
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class TestModule():
        def get_bin_path(self, program, opt_dirs=None):
            return program

        def run_command(self, command):
            return 0, json.dumps({'os' : {'name' : 'CentOS'}}), ""

    test_module = TestModule()
    ffcollector = FacterFactCollector()
    facter_dict = ffcollector.get_facter_output(test_module)
    assert facter_dict is not None, "get_facter_output did not return expected dictionary"
    assert 'os' in facter_dict, "Dictionary returned by get_facter_output did not contain expected key"
    os_dict = facter_dict['os']
    assert os_dict is not None, "get_facter_output did not contain expected value"


# Generated at 2022-06-11 03:48:30.169696
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    facter_output = {'a': 'b', 'c': 'd'}

    module_mock = MockModule({'run_command': (0, json.dumps(facter_output), ''),
                              'get_bin_path': '/bin/facter'})

    facter_fact_collector = FacterFactCollector()
    facter_fact = facter_fact_collector.collect(module=module_mock)
    assert facter_fact is not None
    assert facter_fact == facter_output


# Generated at 2022-06-11 03:48:39.493161
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    facter_collector = get_collector_instance(FacterFactCollector)

    assert isinstance(facter_collector, FacterFactCollector)
    assert isinstance(facter_collector, BaseFactCollector)
    assert isinstance(facter_collector.namespace, PrefixFactNamespace)
    assert facter_collector.namespace.namespace_name == 'facter'
    assert facter_collector.namespace.prefix == 'facter_'


# Generated at 2022-06-11 03:48:43.587897
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    test_collector = FacterFactCollector(namespace=None)
    assert test_collector.collect() == {}

# Generated at 2022-06-11 03:48:47.300292
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import _get_network_module

    dummy_module = _get_network_module()
    collector = FacterFactCollector()
    facter_path = collector.find_facter(dummy_module)

    assert facter_path is not None


# Generated at 2022-06-11 03:48:56.065159
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import pytest

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg, **kwargs):
            return self.params.get('bin_path')

        def run_command(self, arg):
            return self.params.get('run_command_output')

    class MockCollector(object):
        def __init__(self, params):
            self.params = params

        def collect(self, **kwargs):
            return self.params.get('collect_output', {})

    # Tests for find_facter
    facter_path_bin_path_none = MockModule({'bin_path': None})

# Generated at 2022-06-11 03:49:03.652667
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def __init__(self):
            self._bin_paths = []

        def get_bin_path(self, executable, opt_dirs=None, required=False):
            return self._bin_paths.get(executable)

        def run_command(self, command, check_rc=True, close_fds=True, exec_in_temp=None, data=None):
            self.last_command = command
            if command == '/bin/facter --puppet --json':
                stdout = b'{"facter":{"somefact":"somevalue"}}'
            elif command == '/bogus/facter --puppet --json':
                stderr = b"Facter could not find the json library"
                return 1, None, stderr
            else:
                raise Ass

# Generated at 2022-06-11 03:49:13.513690
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Testing class initialization
    facter_collector = FacterFactCollector(
        collectors=[],
        namespace=PrefixFactNamespace(namespace_name='facter', prefix='facter_'))

    # Testing method get_facter_output
    module = basic.AnsibleModule(argument_spec={})

    # Use a mock class to simulate the AnsibleModule class
    class MockAnsibleModule:
        def __init__(self, argument_spec):
            pass


# Generated at 2022-06-11 03:49:19.512493
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import os

    # common vars
    rc = 0
    out = 'stdout'
    err = 'stderr'

    # create a module mock
    class ModuleMock(object):
        def get_bin_path(self, name, opt_dirs=None):
            return os.path.join(os.path.dirname(os.path.realpath(__file__)), name)

        def run_command(self, args, check_rc=True):
            return rc, out, err

    # create a facter collector mock
    class FacterFactCollectorMock(FacterFactCollector):
        def find_facter(self, module):
            return os.path.join(os.path.dirname(os.path.realpath(__file__)), 'facter')

    #
    # 0. run

# Generated at 2022-06-11 03:49:28.557838
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # get_facter_output should return a output with the facter
    # installed on the system

    # Arrange
    class fake_module(object):
        def get_bin_path(self, bin_path, opt_dirs):
            return '/usr/bin/facter'

        def run_command(self, command):
            return 0, '{ "facter": "1.6.18" }', None

    facter = FacterFactCollector()

    # Act
    facter_output = facter.get_facter_output(fake_module())

    # Assert
    assert facter_output == '{ "facter": "1.6.18" }'


# Generated at 2022-06-11 03:49:37.761487
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Test if find_facter() returns 'facter' or 'cfacter' if either of them is present in the system
    def test_facter_or_cfacter_present(mocker, side_effect_facter_path, side_effect_cfacter_path):
        # Test that find_facter() returns 'facter' or 'cfacter'
        mocked_module = mocker.MagicMock()
        mocked_module.get_bin_path.side_effect = [side_effect_facter_path, side_effect_cfacter_path]

        facter_fact_collector = FacterFactCollector()
        test_side_effect_result = facter_fact_collector.find_facter(mocked_module)

        if side_effect_cfacter_path is not None:
            assert test_side_effect

# Generated at 2022-06-11 03:49:48.384454
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import io
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # Facter 3.x

# Generated at 2022-06-11 03:49:52.225690
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collections

    collectors = ansible_collections.ansible.community.plugins.module_utils.facts.collectors
    module = FacterFactCollector(collectors=collectors)

    module.collect()


# Generated at 2022-06-11 03:50:06.047374
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import FakeModule
    from ansible.module_utils.facts import default_collectors

    # Test module
    module = FakeModule()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='/path/to/facter')

    # Test facter collector
    facter_collector = next(c for c in default_collectors if c.name == 'facter')
    facter_output = facter_collector.get_facter_output(module)
    assert facter_output == '{}'

    # Test facter output

# Generated at 2022-06-11 03:50:15.296019
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    """
    test_FacterFactCollector_find_facter
    """
    class MockModule(object):
        def get_bin_path(self, binary, opt_dirs=None):
            """ Mock function for AnsibleModule.get_bin_path
            """
            if binary == "cfacter":
                return "/opt/puppetlabs/bin/cfacter"
            elif binary == "facter":
                return "/opt/puppetlabs/bin/facter"

    mock_module = MockModule()
    facter_fact_collector = FacterFactCollector()
    facter_path = facter_fact_collector.find_facter(mock_module)

    assert facter_path == "/opt/puppetlabs/bin/cfacter"


# Generated at 2022-06-11 03:50:15.827046
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass

# Generated at 2022-06-11 03:50:24.308414
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    test_module = MockModuleUtils()
    test_module.get_bin_path = lambda x, opt_dirs: opt_dirs[0] + "/bin/" + x

    facter_path = FacterFactCollector().find_facter(test_module)
    assert facter_path == '/opt/puppetlabs/bin' + '/bin/' + 'cfacter'

    # if cfacter is not available, use facter
    test_module.get_bin_path = lambda x, opt_dirs: opt_dirs[0] + "/bin/" + x
    facter_path = FacterFactCollector().find_facter(test_module)
    assert facter_path == '/opt/puppetlabs/bin' + '/bin/' + 'facter'

    test_module.get_bin_

# Generated at 2022-06-11 03:50:29.523331
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test that get_facter_output returns None if facter_path does not exist.
    class Module:
        def get_bin_path(self, name, opt_dirs=None):
            return None

    facter_collector = FacterFactCollector()
    facter_output = facter_collector.get_facter_output(Module())

    assert facter_output == None

    # Fix facter_path so that FacterFactCollector.run_facter is called.
    class Module:
        def get_bin_path(self, name, opt_dirs=None):
            return '/bin/facter'


# Generated at 2022-06-11 03:50:34.594136
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible_module_template
    module = ansible_module_template.MyModule(argument_spec={})
    module.run_command = lambda x: (0, '{"version":"3.0.0", "value":{"facter_version":"3.0.0"}}', '')
    module.get_bin_path = lambda x: '/path/to/facter'

    fact_collector = FacterFactCollector()
    facter_facts = fact_collector.collect(module=module)
    assert 'facter_version' in facter_facts, 'facter facts are missing'
    assert facter_facts['facter_version'] == '3.0.0', 'incorrect facter version'

# Generated at 2022-06-11 03:50:44.377523
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # because we want to add a method to a class, we must dynamically create
    # a new class with our extra methods and type it as the old class
    # https://www.python.org/dev/peps/pep-0362/
    class subFactClass(FacterFactCollector):
        def find_facter(self, module):
            return '/facter_path'

        def run_facter(self, module, facter_path):
            return 0, '{"dummy_fact": "dummy_value"}', ''

        def get_facter_output(self, module):
            return None

    # create an instance of the class for test
    testClass = subFactClass(None)

    # create a dummy module for test

# Generated at 2022-06-11 03:50:54.294808
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import sys
    from ansible.module_utils._text import to_bytes

    try:
        from unittest import mock
    except ImportError:
        try:
            import mock  # python2
        except ImportError:
            mock = None

    class ModuleStub(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            if 'cfacter' in args:
                return '/usr/local/bin/cfacter'
            return '/usr/local/bin/facter'

    module = ModuleStub()
    collector = FacterFactCollector()

    assert(collector.find_facter(module) == module.get_bin_path('cfacter'))


# Generated at 2022-06-11 03:51:01.856422
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    mod = MockModule()
    c = FacterFactCollector()

    assert not c.find_facter(mod)

    mod.bin_path = {
        'facter': '/usr/bin/facter',
    }
    assert c.find_facter(mod) == '/usr/bin/facter'

    mod.bin_path = {
        'cfacter': '/usr/bin/cfacter',
    }
    assert c.find_facter(mod) == '/usr/bin/cfacter'

    mod.bin_path = {
        'facter': '/usr/bin/facter',
        'cfacter': '/usr/bin/cfacter',
    }
    assert c.find_facter(mod) == '/usr/bin/cfacter'


# Generated at 2022-06-11 03:51:10.759055
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import ansible_collected_facts
    # Test when no module is passed
    facter_dict = FacterFactCollector().collect()

    assert facter_dict == {}

    # Test when no facter output is generated
    class MockModule:
        def __init__(self):
            self.called = False
            self.rc = 0
            self.err = ''
            self.out = ''

        def get_bin_path(self, app, opt_dirs=None):
            return None

    facter_dict = FacterFactCollector().collect(module=MockModule())
    assert facter_dict == {}


    # Test when facter output is generated
    class MockModule:
        def __init__(self):
            self.called = False
            self.rc = 0

# Generated at 2022-06-11 03:51:26.920854
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create a DummyModule to use for testing
    class DummyModule():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=None):
            if executable == 'facter':
                return 'facter'
            elif executable == 'cfacter':
                return None
            else:
                return None

        def run_command(self, args):
            if args == 'facter --puppet --json':
                return 0, '{"os": {"family": "RedHat", "release": {"major": "6", "minor": "3"}, "name": "CentOS"}, "puppetversion": "3.0.1"}', ''
            else:
                return None, None, None

    module = DummyModule()

    fact_collector = Facter

# Generated at 2022-06-11 03:51:36.055094
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.fact_collector import setup_collector
    from ansible.module_utils.facts.fact_collector import FactCollector

    module = basic.AnsibleModule(argument_spec={})

    FacterFactCollector.run_facter = lambda x, y: (0, to_bytes('{"networking":{"hostname":"localhost.localdomain"}}'), '')
    facter_path = FacterFactCollector(namespace=None).find_facter(module)

    collector = FactCollector(module=module,
                              collectors=[FacterFactCollector],
                              namespace=None)
    facts = collector.collect(module=module)



# Generated at 2022-06-11 03:51:38.677133
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = MockModule()
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-11 03:51:39.580440
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # TODO
    pass


# Generated at 2022-06-11 03:51:47.735301
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    import tempfile

    facter_path = tempfile.mkstemp()[1]

    # Create a facter executable
    with open(facter_path, 'w') as facter_file:
        facter_file.write('#!/usr/bin/env python\nimport sys\n')
        facter_file.write('print(r\'"facter": {"memory": {"system": {"total": "8.00 GB"}}}\')')

    import ansible.module_utils.facts.collector

    class MockModule:

        def run_command(self, cmd):
            return 0, '{} --json'.format(facter_path), ''


# Generated at 2022-06-11 03:51:52.235160
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = {
        'get_bin_path': lambda s: '/usr/bin/facter',
        'run_command': get_facter_output,
    }
    facter_dict = FacterFactCollector().collect(module=module)
    assert facter_dict['facter_puppetversion'] == '4.4.0'


# Generated at 2022-06-11 03:51:52.785320
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    pass

# Generated at 2022-06-11 03:52:01.482446
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils import facts
    import ansible.module_utils.facts.collector

    # Set up the test class in a similar fashion to what happens in the Facts class
    collector_class = FacterFactCollector
    custom_fact_class = ansible.module_utils.facts.collector.CustomFactCollector
    all_collectors = [custom_fact_class, collector_class]

    collector_obj = collector_class(all_collectors)
    custom_fact_obj = custom_fact_class(collector_obj)
    all_collectors = [custom_fact_obj, collector_obj]

    (test_module, test_module_path) = facts.get_test_module()
    assert collector_obj.get_facter_output(test_module) is None

# Generated at 2022-06-11 03:52:10.524359
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():

    import mock
    import unittest
    import os

    # declaring FacterFactCollector class
    class FacterFactCollector(FacterFactCollector):

        # declaring find_facter method,
        # overriding the one in FacterFactCollector
        def find_facter(self, module):
            return "/usr/bin/facter"

    class TestFacterFactCollector(unittest.TestCase):

        # find_facter method test
        @mock.patch('ansible.module_utils.facts.collector.FacterFactCollector.find_facter')
        def test_run_facter(self, mock_facter):
            mock_facter.return_value = "/usr/bin/facter"

# Generated at 2022-06-11 03:52:20.277758
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # If a module instance is passed in it should return the same result as
    # the module's get_bin_path method.
    #
    # Create a fakes module.
    class FakeModule():
        class FakeRunCommand():
            rc = 0
            out = '\"1.8.4\"'
            err = ''

        bin_path_cache = {}
        run_command_cache = {}

        def __init__(self):
            pass

        def has_bin_module(self):
            return True

        def get_bin_path(self, executable, opt_dirs=None):
            if executable in self.bin_path_cache:
                return self.bin_path_cache[executable]

            path = None

            if executable == 'facter':
                path = '/usr/bin/facter'


# Generated at 2022-06-11 03:52:48.839514
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import ModuleStub
    from ansible.module_utils._text import to_bytes

    # create a stub for the module
    module_stub = ModuleStub()

    # create an instance
    ffc = get_collector_instance('facter')

    facter_path = ffc.find_facter(module_stub)
    if facter_path is None:
        rc, out, err = 1, None, None
    else:
        rc, out, err = ffc.run_facter(module_stub, facter_path)

    if rc != 0:
        if out is None:
            out = to_bytes('')

# Generated at 2022-06-11 03:52:54.996631
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    module.params = dict(
        ansible_path=[
            "./ansible",
            "./testing"
        ]
    )
    # On Travis, facter_path returns none, as it isnt installed.
    # On local testing, facter_path returns "/usr/bin/facter"
    facter_path = FacterFactCollector(collectors=None, namespace=None).find_facter(module)
    assert facter_path is not None

# Generated at 2022-06-11 03:53:03.952915
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.modules.system.setup import __file__ as setup_file
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.facts.collector.facter import FacterFactCollector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import os
    import sys

    # AnsibleModule and DebugModule functions
    def AnsibleModule_exit_json(*args, **kwargs):
        raise Exception('exit_json called!')

    def AnsibleModule_fail_json(*args, **kwargs):
        raise Exception('fail_json called!')

    # AnsibleModule
    orig_exit_json = AnsibleModule.exit_json
    AnsibleModule.exit_json = Ansible

# Generated at 2022-06-11 03:53:10.548579
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.other.facter import FacterFactCollector
    from ansible.module_utils.facts.test_utils import DummyModule

    test_module = DummyModule()
    test_module.run_command = lambda x: (0, "{\"foo\":\"bar\"}", None)
    test_module.get_bin_path = lambda x: x

    facter_collector = FacterFactCollector()
    rc, json_facter, err = facter_collector.run_facter(test_module, '/dummy/facter')
    assert rc == 0
    assert err is None
    assert json_facter == '{"foo": "bar"}'


# Generated at 2022-06-11 03:53:11.819556
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO: Add tests for function FacterFactCollector.get_facter_output
    pass

# Generated at 2022-06-11 03:53:17.446568
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    collector = FacterFactCollector()
    class MockModule(object):
        class MockRunCommand(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err
            def __call__(self, cmd):
                return (self.rc, self.out, self.err)
        def __init__(self, run_command):
            self.run_command = run_command
    class MockWhich(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path
        def __call__(self, cmd, opt_dirs=None):
            return self.facter_path

    facter_path = '/usr/bin/facter'

# Generated at 2022-06-11 03:53:23.270770
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, '{"software":{"svc_usr":"svc_usr","svc_grp":"svc_grp", "syslog_facility":"syslog_facility"},"hostname":"hostname"}', ''

        def get_bin_path(self, cmd):
            return 'facter_bin_path'

    class MockFactCollector(FacterFactCollector):
        def run_facter(self, module, facter_path):
            return 0, '{"software":{"svc_usr":"svc_usr","svc_grp":"svc_grp", "syslog_facility":"syslog_facility"},"hostname":"hostname"}', ''

    facter_collector = MockFactCollector()
    module = MockModule()
   

# Generated at 2022-06-11 03:53:29.943538
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import DictCollector
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils._text import to_bytes
 
    # Build some parameters for our method to test
    fake_collectors = [DictCollector({'test_collector': {'test_fact': 'test'}})]
    namespace = FactNamespace('test_namespace')

    # Call the method we're testing
    facter_collector = FacterFactCollector(collectors=fake_collectors, namespace=namespace)
    facts = facter_collector.collect()

    # Check that the facts variable is what we expect
    expected_facts = {'facter_test_fact': 'test'}
    if facts != expected_facts:
        raise Exception

# Generated at 2022-06-11 03:53:38.547970
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # Mock of ansible module
    setattr(module, 'run_command', lambda x: (0, '{"kernel":"Linux"}', ''))
    setattr(module, 'get_bin_path', lambda x: '/usr/bin/facter')

    facter_fact_collector = FacterFactCollector()

    # Collect facter facts
    facter_facts = facter_fact_collector.collect(module=module)

    # Assert type of facter facts
    assert isinstance(facter_facts, dict)

# Generated at 2022-06-11 03:53:47.258222
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import re
    import sys
    import os

    # Fake info if this is windows
    platform = sys.platform
    is_windows = isinstance(platform, str) and re.match('^win.*', platform)

    # Importing module_utils has the side effect of loading all the packages
    # that are contained by it. If it is not done here, then the subsequent
    # import of the module module does not work.
    from ansible.module_utils import basic

    # Force loading of modules from the same directory as facts.
    module_utils_path = os.path.dirname(basic.__file__)
    sys.path.insert(0, module_utils_path)

    from ansible.module_utils.facts import module

    # This is required so that the importer that loads ansible.module_utils.basic
    # does

# Generated at 2022-06-11 03:54:33.980059
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    mock_module = MockAnsibleModule("set")
    facter = FacterFactCollector()

    print("test_FacterFactCollector_run_facter: EXISTS")

# Generated at 2022-06-11 03:54:35.816322
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    collector = FacterFactCollector()
    # If no facter binary is found an empty string is returned
    assert collector.find_facter(None) == ''

# Generated at 2022-06-11 03:54:39.792105
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    executable = "/bin/true"
    module = MockModule(executable)
    fact_collector = FacterFactCollector()

    facter_path = fact_collector.find_facter(module)
    assert facter_path == executable

    facter_output = fact_collector.get_facter_output(module)
    assert facter_output is None


# Generated at 2022-06-11 03:54:48.340650
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    facter_fact_collector = FacterFactCollector()
    class fake_module:
        def get_bin_path(self, facter, opt_dirs):
            return '/opt/puppetlabs/bin/facter'
        def run_command(self, command_string):
            return 0, '{"test":"test", "test2":"test2"}', ""
    # Can't assertEqual to a dict because the order of the items in the dict
    # does not matter in Python 3.5 (it does matter in later versions).
    # So need to assertEqual to a string representation of the dict.
    assert facter_fact_collector.get_facter_output(fake_module()).strip() == '{"test": "test", "test2": "test2"}'


# Generated at 2022-06-11 03:54:56.999319
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Importing is not trivial because get_facter_output depends on the
    # ansible.module_utils.common.run_command method, which is imported in the
    # module_utils/facts/collector.py file.
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import set_collector_instance

    # Clean up the environment
    set_collector_instance(None)

    # Create the mock module
    module = type('AnsibleModule', (object,),
                  {'run_command': Mock(return_value=(0, '{}', ''))})()

    # Create a collector instance

# Generated at 2022-06-11 03:55:06.027970
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    file_content = get_file_content('facter.json')
    base_collector = BaseFactCollector(None, PrefixFactNamespace(namespace_name='facter', prefix='facter_'))
    # Create an instance of FacterFactCollector to use the method
    # get_facter_output
    fact_collector = FacterFactCollector(None, base_collector._namespace)

    class Module(object):
        def __init__(self, path, command_stdout):
            self.path = path
            self.command_stdout = command_stdout


# Generated at 2022-06-11 03:55:13.199712
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils import facts

    # case 1: facter is not installed
    class TestModule1(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = None
            self.run_command_out = None
            self.run_command_err = None
            self.run_command_command = None

        _ansible_sys = SystemFactCollector()

        def get_bin_path(self, binary, opt_dirs=None):
            return None

        def run_command(self, command):
            self.run_command_called = True
            self.run_command_command = command
            return self.run_command_rc, self.run

# Generated at 2022-06-11 03:55:20.306141
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    class Module:
        def get_bin_path(self, binary, opt_dirs=None, required=False):
            return bin_path

        def run_command(self, cmd):
            return rc, out, err

    bin_path = None
    rc = 1
    out = ''
    err = ''

    facter_collector = FacterFactCollector()
    facter_facts = facter_collector.collect(Module())
    assert len(facter_facts) == 0

    bin_path = '/path/to/facter'
    rc = 0

# Generated at 2022-06-11 03:55:27.711304
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():

    class FakeModule:
        def __init__(self, bin_path):
            self.bin_path = bin_path
        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == 'cfacter':
                return self.bin_path + cmd
            else:
                return self.bin_path + 'facter'

    cfacter_exists = FakeModule('/opt/puppetlabs/bin/')
    facter_path = FacterFactCollector().find_facter(cfacter_exists)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'

    cfacter_not_exists = FakeModule('/usr/bin/')
    facter_path = FacterFactCollector().find_facter(cfacter_not_exists)
   

# Generated at 2022-06-11 03:55:32.292974
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector.facter
    from ansible.module_utils.facts.collector import get_collection_module

    module = get_collection_module('facter')
    facter_path, cfacter_path = ansible.module_utils.facts.collector.facter.find_facter(module)

    assert facter_path or cfacter_path
