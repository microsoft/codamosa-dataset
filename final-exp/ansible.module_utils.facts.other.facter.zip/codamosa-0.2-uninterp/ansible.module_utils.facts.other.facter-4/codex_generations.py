

# Generated at 2022-06-17 01:14:13.142313
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    collector = Collector()
    collector.add_collector(TestCollector())
    fact_collector = get_collector_instance(collector, 'test')

    class TestModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            return '/usr/bin/facter'


# Generated at 2022-06-17 01:14:22.692193
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:14:32.065387
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Get the FacterFactCollector instance
    facter_collector = get_collector_instance('facter')

    # Get the list of available collectors
    collectors = list_collectors()

    # Get the list of available fact_ids
    fact_ids = get_collector_names()

    # Test the find_facter method
    facter_path = facter_collector.find_facter(module=None)

    # Test the list_collectors method
    assert 'facter' in collectors

    # Test the get_collector_names method

# Generated at 2022-06-17 01:14:43.778333
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.vmware
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.kvm
    import ansible.module_utils.facts.virtual.openvz

# Generated at 2022-06-17 01:14:52.451595
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_names_for
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:15:02.154704
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_legacy_collectors

# Generated at 2022-06-17 01:15:11.116973
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module path
    old_pythonpath = os.environ.get('PYTHONPATH', '')
    os.environ['PYTHONPATH'] = tmpdir

    # Create a temporary module utils lookup path
    old_module_utils_path = sys.path[:]
    sys.path.append(tmpdir)

    # Create a temporary ansible module utils path
    old_ansible_module_utils_path = os.environ.get('ANSIBLE_MODULE_UTILS', '')
    os.environ['ANSIBLE_MODULE_UTILS'] = tmpdir

    # Create a temporary ansible module utils path
    old_ans

# Generated at 2022-06-17 01:15:21.524459
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_all_fact_collectors

# Generated at 2022-06-17 01:15:27.804529
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_namespace
    from ansible.module_utils.facts.collector import get_collector_class_namespaces


# Generated at 2022-06-17 01:15:37.282293
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test": "test"}', ''

    facter_collector = FacterFactCollector()
    module = MockModule()
    facter_output = facter_collector.get_facter_output(module)
    assert facter_output == '{"facter_test": "test"}'

# Generated at 2022-06-17 01:15:50.161383
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 01:16:01.077998
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:05.410695
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    facter_collector = get_collector_instance('facter')
    assert facter_collector.find_facter(None) is None


# Generated at 2022-06-17 01:16:15.621952
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils._text import to_bytes
    import json

    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'facter']

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, json.dumps({'facter': 'test'}), ''

    class MockFactCollector(BaseFactCollector):
        name

# Generated at 2022-06-17 01:16:28.442669
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import _get_collector_instance
    from ansible.module_utils.facts.collector import _get_collector_class
    from ansible.module_utils.facts.collector import _get_collector_class_name
    from ansible.module_utils.facts.collector import _get_collector_class_path
    from ansible.module_utils.facts.collector import _get_collector_class_paths
    from ansible.module_utils.facts.collector import _get_collector_class_paths_from_module_utils

# Generated at 2022-06-17 01:16:37.397610
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    class FakeModule:
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

    class FakeCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            pass

    class FakeNamespace(ansible.module_utils.facts.namespace.BaseFactNamespace):
        def __init__(self, namespace_name, prefix):
            pass

    facter_collector = FacterFact

# Generated at 2022-06-17 01:16:42.249816
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:50.053424
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test with facter installed
    class MockModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test": "test"}', ''

    facter_path = '/usr/bin/facter'
    module = MockModule(facter_path)
    facter_collector = FacterFactCollector()
    facter_output = facter_collector.get_facter_output(module)
    assert facter_output == '{"facter_test": "test"}'

    # Test with facter not installed
    module = MockModule

# Generated at 2022-06-17 01:17:00.606586
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.virtual

    class FakeModule:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            if name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            return None


# Generated at 2022-06-17 01:17:13.319186
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_namespace_names
    from ansible.module_utils.facts.collector import get_collectors_for_namespace_paths
    from ansible.module_utils.facts.collector import get_collectors_for_namespace_path_names

# Generated at 2022-06-17 01:17:26.920475
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collectors.facter import FacterFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_stat

# Generated at 2022-06-17 01:17:35.935960
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import _get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors

# Generated at 2022-06-17 01:17:45.920484
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/bin/facter'


# Generated at 2022-06-17 01:17:56.767854
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:17:59.712369
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    module = MockModule()
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/usr/bin/facter'


# Generated at 2022-06-17 01:18:13.448239
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path=None):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=None):
            return self.bin_path

        def run_command(self, command):
            return 0, '{"a": "b"}', ''

    class MockCollector(object):
        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors
            self.namespace = namespace


# Generated at 2022-06-17 01:18:24.524036
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6

# Generated at 2022-06-17 01:18:34.293201
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.collectors.pkg_mgr
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.dmi
    import ansible.module_utils.facts.collectors.file_system
    import ansible.module_utils.facts.collectors.identity

# Generated at 2022-06-17 01:18:45.356064
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test": "test"}', ''


# Generated at 2022-06-17 01:18:51.536786
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class FakeModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class FakeFactCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        name = 'fake'
        _fact_ids = set(['fake'])

        def collect(self, module=None, collected_facts=None):
            return {'fake': 'fake'}


# Generated at 2022-06-17 01:19:11.543334
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_instance
    from ansible.module_utils.facts.collector import get_fact_collector_instances
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_namespaces

# Generated at 2022-06-17 01:19:22.813550
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path

        def run_command(self, *args, **kwargs):
            return 0, '{"test": "test"}', ''

    module = TestModule(bin_path='/usr/bin/facter')
    facter_collector = get_collector_instance(FacterFactCollector)

# Generated at 2022-06-17 01:19:32.539661
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_by_name
    from ansible.module_utils.facts.collector import get_collector_class_by_fact_id
    from ansible.module_utils.facts.collector import get_collector_class_by_fact_name
    from ansible.module_utils.facts.collector import get

# Generated at 2022-06-17 01:19:41.170201
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_

# Generated at 2022-06-17 01:19:53.821566
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=None):
            return self.bin_path

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='mock',
                                            prefix='mock_')


# Generated at 2022-06-17 01:20:05.670209
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_for_type
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collector_for_namespace
    from ansible.module_utils.facts.collector import get_collector_for_platform

# Generated at 2022-06-17 01:20:14.155926
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=None):
            return self.bin_path

    class MockFactCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='mock',
                                            prefix='mock_')

# Generated at 2022-06-17 01:20:24.388885
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module
    module = type('FakeModule', (object,), {'get_bin_path': lambda self, executable, opt_dirs=None: os.path.join(tmpdir, executable)})

    # Create a temporary facter executable
    facter = os.path.join(tmpdir, 'facter')
    with open(facter, 'w') as f:
        f.write('#!/bin/sh\necho facter\n')
    os.chmod(facter, 0o755)

    # Create a temporary cfacter executable
    cfacter = os.path.join(tmpdir, 'cfacter')

# Generated at 2022-06-17 01:20:34.747209
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names

    # Create a FacterFactCollector instance
    facter_collector = get_collector_instance('facter')

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['_ansible_version'] = '2.3.0.0'
            self.params['_ansible_module_name'] = 'setup'
            self.params['_ansible_debug'] = False
            self.params['_ansible_diff'] = False
            self.params['_ansible_verbosity'] = 0

# Generated at 2022-06-17 01:20:45.007400
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import sys
    import tempfile
    import shutil
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a fake facter binary
    facter_path = os.path.join(tmpdir, 'facter')
    with open(facter_path, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("echo '{\"facter_test_fact\": \"facter_test_value\"}'\n")
    os.chmod(facter_path, 0o755)

    # Create a fake ansible module

# Generated at 2022-06-17 01:21:17.767584
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.facter
    import ansible.module_utils.facts.ohai
    import ansible.module_utils.facts.pip
    import ansible.module_utils.facts.pkg_mgr
    import ansible.module_utils.facts.service_mgr
    import ansible.module_utils.facts.systemd
    import ansible.module_utils.facts.system_info

# Generated at 2022-06-17 01:21:26.170181
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:21:37.897299
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFileCacheCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/usr/bin/facter'
            elif executable == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None


# Generated at 2022-06-17 01:21:47.998539
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'facter':
                return '/usr/bin/facter'
            elif binary == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None


# Generated at 2022-06-17 01:21:59.310857
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import Facts
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors

# Generated at 2022-06-17 01:22:11.253297
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter

# Generated at 2022-06-17 01:22:22.792897
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, command):
            return self.run_command_results.pop(0)

    # Create a mock module
    module = MockModule()

    # Create a FacterFactCollector object
    facter_fact_collector = FacterFactCollector()

    # Create a mock facter output

# Generated at 2022-06-17 01:22:28.686104
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.facter

    class FakeModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return self.path

    class FakeFacterFactCollector(ansible.module_utils.facts.collector.FacterFactCollector):
        def run_facter(self, module, facter_path):
            return 0, '{"facter_output": "test"}', ''

    module = FakeModule('/usr/bin/facter')
    facter_

# Generated at 2022-06-17 01:22:37.333922
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockModule(object):
        def __init__(self, facter_path, facter_output):
            self.facter_path = facter_path
            self.facter_output = facter_output

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, *args, **kwargs):
            return (0, self.facter_output, '')


# Generated at 2022-06-17 01:22:45.934476
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a fake facter binary
    facter_path = os.path.join(tmpdir, 'facter')
    with open(facter_path, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("echo '{\"facter\": \"test\"}'\n")
    os.chmod(facter_path, 0o755)

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.path = tmpdir

        def get_bin_path(self, *args, **kwargs):
            return facter_path


# Generated at 2022-06-17 01:23:52.356488
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:24:02.633582
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['_ansible_version'] = '2.4.0.0'
            self.params['_ansible_syslog_facility'] = 'LOG_USER'
            self.params['_ansible_debug'] = False
            self.params['_ansible_no_log'] = False
            self.params['_ansible_verbosity'] = 0
            self.params['_ansible_socket'] = None