

# Generated at 2022-06-17 01:14:14.708250
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, command):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:14:24.715457
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule:
        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_foo": "bar"}', ''

    module = MockModule()
    facter_collector = FacterFactCollector()
    facter_output = facter_collector.get_facter_output(module)

    assert facter_output == '{"facter_foo": "bar"}'

# Generated at 2022-06-17 01:14:35.736052
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone.zone_info
    import ansible.module_utils.facts.system.zone.zone_info.zone_info_solaris

# Generated at 2022-06-17 01:14:43.164126
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"foo": "bar"}', ''

    module = MockModule()
    facter_collector = FacterFactCollector()
    facter_output = facter_collector.get_facter_output(module)
    assert facter_output == '{"foo": "bar"}'

# Generated at 2022-06-17 01:14:52.191451
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''


# Generated at 2022-06-17 01:15:01.710270
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import get_namespace_instance
    from ansible.module_utils.facts.namespace import get_namespace_names
    from ansible.module_utils.facts.namespace import list_namespaces

# Generated at 2022-06-17 01:15:10.783528
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test that the FacterFactCollector is available
    assert 'facter' in get_collector_names()

    # Test that the FacterFactCollector is available
    assert 'facter' in list_collectors()

    # Test that the FacterFactCollector is available
    facter_collector = get_collector_instance('facter')
    assert facter_collector is not None

    # Test that the FacterFactCollector is available
    facter_collector = get_collector_instance('facter')
    assert facter_collector is not None



# Generated at 2022-06-17 01:15:21.253476
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-17 01:15:30.721442
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Create a FacterFactCollector instance
    facter_collector = get_collector_instance(FacterFactCollector)

    # Create a BaseFactCollector instance
    base_collector = BaseFactCollector()

    # Create a PrefixFactNamespace instance
    prefix_fact_namespace = PrefixFactNamespace(namespace_name='facter',
                                                prefix='facter_')

    # Create a FacterFactCollector instance with a BaseFactCollector and a PrefixFactNamespace
    facter_collector_with_base_collector_and_prefix

# Generated at 2022-06-17 01:15:40.954529
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    class MockModule:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, binary, opt_dirs=None):
            return self.bin_path

    facter_path = '/usr/bin/facter'
    cfacter_path = '/usr/bin/cfacter'

    # Test case 1: facter_path is not None, cfacter_path is None
    module = MockModule(bin_path=facter_path)
    collector = FacterFactCollector(namespace=ansible.module_utils.facts.namespace.PrefixFactNamespace(namespace_name='facter', prefix='facter_'))


# Generated at 2022-06-17 01:15:54.060281
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace_path
    from ansible.module_utils.facts.collector import get_collectors_for_type_path

# Generated at 2022-06-17 01:16:06.363666
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError

# Generated at 2022-06-17 01:16:16.210420
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    # Create a mock module
    module = ansible.module_utils.facts.utils.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    # Create a mock BaseFactCollector
    base_fact_collector = ansible.module_utils.facts.collector.BaseFactCollector(
        collectors=None,
        namespace=ansible.module_utils.facts.namespace.BaseFactNamespace()
    )

    # Create a mock PrefixFactNamespace

# Generated at 2022-06-17 01:16:28.607332
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceFactDict
    from ansible.module_utils.facts.namespace import NamespaceFactList
    from ansible.module_utils.facts.namespace import NamespaceFactString
    from ansible.module_utils.facts.namespace import NamespaceFactBool
    from ansible.module_utils.facts.namespace import NamespaceFactInt

# Generated at 2022-06-17 01:16:33.925042
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:46.252987
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, executable):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:16:58.510973
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test with facter installed
    module = MockModule()
    module.run_command = Mock(return_value=(0, '{"facter_test": "test_value"}', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/facter')
    facter_collector = FacterFactCollector()
    facter_facts = facter_collector.collect(module=module)
    assert facter_facts == {'facter_test': 'test_value'}

    # Test with facter not installed
    module = MockModule()
    module.get_bin_path = Mock(return_value=None)
    facter_collector = FacterFactCollector()
    facter_facts = facter_collector.collect(module=module)
    assert facter_facts == {}

# Generated at 2022-06-17 01:17:12.435194
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=None):
            return self.bin_path

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set(['fake'])

        def collect(self, module=None, collected_facts=None):
            return {'fake': 'fake'}


# Generated at 2022-06-17 01:17:21.876667
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_for_fact
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:17:31.425305
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:17:45.880283
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_fact_collect

# Generated at 2022-06-17 01:17:48.079952
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    collected_facts = None
    facter_dict = FacterFactCollector().collect(module, collected_facts)
    assert isinstance(facter_dict, dict)

# Generated at 2022-06-17 01:17:59.415201
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    class TestModule(object):
        def __init__(self, facter_path, facter_output):
            self.facter_path = facter_path
            self.facter_output = facter_output

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, *args, **kwargs):
            return 0, self.facter_output, ''


# Generated at 2022-06-17 01:18:13.373354
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:18:24.472269
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:18:31.193080
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_path
    from ansible.module_utils.facts.collector import get_collectors_for_category
    from ansible.module_utils.facts.collector import get_collectors_for_category_in_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_category_in_path

# Generated at 2022-06-17 01:18:40.811559
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:18:50.812837
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_names_for_namespace
    from ansible.module_utils.facts.collector import get_

# Generated at 2022-06-17 01:18:59.904866
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test_fact": "test_value"}', ''

# Generated at 2022-06-17 01:19:10.827856
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_name
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name


# Generated at 2022-06-17 01:19:25.220872
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.pkg_mgr
    import ansible.module_utils.facts.collectors.distribution
    import ansible.module_utils.facts.collectors.service_mgr

# Generated at 2022-06-17 01:19:32.362227
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test_fact": "test_value"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:19:41.091624
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return self.bin_path
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test": "test"}', ''

# Generated at 2022-06-17 01:19:53.725278
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class FakeCollector:
        def __init__(self):
            self.namespace = ansible.module_utils.facts.namespace.BaseFactNamespace()

    class FakeCollector2:
        def __init__(self):
            self.namespace = ansible.module_utils.facts.namespace

# Generated at 2022-06-17 01:20:05.666145
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system.distribution.windows
    import ansible.module_utils.facts.system.distribution.freebsd


# Generated at 2022-06-17 01:20:14.156414
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=[]):
            return self.bin_path

        def run_command(self, cmd):
            return 0, '{"facter_test_fact": "test_value"}', ''

    # Test with facter installed
    module = MockModule('/usr/bin/facter')
    facter_collector

# Generated at 2022-06-17 01:20:24.619772
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.args = {}
            self.tmpdir = '/tmp'

        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == 'facter':
                return '/usr/bin/facter'
            elif cmd == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

       

# Generated at 2022-06-17 01:20:34.972097
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import ModuleUtilsFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModuleUtilsFacts(ModuleUtilsFacts):
        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'facter':
                return '/usr/bin/facter'
            elif arg == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None


# Generated at 2022-06-17 01:20:45.314678
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create a FacterFactCollector object
    facter_fact_collector = FacterFactCollector()

    # Create a mock module
    class MockModule:
        def get_bin_path(self, arg1, arg2=None):
            return '/usr/bin/facter'

        def run_command(self, arg1):
            return 0, '{"facter_test": "test"}', ''

    # Create a mock module object
    mock_module = MockModule()

    # Call the collect method of FacterFactCollector object
    facter_facts = facter_fact_collector.collect(mock_module)

    # Check if the facter_facts is not empty
    assert facter_facts

    # Check if the facter_facts is a dict
    assert isinstance(facter_facts, dict)

   

# Generated at 2022-06-17 01:20:55.308151
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector

# Generated at 2022-06-17 01:21:25.494092
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module
    module = type('AnsibleModule', (object,), {
        'run_command': run_command,
        'get_bin_path': get_bin_path,
    })

    # Create a temporary facter script
    facter_path = os.path.join(tmpdir, 'facter')
    with open(facter_path, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("echo '{\"facter\": \"fact\"}'\n")
    os.chmod(facter_path, 0o755)

    # Create a temporary

# Generated at 2022-06-17 01:21:33.384169
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary 'facter' executable
    facter_path = os.path.join(tmpdir, "facter")
    with open(facter_path, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("echo '{\"facter_test\": \"test_value\"}'\n")
    os.chmod(facter_path, 0o755)

    # Create a temporary ansible module
    module_path = os.path.join(tmpdir, "ansible_module_test.py")
    with open(module_path, 'w') as f:
        f

# Generated at 2022-06-17 01:21:42.139163
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create a mock module
    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command_results = []

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            if name == 'cfacter':
                return None
            return None

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    # Create a mock module with a facter command that returns a valid json
    module = MockModule()
    module.run_command_results.append((0, '{"facter_foo": "bar"}', ''))
    facter_collector = FacterFactCollector()
    facter_facts = facter_collector

# Generated at 2022-06-17 01:21:53.501600
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_instance
    from ansible.module_utils.facts.collector import get_fact_collector_instances
    from ansible.module_utils.facts.collector import get_fact_collector_names

# Generated at 2022-06-17 01:22:04.108406
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import list_collectors

    # Test that the FacterFactCollector is available
    assert 'facter' in get_collector_names()

    # Test that the FacterFactCollector is available
    assert get_collector_for('facter') is not None

    # Test that the FacterFactCollector is available
    assert get_collector_instance('facter') is not None

    # Test that the FacterFactCollector is available
    assert 'facter' in list_collectors()

    # Test that the

# Generated at 2022-06-17 01:22:14.349061
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    module = ansible.module_utils.facts.collector.BaseFactCollector()
    facter_path = ansible.module_utils.facts.collectors.facter.FacterFactCollector.find_facter(module)
    rc, out, err = ansible.module_utils.facts.collectors.facter.FacterFactCollector.run_facter(module, facter_path)
    assert rc == 0
    assert out is not None
    assert err is None


# Generated at 2022-06-17 01:22:23.018635
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.collectors.facter

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['gather_facts'] = True

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'


# Generated at 2022-06-17 01:22:34.077464
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespace
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exception
    from ansible.module_utils.facts.collector import get_collector_exception_only
    from ansible.module_utils.facts.collector import get_collector_exception_msg
    from ansible.module_utils.facts.collector import get_collector_exception_traceback

# Generated at 2022-06-17 01:22:45.482113
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyConflictError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyNotFoundError
   

# Generated at 2022-06-17 01:22:52.001934
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:23:49.823879
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

    facter_collector = get_collector_instance(FacterFactCollector)
    assert isinstance(facter_collector, FacterFactCollector)

    # Test with a module that has facter installed
    class FakeModule:
        def __init__(self):
            self.bin_path = '/usr/bin:/bin'


# Generated at 2022-06-17 01:24:00.007863
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import _get_collector_instance
    from ansible.module_utils.facts.collector import _get_collector_class
    from ansible.module_utils.facts.collector import _get_collector_class_name
    from ansible.module_utils.facts.collector import _get_collector_class_path
    from ansible.module_utils.facts.collector import _get_collector_class_path_from_name
    from ansible.module_utils.facts.collector import _get_collector_class_path_from_name