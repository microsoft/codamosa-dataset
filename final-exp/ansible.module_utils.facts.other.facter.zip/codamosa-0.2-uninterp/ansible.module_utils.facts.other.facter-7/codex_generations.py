

# Generated at 2022-06-17 01:14:12.232040
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import NamespaceFactCollector


# Generated at 2022-06-17 01:14:21.961923
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            self.namespace = PrefixFactNames

# Generated at 2022-06-17 01:14:31.269845
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system.distribution.windows
    import ansible.module_utils.facts.system.distribution.freebsd
    import ansible.module_utils.facts.system.distribution.openbsd
    import ansible.module_

# Generated at 2022-06-17 01:14:37.531304
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    class FakeModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test": "test"}', ''

    facter_path = '/usr/bin/facter'
    module = FakeModule(facter_path)
    facter_collector = ansible.module_utils.facts.collectors.facter.FacterFactCollector()
    facter

# Generated at 2022-06-17 01:14:48.554352
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_namespace_facts
    from ansible.module_utils.facts.collector import get_fact_namespace_fact_ids

# Generated at 2022-06-17 01:15:00.085277
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test with a module that has facter installed
    module = MockModule(bin_paths={'facter': '/usr/bin/facter'})
    module.run_command = Mock(return_value=(0, '{"foo": "bar"}', ''))
    facter_collector = FacterFactCollector()
    facter_facts = facter_collector.collect(module=module)
    assert facter_facts == {'facter_foo': 'bar'}

    # Test with a module that does not have facter installed
    module = MockModule(bin_paths={})
    facter_collector = FacterFactCollector()
    facter_facts = facter_collector.collect(module=module)
    assert facter_facts == {}

    # Test with a module that has facter installed, but facter

# Generated at 2022-06-17 01:15:13.165888
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
   

# Generated at 2022-06-17 01:15:23.542363
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {'bin_path': '/usr/bin'}

        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])

       

# Generated at 2022-06-17 01:15:34.761978
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import PrefixFactNamespace
    from ansible.module_utils.facts.collector import FactCache
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_classes_from_namespace
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-17 01:15:45.261600
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace

    class TestFacterFactCollector(FacterFactCollector):
        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='facter',
                                            prefix='facter_')

# Generated at 2022-06-17 01:15:55.378170
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    facter_collector = get_collector_instance('facter')

    # Test case 1: facter is not installed
    class MockModule:
        def get_bin_path(self, arg1, arg2):
            return None
    module = MockModule()
    facter_path = facter_collector.find_facter(module)
    assert facter_path is None

    # Test case 2: facter is installed
    class MockModule:
        def get_bin_path(self, arg1, arg2):
            return '/usr/bin/facter'
    module = MockModule()
    facter_path = facter_collector.find_facter(module)

# Generated at 2022-06-17 01:16:07.927464
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_all_collectors

# Generated at 2022-06-17 01:16:17.050404
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.pkg_mgr
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.collectors.dns
    import ansible.module_utils.facts.collectors.identity
   

# Generated at 2022-06-17 01:16:20.679101
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    facter_collector = get_collector_instance('facter')
    assert facter_collector.find_facter(None) is None


# Generated at 2022-06-17 01:16:32.932421
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    # Create a mock module
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

    # Create a mock module
    class MockModule2(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return None
            elif name == 'cfacter':
                return None
            else:
                return None

# Generated at 2022-06-17 01:16:45.479301
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:16:57.800149
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:17:11.864745
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class FakeModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test": "test"}', ''

    class FakeCollector(object):
        def __init__(self, module):
            self.module = module

    # Test with facter_path = None
    module = FakeModule(facter_path=None)
    collector = FakeCollector(module)
    facter_fact_collector = FacterFactCollector(collectors=[collector])

# Generated at 2022-06-17 01:17:17.984798
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_foo": "bar"}', ''

    module = MockModule()
    facter_collector = get_collector_instance(FacterFactCollector)
    assert isinstance(facter_collector, BaseFactCollector)

# Generated at 2022-06-17 01:17:26.861199
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=None):
            if executable == 'facter':
                return self.bin_path
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/bin/facter --puppet --json':
                return 0, '{"facter_test": "test"}', ''
            else:
                return 1, '', ''


# Generated at 2022-06-17 01:17:39.071998
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, name, opt_dirs=[]):
            return self.facter_path

        def run_command(self, cmd):
            return 0, '{"facter_foo": "bar"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:17:50.113729
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test with no module
    facter_collector = FacterFactCollector()
    assert facter_collector.collect() == {}

    # Test with module
    class Module:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test_key": "facter_test_value"}', ''

    module = Module()
    facter_collector = FacterFactCollector()
    assert facter_collector.collect(module=module) == {'facter_test_key': 'facter_test_value'}

# Generated at 2022-06-17 01:17:59.348690
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=[]):
            return self.bin_path

        def run_command(self, cmd):
            return 0, '{"facter_uptime": {"seconds": "10"}}', ''


# Generated at 2022-06-17 01:18:13.335732
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_system_collectors


# Generated at 2022-06-17 01:18:24.445139
# Unit test for method collect of class FacterFactCollector

# Generated at 2022-06-17 01:18:35.231679
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=[]):
            return self.bin_path

        def run_command(self, cmd):
            return 0, '{"facter_test_fact": "test_value"}', ''

    class MockFactCollector(object):
        def __init__(self, collectors=None, namespace=None):
            pass

    class MockFactNamespace(object):
        def __init__(self, namespace_name='', prefix=''):
            pass


# Generated at 2022-06-17 01:18:45.932351
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import NamespaceKeyError
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import FactCollectorUnsupportedError
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_namespace_keys
    from ansible.module_utils.facts.collector import get_collector_namespace_key_value

# Generated at 2022-06-17 01:18:57.523980
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-17 01:19:04.392525
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import get_namespace_instance
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import get_namespace_instance

# Generated at 2022-06-17 01:19:12.052452
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import get_collector_instance
   

# Generated at 2022-06-17 01:19:31.752844
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_fact_ids

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'


# Generated at 2022-06-17 01:19:40.700985
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = MockModule()
    facter_path = '/opt/puppetlabs/bin/facter'

# Generated at 2022-06-17 01:19:53.232033
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'facter']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, command):
            return 0, '{"facter_test": "test"}', ''

    fake_module = FakeModule()

# Generated at 2022-06-17 01:20:00.325791
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    collected_facts = None
    facter_dict = {}


# Generated at 2022-06-17 01:20:13.418846
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=[]):
            return self.bin_path

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:20:23.839010
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Setup
    module = MockModule()
    facter_path = '/usr/bin/facter'
    facter_output = '{"facter_uptime_seconds": "1234", "facter_uptime_hours": "5"}'
    facter_dict = {'facter_uptime_seconds': '1234', 'facter_uptime_hours': '5'}
    facter_collector = FacterFactCollector()
    facter_collector.find_facter = Mock(return_value=facter_path)
    facter_collector.run_facter = Mock(return_value=(0, facter_output, ''))

    # Test
    facter_dict_returned = facter_collector.collect(module=module)

    # Assert
    assert facter_dict_return

# Generated at 2022-06-17 01:20:34.341744
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:20:44.908920
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_names
    from ansible.module_utils.facts.collector import get_fact_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_namespaces

# Generated at 2022-06-17 01:20:55.029616
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    # Create a mock module
    module = ansible.module_utils.facts.utils.get_module()

    # Create a mock module.get_bin_path
    def mock_get_bin_path(name, opt_dirs=[]):
        if name == 'facter':
            return '/usr/bin/facter'
        elif name == 'cfacter':
            return '/usr/bin/cfacter'
        else:
            return None

    module.get_bin_path = mock_get_bin_path

    # Create a mock module.run_command

# Generated at 2022-06-17 01:21:05.921538
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_for_namespace
    from ansible.module_utils.facts.collector import get_collector_namespaces_for_type
    from ansible.module_utils.facts.collector import get_collector_namespaces_for_type_names
    from ansible.module_utils.facts.collector import get_collector_namespaces_for

# Generated at 2022-06-17 01:21:37.767851
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_instance_by_name

# Generated at 2022-06-17 01:21:47.931921
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary, opt_dirs=None):
            if binary == 'facter':
                return '/usr/bin/facter'
            elif binary == 'cfacter':
                return None
            else:
                return None


# Generated at 2022-06-17 01:21:53.344619
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test that FacterFactCollector is in the list of available collectors
    assert 'facter' in get_collector_names()

    # Test that FacterFactCollector is in the list of available collectors
    assert 'FacterFactCollector' in [c.__class__.__name__ for c in list_collectors()]

    # Test that FacterFactCollector is returned by get_collector_instance
    assert isinstance(get_collector_instance('facter'), FacterFactCollector)

    # Test that FacterFactCollector is returned by get_collector_instance

# Generated at 2022-06-17 01:22:04.036238
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:22:15.491078
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule:
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, name, opt_dirs=None):
            return self.facter_path

        def run_command(self, cmd):
            return 0, '{"facter_output": "facter_output"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'


# Generated at 2022-06-17 01:22:23.664932
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes

    # Test that FacterFactCollector is in the list of available collectors
    assert 'facter' in get_collector_names()

    # Test that FacterFactCollector is in the list of available collectors
    assert FacterFactCollector in get_collector_classes()

    # Test that FacterFactCollector is returned by get_collector_for
    assert isinstance(get_collector_for('facter'), FacterFactCollector)

    # Test that FacterFactCollector

# Generated at 2022-06-17 01:22:34.143334
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(object):
        def __init__(self):
            self.collectors = []
            self.namespace = ansible.module_utils.facts.namespace.BaseFactNamespace()

    class MockUtils(object):
        def __init__(self):
            self.collectors = []

# Generated at 2022-06-17 01:22:39.671961
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_for_

# Generated at 2022-06-17 01:22:50.156549
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return self.bin_path
            return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test": "test"}', ''
            return 1, '', ''

    class MockCollector(object):
        def __init__(self, collectors=None, namespace=None):
            self.collectors

# Generated at 2022-06-17 01:22:56.691674
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceManager
    from ansible.module_utils.facts.namespace import NamespaceFacts
    from ansible.module_utils.facts.namespace import get_namespace_manager
    from ansible.module_utils.facts.namespace import get_namespace_facts
    from ansible.module_utils.facts.namespace import get_namespace_instance

# Generated at 2022-06-17 01:23:53.562359
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Get a list of all collectors
    collectors = list_collectors()

    # Get a list of all collector names
    names = get_collector_names()

    # Get a list of all fact_ids
    fact_ids = set()
    for name in names:
        fact_ids.update(get_collector_instance(name)._fact_ids)

    # Get a list of all fact_ids
    fact_ids = set()
    for name in names:
        fact_ids.update(get_collector_instance(name)._fact_ids)

    # Get

# Generated at 2022-06-17 01:24:03.357458
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespace

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=None):
            return self.bin_path

        def run_command(self, command):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock_collector'