

# Generated at 2022-06-17 01:14:12.897510
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Check that FacterFactCollector is in the list of available collectors
    assert 'facter' in get_collector_names()

    # Check that FacterFactCollector is in the list of available collectors
    assert 'facter' in list_collectors()

    # Check that FacterFactCollector is in the list of available collectors
    assert 'facter' in list_collectors()

    # Check that FacterFactCollector is in the list of available collectors
    assert 'facter' in list_collectors()

    # Check that FacterFactCollector is in the list of available collectors

# Generated at 2022-06-17 01:14:24.019519
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.cache.file
    import ansible.module_utils.facts.cache.memory
    import ansible.module_utils.facts.cache.jsonfile
    import ansible.module_utils.facts.cache.redis
    import ansible.module_utils.facts.cache.memcache
    import ansible.module_utils.facts.cache.mongodb
    import ansible.module_utils.facts.cache.postgresql


# Generated at 2022-06-17 01:14:33.139956
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():

    # Create a mock module
    class MockModule:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test": "test"}', ''
            elif cmd == '/usr/bin/cfacter --puppet --json':
                return 0, '{"facter_test": "test"}', ''
            else:
                return 1, '', ''

    # Create a mock module
    module = MockModule()

    # Create a FacterFactCollector

# Generated at 2022-06-17 01:14:45.038678
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestNamespace(Namespace):
        name = 'test'


# Generated at 2022-06-17 01:14:54.709215
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespaces

# Generated at 2022-06-17 01:15:03.293898
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='test',
                                            prefix='test_')
            super(TestCollector, self).__init__(collectors=collectors,
                                                namespace=namespace)

# Generated at 2022-06-17 01:15:06.785739
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create a mock module
    class MockModule:
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'
            self.run_command_results = []

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'facter':
                return self.bin_path + '/facter'
            elif binary == 'cfacter':
                return self.bin_path + '/cfacter'
            else:
                return None

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    # Create a mock module with facter installed
    module = MockModule()

# Generated at 2022-06-17 01:15:14.707187
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import list_collectors

    # Test that FacterFactCollector is in the list of all available collectors
    assert 'facter' in get_collector_names()

    # Test that FacterFactCollector is returned when we ask for it
    assert isinstance(get_collector_instance('facter'), FacterFactCollector)

    # Test that FacterFactCollector is returned when we ask for it
    assert get_collector_for_fact('facter') == FacterFactCollector

    # Test that F

# Generated at 2022-06-17 01:15:23.505596
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:15:34.714803
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError

    class MockModule(object):
        def __init__(self, facter_path, facter_output):
            self.facter_path = facter_path
            self.facter_output = facter_output

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, *args, **kwargs):
            return 0, self.facter_output, ''

    class MockCollector(BaseFactCollector):
        name = 'mock'


# Generated at 2022-06-17 01:15:47.534754
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, cmd):
            if cmd == self.facter_path + " --puppet --json":
                return 0, '{"a": "b"}', ''
            else:
                return 1, '', ''

    facter_path = '/usr/bin/facter'
    module = MockModule(facter_path)
    facter_output = FacterFactCollector().get_facter_output(module)
    assert facter_output == '{"a": "b"}'

    facter_path = None

# Generated at 2022-06-17 01:15:52.174618
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes

    # Get the FacterFactCollector class
    facter_fact_collector_class = get_collector_for('facter')

    # Create an instance of FacterFactCollector
    facter_fact_collector = facter_fact_collector_class()

    # Create a mock module

# Generated at 2022-06-17 01:16:01.229477
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_for_type
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_os

# Generated at 2022-06-17 01:16:12.776895
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:20.533374
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class FakeCollector(object):
        def __init__(self):
            self.namespace = ansible.module_utils.facts.namespace.BaseFactNamespace()

    class FakeUtils(object):
        def __init__(self):
            self.module = FakeModule()

    ansible.module_

# Generated at 2022-06-17 01:16:32.845783
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceValueError
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceValueError
    from ansible.module_utils.facts.namespace import NamespaceKeyError

# Generated at 2022-06-17 01:16:45.395887
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.namespace

    class FakeModule:
        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/usr/bin/facter'
            if executable == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'

    class FakeCollector:
        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors
            self.namespace = namespace

    class FakeNamespace:
        def __init__(self, namespace_name='', prefix=''):
            self.namespace_name = namespace_name
            self.prefix = prefix

# Generated at 2022-06-17 01:16:57.699281
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.system.distribution

    module = ansible.module_utils.facts.utils.AnsibleModuleMock()
    module.run_command = ansible.module_utils.facts.utils.run_command_mock
    module.get_bin_path = ansible.module_utils.facts.utils.get_bin_path_mock

    facter_fact_collector = ansible.module_utils.facts.system.facter.FacterFactCollector()
    facter_fact_collector.get_facter_output(module)

   

# Generated at 2022-06-17 01:17:07.549637
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:17:15.822269
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact

# Generated at 2022-06-17 01:17:29.464468
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self, facter_path):
            self.facter_path = facter_path

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_output": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'


# Generated at 2022-06-17 01:17:38.549468
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
   

# Generated at 2022-06-17 01:17:48.378686
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.alpine
    import ansible.module_utils.facts.system.distribution.arch
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.freebsd
    import ansible.module_utils

# Generated at 2022-06-17 01:17:59.172652
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_fact_namespaces
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_fact_ids_from_namespace
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:18:13.335046
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_classes_for_names
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:18:24.445573
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespace_prefixes
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_namespace_for

# Generated at 2022-06-17 01:18:35.230657
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['gather_facts'] = 'yes'

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test_fact": "test_value"}', ''

    module = FakeModule()
    fact

# Generated at 2022-06-17 01:18:45.664056
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace_path
    from ansible.module_utils.facts.collector import get_collectors_for_type_path

# Generated at 2022-06-17 01:18:54.798502
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:19:04.904531
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_names
    from ansible.module_utils.facts.collector import get_fact_collector_namespaces
    from ansible.module_utils.facts.collector import get_fact_collector_prefixes
    from ansible.module_utils.facts.collector import get_fact_collect

# Generated at 2022-06-17 01:19:25.959399
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid

# Generated at 2022-06-17 01:19:32.821877
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = tempfile.mkdtemp()
            self.bin_path = os.path.join(self.tmpdir, 'bin')
            self.lib_path = os.path.join(self.tmpdir, 'lib')
            os.mkdir(self.bin_path)
            os.mkdir(self.lib_path)
            self.facter_path = os.path.join(self.bin_path, 'facter')
            self.cfacter_path = os.path.join(self.bin_path, 'cfacter')
            self.ruby_json_path = os.path.join

# Generated at 2022-06-17 01:19:41.882818
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names

    facter_collector = get_collector_instance(get_collector_names()[0])
    assert facter_collector.name == 'facter'

    # Test for run_facter method
    class FakeModule:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_version": "2.4.6", "facter_architecture": "x86_64", "facter_kernel": "Linux"}', ''

    fake_module = FakeModule()
    rc,

# Generated at 2022-06-17 01:19:54.545149
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_namespace_prefixes
    from ansible.module_utils.facts.collector import get_fact_namespace_for

# Generated at 2022-06-17 01:19:57.129095
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    collected_facts = None
    facter_collector = FacterFactCollector()
    facter_collector.collect(module, collected_facts)

# Generated at 2022-06-17 01:20:07.830528
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create a fake module
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    module = FakeModule()

    # Create a FacterFactCollector object
    facter_collector = FacterFactCollector()

    # Call method collect
    facter_facts = facter_collector.collect(module=module)

    # Assert that the result is correct
    assert facter_facts == {'facter_test': 'test'}

# Generated at 2022-06-17 01:20:14.062286
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_instance
    from ansible.module_utils.facts.collector import get_fact_collector_instances
    from ansible.module_utils.facts.collector import get_fact_names

# Generated at 2022-06-17 01:20:24.333738
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = MockModule()
    facter_path = '/opt/puppetlabs/bin/facter'

# Generated at 2022-06-17 01:20:34.691252
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test with facter installed
    module = MockModule()
    module.run_command = Mock(return_value=(0, '{"facter_test": "test"}', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/facter')
    facter_collector = FacterFactCollector()
    facter_output = facter_collector.get_facter_output(module)
    assert facter_output == '{"facter_test": "test"}'

    # Test with facter not installed
    module = MockModule()
    module.run_command = Mock(return_value=(0, '{"facter_test": "test"}', ''))
    module.get_bin_path = Mock(return_value=None)
    facter_collector = FacterFactCollector()

# Generated at 2022-06-17 01:20:44.959455
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import get_namespace_instance
    from ansible.module_utils.facts.namespace import get_namespace_names

# Generated at 2022-06-17 01:21:17.990444
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_names_for_namespace
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_names_from_ids


# Generated at 2022-06-17 01:21:28.083128
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import ModuleUtilsFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModuleUtilsFacts(ModuleUtilsFacts):
        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'facter':
                return '/usr/bin/facter'
            elif arg == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors
            self.namespace = namespace


# Generated at 2022-06-17 01:21:38.139838
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_names
    from ansible.module_utils.facts.collector import get_fact_collector_for
    from ansible.module_utils.facts.collector import get_fact_collector_instance
    from ansible.module_utils.facts.collector import get_fact_collector_instances

# Generated at 2022-06-17 01:21:48.350509
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:21:59.333997
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collectors_for_fact
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_namespace_for
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_namespaces_for_fact
   

# Generated at 2022-06-17 01:22:11.253727
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleFactsCollector

# Generated at 2022-06-17 01:22:17.055850
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:22:24.653596
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts

# Generated at 2022-06-17 01:22:34.238814
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil

    class MockModule(object):
        def __init__(self):
            self.path = os.environ['PATH']

        def get_bin_path(self, executable, opt_dirs=[]):
            return shutil.which(executable, path=self.path)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary executable file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()

    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp()

    # Create a temporary executable file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)
    tmpfile2.close()



# Generated at 2022-06-17 01:22:39.948921
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_sysctl_collectors
    from ansible.module_utils.facts.collector import list_system_collectors

# Generated at 2022-06-17 01:23:42.868948
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create a mock module
    class MockModule(object):
        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/usr/bin/facter'
            elif executable == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None


# Generated at 2022-06-17 01:23:51.411242
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:24:01.131030
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   