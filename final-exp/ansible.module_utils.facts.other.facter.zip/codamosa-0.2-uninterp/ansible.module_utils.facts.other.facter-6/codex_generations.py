

# Generated at 2022-06-17 01:14:13.773585
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return self.bin_path
            else:
                return None

        def run_command(self, cmd):
            if self.bin_path is None:
                return 1, '', ''
            else:
                return 0, '{"facter_test_fact": "test_value"}', ''

    class MockCollector(object):
        def __init__(self, fact_ids):
            self.fact

# Generated at 2022-06-17 01:14:24.771963
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import PrefixFactNamespace
    from ansible.module_utils.facts.collector import FactCache
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCacheModule

# Generated at 2022-06-17 01:14:29.872437
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    facter_collector = get_collector_instance('facter')
    assert facter_collector.find_facter(None) is None


# Generated at 2022-06-17 01:14:37.145184
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_

# Generated at 2022-06-17 01:14:46.186959
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:14:54.758725
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=None):
            return '/usr/bin/' + name

    class FakeCollector(object):
        def __init__(self):
            self.collectors = []
            self.namespace = ansible.module_utils.facts.namespace.BaseFactNamespace()

    fake_module = FakeModule()
    fake_collector = FakeCollector()

# Generated at 2022-06-17 01:15:03.293929
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:15:11.705609
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:15:23.338853
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test": "test"}', ''

    module = MockModule()
    fact_collector = get_collector_instance(BaseFactCollector)
    fact_collector.collectors = [FacterFactCollector()]
    fact_collector.collect(module=module)
    assert fact_collector.get_fact('facter_test')

# Generated at 2022-06-17 01:15:34.755914
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_namespace_prefixes
    from ansible.module_utils.facts.collector import get_fact_namespace_for

# Generated at 2022-06-17 01:15:47.306077
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test that the FacterFactCollector class is in the list of
    # available fact collectors
    assert 'FacterFactCollector' in get_collector_names()

    # Test that the FacterFactCollector class is in the list of
    # available fact collectors
    assert 'FacterFactCollector' in list_collectors()

    # Test that we can get an instance of the FacterFactCollector
    # class
    assert isinstance(get_collector_instance('FacterFactCollector'),
                      FacterFactCollector)

# Generated at 2022-06-17 01:15:55.034911
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def __init__(self, facter_path, facter_output):
            self.facter_path = facter_path
            self.facter_output = facter_output

        def get_bin_path(self, *args, **kwargs):
            return self.facter_path

        def run_command(self, *args, **kwargs):
            return 0, self.facter_output, ''


# Generated at 2022-06-17 01:16:04.544259
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/opt/puppetlabs/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    module = MockModule()
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-17 01:16:12.275838
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.pkg_mgr
    import ansible.module_utils.facts.collectors.platform
    import ansible.module_utils.facts.collectors.distribution
    import ansible.module_utils.facts.collectors.file_system
    import ans

# Generated at 2022-06-17 01:16:20.465483
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:32.797832
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:45.314541
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:16:57.603374
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.linux
    import ansible.module_utils.facts.system.distribution.linux.debian
    import ansible.module_utils.facts.system.distribution.linux.redhat
    import ansible.module_utils.facts.system.distribution.linux.suse
    import ans

# Generated at 2022-06-17 01:17:07.954686
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/usr/bin/facter'
            elif executable == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None


# Generated at 2022-06-17 01:17:18.093283
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockCollector
    from ansible.module_utils.facts.collector import MockFactsCollector

    module = MockModule()
    module.run_command = lambda x: (0, '{"facter_test": "test"}', '')
    module.get_bin_path = lambda x: '/usr/bin/facter'

    facter_collector = FacterFactCollector()
    facter_collector.collect(module=module)

    assert facter_collector.get_fact('facter_test') == 'test'

    # Test with a MockCollector
    mock_collector = MockCollector()

# Generated at 2022-06-17 01:17:34.773577
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'
            self.run_command_rc = 0
            self.run_command_out = '{"facter_test": "test"}'
            self.run_command_err = ''

        def get_bin_path(self, binary, opt_dirs=None):
            return self.bin_path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    module = MockModule()
    fact

# Generated at 2022-06-17 01:17:45.605807
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:17:52.597400
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary facter binary
    facter_path = os.path.join(tmpdir, 'facter')
    with open(facter_path, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo \'{"facter_test": "test"}\'')
    os.chmod(facter_path, 0o755)

    # Create a temporary ansible.cfg
    ansible_cfg_path = os.path.join(tmpdir, 'ansible.cfg')
    with open(ansible_cfg_path, 'w') as f:
        f.write('[defaults]\n')

# Generated at 2022-06-17 01:18:02.406336
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test that the FacterFactCollector class is registered as a fact collector
    assert 'facter' in get_collector_names()

    # Test that the FacterFactCollector class can be instantiated
    fact_collector = get_collector_instance('facter')
    assert isinstance(fact_collector, FacterFactCollector)

    # Test that the FacterFactCollector class is returned by list_collectors
    assert 'facter' in list_collectors()

# Generated at 2022-06-17 01:18:14.308762
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceValueError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:18:19.793210
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    facter_collector = get_collector_instance('facter')

    # Test case 1: facter is not installed
    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return None

    assert facter_collector.find_facter(MockModule()) is None

    # Test case 2: facter is installed
    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

    assert facter_collector.find_facter(MockModule()) == '/usr/bin/facter'

    # Test case 3: cfacter is installed

# Generated at 2022-06-17 01:18:30.227785
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Test case 1: facter is not installed
    module = MockModule()
    module.get_bin_path.return_value = None
    facter_collector = FacterFactCollector()
    assert facter_collector.find_facter(module) is None

    # Test case 2: facter is installed
    module = MockModule()
    module.get_bin_path.return_value = '/usr/bin/facter'
    facter_collector = FacterFactCollector()
    assert facter_collector.find_facter(module) == '/usr/bin/facter'

    # Test case 3: facter is not installed, but cfacter is installed
    module = MockModule()
    module.get_bin_path.side_effect = [None, '/usr/bin/cfacter']
    facter_

# Generated at 2022-06-17 01:18:41.464986
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces_of_type
    from ansible.module_utils.facts.collector import get_collectors_for_type

# Generated at 2022-06-17 01:18:52.805423
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_exists
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 01:19:04.600488
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification

# Generated at 2022-06-17 01:19:25.625509
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts_collectors
    from ansible.module_utils.facts.collector import list_

# Generated at 2022-06-17 01:19:36.912414
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_instance
    from ansible.module_utils.facts.utils import get_collector_namespace

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda *args, **kwargs: None

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'


# Generated at 2022-06-17 01:19:43.330466
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes

    # get_collector_instance
    facter_collector = get_collector_instance('facter')
    assert isinstance(facter_collector, FacterFactCollector)

    # get_collector_names
    assert 'facter' in get_collector_names()

    # get_collector_for
    assert get_collector_for('facter') == FacterFactCollector

    # get_collector_classes
    assert FacterFactCollector in get

# Generated at 2022-06-17 01:19:55.003142
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_distribution
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_distribution_version
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_os

# Generated at 2022-06-17 01:20:06.859190
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module path
    old_pythonpath = os.environ.get('PYTHONPATH', '')
    os.environ['PYTHONPATH'] = tmpdir

    # Create a temporary ansible module path
    old_ansible_module_utils = os.environ.get('ANSIBLE_MODULE_UTILS', '')
    os.environ['ANSIBLE_MODULE_UTILS'] = tmpdir

    # Create a temporary ansible module path
    old_ansible_module_utils = os.environ.get('ANSIBLE_MODULE_UTILS', '')
    os.environ['ANSIBLE_MODULE_UTILS'] = tmpdir

# Generated at 2022-06-17 01:20:17.113520
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=None):
            if arg == 'facter':
                return '/usr/bin/facter'
            elif arg == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None


# Generated at 2022-06-17 01:20:25.558023
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_for_type
    from ansible.module_utils.facts.collector import get_collector_for_type_with_namespace
    from ansible.module_utils.facts.collector import get_collector_for_type_with_prefix
    from ansible.module_utils.facts.collector import get_collector

# Generated at 2022-06-17 01:20:36.616926
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class FakeModule:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test": "test"}', ''

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set(['fake'])


# Generated at 2022-06-17 01:20:47.561793
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = None

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path

        def run_command(self, *args, **kwargs):
            return 0, '', ''

    # Create a mock module
    module = MockModule()
    module.bin_path = '/usr/bin/facter'

    # Create a FacterFactCollector object
    facter_fact_collector = FacterFactCollector()

    # Test with facter installed
    facter_output = facter_fact_collector.get_facter_output(module)
    assert facter_output is not None

    # Test with facter not installed
   

# Generated at 2022-06-17 01:20:56.576646
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.system.facter.facter_fact_collector
    import ansible.module_utils.facts.system.facter.facter_fact_collector.FacterFactCollector
    import ansible.module_utils.facts.system.facter.facter_fact_collector.PrefixFactNamespace
    import ansible.module_utils.facts.system.facter.facter_fact_collector.test_FacterFactCollector_get_facter_output
    import ansible.module_utils.facts.system.facter.facter_

# Generated at 2022-06-17 01:21:31.944093
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, command):
            return 0, '{"facter_test_fact": "test_value"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

    mock_module

# Generated at 2022-06-17 01:21:39.033221
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_for_fact
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:21:48.953428
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_namespaces
    from ansible.module_utils.facts.collector import get_namespace_info
    from ansible.module_utils.facts.collector import get_namespace_info_for_collector
    from ansible.module_utils.facts.collector import get_namespaces
    from ansible.module_utils.facts.collector import get_namespaces_for_collect

# Generated at 2022-06-17 01:21:59.357344
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_names_from_collectors
    from ansible.module_utils.facts.collector import get_fact

# Generated at 2022-06-17 01:22:11.256490
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module path
    old_pythonpath = os.environ.get('PYTHONPATH', '')
    os.environ['PYTHONPATH'] = tmpdir

    # Create a temporary module utils lookup path
    old_path = sys.path
    sys.path = [tmpdir]

    # Create a temporary ansible module utils path
    tmp_ansible_module_utils = os.path.join(tmpdir, 'ansible', 'module_utils')
    os.makedirs(tmp_ansible_module_utils)

    # Create a temporary ansible module utils facts path

# Generated at 2022-06-17 01:22:17.036474
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespaces

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=None):
            return self.bin_path

        def run_command(self, command):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'

# Generated at 2022-06-17 01:22:26.260264
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:22:34.845913
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/usr/bin/facter'
            elif executable == 'cfacter':
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test": "test"}', ''
            else:
                return 1, '', ''

    module = MockModule()
    facter_output = FacterFactCollector().get_facter_output(module)
    assert facter_output == '{"facter_test": "test"}'

# Generated at 2022-06-17 01:22:45.820893
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    class FakeModule:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    class FakeCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        name = 'fake'
        _fact_ids = set(['fake'])


# Generated at 2022-06-17 01:22:56.138832
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorReason
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorReasonInvalid
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorReasonMissing
    from ansible.module_utils.facts.namespace import FactNamespaceKeyErrorReasonUnsupported

# Generated at 2022-06-17 01:24:00.569719
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    class MockCollector(Collector):
        def __init__(self):
            self.collect_called = False

        def collect(self, module=None, collected_facts=None):
            self.collect_called = True
            return {}

    module = MockModule()
    module.run_command