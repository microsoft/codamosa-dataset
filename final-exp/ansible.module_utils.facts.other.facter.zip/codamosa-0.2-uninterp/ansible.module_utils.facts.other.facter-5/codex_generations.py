

# Generated at 2022-06-17 01:14:15.391510
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'


# Generated at 2022-06-17 01:14:25.642082
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-17 01:14:35.800200
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_instance

    # Create a Collector instance
    collector = Collector()

    # Create a FacterFactCollector instance
    facter_fact_collector = get_collector_instance(FacterFactCollector,
                                                   collectors=[collector])

    # Create a PrefixFactNamespace instance
    namespace = PrefixFactNamespace(namespace_name='facter',
                                    prefix='facter_')

    # Create a FacterFactCollector instance
    facter_fact_collector = FacterFactCollector(collectors=[collector],
                                                namespace=namespace)

    # Create a mock module


# Generated at 2022-06-17 01:14:47.224350
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exceptions
    from ansible.module_utils.facts.collector import get_collector_exception_messages
    from ansible.module_utils.facts.collector import get_collector_exception_tracebacks
    from ansible.module_utils.facts.collector import get_collector_exception_types
    from ansible.module_utils.facts.collector import get_collector_exception_types_and_messages

# Generated at 2022-06-17 01:14:57.855221
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts import ModuleUtilsFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    module = ModuleUtilsFacts()
    module.get_bin_path = lambda x, y: '/usr/bin/facter'
    facter_collector = FacterFactCollector(collectors=[], namespace=PrefixFactNamespace(namespace_name='facter', prefix='facter_'))
    assert facter_collector.find_facter(module) == '/usr/bin/facter'


# Generated at 2022-06-17 01:15:12.225816
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectorError
    from ansible.module_utils.facts.collector import CollectorNotFoundError
    from ansible.module_utils.facts.collector import CollectorUnsupportedError
    from ansible.module_utils.facts.collector import CollectorExecutionError
    from ansible.module_utils.facts.collector import CollectorUnsupportedVersionError
    from ansible.module_utils.facts.collector import CollectorExecutionSkippedError
    from ansible.module_utils.facts.collector import CollectorExecutionTimeoutError
    from ansible.module_utils.facts.collector import CollectorExecutionUnreachableError

# Generated at 2022-06-17 01:15:23.367546
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # Test with facter installed
    module = MockModule()
    module.get_bin_path.return_value = '/usr/bin/facter'
    module.run_command.return_value = (0, '{"facter_test": "test"}', '')
    facter_collector = FacterFactCollector()
    facter_output = facter_collector.get_facter_output(module)
    assert facter_output == '{"facter_test": "test"}'

    # Test with facter not installed
    module = MockModule()
    module.get_bin_path.return_value = None
    facter_collector = FacterFactCollector()
    facter_output = facter_collector.get_facter_output(module)
    assert facter_output is None

    # Test

# Generated at 2022-06-17 01:15:34.757054
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:15:44.112597
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test with a module that has facter installed
    module = MockModule(bin_path='/usr/bin/facter')
    facter_collector = FacterFactCollector()
    facter_dict = facter_collector.collect(module=module)
    assert facter_dict['facter_architecture'] == 'x86_64'

    # Test with a module that does not have facter installed
    module = MockModule(bin_path=None)
    facter_collector = FacterFactCollector()
    facter_dict = facter_collector.collect(module=module)
    assert facter_dict == {}


# Generated at 2022-06-17 01:15:54.428931
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter

# Generated at 2022-06-17 01:16:08.635290
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test with no module
    facter_collector = FacterFactCollector()
    facter_dict = facter_collector.collect()
    assert facter_dict == {}

    # Test with a module
    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    module = MockModule()
    facter_collector = FacterFactCollector()
    facter_dict = facter_collector.collect(module)
    assert facter_dict == {'facter_test': 'test'}

# Generated at 2022-06-17 01:16:20.218083
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_namespace_info
    from ansible.module_utils.facts.collector import get_namespace_info_for_all
    from ansible.module_utils.facts.collector import get_namespace_info_for_all_namespaces
    from ansible.module_utils.facts.collector import get_namespace_info_for_all_collectors

# Generated at 2022-06-17 01:16:32.569421
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.mount
    import ansible.module_utils.facts.system.fips

# Generated at 2022-06-17 01:16:44.993529
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter

# Generated at 2022-06-17 01:16:57.343586
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule:
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_uptime_seconds": "12345"}', ''
            elif cmd == '/usr/bin/cfacter --puppet --json':
                return 0, '{"facter_uptime_seconds": "12345"}', ''
            else:
                return 1, '', ''

    facter_fact_collector = FacterFactCollector()

# Generated at 2022-06-17 01:17:07.839434
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='test',
                                            prefix='test_')
            super(TestCollector, self).__init__(collectors=collectors,
                                                namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return

# Generated at 2022-06-17 01:17:16.463409
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
   

# Generated at 2022-06-17 01:17:26.393981
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:17:35.012878
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, arg, opt_dirs=None):
            return '/usr/bin/facter'

        def run_command(self, arg):
            self.run_command_calls.append(arg)
            return self.run_command_results.pop(0)

    # Create a mock module
    module = MockModule()

    # Create a FacterFactCollector
    facter_fact_collector = FacterFactCollector()

    # Set the run_command_results

# Generated at 2022-06-17 01:17:45.762847
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6
    import ansible.module_utils.facts.network.defaults

# Generated at 2022-06-17 01:17:59.313146
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_local_collectors

# Generated at 2022-06-17 01:18:13.336761
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import get_collector_status_list_from_names
    from ansible.module_utils.facts.collector import get_collector_status_list_from_namespace
    from ansible.module_utils.facts.collector import get_collector_status_list_

# Generated at 2022-06-17 01:18:24.476695
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_namespaces

    class FakeModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact

# Generated at 2022-06-17 01:18:34.240676
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_all
    from ansible.module_utils.facts.collector import get_collector_status_by_name
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import get_collector_status_list_all
    from ansible.module_utils.facts.collector import get_collector_status_

# Generated at 2022-06-17 01:18:45.107401
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:18:52.133529
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', '!min']
            self.params['gather_timeout'] = 10

        def get_bin_path(self, arg, opt_dirs=None):
            return '/usr/bin/facter'

        def run_command(self, arg):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _

# Generated at 2022-06-17 01:18:59.405615
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Test with facter installed
    module = MockModule()
    module.get_bin_path.return_value = '/usr/bin/facter'
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/usr/bin/facter'

    # Test with facter not installed
    module = MockModule()
    module.get_bin_path.return_value = None
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path is None


# Generated at 2022-06-17 01:19:13.166100
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collectors_for_platform
    from ansible.module_utils.facts.collector import get_collectors_for_platform_by_names
    from ansible.module_utils.facts.collector import get_collectors_for_all

# Generated at 2022-06-17 01:19:16.738209
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    facter_collector = get_collector_instance('facter')
    assert facter_collector.find_facter(None) is None


# Generated at 2022-06-17 01:19:28.013364
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter

# Generated at 2022-06-17 01:19:41.848841
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    # Test with facter installed
    module = MockModule()
    module.get_bin_path.return_value = '/usr/bin/facter'
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/usr/bin/facter'

    # Test with facter not installed
    module = MockModule()
    module.get_bin_path.return_value = None
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path is None


# Generated at 2022-06-17 01:19:54.543503
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system

    # Create a FacterFactCollector object
    facter_fact_collector = ansible.module_utils.facts.collector.FacterFactCollector()

    # Create a MockModule object
    mock_module = ansible.module_utils.facts.utils.MockModule()

    # Create a MockCommand object
    mock_command = ansible.module_utils.facts.utils.MockCommand()

    # Create a MockSystem object
    mock_system = ansible.module_utils.facts.system.MockSystem()

    # Set the return value of the MockSystem.get_bin_path method
   

# Generated at 2022-06-17 01:20:06.438447
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for
    from ansible.module_utils.facts.collector import get_fact_collector_instance
    from ansible.module_utils.facts.collector import get_fact_collector_names
    from ansible.module_utils.facts.collector import get_fact_collector_for
    from ansible.module_utils.facts.collector import get_fact_collectors_for
    from ansible.module_utils.facts.collector import get_fact_names

# Generated at 2022-06-17 01:20:12.939163
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_names_from_collectors
    from ansible.module_utils.facts.collector import get_fact_names_from_namespace
    from ansible.module_utils.facts.collector import get_fact_names_

# Generated at 2022-06-17 01:20:23.390745
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_collectors

# Generated at 2022-06-17 01:20:33.022978
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import get_collector_instance
   

# Generated at 2022-06-17 01:20:38.685234
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_collector_classes

# Generated at 2022-06-17 01:20:50.424597
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preset_

# Generated at 2022-06-17 01:20:57.819597
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.ubuntu
    import ansible.module_utils.facts.system.distribution.arch
    import ansible.module_utils.facts.system.distribution.alpine
   

# Generated at 2022-06-17 01:21:07.201131
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.hardware.cpu
    import ansible.module_utils.facts.hardware.dmi
    import ansible.module_utils.facts

# Generated at 2022-06-17 01:21:38.140531
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactCollector

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_a": "b"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'


# Generated at 2022-06-17 01:21:48.350490
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exceptions
    from ansible.module_utils.facts.collector import get_collector_exception_reasons
    from ansible.module_utils.facts.collector import get_collector_exception_tracebacks
    from ansible.module_utils.facts.collector import get_collector_exception_types
    from ansible.module_utils.facts.collector import get_collector_exception_types
    from ansible.module_utils.facts.collector import get_

# Generated at 2022-06-17 01:21:59.333854
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_links

# Generated at 2022-06-17 01:22:11.251512
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collectors_for_fact
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_names
    from ansible.module_utils.facts.collector import get_fact_collector_name
    from ansible.module_utils.facts.collector import get_fact_collect

# Generated at 2022-06-17 01:22:22.793636
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    collected_facts = None
    facter_dict = {}
    facter_output = None
    facter_path = None

    facter_fact_collector = FacterFactCollector()

    facter_fact_collector.find_facter = lambda module: facter_path
    facter_fact_collector.run_facter = lambda module, facter_path: (0, facter_output, None)

    facter_dict = facter_fact_collector.collect(module, collected_facts)
    assert facter_dict == {}

    facter_path = '/usr/bin/facter'
    facter_dict = facter_fact_collector.collect(module, collected_facts)
    assert facter_dict == {}


# Generated at 2022-06-17 01:22:28.965403
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:22:35.912851
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_instance
    from ansible.module_utils.facts.collector import get_fact_collector_instances
    from ansible.module_utils.facts.collector import get_fact_collector_names

# Generated at 2022-06-17 01:22:45.590837
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_for_fact
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:22:52.098045
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces_except
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces_including

# Generated at 2022-06-17 01:23:01.472917
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable, opt_dirs=None):
            if executable in self.bin_path:
                return self.bin_path[executable]
            return None

    # Test with facter and cfacter installed
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 01:24:04.622867
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_namespace
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_classes_for_namespace
    from ansible.module_utils.facts.collector import get_collector_classes_for_namespaces