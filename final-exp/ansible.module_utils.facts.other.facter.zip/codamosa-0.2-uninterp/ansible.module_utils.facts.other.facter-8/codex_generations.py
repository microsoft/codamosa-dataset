

# Generated at 2022-06-17 01:14:17.188445
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:14:27.465608
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names

    # Get all fact collectors
    fact_collectors = get_collector_classes()

    # Get all fact collector names
    fact_collector_names = get_collector_class_names()

    # Get all fact collector instances
    fact_collector_instances = get_collector_instance(fact_collectors)

    # Get all fact collector names
    fact_collector_names

# Generated at 2022-06-17 01:14:36.077357
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=None):
            return self.bin_path

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(object):
        def __init__(self, module):
            self.module = module

    class MockNamespace(object):
        def __init__(self, namespace_name, prefix):
            self.namespace_name = namespace_name
            self.prefix = prefix



# Generated at 2022-06-17 01:14:42.313058
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test with no module argument
    facter_collector = FacterFactCollector()
    facter_dict = facter_collector.collect()
    assert facter_dict == {}

    # Test with a module argument
    facter_collector = FacterFactCollector()
    facter_dict = facter_collector.collect(module=None)
    assert facter_dict == {}

# Generated at 2022-06-17 01:14:51.727099
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = '/usr/bin:/bin'

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    module = MockModule()
    facter_fact_collector = ansible.module_utils.facts.collectors.facter.FacterFactCollector()
   

# Generated at 2022-06-17 01:15:01.657002
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preset_collectors
    from ansible.module_utils.facts.collector import list_legacy_collectors

# Generated at 2022-06-17 01:15:10.754815
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceManager
    from ansible.module_utils.facts.namespace import NamespaceManagerError
    from ansible.module_utils.facts.namespace import NamespaceManagerFactory
    from ansible.module_utils.facts.namespace import NamespaceManagerFactoryError

# Generated at 2022-06-17 01:15:21.199912
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceFactMetadata
    from ansible.module_utils.facts.namespace import NamespaceFactSource
    from ansible.module_utils.facts.namespace import NamespaceFactSourceMetadata
    from ansible.module_utils.facts.namespace import NamespaceFactSourceValue
    from ansible.module_utils.facts.namespace import NamespaceFactSourceValueMetadata


# Generated at 2022-06-17 01:15:27.658038
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'


# Generated at 2022-06-17 01:15:40.232425
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class TestModule:
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/opt/puppetlabs/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])


# Generated at 2022-06-17 01:15:50.631224
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path=None):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=None):
            return self.bin_path

        def run_command(self, cmd):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(object):
        def __init__(self, namespace=None):
            self.namespace = namespace

    class MockNamespace(object):
        def __init__(self, namespace_name=None, prefix=None):
            self.namespace_name = namespace_

# Generated at 2022-06-17 01:16:01.911553
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-17 01:16:13.366674
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_by_name
    from ansible.module_utils.facts.collector import get_collector_class_by_

# Generated at 2022-06-17 01:16:20.818537
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_namespaces_for_class
    from ansible.module_utils.facts.collector import get_collector_classes_for_namespace
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:16:28.296923
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_class_names
    from ansible.module_utils.facts.collector import get_fact_collector_class_name
    from ansible.module_utils.facts.collector import get_fact_collect

# Generated at 2022-06-17 01:16:37.325265
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = MockModule()
    facter_path = '/opt/puppetlabs/bin/facter'

# Generated at 2022-06-17 01:16:42.190407
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import get_namespace_instance
    from ansible.module_utils.facts.namespace import get_namespace_names
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 01:16:50.037138
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_namespace_ids
    from ansible.module_utils.facts.collector import get_fact_namespace_for

# Generated at 2022-06-17 01:17:00.606349
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_collector_classes

# Generated at 2022-06-17 01:17:13.321156
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes

    # Test that FacterFactCollector is registered as a fact collector
    assert 'facter' in get_collector_names()

    # Test that FacterFactCollector is returned by get_collector_instance
    assert isinstance(get_collector_instance('facter'), FacterFactCollector)

    # Test that FacterFactCollector is returned by get_collector

# Generated at 2022-06-17 01:17:25.105194
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_namespaces

# Generated at 2022-06-17 01:17:33.367886
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names

    facter_collector = get_collector_instance('facter')
    assert facter_collector.find_facter(None) is None

    facter_collector = get_collector_instance('facter')
    assert facter_collector.find_facter(None) is None

    facter_collector = get_collector_instance('facter')
    assert facter_collector.find_facter(None) is None

# Generated at 2022-06-17 01:17:44.810861
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_a": "b"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set

# Generated at 2022-06-17 01:17:55.447467
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:18:04.255078
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.facter.facter
    import ansible.module_utils.facts.collectors.facter.facter_json
    import ansible.module_utils.facts.collectors.facter.facter_text
    import ansible.module_utils.facts.collectors.facter.facter_yaml
    import ansible.module_utils.facts.collectors.facter.facter_yaml_utf8
    import ansible.module_utils.facts.collectors.facter.facter_yaml_utf8_bom
    import ansible.module_utils.facts.collect

# Generated at 2022-06-17 01:18:12.850543
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"test": "test"}', ''

    module = MockModule()
    facter_fact_collector = FacterFactCollector()
    facter_output = facter_fact_collector.get_facter_output(module)
    assert facter_output == '{"test": "test"}'

# Generated at 2022-06-17 01:18:24.126501
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module
    module = os.path.join(tmpdir, 'ansible_module_facter.py')
    with open(module, 'w') as f:
        f.write("#!/usr/bin/python")
        f.write("\n")
        f.write("import sys")
        f.write("\n")
        f.write("import json")
        f.write("\n")
        f.write("def main():")
        f.write("\n")
        f.write("    module = AnsibleModule(argument_spec={}, supports_check_mode=True)")
        f.write("\n")

# Generated at 2022-06-17 01:18:35.184127
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collector_for_fact_namespace
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collectors_for_platform
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_

# Generated at 2022-06-17 01:18:45.559447
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_name
    from ansible.module_utils.facts.collector import get_collector_class

    # Create a FacterFactCollector instance
    facter_collector = get_collector_instance('facter')

    # Check that the name of the collector is 'facter'
    assert get_collector_name(facter_collector) == 'facter'

    # Check that the class of the collector is FacterFactCollector
    assert get_collector_class(facter_collector) == FacterFactCollector

    # Check that the method find_facter returns None if facter is not installed

# Generated at 2022-06-17 01:18:52.015062
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

        def run_command(self, cmd):
            return 0, '{"facter_uptime_seconds": "12345"}', ''

    facter_collector = FacterFactCollector()
    module = MockModule()
    facter_output = facter_collector.get_facter_output(module)
    assert facter_output == '{"facter_uptime_seconds": "12345"}'


# Generated at 2022-06-17 01:19:11.542739
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

    class TestModule(object):
        def __init__(self, facter_path, facter_output):
            self.facter_path = facter_path
            self.facter_output = facter_output

        def get_bin_path(self, name, opt_dirs=[]):
            return self.facter_path

        def run_command(self, cmd):
            return 0, self.facter

# Generated at 2022-06-17 01:19:22.213479
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    # Create a new instance of FacterFactCollector
    facter_fact_collector = FacterFactCollector()

    # Create a new instance of AnsibleModule
    ansible_module = ansible.module_utils.facts.utils.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    # Create a new instance of AnsibleModuleUtilsFactsCollector
    ansible_module_utils_facts_collector = ansible.module_utils.facts.collector.AnsibleModuleUtilsFactsCollector(
        ansible_module=ansible_module
    )

    # Create a new instance of Ans

# Generated at 2022-06-17 01:19:31.878003
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_exists
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options

# Generated at 2022-06-17 01:19:40.794177
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.mount
    import ansible.module_utils.facts.system.capabilities
    import ansible.module_utils.facts.system.timezone
    import ansible.module_utils.facts.system

# Generated at 2022-06-17 01:19:53.325506
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestModule(object):
        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'facter':
                return '/usr/bin/facter'
            elif executable == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    test_module = TestModule()
    facter_collector = get_collector_instance(BaseFactCollector, 'facter')
    facter_path = facter_collector.find_facter(test_module)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'

   

# Generated at 2022-06-17 01:20:00.364845
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:20:13.418968
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test": "test"}', ''
            elif cmd == '/usr/bin/cfacter --puppet --json':
                return 0, '{"facter_test": "test"}', ''
            else:
                return 1, '', ''

    facter_fact_collector = FacterFactCollector()
    facter_output = facter_fact_collect

# Generated at 2022-06-17 01:20:23.837972
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact

# Generated at 2022-06-17 01:20:34.341974
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None


# Generated at 2022-06-17 01:20:39.671969
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_for
    from ansible.module_utils.facts.collector import get_collector_class_for_name
    from ansible.module_utils.facts.collector import get_collector_class_for_fact
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 01:21:11.630104
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFileReadCollector
    from ansible.module_utils.facts.collector import BaseFileGlobCollector
    from ansible.module_utils.facts.collector import BaseCommandLineCollector
    from ansible.module_utils.facts.collector import BaseInventoryCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-17 01:21:20.552398
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:21:24.973383
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_instance
    from ansible.module_utils.facts.collector import get_fact_collector_instances
    from ansible.module_utils.facts.collector import get_fact_collector_names
    from ansible.module_utils.facts.collector import get_fact_collectors

# Generated at 2022-06-17 01:21:33.071134
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Get a list of all fact collectors
    all_collectors = list_collectors()

    # Get a list of all fact collector names
    all_collector_names = get_collector_names()

    # Get a list of all fact collector instances
    all_collector_instances = [get_collector_instance(name) for name in all_collector_names]

    # Get a list of all fact collector instances of class FacterFactCollector

# Generated at 2022-06-17 01:21:41.987259
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_namespace_for
    from ansible.module_utils.facts.collector import get_fact_namespace_for_id

# Generated at 2022-06-17 01:21:53.011263
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test_fact": "test_value"}', ''

    module = MockModule()
    fact_collector = get_collector_instance(FacterFactCollector)
    fact_collector.collect(module=module)

    assert isinstance(fact_collector, BaseFactCollector)
    assert fact_collector.name == 'facter'

# Generated at 2022-06-17 01:22:03.822349
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_all
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import get_fact_collector_instance

# Generated at 2022-06-17 01:22:15.492197
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/opt/puppetlabs/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    test_module = TestModule()


# Generated at 2022-06-17 01:22:26.367845
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_all_fact_collectors

# Generated at 2022-06-17 01:22:34.924287
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import get_fact_collector_instance
    from ansible.module_utils.facts.collector import get_fact_collector_names
    from ansible.module_utils.facts.collector import get_fact_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_

# Generated at 2022-06-17 01:23:36.685170
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorError
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyCollisionError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyNotFound

# Generated at 2022-06-17 01:23:37.561841
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # TODO: implement
    pass

# Generated at 2022-06-17 01:23:42.921343
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    class FakeModule(object):
        def __init__(self):
            self.bin_path = {
                'facter': '/usr/bin/facter',
                'cfacter': '/opt/puppetlabs/bin/cfacter'
            }

        def get_bin_path(self, name, opt_dirs=[]):
            return self.bin_path.get(name)


# Generated at 2022-06-17 01:23:51.400418
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 01:24:01.039359
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:24:06.277195
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter.FacterFactCollector
    import ansible.module_utils.facts.collectors.facter