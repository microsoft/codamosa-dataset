

# Generated at 2022-06-17 01:14:16.610189
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import list_collectors

    # Test that the FacterFactCollector class is registered
    assert 'facter' in get_collector_names()
    assert FacterFactCollector in get_collector_classes()

    # Test that the FacterFactCollector class is returned by get_collector_for
    assert isinstance(get_collector_for('facter'), FacterFactCollector)

    # Test that the FacterFact

# Generated at 2022-06-17 01:14:26.897537
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:14:35.884977
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestFacterFactCollector(BaseFactCollector):
        name = 'test_facter'
        _fact_ids = set(['test_facter'])

        def __init__(self, collectors=None, namespace=None):
            namespace = PrefixFactNamespace(namespace_name='test_facter',
                                            prefix='test_facter_')
            super(TestFacterFactCollector, self).__init__(collectors=collectors,
                                                          namespace=namespace)


# Generated at 2022-06-17 01:14:47.271687
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

        def get_bin_path(self, arg1, opt_dirs=None):
            return '/usr/bin/facter'

        def run_command(self, arg1):
            return 0, '{"facter_test": "test"}', ''

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors
           

# Generated at 2022-06-17 01:14:59.398361
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Test with no module
    facter_collector = FacterFactCollector()
    assert facter_collector.collect() == {}

    # Test with module that has no facter
    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return None

    facter_collector = FacterFactCollector()
    assert facter_collector.collect(module=MockModule()) == {}

    # Test with module that has facter
    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test": "test"}', ''

    facter_collector = FacterFactCollector()
   

# Generated at 2022-06-17 01:15:12.923524
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_preserved_facts
    from ansible.module_utils.facts.collector import list_legacy_facts
    from ansible.module_utils.facts.collector import list_all_collectors

# Generated at 2022-06-17 01:15:23.280071
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_for_namespace
    from ansible.module_utils.facts.collector import get_collector_namespaces
    from ansible.module_utils.facts.collector import get_collector_namespaces_for_class
    from ansible.module_utils.facts.collector import get_collector_classes_for_namespace
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 01:15:33.090658
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    class DummyModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    module = DummyModule()
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-17 01:15:45.122162
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            else:
                return None

    class MockFactCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:15:55.262880
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.pkg_mgr
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.collectors.file_system
    import ansible.module_utils.facts.collectors.identity


# Generated at 2022-06-17 01:16:10.096641
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.path
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.mount
    import ansible.module_utils.facts.system.fips

# Generated at 2022-06-17 01:16:18.046962
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import list_collector_names
    from ansible.module_utils.facts.collector import list_enabled_collector_names

# Generated at 2022-06-17 01:16:27.533681
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

        def run_command(self, cmd):
            return 0, '{"facter_test_fact": "test_value"}', ''

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])


# Generated at 2022-06-17 01:16:36.987753
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import os
    import tempfile
    import shutil

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = tempfile.mkdtemp()

        def get_bin_path(self, *args, **kwargs):
            return os.path.join(self.tmpdir, *args)

    module = MockModule()

    # No facter or cfacter
    facter_path = FacterFactCollector().find_facter(module)
    assert facter_path is None

    # Only facter
    os.makedirs(os.path.join(module.tmpdir, 'opt', 'puppetlabs', 'bin'))

# Generated at 2022-06-17 01:16:37.565098
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 01:16:42.367909
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    module = None
    collected_facts = None
    facter_dict = {}


# Generated at 2022-06-17 01:16:48.785773
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import PrefixFactNamespace
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import CollectorException
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_namespace
    from ansible.module_utils.facts.collector import get_collector_namespaces
   

# Generated at 2022-06-17 01:16:59.751910
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            if name == 'cfacter':
                return '/usr/bin/cfacter'
            return None


# Generated at 2022-06-17 01:17:12.994193
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:17:18.241932
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:17:34.818012
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import get_fact_types

# Generated at 2022-06-17 01:17:45.646715
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace

    class MockModule(object):
        def __init__(self):
            self.params = {
                'facter_path': '/usr/bin/facter',
                'cfacter_path': '/usr/bin/cfacter'
            }

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'facter':
                return self.params['facter_path']
            elif binary == 'cfacter':
                return self.params['cfacter_path']


# Generated at 2022-06-17 01:17:56.068838
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Get a list of all fact collectors
    collectors = list_collectors()

    # Get a list of all fact collector names
    names = get_collector_names()

    # Get an instance of the Facter fact collector
    facter_collector = get_collector_instance('facter')

    # Get the output of the Facter fact collector
    facter_output = facter_collector.get_facter_output(module=None)

    # Verify that the Facter fact collector output is None
    assert facter_output is None

# Generated at 2022-06-17 01:18:04.560869
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names

    # Get the instance of FacterFactCollector
    facter_collector = get_collector_instance('facter')

    # Get the module_utils.basic.AnsibleModule instance
    module = facter_collector.get_module()

    # Get the path of facter
    facter_path = facter_collector.find_facter(module)

    # Check if facter_path is not None
    assert facter_path is not None

    # Check if facter_path is a string
    assert isinstance(facter_path, str)

    # Check if facter_path is not empty
    assert facter_path != ''



# Generated at 2022-06-17 01:18:15.217434
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    # Create a FacterFactCollector object
    facter_fact_collector = FacterFactCollector()

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'


# Generated at 2022-06-17 01:18:25.547425
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/facter'

    class MockCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors
            self.namespace = namespace

    class MockNamespace(ansible.module_utils.facts.namespace.BaseFactNamespace):
        def __init__(self, namespace_name=None, prefix=None):
            self.namespace_name = namespace_name

# Generated at 2022-06-17 01:18:35.596662
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.mounts
    import ansible.module_utils.facts.system.date_time
    import ansible.module_utils.facts

# Generated at 2022-06-17 01:18:42.841572
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter.facter_collector
    import ansible.module_utils.facts.collectors.facter

# Generated at 2022-06-17 01:18:54.193340
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces_as_dict
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces_as_list

# Generated at 2022-06-17 01:18:54.885694
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:19:17.204493
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError

# Generated at 2022-06-17 01:19:28.406651
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import sys
    import os

    # Mock module class
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

        def get_bin_path(self, binary, opt_dirs=None):
            if binary == 'facter':
                return '/usr/bin/facter'
            elif binary == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

    # Mock module
    module = MockModule()

    # Create a FacterFactCollector
    facter_fact_collector = FacterFactCollect

# Generated at 2022-06-17 01:19:35.818334
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # get_collector_instance
    facter_collector = get_collector_instance('facter')
    assert isinstance(facter_collector, FacterFactCollector)

    # get_collector_names
    assert 'facter' in get_collector_names()

    # list_collectors
    assert 'facter' in list_collectors()

# Generated at 2022-06-17 01:19:43.264855
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import load_collectors
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import set_collector_status

# Generated at 2022-06-17 01:19:54.960374
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_collectors_for_facts
    from ansible.module_utils.facts.collector import get_collectors_for_platform
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class
    from ansible.module_utils.facts.collector import get_fact_collector_instance


# Generated at 2022-06-17 01:20:06.820671
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    class FakeModule(object):
        def __init__(self):
            self.bin_path = None

        def get_bin_path(self, name, opt_dirs=None):
            return self.bin_path

    class FakeCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        def __init__(self, collectors=None, namespace=None):
            self.namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace(namespace_name='facter',
                                                                                      prefix='facter_')
            self.collectors = collectors


# Generated at 2022-06-17 01:20:16.723725
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter

    class FakeModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'facter':
                return '/usr/bin/facter'
            elif name == 'cfacter':
                return '/usr/bin/cfacter'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/bin/facter --puppet --json':
                return 0, '{"facter_test": "test"}', ''

# Generated at 2022-06-17 01:20:27.706235
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'facter']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['fact_path'] = '/etc/ansible/facts.d'
            self.params['fact_caching'] = 'jsonfile'
            self.params['fact_caching_connection'] = '/tmp/facts'
            self.params['fact_caching_timeout'] = 3600

# Generated at 2022-06-17 01:20:38.328239
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheMixin
    from ansible.module_utils.facts.collector import BaseFileCacheMixin

# Generated at 2022-06-17 01:20:50.014878
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces
    from ansible.module_utils.facts.collector import get_collectors_for_all_namespaces_of_type
    from ansible.module_utils.facts.collector import get_collectors_of_type

# Generated at 2022-06-17 01:21:23.302898
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
    from ansible.module_utils.facts.namespace import FactNamespaceKeyError
   

# Generated at 2022-06-17 01:21:32.775903
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_ids
    from ansible.module_utils.facts.collector import get_fact_namespaces

# Generated at 2022-06-17 01:21:41.684979
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.utils

    # Create a mock module
    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['path'] = '/usr/bin:/bin'
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return (0, '{"facter_test_fact": "test_value"}', '')

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/facter'

    # Create a

# Generated at 2022-06-17 01:21:52.731358
# Unit test for method collect of class FacterFactCollector
def test_FacterFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_instance

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path

        def run_command(self, *args, **kwargs):
            return 0, '{"facter_test": "test"}', ''

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])


# Generated at 2022-06-17 01:22:03.655376
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux
    import ansible.module_utils.facts.system.mounts
    import ansible.module_utils.facts.system.timezone

# Generated at 2022-06-17 01:22:15.460637
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_fact_collector_classes
    from ansible.module_utils.facts.collector import get_fact_collector_class_names

    # Test that FacterFactCollector is registered
    assert 'facter' in get_collector_names()
    assert 'facter' in get_fact_collector_class_names()

    # Test that FacterFactCollector is returned by get_collector_for
    assert isinstance(get_collector_for('facter'), FacterFactCollector)

   

# Generated at 2022-06-17 01:22:25.830485
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.facter

    class FakeModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            if name == 'facter':
                return '/opt/puppetlabs/bin/facter'
            if name == 'cfacter':
                return '/opt/puppetlabs/bin/cfacter'
            return None

    module = FakeModule()
    facter_collector = ansible.module_utils.facts.collectors.facter.FacterFactCollector()
    facter_path = facter_collector.find_facter(module)
    assert facter_path == '/opt/puppetlabs/bin/cfacter'


# Generated at 2022-06-17 01:22:34.519192
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import ModuleUtilsCollector
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseFileOrCommandFactCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileDictFactCollector
    from ansible.module_utils.facts.collector import BaseCommandDictFactCollector

# Generated at 2022-06-17 01:22:39.943151
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors_for_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace
    from ansible.module_utils.facts.collector import get_collectors_for_type_namespace_path
    from ansible.module_utils.facts.collector import get_collectors_for_type_path

# Generated at 2022-06-17 01:22:46.259819
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.facter
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.suse
    import ansible.module_utils.facts.system.distribution.arch

# Generated at 2022-06-17 01:23:51.401157
# Unit test for method run_facter of class FacterFactCollector
def test_FacterFactCollector_run_facter():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.facter
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.system.zone
    import ansible.module_utils.facts.virtual.zone
    import ansible.module_utils.facts.virtual.zone


# Generated at 2022-06-17 01:23:59.224540
# Unit test for method get_facter_output of class FacterFactCollector
def test_FacterFactCollector_get_facter_output():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # get_collector_instance
    facter_collector = get_collector_instance('facter')
    assert isinstance(facter_collector, FacterFactCollector)

    # get_collector_names
    assert 'facter' in get_collector_names()

    # list_collectors
    assert 'facter' in list_collectors()

# Generated at 2022-06-17 01:24:11.190812
# Unit test for method find_facter of class FacterFactCollector
def test_FacterFactCollector_find_facter():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_namespace_prefixes
    from ansible.module_utils.facts.collector import get_fact_namespaces
    from ansible.module_utils.facts.collector import list_fact_namespaces