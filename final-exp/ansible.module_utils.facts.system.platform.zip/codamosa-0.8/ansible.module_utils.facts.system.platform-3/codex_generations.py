

# Generated at 2022-06-11 05:00:34.516374
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'

# Generated at 2022-06-11 05:00:39.800285
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:00:43.704892
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'
    assert platformFactCollector._fact_ids == set([u'system', u'kernel', u'kernel_version', u'machine', u'python_version', u'architecture', u'machine_id'])

# Generated at 2022-06-11 05:00:54.378700
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    # Stub module
    module = type('module', (), {})
    module.run_command = lambda command: (0, "", "")
    module.get_bin_path = lambda command: ""

    # Stub platform
    platform_patcher = mock.patch.object(platform, 'system', create = True, return_value = "AIX")
    platform_patcher.start()
    platform_patcher = mock.patch.object(platform, 'release', create = True, return_value = "1.1.1")
    platform_patcher.start()
    platform_patcher = mock.patch.object(platform, 'version', create = True, return_value = "1.1")
    platform_patcher.start()

# Generated at 2022-06-11 05:01:01.735331
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()

    # test name and fact ids
    assert pfc.name == "platform"
    assert pfc._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}

    # test return facts
    collect_data = pfc.collect()
    assert type(collect_data) == dict
    assert collect_data['python_version'] != ''
    assert collect_data['system'] != ''
    assert 'machine' in collect_data

# Generated at 2022-06-11 05:01:08.557182
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    # The class PlatformFactCollector should have the following attributes
    assert platform_fact_collector.name == 'platform'
    assert set(platform_fact_collector._fact_ids) == set(['system',
                                                          'kernel',
                                                          'kernel_version',
                                                          'machine',
                                                          'python_version',
                                                          'architecture',
                                                          'machine_id'])

# Generated at 2022-06-11 05:01:13.081310
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert 'system' in platform_collector._fact_ids
    assert 'architecture' in platform_collector._fact_ids

# Unit test to verify return values of collect()

# Generated at 2022-06-11 05:01:23.167028
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()[0]

# Generated at 2022-06-11 05:01:32.154079
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = MockModule()
    PlatformFactCollector.collect(module=mock_module)
    assert mock_module.run_command.call_count == 4

    # On AIX, we try to collect the bootinfo first, then fall back to getconf
    mock_module.run_command.assert_any_call(['/usr/bin/bootinfo', '-p'])
    mock_module.run_command.assert_any_call(['/usr/bin/getconf', 'MACHINE_ARCHITECTURE'])
    # On OpenBSD, we use the uname command to get the architecture
    mock_module.run_command.assert_any_call(['/usr/bin/uname', '-p'])
    # We try to get the machine ID from both locations
    mock_module.get_file_content

# Generated at 2022-06-11 05:01:36.423986
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'hostname' not in pfc._fact_ids

# Generated at 2022-06-11 05:02:50.036742
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test when all facts are enabled
    fact_collector = PlatformFactCollector(None, True, '')
    assert fact_collector.name == 'platform'

    # Test with 'machine_id' is disabled
    fact_collector = PlatformFactCollector(None, False, '')
    assert fact_collector.name == 'platform'

# Generated at 2022-06-11 05:02:55.498245
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Prepare input params for the method collect of class PlatformFactCollector
    module = None
    collected_facts = None

    # Unit test execution of method collect of class PlatformFactCollector
    collected_facts = PlatformFactCollector().collect(module, collected_facts)

    # Verify the result of the method collect of class PlatformFactCollector
    assert type(collected_facts) == dict

# Unit test execution
if __name__ == "__main__":
    test_PlatformFactCollector_collect()

# Generated at 2022-06-11 05:02:59.307280
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    result = { "architecture" : "i386", "machine" : "i386", "python_version" : "2.7.5", "system" : "Darwin", "kernel_version" : "12.5.0", "kernel" : "Darwin" }
    platform_facts = PlatformFactCollector()
    facts = platform_facts.collect()
    assert type(facts) is dict
    assert facts == result



# Generated at 2022-06-11 05:03:04.258534
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector("test_collector")
    assert pfc.name == "platform"
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])
    assert pfc.collect()

# Generated at 2022-06-11 05:03:09.137857
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector()
    assert result.name == 'platform'
    assert result._fact_ids == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])


# Generated at 2022-06-11 05:03:10.316760
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fc = PlatformFactCollector()
    assert fc.name == 'platform'

# Generated at 2022-06-11 05:03:15.504272
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids

# Generated at 2022-06-11 05:03:21.598870
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = getattr(__import__('ansible.module_utils', fromlist=['ansible']), 'module_utils')

# Generated at 2022-06-11 05:03:25.205131
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert isinstance(x._fact_ids, set)
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:03:33.167275
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # prepare
    from ansible.module_utils.facts import ModuleFacts
    class TestAnsibleModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, 'amd64', None)

        def get_bin_path(self, x):
            return '/bin/%s' % x

    test_module = TestAnsibleModule()
    platform_collector = PlatformFactCollector()
    facts = {}

    # execute
    platform_collector.collect(test_module, facts)

    # assert
    assert facts['system'] == 'Linux'
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert facts['machine'] == 'amd64'

# Generated at 2022-06-11 05:06:24.443219
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:06:25.976632
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.collect() == {}

# Generated at 2022-06-11 05:06:33.423971
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create an instance of PlatformFactCollector
    pfc = PlatformFactCollector()

    # Validate instance was created correctly
    assert(pfc.name == 'platform')
    assert(pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id']))

    # Collect facts
    facts = pfc.collect()

    # Validate facts were returned
    assert(isinstance(facts, dict))
    assert(len(facts) > 0)

# Unit tests for collect()

# Generated at 2022-06-11 05:06:35.715183
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert pfc.name == "platform"
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version', 'machine',
                             'platform_version', 'architecture', 'machine_id'}

# Generated at 2022-06-11 05:06:40.754731
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """This is to test the constructor of class PlatformFactCollector"""
    platform_testobj = PlatformFactCollector()
    assert platform_testobj
    assert platform_testobj.name == 'platform'
    assert platform_testobj._fact_ids == set(['system',
                                              'kernel',
                                              'kernel_version',
                                              'machine',
                                              'python_version',
                                              'architecture',
                                              'machine_id'])

# Generated at 2022-06-11 05:06:42.673392
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''Unit test for constructor of class PlatformFactCollector'''
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None

# Generated at 2022-06-11 05:06:46.023251
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-11 05:06:48.730190
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert type(PlatformFactCollector()) is PlatformFactCollector
    # TODO: Add tests for other methods
    # TODO: Add tests to exercise other branches that can't be hit via
    # functional testing with Ansible.

# Generated at 2022-06-11 05:06:53.316693
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector

    collector = Collector()
    collector.add_collector(PlatformFactCollector())
    facts = collector.collect(module=None, cached_facts={})

    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()

# Generated at 2022-06-11 05:07:00.601884
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    facts = collector.collect(None, None)
    # bare minimum - these facts should exist
    assert facts['system'] == 'Linux'
    assert facts['kernel'] == '2.6.32-504.el6.x86_64'
    assert facts['machine'] == 'x86_64'
    assert facts['architecture'] == 'x86_64'
    assert facts['userspace_architecture'] == 'x86_64'
    assert facts['fqdn'] == 'test.example.com'
    assert facts['hostname'] == 'test'
    assert facts['domain'] == 'example.com'
    assert "machine_id" in facts