

# Generated at 2022-06-11 05:00:40.452277
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-11 05:00:46.405792
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    collected_facts = platform_fact_collector.collect()
    assert collected_facts

    assert 'python_version' in collected_facts
    assert type(collected_facts['python_version']) is str
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'machine_id' in collected_facts
    assert 'machine_id' in platform_fact_collector._fact_ids

# Generated at 2022-06-11 05:00:51.069389
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()

    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-11 05:00:57.793249
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    my_obj = PlatformFactCollector()
    assert my_obj
    assert type(my_obj) == PlatformFactCollector
    assert my_obj.name == 'platform'
    assert my_obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert my_obj.collect()

# Generated at 2022-06-11 05:00:58.787452
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector()

# Generated at 2022-06-11 05:01:01.993798
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == {'architecture', 'kernel_version', 'python_version',
                           'machine', 'kernel', 'system', 'machine_id'}

# Generated at 2022-06-11 05:01:06.177298
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"
    assert "system" in platform_fact_collector._fact_ids
    assert "kernel" in platform_fact_collector._fact_ids
    assert "kernel_version" in platform_fact_collector._fact_ids
    assert "machine" in platform_fact_collector._fact_ids
    assert "python_version" in platform_fact_collector._fact_ids
    assert "architecture" in platform_fact_collector._fact_ids
    assert "machine_id" in platform_fact_collector._fact_ids

# Generated at 2022-06-11 05:01:13.569579
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    facter = PlatformFactCollector()
    facts = facter.collect()

    assert isinstance(facts, dict)
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'python_version' in facts
    assert 'architecture' in facts
    assert 'userspace_bits' in facts
    assert 'machine_id' in facts

# Generated at 2022-06-11 05:01:17.925679
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                              'kernel',
                              'kernel_version',
                              'machine',
                              'python_version',
                              'architecture',
                              'machine_id'])

# Generated at 2022-06-11 05:01:22.398865
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-11 05:02:41.622086
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.__class__.__name__ == "PlatformFactCollector"
    assert platform.name == "platform"
    assert platform._fact_ids == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])


# Generated at 2022-06-11 05:02:42.571138
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-11 05:02:49.499233
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    This is a Unit test for constructor of class PlatformFactCollector
    with passing empty value as input
    """
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-11 05:02:57.740966
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    instance = PlatformFactCollector()
    result = instance.collect()
    # The "machine" fact is dynamically resolved
    assert result == {
        "system": platform.system(),
        "kernel": platform.release(),
        "kernel_version": platform.version(),
        "machine": platform.machine(),
        "python_version": platform.python_version(),
        "fqdn": socket.getfqdn(),
        "hostname": platform.node().split(".")[0],
        "nodename": platform.node(),
        "domain": ".".join(socket.getfqdn().split(".")[1:]),
        "userspace_bits": platform.architecture()[0].replace("bit", ""),
        "architecture": platform.machine(),
    }

# Generated at 2022-06-11 05:02:58.517889
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:03:00.769982
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None, "Failed to construct a PlatformFactCollector"


# Generated at 2022-06-11 05:03:08.394815
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids

# Generated at 2022-06-11 05:03:09.022420
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:03:10.858063
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    PlatformFactCollector.collect()

# Generated at 2022-06-11 05:03:14.803491
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-11 05:06:05.523355
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-11 05:06:07.105376
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector()

    # getting an empty dict back is the successful response
    assert(type(platform.collect()) == type({}))

# Generated at 2022-06-11 05:06:11.198039
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert x.collect() is not None

# Generated at 2022-06-11 05:06:13.118353
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    import sys
    print(sys.path)
    pfc = PlatformFactCollector()
    print(type(pfc))
    print(pfc)



# Generated at 2022-06-11 05:06:14.501499
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == "platform"
    assert obj.priority == 10

# Generated at 2022-06-11 05:06:19.785717
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'machine_id' in p._fact_ids

# Generated at 2022-06-11 05:06:24.253330
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == "platform"
    assert PlatformFactCollector._fact_ids == set(['system',
                                                  'kernel',
                                                  'kernel_version',
                                                  'machine',
                                                  'python_version',
                                                  'architecture',
                                                  'machine_id'])


# Generated at 2022-06-11 05:06:29.039418
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-11 05:06:33.980339
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector is not None
    assert platformFactCollector.name == "platform"
    assert platformFactCollector._fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id'])


# Generated at 2022-06-11 05:06:35.915386
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])