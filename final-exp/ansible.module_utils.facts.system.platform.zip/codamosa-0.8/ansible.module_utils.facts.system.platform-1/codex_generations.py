

# Generated at 2022-06-11 05:00:37.476733
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pf = PlatformFactCollector()
    facts = pf.collect()
    assert facts['system']
    assert facts['kernel']
    assert facts['kernel_version']
    assert facts['machine']
    assert facts['architecture']

# Generated at 2022-06-11 05:00:46.851312
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert isinstance(PlatformFactCollector._fact_ids, set)
    assert 'system' in PlatformFactCollector._fact_ids
    assert 'kernel' in PlatformFactCollector._fact_ids
    assert 'kernel_version' in PlatformFactCollector._fact_ids
    assert 'machine' in PlatformFactCollector._fact_ids
    assert 'python_version' in PlatformFactCollector._fact_ids
    assert 'architecture' in PlatformFactCollector._fact_ids
    assert 'machine_id' in PlatformFactCollector._fact_ids

# Generated at 2022-06-11 05:00:50.614170
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None
    assert x._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-11 05:00:51.271763
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass

# Generated at 2022-06-11 05:00:51.875490
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:00:56.258900
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-11 05:01:03.680943
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = None
    collected_facts = None
    pf = PlatformFactCollector()
    platform_facts = pf.collect(module, collected_facts)
    # Exact content of 'system' is platform dependent
    assert platform_facts.has_key('system')
    # Exact content of 'kernel' is platform dependent
    assert platform_facts.has_key('kernel')
    assert platform_facts.has_key('kernel_version')
    assert platform_facts.has_key('machine')
    assert platform_facts.has_key('python_version')
    # Exact content of 'architecture' is platform dependent
    assert platform_facts.has_key('architecture')



# Generated at 2022-06-11 05:01:05.630626
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    # 'system' is one of the fact identifiers for this class
    assert 'system' in pfc._fact_ids

# Generated at 2022-06-11 05:01:12.534110
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:01:18.541207
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['architecture'] == platform.machine()

# Generated at 2022-06-11 05:01:41.949306
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    actual_facts = PlatformFactCollector().collect()
    assert 'system' in actual_facts
    assert 'kernel' in actual_facts
    assert 'kernel_version' in actual_facts
    assert 'machine' in actual_facts
    assert 'python_version' in actual_facts
    assert 'architecture' in actual_facts
    assert 'machine_id' in actual_facts

# Generated at 2022-06-11 05:01:43.118268
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-11 05:01:43.732638
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:01:50.876718
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    collected_facts = {'fqdn': 'foo.bar', 'domain': 'bar'}
    platform_facts = pfc.collect(collected_facts)
    assert platform_facts['system'] == platform.system()
    assert platform_facts['system'] != ''
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['architecture'] == platform.machine()
    assert platform_facts['fqdn'] == collected_facts['fqdn']
    assert platform_facts['domain'] == collected_facts['domain']

# Generated at 2022-06-11 05:01:54.103789
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = DummyModule({})
    collected_facts = {}
    pfc = PlatformFactCollector()
    platform_facts = pfc.collect(module, collected_facts)
    assert isinstance(platform_facts, dict)

# Class to mimic AnsibleModule class

# Generated at 2022-06-11 05:01:55.519973
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'

# Generated at 2022-06-11 05:02:03.616372
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test PlatformFactCollector.collect
    """
    class MockModule(object):
        def __init__(self):
            self.mock_results = {}

        def get_bin_path(self, executable):
            return self.mock_results.get(executable)

        def run_command(self, cmd):
            return self.mock_results[cmd]

    platform_facts = {}
    platform_facts.update({u'system': u'Linux',
            u'python_version': u'2.7.5',
            u'machine': u'x86_64',
            u'kernel_version': u'#1 SMP Tue May 6 19:49:32 UTC 2014',
            u'kernel': u'3.13.0-24-generic'
            })

# Generated at 2022-06-11 05:02:07.468465
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:02:08.865792
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert isinstance(collector, PlatformFactCollector)

# Generated at 2022-06-11 05:02:19.342407
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    from ansible.module_utils.facts import FactCollector

    import collections
    import re

    module_mock = collections.namedtuple('module_mock', ['run_command', '_load_params', 'get_bin_path'])
    def get_bin_path_mock(path):
        if path == 'getconf':
            return '/usr/bin/getconf'
        elif path == 'bootinfo':
            return '/usr/bin/bootinfo'

    module = module_mock(None, None, get_bin_path_mock)

    fc = FactCollector(module)
    fc.collect_platform_facts = lambda: True
    platform_facts = fc.get_facts()

    # Test system
    assert platform_facts['system'] == platform.system()

   

# Generated at 2022-06-11 05:03:18.549228
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    This test is for PlatformFactCollector.collect

    '''
    # Creating a fake module object
    def get_bin_path(name):
        return False
    module = type('AnsibleModule', (object,), {'get_bin_path': get_bin_path})()

    # Collecting platform facts
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(module)

    # Check if required platforms facts are present
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['machine'] == platform.machine()

    # Check if architecture is present
    assert platform_facts['architecture'] == platform.machine()

# Generated at 2022-06-11 05:03:22.236839
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Constructor of class PlatformFactCollector
    pfc = PlatformFactCollector()

    # Variable initialized by constructor
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-11 05:03:26.260457
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert 'system' in PlatformFactCollector._fact_ids
    assert 'kernel' in PlatformFactCollector._fact_ids
    assert 'kernel_version' in PlatformFactCollector._fact_ids
    assert 'machine' in PlatformFactCollector._fact_ids
    assert 'python_version' in PlatformFactCollector._fact_ids
    assert 'architecture' in PlatformFactCollector._fact_ids


# Generated at 2022-06-11 05:03:27.424808
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None

# Generated at 2022-06-11 05:03:31.428458
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-11 05:03:33.885497
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()

    # Test collect with no data
    data = pfc.collect()

    assert data is not None
    assert len(data) > 0
    assert data.get("system") is not None

# Generated at 2022-06-11 05:03:37.920922
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'
    assert platformFactCollector._fact_ids == { 'system', 'kernel', 'kernel_version',
                                                'machine', 'python_version', 'architecture',
                                                'machine_id' }
    assert platformFactCollector.collect() is not None

# Generated at 2022-06-11 05:03:47.525888
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # test collect

    platform_facts = {'architecture': 'x86_64',
                      'fqdn': 'test.example.com',
                      'hostname': 'test',
                      'kernel': '3.10.0-327.22.2.el7.x86_64',
                      'kernel_version': '#1 SMP Thu Jun 23 17:05:39 UTC 2016',
                      'machine': 'x86_64',
                      'machine_id': 'bbedcb40243040f19d784bfe2c70cd42',
                      'nodename': 'test.example.com',
                      'python_version': '2.7.5',
                      'system': 'Linux',
                      'userspace_architecture': 'x86_64',
                      'userspace_bits': '64'}


# Generated at 2022-06-11 05:03:51.372398
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert set(p._fact_ids) == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])

# Generated at 2022-06-11 05:03:54.764836
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    i = PlatformFactCollector(None)
    assert i.name == "platform"
    assert 'system' in i._fact_ids
    assert 'kernel' in i._fact_ids
    assert 'kernel_version' in i._fact_ids
    assert 'machine' in i._fact_ids
    assert 'architecture' in i._fact_ids
    assert 'machine_id' in i._fact_ids

# Generated at 2022-06-11 05:05:19.803391
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'

# Generated at 2022-06-11 05:05:27.821711
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platformFactCollector = PlatformFactCollector()

    domain = '.'.join(socket.getfqdn().split('.')[1:])

    facts = {'architecture': platform.machine(),
             'domain': domain,
             'fqdn': socket.getfqdn(),
             'hostname': socket.getfqdn().split('.')[0],
             'kernel': platform.release(),
             'kernel_version': platform.version(),
             'machine': platform.machine(),
             'nodename': socket.getfqdn(),
             'python_version': platform.python_version(),
             'system': platform.system(),
             'userspace_bits': platform.architecture()[0].replace('bit', '')}

    if facts['system'] == 'AIX':
        getconf_bin = module.get_

# Generated at 2022-06-11 05:05:30.651197
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert hasattr(collector, 'name')
    assert hasattr(collector, '_fact_ids')
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-11 05:05:37.167329
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.facts.collectors.platform
    import platform

    # Instantiate a PlatformFactCollector object
    pfc = ansible.module_utils.facts.collectors.platform.PlatformFactCollector()

    # Assert the attributes are initialized properly
    assert pfc.name == "platform"
    assert pfc.fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])

    # Assert it is a subclass of BaseFactCollector
    assert isinstance(pfc, BaseFactCollector)

    # Assert

# Generated at 2022-06-11 05:05:41.256556
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    actual_collector = PlatformFactCollector()
    assert actual_collector.name == 'platform'
    assert actual_collector._fact_ids == set(['system',
                                              'kernel',
                                              'kernel_version',
                                              'machine',
                                              'python_version',
                                              'architecture',
                                              'machine_id'])

# Generated at 2022-06-11 05:05:45.106939
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-11 05:05:49.131372
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:05:51.404368
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Call the constructor of PlatformFactCollector
    fact_collector = PlatformFactCollector()
    # PlatformFactCollector is an object of BaseFactCollector
    assert isinstance(fact_collector, BaseFactCollector)

# Generated at 2022-06-11 05:05:52.219991
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector().collect()

# Generated at 2022-06-11 05:05:59.502302
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """This function is used to test the constructor of PlatformFactCollector class"""

    platform_collector = PlatformFactCollector()

    assert platform_collector.name == 'platform'
    assert 'system' in platform_collector._fact_ids
    assert 'kernel' in platform_collector._fact_ids
    assert 'kernel_version' in platform_collector._fact_ids
    assert 'machine' in platform_collector._fact_ids
    assert 'python_version' in platform_collector._fact_ids
    assert 'architecture' in platform_collector._fact_ids
    assert 'machine_id' in platform_collector._fact_ids


# Generated at 2022-06-11 05:08:53.809599
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'

# Generated at 2022-06-11 05:08:54.279708
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:08:55.861561
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-11 05:09:05.623747
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    print("")
    import types
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    # Creation of a mock module, as if it was sent by Ansible module
    module = types.ModuleType('ansible.module_utils.facts.system.platform')

    # Creation of a mock class, as if it was returned by the module.run_command
    class RunCommandMock(object):

        def __init__(self):
            self.return_values = []
            self.call_count = 0
            self.call_history = []

        def add_return_value(self, return_value):
            self.return_values.append(return_value)


# Generated at 2022-06-11 05:09:10.202389
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Test class import
    from ansible.module_utils.facts import collector

    # Create Platform fact collector object
    test_PlatformFactCollector_collect_object = collector.get_collector('PlatformFactCollector')

    # Test if object is created properly
    assert test_PlatformFactCollector_collect_object is not None

    # Test if method collect is callable
    assert callable(test_PlatformFactCollector_collect_object.collect)

# Generated at 2022-06-11 05:09:13.609059
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:09:21.144153
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import FactsCache
    from ansible.module_utils.facts import ModuleFactsCache

    mfc = ModuleFactsCache(module=None, collected_facts=None)
    facts_cache = FactsCache(module=None, collected_facts=None)
    fc = FactsCollector(mfc, facts_cache, module=None)
    pfc = PlatformFactCollector(module=None)
    fc.collectors.append(pfc)

    collected_facts = fc.collect(module=None)
    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    assert collected_

# Generated at 2022-06-11 05:09:27.857457
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    _platform_facts = {
        "architecture": "x86_64",
        "domain": "",
        "fqdn": "localhost.localdomain",
        "hostname": "localhost",
        "kernel": "2.6.32-431.el6.x86_64",
        "kernel_version": "#1 SMP Fri Nov 22 03:15:09 UTC 2013",
        "machine": "x86_64",
        "nodename": "localhost.localdomain",
        "python_version": "2.6.6",
        "system": "Linux",
        "userspace_architecture": "x86_64",
        "userspace_bits": "64",
    }
    platform_fact_collector = PlatformFactCollector()

# Generated at 2022-06-11 05:09:28.455338
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj

# Generated at 2022-06-11 05:09:31.614109
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])