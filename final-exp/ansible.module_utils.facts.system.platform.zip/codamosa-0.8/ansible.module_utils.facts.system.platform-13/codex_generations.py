

# Generated at 2022-06-11 05:00:41.755812
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-11 05:00:46.118739
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:00:50.798828
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-11 05:01:00.536931
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Using object instead of module for testing.
    class TestModule:
        def get_bin_path(self, name=None, opt_dirs=[]):
            if name in ('getconf', 'bootinfo'):
                return True
            else:
                return False

        def run_command(self, args):
            class TestResult:
                def __init__(self, rc, out, err):
                    self.rc = rc
                    self.out = out
                    self.err = err

            return TestResult(0, "TestStdout", "TestStderr")

    test_module = TestModule()

    platform_facts = PlatformFactCollector(test_module).collect()

    assert 'TestStdout' in platform_facts['architecture']

# Generated at 2022-06-11 05:01:10.184568
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}

    # platform.system() can be Linux, Darwin, Java, or Windows
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['architecture'] = platform.machine()
    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform

# Generated at 2022-06-11 05:01:20.954197
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collectors.platform.linux import PlatformLinuxFactCollector
    from ansible.module_utils.facts.collectors.platform.freebsd import PlatformFreebsdFactCollector
    from ansible.module_utils.facts.collectors.platform.netbsd import PlatformNetbsdFactCollector
    from ansible.module_utils.facts.collectors.platform.aix import PlatformAixFactCollector
    from ansible.module_utils.facts.collectors.platform.sunos import PlatformSunosFactCollector
    from ansible.module_utils.facts.collectors.platform.openbsd import PlatformOpenbsdFactCollector
    from ansible.module_utils.facts.collectors.platform.darwin import PlatformDarwinFactCollector

# Generated at 2022-06-11 05:01:23.656745
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_collector_obj = PlatformFactCollector()
    assert platform_facts_collector_obj.name == "platform"
    assert platform_facts_collector_obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:01:24.731218
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:01:34.229332
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.utils import get_file_content
    import ansible.module_utils.facts.collectors.platform
    import ansible.module_utils.facts.collectors
    import ansible

    import os
    import sys
    import platform

    sys.modules['ansible'] = ansible
    sys.modules['ansible.module_utils'] = ansible.module_utils
    sys.modules['ansible.module_utils.facts'] = ansible.module_utils.facts
    sys.modules['ansible.module_utils.facts.collectors'] = ansible.module_utils.facts.collectors

    module = ansible.module_utils.facts.ModuleStub()
   

# Generated at 2022-06-11 05:01:37.553908
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'architecture' in x._fact_ids

# Generated at 2022-06-11 05:02:21.526804
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instantiate the object
    platform_fact_collector = PlatformFactCollector
    # Check the returned value
    assert platform_fact_collector.collect() is not None

# Generated at 2022-06-11 05:02:22.512492
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector.collect()

# Generated at 2022-06-11 05:02:27.063591
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fc = PlatformFactCollector()
    assert fc is not None
    assert fc.name == 'platform'
    assert fc._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])

# Generated at 2022-06-11 05:02:30.795996
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_module = AnsibleModuleMock()
    fact_module.run_command = Mock()
    fact_module.get_bin_path = Mock()
    fact_module.get_file_content = Mock()
    fact_module.get_file_content.return_value = ""
    fact_module.run_command.return_value = (0, 'x86_64', '')
    fact_module.get_bin_path.return_value = True

    platform_fact_collector = PlatformFactCollector()
    platform_facts_dict = platform_fact_collector.collect(fact_module)

    assert platform_facts_dict['architecture'] == 'x86_64'
    assert platform_facts_dict['userspace_architecture'] == 'x86_64'

# Generated at 2022-06-11 05:02:31.294801
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x

# Generated at 2022-06-11 05:02:39.757821
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    import socket
    import collections
    import pytest

    '''
    NOTE: Warning - this is not a true unit test.
    Why? Because it relies on the correct functioning
    of the socket library to provide the correct data
    (this is well tested elsewhere, but not here)

    What do you need to do to make it work?
    You need to set the environment variable
    ANSIBLE_GATHERING_PLATFORM_FACTS_TEST_HOSTNAME
    to the value you want to test against

    i.e.
    export ANSIBLE_GATHERING_PLATFORM_FACTS_TEST_HOSTNAME=hostname.domain.local
    '''

    platform_facts = collections.OrderedDict()

    # platform.system() can be Linux, Darwin, Java,

# Generated at 2022-06-11 05:02:41.447282
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    facts = pfc.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-11 05:02:43.044344
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert hasattr(PlatformFactCollector, 'name')
    assert hasattr(PlatformFactCollector, '_fact_ids')

# Generated at 2022-06-11 05:02:45.121624
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'

# Generated at 2022-06-11 05:02:54.832668
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def fake_getfqdn():
        return 'localhost'
    def fake_gethostname():
        return 'localhost'
    collector = PlatformFactCollector()
    # The collector instance must have name of 'platform'
    assert collector.name == 'platform'
    # The collect method is only invoked with module,
    # collected_facts and so the method must return a dict
    collected_facts = {}
    # Mock some collect method
    module = type('module', (object, ),
                  {'get_bin_path': lambda x, y=False: '/usr/bin/python'})
    full_facts = collector.collect(module, collected_facts)
    assert full_facts["python_version"] == platform.python_version()
    assert full_facts["kernel"] == platform.release()

# Generated at 2022-06-11 05:04:07.315717
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    # Create instance of class PlatformFactCollector
    platform_facts_collector = PlatformFactCollector()

    # Check name of fact module
    assert platform_facts_collector.name == 'platform'

    # Check types of platform fact data
    assert all(type(v) == set for v in platform_facts_collector._fact_ids)

    # Check values of platform fact data

# Generated at 2022-06-11 05:04:08.355583
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-11 05:04:10.787530
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """This function is used to test the constructor of class
    PlatformFactCollector.
    """
    # make sure the class could be instantiated
    PlatformFactCollector()

# Generated at 2022-06-11 05:04:14.265054
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    facts_dict = platform_collector.collect()
    assert isinstance(facts_dict, dict)
    assert "machine" in facts_dict
    assert "system" in facts_dict
    assert "python_version" in facts_dict

# Generated at 2022-06-11 05:04:18.002025
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', \
                                                    'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-11 05:04:22.272196
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:04:23.416598
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    result = PlatformFactCollector.collect()
    assert result["system"] == platform.system()

# Generated at 2022-06-11 05:04:31.369272
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import mock
    import platform
    from ansible.module_utils.facts import collector

    platform_collector = PlatformFactCollector()

    module = mock.MagicMock()
    module.run_command.return_value = ['', '', '']

    platform.system.return_value = 'Linux'
    platform.release.return_value = '2.6.18-408.e15'
    platform.version.return_value = '#1 SMP Tue Sep 20 19:59:27 EDT 2016'
    platform.machine.return_value = 'x86_64'
    platform.python_version.return_value = '2.7.5'

    socket.getfqdn.return_value = 'abcdefgh12345.abc.def.ghi.jkl'

# Generated at 2022-06-11 05:04:39.497138
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import sys
    import tempfile

    # Create a test environment

# Generated at 2022-06-11 05:04:40.836539
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_collector.collect()

# Generated at 2022-06-11 05:07:57.834514
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == {'system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'}


# Generated at 2022-06-11 05:07:59.956803
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    print(platform_facts)
    print(platform_facts.keys())
    assert(isinstance(platform_facts, dict))


# Generated at 2022-06-11 05:08:01.588537
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    sol_fact_collector = PlatformFactCollector()
    assert sol_fact_collector.name == 'platform'
    assert not sol_fact_collector.has_deps

# Generated at 2022-06-11 05:08:03.339725
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pf = PlatformFactCollector()
    facts = pf.collect()
    assert type(facts) is dict
    assert 'system' in facts


# Generated at 2022-06-11 05:08:06.417075
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


# Generated at 2022-06-11 05:08:09.906477
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert hasattr(PlatformFactCollector, 'name')
    assert PlatformFactCollector.name == 'platform'

    assert hasattr(PlatformFactCollector, '_fact_ids')
    assert PlatformFactCollector._fact_ids == \
        set(['system', 'kernel', 'kernel_version', 'machine',
             'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:08:13.876509
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector(None)
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-11 05:08:19.055518
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()

    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids

# Generated at 2022-06-11 05:08:22.640504
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    base_fact_collector = BaseFactCollector()
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == base_fact_collector._fact_ids



# Generated at 2022-06-11 05:08:23.774207
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector is not None
