

# Generated at 2022-06-11 05:00:41.695062
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """PlatformFactCollector - class constructor test"""
    from ansible.module_utils.facts.collector import BaseFactCollector
    pfc = PlatformFactCollector()
    assert isinstance(pfc, BaseFactCollector)


# Generated at 2022-06-11 05:00:51.777007
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for method collect of class PlatformFactCollector
    """
    import sys
    import platform
    import socket
    module = sys.modules['ansible.module_utils'].basic
    module = sys.modules['ansible.module_utils'].basic

    module.get_bin_path = lambda *args: False
    module.run_command = lambda *args: (0, '', '')

    fact_collector = PlatformFactCollector()

    # platform.system() can be Linux, Darwin, Java, or Windows
    # platform.machine() can be x86_64, i386, or sun4m
    # python version can be 2.6, 2.7, 3.6


# Generated at 2022-06-11 05:00:56.538484
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test with valid parameters
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-11 05:01:01.130440
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-11 05:01:11.515119
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():  # pylint: disable=invalid-name
    # Create a PlatformFactCollector instance to call method collect
    # pylint: disable=unused-variable
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collectors import PlatformFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_content
    import tempfile

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.dc = {}
            self.tmpdir = tempfile.gettempdir()


# Generated at 2022-06-11 05:01:16.078666
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:01:17.735909
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), PlatformFactCollector)


# Generated at 2022-06-11 05:01:25.766060
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # This class is not directly instantiated
    # by the code in the module, but is invoked
    # by the code in the ansible.module_utils.facts.facts
    # module which uses the get_collector() method on
    # the BaseFactCollector class. This is done to create
    # a more testable code base and avoid raising
    # exceptions in the constructor of the class.

    pfc = PlatformFactCollector()
    assert pfc.name == "platform"
    assert pfc._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

    return True


# Generated at 2022-06-11 05:01:30.106393
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])



# Generated at 2022-06-11 05:01:40.962141
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import PlatformFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    if platform.system() == 'Linux':
        file_name = '/var/lib/dbus/machine-id'
    else:
        file_name = '/etc/machine-id'
    content = file_name.split('/').pop()

# Generated at 2022-06-11 05:02:26.137211
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:02:29.339927
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plf = PlatformFactCollector()
    assert plf.name == 'platform'
    assert plf._fact_ids == {'system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'machine_id'}

# Generated at 2022-06-11 05:02:31.275844
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:02:34.229117
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:02:41.185084
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert 'system' in PlatformFactCollector()._fact_ids
    assert 'kernel' in PlatformFactCollector()._fact_ids
    assert 'kernel_version' in PlatformFactCollector()._fact_ids
    assert 'machine' in PlatformFactCollector()._fact_ids
    assert 'python_version' in PlatformFactCollector()._fact_ids
    assert 'architecture' in PlatformFactCollector()._fact_ids
    assert 'machine_id' in PlatformFactCollector()._fact_ids
    assert len(PlatformFactCollector()._fact_ids) == 7

# Generated at 2022-06-11 05:02:47.091429
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Unit test to test collect method of class PlatformFactCollector

# Generated at 2022-06-11 05:02:51.856550
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pc = PlatformFactCollector()
    assert pc.name == "platform"
    assert pc.collect()['system'] == platform.system()
    assert pc.collect()['kernel'] == platform.release()
    assert pc.collect()['kernel_version'] == platform.version()
    assert pc.collect()['machine'] == platform.machine()

# Generated at 2022-06-11 05:02:59.263897
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
        Test the constructor of class PlatformFactCollector
    """

    # Test for class PlatformFactCollector
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector
    assert platformFactCollector.name == 'platform'
    assert len(platformFactCollector._fact_ids) == 9
    assert 'system' in platformFactCollector._fact_ids
    assert 'kernel' in platformFactCollector._fact_ids
    assert 'kernel_version' in platformFactCollector._fact_ids
    assert 'machine' in platformFactCollector._fact_ids
    assert 'python_version' in platformFactCollector._fact_ids
    assert 'architecture' in platformFactCollector._fact_ids
    assert 'machine_id' in platformFactCollector._fact_ids
    assert 'fqdn' in platformFactCollect

# Generated at 2022-06-11 05:03:07.444207
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    import platform
    import re
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.platform.platform import PlatformFactCollector

    platform_facts = PlatformFactCollector()

    assert isinstance(platform_facts, BaseFactCollector)
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == set(['system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'])



# Generated at 2022-06-11 05:03:16.105179
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Facts
    pf = PlatformFactCollector()
    # Create a Facts object
    facts = Facts(None, None)
    # Collect platform facts
    pf.collect(facts)
    # Check the facts
    assert pf.name == 'platform'
    assert len(pf._fact_ids) == 9
    for fact in pf._fact_ids:
        assert fact in facts.data
    assert facts.data['system'] == 'Linux'
    assert facts.data['kernel'] == '3.10.0-327.el7.x86_64'
    assert facts.data['kernel_version'] == '#1 SMP Thu Nov 19 22:10:57 UTC 2015'
    assert facts.data['machine'] == 'x86_64'

# Generated at 2022-06-11 05:04:34.633057
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create an instance of class PlatformFactCollector
    platform_collector = PlatformFactCollector()
    # run collect method and store the result in a facts dictionary
    facts = platform_collector.collect()
    # check that the facts dictionary is not empty
    assert facts is not None
    assert bool(facts) is True
    # check if the required keys are present in the dictionary
    keys = ('system', 'kernel', 'kernel_version', 'machine', 'python_version',
            'architecture', 'machine_id')
    for key in keys:
        assert key in facts

# Generated at 2022-06-11 05:04:43.037156
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    result = PlatformFactCollector().collect()
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()
    assert result['domain'] == '.'.join(socket.getfqdn().split('.')[1:])
    # FIXME: This bit of the test is broken when the host fqdn is an IP address

# Generated at 2022-06-11 05:04:45.374927
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert "system" in p.collect(collected_facts={}), "Failed to return data for system"

# Generated at 2022-06-11 05:04:52.295385
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Initialize the module and ignore the arguments
    module = AnsibleModuleMock(argument_spec={})
    # Initialize the class
    obj = PlatformFactCollector(module=module)
    # Collect the facts
    facts_dict = obj.collect()

    # check if the kernel fact is present
    assert 'kernel' in facts_dict
    assert facts_dict['kernel'] is not None
    # check if the system fact is present
    assert 'system' in facts_dict
    assert facts_dict['system'] is not None
    # check if the machine fact is present
    assert 'machine' in facts_dict
    assert facts_dict['machine'] is not None
    # check if the kernel fact is present
    assert 'kernel_version' in facts_dict
    assert facts_dict['kernel_version'] is not None


# Generated at 2022-06-11 05:04:53.861265
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert isinstance(x._fact_ids, set)

# Generated at 2022-06-11 05:04:57.149811
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector = FactsCollector(module=None)
    platform_facts_collector = PlatformFactCollector()
    assert not set.difference(platform_facts_collector._fact_ids, facts_collector._fact_ids)

# Generated at 2022-06-11 05:05:03.590084
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.collect()["system"] == platform.system()
    assert p.collect()["kernel"] == platform.release()
    assert p.collect()["kernel_version"] == platform.version()
    assert p.collect()["machine"] == platform.machine()
    assert p.collect()["python_version"] == platform.python_version()
    assert p.collect()["fqdn"] == socket.getfqdn()
    assert p.collect()["domain"] == p.collect()["fqdn"][p.collect()["fqdn"].find('.')+1:]

# Generated at 2022-06-11 05:05:05.332831
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    supported_facts = PlatformFactCollector._fact_ids
    for fact in PlatformFactCollector().collect():
        assert fact in supported_facts

# Generated at 2022-06-11 05:05:06.181592
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect({})

# Generated at 2022-06-11 05:05:14.137627
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class TestModule:
        def get_bin_path(self, executable, required=False):
            if executable == "bootinfo":
                return "/usr/bin/bootinfo"
            elif executable == "getconf":
                return "/usr/bin/getconf"

        def run_command(self, command):
            if command == ['/usr/bin/bootinfo', '-p']:
                return 0, "powerpc\n", ""
            elif command == ['/usr/bin/getconf', 'MACHINE_ARCHITECTURE']:
                return 0, "powerpc\n", ""

    # Test for AIX
    platform_facts = PlatformFactCollector()

    test_module = TestModule()
    platform_facts.collect(module=test_module)

# Generated at 2022-06-11 05:08:19.089760
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert isinstance(pf, PlatformFactCollector)
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])


# Generated at 2022-06-11 05:08:22.679258
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-11 05:08:26.883338
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'

    # Assert that all the fact ids are in fact_ids
    assert collector._fact_ids == {'system',
                                   'kernel',
                                   'kernel_version',
                                   'machine',
                                   'python_version',
                                   'architecture',
                                   'machine_id'}

# Generated at 2022-06-11 05:08:34.565599
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # create a stub module object
    class StubModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/uname'

        def run_command(self, *args, **kwargs):
            class StubRC(object):
                returncode = 0

            class StubOut(object):
                splitlines = lambda self: ['aix']

            class StubErr(object):
                splitlines = lambda self: []

            return StubRC(), StubOut(), StubErr()

    # create a stub module class for test
    class StubModuleClass(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    stub_module = StubModule()
   

# Generated at 2022-06-11 05:08:37.762168
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    for fact_id in platform_fact_collector._fact_ids:
        assert fact_id in platform_fact_collector.collect()


# Generated at 2022-06-11 05:08:45.213462
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test PlatformFactCollector.collect()
    """
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import fetch_filesystem_info
    from ansible.module_utils.facts.collector import get_module_paths


# Generated at 2022-06-11 05:08:48.964929
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:08:52.767090
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])
    assert callable(platform_facts.collect)

# Generated at 2022-06-11 05:08:55.765264
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture'])

# Generated at 2022-06-11 05:08:57.221574
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector is not None

