

# Generated at 2022-06-11 05:00:37.976729
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert 'platform' == pfc.name
    assert {'system', 'kernel', 'kernel_version', 'machine', 'python_version',
        'architecture', 'machine_id'} == pfc._fact_ids

    # The rest of the class is not easily tested at the module level
    # It would require mocking out the platform library
    # (which would be possible, just not worth it)

# Generated at 2022-06-11 05:00:47.606723
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MockModule()
    collector = PlatformFactCollector(module=module)

    facts = collector.collect()
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['machine_id'] == 'test_machine_id'
    assert facts['fqdn'] == 'host.domain.tld'
    assert facts['hostname'] == 'host'
    assert facts['nodename'] == 'host.domain.tld'
    assert facts['domain'] == 'domain.tld'

    # TODO: add other tests

# Unit test class PlatformFactCollector

# Generated at 2022-06-11 05:00:55.391442
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    result = PlatformFactCollector.collect()
    assert isinstance(result, dict), "Expected the result to be a dict"
    assert result['system'] is not None, "Expected the result to contain a system key with a valid value"
    assert result['kernel'] is not None, "Expected the result to contain a kernel key with a valid value"
    assert result['kernel_version'] is not None, "Expected the result to contain a kernel_version key with a valid value"
    assert result['machine'] is not None, "Expected the result to contain a machine key with a valid value"

# Generated at 2022-06-11 05:00:57.072163
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test instantiation
    pfc = PlatformFactCollector()

    # Test all attributes
    assert hasattr(pfc, "name")
    assert hasattr(pfc, "_fact_ids")
    assert hasattr(pfc, "collect")

# Generated at 2022-06-11 05:01:01.284353
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


# Generated at 2022-06-11 05:01:10.528728
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector(dict())
    assert isinstance(p, PlatformFactCollector)
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
# Unit test: test_PlatformFactCollector()
#
# This method is a unit test for testing PlatformFactCollector class constructor
#
# Parameters:
#
#  None
#
# Returns:
#
#  None
#
# Raises:
#
#  None
#
# Notes:
#
#  None

# Generated at 2022-06-11 05:01:12.329032
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None

# Generated at 2022-06-11 05:01:13.817697
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc is not None


# Generated at 2022-06-11 05:01:17.830535
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    result = fact_collector.collect()

    assert 'system' in result
    assert 'kernel' in result
    assert 'kernel_version' in result
    assert 'machine' in result
    assert 'python_version' in result

# Generated at 2022-06-11 05:01:24.532533
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert 'system' in platform_collector._fact_ids
    assert 'kernel' in platform_collector._fact_ids
    assert 'kernel_version' in platform_collector._fact_ids
    assert 'machine' in platform_collector._fact_ids
    assert 'python_version' in platform_collector._fact_ids
    assert 'architecture' in platform_collector._fact_ids
    assert 'machine_id' in platform_collector._fact_ids


# Generated at 2022-06-11 05:02:11.158211
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test for method collect of class PlatformFactCollector
    _expected_facts = {'system': 'Linux', 'kernel': '3.16.0-4-amd64', 'kernel_version': '#1 SMP Debian 3.16.7-ckt25-2 (2016-04-08)', 'machine': 'x86_64', 'python_version': '2.7.9', 'fqdn': 'foo.bar.baz', 'hostname': 'foo', 'nodename': 'foo.bar.baz', 'domain': 'bar.baz', 'userspace_bits': '64', 'architecture': 'x86_64', 'userspace_architecture': 'x86_64', 'machine_id': 'deadbeef'}
    _platform_fact_collector = PlatformFactCollector()
    _mock

# Generated at 2022-06-11 05:02:16.562929
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:02:21.925231
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector_obj = PlatformFactCollector()
    assert platform_collector_obj.name == 'platform'
    assert platform_collector_obj._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-11 05:02:24.644768
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, BaseFactCollector)
    assert sorted(platform_fact_collector.fact_ids) == sorted(['system',
                                                               'kernel',
                                                               'kernel_version',
                                                               'machine',
                                                               'python_version',
                                                               'architecture',
                                                               'machine_id'])
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-11 05:02:25.264764
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:02:29.501621
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert platform_obj.name == 'platform'
    assert platform_obj._fact_ids == set(['system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id'])

# Generated at 2022-06-11 05:02:30.312496
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert hasattr(PlatformFactCollector, 'collect')

# Generated at 2022-06-11 05:02:35.281271
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pf = PlatformFactCollector()
    d = pf.collect()
    print("__test__PlatformFactCollector_collect__: %s" % d)
    assert d['system']
    assert d['kernel']
    assert d['kernel_version']
    assert d['machine']

    assert d['python_version']

    assert d['fqdn']
    assert d['hostname']
    assert d['nodename']

    assert d['domain']

    assert d['userspace_bits']

    assert d['architecture']

    assert d['userspace_architecture']

    assert d['machine_id']

# Generated at 2022-06-11 05:02:37.078634
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert set(PlatformFactCollector()._fact_ids) == PlatformFactCollector._fact_ids

# Generated at 2022-06-11 05:02:38.436579
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fc = PlatformFactCollector()
    print(platform_fc.collect())

# Generated at 2022-06-11 05:03:05.033023
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

    assert obj.collect()

# Generated at 2022-06-11 05:03:14.224700
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Check that facts match to specific system
    """
    mock_module = type('AnsibleModule', (object,), {'get_bin_path': lambda self, path: path})()
    mock_module.run_command = lambda args: (0, '', '')
    platform_facts = PlatformFactCollector().collect(mock_module)

# Generated at 2022-06-11 05:03:17.379974
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    c = PlatformFactCollector()
    assert c.name == 'platform'
    assert c._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:03:20.192111
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set([u'system',
                               u'kernel',
                               u'kernel_version',
                               u'machine',
                               u'python_version',
                               u'architecture',
                               u'machine_id'])

# Generated at 2022-06-11 05:03:27.576632
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert 'system' in collector._fact_ids
    assert 'kernel' in collector._fact_ids
    assert 'kernel_version' in collector._fact_ids
    assert 'machine' in collector._fact_ids
    assert 'python_version' in collector._fact_ids
    assert 'architecture' in collector._fact_ids
    assert 'machine_id' in collector._fact_ids
    assert 'fqdn' in collector._fact_ids
    assert 'hostname' in collector._fact_ids
    assert 'nodename' in collector._fact_ids
    assert 'domain' in collector._fact_ids
    assert 'userspace_bits' in collector._fact_ids


# Generated at 2022-06-11 05:03:36.008439
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert 'system' in platform_facts.keys()
    assert platform_facts['system']
    assert isinstance(platform_facts['system'], str)
    assert 'kernel' in platform_facts.keys()
    assert platform_facts['kernel']
    assert isinstance(platform_facts['kernel'], str)
    assert 'kernel_version' in platform_facts.keys()
    assert platform_facts['kernel_version']
    assert isinstance(platform_facts['kernel_version'], str)
    assert 'machine' in platform_facts.keys()
    assert platform_facts['machine']
    assert isinstance(platform_facts['machine'], str)
    assert 'python_version' in platform_facts.keys()
    assert platform_facts

# Generated at 2022-06-11 05:03:45.471275
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a fake module as we can't rely on an existing module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, binary):
            return binary

        def run_command(self, args):
            return 0, '', ''

    module = FakeModule()
    collected_facts = {}


# Generated at 2022-06-11 05:03:46.084552
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-11 05:03:49.567129
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == "platform"
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:03:51.767622
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fake_platform = FakePlatform()
    collector = PlatformFactCollector(fake_platform)
    platform_facts = collector.collect()
    assert platform_facts == fake_platform.expected_facts


# Generated at 2022-06-11 05:04:39.315481
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class TestModule(object):

        def __init__(self):
            self._arch = 'i386'

        def get_bin_path(self, name, opts=None, required=False):
            if name in ('getconf', 'bootinfo'):
                return name

        def run_command(self, cmd):
            out = ''
            if cmd[0] == 'getconf':
                out = 'MACHINE_ARCHITECTURE\n{0}\n'.format(self._arch)
            elif cmd[0] == 'bootinfo':
                out = '{0}\n'.format(self._arch)
            return (0, out, '')

    # Test with an i386 system
    tm = TestModule()

# Generated at 2022-06-11 05:04:40.289035
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()


# Generated at 2022-06-11 05:04:40.881078
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:04:42.021873
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.collect()

# Generated at 2022-06-11 05:04:49.785980
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a new instance of PlatformFactCollector
    # Check that instance is not null
    factCollectorInstance = PlatformFactCollector()
    assert factCollectorInstance is not None

    # Create a new instance of class ModuleStub with default values
    moduleInstance = ModuleStub()

    # Retrieve facts from PlatformFactCollector instance
    # Check that result is not null
    result = factCollectorInstance.collect(moduleInstance, None)
    assert result is not None

    # Check that result dict contains not null values
    assert len(result) != 0
    assert result['fqdn'] is not None
    assert result['hostname'] is not None
    assert result['machine_id'] is not None
    assert result['architecture'] is not None
    assert result['kernel'] is not None
    assert result['kernel_version'] is not None

# Generated at 2022-06-11 05:04:50.547760
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert 'system' in PlatformFactCollector().collect().keys()

# Generated at 2022-06-11 05:04:51.298622
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-11 05:04:54.644144
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == \
           set(['system', 'kernel', 'kernel_version',
                'machine', 'python_version', 'architecture',
                'machine_id'])



# Generated at 2022-06-11 05:05:02.906686
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    m = platform
    m.system = lambda: 'Linux'
    m.machine = lambda: 'x86_64'
    m.python_version = lambda: '2.7.10'
    m.release = lambda: '4.2.0-35-generic'
    m.version = lambda: '#40~14.04.1-Ubuntu SMP Fri Mar 18 16:37:35 UTC 2016'
    s = socket
    s.getfqdn = lambda: 'testing'

    platform_facts = PlatformFactCollector().collect()

# Generated at 2022-06-11 05:05:06.255772
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    import json
    import module_utils.facts.collector

    p = module_utils.facts.collector.get_collector('platform')
    json.dumps(p.facts)
    assert isinstance(p.facts, dict)


if __name__ == "__main__":
    test_PlatformFactCollector()

# Generated at 2022-06-11 05:06:05.564774
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Test of constructor of class PlatformFactCollector."""
    platform_fact_collector_inst = PlatformFactCollector()
    assert platform_fact_collector_inst.name == "platform"
    assert platform_fact_collector_inst._fact_ids == set(['system',
                                                          'kernel',
                                                          'kernel_version',
                                                          'machine',
                                                          'python_version',
                                                          'architecture',
                                                          'machine_id'])

# Generated at 2022-06-11 05:06:07.174553
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, PlatformFactCollector)


# Generated at 2022-06-11 05:06:10.118840
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import module_utils.facts.collectors.platform

    PlatformFactCollector = module_utils.facts.collectors.platform.PlatformFactCollector
    obj = PlatformFactCollector()
    out = obj.collect()
    assert out is not None
    assert isinstance(out, dict)

# Generated at 2022-06-11 05:06:15.798675
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fc = PlatformFactCollector()
    assert platform_fc.collect(None, None)

    # TODO: make the following non-platform dependent
    assert platform_fc.name == 'platform'
    assert platform_fc._fact_ids == {'system', 'machine', 'architecture',
                                     'kernel_version', 'fqdn', 'domain',
                                     'kernel', 'python_version', 'nodename',
                                     'machine_id', 'userspace_architecture',
                                     'hostname', 'userspace_bits'}

# Generated at 2022-06-11 05:06:17.063361
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'

# Generated at 2022-06-11 05:06:21.388017
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == \
        set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-11 05:06:22.643587
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(None), BaseFactCollector)

# Generated at 2022-06-11 05:06:26.708346
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = get_module(dict())
    pc = PlatformFactCollector()
    fact_list = pc.collect(module=module)
    assert(fact_list['python_version'] == platform.python_version())
    assert(fact_list['system'] == platform.system())

# Generated at 2022-06-11 05:06:32.114300
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    # PlatformFactCollector is a sub-class of BaseFactCollector
    assert isinstance(platform_fact_collector, BaseFactCollector)
    # PlatformFactCollector class uses 'info' category
    assert platform_fact_collector.category == 'info'
    # PlatformFactCollector class name is 'platform'
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-11 05:06:35.413715
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    expected_fact_ids = set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == expected_fact_ids



# Generated at 2022-06-11 05:07:51.330831
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert(x)


# Generated at 2022-06-11 05:07:52.993392
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == PlatformFactCollector.name
    assert PlatformFactCollector()._fact_ids == PlatformFactCollector._fact_ids

# Generated at 2022-06-11 05:07:53.725118
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-11 05:07:57.009892
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_facts = PlatformFactCollector()
    assert platform_facts is not None
    assert platform_facts.name == 'platform'
    assert platform_facts.fact_id == 'platform'
    assert set(platform_facts.fact_ids) == PlatformFactCollector._fact_ids

# Generated at 2022-06-11 05:08:00.820754
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:08:03.247284
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    facts_dict = collector.collect()
    assert facts_dict is not None
    assert len(facts_dict) > 0
    assert facts_dict['system'] == 'Linux'
    assert facts_dict['architecture'] == 'x86_64'

# Generated at 2022-06-11 05:08:10.146618
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.facts import ModuleFacts

    module = ModuleFacts()
    results = PlatformFactCollector()
    results_dict = results.collect(module=module)

    assert results_dict
    assert results_dict['system']
    assert results_dict['machine']
    assert results_dict['architecture']
    assert results_dict['python_version']
    assert results_dict['kernel']
    assert results_dict['kernel_version']
    assert results_dict['nodename']
    assert results_dict['fqdn']
    assert results_dict['hostname']
    assert results_dict['machine_id']

# Generated at 2022-06-11 05:08:11.597336
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    hostvars = {}
    results = PlatformFactCollector().collect(hostvars)
    assert results != {}

# Generated at 2022-06-11 05:08:12.773225
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'

# Generated at 2022-06-11 05:08:17.227929
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat_fact_collector = PlatformFactCollector()
    assert plat_fact_collector.name == 'platform'
    assert plat_fact_collector._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'])