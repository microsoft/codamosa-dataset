

# Generated at 2022-06-11 05:00:43.160406
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact = PlatformFactCollector()
    assert platform_fact.name == 'platform'
    assert platform_fact._fact_ids == set(['system', 'kernel', 'kernel_version',
                                           'machine', 'python_version', 'architecture',
                                           'machine_id'])

# Generated at 2022-06-11 05:00:50.208567
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'architecture',
                             'fqdn',
                             'hostname',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'machine_id',
                             'nodename',
                             'system',
                             'domain',
                             'python_version',
                             'userspace_bits',
                             'userspace_architecture'}


# Generated at 2022-06-11 05:01:00.659408
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ..utils import AnsibleExitJson, AnsibleFailJson
    from ..utils import Module, set_module_args
    module = Module()
    set_module_args({'gather_subset': '!all,min'})

    # Mock the module args
    module.params = {
        'gather_subset': ['!all', 'min'],
    }

    # Mock the Ansible module
    ansible_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', required=False),
            filter=dict(type='list', required=False),
            exclude=dict(type='list', required=False)
        ),
        supports_check_mode=False
    )

    # Get the platform facts

# Generated at 2022-06-11 05:01:03.716782
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == "platform"
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-11 05:01:08.933782
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:01:19.937994
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform as py_platform
    from ansible.module_utils.facts.collector import BaseFactCollector

    class _Platform(object):
        def __init__(self, machine, node, python_version, release,
                     system='OtterOS', version='0.0.1'):
            self.machine = machine
            self.node = node
            self.python_version = python_version
            self.release = release
            self.system = system
            self.version = version

        def architeture(self):
            return ('64bit', 'ELF')

        def uname(self):
            return (self.system,
                    'puddlejumper',
                    self.release,
                    '#1 SMP Otter 20, 2017',
                    self.machine,
                    'sparky')


# Generated at 2022-06-11 05:01:26.723970
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['architecture'] == platform.machine()
    hostname = platform.node().split('.')[0]
    assert platform_facts['hostname'] == hostname
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['fqdn'] == socket.getfqdn()

# Generated at 2022-06-11 05:01:31.928813
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:01:43.070241
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collectors = [PlatformCollector()]
    result = PlatformCollector().collect(module=None, collected_facts=None)
    assert len(result) == 7
    assert result['system'] == 'Linux'
    assert result['kernel'] == '4.4.0-62-generic'
    assert result['kernel_version'] == '#83-Ubuntu SMP Wed Jan 18 14:10:15 UTC 2017'
    assert result['machine'] == 'x86_64'
    assert result['python_version'] == '2.7.12'
    assert result['fqdn'] == 'localhost'
    assert result['hostname'] == 'localhost'
    assert result['nodename'] == 'localhost'
    assert result['domain'] == 'localhost'
    assert result['userspace_bits'] == '64'

# Generated at 2022-06-11 05:01:50.562617
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

    # Test Linux platform
    platform_facts = platform_fact_collector.collect(None, {'system': 'Linux',
                                                            'machine': 'x86_64'})
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel'] != ''
    assert platform_facts['kernel_version'] != ''
    assert platform_facts['architecture'] == 'x86_64'
    assert platform_facts['machine'] == 'x86_64'
    assert platform_facts['python_version'] != ''
    assert platform_facts['fqdn']
    assert platform_facts['hostname']
    assert platform_facts['nodename']
    assert platform_facts['domain']

    # Test Solaris platform with i86pc architecture
    platform_

# Generated at 2022-06-11 05:02:36.662201
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat_fact_collector = PlatformFactCollector()

    assert plat_fact_collector.name == "platform"
    assert plat_fact_collector._fact_ids == {"system",
                     "kernel",
                     "kernel_version",
                     "machine",
                     "python_version",
                     "architecture",
                     "machine_id"}

# Generated at 2022-06-11 05:02:38.015551
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    assert collector.collect()

# Generated at 2022-06-11 05:02:48.691906
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import os
    import platform

    my_platform = platform.system()
    platform_collector = PlatformFactCollector()

    test_platform_facts = platform_collector.collect(None, None)
    # Check for expected values for proper type
    assert isinstance(test_platform_facts['kernel'], str)
    assert isinstance(test_platform_facts['kernel_version'], str)
    assert isinstance(test_platform_facts['machine'], str)
    assert isinstance(test_platform_facts['architecture'], str)
    assert isinstance(test_platform_facts['userspace_bits'], str)
    if my_platform == 'Linux':
        assert isinstance(test_platform_facts['machine_id'], str)

    # Check for expected values for os
    test_system = test_platform_facts

# Generated at 2022-06-11 05:02:57.428848
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
  collector = PlatformFactCollector()

  result = collector.collect()
  assert result['system'] == platform.system()
  assert result['kernel'] == platform.release()
  assert result['kernel_version'] == platform.version()
  assert result['machine'] == platform.machine()
  assert result['python_version'] == platform.python_version()
  assert result['fqdn'] == socket.getfqdn()
  assert result['hostname'] == platform.node().split('.')[0]
  assert result['nodename'] == platform.node()
  assert result['domain'] == '.'.join(platform.node().split('.')[1:])

  arch_bits = platform.architecture()[0]
  assert result['userspace_bits'] == arch_bits.replace('bit', '')


# Generated at 2022-06-11 05:03:07.939462
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.utils import FactsFiles
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import get_collector_classes

    # set up basic class references
    mf = ModuleFacts(module_name='TestModule')
    mf._module = type('AnsibleModule', (object,), {})
    mf._module.params = {} # type: AnsibleModule
    mf._module.get_bin_path = lambda x: x
    mf._module.run_command = lambda x: (0, '', '')
    mf._facts_files = FactsFiles(mf._module, '/tmp')

    # set up collector classes
    Collector._fact_classes

# Generated at 2022-06-11 05:03:13.337134
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Construct an instance of PlatformFactCollector
    lfc = PlatformFactCollector()

    # Check if the instance is constructed properly
    assert isinstance(lfc, PlatformFactCollector)
    assert lfc.name == 'platform'
    assert lfc._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-11 05:03:20.419441
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-11 05:03:24.049773
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert isinstance(x._fact_ids, set)
    assert 'kernel_version' in x._fact_ids
    assert x.collect()['system'] == platform.system()
    assert x.collect()['kernel'] == platform.release()
    assert x.collect()['architecture'] == platform.machine()

# Generated at 2022-06-11 05:03:28.287176
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert len(facts) >= 0
    assert "system" in facts
    assert "kernel" in facts
    assert "kernel_version" in facts
    assert "machine" in facts
    assert "python_version" in facts
    assert "architecture" in facts


# Generated at 2022-06-11 05:03:32.370143
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    Test PlatformFactCollector constructor
    """
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version',
                             'machine', 'python_version', 'architecture',
                             'machine_id'}

# Generated at 2022-06-11 05:04:58.223011
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-11 05:05:01.168762
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}, platform._fact_ids

# Generated at 2022-06-11 05:05:02.906111
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Test construction of class PlatformFactCollector.
    """
    o = PlatformFactCollector()
    assert o.name == 'platform'

# Generated at 2022-06-11 05:05:06.851339
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collection = PlatformFactCollector()
    assert fact_collection.name == 'platform'
    assert fact_collection._fact_ids == set(['system',
                                             'kernel',
                                             'kernel_version',
                                             'machine',
                                             'python_version',
                                             'architecture',
                                             'machine_id'])


# Generated at 2022-06-11 05:05:08.729299
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Instantiate a Platform Fact collector and make sure it is of the correct type
    assert isinstance(PlatformFactCollector(), BaseFactCollector)

# Generated at 2022-06-11 05:05:16.710474
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Prepare test data
    module_mock = MockModule()
    openbsd_platform_uname = ['OpenBSD', 'hostname', '4.4', '#4',
                            'Wed Oct 15 17:30:01 PDT 2014', 'i386', 'i386']
    solaris_platform_uname = ['SunOS', 'hostname', '5.10', 'Generic_144488-04',
                            'i86pc', 'i386', 'i86pc']
    linux_platform_uname = ['Linux', 'hostname', '4.4.0-47-generic', '#68-Ubuntu',
                            'SMP Wed Oct 26 19:39:52 UTC 2016', 'x86_64', 'x86_64',
                            'x86_64']

# Generated at 2022-06-11 05:05:21.468333
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()

    # Call collect method
    failed_facts_check, facts = platform_collector.collect()

    assert failed_facts_check == []

    assert 'system' in facts
    # Don't assert on Python because it's an implementation detail
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    # Don't assert on machine because it's an implementation detail
    assert 'python_version' in facts
    assert 'architecture' in facts

# Generated at 2022-06-11 05:05:25.027593
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system', 'kernel', 'kernel_version',
                                'machine', 'python_version', 'architecture', 'machine_id'])
    assert pf.collect_fn

# Generated at 2022-06-11 05:05:27.780926
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = _MockModule()
    platform_fact_collector = PlatformFactCollector()
    actual_facts = platform_fact_collector.collect(module=mock_module, collected_facts=_MockFacts())
    assert actual_facts != None



# Generated at 2022-06-11 05:05:34.300466
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = platform_fact_collector.collect()
    assert platform_facts["system"] == platform.system()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["python_version"] == platform.python_version()
    assert platform_facts["fqdn"] == socket.getfqdn()
    assert platform_facts["hostname"] == platform.node().split('.')[0]
    assert platform_facts["nodename"] == platform.node()
    assert platform_facts["domain"] == '.'.join(platform_facts["fqdn"].split('.')[1:])

# Generated at 2022-06-11 05:08:46.429173
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, opts=None, required=False, chk_fn=None):
            if executable == 'getconf':
                return '/usr/bin/getconf'
            elif executable == 'bootinfo':
                return '/usr/sbin/bootinfo'
            else:
                raise Exception

        def run_command(self, command):
            rc = 0
            if command[0] == '/usr/bin/getconf':
                machine_architecture = {'i686': 'i686'}
                try:
                    data = [ machine_architecture[command[1]] ]
                except:
                    data = []
                    rc = 1

# Generated at 2022-06-11 05:08:53.510370
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # import statements are only needed for unit tests, it's bad style to import elsewhere
    import sys
    import platform
    import socket

    class FakeAnsibleModule:

        def get_bin_path(self, _):
            return "/bin/getconf"

        def  run_command(self, args, check_rc=False):
            return True, "", None

    class FakeAnsibleModule2:

        def get_bin_path(self, _):
            return None

        def  run_command(self, args, check_rc=False):
            return True, "", None

    # Mock platform.machine() and platform.system() to be able to set the expected behaviour
    old_machine = platform.machine
    platform.machine = lambda: "x86_64"

    old_system = platform.system

# Generated at 2022-06-11 05:08:55.051134
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # We just test the basic functionality by constructing the class and
    # calling the collect method. We don't assert the result
    PlatformFactCollector({}).collect()

# Generated at 2022-06-11 05:09:04.312134
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Module
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ..collector.base import BaseFactCollector
    facts = PlatformFactCollector().collect(None, {})
    assert isinstance(facts, dict)
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['fqdn'] == socket.getfqdn()
    assert facts['hostname'] == platform.node().split('.')[0]
    assert facts['nodename'] == platform.node()
    assert 'domain' in facts

# Generated at 2022-06-11 05:09:12.643840
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test return value when platform is Linux
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils.get_file_content import get_file_content_mock
    import platform
    import socket
    import re
    platform_old = platform.system
    socket_old = socket.getfqdn
    re_old = re.search
    platform_system = "Linux"
    platform_release = "2.6.32-754.3.5.el6.x86_64"
    platform_version = "#1 SMP Mon Mar 18 11:10:41 EDT 2019"
    platform_machine = "x86_64"
    platform_python_version = "2.7.5"
    os_distro = "centos"
    os_

# Generated at 2022-06-11 05:09:16.241313
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector(None)
    assert x.name == 'platform'
    assert sorted(x.fact_ids()) == ['architecture', 'fqdn', 'hostname', 'kernel', 'kernel_version', 'machine', 'machine_id', 'nodename', 'python_version', 'system', 'userspace_architecture', 'userspace_bits']

# Generated at 2022-06-11 05:09:18.020733
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'architecture', 'machine_id'])



# Generated at 2022-06-11 05:09:21.604386
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel_version'] == '3.13.0-57-generic'
    assert platform_facts['architecture'] == 'x86_64'

# Generated at 2022-06-11 05:09:26.544365
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    fact_subset = ['architecture', 'fqdn', 'system', 'kernel']
    fact_parser = FactCollector({}, fact_subset)
    pfc = PlatformFactCollector(fact_subset, fact_parser)
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['architecture', 'fqdn', 'system', 'kernel'])

# Generated at 2022-06-11 05:09:33.250475
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test method collect of PlatformFactCollector.
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    #
    # Monkey patch for BaseFactCollector.get_module_path
    #
    def get_module_path(self):
        return "ansible.module_utils.facts.collectors.platform"

    BaseFactCollector.get_module_path = get_module_path
    #
    # Monkey patch for BaseFactCollector.get_module_path
    #
    class MockModule:
        def __init__(self):
            self.params = {
                "gather_subset": [
                    "all"
                ],
                "filter": "*"
            }

