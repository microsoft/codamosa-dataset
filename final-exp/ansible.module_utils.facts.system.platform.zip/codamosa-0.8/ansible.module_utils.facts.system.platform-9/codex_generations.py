

# Generated at 2022-06-11 05:00:34.883623
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:00:35.473049
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:00:39.086081
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector.collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

# Generated at 2022-06-11 05:00:41.421123
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert isinstance(platform_facts, dict)

# Generated at 2022-06-11 05:00:46.259951
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p is not None
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-11 05:00:51.776675
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.utils import AnsibleCollector

    ansible = AnsibleCollector()
    PlatformFactCollector.populate(ansible)
    assert BaseFactCollector.collectors['platform'] is PlatformFactCollector

# Generated at 2022-06-11 05:00:56.109844
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:00:57.837780
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    host_info = PlatformFactCollector()
    result  = host_info.collect()
    assert result is not None

# Generated at 2022-06-11 05:01:01.883211
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    platform_facts = PlatformFactCollector().collect(module)

    assert platform_facts['system'] == 'Linux'
    assert platform_facts['architecture'] == 'x86_64'
    assert platform_facts['python_version'] == '2.7.5'


# Generated at 2022-06-11 05:01:05.724471
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-11 05:01:26.509647
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert 'system' in x._fact_ids
    assert 'kernel' in x._fact_ids
    assert 'kernel_version' in x._fact_ids
    assert 'machine' in x._fact_ids
    assert 'python_version' in x._fact_ids
    assert 'architecture' in x._fact_ids
    assert 'machine_id' in x._fact_ids


# Generated at 2022-06-11 05:01:30.197614
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector()
    assert result.name == 'platform'
    assert result._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-11 05:01:41.044411
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()
    platform_facts['python_version'] = platform.python_version()
    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()
    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()[0]
    platform_facts['userspace_bits'] = arch_bits.replace('bit', '')
   

# Generated at 2022-06-11 05:01:49.553928
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    def call_function(*args, **kwargs):
        return platform.system(), platform.release(), platform.version(), platform.machine(), \
               platform.python_version(), socket.getfqdn(), platform.node().split('.')[0], platform.node(), \
               '.'.join(socket.getfqdn().split('.')[1:]), platform.architecture()[0], \
               get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")

    platform_facts = PlatformFactCollector()

    result = platform_facts.collect(call_function=call_function)

    # Linux
    assert result["system"] == "Linux"
    assert result["kernel"] == "4.4.0-47-generic"
    assert result["kernel_version"]

# Generated at 2022-06-11 05:01:58.176511
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import re
    platform_facts = {}
    # platform.system() can be Linux, Darwin, Java, or Windows
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()
    platform_facts['python_version'] = platform.python_version()
    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()
    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])
    arch_bits = platform.architect

# Generated at 2022-06-11 05:02:02.477593
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()

    # Make sure the setup of the BaseFactCollector was successful
    _fact_ids = set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])
    assert pfc.name == 'platform'
    assert pfc._fact_ids == _fact_ids

# Generated at 2022-06-11 05:02:03.353802
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-11 05:02:12.808985
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, args):
            return None, None, None

        def get_bin_path(self, arg):
            return "sbin/bootinfo"

    class MockSystem(object):
        def system(self):
            return "AIX"

        def node(self):
            return "aix_host.example.net"

        def release(self):
            return "7100-02-03-1415-ABCDEF"

        def version(self):
            return "7100-02-03-1415-ABCDEF"

        def machine(self):
            return "powerpc"

        def python_version(self):
            return "2.7.10"

    import sys
    import platform as mock_

# Generated at 2022-06-11 05:02:15.625228
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # PlatformFactCollector.collect should return a dictionary
    # Don't test all fields, just one to check doesn't return empty
    assert 'fqdn' in PlatformFactCollector().collect()

# Generated at 2022-06-11 05:02:25.849929
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import os
    import platform
    import socket

    machine_id_paths = ["/var/lib/dbus/machine-id", "/etc/machine-id"]
    machine_id = None
    for path in machine_id_paths:
        if os.path.isfile(path):
            with open(path, 'r') as m_id:
                machine_id = m_id.readline().strip()
                break

    # create a class object of type Collector
    collector = Collector()

    # create a class object of type PlatformFactCollector
    fact_collector = PlatformFactCollector()
    fact_collector.collect(module=collector)

    # create a dictionary of expected results
    platform_facts = {}
    platform_facts['system']

# Generated at 2022-06-11 05:03:18.524796
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'

# Generated at 2022-06-11 05:03:19.698986
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector()
    assert result.name == 'platform'
    assert dict(result.collect()) == dict()

# Generated at 2022-06-11 05:03:23.023121
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:03:24.362151
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'system' in x._fact_ids

# Generated at 2022-06-11 05:03:28.941642
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Creating a fake module object containing the param 'name'
    module = type('module', (), {
        'get_bin_path': lambda name, opts=None: '/bin/' + name
    })
    pc = PlatformFactCollector()
    platform_facts = pc.collect(module=module)
    # We know that on our side, the architecture should be x86_64
    assert platform_facts['architecture'] == 'x86_64'

# Generated at 2022-06-11 05:03:33.037360
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == {'system',
                                        'kernel',
                                        'kernel_version',
                                        'machine',
                                        'python_version',
                                        'architecture',
                                        'machine_id'}

# Generated at 2022-06-11 05:03:35.364542
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    keys = ('system', 'kernel', 'kernel_version', 'machine', 'architecture' )
    for key in keys:
        assert key in platform_facts

# Generated at 2022-06-11 05:03:40.332670
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])
    assert fact_collector._platform == 'all'

# Generated at 2022-06-11 05:03:45.376902
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert sorted(pfc._fact_ids) == sorted(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-11 05:03:48.655899
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p._fact_ids.issubset(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-11 05:06:47.991959
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-11 05:06:48.577509
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-11 05:06:52.127953
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-11 05:06:55.291243
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-11 05:06:58.672280
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:07:00.319468
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        PlatformFactCollector()
    except Exception:
        assert False



# Generated at 2022-06-11 05:07:08.159354
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['architecture'] == platform.machine()
    if platform_facts['machine'] == 'x86_64':
        assert platform_facts['architecture'] == 'x86_64'
    elif solaris_i86_re.search(platform_facts['machine']):
        assert platform_facts['architecture'] == 'i386'
    assert 'system_vendor' not in platform_facts

# Generated at 2022-06-11 05:07:15.938674
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2

    # instantiate the module

# Generated at 2022-06-11 05:07:20.373295
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids


# Generated at 2022-06-11 05:07:24.122075
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = PlatformFactCollector()
    fact = module.collect()
    assert 'system' in fact
    assert 'kernel' in fact
    assert 'kernel_version' in fact
    assert 'machine' in fact
    assert 'architecture' in fact
    assert 'python_version' in fact
