

# Generated at 2022-06-11 05:00:39.164895
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    testPlatformFactCollector = PlatformFactCollector()
    assert testPlatformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])



# Generated at 2022-06-11 05:00:43.747329
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert sorted(pfc._fact_ids) == sorted(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-11 05:00:45.920208
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''Unit test for constructor of class PlatformFactCollector'''
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'

# Generated at 2022-06-11 05:00:56.682001
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MagicMock()
    def get_bin_path(path):
        if 'bootinfo' == path:
            return '/usr/bin/bootinfo'
        elif 'getconf' == path:
            return '/usr/bin/getconf'
        return None
    module.get_bin_path = MagicMock(side_effect=get_bin_path)
    module.run_command.return_value = (0, '{}\n'.format(dict(
        bootinfo=['chrp'],
        getconf=['rs6000']
    )[module.get_bin_path.call_args[0][0].split('/')[-1]]), '')
    platform_facts = PlatformFactCollector().collect(module=module)

# Generated at 2022-06-11 05:01:04.536636
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector.collect()['system'] == platform.system()
    assert collector.collect()['kernel'] == platform.release()
    assert collector.collect()['kernel_version'] == platform.version()
    assert collector.collect()['machine'] == platform.machine()
    assert collector.collect()['python_version'] == platform.python_version()
    assert collector.collect()['hostname'] == platform.node().split('.')[0]
    assert collector.collect()['fqdn'] == socket.getfqdn()
    assert collector.collect()['domain'] == '.'.join(socket.getfqdn().split('.')[1:])
    assert collector.collect()['nodename'] == platform.node()

# Generated at 2022-06-11 05:01:14.629626
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.collect()['system'] == platform.system()
    assert platform_facts.collect()['kernel'] == platform.release()
    assert platform_facts.collect()['kernel_version'] == platform.version()
    assert platform_facts.collect()['machine'] == platform.machine()
    assert platform_facts.collect()['python_version'] == platform.python_version()
    assert platform_facts.collect()['fqdn'] == socket.getfqdn()
    assert platform_facts.collect()['hostname'] == platform.node().split('.')[0]
    assert platform_facts.collect()['nodename'] == platform.node()

# Generated at 2022-06-11 05:01:23.453976
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create an instance of PlatformFactCollector
    p = PlatformFactCollector()

    # Assert that the instance is an instance of class PlatformFactCollector
    assert isinstance(p, PlatformFactCollector)

    # Assert the name of the instance is platform
    assert p.name == 'platform'

    # Assert that there are the correct number of ids set
    assert len(p._fact_ids) == 9

    # Assert that none of the ids overlap
    assert len(p._fact_ids & BaseFactCollector._fact_ids) == 0

    # Assert that none of the ids overlap
    assert len(p._fact_ids & PlatformFactCollector._fact_ids) == 0

# Generated at 2022-06-11 05:01:27.318020
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector().fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id'])


# Generated at 2022-06-11 05:01:31.310285
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Pass
    p = PlatformFactCollector()
    assert p.name == 'platform'

    # Fail
    try:
        p = PlatformFactCollector()
        p.name = 'something'
        assert p.name == 'platform'
    except AttributeError:
        pass



# Generated at 2022-06-11 05:01:35.246890
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:02:52.138005
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fc = PlatformFactCollector()
    assert fc.name == 'platform', 'Wrong name of PlatformFactCollector'
    assert fc._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])

# Generated at 2022-06-11 05:02:58.852530
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pltf_fact_collector = PlatformFactCollector()
    assert pltf_fact_collector.name == 'platform'

# Unit tests for facts collected by platform module
tests = [
    dict(platform_facts = dict(system = 'Linux'),
         expected = dict(system = 'Linux',
                         kernel = 'Linux',
                         kernel_version = 'Linux',
                         machine = 'Linux',
                         architecture = 'Linux',
                         python_version = 'Linux',
                         userspace_bits = 'Linux',
                         userspace_architecture = 'Linux',
                         fqdn = 'Linux',
                         nodename = 'Linux',
                         domain = 'Linux',
                         hostname = 'Linux'))
]


# Generated at 2022-06-11 05:03:03.222350
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:03:13.142959
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    domain_part = ".".join(platform_facts['fqdn'].split('.')[1:])
    assert platform_facts['domain'] == domain_

# Generated at 2022-06-11 05:03:17.072683
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector.collect()

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-11 05:03:19.809821
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()

    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:03:22.595196
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-11 05:03:23.663999
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'

# Generated at 2022-06-11 05:03:25.909457
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts
    for fact_name, fact_value in platform_facts.items():
        assert fact_name in PlatformFactCollector._fact_ids

# Generated at 2022-06-11 05:03:27.726262
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # The constructor of class PlatformFactCollector should return a instance of this class
    assert isinstance(PlatformFactCollector(), PlatformFactCollector)

# Generated at 2022-06-11 05:06:31.106301
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'

# Generated at 2022-06-11 05:06:35.416752
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:06:39.745797
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:06:47.918604
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup PlatformFactCollector instance
    instance = PlatformFactCollector()

    # Setup mock module
    module = type('MockModule', (object,), {})()
    setattr(module, 'run_command', lambda x: [0, '', ''])
    setattr(module, 'get_bin_path', lambda x: None)

    # Setup mock facts
    collected_facts = {}

    # run collect on PlatformFactCollector instance
    result = instance.collect(module=module, collected_facts=collected_facts)

    # assert that dictionary keys are as expected

# Generated at 2022-06-11 05:06:51.281483
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts

# Generated at 2022-06-11 05:06:54.705630
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-11 05:07:02.903195
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    ## Declaring mock class for testing ansible.module_utils.facts.utils.get_file_content
    class MockGetFileContent(object):
        def __init__(self, file_name):
            self.file_name = file_name

        def splitlines(self):
            if self.file_name == "/var/lib/dbus/machine-id":
                return ["mocked_machine_id"]
            if self.file_name == "/etc/machine-id":
                return ["another_mocked_machine_id"]

    ## Declaring mock class for testing ansible.module_utils.facts.collector.platform

# Generated at 2022-06-11 05:07:06.243951
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    results = PlatformFactCollector().collect()

    assert 'system' in results
    assert 'kernel' in results
    assert 'kernel_version' in results
    assert 'machine' in results
    assert 'python_version' in results
    assert 'architecture' in results
    assert 'machine_id' in results

# Generated at 2022-06-11 05:07:09.641932
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:07:13.437800
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector is not None
    assert collector.name == 'platform'
    assert collector._fact_ids == {'system',
                                   'kernel',
                                   'kernel_version',
                                   'machine',
                                   'python_version',
                                   'architecture',
                                   'machine_id'}
