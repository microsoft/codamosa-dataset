

# Generated at 2022-06-11 05:00:40.961899
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert set(['system',
                'kernel',
                'kernel_version',
                'machine',
                'python_version',
                'architecture']) == platform_fact_collector._fact_ids

# Generated at 2022-06-11 05:00:45.288308
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector.collect()

    # The platform module of Python provides a bunch of useful
    # information. We can check that the dictionary we get from
    # the collect() method is equal to the one we get from the
    # platform module.
    assert platform_facts == dict(platform.__dict__, **platform_facts)

# Generated at 2022-06-11 05:00:46.792794
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector()
    assert PlatformFactCollector().name == 'platform'

# Generated at 2022-06-11 05:00:52.376145
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    facts_collector = PlatformFactCollector()
    assert facts_collector.name == 'platform'
    assert facts_collector._fact_ids == set(['system',
                                             'kernel',
                                             'kernel_version',
                                             'machine',
                                             'python_version',
                                             'architecture',
                                             'machine_id'])


# Generated at 2022-06-11 05:01:02.173255
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    ansible_facts = dict()
    platform_facts = dict()
    ansible_facts['ansible_system'] = 'Linux'
    ansible_facts['ansible_kernel'] = '2.6.32-696.20.1.el6.x86_64'
    ansible_facts['ansible_machine'] = 'x86_64'
    ansible_facts['ansible_python_version'] = '2.7.5'
    ansible_facts['ansible_architecture'] = 'Linux-3.10.0-693.21.1.el7.x86_64-x86_64-with-redhat-6.10-Santiago'

# Generated at 2022-06-11 05:01:03.835667
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-11 05:01:12.481346
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MockModule()
    fact_collector = PlatformFactCollector(module=module)
    ansible_facts = fact_collector.collect()

    assert ansible_facts['system'] == platform.system()
    assert ansible_facts['kernel'] == platform.release()
    assert ansible_facts['kernel_version'] == platform.version()
    assert ansible_facts['machine'] == platform.machine()
    assert ansible_facts['python_version'] == platform.python_version()

#####################
# Mock helper class #
#####################


# Generated at 2022-06-11 05:01:13.139573
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert 1 == 1

# Generated at 2022-06-11 05:01:16.853998
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    result = platform_collector.collect()
    
    assert result is not None
    assert result['system'] is not None
    assert result['kernel'] is not None
    assert result['kernel_version'] is not None
    assert result['machine'] is not None
    assert result['python_version'] is not None
    assert result['architecture'] is not None
    assert result['userspace_bits'] is not None
    assert result['fqdn'] is not None
    assert result['hostname'] is not None
    assert result['nodename'] is not None
    assert result['domain'] is not None


# Generated at 2022-06-11 05:01:19.137737
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p.collect()['system'] == 'Linux'

# Generated at 2022-06-11 05:01:41.629726
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert 'machine_id' in obj._fact_ids
    assert 'kernel' in obj.collect()

# Generated at 2022-06-11 05:01:45.569761
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    collected_facts = platform_fact_collector.collect()
    assert isinstance(collected_facts['machine'], str)
    assert isinstance(collected_facts['machine_id'], str) or collected_facts['machine_id'] is None

# Generated at 2022-06-11 05:01:52.059763
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector


# Generated at 2022-06-11 05:02:00.497566
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector


# Generated at 2022-06-11 05:02:04.721240
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Return a collection of platform facts"""
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts

# Generated at 2022-06-11 05:02:14.529363
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import get_collector_instance
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector

    # Test the constructor of class PlatformFactCollector
    obj = PlatformFactCollector()

    # Get platform facts
    #obj.collect()

    # Test get_name() method
    assert obj.get_name() == "platform", "get_name() method of PlatformFactCollector class should return platform"

    # Test get_fact_ids() method

# Generated at 2022-06-11 05:02:24.770431
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible._compat import StringIO
    from ansible.module_utils.facts.utils import FactCollector
    from ansible.module_utils.facts import _common_utils
    # create a stub module to make it think we are running inside a task
    fake_module = type('fake_module', (object, ), {
        'exit_json': lambda self, **kwargs: None,
        'run_command': lambda self, args, check_rc=False: (0, 'x86_64\n', ''),
        'get_bin_path': lambda self, arg: arg,
        'fail_json': lambda self, **kwargs: None,
        '_ansible_debug': True,
        'log': lambda self, msg: None,
    })()
    # call the collect method and assert about result

# Generated at 2022-06-11 05:02:30.649286
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platformfactcollector = PlatformFactCollector()

    assert platformfactcollector.name == 'platform', \
        'Test Failed: PlatformFactCollector did not take on the right name'
    assert platformfactcollector._fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id']), \
        'Test Failed: PlatformFactCollector did not take on the right fact ids'

# Generated at 2022-06-11 05:02:33.749350
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:02:43.280719
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleData, get_collectors_per_platform

    collected_facts = PlatformFactCollector().collect(ModuleData(
        "fake_module",
        "ANSIBLE_COLLECTORS_ENABLED"
    ), {})

    assert collected_facts["machine_id"] == "asdf1234"
    assert collected_facts["domain"] == "example.com"
    assert collected_facts["nodename"] == "host.example.com"
    assert collected_facts["hostname"] == "host"
    assert collected_facts["fqdn"] == "host.example.com"
    assert collected_facts["system"] == "Linux"
    assert collected_facts["kernel_version"] == "3.10.0-957.el7.x86_64"

# Generated at 2022-06-11 05:03:28.360514
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.collect()

# Generated at 2022-06-11 05:03:32.168698
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id', 'userspace_architecture'])



# Generated at 2022-06-11 05:03:35.440360
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    f = PlatformFactCollector()
    assert f.name == 'platform'
    assert f._fact_ids == {'system',
                           'kernel',
                           'kernel_version',
                           'machine',
                           'python_version',
                           'architecture',
                           'machine_id'}

# Generated at 2022-06-11 05:03:39.767961
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == {'system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'}

# Generated at 2022-06-11 05:03:43.575592
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:03:47.727579
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-11 05:03:51.537370
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()

    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])


# Generated at 2022-06-11 05:03:53.097864
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector()
    assert platform_facts.collect()['python_version'] == platform.python_version()

# Generated at 2022-06-11 05:03:57.863361
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-11 05:03:59.585363
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'



# Generated at 2022-06-11 05:06:51.249339
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def run_collect(data):
        # Mocks for module and platform.system
        class Module():
            def __init__(self, platform_system):
                self._platform_system = platform_system

            def get_bin_path(self, binary_name):
                return '%s not found' % binary_name

            def run_command(self, command):
                if self._platform_system == "AIX":
                    if command[0] == "getconf":
                        return (0, "32", "")
                    elif command[0] == "bootinfo":
                        return (0, "PowerPC_POWER7", "")
                else:
                    raise Exception("Unexpected command")

        # Mocks for get_file_content

# Generated at 2022-06-11 05:06:52.390690
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector

# Generated at 2022-06-11 05:06:55.745274
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system', 'kernel','kernel_version','machine','python_version','architecture','machine_id'}

# Generated at 2022-06-11 05:07:00.201123
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:07:03.475609
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.name == "platform"
    assert platform._fact_ids == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])

# Generated at 2022-06-11 05:07:05.043247
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == "platform"

# Generated at 2022-06-11 05:07:08.445281
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-11 05:07:16.226603
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Arrange
    module = AnsibleModuleMock()
    platform_facts = PlatformFactCollector(module)

    # Act
    result = platform_facts.collect()

    # Assert
    assert result["system"] == platform.system()
    assert result["kernel"] == platform.release()
    assert result["kernel_version"] == platform.version()
    assert result["machine"] == platform.machine()
    assert result["python_version"] == platform.python_version()
    assert result["fqdn"] == socket.getfqdn()
    assert result["hostname"] == platform.node().split(".")[0]
    assert result["nodename"] == platform.node()
    assert result["domain"] == ".".join(result["fqdn"].split(".")[1:])
    arch_bits = platform.architect

# Generated at 2022-06-11 05:07:20.959835
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert x.name == 'platform'
    assert x.collect()

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-11 05:07:24.429205
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version',
                                 'machine', 'python_version', 'architecture',
                                 'machine_id'])

