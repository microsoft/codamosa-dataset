

# Generated at 2022-06-11 05:00:29.817716
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = 'ansible.module_utils.facts.system.platform.PlatformFactCollector'
    PlatformFactCollector()
    assert pf == 'ansible.module_utils.facts.system.platform.PlatformFactCollector'

# Generated at 2022-06-11 05:00:34.392958
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()

    expected_result = 'platform'
    assert(p.name == expected_result)

    expected_result = set(['system',
                           'kernel',
                           'kernel_version',
                           'machine',
                           'python_version',
                           'architecture',
                           'machine_id'])
    assert(p._fact_ids == expected_result)

# Generated at 2022-06-11 05:00:43.346978
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = DummyModule()
    fact_collector = PlatformFactCollector(module)

    content_architecture = 'x86_64'
    content_machine_id = '737418c2-efeb-43df-9648-f7d255144604'
    content_node = 'ubuntu-xenial'
    content_userspace_bits = '64'
    content_userspace_architecture = 'x86_64'
    content_kernel = '4.4.0-45-generic'
    content_kernel_version = '#66-Ubuntu SMP Wed Oct 19 14:12:37 UTC 2016'
    content_machine = 'x86_64'
    content_python_version = '2.7.12'
    content_system = 'Linux'

    def getfqdn():
        return

# Generated at 2022-06-11 05:00:48.479045
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert isinstance(pf, PlatformFactCollector)
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system',
    'kernel',
    'kernel_version',
    'machine',
    'python_version',
    'architecture',
    'machine_id'])

# Generated at 2022-06-11 05:00:53.086655
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    result = set(["system", "kernel", "kernel_version", "machine",
                  "python_version", "architecture", "machine_id", "nodename",
                  "hostname", "domain", "userspace_bits", "userspace_architecture", "fqdn"])
    assert set(PlatformFactCollector().collect().keys()) == result

# Generated at 2022-06-11 05:00:56.864519
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert set(('system', 'kernel', 'kernel_version', 'machine',
                'python_version', 'architecture', 'machine_id')) == \
        platform_obj._fact_ids

# Generated at 2022-06-11 05:01:04.247002
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    # Setting mock values for the ansible_facts
    ansible_facts = {
        'machine_id' : '123456789abcd'
    }

    # Instantiating an object for PlatformFactCollector
    pfc = PlatformFactCollector()

    # Adding the object pfc to ansible_collector
    ansible_collector.add_collector(pfc)

    # Calling the collect method of PlatformFactCollector
    pfc.collect(collected_facts = ansible_facts)

    # Validating the collected values
    assert 'machine_id' in ansible_facts
    assert ansible_facts['machine_id'] == '123456789abcd'

# Generated at 2022-06-11 05:01:15.810824
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestModule:
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            if cmd[-1] == "/var/lib/dbus/machine-id":
                return 0, self.params["fake_machine_id"], ""
            elif cmd[-1] == "/etc/machine-id":
                return 0, self.params["fake_machine_id"], ""
            elif cmd[-1] == "getconf":
                return 0, "x86_64", ""
            elif cmd[-1] == "bootinfo":
                return 0, "powerpc", ""
            else:
                return 0, self.params["fake_platform_data"], ""

        def get_bin_path(self, path):
            if path == 'getconf':
                return

# Generated at 2022-06-11 05:01:19.519672
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    Test PlatformFactCollector constructor to see if it can return a instance of PlatformFactCollector.
    """
    try:
        assert PlatformFactCollector()
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-11 05:01:22.008387
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    result = platform_fact_collector.collect()
    assert result["python_version"] == '2.7.11'

# Generated at 2022-06-11 05:01:54.237284
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_obj = PlatformFactCollector(None, {})
    assert test_obj.name == 'platform'
    assert test_obj._fact_ids == {'system',
                                  'kernel',
                                  'kernel_version',
                                  'machine',
                                  'python_version',
                                  'architecture',
                                  'machine_id'}

# Generated at 2022-06-11 05:02:02.524500
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])
    assert platform_facts['nodename'] == platform.node()

    arch_bits = platform.architecture()[0]

# Generated at 2022-06-11 05:02:07.375413
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, "", ""))
    platform_collection = PlatformFactCollector(module)
    result = platform_collection.collect(module=module)
    assert 'system' in result
    assert 'kernel' in result
    assert 'kernel_version' in result
    assert 'machine' in result
    assert 'python_version' in result

# Generated at 2022-06-11 05:02:11.821706
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-11 05:02:22.330222
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-11 05:02:31.050028
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for method collect of class PlatformFactCollector
    """
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    def _get_bin_path(name):
        """
        Stub method for getting the executable path for a command
        """
        return None

    def _run_command(command):
        """
        Stub method for running a command
        """
        pass

    class FakeModule(object):
        """
        Simple stub class for module
        """

# Generated at 2022-06-11 05:02:32.881038
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                               'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:02:42.414024
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    facts_dict = platform_collector.collect()
    assert facts_dict.get('system', None) is not None
    assert facts_dict.get('kernel', None) is not None
    assert facts_dict.get('kernel_version', None) is not None
    assert facts_dict.get('machine', None) is not None
    assert facts_dict.get('architecture', None) is not None
    assert facts_dict.get('python_version', None) is not None
    assert facts_dict.get('fqdn', None) is not None
    assert facts_dict.get('hostname', None) is not None
    assert facts_dict.get('nodename', None) is not None
    assert facts_dict.get('domain', None) is not None

# Generated at 2022-06-11 05:02:47.092004
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system', 'kernel',
                                                   'kernel_version','machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-11 05:02:52.224415
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_collector = PlatformFactCollector()

    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-11 05:03:47.891428
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """ Test method collect of PlatformFactCollector
    """
    test_platform = 'test'
    test_release = 'test_release'
    test_version = 'test_version'
    test_machine = 'test_machine'
    test_python_version = 'test_python_version'
    test_hostname = 'test_hostname'
    test_nodename = 'test_nodename'
    test_architecture = 'test_architecture'
    test_machine_id = 'test_machine_id'
    test_fqdn = 'test.fqdn.com'

    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.run_command = kwargs['run_command']
            self.get_bin_path = kwargs

# Generated at 2022-06-11 05:03:53.031037
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()

    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids


# Generated at 2022-06-11 05:04:01.411441
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    from ansible.module_utils.facts.collector import Collector
    pfc = PlatformFactCollector()

    assert isinstance(pfc, Collector)

    assert pfc.name == 'platform'

    assert pfc._fact_ids & set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id']) == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])


# Generated at 2022-06-11 05:04:11.188892
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collectors import PlatformFactCollector
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts import ModuleExcutor
    import platform

    ansible_module = AnsibleModule()
    collector = PlatformFactCollector(ansible_module=ansible_module)
    platform_value = collector.collect()

    # platform.system() can be Linux, Darwin, Java, or Windows
    assert platform_value['system'] == platform.system()
    assert platform_value['kernel'] == platform.release()
    assert platform_value['kernel_version'] == platform.version()
    assert platform_value['machine'] == platform.machine()

    # machine_id returned is of type str or unicode

# Generated at 2022-06-11 05:04:14.382655
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-11 05:04:22.491053
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform
    import socket
    import os

    try:
        import dbus
    except ImportError:
        dbus = None

    import sys
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        try:
            from cStringIO import StringIO
        except ImportError:
            from StringIO import StringIO

    class TestModule(object):
        def run_command(self, cmd, check_rc=True):
            if cmd[:2] == ['getconf', 'MACHINE_ARCHITECTURE']:
                return (0, 'powerpc\n', '')
            elif cmd[0] == 'bootinfo':
                return (0, 'powerpc\n', '')

# Generated at 2022-06-11 05:04:27.262439
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    platform_facts = PlatformFactCollector().collect()

    assert 'system' in platform_facts.keys()
    assert 'kernel' in platform_facts.keys()
    assert 'kernel_version' in platform_facts.keys()
    assert 'machine' in platform_facts.keys()
    assert 'python_version' in platform_facts.keys()
    assert 'architecture' in platform_facts.keys()
    assert 'machine_id' in platform_facts.keys()

# Generated at 2022-06-11 05:04:31.016278
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-11 05:04:33.488853
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == "platform"
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-11 05:04:36.168974
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    pfc.collect()

# Test invocation of class PlatformFactCollector
if __name__ == '__main__':
    pfc = PlatformFactCollector()
    pfc.collect()

# Generated at 2022-06-11 05:07:11.622676
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    platform_facts = {}
    # platform.system() can be Linux, Darwin, Java, or Windows
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()
    platform_facts['python_version'] = platform.python_version()
    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()
    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()[0]
    platform

# Generated at 2022-06-11 05:07:14.883146
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version',
                                                     'machine', 'architecture', 'python_version', 'machine_id'])

# Generated at 2022-06-11 05:07:16.009499
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # TODO: Add unit test for class PlatformFactCollector
    pass


# Generated at 2022-06-11 05:07:20.063838
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''Unit test for constructor of class PlatformFactCollector'''
    pfc = PlatformFactCollector()
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])
    assert pfc.name == 'platform'

# Generated at 2022-06-11 05:07:26.374196
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # create a PlatformFactCollector object
    platform_obj = PlatformFactCollector(None)
    # set module object
    setattr(platform_obj, 'module', None)
    # call the method
    platform_facts = platform_obj.collect()

    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel'] == '3.10.0-327.28.2.el7.x86_64'
    assert platform_facts['machine'] == 'x86_64'
    assert platform_facts['architecture'] == 'x86_64'

# Generated at 2022-06-11 05:07:27.181583
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-11 05:07:34.648625
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MagicMock()
    module.get_bin_path.side_effect = lambda x: '/bin/%s' % x
    fact_collector = PlatformFactCollector()
    # If the system is Linux
    platform.system = MagicMock(return_value='Linux')
    platform._supports_platform_system_linux = True
    # Try to collect facts
    facts = {}
    fact_collector.collect(module=module, collected_facts=facts)
    # Ensure that all facts are collected properly
    assert facts['system'] == 'Linux'
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['fqdn'] == socket

# Generated at 2022-06-11 05:07:36.734234
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    # Test whether platform.system() is among _fact_ids
    assert 'system' in p._fact_ids
    # Test whether p collects facts
    assert 'system' in p.collect()

# Generated at 2022-06-11 05:07:40.666225
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids

# Generated at 2022-06-11 05:07:42.814902
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert set(['kernel', 'kernel_version', 'machine', 'python_version', 'system',
                'architecture', 'machine_id']) == platform_fact_collector._fact_ids