

# Generated at 2022-06-11 05:00:40.295790
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()

    assert p.name == 'platform'
    assert p.collect()['system'] == platform.system()
    assert p.collect()['kernel'] == platform.release()
    assert p.collect()['kernel_version'] == platform.version()
    assert p.collect()['machine'] == platform.machine()
    assert p.collect()['python_version'] == platform.python_version()
    assert p.collect()['fqdn'] == socket.getfqdn()
    assert p.collect()['hostname'] == platform.node().split('.')[0]
    assert p.collect()['nodename'] == platform.node()
    if platform.node().split('.')[0] == 'localhost':
        assert p.collect()['domain'] == ''

# Generated at 2022-06-11 05:00:43.531151
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', "machine_id"}


# Generated at 2022-06-11 05:00:48.297067
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-11 05:00:54.428529
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_collector = PlatformFactCollector()
    assert test_collector.name == 'platform', "test_PlatformFactCollector: Failed to create PlatformFactCollector"
    assert test_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                            'python_version', 'architecture', 'machine_id']), \
        "test_PlatformFactCollector: Failed to create PlatformFactCollector"

# Generated at 2022-06-11 05:00:55.974537
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector()
    assert platform.collect() is not None

# Generated at 2022-06-11 05:01:04.169833
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import apply_collection_ignore
    from ansible.module_utils.facts import collector

    PlatformFactCollector.get_file_content = lambda self, file_name: 'this_is_a_test_file'
    platform_facts = PlatformFactCollector.collect(None)
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['machine_id'] == 'this_is_a_test_file'


# Generated at 2022-06-11 05:01:09.642844
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert set(p._fact_ids) == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])

# Generated at 2022-06-11 05:01:17.291440
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    print(str(platform_fact_collector))
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-11 05:01:21.828842
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

test_PlatformFactCollector()

# Generated at 2022-06-11 05:01:25.421371
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfgc = PlatformFactCollector()
    pfgc._module = {}
    pfgc._module.get_bin_path = lambda x: "true"
    pfgc._module.run_command = lambda x: ["", "", ""]
    pfgc.collect()
    assert pfgc._facts["system"] == platform.system()

# Generated at 2022-06-11 05:02:49.119418
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert p.name == 'platform'
    assert p.collect() == {}

# Generated at 2022-06-11 05:02:57.740898
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Assert that collect() returns the expected platform_facts
    """
    import ansible.module_utils.facts.collectors.platform

    platform_facts_collector = ansible.module_utils.facts.collectors.platform.PlatformFactCollector()


# Generated at 2022-06-11 05:03:06.794934
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()

    assert 'system' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'machine' in platform_facts
    assert 'hostname' in platform_facts
    assert 'nodename' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'domain' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'python_version' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'userspace_architecture' in platform_facts

# Generated at 2022-06-11 05:03:15.582174
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-11 05:03:17.886196
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    dut = PlatformFactCollector()

    assert dut.name == 'platform'
    assert dut._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-11 05:03:20.661246
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat_fd = PlatformFactCollector()
    assert plat_fd.name == "platform"
    assert plat_fd._fact_ids == {'system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'}

# Generated at 2022-06-11 05:03:28.360432
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # mock return value for import of module platform
    platform_mock = MagicMock()
    # system, kernel, kernel_version, machine, python_version, nodename, node.
    platform_mock.system.return_value = "Linux"
    platform_mock.release.return_value = "2.6.32-504.1.3.el6.x86_64"
    platform_mock.version.return_value = "#1 SMP Wed Oct 15 04:27:16 UTC 2014"
    platform_mock.machine.return_value = "x86_64"
    platform_mock.python_version.return_value = "2.7.5"
    platform_mock.node.return_value = "localhost.localdomain"
    #  patch to replace the import with a mock

# Generated at 2022-06-11 05:03:36.837508
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.utils import mock_ansible_module
    from ansible.module_utils.facts.utils import MockModuleUtils
    import sys
    import platform

    # Generate a mock module and mock ansible module
    mock_mod = mock_module(platform)
    mock_ans_mod = mock_ansible_module(platform)
    assert mock_mod is not None
    assert mock_ans_mod is not None

    # Mock module utils
    mock_ModuleUtils = MockModuleUtils(platform, platform.system())
    assert mock_ModuleUtils is not None

    # Instantiate a PlatformFactCollector object
    pfc = PlatformFactCollector(mock_mod, mock_ans_mod, mock_ModuleUtils)

# Generated at 2022-06-11 05:03:43.862094
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class MockModule:
        def __init__(self, return_value):
            self.return_value = return_value

        def get_bin_path(self, executable, required=False):
            return self.return_value

    module = MockModule(return_value=None)
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(module=module)

    assert platform_facts['system'] == platform.system()
    assert platform_facts['architecture'] == platform.machine()


# Generated at 2022-06-11 05:03:48.617433
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class MockModule():
        def __init__(self, name):
            self.name = name

        def get_bin_path(self, name):
            return None

        def run_command(self, cmd):
            return 0, "", ""

    pfc = PlatformFactCollector()
    assert type(pfc.collect(module=MockModule(name='test_platform'), collected_facts={})) == dict

# Generated at 2022-06-11 05:07:04.836415
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert (platform_obj.name == 'platform')
    assert (platform_obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id']))
    assert (callable(platform_obj.collect))


# Generated at 2022-06-11 05:07:07.403524
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert set(x._fact_ids) == set(['system','kernel','kernel_version','machine','python_version','architecture','machine_id'])

# Generated at 2022-06-11 05:07:10.600824
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    ])

# Generated at 2022-06-11 05:07:13.400311
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformfactcollector = PlatformFactCollector()
    assert platformfactcollector.name == 'platform'
    assert platformfactcollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:07:14.676774
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'

# Generated at 2022-06-11 05:07:15.790487
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
  pfc = PlatformFactCollector()
  assert pfc is not None


# Generated at 2022-06-11 05:07:24.082969
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    platform_facts = PlatformFactCollector.collect()

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])
    assert platform_facts['userspace_bits']

# Generated at 2022-06-11 05:07:29.005520
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'machine_id' in p._fact_ids

# Generated at 2022-06-11 05:07:30.567748
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    facts = collector.collect()
    assert facts['system'] == 'Linux'

# Generated at 2022-06-11 05:07:36.614827
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector
    import json

    # This collector does not have a config, so pass an empty dict
    collect_obj = PlatformFactCollector({})

    # Capture the output from the fact collector
    with open("./unit_tests/output/fact_collector_output.txt", "w") as output:
        try:
            with basic.capture_stdout(output):
                facts_dict = collect_obj.collect(module=None, collected_facts=None)
        except Exception as e:
            output.write(e.message)

    # If you need to update the golden file, simply delete the fact_collector_output.txt
    # file, re-run the test, then copy/paste the output into the file.