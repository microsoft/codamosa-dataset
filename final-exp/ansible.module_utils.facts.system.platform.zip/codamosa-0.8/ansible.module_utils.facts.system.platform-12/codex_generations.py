

# Generated at 2022-06-11 05:00:40.332629
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert len(pfc._fact_ids) == 8

    # Test

# Generated at 2022-06-11 05:00:44.700469
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert set(['system',
                'kernel',
                'kernel_version',
                'machine',
                'python_version',
                'architecture',
                'machine_id']) == pfc._fact_ids


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-11 05:00:49.531905
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:01:00.022877
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test platform.system() == 'Linux'
    class MockModule(object):
        def __init__(self, system_value, machine_value, release_value, version_value):
            self.get_bin_path_values = {
                "getconf": 'getconf',
                "bootinfo": 'bootinfo'
            }
            self.run_command_values = {
                ('getconf', 'MACHINE_ARCHITECTURE') : (0, 'data', None),
                ('bootinfo', '-p') : (0, 'data', None)
            }
            self.platform_system = system_value
            self.platform_machine = machine_value
            self.platform_release = release_value
            self.platform_version = version_value


# Generated at 2022-06-11 05:01:00.989117
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().collect() != None

if __name__ == "__main__":
    test_PlatformFactCollector()

# Generated at 2022-06-11 05:01:11.150630
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()

    assert platform_facts.name == 'platform'
    assert isinstance(platform_facts._fact_ids, set)
    assert 'system' in platform_facts._fact_ids
    assert 'kernel' in platform_facts._fact_ids
    assert 'kernel_version' in platform_facts._fact_ids
    assert 'machine' in platform_facts._fact_ids
    assert 'python_version' in platform_facts._fact_ids
    assert 'architecture' in platform_facts._fact_ids
    assert 'machine_id' in platform_facts._fact_ids
    assert 'userspace_bits' in platform_facts._fact_ids
    assert 'userspace_architecture' in platform_facts._fact_ids
    assert 'fqdn' in platform_facts._fact_ids

# Generated at 2022-06-11 05:01:13.385312
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    c = PlatformFactCollector()
    assert 'system' in c.collect(_module=None, collected_facts=None)

# Generated at 2022-06-11 05:01:22.398212
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    m = module_mock()
    pfc = PlatformFactCollector()

    m.run_command.side_effect = [
        (1, '', ''),
        (0, 'x86_64', ''),
        (0, 'i686', ''),
    ]

    platform_facts = pfc.collect(module=m)
    assert platform_facts['architecture'] == 'x86_64'
    assert platform_facts['userspace_architecture'] == 'x86_64'

    platform_facts = pfc.collect(module=m)
    assert platform_facts['architecture'] == 'i386'
    assert platform_facts['userspace_architecture'] == 'i386'

# Generated at 2022-06-11 05:01:25.324809
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformfactcollector = PlatformFactCollector()
    assert platformfactcollector.name == "platform"
    assert platformfactcollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:01:25.819201
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:02:08.370780
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:02:09.762146
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert (pfc.name == 'platform')

# Generated at 2022-06-11 05:02:14.345365
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    plugin = PlatformFactCollector()
    result = plugin.collect(None, None)

    assert result['system'] == 'Linux'
    assert result['architecture'] == 'x86_64'

    import platform
    assert platform.system() == 'Linux'
    assert platform.machine() == 'x86_64'

# Generated at 2022-06-11 05:02:18.904945
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:02:19.536960
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:02:25.077622
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_Collector = PlatformFactCollector()
    assert platform_fact_Collector
    assert platform_fact_Collector.name == 'platform'
    assert platform_fact_Collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:02:33.035317
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleDummy()
    fact_collector = PlatformFactCollector(module)
    # call the collect method
    fact_collector.collect()
    # Check attribute system
    system_value = fact_collector.collect_facts['system']
    assert (system_value == 'Linux')
    # Check attribute kernel
    kernel_value = fact_collector.collect_facts['kernel']
    assert (kernel_value == '3.10.0-327.el7.x86_64')
    # Check attribute kernel_version
    kernel_version_value = fact_collector.collect_facts['kernel_version']
    assert (kernel_version_value == '#1 SMP Thu Nov 19 22:10:57 UTC 2015')
    # Check attribute machine
    machine_value = fact_collector.collect_facts['machine']

# Generated at 2022-06-11 05:02:37.736781
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fc = PlatformFactCollector()
    assert platform_fc.name == 'platform'
    assert platform_fc._fact_ids == set(['system',
                                         'kernel',
                                         'kernel_version',
                                         'machine',
                                         'python_version',
                                         'architecture',
                                         'machine_id'])


# Generated at 2022-06-11 05:02:48.408768
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform
    from ansible.module_utils.facts import FactCollector

    collected_facts = dict()
    platform_collector = PlatformFactCollector(collected_facts, None)
    platform_facts = platform_collector.collect()
    assert platform_facts.get('system') == platform.system()
    assert platform_facts.get('kernel') == platform.release()
    assert platform_facts.get('kernel_version') == platform.version()
    assert platform_facts.get('machine') == platform.machine()
    assert platform_facts.get('fqdn') == socket.getfqdn()
    assert platform_facts.get('hostname') == platform.node().split('.')[0]
    assert platform_facts.get('nodename') == platform.node()

    # test with no hostname fact present
    facts

# Generated at 2022-06-11 05:02:52.138529
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == {'system', 'kernel', 'kernel_version', 'machine',
                             'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-11 05:03:49.392775
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:03:57.612145
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    pfc = PlatformFactCollector()
    fact_ids = pfc.get_fact_ids()
    facts = pfc.collect()

    assert isinstance(facts, dict)
    assert facts
    assert not fact_ids - set(facts.keys())
    assert set(facts.keys()) - fact_ids == set(['nodename', 'hostname', 'domain', 'fqdn', 'userspace_architecture'])
    assert './module_utils/facts/platform.py' not in facts
    assert 'ansible_python_version' not in facts
    assert 'ansible_machine_id' not in facts
    assert 'ansible_architecture' not in facts
    assert 'ansible_machine' not in facts

# Generated at 2022-06-11 05:04:08.171419
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

# Generated at 2022-06-11 05:04:15.853094
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create instance of PlatformFactCollector
    obj_pf_collector = PlatformFactCollector()

    platform_facts = {'system': 'Linux',
                      'kernel': '3.10.0-1062.12.1.el7.x86_64',
                      'kernel_version': '#1 SMP Wed Aug 7 02:05:26 EDT 2019',
                      'machine': 'x86_64',
                      'python_version': '2.7.5',
                      'architecture': 'x86_64',
                      'userspace_bits': '64'
                      }

    assert platform_facts == obj_pf_collector.collect()

# Generated at 2022-06-11 05:04:22.633890
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector_instance = PlatformFactCollector()

    # get_file_content is not mocked
    platform_facts = PlatformFactCollector_instance.collect()
    if platform_facts['system'] == 'Darwin':
        assert platform.mac_ver()[0] == platform_facts['kernel_version']
        assert platform.uname()[4] == platform_facts['machine']
    elif platform_facts['system'] == 'Linux':
        assert platform.platform() == platform_facts['kernel_version']
        assert platform.uname()[4] == platform_facts['machine']
    else:
        assert platform.platform() == platform_facts['kernel_version']

# Generated at 2022-06-11 05:04:26.823830
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system',
                                             'kernel',
                                             'kernel_version',
                                             'machine',
                                             'python_version',
                                             'architecture',
                                             'machine_id'}


# Generated at 2022-06-11 05:04:30.293027
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:04:38.186150
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test PlatformFactCollector.collect()
    """

    # patches are used to replace the return values of imported modules
    # the mock_open context manager mocks the file system and the file handles
    # and is used to mock the file system and the file handles
    @contextmanager
    def mock_open(mock=None):
        if mock is None:
            mock = MagicMock(spec=file)
        with patch('ansible.module_utils.facts.collector.open', mock, create=True):
            yield mock

    # patch is used to replace the imported modules

# Generated at 2022-06-11 05:04:41.271931
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert set(PlatformFactCollector._fact_ids) == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:04:46.616291
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Initialize the instance
    platform_facts_collector = PlatformFactCollector()

    # Check the name
    assert platform_facts_collector.name == 'platform'

    # Check the list of fact names
    assert platform_facts_collector.fact_ids == {'system',
                                                 'kernel',
                                                 'kernel_version',
                                                 'machine',
                                                 'python_version',
                                                 'architecture',
                                                 'machine_id'}

# Generated at 2022-06-11 05:07:52.914289
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    ################################################
    # unit test for class constructor
    ################################################
    # test with valid parameters
    c = PlatformFactCollector()
    assert isinstance(c, BaseFactCollector)

    # test with None parameters
    try:
        c = PlatformFactCollector(None)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-11 05:08:00.761542
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-11 05:08:03.182228
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == "platform"
    assert set(pfc._fact_ids) == set(['system', 'kernel', 'kernel_version', 'machine',
                                      'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:08:07.915820
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == "platform"
    assert fact_collector._fact_ids == set(['machine_id', 'architecture', 'domain',
                                            'userspace_bits', 'machine', 'system', 'nodename',
                                            'fqdn', 'python_version', 'kernel_version',
                                            'kernel', 'hostname'])
    assert fact_collector.collect()
    assert fact_collector.fact_class == 'platform'

# Generated at 2022-06-11 05:08:10.553634
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == {'system', 'kernel', 'kernel_version',
                                   'machine', 'python_version', 'architecture',
                                   'machine_id'}

# Generated at 2022-06-11 05:08:17.267623
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    mock_module = Mock()
    mock_module.run_command = Mock(return_value=(0, "test", ""))
    mock_module.get_bin_path = Mock(return_value=True)
    mock_module.get_file_content = Mock(return_value=True)
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(mock_module)
    assert platform_facts is not None
    assert 'system' in platform_facts

# Generated at 2022-06-11 05:08:22.903960
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids


# Generated at 2022-06-11 05:08:31.250698
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]

    platform_facts['userspace_bits'] = arch_bits.replace('bit', '')
   

# Generated at 2022-06-11 05:08:36.758575
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_collector = PlatformFactCollector()
    assert test_collector.name == 'platform'
    assert 'system' in test_collector._fact_ids
    assert 'kernel' in test_collector._fact_ids
    assert 'kernel_version' in test_collector._fact_ids
    assert 'machine' in test_collector._fact_ids
    assert 'python_version' in test_collector._fact_ids
    assert 'architecture' in test_collector._fact_ids
    assert 'machine_id' in test_collector._fact_ids


# Generated at 2022-06-11 05:08:40.574821
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    tf = PlatformFactCollector()
    assert isinstance(tf,PlatformFactCollector)
    assert tf.name == 'platform'
    assert tf._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])
