

# Generated at 2022-06-11 05:00:38.568251
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()


# Generated at 2022-06-11 05:00:43.439704
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert platform_obj
    assert platform_obj.name == "platform"
    assert platform_obj._fact_ids == set(['system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id'])

# Generated at 2022-06-11 05:00:51.279167
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = Mock()
    class_under_test = PlatformFactCollector()
    assert 'system' in class_under_test.collect(module)
    assert 'kernel' in class_under_test.collect(module)
    assert 'kernel_version' in class_under_test.collect(module)
    assert 'machine' in class_under_test.collect(module)
    assert 'python_version' in class_under_test.collect(module)
    assert 'architecture' in class_under_test.collect(module)
    assert 'machine_id' in class_under_test.collect(module)


# Generated at 2022-06-11 05:01:00.898013
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    collector = PlatformFactCollector()
    collected_facts = Collector().collect(collector)

    assert collected_facts['kernel']
    assert collected_facts['kernel_version']

    assert collected_facts['machine']
    assert collected_facts['python_version']

    assert collected_facts['fqdn']
    assert collected_facts['hostname']
    assert collected_facts['nodename']
    assert collected_facts['domain'] is not None

    # architecture may be different on x86_64
    # assert collected_facts['architecture']
    # assert collected_facts['machine_id'] is not None

# Generated at 2022-06-11 05:01:01.266795
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:01:05.123245
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()

    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-11 05:01:11.201657
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'
    assert platformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-11 05:01:15.764503
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == {'system', 'kernel', 'kernel_version',
                                            'machine', 'python_version', 'architecture',
                                            'machine_id'}

# Generated at 2022-06-11 05:01:21.361525
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, BaseFactCollector)
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-11 05:01:24.818370
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformfactcollector = PlatformFactCollector()
    assert platformfactcollector.name == 'platform'
    assert platformfactcollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])



# Generated at 2022-06-11 05:02:42.288451
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """ Unit test for checking the constructor of class PlatformFactCollector """
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert len(platform_fact_collector._fact_ids) == 9
    assert sorted(platform_fact_collector._fact_ids) == sorted(['system',
                                                                'kernel',
                                                                'kernel_version',
                                                                'machine',
                                                                'python_version',
                                                                'architecture',
                                                                'machine_id',
                                                                'fqdn',
                                                                'hostname',
                                                                'nodename',
                                                                'domain'])

# Generated at 2022-06-11 05:02:49.166324
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MockModule()
    platform_facts_collector = PlatformFactCollector(module=module)
    facts = platform_facts_collector.collect(module=module)

    assert "system" in facts
    assert "kernel" in facts
    assert "kernel_version" in facts
    assert "machine" in facts
    assert "python_version" in facts
    assert "architecture" in facts
    assert "machine_id" in facts

    assert "userspace_bits" in facts

# Generated at 2022-06-11 05:02:57.501288
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    Unit test for constructor of class PlatformFactCollector
    """
    obj = PlatformFactCollector()
    assert obj.name == "platform"
    assert obj.collect() == dict(nodename=platform.node(),
                                 system=platform.system(),
                                 kernel=platform.release(),
                                 kernel_version=platform.version(),
                                 machine=platform.machine(),
                                 python_version=platform.python_version(),
                                 fqdn=socket.getfqdn(),
                                 hostname=platform.node().split(".")[0],
                                 domain=".".join(socket.getfqdn().split(".")[1:]))

if __name__ == "__main__":
    # Unit tests for fact collector
    test_PlatformFactCollector()

# Generated at 2022-06-11 05:03:07.984971
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test correct generation of platform facts with mock return values
    """

    # TODO: This test needs to be rewritten to mock platform.
    #       Leave this test in place until mock is added to ansible.

    from ansible.module_utils.facts import ModuleFacts
    import platform

    # Mock platform.system() returning 'Linux'
    # (Default is 'Darwin')
    platform.system = lambda: 'Linux'

    # Mock platform.release() returning 2.6.18-6-amd64
    # (Default is Darwin Kernel Version 14.3.0: Mon Mar 23 11:59:05 PDT 2015; root:xnu-2782.20.48~5/RELEASE_X86_64)
    platform.release = lambda: '2.6.18-6-amd64'

    # Mock platform.version() returning #

# Generated at 2022-06-11 05:03:12.360739
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert set(platform_facts._fact_ids) == set(('system',
                                                 'kernel',
                                                 'kernel_version',
                                                 'machine',
                                                 'python_version',
                                                 'architecture',
                                                 'machine_id'))

# Generated at 2022-06-11 05:03:15.505337
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.collect()
    assert p.name == 'platform'
    assert p._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}



# Generated at 2022-06-11 05:03:19.382098
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts.get('system') in ('Linux', 'Darwin', 'Java', 'Windows')
    assert isinstance(platform_facts.get('python_version'), str)
    assert isinstance(platform_facts.get('kernel_version'), str)
    assert isinstance(platform_facts.get('machine'), str)
    assert isinstance(platform_facts.get('fqdn'), str)
    assert isinstance(platform_facts.get('hostname'), str)
    assert isinstance(platform_facts.get('domain'), str)

# Generated at 2022-06-11 05:03:23.805919
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert isinstance(fact_collector, PlatformFactCollector)
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])


# Generated at 2022-06-11 05:03:28.941446
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    platform_collector = PlatformFactCollector()
    assert platform_collector
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == {"system",
                                            "kernel",
                                            "kernel_version",
                                            "machine",
                                            "python_version",
                                            "architecture",
                                            "machine_id"}


# Generated at 2022-06-11 05:03:32.408051
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert isinstance(obj, PlatformFactCollector)

    expected_attributes = set(['_fact_ids', 'name'])
    assert expected_attributes == set(obj.__dict__.keys())


# Generated at 2022-06-11 05:06:31.549421
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()

    # Stub out the platform
    mock_platform = MockPlatform()

    # Stub out the module
    mock_module = MockModule(collector_platform=mock_platform)

    # Create a PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()

    # Collect the facts
    platform_facts = platform_fact_collector.collect(module=mock_module)

    # Did we get the expected results?
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel'] == '2.6.18-164.el5'
    assert platform_facts['kernel_version'] == '#1 SMP Tue Aug 18 15:51:48 EDT 2009'

# Generated at 2022-06-11 05:06:39.641385
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule:

        def __init__(self, sysname, nodename, release, version, machine, processor):
            self.sysname = sysname
            self.nodename = nodename
            self.release = release
            self.version = version
            self.machine = machine
            self.processor = processor

        class MockPlatform:

            def __init__(self, uname_result):
                self.uname_result = uname_result

            def uname(self):
                return self.uname_result

            def system(self):
                return self.uname_result.sysname

            def release(self):
                return self.uname_result.release

            def version(self):
                return self.uname_result.version

            def machine(self):
                return self.uname_result.machine



# Generated at 2022-06-11 05:06:41.352942
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"
    assert isinstance(p,BaseFactCollector)

# Generated at 2022-06-11 05:06:42.458701
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'

# Generated at 2022-06-11 05:06:46.739310
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-11 05:06:55.076340
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    collected_facts = {'ansible_architecture': 'x86_64'}

    fact_collector = FactCollector(collected_facts)

    platform_fact_collector = PlatformFactCollector(fact_collector)

    platform_facts = platform_fact_collector.collect()

    assert 'system' in platform_facts.keys()
    assert 'kernel' in platform_facts.keys()
    assert 'kernel_version' in platform_facts.keys()
    assert 'machine' in platform_facts.keys()
    assert 'python_version' in platform_facts.keys()
    assert 'fqdn' in platform_facts.keys()
    assert 'nodename'

# Generated at 2022-06-11 05:06:56.385269
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'

# Generated at 2022-06-11 05:07:01.028320
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert isinstance(p, PlatformFactCollector)
    assert p.name == "platform"
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-11 05:07:04.288911
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    p = PlatformFactCollector()
    # Test with empty collected_facts
    collected_facts = {}
    platform_facts = p.collect(collected_facts)
    assert platform_facts.get('system') == platform.system()
    assert platform_facts.get('architecture') == platform.machine()

# Generated at 2022-06-11 05:07:11.975923
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = FakeModule('/bin/foo')
    platform = PlatformFactCollector(module=module)

    def execute_module():
        return platform.collect()

    platform.get_file_content = lambda x: ""
    platform.run_command = lambda x, encoding=None: (0, '', '')
