

# Generated at 2022-06-11 05:00:43.747131
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Unit tests for method collect

# Generated at 2022-06-11 05:00:45.466227
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect()

# Generated at 2022-06-11 05:00:50.662887
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-11 05:01:01.055932
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test method collect of class PlatformFactCollector
    """
    # Create object
    platform_module = PlatformFactCollector()


# Generated at 2022-06-11 05:01:03.453975
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert sorted(x.collect()) == sorted(['system', 'kernel', 'kernel_version',
                                 'machine', 'python_version',
                                 'architecture'])

# Generated at 2022-06-11 05:01:07.140634
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set([
        'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:01:18.898955
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # we have to monkey patch get_file_content
    def fake_get_file_content(filename):
        if filename == "/var/lib/dbus/machine-id":
            return "1a2b3c4d-5e6f-7a8b-9c0d"
        raise IOError("filedoes not exist")
    PlatformFactCollector.get_file_content = fake_get_file_content

    module = None
    collected_facts = None
    pfc = PlatformFactCollector()

    # Test that it returns a dictionary and not a list
    platform_facts = pfc.collect(module, collected_facts)
    assert isinstance(platform_facts, dict), "PlatformFactCollector.collect must return a dictionary"

# Generated at 2022-06-11 05:01:20.512420
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test PlatformFactCollector class constructor
    platform_collector = PlatformFactCollector()

    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-11 05:01:27.551276
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    result = PlatformFactCollector.collect()
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()
    assert result['domain'] == '.'.join(result['fqdn'].split('.')[1:])
    assert result['userspace_bits'] == platform.architecture()[0].replace('bit', '')

# Generated at 2022-06-11 05:01:28.913252
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None

# Generated at 2022-06-11 05:02:55.886581
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    fake_platform = {
        'system': 'Linux',
        'machine': 'x86_64',
        'release': '4.4.0-21-generic',
        'version': '#37-Ubuntu SMP Mon Apr 18 18:33:37 UTC 2016',
        'python_version': '2.7.11'
    }
    fake_platform_keys = fake_platform.keys()


# Generated at 2022-06-11 05:02:57.266520
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    The constructor of the class PlatformFactCollector can be invoked. The
    returned instance of the class is an object of class PlatformFactCollector.
    '''
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)

# Generated at 2022-06-11 05:03:01.767247
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-11 05:03:03.083511
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.collect() == {}

# Generated at 2022-06-11 05:03:12.321469
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    assert PlatformFactCollector.collect() == \
           {'architecture': 'x86_64',
            'domain': '',
            'fqdn': '',
            'hostname': '',
            'kernel': '3.13.0-24-generic',
            'kernel_version': '#47-Ubuntu SMP Fri May 2 23:30:00 UTC 2014',
            'machine': 'x86_64',
            'nodename': '',
            'python_version': '2.7.6',
            'system': 'Linux',
            'userspace_bits': '64',
            'userspace_architecture': 'x86_64'}


# Generated at 2022-06-11 05:03:14.532573
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    # The method collect() will return a dictionary with platform's details
    assert isinstance(pf.collect(), dict)

# Generated at 2022-06-11 05:03:17.908549
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platf_obj = PlatformFactCollector()
    assert platf_obj.name == 'platform'
    assert platf_obj._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-11 05:03:20.271374
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:03:26.072533
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Facts

    test_collector = PlatformFactCollector()
    test_facts = Facts(None)

    test_collector.collect(collected_facts=test_facts)
    platform_facts = test_facts.get('platform')
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-11 05:03:29.928272
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-11 05:06:54.009669
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert "machine" in x._fact_ids
    assert "machine_id" in x._fact_ids

# Generated at 2022-06-11 05:07:02.195915
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    platform_facts = PlatformFactCollector.collect()
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel'] == '4.4.0-31-generic'
    assert platform_facts['kernel_version'] == '#50~14.04.1-Ubuntu SMP Wed Jul 13 01:07:32 UTC 2016'
    assert platform_facts['machine'] == 'x86_64'
    assert platform_facts['python_version'] == '2.7.5'
    assert platform_facts['fqdn'] == 'Ansible-Galaxy-Vagrant-VirtualBox.local' or 'Ansible-Galaxy-Workstation.local'
    assert platform_facts['hostname'] == 'Ansible-Galaxy-Vagrant-VirtualBox'

# Generated at 2022-06-11 05:07:08.732009
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Run the platform.collect function against a fixed set of data
    # and verify resulting data

    # We are running in the tests directory, so import the testable data
    # from the module_utils directory
    from module_utils import facts_test_data

    fact_collector = PlatformFactCollector()

    system_facts = fact_collector.collect(
        module=None,
        collected_facts=None)

    for fact_name in system_facts:
        assert fact_name in facts_test_data.expected_system_facts
        assert system_facts[fact_name] == facts_test_data.expected_system_facts[fact_name]


# Generated at 2022-06-11 05:07:09.817553
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector.collect()['system'] == platform.system()

# Generated at 2022-06-11 05:07:11.546412
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert isinstance(x, PlatformFactCollector)
    assert x.name == 'platform'

# Generated at 2022-06-11 05:07:14.814283
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == {
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    }

# Generated at 2022-06-11 05:07:19.516656
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert(platform_facts["system"] or platform_facts["kernel"] or platform_facts["machine"] or platform_facts["python_version"])
    assert(platform_facts["domain"] or platform_facts["fqdn"] or platform_facts["nodename"] or platform_facts["hostname"])
    assert(platform_facts["architecture"] or platform_facts["userspace_architecture"] or platform_facts["userspace_bits"])

# Generated at 2022-06-11 05:07:20.667605
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'

# Generated at 2022-06-11 05:07:24.467571
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:07:25.271231
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    f = PlatformFactCollector()
    f.collect()