

# Generated at 2022-06-11 05:00:48.242236
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert len(p._fact_ids) == 9
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'fqdn' in p._fact_ids
    assert 'nodename' in p._fact_ids
    assert 'domain' in p._fact_ids

# Generated at 2022-06-11 05:00:50.030272
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    x._fact_ids = set()

# Generated at 2022-06-11 05:01:00.495302
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()


# Generated at 2022-06-11 05:01:01.627968
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    This method will be used for testing the constructor of PlatformFactCollector class
    """
    assert isinstance(PlatformFactCollector(), PlatformFactCollector)

# Generated at 2022-06-11 05:01:12.774297
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create object instance
    platform_fact_collector = PlatformFactCollector()

    # Verify list of keys returned by method _get_fact_ids of FactCollector
    # object
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'architecture',
                                                     'machine_id',
                                                     'python_version'])

    # From local ansible/test/unit/module_utils/facts/test_platform.py
    assert platform.system() in ['Linux', 'Darwin', 'FreeBSD', 'NetBSD',
                                 'OpenBSD', 'SunOS', 'AIX', 'Windows']
    assert platform.node() == socket.getfqdn()

# Generated at 2022-06-11 05:01:14.301485
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    return platform_facts

# Generated at 2022-06-11 05:01:20.994705
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-11 05:01:23.423231
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:01:28.784365
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Arrange
    # Set up a mock module and collector
    module = MockModule()
    collector = PlatformFactCollector()

    # Act
    facts = collector.collect(module=module)

    # Assert

# Generated at 2022-06-11 05:01:33.176129
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version',
                                 'architecture', 'machine_id'])
    assert len(pfc.collect()) == 9


# vim: set expandtab:

# Generated at 2022-06-11 05:02:14.398284
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-11 05:02:18.447325
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import ansible.module_utils.facts.collector
    test_obj = ansible.module_utils.facts.collector.BaseFactCollector()
    PlatformFactCollector_obj = PlatformFactCollector(test_obj)
    PlatformFactCollector_obj.collect()

# Generated at 2022-06-11 05:02:22.235835
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                     'kernel',
                     'kernel_version','machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-11 05:02:30.941608
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import join
    from ansible.module_utils.facts.utils import get_file_content

    test_facts = PlatformFactCollector()

    assert test_facts.name == 'platform'
    assert 'system' in test_facts._fact_ids
    assert 'kernel' in test_facts._fact_ids
    assert 'kernel_version' in test_facts._fact_ids
    assert 'machine' in test_facts._fact_ids
    assert 'python_version' in test_facts._fact_ids
    assert 'architecture' in test_facts._fact_ids
    assert 'machine_id' in test_facts._fact_ids


# Generated at 2022-06-11 05:02:32.276815
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert len(platform_collector._fact_ids) >= 5

# Generated at 2022-06-11 05:02:35.962515
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:02:46.335718
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = PlatformFactCollector.collect(platform)
    assert type(test_platform_facts) is dict, "test_PlatformFactCollector_collect: Returned value should be a dict"
    assert "architecture" in test_platform_facts, "test_PlatformFactCollector_collect: Returned dict does not contain" \
                                                  "architecture"
    assert "fqdn" in test_platform_facts, "test_PlatformFactCollector_collect: Returned dict does not contain" \
                                          "fqdn"
    assert "hostname" in test_platform_facts, "test_PlatformFactCollector_collect: Returned dict does not contain" \
                                              "hostname"

# Generated at 2022-06-11 05:02:47.950388
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.__name__ == 'PlatformFactCollector'

# Generated at 2022-06-11 05:02:56.848732
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fc = PlatformFactCollector()
    collected_facts = platform_fc.collect({})

    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    assert collected_facts['machine'] == platform.machine()
    assert collected_facts['architecture'] == platform.machine()
    assert collected_facts['python_version'] == platform.python_version()
    assert collected_facts['fqdn'] == socket.getfqdn()
    assert collected_facts['hostname'] == platform.node().split('.')[0]
    assert collected_facts['nodename'] == platform.node()

# Generated at 2022-06-11 05:03:00.818503
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()

    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                               'python_version', 'architecture',
                               'machine_id'])



# Generated at 2022-06-11 05:03:35.894914
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_data = PlatformFactCollector.collect()
    assert 'system' in fact_data
    assert 'kernel' in fact_data
    assert 'kernel_version' in fact_data
    assert 'machine' in fact_data
    assert 'python_version' in fact_data
    assert 'architecture' in fact_data
    assert 'fqdn' in fact_data
    assert 'hostname' in fact_data
    assert 'nodename' in fact_data
    assert 'domain' in fact_data

# Generated at 2022-06-11 05:03:39.475385
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-11 05:03:45.146962
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-11 05:03:46.120115
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()

# Generated at 2022-06-11 05:03:53.228777
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fake_module = type('module', (object,), {})()
    collector = PlatformFactCollector(fake_module) # pylint: disable=abstract-class-instantiated
    fake_module.get_bin_path = lambda x: None
    facts = collector.collect()
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'python_version' in facts
    assert 'fqdn' in facts
    assert 'hostname' in facts
    assert 'nodename' in facts
    assert 'domain' in facts
    assert 'architecture' in facts
    assert 'userspace_bits' in facts

# Generated at 2022-06-11 05:03:56.556338
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-11 05:04:01.565488
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_collector = PlatformFactCollector()
    assert platform_facts_collector.name == 'platform'
    assert PlatformFactCollector._fact_ids == {'system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'}

# Generated at 2022-06-11 05:04:03.670099
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    mock_module = {}
    platform_fact_collector = PlatformFactCollector(mock_module)
    assert platform_fact_collector

# Generated at 2022-06-11 05:04:13.360939
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class mock_platform:
        def __init__(self, system_val, release_val, machine_val, architecture_val):
            self.system_val = system_val
            self.release_val = release_val
            self.machine_val = machine_val
            self.architecture_val = architecture_val

        def system(self):
            return self.system_val

        def release(self):
            return self.release_val

        def machine(self):
            return self.machine_val

        def architecture(self):
            return self.architecture_val

    class mock_socket:
        def __init__(self, fqdn_val, nodename_val):
            self.fqdn_val = fqdn_val
            self.nodename_val = nodename_val


# Generated at 2022-06-11 05:04:18.902122
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector.fetchable_by == 'setup'
    assert set(platform_fact_collector._fact_ids) == {'system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'}

# Generated at 2022-06-11 05:06:07.826608
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-11 05:06:11.886090
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert x.collect()

# Generated at 2022-06-11 05:06:12.954490
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fn = PlatformFactCollector().collect
    assert isinstance(fn, collections.Callable)

# Generated at 2022-06-11 05:06:14.315100
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert type(obj) == PlatformFactCollector



# Generated at 2022-06-11 05:06:17.640101
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == "platform"
    assert pfc.collect()
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-11 05:06:23.034369
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'machine_id' in p._fact_ids

# Generated at 2022-06-11 05:06:33.078508
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Initialize
    input = {}
    module = None
    collected_facts = {}

    # Pre-Run
    platform_collector = PlatformFactCollector()
    result = platform_collector.collect(module, collected_facts)

    # Assertions
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()

# Generated at 2022-06-11 05:06:36.459516
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    p = PlatformFactCollector()

    facts = FactCollector().get_facts()
    test_facts = p.collect(collected_facts=facts)
    assert 'system' in test_facts
    assert 'kernel' in test_facts
    assert 'kernel_version' in test_facts
    assert 'machine' in test_facts
    assert 'python_version' in test_facts
    assert 'architecture' in test_facts
    assert 'machine_id' in test_facts

# Generated at 2022-06-11 05:06:37.633161
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    c = PlatformFactCollector()
    assert c.name == 'platform'

# Generated at 2022-06-11 05:06:44.260633
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class ModuleStub:
        def get_bin_path(self, _):
            return None
        def run_command(self, _):
            return (0, "", "")
    class CollectedFactsStub:
        pass

    result = PlatformFactCollector.collect(
        collector=PlatformFactCollector(),
        module=ModuleStub(),
        collected_facts=CollectedFactsStub())
    assert "architecture" in result
    assert "userspace_architecture" in result
    assert "kernel" in result
    assert "kernel_version" in result
    assert "machine" in result
    assert "python_version" in result
    assert "system" in result