

# Generated at 2022-06-20 19:43:37.007432
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == "platform"
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:43:49.687398
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import CollectorsRegistry

    # Ensure PlatformFactCollector is registered
    registered_collectors = CollectorsRegistry().registered_collectors()
    assert 'PlatformFactCollector' in registered_collectors
    
    # Ensure the name is set correctly
    assert registered_collectors['PlatformFactCollector'].name == 'platform'

    # Ensure the list of _fact_ids is set correctly
    assert registered_collectors['PlatformFactCollector']._fact_ids == set(['system',
                                                                            'kernel',
                                                                            'kernel_version',
                                                                            'machine',
                                                                            'python_version',
                                                                            'architecture',
                                                                            'machine_id'])


# Generated at 2022-06-20 19:43:52.413638
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModule({})
    facts_collector = PlatformFactCollector(module=module)
    result = facts_collector.collect()
    assert result is not None

# Generated at 2022-06-20 19:44:02.944975
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()

# Generated at 2022-06-20 19:44:08.937351
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Mock
    class MockModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, a1):
            return "get_bin_path"
        def run_command(self, a1):
            return (False, "", "")

    p = PlatformFactCollector()
    m = MockModule()
    p.collect(module=m)

# Generated at 2022-06-20 19:44:13.416182
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == "platform"
    assert platform_facts._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-20 19:44:19.294893
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-20 19:44:20.523906
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
  x = PlatformFactCollector()
  assert x.collect() is not None

# Generated at 2022-06-20 19:44:25.033900
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set (['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-20 19:44:26.236154
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.collect()

# Generated at 2022-06-20 19:44:46.611302
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module_mock = Mock()
    platform_collector = PlatformFactCollector()
    platform_collector.collect(module_mock)


# Generated at 2022-06-20 19:44:52.114890
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    name = 'platform'
    obj = PlatformFactCollector()
    assert(name == obj.name)
    assert('system' in obj._fact_ids)
    assert('kernel' in obj._fact_ids)
    assert('kernel_version' in obj._fact_ids)
    assert('machine' in obj._fact_ids)
    assert('python_version' in obj._fact_ids)
    assert('architecture' in obj._fact_ids)

# Generated at 2022-06-20 19:44:57.954114
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create a mock module and mock class
    mockModule = type('MockModule', (object,), {'get_bin_path': lambda self, arg: None})
    mockClass = type('MockClass', (object,), {'run_command': lambda self, arg: (0, 'x86_64', None)})
    mockModule.run_command = lambda self, arg: (0, 'x86_64', None)

    # create an instance of PlatformFactCollector
    fc = PlatformFactCollector()

    # create a mock platfrom module

# Generated at 2022-06-20 19:45:04.042263
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a fact collector
    fact_collector = PlatformFactCollector()
    # get facts
    platform_facts = fact_collector.collect()
    # assert that system facts are collected
    assert 'system' in platform_facts
    # assert that kernel facts are collected
    assert 'kernel' in platform_facts
    # assert that kernel_version facts are collected
    assert 'kernel_version' in platform_facts
    # assert that machine facts are collected
    assert 'machine' in platform_facts
    # assert that python_version facts are collected
    assert 'python_version' in platform_facts
    # assert that architecture facts are collected
    assert 'architecture' in platform_facts


# Generated at 2022-06-20 19:45:06.332604
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.name == 'platform'
    assert len(platform._fact_ids) == 9

# Generated at 2022-06-20 19:45:10.609553
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-20 19:45:16.929017
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
  from ansible.module_utils.facts.collector import FactCollector
  import json

  facts_collector = FactCollector()
  facts_collector.collect(module=None, collected_facts=None)
  facts = facts_collector.get_facts()

  output = json.dumps(facts,sort_keys=True)

  return output

# Generated at 2022-06-20 19:45:27.170500
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestModule(object):
        def __init__(self):
            self.path_backup = {}
        def get_bin_path(self, command):
            return self.path_backup.get(command, None)
        def run_command(self, command):
            return (0, "", "")

    def test_case(test_number, test_dict, expected_result):
        """ Unit test for collect method of class PlatformFactCollector.
        :param test_number: test number
        :param test_dict: dictionary to be returned by get_bin_path
        :param expected_result: expected_result
        :rtype: None
        """

        test_module = TestModule()
        test_module.path_backup = test_dict
        platform_fact_collector = PlatformFactCollector()
        result

# Generated at 2022-06-20 19:45:31.942273
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test if the return of collect method of PlatformFactCollector is a dict."""
    p = PlatformFactCollector()
    assert isinstance(p.collect(), dict)


# Generated at 2022-06-20 19:45:42.709714
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts_output = {
            'architecture': 'i386',
            'domain': 'localhost',
            'fqdn': 'localhost',
            'hostname': 'localhost',
            'kernel': '3.19.0-28-generic',
            'kernel_version': '#30~14.04.1-Ubuntu SMP Fri Jan 15 17:43:14 UTC 2016',
            'machine': 'i686',
            'nodename': 'localhost',
            'python_version': '2.7.6',
            'system': 'Linux',
            'userspace_architecture': 'i386',
            'userspace_bits': '32',
            'machine_id': '3b7f00d9c942f83fc467b75a716ba3e3'
        }

    plat_

# Generated at 2022-06-20 19:46:11.946532
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = NonCallableMagicMock(name='mock_module')
    mock_module.params = {'gather_subset': ['!all', 'network']}
    mock_module.config = {'fact_cache': None}

    collector = PlatformFactCollector(mock_module)

    facts = collector.collect(mock_module)
    assert facts['system'] == 'Linux'
    assert facts['python_version'] == '2.7.6'
    assert facts['fqdn'] == 'mock_hostname'
    assert facts['hostname'] == 'mock_hostname'
    assert facts['nodename'] == 'mock_hostname'
    assert facts['domain'] == 'mock_domain'
    assert facts['architecture'] == 'x86_64'

# Generated at 2022-06-20 19:46:17.670041
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()

    assert platform_obj.name is not None
    assert platform_obj._fact_ids is not None

    assert platform_obj.name == "platform"
    assert platform_obj._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-20 19:46:22.943924
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-20 19:46:26.032095
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert 'system' in pf.name
    assert pf.name == 'platform'

# Generated at 2022-06-20 19:46:32.786621
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids


# Generated at 2022-06-20 19:46:43.797802
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform

    mocked_module = MagicMock()
    mocked_module.run_command.return_value = (0, "", "")

    collector = PlatformFactCollector(mocked_module)

    data = collector.collect(mocked_module, None)

    assert 'system' in data
    assert data['system'] == platform.system()
    assert 'kernel' in data
    assert data['kernel'] == platform.release()
    assert 'kernel_version' in data
    assert data['kernel_version'] == platform.version()
    assert 'machine' in data
    assert data['machine'] == platform.machine()
    assert 'python_version' in data
    assert data['python_version'] == platform.python_version()
    assert 'fqdn' in data
    assert data['fqdn'] == socket.getfqdn

# Generated at 2022-06-20 19:46:46.747451
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:46:56.273510
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    facts = collector.collect()

    assert facts['system'] == 'Linux'
    assert facts['kernel'] == '3.13.0-39-generic'
    assert facts['machine'] == 'x86_64'
    assert facts['architecture'] == 'x86_64'
    assert facts['userspace_bits'] == '64'
    assert facts['userspace_architecture'] == 'x86_64'
    assert facts['python_version'] == '2.7.6'
    assert facts['fqdn'] == 'osboxes.org'
    assert facts['hostname'] == 'osboxes'
    assert facts['domain'] == 'org'
    assert facts['nodename'] == 'osboxes.org'

# Generated at 2022-06-20 19:47:02.641883
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """PlatformFactCollector: Test collect method."""
    class FakeModule:
        def __init__(self):
            self.params = ''
        def get_bin_path(self, cmd):
            return cmd
        def run_command(self, cmd):
            return 0, 'aix-arch', ''

    platform_facts = PlatformFactCollector().collect(FakeModule())
    assert platform_facts['architecture'] == 'aix-arch'

# Generated at 2022-06-20 19:47:14.745024
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def get_bin_path(self, arg):
            return "echo test"

        def run_command(self, arg):
            return 0, "0", ""

    module = MockModule()
    # test domain
    platform_facts = PlatformFactCollector().collect(module=module)
    assert '.'.join(platform_facts['fqdn'].split('.')[1:]) == platform_facts['domain']

    # set a machine id file
    machine_id_file = "/var/lib/dbus/machine-id"
    machine_id = "adb5f5c5-6e5b-4ec7-9a9e-f7b08d0d103e"
    mock_open = mock.mock_open(read_data=machine_id)

# Generated at 2022-06-20 19:48:37.252254
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:48:40.732895
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_object = PlatformFactCollector()
    assert platform_object.name == "platform"
    assert platform_object._fact_ids == {'nodename', 'hostname', 'kernel', 'system', 'python_version', 'domain',
                                         'architecture', 'fqdn', 'machine_id', 'kernel_version', 'machine',
                                         'userspace_bits'}

# Generated at 2022-06-20 19:48:48.653604
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # The module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a PlatformFactCollector object
    pfc = PlatformFactCollector(module=module)

    # Collect the facts and check if the result is what we expect
    platform_facts = pfc.collect()

    module.exit_json(changed=False, ansible_facts=platform_facts)

# import module snippets
from ansible.module_utils.basic import *

main()

# Generated at 2022-06-20 19:48:51.271262
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system','kernel','kernel_version','machine','python_version','architecture','machine_id'])



# Generated at 2022-06-20 19:48:57.922652
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_obj = PlatformFactCollector()
    assert platform_facts_obj.name == 'platform'
    assert platform_facts_obj._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-20 19:49:03.529493
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()

    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['python_version']
    assert platform_facts['architecture']
    assert platform_facts['machine_id']

# Generated at 2022-06-20 19:49:14.465655
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import os
    from ansible.module_utils.facts import get_module_path

    # Initialize an instance of class PlatformFactCollector
    module_path = get_module_path('ansible.module_utils.facts')
    collect_cache_dir = os.path.join(module_path, 'collect_cache')
    pfc = PlatformFactCollector(
        module=None,
        collected_facts={},
        cache_dir=collect_cache_dir,
        timeout=10,
        platform_subset=None,
    )

    # Invoke method collect of class PlatformFactCollector
    platform_facts = pfc.collect()

    # Check value of keys in return value
    assert 'system' in platform_facts
    assert platform_facts['system'] == platform.system()

# Generated at 2022-06-20 19:49:17.103584
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    PlatformFactCollector.collect()

# Generated at 2022-06-20 19:49:24.914352
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector_obj = PlatformFactCollector()
    platform_facts = PlatformFactCollector_obj.collect()

    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['architecture']
    assert platform_facts['nodename']
    assert platform_facts['hostname']
    assert platform_facts['fqdn']
    assert platform_facts['domain']
    assert platform_facts['python_version']


# Generated at 2022-06-20 19:49:34.147631
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform
    import socket

    hostname = platform.node().split('.')[0]
    fqdn = socket.getfqdn()

    platform_facts = PlatformFactCollector().collect()

    if platform.system() == 'AIX':
        assert platform_facts['system'] == 'AIX'
        assert platform_facts['kernel'] == platform.release()
        assert platform_facts['kernel_version'] == platform.version()
        assert platform_facts['architecture'] == platform_facts['machine']
        assert platform_facts['nodename'] == platform.node()
        assert platform_facts['fqdn'] == fqdn
        assert platform_facts['hostname'] == hostname
        assert platform_facts['domain'] == '.'.join(fqdn.split('.')[1:])