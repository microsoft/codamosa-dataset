

# Generated at 2022-06-20 19:43:50.793410
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Here we use the PlatformFactCollector class to store the collected facts
    # in a platfrom_facts variable
    platform_facts = PlatformFactCollector().collect()

    # The tests below check if some of the collected facts match expected values
    assert platform_facts["system"] in ["Linux", "Darwin", "Windows"]

    if platform_facts["system"] == "Linux":
        assert platform_facts["kernel"] in ["Linux", "GNU/kFreeBSD"]
    elif platform_facts["system"] == "AIX":
        assert platform_facts["kernel"] == "AIX"
    elif platform_facts["system"] == "Darwin":
        assert platform_facts["kernel"] == "Darwin"
    elif platform_facts["system"] == "Windows":
        assert platform_facts["kernel"] == "Windows"

    assert platform_

# Generated at 2022-06-20 19:43:52.287574
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    assert platform_collector.collect()['system'] == 'Linux'

# Generated at 2022-06-20 19:43:58.925765
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, PlatformFactCollector)
    assert hasattr(platform_fact_collector, 'name')
    assert isinstance(platform_fact_collector.name, str)
    assert hasattr(platform_fact_collector, '_fact_ids')
    assert isinstance(platform_fact_collector._fact_ids, set)

# Generated at 2022-06-20 19:44:01.124358
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert not any(value is None for value in platform_facts.values())

# Generated at 2022-06-20 19:44:02.690027
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-20 19:44:09.111152
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-20 19:44:10.062634
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector()
    assert result is not None

# Generated at 2022-06-20 19:44:20.438195
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    facts = {}
    fact_collector = PlatformFactCollector(module)
    collected_facts = fact_collector.collect(module=module, collected_facts=facts)
    assert collected_facts['system'] == 'Linux'
    assert collected_facts['machine'] == 'x86_64'
    assert collected_facts['python_version'][0] == '2'
    machine_id = get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")
    if machine_id:
        assert machine_id.splitlines()[0] == collected_facts["machine_id"]

# Generated at 2022-06-20 19:44:25.033929
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


# Generated at 2022-06-20 19:44:30.155976
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform
    import pytest

    class Mock_platform:
        # pylint: disable=missing-docstring
        def system(self):
            pass
        def version(self):
            pass
        def python_version(self):
            pass
        def release(self):
            pass
        def machine(self):
            pass
        def uname(self):
            pass
        def architecture(self):
            pass
        def node(self):
            pass

    class Mock_socket:
        # pylint: disable=missing-docstring
        def getfqdn(self):
            pass

    p = PlatformFactCollector()

    def mock_getfqdn():
        return "test.domain.com"

    def mock_python_version():
        return "2.6.9"


# Generated at 2022-06-20 19:45:48.106986
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()
    pass

# Generated at 2022-06-20 19:45:55.103693
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-20 19:45:56.596535
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-20 19:46:00.624491
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    result = {}
    result = PlatformFactCollector().collect(None, result)
    for key in PlatformFactCollector()._fact_ids:
        assert key in result

# Generated at 2022-06-20 19:46:10.753609
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import mock
    import os
    import tempfile
    import socket

    mock_module = mock.Mock(get_bin_path=lambda x,y=None: x)

    # test_system = 'Linux'
    # test_kernel = '2.6.18-348.3.1.el5'
    # test_kernel_version = '#1 SMP Wed Oct 30 18:39:05 EDT 2013'
    # test_machine = 'x86_64'
    test_python_version = '2.7.4'

    # test_fqdn = 'test.example.com'
    # test_nodename = 'test.example.com'
    # test_domain = 'example.com'
    # test_architecture = 'x86_64'
    # test_userspace_

# Generated at 2022-06-20 19:46:11.497919
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    objCollector = PlatformFactCollector()

    pass

# Generated at 2022-06-20 19:46:15.948844
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:46:19.532899
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformfact_collector_ins = PlatformFactCollector()
    assert platformfact_collector_ins.name == 'platform'
    assert len(platformfact_collector_ins._fact_ids) == 9

# Generated at 2022-06-20 19:46:23.355008
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    x = PlatformFactCollector()
    result = x.collect()
    assert 'system' in result
    assert 'kernel' in result
    assert 'kernel_version' in result
    assert 'machine' in result
    assert 'python_version' in result
    assert 'architecture' in result

# Generated at 2022-06-20 19:46:26.129848
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"

# Generated at 2022-06-20 19:48:04.732120
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = PlatformFactCollector()

    result = test_platform_facts.collect()
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()
    assert result['domain'] == '.'.join(result['fqdn'].split('.')[1:])
    assert result['architecture'] == platform.machine()

    if platform.machine() == 'x86_64':
        assert result['architecture'] == 'x86_64'
        assert result

# Generated at 2022-06-20 19:48:12.963927
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    This test just verifies if the method collect of PlatformFactCollector class
    is working properly. No actual data is being tested, just the structure is
    being made sure. If a key is added to the return of collect method, this
    test will fail as well.
    """
    platform_collector = PlatformFactCollector()

    # Call the collect method
    result = platform_collector.collect()

    assert isinstance(result, dict)
    assert set(result.keys()) == set(platform_collector.fact_ids())
    for key in result:
        assert isinstance(result[key], str) or isinstance(result[key], int)

# Generated at 2022-06-20 19:48:22.764365
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import ansible.module_utils.facts.collectors.platform
    platform_facts = ansible.module_utils.facts.collectors.platform.PlatformFactCollector().collect()
    assert platform_facts['system'] is not None
    assert platform_facts['kernel'] is not None
    assert platform_facts['kernel_version'] is not None
    assert platform_facts['machine'] is not None
    assert platform_facts['python_version'] is not None
    assert platform_facts['fqdn'] is not None
    assert platform_facts['hostname'] is not None
    assert platform_facts['nodename'] is not None
    assert platform_facts['domain'] is not None
    assert platform_facts['userspace_bits'] is not None
    assert platform_facts['architecture'] is not None

# Generated at 2022-06-20 19:48:32.609041
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    TEST_PLATFORM_FACTS = {
        'architecture': 'x86_64',
        'domain': 'testdomain',
        'fqdn': 'localhost.testdomain',
        'hostname': 'localhost',
        'kernel': '3.10.0-693.el7.x86_64',
        'kernel_version': '#1 SMP Thu Jul 6 19:56:59 UTC 2017',
        'machine': 'x86_64',
        'machine_id': '',
        'nodename': 'localhost.testdomain',
        'python_version': '2.7.5',
        'system': 'Linux',
        'userspace_bits': '64',
        'userspace_architecture': 'x86_64'
    }

    import platform

# Generated at 2022-06-20 19:48:40.826219
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PLATFORM_FACTS = {
        'system': 'Linux',
        'kernel': '3.13.0-49-generic',
        'kernel_version': '#80-Ubuntu SMP Thu Mar 12 11:16:15 UTC 2015',
        'machine': 'x86_64',
        'python_version': '2.7.6',
        'architecture': 'x86_64',
        'fqdn': 'localhost.localdomain',
        'hostname': 'localhost',
        'nodename': 'localhost.localdomain',
        'domain': 'localdomain'
    }

    class MockModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, PLATFORM_FACTS['hostname'], None)
            self

# Generated at 2022-06-20 19:48:51.443957
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    class ModuleMock(object):

        def get_bin_path(self, program):
            if program == 'getconf':
                return '/usr/bin/getconf'
            elif program == 'bootinfo':
                return '/usr/bin/bootinfo'
            else:
                return None

        def run_command(self, args):
            return 0, "fake", ""

    mod = ModuleMock()

    platform_facts = []
    for p in Collector.get_facts_from_collectors(
            collectors=[PlatformFactCollector],
            module=mod
    ):
        platform_facts.append(p)


# Generated at 2022-06-20 19:48:58.815905
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Collector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector
    platform_collector = PlatformFactCollector()
    collected_facts = {}
    platform_collector.collect(collected_facts=collected_facts)


# Generated at 2022-06-20 19:49:04.602130
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create an instance of the PlatformFactCollector class
    p = PlatformFactCollector()
    p_facts = p.collect()
    # check if the collect method returns a dict
    assert isinstance(p_facts, dict)
    # check if the collect method returns a non-empty dict
    assert bool(p_facts) is True
    # check if the collect method returns a dict containing 'system'
    assert 'system' in p_facts

# Generated at 2022-06-20 19:49:06.694241
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == "platform"

# Generated at 2022-06-20 19:49:16.322317
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    import ansible.module_utils.facts.system.platform as platform_module

    class MockModule:
        def __init__(self):
            self.base_dir = 'tmp'

        def get_bin_path(self, bin):
            if bin == 'bootinfo':
                return 'bootinfo'
            if bin == 'getconf':
                return 'getconf'

        def run_command(self, args, check_rc=True, close_fds=True):
            if args[0] == 'bootinfo':
                return 0, '64', ''
            if args[0] == 'getconf':
                return 0, '123', ''

    platform_collector = PlatformFactCollector()