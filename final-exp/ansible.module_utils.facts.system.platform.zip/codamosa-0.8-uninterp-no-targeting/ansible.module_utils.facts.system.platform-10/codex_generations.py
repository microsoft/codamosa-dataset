

# Generated at 2022-06-20 19:43:45.263196
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    platform_solaris = PlatformFactCollector()

    facts = platform_solaris.collect()

    assert facts['system'] == 'SunOS'
    assert facts['architecture'] == 'i386'
    assert facts['kernel_version'] == 'generic_147147-26'
    assert facts['machine'] == 'i86pc'
    assert facts['python_version'] == '2.7.5'

# Generated at 2022-06-20 19:43:46.708602
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.platform_facts['system'] is not None

# Generated at 2022-06-20 19:43:51.903982
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:44:02.375982
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Facts that platform.uname would return
    uname = ('Linux', 'testbox.example.org', '2.6.32-431.11.2.el6.x86_64', '#1 SMP Tue Sep 9 21:35:44 UTC 2014', 'x86_64')
    # Facts that platform.architecture would return
    arch = ('64bit', '')
    # Facts that platform.python_version would return
    py_version = '2.7.16'
    # Facts that socket.getfqdn would return
    fqdn = 'testbox.example.org'
    # Facts that platform.node would return
    node = 'testbox'

    # Python object that is an instance of PlatformFactCollector
    platform_collector = PlatformFactCollector()
    # Tuple that is a stub of a platform

# Generated at 2022-06-20 19:44:11.590352
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()

    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()

    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]

    assert platform_facts['userspace_bits'] == arch_bits.replace('bit', '')

# Generated at 2022-06-20 19:44:19.149570
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test case with no machine_id
    mock_module = MockModule()
    platform_fact_collector = PlatformFactCollector(mock_module)
    collected_facts = {}
    collected_facts['system'] = 'Linux'
    collected_facts['kernel'] = '3.13.0-24-generic'
    collected_facts['kernel_version'] = '#47-Ubuntu SMP Fri May 2 23:30:00 UTC 2014'
    collected_facts['machine'] = 'x86_64'
    collecte

# Generated at 2022-06-20 19:44:22.814920
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    fact_collector = FactsCollector()
    collector = PlatformFactCollector(fact_collector)
    assert collector.collect() != None

# Generated at 2022-06-20 19:44:26.191177
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = None
    collected_facts = None
    plt = PlatformFactCollector()
    plt.collect(module, collected_facts)

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-20 19:44:34.314777
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        import platform
        import re
    except:
        print("ERROR: Failed to load platform python package")

    try:
        import socket
    except:
        print("ERROR: Failed to load socket module")

    try:
        import ansible.module_utils.facts.utils
        import ansible.module_utils.facts.collector
    except:
        print("ERROR: Failed to load ansible module_utils")

    m = ansible.module_utils.facts.collector.get_collector_class('platform')()
    platform_facts = m.collect()

    assert platform_facts['system'] is not None
    assert platform_facts['kernel'] is not None
    assert platform_facts['kernel_version'] is not None
    assert platform_facts['machine'] is not None

    assert platform_facts['python_version']

# Generated at 2022-06-20 19:44:34.938879
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass

# Generated at 2022-06-20 19:45:20.938777
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test for PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert len(platform_fact_collector._fact_ids) == 8

# Unit Test for collect method of class PlatformFactCollector

# Generated at 2022-06-20 19:45:23.539344
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector()
    assert result is not None

# Generated at 2022-06-20 19:45:25.640765
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-20 19:45:32.306919
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.collectors.platform as platform_collector

    # Create a class that wraps module to avoid exit_json and fail_json
    # being called during the tests.
    class ModuleStub(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda **kwargs: None
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, path):
            if path == 'getconf':
                return '/usr/bin/getconf'

# Generated at 2022-06-20 19:45:34.814950
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector.collect()
    assert platform_facts['system'].startswith('Linux')

# Generated at 2022-06-20 19:45:45.290279
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """ Test for method collect() of class PlatformFactCollector """

    # Run test for method collect of class PlatformFactCollector
    p = PlatformFactCollector()
    p.collect()

    # Assert that collect returns a fact

# Generated at 2022-06-20 19:45:47.168720
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_collector.collect()

# Generated at 2022-06-20 19:45:53.404464
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'min'}
            self.fail_json = fail_json
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    def run_command(command):
        command_string = " ".join(command)
        if command_string == 'bootinfo -p':
            return (0, "ppc64\n", '')
        elif command_string == 'getconf MACHINE_ARCHITECTURE':
            return (0, "powerpc\n", '')
        elif command_string == 'uname -m':
            return (0, "i686", '')


    def get_bin_path(command):
        return command


# Generated at 2022-06-20 19:45:55.348674
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-20 19:46:00.625412
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == {'architecture',
                             'fqdn',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'machine_id',
                             'domain',
                             'hostname',
                             'nodename',
                             'python_version',
                             'system',
                             'userspace_architecture',
                             'userspace_bits'}


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-20 19:46:20.699342
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-20 19:46:30.849271
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector is not None
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids is not None
    assert len(platform_collector._fact_ids) == 9
    assert 'system' in platform_collector._fact_ids
    assert 'kernel' in platform_collector._fact_ids
    assert 'kernel_version' in platform_collector._fact_ids
    assert 'machine' in platform_collector._fact_ids
    assert 'python_version' in platform_collector._fact_ids
    assert 'architecture' in platform_collector._fact_ids
    assert 'fqdn' in platform_collector._fact_ids
    assert 'hostname' in platform_collector._fact_ids

# Generated at 2022-06-20 19:46:41.969777
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    platform = PlatformFactCollector()

    # Default usage
    collected_facts = {}
    collected_facts['system'] = platform.collect()['system']
    collected_facts['kernel'] = platform.collect()['kernel']
    collected_facts['kernel_version'] = platform.collect()['kernel_version']
    collected_facts['machine'] = platform.collect()['machine']
    collected_facts['python_version'] = platform.collect()['python_version']
    collected_facts['architecture'] = platform.collect()['architecture']
    collected_facts['machine_id'] = platform.collect()['machine_id']

    assert collected_facts['system'] == platform.collect()['system']
    assert collected_facts['kernel'] == platform.collect()['kernel']

# Generated at 2022-06-20 19:46:46.088740
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine',
                                            'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-20 19:46:50.389632
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    mac = PlatformFactCollector()
    assert mac.name == 'platform'
    assert 'system' in mac._fact_ids
    assert 'kernel' in mac._fact_ids
    assert 'kernel_version' in mac._fact_ids
    assert 'machine' in mac._fact_ids
    assert 'python_version' in mac._fact_ids
    assert 'architecture' in mac._fact_ids
    assert 'machine_id' in mac._fact_ids



# Generated at 2022-06-20 19:46:58.336976
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    This method tests if the dictionary returned by method collect of class
    PlatformFactCollector contains the correct values for the "kernel" key.
    """
    # Create an instance of class PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()

    # Get the current system's kernel
    current_kernel = platform.release()

    # Get the dictionary returned by method collect
    collected_facts = platform_fact_collector.collect()

    # Check if the dictionary returned by method collect has the correct
    # kernel
    assert collected_facts['kernel'] == current_kernel

# Generated at 2022-06-20 19:47:05.326734
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = dict(
        system='AIX',
        kernel='7.2',
        kernel_version='7200-02-02',
        machine='powerpc',
        python_version='2.7.13',
        fqdn='localhost.localdomain',
        hostname='localhost',
        nodename='localhost',
        domain='localdomain',
        userspace_bits='64',
        architecture='powerpc',
        userspace_architecture='powerpc'
    )
    test_module = None
    test_platform = PlatformFactCollector()

    assert test_platform.collect(test_module) == test_platform_facts

# Generated at 2022-06-20 19:47:07.056449
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector.collect().has_key('system')

# Generated at 2022-06-20 19:47:14.548363
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # setup
    pfc = PlatformFactCollector()

    assert 'system' in pfc.fact_ids()
    assert 'kernel' in pfc.fact_ids()
    assert 'kernel_version' in pfc.fact_ids()
    assert 'machine' in pfc.fact_ids()
    assert 'python_version' in pfc.fact_ids()
    assert 'architecture' in pfc.fact_ids()
    assert 'machine_id' in pfc.fact_ids()

# Generated at 2022-06-20 19:47:20.450455
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.name == 'platform'
    assert platform._fact_ids == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])

# Generated at 2022-06-20 19:49:38.841654
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collectors import collector_module

    platform_facts_collector = PlatformFactCollector(
        module=collector_module,
        collected_facts={'ansible_facts': {'hostname': 'host'}})

# Generated at 2022-06-20 19:49:47.388357
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts
    assert platform_facts['system'] == platform.system()

    assert 'kernel' in platform_facts
    assert platform_facts['kernel'] == platform.release()

    assert 'kernel_version' in platform_facts
    assert platform_facts['kernel_version'] == platform.version()

    assert 'machine' in platform_facts
    assert platform_facts['machine'] == platform.machine()

    assert 'python_version' in platform_facts
    assert platform_facts['python_version'] == platform.python_version()

    assert 'architecture' in platform_facts
    assert platform_facts['architecture'] == platform.machine()

    assert 'machine_id' in platform_facts

# Generated at 2022-06-20 19:49:56.602399
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    fake_module = FakeModule()
    fake_module.add_bin_path("getconf", "/bin/getconf")
    fake_module.add_bin_path("bootinfo", "/bin/bootinfo")
    fake_module.add_file("/bin/getconf",
                         "i86sr, MACHINE_ARCHITECTURE\ni386, MACHINE_ARCHITECTURE\n")
    fake_module.add_file("/bin/bootinfo", "-p\npowerpc\n")
    fake_module.add_file("/var/lib/dbus/machine-id", "11112222333344445555666677778888\n")
    fake_module.add_file("/etc/machine-id", "99988877766655544433322211100099\n")


# Generated at 2022-06-20 19:50:02.737900
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fc = PlatformFactCollector()
    assert fc.name == 'platform'
    assert fc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-20 19:50:05.672660
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
  collector = PlatformFactCollector()
  assert collector.name == 'platform'
  assert collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-20 19:50:16.666134
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = "module"
    # mock the module object
    module = MockModule()

    # mock the facts object
    collected_facts = dict()

    # mock the architecture of the machine
    architecture = MockArchitecture()
    collected_facts["architecture"] = architecture

    # mock the platform object
    platform_ = MockPlatform()
    collected_facts["platform"] = platform_

    # mock the uname object
    uname = MockUname()
    collected_facts["uname"] = uname

    # create the PlatformFactCollector object
    platform_fact_collector = PlatformFactCollector()

    # test method collect
    platform_fact_collector.collect(module, collected_facts)

# create a mock module class

# Generated at 2022-06-20 19:50:27.446909
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert type(platform_facts) is dict
    # The following assertion is hard to check in an automated fashion.
    # assert platform_facts['system'] in ('Linux', 'Darwin', 'Java', 'Windows')
    assert type(platform_facts['kernel']) is str
    assert type(platform_facts['kernel_version']) is str
    assert type(platform_facts['machine']) is str
    assert re.match(r'\d.\d.\d', platform_facts['python_version'])
    assert type(platform_facts['fqdn']) is str
    assert type(platform_facts['hostname']) is str
    assert type(platform_facts['nodename']) is str
    assert type(platform_facts['domain']) is str
    assert platform_

# Generated at 2022-06-20 19:50:29.015941
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'

# Generated at 2022-06-20 19:50:30.340426
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert 'system' in PlatformFactCollector().collect().keys()

# Generated at 2022-06-20 19:50:40.424984
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    hostname = platform.node()
    fqdn = socket.getfqdn()
    domain = '.'.join(fqdn.split('.')[1:])
    fake_module = type("module", (object,),
                       {"get_bin_path": lambda self, x: '/bin/' + x})()

    # Emulate AIX
    platform.system = lambda: 'AIX'
    platform.release = lambda: '7.1'
    platform.version = lambda: '7100-01-01-1743'
    platform.machine = lambda: 'powerpc'
    platform.node = lambda: hostname
    platform.architecture = lambda: ('64bit', '')
    platform.python_version = lambda: '2.7.10'

    collector = PlatformFactCollector()

    # Test normal AIX