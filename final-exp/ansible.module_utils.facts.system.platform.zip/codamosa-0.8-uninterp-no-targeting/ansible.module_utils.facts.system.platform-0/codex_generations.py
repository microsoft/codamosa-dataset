

# Generated at 2022-06-20 19:43:43.294082
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    myplat_collector = PlatformFactCollector()
    assert myplat_collector.name == 'platform'
    assert myplat_collector._fact_ids == set(['system',
                                              'kernel',
                                              'kernel_version',
                                              'machine',
                                              'python_version',
                                              'architecture',
                                              'machine_id'])

# Generated at 2022-06-20 19:43:48.215218
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-20 19:43:53.497585
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    system_facts = PlatformFactCollector().collect()
    assert system_facts["system"] == platform.system()
    assert system_facts["architecture"] == platform.machine()
    assert system_facts["kernel"] == platform.release()
    assert system_facts["kernel_version"] == platform.version()
    assert system_facts["machine"] == platform.machine()
    assert system_facts["python_version"] == platform.python_version()
    assert system_facts["fqdn"] == socket.getfqdn()

# Generated at 2022-06-20 19:44:05.057628
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert platform_facts['architecture']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['machine_id']
    assert platform_facts['system']
    assert platform_facts['nodename']
    assert platform_facts['fqdn']
    assert platform_facts['hostname']
    assert platform_facts['domain']
    assert platform_facts['python_version']
    assert platform_facts['userspace_bits']
    assert platform_facts['userspace_architecture']

    assert isinstance(platform_facts['architecture'], str)
    assert isinstance(platform_facts['kernel'], str)
    assert isinstance(platform_facts['kernel_version'], str)

# Generated at 2022-06-20 19:44:12.722329
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    from ansible.module_utils.facts import ModuleBase
    from ansible.module_utils.facts.utils import get_file_content
    module = ModuleBase()
    facts = collector.collect(module=module, collected_facts={})
    assert facts['system']
    assert facts['kernel']
    assert facts['kernel_version']
    assert facts['machine']
    assert facts['python_version']
    assert facts['architecture'] == facts['machine'] or facts['architecture'] == 'i386'
    assert facts['userspace_bits'] == '64' or facts['userspace_bits'] == '32'
    assert facts['userspace_architecture']
    assert facts['hostname'] == facts['nodename'].split('.')[0]
    assert facts['domain']
   

# Generated at 2022-06-20 19:44:13.319298
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:44:25.033919
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts import collect
    import ansible.module_utils.facts.collectors.platform

    ansible.module_utils.facts.collectors.platform.platform = platform
    ansible.module_utils.facts.collectors.platform.BaseFactCollector = BaseFactCollector
    ansible.module_utils.facts.collectors.platform.get_file_content = get_file_content
    ansible.module_utils.facts.collectors.platform.socket = socket
    ansible.module_utils.facts.collectors.platform.re = re
    collected_facts = collect.collect(['platform'])

# Generated at 2022-06-20 19:44:29.543015
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids


# Generated at 2022-06-20 19:44:36.615228
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])
    assert not platform_fact_collector.collect()

# Generated at 2022-06-20 19:44:37.243064
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:45:58.171019
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import os
    import platform
    class MockModule():
        def __init__(self):
            self.get_bin_path_args = None
            self.get_bin_path_succeeds = True
            self.run_command_args = None
            self.run_command_succeeds = True
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.params = ''
        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args
            self.fail_json_kwargs = kwargs
        def get_bin_path(self, arg, *args, **kwargs):
            self.get_bin_path_args = arg, args, kwargs

# Generated at 2022-06-20 19:46:00.720476
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_object = PlatformFactCollector()
    assert isinstance(test_object.collect(),dict)

# Generated at 2022-06-20 19:46:10.830654
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    x86_64_collector = PlatformFactCollector()

# Generated at 2022-06-20 19:46:15.812766
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-20 19:46:19.814082
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert x._fact_ids == {"system", "kernel", "kernel_version", "machine",
                           "python_version", "architecture", "machine_id"}

# Generated at 2022-06-20 19:46:20.450218
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:46:30.658874
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import FallbackModuleUtilsCache
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    module_cache = FallbackModuleUtilsCache()
    module_cache.add_module(DistributionFactCollector.name, module_utils=DistributionFactCollector())
    facts_collector = FactsCollector(module_cache=module_cache)
    facts_collector.collect()
    platform_facts = facts_collector.get_facts()["ansible_facts"]["ansible_platform"]
    assert "system" in platform_facts
    assert "kernel" in platform_facts
    assert "kernel_version" in platform_facts
    assert "machine" in platform_facts

# Generated at 2022-06-20 19:46:35.810334
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-20 19:46:45.438761
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for method PlatformFactCollector.collect
    """
    # Get a reference to the module
    import sys
    import ansible.module_utils.facts.collector
    test_module = sys.modules['ansible.module_utils.facts.collector']
    # Get a reference to the PlatformFactCollector class
    PlatformFactCollectorClass = getattr(test_module, 'PlatformFactCollector')
    # Create an instance of the PlatformFactCollector class
    platform_fact_collector = PlatformFactCollectorClass()
    platform_facts = platform_fact_collector.collect()
    print(platform_facts)

if __name__ == "__main__":
    test_PlatformFactCollector_collect()

# Generated at 2022-06-20 19:46:51.459437
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Get a PlatformFactCollector object
    fact_collector = PlatformFactCollector()

    # Assert that member name is 'platform'
    assert fact_collector.name == 'platform'

    # Assert that the fact_id set is correct
    fact_ids = fact_collector.get_fact_ids()

    assert isinstance(fact_ids, set)
    assert 'system' in fact_ids
    assert 'kernel' in fact_ids
    assert 'kernel_version' in fact_ids
    assert 'machine' in fact_ids
    assert 'python_version' in fact_ids
    assert 'architecture' in fact_ids
    assert 'machine_id' in fact_ids


# Generated at 2022-06-20 19:48:28.648007
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert isinstance(platform_facts['system'], str)
    assert isinstance(platform_facts['kernel'], str)
    assert isinstance(platform_facts['kernel_version'], str)
    assert isinstance(platform_facts['machine'], str)
    assert isinstance(platform_facts['python_version'], str)
    assert isinstance(platform_facts['architecture'], str)


# Generated at 2022-06-20 19:48:33.358308
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()

    #Test name of the collector
    assert platform_collector.name == 'platform'

    #Test fact_ids of the collector
    assert set(platform_collector._fact_ids) == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-20 19:48:34.958484
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    x = PlatformFactCollector()
    out = x.collect()
    assert out["system"]

# Generated at 2022-06-20 19:48:36.399007
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    assert platform_collector.collect()

# Generated at 2022-06-20 19:48:43.007335
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestModule(object):
        def __init__(self):
            self._module = 'ansible.module_utils.facts.collector.base'

        def get_bin_path(self, name):
            return ''

        def run_command(self, cmd):
            return 0, '', ''

    class TestCollectedFact(object):
        def __init__(self):
            self._fact_id = []

        def add(self, fact_id, fact_data):
            self._fact_id.append(fact_id)

    collector = PlatformFactCollector()
    facts_collected = TestCollectedFact()
    collector.collect(TestModule(), facts_collected)

    for fact_id in collector._fact_ids:
        assert(fact_id in facts_collected._fact_id)

# Generated at 2022-06-20 19:48:52.860744
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_info = PlatformFactCollector.collect(None, None)
    assert platform_info["python_version"] == platform.python_version()
    assert platform_info["system"] == platform.system()
    assert platform_info["machine"] == platform.machine()
    assert platform_info["kernel_version"] == platform.version()
    assert platform_info["kernel"] == platform.release()
    assert platform_info["architecture"] == platform.uname()[4]
    assert platform_info["userspace_bits"] == platform.architecture()[0].replace("bit", "")
    if platform_info["python_version"].startswith('2.6'):
        assert platform_info["hostname"] == platform.node().split('.')[0].split('-')[0]
    else:
        assert platform_info

# Generated at 2022-06-20 19:49:01.891385
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """ Test the constructor of PlatformFactCollector class """

    platform_fact_collector = PlatformFactCollector()

    # Assert the name of the class
    assert platform_fact_collector.name == "platform"
    # Assert the private attribute '_fact_ids'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:49:02.736369
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()


# Generated at 2022-06-20 19:49:13.937174
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    with open('/proc/cpuinfo', 'r') as f:
        cpuinfo = f.read()

    with open('/proc/version', 'r') as f:
        version = f.read()

    c = PlatformFactCollector()
    collected_facts = {}
    c.collect(collected_facts=collected_facts, module=None)
    # noinspection PyUnresolvedReferences
    assert collected_facts['architecture'] == platform.machine()
    # noinspection PyUnresolvedReferences
    assert collected_facts['kernel_version'] == platform.version()
    # noinspection PyUnresolvedReferences
    assert collected_facts['system'] == platform.system()
    # noinspection PyUnresolvedReferences
    assert collected_facts['machine'] == platform.machine()
    # noinspection PyUnresolved

# Generated at 2022-06-20 19:49:20.874618
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:52:33.486658
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc is not None
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:52:41.735869
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform', "test_PlatformFactCollector: property 'name' failed"

    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id']), "test_PlatformFactCollector: property '_fact_ids' failed"

# Generated at 2022-06-20 19:52:43.872656
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc
    assert pfc.name == 'platform'
    assert pfc._fact_ids

# Generated at 2022-06-20 19:52:48.814972
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # mock module
    module = AnsiModuleMock()
    # create instance of PlatformFactCollector
    pf = PlatformFactCollector()
    # call method collect
    pf.collect(module)
    # check two facts exist
    assert(len(module.facts) == 2)
    # check two facts are equal to expected values
    assert(module.facts['system'] == 'Linux')
    assert(module.facts['machine'] == 'x86_64')


# mock class for AnsibleModule