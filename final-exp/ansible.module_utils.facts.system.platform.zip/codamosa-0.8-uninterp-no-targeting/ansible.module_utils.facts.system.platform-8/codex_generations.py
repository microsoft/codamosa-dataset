

# Generated at 2022-06-20 19:43:36.774476
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestPlatformModule(object):

        def get_bin_path(self, arg):
            return None

        def run_command(self, arg):
            return (0, "32", "")

    test_system_facts_collector = PlatformFactCollector()

    test_platform_module = TestPlatformModule()

    result = test_system_facts_collector.collect(test_platform_module)

    assert 'architecture' in result


# Generated at 2022-06-20 19:43:38.579257
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert set(platform_facts.collect().keys()) == platform_facts._fact_ids

# Generated at 2022-06-20 19:43:42.226162
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector.collect()["system"] == platform.system()
    assert PlatformFactCollector.collect()["machine"] == platform.machine()

# Generated at 2022-06-20 19:43:48.706166
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids

# Generated at 2022-06-20 19:43:52.553470
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == "platform"
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-20 19:43:58.881982
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    o = PlatformFactCollector()
    assert o.name == 'platform'
    assert o._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert o._platform == 'Generic'

# Generated at 2022-06-20 19:44:03.026742
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert isinstance(p, PlatformFactCollector)
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:44:09.170898
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-20 19:44:15.181987
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

    # No paramater given
    # Should return a dictionary
    platform_facts = platform_fact_collector.collect()
    assert isinstance(platform_facts, dict)

    # Check some keys
    expected_keys = ['system', 'kernel', 'kernel_version', 'machine']
    for key in expected_keys:
        assert key in platform_facts

# Generated at 2022-06-20 19:44:26.068364
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a instance of PlatformFactCollector without any parameter
    instance = PlatformFactCollector()
    # Check that the instance is correctly initialized
    assert instance.name == 'platform'
    assert instance._fact_ids == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])
    # Call the method collect of the instance
    result = instance.collect()
    # Check the name of keys in the result
    assert 'system' in result
    assert 'kernel' in result
    assert 'kernel_version' in result
    assert 'machine' in result
    assert 'python_version' in result
    assert 'architecture' in result
    assert 'fqdn' in result

# Generated at 2022-06-20 19:45:25.291826
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])



# Generated at 2022-06-20 19:45:29.492821
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x.fact_ids == set(['system',
                              'kernel',
                              'kernel_version',
                              'machine',
                              'python_version',
                              'architecture',
                              'machine_id'])
    assert x.platform_filters == {'machine': 'i86pc'}

# Generated at 2022-06-20 19:45:32.458620
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector()._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:45:43.630067
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts import ModuleArgsParseException

    distributed_collector = FactsCollector()
    distributed_collector.collectors = [PlatformFactCollector()]

    fact_list = [
        "system",
        "kernel",
        "kernel_version",
        "machine",
        "python_version",
        "architecture",
    ]

    # Method collect of class PlatformFactCollector should return a dict
    # Key 'system' of the dict should equal to platform.system()
    # Key 'kernel' of the dict should equal to platform.release()
    # Key 'kernel_version' of the dict should equal to platform.version()
    # Key 'machine' of the dict should equal to platform.machine()
    # Key 'python_

# Generated at 2022-06-20 19:45:48.713949
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set([ 'architecture', 'kernel_version', 'python_version', 'system', 'hostname', 'kernel', 'machine_id', 'machine', 'nodename', 'fqdn', 'domain', 'userspace_architecture', 'userspace_bits' ])

# Generated at 2022-06-20 19:45:51.889817
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()

    assert platform_facts['python_version'] == platform.python_version()

# Generated at 2022-06-20 19:45:57.991463
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert 'system' in platform_facts._fact_ids
    assert 'kernel' in platform_facts._fact_ids
    assert 'kernel_version' in platform_facts._fact_ids
    assert 'machine' in platform_facts._fact_ids
    assert 'python_version' in platform_facts._fact_ids
    assert 'architecture' in platform_facts._fact_ids
    assert 'machine_id' in platform_facts._fact_ids


# Generated at 2022-06-20 19:45:59.892015
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()



# Generated at 2022-06-20 19:46:05.442828
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-20 19:46:06.678075
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'

# Generated at 2022-06-20 19:48:01.658197
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    # Check the instance of the class
    assert isinstance(platform_facts, PlatformFactCollector)
    # Check the facts_type of the class
    assert platform_facts.name == "platform"
    # Check the fact_ids of the class
    assert platform_facts._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-20 19:48:13.134454
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import re
    import json

    SOLARIS_I86_RE_PATTERN = r'i([3456]86|86pc)'
    solaris_i86_re = re.compile(SOLARIS_I86_RE_PATTERN)

    def mock_get_bin_path(name, required=False):
        return name

    module = type('mock_module', (object,),
                  {'get_bin_path': mock_get_bin_path,
                   'run_command': lambda name, shell=False: [0, '', '']})()

    fact_collector = PlatformFactCollector()
    fact_collector.collect(module, {})
    all_facts = fact_collector.get_facts()

    assert all_facts["system"] == platform

# Generated at 2022-06-20 19:48:23.229431
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = {
        'system': 'Linux',
        'kernel': '3.13.0-45-generic',
        'kernel_version': '#74-Ubuntu SMP Tue Jan 13 19:36:28 UTC 2015',
        'machine': 'x86_64',
        'fqdn': 'localhost.localdomain',
        'hostname': 'localhost',
        'nodename': 'localhost.localdomain',
        'domain': 'localdomain',
        'python_version': '2.7.6',
        'userspace_bits': '32',
        'machine_id': "0123456789abcdef0123456789abcdef",
        'architecture': 'x86_64',
        'userspace_architecture': 'i386',
    }
   

# Generated at 2022-06-20 19:48:32.802482
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Define a mock_module object, as it would be returned by AnsibleModule
    # during module execution
    class mock_module(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, executable=None, required=False, opt_dirs=[]):
            if executable == 'getconf':
                return '/usr/bin/getconf'
            elif executable == 'bootinfo':
                return '/usr/sbin/bootinfo'
            elif executable == 'uname':
                return '/usr/bin/uname'

    # Define a mocked 'ansible_facts' dict, as it would be returned by
    # BaseFactCollector._get_facts_from_cache or _

# Generated at 2022-06-20 19:48:37.782907
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    pf.collect()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])

# Generated at 2022-06-20 19:48:38.171924
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:48:41.620668
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id'])
    assert isinstance(PlatformFactCollector._fact_ids, set)

# Generated at 2022-06-20 19:48:52.009322
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collection import Facts
    from ansible.module_utils.facts import get_module_facts

    def try_module(**kwargs):
        return True

    def try_module_run_command(cmd):
        return (None, "", "")

    PlatformFactCollector.collect(try_module_get_bin_path=try_module_run_command)

    FactsCollector._initialize_fact_collectors()
    f = FactsCollector(get_module_facts, None, True, "", try_module)
    facts = Facts(f.collect()[0])
    facts.populate()
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts


# Generated at 2022-06-20 19:49:03.675853
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    This is a unit test to test method collect of class
    PlatformFactCollector.
    A test class with a mocked module is used to test method collect.
    """
    class MockModule():
        """
        A mock class to create an object of class 'Module'
        """

        def __init__(self):
            """
            __init__ method to initialise the class
            """
            self.params = {}

        def get_bin_path(self, executable):
            """
            A mock method to create method 'get_bin_path()'
            """
            return executable

        def run_command(self, cmd):
            """
            A mock method to create method 'run_command()'
            """
            return 0, "", ""

    mock_module = MockModule()
    collector = PlatformFactCollector()
    output

# Generated at 2022-06-20 19:49:14.602814
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import re
    import socket
    import os

    class Test:
        def __init__(self):
            self.path = os.environ['PATH']
            self.bin_path_map = {'getconf': 'spec/unit/module_utils/facts/files/getconf', 'bootinfo': 'spec/unit/module_utils/facts/files/bootinfo'}

        def get_bin_path(self, name):
            if name in self.bin_path_map:
                return self.bin_path_map[name]
            else:
                return None

        def run_command(self, command):
            if command.count('getconf') > 0:
                return 0, '64\n', None

# Generated at 2022-06-20 19:52:23.292038
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert len(pfc._fact_ids) == 9
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'userspace_architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids


# Generated at 2022-06-20 19:52:31.146820
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])


# Generated at 2022-06-20 19:52:36.574421
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Read platform facts from platform
    collector = PlatformFactCollector()
    platform_facts = collector.collect()

    # Test fqdn
    if 'fqdn' in platform_facts:
        # If FQDN is specified, test hostname and domain
        assert 'hostname' in platform_facts
        assert 'domain' in platform_facts

        # Test whether FQDN can be reconstructed as hostname + domain
        assert platform_facts['fqdn'] == (platform_facts['hostname'] + "." + platform_facts['domain'])
    else:
        # If FQDN is not specified, test nodename
        assert 'nodename' in platform_facts

# Generated at 2022-06-20 19:52:46.468362
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import doctest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    import ansible.module_utils.facts.utils

    module = ansible.module_utils.facts.utils.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    platform_fact_collector = PlatformFactCollector(module=module)
    assert len(platform_fact_collector.collect()) == 6

    platform_fact_collector = PlatformFactCollector(module)
    platform_facts = platform_fact_collector.collect()
