

# Generated at 2022-06-20 19:43:43.128684
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector_obj = PlatformFactCollector()
    output = PlatformFactCollector_obj.collect()
    assert 'system' in output.keys()
    assert output['system'] == 'Linux'

# Generated at 2022-06-20 19:43:52.714495
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def mock_python_version():
        return '2.6.6'
    def mock_system():
        return 'Linux'
    def mock_release():
        return '2.6.32-71.el6.x86_64'
    def mock_version():
        return '#1 SMP Tue Mar 22 18:03:27 UTC 2011'
    def mock_machine():
        return 'x86_64'
    def mock_node():
        return 'test-node'
    def mock_getfqdn():
        return 'test-node.example.net'
    def mock_architecture():
        return ('64bit', 'ELF')
    def mock_uname():
        return ('OpenBSD', 'foo', '5.4', 'GENERIC.MP', 'amd64')

    original_python_version = platform

# Generated at 2022-06-20 19:43:53.284399
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-20 19:44:00.237104
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    print(x)
    assert x.name == "platform"
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-20 19:44:05.820120
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-20 19:44:10.314707
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_obj = PlatformFactCollector()
    assert platform_facts_obj.name == 'platform'
    assert platform_facts_obj._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])


# Generated at 2022-06-20 19:44:22.170122
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Retrieve facts using PlatformFactCollector
    """

    class MockModule():
        @staticmethod
        def run_command(args, check_rc=True):
            if args[1] == 'MACHINE_ARCHITECTURE':
                return 0, "powerpc_rs64", ""

        @staticmethod
        def get_bin_path(arg):
            if arg == 'getconf':
                return "/usr/bin/getconf"
            elif arg == 'bootinfo':
                return "/usr/sbin/bootinfo"

    MockModule.platform = platform
    MockModule.socket = socket


# Generated at 2022-06-20 19:44:28.660112
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    expected_fact_ids = frozenset(['system', 'kernel',
                                   'kernel_version', 'machine',
                                   'python_version', 'architecture',
                                   'machine_id', 'fqdn', 'hostname',
                                   'nodename', 'domain', 'userspace_bits',
                                   'userspace_architecture'])
    p = PlatformFactCollector()
    assert p.collect() is not None
    assert p._fact_ids == expected_fact_ids

# Generated at 2022-06-20 19:44:30.191180
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.name == "platform"


# Generated at 2022-06-20 19:44:35.179998
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:45:20.608350
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert 'platform' == PlatformFactCollector.name

# Generated at 2022-06-20 19:45:30.228104
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create fact object
    fact = PlatformFactCollector()

    # test collect method with system Linux
    platform.system = lambda: 'Linux'
    fact_collect = fact.collect()
    assert fact_collect == {'fqdn': 'localhost.localdomain', 'nodename': 'localhost.localdomain', 'architecture': 'x86_64', 'hostname': 'localhost', 'machine': 'x86_64', 'system': 'Linux', 'domain': 'localdomain', 'userspace_architecture': 'x86_64', 'kernel': 'ansible-test-kernel', 'kernel_version': 'ansible-test-kernel', 'python_version': '2.7.5'}

    # test collect method with system Windows
    platform.system = lambda: 'Windows'

# Generated at 2022-06-20 19:45:31.805790
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()

    assert obj.name == 'platform'

# Generated at 2022-06-20 19:45:42.585133
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    result = platform_collector.collect()

    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()
    assert result['domain'] == '.'.join(result['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()[0]

# Generated at 2022-06-20 19:45:53.183051
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]

    platform_facts['userspace_bits'] = arch_bits.replace('bit', '')
   

# Generated at 2022-06-20 19:45:57.163511
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    This is a test for the PlatformFactCollector class.
    '''

    from ansible.module_utils.facts.collector import BaseFactCollector

    pf = PlatformFactCollector()
    assert isinstance(pf, BaseFactCollector)
    assert hasattr(pf, 'name')
    assert hasattr(pf, '_fact_ids')
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])



# Generated at 2022-06-20 19:46:02.806020
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    foo = PlatformFactCollector()
    assert foo.name == 'platform'
    assert foo._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:46:06.285939
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import Collector
    x = Collector()
    assert isinstance(x, Collector)
    assert isinstance(x, PlatformFactCollector)

# Generated at 2022-06-20 19:46:10.256583
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-20 19:46:15.950466
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = dict(
        system='Linux',
        kernel='3.10.0-862.14.4.el7.x86_64',
        kernel_version='#1 SMP Tue Aug 14 21:49:04 UTC 2018',
        machine='x86_64',
        python_version='2.7.5',
        fqdn='bogus.example.com',
        nodename='bogus.example.com',
        domain='example.com',
        userspace_bits='64',
        architecture='x86_64',
        userspace_architecture='x86_64',
        machine_id='0e7f1159c9594a7f8cfb35e1f3d3f863'
    )

    expected = dict(
        platform=platform_facts
    )


# Generated at 2022-06-20 19:47:04.821748
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'

# Generated at 2022-06-20 19:47:11.815384
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """ This function instantiates the PlatformFactCollector class
        and collects platform facts.
    """
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    print(platform_facts)

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-20 19:47:15.200103
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    facts = collector.collect(None, None)

    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'userspace_bits' in facts
    assert 'architecture' in facts
    assert 'python_version' in facts

# Generated at 2022-06-20 19:47:20.396061
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                               'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:47:21.544345
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'

# Generated at 2022-06-20 19:47:32.269009
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    collector = PlatformFactCollector()
    facts_dict = {'system': 'Darwin', 'kernel': '15.6.0', 'kernel_version': 'Darwin Kernel Version 15.6.0: Mon Jan 23 18:52:52 PST 2017; root:xnu-3248.60.11~1/RELEASE_X86_64', 'machine': 'x86_64', 'python_version': '2.7.3', 'fqdn': 'MacBook-Pro-de-Toto.local', 'hostname': 'MacBook-Pro-de-Toto', 'nodename': 'MacBook-Pro-de-Toto', 'domain': 'local', 'userspace_bits': '64', 'userspace_architecture': 'x86_64', 'architecture': 'x86_64'}

    assert collector.collect()

# Generated at 2022-06-20 19:47:32.752608
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass

# Generated at 2022-06-20 19:47:37.755783
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:47:49.955711
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command = lambda params: ({u'rc': 0, u'out': "sparc", u'err': ''}, True)
    platform_collector = PlatformFactCollector()
    facts = platform_collector.collect(module=mock_module)

    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['fqdn'] == socket.getfqdn()
    assert facts['hostname'] == platform.node().split('.')[0]
    assert facts['nodename'] == platform.node()

# Generated at 2022-06-20 19:48:01.492469
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-20 19:50:12.190193
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector.collect()['python_version'] == platform.python_version()

# Generated at 2022-06-20 19:50:13.576854
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    assert collector.collect()["system"] == platform.system()

# Generated at 2022-06-20 19:50:18.267468
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id',
                               'fqdn',
                               'hostname',
                               'nodename',
                               'domain'])

# Generated at 2022-06-20 19:50:22.208246
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    fact_collector.collect()
    for i in fact_collector.facter():
        print(fact_collector.facter[i])

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-20 19:50:29.157625
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:50:33.196401
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts["system"] == platform.system()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["python_version"] == platform.python_version()

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-20 19:50:42.359127
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def get_bin_path(self, name):
            return None

    mock_fact_collector = PlatformFactCollector()
    mock_module = MockModule()
    result = mock_fact_collector.collect(mock_module)

    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()

    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()


# Generated at 2022-06-20 19:50:44.492399
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    m = {}
    p = PlatformFactCollector(m)
    result = p.collect()
    print(result)

# Generated at 2022-06-20 19:50:46.874696
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), BaseFactCollector)


# Generated at 2022-06-20 19:50:50.049982
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'
    assert 'system' in platformFactCollector._fact_ids
    assert 'kernel' in platformFactCollector._fact_ids
    assert 'kernel_version' in platformFactCollector._fact_ids