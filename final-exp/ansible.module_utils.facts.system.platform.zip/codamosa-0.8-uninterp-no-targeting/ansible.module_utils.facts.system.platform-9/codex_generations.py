

# Generated at 2022-06-20 19:43:50.542226
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes

    test_collector = Collector()
    test_collector.collect_platform_facts = PlatformFactCollector().collect
    # Create a fake module
    module = type('FakeModule', (), {'get_bin_path': lambda s, p: None})

    # Create a fake ansible module
    set_module_args = type('FakeModuleArgs', (), {
        'set_fact': lambda self, **kwargs: None,
    })

# Generated at 2022-06-20 19:43:52.629748
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None
    assert 'machine_id' in platform_fact_collector._fact_ids

# Generated at 2022-06-20 19:44:03.244507
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    # Test name property
    assert pfc.name == 'platform'
    # Test _fact_ids property
    assert pfc._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}
    # Test collect() method

# Generated at 2022-06-20 19:44:10.201365
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test class PlatformFactCollector:
    Method collect.
    """
    # Build a mock module
    module = AnsibleModule(argument_spec={})
    # Build a mock set of collected facts
    collected_facts = {}
    # Instantiate the PlatformFactCollector object
    platform_fact_collector = PlatformFactCollector()
    # Call method collect of the PlatformFactCollector object
    facts = platform_fact_collector.collect(module=module, collected_facts=collected_facts)
    # Check that the facts dictionary is not empty
    assert len(facts) > 0


# Generated at 2022-06-20 19:44:23.619318
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test PlatformFactCollector.collect()
    """


# Generated at 2022-06-20 19:44:29.988515
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'hostname' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'domain' in platform_facts

# Generated at 2022-06-20 19:44:36.250808
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system',
                                                 'kernel',
                                                 'kernel_version',
                                                 'machine',
                                                 'python_version',
                                                 'architecture',
                                                 'machine_id'}


# Generated at 2022-06-20 19:44:43.722613
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    platform_facts = PlatformFactCollector().collect(None, {})
    assert platform_facts.keys() == set(['system',
                                         'kernel',
                                         'kernel_version',
                                         'machine',
                                         'python_version',
                                         'architecture',
                                         'fqdn',
                                         'hostname',
                                         'nodename',
                                         'domain',
                                         'userspace_bits'])

test_PlatformFactCollector_collect()

# Generated at 2022-06-20 19:44:53.710498
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform as py_platform
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def get_bin_path(self, arg):
            return None

    class FakePopen(object):
        def __init__(self, arg, shell=True):
            pass

        def communicate(self):
            return (None, None)

    fake_module = FakeModule()
    collected_facts = {}

    if not py_platform.system() in ('Linux', 'Java'):
        setattr(py_platform, 'uname', lambda: ('', '', '', '',
                                               'x86_64', '', '', '', ''))

    # Actual facts from platform.

# Generated at 2022-06-20 19:45:02.484180
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    data = [
        'Linux', '4.4.0-59-generic', '#80-Ubuntu SMP Fri Jan 6 17:47:47 UTC 2017', 'x86_64',
        'x86_64', 'GNU/Linux', ''
    ]
    data = ' '.join(data)

    class MockModule(object):
        def __init__(self):
            self.params = None

        @staticmethod
        def fail_json(*args, **kwargs):
            pass

        @staticmethod
        def get_bin_path(arg):
            return '/bin/%s' % arg

        @staticmethod
        def run_command(arg):
            return 0, data, ''

    module = MockModule()
    platform_facts = PlatformFactCollector(module=module)
    platform_facts_result = platform_

# Generated at 2022-06-20 19:45:40.024270
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()

    assert 'system' in collector.fact_ids

    assert collector.name == 'platform'

# Generated at 2022-06-20 19:45:48.260037
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    # Test that the name of the class is Platform
    assert pfc.name == 'platform'
    # Test that the _fact_ids are correct
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids


# Generated at 2022-06-20 19:45:52.710064
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id'])



# Generated at 2022-06-20 19:45:59.479284
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert isinstance(fact_collector, BaseFactCollector)
    assert hasattr(fact_collector, '_fact_ids')
    assert isinstance(fact_collector._fact_ids, set)
    assert set(['system', 'kernel', 'kernel_version', 'machine',
                'python_version', 'architecture', 'machine_id']) == fact_collector._fact_ids
    assert hasattr(fact_collector, 'name')
    assert isinstance(fact_collector.name, str)
    assert fact_collector.name == 'platform'

# Generated at 2022-06-20 19:46:04.216662
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts import FactCollector
    fact_collector = FactCollector()
    collector = PlatformFactCollector(None)
    collector.collect(fact_collector)

    assert 'platform' in [k.name for k in fact_collector.fact_classes]

# Generated at 2022-06-20 19:46:09.704415
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect()

    assert 'machine' in platform_facts
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'nodename' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'hostname' in platform_facts

# Generated at 2022-06-20 19:46:12.441150
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    Unit test for method collect of class PlatformFactCollector
    '''
    collector = PlatformFactCollector()
    platform_facts = collector.collect()
    assert isinstance(platform_facts, dict)
    assert platform_facts['python_version'] == platform.python_version()

# Generated at 2022-06-20 19:46:13.264651
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-20 19:46:15.712724
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector()
    assert result is not None

# Generated at 2022-06-20 19:46:26.930854
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    expected_results = {
        "architecture": "x86_64",
        "fqdn": "localhost.localdomain",
        "kernel": "2.6.32-431.el6.x86_64",
        "kernel_version": "#1 SMP Fri Nov 22 03:15:09 UTC 2013",
        "machine": "x86_64",
        "nodename": "localhost.localdomain",
        "system": "Linux"
    }

    class TestModule(object):
        def get_bin_path(self, arg):
            return None

        def run_command(self, arg):
            return None

    collector = PlatformFactCollector()
    results = collector.collect(TestModule())

    assert results == expected_results

# Generated at 2022-06-20 19:47:44.446676
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name is not None
    assert obj._fact_ids is not None
    assert len(obj._fact_ids) is 8

# Generated at 2022-06-20 19:47:49.572352
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])
    assert platform_fact_collector.collect() == platform.uname()

# Generated at 2022-06-20 19:47:54.943448
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class Platform:
        pass
    setattr(Platform, 'system', lambda: 'Windows')
    setattr(Platform, 'release', lambda: '10')
    setattr(Platform, 'version', lambda: '6.3.9600')
    setattr(Platform, 'machine', lambda: 'x86_64')
    setattr(Platform, 'python_version', lambda: '3.4.1')
    setattr(Platform, 'architecture', lambda: ('64bit', ''))
    setattr(Platform, 'node', lambda: 'foo.example.com')

    platform.uname = lambda: ('', '', '', '', 'x86_64')
    platform.system = lambda: Platform.system()
    platform.release = lambda: Platform.release()
    platform.version = lambda: Platform.version()
    platform.machine

# Generated at 2022-06-20 19:48:00.574714
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:48:01.738744
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == "platform"

# Generated at 2022-06-20 19:48:11.087692
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModule(argument_spec={
        'filter': {'default': 'kernel_version,system'}
    })

    platform_fact_collector = PlatformFactCollector()
    facts = platform_fact_collector.collect(module=module)

    assert facts['machine_id']
    assert facts['system']
    assert facts['kernel']
    assert facts['kernel_version']
    assert facts['machine']
    assert facts['python_version']
    assert facts['architecture']
    assert facts['userspace_bits']
    assert facts['userspace_architecture']



# Generated at 2022-06-20 19:48:21.629450
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    # Create object instance
    platform_facts_collector = PlatformFactCollector()
    # Get collector result
    result = platform_facts_collector.collect()
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()
    assert result['domain'] == '.'.join(result['fqdn'].split('.')[1:])
    # On some distributions the architecture() returned value may not have

# Generated at 2022-06-20 19:48:31.953283
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()

    assert platform_facts['python_version'] == platform.python_version()

    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()

    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]
    userspace_bits = arch_

# Generated at 2022-06-20 19:48:33.746327
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()

# Generated at 2022-06-20 19:48:41.510068
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup
    platform = PlatformFactCollector()
    collected_facts = {"ansible_system": "", "ansible_kernel": "", "ansible_machine": "", "ansible_python_version": "", "ansible_architecture": "", "ansible_machine_id": ""}

    # Exercise
    platform_facts = platform.collect(collected_facts=collected_facts)

    # Verify
    assert platform_facts["ansible_system"] == platform.collect()["system"]
    assert platform_facts["ansible_kernel"] == platform.collect()["kernel"]
    assert platform_facts["ansible_kernel_version"] == platform.collect()["kernel_version"]
    assert platform_facts["ansible_machine"] == platform.collect()["machine"]

# Generated at 2022-06-20 19:51:35.047667
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collected_facts = {}
    platform_collector = PlatformFactCollector()
    platform_collector.collect(collected_facts=collected_facts)

# Generated at 2022-06-20 19:51:40.662905
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])
    return pf


# Generated at 2022-06-20 19:51:42.510761
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Call PlatformFactCollector with module to get platform facts
    assert PlatformFactCollector.__init__

# Generated at 2022-06-20 19:51:46.876251
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create instance of class PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()

    # Check that required attributes exist
    assert platform_fact_collector.name == "platform"
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:51:54.477030
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:52:05.413262
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()

    # Add fake user and group info
    #
    # Special note on the user and group ids. Certain id's are considered
    # illegal. See the implementation of the module 'pwd' for more details.
    # http://docs.python.org/2/library/pwd.html
    #
    # Since this set of test data can be considered static, the ids are not
    # actually random. They are chosen to not be considered illegal ids.

# Generated at 2022-06-20 19:52:06.957434
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), PlatformFactCollector), 'PlatformFactCollector is an instance of PlatformFactCollector'


# Generated at 2022-06-20 19:52:16.824175
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import platform
    import socket

    os_system = platform.system()
    os_release = platform.release()
    os_version = platform.version()
    os_machine = platform.machine()
    python_version = platform.python_version()
    fqdn = socket.getfqdn()
    nodename = platform.node()

    assert os_system
    assert os_release
    assert os_version
    assert os_machine
    assert python_version
    assert fqdn
    assert nodename

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    collector = PlatformFactCollector(module=module)


# Generated at 2022-06-20 19:52:26.956049
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    result = fact_collector.collect()
    assert result
    assert result["system"] == "Linux"
    assert result["kernel"] == "3.13.0-40-generic"
    assert result["machine"] == "x86_64"
    assert result["python_version"] == "2.7.6"
    assert result["fqdn"] == "vagrant-ubuntu-trusty-64.vagrantup.com"
    assert result["hostname"] == "vagrant-ubuntu-trusty-64"
    assert result["nodename"] == "vagrant-ubuntu-trusty-64.vagrantup.com"
    assert result["userspace_bits"] == "64"
    assert result["domain"] == "vagrantup.com"
    assert result["architecture"]

# Generated at 2022-06-20 19:52:36.066436
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    expected_fact_ids = 'architecture', 'fqdn', 'hostname', 'machine', 'machine_id', 'nodename', 'python_version', 'domain', 'kernel', 'kernel_version', 'system', 'userspace_architecture', 'userspace_bits'

    pfc = PlatformFactCollector()
    fact_ids = pfc._fact_ids
    assert isinstance(fact_ids, set)
    assert 'kernel_version' in fact_ids
    assert 'architecture' in fact_ids
    # check if all expected ids are in the set
    for expected_fact_id in expected_fact_ids:
        assert expected_fact_id in fact_ids
    # check if all fact_ids are expected ids
    for fact_id in fact_ids:
        assert fact_id in expected_fact