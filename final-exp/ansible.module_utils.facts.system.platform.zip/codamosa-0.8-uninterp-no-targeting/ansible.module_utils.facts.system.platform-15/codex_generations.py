

# Generated at 2022-06-20 19:43:47.398238
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform', 'Test PlatformFactCollector constructor#1 has failed!'
    assert set(sorted(platform_fact_collector._fact_ids)) == set(sorted(['system', 'kernel', 'kernel_version', 'machine',
                                                                         'python_version', 'architecture', 'machine_id'])) \
           , 'Test PlatformFactCollector constructor#2 has failed!'


# Generated at 2022-06-20 19:43:48.506318
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-20 19:43:55.550038
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a stub for a module object
    class ModuleStub():
        def get_bin_path(self, arg):
            return "get_bin_path(arg)"

        def run_command(self, arg):
            print("run_command(arg)")

    collector = PlatformFactCollector()
    module = ModuleStub()
    result = collector.collect(module=module)
    assert result

    # Verify correct 'machine_id' result
    # id_path = "/var/lib/dbus/machine-id"
    # if os.path.exists(id_path):
    #     expected_id = ''.join(open(id_path, 'r').readlines()).strip()
    #     assert result['machine_id'] == expected_id
    # else:
    #     assert "machine_id" not

# Generated at 2022-06-20 19:43:59.537368
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert isinstance(PlatformFactCollector.name, str)
    assert PlatformFactCollector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-20 19:44:01.042647
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # This method is tested via the setup and ansible modules,
    # as it is used in both
    pass

# Generated at 2022-06-20 19:44:05.943281
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:44:13.228519
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    architecture_bits = platform.architecture()[0]
    assert platform_facts['userspace_bits'] == architecture_bits.replace('bit', '')

# Generated at 2022-06-20 19:44:18.330624
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.name == 'platform'
    assert platform._fact_ids == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])

# Generated at 2022-06-20 19:44:20.565843
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert set(p.collect().keys()) == p._fact_ids

# Generated at 2022-06-20 19:44:30.272918
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert issubclass(pfc.__class__, BaseFactCollector)
    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids
    assert 'fqdn' in pfc._fact_ids
    assert 'hostname' in pfc._fact_ids
    assert 'nodename' in pfc._fact_ids
    assert 'domain' in pfc._fact_ids
    assert 'userspace_bits' in pfc._fact_ids

# Generated at 2022-06-20 19:45:16.116966
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    Unit test for constructor of class PlatformFactCollector
    '''
    obj = PlatformFactCollector()
    assert obj.name == "platform", "Name of PlatformFactCollector should be 'platform'"
    assert obj.collect()["python_version"] == platform.python_version(), "Python version should be equal to: %s" % platform.python_version()

# Generated at 2022-06-20 19:45:18.549665
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:45:25.201548
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                           'kernel',
                           'kernel_version',
                           'machine',
                           'python_version',
                           'architecture',
                           'machine_id'])

# Generated at 2022-06-20 19:45:28.296476
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'system' in x._fact_ids
    assert 'kernel' in x._fact_ids
    assert 'machine' in x._fact_ids
    assert 'architecture' in x._fact_ids

# Generated at 2022-06-20 19:45:40.449049
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    import sys
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.settings import Settings

    test_instance = PlatformFactCollector(BaseFactCollector)
    assert isinstance(test_instance, PlatformFactCollector)

    test_instance = PlatformFactCollector(BaseFactCollector, Settings())
    assert isinstance(test_instance, PlatformFactCollector)
    assert test_instance.name == 'platform'
    assert test_instance._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    ])

    assert 'platform' in collector

# Generated at 2022-06-20 19:45:50.270452
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # platform.system() can be Linux, Darwin, Java, or Windows
    platform_system = platform.system()
    platform_kernel = platform.release()
    platform_kernel_version = platform.version()
    platform_machine = platform.machine()

    platform_python_version = platform.python_version()

    fqdn = socket.getfqdn()
    hostname = platform.node().split('.')[0]
    nodename = platform.node()

    domain = '.'.join(fqdn.split('.')[1:])

    arch_bits = platform.architecture()[0]

    userspace_bits = arch_bits.replace('bit', '')
    architecture = platform_machine
    userspace_architecture = platform_machine
    if platform_machine == 'x86_64':
        architecture = platform_

# Generated at 2022-06-20 19:45:54.396807
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert platform_obj.name == 'platform'
    assert platform_obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:46:04.716648
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test with only one fact
    fct = PlatformFactCollector()
    fct._fact_ids = set(['system'])
    result = fct.collect()
    assert 'system' in result

    # Test with two facts
    fct = PlatformFactCollector()
    fct._fact_ids = set(['system', 'kernel_version'])
    result = fct.collect()
    assert 'system' in result
    assert 'kernel_version' in result

    # Test all facts
    fct = PlatformFactCollector()
    result = fct.collect()
    for fact_name in fct._fact_ids:
        assert fact_name in result

# Generated at 2022-06-20 19:46:12.817252
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    facts = dict()
    section_to_add = 'platform'

# Generated at 2022-06-20 19:46:20.948307
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    Returns platform facts for unit test.
    """

    platform_fact_collector = PlatformFactCollector()

    platform_facts = platform_fact_collector.collect()

    # Basic validations
    # FIXME: Move assertions to test_platform.py
    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['machine']
    assert platform_facts['architecture']
    assert platform_facts['kernel_version']
    assert platform_facts['python_version']

# Generated at 2022-06-20 19:47:42.168730
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = type('AnsibleModule', (), dict())
    mock_module.get_bin_path = lambda self, arg: None
    mock_module.run_command = lambda self, arg: (0, '', '')
    platform_collector = PlatformFactCollector()
    result = platform_collector.collect(mock_module)
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()

# Generated at 2022-06-20 19:47:46.893506
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert set(x._fact_ids) == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])

# Generated at 2022-06-20 19:47:51.880689
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id',
        'fqdn',
        'hostname',
        'nodename',
        'domain',
        'userspace_bits',
        'userspace_architecture',
        ])

# Generated at 2022-06-20 19:47:56.499211
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:48:03.028833
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Ensure collect returns a dictionary containing the expected values
    """
    platform_collector = PlatformFactCollector()
    collected_facts = platform_collector.collect()
    assert 'system' in collected_facts
    assert 'kernel' in collected_facts
    assert 'kernel_version' in collected_facts
    assert 'machine' in collected_facts
    assert 'python_version' in collected_facts
    assert 'architecture' in collected_facts
    assert 'machine_id' in collected_facts

# Generated at 2022-06-20 19:48:05.879992
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert(PlatformFactCollector().name == "platform")


# Generated at 2022-06-20 19:48:17.065551
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    #Override the method platform.machine() for the unit test
    def machine(self):
        return self._machine

    def version(self):
        return self._version

    platform.machine = machine
    platform.version = version
    #Create an instance of PlatformFactCollector
    pfc = PlatformFactCollector()
    #Define a dict of platform facts

# Generated at 2022-06-20 19:48:20.069524
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector({})
    ret = pfc.collect()
    assert isinstance(ret, dict)
    assert ret['system'] == platform.system()
    assert ret['machine'] == platform.machine()

# Generated at 2022-06-20 19:48:27.817298
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    os_platform = platform.system()
    os_version = platform.release()

    collector = PlatformFactCollector()
    facts = collector.collect(module=None, collected_facts=None)
    assert facts["ansible_facts"]["system"] == os_platform
    assert facts["ansible_facts"]["kernel"] == os_version
    assert facts["ansible_facts"]["kernel_version"] == platform.version()
    assert facts["ansible_facts"]["machine"] == platform.machine()

# Generated at 2022-06-20 19:48:29.941025
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert "system" in x._fact_ids
    assert "architecture" in x._fact_ids
    assert "machine_id" in x._fact_ids

# Generated at 2022-06-20 19:51:35.217392
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())
    fake_platform = {
        'system': 'Linux',
        'release': '2.6.32-431.el6.x86_64',
        'version': '#1 SMP Fri Nov 22 03:15:09 UTC 2013',
        'machine': 'x86_64',
        'python_version': '2.6.6',
        'node': 'ci-ansible-test-2',
    }
    module.run_command = Mock(return_value=(0, '', ''))

# Generated at 2022-06-20 19:51:45.172285
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    platform_facts = PlatformFactCollector.collect()
    print("platform_facts = ")
    print(platform_facts)
    assert platform_facts
    assert platform_facts.get("system") == platform.system()
    assert platform_facts.get("kernel") == platform.release()
    assert platform_facts.get("kernel_version") == platform.version()
    assert platform_facts.get("machine") == platform.machine()
    assert platform_facts.get("python_version") == platform.python_version()
    assert platform_facts.get("fqdn") == socket.getfqdn()
    assert platform_facts.get("hostname") == platform.node().split('.')[0]

# Generated at 2022-06-20 19:51:50.470744
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = __import__("ansible.module_utils.facts.system.platform.PlatformFactCollector", fromlist=['object']).PlatformFactCollector
    platform_facts = dict()
    collect_result = PlatformFactCollector().collect(collected_facts=platform_facts)
    assert 'system' in collect_result
    assert 'kernel' in collect_result
    assert 'kernel_version' in collect_result
    assert 'machine' in collect_result
    assert 'python_version' in collect_result
    assert 'architecture' in collect_result
    assert 'machine_id' in collect_result
    assert 'fqdn' in collect_result
    assert 'hostname' in collect_result
    assert 'nodename' in collect_result
    assert 'domain' in collect_result

# Generated at 2022-06-20 19:51:55.713238
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == "platform"
    assert set(x._fact_ids) == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])

# Generated at 2022-06-20 19:51:57.351354
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.__class__.__name__ == 'PlatformFactCollector'

# Generated at 2022-06-20 19:52:03.159990
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-20 19:52:05.314849
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert pfc.name == 'platform'

# Generated at 2022-06-20 19:52:08.319635
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])



# Generated at 2022-06-20 19:52:17.877656
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import sys

    if sys.version_info[:2] == (2, 6):
        # The object returned by platform.uname() changed between Python 2.6 and
        # Python 2.7 (Python 2.6 only returned the first five elements).  This
        # causes problems with the unit test, so we'll use our own mock uname
        # value that happens to be from a machine running Python 2.6
        platform.uname = (lambda: ('Linux', 'bar', '2.6.32-504.12.2.el6.x86_64',
                                   '#1 SMP Wed Apr 22 06:48:29 UTC 2015',
                                   'x86_64', 'x86_64'))

    module_mock = MockModuleUtilsModule()
    module_mock.run_command.return_value

# Generated at 2022-06-20 19:52:21.902932
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''Unit test for constructor of class PlatformFactCollector'''
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
