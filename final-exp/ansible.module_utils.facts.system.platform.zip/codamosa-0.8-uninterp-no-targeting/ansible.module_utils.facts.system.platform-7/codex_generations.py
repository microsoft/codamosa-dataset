

# Generated at 2022-06-20 19:43:50.668011
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import socket
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    class PlatformFactCollectorMock(BaseFactCollector):
        name = 'platform'
        _fact_ids = {'system',
             'kernel',
             'kernel_version',
             'machine',
             'python_version',
             'architecture',
             'machine_id'}

        def collect():
            platform_facts = {}
            platform_facts['system'] = platform.system()
            platform_facts['kernel'] = platform.release()
            platform_facts['kernel_version'] = platform.version()
            platform_facts['machine'] = platform.machine()

            platform_facts['python_version'] = platform.python_version

# Generated at 2022-06-20 19:44:01.204533
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    import types

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    class FakeModule(object):
        def __init__(self, platform, arch):
            self.platform = platform
            self.arch = arch
            self.path = None
            self.getpid_return = 42

        def get_bin_path(self, executable):
            return '/usr/bin/{0}'.format(executable)

        def run_command(self, args):
            if self.platform == 'Linux':
                if args[0] in ('/usr/bin/getconf', '/usr/bin/arch'):
                    return (0, self.arch, '')

# Generated at 2022-06-20 19:44:07.003320
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_object = PlatformFactCollector()
    assert platform_object.platform == platform
    assert platform_object.name == 'platform'
    assert platform_object._fact_ids ==  {'system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id'}


# Generated at 2022-06-20 19:44:13.690733
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a collector object
    pfc = PlatformFactCollector()

    # Set the facts to be gathered
    fact_name = 'system'
    pfc._fact_ids.add(fact_name)
    fact_name = 'kernel'
    pfc._fact_ids.add(fact_name)
    fact_name = 'kernel_version'
    pfc._fact_ids.add(fact_name)
    fact_name = 'machine'
    pfc._fact_ids.add(fact_name)
    fact_name = 'python_version'
    pfc._fact_ids.add(fact_name)
    fact_name = 'architecture'
    pfc._fact_ids.add(fact_name)
    fact_name = 'machine_id'

# Generated at 2022-06-20 19:44:24.857347
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.utils import mock_uname
    from ansible.module_utils.facts.utils import MockFile

    # Create the mocks
    m_module = mock_module()
    m_uname = mock_uname()

    # Enable the side effect of get_file_content on
    # /var/lib/dbus/machine-id and /etc/machine-id
    m_file_dbus_machine_id = MockFile({'content': 'mocked_dbus_machine_id'})
    m_file_etc_machine_id = MockFile({'content': 'mocked_etc_machine_id'})

# Generated at 2022-06-20 19:44:26.159561
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector

# Generated at 2022-06-20 19:44:29.782112
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()

    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-20 19:44:33.256961
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector.fact_ids == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])


# Generated at 2022-06-20 19:44:42.919763
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Unit test to check PlatformFactCollector
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'machine_id' in p._fact_ids
    assert not hasattr(p, 'data')
    assert not hasattr(p, 'module')
    assert not hasattr(p, 'collected_facts')
    assert not hasattr(p, 'warnings')

# Generated at 2022-06-20 19:44:44.924567
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # This should not raise anything
    PlatformFactCollector()

# Generated at 2022-06-20 19:45:40.623459
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform
    from ansible.module_utils.facts import collector

    class DummyModule(object):
        def __init__(self):
            self.params = dict()
            self.fail_json = dict()

        def get_bin_path(self, executable):
            return ""

        def run_command(self, command):
            return 0, "", ""

    module = DummyModule()
    fact_collector = PlatformFactCollector()
    fact_collector.collect(module)

    assert fact_collector.name == 'platform'

# Generated at 2022-06-20 19:45:50.404685
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class MockModule():
        def __init__(self):
            self.run_command_line_count = 0
            self.run_command_line_exits = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            self.run_command_line_stdouts = [
                """
                x86_64
                """,
                """
                hello world
                """,
            ]

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd):
            self.run_command_line_count += 1

# Generated at 2022-06-20 19:45:57.998412
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    from ansible.module_utils.facts import collector

    # Create a PlatformFactCollector instance
    pfc = PlatformFactCollector(None)

    # Perform some minimal test asserts
    assert pfc.name == 'platform'
    assert pfc.collect(None) is not None
    assert pfc.collect(None).get('system') is not None
    assert pfc.collect(None).get('kernel') is not None
    assert pfc.collect(None).get('architecture') is not None
    assert pfc.collect(None).get('python_version') == sys.version.split(' ', 1)[0]

# Generated at 2022-06-20 19:46:04.418563
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:46:09.549558
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-20 19:46:17.294713
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        import_path = 'ansible.module_utils.facts.collectors.platform.PlatformFactCollector'
        p = PlatformFactCollector()
        assert p._fact_ids == {'architecture', 'machine_id', 'system', 'kernel', 'machine', 'nodename', 'hostname',
                               'kernel_version', 'domain', 'python_version', 'userspace_bits', 'fqdn', 'userspace_architecture'}
        assert p.name == 'platform'
    except TypeError:
        print('%s not installed' % import_path)
        raise

# Generated at 2022-06-20 19:46:28.757776
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestModule(object):
        def get_bin_path(self, arg1, arg2=None, arg3=None):
            return None

        def run_command(self, arg1, arg2=None, arg3=None):
            return None

    platform_facts = PlatformFactCollector()
    facts = platform_facts.collect(TestModule())

    assert facts['architecture'] == 'x86_64'
    assert facts['machine'] == 'x86_64'
    assert facts['kernel'] == '5.5.5-200.fc31.x86_64'
    assert facts['kernel_version'] == '#1 SMP Wed May 6 16:47:39 UTC 2020'
    assert facts['system'] == 'Linux'
    assert facts['python_version'] == '3.6.6'

# Generated at 2022-06-20 19:46:34.764682
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'system' in x._fact_ids
    assert 'kernel' in x._fact_ids
    assert 'machine' in x._fact_ids
    assert 'python_version' in x._fact_ids
    assert 'architecture' in x._fact_ids
    assert 'machine_id' in x._fact_ids

# Generated at 2022-06-20 19:46:39.856204
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform', pf.name
    assert pf._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id']), pf._fact_ids

# Generated at 2022-06-20 19:46:43.840382
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:48:21.256476
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-20 19:48:27.202590
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts import FactCollector,FactCache
    fact_collector = FactCollector(None, None, None)
    fact_cache = FactCache()

    platform_fact = PlatformFactCollector(fact_collector, fact_cache)
    assert platform_fact.name == 'platform'

test_PlatformFactCollector()

# Generated at 2022-06-20 19:48:34.741512
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create an instance of PlatformFactCollector
    platform_fact_collector_instance = PlatformFactCollector()

    # Test collect method of PlatformFactCollector
    collected_facts = platform_fact_collector_instance.collect()

    assert collected_facts["system"] == platform.system()
    assert collected_facts["kernel"] == platform.release()
    assert collected_facts["kernel_version"] == platform.version()
    assert collected_facts["machine"] == platform.machine()
    assert collected_facts["python_version"] == platform.python_version()
    assert collected_facts["fqdn"] == socket.getfqdn()
    assert collected_facts["hostname"] == platform.node().split('.')[0]
    assert collected_facts["nodename"] == platform.node()

# Generated at 2022-06-20 19:48:35.855440
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-20 19:48:37.094859
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact = PlatformFactCollector()
    assert isinstance(fact.collect(), dict)

# Generated at 2022-06-20 19:48:42.186545
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Returns ansible_facts from PlatformFactCollector.collect method
    """
    PlatformFactCollector_collect = PlatformFactCollector().collect()
    assert PlatformFactCollector_collect is not None
    assert 'system' in PlatformFactCollector_collect
    assert 'kernel' in PlatformFactCollector_collect
    assert 'kernel_version' in PlatformFactCollector_collect
    assert 'machine' in PlatformFactCollector_collect
    assert 'python_version' in PlatformFactCollector_collect
    assert 'architecture' in PlatformFactCollector_collect
    assert 'machine_id' in PlatformFactCollector_collect

# Generated at 2022-06-20 19:48:52.246486
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform

    platform_facts = {}

    # Mock module
    class MockModule(object):
        def __init__(self):
            self.run_command = lambda self: (0, "", "")
            self.get_bin_path = lambda self: None

    # Mock platform
    class MockPlatform(object):
        def __init__(self):
            self.system = lambda self: "Linux"
            self.release = lambda self: "2.6.32-504.8.1.el6.x86_64"
            self.version = lambda self: "#1 SMP Wed Oct 15 04:27:16 UTC 2014"
            self.machine = lambda self: "x86_64"
            self.python_version = lambda self: "2.7.8"

# Generated at 2022-06-20 19:48:59.251828
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-20 19:49:05.010522
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    platform_facts = PlatformFactCollector.collect()
    assert "platform" in platform_facts
    assert "system" in platform_facts["platform"]
    assert "kernel" in platform_facts["platform"]
    assert "machine" in platform_facts["platform"]
    assert "python_version" in platform_facts["platform"]
    assert "architecture" in platform_facts["platform"]

# Generated at 2022-06-20 19:49:15.680741
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def get_bin_path(name):
            return
        def run_command(args):
            if "bootinfo -p" in args:
                return (0, "ppc64", "")
            elif "getconf MACHINE_ARCHITECTURE" in args:
                return (0, "powerpc64", "")
            return (0, "", "")

    class MockFactCollector(PlatformFactCollector):
        def __init__(self):
            self._module_facts = {}
        def collect(self, module, collected_facts):
            self._module_facts = super(MockFactCollector, self).collect(module, collected_facts)

    module = MockModule()

    collector = MockFactCollector()
    collector.collect(module, {})

    # Verifying platform

# Generated at 2022-06-20 19:52:37.164737
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:52:42.222751
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert set(x._fact_ids) == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])

# Generated at 2022-06-20 19:52:50.435078
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    class_instance = PlatformFactCollector()
    collected_facts = class_instance.collect(module=module)
    assert collected_facts['architecture'] == 'x86_64'
    assert collected_facts['domain'] == 'vm.local'
    assert collected_facts['fqdn'] == 'localhost.vm.local'
    assert collected_facts['hostname'] == 'localhost'
    assert collected_facts['kernel'] == '3.10.0-327.el7.x86_64'
    assert collected_facts['kernel_version'] == '#1 SMP Thu Nov 19 22:10:57 UTC 2015'
    assert collected_facts['machine'] == 'x86_64'
    assert collected_facts['nodename'] == 'localhost'