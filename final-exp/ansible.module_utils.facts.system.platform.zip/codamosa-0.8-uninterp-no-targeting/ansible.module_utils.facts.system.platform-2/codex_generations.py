

# Generated at 2022-06-20 19:43:51.316830
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector.collect()
    if platform_facts:
        assert platform_facts['system'] == platform.system()
        assert platform_facts['kernel'] == platform.release()
        assert platform_facts['kernel_version'] == platform.version()
        assert platform_facts['machine'] == platform.machine()
        assert platform_facts['python_version'] == platform.python_version()
        assert platform_facts['fqdn'] == socket.getfqdn()
        assert platform_facts['hostname'] == platform.node().split('.')[0]
        assert platform_facts['nodename'] == platform.node()

        if platform_facts['system'] == 'AIX':
            if platform_facts['architecture'] == 'powerpc':
                assert platform_facts['userspace_bits'] == '64'
               

# Generated at 2022-06-20 19:43:58.181381
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-20 19:44:02.303426
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])


# Generated at 2022-06-20 19:44:06.795390
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:44:10.572457
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-20 19:44:13.829249
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # TODO: write unit test
    collected_facts = {}
    fact_collector = PlatformFactCollector()
    fact_collector.collect(collected_facts=collected_facts)

# Generated at 2022-06-20 19:44:24.985620
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys

    platform = sys.platform

    class MockModule:
        class MockRunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def run(self, cmd, cwd=None, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, env_update=None):
                return self.rc, self.out, self.err

        def __init__(self, rc, out, err):
            self.run_command = PlatformFactCollector.MockRunCommand(rc, out, err)

        def get_bin_path(self, cmd):
            if 'getconf' == cmd:
                return '/usr/bin/getconf'

# Generated at 2022-06-20 19:44:26.612744
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'


# Generated at 2022-06-20 19:44:34.569983
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    import platform as python_platform
    import socket
    from ansible.module_utils import facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule():
        def get_bin_path(self, path):
            return path

        def run_command(self, args):
            return (None, args, None)

    platform_facts = facts.get_facts(MockModule())
    assert "system" in platform_facts
    assert platform_facts["system"] == platform.system()
    assert platform_facts["system"] != "Foo"
    assert platform_facts["system"] != BaseFactCollector.UNKNOWN_FACT
    assert "kernel" in platform_facts
    assert platform_facts["kernel"] == platform.release()

# Generated at 2022-06-20 19:44:42.794007
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    results = pfc.collect()
    assert 'system' in results
    assert 'kernel' in results
    assert 'kernel_version' in results
    assert 'machine' in results
    assert 'python_version' in results
    assert 'architecture' in results
    assert 'machine_id' in results
    assert 'fqdn' in results
    assert 'hostname' in results
    assert 'nodename' in results
    assert 'domain' in results
    assert 'userspace_bits' in results
    assert 'userspace_architecture' in results


# Generated at 2022-06-20 19:45:59.314622
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert platform_facts["system"] in ["Linux", "AIX", "Darwin", "Java", "Windows"]
    assert platform_facts["kernel"]
    assert platform_facts["kernel_version"]
    assert platform_facts["machine"]
    assert platform_facts["python_version"]

    assert re.match("^[a-z0-9-]{5,50}$", platform_facts["machine_id"])
    assert re.match("^[.]*$", platform_facts["domain"])

    assert platform_facts["userspace_bits"] in [32, 64]
    assert platform_facts["architecture"]
    assert platform_facts["userspace_architecture"]

# Generated at 2022-06-20 19:46:08.057158
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['fqdn'] == socket.getfqdn()

# Generated at 2022-06-20 19:46:14.739676
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_mock = monkeypatch_platform_machine("x86_64")
    machine_id_mock = monkeypatch_get_file_content("/var/lib/dbus/machine-id", "fake_machine_id")
    facts_collector = PlatformFactCollector()
    facts_collector.collect()
    assert facts_collector.collect() == {
        'system': 'Linux',
        'kernel': '3.10.0-327.el7.x86_64',
        'kernel_version': '#1 SMP Thu Nov 19 22:10:57 UTC 2015',
        'machine': 'x86_64',
        'python_version': '2.7.5',
        'architecture': 'x86_64',
        'machine_id': 'fake_machine_id'}


# Generated at 2022-06-20 19:46:26.415294
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import ModuleFailException
    module = MockModule(run_command_return_value=(0, "/usr/bin/python2.7", ""))
    module.get_bin_path = Mock(side_effect=lambda x: "/bin/" + x if x in ['getconf', 'bootinfo'] else None)
    collector = PlatformFactCollector(module=module)

    result = collector.collect()

    assert "system" in result
    assert result["system"] == platform.system()

    assert "kernel" in result
    assert result["kernel"] == platform.release()

    assert "kernel_version" in result
    assert result["kernel_version"] == platform.version()

    assert "machine" in result
    assert result["machine"] == platform.machine()

    assert "python_version" in result


# Generated at 2022-06-20 19:46:33.852907
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector()
    result = platform.collect()

# Generated at 2022-06-20 19:46:43.920857
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    facts = PlatformFactCollector().collect()
    assert len(facts) == 8
    assert facts['system'] == 'Linux'
    assert facts['kernel'] == '2.6.32-573.e16.x86_64'
    assert facts['kernel_version'] == '#1 SMP Mon Apr 25 06:11:32 EDT 2016'
    assert facts['machine'] == 'x86_64'
    assert facts['architecture'] == 'x86_64'
    assert facts['fqdn'] == 'localhost'
    assert facts['hostname'] == 'localhost'
    assert facts['nodename'] == 'localhost'
    assert facts['domain'] == 'localdomain'
    assert facts['python_version'] == '2.7.5'

# Generated at 2022-06-20 19:46:48.286070
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test instantiation of class PlatformFactCollector
    platform_facts = PlatformFactCollector()
    # Check properties of PlatformFactCollector object
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == {'system', 'kernel', 'kernel_version', 'machine',
                                        'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-20 19:46:51.547351
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf is not None
    assert pf.name == "platform"
    assert "system" in pf._fact_ids
    assert "kernel" in pf._fact_ids
    assert "architecture" in pf._fact_ids

# Generated at 2022-06-20 19:46:53.531933
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Test to see if class is created successfully."""
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None

# Generated at 2022-06-20 19:46:54.658211
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-20 19:49:33.044186
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


# Generated at 2022-06-20 19:49:39.486026
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = PlatformFactCollector()
    fake_ansible_module = FakeAnsibleModule()

    # test the case if /var/lib/dbus/machine-id exist
    test_platform_facts.collect(fake_ansible_module)
    assert fake_ansible_module.run_command.call_count == 1

    # test the case if /var/lib/dbus/machine-id does not exist
    fake_ansible_module.facts = {}
    test_platform_facts.collect(fake_ansible_module)
    assert fake_ansible_module.run_command.call_count == 2


# Generated at 2022-06-20 19:49:47.873679
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket

    import pytest
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()

    machine_id = get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")
    if machine_id:
        machine_id = machine_id.splitlines()[0]
        assert platform_facts["machine_id"] == machine_id

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()

# Generated at 2022-06-20 19:49:53.859346
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fc = PlatformFactCollector()
    # Test results of property name
    assert platform_fc.name == "platform"
    # Test results of private property _fact_ids
    assert platform_fc._fact_ids == set(['system',
                                         'kernel',
                                         'kernel_version',
                                         'machine',
                                         'python_version',
                                         'architecture',
                                         'machine_id'])


# Generated at 2022-06-20 19:49:56.758084
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-20 19:49:58.296042
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:50:05.460284
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'

    assert sorted(platform_fact_collector._fact_ids) == sorted(['system',
                                                                'kernel',
                                                                'kernel_version',
                                                                'machine',
                                                                'python_version',
                                                                'architecture',
                                                                'machine_id'])


# Generated at 2022-06-20 19:50:12.684258
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert(pfc.name == 'platform')
    assert(pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id']))


# Generated at 2022-06-20 19:50:20.141827
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import random
    import string
    import sys
    import platform

    class MockModule:
        def __init__(self):
            self._list_of_commands = []
            self._list_of_commands_cache = {}
            self._command_results = {}

        def get_bin_path(self, binary):
            return binary

        def run_command(self, command):
            self._list_of_commands.append(command)
            if command in self._command_results:
                return self._command_results[command]

            return (0, "", "")

    class MockPlatform:
        PLATFORM_SYSTEM = None
        PLATFORM_RELEASE = None
        PLATFORM_VERSION = None
        PLATFORM_MACHINE = None
        PLATFORM_UNAME = None
        PL

# Generated at 2022-06-20 19:50:25.170764
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])