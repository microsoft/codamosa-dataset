

# Generated at 2022-06-20 19:43:49.054913
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    if platform.system() == "Microsoft":
        test_platform_facts = {"system": "Windows",
                               "hostname": platform.node(),
                               "kernel": "Windows",
                               "architecture": platform.machine(),
                               "python_version": platform.python_version()}
    else:
        test_platform_facts = {"system": platform.system(),
                               "hostname": platform.node().split('.')[0],
                               "kernel": platform.release(),
                               "architecture": platform.machine(),
                               "python_version": platform.python_version()}
    platform_obj = PlatformFactCollector()
    assert test_platform_facts == platform_obj.collect()

# Generated at 2022-06-20 19:43:55.559791
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector()
    assert result.name == 'platform'
    assert set(result._fact_ids) == set(['system',
                                         'kernel',
                                         'kernel_version',
                                         'machine',
                                         'python_version',
                                         'architecture',
                                         'machine_id'])

# Generated at 2022-06-20 19:44:05.459505
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Initialization of test objects
    module = AnsibleModuleMock()
    fact_collector = PlatformFactCollector(module)
    # Testing method collect with standard instanciation of PlatformFactCollector
    fact_collector.collect(module, None)
    assert 'hostname' in fact_collector.facts
    assert fact_collector.facts['hostname'] == '<hostname>'
    assert 'machine' in fact_collector.facts
    assert 'system' in fact_collector.facts
    assert fact_collector.facts['system'] == '<system>'
    assert 'kernel' in fact_collector.facts
    assert fact_collector.facts['kernel'] == '<kernel_release>'
    assert 'kernel_version' in fact_collector.facts

# Generated at 2022-06-20 19:44:09.337874
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:44:18.856838
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_platform_fact_collector = PlatformFactCollector()
    assert test_platform_fact_collector.name == "platform"
    assert test_platform_fact_collector._fact_ids == set(['system',
                                                          'kernel',
                                                          'kernel_version',
                                                          'machine',
                                                          'python_version',
                                                          'architecture',
                                                          'machine_id'])
    test_platform_fact_collector.collect()

if __name__ == "__main__":
    test_PlatformFactCollector()

# Generated at 2022-06-20 19:44:23.619549
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # init the test PlatformFactCollector
    pfc = PlatformFactCollector()
    # call the method being tested
    result = pfc.collect()
    assert result['system'] in ['Linux', 'Darwin', 'Java', 'Windows']
    assert result['architecture']
    assert result['machine']
    assert result['kernel']
    assert result['kernel_version']
    assert result['python_version']

# Generated at 2022-06-20 19:44:32.722953
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import json
    import os
    import platform

    from ansible.module_utils.facts.collector import BaseFactCollector

    # Get a json file to use for mocking
    # the /etc/os-release file
    f = open(os.path.join(os.path.dirname(__file__), '../../unit/module_utils/facts/os_release_mock.json'), 'r')
    json_data = f.read()
    f.close()
    os_release_dict = json.loads(json_data)

    # Setup the module to be used in the unit test
    module = MockModuleUtilsModule(os_release_dict)

    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(module)

    # Test results, should match the

# Generated at 2022-06-20 19:44:44.925092
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """This is a basic test for method collect of class PlatformFactCollector."""
    # Create a mock module object
    # Modules use the AnsibleModule class from lib/ansible/module_utils/basic.py
    # Test for AnsibleModule will be done in test_ansible.py
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, command):
            return (0, '', '')

        def get_bin_path(self, cmd):
            return cmd

    # Create a mock module object
    module = MockModule()
    # Create a PlatformFactCollector object
    platform_collector = PlatformFactCollector()
    # Pass the module object to collect of PlatformFactCollector

# Generated at 2022-06-20 19:44:51.401316
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc_obj = PlatformFactCollector()
    # check name
    assert pfc_obj.name == "platform", 'test_PlatformFactCollector: Fact name is not as expected'

    # check fact ids
    assert pfc_obj._fact_ids == set(["system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"]), \
        'test_PlatformFactCollector: Fact ids are not as expected'


# Generated at 2022-06-20 19:44:52.536675
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    obj = PlatformFactCollector()
    assert obj.name == 'platform'

# Generated at 2022-06-20 19:45:39.940266
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
     p = PlatformFactCollector()
     assert p.name == "platform"
     assert list(p._fact_ids) == ['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id']

# Generated at 2022-06-20 19:45:44.837924
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create argument dict to be passed to the module
    arguments = dict(
        gather_subset='!all',
    )
    # Instantiate the module
    module = AnsibleModule(argument_spec=arguments)

    # Instantiate the Platform fact class
    pf = PlatformFactCollector(module)
    # Call the collect method
    result = pf.collect()

    # Test the results
    assert result is not None
    assert 'system' in result
    assert 'kernel' in result
    assert 'machine' in result
    assert 'python_version' in result

# Generated at 2022-06-20 19:45:47.380689
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-20 19:45:52.917636
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:46:00.558853
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # set collected_facts to None to prevent AnsibleModule mock to keep
    # facts from previous collect call when calling multiple times collect
    # from the same PlatformFactCollector instance
    platform_facts = PlatformFactCollector().collect(collected_facts=None)
    assert platform_facts["system"] == platform.system()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["python_version"] == platform.python_version()
    assert platform_facts["hostname"] == platform.node().split('.')[0]
    assert platform_facts["nodename"] == platform.node()
    assert platform_facts["architecture"] == platform.machine()


# Generated at 2022-06-20 19:46:01.164984
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-20 19:46:05.162178
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    import platform
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['architecture'] == platform.machine()

# Generated at 2022-06-20 19:46:09.547590
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """PlatformFactCollector: test collect method
    """
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.collectors['platform.platform_collector'] = PlatformFactCollector()
    collected_facts = ansible_collector.collect()

    print(collected_facts)

# Generated at 2022-06-20 19:46:13.668976
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id',
                                 'fqdn',
                                 'hostname',
                                 'nodename',
                                 'domain'])


# Generated at 2022-06-20 19:46:14.263898
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-20 19:46:42.942792
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    facts = pfc.collect()

    assert type(facts['system']) is str
    assert type(facts['kernel']) is str
    assert type(facts['kernel_version']) is str
    assert type(facts['machine']) is str
    assert type(facts['python_version']) is str
    assert type(facts['architecture']) is str
    assert type(facts['userspace_bits']) is str
    assert type(facts['userspace_architecture']) is str
    assert type(facts['fqdn']) is str
    assert type(facts['hostname']) is str
    assert type(facts['nodename']) is str
    assert type(facts['domain']) is str

    assert 'system' in facts
    assert 'kernel' in facts
   

# Generated at 2022-06-20 19:46:50.463119
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def get_bin_path(path):
        return '/bin/' + path

    class MockModule(object):
        def get_bin_path(path):
            return get_bin_path(path)

    class MockFacts(object):
        pass

    module = MockModule()
    collected_facts = MockFacts()

    pfc = PlatformFactCollector()
    facts = pfc.collect(module, collected_facts)

    assert type(facts) == dict
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['fqdn'] == socket.getfqdn()
    assert facts

# Generated at 2022-06-20 19:46:56.509686
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

    assert x.collect()
    assert isinstance(x.collect(), dict)
    assert isinstance(x.collect(collected_facts=dict()), dict)

# Generated at 2022-06-20 19:47:05.725094
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()

    tested_facts = platform_collector.collect(collected_facts={})

    assert tested_facts["system"] == platform.system()
    assert tested_facts["kernel"] == platform.release()
    assert tested_facts["kernel_version"] == platform.version()
    assert tested_facts["machine"] == platform.machine()
    assert tested_facts["python_version"] == platform.python_version()

    assert tested_facts["fqdn"] == socket.getfqdn()
    assert tested_facts["hostname"] == platform.node().split('.')[0]
    assert tested_facts["nodename"] == platform.node()
    assert tested_facts["architecture"] == platform_collector._get_architecture()
    assert tested_facts["userspace_bits"] == platform

# Generated at 2022-06-20 19:47:06.374518
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:47:13.294108
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()

    pfc = PlatformFactCollector()
    res = pfc.collect(module)

    assert res['system'] == 'Linux'
    assert res['kernel'] == '5.5.0-kali3-amd64'
    assert res['machine'] == 'x86_64'
    assert res['architecture'] == 'x86_64'


# Generated at 2022-06-20 19:47:17.196419
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys

    pfc = PlatformFactCollector()
    facts = pfc.collect()

    assert facts['system'] == sys.platform
    assert facts['kernel'] is not None
    assert facts['kernel_version'] is not None
    assert facts['machine'] is not None
    assert facts['python_version'] == sys.version.split(' ')[0]
    assert facts['userspace_bits'] == '64'
    assert facts['architecture'] is not None
    assert facts['userspace_architecture'] is not None


# Generated at 2022-06-20 19:47:25.895790
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    # test all the fact ids are present
    assert platform_fact_collector.collect()
    assert 'system' in platform_fact_collector.collect()
    assert 'kernel' in platform_fact_collector.collect()
    assert 'kernel_version' in platform_fact_collector.collect()
    assert 'machine' in platform_fact_collector.collect()
    assert 'python_version' in platform_fact_collector.collect()
    assert 'architecture' in platform_fact_collector.collect()
    assert 'machine_id' in platform_fact_collector.collect()

# Generated at 2022-06-20 19:47:37.688837
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = FakeModule()
    collecter = PlatformFactCollector()
    facts = collecter.collect(module=module)
    assert facts['system'] == 'Linux'
    assert facts['kernel'] == '3.10.0-327.13.1.el7.x86_64'
    assert facts['kernel_version'] == '#1 SMP Thu Mar 31 16:04:38 UTC 2016'
    assert facts['machine'] == 'x86_64'
    assert facts['fqdn'] == 'localhost.localdomain'
    assert facts['hostname'] == 'localhost'
    assert facts['nodename'] == 'localhost.localdomain'
    assert facts['domain'] == 'localdomain'
    assert facts['userspace_bits'] == '64'

# Generated at 2022-06-20 19:47:43.244590
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Create a mock module with arguments
    module = AnsibleModule(argument_spec={})

    # Instanciate a PlatformFactCollector object
    pfc = PlatformFactCollector()

    # Call the method collect
    result = pfc.collect(module=module)

    # Test the result's keys
    assert 'system' in result
    assert isinstance(result['system'], type(u'')) or isinstance(result['system'], type(''))

    assert 'kernel' in result
    assert isinstance(result['kernel'], type(u'')) or isinstance(result['kernel'], type(''))

    assert 'kernel_version' in result
    assert isinstance(result['kernel_version'], type(u'')) or isinstance(result['kernel_version'], type(''))

    assert 'machine' in result
   

# Generated at 2022-06-20 19:48:53.028474
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    platform_facts = collector.collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'hostname' in platform_facts
    assert 'nodename' in platform_facts
    assert 'domain' in platform_facts

# Generated at 2022-06-20 19:49:04.567222
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.utils import get_file_content

    fact_cache = FactCache()
    py_version = platform.python_version()
    system = platform.system()
    kernel = platform.release()
    kernel_version = platform.version()
    machine = platform.machine()
    fqdn = socket.getfqdn()
    hostname = platform.node().split('.')[0]
    nodename = platform.node()
    domain = '.'.join(fqdn.split('.')[1:])
    userspace_bits = platform.architecture()[0].replace('bit', '')
    if machine == 'x86_64':
        architecture = machine
        if userspace_bits == '64':
            userspace_arch

# Generated at 2022-06-20 19:49:10.201959
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert not obj.__dict__
    assert obj.name == 'platform'
    assert obj.platform == 'posix'
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:49:14.673237
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id'])


# Generated at 2022-06-20 19:49:21.142219
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-20 19:49:23.801814
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_PlatformFactCollector = PlatformFactCollector()
    assert type(test_PlatformFactCollector) == PlatformFactCollector
    assert test_PlatformFactCollector.name == 'platform'



# Generated at 2022-06-20 19:49:32.683882
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # If a test for a collect method exists, the collect method is actually called only once.
    # This is in contrast with other collectors, whose collect method is called for every fact in _fact_ids.
    # This is why the test_PlatformFactCollector_collect method actually tests that the collect method works.
    # We also test here that the values returned by collect are of the correct type.
    # We also test that the collect method returns the facts that we expect.
    # We test the values using an if statement, verifying that the values are not None.
    # We should actually be testing the values further, but we do not do that here.

    # We create a PlatformFactCollector object.
    collector = PlatformFactCollector()

    # We run the collect method on the collector object.
    # We do not pass any parameters to the collect method.
    # The collect method

# Generated at 2022-06-20 19:49:33.256760
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-20 19:49:34.377985
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-20 19:49:36.673570
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert len(p._fact_ids) == 9
