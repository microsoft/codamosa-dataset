

# Generated at 2022-06-20 19:43:38.931494
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.base import FactCollectorCacheDict
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.basic import AnsibleModule


    # Set up the module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    module.params = {}

    # Set up and prepare the fact collector object
    fact_collector = FactCollector(module)
    collected_facts = FactCollectorCacheDict()
    fact_collector._collectors

# Generated at 2022-06-20 19:43:43.824051
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # set up an object instance
    platform_fact_collector = PlatformFactCollector()

    # get a platform fact from the function collect
    platform_fact = platform_fact_collector.collect()

    # test if the platform fact is not None
    assert platform_fact is not None

# Generated at 2022-06-20 19:43:48.705808
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert sorted(obj._fact_ids) == sorted([
        'architecture',
        'kernel',
        'kernel_version',
        'machine',
        'machine_id',
        'python_version',
        'system'
    ])


# Generated at 2022-06-20 19:43:55.620766
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class FakeModule(object):
        def get_bin_path(self, program, optional=False):
            return program

        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None):
            if args[0] == 'getconf':
                return 0, "ppc64", ""
            elif args[0] == 'bootinfo':
                return 0, "powerpc", ""
            return 0, "x86_64", ""

    module = FakeModule()
    fact_collector = PlatformFactCollector(module=module)

# Generated at 2022-06-20 19:44:02.382223
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Create an instance of PlatformFactCollector class
    PlatformFactCollector_ins = PlatformFactCollector()

    # Get the value of the attribute name of PlatformFactCollector_ins
    name_value = PlatformFactCollector_ins.name

    print(name_value)

    from ansible.module_utils.facts.json.test_json_test import Fake_module
    fake_module = Fake_module()

    # Call the method collect of PlatformFactCollector_ins with parameters fake_module
    platform_facts = PlatformFactCollector_ins.collect(fake_module)

    print(platform_facts)

# Create a test instance of PlatformFactCollector and call the method collect
test_PlatformFactCollector_collect()

# Generated at 2022-06-20 19:44:11.623573
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import socket

    c = PlatformFactCollector()

    facts = c.collect()

    # Although this could be tested on any platform,
    # these are known to be present in the default facts
    assert facts['domain'] == '.'.join(socket.getfqdn().split('.')[1:])
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['userspace_bits'] == platform.architecture()[0].replace('bit', '')
    assert facts['nodename'] == platform.node()

    # These keys are not always defined and may be platform dependent
    # These are known to be present
    assert facts['fqdn'] == socket.getf

# Generated at 2022-06-20 19:44:23.619524
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic

    platform_facts = PlatformFactCollector().collect(module=basic.AnsibleModule(
    ))
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['nodename'] == platform.node()
    assert re.match(r'\.'.join(platform_facts['fqdn'].split('.')[1:]
                               ), platform_facts['domain'])


# Generated at 2022-06-20 19:44:27.527579
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id'])
    assert x.name == 'platform'

# Generated at 2022-06-20 19:44:28.823772
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'


# Generated at 2022-06-20 19:44:34.020269
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'userspace_architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-20 19:45:52.378219
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector, TestCollectedFacts
    from ansible.module_utils.facts.utils import get_file_content
    import platform as system_platform
    import socket

    # Note: machine is not on the list of platform facts to be provided
    m = Collector()
    m.collect = {'platform': PlatformFactCollector()}

    collected_facts = TestCollectedFacts()

    # Monkey-patch platform.uname, platform.release, platform.node, platform.architecture, get_file_content
    saved_uname = system_platform.uname
    saved_release = system_platform.release
    saved_node = system_platform.node
    saved_architecture = system_platform.architecture
    saved_get_file_content = get_file_content



# Generated at 2022-06-20 19:46:00.312219
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()


# Generated at 2022-06-20 19:46:06.449978
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-20 19:46:13.907572
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Test code
    class Linux:
        system = "Linux"
        release = "4.15.0-72-generic"
        version = "#81-Ubuntu SMP Tue Nov 26 12:20:02 UTC 2019"
        node = "toto"
        machine = "x86_64"

    class Windows:
        system = "Windows"
        release = ""
        version = "10.0.18363"
        node = "toto"
        machine = "AMD64"

    import platform
    platform.system = lambda: Linux.system
    platform.release = lambda: Linux.release
    platform.version = lambda: Linux.version
    platform.node = lambda: Linux.node
    platform.machine = lambda: Linux.machine
    platform.python_version = lambda: "3.6.9"

    import socket
    socket

# Generated at 2022-06-20 19:46:20.908495
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}
    assert platform_fact_collector.fact_class == 'platform'
    assert platform_fact_collector.fact_subclass == 'system'

# Generated at 2022-06-20 19:46:30.988218
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    result = platform_collector.collect()
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()
    assert result['domain'] == '.'.join(result['fqdn'].split('.')[1:])
    assert result['userspace_bits'] == platform.architecture()[0].replace('bit', '')

# Generated at 2022-06-20 19:46:32.060553
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-20 19:46:37.002106
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:46:38.767483
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p is not None

# Generated at 2022-06-20 19:46:46.902602
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    # Collector instance is initialized with current_collector and can_run_function
    # can_run_function is in turn initialized with list of valid collector names
    # In this test we initialize the collector instance directly
    collector = PlatformFactCollector('PlatformFactCollector', None)

    # Collect function is called and returns a dictionary of collected facts
    result = collector.collect()

    assert result['system'] == 'OpenBSD'
    assert result['python_version'] == '3.6'

# Generated at 2022-06-20 19:48:23.594746
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """ Test that collect returns the expected data """
    # build a fake module object to use to invoke function
    # If a real module object was used, tests would have an unexpected side effect.
    # The module object uses os.environ to store its parameters
    fake_module = FakeAnsibleModule()
    fake_module.params = {}
    fake_module.get_bin_path = lambda x: None
    # Invoke the function to be tested
    fact_collector = PlatformFactCollector(fake_module)
    result = fact_collector.collect(fake_module, None)
    # Check that results are as expected
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()

# Generated at 2022-06-20 19:48:32.865643
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        import platform
        import socket
        import re
    except ImportError:
        return
    platform.machine = lambda: 'x86_64'
    platform.architecture = lambda: ('64bit', '')
    platform.system = lambda: 'Linux'
    platform.release = lambda: '2.2.42'
    platform.version = lambda: '#1 Tue Jun 18 23:13:24 PDT 2013'
    platform.python_version = lambda: '2.7.5'
    socket.getfqdn = lambda: 'www.example.com'
    re.compile = lambda x: re.compile('.*')
    platform.node = lambda: 'node'
    module = AnsibleModule()
    pfc = PlatformFactCollector()
    collected_facts = {}
    new_facts = pfc

# Generated at 2022-06-20 19:48:37.783042
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert sorted(x.collect().keys()) == ['architecture', 'domain', 'fqdn',
                                          'hostname', 'kernel',
                                          'kernel_version', 'machine',
                                          'machine_id', 'nodename',
                                          'python_version', 'system',
                                          'userspace_architecture',
                                          'userspace_bits']

# Generated at 2022-06-20 19:48:44.664860
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-20 19:48:49.378994
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    fact_ids = set(['system',
                    'kernel',
                    'kernel_version',
                    'machine',
                    'python_version',
                    'architecture',
                    'machine_id'])
    assert PlatformFactCollector._fact_ids == fact_ids

# Generated at 2022-06-20 19:48:51.161312
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()


# Generated at 2022-06-20 19:49:02.619073
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()

    # Simple sanity tests of defaults
    collected_facts = fact_collector.collect()
    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    assert collected_facts['machine'] == platform.machine()
    assert collected_facts['python_version'] == platform.python_version()
    assert collected_facts['fqdn']

    # Solaris testing
    uname_result = (
        'SunOS',
        'test_node',
        '5.11',
        'joyent_20130322T023403Z',
        'i86pc',
        'i386',
        'i86pc',
    )

# Generated at 2022-06-20 19:49:07.312498
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-20 19:49:10.713673
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'hostname' in platform_fact_collector._fact_ids

# Generated at 2022-06-20 19:49:17.878160
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fake_module = create_fake_module()
    platform_object = PlatformFactCollector(fake_module)
    collected_fact = platform_object.collect()

# Generated at 2022-06-20 19:52:38.701368
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-20 19:52:48.116596
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = PlatformFactCollector().collect()
    assert test_platform_facts['system'] == platform.system()
    assert test_platform_facts['kernel'] == platform.release()
    assert test_platform_facts['kernel_version'] == platform.version()
    assert test_platform_facts['machine'] == platform.machine()
    assert test_platform_facts['python_version'] == platform.python_version()
    assert test_platform_facts['fqdn'] == socket.getfqdn()
    assert test_platform_facts['nodename'] == platform.node()
    assert test_platform_facts['hostname'] == platform.node().split('.')[0]
    assert test_platform_facts['domain'] == '.'.join(test_platform_facts['fqdn'].split('.')[1:])