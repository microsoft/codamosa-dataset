

# Generated at 2022-06-20 19:43:39.629946
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:43:45.839707
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:43:54.857820
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    platform_system = platform.system()
    if platform_system != 'SunOS':
        import pytest
        pytest.skip("Test not supported on platform '%s'" % platform_system)

    pc = PlatformFactCollector()
    platform_facts = pc.collect()

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'domain' in platform_facts
    assert 'nodename' in platform_facts
    assert 'hostname' in platform_facts

# Generated at 2022-06-20 19:44:03.880492
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import os
    import platform
    import socket

    from ansible.module_utils.facts.collector import Collector

    # Setup the following test variables
    # Note: The test module is defined below
    test_module = CollectorTestModule()
    test_platform = platform.system()
    test_fqdn = socket.getfqdn()
    test_hostname = test_fqdn.split('.')[0]
    test_nodename = platform.node()

    # Setup the following test variables
    if test_platform == 'Linux':
        uname_test = os.uname()
        test_kernel = uname_test[2]
        test_kernel_version = uname_test[2]
        test_domain = test_fqdn.split('.')[1:]

# Generated at 2022-06-20 19:44:12.179382
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform
    import ansible.module_utils.facts.collectors.platform as platform_collector

    class MockModule:
        def __init__(self):
            self.params = {}
            self.socket = None
        def get_bin_path(self, command):
            if command == 'bootinfo':
                return '/usr/sbin/bootinfo'
            elif command == 'getconf':
                return '/usr/bin/getconf'
        def run_command(self, bin, check_rc=True):
            if bin == ['/usr/sbin/bootinfo', '-p']:
                return (0, 'ppc', None)
            elif bin == ['/usr/bin/getconf', 'MACHINE_ARCHITECTURE']:
                return (0, 'ppc64', None)
            el

# Generated at 2022-06-20 19:44:23.029136
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    # Two pass load test, ensure we can load the class both when
    # the module is in the pythonpath, and when we are executing
    # from an installed package
    platform_collector = PlatformFactCollector()
    assert(isinstance(platform_collector, BaseFactCollector))
    assert('platform' in collector.all_collectors)

    # Collected facts should be a hash
    result = platform_collector.collect()
    assert(isinstance(result, dict))

    # Collected facts should be populated
    assert(result.get('system') == platform.system())
    assert(result.get('kernel') == platform.release())

# Generated at 2022-06-20 19:44:28.477262
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])


# Generated at 2022-06-20 19:44:34.020121
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    # Creating object for class PlatformFactCollector
    platform_obj = PlatformFactCollector()

    assert platform_obj.name == 'platform'

    assert 'system' in platform_obj._fact_ids
    assert 'kernel' in platform_obj._fact_ids
    assert 'kernel_version' in platform_obj._fact_ids
    assert 'machine' in platform_obj._fact_ids
    assert 'python_version' in platform_obj._fact_ids
    assert 'architecture' in platform_obj._fact_ids
    assert 'machine_id' in platform_obj._fact_ids

# Generated at 2022-06-20 19:44:39.815457
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    assert 'system' in collector.collect()
    assert 'kernel' in collector.collect()
    assert 'kernel_version' in collector.collect()
    assert 'machine' in collector.collect()
    assert 'python_version' in collector.collect()
    assert 'architecture' in collector.collect()
    assert 'machine_id' in collector.collect()

# Generated at 2022-06-20 19:44:45.695611
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-20 19:45:35.590712
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None
    assert x.__class__.__name__ == 'PlatformFactCollector'

# Generated at 2022-06-20 19:45:39.940204
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == {
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    }

# Generated at 2022-06-20 19:45:42.305254
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts import FactCollector

    facts_collector = FactsCollector(None, FactCollector())
    facts = facts_collector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-20 19:45:51.165275
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    x = PlatformFactCollector()
    fake_module = FakeModule()
    x.collect(module=fake_module)
    result = {'system': 'Hello',
              'kernel': 'World',
              'kernel_version': '1',
              'machine': 'x86_64',
              'python_version': '2.7.2',
              'fqdn': 'localhost.localdomain',
              'hostname': 'localhost',
              'nodename': 'localhost.localdomain',
              'domain': 'localdomain',
              'userspace_bits': '64',
              'architecture': 'x86_64',
              'userspace_architecture': 'x86_64'}

    assert x.collect_facts == result


# Generated at 2022-06-20 19:45:59.801137
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-20 19:46:10.140220
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # test1: input is a module
    module = AnsibleModuleMock()
    collector = PlatformFactCollector()
    result = collector.collect(module=module)
    assert module.run_command.called
    assert module.get_bin_path.called
    assert result['system'] == 'Linux'
    assert result['hostname'] == 'localhost'
    assert result['architecture'] == 'x86_64'
    assert result['userspace_bits'] == '64'
    assert result['userspace_architecture'] == 'x86_64'
    assert result['machine_id'] == None
    assert result['python_version'] == '2.7.12'

    # test2: input is a module, expect output to be a dict
    module = AnsibleModuleMock()

# Generated at 2022-06-20 19:46:20.793138
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())
    fact_collector = PlatformFactCollector(module=module)
    platform_facts = fact_collector.collect(module=module)

    assert type(platform_facts) == dict
    for key, value in platform_facts.items():
        assert type(key) == str
        assert type(value) == str
    # Specific checks
    assert 'system' in platform_facts.keys()
    assert platform_facts['system'] in ['Linux', 'AIX', 'Darwin', 'OpenBSD', 'SunOS', 'Windows', 'FreeBSD',
                                        'NetBSD', 'HP-UX', 'DragonFly', 'Minix']
    assert 'kernel' in platform_facts.keys()
    assert 'kernel_version' in platform_facts.keys()
    assert 'machine' in platform_

# Generated at 2022-06-20 19:46:23.435722
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    import module_utils.facts.collectors.platform as platform_collector
    collector = platform_collector.PlatformFactCollector()
    assert collector.name == "platform"

# Generated at 2022-06-20 19:46:28.758050
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-20 19:46:30.641243
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-20 19:48:00.415717
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert isinstance(x._fact_ids, set)
    assert 'system' in x._fact_ids
    assert 'kernel' in x._fact_ids
    assert 'kernel_version' in x._fact_ids
    assert 'machine' in x._fact_ids
    assert 'python_version' in x._fact_ids
    assert 'architecture' in x._fact_ids

# Generated at 2022-06-20 19:48:07.108505
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    collected_facts = Collector(module=module).collect()
    result = PlatformFactCollector(module=module).collect(collected_facts=collected_facts)
    assert isinstance(result, dict)

# Generated at 2022-06-20 19:48:10.509274
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:48:11.784313
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        PlatformFactCollector().collect()
    except:
        assert False

# Generated at 2022-06-20 19:48:22.076507
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleCollector
    module_collector = ModuleCollector()
    PlatformFactCollector.populate(module_collector)

    ansible_facts = {}
    collected_facts = module_collector.collect(module=None, collected_facts=ansible_facts)

# Generated at 2022-06-20 19:48:27.286816
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'
    assert platformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:48:30.151777
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert isinstance(pfc._fact_ids, set)
    for fact_id in pfc._fact_ids:
        assert isinstance(fact_id, str)

# Generated at 2022-06-20 19:48:32.803151
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), PlatformFactCollector)
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system','kernel','kernel_version','machine','python_version','architecture', 'machine_id'])

# Generated at 2022-06-20 19:48:40.942786
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]


# Generated at 2022-06-20 19:48:47.498296
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-20 19:51:56.770169
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'

# Generated at 2022-06-20 19:52:05.540975
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids

# Generated at 2022-06-20 19:52:11.154278
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    import platform
    import socket

    class MockPlatformFS(object):
        @staticmethod
        def get_file_content(*args, **kwargs):
            return '/var/lib/dbus/machine-id: DUMMY\n'

    class MockModule(object):
        def __init__(self):
            self.fs = MockPlatformFS()

        @staticmethod
        def run_command(*args, **kwargs):
            return 0, 'out\n', 'err'

        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/bin/getconf'

    class MockPlatform(object):
        @staticmethod
        def system():
            return 'Linux'


# Generated at 2022-06-20 19:52:16.657666
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Instantiate the PlatformFactCollector class
    platform_collector = PlatformFactCollector()
    assert platform_collector is not None

    # Try calling the collect method without passing an argument
    platform_facts = platform_collector.collect()

    assert "system" in platform_facts
    assert "kernel" in platform_facts
    assert "kernel_version" in platform_facts
    assert "machine" in platform_facts
    assert "python_version" in platform_facts
    assert "architecture" in platform_facts

# Generated at 2022-06-20 19:52:20.193457
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:52:26.535141
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''Test collect of PlatformFactCollector method
    '''

    # Setup a mock object for the module_util object
    class MockModuleUtil:

        def get_bin_path(self, arg1):
            return None

        def run_command(self, arg1):
            return (0, "", "")

    # Setup a mock object for the PlatformFactCollector object
    class MockPlatformFactCollector:

        platform_util = None
        module_util = None
        platform_facts = None

        def __init__(self):
            self.platform_util = platform
            self.module_util = MockModuleUtil()

# Generated at 2022-06-20 19:52:28.724685
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    facts_to_collect = ['system',
                        'kernel',
                        'kernel_version',
                        'machine',
                        'python_version',
                        'architecture',
                        'machine_id']
    collector = PlatformFactCollector()

    assert collector.name == 'platform'
    assert collector._fact_ids == set(facts_to_collect)

# Generated at 2022-06-20 19:52:33.169342
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_obj = PlatformFactCollector()
    expected_result = set(['system', 'kernel', 'kernel_version', 'machine',
                           'python_version', 'architecture', 'machine_id'])
    assert test_obj._fact_ids == expected_result

# Generated at 2022-06-20 19:52:39.222755
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), BaseFactCollector)
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:52:40.157217
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect({})