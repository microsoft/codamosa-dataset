

# Generated at 2022-06-20 19:43:40.501297
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    import socket

    platform_facts = {'architecture': platform.architecture()[0].replace('bit', ''),
                      'domain': '.'.join(socket.getfqdn().split('.')[1:]),
                      'fqdn': socket.getfqdn(),
                      'hostname': platform.node().split('.')[0],
                      'kernel': platform.release(),
                      'kernel_version': platform.version(),
                      'machine': platform.machine(),
                      'python_version': platform.python_version(),
                      'system': platform.system(),
                      'userspace_bits': platform.architecture()[0].replace('bit', ''),
                      'nodename': platform.node()}
    pfc = PlatformFactCollector()
    assert pfc.collect() == platform_

# Generated at 2022-06-20 19:43:50.875576
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    PlatformFactCollector.cache = {}

    mock_module = type('MockModule', (object,), {'run_command': lambda x: (0, '', ''),
                                                 'get_bin_path': lambda x: '/bin/' + x,
                                                 'get_file_content': lambda x: x.split('/')[-1]})
    platform_facts = PlatformFactCollector().collect(mock_module)

    assert platform_facts["system"] == platform.system()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["python_version"] == platform.python_version()

# Generated at 2022-06-20 19:43:51.709486
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x

# Generated at 2022-06-20 19:43:57.232471
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert isinstance(collector, PlatformFactCollector)
    assert 'platform' == collector.name
    assert set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id']) == collector._fact_ids

# Generated at 2022-06-20 19:44:02.119510
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

    assert fact_collector._platform_facts is None


# Generated at 2022-06-20 19:44:06.923711
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:44:09.461074
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    x = PlatformFactCollector()
    platform_facts = x.collect()

    assert platform_facts['architecture'] == platform.machine()
    assert platform_facts['system'] == platform.system()

# Generated at 2022-06-20 19:44:20.484817
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fake_module = type("", (), {})()
    mock_get_bin_path = type("", (), {})()
    fake_module.get_bin_path = mock_get_bin_path
    fake_module.run_command = type("", (), {"return_value":(0, "some value", "some error")})
    mock_get_bin_path.return_value = "/bin/path"
    platform_fact_collector = PlatformFactCollector()
    result = platform_fact_collector.collect(fake_module)
    assert result.get("architecture") == "x86_64"
    assert result.get("machine") == "x86_64"
    assert result.get("userspace_bits") == "64"

# Generated at 2022-06-20 19:44:30.190871
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModule()

    fake_platform_facts = {
        'system': 'Linux',
        'kernel': '3.10.0-327.el7.x86_64',
        'kernel_version': '#1 SMP Thu Nov 19 22:10:57 UTC 2015',
        'machine': 'x86_64',
        'python_version': '2.7.5',
        'fqdn': 'foo.bar',
        'hostname': 'foo',
        'nodename': 'foo.bar',
        'domain': 'bar',
        'userspace_bits': '64',
        'architecture': 'x86_64',
        'userspace_architecture': 'x86_64',
        'machine_id': 'fake-machine-id'
    }


# Generated at 2022-06-20 19:44:33.585215
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert sorted(fact_collector._fact_ids) ==\
	   sorted(['system', 'kernel', 'kernel_version', 'machine', 
		   'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-20 19:45:41.618845
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


# Generated at 2022-06-20 19:45:48.724500
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'fqdn',
                                            'hostname',
                                            'nodename',
                                            'domain'])



# Generated at 2022-06-20 19:45:54.712284
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    with mock.patch.multiple(platform, system=mock.DEFAULT, release=mock.DEFAULT,
                             version=mock.DEFAULT, machine=mock.DEFAULT,
                             python_version=mock.DEFAULT,
                             architecture=lambda: ('32bit', 'ELF')):
        platform.system.return_value = 'Linux'
        platform.release.return_value = '3.10.0-123.20.1.el7.x86_64'
        platform.version.return_value = '#1 SMP Mon Jun 2 11:42:46 EDT 2014'
        platform.machine.return_value = 'x86_64'
        platform.python_version.return_value = '2.7.5'
        pfc = PlatformFactCollector()

# Generated at 2022-06-20 19:45:58.067703
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module_mock = None
    collected_facts = None
    platform_facts = PlatformFactCollector().collect(module_mock, collected_facts)
    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['machine']
    assert platform_facts['python_version']

# Generated at 2022-06-20 19:46:02.620745
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture'])

# Generated at 2022-06-20 19:46:11.945988
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert len(platform_facts) > 0
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'hostname' in platform_facts
    assert 'nodename' in platform_facts
    assert 'domain' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'userspace_architecture' in platform_facts

# Generated at 2022-06-20 19:46:23.436321
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unitary tests for method collect of class PlatformFactCollector
    """

    # Get a dummy module object
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    module = ModuleFacts()
    platform_collector = PlatformFactCollector(module)

    collected_facts = platform_collector.collect()
    assert "system" in collected_facts
    assert "kernel" in collected_facts
    assert "kernel_version" in collected_facts
    assert "machine" in collected_facts
    assert "python_version" in collected_facts
    assert "architecture" in collected_facts
    assert "machine_id" in collected_facts
    assert "userspace_bits" in collected_facts
    assert "userspace_architecture"

# Generated at 2022-06-20 19:46:24.478360
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'

# Generated at 2022-06-20 19:46:33.274545
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    ansible_platform = 'Linux'
    ansible_machine_id = '1234567890'

    class MockAnsibleModule:
        _ansible_platform = ansible_platform
        _ansible_machine_id = ansible_machine_id

        def __init__(self):
            self.params = {}

        def get_bin_path(self, a):
            return '/bin/' + a

        def run_command(self, cmd):
            if cmd[0] == '/bin/getconf':
                if cmd[1] == 'MACHINE_ARCHITECTURE':
                    return (0, 'ppc64le\n', '')
            elif cmd[0] == '/bin/bootinfo':
                if cmd[1] == '-p':
                    return (0, 'powerpc\n', '')

# Generated at 2022-06-20 19:46:43.879768
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_args = {
        'module': None,
        'collected_facts': None
    }

    expected_results = {
        'system': platform.system(),
        'kernel': platform.release(),
        'kernel_version': platform.version(),
        'machine': platform.machine(),
        'python_version': platform.python_version(),
        'fqdn': socket.getfqdn(),
        'hostname': platform.node().split('.')[0],
        'nodename': platform.node(),
        'domain': '.'.join(socket.getfqdn().split('.')[1:])
    }


# Generated at 2022-06-20 19:48:07.765504
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # input
    module = platform
    collected_facts = {}
    # instantiate
    fact_collector = PlatformFactCollector()
    output = fact_collector.collect(module=module, collected_facts=collected_facts)
    assert output

    # ensure there are no overlaps in the return value keys
    # of the two functions
    for k in output:
        assert (k not in collected_facts)

    return True

# Generated at 2022-06-20 19:48:10.468484
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    facts = platform_fact_collector.collect()
    assert facts['system'] == platform.system()


# Generated at 2022-06-20 19:48:15.643774
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector.collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts

# Generated at 2022-06-20 19:48:21.084598
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'

    # As of python2.7.12, platform.system() can be Linux, Darwin, Java, or Windows
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:48:31.442706
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestPlatformFactCollector(PlatformFactCollector):
        name = 'TestPlatformFactCollector'
        _fact_ids = set(['system',
                         'kernel',
                         'kernel_version',
                         'machine',
                         'python_version',
                         'architecture',
                         'machine_id'])
        def collect(self, module=None, collected_facts=None):
            self.system = platform.system()
            self.kernel = platform.release()
            self.kernel_version = platform.version()
            self.machine = platform.machine()
            self.python_version = platform.python_version()
            self.fqdn = socket.getfqdn()

# Generated at 2022-06-20 19:48:38.364834
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert 'system' in platform_collector._fact_ids
    assert 'kernel' in platform_collector._fact_ids
    assert 'kernel_version' in platform_collector._fact_ids
    assert 'machine' in platform_collector._fact_ids
    assert 'python_version' in platform_collector._fact_ids
    assert 'architecture' in platform_collector._fact_ids
    assert 'machine_id' in platform_collector._fact_ids

# Generated at 2022-06-20 19:48:44.108852
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pc = PlatformFactCollector()
    platform_facts = pc.collect()
    assert platform_facts['system'] == sys_info['system']
    assert platform_facts['kernel'] == sys_info['kernel']
    assert platform_facts['kernel_version'] == sys_info['kernel_version']
    assert platform_facts['machine'] == sys_info['machine']
    assert platform_facts['python_version'] == sys_info['python_version']
    assert platform_facts['fqdn'] == sys_info['fqdn']
    assert platform_facts['hostname'] == sys_info['hostname']
    assert platform_facts['nodename'] == sys_info['nodename']


# Load System-specific values
# This information could be loaded from a module like platform.py,
# but to keep the dependencies easy, I'm keeping

# Generated at 2022-06-20 19:48:49.772367
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert platform_obj.name == 'platform'
    assert platform_obj._fact_ids == set(['system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id'])


# Generated at 2022-06-20 19:49:01.741208
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = PlatformFactCollector().collect()
    assert 'machine' in test_platform_facts
    assert 'system' in test_platform_facts
    assert 'kernel' in test_platform_facts
    assert 'kernel_version' in test_platform_facts
    assert 'python_version' in test_platform_facts
    assert 'architecture' in test_platform_facts
    assert 'userspace_bits' in test_platform_facts
    assert 'hostname' in test_platform_facts
    assert 'fqdn' in test_platform_facts
    assert 'domain' in test_platform_facts
    assert 'nodename' in test_platform_facts

# Generated at 2022-06-20 19:49:03.297762
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    a = PlatformFactCollector()
    assert a.collect()

# Generated at 2022-06-20 19:51:56.011138
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert 'system' in PlatformFactCollector._fact_ids
    assert 'kernel' in PlatformFactCollector._fact_ids
    assert 'kernel_version' in PlatformFactCollector._fact_ids
    assert 'machine' in PlatformFactCollector._fact_ids
    assert 'python_version' in PlatformFactCollector._fact_ids
    assert 'architecture' in PlatformFactCollector._fact_ids


# Generated at 2022-06-20 19:52:01.263076
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    obtained_facts = fact_collector.collect()
    assert obtained_facts is not None
    assert isinstance(obtained_facts, dict)
    assert obtained_facts['system'] == platform.system()
    assert obtained_facts['architecture'] == platform.machine()

# Generated at 2022-06-20 19:52:05.356990
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"

    expected_fact_ids = frozenset({'system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'})
    assert p._fact_ids == expected_fact_ids

# Generated at 2022-06-20 19:52:06.354625
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 19:52:11.742254
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert hasattr(PlatformFactCollector, 'name')
    assert hasattr(PlatformFactCollector, '_fact_ids')
    assert hasattr(PlatformFactCollector, 'collect')
    assert PlatformFactCollector.name == 'platform'
    assert isinstance(PlatformFactCollector._fact_ids, set)
    assert PlatformFactCollector.collect()['system'] == platform.system()
    assert PlatformFactCollector.collect()['kernel'] == platform.release()
    assert PlatformFactCollector.collect()['kernel_version'] == platform.version()
    assert PlatformFactCollector.collect()['machine'] == platform.machine()
    assert PlatformFactCollector.collect()['userspace_bits'] == platform.architecture()[0].replace('bit', '')
    assert PlatformFactCollector.collect()['architecture'] == platform.machine

# Generated at 2022-06-20 19:52:19.528738
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    p = PlatformFactCollector()
    d = p.collect()

    assert '*nix' in d['system']
    assert 'Linux' in d['system'] or 'BSD' in d['system'] or 'Darwin' in d['system'] \
           or 'SunOS' in d['system'] or 'AIX' in d['system']
    assert 'kernel' in d
    assert 'kernel_version' in d
    assert 'machine' in d
    assert 'python_version' in d
    assert 'architecture' in d
    assert 'userspace_architecture' in d
    assert 'userspace_bits' in d
    assert 'fqdn' in d
    assert 'hostname' in d
    assert 'nodename' in d
    assert 'domain' in d
    assert 'machine_id' in d

# Generated at 2022-06-20 19:52:26.111261
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector

    # Instantiate a PlatformFactCollector object
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert isinstance(pfc, BaseFactCollector)
    assert pfc.name == 'platform'

    # Assert _fact_ids is as expected
    assert isinstance(pfc._fact_ids, set)
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

    # Assert collect will properly collect

# Generated at 2022-06-20 19:52:35.520186
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup the class we are testing
    platform_fact_collector = PlatformFactCollector()

    # Return values from mocked methods/functions
    platform_machine = 'x86_64'
    platform_uname_return_value = ('', '', '', '', platform_machine , '')
    platform_architecture_return_value = ('64bit', 'ELF')
    socket_getfqdn_return_value = 'localhost'
    platform_python_version_return_value = '3.5.1'
    platform_release_return_value = '4.4.0-57-generic'
    platform_version_return_value = '#78-Ubuntu SMP Fri Dec 9 23:50:32 UTC 2016'
    platform_node_return_value = 'localhost'

    # Set module and facts using the mock class


# Generated at 2022-06-20 19:52:39.451926
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:52:42.308260
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    print("Test constructor of PlatformFactCollector")
    obj = PlatformFactCollector()
    assert isinstance(obj.collect(), dict)