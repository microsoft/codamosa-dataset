

# Generated at 2022-06-20 19:43:39.468151
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import FactCollector

    p = PlatformFactCollector()
    assert isinstance(p, FactCollector)
    assert p.name == 'platform'
    assert p.priority == 8
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'machine_id' in p._fact_ids

    assert p in Collectors.get_collectors()

# Generated at 2022-06-20 19:43:45.395490
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    facts = platform_collector.collect()
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['architecture'] == platform.machine()

# Generated at 2022-06-20 19:43:51.556089
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    r = PlatformFactCollector()
    assert isinstance(r._fact_ids, set)
    assert "system" in r._fact_ids
    assert "kernel" in r._fact_ids
    assert "kernel_version" in r._fact_ids
    assert "machine" in r._fact_ids
    assert "python_version" in r._fact_ids
    assert "architecture" in r._fact_ids
    assert "machine_id" in r._fact_ids

# Generated at 2022-06-20 19:44:02.044514
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    module = sys.modules['ansible.module_utils.facts.collector.platform']
    if hasattr(module, 'test_PlatformFactCollector'):
        del module.test_PlatformFactCollector
    test_PlatformFactCollector = PlatformFactCollector()
    module.test_PlatformFactCollector = test_PlatformFactCollector
    input = {}
    output = {'system': platform.system(), 'kernel': platform.release(), 'kernel_version': platform.version(), 'machine': platform.machine(), 'python_version': platform.python_version(), 'architecture': platform.machine()}

# Generated at 2022-06-20 19:44:11.318240
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, name):
            return name

        def run_command(self, command):
            if command == ['getconf', 'MACHINE_ARCHITECTURE']:
                return (0, 'ppc64', '')
            elif command == ['bootinfo', '-p']:
                return (0, '9111-520', '')

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    PlatformCollector = PlatformFactCollector()
    BaseCollector = BaseFactCollector()
    Base

# Generated at 2022-06-20 19:44:22.421932
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # TODO: refactor to ansible test module
    from ansible.module_utils.facts import FactsCollector
    from io import StringIO
    import sys
    import platform

    class FakeModule(object):
        def run_command(self, command):
            return 0, '', ''

        @staticmethod
        def get_bin_path(binary, required=False):
            return binary

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            raise Exception(kwargs['msg'])

    fake_module = FakeModule()
    collector = PlatformFactCollector()

    result = collector.collect(fake_module)

    assert 'system' in result
    assert 'kernel' in result

# Generated at 2022-06-20 19:44:25.070055
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test case for method collect of class PlatformFactCollector
    """
    fact_collector = PlatformFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 19:44:26.024110
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-20 19:44:30.941294
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import PlatformFactCollector

    c = PlatformFactCollector()
    assert isinstance(c, PlatformFactCollector)
    assert isinstance(c, BaseFactCollector)
    assert c.name == 'platform'

# Generated at 2022-06-20 19:44:42.793829
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.utils import get_file_content

    def setUpModule():
        # modules that the fail module depends on need to be
        # mocked here since each test case gets its own instance
        # of the fail module
        ansible_facts['ansible_python_version'] = 2.6

    def tearDownModule():
        # reset the fail module
        ansible_facts['ansible_python_version'] = None

    def test__openbsd_architecture(self, fs):
        fs.add_real_directory(path='/sbin')
        fs.add_real_file(path='/sbin/sysctl', contents='hw.machine=amd64')


# Generated at 2022-06-20 19:45:50.304238
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-20 19:45:57.922083
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Unit test for method collect of class PlatformFactCollector"""
    # Set up the class we are testing.
    pfc = PlatformFactCollector()

    # Call the method we are testing.
    result = pfc.collect()

    assert 'system' in result
    assert 'kernel' in result
    assert 'kernel_version' in result
    assert 'machine' in result
    assert 'python_version' in result
    assert 'architecture' in result
    assert 'userspace_bits' in result
    assert 'fqdn' in result
    assert 'hostname' in result
    assert 'nodename' in result
    assert 'domain' in result

# Generated at 2022-06-20 19:46:01.448401
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    print(platform_facts)

# This is being used as a parameter to PlatformFactCollector() call.
# module object is module class object

# Generated at 2022-06-20 19:46:11.409048
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test 1
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    class FakeModule:
        class FakeCommand:
            def __init__(self, module, cmd, run_in_check_mode=False, no_log=False, check_rc=True, environ_update=None, binary_data=False):
                self.cmd = cmd
                self.no_log = no_log
                self.check_rc = check_rc
                self.environ_update = environ_update

            def __call__(self):
                if self.cmd[0] == "getconf":
                    data = ["32/64"]
                else:
                    data = ["64-bit"]
                return 0, data, None

# Generated at 2022-06-20 19:46:16.592277
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert(p.name == 'platform')
    assert(p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id']))


# Generated at 2022-06-20 19:46:27.236511
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    pfc.collect()
    assert 'system' in pfc.collect()
    assert 'kernel' in pfc.collect()
    assert 'kernel_version' in pfc.collect()
    assert 'machine' in pfc.collect()
    assert 'python_version' in pfc.collect()
    assert 'architecture' in pfc.collect()
    assert 'machine_id' in pfc.collect()
    assert 'fqdn' in pfc.collect()
    assert 'hostname' in pfc.collect()
    assert 'nodename' in pfc.collect()
    assert 'domain' in pfc.collect()
    assert 'userspace_bits' in pfc.collect()

# Generated at 2022-06-20 19:46:38.998942
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, BaseFactCollector)
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-20 19:46:41.455069
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for testing method collect of class PlatformFactCollector
    """
    pass

# vim: set expandtab shiftwidth=4:

# Generated at 2022-06-20 19:46:46.126121
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-20 19:46:51.081478
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids

# Generated at 2022-06-20 19:48:20.607257
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    # assert that the name of sut is 'platform'
    assert platformFactCollector.name == 'platform', 'Test failed as no platform name is returned'
    # assert that the fact_ids of sut is _fact_ids
    assert platformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id']), 'Test failed as no fact ids returned'

# Generated at 2022-06-20 19:48:21.654561
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test case for class PlatformFactCollector collect method.
    """
    pass

# Generated at 2022-06-20 19:48:22.342492
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-20 19:48:26.824994
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    collector = FactCollector()
    collected_facts = collector.collect(limit='platform', gather_subset=[])
    assert collected_facts == {}

# Generated at 2022-06-20 19:48:34.148759
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def get_bin_path_result(x):
        return x

    def run_command_result(x):
        return 0, '', ''

    PlatformFactCollector.get_bin_path = get_bin_path_result
    PlatformFactCollector.run_command = run_command_result
    module = ''
    result = PlatformFactCollector().collect(module)
    assert(result['system'] == 'Linux')
    assert(result['kernel'] == '3.13.0-101-generic')
    assert(result['kernel_version'] == '')
    assert(result['machine'] == 'x86_64')
    assert(result['python_version'] == '2.7.12')
    assert(result['fqdn'] == 'linux.mjv.dev')

# Generated at 2022-06-20 19:48:38.563082
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    res = PlatformFactCollector._collect_platform_facts()

    assert res['system'] == 'Linux'
    assert res['kernel'] == '3.12.0+'
    assert res['machine_id'] == '08d1e39a52bc47bc8ca8dc1b2a234b9f'

# Generated at 2022-06-20 19:48:44.213997
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class MockModule(object):
        def get_bin_path(self, arg):
            return None

        def run_command(self, args):
            return 0, None, None

    class MockFacts(dict):
        def __init__(self):
            pass

    mock_module = MockModule()
    mock_facts = MockFacts()

    # existing machine fact is None
    mock_facts['machine'] = None
    # run method
    pfc = PlatformFactCollector()
    pfc.collect(module=mock_module, collected_facts=mock_facts)
    # assert results
    assert 'machine' not in pfc._fact_ids
    assert 'userspace_bits' in pfc._fact_ids
    assert 'userspace_architecture' in pfc._fact_ids

    # existing machine fact is

# Generated at 2022-06-20 19:48:49.773774
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert sorted(collector._fact_ids) == sorted(['system',
                                                  'kernel',
                                                  'kernel_version',
                                                  'machine',
                                                  'python_version',
                                                  'architecture',
                                                  'machine_id'])


# Generated at 2022-06-20 19:48:58.776821
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    fact_collector.collect()
    platform_facts = fact_collector.collect()

    assert platform_facts
    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['architecture']
    assert platform_facts['python_version']
    assert platform_facts['fqdn']
    assert platform_facts['hostname']
    assert platform_facts['nodename']
    assert platform_facts['domain']

# Generated at 2022-06-20 19:49:10.039730
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector(None)
    collected_facts = collector.collect(None)
    assert collected_facts["system"] == platform.system()
    assert collected_facts["kernel"] == platform.release()
    assert collected_facts["kernel_version"] == platform.version()
    assert collected_facts["machine"] == platform.machine()
    assert collected_facts["python_version"] == platform.python_version()
    assert collected_facts["fqdn"] == socket.getfqdn()
    assert collected_facts["hostname"] == platform.node().split('.')[0]
    assert collected_facts["nodename"] == platform.node()
    assert collected_facts["domain"] == '.'.join(collected_facts["fqdn"].split('.')[1:])
    assert "userspace_bits" in collected_facts

# Generated at 2022-06-20 19:52:28.101199
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()


# Generated at 2022-06-20 19:52:36.554725
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = {
        "get_bin_path": lambda *args: "/bin/getconf"
    }

# Generated at 2022-06-20 19:52:41.613650
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    test_collector = PlatformFactCollector()

    assert test_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-20 19:52:42.145680
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:52:48.178070
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert 'machine_id' in platform_facts
    assert 'architecture' in platform_facts
    assert 'hostname' in platform_facts
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'domain' in platform_facts
    assert 'nodename' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts