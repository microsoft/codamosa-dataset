

# Generated at 2022-06-20 19:43:44.710942
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-20 19:43:54.856743
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockCommand
    from ansible.module_utils.facts import collect

    module = MockModule()
    collect.add_collector(PlatformFactCollector())

    commands = {
        'bootinfo -p': MockCommand(stdout=b"pSeries"),
        'getconf MACHINE_ARCH': MockCommand(stdout=b"powerpc64"),
        'uname -m': MockCommand(stdout="x86_64"),
    }
    platform_facts = collect(module=module, commands=commands)

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts

# Generated at 2022-06-20 19:43:58.008573
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Unit test of method collect()

# Generated at 2022-06-20 19:44:02.444565
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == "platform"
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])


# Generated at 2022-06-20 19:44:11.654651
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform as PlatformFactCollectorPlatform
    import socket as PlatformFactCollectorSocket
    import re as PlatformFactCollectorRe

    class MockModule:
        class MockRunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def run_command(self, command):
                return (self.rc, self.out, self.err)

        def __init__(self, get_bin_path_return_value, run_command_return_value):
            self.get_bin_path_return_value = get_bin_path_return_value
            self.run_command_return_value = run_command_return_value

        def get_bin_path(self, executable):
            return self.get_bin_path_return

# Generated at 2022-06-20 19:44:13.256528
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'



# Generated at 2022-06-20 19:44:19.003168
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # test setUp
    collected_facts = {}
    platform_fact_collector_instance = PlatformFactCollector()
    # test call
    platform_fact_collector_instance.collect(collected_facts=collected_facts)
    # test assertions
    assert 'system' in collected_facts
    assert 'kernel' in collected_facts

# Generated at 2022-06-20 19:44:28.786990
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector(None, None)

    platform_facts = collector.collect()
    assert type(platform_facts) == dict
    assert platform_facts["system"] == platform.system()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["python_version"] == platform.python_version()
    assert platform_facts["fqdn"] == socket.getfqdn()
    assert platform_facts["nodename"] == platform.node()
    assert type(platform_facts["domain"]) == str
    assert platform_facts["domain"] == ".".join(platform_facts["fqdn"].split(".")[1:])
    assert platform_facts["hostname"]

# Generated at 2022-06-20 19:44:35.550700
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class TestModule(object):
        def __init__(self):
            self.module = True
            self.params = {}
            self.mock_commands = {
                "getconf MACHINE_ARCHITECTURE" : "",
                "bootinfo -p": "",
                "uname -i": "",
            }
            self.mock_results = {
                "getconf MACHINE_ARCHITECTURE" : (0, "PowerNV 8IH", ""),
                "bootinfo -p": (0, "PowerNV 8IH", ""),
                "uname -i": (0, "PowerNV 8IH", ""),
            }
        def get_bin_path(self, path, required=False):
            if path == "getconf":
                return "/path/to/getconf"


# Generated at 2022-06-20 19:44:40.161916
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts["system"] == "Linux"
    assert platform_facts["architecture"] == "x86_64"
    assert platform_facts["machine_id"] == "9e6b57460aeb4d7fadd47b190c184e2d"

# Generated at 2022-06-20 19:45:34.951336
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fc = PlatformFactCollector()
    out = fc.collect()

    assert isinstance(out, dict)
    assert "system" in out
    assert "kernel" in out
    assert "kernel_version" in out
    assert "machine" in out
    assert "python_version" in out
    assert "architecture" in out



# Generated at 2022-06-20 19:45:45.418616
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])
    assert platform_fact_collector.collect()['domain'] == 'localhost'
    with open('/tmp/machine-id', 'w') as machine_id_file:
        machine_id_file.write("123456789\n")

# Generated at 2022-06-20 19:45:47.549204
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test to check that the method returns a dict
    assert isinstance(PlatformFactCollector().collect(), dict)

# Generated at 2022-06-20 19:45:58.169373
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create an instance of PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()
    # Retrieve system facts
    platform_facts = platform_fact_collector.collect()
    # Assert specific facts are present
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'

# Generated at 2022-06-20 19:46:09.548289
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}
    #platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]

    platform_facts['userspace_bits'] = arch_bits.replace('bit', '')


# Generated at 2022-06-20 19:46:20.298083
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    PlatformFactCollector - Test method collect
    """

    _platform_facts = {
        'python_version': '3.6.4',
        'machine_id': 'abcdef1234567890abcdef',
        'system': 'AIX',
        'fqdn': 'AIX-P8.example.org',
        'kernel_version': '3.8.0-44-generic',
        'domain': 'example.org',
        'machine': 'powerpc',
        'nodename': 'AIX-P8',
        'architecture': 'powerpc',
        'kernel': '3.8.0-44-generic',
        'hostname': 'AIX-P8',
        'userspace_architecture': 'ppc64'
    }

    pfc = PlatformFactCollector

# Generated at 2022-06-20 19:46:30.535549
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Clean the platform module cache
    platform.system.cache_clear()

    # Mock
    def platform_system():
        return 'Linux'

    def platform_release():
        return '2.6.32-504.el6.x86_64'

    def platform_version():
        return '#1 SMP Wed Oct 15 04:27:16 UTC 2014'

    def platform_machine():
        return 'x86_64'

    def platform_python_version():
        return '2.7.5'

    def getfqdn():
        return 'testhost.example.com'

    def platform_node():
        return 'testhost.example.com'


# Generated at 2022-06-20 19:46:41.588904
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
        Not an actual unit test, this function is used to build the source for ``PlatformFactCollectorTest.yml``

        :return: Returns a dictionary containing the mock facts collected by this collector
        :rtype: dict
    """
    import platform
    test_data = {}
    test_data['system'] = platform.system()
    test_data['kernel'] = platform.release()
    test_data['kernel_version'] = platform.version()
    test_data['machine'] = platform.machine()
    test_data['python_version'] = platform.python_version()
    test_data['fqdn'] = socket.getfqdn()
    test_data['hostname'] = platform.node().split('.')[0]
    test_data['nodename'] = platform.node()

# Generated at 2022-06-20 19:46:50.067697
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def mock_platform_system(self):
        return 'AIX'

    def mock_platform_release(self):
        return '7.2.0.0'

    def mock_platform_version(self):
        return '7200-02-00-000'

    def mock_platform_machine(self):
        return 'pSeries'

    def mock_platform_python_version(self):
        return '2.7.1'

    def mock_platform_node(self):
        return 'c9100.ambari.apache.org'

    def mock_platform_uname(self):
        return ('AIX', 'c9100', '7', '2', '00013C00C00', 'ppc')

    def mock_get_bin_path(self, name):
        return '/usr/bin/' + name

# Generated at 2022-06-20 19:47:01.004416
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    #
    # Mock methods and variables
    #

    #
    # Variables
    #

    # Replace this with the output of platform.python_version() on your
    # system
    python_version = '2.7.13'

    # Replace this with the output of platform.machine()
    # on your system
    machine = 'x86_64'

    # Replace this with the output of platform.release() on your system
    kernel = '4.4.0-62-generic'

    # Replace this with the output of platform.system() on your system
    system = 'Linux'

    # Replace this with the output of platform.version() on your system
    kernel_version = '#83-Ubuntu SMP Wed Jan 18 14:10:15 UTC 2017'

    # Replace this with the output of platform.uname() on your
   

# Generated at 2022-06-20 19:48:30.882105
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector_platform = PlatformFactCollector()
    facts = collector_platform.collect()
    assert isinstance(facts, dict), 'Facts should be a dict'
    assert len(facts) >= 1, 'Fact should contain more than one element'
    for key in ['system', 'kernel_version', 'kernel', 'machine', 'fqdn',
                'hostname', 'architecture', 'userspace_bits']:
        assert key in facts, "Fact returned should contain %s" % key

# Generated at 2022-06-20 19:48:32.525662
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts_collector = PlatformFactCollector()
    assert isinstance(platform_facts_collector.collect(), dict)

# Generated at 2022-06-20 19:48:39.534663
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module_mock = AnsibleModuleMock()
    module_mock.run_command = MagicMock(return_value=(0, "", ""))

    pfc = PlatformFactCollector()
    pfc.collect(module=module_mock)

    assert "system" in pfc.collect()
    assert "kernel" in pfc.collect()
    assert "kernel_version" in pfc.collect()
    assert "machine" in pfc.collect()
    assert "python_version" in pfc.collect()
    assert "architecture" in pfc.collect()
    assert "machine_id" in pfc.collect()

# Generated at 2022-06-20 19:48:43.451360
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert isinstance(platform_facts['system'], str)
    assert 'kernel' in platform_facts

# Generated at 2022-06-20 19:48:54.498850
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    assert platform.system() == 'AIX'

    cidr = '192.168.2.0/24'
    filename = cidr.split('/')[0]
    collector = PlatformFactCollector(module=module, collected_facts=None)
    platform_facts = collector.collect()

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]


# Generated at 2022-06-20 19:49:02.841532
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test PlatformFactCollector.collect()"""
    # Initialize PlatformFactCollector instance
    platform = PlatformFactCollector()
    # Call PlatformFactCollector.collect
    result = platform.collect()
    # Verify the result
    assert result["system"] == platform.system()
    assert result["kernel"] == platform.kernel()
    assert result["kernel_version"] == platform.kernel_version()
    assert result["machine"] == platform.machine()
    assert result["python_version"] == platform.python_version()

# Generated at 2022-06-20 19:49:05.034690
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['architecture',
                               'fqdn',
                               'home',
                               'hostname',
                               'machine',
                               'machine_id',
                               'nodename',
                               'python_version',
                               'system',
                               'userspace_architecture',
                               'userspace_bits'])

# Generated at 2022-06-20 19:49:13.480630
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert 'system' in platform_facts._fact_ids
    assert 'kernel' in platform_facts._fact_ids
    assert 'kernel_version' in platform_facts._fact_ids
    assert 'machine' in platform_facts._fact_ids
    assert 'python_version' in platform_facts._fact_ids
    assert 'architecture' in platform_facts._fact_ids
    assert 'machine_id' in platform_facts._fact_ids


# Generated at 2022-06-20 19:49:15.781807
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-20 19:49:26.742799
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create an instance of PlatformFactCollector
    pfc = PlatformFactCollector()

    # Test the method collect

# Generated at 2022-06-20 19:52:45.346553
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert isinstance(x._fact_ids, set)
    assert len(x._fact_ids) == 11
    assert 'system' in x._fact_ids
    assert 'kernel' in x._fact_ids
    assert 'kernel_version' in x._fact_ids
    assert 'machine' in x._fact_ids
    assert 'python_version' in x._fact_ids
    assert 'architecture' in x._fact_ids
    assert 'machine_id' in x._fact_ids


# Generated at 2022-06-20 19:52:47.094197
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert isinstance(p, PlatformFactCollector)
    assert p.name == 'platform'
