

# Generated at 2022-06-23 01:29:38.999904
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect() == {
        'system' : platform.system(),
        'kernel' : platform.release(),
        'kernel_version' : platform.version(),
        'machine' : platform.machine(),
        'python_version' : platform.python_version(),
        'fqdn' : socket.getfqdn(),
        'hostname' : platform.node().split('.')[0],
        'nodename' : platform.node(),
        'domain' : '.'.join(socket.getfqdn().split('.')[1:]),
        'architecture' : platform.machine(),
        'userspace_bits' : platform.architecture()[0].replace('bit', '')
    }

# Generated at 2022-06-23 01:29:46.765681
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # mock module and collected_facts
    module = MockAnsibleModule()
    collected_facts = {'kernel': 'Linux'}

    # instantiate PlatformFactCollector
    platform_collector = PlatformFactCollector(module=module)

    # call collect
    platform_collector.collect(module=module, collected_facts=collected_facts)
    # assert output
    assert module.warn.called
    assert module.warn.call_args[0][0].startswith('Could not gather possible kernel facts')


# Generated at 2022-06-23 01:29:56.663315
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create an instance of PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()

    # Test if the method collect of PlatformFactCollector is working correctly
    platform_facts_returned = platform_fact_collector.collect()

    # Test the keys "system", "kernel", "kernel_version", "machine", "python_version", "architecture" of the dict returned
    platform_facts_keys = ["system", "kernel", "kernel_version", "machine", "python_version", "architecture"]

    assert set(platform_facts_keys).issubset(set(platform_facts_returned.keys())), "Error in PlatformFactCollector.collect method"

    # Test that the method collect returns a dict
    assert isinstance(platform_facts_returned, dict), "Error in PlatformFactCollector.collect method"

# Generated at 2022-06-23 01:30:01.996760
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert 'architecture' in p._fact_ids
    assert 'machine_id' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'system' in p._fact_ids
    assert p.name not in p._fact_ids

# Generated at 2022-06-23 01:30:06.370292
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids


# Generated at 2022-06-23 01:30:07.230592
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:30:13.761591
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module_mock = Mock()
    module_mock.get_bin_path.return_value = "/bin/getconf"
    module_mock.run_command.return_value = (0, 'line1\nline2', '')
    # initialize class instance
    platform_collector = PlatformFactCollector()
    # call class method collect
    platform_facts = platform_collector.collect(module_mock)
    assert "system" in platform_facts
    assert "architecture" in platform_facts
    assert "machine_id" not in platform_facts


# Generated at 2022-06-23 01:30:15.345202
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-23 01:30:19.209722
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    fact_ids = pfc._fact_ids
    assert fact_ids == set(['system',
                    'kernel',
                    'kernel_version',
                    'machine',
                    'python_version',
                    'architecture'])

# Generated at 2022-06-23 01:30:24.562217
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert isinstance(pf._fact_ids, set)
    assert pf._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])



# Generated at 2022-06-23 01:30:27.218606
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    myPlatformFactCollector = PlatformFactCollector()
    myPlatformFactCollector.collect()
    assert type(myPlatformFactCollector._fact_ids) is set
    assert type(myPlatformFactCollector.name) is str

# Generated at 2022-06-23 01:30:32.074454
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:30:37.216829
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-23 01:30:41.066854
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    fact_ids = set(['system', 'kernel', 'kernel_version', 'machine',
                    'python_version', 'architecture', 'machine_id'])
    assert pfc._fact_ids == fact_ids

# Generated at 2022-06-23 01:30:44.405328
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_platformFactCollector = PlatformFactCollector()
    assert test_platformFactCollector is not None

# Generated at 2022-06-23 01:30:51.320801
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts.collector import collector_factory
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    collector = collector_factory(PlatformFactCollector)

    assert collector is PlatformFactCollector
    assert collector.name == 'platform'

    collected_facts = collector.collect()

    assert isinstance(collected_facts, dict)
    assert 'system' in collected_facts
    assert 'kernel' in collected_facts
    assert 'kernel_version' in collected_facts
    assert 'machine' in collected_facts
    assert 'python_version' in collected_facts
    assert 'architecture' in collected_facts
    assert 'machine_id' in collected_facts


if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-23 01:30:53.047065
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    coll = PlatformFactCollector()
    assert coll

# Generated at 2022-06-23 01:30:58.902842
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instantiate a collector class
    platform_facts_collector = PlatformFactCollector()
    platform_facts_collector.collect()
    # Check that the collected facts match the expected ones
    assert set(platform_facts_collector.get_facts().keys()) == set(platform_facts_collector._fact_ids)

# Generated at 2022-06-23 01:31:04.169664
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    pfc = PlatformFactCollector()
    fact_list = pfc.collect(module=Collector())
    for fact in fact_list:
        assert isinstance(fact, str)
        assert isinstance(fact_list[fact], (type(None), str, int))

# Generated at 2022-06-23 01:31:13.898944
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # This test is somewhat different than others, because
    # by default, the global in platform.dist will be
    # initialized the first time we import platform.
    # Thus, we need to unset that variable and
    # reinitialize it to the empty string so that
    # our mocked-out platform.linux_distribution()
    # function gets invoked.
    # pylint: disable=unused-variable
    dist = platform.dist()
    dist = None
    del dist

    # set the platorm.dist to be the mocked-out function
    platform.dist = lambda: (None, None, None)

    # construct a PlatformFactCollector
    pfc = PlatformFactCollector()

    # fact_collection_warnings should be empty list
    assert pfc.fact_collection_warnings == []

    # fact_collection_warnings

# Generated at 2022-06-23 01:31:15.284671
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    pfc.collect()

# Generated at 2022-06-23 01:31:20.643975
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-23 01:31:25.940247
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # create an instance of PlatformFactCollector
    pfc = PlatformFactCollector()
    assert pfc.name == "platform"
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:31:30.366710
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


# Generated at 2022-06-23 01:31:34.185384
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert PlatformFactCollector._fact_ids.issubset(x._fact_ids)

# Generated at 2022-06-23 01:31:39.755866
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Unit test for method collect of class PlatformFactCollector."""
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-23 01:31:41.328568
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector()
    assert platform.collect()

# Generated at 2022-06-23 01:31:45.909884
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert set(platform_collector._fact_ids) == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:31:53.221560
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert sorted(x._fact_ids) == ['architecture', 'domain', 'fqdn', 'hostname', 'kernel', 'kernel_version', 'machine', 'machine_id', 'nodename', 'python_version', 'system', 'userspace_architecture', 'userspace_bits']


# Generated at 2022-06-23 01:31:59.116588
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # set default args
    set_module_args({})
    PlatformFactCollector()
    # Check if the returned facts are adequate
    assertFacts(dict(ansible_architecture='x86_64', ansible_machine='x86_64',
                     ansible_machine_id=None, ansible_system='Linux',
                     ansible_userspace_bits='64', ansible_userspace_architecture='x86_64'))

# Generated at 2022-06-23 01:32:05.393918
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts_collector = PlatformFactCollector()
    platform_facts = platform_facts_collector.collect()
    test_host = platform.node()

    assert len(platform_facts) > 0
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == test_host.split('.')[0]
    assert platform_facts['nodename'] == test_host

# Generated at 2022-06-23 01:32:10.123142
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                               'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:32:14.261672
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create instance of PlatformFactCollector
    platform_collector = PlatformFactCollector()

    # Assert that the necessary attributes are set
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-23 01:32:16.538701
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-23 01:32:27.405756
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform

    import ansible.module_utils.facts.collector

    from ansible.module_utils.facts import Collector

    import ansible.module_utils.facts.collectors.platform

    import ansible.module_utils.facts.utils

    # The following is the output of [platform.system(), platform.release(), platform.version(), platform.machine()] on my linux virtual machine. 
    platform_system = platform.system()
    platform_release = platform.release()
    platform_version = platform.version()
    platform_machine = platform.machine()

    platform_facts = ansible.module_utils.facts.collectors.platform.PlatformFactCollector.collect(ansible.module_utils.facts.collectors.platform.PlatformFactCollector, None, None)

    assert platform_facts["system"] == platform_system

# Generated at 2022-06-23 01:32:29.247254
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector.platform import Platfo

# Generated at 2022-06-23 01:32:32.871286
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    x = PlatformFactCollector()

    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:32:35.403162
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-23 01:32:37.158903
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)

# Generated at 2022-06-23 01:32:39.844747
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    parser = PlatformFactCollector()
    assert parser.name == 'platform'

# Generated at 2022-06-23 01:32:49.406609
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # create test instance, capture return
    fact_collector = PlatformFactCollector()
    fact_collector_return = fact_collector.collect()

    # verify expected keys are returned
    fact_collector_return_keys = fact_collector_return.keys()
    assert 'system' in fact_collector_return_keys
    assert 'kernel' in fact_collector_return_keys
    assert 'kernel_version' in fact_collector_return_keys
    assert 'machine' in fact_collector_return_keys
    assert 'python_version' in fact_collector_return_keys
    assert 'architecture' in fact_collector_return_keys
    assert 'machine_id' in fact_collector_return_keys

    # verify values are consistent

# Generated at 2022-06-23 01:32:57.004834
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class PlatformFactCollectorMock(PlatformFactCollector):
        """
        This class mocks the module PlatformFactCollector used for testing the collect function
        """
        def __init__(self):
            super(PlatformFactCollectorMock, self).__init__()

        def get_bin_path(self, binary):
            binary_path = {'getconf': True, 'bootinfo': True}
            return binary_path[binary]

    module = None
    fact_collector_mock_object = PlatformFactCollectorMock()
    facts = {'system': 'AIX'}
    fact_collector_mock_object.collect(module, facts)

# Generated at 2022-06-23 01:33:02.694490
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert p.collect()
    assert p.collect()['architecture'] == platform.machine()

# Generated at 2022-06-23 01:33:06.839209
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version', 'machine',
                             'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-23 01:33:15.450285
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def test_module(module):
        return ('/bin/true', None)

    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import ModuleDeps
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    platform_facts = Collector(ModuleDeps(), test_module).collect(get_file_content)

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'userspace_bits' in platform_facts

# Generated at 2022-06-23 01:33:20.029933
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert(pfc.name == 'platform')
    assert(pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id']))


# Generated at 2022-06-23 01:33:23.062891
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
#	platform_collector = PlatformFactCollector()
#	test_dict = platform_collector.collect()
	#TODO
	assert True

# Generated at 2022-06-23 01:33:31.632672
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import mock

    module = mock.Mock()
    module.get_bin_path.return_value=True

    platform_facts = PlatformFactCollector().collect(module=module)

    assert 'system' in platform_facts.keys()
    assert 'kernel' in platform_facts.keys()
    assert 'kernel_version' in platform_facts.keys()
    assert 'machine' in platform_facts.keys()
    assert 'python_version' in platform_facts.keys()
    assert 'architecture' in platform_facts.keys()
    assert 'machine_id' in platform_facts.keys()
    assert 'fqdn' in platform_facts.keys()
    assert 'hostname' in platform_facts.keys()
    assert 'nodename' in platform_facts.keys()
    assert 'domain' in platform_facts.keys

# Generated at 2022-06-23 01:33:34.780611
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert pfc.name == 'platform'

# Generated at 2022-06-23 01:33:44.659953
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert len(PlatformFactCollector._fact_ids) == 9
    assert len(set(PlatformFactCollector._fact_ids) & set(PlatformFactCollector.__dict__)) == 0
    assert len(set(PlatformFactCollector._fact_ids) & set(PlatformFactCollector.collect.__code__.co_varnames)) == 9
    assert len(set(PlatformFactCollector._fact_ids) & set(PlatformFactCollector.collect.__code__.co_varnames[:PlatformFactCollector.collect.func_code.co_argcount])) == 9
    assert set(PlatformFactCollector._fact_ids) <= set(PlatformFactCollector.collect.__code__.co_varnames)

# Generated at 2022-06-23 01:33:50.005042
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:33:59.772170
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector

    m_module = basic.AnsibleModule(argument_spec={})

    # Setup the collector instance and run the command
    platform_collector = ansible_collector.get_collector(m_module, 'platform')
    results = platform_collector.collect(module=m_module, collected_facts={})

    # Assert that the node name is set
    assert results['system'], 'Platform system is not set'

    # Assert that the kernel is set
    assert results['kernel'], 'Platform kernel is not set'

    # Assert that the kernel version is set
    assert results['kernel_version'], 'Platform kernel version is not set'



# Generated at 2022-06-23 01:34:04.677588
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector()
    expected_platform_facts = {
        'system': platform.system(),
        'kernel': platform.release(),
        'kernel_version': platform.version(),
        'machine': platform.machine(),
        'architecture': platform.machine(),
        'python_version': platform.python_version(),
        'fqdn': socket.getfqdn()
    }
    actual_platform_facts = platform.collect()
    assert actual_platform_facts == expected_platform_facts

# Generated at 2022-06-23 01:34:10.168579
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat_fc = PlatformFactCollector()
    assert plat_fc.name == 'platform'
    assert plat_fc._fact_ids == set(['system',
                                     'kernel',
                                     'kernel_version',
                                     'machine',
                                     'python_version',
                                     'architecture',
                                     'machine_id'])



# Generated at 2022-06-23 01:34:20.403613
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def get_bin_path(self, path):
            return path

        def run_command(self, args):
            if args == ['getconf', 'MACHINE_ARCHITECTURE']:
                return 0, "POWERPC64\n", ""
            elif args == ['bootinfo', '-p']:
                return 0, "powerpc\n", ""
            elif args == ['getconf', 'MACHINE_IS_64_BIT']:
                return 0, "1\n", ""
            return 0, "", ""

    module = MockModule()
    platform_obj = PlatformFactCollector()

    facts = platform_obj.collect(module)

    assert facts["system"] == "AIX"
    assert facts["architecture"] == "POWERPC64"

# Generated at 2022-06-23 01:34:25.244189
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None
    assert platform_fact_collector.name is not None
    assert platform_fact_collector._fact_ids is not None
    assert len(platform_fact_collector._fact_ids) == 10
    assert platform_fact_collector.name == 'platform'
    assert isinstance(platform_fact_collector, BaseFactCollector)

# Generated at 2022-06-23 01:34:29.340920
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert x.name == 'platform'

# Generated at 2022-06-23 01:34:39.593260
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    To test method collect of class PlatformFactCollector
    """
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    class MockModule(object):
        """
        To mock class Module.
        """
        def __init__(self):
            self.params = {}
            self._debug = None
            self._fact_cache = dict()
            self.exit_json = AnsibleExitJson()
            self.fail_json = AnsibleFailJson()
            self.client = 'local'

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd):
            """
            To simulate run_command in module
            """
            return 0, "", ""

    module

# Generated at 2022-06-23 01:34:40.169408
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:34:47.151939
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    ansible_module = FakeAnsibleModule()
    result = platform_fact_collector.collect(ansible_module)

    assert result
    assert result["system"]
    assert result["kernel"]
    assert result["kernel_version"]
    assert result["machine"]
    assert result["python_version"]
    assert result["architecture"]
    assert result["fqdn"]
    assert result["hostname"]
    assert result["nodename"]
    assert result["domain"]
    assert result["userspace_bits"]
    assert result["userspace_architecture"]


# Generated at 2022-06-23 01:34:50.984554
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # try:
    #     x = PlatformFactCollector()
    #     assert x is not None
    # except Exception as e:
    #     raise AssertionError("Constructor of class PlatformFactCollector does not work as expected.") from e
    assert True

# Generated at 2022-06-23 01:34:58.028310
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector.collect() == dict(
        architecture='x86_64',
        domain='',
        fqdn='localhost.localdomain',
        hostname='localhost',
        kernel='4.4.0-93-generic',
        kernel_version='#116-Ubuntu SMP Mon Aug 21 14:29:09 UTC 2017',
        machine='x86_64',
        nodename='localhost.localdomain',
        python_version='2.7.12',
        system='Linux',
    )

# Generated at 2022-06-23 01:35:02.799770
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts

# Generated at 2022-06-23 01:35:08.545760
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Check if we can run collect without argument and without module
    try:
        plat_fac_coll = PlatformFactCollector()
        facts = plat_fac_coll.collect()
    except:
        pass
    else:
        assert isinstance(facts, dict)
        assert 'system' in facts
        assert 'kernel' in facts
        assert 'kernel_version' in facts
        assert 'machine' in facts
        assert 'python_version' in facts
        assert 'architecture' in facts


# Generated at 2022-06-23 01:35:12.951242
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:35:17.066107
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()

    assert pfc is not None
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version',
                             'architecture', 'machine_id'}


# Generated at 2022-06-23 01:35:22.786732
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    PlatformFactCollector = PlatformFactCollector()
    platform_facts = PlatformFactCollector.collect()
    assert not platform_facts.has_key('_system'), "PlatformFactCollector.collect returned unexpected keys: %s" % platform_facts.keys()
    assert platform_facts['system'] == 'Linux', "PlatformFactCollector.collect returned invalid 'system': %s" % platform_facts['system']

# Generated at 2022-06-23 01:35:34.790044
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Mock platform to pass values for testing
    import sys, platform
    class MockPlatform(object):
        system = "AIX"
        release = "7.1.0.0"
        version = "1"
        machine = "powerpc"
    platform.system = lambda: MockPlatform.system
    platform.release = lambda: MockPlatform.release
    platform.version = lambda: MockPlatform.version
    platform.machine = lambda: MockPlatform.machine
    sys.modules['platform'] = platform

    # Mock module to pass values for testing
    class MockModule(object):
        def get_bin_path(arg):
            if arg == "getconf":
                return "/usr/sbin/getconf"
            elif arg == "bootinfo":
                return "/usr/sbin/bootinfo"
    module = MockModule()

    #

# Generated at 2022-06-23 01:35:37.886787
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert len(pfc._fact_ids) == 8

# Generated at 2022-06-23 01:35:40.566674
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector({}).collect()
    assert isinstance(platform_facts, dict)

# Generated at 2022-06-23 01:35:49.899765
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = dict()
    test_platform_facts['system'] = platform.system()
    test_platform_facts['kernel'] = platform.release()
    test_platform_facts['kernel_version'] = platform.version()
    test_platform_facts['python_version'] = platform.python_version()
    test_platform_facts['fqdn'] = socket.getfqdn()
    test_platform_facts['domain'] = '.'.join(test_platform_facts['fqdn'].split('.')[1:])

    platform_collector = PlatformFactCollector()
    assert platform_collector
    assert platform_collector.name == 'platform'
    assert platform_collector.collect() == test_platform_facts

# Generated at 2022-06-23 01:35:59.874036
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            pass

        def get_bin_path(self, command):
            return "/usr/bin/%s" % command

    m = TestModule()
    f = FactsCollector()
    f.collector['platform'] = PlatformFactCollector(m)
    f.collect(m)
    FIELDS_NOT_ALLOWED = ('fqdn', 'hostname', 'nodename', 'domain')

# Generated at 2022-06-23 01:36:08.743456
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup
    module = MagicMock()
    module.get_bin_path.return_value = None
    module.run_command.return_value = (True, "machine_architecture_value", None)

    pfc = PlatformFactCollector(module=module)

    # Test
    assert pfc.collect() == {'system': 'Linux', 'architecture': 'machine_architecture_value',
                             'userspace_bits': '64', 'kernel': '2.6.32-431.el6.x86_64',
                             'kernel_version': '#1 SMP Fri Nov 22 03:15:09 UTC 2013',
                             'machine': 'x86_64', 'python_version': '3.6.3'}

# Generated at 2022-06-23 01:36:12.717968
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    instance = PlatformFactCollector()
    assert instance.name == 'platform'
    assert instance._fact_ids == {'system',
                                  'kernel',
                                  'kernel_version',
                                  'machine',
                                  'python_version',
                                  'architecture',
                                  'machine_id'}

# Generated at 2022-06-23 01:36:19.972444
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys

    if sys.version_info >= (2, 7):
        import unittest
    else:
        import unittest2 as unittest

    from ansible.module_utils.facts.collector import BaseFactCollector

    # create the mock module
    module = type('MockModule', (object,), {
        'run_command': (lambda self, command, check_rc=True: (0, 'a', '')),
        'get_bin_path': (lambda self, binary: binary),
    })()

    fact_collector = PlatformFactCollector()

    # create the expected results

# Generated at 2022-06-23 01:36:30.877536
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform
    import os

    # Initialize a PlatformFactCollector object
    platform_collector = PlatformFactCollector()

    # Initialize a mock AnsibleModule object
    module = AnsibleModuleMock()

    # Initialize facts from collector
    platform_facts = platform_collector.collect(module=module)

    # Initialize expected facts
    expected_facts = {}
    expected_facts['system'] = platform.system()
    expected_facts['kernel'] = platform.release()
    expected_facts['kernel_version'] = platform.version()
    expected_facts['machine'] = platform.machine()

    expected_facts['python_version'] = platform.python_version()

    expected_facts['fqdn'] = socket.getfqdn()
    expected_facts['hostname'] = platform.node().split('.')[0]

# Generated at 2022-06-23 01:36:40.054720
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create instance of PlatformFactCollector class
    pfc = PlatformFactCollector()

    # test the name attribute
    assert pfc.name == "platform"

    # test the _fact_ids attribute
    assert "system" in pfc._fact_ids
    assert "kernel" in pfc._fact_ids
    assert "kernel_version" in pfc._fact_ids
    assert "machine" in pfc._fact_ids
    assert "python_version" in pfc._fact_ids
    assert "architecture" in pfc._fact_ids
    assert "machine_id" in pfc._fact_ids
    assert len(pfc._fact_ids) == 7

# Generated at 2022-06-23 01:36:49.755203
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:36:55.126402
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    module.get_bin_path = Mock(return_value="/usr/bin/bootinfo")
    module.run_command = Mock(return_value=(0, "pSeries\n", None))
    platform_facts_collector = PlatformFactCollector()
    platform_facts_collector.collect(module=module)

# Generated at 2022-06-23 01:36:55.743594
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:37:00.268571
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:37:05.779453
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instantiate object PlatformFactCollector
    pfc = PlatformFactCollector()
    # Invoke method collect
    pfc.collect()
    # Check attributes of object PlatformFactCollector
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version',
                             'machine', 'python_version', 'architecture',
                             'machine_id'}

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-23 01:37:10.546692
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat_fc = PlatformFactCollector()
    assert plat_fc.name == 'platform'
    assert plat_fc._fact_ids == set(['system',
                                     'kernel',
                                     'kernel_version',
                                     'machine',
                                     'python_version',
                                     'architecture',
                                     'machine_id'])


# Generated at 2022-06-23 01:37:16.180585
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-23 01:37:17.780942
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    a = PlatformFactCollector()
    assert isinstance(a, PlatformFactCollector)

# Generated at 2022-06-23 01:37:22.486272
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:37:29.172119
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_facts_collector = PlatformFactCollector()

    assert platform_facts_collector is not None
    assert platform_facts_collector.name == 'platform'
    assert set(platform_facts_collector._fact_ids) == set(['system',
                                                           'kernel',
                                                           'kernel_version',
                                                           'machine',
                                                           'python_version',
                                                           'architecture',
                                                           'machine_id'])

# Generated at 2022-06-23 01:37:34.916804
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    tcp_collector = PlatformFactCollector()

    assert tcp_collector.name == 'platform'
    assert 'system' in tcp_collector._fact_ids
    assert 'kernel' in tcp_collector._fact_ids
    assert 'kernel_version' in tcp_collector._fact_ids
    assert 'machine' in tcp_collector._fact_ids
    assert 'python_version' in tcp_collector._fact_ids
    assert 'architecture' in tcp_collector._fact_ids
    assert 'machine_id' in tcp_collector._fact_ids

# Generated at 2022-06-23 01:37:37.314842
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 01:37:42.895452
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec=dict())
    module.exit_json = lambda x: x
    platform_facts_collector = PlatformFactCollector()
    result = platform_facts_collector.collect(module=module)
    assert 'system' in result
    assert 'kernel' in result
    assert 'kernel_version' in result
    assert 'machine' in result
    assert 'nodename' in result
    assert 'fqdn' in result
    assert 'domain' in result
    assert 'python_version' in result
    assert 'userspace_bits' in result
    assert 'userspace_architecture' in result
    assert 'machine_id' in result

# Generated at 2022-06-23 01:37:48.739118
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import ansible.module_utils.facts.platform.linux
    plat = ansible.module_utils.facts.platform.linux.LinuxFactCollector()
    fact = plat.collect()
    assert fact['system'] == 'Linux'
    assert fact['architecture'] == 'x86_64'
    assert fact['userspace_architecture'] == 'x86_64'

# Generated at 2022-06-23 01:37:54.792347
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert isinstance(x, PlatformFactCollector)
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert isinstance(x._fact_ids, set)


# Generated at 2022-06-23 01:38:01.458579
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector(None)

    result = collector.collect()
    assert result['machine'] == 'x86_64'
    assert result['architecture'] == 'x86_64'
    assert result['python_version'] == '3.6.8'
    assert result['kernel'] == '4.15.18-1-MANJARO'
    assert result['kernel_version'] == '#1 SMP PREEMPT Sun Dec 2 14:51:29 CET 2018'
    assert result['system'] == 'Linux'

# Generated at 2022-06-23 01:38:13.598166
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    facts = platform_collector.collect()

    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['fqdn'] == socket.getfqdn()
    assert facts['hostname'] == platform.node().split('.')[0]
    assert facts['nodename'] == platform.node()
    assert facts['domain'] == '.'.join(facts['fqdn'].split('.')[1:])
    assert facts['userspace_bits'] == platform.architecture()[0].replace('bit', '')

# Generated at 2022-06-23 01:38:24.623689
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create instance
    PlatformFactCollector_instance = PlatformFactCollector()
    assert PlatformFactCollector_instance is not None

    # Read input
    # Create a file called "platform.py" in the same directory as this file
    # And paste the following within the file:
    #  import platform
    #  if __name__ == '__main__':
    #      print(platform.python_version())
    #      print(platform.machine())
    #      print(platform.architecture()[0])
    #      print(platform.node())
    # Make the file executable, and run it
    # Now paste the output of the file here
    input_file = open('platform.py', "r")
    input_data_list = input_file.readlines()
    input_file.close()

    # Set input
   

# Generated at 2022-06-23 01:38:30.070786
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert 'system' in platform_collector._fact_ids
    assert 'kernel' in platform_collector._fact_ids
    assert 'kernel_version' in platform_collector._fact_ids
    assert 'machine' in platform_collector._fact_ids
    assert 'python_version' in platform_collector._fact_ids
    assert 'architecture' in platform_collector._fact_ids
    assert 'machine_id' in platform_collector._fact_ids

# Generated at 2022-06-23 01:38:36.272584
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert (PlatformFactCollector.name == "platform")
    assert (PlatformFactCollector.priority == 80)
    assert (PlatformFactCollector._fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id']))

# Generated at 2022-06-23 01:38:38.913422
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'

# Generated at 2022-06-23 01:38:39.652218
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x

# Generated at 2022-06-23 01:38:46.387502
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert 'system' in platform_facts._fact_ids
    assert 'kernel' in platform_facts._fact_ids
    assert 'kernel_version' in platform_facts._fact_ids
    assert 'machine' in platform_facts._fact_ids
    assert 'python_version' in platform_facts._fact_ids
    assert 'architecture' in platform_facts._fact_ids
    assert 'machine_id' in platform_facts._fact_ids

# Generated at 2022-06-23 01:38:49.069327
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector(None)
    assert platform_fact_collector.name == "platform"
    assert platform_fact_collector.collect() == {}

# Generated at 2022-06-23 01:38:54.146132
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
  fact_collector = PlatformFactCollector()
  assert fact_collector.name == 'platform'
  assert fact_collector._fact_ids == set(['system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id'])

# Generated at 2022-06-23 01:39:04.181552
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import re

    _platform = platform
    _socket = socket

    class Module(object):
        def __init__(self):
            self.user_specified_bin_path = None
            self.fact_cache = {}
            self.params = {}

        def get_bin_path(self, arg1):
            return self.user_specified_bin_path

        def run_command(self, arg1):
            return 0, '', ''

    class Platform(object):
        def __init__(self):
            self.system_return_value = 'Linux'
            self.release_return_value = '4.1.6-200.fc22.x86_64'
            self.version_return_value = '#1 SMP Wed Oct 21 11:01:51 UTC 2015'
            self

# Generated at 2022-06-23 01:39:05.668831
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'

# Generated at 2022-06-23 01:39:13.819805
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:39:18.283841
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.name == 'platform'
    assert platform._fact_ids == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])

# Generated at 2022-06-23 01:39:28.150762
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def fake_get_file_content(filename):
        content = {
            "/var/lib/dbus/machine-id": "1\n",
            "/etc/machine-id": "2\n"
        }
        return content.get(filename, "")

    def fake_get_bin_path(binary):
        return binary

    import platform

    def fake_platform_system():
        return "Linux"

    def fake_platform_python_version():
        return "2.7.5"

    def fake_platform_node():
        return "test_node.example.com"

    def fake_platform_architecture():
        return ("64bit", "ELF")

    def fake_platform_release():
        return "3.10.0-229.el7.x86_64"


# Generated at 2022-06-23 01:39:35.044681
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    collection = PlatformFactCollector(module)
    collection.collect()
    facts = module.exit_json.get('ansible_facts', {})
    assert 'ansible_system' in facts
    assert 'ansible_machine' in facts
    assert 'ansible_nodename' in facts
    assert 'ansible_python_version' in facts
    assert 'ansible_fqdn' in facts
    assert 'ansible_domain' in facts
    assert 'ansible_architecture' in facts
    assert 'ansible_machine_id' in facts