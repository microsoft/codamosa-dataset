

# Generated at 2022-06-23 01:29:32.923630
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert sorted(pf._fact_ids) == sorted(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-23 01:29:35.201164
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform', 'Platform fact collector should be named platform.'
    assert platform.system() in pfc._fact_ids, 'System fact should be gathered'

# Generated at 2022-06-23 01:29:45.242869
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, BaseFactCollector)
    assert sorted(pfc._fact_ids) == sorted(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])
    assert pfc._platform == None


# Generated at 2022-06-23 01:29:48.791870
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """check if PlatformFactCollector constructor works"""
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids is not None
    assert PlatformFactCollector.name in PlatformFactCollector._fact_ids


# Generated at 2022-06-23 01:29:54.282444
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformCollector = PlatformFactCollector()
    assert platformCollector.name == 'platform'
    assert platformCollector._fact_ids == set(['system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'])

# Generated at 2022-06-23 01:29:58.202176
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pf = PlatformFactCollector()
    results = pf.collect()
    # test if we get a dict
    assert isinstance(results, dict)
    # test that we get a dict with the keys from _fact_ids
    assert set(results.keys()).issuperset(pf._fact_ids)

# Generated at 2022-06-23 01:30:03.416375
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # create an instance of the PlatformFactCollector class
    collect = PlatformFactCollector()

    assert collect.name == 'platform' # test the name attribute
    assert collect._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id']) # test the _fact_ids attribute
    assert not collect.collect() # test the collect method to see if it has populated the platform facts

# Generated at 2022-06-23 01:30:12.764584
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Set up
    test_platform = {'system': 'Linux',
                     'kernel': 'Linux',
                     'kernel_version': '2.6.32-504.8.1.el6.x86_64',
                     'machine': 'x86_64',
                     'python_version': '2.7.5',
                     'architecture': 'x86_64',
                     'userspace_bits': '64',
                     'userspace_architecture': 'x86_64'}
    test_mod = MagicMock()
    test_collected_facts = {}
    test_module_name = 'ansible.module_utils.facts.system.platform'

    # Setup some values (we can't patch something after it has been imported)

# Generated at 2022-06-23 01:30:14.508792
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'

# Generated at 2022-06-23 01:30:18.712515
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:30:22.629050
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert 'python_version' in platform_facts
    assert 'system' in platform_facts
    assert 'machine' in platform_facts
    assert 'architecture' in platform_facts

# Generated at 2022-06-23 01:30:31.312944
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleData
    from ansible.module_utils.facts import RunnerData
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector


# Generated at 2022-06-23 01:30:34.471789
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert (p.name == 'platform')
    assert (p.collect()['system'] == platform.system())

# Generated at 2022-06-23 01:30:37.831172
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:30:43.240906
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == "platform"
    assert collector._fact_ids == {'system',
                                   'kernel',
                                   'kernel_version',
                                   'machine',
                                   'python_version',
                                   'architecture',
                                   'machine_id'}


# Generated at 2022-06-23 01:30:49.452883
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create an instance of PlatformFactCollector
    platform_fact_collector_instance = PlatformFactCollector()

    # Call method collect
    # No parameters and no return value
    assert platform_fact_collector_instance.collect()

# Generated at 2022-06-23 01:30:55.779040
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:31:01.713914
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    # Testing the constructor
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])


# Generated at 2022-06-23 01:31:13.452043
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import mock

    machine_id = "somefakemachineid1234567890abcdef"

    # Create an instance of PlatformFactCollector to work on
    collector = PlatformFactCollector()
    # Create an instance of the dummy module to return from the PlatformFactCollector.collect() method
    module = mock.MagicMock()

    # type is set to str because some platforms do not support unicode
    # so we declare it here instead.
    fqdn = "fakedomain.local"

    # Create a test for the PlatformFactCollector
    # The test will inject various values for the various checks and
    # verify that the returned dict matches what we expect
    # We will test the following platform.system() values:
    #  - Linux
    #  - Darwin
    #  - Java
    #  - Windows
    #

# Generated at 2022-06-23 01:31:17.887817
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector.collect()
    assert ('system' in platform_facts and
            'kernel' in platform_facts and
            'kernel_version' in platform_facts and
            'machine' in platform_facts and
            'python_version' in platform_facts and
            'architecture' in platform_facts and
            'machine_id' in platform_facts)

# Generated at 2022-06-23 01:31:19.096367
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:31:22.150581
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    import platform
    import ansible.module_utils.facts.collectors.platform as platform_col

    assert platform.system() == platform_col.PlatformFactCollector().collect()['system']

# Generated at 2022-06-23 01:31:31.226402
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pytest_platform_factcollector = PlatformFactCollector()
    assert pytest_platform_factcollector.name == 'platform'
    assert pytest_platform_factcollector._fact_ids == set(['system',
                                                           'kernel',
                                                           'kernel_version',
                                                           'machine',
                                                           'python_version',
                                                           'architecture',
                                                           'machine_id'])

# Generated at 2022-06-23 01:31:41.421017
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    # Initialize AnsibleModule object.
    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    platform_collector = PlatformFactCollector(module)
    platform_facts = platform_collector.collect(module)

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['architecture'] == platform.architecture()[0]

# Generated at 2022-06-23 01:31:49.325132
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Unsupported unix system
    def fake_platform_system(self):
        return "AIX"

    def fake_fact_architecture(self):
        return "FakeArchitecture"

    from ansible.module_utils.facts.collector import PlatformFactCollector
    pfc = PlatformFactCollector()

    @mock.patch("ansible.module_utils.facts.collector.platform.system", fake_platform_system)
    def test_fake_aix():
        facts = pfc.collect()
        assert facts['architecture'] == "FakeArchitecture"

    # Linux
    pfc.system = "Linux"
    pfc.kernel = "2.6.18-194.el5"
    pfc.machine = "x86_64"

# Generated at 2022-06-23 01:31:55.558255
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert 'system' in obj._fact_ids
    assert 'kernel' in obj._fact_ids
    assert 'kernel_version' in obj._fact_ids
    assert 'machine' in obj._fact_ids
    assert 'python_version' in obj._fact_ids
    assert 'architecture' in obj._fact_ids
    assert 'machine_id' in obj._fact_ids


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:31:57.805984
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    PlatformFactCollector.collect(None, FactCollector(), True)


# Generated at 2022-06-23 01:32:01.532717
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])



# Generated at 2022-06-23 01:32:12.792438
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes

    collector = PlatformFactCollector(None)
    facts_dict = {}
    platform_facts = collector.collect(None, collected_facts=facts_dict)
    # Now check the collected values against ones we expect
    # from our mock (python) platform
    # note that these tests will only work properly on linux
    # due to platform specific values
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()

# Generated at 2022-06-23 01:32:17.249354
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    obj = PlatformFactCollector()

    assert hasattr(obj, '_fact_ids')
    assert hasattr(obj, 'collect')
    assert hasattr(obj, 'name')
    assert obj.name == 'platform'

# Generated at 2022-06-23 01:32:19.707525
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None

# Generated at 2022-06-23 01:32:29.249085
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create mock to replace 'platform' module
    class MockPlatform(object):
        @staticmethod
        def system():
            return 'Linux'
        @staticmethod
        def release():
            return '4.4.0-116-generic'
        @staticmethod
        def version():
            return '#140-Ubuntu SMP Mon Feb 12 21:23:04 UTC 2018'
        @staticmethod
        def machine():
            return 'x86_64'
        @staticmethod
        def uname():
            return ['OpenBSD', 'vbox', '6.3', 'GENERIC.MP', 'amd64']
        @staticmethod
        def architecture():
            return ['64bit']
        @staticmethod
        def python_version():
            return '2.7.15rc1'

# Generated at 2022-06-23 01:32:30.517593
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'

# Generated at 2022-06-23 01:32:31.113604
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:32:32.871596
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector({ 'module': None })
    platform_collector.collect()

# Generated at 2022-06-23 01:32:36.697401
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == "platform"
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:32:44.968997
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PLATFORM_FACT_COLLECTOR = PlatformFactCollector()
    assert PLATFORM_FACT_COLLECTOR.name == 'platform'
    assert PLATFORM_FACT_COLLECTOR._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])
    assert PLATFORM_FACT_COLLECTOR._platform == 'Generic'

# Generated at 2022-06-23 01:32:47.500296
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version',
                                                   'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:32:57.941602
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = type('MockModule', (object,), {})
    mock_module.run_command = get_cmd_result
    mock_module.get_bin_path = return_bin_path
    pfc = PlatformFactCollector()

# Generated at 2022-06-23 01:33:01.995131
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:33:06.925450
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:33:12.197489
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids

# Generated at 2022-06-23 01:33:22.102178
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import json
    class MockPlatform:
        system = platform.system()
        release = platform.release()
        version = platform.version()
        machine = platform.machine()
        python_version = platform.python_version()
        uname = {}

    class MockModule:
        def get_bin_path(self, name, **kwargs):
            if name == 'getconf':
                return '/usr/bin/getconf'
            if name == 'bootinfo':
                return '/usr/sbin/bootinfo'
            return None

        def run_command(self, name, **kwargs):
            if name[0] == '/usr/bin/getconf':
                return 0, 'amd64', ''
            if name[0] == '/usr/sbin/bootinfo':
                return 0, 'powerpc', ''

# Generated at 2022-06-23 01:33:33.041641
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # mock class and it's attributes
    class mock_class:
        def __init__(self):
            self.system = "Linux"
            self.release = "release"
            self.version = "version"
            self.machine = "machine"
            self.python_version = "python_version"
            self.architecture = "architecture"
            self.node = "node"
            self.fqdn = "fqdn"
            self.hostname = "hostname"
            self.nodename = "nodename"
            self.domain = "domain"
            self.machine_id = "machine_id"

    # create an object of the mock class
    mock_instance = mock_class()

    # initialize an object of PlatformFactCollector
    fact_collector = PlatformFactCollector()

   

# Generated at 2022-06-23 01:33:43.415883
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None

    class Module:

        def get_bin_path(self, command):
            if command == 'getconf':
                return 'test'
            else:
                return None

        def run_command(self, command):
            assert command == ['test', 'MACHINE_ARCHITECTURE']
            return 0, 'x86_64', ''

    platform_facts = platform_fact_collector.collect(Module())

    assert isinstance(platform_facts, dict)
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts

# Generated at 2022-06-23 01:33:45.278443
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform', pfc.name

# Generated at 2022-06-23 01:33:51.864475
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class _module():
        def get_bin_path(self, arg):
            return '/bin/' + arg
        def run_command(self, arg):
            return 0, ['test'], []
    test_dict = PlatformFactCollector().collect(module=_module())
    assert 'system' in test_dict
    assert 'kernel' in test_dict
    assert 'kernel_version' in test_dict
    assert 'machine' in test_dict
    assert 'python_version' in test_dict
    assert 'architecture' in test_dict
    assert 'machine_id' in test_dict

# Generated at 2022-06-23 01:33:59.662466
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create an instance of PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()

    # Unit test for method collect of PlatformFactCollector
    assert platform_fact_collector.collect() == {'kernel': '3.10.0-229.el7.x86_64', 'userspace_bits': '64', 'kernel_version': '#1 SMP Tue Nov 3 19:10:07 UTC 2015', 'machine': 'x86_64', 'python_version': '2.7.5', 'architecture': 'x86_64', 'userspace_architecture': 'x86_64', 'system': 'Linux'}

# Generated at 2022-06-23 01:34:04.249108
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:34:09.014510
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:34:14.811889
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'fqdn' in platform_facts
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'architecture' in platform_facts
    assert 'python_version' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-23 01:34:17.637772
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
  obj = PlatformFactCollector()
  assert obj.name == 'platform'
  assert obj._fact_ids == {'system', 'kernel', 'kernel_version',
                           'machine', 'python_version', 'architecture',
                           'machine_id'}



# Generated at 2022-06-23 01:34:26.804164
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup test objects
    pfc = PlatformFactCollector()
    collected_facts = {}

    # Run collect method and check result
    pfc.collect(collected_facts=collected_facts)

# Generated at 2022-06-23 01:34:35.721110
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestModule():
        def __init__(self):
            self._platform_system = 'Linux'
            self._platform_release = '2.6.32-71.29.1.el6.x86_64'
            self._platform_version = '#1 SMP Mon Jun 27 19:49:27 BST 2011'
            self._platform_machine = 'x86_64'
            self._socket_getfqdn_return_value = 'ip-10-174-50-179.ec2.internal'
            self._platform_node_return_value = 'ip-10-174-50-179.ec2.internal'
            self._platform_python_version_return_value = '3.7.3'
            self._platform_architecture_return_value = ('64bit', '')
            self._get_bin

# Generated at 2022-06-23 01:34:45.293725
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert 'fqdn' in platform_facts
    assert 'domain' in platform_facts
    assert 'machine' in platform_facts
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'userspace_architecture' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'hostname' in platform_facts
    assert 'nodename' in platform_facts
    assert 'python_version' in platform_facts

# Generated at 2022-06-23 01:34:46.104103
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformfact_collector = PlatformFactCollector()
    platformfact_collector.collect()

# Generated at 2022-06-23 01:34:49.647050
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform
    assert platform.name == 'platform'
    assert 'system' in platform._fact_ids
    assert 'kernel' in platform._fact_ids
    assert 'kernel_version' in platform._fact_ids
    assert 'architecture' in platform._fact_ids
    assert 'machine_id' in platform._fact_ids

# Generated at 2022-06-23 01:35:00.208656
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class MockModule:
        platform = 'linux'

        @staticmethod
        def run_command(*args, **kwargs):
            if args[0] == getconf_bin:
                return 0, "x86_64\n", ""
            elif args[0] == bootinfo_bin:
                return 0, "PowerPC\n", ""

        @staticmethod
        def get_bin_path(command):
            if command == 'getconf':
                return getconf_bin
            elif command == 'bootinfo':
                return bootinfo_bin

    module = MockModule()

    pltfrm_clctr = PlatformFactCollector(module=module)
    result = pltfrm_clctr.collect()

    assert result['system'] == 'Linux'
    assert result['kernel'] == platform.release()
    assert result

# Generated at 2022-06-23 01:35:03.720026
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()

    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids


# Generated at 2022-06-23 01:35:09.564281
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import FactCollector

    module_mock = None
    collected_facts_mock = None
    pfc = PlatformFactCollector()
    pfc.collect(module=module_mock, collected_facts=collected_facts_mock)

# Generated at 2022-06-23 01:35:18.398939
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Facts
    facts_module = Facts(None, None, None, None)

    fact_collector = PlatformFactCollector(facts_module)
    fact_collector._module = facts_module
    fact_collector.collect(facts_module, {})

    assert fact_collector.collect()['system'] == platform.system()
    assert fact_collector.collect()['kernel'] == platform.release()
    assert fact_collector.collect()['kernel_version'] == platform.version()
    assert fact_collector.collect()['machine'] == platform.machine()
    py_dmaj = int(platform.python_version_tuple()[0])
    py_dmin = int(platform.python_version_tuple()[1])

# Generated at 2022-06-23 01:35:27.707532
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import sys
    import os
    import socket

    class fake_module():
        def __init__(self):
            self.params = {}
            self.version_info = sys.version_info
        def run_command(self, args):
            class FakeOut:
                def readlines(self):
                    return ['x86_64','32','64','x86_64','i386','x86_64','x86_64','i386','x86_64','i386','x86_64','i386','x86_64']
            return (0, FakeOut(), None)
        def get_bin_path(self, opt):
            return True

    class fake_socket():
        def getfqdn(self):
            return True

    module = fake_module()
    platform.system = lambda: "Linux"

# Generated at 2022-06-23 01:35:33.886514
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-23 01:35:45.945144
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform

    class PlatformFactCollectorMock(PlatformFactCollector):
        def collect(self, module=None, collected_facts=None):
            platform_facts = {}
            # platform.system() can be Linux, Darwin, Java, or Windows
            platform_facts['system'] = platform.system()
            platform_facts['kernel'] = platform.release()
            platform_facts['kernel_version'] = platform.version()
            platform_facts['machine'] = platform.machine()

            platform_facts['python_version'] = platform.python_version()

            platform_facts['fqdn'] = socket.getfqdn()
            platform_facts['hostname'] = platform.node().split('.')[0]
            platform_facts['nodename'] = platform.node()


# Generated at 2022-06-23 01:35:50.129523
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert platform_fact_collector._platform == None
    assert platform_fact_collector._done == set()


# Generated at 2022-06-23 01:35:57.460542
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts.has_key('system')
    assert platform_facts.has_key('kernel')
    assert platform_facts.has_key('kernel_version')
    assert platform_facts.has_key('machine')
    assert platform_facts.has_key('architecture')
    assert platform_facts.has_key('python_version')
    assert platform_facts.has_key('machine_id')

# Generated at 2022-06-23 01:36:01.404736
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    c = PlatformFactCollector()
    assert c.name == 'platform'
    assert c._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:36:11.538703
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import copy
    import json

    import mock
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector

    test_platform = platform.platform()
    test_machine = platform.machine()

    # create mock objects
    module = mock.Mock()
    module.run_command.return_value = (0, '', '')
    mock_fact_class = mock.Mock(spec=BaseFactCollector)
    mock_fact_class.return_value = module

    # initialize the class
    fact_collector = PlatformFactCollector()

    # initialize return values
    fact_collector.solaris_i86_re = mock.Mock()
    fact_collector.solaris_i86_re.search.return_value = None
    fact_collector.platform = mock

# Generated at 2022-06-23 01:36:19.344296
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockSystem:
        def architecture(self):
            return ('32bit', 'ELF')

    class MockPlatform:
        system = MockSystem()
        release = 'test'
        version = 'test'
        machine = 'test'
        python_version = 'test'
        node = 'test'

    class MockModule:
        def run_command(self, args):
            return 0, '', ''
        def get_bin_path(self, bin_path):
            return bin_path

    class MockSocket:
        def getfqdn(self):
            return 'test.domain'

    platform_fact_collector = PlatformFactCollector()

    platform_facts = {}

    mock_module = MockModule()
    mock_platform = MockPlatform()
    mock_socket = MockSocket()
    facts = platform_fact_collect

# Generated at 2022-06-23 01:36:23.607103
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == {'system', 'kernel', 'kernel_version',
                             'machine', 'python_version',
                             'architecture', 'machine_id'}

# Generated at 2022-06-23 01:36:26.321029
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x.valid

# Generated at 2022-06-23 01:36:37.382467
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class DummyModule(object):
        def get_bin_path(self, arg):
            return arg

    import sys
    import platform
    import socket
    import re

    dummy_platform = dict()

    def platform_system():
        return dummy_platform['system']

    def platform_release():
        return dummy_platform['kernel']

    def platform_version():
        return dummy_platform['kernel_version']

    def platform_machine():
        return dummy_platform['machine']

    def platform_uname():
        return dummy_platform['uname']

    def python_version():
        return '2.7.12'

    def getfqdn():
        return dummy_platform['fqdn']

    def node():
        return dummy_platform['nodename']

    def run_command(arg):
        global v


# Generated at 2022-06-23 01:36:42.556315
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()

    # _fact_name is set correctly
    assert collector.name == 'platform'

    # _fact_ids are set correctly
    assert collector._fact_ids == {'system',
                                   'kernel',
                                   'kernel_version',
                                   'machine',
                                   'python_version',
                                   'architecture',
                                   'machine_id'}

# Generated at 2022-06-23 01:36:52.932787
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    platform_facts = fact_collector.collect()

    assert isinstance(platform_facts, dict)
    assert "system" in platform_facts
    assert isinstance(platform_facts["system"], str)
    assert platform_facts["system"] in ("Linux", "Darwin", "Java", "Windows")

    assert "kernel" in platform_facts
    assert isinstance(platform_facts["kernel"], str)

    assert "kernel_version" in platform_facts
    assert isinstance(platform_facts["kernel_version"], str)

    assert "machine" in platform_facts
    assert isinstance(platform_facts["machine"], str)
    assert platform_facts["machine"] in ("x86_64", "i386", "ppc")

    assert "python_version" in platform_facts

# Generated at 2022-06-23 01:36:59.802448
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert platform_facts.get('system') is not None
    assert platform_facts.get('kernel') is not None
    assert platform_facts.get('kernel_version') is not None
    assert platform_facts.get('machine') is not None
    assert platform_facts.get('python_version') is not None
    assert platform_facts.get('architecture') is not None
    assert platform_facts.get('machine_id') is not None

# Generated at 2022-06-23 01:37:08.123895
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    Test of method collect of class PlatformFactCollector
    '''
    class Options(object):
        def __init__(self):
            self.gather_subset = ['all']

    class ModuleExit(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class AnsibleModule(object):
        def __init__(self):
            self._debug = False
            self._verbosity = 0
            self.check_mode = False
            self.params = Options()
            self.exit_json = self.fail_json = self.run_command = self.get_bin_path = lambda *args, **kwargs: None
            self.get_bin_path = lambda *args, **kwargs: None


# Generated at 2022-06-23 01:37:09.793154
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'

# Generated at 2022-06-23 01:37:19.101354
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test with a class created
    platform_facts_collector = PlatformFactCollector()
    machine_id = get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")
    if machine_id:
        machine_id = machine_id.splitlines()[0]
    platform_facts = platform_facts_collector.collect()
    assert platform_facts["system"] == platform.system(), "platform.system() == " + platform.system()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["python_version"] == platform.python_version()

# Generated at 2022-06-23 01:37:23.755417
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    _fact_ids = set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])
    assert pfc._fact_ids == _fact_ids

# Generated at 2022-06-23 01:37:25.988913
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector(None, None).collect()
    assert platform_facts is not None
    assert len(platform_facts) > 0

# Generated at 2022-06-23 01:37:34.558611
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

# Generated at 2022-06-23 01:37:36.615760
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'

# Generated at 2022-06-23 01:37:47.477958
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    input_data = {
        "ansible_facts": {
            "kernel": "Linux",
            "kernel_version": "4.4.0-22-generic"
        }
    }
    if platform.system() == "AIX":
        input_data["ansible_facts"]["machine"] = "PowerNV"
        input_data["ansible_facts"]["architecture"] = "ppc64"
    elif platform.system() == "OpenBSD":
        input_data["ansible_facts"]["machine"] = "amd64"
        input_data["ansible_facts"]["architecture"] = "amd64"
    else:
        input_data["ansible_facts"]["machine"] = "x86_64"

# Generated at 2022-06-23 01:37:51.945731
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a new instance of PlatformFactCollector
    pfc = PlatformFactCollector()

    # Check if the collect method works correctly
    assert pfc.collect()["system"] == platform.system()

# Generated at 2022-06-23 01:37:57.122097
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()

    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:38:01.458534
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == {'system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'}

# Generated at 2022-06-23 01:38:04.835067
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:38:08.094096
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:38:09.887406
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    # unit test method 'collect'
    pfc.collect()

# Generated at 2022-06-23 01:38:11.536640
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect()

# Generated at 2022-06-23 01:38:19.363663
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test for class PlatformFactCollector: getter for platform facts

    # Test for a class method
    if PlatformFactCollector.collect is None:
        raise ValueError("getter for platform facts method missing.")

    # Test for the absence of an attribute
    if hasattr(PlatformFactCollector, "facts"):
        raise ValueError("Attribute 'facts' must be absent.")

    # Test for the absence of an attribute
    if hasattr(PlatformFactCollector, "collect"):
        raise ValueError("Attribute 'collect' must be absent.")

# Generated at 2022-06-23 01:38:25.555777
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    assert set(platform_collector.collect().keys()) == set(['system',
                                                            'kernel',
                                                            'kernel_version',
                                                            'machine',
                                                            'python_version',
                                                            'architecture',
                                                            'machine_id'])

# Generated at 2022-06-23 01:38:31.027371
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    collected_facts = collector.collect()
    assert 'system' in collected_facts
    assert 'kernel' in collected_facts
    assert 'kernel_version' in collected_facts
    assert 'machine' in collected_facts
    assert 'python_version' in collected_facts
    assert 'architecture' in collected_facts
    assert 'machine_id' in collected_facts

    assert 'fqdn' in collected_facts
    assert 'hostname' in collected_facts
    assert 'nodename' in collected_facts
    assert 'domain' in collected_facts
    assert 'userspace_bits' in collected_facts
    assert 'userspace_architecture' in collected_facts

# Generated at 2022-06-23 01:38:36.275521
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert platform_obj.name == 'platform'
    assert platform_obj._fact_ids == set(['system',
                                         'kernel',
                                         'kernel_version',
                                         'machine',
                                         'python_version',
                                         'architecture',
                                         'machine_id'])

# Generated at 2022-06-23 01:38:39.860376
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    platform_collector = PlatformFactCollector()
    platform_collector.collect(module)

# Generated at 2022-06-23 01:38:45.413651
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def module_mock(commands):
        """ mock module instance """
        class MockModule:
            def __init__(self):
                self.commands = commands
                self.params = {}
                self.check_mode = False

            def run_command(self, cmd, check_rc=True, environ_update=None,
                            data=None, binary_data=False, path_prefix=None,
                            cwd=None, raise_err=False, encoding=None, errors='strict',
                            expand_user_and_vars=True):
                # Calling with cmd only allows us to
                # call with a string or with a list with a single value
                if isinstance(cmd, list):
                    cmd = cmd[0]

                if cmd in self.commands:
                    return self.commands[cmd]

# Generated at 2022-06-23 01:38:50.507277
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system',
                                                 'kernel',
                                                 'kernel_version',
                                                 'machine',
                                                 'architecture',
                                                 'machine_id'}



# Generated at 2022-06-23 01:38:58.910678
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.six import PY3

    import platform

    if PY3:
        _system = platform.system()
    else:
        _system = platform._syscmd_uname('--kernel-name') # pylint: disable=no-member

    if platform.machine().startswith('armv6'):
        # Checks for ARM processors without hardware FPU
        machine = 'armv6l'
    elif platform.machine().startswith('armv7'):
        # Checks for ARM processors with hardware FPU
        machine = 'armv7l'
    else:
        machine = platform.machine()


# Generated at 2022-06-23 01:39:03.432735
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert set(x._fact_ids) == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:39:11.550609
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:39:16.273124
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:39:22.393088
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id'])

# Generated at 2022-06-23 01:39:24.114392
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert hasattr(pf, 'name') == True

# Generated at 2022-06-23 01:39:34.950331
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for PlatformFactCollector.collect
    """

    (success, ansible_module_instance, platform_facts) = test_PlatformFactCollector_helper()
