

# Generated at 2022-06-23 01:29:34.415987
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # This sanity check verifies that the method collect returns not empty dictionary.
    # If this test failes, it is most likely that this is a bug in the the module returned
    # by the method collect.
    collector = PlatformFactCollector()
    assert collector.collect()

# Generated at 2022-06-23 01:29:44.521565
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    fact_collector = PlatformFactCollector()

    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:29:46.446071
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert isinstance(p, PlatformFactCollector)


# Generated at 2022-06-23 01:29:55.745262
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()

    # Test behavior with "architecture" defined as a slot of platform_facts
    if not hasattr(platform, 'architecture'):
        platform.architecture = lambda: ('64bit', 'ELF')

    module = lambda: None
    module.run_command = lambda x: (0, "", "")
    module.get_bin_path = lambda x: "/bin/%s" % x
    platform_facts = collector.collect(module)
    assert 'architecture' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'userspace_architecture' in platform_facts
    assert platform_facts['architecture'] == 'x86_64'
    assert platform_facts['userspace_bits'] == '64'

# Generated at 2022-06-23 01:29:59.757359
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:30:00.587879
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'

# Generated at 2022-06-23 01:30:04.386330
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:30:06.338887
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_object = PlatformFactCollector()
    result = test_object.collect()
    print(result)


# Generated at 2022-06-23 01:30:16.428488
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert plat.name == 'platform'
    assert plat.fact_ids == {'architecture',
                             'fqdn',
                             'hostname',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'machine_id',
                             'python_version',
                             'system',
                             'userspace_bits',
                             'userspace_architecture',
                             'domain',
                             'nodename'}
    assert plat._fact_ids == {'system',
                              'kernel',
                              'kernel_version',
                              'machine',
                              'python_version',
                              'architecture',
                              'machine_id'}

# Generated at 2022-06-23 01:30:26.368840
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector._get_possible_names = lambda self: {'machine': 'x86_64'}
    PlatformFactCollector._get_platform_system = lambda self: 'Linux'
    PlatformFactCollector._get_platform_release = lambda self: '3.10.0-229.20.1.el7.x86_64'
    PlatformFactCollector._get_platform_version = lambda self: '#1 SMP Fri Mar 6 11:36:42 UTC 2015'
    PlatformFactCollector._get_platform_machine = lambda self: 'x86_64'
    PlatformFactCollector._get_platform_python_version = lambda self: '3.6.3'
    PlatformFactCollector._get_architecture = lambda self: '64bit'

    collector = PlatformFactCollector()

    facts = collector.collect()

# Generated at 2022-06-23 01:30:36.932291
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    mock_module = type('', (), {
        'get_bin_path': lambda self, arg: 'path'
    })()
    mock_module.run_command = lambda arg1, arg2: (0, '', '')
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(mock_module, {})
    assert('system' in platform_facts)
    assert('kernel' in platform_facts)
    assert('kernel_version' in platform_facts)
    assert('machine' in platform_facts)
    assert('python_version' in platform_facts)
    assert('fqdn' in platform_facts)
    assert('hostname' in platform_facts)
    assert('nodename' in platform_facts)

# Generated at 2022-06-23 01:30:51.009751
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create a PlatformFactCollector object
    platform_obj = PlatformFactCollector()
    # create a mock 'module' object
    class MockModule:
        def get_bin_path(self, arg):
            return None
        def fail_json(self, **kwargs):
            raise Exception('MockModule.fail_json called')
        def run_command(self, arg):
            return 0, "", ""
    module = MockModule()
    # call the method collect of PlatformFactCollector object with
    # 'module' object as argument
    result = platform_obj.collect(module)
    # check if the result is empty
    assert result
    # check if the result is a dictionary
    assert isinstance(result, dict)
    # check if the result have expected keys
    assert 'system' in result

# Generated at 2022-06-23 01:30:55.779003
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
        'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:30:58.684636
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    """
    This method returns the result of calling collect method
    on PlatformFactCollector class.
    :return: Dictionary of Platform Facts.
    """
    test = PlatformFactCollector()
    host_facts = test.collect()
    return host_facts

# Generated at 2022-06-23 01:30:59.290957
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:31:03.424039
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    for fact in [
            'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'
        ]:
        assert fact in pfc._fact_ids


# Generated at 2022-06-23 01:31:15.330569
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a new PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()
    # Collect platform facts
    facts = platform_fact_collector.collect()

    assert facts is not None
    assert isinstance(facts, dict)
    assert 'ansible_facts' in facts
    assert 'ansible_local' in facts

    platform_facts = facts['ansible_facts']
    assert isinstance(platform_facts, dict)
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts or 'ansible_machine_id' in platform_facts

# Generated at 2022-06-23 01:31:17.834501
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # establish that the constructor exists and works with no inputs
    PlatformFactCollector()

# Generated at 2022-06-23 01:31:18.705621
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:31:29.100946
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import ansible.module_utils.facts.collector

    module = ansible.module_utils.facts.collector

# Generated at 2022-06-23 01:31:36.945835
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    a = PlatformFactCollector()

    assert a.name == 'platform'

    assert a._fact_ids.__len__() > 0

    assert isinstance(a._fact_ids, set)

    assert 'system' in a._fact_ids

    assert 'machine' in a._fact_ids

    assert 'architecture' in a._fact_ids

    assert 'machine_id' in a._fact_ids

    assert a.collect()

# Generated at 2022-06-23 01:31:46.123731
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, name, opt_dirs=[]):
            return "/bin/%s" % name

        def run_command(self, args):
            return (0, '', '')

    sys_platform = platform.system()
    platform_arch = platform.machine()
    arch_bits = platform.architecture()[0]
    testmodule = TestModule(system=sys_platform, architecture=platform_arch,
                            userspace_bits=arch_bits.replace('bit', ''))
    platform_facts_collector = PlatformFactCollector()

    # Test for a supported platform that uses Python 2.7

# Generated at 2022-06-23 01:31:49.313435
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert isinstance(p.collect(), dict)

# Generated at 2022-06-23 01:31:56.365823
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # GIVEN: class PlatformFactCollector and none of its methods are mocked
    plugin = PlatformFactCollector()
    # WHEN: calling collect
    actual = plugin.collect()
    # THEN: the properties of the dictionary returned should be as expected
    for prop in ['system', 'kernel', 'kernel_version', 'machine',
                 'python_version', 'architecture', 'machine_id']:
        assert prop in actual
    assert actual['python_version'].startswith('2.')
    assert actual['architecture'] in ['x86_64', 'i386', 'ppc64le', 's390x', 'aarch64']

# Generated at 2022-06-23 01:31:58.006066
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform', 'Test constructor of a PlatformFactCollector'

# Generated at 2022-06-23 01:32:01.733922
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = None
    try:
        platform_fact_collector = PlatformFactCollector()
        platform_facts = platform_fact_collector.collect()
    except Exception as ex:
        # FIXME: Log something reasonable
        print(ex)
    assert platform_facts

# vim: set ts=4 sw=4 expandtab:

# Generated at 2022-06-23 01:32:02.874382
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x=PlatformFactCollector()
    assert x


# Generated at 2022-06-23 01:32:04.592045
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert (PlatformFactCollector().name == 'platform')

# Generated at 2022-06-23 01:32:09.395962
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc
    expected_fact_ids = {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture',
                         'machine_id'}
    assert pfc._fact_ids == expected_fact_ids

# Generated at 2022-06-23 01:32:20.235447
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback.default import CallbackModule

    module_args = dict(
        timeout=10,
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    play_context = PlayContext()
    play_context.network_os = None

    callback = CallbackModule()
    tqm = None

# Generated at 2022-06-23 01:32:24.990958
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


# Generated at 2022-06-23 01:32:35.436770
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import PlatformFactCollector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.modulefacts import ModuleFactsCollector
    from ansible.module_utils.facts.modulefacts import ModuleFacts

    module = ModuleFactsCollector
    facts_collector = FactCollector()
    c = PlatformFactCollector(module, facts_collector)

    module = ModuleFacts

    c = PlatformFactCollector(module)
    print(c.collect())



# Generated at 2022-06-23 01:32:38.943100
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-23 01:32:48.626177
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import sys

    facts = PlatformFactCollector().collect()

    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['architecture'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['fqdn'] == socket.getfqdn()
    assert facts['hostname'] == platform.node().split('.')[0]
    assert facts['nodename'] == platform.node()
    assert facts['domain'] == '.'.join(socket.getfqdn().split('.')[1:])

    arch_bits = platform.architecture()[0]

# Generated at 2022-06-23 01:32:58.334971
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create an instance of the PlatformFactCollector class for testing
    platform_collector = PlatformFactCollector()

    # execute the collect method of the PlatformFactCollector instance
    platform_facts = platform_collector.collect()

    # make sure the resulting data is valid
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts



# Generated at 2022-06-23 01:33:03.487517
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector(None, None)
    expected_fact_ids = set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    ])
    assert fact_collector._fact_ids == expected_fact_ids

# Generated at 2022-06-23 01:33:10.893191
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert sorted(PlatformFactCollector().collect().keys()) == sorted(['system',
                                                                       'userspace_bits',
                                                                       'kernel',
                                                                       'kernel_version',
                                                                       'machine',
                                                                       'nodename',
                                                                       'python_version',
                                                                       'domain',
                                                                       'architecture',
                                                                       'fqdn',
                                                                       'userspace_architecture',
                                                                       'machine_id',
                                                                       'hostname'])

# Generated at 2022-06-23 01:33:22.041257
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Note: Do not use instance attributes to initialize other instances
    # to avoid dependency issues
    test_instance = PlatformFactCollector()
    test_module = AnsibleModuleMock()

    # Test when platform.system() is Linux
    platform.system = Mock(return_value = 'Linux')
    platform.release = Mock(return_value = 'Linux')
    platform.version = Mock(return_value = 'Linux')
    platform.machine = Mock(return_value = 'Linux')
    platform.python_version = Mock(return_value = 'Linux')
    platform.node = Mock(return_value = 'Linux')
    platform.architecture = Mock(return_value = ('bit', '32bit'))

    socket.getfqdn = Mock(return_value = 'Linux')

    # Test collection of facts

# Generated at 2022-06-23 01:33:30.805884
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform as mod_platform
    from ansible.module_utils.facts import ModuleFacts

    p = PlatformFactCollector()
    platform_facts = p.collect()

    # Check system fact
    if sys.platform == 'linux2':
        assert platform_facts['system'] == 'Linux'
    if sys.platform == 'darwin':
        assert platform_facts['system'] == 'Darwin'
    if sys.platform == 'sunos':
        assert platform_facts['system'] == 'SunOS'

    # Check kernel fact
    assert platform_facts['kernel'] == mod_platform.release()

    # Check kernel_version fact
    assert platform_facts['kernel_version'] == mod_platform.version()

    # Check machine fact
    assert platform_facts['machine'] == mod_platform.machine()

    # Check

# Generated at 2022-06-23 01:33:40.795727
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': "!all",
            }

        def run_command(self, x):
            return(0, "kernel_version", "")

        def get_bin_path(self, x):
            return "/usr/bin/%s" % x

    collector = PlatformFactCollector()

    module = FakeModule()

    facts = collector.collect(module=module, collected_facts=None)

    assert facts['kernel_version'] == "kernel_version"

# Generated at 2022-06-23 01:33:46.205880
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:33:51.420769
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    my_platform_fact_collector = PlatformFactCollector()
    my_platform_facts = my_platform_fact_collector.collect(module=module)

    for fact in my_platform_facts.keys():
        assert fact in my_platform_fact_collector._fact_ids
        assert my_platform_facts[fact] is not None


# Generated at 2022-06-23 01:33:58.687522
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Provide some test data for the method
    # This test data can be replaced with some input data that can be passed
    # to the method and its output is verified.
    platform_facts_test_data = {'kernel': '3.13.0-24-generic', 'machine': 'x86_64', 'python_version': '2.7.5+', 'architecture': 'x86_64', 'hostname': 'testhostname', 'fqdn': 'testhostname.testdomain.com', 'system': 'Linux', 'kernel_version': '#46-Ubuntu SMP Thu Apr 10 19:11:08 UTC 2014', 'nodename': 'testhostname.testdomain.com'}
    platform_facts_test_obj = PlatformFactCollector()

# Generated at 2022-06-23 01:34:06.616535
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        import platform
    except ImportError:
        print('platform is not available on your system, skipping.')
    else:
        platform_fact_collector = PlatformFactCollector()
        actual = platform_fact_collector.collect()
        expected_keys = frozenset(
            [
                'system', 'kernel', 'kernel_version', 'machine',
                'python_version', 'architecture', 'machine_id'
            ]
        )
        assert expected_keys.issubset(actual), "platform keys not found: {}".format(expected_keys.difference(actual))

# Generated at 2022-06-23 01:34:16.270568
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    import sys

    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(('system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'))
    platform_collector.collect()
    assert platform_collector.platform_info['system'] == platform.system()
    assert platform_collector.platform_info['kernel'] == platform.release()
    assert platform_collector.platform_info['kernel_version'] == platform.version()
    assert platform_collector.platform_info['machine'] == platform.machine()
    assert platform_collector.platform_info['python_version'] == platform.python_version()

# Generated at 2022-06-23 01:34:17.798337
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-23 01:34:20.934319
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:34:28.478870
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Set expected name of 'system' fact
    expected_system = platform.system()
    # Set expected name of 'kernel' fact
    expected_kernel = platform.release()
    # Set expected name of 'kernel_version' fact
    expected_kernel_version = platform.version()
    # Set expected name of 'machine' fact
    expected_machine = platform.machine()
    # Set expected name of 'python_version' fact
    expected_python_version = platform.python_version()
    # Set expected arch_bits name
    arch_bits = platform.architecture()[0]
    # Set expected name of 'userspace_bits' fact
    expected_userspace_bits = arch_bits.replace('bit', '')
    # Set expected name of 'architecture' fact
    expected_architecture = platform.machine()

# Generated at 2022-06-23 01:34:33.814426
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert plat.name == "platform"
    assert plat._fact_ids == set(['system',
                                  'kernel',
                                  'kernel_version',
                                  'machine',
                                  'python_version',
                                  'architecture',
                                  'machine_id'])

# Generated at 2022-06-23 01:34:40.896397
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    import platform
    p = PlatformFactCollector()
    # Fact Collectors can be instantiated.
    assert p
    # _fact_id is set
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'architecture',
                               'python_version'])
    # name is set
    assert p.name == 'platform'
    # facts is a set
    assert isinstance(p.facts, set)
    # facts is not empty
    assert len(p.facts) > 0

# Generated at 2022-06-23 01:34:41.561302
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:34:49.552416
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import re
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.platform.impl_linux import LinuxPlatformFactCollector
    from ansible.module_utils.facts.platform.impl_bsd import BSDPlatformFactCollector
    from ansible.module_utils.facts.platform.impl_sunos import SunOSPlatformFactCollector
    from ansible.module_utils.facts.platform.impl_aix import AixPlatformFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3

    fake_getfile_content = {'/var/lib/dbus/machine-id': 'aThis is a fake machine-id.\n'}



# Generated at 2022-06-23 01:34:58.660594
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector_obj = PlatformFactCollector()
    assert PlatformFactCollector_obj.collect() == {'system': 'Linux', 'kernel': '3.13.0-149-generic', 'kernel_version': '#199-Ubuntu SMP Thu Apr 5 14:41:04 UTC 2018', 'machine': 'x86_64', 'python_version': '2.7.6', 'fqdn': 'localhost', 'hostname': 'localhost', 'nodename': 'localhost', 'domain': '', 'userspace_bits': '64bit', 'architecture': 'x86_64', 'userspace_architecture': 'x86_64'}

# Tests for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:35:04.192802
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_collector = PlatformFactCollector()
    assert platform_facts_collector.name == 'platform'
    assert platform_facts_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:35:13.979085
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    ansible_module = Mock()
    ansible_module.run_command.return_value = (0, 'x86_64', '')

    fact_collector = PlatformFactCollector()

    fact_collector.collect(ansible_module)

    # assert that some keys are present in the result
    assert 'system' in fact_collector._collected_facts
    assert 'kernel' in fact_collector._collected_facts
    assert 'kernel_version' in fact_collector._collected_facts
    assert 'machine' in fact_collector._collected_facts
    assert 'python_version' in fact_collector._collected_facts
    assert 'architecture' in fact_collector._collected_facts

    # assert that the returned keys are correct
    assert fact_collector._collected_facts['system']

# Generated at 2022-06-23 01:35:16.139816
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        PlatformFactCollector.collect()
    except Exception as exception:
        pass
    else:
        assert False, "Exception was not raised"

# Generated at 2022-06-23 01:35:19.468599
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:35:23.803474
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert set(pf._fact_ids) == set(['system',
                                     'kernel',
                                     'kernel_version',
                                     'machine',
                                     'python_version',
                                     'architecture',
                                     'machine_id'])


# Generated at 2022-06-23 01:35:32.342386
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'hostname' in platform_facts
    assert 'nodename' in platform_facts
    assert 'domain' in platform_facts
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts

# Generated at 2022-06-23 01:35:36.178775
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Init
    PlatformFactCollector.collect()

    # This collector should never return a fact
    assert (PlatformFactCollector.collect() == {})

# Generated at 2022-06-23 01:35:46.658318
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()
    platform_facts['python_version'] = platform.python_version()
    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()
    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()[0]
    platform_facts['userspace_bits'] = arch_bits.replace('bit', '')
   

# Generated at 2022-06-23 01:35:53.717219
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Override platform.system() as it returns a different string on new machines
    Obj_PlatformFactCollector = PlatformFactCollector()
    platform_facts = Obj_PlatformFactCollector.collect({}, {})
    # Override python_version which is different on each machine
    platform_facts['python_version'] = "2.7.12"

# Generated at 2022-06-23 01:35:57.576130
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:36:01.169321
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert set(platform_fact_collector._fact_ids) == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:36:09.594480
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule

    module = MockModule({})
    fact_collector = PlatformFactCollector(module)
    facts = fact_collector.collect()
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'python_version' in facts
    assert 'architecture' in facts
    assert 'machine_id' in facts
    assert 'fqdn' in facts
    assert 'hostname' in facts
    assert 'nodename' in facts
    assert 'domain' in facts
    assert 'userspace_bits' in facts
    assert 'userspace_architecture' in facts

# Generated at 2022-06-23 01:36:14.293035
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert isinstance(platform_facts, dict)
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts


# Generated at 2022-06-23 01:36:20.283977
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:36:24.835354
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:36:34.177879
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert "system" in platform_facts
    assert "kernel" in platform_facts
    assert "kernel_version" in platform_facts
    assert "machine" in platform_facts
    assert "python_version" in platform_facts
    assert "architecture" in platform_facts
    assert "fqdn" in platform_facts
    assert "hostname" in platform_facts
    assert "nodename" in platform_facts
    assert "domain" in platform_facts
    assert "userspace_bits" in platform_facts
    if platform_facts["machine"] == "x86_64" or solaris_i86_re.search(platform_facts["machine"]):
        assert "userspace_architecture" in platform_facts

# Generated at 2022-06-23 01:36:39.678131
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    assert pfc.collect() == {'architecture': 'x86_64', 'machine': 'x86_64', 'python_version': '2.7.5', 'kernel': '3.13.0-32-generic', 'kernel_version': '#57-Ubuntu SMP Tue Jul 15 03:51:08 UTC 2014', 'system': 'Linux'}

# Generated at 2022-06-23 01:36:41.323547
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version',
        'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:36:48.242678
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts.keys()
    assert 'kernel' in platform_facts.keys()
    assert 'kernel_version' in platform_facts.keys()
    assert 'machine' in platform_facts.keys()
    assert 'python_version' in platform_facts.keys()

# Generated at 2022-06-23 01:36:53.216849
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test for PlatformFactCollector class
    test = PlatformFactCollector()
    assert test
    assert test.name == 'platform'
    assert test._fact_ids == set(['system',
                                  'kernel',
                                  'kernel_version',
                                  'machine',
                                  'python_version',
                                  'architecture',
                                  'machine_id'])

# Generated at 2022-06-23 01:36:59.707829
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_collector = PlatformFactCollector()
    assert platform_facts_collector.name == 'platform'
    assert platform_facts_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])


# Generated at 2022-06-23 01:37:05.289123
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    facts = PlatformFactCollector().collect()
    assert 'architecture' in facts
    assert 'userspace_architecture' in facts
    assert 'userspace_bits' in facts
    assert 'system' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'fqdn' in facts
    assert 'nodename' in facts
    assert 'domain' in facts
    assert 'hostname' in facts
    assert 'python_version' in facts


# Generated at 2022-06-23 01:37:09.293638
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:37:13.591689
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'

    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:37:24.437112
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    # This can be Linux, Darwin, Java, or Windows
    assert platform_facts['system']

    # This can be Linux, Darwin, Java, or Windows
    assert platform_facts['kernel']

    assert platform_facts['kernel_version']
    assert platform_facts['machine']

    assert platform_facts['python_version']

    # To remove domain need to split on "." and join the last N-1 components
    assert platform_facts['fqdn']
    assert platform_facts['hostname']

    assert platform_facts['nodename']

    if len(platform_facts['fqdn'].split('.')) > 1:
        dot_domain_components = platform_facts['fqdn'].split('.')[1:]

# Generated at 2022-06-23 01:37:26.237918
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert len(PlatformFactCollector()._fact_ids) == 9

# Generated at 2022-06-23 01:37:34.707200
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Set up params
    params = {'module': {'run_command': run_command}, 'collected_facts': {}}

    # Instantiate PlatformFactCollector and invoke the collect method
    platform_facts = PlatformFactCollector.collect(params['module'], params['collected_facts'])

    # Assert that the facts we're expecting to see are in the returned platform_facts dictionary
    # Note that this test may very well fail on non Linux systems.
    required_facts = ['system', 'kernel', 'kernel_version', 'machine', 'python_version',
                      'architecture', 'fqdn', 'hostname', 'nodename', 'domain', 'userspace_bits']
    for fact in required_facts:
        assert fact in platform_facts, "%s not in platform_facts" % fact


# Generated at 2022-06-23 01:37:35.951028
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:37:36.959221
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:37:46.223566
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Init
    platform_fact_collector = PlatformFactCollector()

    # Test
    platform_facts = platform_fact_collector.collect()
    assert isinstance(platform_facts, dict)
    assert isinstance(platform_facts['system'], str)
    assert isinstance(platform_facts['kernel'], str)
    assert isinstance(platform_facts['kernel_version'], str)
    assert isinstance(platform_facts['machine'], str)
    assert isinstance(platform_facts['python_version'], str)
    assert isinstance(platform_facts['architecture'], str)

    # Clean
    pass

# Generated at 2022-06-23 01:37:58.493587
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json_called = False

        def fail_json(self, *args, **kwargs):
            self.fail_json_called = True

        def get_bin_path(self, app):
            if app == 'getconf':
                return '/usr/bin/getconf'
            elif app == 'bootinfo':
                return '/usr/sbin/bootinfo'

        def run_command(self, args):
            if args[0] == '/usr/sbin/bootinfo':
                if args[1] == '-K':
                    rc = 0
                    out = '64'
                    err = ''
                elif args[1] == '-p':
                    rc = 0

# Generated at 2022-06-23 01:38:06.342861
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    obj = fact_collector.collect()
    assert obj.get('system') is not None
    assert obj.get('kernel') is not None
    assert obj.get('kernel_version') is not None
    assert obj.get('machine') is not None
    assert obj.get('fqdn') is not None
    assert obj.get('hostname') is not None
    assert obj.get('nodename') is not None
    assert obj.get('architecture') is not None
    assert obj.get('python_version').split(".")[0] == "2"
    assert obj.get("machine_id") is not None

# Generated at 2022-06-23 01:38:15.772570
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import platform
    import os
    import sys
    import tempfile
    import json
    import pytest
    import ansible.module_utils.facts.system.platform

    class FakeModule(object):

        def __init__(self):
            self._debug = True
            self._verbosity = 0
            self.exit_args = None
            self.exit_kwargs = None
            self.warns = []
            self.failures = []
            self.result = {
                'ansible_facts': {'platform': {
                    'system': '',
                    'kernel': '',
                    'kernel_version': '',
                    'machine': ''}
                }
            }


# Generated at 2022-06-23 01:38:19.923198
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector != None
    platform_facts = platform_fact_collector.collect()
    assert type(platform_facts) is dict
    # TODO: Add more unit tests

# Generated at 2022-06-23 01:38:24.451074
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:38:34.760701
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Mock module to use the class
    module = Mock()
    # Create instance of PlatformFactCollector
    obj = PlatformFactCollector(module=module)
    # Collect the facts
    facts = obj.collect()
    # Test the collected facts

    assert facts['system'] == 'Linux'
    assert facts['kernel'] == '3.10.0-957.el7.x86_64'
    assert '.' in facts['kernel_version']
    assert facts['machine'] == 'x86_64'
    assert facts['python_version'] == '2.7.5'
    assert facts['fqdn'] == 'ip-10-0-1-102.eu-west-1.compute.internal'
    assert facts['hostname'] == 'ip-10-0-1-102'
    assert facts['nodename']

# Generated at 2022-06-23 01:38:39.850759
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    }
    assert isinstance(platform_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:38:40.542900
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-23 01:38:41.960802
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.collect()

# Generated at 2022-06-23 01:38:47.825876
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])



# Generated at 2022-06-23 01:38:49.633429
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)


# Generated at 2022-06-23 01:39:00.622394
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert type(platform_fact_collector._fact_ids) == set
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids
    assert 'userspace_bits' in platform_fact_collector._fact_ids

# Generated at 2022-06-23 01:39:10.661315
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import os
    import sys
    import platform

    class MockModule:
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])

        def get_bin_path(self, x):
            if x == 'getconf':
                return 'getconf'
            if x == 'bootinfo':
                return 'bootinfo'

        def run_command(self, command):
            if command == ['getconf','MACHINE_ARCHITECTURE']:
                return 0, 'testarch', None
            if command == ['bootinfo','-p']:
                return 0, 'rs6k', None
            raise Exception('unexpected call to run_command')


# Generated at 2022-06-23 01:39:12.452390
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.collect()

# Generated at 2022-06-23 01:39:14.178355
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert set(p.collect().keys()) == set(p._fact_ids)

# Generated at 2022-06-23 01:39:24.806634
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content, get_bin_path
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts._module import _Module
    from ansible.module_utils.facts.collector import Facts

    def mock_get_file_content(filename):
        class Dummy(object):
            def __init__(self):
                self.data = {
                    "/etc/machine-id": "some_machine_id\n",
                    "/var/lib/dbus/machine-id": "another_machine_id\n",
                }
            def __call__(self):
                return self.data[filename]
        return Dummy()


# Generated at 2022-06-23 01:39:30.452174
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pl = PlatformFactCollector()
    assert sorted(pl._fact_ids) == sorted(['system',
                                           'kernel',
                                           'kernel_version',
                                           'machine',
                                           'python_version',
                                           'architecture',
                                           'machine_id'])
    assert pl.name == 'platform'

# Generated at 2022-06-23 01:39:31.632991
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()