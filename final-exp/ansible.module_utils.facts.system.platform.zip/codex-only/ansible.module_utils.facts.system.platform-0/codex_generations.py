

# Generated at 2022-06-23 01:29:36.888874
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    imp_platform = 'ansible.module_utils.facts.collector.platform_sunos.platform'
    imp_socket   = 'ansible.module_utils.facts.collector.platform_sunos.socket'
    imp_re       = 'ansible.module_utils.facts.collector.platform_sunos.re'

    class TestModule(object):
        def __init__(self):
            self.exit_json = lambda x, **kwargs: None

        def get_bin_path(self, name):
            return None

        def run_command(self, args):
            cmd = args[0]
            if cmd == 'getconf':
                return 0, 'mach_arch', ''
            if cmd == 'bootinfo':
                return 0, 'powerpc', ''


# Generated at 2022-06-23 01:29:41.355309
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    result = {
        'architecture': 'x86_64',
        'fqdn': 'test.test.test.test',
        'kernel': '2.6.32-431.23.3.el6.x86_64',
        'kernel_version': '#1 SMP Fri Jan 3 21:39:27 UTC 2014',
        'machine': 'x86_64',
        'machine_id': '123123123123123123123123123123',
        'python_version': '2.6.6',
        'system': 'Linux',
        'userspace_architecture': 'x86_64',
        'userspace_bits': '64'
    }
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import get

# Generated at 2022-06-23 01:29:47.386038
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collected_facts = {}
    module_mock = mock.Mock()
    module_mock.run_command.return_value = (0, 'x86_64', '')
    platform_fact_collector = PlatformFactCollector(module=module_mock)
    result = platform_fact_collector.collect(collected_facts=collected_facts)
    assert result['architecture'] == 'x86_64'

# Generated at 2022-06-23 01:29:49.423167
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform = PlatformFactCollector()
    platform_facts = test_platform.collect()
    assert isinstance(platform_facts, dict)


# Generated at 2022-06-23 01:29:53.034527
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collect = PlatformFactCollector().collect()
    assert 'system' in collect
    assert 'kernel' in collect
    assert 'kernel_version' in collect
    assert 'machine' in collect
    assert 'python_version' in collect

# Generated at 2022-06-23 01:29:54.112518
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector.collect()

# Generated at 2022-06-23 01:29:58.362896
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact = PlatformFactCollector()
    assert fact.name == 'platform'
    assert fact._fact_ids == set(['system',
                                  'kernel',
                                  'kernel_version',
                                  'machine',
                                  'python_version',
                                  'architecture',
                                  'machine_id'])


# Generated at 2022-06-23 01:30:03.838923
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    Test the constructor of PlatformFactCollector
    '''
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == "platform"
    assert platform_collector._fact_ids == set(['system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'])


# Generated at 2022-06-23 01:30:09.617034
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])
    assert platform_fact_collector._platform == 'Generic'

# Generated at 2022-06-23 01:30:10.979380
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pc = PlatformFactCollector()
    assert pc.collect() is not None

# Generated at 2022-06-23 01:30:11.598378
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:30:15.514331
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-23 01:30:21.006828
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:30:27.209618
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'architecture',
                                                      'machine',
                                                      'python_version',
                                                      'machine_id'])

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:30:32.953447
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert "linux_distribution" in p._fact_ids
    assert isinstance(p._fact_ids, set)
    # Test that there are no other methods beginning with _
    p_methods = [a for a in dir(p) if not a.startswith('_')]
    assert len(p_methods) == 0

# Generated at 2022-06-23 01:30:38.773854
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:30:41.035532
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'

# Generated at 2022-06-23 01:30:52.963165
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = lambda args: ("", "", 0)
    module.get_bin_path = lambda binary: "/usr/bin/%s" % binary

    collector = PlatformFactCollector()

    # Test that the system is properly detected
    result = collector.collect(module, {})
    assert result["system"] == "Linux"
    assert result["userspace_bits"] == "64"
    assert result["userspace_architecture"] == "x86_64"
    assert result["architecture"] == "x86_64"

    # Test that the kernel version is properly detected
    assert result["kernel"] == "Linux"
    assert result["kernel_version"] == "Linux"

    # Test that we have the proper machine ID

# Generated at 2022-06-23 01:30:56.861072
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert plat.name == 'platform'
    assert plat._fact_ids == set(['system', 'kernel', 'kernel_version',
                                  'machine', 'python_version', 'architecture',
                                  'machine_id'])

# Generated at 2022-06-23 01:31:00.484641
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:31:01.348592
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:31:07.901377
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert len(platform_facts.keys()) > 1
    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['python_version']
    assert platform_facts['architecture']
    assert platform_facts['hostname']
    assert platform_facts['nodename']
    assert platform_facts['domain']

# Generated at 2022-06-23 01:31:12.470556
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert sorted(x._fact_ids) == sorted(['system', 'kernel', 'kernel_version',
                                           'machine', 'python_version', 'architecture',
                                           'machine_id'])

# Generated at 2022-06-23 01:31:16.172089
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert len(platform_facts) > 0
    for fact_id in platform_facts:
        assert isinstance(platform_facts[fact_id], str)
        assert fact_id in PlatformFactCollector._fact_ids

# Generated at 2022-06-23 01:31:21.229261
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fc = PlatformFactCollector()
    facts = platform_fc.collect()
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'python_version' in facts
    assert 'architecture' in facts

# Generated at 2022-06-23 01:31:30.513159
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plugin = PlatformFactCollector()
    assert plugin.name == 'platform'
    assert plugin.fact_class == 'platform'
    assert plugin._fact_ids == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])


# Generated at 2022-06-23 01:31:38.642615
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Set up the objects we need and set attributes on those objects as needed.
    module = type('FakeModule', (object,), dict(get_bin_path=lambda _: False))()
    module.run_command = lambda _: (True, 'machine', '')
    # Call the method we're testing, passing in the faked objects.
    fact = PlatformFactCollector(module).collect()
    # Check that the fact we expect is correct.
    assert fact['machine'] == 'machine', "platform.fact.collect() does not return correct machine fact."

# Generated at 2022-06-23 01:31:47.488793
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    def mock_get_bin_path(module_name):
        # On AIX, we use bootinfo to determine the architecture
        #
        # In tests, that isn't available, so we alias bootinfo to
        # uname so the test passes
        if module_name == 'bootinfo':
            return '/usr/bin/uname'
        elif module_name == 'getconf':
            return '/usr/bin/getconf'
        else:
            return None

    import mock
    class MockModule(object):
        def __init__(self):
            self._ancient_python = False
        def get_bin_path(self, binary):
            return mock_get_bin_path(binary)
        def run_command(self, cmd, stdin=None, use_unsafe_shell=False):
            out = ""


# Generated at 2022-06-23 01:31:58.066307
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import ansible.module_utils.facts.collectors.platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import module

    get_file_content_map = {
        '/var/lib/dbus/machine-id': 'eee1e00a8f2b4831ab6f13d2d3b6ffa3',
        '/etc/machine-id': 'eee1e00a8f2b4831ab6f13d2d3b6ffa3'
    }

    BaseFactCollector._module = module

    def get_bin_path_fake(path):
        return None


# Generated at 2022-06-23 01:32:06.372477
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fc = PlatformFactCollector()

    expected = {'system': 'Linux', 'kernel': '3.16.0-4-amd64', 'kernel_version': '#1 SMP Debian 3.16.7-ckt11-1+deb8u4 (2015-09-19)', 'machine': 'x86_64', 'python_version': '2.7.8', 'fqdn': 'dell-7010', 'hostname': 'dell-7010', 'nodename': 'dell-7010', 'domain': 'dell-7010', 'userspace_bits': '64', 'architecture': 'x86_64', 'userspace_architecture': 'x86_64'}

    assert expected == fc.collect(None, None)

# Generated at 2022-06-23 01:32:13.224762
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    fact_ids = frozenset(['system',
                          'kernel',
                          'kernel_version',
                          'machine',
                          'python_version',
                          'architecture',
                          'machine_id'])
    assert platform_fact_collector._fact_ids == fact_ids

# Generated at 2022-06-23 01:32:20.182308
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    "TEST: Basic and AIX platform info"

    class MockLinuxModule:
        def get_bin_path(self, name):
            return None

        def run_command(self, cmd):
            if cmd[0] == '/usr/bin/getconf':
                return 0, 'POWER6\n', ''
            elif cmd[0] == '/usr/sbin/bootinfo':
                return 0, 'powerpc\n', ''

    class MockAIXModule:
        def get_bin_path(self, name):
            if name == 'getconf':
                return '/usr/bin/getconf'
            elif name == 'bootinfo':
                return '/usr/sbin/bootinfo'
            else:
                return None


# Generated at 2022-06-23 01:32:29.559976
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # The following fake 'ansible_facts' are necessary to get past the
    # code in the BaseFactCollector class.
    ansible_facts = {'ansible_local': {'gathered_facts_filter': ['!network', '!facter', '!ohai']}}
    test_module = BaseFactCollector(ansible_facts=ansible_facts)

    # The following fake 'module' is necessary to get past the code in
    # the PlatformFactCollector class.
    test_module.get_bin_path = lambda path: path
    test_module.run_command = lambda arr: (0, '', '')
    test_module.get_file_content = lambda path: path

    platform_collector = PlatformFactCollector(module=test_module)
    platform_facts = platform_collector.collect()



# Generated at 2022-06-23 01:32:36.771520
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """This is a dummy unit test.  It looks like it will fail on platforms
    that do not use the platform module (e.g., Windows)."""
    import socket
    import platform
    # platform.system() can be Linux, Darwin, Java, or Windows
    assert platform.system() in ['Linux', 'Darwin', 'Java', 'Windows']
    assert platform.release()
    assert platform.version()
    assert platform.machine()
    my_fqdn = socket.getfqdn()
    assert my_fqdn
    assert platform.node().split('.')[0]
    assert platform.node() == my_fqdn

# Generated at 2022-06-23 01:32:48.064468
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PC = PlatformFactCollector()

    # Mock module
    class MockModule(object):

        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = list()

        def run_command(self, args):
            out, err = '', ''
            return (0, out, err)

        def get_bin_path(self, executable):
            return ''

    module = MockModule()

    # Mock platform
    sys = platform.system
    arch = platform.architecture
    plat = platform.platform
    uname = platform.uname

    platform.system = lambda: 'Linux'
    platform.architecture = lambda: ['64bit', '']

# Generated at 2022-06-23 01:32:52.390236
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    fact_collector.collect()

    # Test that _fact_ids is set to something other than the default
    assert fact_collector._fact_ids != BaseFactCollector._fact_ids

# Generated at 2022-06-23 01:32:58.777354
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert sorted(x._fact_ids) == sorted(['architecture',
                                          'fqdn',
                                          'hostname',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'machine_id',
                                          'nodename',
                                          'python_version',
                                          'system',
                                          'domain'])



# Generated at 2022-06-23 01:33:00.671858
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platFactCollector = PlatformFactCollector()
    assert platFactCollector.name == 'platform'

# Generated at 2022-06-23 01:33:03.048164
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert len(pfc.collect()) >= len(pfc._fact_ids)

# Generated at 2022-06-23 01:33:05.098529
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for method collect of class
    PlatformFactCollector
    """
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:33:06.230793
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:33:09.115433
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    print(x.name)
    print(x.collect())

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:33:17.073252
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create instance of class PlatformFactCollector
    pfc = PlatformFactCollector()

    # Create instance of mock class object
    module = AnsibleModuleMock()

    # Call method collect of class PlatformFactCollector
    result = pfc.collect(module, "collected_facts")

    # Check if result is correct

# Generated at 2022-06-23 01:33:28.355068
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:33:36.707694
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    import platform

    platform_module = BaseFactCollector()

    platform_collector = PlatformFactCollector(platform_module)

    platform_facts = platform_collector.collect()

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['architecture'] == platform.uname()[4]



# Generated at 2022-06-23 01:33:45.985142
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, program, required=False, opt_dirs=[]):
            if program in self.params:
                return self.params[program]
            else:
                return None

        def run_command(self, args):
            if args[0] in self.params:
                return 0, self.params[args[0]], ""
            else:
                return 0, "", ""

    module = TestModule({
        "bootinfo": "16"
    })
    PlatformFactCollector.collect(module)

    module = TestModule({
        "bootinfo": "32"
    })
    PlatformFactCollector.collect(module)


# Generated at 2022-06-23 01:33:51.555631
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector().collect()

    assert result['system'] == "Linux"
    assert result['architecture'] == "x86_64"
    assert result['machine'] == "x86_64"
    assert result['machine_id'] == "c9e09f79c56e4543917d895cef1b305a"

# Generated at 2022-06-23 01:33:58.481441
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    # Test platform_facts has required keys
    platform_facts = PlatformFactCollector()
    assert 'system' in platform_facts.collect().keys()
    assert 'kernel' in platform_facts.collect().keys()
    assert 'kernel_version' in platform_facts.collect().keys()
    assert 'machine' in platform_facts.collect().keys()
    assert 'python_version' in platform_facts.collect().keys()
    assert 'architecture' in platform_facts.collect().keys()
    assert 'machine_id' in platform_facts.collect().keys()

# Generated at 2022-06-23 01:34:05.830337
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create object of class PlatformFactCollector
    PlatformFactCollectorObj = PlatformFactCollector()

    # Validate name var of object PlatformFactCollectorObj
    assert PlatformFactCollectorObj.name == "platform"

    # Validate platform var of object PlatformFactCollectorObj
    assert PlatformFactCollectorObj._fact_ids == {"system",
                                                   "kernel",
                                                   "kernel_version",
                                                   "machine",
                                                   "python_version",
                                                   "architecture",
                                                   "machine_id"}

# Generated at 2022-06-23 01:34:10.348215
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert not platform_facts['system'] is None
    assert not platform_facts['kernel'] is None
    assert not platform_facts['kernel_version'] is None
    assert not platform_facts['machine'] is None
    assert not platform_facts['python_version'] is None

# Generated at 2022-06-23 01:34:14.674060
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == {'system','kernel','kernel_version',
                           'machine','python_version','architecture',
                           'machine_id'}

# Generated at 2022-06-23 01:34:18.039908
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-23 01:34:20.224331
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert set(PlatformFactCollector()._fact_ids) == PlatformFactCollector._fact_ids

# Generated at 2022-06-23 01:34:24.106585
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == {'system',
                                        'kernel',
                                        'kernel_version',
                                        'machine',
                                        'python_version',
                                        'architecture',
                                        'machine_id'}

# Generated at 2022-06-23 01:34:28.409288
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:34:32.536373
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                               'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:34:41.864691
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test all of the return values, except 'python_version'.
    # There is no way to know what Python version the test is
    # running under.

    class MockModule(object):
        def run_command(self, args):
            if args[0] == 'bootinfo' and args[1] == '-p':
                return 0, 'PowerPC_POWER7\n', ''
            elif args[0] == 'getconf' and args[1] == 'MACHINE_ARCHITECTURE':
                return 0, 'PowerPC_POWER7', ''
            else:
                return 0, '', ''

        def get_bin_path(self, argv0, required=False):
            if argv0 in ['bootinfo', 'getconf']:
                return 'bin/' + argv0

# Generated at 2022-06-23 01:34:49.728835
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import sys

    class FakeModule(object):
        def get_bin_path(self, name):
            return None

        def run_command(self, args):
            return 0, '', ''

    module = FakeModule()
    facts = {}
    fact_collector = PlatformFactCollector()
    fact_collector.collect(module, facts)

    assert set(facts.keys()) == fact_collector._fact_ids

    # To keep backward compatibilty
    assert facts['distribution'] == facts['system']
    assert facts['distribution_version'] == facts['kernel_version']
    assert facts['distribution_release'] == facts['kernel']
    assert facts['os_family'] == facts['system']
    assert facts['virtual'] == platform.python_version_tuple()[0]



# Generated at 2022-06-23 01:35:00.258853
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from os import path
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import Facts

    # Create an instance of a PlatformFactCollector class
    pfc = PlatformFactCollector()

    # Create an instance of a Facts class
    facts = Facts()

    # Create an instance of a Collector class
    c = Collector(facts, [pfc])

    # Define the test params
    params = {}
    module = "an_ansible_module"
    collected_facts = {}

    # Execute the collect method of the PlatformFactCollector class
    result = pfc.collect(module=module, collected_facts=collected_facts)

    # Test if result is a dict
    assert isinstance(result, dict)
    # Test if result has a key called system

# Generated at 2022-06-23 01:35:04.439058
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-23 01:35:04.856291
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:35:12.367929
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Dummy class for module
    class DummyModule:
        class DummyRunCommand:
            stdout = 'test'

        def get_bin_path(self, name):
            return name

        def run_command(self, command):
            return DummyRunCommand()

    def get_file_content(name):
        return 'test'

    module = DummyModule()

    collector = PlatformFactCollector()

    facts = collector.collect(module, None)

    assert facts['architecture'] == 'x86_64'
    assert facts['machine_id'] == 'test'

# Generated at 2022-06-23 01:35:22.131752
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = FakeAnsibleModule()

# Generated at 2022-06-23 01:35:29.505716
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids

# Generated at 2022-06-23 01:35:32.788665
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x._fact_ids == {'system',
                           'kernel',
                           'kernel_version',
                           'machine',
                           'python_version',
                           'architecture',
                           'machine_id'}


# Generated at 2022-06-23 01:35:38.430945
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts.collector import Cache
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils import fallback_facts

    c = PlatformFactCollector()

    facts = dict(fallback_facts, system='Linux', kernel='3.10.0-123.el7.x86_64', kernel_version='#1 SMP Tue Sep 9 16:56:34 EDT 2014', machine='x86_64')

# Generated at 2022-06-23 01:35:43.620767
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-23 01:35:44.815449
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert not PlatformFactCollector()._fact_ids



# Generated at 2022-06-23 01:35:46.215263
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert plat.name == 'platform'
    assert 'system' in plat.collect()

# Generated at 2022-06-23 01:35:50.801869
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'])

# Generated at 2022-06-23 01:35:57.395964
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:36:02.594938
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert sorted(set(pfc._fact_ids)) == ['system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id']

# Generated at 2022-06-23 01:36:07.911482
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    assert 'python_version' in platform_facts
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-23 01:36:12.207366
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == {'system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'}


# Generated at 2022-06-23 01:36:23.059493
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """This unit test checks if values of class PlatformFactCollector are
    collected correctly.
    """

    # the various possibilities how the output of platform.machine() can look
    # like
    platform_machine = ('armv6l',
                        'armv7l',
                        'x86_64',
                        'i386',
                        'i586',
                        'i686',
                        'sun4u',
                        'sparc',
                        'sun4v',
                        'sparcv9',
                        'aarch64',
                        'ppc64le',
                        'x86_64',
                        'AMD64',
                        'Power Macintosh',
                        'i686')

    # the various possibilities how the output of platform.architecture()[0]
    # can look like

# Generated at 2022-06-23 01:36:34.193971
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import mock

    module = mock.Mock()
    collected_facts = mock.Mock()

# Generated at 2022-06-23 01:36:38.419249
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test setup
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert set(pf._fact_ids) == set(['system',
                                     'kernel',
                                     'kernel_version',
                                     'machine',
                                     'python_version',
                                     'architecture',
                                     'machine_id'])

# Generated at 2022-06-23 01:36:49.377892
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import re
    import socket
    import tempfile

    # Create a temporary file to hold the machine-id
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write("1234567890123456789012345678901234567890\n")
    f.close()

    # Create a PlatformFactCollector
    pfc = PlatformFactCollector()

    # Create a 'module' mock object
    class ModuleMock:
        def __init__(self):
            self.params = dict()
            self.bin_path = dict()

        def get_bin_path(self, bname):
            return self.bin_path.get(bname)

    module = ModuleMock()

    # Set up a few module.params values

# Generated at 2022-06-23 01:36:53.640897
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_subject = PlatformFactCollector()
    assert test_subject.name == 'platform'
    assert test_subject._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:37:00.803138
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import TestFactCollector

    fake_module = TestFactCollector()
    fake_module.run_command = lambda x, check_rc=False, close_fds=False: (0, "", "")
    fake_module.get_bin_path = lambda x: None

    PlatformFactCollector().collect(fake_module, dict())

    # Ensure the platform fact collector is non-destructive
    assert fake_module.run_command.call_count == 0

# Generated at 2022-06-23 01:37:07.456471
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:37:16.767264
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert hasattr(obj, "name")
    assert obj.name == "platform"
    assert hasattr(obj, "_fact_ids")
    assert 'system' in obj._fact_ids
    assert 'kernel' in obj._fact_ids
    assert 'kernel_version' in obj._fact_ids
    assert 'machine' in obj._fact_ids
    assert 'python_version' in obj._fact_ids
    assert 'architecture' in obj._fact_ids
    assert 'machine_id' in obj._fact_ids

    assert hasattr(obj, "collect")
    assert callable(obj.collect)

# Generated at 2022-06-23 01:37:27.529938
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from ansible.module_utils.facts import collector

    platform_fact_collector = collector.get_collector('platform')
    platform_facts = platform_fact_collector.collect()

    assert platform_facts['system'] in ('Linux', 'Darwin', 'Java', 'Windows') or platform_facts['system'].startswith('CYGWIN')
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['architecture'] in ('x86_64', 'x86', 'i386', 'i686', 'ppc64', 'ppc64le')

   

# Generated at 2022-06-23 01:37:29.320270
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = FakeModule()
    fact_collector = PlatformFactCollector(module=module)
    fact_collector.collect(module)

# Generated at 2022-06-23 01:37:36.905530
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module_mock = {}

    class Subobject(object):
        def __init__(self):
            self.rc = 0
            self.stdout = 'i'
            self.stderr = ''

    subobject_mock = Subobject()

    def run_command_mock(command, check_rc=True):
        if command == ['getconf', 'MACHINE_ARCHITECTURE']:
            return subobject_mock
        return Subobject()

    def get_bin_path_mock(binary):
        if binary == 'bootinfo':
            return '/no/such/bootinfo'
        elif binary == 'getconf':
            return '/no/such/getconf'
        return None

    module_mock.run_command = run_command_mock
    module_mock.get_bin

# Generated at 2022-06-23 01:37:44.909251
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids

# Generated at 2022-06-23 01:37:50.438678
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fc = PlatformFactCollector()
    facts = [
        'os',
        'distribution',
        'distribution_release',
        'distribution_version',
    ]
    data = fc.collect(collected_facts=facts)

    assert data['os'] == 'Linux'
    assert data['distribution'] == 'Ubuntu'
    assert data['distribution_release'] == '14.04'
    assert data['distribution_version'] == '14.04'

# Generated at 2022-06-23 01:37:57.418063
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.utils import AnsibleFact

    PlatformFactCollector.collect()
    assert AnsibleFact('system') in Collector._fact_cache
    assert AnsibleFact('kernel_version') in Collector._fact_cache
    assert AnsibleFact('machine') in Collector._fact_cache
    assert AnsibleFact('python_version') in Collector._fact_cache

    assert PlatformFactCollector.name in Collector._fact_cache.names

# Generated at 2022-06-23 01:38:00.715919
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_collector = PlatformFactCollector()
    end_result = test_collector.collect()

    assert isinstance(end_result, dict)
    for key in test_collector._fact_ids:
        assert key in end_result

# Generated at 2022-06-23 01:38:04.504815
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():    
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:38:06.203526
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    platform_facts = PlatformFactCollector()
    assert ('machine_id' in platform_facts.collect())

# Generated at 2022-06-23 01:38:15.007811
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    argument_spec = {}
    platform_collector = PlatformFactCollector(argument_spec, basic.AnsibleModule(
        argument_spec=argument_spec, supports_check_mode=True))
    platform_facts = platform_collector.collect()
    assert platform_facts['system'].lower() in ['linux', 'darwin', 'java', 'windows']
    assert platform_facts['userspace_bits'] in ['32', '64']
    assert platform_facts['architecture'] in ['i386', 'x86_64', 'ppc64', 'ppc64le', 'ppc64p7']
    #assert platform_facts['python_version'].startswith('2.')

# Generated at 2022-06-23 01:38:21.119448
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fc = PlatformFactCollector()

    assert platform_fc.name == 'platform'
    assert set(platform_fc._fact_ids) == set(['system',
                                              'kernel',
                                              'kernel_version',
                                              'machine',
                                              'python_version',
                                              'architecture',
                                              'machine_id'])

    assert platform_fc.collect()

# Generated at 2022-06-23 01:38:31.996418
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts.utils import ModuleFactsCollectionHelper
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.platform import name

    # Create a new object of class PlatformFactCollector to test its methods
    pfc = PlatformFactCollector()

    # test collect function
    mfch = ModuleFactsCollectionHelper(name)
    mfch.add(pfc)
    collected_facts = mfch.get_facts()
    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    assert collected_facts['machine'] == platform.machine()

# Generated at 2022-06-23 01:38:36.752911
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:38:43.244911
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert sorted(x._fact_ids) == sorted(['system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id'])
    assert x.collect() > 0

# Generated at 2022-06-23 01:38:47.494726
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:38:56.882869
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    platform_fact_collector = PlatformFactCollector(module=module)
    platform_facts = platform_fact_collector.collect(module=module)
    assert set(platform_facts.keys()) == set(['system',
                                              'kernel',
                                              'kernel_version',
                                              'machine',
                                              'python_version',
                                              'fqdn',
                                              'hostname',
                                              'nodename',
                                              'domain',
                                              'userspace_bits',
                                              'architecture',
                                              'userspace_architecture'])


# Generated at 2022-06-23 01:39:05.492958
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import ansible.module_utils.facts.collectors.platform as platform_collector

    class TestModule(object):
        def __init__(self, returncode, stdout, stderr):
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

        def run_command(self, args):
            return self.returncode, self.stdout, self.stderr

        def get_bin_path(self, arg):
            return 'path/to/' + arg

    test_module = TestModule(0, "alpine\n", "")
    fact_collector = platform_collector.PlatformFactCollector()

    # expected result when the get_file_content succeeded
    # (machine_id exists)
    (returncode, result, err) = fact

# Generated at 2022-06-23 01:39:08.419608
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector

    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector.collect()

# Generated at 2022-06-23 01:39:20.018271
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test data
    _system_str = "Linux"
    _kernel_str = "3.10.0-327.el7.x86_64"
    _kernel_version_str = "#1 SMP Thu Nov 19 22:10:57 UTC 2015"
    _machine_str = "x86_64"
    _python_version_str = "2.7.5"
    _fqdn_str = "test_machine.test_realm"
    _hostname_str = "test_machine"
    _nodename_str = "test_machine.test_realm"
    _domain_str = "test_realm"
    _userspace_bits_str = "64"
    _architecture_str = "x86_64"

# Generated at 2022-06-23 01:39:25.769404
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert 'system' in pf._fact_ids
    assert 'kernel' in pf._fact_ids
    assert 'kernel_version' in pf._fact_ids
    assert 'machine' in pf._fact_ids
    assert 'python_version' in pf._fact_ids
    assert 'architecture' in pf._fact_ids

# Generated at 2022-06-23 01:39:30.607890
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()