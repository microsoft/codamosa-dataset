

# Generated at 2022-06-23 01:29:38.480217
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:29:40.352130
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), PlatformFactCollector)

# Generated at 2022-06-23 01:29:45.873384
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:29:47.831087
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    assert 'system' in platform_fact_collector.collect()

# Generated at 2022-06-23 01:29:57.951677
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes
    platform = PlatformFactCollector()
    py_version = "%s.%s.%s" % (platform.python_version_info[0], platform.python_version_info[1], platform.python_version_info[2])
    facts = platform.collect()
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine_id'].startswith('c936d8ce')
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == py_version
    assert facts['fqdn'] == socket.getfqdn()

# Generated at 2022-06-23 01:30:02.227542
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'}

# Generated at 2022-06-23 01:30:04.488606
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert BaseFactCollector.collect(PlatformFactCollector)

# Generated at 2022-06-23 01:30:06.943079
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    fact_collector._module = None
    fact_collector._collect()

# Generated at 2022-06-23 01:30:13.381350
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'machine_id' in p._fact_ids



# Generated at 2022-06-23 01:30:15.705863
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        p = PlatformFactCollector()
    except:
        pass


# Generated at 2022-06-23 01:30:25.815409
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test PlatformFactCollector.collect and PlatformFactCollector.get_fact_ids methods"""
    # Test module with faked ansible "AnsibleModule"
    # Test class with faked ansible "AnsibleModule"
    # Test class with faked ansible "AnsibleModule"

    platform_facts = {}

    # Python 2.6 doesn't have getfqdn
    getfqdn = getattr(socket, 'getfqdn', lambda: 'localhost.localdomain')
    platform_facts['fqdn'] = getfqdn()
    platform_facts['hostname'] = platform.node()
    platform_facts['nodename'] = platform.node()
    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    platform_facts['system']

# Generated at 2022-06-23 01:30:36.560863
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])
    assert platform_facts['userspace_bits'] in ["64", "32", "16", "8"]

# Generated at 2022-06-23 01:30:39.065664
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    instance = PlatformFactCollector()

    assert isinstance(instance, PlatformFactCollector)
    assert hasattr(instance, 'name')
    assert hasattr(instance, '_fact_ids')

# Generated at 2022-06-23 01:30:43.072295
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:30:46.253163
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    facts = collector.collect()

    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'python_version' in facts
    assert 'architecture' in facts

# Generated at 2022-06-23 01:30:53.323239
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = FakeModule()
    platform = PlatformFactCollector()
    result = platform.collect(module)
    assert result['system'] == 'Linux'
    assert result['kernel'] == '2.6.18-92.el5'
    assert result['kernel_version'] == '#1 SMP Thu Apr 10 13:58:00 EDT 2008'
    assert result['machine'] == 'x86_64'
    assert result['python_version'] == '2.6.6'
    assert result['fqdn'] == 'localhost.localdomain'
    assert result['hostname'] == 'localhost'
    assert result['nodename'] == 'localhost.localdomain'
    assert result['domain'] == 'localdomain'
    assert result['userspace_bits'] == '64'

# Generated at 2022-06-23 01:31:04.784539
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test the collect function of the PlatformFactCollector class.
    """
    class FakeAnsibleModule(object):
        """
        Class that implements the AnsibleModule API.
        """
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.debug = False
            self.fail_json = False
            self.exit_json = False

        def get_bin_path(self, path):
            """
            Implements the get_bin_path() function of the AnsibleModule class.
            """
            return '/bin/' + path

        def run_command(self, args):
            """
            Implements the run_command() function of the AnsibleModule class.
            """

# Generated at 2022-06-23 01:31:13.839547
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_system_facts = PlatformFactCollector()
    # Checks if class PlatformFactCollector is instance of BaseFactCollector
    assert isinstance(test_system_facts, BaseFactCollector)
    # Checks if class PlatformFactCollector has attribute name and _fact_ids
    assert hasattr(test_system_facts, 'name')
    assert hasattr(test_system_facts, '_fact_ids')
    # Checks if system name is platform
    assert test_system_facts.name == 'platform'


platform_mod = PlatformFactCollector()
platform_mod.collect()

# Generated at 2022-06-23 01:31:22.013370
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assertNotEmpty(platform_facts['system'])
    assertNotEmpty(platform_facts['kernel'])
    assertNotEmpty(platform_facts['kernel_version'])
    assertNotEmpty(platform_facts['machine'])
    assertNotEmpty(platform_facts['python_version'])
    assertNotEmpty(platform_facts['architecture'])
    assertNotEmpty(platform_facts['machine_id'])
    assertNotEmpty(platform_facts['fqdn'])
    assertNotEmpty(platform_facts['hostname'])
    assertNotEmpty(platform_facts['nodename'])
    assertNotEmpty(platform_facts['domain'])
    assertNotEmpty(platform_facts['userspace_bits'])

# Generated at 2022-06-23 01:31:29.605927
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    platform_facts_mock = dict(system=platform.system(),
                               kernel=platform.release(),
                               kernel_version=platform.version(),
                               machine=platform.machine(),
                               python_version=platform.python_version(),
                               fqdn=socket.getfqdn(),
                               hostname='testhost')
    fact_collector = PlatformFactCollector()
    fact_collector.collect()
    for key in platform_facts_mock:
        assert fact_collector.facts[key] == platform_facts_mock[key]



# Generated at 2022-06-23 01:31:34.184962
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert isinstance(platform_facts, dict)
    assert platform_facts



# Generated at 2022-06-23 01:31:35.189496
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:31:40.319388
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version',
                                 'machine', 'python_version', 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:31:44.176370
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == "platform"
    assert set(PlatformFactCollector._fact_ids) == set(
            ['system',
             'kernel',
             'kernel_version',
             'machine',
             'python_version',
             'architecture',
             'machine_id'])

# Generated at 2022-06-23 01:31:54.213101
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class FakeModule(object):
        """Class to fake a module"""
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, bin):
            """Fake get_bin_path to return a preset bin path"""
            return self.params.get(bin, None)

        def run_command(self, command):
            """Fake run_command to return a preset result"""
            return self.params.get(command[0], dict(rc=1))

    class FakeAnsibleModule(object):
        """Class to fake an AnsibleModule"""
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, bin):
            """Fake get_bin_path to return a preset bin path"""

# Generated at 2022-06-23 01:32:00.365178
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

    pfc = PlatformFactCollector(['extra'])
    assert pfc._fact_ids == set(['extra'])



# Generated at 2022-06-23 01:32:07.503117
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_result = platform_collector.collect()
    assert platform_result['system'] == 'Linux'
    assert platform_result['kernel'] == '4.4.0-97-generic'
    assert platform_result['fqdn'] == 'test-platform-facts.com'
    assert platform_result['hostname'] == 'test-platform-facts'
    assert platform_result['nodename'] == 'test-platform-facts.com'
    assert platform_result['domain'] == 'com'
    assert platform_result['python_version'] == '2.7.12'
    assert platform_result['machine_id'] == 'FAKE_MACHINE_ID'


# Generated at 2022-06-23 01:32:10.031365
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'


# Generated at 2022-06-23 01:32:11.822795
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None

# Generated at 2022-06-23 01:32:16.015150
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                              'kernel',
                              'kernel_version',
                              'machine',
                              'python_version',
                              'architecture',
                              'machine_id'])

# Generated at 2022-06-23 01:32:27.130908
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts import ansible_collector
    # Monkey-patching together a platform.system() that returns 'Linux'
    def fake_system():
        return 'Linux'
    platform_parent_namespace = platform.__dict__.copy()
    platform_namespace = platform.system.__dict__.copy()
    platform.system = mock_module.MockModule(platform_namespace, fake_system)

    # Monkey-patching together a platform.machine() that returns 'x86_64'
    def fake_machine():
        return 'x86_64'
    platform_namespace = platform.machine.__dict__.copy()
    platform.machine = mock_module.MockModule(platform_namespace, fake_machine)



# Generated at 2022-06-23 01:32:35.951537
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create an instance of PlatformFactCollector
    x = PlatformFactCollector()

    # Run the method collect of PlatformFactCollector on a simple test case
    platform_facts = x.collect()

    # Test the result
    assert platform.system() == platform_facts['system']
    assert platform.release() == platform_facts['kernel']
    assert platform.version() == platform_facts['kernel_version']
    assert platform.machine() == platform_facts['machine']
    assert platform.python_version() == platform_facts['python_version']
    assert platform_facts['hostname'] == platform_facts['fqdn'].split('.')[0]
    assert platform_facts['nodename'] == platform.node()

# Generated at 2022-06-23 01:32:47.170884
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import PlatformFactCollector

    # Create a platform fact collector instance
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

    # Verify that the name of a PlatformFactCollector is 'platform'
    assert platform_fact_collector.name == 'platform'

    # Create a Collector object
    collector = Collector()

    # Initialize the Collector object with the platform fact

# Generated at 2022-06-23 01:32:47.644611
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:32:57.941468
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    collected_facts = platform_collector.collect()
    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    if platform_collector.__module__.endswith('platform'):
        # When we are using the module from a galaxy collection, the machine name is different
        assert collected_facts['machine'] == platform.machine().replace('_', '-')
    else:
        assert collected_facts['machine'] == platform.machine()
    assert collected_facts['python_version'] == platform.python_version()
    assert collected_facts['fqdn'] == socket.getfqdn()

# Generated at 2022-06-23 01:33:08.592469
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform as pythonplatform

    testobj = PlatformFactCollector(None, {})

    # Test result of collect method in case some platform functions return
    # info that has not been expected earlier
    def foo1():
        return ("AIX", "", "", "", "", "", "", "", "")
    def foo2():
        return ("AIX", "", "", "", "", "", "", "", "", "")
    platform.uname = foo1
    platform.python_version = lambda: '2.7.99'
    testobj.architecture = lambda: 'foo'
    platform.architecture = foo2
    result = testobj.collect()
    assert result['architecture'] == 'foo'
    assert result['python_version'] == '2.7.99'

    platform.uname

# Generated at 2022-06-23 01:33:16.681343
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    print(platform_facts)

    # {
    #     'architecture': 'x86_64',
    #     'domain': 'saltstack.com',
    #     'fqdn': 'ubuntu-xenial.saltstack.com',
    #     'hostname': 'ubuntu-xenial',
    #     'kernel': '4.10.0-37-generic',
    #     'kernel_version': '#41~16.04.1-Ubuntu SMP Fri Oct 6 22:42:59 UTC 2017',
    #     'machine': 'x86_64',
    #     'machine_id': 'b13d5b59f7b44c5da8d5eb54214e5b5f',
    #     'nodename

# Generated at 2022-06-23 01:33:28.191620
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content, get_bin_path

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        )

    def ansible_get_file_content(filename):
        return get_file_content(filename)

    module.get_file_content = ansible_get_file_content

    platform = PlatformFactCollector(module)

    def ansible_get_bin_path(filename):
        return get_bin_path(filename)

    module.get_bin_path = ansible_get_bin_path

    def ansible_run_command(command):
        out = ""
        data

# Generated at 2022-06-23 01:33:33.041283
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    # test the name attribute
    assert x.name == 'platform'
    # test the _fact_ids attriute
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:33:43.414804
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import json
    import tempfile
    import os
    import platform

    # Create host facts
    platform_facts = {}
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]



# Generated at 2022-06-23 01:33:46.301790
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    TestFactCollector = type('TestFactCollector', (object,),
                             {'collect': PlatformFactCollector.collect})
    instance = TestFactCollector()
    assert isinstance(instance.collect(), dict)

# Generated at 2022-06-23 01:33:51.827448
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])



# Generated at 2022-06-23 01:33:53.210212
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'


# Generated at 2022-06-23 01:34:02.601198
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    fact_collector._module = None
    fact_collector._collect_platform()
    platform_facts = fact_collector.collect(module=None)
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()

# Generated at 2022-06-23 01:34:10.352462
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])


# Generated at 2022-06-23 01:34:20.518683
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Method collect of PlatformFactCollector can collect
    information about platform.

    This method is called by AnsibleModule.
    """
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    # Create a mocked ModuleFacts to avoid loading the real module
    module_facts = ModuleFacts(ModuleFactsCollector())

    # Create a mocked PlatformFactCollector
    platform_collector = PlatformFactCollector(module_facts)

    # Gather facts and test that we collected the expected ones
    facts = platform_collector.collect()
    assert 'python_version' in facts
    assert 'system' in facts
    assert 'kernel' in facts

# Generated at 2022-06-23 01:34:26.844504
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    Test the constructor of the PlatformFactCollector object.

    """
    platform_collector = PlatformFactCollector()
    assert platform_collector is not None
    # Test _fact_ids initialized to set
    assert isinstance(platform_collector._fact_ids, set)
    # Test name initialized to platform
    assert platform_collector.name == "platform"
    # Test _fact_ids initialized to expected set of references
    expected_ids_set = {"system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"}
    assert platform_collector._fact_ids == expected_ids_set


# Generated at 2022-06-23 01:34:29.971822
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    obj = PlatformFactCollector()
    platform_facts = obj.collect()
    assert platform_facts['system'] == 'Linux'

# Generated at 2022-06-23 01:34:39.872779
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            if cmd[0] == "getconf":
                return (0, "mock_getconf_machine_architecture_data", "")
            elif cmd[0] == "bootinfo":
                return (0, "mock_bootinfo_machine_architecture_data", "")
            elif cmd[0] == "uname":
                return (0, "OpenBSD", "")
            else:
                raise Exception("unexpected command: %s" % cmd)


# Generated at 2022-06-23 01:34:42.623415
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:34:50.733764
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create a module for testing
    basic._ANSIBLE_ARGS = to_bytes(
        '{"ANSIBLE_MODULE_ARGS": {}, "ANSIBLE_MODULE_CONSTANTS": {}, "ANSIBLE_MODULES": "", "ANSIBLE_KEEP_REMOTE_FILES": "0", "ANSIBLE_REMOTE_TEMP": "/tmp/ansible-tmp-1QnB1Gl/", "ANSIBLE_PYTHON_INTERPRETER": "/usr/bin/python", "ANSIBLE_MODULE_REQUIREMENTS": {}, "ANSIBLE_GATHER_SUBSET": ["all"]}'
    )

    pfc = PlatformFactCollector()

# Generated at 2022-06-23 01:34:55.566111
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'
    assert platformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-23 01:34:56.154321
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:35:06.245119
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    sys_platform = platform.system()
    if sys_platform == 'Darwin':
        platform_facts = PlatformFactCollector().collect(module)
        assert platform_facts['system'] == 'Darwin'
        assert platform_facts['kernel'] == 'Darwin'
        assert platform_facts['kernel_version'] == 'Darwin Kernel Version 17.4.0: Sun Dec 17 09:19:54 PST 2017; root:xnu-4570.41.2~1/RELEASE_X86_64'
        assert platform_facts['machine'] == 'x86_64'
        assert platform_facts['python_version'] == '2.7.14'
        assert platform_facts['architecture'] == 'x86_64'
        assert platform_facts['fqdn'] == 'localhost'
       

# Generated at 2022-06-23 01:35:17.435423
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:35:22.225450
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_collector = PlatformFactCollector()
    assert platform_facts_collector.name == 'platform'
    assert platform_facts_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-23 01:35:26.963863
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector(None)
    facts = pfc.collect({}, set())
    assert isinstance(facts, dict)
    assert len(facts) > 0
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'architecture' in facts
    assert 'userspace_bits' in facts
    assert 'machine' in facts

# Generated at 2022-06-23 01:35:30.732391
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:35:36.791244
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    print(PlatformFactCollector._fact_ids)
    print(PlatformFactCollector.collect())

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-23 01:35:47.117051
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Test with module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    module.run_command = MagicMock(return_value=(0, 'fakeout', 'fakeerr'))

    # Test with random module name
    module.params = {
        'module_name': 'fake_module_name',
    }

    # Test for method collect of class PlatformFactCollector with module object
    test_platform_fact_collector = PlatformFactCollector()
    test_platform_fact_collector.collect(module=module, collected_facts=dict())

    # Test for method collect of class PlatformFactCollector with module object and non-default module_name
    test_platform_fact_collector.collect(module=module, collected_facts=dict())

# Generated at 2022-06-23 01:35:51.229001
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:35:53.842139
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version', 'machine',
                             'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:35:55.761898
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'


# Generated at 2022-06-23 01:36:02.181449
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert sorted(p._fact_ids) == ['architecture', 'fqdn', 'hostname', 'kernel', 'kernel_version', 'machine', 'machine_id', 'nodename', 'python_version', 'system', 'userspace_architecture', 'userspace_bits']

# Generated at 2022-06-23 01:36:07.552515
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-23 01:36:15.890738
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    collected_facts = platform_fact_collector.collect()
    assert collected_facts["system"] == platform.system()
    assert collected_facts["kernel"] == platform.release()
    assert collected_facts["kernel_version"] == platform.version()
    assert collected_facts["machine"] == platform.machine()
    assert collected_facts["python_version"] == platform.python_version()
    assert collected_facts["fqdn"] == socket.getfqdn()
    assert collected_facts["hostname"] == platform.node().split('.')[0]
    assert collected_facts["nodename"] == platform.node()
    assert collected_facts["domain"] == '.'.join(collected_facts["fqdn"].split('.')[1:])

# Generated at 2022-06-23 01:36:21.226972
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:36:28.765694
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    module = type('module', (object,), {
        'get_bin_path': lambda *a, **kw: None
    })()

    platform_fact_collector = PlatformFactCollector(module=module)

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    ])


# Generated at 2022-06-23 01:36:37.268088
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()

    returned_platform_facts = platform_collector.collect()

    assert returned_platform_facts["system"] == "Linux"
    assert returned_platform_facts["kernel"] == "4.9.0-8-amd64"
    assert returned_platform_facts["kernel_version"] == "#1 SMP Debian 4.9.144-3.1 (2019-02-19)"
    assert returned_platform_facts["machine"] == "x86_64"
    assert returned_platform_facts["python_version"] == "2.7.16"
    assert returned_platform_facts["fqdn"] == "debian-amd64-8.home"
    assert returned_platform_facts["hostname"] == "debian-amd64-8"

# Generated at 2022-06-23 01:36:42.059032
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()
    collector.collect_platform_facts()
    assert collector.platform_facts['machine'] == 'x86_64'
    assert collector.platform_facts['architecture'] == 'x86_64'
    assert collector.platform_facts['userspace_architecture'] == 'x86_64'

# Generated at 2022-06-23 01:36:52.808492
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Mock p platform
    mock_platform = mock.MagicMock()
    mock_platform.system.return_value = 'Linux'
    mock_platform.release.return_value = '3.18.9-1'
    mock_platform.version.return_value = '#1 SMP Thu Apr 23 10:48:33 PDT 2015'
    mock_platform.machine.return_value = 'amd64'
    mock_platform.python_version.return_value = '3.5.1'
    mock_platform.node.return_value = 'example.com'
    mock_platform.architecture.return_value = ('64bit', '')
    pltfrm = {'platform': mock_platform}

    # Mock socket module
    mock_socket = mock.MagicMock()

# Generated at 2022-06-23 01:36:59.345808
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()


# Generated at 2022-06-23 01:37:07.761502
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test method PlatformFactCollector.collect"""
    # Patch module_utils.facts.utils.get_file_content
    monkeypatch.setattr(utils, 'get_file_content', lambda x: "test-machine-id")

    # Patch platform module
    monkeypatch.setattr(platform, "system", lambda: "Linux")
    monkeypatch.setattr(platform, "release", lambda: "4.4.0-31-generic")
    monkeypatch.setattr(platform, "version", lambda: "#50-Ubuntu SMP Wed Jul 13 00:07:12 UTC 2016")
    monkeypatch.setattr(platform, "machine", lambda: "x86_64")
    monkeypatch.setattr(platform, "python_version", lambda: "2.7.12")

# Generated at 2022-06-23 01:37:13.909762
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    _platform_fact_collector = PlatformFactCollector()

    assert _platform_fact_collector.name == 'platform'
    assert _platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-23 01:37:24.735627
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'architecture',
                               'python_version'])

# Generated at 2022-06-23 01:37:33.568419
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys

    # Create a dummy module for testing.
    class DummyModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda *_, **_kwargs: sys.exit()
            self.fail_json = lambda *_, **_kwargs: sys.exit(1)

        def get_bin_path(self, *_):
            return None

        def run_command(self, *_):
            return (0, '', '')

    platform_facts = PlatformFactCollector(DummyModule()).collect()
    assert "kernel" in platform_facts
    assert "system" in platform_facts
    assert "machine" in platform_facts
    assert "architecture" in platform_facts
    assert "python_version" in platform_facts

# Generated at 2022-06-23 01:37:36.208155
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector is not None

# Generated at 2022-06-23 01:37:47.227072
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # mock module
    module = type('AnsibleModule', (object,), {'get_bin_path': lambda s, p: ''})

    # mock platform.machine() function
    old_platform_machine = platform.machine

    # mock platform.python_version() function
    old_platform_python_version = platform.python_version

    # mock platform.system() function
    old_platform_system = platform.system

    # mock platform.release() function
    old_platform_release = platform.release

    # mock platform.version() function
    old_platform_version = platform.version

    # mock platform.node() function
    old_platform_node = platform.node

    # mock platform.architecture() function
    old_platform_architecture = platform.architecture

    # mock platform.uname() function
    old

# Generated at 2022-06-23 01:37:49.212032
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:37:57.075229
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestModule:
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
            self.get_bin_path = lambda x: x

    platform_facts = PlatformFactCollector().collect(TestModule())

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts

# Generated at 2022-06-23 01:38:05.776415
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert isinstance(platform_facts, dict)

    assert 'system' in platform_facts
    assert isinstance(platform_facts['system'], str)

    assert 'kernel' in platform_facts
    assert isinstance(platform_facts['kernel'], str)

    assert 'kernel_version' in platform_facts
    assert isinstance(platform_facts['kernel_version'], str)

    assert 'machine' in platform_facts
    assert isinstance(platform_facts['machine'], str)

    assert 'python_version' in platform_facts
    assert isinstance(platform_facts['python_version'], str)

    assert 'fqdn' in platform_facts
    assert isinstance(platform_facts['fqdn'], str)

    assert 'hostname' in platform_facts
   

# Generated at 2022-06-23 01:38:09.840809
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-23 01:38:18.448157
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket

    platform_collector = PlatformFactCollector()

    original_platform_system = platform.system
    original_platform_architecture = platform.architecture
    original_platform_machine = platform.machine
    original_platform_python_version = platform.python_version
    original_platform_release = platform.release
    original_platform_version = platform.version
    original_platform_node = platform.node
    original_socket_getfqdn = socket.getfqdn

    socket.getfqdn = lambda: 'foo.bar.baz'

    platform_facts = {}
    platform_facts['system'] = 'Linux'
    platform_facts['kernel'] = '3.10.0-123.el7'

# Generated at 2022-06-23 01:38:22.780851
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:38:28.465709
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:38:33.453410
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:38:39.231222
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    _platform_facts = PlatformFactCollector().collect()

    assert _platform_facts['system'].lower() in ['linux', 'darwin', 'java', 'windows']
    assert _platform_facts['kernel'] != ''
    assert _platform_facts['kernel_version'] != ''
    assert _platform_facts['machine'] != ''
    assert _platform_facts['python_version'] != ''
    assert _platform_facts['userspace_bits'] in ['64', '32']

# Generated at 2022-06-23 01:38:41.616414
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Initializing the class object
    pfc = PlatformFactCollector()

    # Calling the method collect
    collected_facts = {}
    pfc.collect(collected_facts=collected_facts)

    # Assertion for collect method
    assert collected_facts is not None

# Generated at 2022-06-23 01:38:42.876384
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'


# Generated at 2022-06-23 01:38:53.601531
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def test_ansible_module(ansible_module):
        return ansible_module

    def test_ansible_module_run_command(command):
        return 0, command, ""


# Generated at 2022-06-23 01:38:59.557796
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"
    assert p._fact_ids == set([u'system',
                               u'kernel',
                               u'kernel_version',
                               u'machine',
                               u'python_version',
                               u'architecture',
                               u'machine_id'])


# Generated at 2022-06-23 01:39:03.197009
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    PlatformFactCollector._module = None
    PlatformFactCollector._collect_from_files = lambda x: None
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:39:12.245368
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test PlatformFactCollector._collect_platform_facts"""

    def _get_fake_platform(system='Linux', python_version='2.7.10',
                           machine='x86_64', release='3.10.0-327.36.3.el7.x86_64',
                           version='#1 SMP Thu Nov 24 17:19:59 UTC 2016'):
        """Create a fake 'platform' instance"""
        class Fake_Platform(object):
            """Mock class for platform"""
            @staticmethod
            def system():
                """Mock method for system()"""
                return system
            @staticmethod
            def release():
                """Mock method for release()"""
                return release
            @staticmethod
            def version():
                """Mock method for version()"""
                return version

# Generated at 2022-06-23 01:39:23.122345
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import json
    """
    Test the PlatformFactCollector
    """

    import platform
    import socket
    import re

    # Get test data
    data = PlatformFactCollector.collect()

    # Test system
    system = platform.system()
    assert system == data['system']

    # Test kernel
    kernel = platform.release()
    assert kernel == data['kernel']

    # Test kernel version
    kernel_version = platform.version()
    assert kernel_version == data['kernel_version']

    # Test machine
    machine = platform.machine()
    assert machine == data['machine']

    # Test python version
    python_version = platform.python_version()
    assert python_version == data['python_version']

    # Test fully qualified domain name
    fqdn = socket.getfqdn()
    assert fqdn

# Generated at 2022-06-23 01:39:27.996022
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

if __name__ == "__main__":
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:39:39.938047
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

    import platform
    # Call collect method of PlatformFactCollector with an empty dictionary
    # as the first argument.
    platform_facts = obj.collect(collected_facts={})
    platform_facts_keys = set(platform_facts.keys())

    assert platform_facts_keys == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture'])
