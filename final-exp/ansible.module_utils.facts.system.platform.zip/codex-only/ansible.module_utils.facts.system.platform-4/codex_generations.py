

# Generated at 2022-06-23 01:29:36.835574
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    result = PlatformFactCollector().collect()
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
    assert result['hostname'] == platform.node().split('.')[0]
    assert result['nodename'] == platform.node()
    assert result['userspace_bits'] in ('32','64')
    assert result['architecture'] == platform_facts['machine']

# Generated at 2022-06-23 01:29:38.766889
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == \
        set(['system', 'kernel', 'kernel_version', 'machine', 'python_version',
             'architecture', 'machine_id'])


# Generated at 2022-06-23 01:29:50.166713
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    pc = PlatformFactCollector()
    ansible_collected_facts = pc.collect()

# Generated at 2022-06-23 01:29:54.929522
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:29:58.969653
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    os_facts = PlatformFactCollector()
    ansible_facts = {}
    platform_facts = os_facts.collect(ansible_facts)

    assert len(platform_facts.keys()) > 0, "platform facts failed to collect"

# Generated at 2022-06-23 01:30:00.387555
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.collect()

# Generated at 2022-06-23 01:30:02.631954
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector()
    # test if platform_facts.collect() is dict
    assert isinstance(platform_facts.collect(), dict)


# Generated at 2022-06-23 01:30:08.648057
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])


# Generated at 2022-06-23 01:30:10.644248
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # until we have something specific, just test for not falling over
    PlatformFactCollector().collect()

# Generated at 2022-06-23 01:30:20.612647
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform

    platform_facts = {'machine': platform.machine(),
                      'machine_id': '',
                      'architecture': platform.machine(),
                      'system': platform.system(),
                      'kernel_version': platform.version(),
                      'kernel': platform.release(),
                      'python_version': platform.python_version(),
                      'hostname': platform.node().split('.')[0],
                      'fqdn': socket.getfqdn(),
                      'nodename': platform.node()}

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split(".")[1:])

    if platform.machine() == 'x86_64':
        platform_facts['architecture'] = 'x86_64'
        platform_facts['userspace_bits'] = '64'
       

# Generated at 2022-06-23 01:30:29.596339
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instantiate the PlatformFactCollector class
    pfc = PlatformFactCollector()

    # Dict containing the expected results for the given platform

# Generated at 2022-06-23 01:30:38.210874
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import sys
    import platform

    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.platform.tests.platform_test_data import PLATFORM_TEST_DATA

    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.run_command_args = []
            self.run_command_kwargs = []

        def run_command(self, *args, **kwargs):
            self.run_command_args.append(args)
            self.run_command_kwargs.append(kwargs)

        def get_bin_path(self, *args, **kwargs):
            return None


# Generated at 2022-06-23 01:30:51.838902
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import mock

    module_get_bin_path_mock = mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.get_bin_path',
                                          return_value="/bin/echo")
    module_run_command_mock = mock.patch('ansible.module_utils.facts.collector.os.path.isfile', return_value=True)
    module_run_command_mock = mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.run_command')
    module_run_command_mock.return_value = (0, "alice\n", "")


# Generated at 2022-06-23 01:30:55.255514
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    for fact in platform_facts._fact_ids:
        assert 'platform.%s' % fact in platform_facts.collect()

# Generated at 2022-06-23 01:31:05.546031
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()

    import sys
    import platform
    import socket

    class FakeModule(object):
        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd):
            class FakeResult(object):
                def __init__(self, rc, stdout, stderr):
                    self.rc = rc
                    self.stdout = stdout
                    self.stderr = stderr

            return FakeResult(0, "mock-data", None)

    class FakeSocket(object):
        @classmethod
        def getfqdn(self):
            return "mock-fqdn"

    sys.modules['ansible.module_utils.facts.collector.platform'] = FakePlatform()
    sys.modules['socket'] = FakeSocket()
    sys

# Generated at 2022-06-23 01:31:16.813157
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'getconf':
                return 'test_getconf_bin'
            elif name == 'bootinfo':
                return 'test_bootinfo_bin'
            else:
                return None

        def run_command(self, args):
            if args == ['test_getconf_bin', 'MACHINE_ARCHITECTURE']:
                return (0, 'powerpc\n', '')
            elif args == ['test_bootinfo_bin', '-p']:
                return (0, 'powerpc\n', '')

    class MyPlatform:
        def machine(self):
            return 'powerpc'



# Generated at 2022-06-23 01:31:19.254974
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert set(PlatformFactCollector._fact_ids).issubset(set(BaseFactCollector._fact_ids))

# Generated at 2022-06-23 01:31:23.332996
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj_platform = PlatformFactCollector()
    assert obj_platform.name == "platform"
    assert obj_platform._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-23 01:31:33.052886
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Stub class to control the side effects of calls to platform.system, platform.release etc. so that the test
    # is not affected by the actual platform on which it is being run.
    class FakePlatform:
        @staticmethod
        def system():
            return "Linux"
        @staticmethod
        def release():
            return "fake_kernel"
        @staticmethod
        def version():
            return "fake_kernel_version"
        @staticmethod
        def machine():
            return "x86_64"
        @staticmethod
        def python_version():
            return "3.4.3"
        @staticmethod
        def node():
            return "fakehost.fakedomain.com"

    # Stub class to control the side effects of calls to socket.getfqdn so that the test is not affected by the actual
    #

# Generated at 2022-06-23 01:31:33.726177
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:31:43.632739
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactCollector

    # for now, just a smoke test
    PlatformFactCollector().collect()

    # test the resolver's ability to preferentially resolve the correct class
    class MockPlatformFactCollector(PlatformFactCollector):
        name = 'platform'

    class Mock1FactCollector(BaseFactCollector):
        _fact_ids = set(['system'])

    class Mock2FactCollector(BaseFactCollector):
        _fact_ids = set(['kernel'])

    fact_collector = ModuleFactCollector()
    fact_collector._fact_collectors = (MockPlatformFactCollector(),
                                       Mock1FactCollector(),
                                       Mock2FactCollector())
    for fact, value in PlatformFactCollector().collect().iteritems():
        assert fact_collect

# Generated at 2022-06-23 01:31:49.156526
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    # We should not have anything in our list of fact collectors yet
    assert obj.name == 'platform'
    assert obj._fact_class_name == 'PlatformFactCollector'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])



# Generated at 2022-06-23 01:31:53.911586
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a new instance of PlatformFactCollector
    PFC = PlatformFactCollector()
    # Set test_facts equal to the return value of collect()
    test_facts = PFC.collect()
    # Check that test_facts is a dict
    assert isinstance(test_facts, dict)
    # Check if test_facts is not empty
    assert test_facts != {}

# Generated at 2022-06-23 01:31:58.153096
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import fact_collector

    # Make sure we can get the facts for this collector
    for fact_collector_cls in fact_collector.get_collectors():
        if fact_collector_cls.name == "platform":
            assert fact_collector_cls.collect()

# Generated at 2022-06-23 01:32:02.522650
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:32:09.875936
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    # Import required modules
    import os
    import platform

    # Construct an instance of FactsCollector
    facts_collector = FactsCollector()

    # Add a PlatformFactCollector instance to facts_collector
    platform_fact_collector = PlatformFactCollector()
    facts_collector.add_collector(platform_fact_collector)

    # Populating the module
    module = type('', (), {})()
    module.get_bin_path = lambda path: None
    module.run_command = lambda command, use_unsafe_shell=False: (0, os.uname()[4] + '\n', '')
    module.params = type('', (), {})()

    # Invoking the method collect of PlatformFactCollector
    results

# Generated at 2022-06-23 01:32:13.767390
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Test PlatformFactCollector"""
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert isinstance(platform_fact_collector.name, str)
    assert isinstance(platform_fact_collector._fact_ids, set)

# Generated at 2022-06-23 01:32:15.901476
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:32:25.944762
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule:
        def get_bin_path(self):
            return "bin/path"

        def run_command(self, command):
            return 0, "", ""

    class MockFactCollector:
        def __init__(self):
            self.data = {
                "kernel": "3.16.0-4-amd64",
                "kernel_version": "#1 SMP Debian 3.16.43-2 (2017-04-30)",
                "machine": "x86_64",
                "architecture": "x86_64",
                "userspace_architecture": "x86_64",
                "system": "Linux",
                "python_version": "2.7.13"
            }

        def get_kernel_version(self):
            return self.data["kernel_version"]

       

# Generated at 2022-06-23 01:32:27.930318
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector().collect()

# Generated at 2022-06-23 01:32:37.163957
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = {}
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]

    platform_facts['userspace_bits'] = arch_bits.replace('bit', '')
   

# Generated at 2022-06-23 01:32:42.588533
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:32:44.682770
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert "system" in platform_facts

# Test collect method for AIX

# Generated at 2022-06-23 01:32:45.682037
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:32:46.654461
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:32:52.758135
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == "platform"
    assert "system" in fact_collector._fact_ids
    assert "kernel" in fact_collector._fact_ids
    assert "kernel_version" in fact_collector._fact_ids
    assert "machine" in fact_collector._fact_ids
    assert "python_version" in fact_collector._fact_ids
    assert "architecture" in fact_collector._fact_ids
    assert "machine_id" in fact_collector._fact_ids

# Generated at 2022-06-23 01:32:54.291374
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert isinstance(collector, PlatformFactCollector)

# Generated at 2022-06-23 01:33:00.075743
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set([
                                                   'system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-23 01:33:10.808500
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts.get('system') == platform.system()
    assert platform_facts.get('kernel') == platform.release()
    assert platform_facts.get('kernel_version') == platform.version()
    assert platform_facts.get('machine') == platform.machine()
    assert platform_facts.get('python_version') == platform.python_version()
    assert platform_facts.get('fqdn') == socket.getfqdn()
    assert platform_facts.get('hostname') == platform.node().split('.')[0]
    assert platform_facts.get('nodename') == platform.node()
    assert platform_facts.get('domain') == '.'.join(platform_facts['fqdn'].split('.')[1:])

# Generated at 2022-06-23 01:33:18.573619
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == {'system',
                                        'kernel',
                                        'kernel_version',
                                        'machine',
                                        'python_version',
                                        'architecture',
                                        'machine_id'}


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:33:19.665421
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    p = PlatformFactCollector()
    p.collect()

# Generated at 2022-06-23 01:33:22.748683
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    This is a unit test for the method collect of class PlatformFactCollector
    """
    fact_collector = PlatformFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:33:24.063962
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    plat = PlatformFactCollector()
    print(plat.collect())

# Generated at 2022-06-23 01:33:32.424045
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    results = collector.collect()

    # Check we only get the facts we're expecting
    fact_ids = {'architecture', 'domain', 'fqdn', 'hostname', 'kernel', 'kernel_version', 'machine', 'machine_id',
                'nodename', 'python_version', 'system', 'userspace_architecture', 'userspace_bits'}
    assert set(results.keys()) == fact_ids

    assert results['system'] == platform.system()
    assert results['kernel'] == platform.release()
    assert results['kernel_version'] == platform.version()
    assert results['machine'] == platform.machine()
    assert results['python_version'] == platform.python_version()

    assert results['fqdn'] == socket.getfqdn()

# Generated at 2022-06-23 01:33:35.486328
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = False
    collected_facts = {'system': 'AIX'}
    p = PlatformFactCollector()
    p.collect(module, collected_facts)

# Generated at 2022-06-23 01:33:36.915262
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:33:39.131603
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert set(platform_collector.collect()) == set(platform_collector._fact_ids)

# Generated at 2022-06-23 01:33:47.624266
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_ob = PlatformFactCollector()

    assert platform_ob.name == "platform"
    assert 'system' in platform_ob._fact_ids
    assert 'kernel' in platform_ob._fact_ids
    assert 'kernel_version' in platform_ob._fact_ids
    assert "machine" in platform_ob._fact_ids
    assert "python_version" in platform_ob._fact_ids
    assert "architecture" in platform_ob._fact_ids
    assert "machine_id" in platform_ob._fact_ids

# Generated at 2022-06-23 01:33:48.734909
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'

# Generated at 2022-06-23 01:33:54.163817
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])


# Generated at 2022-06-23 01:34:05.471308
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = FakeModule(argument_spec={})
    platform_facts = PlatformFactCollector().collect(module=module)

    assert platform_facts["system"] == "Linux"
    assert platform_facts["kernel"] == "2.6.32-504.el6.x86_64"
    assert platform_facts["kernel_version"] == "#1 SMP Wed Oct 15 04:27:16 UTC 2014"
    assert platform_facts["machine"] == "x86_64"
    assert platform_facts["python_version"] == "2.6.6"
    assert platform_facts["fqdn"] == "gw.example.com"
    assert platform_facts["hostname"] == "gw"
    assert platform_facts["nodename"] == "gw.example.com"

# Generated at 2022-06-23 01:34:07.997074
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert isinstance(obj._fact_ids, set)

# Generated at 2022-06-23 01:34:18.669364
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    platform_facts_dict = PlatformFactCollector().collect()

    # check python version
    assert platform_facts_dict['python_version'] == platform.python_version()

    # check system
    assert platform_facts_dict['system'] == platform.system()
    # check kernel
    assert platform_facts_dict['kernel'] == platform.release()
    # check kernel_version
    assert platform_facts_dict['kernel_version'] == platform.version()
    # check machine
    assert platform_facts_dict['machine'] == platform.machine()
    # check fqdn
    assert platform_facts_dict['fqdn'] == socket.getfqdn()
    # check hostname
    assert platform_facts_dict['hostname'] == platform.node().split('.')[0]
    # check nodename
    assert platform_facts_dict

# Generated at 2022-06-23 01:34:20.521815
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector_instance = PlatformFactCollector()
    PlatformFactCollector_instance.collect()


# Generated at 2022-06-23 01:34:27.616827
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:34:29.579805
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert len(p._fact_ids) == 8

# Generated at 2022-06-23 01:34:34.978454
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-23 01:34:40.960843
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform = PlatformFactCollector()
    facts = test_platform.collect()
    assert len(facts) > 1
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'architecture' in facts
    assert 'python_version' in facts

# Generated at 2022-06-23 01:34:45.608261
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )

    platform_instance = PlatformFactCollector()
    res = platform_instance.collect(module=module)
   
    # FIXME: Add unit tests
    assert False

# Generated at 2022-06-23 01:34:54.262803
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert isinstance(platform_fact_collector._fact_ids, set)
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids



# Generated at 2022-06-23 01:34:59.825635
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()

    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])


# Generated at 2022-06-23 01:35:05.634531
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert sorted(pf._fact_ids) == sorted(['system',
                                           'kernel',
                                           'kernel_version',
                                           'machine',
                                           'python_version',
                                           'architecture',
                                           'machine_id'])

# Generated at 2022-06-23 01:35:13.056585
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import re
    from ansible.module_utils._text import to_bytes

    pl = PlatformFactCollector()
    platf = pl.collect()

    platf_expected_results = {'system': platform.system(),
                              'kernel': platform.release(),
                              'kernel_version': platform.version(),
                              'machine': platform.machine(),
                              'python_version': platform.python_version(),
                              'fqdn': socket.getfqdn(),
                              'hostname': platform.node().split('.')[0],
                              'nodename': platform.node(),
                              'domain': '.'.join(platform.node().split('.')[1:])
                             }

    # A user space architecture cannot be same as architecture
    # This can happen when Debian 7 is

# Generated at 2022-06-23 01:35:16.717317
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert 'kernel' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'fqdn' not in pfc._fact_ids

# Generated at 2022-06-23 01:35:25.925624
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    import socket
    import lib_platform_facts
    platform_facts = lib_platform_facts.PlatformFactCollector()

    collected_facts = {}
    platform_facts.collect(collected_facts=collected_facts)

    assert(collected_facts['system'] == platform.system())
    assert(collected_facts['kernel'] == platform.release())
    assert(collected_facts['kernel_version'] == platform.version())
    assert(collected_facts['machine'] == platform.machine())
    assert(collected_facts['python_version'] == platform.python_version())

    assert(collected_facts['fqdn'] == socket.getfqdn())
    assert(collected_facts['hostname'] == platform.node().split('.')[0])

# Generated at 2022-06-23 01:35:35.703141
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    class PlatformFactCollector():
    '''
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert "_fact_ids" in dir(x)
    assert x._fact_ids == {"system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"}
    assert x.kernel_version is None
    assert x.machine is None
    assert x.python_version is None
    assert x.fqdn is None
    assert x.hostname is None
    assert x.nodename is None
    assert x.domain is None
    assert x.userspace_bits is None
    assert x.machine_id is None
    assert hasattr(x, "collect")
    assert x.system is None
    assert x.kernel is None


# Generated at 2022-06-23 01:35:41.707458
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector()
    assert 'system' in platform.collect()
    assert 'kernel' in platform.collect()
    assert 'kernel_version' in platform.collect()
    assert 'machine' in platform.collect()
    assert 'python_version' in platform.collect()
    assert 'architecture' in platform.collect()

# Generated at 2022-06-23 01:35:42.328674
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:35:48.115415
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert 'fqdn' in pfc._fact_ids
    assert 'system' in pfc._fact_ids
    assert 'nodename' in pfc._fact_ids
    assert 'domain' in pfc._fact_ids
    assert 'userspace_bits' in pfc._fact_ids
    assert 'userspace_architecture' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids

# Generated at 2022-06-23 01:35:56.001122
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import json
    import platform

    platform_facts = {
        "kernel": platform.release(),
        "kernel_version": platform.version(),
        "machine": platform.machine(),
        "machine_id": None,
        "python_version": platform.python_version(),
        "nodename": platform.node(),
        "domain": platform.node().split('.')[1:],
        "architecture": platform.machine(),
        "userspace_bits": platform.architecture()[0].replace('bit', ''),
        "hostname": platform.node().split('.')[0],
        "system": platform.system(),
        "fqdn": platform.node()
    }
    platform_facts_json = json.dumps(platform_facts, sort_keys=True, indent=4)
    assert platform_facts_

# Generated at 2022-06-23 01:36:07.719718
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = {
        'architecture': 'x86_64',
        'domain': 'example.com',
        'fqdn': 'localhost.example.com',
        'hostname': 'localhost',
        'kernel': '2.6.32-504.16.2.el6.x86_64',
        'kernel_version': '#1 SMP Wed Apr 22 06:48:29 UTC 2015',
        'machine': 'x86_64',
        'nodename': 'localhost.example.com',
        'python_version': '2.7.5',
        'system': 'Linux',
        'userspace_architecture': 'x86_64',
        'userspace_bits': '64',
    }
    pfc = PlatformFactCollector()
    facts = pfc.collect()

# Generated at 2022-06-23 01:36:16.799933
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import CollectedFacts


# Generated at 2022-06-23 01:36:22.357660
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:36:23.032669
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:36:28.666619
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Initialize class
    obj = PlatformFactCollector([])

    # Check return value
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version',
                                 'architecture', 'machine_id'])
    assert obj.collect()

# Generated at 2022-06-23 01:36:35.512008
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert 'system' in platform_fact_collector.collect()
    assert 'kernel' in platform_fact_collector.collect()
    assert 'kernel_version' in platform_fact_collector.collect()
    assert 'machine' in platform_fact_collector.collect()
    assert 'python_version' in platform_fact_collector.collect()
    assert 'architecture' in platform_fact_collector.collect()
    assert 'machine_id' in platform_fact_collector.collect()
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-23 01:36:39.822464
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:36:49.000354
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect() == {'system': platform.system(), 'kernel': platform.release(), 'kernel_version': platform.version(), 'machine': platform.machine(), 'python_version': platform.python_version(), 'fqdn': socket.getfqdn(), 'hostname': platform.node().split('.')[0], 'nodename': platform.node(), 'domain': '.'.join(socket.getfqdn().split('.')[1:]), 'userspace_bits': platform.architecture()[0].replace('bit', ''), 'architecture': platform.machine(), 'userspace_architecture': platform.architecture()[0].replace('bit', '')}

# Generated at 2022-06-23 01:36:54.660778
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert sorted(x._fact_ids) == sorted(['system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id'])


# Generated at 2022-06-23 01:36:56.599903
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'

# Generated at 2022-06-23 01:36:58.514355
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collection = PlatformFactCollector()
    assert collection.collect()['system'] == platform.system()

# Generated at 2022-06-23 01:37:07.221282
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()

    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]


# Generated at 2022-06-23 01:37:14.290969
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Inject a platform.system() call return value.
    def _platform_system_side_effect(*_):
        return 'Linux'
    import platform
    platform_system_mock = platform.system
    # Use python module mock to patch the platform.system() call
    import mock
    platform.system = mock.Mock(side_effect=_platform_system_side_effect)
    # Collect platform facts
    platform_instance = PlatformFactCollector()
    facts = platform_instance.collect()
    # Make asserts on the facts
    assert 'system' in facts
    assert facts['system'] == 'Linux'
    # Cleanup
    platform.system = platform_system_mock

# Generated at 2022-06-23 01:37:19.422267
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:37:27.144508
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    result = collector.collect()
    assert "system" in result
    assert "kernel" in result
    assert "kernel_version" in result
    assert "machine" in result
    assert "python_version" in result
    assert "fqdn" in result
    assert "hostname" in result
    assert "nodename" in result
    assert "domain" in result
    assert "userspace_bits" in result
    assert "architecture" in result
    assert "userspace_architecture" in result
    assert "machine_id" in result

# Generated at 2022-06-23 01:37:35.199415
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def mock_platform_architecture(executable=True, bits=''):
        """Mocks the platform.architecture() return value.

        :param executable: whether the architecture is executable
        :param bits: what bits the architecture is
        :return: a tuple of the return values
        """
        return bits, executable

    def mock_platform_uname(uname='OpenBSD'):
        if uname == 'OpenBSD':
            return ('OpenBSD', '', '', '', 'amd64', '')

    monkeypatch.setattr(platform, 'architecture', mock_platform_architecture)
    monkeypatch.setattr(platform, 'uname', mock_platform_uname)
    monkeypatch.setattr(platform, 'uname', mock_platform_uname)
    facts = PlatformFactCollector().collect()


# Generated at 2022-06-23 01:37:39.051109
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = ansible_collections.ansible.community.plugins.module_utils.facts.collectors.platform.PlatformFactCollector
    PlatformFactCollector_collect_function = ansible_collections.ansible.community.plugins.module_utils.facts.collectors.platform.PlatformFactCollector._collect
    ansible_module = DummyAnsibleModule()
    PlatformFactCollector_collect_function(ansible_module, PlatformFactCollector())


# Generated at 2022-06-23 01:37:49.001757
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test that we can get the same values as by calling the legacy fact
    module plugin.
    """

    import imp
    import os
    import tempfile

    # imp.load_source is deprecated in Python 3
    if imp.new_module:
        load_source = imp.new_module
    else:
        load_source = imp.load_source
    facts_platform_legacy = load_source('ansible.module_utils.facts.platform_legacy', os.path.join(
        tempfile.gettempdir(),
        'ansible_facts_platform_legacy.py',
    ))

    # Call collect method of PlatformFactCollector to get a dict
    platform_facts = PlatformFactCollector().collect()

    # Call parse_facts of the old (and deprecated) plugin
    # and compare results
    old_result

# Generated at 2022-06-23 01:38:00.039809
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MockModule()

    # mock platform.system()
    def _platform_system(self):
        return 'Linux'
    platform.system = _platform_system

    # mock platform.release()
    def _platform_release(self):
        return '2.6.32-431.11.2.el6.x86_64'
    platform.release = _platform_release

    # mock platform.version()
    def _platform_version(self):
        return '#1 SMP Wed Jun 18 23:25:18 UTC 2014'
    platform.version = _platform_version

    # mock platform.machine()
    def _platform_machine(self):
        return 'x86_64'
    platform.machine = _platform_machine

    # mock platform.python_version()

# Generated at 2022-06-23 01:38:05.367234
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids

# Generated at 2022-06-23 01:38:13.575027
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    pfc_dict = pfc.collect()
    assert 'system' in pfc_dict
    assert 'kernel' in pfc_dict
    assert 'kernel_version' in pfc_dict
    assert 'machine' in pfc_dict
    assert 'python_version' in pfc_dict
    assert 'architecture' in pfc_dict
    assert 'machine_id' in pfc_dict
    assert pfc_dict['system']
    assert pfc_dict['kernel']
    assert pfc_dict['kernel_version']
    assert pfc_dict['machine']
    assert pfc_dict['python_version']

# Generated at 2022-06-23 01:38:18.618907
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    result = PlatformFactCollector()
    assert result._fact_ids == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])

# Generated at 2022-06-23 01:38:22.811074
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:38:26.581137
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'system' in x._fact_ids
    assert 'kernel_version' in x._fact_ids
    assert 'machine' in x._fact_ids

# Generated at 2022-06-23 01:38:31.804478
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    PlatformFactCollector.collect() Test
    """
    from ansible.module_utils.basic import AnsibleModule
    platform_facts_collector = PlatformFactCollector()
    module = AnsibleModule(argument_spec={})
    platform_facts = platform_facts_collector.collect(module=module)
    assert isinstance(platform_facts, dict)
    assert isinstance(platform_facts['system'], str)
    assert isinstance(platform_facts['kernel'], str)
    assert isinstance(platform_facts['kernel_version'], str)
    assert isinstance(platform_facts['machine'], str)
    assert isinstance(platform_facts['python_version'], str)
    assert isinstance(platform_facts['fqdn'], str)

# Generated at 2022-06-23 01:38:36.718945
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-23 01:38:43.580610
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Collector

    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, PlatformFactCollector)
    assert isinstance(platform_fact_collector, BaseFactCollector)


# Generated at 2022-06-23 01:38:54.150619
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collectors import PlatformFactCollector
    import platform
    import socket

    platform.system = lambda: 'AIX'
    platform.release = lambda: '1'
    platform.version = lambda: '2'
    platform.machine = lambda: '3'
    platform.python_version = lambda: '4'
    platform.node = lambda: '5'
    platform.architecture = lambda: ('6', '7')
    platform.uname = lambda: ['8'] * 10
    socket.getfqdn = lambda: '10'
    
    class Module():
        def __init__(self):
            self.run_command = lambda x: (x, None, None)
            self.get_bin_path = lambda x: x
            
    pfc = PlatformFactCollector()

# Generated at 2022-06-23 01:39:00.346641
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id']), \
                                 pfc._fact_ids

# Generated at 2022-06-23 01:39:06.948746
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact = PlatformFactCollector()
    assert isinstance(platform_fact, PlatformFactCollector), 'is not of class PlatformFactCollector'
    assert set(platform_fact._fact_ids) == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id']), '_facts_list is not set to expected value'

# Generated at 2022-06-23 01:39:10.656055
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert isinstance(pfc.name, str)
    assert isinstance(pfc._fact_ids, set)

# Generated at 2022-06-23 01:39:17.575990
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """This is to test the constructor for PlatformFactCollector class"""
    x = PlatformFactCollector()
    assert isinstance(x, PlatformFactCollector)
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-23 01:39:23.324395
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:39:30.495530
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert 'system' in PlatformFactCollector._fact_ids
    assert 'kernel' in PlatformFactCollector._fact_ids
    assert 'kernel_version' in PlatformFactCollector._fact_ids
    assert 'machine' in PlatformFactCollector._fact_ids
    assert 'python_version' in PlatformFactCollector._fact_ids
    assert 'architecture' in PlatformFactCollector._fact_ids

# Generated at 2022-06-23 01:39:35.043091
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
