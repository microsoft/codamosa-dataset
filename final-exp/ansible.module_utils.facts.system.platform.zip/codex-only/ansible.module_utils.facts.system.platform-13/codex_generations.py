

# Generated at 2022-06-23 01:29:38.614986
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Initialize platform fact collector object
    platform_fact_collector = PlatformFactCollector()

    # Collect platform facts
    platform_facts = platform_fact_collector.collect()

    # Check system fact
    assert 'system' in platform_facts
    assert isinstance(platform_facts['system'], str)
    assert platform_facts['system'] == platform.system()

    # Check kernel fact
    assert 'kernel' in platform_facts
    assert isinstance(platform_facts['kernel'], str)
    assert platform_facts['kernel'] == platform.release()

    # Check kernel_version fact
    assert 'kernel_version' in platform_facts
    assert isinstance(platform_facts['kernel_version'], str)
    assert platform_facts['kernel_version'] == platform.version()

    # Check machine fact

# Generated at 2022-06-23 01:29:40.050934
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:29:45.602440
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert sorted(pfc._fact_ids) == sorted(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:29:49.059249
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system','kernel','kernel_version','machine','python_version','architecture','machine_id'])


# Generated at 2022-06-23 01:29:50.085071
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()


# Generated at 2022-06-23 01:30:00.099277
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleManager
    from ansible.module_utils.facts import BaseFactModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import set_module_args

    class MockedModule(BaseFactModule):
        def run(self, tmp=None, task_vars=None):
            return dict(ansible_facts=self.collector.collect(self, self._shared_memory_settings))

    # Mock object
    class MockedAnsibleModule(object):
        def __init__(self):
            self.params = {}

        # Mock object
        class ReturnValue(object):
            def __init__(self):
                self.function_name

# Generated at 2022-06-23 01:30:11.638101
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    # Testing default behavior (bypassing the cache)
    pfc = PlatformFactCollector()
    platform_facts = pfc.collect()
    # The default behavior is to collect all data
    assert set(platform_facts) == set(pfc._fact_ids)
    # Collected data is of the right type
    assert isinstance(platform_facts['system'], str)
    assert isinstance(platform_facts['kernel'], str)
    assert isinstance(platform_facts['kernel_version'], str)
    assert isinstance(platform_facts['machine'], str)
    assert isinstance(platform_facts['python_version'], str)
    assert isinstance(platform_facts['architecture'], str)
    # Collected data is also consistent with platform
    assert platform_facts['system'] == platform.system()

# Generated at 2022-06-23 01:30:12.623207
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    _ = PlatformFactCollector()


# Generated at 2022-06-23 01:30:13.375436
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()

# Generated at 2022-06-23 01:30:18.505834
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:30:23.837551
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_collector = PlatformFactCollector()
    facts = test_collector.collect()
    assert 'system' in facts
    assert facts.get('system') == 'Linux'
    assert 'kernel' in facts
    assert facts.get('fqdn') == socket.getfqdn()
    assert 'architecture' in facts
    assert facts.get('architecture') == 'x86_64'

# Generated at 2022-06-23 01:30:24.844615
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-23 01:30:28.904098
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert set(platform_fact_collector._fact_ids) == set(['system',
                                                          'kernel',
                                                          'kernel_version',
                                                          'machine',
                                                          'python_version',
                                                          'architecture',
                                                          'machine_id'])


# Generated at 2022-06-23 01:30:32.668791
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])


# Generated at 2022-06-23 01:30:34.631103
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector()
    result = platform.collect()
    print(result)

# Generated at 2022-06-23 01:30:39.395715
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfcollector = PlatformFactCollector()

    assert pfcollector.name == 'platform'
    assert pfcollector._fact_ids == set(['system',
                                         'kernel',
                                         'kernel_version',
                                         'machine',
                                         'python_version',
                                         'architecture',
                                         'machine_id'])


# Generated at 2022-06-23 01:30:52.168003
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    import platform

    # We mock the platform.system() method to return Linux
    # so that the PlatformFactCollector._is_solaris() returns False
    platform.system = lambda: 'Linux'

    platform_collector = PlatformFactCollector()

    # We use a lambda function to return values for the
    # platform.uname() method
    platform.uname = lambda: ['Linux', 'foo', '3.10-3-amd64', '#1 SMP Debian 3.10.7-1', 'x86_64', 'GNU/Linux']

    # We use a lambda function to return values for the
    # platform.architecture() method
    platform.architecture = lambda: ('64bit', '')

    # We use a lambda

# Generated at 2022-06-23 01:30:53.701620
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p_obj = PlatformFactCollector()
    assert p_obj.name == 'platform'

# Generated at 2022-06-23 01:30:55.955809
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:31:02.616445
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collected_facts = {}
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

    assert p.collect(collected_facts=collected_facts)["fqdn"] == socket.getfqdn()


# Generated at 2022-06-23 01:31:05.977958
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])



# Generated at 2022-06-23 01:31:09.283906
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'machine' in x._fact_ids
    assert 'architecture' in x._fact_ids

# Generated at 2022-06-23 01:31:18.932926
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import platform
    import socket
    # Use a fake socket name to get localhost.localdomain
    # This is not found on all machines so we can't use it in
    # the general case.
    orig_getfqdn = socket.getfqdn
    socket.getfqdn = lambda: 'localhost.localdomain'
    p = PlatformFactCollector()
    f = p.collect(None)
    assert 'system' in f
    assert 'kernel' in f
    assert 'kernel_version' in f
    assert 'machine' in f
    assert 'python_version' in f
    assert 'fqdn' in f
    assert 'hostname' in f
    assert 'nodename' in f
    assert 'domain' in f
    assert 'userspace_bits' in f

# Generated at 2022-06-23 01:31:25.505675
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    facts_keys = [
      'system',
      'kernel',
      'kernel_version',
      'machine',
      'python_version',
      'architecture',
      'fqdn',
      'hostname',
      'nodename',
      'domain',
      'userspace_bits',
      'userspace_architecture'
      ]

    for key in facts_keys:
        assert key in platform_facts

# Generated at 2022-06-23 01:31:30.594236
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x=PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == { 'system',
             'kernel',
             'kernel_version',
             'machine',
             'python_version',
             'architecture',
             'machine_id'}

# Generated at 2022-06-23 01:31:33.911862
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Init class
    x = PlatformFactCollector()

    # Check instance
    assert isinstance(x, PlatformFactCollector) == True

# Generated at 2022-06-23 01:31:42.326942
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform', "FactCollector name should be platform, but got %s" % fact_collector.name
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id']), "fact_ids should be system,kernel,kernel_version,machine,python_version,architecture,machine_id, but got %s" % fact_collector._fact_ids


# Generated at 2022-06-23 01:31:43.956615
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['system'] == 'Linux'

# Generated at 2022-06-23 01:31:53.710419
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_platform = PlatformFactCollector()
    assert isinstance(test_platform._fact_ids, set)
    assert 'system' in test_platform._fact_ids
    assert 'kernel' in test_platform._fact_ids
    assert 'kernel_version' in test_platform._fact_ids
    assert 'machine' in test_platform._fact_ids
    assert 'python_version' in test_platform._fact_ids
    assert 'architecture' in test_platform._fact_ids
    assert 'machine_id' in test_platform._fact_ids
    assert 'name' in dir(test_platform)

# Generated at 2022-06-23 01:31:54.669577
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'

# Generated at 2022-06-23 01:32:02.835545
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids


# Generated at 2022-06-23 01:32:03.966430
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_collector.collect()

# Generated at 2022-06-23 01:32:12.668747
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fc = PlatformFactCollector()

    assert platform_fc.name == 'platform'
    assert isinstance(platform_fc._fact_ids, set)
    assert 'system' in platform_fc._fact_ids
    assert 'kernel' in platform_fc._fact_ids
    assert 'kernel_version' in platform_fc._fact_ids
    assert 'machine' in platform_fc._fact_ids
    assert 'python_version' in platform_fc._fact_ids
    assert 'architecture' in platform_fc._fact_ids
    assert 'machine_id' in platform_fc._fact_ids


# Generated at 2022-06-23 01:32:22.999710
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import loader

    tmp_path = loader.get_basedir() + '/test_platform_facts/tmp/'

    collector = PlatformFactCollector()

    def new_get_file_content(path):
        print("### new_get_file_content: " + path)
        return '1eb70cb6-c903-46ae-8a70-fc88a64c59d3'

    collector.get_file_content = new_get_file_content

    def new_get_bin_path(name):
        print("### new_get_bin_path: " + name)
        if (name == 'getconf'):
            return tmp_path + 'bin/getconf'

# Generated at 2022-06-23 01:32:31.188659
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test collecting platform facts.

    This test collects platform facts by calling the method collect from the
    class PlatformFactCollector.

    """

    # Create a mock module
    from ansible.module_utils.facts import ModuleMock
    module = ModuleMock()

    # Collect platform facts
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(module)

    # Make assertions
    assert platform_fact_collector.name == 'platform'
    assert isinstance(platform_facts, dict)
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts

# Generated at 2022-06-23 01:32:42.183305
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Test with linux machine of type x86_64
    machine=platform.machine()
    platform_system=platform.system()
    machine_id = get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")
    if machine_id:
        machine_id = machine_id.splitlines()[0]


# Generated at 2022-06-23 01:32:51.338655
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import platform
    import sys

    if sys.version_info[:2] == (2, 6):
        module = basic.AnsibleModule(argument_spec={})
        module_return_value = dict(ansible_facts=dict(platform=dict()))
    else:
        module = basic.AnsibleModule(argument_spec=dict())
        module_return_value = dict(ansible_facts=dict(platform=dict()))


# Generated at 2022-06-23 01:32:56.737269
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:33:00.024675
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instanciate PlatformFactCollector
    platform_object = PlatformFactCollector()

    # Test if class PlatformFactCollector has method collect
    assert callable(platform_object.collect)


# Generated at 2022-06-23 01:33:04.300268
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:33:11.667672
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts == {
        'architecture': platform.machine(),
        'domain': socket.getfqdn().split('.', 1)[1],
        'fqdn': socket.getfqdn(),
        'hostname': platform.node().split('.')[0],
        'kernel': platform.release(),
        'kernel_version': platform.version(),
        'machine': platform.machine(),
        'nodename': platform.node(),
        'python_version': platform.python_version(),
        'system': platform.system()
    }

# Generated at 2022-06-23 01:33:22.068052
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test PlatformFactCollector.collect.

    This is done by checking that values set by platform.system()
    and platform.release() are present for the keys 'system' and 'kernel'
    """
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    platform_collector = PlatformFactCollector()
    # Reset the registered fact collectors
    Collector._fact_collectors = {}
    Collector._collectors_loaded = False
    Collector.register(platform_collector)
    facts_dict = Collector.collect(warnings=[])

    assert 'system' in facts_dict
    assert 'kernel' in facts_dict
    # Assert that the values obtained via platform.system() and platform.release()
    # are present in the facts_dict
   

# Generated at 2022-06-23 01:33:24.136906
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector.collect()


# Generated at 2022-06-23 01:33:30.622361
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert "system" in x._fact_ids
    assert "kernel" in x._fact_ids
    assert "kernel_version" in x._fact_ids
    assert "machine" in x._fact_ids
    assert "python_version" in x._fact_ids
    assert "architecture" in x._fact_ids
    assert "machine_id" in x._fact_ids


# Generated at 2022-06-23 01:33:34.823835
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == "platform"
    assert obj._fact_ids == set(["system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"])

# Generated at 2022-06-23 01:33:44.696247
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PLATFORM_FACTS = dict(system='Linux',
                          kernel='Linux',
                          kernel_version='Linux',
                          machine='x86_64',
                          python_version='Python 2.7.5',
                          architecture='x86_64',
                          fqdn='foo.bar.com',
                          hostname='foo',
                          nodename='foo.bar.com',
                          domain='bar.com',
                          userspace_bits='64',
                          userspace_architecture='x86_64',
                          machine_id="c8f5aa2f5c5a4a5da08e28b2a6ff12a6")

    PlatformFactCollector.collect_fn = lambda *args, **kwargs: PLATFORM_FACTS

    assert PlatformFactCollector

# Generated at 2022-06-23 01:33:48.293440
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                 'python_version', 'architecture', 'machine_id'])



# Generated at 2022-06-23 01:33:58.470420
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {
        "architecture": "x86_64",
        "fqdn": "localhost.localdomain",
        "domain": "localhost.localdomain",
        "hostname": "localhost",
        "kernel": "3.19.0-25-generic",
        "kernel_version": "#26-Ubuntu SMP Fri Jul 24 21:18:00 UTC 2015",
        "machine": "x86_64",
        "nodename": "localhost.localdomain",
        "python_version": "2.7.6",
        "system": "Linux",
        "userspace_bits": "64"
    }
    collector = PlatformFactCollector()
    facts = collector.collect()
    assert facts["architecture"] == platform_facts["architecture"]

# Generated at 2022-06-23 01:34:03.685247
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    pfc = PlatformFactCollector(module)
    pfc.collect()
    # Check if method collect executed successfully
    assert not module.fail_json.called

# Unit test class for testing with the abstract class
# BaseFactCollectorTest(unittest.TestCase):

# Generated at 2022-06-23 01:34:08.180326
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert type(pfc) is PlatformFactCollector
    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids

# Generated at 2022-06-23 01:34:13.299778
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:34:17.592327
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-23 01:34:20.087670
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)


# Generated at 2022-06-23 01:34:24.309155
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collect_obj = PlatformFactCollector()
    assert collect_obj.name == 'platform'
    assert collect_obj._fact_ids == set(['system',
                                         'kernel',
                                         'kernel_version',
                                         'machine',
                                         'python_version',
                                         'architecture',
                                         'machine_id'])


# Generated at 2022-06-23 01:34:26.813717
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    Unit tests for PlatformFactCollector.
    '''
    PlatformFactCollector()

# Generated at 2022-06-23 01:34:27.975324
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

# Generated at 2022-06-23 01:34:37.099966
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()

    system_facts = fact_collector.collect()
    assert system_facts is not None
    assert system_facts['system'] is not None
    assert system_facts['kernel'] is not None
    assert system_facts['kernel_version'] is not None
    assert system_facts['machine'] is not None
    assert system_facts['python_version'] is not None
    assert system_facts['architecture'] is not None
    assert system_facts['fqdn'] is not None
    assert system_facts['hostname'] is not None
    assert system_facts['nodename'] is not None

# Generated at 2022-06-23 01:34:42.035546
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == {'machine_id', 'userspace_architecture', 'architecture', 'nodename', 'system', 'kernel', 'kernel_version', 'fqdn', 'domain', 'python_version', 'userspace_bits', 'hostname', 'machine'}

# Generated at 2022-06-23 01:34:48.937802
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Mock parameters
    module = MagicMock()
    collected_facts = MagicMock()

    # Create instance
    instance = PlatformFactCollector()

    # Unit test
    assert [set(['architecture', 'fqdn', 'kernel', 'machine', 'python_version', 'system']),
     {'architecture': 'x86_64', 'fqdn': 'localhost.localdomain', 'kernel': '3.10.0-957.1.3.el7.x86_64', 'machine': 'x86_64', 'python_version': '2.7.5', 'system': 'Linux'}] == instance.collect(module, collected_facts)

# Generated at 2022-06-23 01:34:59.587844
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    PlatformFactCollector constructor should set instance attribute '_fact_ids'
    to be a set of strings containing 'platform' and all the keys of
    the ansible_facts['platform'] dictionary.
    """


# Generated at 2022-06-23 01:35:07.314035
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Unit test for method collect of class PlatformFactCollector"""

    # Check the facts with current system platform
    platform_facts = PlatformFactCollector().collect()
    assert "machine" in platform_facts
    assert "system" in platform_facts
    assert "architecture" in platform_facts
    assert "python_version" in platform_facts
    assert "domain" in platform_facts
    assert "fqdn" in platform_facts
    assert "hostname" in platform_facts
    assert "kernel" in platform_facts
    assert "kernel_version" in platform_facts
    assert "machine_id" in platform_facts
    assert "nodename" in platform_facts
    assert "userspace_bits" in platform_facts

# Generated at 2022-06-23 01:35:18.590403
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test for PlatformFactCollector.collect() in case of non-existent executable
    def run_command(args):
        if args[0] == "/usr/bin/getconf":
            return (0, "", "")
        elif args[0] == "/sbin/bootinfo":
            return (0, "", "")
        elif args[0] == "bootinfo":
            return (0, "", "")
        return (-1, "", "")

    module = Mock()
    module.get_bin_path.side_effect = lambda x: x
    module.run_command.side_effect = run_command

    collector = PlatformFactCollector()
    result = collector.collect(module=module)


# Generated at 2022-06-23 01:35:26.879011
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command
    platform_collector = PlatformFactCollector()
    # set the module, so that it won't call the module author's module on collector.collect
    platform_collector.module = module
    platform_facts = platform_collector.collect()

    # test if all the facts in _fact_ids is collected
    assert set(platform_facts.keys()).issuperset(platform_collector._fact_ids)

    # test if all the facts are collected and matches the platform_facts_output
    for fact in platform_facts:
        assert platform_facts_output[fact] == platform_facts[fact]


# Generated at 2022-06-23 01:35:32.937152
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = collections.namedtuple('PlatformFactCollector', 'system kernel kernel_version machine')
    platform_facts = PlatformFactCollector(system='Linux',kernel='3.10.0-957.21.3.el7.x86_64',kernel_version='#1 SMP Fri Jun 28 16:33:28 UTC 2019',machine='x86_64')
    assert platform_facts == platform_facts


# Generated at 2022-06-23 01:35:33.777018
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().collect()

# Generated at 2022-06-23 01:35:36.637998
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None


# Generated at 2022-06-23 01:35:40.369534
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MockLinuxModule()
    pfc = PlatformFactCollector(module=module)
    test_facts = pfc.collect()
    print(test_facts)


# Generated at 2022-06-23 01:35:45.250086
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for method collect of class PlatformFactCollector
    """
    pfc = PlatformFactCollector()
    pfc_facts = pfc.collect()
    assert "system" in pfc_facts
    assert "kernel" in pfc_facts
    assert "kernel_version" in pfc_facts
    assert "machine" in pfc_facts
    assert "python_version" in pfc_facts

# Generated at 2022-06-23 01:35:46.914248
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    result = platform_collector.collect()
    assert result["system"] == platform.system()

# Generated at 2022-06-23 01:35:54.633955
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    collector = PlatformFactCollector()
    assert collector.collect()["system"] == platform.system()
    assert collector.collect()["kernel"] == platform.release()
    assert collector.collect()["kernel_version"] == platform.version()
    assert collector.collect()["machine"] == platform.machine()
    assert collector.collect()["python_version"] == platform.python_version()
    assert collector.collect()["fqdn"] == socket.getfqdn()
    assert collector.collect()["hostname"] == platform.node().split('.')[0]
    assert collector.collect()["nodename"] == platform.node()
    assert collector.collect()["domain"] == '.'.join(socket.getfqdn().split('.')[1:])

# Generated at 2022-06-23 01:36:06.916658
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """This will run tests on the collect method of PlatformFactCollector"""
    platform_collected_facts = PlatformFactCollector.collect()
    assert platform_collected_facts == {
        'system': 'Linux',
        'kernel': '4.10.0-19-generic',
        'kernel_version': '#21-Ubuntu SMP Thu Apr 6 17:04:57 UTC 2017',
        'machine': 'x86_64',
        'python_version': '2.7.12',
        'fqdn': 'ubuntu',
        'hostname': 'ubuntu',
        'nodename': 'ubuntu',
        'domain': '',
        'userspace_bits': '64',
        'architecture': 'x86_64',
        'userspace_architecture': 'x86_64',
    }

# Generated at 2022-06-23 01:36:16.066836
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import pytest
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from mock import Mock

    # Create a fake module and facts collection
    module = Mock()
    module.get_bin_path.return_value = False
    collected_facts = dict()

    # Create a PlatformFactCollector instance
    platform_facts_collector = PlatformFactCollector()

    # Collect expected facts
    expected_facts = dict()
    expected_facts['system'] = platform.system()
    expected_facts['kernel'] = platform.release()
    expected_facts['kernel_version'] = platform.version()
    expected_facts['machine'] = platform.machine()
    expected_facts['python_version'] = platform.python_version()
    expected_facts['fqdn'] = socket.getfq

# Generated at 2022-06-23 01:36:19.510168
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-23 01:36:25.839139
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()

    # Test _fact_ids and name
    print("Test '_fact_ids' and 'name'")
    print(plat._fact_ids)
    print(plat.name)

    # Test collect function returns a dictionary
    print("Test collect function ")
    print(type(plat.collect()))

if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:36:36.924663
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector

    collector = PlatformFactCollector()
    assert isinstance(collector, BaseFactCollector)
    assert isinstance(collector, FactCollector)

    # Test an actual run, but only do minimal testing of the results
    facts_dict = collector.collect()
    assert 'platform' in facts_dict
    assert facts_dict['platform']
    assert 'system' in facts_dict['platform']
    assert 'kernel' in facts_dict['platform']
    assert 'kernel_version' in facts_dict['platform']
    assert 'machine' in facts_dict['platform']
    assert 'python_version' in facts

# Generated at 2022-06-23 01:36:37.671303
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:36:38.693330
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    assert pfc.collect()

# Generated at 2022-06-23 01:36:44.245025
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-23 01:36:50.057526
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'fqdn',
                                       'hostname',
                                       'nodename',
                                       'domain'])

# Generated at 2022-06-23 01:37:01.313506
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.os import OsFactCollector

    os_fact_collector = OsFactCollector()
    platform_fact_collector = PlatformFactCollector()
    facts_collector = FactsCollector([os_fact_collector, platform_fact_collector])
    result = facts_collector.collect(module=None, collected_facts=None)
    assert 'system' in result
    assert 'kernel' in result
    assert 'kernel_version' in result


# Generated at 2022-06-23 01:37:09.294096
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p1 = PlatformFactCollector()
    assert p1.name == 'platform'
    assert p1._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])
    assert p1 == PlatformFactCollector()
    assert p1 != BaseFactCollector()
    

# Generated at 2022-06-23 01:37:15.051796
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'system' in x._fact_ids
    assert 'kernel' in x._fact_ids
    assert 'kernel_version' in x._fact_ids
    assert 'machine' in x._fact_ids
    assert 'python_version' in x._fact_ids
    assert 'architecture' in x._fact_ids

# Generated at 2022-06-23 01:37:19.724096
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command
    platform = PlatformFactCollector()
    result = platform.collect(module)

    assert result['system'] == 'AIX'
    assert result['kernel_version'] == '7100-03-03-1441'


# Generated at 2022-06-23 01:37:24.839100
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    x = PlatformFactCollector()
    assert x is not None
    assert x._fact_ids == {'architecture', 'fqdn', 'domain', 'machine', 'kernel',
                           'kernel_version', 'userspace_bits', 'userspace_architecture',
                           'python_version', 'system', 'hostname', 'machine_id', 'nodename'}

# Generated at 2022-06-23 01:37:33.934421
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Setting the following class attributes
    PlatformFactCollector.name = 'platform'
    PlatformFactCollector._fact_ids = set(['system',
                                           'kernel',
                                           'kernel_version',
                                           'machine',
                                           'python_version',
                                           'architecture',
                                           'machine_id'])

    # Create an instance of PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()

    # Check that instance created correctly
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-23 01:37:46.017326
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"

    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'fqdn' in p._fact_ids
    assert 'hostname' in p._fact_ids
    assert 'nodename' in p._fact_ids
    assert 'domain' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'userspace_architecture' in p._fact_ids
    assert 'userspace_bits' in p._fact_ids
    assert 'machine_id' in p._fact_ids

# Unit

# Generated at 2022-06-23 01:37:47.011878
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:37:53.657535
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == "platform"
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:37:58.590740
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    module = type('module', (), {})()
    platform = PlatformFactCollector(module)
    assert platform._fact_ids == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])

    assert platform.name == 'platform'

# Generated at 2022-06-23 01:38:07.951914
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):

        def __init__(self):
            self.run_command_results = {}

        def run_command(self, command):
            return self.run_command_results[tuple(command)]

        def get_bin_path(self, binary):
            if binary == 'getconf':
                return '/usr/bin/getconf'
            if binary == 'bootinfo':
                return '/usr/sbin/bootinfo'
            if binary == 'uname':
                return '/usr/bin/uname'

    class MockPlatform(object):

        def __init__(self):
            self.system_result = 'Linux'
            self.release_result = '3.10.0-327.36.1.el7.x86_64'

# Generated at 2022-06-23 01:38:10.145144
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts is not None
    assert len(platform_facts) > 0

# Generated at 2022-06-23 01:38:18.524967
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fc = PlatformFactCollector()
    platform_facts = platform_fc.collect()

    assert 'system' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'kernel' in platform_facts
    assert 'machine' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'hostname' in platform_facts
    assert 'nodename' in platform_facts
    assert 'domain' in platform_facts
    assert 'architecture' in platform_facts

    assert 'machine_id' in platform_facts

    assert 'python_version' in platform_facts



# Generated at 2022-06-23 01:38:29.821297
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    FakeModule = type('module', (object,), {'run_command': lambda self, *args, **kw: (0, None, None)})
    FakeModule.get_bin_path = lambda self, *args, **kw: None

    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect(module=FakeModule())

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['architecture'] == platform.machine()

    if platform_facts['system'] == 'AIX':
        assert platform_facts['architecture'] == 'PowerPC_POWER7'

# Generated at 2022-06-23 01:38:35.641796
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p._fact_ids == frozenset(['system',
                                     'kernel',
                                     'kernel_version',
                                     'machine',
                                     'python_version',
                                     'architecture',
                                     'machine_id'])
    assert p.name == 'platform'

# Generated at 2022-06-23 01:38:39.272407
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pc = PlatformFactCollector()
    facts = pc.collect()
    assert 'system' in facts
    assert facts['system'] is not None

# Generated at 2022-06-23 01:38:42.418045
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert 'architecture' in p._fact_ids
    assert 'system' in p._fact_ids
    assert 'fqdn' in p._fact_ids
    assert 'hostname' in p._fact_ids

# Generated at 2022-06-23 01:38:47.368105
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id'])



# Generated at 2022-06-23 01:38:49.529630
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fc = PlatformFactCollector()
    assert fc.name == 'platform'
    assert 'system' in fc.collect()

# Generated at 2022-06-23 01:38:57.620353
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create instance of PlatformFactCollector
    platform_collector = PlatformFactCollector()

    # Assert that the name is platform
    assert platform_collector.name == 'platform'

    # Assert the fact_ids are as expected
    actual_ids = platform_collector._fact_ids
    expected_ids = set(['system',
                        'kernel',
                        'kernel_version',
                        'machine',
                        'python_version',
                        'architecture',
                        'machine_id'])

    assert actual_ids == expected_ids

# Generated at 2022-06-23 01:39:06.099628
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()

    import platform
    platform_facts = platform_collector.collect()
    assert platform_facts["system"] == platform.system()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["machine"] == platform.machine()
    assert re.match("[0-9]+.[0-9]+.[0-9]+", platform_facts["python_version"])

# Generated at 2022-06-23 01:39:08.007252
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect() is not None


# Generated at 2022-06-23 01:39:15.032168
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == "platform"
    assert PlatformFactCollector()._fact_ids == {'system',
                                                 'kernel',
                                                 'kernel_version',
                                                 'machine',
                                                 'python_version',
                                                 'architecture'}

# Generated at 2022-06-23 01:39:25.614134
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import copy
    import sys
    import platform as pyplatform

    class FakeModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, name):
            return '/bin/%s' % name

        def run_command(self, args, **kwargs):
            self.args = copy.deepcopy(args)
            return self.rc, self.out, self.err

    class FakeKernelReleasePlatform(object):
        @property
        def system(self):
            return 'Linux'

        @property
        def release(self):
            return '2.6.32-431.23.3.el6.x86_64'

        @property
        def version(self):
            return '#1 SMP Fri Jan 3 21:39:27 UTC 2014'


# Generated at 2022-06-23 01:39:34.957220
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert set(platform_collector._fact_ids) == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])