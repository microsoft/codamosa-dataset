

# Generated at 2022-06-23 01:29:31.961056
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:29:40.244620
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup
    module = None
    collected_facts = None
    pfc = PlatformFactCollector()

    # Preconditions
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

    # Execution
    platform_facts = pfc.collect(module, collected_facts)

    # Postconditions
    hostname = platform.node().split('.')[0]
    domain = '.'.join(socket.getfqdn().split('.')[1:])
    architecture = platform.machine()
    if architecture == 'x86_64':
        architecture = platform.machine()

# Generated at 2022-06-23 01:29:50.591729
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test that the following facts are returned by the PlatformFactCollector collect method:
        system
        kernel
        kernel_version
        machine
        python_version
    """
    import platform
    import sys

    platform_collector = PlatformFactCollector()

    sys_platform = platform.system()
    kernel = platform.release()
    kernel_version = platform.version()
    machine = platform.machine()
    python_version = platform.python_version()

    result = platform_collector.collect()

    assert result is not None
    assert result.get('system') == sys_platform
    assert result['kernel'] == kernel
    assert result['kernel_version'] == kernel_version
    assert result['machine'] == machine
    assert result['python_version'] == python_version



# Generated at 2022-06-23 01:30:00.760059
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    # Machine id might be missing in case of /etc/machine-id and /var/lib/dbus/machine-id not present on the system
    if 'machine_id' in platform_facts.keys():
        platform_facts.pop('machine_id')

# Generated at 2022-06-23 01:30:12.041926
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    collected_facts = platform_fact_collector.collect()
    # test the fact being collected
    assert collected_facts['system'] is not None
    assert collected_facts['kernel'] is not None
    assert collected_facts['kernel_version'] is not None
    assert collected_facts['machine'] is not None
    assert collected_facts['python_version'] is not None
    assert collected_facts['architecture'] is not None
    assert collected_facts['fqdn'] is not None
    assert collected_facts['nodename'] is not None
    assert collected_facts['hostname'] is not None
    assert collected_facts['domain'] is not None
    if 'machine_id' in collected_facts:
        assert collected_facts['machine_id'] is not None

# Generated at 2022-06-23 01:30:18.720962
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc
    assert isinstance(pfc, BaseFactCollector)
    assert pfc.name == 'platform'
    assert pfc._fact_ids != None
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:30:22.505894
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-23 01:30:30.438790
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import collections

    collector = PlatformFactCollector()
    facts_dict = collector.collect()

    # test if fields exist
    assert facts_dict["system"]
    assert facts_dict["kernel"]
    assert facts_dict["kernel_version"]
    assert facts_dict["machine"]
    assert facts_dict["python_version"]
    assert facts_dict["architecture"]

    # test if fields are correct
    assert platform.system() == facts_dict["system"]
    assert platform.release() == facts_dict["kernel"]
    assert platform.version() == facts_dict["kernel_version"]
    assert platform.machine() == facts_dict["machine"]
    assert platform.python_version() == facts_dict["python_version"]
    assert platform.architecture()[0].replace("bit", "") == facts_dict

# Generated at 2022-06-23 01:30:37.648152
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Create a PlatformFactCollector object
    pfc = PlatformFactCollector()

    # Check name
    assert pfc.name == 'platform'

    # Check _fact_ids
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:30:41.555757
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts_collector = PlatformFactCollector()
    # Only check the names of facts
    assert set(platform_facts_collector.collect().keys()) == platform_facts_collector._fact_ids

# Generated at 2022-06-23 01:30:45.756138
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:30:51.638061
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for method collect of class PlatformFactCollector
    """
    # Test case with "system" == "Linux", "machine" == "x86_64", "architecture" == "64bit"
    from ansible.module_utils.facts.utils import AnsibleModule
    import ansible.module_utils.facts.collectors.platform
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = lambda cmd: (
        0,
        "x86_64",
        "",
    )
    test_module.get_bin_path = lambda name: "/usr/bin/getconf"
    platform_collector = ansible.module_utils.facts.collectors.platform.PlatformFactCollector(test_module)
    result = platform_collector.collect({}, {})

# Generated at 2022-06-23 01:30:53.606976
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x._fact_ids is not None

# Generated at 2022-06-23 01:30:59.194586
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:31:06.017570
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    Test instantiation of PlatformFactCollector class
    """
    pfc = PlatformFactCollector(None)
    assert isinstance(pfc, PlatformFactCollector)
    assert pfc.name == 'platform'
    assert pfc.collect_method == 'setup.py'
    assert set(pfc._fact_ids) == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])

# Generated at 2022-06-23 01:31:13.502264
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'hostname' in platform_facts
    assert 'nodename' in platform_facts
    assert 'domain' in platform_facts
    assert 'userspace_bits' in platform_facts

# Generated at 2022-06-23 01:31:21.808080
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    fc = FactsCollector()
    platform_facts = PlatformFactCollector()
    fc.collectors.append(platform_facts)

    res = platform_facts.collect()
    machine_id = get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")
    if machine_id:
        machine_id = machine_id.splitlines()[0]
        assert res["machine_id"] == machine_id
    assert platform.machine() == res['machine']
    assert platform.python_version() == res['python_version']
    assert platform.system() == res['system']
    assert platform.release() == res['kernel']

# Generated at 2022-06-23 01:31:31.557820
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test :meth:`PlatformFactCollector.collect()`
    """
    PLATFORM_FACTS = {
        'kernel': '5.0.0-29-generic',
        'kernel_version': '#31~18.04.1-Ubuntu SMP Wed Jul 17 17:30:44 UTC 2019',
        'machine': 'x86_64',
        'system': 'Linux',
        'python_version': '2.7.12 (default, Nov 12 2018, 14:36:49) \n[GCC 5.4.0 20160609]',
        'architecture': 'x86_64',
        'userspace_bits': '64',
        'userspace_architecture': 'x86_64',
    }

    platform_collector = PlatformFactCollector()

# Generated at 2022-06-23 01:31:38.730174
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a instance of PlatformFactCollector
    pfc = PlatformFactCollector()

    # Call method collect
    facts = pfc.collect()

    # assert facts - should contain hostname, system, architecture
    assert 'hostname' in facts
    assert 'system' in facts
    assert 'architecture' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'python_version' in facts
    assert 'machine_id' in facts

# Generated at 2022-06-23 01:31:43.178635
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-23 01:31:45.783708
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pc = PlatformFactCollector()
    print(pc.collect())

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-23 01:31:55.333399
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    expected_fact_ids = set(['system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'])
    assert platform_fact_collector._fact_ids == expected_fact_ids

"""
- name: test platform facts
  hosts: localhost
  gather_facts: False
  tasks:
    - platform_facts:
    - debug: var=ansible_facts.platform
"""

# Generated at 2022-06-23 01:32:00.130937
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:32:05.763548
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == {'system',
                           'kernel',
                           'kernel_version',
                           'machine',
                           'python_version',
                           'architecture',
                           'machine_id'}



# Generated at 2022-06-23 01:32:08.925549
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    print(platform_facts)

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-23 01:32:14.673954
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.collect() == pfc.collect_nested()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:32:26.711053
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Unit test for method collect of class PlatformFactCollector"""
    # set up test environment
    import os
    os.environ['_ANSIBLE_TEST_PLATFORM_COLLECTION_SYSTEM'] = 'Linux'
    os.environ['_ANSIBLE_TEST_PLATFORM_COLLECTION_KERNEL'] = 'Linux'
    os.environ['_ANSIBLE_TEST_PLATFORM_COLLECTION_KERNEL_VERSION'] = '1.0.0'
    os.environ['_ANSIBLE_TEST_PLATFORM_COLLECTION_MACHINE'] = 'Linux'
    os.environ['_ANSIBLE_TEST_PLATFORM_COLLECTION_PYTHON_VERSION'] = '1.0.0'

# Generated at 2022-06-23 01:32:29.654993
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    _platform = PlatformFactCollector()
    assert isinstance(_platform, PlatformFactCollector)
    assert _platform.name == 'platform'

# Generated at 2022-06-23 01:32:33.951922
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:32:35.277427
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'

# Generated at 2022-06-23 01:32:39.109805
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                 'python_version', 'architecture', 'machine_id'])
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-23 01:32:45.101730
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert 'system' in PlatformFactCollector._fact_ids
    assert 'kernel' in PlatformFactCollector._fact_ids
    assert 'kernel_version' in PlatformFactCollector._fact_ids
    assert 'machine' in PlatformFactCollector._fact_ids
    assert 'python_version' in PlatformFactCollector._fact_ids
    assert 'architecture' in PlatformFactCollector._fact_ids

    c = PlatformFactCollector()
    assert c.name == 'platform'

# Generated at 2022-06-23 01:32:48.329477
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:32:52.803917
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import platform

    platform_facts = {'system': 'XX',
                      'kernel': 'XX',
                      'kernel_version': 'XX',
                      'machine': 'XX',
                      'architecture': 'XX',
                      'python_version': 'XX',
                      'fqdn': 'XX',
                      'hostname': 'XX',
                      'nodename': 'XX',
                      'domain': 'XX'}

# Generated at 2022-06-23 01:32:56.592255
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:33:01.504247
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    cls = PlatformFactCollector()
    assert cls.name == 'platform'
    assert cls._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:33:11.829014
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''Unit test for method collect of PlatformFactCollector'''
    class ModuleMock(object):
        '''
        This is a mock module to run the fact collection without
        an actual Ansible module.
        '''
        def get_bin_path(self, name):
            '''
            Utility method to return the location of a binary
            '''
            if name == 'bootinfo':
                return '/usr/bin/bootinfo'
            if name == 'getconf':
                return '/usr/bin/getconf'
            return None

        def run_command(self, args):
            '''
            Utility method to return a tuple of (rc, out, err)
            '''
            class DummyPopen(object):
                '''
                Dummy class for python 2.6 compatibility
                '''

# Generated at 2022-06-23 01:33:18.937540
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Importing platform to get platform.system()
    import platform

    class mock_platform_system(object):
        def __init__(self, platform="Linux"):
            self.platform = platform

        def __call__(self):
            return self.platform

    # Creating mock class for platform
    class mock_platform(object):
        pass

    # Creating mock class for module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False):
            if executable == 'bootinfo':
                return 'bootinfo'
            else:
                return ''

        def run_command(self, command):
            out = "0042 0042 0042"
            if command == ['bootinfo', '-p']:
                return 0,

# Generated at 2022-06-23 01:33:28.872185
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()

    # Create a mock module
    # Returned values should be the ones specified here to make the test
    # pass
    def mock_get_bin_path(binary):
        if binary == 'getconf':
            return 'getconf'
        elif binary == 'bootinfo':
            return 'bootinfo'
        else:
            return None

    def mock_run_command(command):
        if command == ['getconf', 'MACHINE_ARCHITECTURE']:
            return 0, 'ppc64', None
        elif command == ['bootinfo', '-p']:
            return 0, 'ppc64', None
        else:
            return 0, '/bin/bash', None


# Generated at 2022-06-23 01:33:35.890184
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    Unit test for method collect of class PlatformFactCollector
    '''
    print("Running test_PlatformFactCollector_collect")
    collector = PlatformFactCollector()
    platform_facts = collector.collect()
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['architecture'] == 'x86_64'
    assert platform_facts['hostname'] == 'tbedell-ltm'
    assert platform_facts['python_version'] == '2.7.5'
    import platform
    import re
    try:
        assert platform_facts['machine_id'] == platform.uname()[1]
    except:
        pass

# Generated at 2022-06-23 01:33:44.045518
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    if platform.system() == 'AIX':
        assert PlatformFactCollector().collect()['system'] == 'AIX'
    elif platform.system() == 'Darwin':
        assert PlatformFactCollector().collect()['system'] == 'Darwin'
    elif platform.system() == 'Linux':
        assert PlatformFactCollector().collect()['system'] == 'Linux'
    elif platform.system() == 'OpenBSD':
        assert PlatformFactCollector().collect()['system'] == 'OpenBSD'
    elif platform.system() == 'Windows':
        assert PlatformFactCollector().collect()['system'] == 'Windows'
    else:
        assert False

# Generated at 2022-06-23 01:33:44.643765
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass

# Generated at 2022-06-23 01:33:48.252737
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()

    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:33:58.427391
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket

    # Setup test platform env
    test_distro = platform.linux_distribution()
    test_node = platform.node()
    test_system = platform.system()
    test_release = platform.release()
    test_version = platform.version()
    test_machine = platform.machine()
    test_python_version = platform.python_version()

    # Setup socket mocks
    def side_effect(*popenargs, **kwargs):
        return ("testdomain.tld", "", 0)
    socket.getfqdn = side_effect

    class MockModule:
        class run_command:
            def __init__(self, args, env=None):
                self.args = args
                self.env = env


# Generated at 2022-06-23 01:34:04.639930
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:34:16.176223
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test PlatformFactCollector.collect()."""
    import platform
    import sys

    class MockModule:
        @staticmethod
        def get_bin_path(path):
            return path

        @staticmethod
        def run_command(cmd):
            cmd = cmd[0]
            if cmd == "getconf":
                return (0, "i686\n", "")
            elif cmd == "getconf MACHINE_ARCHITECTURE":
                return (0, "ppc64\n", "")
            elif cmd == "bootinfo":
                return (0, "ppc64\n", "")
            else:
                raise ValueError(cmd)

        @staticmethod
        def fail_json(*args, **kwargs):
            raise Exception()


# Generated at 2022-06-23 01:34:17.394455
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:34:20.922662
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create an instance of class PlatformFactCollector with initializing data
    PlatformCollectorObj = PlatformFactCollector()

    # call method collect of class PlatformFactCollector
    PlatformCollectorObj.collect()

# Generated at 2022-06-23 01:34:22.154465
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform', 'constructor for PlatformFactCollector failed'

# Generated at 2022-06-23 01:34:28.600548
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create an instance of the PlatformFactCollector class with
    # required arguments
    pfc = PlatformFactCollector()

    # testing the return value of method collect by passing an instance
    # of the class FakeModule.
    ret = pfc.collect(None, None)

    assert ret['system'] == 'Linux'
    assert ret['kernel'] != ''
    assert ret['kernel_version'] != ''
    assert ret['machine'] != ''
    assert ret['python_version'] == platform.python_version()
    assert ret['architecture'] != ''
    assert ret['fqdn'] != ''
    assert ret['hostname'] != ''
    assert ret['nodename'] != ''
    assert ret['domain'] != ''

# Generated at 2022-06-23 01:34:33.945185
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])



# Generated at 2022-06-23 01:34:36.542193
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """ test_PlatformFactCollector

    Test the instantiation of the PlatformFactCollector
    """
    p = PlatformFactCollector()
    assert isinstance(p, PlatformFactCollector)

# Generated at 2022-06-23 01:34:45.130910
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """ Stub for testing the PlatformFactCollector.collect() method. """

    # Setup required parameters.
    module = FakeAnsibleModule()

    # Setup a fake collected_facts dict, with no collected facts.
    collected_facts = dict()

    # Setup the PlatformFactCollector object.
    platformfactcollector = PlatformFactCollector()

    # Run the PlatformFactCollector object.collect() method.
    test_platform = platformfactcollector.collect(module, collected_facts)

    # Check if the returned test_platform dict is empty.
    assert len(test_platform) > 0

    # Check if the returned test_platform dict has the 'system' key.
    assert 'system' in test_platform

    # Check if the returned test_platform dict has the 'kernel' key.
    assert 'kernel' in test_platform

    # Check

# Generated at 2022-06-23 01:34:49.244926
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Test the constructor of PlatformFactCollector"""

    fact_class = PlatformFactCollector()
    assert fact_class._name == "platform"
    assert fact_class._fact_ids == set(['system',
                                        'kernel',
                                        'kernel_version',
                                        'machine',
                                        'python_version',
                                        'architecture',
                                        'machine_id'])


# Generated at 2022-06-23 01:34:57.074179
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()

    assert platform_collector.name == 'platform', "PlatformFactCollector's name should be platform"
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id']), \
                                                "PlatformFactCollector's _fact_ids should be system, kernel, " \
                                                "kernel_version, machine, python_version, architecture and machine_id"

# Generated at 2022-06-23 01:34:59.826270
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """ This method will cover the __init__() method of class PlatformFactCollector """
    pf = PlatformFactCollector()
    assert pf.name == 'platform'


# Generated at 2022-06-23 01:35:04.380096
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()

    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:35:08.435924
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fc = PlatformFactCollector()
    facts = platform_fc.collect()
    assert platform.system() == facts['system']
    assert platform.release() == facts['kernel']
    assert platform.version() == facts['kernel_version']
    assert platform.machine() == facts['machine']
    assert platform.python_version() == facts['python_version']

# Generated at 2022-06-23 01:35:12.801170
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:35:22.945981
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()[0]

# Generated at 2022-06-23 01:35:24.312285
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    myCollector = PlatformFactCollector()
    assert myCollector.collect()

# Generated at 2022-06-23 01:35:30.926142
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == {'system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id',
                                            'fqdn',
                                            'hostname',
                                            'nodename',
                                            'domain',
                                            'userspace_bits',
                                            'userspace_architecture'}

# Generated at 2022-06-23 01:35:38.280595
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf_collector = PlatformFactCollector()
    assert pf_collector.name == 'platform'
    assert isinstance(pf_collector._fact_ids, frozenset)
    for fact_id in ['system', 'kernel', 'kernel_version', 'machine',
                    'architecture', 'machine_id']:
        assert fact_id in pf_collector._fact_ids

# Generated at 2022-06-23 01:35:47.926179
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['architecture'] == platform_facts['machine']
    assert platform_facts['python_version'] == platform.python_version()

# Generated at 2022-06-23 01:35:52.484879
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Initialize instance
    platform_fact_collector = PlatformFactCollector()
    # Call method collect
    platform_facts = platform_fact_collector.collect()
    # Assert none None
    assert platform_facts['system'] is not None
    assert platform_facts['kernel'] is not None
    assert platform_facts['kernel_version'] is not None
    assert platform_facts['machine'] is not None
    assert platform_facts['python_version'] is not None
    assert platform_facts['architecture'] is not None

# Generated at 2022-06-23 01:36:00.533008
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Testing the case where the platform is Linux or Darwin
    platform_facts = PlatformFactCollector().collect()
    if platform_facts['system'] == 'Linux' or platform_facts['system'] == 'Darwin':
        assert platform_facts['system'] is not None
        assert platform_facts['kernel'] is not None
        assert platform_facts['kernel_version'] is not None
        assert platform_facts['machine'] is not None
        assert platform_facts['python_version'] == platform.python_version()
    # Testing the case for Windows
    elif platform_facts['system'] == "Windows":
        assert platform_facts['system'] is not None
        assert platform_facts['machine'] == "AMD64"
        assert platform_facts['python_version'] == platform.python_version()
    # Testing the case for Solaris

# Generated at 2022-06-23 01:36:10.010447
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = dict(
        system='Linux',
        kernel='2.6.32-36-generic',
        kernel_version='#81-Ubuntu SMP Mon Sep 24 15:59:30 UTC 2012',
        machine='x86_64',
        python_version='2.7.2',
        fqdn='myhost.mydomain.tld',
        hostname='myhost',
        nodename='myhost.mydomain.tld',
        domain='mydomain.tld',
        userspace_bits='64',
        architecture='x86_64',
        userspace_architecture='x86_64',
        machine_id='1234567890abcdef'
    )
    module = MockModule()
    # fake the call of run_command, module.run_command has no return value
    module.run

# Generated at 2022-06-23 01:36:11.780361
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_platform = PlatformFactCollector()
    assert platform_platform.collect() is None


# Generated at 2022-06-23 01:36:15.477179
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version',
                                 'machine', 'python_version', 'architecture',
                                 'machine_id'])



# Generated at 2022-06-23 01:36:23.898727
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # Setup a mock module and test variables to be used by the unit test.
    module = Mock()
    module.run_command.return_value = 0, '1', ''

# Generated at 2022-06-23 01:36:26.671902
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()

    assert pfc.name is not None and pfc.name

    # _fact_ids tested in test_collect()


# Generated at 2022-06-23 01:36:28.620233
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'

# Generated at 2022-06-23 01:36:39.486808
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect()
    # The system can be Linux, Darwin, Java, or Windows
    # The kernel is not hardcoded, it can be Linux, Darwin, etc.
    # The kernel_version is not hardcoded
    # The machine is not hardcoded
    assert platform_facts['system'] in ('Linux', 'Darwin', 'Java', 'Windows')
    assert platform_facts['kernel'] in ('Linux', 'Darwin', 'Java', 'Windows')
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    # the python_version is not hardcoded, we use it as a string
    assert platform_facts['python_version']
    # the fqdn is not hardcoded, we use it as a string

# Generated at 2022-06-23 01:36:43.826790
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == {'system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'}


# Generated at 2022-06-23 01:36:49.582902
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert platform_facts._fact_ids == set(['system', 'kernel', 'kernel_version',
                                            'machine', 'python_version',
                                            'architecture', 'machine_id'])

# Generated at 2022-06-23 01:36:53.416740
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert x._fact_ids == {"system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"}


# Generated at 2022-06-23 01:36:54.296181
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:37:00.400952
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'architecture' in platform_facts


# Generated at 2022-06-23 01:37:08.596495
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import ansible.module_utils.facts.collectors
    from ansible.module_utils.facts import timeout

    collector = ansible.module_utils.facts.collectors.get_collector("platform")
    platform_facts = collector.collect()

    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel'] == 'Linux'
    assert platform_facts['kernel_version'].startswith('Linux')
    assert platform_facts['machine'] == 'Linux'
    assert platform_facts['architecture'] == 'Linux'
    assert platform_facts['python_version'] == 'Linux'
    assert platform_facts['fqdn'] == 'Linux'
    assert platform_facts['hostname'] == 'Linux'
    assert platform_facts['nodename'] == 'Linux'
    assert platform_facts['domain']

# Generated at 2022-06-23 01:37:13.379371
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''Unit test for constructor of class PlatformFactCollector'''
    ''' platform_object is an instance of class PlatformFactCollector'''
    platform_object = PlatformFactCollector()
    assert platform_object.name == 'platform'
    assert len(platform_object._fact_ids) == 9

# Generated at 2022-06-23 01:37:15.404893
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert type(x) == PlatformFactCollector


# Generated at 2022-06-23 01:37:23.561475
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # default call
    platform_fact = PlatformFactCollector()
    result = platform_fact.collect()
    # assert that result is dict
    assert isinstance(result, dict)
    # assert that result contains the following keys
    assert result.keys() == {'domain',
                             'nodename',
                             'userspace_bits',
                             'system',
                             'python_version',
                             'machine',
                             'kernel',
                             'kernel_version',
                             'hostname',
                             'fqdn',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-23 01:37:25.038399
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    p = PlatformFactCollector()

    assert(p) is not None

# Generated at 2022-06-23 01:37:33.758744
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform

    pc = PlatformFactCollector()

    def test_run(expected_platform='Linux', expected_architecture='x86_64'):
        facts = pc.collect(None, None)
        assert facts.get("system") == expected_platform
        assert facts.get("architecture") == expected_architecture

    f_platform_system = platform.system
    f_platform_architecture = platform.architecture

    platform.system = lambda: 'Linux'
    platform.architecture = lambda: ('64bit', 'ELF')
    test_run()

    platform.system = lambda: 'AIX'
    platform.architecture = lambda: ('64bit', 'ELF')
    test_run(expected_platform='AIX', expected_architecture='powerpc')


# Generated at 2022-06-23 01:37:38.928682
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fake_module = object()
    collected_facts = object()
    platform_facts = PlatformFactCollector(fake_module).collect(collected_facts)
    for fact_id in PlatformFactCollector._fact_ids:
        assert fact_id in platform_facts

# Generated at 2022-06-23 01:37:48.846457
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create a platform fact collector instance
    c = PlatformFactCollector()

    # call collect to get a dictionary of facts about the platform
    # for this machine
    platform_facts = c.collect()

    # assert the 'system' fact is in the dictionary
    assert 'system' in platform_facts
    # get the system name from the platform module
    system = platform.system()
    # assert the values for the 'system' fact in the dictionary
    # and from the platform module match
    assert platform_facts['system'] == system

    # Assert the 'kernel' fact is in the dictionary
    assert 'kernel' in platform_facts
    # get the kernel name from the platform module
    kernel = platform.release()
    # assert the values for the 'kernel' fact in the dictionary
    # and from the platform module match

# Generated at 2022-06-23 01:37:50.381950
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    obj = PlatformFactCollector()
    obj.collect()

# Generated at 2022-06-23 01:37:52.442242
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfact = PlatformFactCollector()
    assert len(pfact._fact_ids) == 9

# Generated at 2022-06-23 01:38:02.347186
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts import ModuleUtilsLegacyFactCollector
    from ansible.module_utils._text import to_native

    class DummyModuleLegacy(object):
        def __init__(self):
            self.run_command_environ_update = dict()
            self.params = dict()
            self.run_command_environ_update['LANG'] = 'C'
            self.run_command_environ_update['LC_ALL'] = 'C'

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'uname':
                return '/bin/uname'
            elif arg == 'getconf':
                return '/usr/bin/getconf'
            el

# Generated at 2022-06-23 01:38:09.461917
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert len(p._fact_ids) == 9
    assert p._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'fqdn',
                     'hostname',
                     'machine_id'])

# Generated at 2022-06-23 01:38:11.497470
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf_collector = PlatformFactCollector()
    assert pf_collector.name == 'platform'


# Generated at 2022-06-23 01:38:22.571533
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import os

    # Test object creation
    PlatformFactCollectorObject = PlatformFactCollector()

    # Test method collect
    # Test 1: default condition
    try:
        import platform
    except ImportError:
        exit_message = 'module python platform is not installed. Skipping unit test.'
        os._exit(0)
    else:
        pass

    # Test 2: exception handling
    # Test 2.1: use fake class for platform module
    import sys

    class FakePlatformClass:
        def __init__(self):
            self.system = 'Linux'
        def machine(self):
            return 'x86_64'

# Generated at 2022-06-23 01:38:24.817271
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    h = PlatformFactCollector()
    assert h.name == 'platform'
    h.collect()

# Generated at 2022-06-23 01:38:33.596202
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = FakeModule()
    platform_collector = PlatformFactCollector(module)
    ret = platform_collector.collect()
    assert ret['system'] == 'Linux'
    assert ret['nodename'] == 'localhost'
    assert ret['hostname'] == 'localhost'
    assert ret['kernel_version'] == '#1 SMP Tue Jan 8 21:35:10 CES 2013'
    assert ret['architecture'] == 'x86_64'
    assert ret['kernel'] == '2.6.32-5-amd64'
    assert ret['python_version'] == '2.7.5'
    assert ret['machine'] == 'x86_64'



# Generated at 2022-06-23 01:38:37.914082
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert x.name == 'platform'

# Generated at 2022-06-23 01:38:47.948230
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """ This is a more of an integration test than a unit test as it
    tests that we correctly parse the output of platform.system(),
    platform.release(), platform.version(), platform.machine(),
    platform.python_version(), and platform.architecture()
    """
    # We are passing in a None for module to be consistent with the other
    # collectors
    platform_fact_collector = PlatformFactCollector(None)
    assert platform_fact_collector is not None
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture'])


# Generated at 2022-06-23 01:38:59.110920
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test input data
    module = lambda: None
    module.run_command = lambda x: (0, 'x86', '')
    module.get_bin_path = lambda x: '/' + x

    # Expected output

# Generated at 2022-06-23 01:39:06.800992
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fc = PlatformFactCollector()

    expected_platform_facts = {
        'system': 'Linux',
        'kernel': '3.10.0-327.el7.x86_64',
        'kernel_version': '#1 SMP Thu Nov 19 22:10:57 UTC 2015',
        'machine': 'x86_64',
        'architecture': 'x86_64',
        'python_version': '2.7.5',
        'fqdn': 'localhost.localdomain',
        'hostname': 'localhost',
        'nodename': 'localhost.localdomain'
    }

    platform_facts = fc.collect()
    for expected_fact_key in expected_platform_facts:
        assert expected_fact_key in platform_facts

# Generated at 2022-06-23 01:39:10.586906
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                                     'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:39:21.839583
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector()
    platform_facts.populate_facts()

    assert len(platform_facts.facts['platform'].keys()) == 6
    assert platform_facts.facts['platform']['system'] == 'Linux'
    assert platform_facts.facts['platform']['kernel'] == '4.15.0-136-generic'
    assert platform_facts.facts['platform']['kernel_version'] == '#137-Ubuntu SMP Mon Sep 24 16:19:09 UTC 2018'
    assert platform_facts.facts['platform']['machine'] == 'x86_64'
    assert platform_facts.facts['platform']['fqdn'] == socket.getfqdn()
    assert platform_facts.facts['platform']['hostname'] == platform.node().split('.')[0]

# Generated at 2022-06-23 01:39:22.894405
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-23 01:39:31.341927
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Test 1
    platform_facts_dict = {'system': 'Linux',
                           'kernel_version': '#1 SMP Wed Sep 9 10:27:00 PDT 2015',
                           'architecture': 'x86_64',
                           'kernel': '4.4.0-21-generic',
                           'machine': 'x86_64'}

    class ModuleStub(object):
        def __init__(self):
            self._facts = {}

            # Since we run the collector with gather_subset='all', we need to satisfy
            # this check in the module utils:
            #
            # if gather_subset in ('all', 'min') and not self.supports_ansible_facts:
            #     self.fail_json(msg="Incorrect OS type found via detection plugin. "
            #                        