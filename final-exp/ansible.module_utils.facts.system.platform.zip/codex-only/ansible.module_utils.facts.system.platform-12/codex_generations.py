

# Generated at 2022-06-23 01:29:38.685048
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    Test cases for method collect of class PlatformFactCollector.
    '''
    class Tests(object):
        '''
        Instance class for testing method collect.
        '''
        def __init__(self, module):
            self._test_module = module

    class TestModule(object):
        '''
        Instance class for testing method collect.
        '''
        @staticmethod
        def get_bin_path(binary):
            '''
            Method get_bin_path
            '''
            return None

        @staticmethod
        def run_command():
            '''
            Method run_command
            '''
            return (1, 'result1\nresult2', 'error')

    platform_fact_collector = PlatformFactCollector()
    test_module = TestModule()
    test_tests

# Generated at 2022-06-23 01:29:50.128782
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    def get_bin_path(name):
        return "/bin/" + name

    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    PlatformFactCollector.fqdn = 'test_fqdn'
    PlatformFactCollector.kernel = 'test_kernel'
    PlatformFactCollector.kernel_version = 'test_kernel_version'
    PlatformFactCollector.machine = 'test_machine'
    PlatformFactCollector.python_version = 'test_python_version'
    PlatformFactCollector.system = 'test_system'

    PlatformFactCollector.nodename = 'test_node_name'
   

# Generated at 2022-06-23 01:29:54.887987
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:29:57.232999
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"

# Generated at 2022-06-23 01:30:00.665017
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test with an empty collected_facts dictionary
    test_platform_facts = PlatformFactCollector().collect(collected_facts={})
    assert test_platform_facts is not None
    assert 'architecture' in test_platform_facts

# Generated at 2022-06-23 01:30:04.769426
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == "platform"
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])
    assert not collector._platform_independent



# Generated at 2022-06-23 01:30:10.880225
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()

    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:30:13.009984
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    # New instance should have empty dict as facts
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-23 01:30:23.033326
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
        Unit test for method collect of class PlatformFactCollector
    """
    # Define a fake module
    class FakeModule(object):

        def __init__(self):
            self._ansible_version = '2.8.0'
            self.params = {}
            self.args = {}

        def get_bin_path(self, arg):
            return arg

        def run_command(self, arg):
            return (0, '', '')

    fake_module = FakeModule()

    # Define a fake architectural platform
    class FakeArchitecturePlatform(object):

        def __init__(self):
            self.system = 'AIX'
            self.release = '7.2.0.0'
            self.version = '7200-01-00-0000'

# Generated at 2022-06-23 01:30:27.256016
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector(None)

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector.fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id'])

# Generated at 2022-06-23 01:30:37.117312
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import PlatformFactCollector
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}
            self.check_mode = False
            self.exit_json = None
            self.fail_json = None

    module = FakeModule()
    collector = PlatformFactCollector(module=module)
    just_the_facts = {}
    collector.collect(module=module, collected_facts=just_the_facts)
    assert isinstance(just_the_facts, dict)

# Generated at 2022-06-23 01:30:43.347979
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['machine_id'][0:32] == (get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")).splitlines()[0][0:32]
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]

# Generated at 2022-06-23 01:30:51.139530
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import collections
    import platform
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    FakeModule = collections.namedtuple('Module', ['run_command', 'get_bin_path'])

    def fake_get_bin_path(name):
        if name == 'getconf':
            return '/opt/freeware/bin/getconf'
        elif name == 'bootinfo':
            return '/usr/sbin/bootinfo'
        else:
            return None

    def fake_run_command(cmd):
        if cmd == ['/opt/freeware/bin/getconf', 'MACHINE_ARCHITECTURE']:
            return 0, "PowerPC64_POWER8\n", ''

# Generated at 2022-06-23 01:30:56.937907
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector(None)
    assert platform_collector.name is 'platform'
    assert platform_collector._fact_ids is set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:31:07.609679
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import Facts

    facts = Facts(dict())

    # Setup mock objects
    collector = PlatformFactCollector()
    ansible.module_utils.facts.collector.add_collector(collector)

    # Test against supported platform
    if sys.platform.startswith('linux'):
        assert collector.name == 'platform'
        assert 'platform' in facts.data
        assert 'system' in facts.data['platform']
        assert 'kernel' in facts.data['platform']
        assert 'kernel_version' in facts.data['platform']
        assert 'machine' in facts.data['platform']

# Generated at 2022-06-23 01:31:17.963461
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collectors.system import PlatformFactCollector
    from ansible.module_utils.facts.collectors.base import FactsCollector

    facts_collector = FactsCollector()
    platform_fact_collector = PlatformFactCollector(facts_collector)

    collected_facts = {}

    new_facts = platform_fact_collector.collect(collected_facts=collected_facts)
    assert isinstance(new_facts, dict)
    assert "system" in new_facts.keys()
    assert "kernel" in new_facts.keys()
    assert "kernel_version" in new_facts.keys()
    assert "machine" in new_facts.keys()
    assert "python_version" in new_facts.keys()

# Generated at 2022-06-23 01:31:19.493559
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    a = PlatformFactCollector()
    b = a.collect()
    print(b)

# Generated at 2022-06-23 01:31:25.125463
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:31:32.560308
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    class MockModule(object):
        def __init__(self):
            self.run_command = basic.run_command
            self.get_bin_path = basic.get_bin_path
            self.basic = basic
    collected_facts = {}
    PlatformFactCollector().collect(MockModule(), collected_facts)
    assert collected_facts['architecture'] == 'x86_64'

# Generated at 2022-06-23 01:31:34.383063
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert repr(PlatformFactCollector) == repr(PlatformFactCollector)

# Generated at 2022-06-23 01:31:44.217922
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Run a test for testing platform fact of the collector"""
    fake_platform = {
        'system': 'Linux',
        'kernel': '4.4.0-62-generic',
        'kernel_version': '#83-Ubuntu SMP Wed Jan 18 14:10:15 UTC 2017',
        'machine': 'x86_64'
    }
    fake_python_version = '2.7.12'
    fake_fqdn = 'system.my.domain'
    fake_hostname = 'system'
    fake_nodename = 'system.my.domain'

    def get_system_mock():
        return fake_platform['system']

    def get_kernel_mock():
        return fake_platform['kernel']


# Generated at 2022-06-23 01:31:44.963369
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()
    assert True

# Generated at 2022-06-23 01:31:45.560884
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:31:55.854602
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Import the facts module
    import ansible.module_utils.facts.system.platform as platform_module

    # Create an instance of PlatformFactCollector class
    platform_fact_collector = PlatformFactCollector()

    # Get the instance of AnsibleModule class that is created when the
    # module is run
    ansible_module_instance = platform_module.AnsibleModule(argument_spec=dict())

    # Create the return value of the module
    facts_dict = platform_fact_collector.collect(module=ansible_module_instance)

    assert facts_dict['system'] == 'Linux'
    assert facts_dict['python_version']
    assert facts_dict['kernel_version']
    assert facts_dict['machine']
    assert facts_dict['nodename']
    assert facts_dict['fqdn']

# Generated at 2022-06-23 01:32:02.710041
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

    assert solaris_i86_re.pattern == SOLARIS_I86_RE_PATTERN
    assert solaris_i86_re.flags == re.IGNORECASE

# Generated at 2022-06-23 01:32:04.738523
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert isinstance(plat, PlatformFactCollector)

# Generated at 2022-06-23 01:32:11.072983
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector({})
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])
    assert pfc.collect()["architecture"] == platform.machine()

# Generated at 2022-06-23 01:32:12.517419
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'

# Generated at 2022-06-23 01:32:22.862317
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    module.get_bin_path = get_bin_path_mock
    module.run_command = run_command_mock

    platform_fact_collector = PlatformFactCollector()
    facts_dict = platform_fact_collector.collect(module=module)

    assert facts_dict['system'] == 'Linux'
    assert facts_dict['kernel'] == '3.19.0-33-generic'
    assert facts_dict['kernel_version'] == '#38~14.04.1-Ubuntu SMP Fri Nov 6 18:17:28 UTC 2015'
    assert facts_dict['machine'] == 'x86_64'
    assert facts_dict['python_version'] == '2.7.6'
    assert facts_dict['architecture'] == 'x86_64'


# Generated at 2022-06-23 01:32:26.448685
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:32:31.733922
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-23 01:32:37.477340
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    ])

# Generated at 2022-06-23 01:32:43.393077
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == "platform"
    assert "system" in pfc._fact_ids
    assert "kernel" in pfc._fact_ids
    assert "kernel_version" in pfc._fact_ids
    assert "machine" in pfc._fact_ids
    assert "python_version" in pfc._fact_ids

# Generated at 2022-06-23 01:32:52.264168
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import re
    import os
    from ansible.module_utils.facts.utils import get_file_content
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors.platform as platform_collector
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors.base as base_collector
    import ansible_collections.ansible.community.plugins.module_utils.facts.utils as utils

    class MockModule:
        def get_bin_path(arg):
            return "C:\Program Files\Ansible\ansible\bin\python.exe"

    class MockRun_command:
        def return_values(self, rc, out, err):
            self.rc = 0
            self.out = out


# Generated at 2022-06-23 01:32:56.378844
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:33:00.508627
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for collect method of PlatformFactCollector.
    """
    fake_module = type('FakeModule', (), dict())()
    platform_fact_collector = PlatformFactCollector(fake_module)
    assert platform_fact_collector.collect()

# Generated at 2022-06-23 01:33:02.452292
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    # Test that PlatformFactCollector class can be initiated
    PlatformFactCollector()

# Generated at 2022-06-23 01:33:10.352718
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert platform_obj.name == 'platform'
    assert len(platform_obj._fact_ids) == 9
    assert 'system' in platform_obj._fact_ids
    assert 'kernel' in platform_obj._fact_ids
    assert 'kernel_version' in platform_obj._fact_ids
    assert 'machine' in platform_obj._fact_ids
    assert 'python_version' in platform_obj._fact_ids
    assert 'architecture' in platform_obj._fact_ids
    assert 'machine_id' in platform_obj._fact_ids


# Generated at 2022-06-23 01:33:21.846665
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    This method unit tests the PlatformFactCollector.collect() method

    :return:
    """
    from ansible.module_utils.facts import ModuleExitException

    class MockPlatform(object):
        @staticmethod
        def system():
            return 'Linux'

        @staticmethod
        def release():
            return 'Linux'

        @staticmethod
        def version():
            return 'Linux'

        @staticmethod
        def machine():
            return 'Linux'

        @staticmethod
        def uname():
            return 'Linux'

        @staticmethod
        def python_version():
            return 'Linux'

        @staticmethod
        def architecture():
            return 'Linux'

        @staticmethod
        def architecture():
            return 'Linux'


# Generated at 2022-06-23 01:33:26.541139
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    platform_collector = get_collector_instance(PlatformFactCollector)
    facts = platform_collector.collect()
    assert 'system' in facts

# Generated at 2022-06-23 01:33:33.620855
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert set(platform_fact_collector._fact_ids) == set(['system',
                                                           'kernel',
                                                           'kernel_version',
                                                           'machine',
                                                           'python_version',
                                                           'architecture',
                                                           'machine_id'])


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:33:43.662561
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = type('', (), {})()
    setattr(module, 'run_command', lambda command: (0, "", ""))
    setattr(module, 'get_bin_path', lambda command: '')
    class DummyFile(object):
        def readline(self):
            return "fake_machine_id"
    setattr(module, 'open', lambda *args, **kwargs: DummyFile())

    collector = PlatformFactCollector()
    facts = collector.collect(module=module)
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    # On Mac OS X 10.5 and later, platform.version() includes the major version number, so we cut it off.
    # See http://stackoverflow.com/questions/1724693/find-out-which-

# Generated at 2022-06-23 01:33:47.670900
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    x = PlatformFactCollector()
    out = x.collect()
    assert out is not None
    assert "system" in out
    assert "kernel" in out
    assert "kernel_version" in out
    assert "machine" in out
    assert "python_version" in out
    assert "architecture" in out

# Generated at 2022-06-23 01:33:51.082852
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:33:55.722876
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:34:00.123313
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == { 'system',
                                             'kernel',
                                             'kernel_version',
                                             'machine',
                                             'python_version',
                                             'architecture',
                                             'machine_id' }

# Generated at 2022-06-23 01:34:08.284139
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # we create a class to be able to override run_command
    class MyPlatformFactCollector(PlatformFactCollector):
        def run_command(self, args, check_rc=True):
            if args[0] == '/usr/bin/getconf':
                # getconf output:
                out = '64'
            elif args[0] == '/usr/sbin/bootinfo':
                # bootinfo output
                out = 'powerpc'
            else:
                raise Exception("Should not be here")
            return 0, out, ''

    pfc = MyPlatformFactCollector()
    module = Mock()
    module.run_command = pfc.run_command
    collected_facts = {}
    pfc.collect(module, collected_facts)



# Generated at 2022-06-23 01:34:10.496194
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = None
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['python_version'] == '2.7.5'

# Generated at 2022-06-23 01:34:20.670673
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    collected_facts = FactsCollectorMock()
    pfc = PlatformFactCollector(module=module, collected_facts=collected_facts)
    out = {}
    out["system"] = platform.system()
    out["kernel"] = platform.release()
    out["kernel_version"] = platform.version()
    out["machine"] = platform.machine()
    out["python_version"] = platform.python_version()
    out["fqdn"] = socket.getfqdn()
    out["hostname"] = platform.node().split('.')[0]
    out["nodename"] = platform.node()
    out["domain"] = '.'.join(out["fqdn"].split('.')[1:])
    out["userspace_bits"] = platform.architecture()

# Generated at 2022-06-23 01:34:31.194160
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    hostname = socket.gethostname()
    fqdn = socket.getfqdn()
    platform_data = {'system': platform.system(),
                     'kernel': platform.release(),
                     'kernel_version': platform.version(),
                     'machine': platform.machine(),
                     'python_version': platform.python_version(),
                     'fqdn': fqdn,
                     'hostname': hostname,
                     'nodename': hostname, # Needed for AIX
                     'architecture': platform.architecture()[0],
                     'machine_id': '',
                    }
    platform_data['domain'] = '.'.join(fqdn.split('.')[1:])


# Generated at 2022-06-23 01:34:35.705216
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:34:40.394102
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:34:44.894490
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector(None, None)
    assert fact_collector.name == 'platform'
    assert PlatformFactCollector._fact_ids == {'system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'}


# Generated at 2022-06-23 01:34:50.646686
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fake_module = 'ansible.module_utils.facts.collectors.platform'
    fake_ids = set(['system',
                    'kernel',
                    'kernel_version',
                    'machine',
                    'python_version',
                    'architecture',
                    'machine_id'])

    platform_obj = PlatformFactCollector()
    assert platform_obj.collect() == {}
    assert platform_obj.name == 'platform'
    assert platform_obj._fact_ids == fake_ids
    assert platform_obj.__doc__ == "Responsible for collecting platform facts."

# Generated at 2022-06-23 01:35:00.825638
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
  result = dict(system='Linux',
                kernel='4.4.0-25-generic',
                kernel_version='#44~14.04.1-Ubuntu SMP Thu Jun 9 09:45:41 UTC 2016',
                machine='x86_64',
                python_version='2.7.5',
                fqdn='ubuntu',
                hostname='ubuntu',
                nodename='ubuntu',
                domain='',
                userspace_bits='64',
                architecture='x86_64',
                userspace_architecture='x86_64',
                machine_id='8ea7b49fd2c74ab7a3755a6a5c6b16af')
  module = MockModule()
  c = PlatformFactCollector(module=module)
  assert c.collect() == result

# Mock class for module

# Generated at 2022-06-23 01:35:04.607964
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    expected_collector = PlatformFactCollector()
    assert expected_collector.name == 'platform'
    assert expected_collector._fact_ids == set(['system', 'kernel', 'kernel_version',
                                                'machine', 'python_version', 'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:35:08.873767
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])



# Generated at 2022-06-23 01:35:19.683470
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a PlatformFactCollector instance
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'userspace_bits' in platform_facts

    assert isinstance(platform_facts['system'], basestring) and platform_facts['system'] != ''
    assert isinstance(platform_facts['kernel'], basestring) and platform_facts['kernel'] != ''
    assert isinstance(platform_facts['machine'], basestring) and platform_facts['machine'] != ''
    assert isinstance(platform_facts['python_version'], basestring) and platform_facts['python_version']

# Generated at 2022-06-23 01:35:22.741181
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == {'system', 'kernel', 'kernel_version', 'machine',
                             'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:35:34.788584
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Create a mock object for the module argument.
    # The mock object will record calls to methods of the module object.
    mod_mock = MagicMock()

    # Set up side effects for mocked methods.
    # When get_bin_path is called, it returns values according to the dict
    # bootinfo.  This allows us to test that the correct get_bin_path is used
    # with the correct argument.
    # This side_effect is set on the get_bin_path.return_value attribute,
    # which is the return value of get_bin_path.
    mod_mock.get_bin_path.return_value.side_effect = {
        ("getconf",): "/path/getconf",
        ("bootinfo",): "/path/bootinfo",
    }

    # Set up side effects for mocked methods.
   

# Generated at 2022-06-23 01:35:35.956949
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:35:37.735130
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Unit test for constructor of class PlatformFactCollector"""
    platform_obj = PlatformFactCollector()
    assert platform_obj.name == "platform"

# Generated at 2022-06-23 01:35:44.134152
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:35:49.578169
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    facts = pf.collect()
    assert isinstance(facts, dict)
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'architecture' in facts
    assert 'fqdn' in facts
    assert 'nodename' in facts
    assert 'domain' in facts
    assert 'hostname' in facts
    assert 'python_version' in facts

# Generated at 2022-06-23 01:35:59.998141
# Unit test for constructor of class PlatformFactCollector

# Generated at 2022-06-23 01:36:06.512371
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """This is to test the constructor of class PlatformFactCollector
    """
    facts_aggregator = PlatformFactCollector()
    assert facts_aggregator.name == 'platform'
    assert facts_aggregator._fact_ids == set(['system',
                                              'kernel',
                                              'kernel_version',
                                              'machine',
                                              'python_version',
                                              'architecture',
                                              'machine_id'])

# Generated at 2022-06-23 01:36:15.730797
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    with patch('platform.system') as mock_system, patch('platform.release') as mock_release, \
         patch('platform.version') as mock_version, patch('platform.machine') as mock_machine, \
         patch('platform.python_version') as mock_python_version, patch('platform.uname') as mock_uname, \
         patch('ansible.module_utils.facts.collector.get_file_content') as mock_get_file_content, \
         patch('ansible.module_utils.facts.utils.get_file_content') as mock_get_file_content, \
         patch('socket.getfqdn') as mock_getfqdn:

        mock_system.return_value = "Linux"
        mock_release.return_value = "4.4.4"

# Generated at 2022-06-23 01:36:21.807947
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Construct a PlatformFactCollector object and call collect on it
    x = PlatformFactCollector()
    platform_facts = x.collect()

    # Test some results
    assert 'system' in platform_facts
    assert 'os_family' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'distribution' in platform_facts
    assert 'distribution_version' in platfor

# Generated at 2022-06-23 01:36:26.253591
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert 'platform' == PlatformFactCollector().name
    assert set([platform_fact.name for platform_fact in PlatformFactCollector().fact_classes]) == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:36:30.309764
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'
    assert pf._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'architecture'])

# Generated at 2022-06-23 01:36:35.513401
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fa = PlatformFactCollector()
    assert type(fa) == PlatformFactCollector
    assert type(fa.collect()) == dict
    expected_keys = ['system', 'kernel', 'kernel_version', 'machine',
                     'python_version', 'architecture', 'machine_id']
    for key in expected_keys:
        assert key in fa.collect()

# Generated at 2022-06-23 01:36:42.201019
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a PlatformFactCollector instance
    collector = PlatformFactCollector()

    # Test with a module and a dummy collected_facts
    collected_facts = {}
    module = 'TEST'
    facts = collector.collect(module, collected_facts)

# Generated at 2022-06-23 01:36:48.593877
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture'])

# Generated at 2022-06-23 01:36:49.193213
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:36:54.447867
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert p.priority == 80

# Generated at 2022-06-23 01:37:03.938842
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect({})
    assert len(platform_facts) == 9
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['architecture'] == platform.machine()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()

# Generated at 2022-06-23 01:37:10.955122
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector.collect()

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()


# Generated at 2022-06-23 01:37:16.578021
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-23 01:37:20.217340
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert plat.name == 'platform'
    assert plat._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:37:30.335107
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instantiate a new PlatformFactCollector object that inherits from BaseFactCollector
    platform_fact_collector = PlatformFactCollector()
    # Invoke the method collect with no arguments
    platform_facts = platform_fact_collector.collect()
    # Verify the method collect returns a dict object
    assert isinstance(platform_facts, dict)
    # Verify the method collect returns the expected values
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['nodename']

# Generated at 2022-06-23 01:37:37.354613
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:37:43.848588
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Patch platform.system() return a string
    platform.system = lambda: "Linux"
    # Patch platform.release() return a string
    platform.release = lambda: "Linux-release"
    # Patch platform.version() return a string
    platform.version = lambda: "Linux-version"
    # Patch platform.machine() return a string
    platform.machine = lambda: "Linux-machine"
    # Patch platform.python_version() return a string
    platform.python_version = lambda: "Linux-python_version"
    # Patch socket.getfqdn() return a string
    socket.getfqdn = lambda: "Linux-host"
    # Patch platform.node() return a string
    platform.node = lambda: "Linux-node"
    # Patch platform.architecture() return a tuple

# Generated at 2022-06-23 01:37:53.221995
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()

    hostname = "testhostname"
    nodename = "testhostname.testdomain.tld"
    fqdn = "testhostname.testdomain.tld"
    domain = "testdomain.tld"

    expected_platform_facts = {
        'architecture': platform.machine(),
        'domain': domain,
        'fqdn': fqdn,
        'kernel': platform.release(),
        'kernel_version': platform.version(),
        'machine': platform.machine(),
        'nodename': nodename,
        'python_version': platform.python_version(),
        'system': platform.system()
    }

    expected_platform_facts['hostname'] = hostname
    expected_platform_facts['userspace_bits'] = platform.architect

# Generated at 2022-06-23 01:37:53.914733
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:37:56.863356
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.name == "platform"
    assert platform.collect() is not None


# Generated at 2022-06-23 01:38:02.591405
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector
    platform_facts_collector = FactsCollector()
    platform_facts = platform_facts_collector.get_facts()
    assert platform_facts['system'] is not None
    assert platform_facts['kernel'] is not None
    assert platform_facts['kernel_version'] is not None
    assert platform_facts['architecture'] is not None
    assert platform_facts['nodename'] is not None

# Generated at 2022-06-23 01:38:08.843916
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:38:14.399290
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert sorted(platform_fact_collector._fact_ids) == sorted(['system',
                                                                'kernel',
                                                                'kernel_version',
                                                                'machine',
                                                                'python_version',
                                                                'architecture',
                                                                'machine_id'])


# Generated at 2022-06-23 01:38:17.374681
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()

    assert plat.name == 'platform'
    assert plat.collect()
    assert plat.collect({})
    assert plat.collect({}, {})

# Generated at 2022-06-23 01:38:23.391907
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule(object):
        def run_command(name, args):
            return (0, '64', '')
        def get_bin_path(name):
            return True

    mock_module = MockModule()
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(module=mock_module)

    assert platform_facts['userspace_bits'] == '64'

# Generated at 2022-06-23 01:38:34.105722
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    a = PlatformFactCollector()
    expected_system_facts = {}

    # i386
    # different values on different platforms
    expected_system_facts['architecture'] = {
        'Linux': 'i386',
        'FreeBSD': 'i386',
        'Darwin': 'i386',
        'SunOS': 'i386',
        'AIX': 'powerpcle',
    }
    # powerpc
    # different values on Darwin
    expected_system_facts['architecture'] = {
        'Linux': 'powerpc',
        'FreeBSD': 'powerpc',
        'SunOS': 'powerpc',
        'AIX': 'powerpcle',
    }
    # x86_64

# Generated at 2022-06-23 01:38:42.046690
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    This tests the collect method of PlatformFactCollector against nrf51 targets.
    '''
    # Import dependencies
    import platform
    import socket
    import re
    import os
    import os.path

    # TODO: This setup is a bit awkward, find a better way of testing
    # We need a class object and an instance object for
    # get_file_content function to work

    class Module(object):
        class run_command(object):
            def __init__(self, data):
                self.data = data
            def __call__(self, command):
                if command[0] == '/usr/sbin/bootinfo':
                    return (0, '64-bit\n', '')

# Generated at 2022-06-23 01:38:53.410549
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = None
    p = PlatformFactCollector()
    facts = p.collect(module)
    assert facts['system'] == 'Linux'
    assert facts['machine'] == 'x86_64'
    assert facts['kernel'] == '2.6.32-431.el6.x86_64'
    assert facts['kernel_version'] == '#1 SMP Fri Nov 22 03:15:09 UTC 2013'
    assert facts['architecture'] == 'x86_64'
    assert facts['userspace_bits'] == '64'
    assert facts['python_version'] == '2.6.6'
    assert facts['fqdn'] == 'localhost.localdomain'
    assert facts['hostname'] == 'localhost'
    assert facts['nodename'] == 'localhost'

# Generated at 2022-06-23 01:38:59.957249
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = type('ansible_module', (object,), {
        "get_bin_path": lambda self, executable: "/usr/bin/{0}".format(executable)
    })
    mock_module_instance = mock_module()

    collector = PlatformFactCollector()

    collected_facts = collector.collect(mock_module_instance)

    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    assert collected_facts['machine'] == platform.machine()
    assert collected_facts['python_version'] == platform.python_version()
    assert collected_facts['fqdn'] == socket.getfqdn()

# Generated at 2022-06-23 01:39:04.414885
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:39:13.745219
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform

    # Prepare test setup
    class TestModule:
        def run_command(self, cmd, check_rc=True):
            class TestResponse:
                def __init__(self, cmd):
                    assert cmd == ['/usr/bin/bootinfo', '-p']

                    # set return code
                    self.rc = 0

                    # set out
                    self.out = '00-00-04'

                    # set err
                    self.err = ''

                def splitlines(self):
                    return self.out.splitlines()

            return TestResponse(cmd)

        def get_bin_path(self, cmd):
            return '/usr/bin/' + cmd

    class TestBaseFactCollector:
        def __init__(self, collected_facts=None):
            if collected_facts:
                self.collected_facts

# Generated at 2022-06-23 01:39:23.216889
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Returns a dictionary which can be used for comparison against
    the results of the collect method for PlatformFactCollector
    """

    return dict(
        system='Linux',
        kernel='2.6.18-238.9.1.el5',
        kernel_version='#1 SMP Tue Jan 10 18:27:01 EST 2012',
        machine='x86_64',
        userspace_bits='64',
        architecture='x86_64',
        python_version='2.7.5',
        fqdn='localhost.localdomain',
        hostname='localhost',
        nodename='localhost.localdomain',
        domain='localdomain',
    )


# Generated at 2022-06-23 01:39:31.593544
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # unit test for method collect of class PlatformFactCollector
    # set up mocks:
    platform_mock = get_mock_platform_facts()
    module_mock = get_mock_module()
    # call the function to be tested:
    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect(module=module_mock, collected_facts={})
    # check the results: