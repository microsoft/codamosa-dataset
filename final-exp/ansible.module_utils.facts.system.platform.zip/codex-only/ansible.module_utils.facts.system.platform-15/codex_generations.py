

# Generated at 2022-06-23 01:29:34.309579
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:29:42.464973
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    mock_module = basic.AnsibleModule(
        argument_spec = dict()
    )
    collected_facts = dict()
    mock_module.run_command = MagicMock(return_value=(0, "AMD64", None))
    mock_module.get_bin_path = MagicMock(return_value=None)
    fc = PlatformFactCollector(mock_module)
    platform_facts = fc.collect(mock_module, collected_facts)
    # We cannot truthfully test this collector - please see either
    # test/units/network/gather/test_default.py or
    # test/units/network/gather/test_net_tools.py.
    # I'm leaving this here as a record that this code was
    # tested, albeit unt

# Generated at 2022-06-23 01:29:47.381572
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert set(x._fact_ids) == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])


# Generated at 2022-06-23 01:29:51.467349
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    p = PlatformFactCollector()
    d = p.collect()
    assert 'system' in d
    assert 'kernel' in d
    assert 'kernel_version' in d
    assert 'architecture' in d
    assert 'machine' in d
    assert 'python_version' in d
    assert 'machine_id' not in d


# Generated at 2022-06-23 01:29:52.722962
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:30:01.669500
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import mock
    import datetime

    #
    # Set up side effects
    #

    # Return system=Linux, kernel='2.6.32',
    # kernel_version='#1 SMP Thu Nov 19 22:10:57 UTC 2009',
    # machine='i686'
    def side_effect_platform_system(this):
        return "Linux"

    def side_effect_platform_release(this):
        return "2.6.32"

    def side_effect_platform_version(this):
        return "#1 SMP Thu Nov 19 22:10:57 UTC 2009"

    def side_effect_platform_machine(this):
        return "i686"

    # Assume python 2
    def side_effect_platform_python_version(this):
        return "2.6.6"

    #

# Generated at 2022-06-23 01:30:05.586938
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    print(x.collect())


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:30:07.080847
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'

# Generated at 2022-06-23 01:30:17.364207
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts["architecture"] == platform.machine()
    if platform_facts["machine"] == 'x86_64':
        if platform_facts['userspace_bits'] == '64':
            assert platform_facts["userspace_architecture"] == 'x86_64'
        elif platform_facts['userspace_bits'] == '32':
            assert platform_facts["userspace_architecture"] == 'i386'
    elif solaris_i86_re.search(platform_facts['machine']):
        if platform_facts['userspace_bits'] == '64':
            assert platform_facts["userspace_architecture"] == 'x86_64'

# Generated at 2022-06-23 01:30:17.970256
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:30:19.814823
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'

# Generated at 2022-06-23 01:30:25.125234
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert set(platform_fact_collector._fact_ids) == set(['system',
                                                          'kernel',
                                                          'kernel_version',
                                                          'machine',
                                                          'python_version',
                                                          'architecture',
                                                          'machine_id'])


# Generated at 2022-06-23 01:30:28.424999
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == {'system',
                                                 'kernel',
                                                 'kernel_version',
                                                 'machine',
                                                 'python_version',
                                                 'architecture',
                                                 'machine_id'}

    PlatformFactCollector().collect()


# Generated at 2022-06-23 01:30:34.660204
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_raw_facts = PlatformFactCollector().collect(None)
    assert platform_raw_facts['system'] == 'Linux'
    assert platform_raw_facts['kernel']
    assert platform_raw_facts['kernel_version']
    assert platform_raw_facts['machine']
    assert platform_raw_facts['python_version']
    assert platform_raw_facts['fqdn']
    assert platform_raw_facts['nodename']
    assert platform_raw_facts['domain']
    assert platform_raw_facts['userspace_bits'] == platform.architecture()[0].replace('bit', '')

# Generated at 2022-06-23 01:30:38.798281
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.collect()
    assert 'system' in obj.collect()
    assert 'kernel' in obj.collect()
    assert 'kernel_version' in obj.collect()
    assert 'machine' in obj.collect()
    assert 'python_version' in obj.collect()
    assert 'architecture' in obj.collect()
    assert 'machine_id' in obj.collect()


# Generated at 2022-06-23 01:30:48.052438
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-23 01:30:51.251513
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    facts_dict = PlatformFactCollector().collect()
    assert 'machine' in facts_dict

# Generated at 2022-06-23 01:30:52.436626
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:30:57.587690
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    con = PlatformFactCollector()
    assert con is not None
    assert set(con._fact_ids).issubset(con._fact_ids)
    assert con.name == 'platform'

    platform_facts = con.collect()
    assert platform_facts is not None
    assert set(platform_facts.keys()).issubset(con._fact_ids)

# Generated at 2022-06-23 01:31:03.794540
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import Collector, get_collector_instance
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, "", "")
    module.params = {}
    module.get_bin_path = lambda x: x
    setattr(module, '_ansible_debug', True)
    setattr(module, '_ansible_verbosity', 3)
    module.exit_json = lambda x: x
    module.fail_json = lambda x: x

    module.params['collect_default'] = None

# Generated at 2022-06-23 01:31:05.970325
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert set(pfc.collect()) == pfc._fact_ids
    assert pfc.name == 'platform'

# Generated at 2022-06-23 01:31:17.005182
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MockAnsibleModule()
    module.run_command = MockRunCommand()
    platform_collector = PlatformFactCollector(module)

    # Calling collect
    platform_facts = platform_collector.collect()

    # Making sure that the result is what we expect

# Generated at 2022-06-23 01:31:25.814102
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def get_bin_path(foo):
        return None

    class DummyModule(object):
        def __init__(self, fail_json):
            self.fail_json = fail_json
            self.run_command_called_with = []

        def run_command(self, cmd):
            self.run_command_called_with.append(cmd)

            if cmd == [getconf_bin, 'MACHINE_ARCHITECTURE']:
                if getconf_bin:
                    return 0, "data", ""
                else:
                    return 1, "", ""
            elif cmd == [bootinfo_bin, '-p']:
                if bootinfo_bin:
                    return 0, "data", ""
                else:
                    return 1, "", ""


# Generated at 2022-06-23 01:31:32.382240
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    Unit test for constructor
    '''
    platform_fact = PlatformFactCollector()
    assert platform_fact.name == 'platform'
    assert set(platform_fact._fact_ids) == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:31:37.122272
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                                     'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:31:42.012113
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

# Generated at 2022-06-23 01:31:49.729109
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    plat_fc = PlatformFactCollector()
    _platform_facts = plat_fc.collect()

# Generated at 2022-06-23 01:31:55.226977
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    # test for class instance
    assert isinstance(fact_collector, PlatformFactCollector)
    # test for class name
    assert fact_collector.name == 'platform'
    # test for class fact_ids
    assert fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:31:59.258677
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:32:00.471181
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_collector.collect()

# Generated at 2022-06-23 01:32:03.049536
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:32:05.812571
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts

# Generated at 2022-06-23 01:32:07.033814
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'

# Generated at 2022-06-23 01:32:18.759150
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test 1 - normal run
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert "system" in platform_facts
    assert "kernel" in platform_facts
    assert "kernel_version" in platform_facts
    assert "machine" in platform_facts
    assert "fqdn" in platform_facts
    assert "hostname" in platform_facts
    assert "domain" in platform_facts
    assert "architecture" in platform_facts
    assert "machine_id" in platform_facts

    # Test 2 - get machine-id for RHEL/Debian/Ubuntu
    assert platform_facts['system'] in ['Linux', 'AIX'] or platform_facts['machine'] in ['PowerNV']
    assert len(platform_facts['machine_id']) == 32 or platform_facts

# Generated at 2022-06-23 01:32:20.708022
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x is not None


# Generated at 2022-06-23 01:32:30.032613
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Define dict of classes that exist in module
    classes = dict(PlatformFactCollector=PlatformFactCollector())

    # Create object using module method
    object = PlatformFactCollector()
    assert object is not None, "Object constructor failed"

    # Check if module attributes exist
    assert hasattr(object, '_fact_ids'), "Module has no attribute '_fact_ids'"

    # Check if classes exist
    for cls_name, cls_object in classes.items():
        assert cls_name in locals(), "Class '{}' does not exist".format(cls_name)
        assert cls_object is not None, "Class '{}' object is null".format(cls_name)

    # Check if classes can be instantiated
    for cls_name, cls_object in classes.items():
        cl

# Generated at 2022-06-23 01:32:35.952992
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        import platform
    except ImportError:
        return
    platform_facts = PlatformFactCollector().collect()
    assert isinstance(platform_facts, dict)
    assert isinstance(platform_facts['system'], str)
    assert isinstance(platform_facts['kernel'], str)
    assert isinstance(platform_facts['kernel_version'], str)
    assert isinstance(platform_facts['machine'], str)
    assert isinstance(platform_facts['architecture'], str)

# Generated at 2022-06-23 01:32:36.923940
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-23 01:32:46.284206
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:32:50.189376
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:33:00.207695
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create a temporary file for storing machine-id
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.write("a1b2c3d4e5f6g7h8i9j10k11l12m13n14\n")
    tmpfile.close()

    module_mock = AnsibleModule()
    f = PlatformFactCollector()
    # Set path for machine_id file
    f.machine_id_file_paths = [tmpfile.name]
    collected_facts = f.collect(module_mock)


# Generated at 2022-06-23 01:33:10.935499
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create mock objects
    module = MockModule()
    collected_facts = {}
    # create object under test
    pfc = PlatformFactCollector(module, collected_facts)
    # execute method under test
    result = pfc.collect()
    # verify results
    assert 'system' in result
    assert result['system'] == 'Linux'
    assert 'kernel' in result
    assert result['kernel'] == '3.13.0-65-generic'
    assert 'kernel_version' in result
    assert result['kernel_version'] == '#106-Ubuntu SMP Fri Oct 2 22:08:27 UTC 2015'
    assert 'machine' in result
    assert result['machine'] == 'x86_64'
    assert 'architecture' in result
    assert result['architecture'] == 'x86_64'

# Generated at 2022-06-23 01:33:15.926553
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert len(platform_fact_collector._fact_ids) == 8



# Generated at 2022-06-23 01:33:18.208393
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    f = PlatformFactCollector()
    assert f.name == 'platform'
    assert f._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}



# Generated at 2022-06-23 01:33:21.585586
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    dummy_module = True
    try:
        PlatformFactCollector().collect(dummy_module)
    except Exception as e:
        assert False, "Exception. %s" % e

# Generated at 2022-06-23 01:33:29.857769
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import inject_facts
    from ansible.module_utils.facts.collector import Collector

    collected_facts = Collector().collect(inject_facts({}, None))
    fact_collector = PlatformFactCollector()
    fact_collector.collect(collected_facts=collected_facts)
    assert 'Linux' == collected_facts['ansible_system']
    assert 'x86_64' == collected_facts['ansible_machine']
    assert 'Linux' == collected_facts['ansible_kernel']
    assert 'x86_64' == collected_facts['ansible_architecture']
    assert collected_facts['ansible_architecture'] == collected_facts['ansible_machine']

# Generated at 2022-06-23 01:33:40.876764
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()

    assert isinstance(platform_facts, dict)

    assert platform_facts["system"] == platform.system()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["python_version"] == platform.python_version()
    assert platform_facts["fqdn"] == socket.getfqdn()
    assert platform_facts["hostname"] == platform.node().split('.')[0]
    assert platform_facts["nodename"] == platform.node()

# Generated at 2022-06-23 01:33:46.253985
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert(pf.name == 'platform')
    assert(pf._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'})

# Unit tests for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:33:54.358375
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    import ansible.module_utils.facts.collectors.platform as platform_collector
    import platform
    import re

    module = ModuleFacts(dict(), dict())

    # set these as attributes since the module is normally a parameter to the
    # class' method
    module.get_bin_path = lambda x: None
    module.run_command = lambda x: (None, "", "")

    platforms = platform_collector.PlatformFactCollector(module=module)

    assert platforms._collect() is not None

# Generated at 2022-06-23 01:33:55.771987
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    assert pfc.collect()

# Generated at 2022-06-23 01:34:06.303288
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    platform_facts = PlatformFactCollector()

    result = platform_facts.collect(collected_facts={})
    assert isinstance(result, dict)
    assert result['system'] == platform.system()
    assert result['kernel'] == platform.release()
    assert result['kernel_version'] == platform.version()
    assert result['machine'] == platform.machine()
    assert result['architecture'] == platform.machine()
    assert result['python_version'] == platform.python_version()
    assert result['fqdn'] == socket.getfqdn()
   

# Generated at 2022-06-23 01:34:12.638923
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:34:17.759264
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'architecture' in p._fact_ids

# Generated at 2022-06-23 01:34:20.459339
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Make sure it runs at all
    collector = PlatformFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-23 01:34:28.168345
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Checks the method collect of class PlatformFactCollector
    """
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.collectors.distribution import DistributionFactCollector

    fact_collector = PlatformFactCollector()
    fact_collector.collect()
    assert fact_collector.name == "platform"

    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.collectors = [fact_collector]
    facts = ansible_fact_collector.collect(module=None, collected_facts=None)

    assert not facts["ansible_system"] is None
    assert not facts["ansible_kernel"] is None


# Generated at 2022-06-23 01:34:38.805599
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fc = PlatformFactCollector()
    result = platform_fc.collect()

    assert 'system' in result
    assert result['system'] == platform.system()
    assert 'kernel' in result
    assert result['kernel'] == platform.release()
    assert 'kernel_version' in result
    assert result['kernel_version'] == platform.version()
    assert 'machine' in result
    assert result['machine'] == platform.machine()
    assert 'python_version' in result
    assert result['python_version'] == platform.python_version()
    assert 'fqdn' in result
    assert result['fqdn'] == socket.getfqdn()
    assert 'hostname' in result
    assert result['hostname'] == platform.node().split('.')[0]
    assert 'nodename' in result
    assert result

# Generated at 2022-06-23 01:34:47.483114
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.utils import DictObject
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    # Testing constructor
    inst = PlatformFactCollector()
    assert inst.name == 'platform'
    assert inst._fact_ids == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])

    # Testing _collect_platform_dist
    # module = AnsibleModuleMock()
    module = ModuleFacts(
        dict(
            ansible_facts=dict(),
            ansible_module_args=dict()
        )
    )
    module._ans

# Generated at 2022-06-23 01:34:57.560588
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCache
    from ansible.playbook.play_context import PlayContext

    # Create the module and collector
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
    )
    module.run_command = lambda x, checksrc=False, encoding=None: (0, 'test_platform_test', '')
    module.get_bin_path = lambda x: 'test_path'

    collector = Collector()

    # Inject the collector into the cache
    fact_cache = FactCache()
    fact_cache._fact_collectors['platform'] = collector

    # Create the PlayContext
    play_context = PlayContext()

# Generated at 2022-06-23 01:35:06.717425
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    collector = PlatformFactCollector()
    facts = collector.collect(module=module)

    assert len(facts) > 0
    assert 'system' in facts
    assert facts['system'] == platform.system()
    assert 'kernel' in facts
    assert facts['kernel'] == platform.release()
    assert 'kernel_version' in facts
    assert facts['kernel_version'] == platform.version()
    assert 'machine' in facts
    assert facts['machine'] == platform.machine()
    assert 'architecture' in facts
    assert facts['architecture'] == platform.machine() or facts['architecture'] == 'i386'
    assert 'machine_id' in facts
    assert 'hostname' in facts
    assert facts['hostname'] == platform.node().split('.')[0]
   

# Generated at 2022-06-23 01:35:12.468176
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:35:16.315706
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """ test constructor/instantiation of PlatformFactCollector class """
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert hasattr(pfc, 'name')
    assert hasattr(pfc, '_fact_ids')

# Generated at 2022-06-23 01:35:25.602902
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import default_collectors

    # Create default collectors
    collectors = default_collectors
    collector = Collector(collectors)

    # Collect facts
    platform_facts = collector.collect(collect_subset='!all',
                                    collected_facts=None,
                                    module=None)['ansible_facts']

    assert platform_facts['ansible_architecture']
    assert platform_facts['ansible_distribution']
    assert platform_facts['ansible_distribution_file_parsed']
    assert platform_facts['ansible_distribution_file_path']
    assert platform_facts['ansible_distribution_file_variety']
    assert platform_facts['ansible_distribution_major_version']
   

# Generated at 2022-06-23 01:35:31.611439
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert sorted(PlatformFactCollector._fact_ids) == sorted(['system',
                                                              'kernel',
                                                              'kernel_version',
                                                              'machine',
                                                              'python_version',
                                                              'architecture',
                                                              'machine_id'])

# Generated at 2022-06-23 01:35:35.259584
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test whether the constructor works or not
    PlatformFactCollector()


# Generated at 2022-06-23 01:35:36.600567
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    tf = PlatformFactCollector()
    assert tf.name == 'platform'

# Generated at 2022-06-23 01:35:41.095990
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:35:50.611178
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]

    platform_facts['userspace_bits'] = arch_bits.replace('bit', '')
   

# Generated at 2022-06-23 01:36:00.038645
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import types

    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, arg):
            if arg == 'getconf':
                return '/usr/bin/getconf'
            elif arg == 'bootinfo':
                return '/usr/bin/bootinfo'

        def run_command(self, cmd, check_rc=True):
            if cmd == ['/usr/bin/bootinfo', '-p']:
                return 0, 'powerpc\n', ''
            elif cmd == ['/usr/bin/getconf', 'MACHINE_ARCHITECTURE']:
                return 0, 'powerpc\n', ''

    platform.machine = lambda: 's390x'
    platform.architecture = lambda: ('64bit', 'ELF')
   

# Generated at 2022-06-23 01:36:05.814388
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector_object = PlatformFactCollector()
    assert fact_collector_object.name == 'platform'
    assert fact_collector_object._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-23 01:36:13.588680
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids


# Generated at 2022-06-23 01:36:16.313161
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert len(platform_fact_collector._fact_ids) == 9

# Generated at 2022-06-23 01:36:19.393043
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()


# Generated at 2022-06-23 01:36:24.942739
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts

    module = ModuleFacts()
    facts = PlatformFactCollector().collect()

    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()


# Generated at 2022-06-23 01:36:31.885148
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test creation of object
    obj = PlatformFactCollector()
    assert obj.name == "platform"
    assert 'system' in obj._fact_ids
    assert 'kernel' in obj._fact_ids
    assert 'machine' in obj._fact_ids
    assert 'python_version' in obj._fact_ids
    assert 'architecture' in obj._fact_ids
    assert 'machine_id' in obj._fact_ids
    assert 'kernel_version' in obj._fact_ids
    assert len(obj._fact_ids) == 8

# Generated at 2022-06-23 01:36:37.626303
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    Unit test for constructor of class PlatformFactCollector
    '''
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert sorted(list(platform_fact_collector._fact_ids)) == sorted(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:36:43.203814
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # return value will be a dictionary
    platform_facts = PlatformFactCollector()

    # check for success and no errors
    assert platform_facts is not None

    # return value has to be a dictionary
    assert isinstance(platform_facts, dict)

    # check required keys (HINT: this keys should always be there)
    assert 'machine' in platform_facts
    assert 'system' in platform_facts
    assert 'python_version' in platform_facts

# Generated at 2022-06-23 01:36:53.203199
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create a fake module to pass into the platform collector
    class TestAnsibleModule():
        def __init__(self):
            self.params = {}

        def fail_json(self, **args):
            return {'failed': True, 'msg': args}

        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            return (0, "", "")


# Generated at 2022-06-23 01:36:57.051988
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert len(p.collect()) > 0
    assert isinstance(p.collect(), dict)
    assert not len(p.missing_facts) > 0
    assert isinstance(p.missing_facts, list)

# Generated at 2022-06-23 01:37:02.966560
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'fqdn',
                                            'hostname',
                                            'nodename',
                                            'domain',
                                            'userspace_bits',
                                            'userspace_architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:37:13.340133
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content

    class ModuleMock:
        def __init__(self):
            return

        def run_command(self, cmd):
            return (0, "", "")

        def get_bin_path(self, cmd):
            return "/usr/bin/" + cmd

    class PlatformMock:
        def __init__(self):
            self.system = "Linux"
            self.release = "3.13.0-74-generic"
            self.version = "#118-Ubuntu SMP Thu Dec 17 22:52:10 UTC 2015"
            self.machine = "x86_64"
            self.python

# Generated at 2022-06-23 01:37:19.322160
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system',
                                                 'kernel',
                                                 'kernel_version',
                                                 'machine',
                                                 'python_version',
                                                 'architecture',
                                                 'machine_id'}

# Generated at 2022-06-23 01:37:29.597337
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import os

    from ansible.module_utils.facts.collector import TestCollector

    # This is a testing-only function, so we can have extra requirements
    from ansible.module_utils.facts import collector

    test_collector = TestCollector()
    test_collector.collect()


# Generated at 2022-06-23 01:37:30.751633
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.collect()


# Generated at 2022-06-23 01:37:37.011056
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:37:43.673240
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:37:48.861461
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert sorted(p.collect().keys()) == ['architecture', 'domain', 'fqdn', 'hostname', 'kernel', 'kernel_version', 'machine', 'machine_id', 'nodename', 'python_version', 'system', 'userspace_architecture', 'userspace_bits']

# Generated at 2022-06-23 01:37:50.873595
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), PlatformFactCollector)


# Generated at 2022-06-23 01:38:01.197924
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Return a set of facts from the PlatformFactCollector class.
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import utils
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.platform.aix import PlatformFactCollector
    from ansible.module_utils.facts.platform.openbsd import PlatformFactCollector
    from ansible.module_utils.facts.platform.posix import PlatformFactCollector
    from ansible.module_utils.facts.platform.solaris import PlatformFactCollector

    test_instance = Collector()
    test_instance._module = utils.FakeModule()
    # Mock the get_file_content function to always return None
    test_instance._module

# Generated at 2022-06-23 01:38:05.444742
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids is not None


# Generated at 2022-06-23 01:38:09.841431
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'architecture'])

# Generated at 2022-06-23 01:38:15.172358
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fields = ".system, .kernel, .kernel_version, .machine, .python_version, .architecture, .fqdn, .hostname, .domain, .userspace_bits, .nodename"
    platform_facts = PlatformFactCollector().collect()
    # Check that each item in fields matches one key in output of method collect

# Generated at 2022-06-23 01:38:25.364241
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform as platform_module
    import socket
    import re
    from ansible.module_utils.facts import collector

    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = collector.ALL_SUBSETS

        def get_bin_path(self, *args, **kwargs):
            return

        def run_command(self, *args, **kwargs):
            return 0, 'testdata', ''

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-23 01:38:35.418444
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from . import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible.module_utils import basic

    test_case = ModuleTestCase('/does/not/exists')
    test_case.mock({"get_bin_path": lambda arg: arg})

    platform_fact_collector = PlatformFactCollector(None, test_case)

    platform_facts = platform_fact_collector.collect()

    expected_platform_fact_keys = set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])
    assert expected_platform_fact_keys == set(platform_facts.keys())

    test_case.fail_json.assert_not_called()

# Generated at 2022-06-23 01:38:38.965326
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = ansible_module_mock()
    fact_collector = PlatformFactCollector()
    fact_collector.collect(module=module)

# Generated at 2022-06-23 01:38:48.600664
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import Collector

    # prepare the mocks
    mock_platform = dict(platform.__dict__)

    # prepare the mocks' inputs
    mock_platform["python_version"] = "2.7.5"
    mock_platform["machine"] = "x86_64"
    mock_platform["release"] = "1.2.3"
    mock_platform["version"] = "3.4.5"
    mock_platform["system"] = "Linux"
    mock_platform["node"] = "ut.test"
    mock_platform["architecture"] = ("32bit", "ELF")

    # prepare the mocks' outputs

# Generated at 2022-06-23 01:38:53.255617
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert isinstance(plat, BaseFactCollector)
    assert plat.name is not None
    assert plat.name == "platform"
    assert plat._fact_ids is not None
    assert len(plat._fact_ids.intersection(plat.collect().keys())) == len(plat._fact_ids)

# Generated at 2022-06-23 01:38:59.940103
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Run the collect method of the PlatformFactCollector
    # object, using a fake module and set of facts
    pfc = PlatformFactCollector()
    facts = {}
    pfc.collect(collected_facts=facts)

    # Unset values that won't be set on all systems as we don't want to
    # hard-code them.
    unset_keys = ['fqdn', 'machine_id']
    for key in unset_keys:
        facts.pop(key, None)

    # Assert that the facts we expect to be present are present
    assert facts['system'] == 'Linux'
    assert facts['architecture'] == 'x86_64'
    assert facts['python_version']
    assert facts['userspace_bits'] == '64'
    assert facts['kernel']

# Generated at 2022-06-23 01:39:06.014049
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_collector = PlatformFactCollector()
    assert platform_facts_collector.name == 'platform'
    assert platform_facts_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-23 01:39:07.588543
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:39:15.679425
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    testPlatformFactCollector = PlatformFactCollector()
    assert testPlatformFactCollector.name == 'platform'
    assert testPlatformFactCollector._fact_ids == {'system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'}

# Generated at 2022-06-23 01:39:25.894551
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fake_module = type('', (), {})()
    fake_module.get_bin_path = lambda f: 'path_to_{}'.format(f)
    fake_module.run_command = lambda f: ('rc', 'out', 'err')
    fake_module.get_platform = lambda: 'uname'
    fake_module.get_distribution = lambda: 'distribution'
    fake_module.get_distribution_version = lambda: 'version'
    fake_module.get_distribution_release = lambda: 'release'
    fake_facts = {}

    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect(fake_module, fake_facts)

    # Input values
    assert fake_module is not None
    assert fake_facts is not None

    # Output values
   

# Generated at 2022-06-23 01:39:35.621387
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Returns a dictionary of platform facts for the given module.
    """
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    import mock
    class ModuleMock(object):
        def __init__(self):
            self.params = dict()
    module = ModuleMock()
    # test dummy output
    result_dict = dict()
    platformFactCollector = PlatformFactCollector()
    result_dict = platformFactCollector.collect(module=module)
    print(result_dict)
    assert result_dict.has_key('system')
    assert result_dict.has_key('kernel')