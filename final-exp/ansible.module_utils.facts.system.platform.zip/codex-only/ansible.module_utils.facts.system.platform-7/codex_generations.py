

# Generated at 2022-06-23 01:29:30.631296
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj



# Generated at 2022-06-23 01:29:38.541794
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector

    import platform

    class TestPlatformFactCollector(PlatformFactCollector):
        _fact_ids = set(['system',
                         'kernel',
                         'kernel_version',
                         'machine',
                         'python_version',
                         'architecture',
                         'machine_id'])

    class TestNetworkFactCollector(PlatformFactCollector):
        def __init__(self, module=None, collected_facts=None):
            pass


# Generated at 2022-06-23 01:29:44.480561
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:29:49.822215
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'system' in x._fact_ids
    assert 'kernel' in x._fact_ids
    assert 'kernel_version' in x._fact_ids
    assert 'machine' in x._fact_ids
    assert 'python_version' in x._fact_ids
    assert 'architecture' in x._fact_ids

# Generated at 2022-06-23 01:29:56.802460
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_module = type('', (object,), {'get_bin_path': lambda *a: '/bin/true'})()
    test_module.run_command = lambda *a: ('', 'amd64\n', '')
    test_collector = PlatformFactCollector(module=test_module)

    test_output = test_collector.collect()

    # The testing system must be x86_64, so this is a reasonable assertion
    assert test_output['architecture'] == 'amd64'

# Generated at 2022-06-23 01:29:57.528181
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:29:58.454705
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-23 01:30:06.952681
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platforms = ["Linux",
                 "Darwin",
                 "Java",
                 "Windows",
                 "AIX",
                 "OpenBSD"]


# Generated at 2022-06-23 01:30:11.136434
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version',
                                                     'machine', 'python_version',
                                                     'architecture', 'machine_id'])

# Generated at 2022-06-23 01:30:13.644644
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_collector = PlatformFactCollector(
        module=None,
        collected_facts=None
    )

    assert test_collector.name == 'platform'

# Generated at 2022-06-23 01:30:17.313476
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
#

# Generated at 2022-06-23 01:30:18.713216
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    foo = PlatformFactCollector()
    assert foo.name == "platform"

# Generated at 2022-06-23 01:30:23.407233
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-23 01:30:24.687835
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'

# Generated at 2022-06-23 01:30:30.250070
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # creating an instance of PlatformFactCollector()
    pfc = PlatformFactCollector()

    # dict() is used to create a new dictionary object
    fake_platform_facts = dict()

    # assigning the 'system' and 'machine' values
    fake_platform_facts['system'] = 'OpenBSD'
    fake_platform_facts['machine'] = 'amd64'

    # Assigning the return value of method collect() to fake_platform_facts
    fake_platform_facts = pfc.collect(fake_platform_facts)

    # Assert if the two values are equal
    assert fake_platform_facts['system'] == 'OpenBSD'
    assert fake_platform_facts['machine'] == 'amd64'
    return fake_platform_facts

# Generated at 2022-06-23 01:30:36.851165
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = PlatformFactCollector(module, collected_facts)
    actual_facts = fact_collector.collect()
    assert 'system' in actual_facts
    assert 'kernel' in actual_facts
    assert 'kernel_version' in actual_facts
    assert 'machine' in actual_facts
    assert 'arhitecture' in actual_facts or 'arch' in actual_facts
    assert 'python_version' in actual_facts
    assert 'fqdn' in actual_facts
    assert 'hostname' in actual_facts
    assert 'nodename' in actual_facts

test_PlatformFactCollector_collect()

# Generated at 2022-06-23 01:30:50.970515
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = type('MockModule', (), {})
    mock_module.params = {}
    mock_facts = {}
    plat_coll = PlatformFactCollector(mock_module)

    expected_results = {}
    expected_results['system'] = platform.system()
    expected_results['kernel'] = platform.release()
    expected_results['kernel_version'] = platform.version()
    expected_results['machine'] = platform.machine()

    expected_results['python_version'] = platform.python_version()

    expected_results['fqdn'] = socket.getfqdn()
    expected_results['hostname'] = platform.node().split('.')[0]
    expected_results['nodename'] = platform.node()


# Generated at 2022-06-23 01:30:56.547816
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'python_version' in platform_facts
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'architecture' in platform_facts



# Generated at 2022-06-23 01:31:06.621854
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    # Test case #1
    module = MockModule()
    platform_fact_collector = PlatformFactCollector(module=module)
    output = platform_fact_collector.collect()
    assert 'architecture' in output.keys()
    assert 'system' in output.keys()
    assert 'kernel' in output.keys()
    assert 'kernel_version' in output.keys()
    assert 'machine' in output.keys()
    assert 'python_version' in output.keys()
    assert 'domain' in output.keys()
    assert 'hostname' in output.keys()
    assert 'userspace_bits' in output.keys()
    assert 'fqdn' in output.keys()
    assert 'nodename' in output.keys

# Generated at 2022-06-23 01:31:11.504217
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert set(platform_collector._fact_ids) == set(['system', 'kernel',
                                                     'kernel_version', 'machine',
                                                     'python_version',
                                                     'architecture', 'machine_id'])

# Generated at 2022-06-23 01:31:16.265407
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:31:23.355627
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    This unit test can be configured to perform the following tests:

    - invoking the constructor with valid arguments,
    - invoking the constructor with invalid arguments,

    """
    if len(sys.argv) < 2:
        sys.exit(1)

    module_name = sys.argv[1]

    # Test construction of an object, with valid arguments
    if module_name == "valid_args":
        my_platform_fact_collector_object = PlatformFactCollector()
        print(my_platform_fact_collector_object.name)
        print(my_platform_fact_collector_object._fact_ids)
    else:
        my_platform_fact_collector_object = PlatformFactCollector(
            "invalid name",
            "invalid fact ids"
        )


# Generated at 2022-06-23 01:31:34.569540
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PLATFORM_FACTS_ARRAY = ["kernel_version", "machine_id", "python_version", "architecture", "system", "machine", "nodename", "fqdn", "kernel", "domain", "hostname", "userspace_bits", "userspace_architecture"]
    module = MockModule()
    setattr(module, 'run_command', Mock(return_value=(0, "", "")))
    setattr(module, 'get_bin_path', Mock(return_value=True))
    pc = PlatformFactCollector()
    facts = pc.collect(module=module)
    for fact in PLATFORM_FACTS_ARRAY:
        assert fact in facts

# Unit test class for PlatformFactCollector

# Generated at 2022-06-23 01:31:37.953620
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector.collect()
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['userspace_bits'] == '64'
    assert platform_facts['architecture'] == 'x86_64'

# Generated at 2022-06-23 01:31:39.269390
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name is not None

# Generated at 2022-06-23 01:31:40.442594
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:31:44.908982
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert not platform_fact_collector._platform_facts


# Generated at 2022-06-23 01:31:48.522947
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert set(pfc._fact_ids) == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])


# Generated at 2022-06-23 01:31:54.070551
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x.__class__.__name__ == 'PlatformFactCollector'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert x.collect() == {}

# Generated at 2022-06-23 01:31:55.293267
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x

# Generated at 2022-06-23 01:32:00.050964
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector() # instantiate PlatformFactCollector
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == {'system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'}

# Generated at 2022-06-23 01:32:07.915501
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {'architecture': 'armv7l',
                      'domain': '',
                      'fqdn': 'raspberrypi',
                      'hostname': 'raspberrypi',
                      'kernel': '3.18.7+',
                      'kernel_version': '#755',
                      'machine': 'armv7l',
                      'machine_id': '',
                      'nodename': 'raspberrypi',
                      'python_version': '2.7.9',
                      'system': 'Linux',
                      'userspace_architecture': 'armv7l',
                      'userspace_bits': '32',
                      'role': 'node'}
    pc = PlatformFactCollector()
    expected = pc.collect()

    assert expected == platform_facts

# vim: set et ts=4 sw=4

# Generated at 2022-06-23 01:32:19.079502
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_module = 'ansible/test_utils/modules/test_get_platform.py'
    test_system = 'Linux'
    test_kernel = '3.10.0-957.12.2.el7.x86_64'
    test_machine = 'x86_64'
    test_userspace_bits = '64'
    test_architecture = 'x86_64'

    # Create a PlatformFactCollector instance
    platform_collector = PlatformFactCollector()

    # Build the module object
    test_module_obj = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Invoke the collect method of the instance
    collected_platform_facts = platform_collector.collect(
        module=test_module_obj
    )

   

# Generated at 2022-06-23 01:32:24.137606
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:32:31.876637
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fc = PlatformFactCollector()
    platform_facts = platform_fc.collect()

    assert isinstance(platform_facts, dict)
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'machine' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-23 01:32:42.259807
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test collect method of platform
    """
    # collected_facts will contain execution results
    collected_facts = {}

    # Gather facts
    PlatformFactCollector().collect(module=None, collected_facts=collected_facts)

    assert collected_facts['system'] == 'Linux'
    assert collected_facts['kernel'] == '2.6.32-504.el6.x86_64'
    assert collected_facts['kernel_version'] == '#1 SMP Wed Oct 15 04:27:16 UTC 2014'
    assert collected_facts['machine'] == 'x86_64'
    assert collected_facts['python_version'] == '2.6.6'
    assert collected_facts['fqdn'] == 'ServerName.Example.COM'
    assert collected_facts['hostname'] == 'ServerName'
    assert collected

# Generated at 2022-06-23 01:32:46.172281
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version',
                                                   'architecture', 'machine_id'])

# Generated at 2022-06-23 01:32:49.019211
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert 'machine_id' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids

# Generated at 2022-06-23 01:32:58.093642
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})


# Generated at 2022-06-23 01:33:02.933593
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts import FakeModule

    module = FakeModule()
    pfc = PlatformFactCollector(module)

    determined_facts = pfc.collect()

    assert len(pfc._fact_ids) == len(determined_facts)

# Generated at 2022-06-23 01:33:04.614537
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.collect()

# Generated at 2022-06-23 01:33:13.796136
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Exercises the 'collect' method of PlatformFactCollector

    :return:
    """
    # Test collect when there is a /etc/machine-id file
    with open('/etc/machine-id', 'w') as f:
        f.write('abc0123456789')

# Generated at 2022-06-23 01:33:19.542457
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:33:23.347995
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == "platform"
    assert PlatformFactCollector()._fact_ids == {"system", "kernel", "kernel_version", "machine",
                                                 "python_version", "architecture", "machine_id"}

# Generated at 2022-06-23 01:33:28.605386
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_platform_fact_collector = PlatformFactCollector()
    assert test_platform_fact_collector.name == 'platform'
    assert test_platform_fact_collector._fact_ids == set(['system',
                                                           'kernel',
                                                           'kernel_version',
                                                           'machine',
                                                           'python_version',
                                                           'architecture',
                                                           'machine_id'])

# Generated at 2022-06-23 01:33:36.886002
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class PlatformCollector(PlatformFactCollector):
        def __init__(self, module=None, collected_facts=None):
            pass

    # Test with normal platform.machine value
    platform_collector = PlatformCollector()
    platform_facts = platform_collector.collect()
    assert platform_facts['architecture'] == platform.machine()

    # Test with an architecture name of a 64-bit platform.  The
    # architecture name is different than the machine name.
    platform_collector = PlatformCollector()
    platform_collector.machine = "i686"
    platform_facts = platform_collector.collect()
    if platform.machine() == "x86_64":
        assert platform_facts['architecture'] == "x86_64"

# Generated at 2022-06-23 01:33:38.697223
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'


# Generated at 2022-06-23 01:33:46.285968
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    module = AnsibleModule(argument_spec=dict())
    platform_fact_collector = PlatformFactCollector()

    result = platform_fact_collector.collect(module)
    system_facts = result['ansible_facts']
    assert system_facts['ansible_system'].lower() == platform.system().lower()
    assert system_facts['ansible_kernel'].lower() == platform.release().lower()
    assert system_facts['ansible_machine'].lower() == platform.machine().lower()
    assert system_facts['ansible_architecture'] == system_facts['ansible_machine']

from ansible.module_utils.basic import *

main()

# Generated at 2022-06-23 01:33:48.696004
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Check if required attributes are present
    assert hasattr(PlatformFactCollector, 'name')
    assert hasattr(PlatformFactCollector, '_fact_ids')

# Generated at 2022-06-23 01:33:54.114520
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    '''
    Unit test for constructor of class PlatformFactCollector
    '''
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert set(platform_facts.fact_ids) == set(['system', 'kernel', 'kernel_version',
                                                'machine', 'python_version', 'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:34:03.202361
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class PlatformFactCollectorUnderTest(PlatformFactCollector):
        # Method _get_platform_system exists only for the purpose of unit testing
        def _get_platform_system(self):
            return 'Linux'

        def _get_platform_release(self):
            return '1'

        def _get_platform_version(self):
            return '2'

        def _get_platform_machine(self):
            return 'x86_64'

        def _get_python_version(self):
            return '3'

        def _get_hostname(self):
            return 'hostname'

        def _get_domainname(self):
            return 'domainname'

        def _get_fqdn(self):
            return 'fqdn'

        def _get_node_name(self):
            return 'node'

# Generated at 2022-06-23 01:34:08.115075
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.name == 'platform'
    assert platform._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                      'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:34:13.201683
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # A bit of a hack
    module = {}
    module.run_command = lambda cmd: (0, "", "")
    module.get_bin_path = lambda name: "/bin/%s" % name
    platform_facts = PlatformFactCollector()
    platform_facts.collect(module)

# Generated at 2022-06-23 01:34:25.022019
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import platform as real_platform

    class TestAnsibleModule():
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

        def get_bin_path(self, *args, **kwargs):
            p = real_platform.system()
            return {
                "Linux": "/bin/getconf",
                "SunOS": "/usr/bin/getconf",
                "OpenBSD": "/sbin/sysctl"
            }.get(p)

        def run_command(self, args):
            p = real_platform.system()

# Generated at 2022-06-23 01:34:33.718005
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform as python_platform
    import re
    import socket
    import tempfile

    temp = tempfile.mkdtemp()

    platform_machine_id = "/var/lib/dbus/machine-id"
    platform_machine_id_temp = tempfile.mkstemp(prefix=platform_machine_id, dir=temp)
    platform_machine_id_temp_path = platform_machine_id_temp[1]

    python_platform.machine = lambda: "x86_64"
    python_platform.node = lambda: "test_node.domain"
    python_platform.release = lambda: "test_release"
    python_platform.system = lambda: "Linux"

# Generated at 2022-06-23 01:34:35.860592
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    result = collector.collect()
    assert type(result) == dict

# Generated at 2022-06-23 01:34:44.073665
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    platform_facts = PlatformFactCollector().collect()
    # Checking if fact "system" is present
    assert "system" in platform_facts

    # Checking if fact "kernel" is present
    assert "kernel" in platform_facts

    # Checking if fact "machine" is present
    assert "machine" in platform_facts

    # Checking if fact "python_version" is present
    assert "python_version" in platform_facts

    # Checking if fact "architecture" is present
    assert "architecture" in platform_facts

    # Checking if fact "machine_id" is present
    assert "machine_id" in platform_facts

# Generated at 2022-06-23 01:34:44.960566
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert 'system' in platform_fact_collector._fact_ids

# Generated at 2022-06-23 01:34:54.349652
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from . import TestCase
    from .test_utils import patch_module, load_fixture

    def get_bin_path(module, arg):
        if arg == 'getconf':
            return 'getconf'
        elif arg == 'bootinfo':
            return 'bootinfo'

    def run_command(module_self, commands, check_rc=True):
        if commands[0] == 'getconf':
            return 0, load_fixture('fixture_getconf_MACHINE_ARCHITECTURE'), ''
        elif commands[0] == 'bootinfo':
            return 0, load_fixture('fixture_bootinfo_p'), ''


# Generated at 2022-06-23 01:35:00.574801
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create fixture object
    PlatformFactCollector_obj = PlatformFactCollector()

    # run collect and get result
    result = PlatformFactCollector_obj.collect()

    # test for result
    assert type(result) is dict
    assert set(result.keys()) == PlatformFactCollector_obj._fact_ids

    # example assert for test
    assert PlatformFactCollector_obj.name == 'platform'

# Generated at 2022-06-23 01:35:10.386066
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    sys.modules["platform"] = MockPlatform()
    sys.modules["socket"] = MockSocket()
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, "system=AIX\narchitecture=powerpc\n", ""))
    mock_module.get_bin_path = Mock(return_value="/bin/getconf")
    fc = PlatformFactCollector()
    facts = fc.collect(module=mock_module)

    assert 'architecture' in facts
    assert facts['architecture'] == 'powerpc'

    mock_module.run_command.return_value = (1, "", "not found")
    fc = PlatformFactCollector()
    facts = fc.collect(module=mock_module)

# Generated at 2022-06-23 01:35:11.732741
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform = PlatformFactCollector()
    assert platform.collect()["system"] == platform.system

# Generated at 2022-06-23 01:35:22.034642
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts_collector = PlatformFactCollector()
    collected_facts = {}
    platform_facts = platform_facts_collector.collect(collected_facts)
    assert platform_facts.has_key('architecture')
    assert platform_facts.has_key('fqdn')
    assert platform_facts.has_key('hostname')
    assert platform_facts.has_key('kernel')
    assert platform_facts.has_key('kernel_version')
    assert platform_facts.has_key('machine')
    assert platform_facts.has_key('machine_id')
    assert platform_facts.has_key('nodename')
    assert platform_facts.has_key('python_version')
    assert platform_facts.has_key('system')

# Generated at 2022-06-23 01:35:31.003680
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform

    # create an instance
    pfc = PlatformFactCollector()

    # test on Linux platform
    platform.system = lambda: 'Linux'
    platform.release = lambda: '2.6.32-220.23.1.el6.x86_64'
    platform.version = lambda: '#1 SMP Wed May 16 00:01:37 BST 2012'
    platform.machine = lambda: 'x86_64'
    platform.architecture = lambda: ('64bit', 'ELF')
    platform.python_version = lambda: '2.6.6'

    platform.node = lambda: 'foo.example.org'
    socket.getfqdn = lambda: 'foo.example.org'

    result = pfc.collect()

    assert result['system'] == 'Linux'

# Generated at 2022-06-23 01:35:37.736811
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert sorted(fact_collector.fact_ids()) == sorted(['system', 'kernel', 'kernel_version', 'machine'
        , 'python_version', 'architecture', 'machine_id'])


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:35:40.369618
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    facts = PlatformFactCollector().collect({}, {})
    assert 'architecture' in facts

# Generated at 2022-06-23 01:35:50.574265
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.machine.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def run_command(self, args, **kwargs):
            return (0, args[1], None)

        def get_bin_path(self, arg):
            return "/usr/bin/%s" % arg

    m = FakeModule(ansible_python_interpreter="/usr/bin/python")
    platform_facts = PlatformFactCollector()
    results = platform_facts.collect(m, {})

# Generated at 2022-06-23 01:35:55.169331
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fc = PlatformFactCollector()
    assert PlatformFactCollector.name == 'platform'
    assert fc.name == 'platform'
    assert fc.collect()


# Generated at 2022-06-23 01:36:07.275678
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts import FactCollector

    mf = ModuleFacts(module=None)
    collector = PlatformFactCollector(mf)
    result = collector.collect()

    # as we don't execute the module in the unit test,
    # we simulate the result of the run_command method
    result['system'] = 'Linux'
    result['kernel'] = '3.14.29-hrt2-17.48.amzn1.x86_64'
    result['architecture'] = 'x86_64'
    result['nodename'] = 'ip-172-31-4-185.ec2.internal'
    result['hostname'] = 'ip-172-31-4-185'

# Generated at 2022-06-23 01:36:12.673288
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    # Define a PlatformFactCollector object
    pfc = PlatformFactCollector()
    # Assert name and _fact_ids are set correctly
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:36:16.599248
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])



# Generated at 2022-06-23 01:36:19.817490
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'system' in x.collect()

# Generated at 2022-06-23 01:36:24.782315
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == "platform"
    assert p._fact_ids == set(['system',
                                'kernel',
                                'kernel_version',
                                'machine',
                                'python_version',
                                'architecture',
                                'machine_id'])


# Generated at 2022-06-23 01:36:34.242074
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mock_module = DummyAnsibleModule()
    mock_module.run_command = MagicMock(return_value=(0, "x86_64", ""))
    pfc = PlatformFactCollector(mock_module)
    platform_facts = pfc.collect()
    assert 'machine_id' not in platform_facts
    mock_module.run_command = MagicMock(return_value=(0, "", ""))
    pfc = PlatformFactCollector(mock_module)
    platform_facts = pfc.collect()
    assert 'machine_id' not in platform_facts
    assert platform_facts['architecture'] == 'x86_64'


# Generated at 2022-06-23 01:36:34.993037
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-23 01:36:41.754614
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Test Creation of PlatformFactCollector instance, and verify it's attributes """
    pfc = PlatformFactCollector()
    assert pfc.name == "platform"

    assert "system" in pfc._fact_ids
    assert "kernel" in pfc._fact_ids
    assert "kernel_version" in pfc._fact_ids
    assert "machine" in pfc._fact_ids
    assert "python_version" in pfc._fact_ids
    assert "architecture" in pfc._fact_ids
    assert "userspace_bits" in pfc._fact_ids
    assert "userspace_architecture" in pfc._fact_ids
    assert "machine_id" in pfc._fact_ids
    assert "fqdn" in pfc._fact_ids
    assert "hostname" in pfc._fact_

# Generated at 2022-06-23 01:36:48.508204
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system', 'kernel',
                                            'kernel_version', 'machine',
                                            'python_version',
                                            'architecture', 'machine_id'])

# Generated at 2022-06-23 01:36:59.707684
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts
    assert isinstance(platform_facts, dict)
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

    try:
        platform_facts['fqdn'] == socket.getfqdn()
    except:
        pass

    assert platform_facts['hostname'] == platform_facts['nodename'].split('.')[0]

    assert platform_facts['nodename'] == platform.node()


# Generated at 2022-06-23 01:37:06.803970
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platformfactcollector = PlatformFactCollector()
    def get_bin_path(name):
        if name == 'bootinfo':
            return '/usr/bin/bootinfo'
        elif name == 'getconf':
            return '/usr/bin/getconf'
    # Platform is Linux
    def run_command(args):
        if args == ['/usr/bin/bootinfo', '-p']:
            return (0, "PowerPC\n", "")
        elif args == ['/usr/bin/getconf', 'MACHINE_ARCHITECTURE']:
            return (0, "PowerPC\n", "")
    def getfqdn():
        return "localhost.localdomain"

# Generated at 2022-06-23 01:37:10.088383
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:37:21.673935
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    m = module.params = {'gather_subset': [], 'gather_timeout': 10, 'filter': '*'}

    pfc = PlatformFactCollector(module=module)
    facts = pfc.collect(module=module)

    assert type(facts) is dict
    assert 'system' in facts
    assert facts['system']
    assert 'kernel' in facts
    assert facts['kernel']
    assert 'kernel_version' in facts
    assert facts['kernel_version']
    assert 'machine' in facts
    assert facts['machine']
    assert 'python_version' in facts
    assert facts['python_version']
    assert 'architecture' in facts
    assert facts['architecture']
    assert 'machine_id' in facts
    assert facts['machine_id']

# Generated at 2022-06-23 01:37:31.446787
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    ''' Unit test for method collect of class PlatformFactCollector '''
    # setup a module object and a fact collector object
    module = MockModule()
    fact_collector = PlatformFactCollector(module)
    # set module attributes
    setattr(module, "get_bin_path", MockGetBinPath)
    # set facts in module object
    module.facts = dict()

# Generated at 2022-06-23 01:37:37.555523
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector.fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:37:43.967366
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector

    platform_facts = PlatformFactCollector("", {}, {})

    # check if class is subclass of BaseFactCollector
    assert issubclass(PlatformFactCollector, BaseFactCollector)

    assert platform_facts._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

    platform_facts = platform_facts.collect()
    assert isinstance(platform_facts, dict)
    # platform.system() can be Linux, Darwin, Java, or Windows
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel']

# Generated at 2022-06-23 01:37:44.768749
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
  pass

# Generated at 2022-06-23 01:37:49.142466
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    o = PlatformFactCollector()
    assert o.name == 'platform'
    assert o._fact_ids == {'system',
                           'kernel',
                           'kernel_version',
                           'machine',
                           'python_version',
                           'architecture',
                           'machine_id'}



# Generated at 2022-06-23 01:37:54.296969
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    _collector = PlatformFactCollector()
    assert _collector.name == 'platform'
    assert _collector._fact_ids == set(['system', 'kernel', 'kernel_version',
                                        'machine', 'python_version',
                                        'architecture', 'machine_id'])

# Generated at 2022-06-23 01:37:59.572230
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert set(platform_collector._fact_ids) == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert isinstance(platform_collector, BaseFactCollector)
    assert platform_collector.name == 'platform'

# Generated at 2022-06-23 01:38:03.819899
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    # Case 1
    platform_fact_collector_obj = PlatformFactCollector()

    assert platform_fact_collector_obj.name == 'platform'
    assert platform_fact_collector_obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine','python_version','architecture','machine_id'])

# Generated at 2022-06-23 01:38:13.490135
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    Test the method PlatformFactCollector.collect
    '''
    from ansible.module_utils.facts import Collector
    from ansible.module_utils._text import to_bytes
    import os
    import platform

    class TestModule:
        def run_command(self, args):
            if args[0] == '/usr/bin/getconf':
                if args[1] == 'MACHINE_ARCHITECTURE':
                    output = to_bytes(platform.machine() + '\n')
                    return 0, output, None
            elif args[0] == '/usr/sbin/bootinfo':
                output = to_bytes(platform.machine() + '\n')
                return 0, output, None
            else:
                output = b''
                return 0, output, None


# Generated at 2022-06-23 01:38:20.603167
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_collector = PlatformFactCollector()
    assert platform_facts_collector.name == 'platform'
    assert platform_facts_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])


# Generated at 2022-06-23 01:38:31.828540
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    fc = PlatformFactCollector()
    platform_facts = fc.collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()[0]


# Generated at 2022-06-23 01:38:34.616921
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    result = collector.collect(module=None, collected_facts=None)
    assert result is not None

# Generated at 2022-06-23 01:38:36.312123
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    fact_collector.collect()


# Generated at 2022-06-23 01:38:40.658846
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pc = PlatformFactCollector()
    mock_module = MockModule()
    facts = pc.collect(module=mock_module)
    assert facts is not None
    print(facts)


# Generated at 2022-06-23 01:38:49.754321
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:38:53.996661
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:38:56.973610
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['kernel'] == platform.release()

# Generated at 2022-06-23 01:39:05.026791
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.collector import FactsCollector

    for collector_class in collector_registry:
        if collector_class.name == 'platform':
            break
    else:
        assert False, "Cannot find PlatformFactCollector in collector_registry!"

    collector = FactsCollector(ModuleFacts())
    collector.collect(collector_class)
    fact_ids = collector.get_fact_ids()

    assert PlatformFactCollector._fact_ids.issubset(fact_ids), "ModuleFacts missing fact_ids!"

# vim: set et sw=4 ts=4:

# Generated at 2022-06-23 01:39:10.325687
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == {'system', 'kernel', 'kernel_version', 'machine',
            'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-23 01:39:17.864359
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_collector = PlatformFactCollector()

    assert test_platform_collector.collect() == {
        'architecture': platform.machine(),
        'domain': '.'.join(socket.getfqdn().split('.')[1:]),
        'fqdn': socket.getfqdn(),
        'hostname': platform.node().split('.')[0],
        'kernel': platform.release(),
        'kernel_version': platform.version(),
        'machine': platform.machine(),
        'nodename': platform.node(),
        'system': platform.system(),
        'python_version': platform.python_version()
    }


# Generated at 2022-06-23 01:39:26.143070
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids is not None
    assert 'system' in platform_collector._fact_ids
    assert 'kernel' in platform_collector._fact_ids
    assert 'kernel_version' in platform_collector._fact_ids
    assert 'machine' in platform_collector._fact_ids
    assert 'python_version' in platform_collector._fact_ids
    assert 'architecture' in platform_collector._fact_ids
    assert 'machine_id' in platform_collector._fact_ids

# Generated at 2022-06-23 01:39:34.960645
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])