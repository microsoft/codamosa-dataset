

# Generated at 2022-06-23 01:29:32.534710
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert plat.name == 'platform'
    assert plat._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'architecture', 'python_version', 'machine_id'])

# Generated at 2022-06-23 01:29:35.774273
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:29:38.954380
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test platform_fact_collector object is created properly
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:29:46.464814
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Return the platform facts.

    Return the platform facts.

    :return: Returns the platform facts.
    :rtype: dict
    """
    pfc = PlatformFactCollector()

    platform_facts = pfc.collect(None, {})

    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['python_version']
    assert platform_facts['architecture']


# Generated at 2022-06-23 01:29:55.756952
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts import Collector
    platforms = ['Linux', 'FreeBSD', 'OpenBSD', 'NetBSD', 'Darwin', 'SunOS', 'AIX']
    for platform in platforms:
        c = Collector('platform', platform)
        f = c.facts.get('platform')
        assert f is not None, c.facts
        assert isinstance(f, dict)
        assert 'system' in f
        assert 'kernel' in f
        assert 'kernel_version' in f
        assert 'machine' in f
        assert 'python_version' in f
        assert 'architecture' in f
        assert 'userspace_bits' in f
        assert 'userspace_architecture' in f
        assert 'machine_id' in f
        assert 'fqdn' in f

# Generated at 2022-06-23 01:30:05.408468
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import os
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary):
            return '/bin/' + binary

        def run_command(self, cmd):
            return (0, '', '')

    m = MockModule()
    p = PlatformFactCollector(m)
    f = p.collect(m)

    # Check all expected keys are present
    assert f['system'] == platform.system()
    assert f['kernel'] == platform.release()
    assert f['kernel_version'] == platform.version()
    assert f['machine'] == platform.machine()
    assert f['python_version'] == platform.python_version()


# Generated at 2022-06-23 01:30:10.173451
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert set(obj._fact_ids) == set(['system', 'kernel', 'kernel_version', 'machine',
                                      'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:30:15.288708
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    o = PlatformFactCollector(None)
    assert o.name == 'platform'
    assert o._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Unit test to check the PlatformFactCollector.collect() against invalid and valid inputs

# Generated at 2022-06-23 01:30:25.448999
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes

    PC = PlatformFactCollector
    facts_dict = FactCollector().collect(module=None, collected_facts=None)

    assert PC.collect()['python_version'] == platform.python_version()

    if platform.uname()[0] == 'SunOS':
        assert solaris_i86_re.search(PC.collect()['machine'])
        assert 'i386' == PC.collect()['architecture']
        assert 'i386' == PC.collect()['userspace_architecture']
    elif platform.uname()[0] == 'AIX':
        assert 'power' in PC.collect()['architecture']

# Generated at 2022-06-23 01:30:36.421286
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    # Empty 'module' object needed for some of the tests
    class Module():
        def get_bin_path(self, arg):
            return None
        def run_command(self, args):
            return None, '', ''
    # Should return a dict containing the following keys
    expected_keys = set(['system',
                         'kernel',
                         'kernel_version',
                         'machine',
                         'python_version',
                         'architecture',
                         'machine_id'])
    # Test that it returns the right dict with the right keys
    assert(set(pfc.collect(Module()).keys()) == expected_keys)
    # Test that the fqdn and hostname keys contain the right values

# Generated at 2022-06-23 01:30:39.498142
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = {}
    obj = PlatformFactCollector()
    platform_facts = obj.collect()
    assert 'system' in platform_facts

# Generated at 2022-06-23 01:30:49.845411
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformfactcollector = PlatformFactCollector()
    assert platformfactcollector.name == "platform"
    assert 'system' in platformfactcollector._fact_ids
    assert 'kernel' in platformfactcollector._fact_ids
    assert 'kernel_version' in platformfactcollector._fact_ids
    assert 'machine' in platformfactcollector._fact_ids
    assert 'python_version' in platformfactcollector._fact_ids
    assert 'architecture' in platformfactcollector._fact_ids
    assert 'machine_id' in platformfactcollector._fact_ids



# Generated at 2022-06-23 01:30:55.212141
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()

    assert p.name == 'platform'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:30:59.672271
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version',
                                 'machine', 'python_version', 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:31:01.513889
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == "platform"


# Generated at 2022-06-23 01:31:06.616887
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:31:15.743554
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    # Perform basic sanity checks on method collect of class PlatformFactCollector
    collect_mock = get_collector_instance('platform').collect()
    assert type(collect_mock) is dict
    assert 'system' in collect_mock
    assert 'kernel' in collect_mock
    assert 'kernel_version' in collect_mock
    assert 'machine' in collect_mock
    assert 'python_version' in collect_mock
    assert 'architecture' in collect_mock
    assert 'machine_id' in collect_mock

# Generated at 2022-06-23 01:31:19.535483
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()

    p = PlatformFactCollector()

    facts = p.collect(module)

    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'python_version' in facts
    assert 'architecture' in facts



# Generated at 2022-06-23 01:31:29.784920
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    inv = {}
    pfc = PlatformFactCollector()
    machine_id = get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")
    if machine_id:
        machine_id = machine_id.splitlines()[0]

# Generated at 2022-06-23 01:31:35.863918
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert set(pfc._fact_ids) == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])
    assert pfc.name == 'platform'

# Generated at 2022-06-23 01:31:39.127600
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector(None, None)
    assert x.name == 'platform'
    assert hasattr(x, 'collect') and callable(getattr(x, 'collect'))
    assert x.collect()


# Generated at 2022-06-23 01:31:41.488790
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts

    platform = PlatformFactCollector()
    module = ModuleFacts()
    platform_facts = platform.collect(module)
    assert type(platform_facts) == dict

# Generated at 2022-06-23 01:31:43.833898
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_PlatformFactCollector = PlatformFactCollector()
    test_PlatformFactCollector.collect()
    assert test_PlatformFactCollector.collect()['system'] == 'Linux'

# Generated at 2022-06-23 01:31:48.081335
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'architecture' in platform_facts

# Generated at 2022-06-23 01:31:53.098674
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert platform_obj.name == "platform"
    assert platform_obj._fact_ids == set(['system',
                                          'kernel',
                                          'kernel_version',
                                          'machine',
                                          'python_version',
                                          'architecture',
                                          'machine_id'])

# Generated at 2022-06-23 01:32:02.961271
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    (os_facts, domain) = PlatformFactCollector().collect()

    assert os_facts['system'] == platform.system()
    assert os_facts['kernel'] == platform.release()
    assert os_facts['kernel_version'] == platform.version()
    assert os_facts['machine'] == platform.machine()

    assert os_facts['python_version'] == platform.python_version()

    assert socket.getfqdn() == os_facts['fqdn']
    assert platform.node().split('.')[0] == os_facts['hostname']
    assert platform.node() == os_facts['nodename']

    assert '.'.join(os_facts['fqdn'].split('.')[1:]) == os_facts['domain']

    arch_bits = platform.architecture()[0]

    assert arch_

# Generated at 2022-06-23 01:32:09.325944
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fc = PlatformFactCollector()
    assert platform_fc.name == 'platform'
    assert platform_fc._fact_ids == set(['system',
                                         'kernel',
                                         'kernel_version',
                                         'machine',
                                         'python_version',
                                         'architecture',
                                         'machine_id'])

# Generated at 2022-06-23 01:32:11.772245
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    my_collector = PlatformFactCollector()
    assert my_collector.name == "platform"
    assert len(my_collector.collect()) == 11

# Generated at 2022-06-23 01:32:20.435548
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    instance = PlatformFactCollector()
    result = instance.collect()

    assert isinstance(result, dict)
    assert "system" in result
    assert "kernel" in result
    assert "kernel_version" in result
    assert "machine" in result
    assert "python_version" in result
    assert "fqdn" in result
    assert "hostname" in result
    assert "nodename" in result
    assert "domain" in result
    assert "userspace_bits" in result
    assert "architecture" in result
    assert "userspace_architecture" in result
    assert "machine_id" in result

# Generated at 2022-06-23 01:32:25.106979
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == "platform"
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:32:36.368448
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    PlatformFactCollector.collect() Test Plan:
        - Mock platform subsystem and return known data
        - Test that get_file_content("/var/lib/dbus/machine-id") is properly called
        - Test that get_file_content("/etc/machine-id") is properly called
    """
    from ansible.module_utils.facts import collector

    class MockModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, *args, **kwargs):
            return "MOCK_BIN"
        def run_command(self, *args, **kwargs):
            return (0, "STDOUT", "STDERR")

    class MockPlatform:
        def __init__(self):
            self.system_value = "OpenBSD"
            self.machine_

# Generated at 2022-06-23 01:32:45.293319
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    plat_coll = PlatformFactCollector()
    machine = plat_coll.collect()
    assert 'system' in machine
    assert 'kernel' in machine
    assert 'kernel_version' in machine
    assert 'machine' in machine
    assert 'python_version' in machine
    assert 'architecture' in machine
    assert 'machine_id' in machine

    assert 'python_version' in machine
    assert 'fqdn' in machine
    assert 'hostname' in machine
    assert 'nodename' in machine
    assert 'domain' in machine
    assert 'userspace_bits' in machine


# Generated at 2022-06-23 01:32:53.695683
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    platform_facts = {
        'system': platform.system(),
        'kernel': platform.release(),
        'kernel_version': platform.version(),
        'machine': platform.machine(),
        'python_version': platform.python_version(),
        'fqdn': socket.getfqdn(),
        'hostname': platform.node().split('.')[0],
        'nodename': platform.node()
    }
    pfc = PlatformFactCollector()
    # Create a mock module
    class MockModule:
        def get_bin_path(self, arg):
            return '/usr/bin/' + arg
        def run_command(self, arg):
            return 0, '', ''
    module = MockModule()
    collected_facts = {}

# Generated at 2022-06-23 01:32:58.541539
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:33:08.947738
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    p = PlatformFactCollector()
    sys = platform.system()
    krel = platform.release()
    kver = platform.version()
    mach = platform.machine()
    pyver = platform.python_version()

    expected = {'system': sys,
                'kernel': krel,
                'kernel_version': kver,
                'machine': mach,
                'python_version': pyver.split(' ')[0]
                }

    def fake_platform(x):
        if x == 'system':
            return sys
        elif x == 'release':
            return krel
        elif x == 'version':
            return kver
        elif x == 'machine':
            return mach
        elif x == 'python_version':
            return pyver

    real_platform = platform.system


# Generated at 2022-06-23 01:33:13.834902
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])



# Generated at 2022-06-23 01:33:21.397394
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts_collector = PlatformFactCollector(None)
    platform_facts = platform_facts_collector.collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['architecture'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()



# Generated at 2022-06-23 01:33:26.037489
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:33:30.906170
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-23 01:33:39.033831
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_collector = PlatformFactCollector()
    assert test_collector.name == 'platform'
    assert 'system' in test_collector._fact_ids
    assert 'kernel' in test_collector._fact_ids
    assert 'kernel_version' in test_collector._fact_ids
    assert 'machine' in test_collector._fact_ids
    assert 'python_version' in test_collector._fact_ids
    assert 'architecture' in test_collector._fact_ids
    assert 'machine_id' in test_collector._fact_ids


# Generated at 2022-06-23 01:33:42.457448
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert plat.collect()['architecture'] == platform.machine()

# Generated at 2022-06-23 01:33:48.441652
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:33:58.558094
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModUtils(object):
        class PlatformFactCollector_Mock_run_command(list):
            class MockFile(list):
                def __init__(self, *args, **kwargs):
                    pass

                def read(self):
                    return "abcd1234"

                def readlines(self):
                    return ["abcd1234"]

            def __init__(self, *args, **kwargs):
                pass

            def __call__(self, *args, **kwargs):
                return 0, "success", "none"

            def get_bin_path(self, cmd):
                return "/bin/{0}".format(cmd)

            def run_command(self, list):
                return 0, "success", "none"


# Generated at 2022-06-23 01:34:04.446145
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:34:16.034715
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform

    test_platform = platform.system()

    def create_mock_platform(platform_name):
        old_platform = platform.system
        platform.system = lambda: platform_name
        yield
        platform.system = old_platform

    def create_mock_getfqdn(fqdn_name):
        old_getfqdn = socket.getfqdn
        socket.getfqdn = lambda: fqdn_name
        yield
        socket.getfqdn = old_getfqdn

    def create_mock_uname(uname):
        old_uname = platform.uname
        platform.uname = lambda: uname
        yield
        platform.uname = old_uname


# Generated at 2022-06-23 01:34:18.405859
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert isinstance(x, PlatformFactCollector)

# Generated at 2022-06-23 01:34:26.451031
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Create a class to mock up a module object
    class Options:
        def __init__(self):
            self.module_name = 'ansible'
            self.module_args = ''
            self.become = False
            self.become_method = ''
            self.become_user = ''
            self.check_mode = False
            self.diff = False

    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False):
            self.argument_spec = argument_spec
            self.params = {}
            self.fail_json = lambda *a, **k: None

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return ""


# Generated at 2022-06-23 01:34:34.835404
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Create a mock module and verify the results of PlatformFactCollector.collect()
    """
    from ansible.module_utils.facts.collector import collect_facts
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content, get_bin_path
    from ansible.module_utils.facts import default_collectors

    # Define a mock version of the get_bin_path method to simply return the name of the executable
    def mock_get_bin_path(filename):
        return filename

    # Define a mock version of the get_file_content method to return a value based on the filename

# Generated at 2022-06-23 01:34:42.556390
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test that all properties set on the PlatformFactCollector object
    are present and of expected value when the collect method is run.

    Note: The collect method is the only method of the PlatformFactCollector
    object and it is called automatically when the object is instantiated.

    """
    platform_facts_collector_object = PlatformFactCollector()
    platform_facts = platform_facts_collector_object.collect()
    system = platform_facts.get("system")
    assert(system != None)
    assert(type(system) == str)
    kernel = platform_facts.get("kernel")
    assert(kernel != None)
    assert(type(kernel) == str)
    kernel_version = platform_facts.get("kernel_version")
    assert(kernel_version != None)
    assert(type(kernel_version) == str)


# Generated at 2022-06-23 01:34:50.046343
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.facts.collectors import which
    import sys

    class TestModule(object):
        def __init__(self):
            self._bin_path_cache = {}
            self.run_command_calls = []

        def get_bin_path(self, arg):
            if arg in self._bin_path_cache:
                return self._bin_path_cache[arg]
            rc = which(arg)
            if rc:
                self._bin_path_cache[arg] = rc
            return rc

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-23 01:34:56.306685
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


if __name__ == '__main__':
    # Unit test for constructor of class PlatformFactCollector
    test_PlatformFactCollector()

# Generated at 2022-06-23 01:35:01.512382
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:35:10.583310
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # create a mock object for module class
    mock_module = type("AnsibleModule", (object,), {})
    mock_module.run_command = lambda self, cmd: (0, "", "")
    mock_module.get_bin_path = lambda self, binary: binary

    # create a mock object for paltform class
    mock_platform = type("platform", (object,), {})
    mock_platform.architecture = lambda: ("64bit", "ELF")
    mock_platform.machine = lambda: "x86_64"
    mock_platform.node = lambda: "test-host"
    mock_platform.python_version = lambda: "3.6.6"
    mock_platform.release = lambda: "2.6.32-754.17.1.el6.x86_64"
    mock

# Generated at 2022-06-23 01:35:12.003034
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fact_collector = PlatformFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:35:14.727263
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Run collect
    p = PlatformFactCollector()
    ret = {}
    for name in p._fact_ids:
        ret[name] = name
    assert ret == p.collect()

# Generated at 2022-06-23 01:35:18.753246
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Test PlatformFactCollector constructor"""
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:35:23.019226
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:35:25.544479
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector.collect()

# Generated at 2022-06-23 01:35:27.394539
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector(None)
    assert isinstance(platform.collect(), dict)

# Generated at 2022-06-23 01:35:36.509744
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    fake_module = type('module', (object,), {
        'run_command': lambda self, args, check_rc=True: (0, args[0], ''),
        'get_bin_path': lambda self, binary, default=None: '/bin/' + binary
    })()

    fact_collector = PlatformFactCollector()

    facts = fact_collector.collect(fake_module, None)

# Generated at 2022-06-23 01:35:42.992653
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    facts_collector = PlatformFactCollector()
    assert facts_collector.name == 'platform'
    assert sorted(facts_collector._fact_ids) == sorted(['system',
                                                        'kernel',
                                                        'kernel_version',
                                                        'machine',
                                                        'python_version',
                                                        'architecture',
                                                        'machine_id'])

# Generated at 2022-06-23 01:35:48.503417
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert set(['system',
                'kernel',
                'kernel_version',
                'machine',
                'python_version',
                'architecture',
                'fqdn',
                'hostname',
                'nodename',
                'domain',
                'userspace_bits',
                'userspace_architecture',
                'machine_id']) == set(obj._fact_ids)


# Generated at 2022-06-23 01:35:55.686104
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert platformFactCollector.name == 'platform'

    assert platformFactCollector._fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id'])


# Generated at 2022-06-23 01:36:01.804507
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:36:11.968764
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    platform_facts = PlatformFactCollector.collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()

# Generated at 2022-06-23 01:36:15.469567
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect()


# Generated at 2022-06-23 01:36:16.628435
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """Test PlatformFactCollector when instantiating"""
    PlatformFactCollector()

# Generated at 2022-06-23 01:36:24.509281
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"
    platform_fact_collector_ids = platform_fact_collector._fact_ids
    platform_fact_collector_ids.remove('machine_id')
    platform_fact_collector_ids.remove('domain')
    platform_fact_collector_ids.remove('fqdn')
    platform_fact_collector_ids.remove('hostname')
    platform_fact_collector_ids.remove('nodename')
    platform_fact_collector_ids.remove('userspace_architecture')
    platform_fact_collector_ids.remove('userspace_bits')

# Generated at 2022-06-23 01:36:34.075187
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import json

    # Required for mocking
    import platform

    # Importing the module under test
    import ansible.module_utils.facts.collectors.platform as platform_collector

    # set up required mocks
    def mock_platform_system(self):
        return "Linux"
    def mock_platform_release(self):
        return "2.6.32-696.6.3.el6.x86_64"
    def mock_platform_version(self):
        return "#1 SMP Tue Sep 12 16:55:55 UTC 2017"
    def mock_platform_machine(self):
        return "x86_64"
    def mock_platform_python_version(self):
        return "2.7.5"

# Generated at 2022-06-23 01:36:41.142000
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    expected_fact_ids = set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    ])

    # Create an instance of PlatformFactCollector
    obj_pf_collector = PlatformFactCollector()

    # Compare the members of actual and expected
    assert vars(obj_pf_collector) == {'name': 'platform', '_fact_ids': expected_fact_ids}


# Generated at 2022-06-23 01:36:48.858360
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    facts_collector = PlatformFactCollector()
    # Assert name of the facts_collector
    assert facts_collector.name == "platform"
    # Assert that the facts_collector is not cached
    assert facts_collector.is_cacheable is False
    # Assert that the facts_collector has the correct list of fact_names
    assert facts_collector._fact_ids == set(['system',
                                             'kernel',
                                             'kernel_version',
                                             'machine',
                                             'python_version',
                                             'architecture',
                                             'machine_id'])

# Generated at 2022-06-23 01:36:58.920672
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector

    class CollectMockFactCollector(BaseFactCollector):
        name = 'collectmock'
        _fact_ids = set(['collectmock_id'])
        def collect(self, module=None, collected_facts=None):
            return {"collectmock_id" : "collectmock_result"}

    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.fact_collector_classes['collectmock'] = CollectMockFactCollector

    platform_fact_collector = PlatformFactCollector()
    collected_facts = {}
    platform_facts = platform_fact_collector.collect(collected_facts=collected_facts)
    assert platform_facts['system'] == platform.system

# Generated at 2022-06-23 01:36:59.406151
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:37:01.041857
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    #TODO: Need to be implemented
    pass

# Generated at 2022-06-23 01:37:08.636695
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:37:18.962727
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.six import StringIO
    import textwrap
    facts_collector = FactsCollector()
    platform_collector = facts_collector.collectors[PlatformFactCollector.name]
    fake_module = type('FakeModule', (object,), {
        'run_comman': lambda self, command: (0, "", ""),
        'get_bin_path': lambda self, command: command,
        'params': {'gather_subset': 'all'},
        'get_option': (lambda self, o: 'something'),
        'boolean': lambda self, o: True,
        'fail_json': lambda self, *args, **kwargs: None
    })()


# Generated at 2022-06-23 01:37:22.804221
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test method PlatformFactCollector.collect."""
    # create class object
    pfc = PlatformFactCollector()

    # get platform facts
    facts = pfc.collect()

    # assert that all fact_ids are present
    assert set(facts.keys()).issuperset(pfc._fact_ids)

# Generated at 2022-06-23 01:37:28.420891
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:37:36.181009
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class ModuleMock(object):

        def get_bin_path(self, path, default=None):
            return default

        def run_command(self, cmd):
            return (0, '', '')

    fake_platform = {
        'system': 'Darwin',
        'kernel': 'Darwin Kernel Version 16.7.0',
        'kernel_version': '16.7.0',
        'machine': 'x86_64',
        'python_version': '2.7.13',
        'architecture': 'x86_64'
    }
    fake_platform_keys = sorted(fake_platform.keys())

    # Forcing the platform module to return 'Darwin'
    monkeypatch.setattr(platform, 'system', lambda: 'Darwin')

# Generated at 2022-06-23 01:37:42.909820
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])


# Generated at 2022-06-23 01:37:48.406935
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == "platform"
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                 'python_version', 'architecture', 'machine_id'])

# Unit test show the constructor of class PlatformFactCollector
test_PlatformFactCollector()

# Generated at 2022-06-23 01:37:54.148217
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:37:54.637873
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:38:00.950116
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    """
    Unit test for the PlatformFactCollector class
    """
    # Create an instance of PlatformFactCollectortest
    pf = PlatformFactCollector()

    assert pf.name == 'platform'
    assert pf._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    ])

# Generated at 2022-06-23 01:38:07.053496
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Patch needed to avoid showing error message from 'platform.system()'
    def mocked_system(self):
        return 'Linux'
    platform._syscmd_uname.system = mocked_system

    fake_module = None
    fake_collector = PlatformFactCollector()
    result = fake_collector.collect(fake_module)
    assert {'domain', 'kernel', 'python_version', 'system', 'fqdn', 'kernel_version', 'hostname', 'nodename', 'machine'} <= result.keys()

# Generated at 2022-06-23 01:38:16.411142
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    result = platform_fact_collector.collect()
    for key in ['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture']:
        assert result[key], "PlatformFactCollector should return a value for key: %s" % key
    # assert result['system'] in ['Linux', 'Darwin', 'Java', 'Windows'], "PlatformFactCollector should return value for key 'system' within ['Linux', 'Darwin', 'Java', 'Windows']"
    # assert result['architecture'] in ['x86_64', 'i386', 'powerpc64', 'powerpc', 'sparc', 'ia64', 'ppc64', 'ppc', 'sparc64', 'mips64'], "PlatformFactCollector should return value

# Generated at 2022-06-23 01:38:20.213627
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert 'kernel' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'machine_id' in p._fact_ids

# Generated at 2022-06-23 01:38:31.424163
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_facts = {
         'python_version': '2.7.5',
         'machine': 'x86_64',
         'fqdn': 'ansible.test',
         'kernel': '2.6.32-431.el6.x86_64',
         'kernel_version': '#1 SMP Fri Nov 22 03:15:09 UTC 2013',
         'domain': 'test',
         'architecture': 'x86_64',
         'system': 'Linux',
         'nodename': 'ansible.test',
         'hostname': 'ansible'
    }

    pfc = PlatformFactCollector()
    assert pfc is not None

# Generated at 2022-06-23 01:38:33.892407
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    my_collector = PlatformFactCollector()
    my_collector.collect()

# Generated at 2022-06-23 01:38:39.785639
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids
    assert 'machine' in pfc._fact_ids
    assert 'python_version' in pfc._fact_ids
    assert 'architecture' in pfc._fact_ids
    assert 'machine_id' in pfc._fact_ids



# Generated at 2022-06-23 01:38:44.355975
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector =  PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])


# Generated at 2022-06-23 01:38:54.589641
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_module = type('platform_module', (object,), {'run_command':lambda self, x: (0, '', ''),
                                                          'get_bin_path':lambda s, x: True,
                                                          'get_file_content': lambda s, x: ''})
    platform_module_instance = platform_module()
    platform_fact_collector = PlatformFactCollector()

    # Test 1: AIX
    ansible_facts = {'system': 'AIX'}
    collected_facts = {'ansible_facts': ansible_facts}
    collected_facts = platform_fact_collector.collect(platform_module_instance, collected_facts)
    assert 'ansible_architecture' in collected_facts['ansible_facts']
    assert 'ansible_fqdn' in collected_

# Generated at 2022-06-23 01:38:57.462135
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'

# Generated at 2022-06-23 01:39:09.263984
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform

    platform_data = PlatformFactCollector().collect()
    #
    # Test system
    #
    assert platform.system() == platform_data['system']

    #
    # Test kernel
    #
    assert platform.release() == platform_data['kernel']

    #
    # Test kernel_version
    #
    assert platform.version() == platform_data['kernel_version']

    #
    # Test machine
    #
    assert platform.machine() == platform_data['machine']

    #
    # Test python_version
    #
    assert platform.python_version() == platform_data['python_version']

    #
    # Test fqdn and hostname
    #
    socket_fqdn = socket.getfqdn()
    hostname = socket_fqdn.split('.')[0]

# Generated at 2022-06-23 01:39:15.749866
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])

# Generated at 2022-06-23 01:39:16.752910
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:39:22.492894
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:39:33.000844
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import ansible.module_utils.facts.collectors.platform.PlatformFactCollector as PlatformFactCollector
    from ansible.module_utils.facts.utils import mock_module

    # Test if system is windows
    module = mock_module("platform")
    platform.system.return_value = "Windows"
    p = PlatformFactCollector("platform")
    p.collect(module)
    assert p.platform_facts["system"] == "Windows"

    # Test if system is Linux
    module = mock_module("platform")
    platform.system.return_value = "Linux"
    p = PlatformFactCollector("platform")
    p.collect(module)
    assert p.platform_facts["system"] == "Linux"