

# Generated at 2022-06-23 01:29:30.570479
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts_collector = PlatformFactCollector()
    assert platform_facts_collector.name == 'platform'

# Generated at 2022-06-23 01:29:34.881249
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert isinstance(pfc, PlatformFactCollector)
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:29:36.025893
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    def test():
        PlatformFactCollector()
    test()


# Generated at 2022-06-23 01:29:44.713430
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''Unit test for method collect of class PlatformFactCollector'''

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.six.moves import builtins
    collector = Collector()
    PlatformFactCollector(module=builtins, collector=collector).collect()

    platform_facts = collector.get_facts()
    assert platform_facts["system"] == platform.system()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["python_version"] == platform.python_version()

# Generated at 2022-06-23 01:29:46.260290
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.collect()

# Generated at 2022-06-23 01:29:55.466533
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    (platform_facts, _) = PlatformFactCollector().collect()
    assert platform_facts["system"] == platform.system()
    assert platform_facts["kernel"] == platform.release()
    assert platform_facts["kernel_version"] == platform.version()
    assert platform_facts["machine"] == platform.machine()
    assert platform_facts["python_version"] == platform.python_version()
    assert platform_facts["fqdn"] == socket.getfqdn()
    assert platform_facts["hostname"] == platform.node().split('.')[0]
    assert platform_facts["nodename"] == platform.node()
    assert platform_facts["domain"] == '.'.join(platform_facts["fqdn"].split('.')[1:])
    arch_bits = platform.architecture()[0]
    platform_facts

# Generated at 2022-06-23 01:30:00.294042
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:30:04.153077
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test method collect in class PlatformFactCollector
    module = "ansible.module_utils.facts.collectors.platform"
    m = __import__(module, globals(), locals(), ['PlatformFactCollector'], 0)
    platform = m.PlatformFactCollector()
    platform.collect()
# end of test_PlatformFactCollector_collect

# Generated at 2022-06-23 01:30:09.804398
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def _execute_module(*args, **kwargs):
        return 0, '/path', ''

    module = type('TestModule', (object,), dict(
        params={},
        run_command=lambda self, cmd: _execute_module(*cmd),
        get_bin_path=lambda self, name: '/path'
    ))()

    platform_facts = PlatformFactCollector().collect(module=module)
    assert set(platform_facts.keys()) == PlatformFactCollector._fact_ids

# Generated at 2022-06-23 01:30:14.920223
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert isinstance(platform_fact_collector._fact_ids, set)
    assert set(['system', 'kernel', 'kernel_version',
          'machine', 'python_version', 'architecture', 'machine_id']) == platform_fact_collector._fact_ids


# Generated at 2022-06-23 01:30:25.083496
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestPlatformFactCollector(BaseFactCollector):
        name = 'platform'
        _fact_ids = set(['system', 'kernel', 'kernel_version', 'machine'])

        def collect(self, module=None, collected_facts=None):
            return {"system": "Linux", "kernel": "2.6.32-220.2.1.el6.i686", "kernel_version": "2.6.32-220.2.1.el6.i686", "machine": "i686"}
    BaseFactCollector._instance = TestPlatformFactCollector()
    assert BaseFactCollector.get_fact('system') == "Linux"

# Generated at 2022-06-23 01:30:30.820697
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pc = PlatformFactCollector()

    uname_result = 'Linux'
    release_result = '3.14'
    version_result = '3.14'
    machine_result = 'x86_64'
    python_version_result = '2.6.6'
    fqdn_result = 'test.testdomain.com'
    hostname_result = 'test.testdomain.com'
    nodename_result = 'test'
    domain_result = 'testdomain.com'
    arch_bits_result = '64bit'
    userspace_bits_result = '64'
    userspace_architecture_result = 'x86_64'
    architecture_result = 'x86_64'
    machine_id = 'f10abcdef10abcdef10abcdef10abcde'

    platform.system

# Generated at 2022-06-23 01:30:36.891682
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc is not None
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:30:46.152158
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import re

    module = platform
    module.run_command = lambda cmd: (0, '\n'.join(platform.uname()), '')

    collector = PlatformFactCollector()
    facts = collector.collect(module=module)

    assert len(facts) == 10
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['fqdn'] == socket.getfqdn()
    assert facts['hostname'] == platform.node().split('.')[0]
    assert facts['nodename'] == platform.node()

# Generated at 2022-06-23 01:30:47.002362
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-23 01:30:48.191867
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    output = collector.collect()
    assert 'system' in output

# Generated at 2022-06-23 01:30:59.906327
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule():
        def __init__(self):
            self.run_command_result_side_effect_states = [
                { 'rc': 0, 'out': "i386", 'err': None },
                { 'rc': 0, 'out': "PowerPC_POWER7", 'err': None },
                { 'rc': 0, 'out': "mips64", 'err': None },
                { 'rc': 0, 'out': "mips64", 'err': None }
            ]
            self.run_command_result_state = self.run_command_result_side_effect_states.pop(0)

        def get_bin_path(self, command, required=False):
            return command


# Generated at 2022-06-23 01:31:11.176951
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}
    platform_facts['system'] = 'openSUSE'
    platform_facts['kernel'] = '4.4.98-34-default'
    platform_facts['kernel_version'] = '#1 SMP Mon Feb 25 18:47:23 UTC 2019'
    platform_facts['machine'] = 'x86_64'
    platform_facts['python_version'] = '2.7.5'
    platform_facts['fqdn'] = 'localhost.localdomain'
    platform_facts['hostname'] = platform_facts['fqdn'].split('.')[0]
    platform_facts['nodename'] = platform_facts['fqdn']
    platform_facts['domain'] = platform_facts['fqdn'].split('.')[0]

# Generated at 2022-06-23 01:31:20.551284
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, '', '')
    module_mock.get_bin_path.side_effect = lambda binary: binary

    # Run with empty collected facts
    collected_facts = {}
    PlatformFactCollector().collect(module=module_mock, collected_facts=collected_facts)

    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    assert collected_facts['machine'] == platform.machine()
    assert collected_facts['python_version'] == platform.python_version()
    assert collected_

# Generated at 2022-06-23 01:31:25.124466
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:31:37.010899
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket

    from ansible.module_utils.facts.collector import BaseFactCollector

    class DummyModule(object):
        def __init__(self, **kwargs):
            self.params = {
                "gather_subset": kwargs.get("gather_subset", []),
            }
            self.run_command = self.get_bin_path = lambda x: ['bin']

    def monkey_architecture(**kwargs):
        return '64bit'

    def monkey_system(**kwargs):
        return 'Linux'

    def monkey_node(**kwargs):
        return 'somehost.example.com'

    def monkey_python_version(**kwargs):
        return '2.7.12'

    def monkey_release(**kwargs):
        return

# Generated at 2022-06-23 01:31:46.158384
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector()
    platform_dict = platform.collect()

    assert platform_dict['system'] == platform.system
    assert platform_dict['kernel'] == platform.release()
    assert platform_dict['kernel_version'] == platform.version()
    assert platform_dict['machine'] == platform.machine()
    assert platform_dict['python_version'] == platform.python_version()
    assert platform_dict['fqdn'] == socket.getfqdn()
    assert platform_dict['hostname'] == platform.node().split('.')[0]
    assert platform_dict['nodename'] == platform.node()
    assert platform_dict['domain'] == '.'.join(platform_dict['fqdn'].split('.')[1:])
    arch_bits = platform.architecture()[0]
    assert platform

# Generated at 2022-06-23 01:31:53.547591
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                    'kernel',
                                                    'kernel_version',
                                                    'machine',
                                                    'python_version',
                                                    'architecture',
                                                    'machine_id'])


# Generated at 2022-06-23 01:31:55.490415
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector

    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:31:59.546075
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == \
        {'system', 'kernel', 'kernel_version', 'machine', 'python_version',
         'architecture', 'machine_id'}


# Generated at 2022-06-23 01:32:00.067499
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass

# Generated at 2022-06-23 01:32:02.985112
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    f = PlatformFactCollector()
    assert f.name == 'platform'
    assert set(f._fact_ids) == set(['system', 'kernel', 'kernel_version',
                                    'machine', 'python_version', 'architecture',
                                    'machine_id'])


# Generated at 2022-06-23 01:32:11.473306
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MagicMock()
    class_name = 'ansible.module_utils.facts.system.platform.PlatformFactCollector'
    method_name = 'collect'
    method = getattr(sys.modules[class_name], method_name)
    module.get_bin_path.return_value = "mock"
    module.run_command.return_value = 1, "mock", "mock"
    platform_facts = method(module)
    assert platform_facts['system'] == 'Linux'

# Generated at 2022-06-23 01:32:17.168973
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['architecture'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

# Generated at 2022-06-23 01:32:17.708244
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:32:27.938114
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create an instance of PlatformFactCollector
    pfc = PlatformFactCollector()

    # Patch the following methods to avoid errors
    pfc.get_file_content = lambda x: None
    pfc.get_bin_path = lambda x: None

    # Run the collect() method and store the results in the facts variable
    facts = pfc.collect()

    # Assert that the PlatformFactCollector.name matches the fact id 'system'
    assert pfc.name == 'platform'

    # Assert that the PlatformFactCollector.name is 'system'
    assert facts['system'] == platform.system()

    # Assert that the PlatformFactCollector.name is 'kernel'
    assert facts['kernel'] == platform.release()

    # Assert that the PlatformFactCollector.name is 'kernel_version'

# Generated at 2022-06-23 01:32:37.175342
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect()
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'architecture' in platform_facts
    assert 'python_version' in platform_facts
    assert 'nodename' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'domain' in platform_facts
    assert 'hostname' in platform_facts
    assert len(platform_facts['system']) > 0
    assert len(platform_facts['kernel']) > 0
    assert len(platform_facts['kernel_version']) > 0

# Generated at 2022-06-23 01:32:48.204198
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # create a mock module object
    class MockModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg, required=False):
            if arg == "getconf":
                if self.params['get_bin_path_getconf'] is None:
                    return None
                else:
                    return self.params['get_bin_path_getconf']
            elif arg == "bootinfo":
                if self.params['get_bin_path_bootinfo'] is None:
                    return None
                else:
                    return self.params['get_bin_path_bootinfo']

        def run_command(self, cmd):
            if cmd[0] == "/usr/bin/getconf":
                return (0, "/usr/bin/getconf\n", None)


# Generated at 2022-06-23 01:32:50.525444
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # TODO: define collect method and write unit test for it
    pass

# Generated at 2022-06-23 01:32:59.036634
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Try some typical platform.system() values
    for sys in ['Linux', 'Darwin', 'Java', 'Windows']:
        pfc = PlatformFactCollector(None, {}, {})
        pfc.platform = MockPlatform(system=sys)
        pfc.socket = MockSocket()
        res = pfc.collect()
        assert res['system'] == sys
        assert res['kernel'] == '2.6.18-274.7.1.el5.028stab070.3'
        assert res['kernel_version'] == 'mock_kernel_version'
        assert res['machine'] == 'x86_64'
        assert res['python_version'] == '2.7.5'
        assert res['architecture'] == 'x86_64'

# Generated at 2022-06-23 01:33:10.216170
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class DummyModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, binary_name):
            return binary_name
        def run_command(self, cmd):
            return 1, '', ''
    pfc = PlatformFactCollector()
    pfc_facts = pfc.collect(DummyModule())
    assert 'system' in pfc_facts
    assert 'kernel' in pfc_facts
    assert 'kernel_version' in pfc_facts
    assert 'machine' in pfc_facts
    assert 'python_version' in pfc_facts
    assert 'fqdn' in pfc_facts
    assert 'hostname' in pfc_facts
    assert 'nodename' in pfc_facts
    assert 'domain' in pfc_facts

# Generated at 2022-06-23 01:33:13.384656
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()

    assert p.name == 'platform'
    assert p._fact_ids == {'system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'}

# Generated at 2022-06-23 01:33:15.820331
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc
    assert pfc.name == 'platform'

# Generated at 2022-06-23 01:33:19.464485
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_collector = PlatformFactCollector()
    assert test_collector.name == 'platform'
    assert isinstance(test_collector._fact_ids, set)
    assert test_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:33:24.014228
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:33:26.429991
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    x = PlatformFactCollector()
    print(x.collect())

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-23 01:33:27.391429
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:33:35.574398
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test with two different objects to make sure that the name and _fact_ids
    # are not being shared between instances.

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['architecture',
                                                     'domain',
                                                     'fqdn',
                                                     'hostname',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'nodename',
                                                     'python_version',
                                                     'system',
                                                     'userspace_architecture',
                                                     'userspace_bits',
                                                     'machine_id'])

# Generated at 2022-06-23 01:33:40.061940
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:33:43.370102
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert len(p._fact_ids) == 8


# Generated at 2022-06-23 01:33:48.125742
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pFactCollector = PlatformFactCollector()

    assert pFactCollector.name == 'platform'
    assert pFactCollector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:33:58.296669
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts import utils
    import platform
    import socket
    import re

    class MockModule:
        def __init__(self):
            self._platform = platform
            self._socket = socket
            self._re = re
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            return (0, "", "")

        def get_platform(self):
            return self._platform

        def get_socket(self):
            return self._socket

        def get_re(self):
            return self._re
            

# Generated at 2022-06-23 01:34:03.848991
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    ansible_module = MockModule()
    platform = PlatformFactCollector(ansible_module)

    assert platform.name == 'platform'
    assert platform._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:34:14.632420
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.exit_json = lambda d: None

        def get_bin_path(self, name):
            if name == "getconf":
                return '/usr/bin/getconf'
            elif name == "bootinfo":
                return '/usr/sbin/bootinfo'
            elif name == "uname":
                return '/usr/bin/uname'
            else:
                return None

        def run_command(self, cmd):
            if '/usr/sbin/bootinfo' in cmd:
                return 0, "PowerPC_POWER8", None
            elif '/usr/bin/getconf' in cmd:
                return 0, "PowerPC_POWER8", None
            elif '/usr/bin/uname' in cmd:
                return

# Generated at 2022-06-23 01:34:20.364548
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    test_platform = PlatformFactCollector()

    assert test_platform.name == 'platform'

    assert 'system' in test_platform._fact_ids
    assert 'kernel' in test_platform._fact_ids
    assert 'kernel_version' in test_platform._fact_ids
    assert 'machine' in test_platform._fact_ids
    assert 'python_version' in test_platform._fact_ids
    assert 'architecture' in test_platform._fact_ids

    assert not hasattr(test_platform, 'collect')

# Generated at 2022-06-23 01:34:21.943551
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector


# Generated at 2022-06-23 01:34:25.696026
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test PlatformFactCollector.collect()
    """
    class MockModule(object):
        def __init__(self, params=None):
            self.params = params

        def get_bin_path(self, _):
            return None

    platform_collector = PlatformFactCollector()

    assert platform_collector.collect(MockModule())

# Generated at 2022-06-23 01:34:33.972471
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_class = PlatformFactCollector()
    collected_facts = test_class.collect()
    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    assert collected_facts['machine'] == platform.machine()
    assert collected_facts['python_version'] == platform.python_version()
    assert collected_facts['fqdn'] == socket.getfqdn()
    assert collected_facts['hostname'] == platform.node().split('.')[0]
    assert collected_facts['nodename'] == platform.node()
    assert collected_facts['domain'] == '.'.join(collected_facts['fqdn'].split('.')[1:])

# Generated at 2022-06-23 01:34:37.924607
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:34:46.842563
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class MockModule(object):
        def __init__(self, name, **kwargs):
            self.name = name
            self.files = ["/var/lib/dbus/machine-id", "/etc/machine-id"]
            self.params = dict()

        def get_bin_path(self, name):
            return None

        def run_command(self, cmd):
            rc = 0
            out = ""
            err = ""
            if cmd[0] == 'bootinfo':
                rc = 0
                out = "powerpc"
                err = ""
            elif cmd[0] == 'getconf':
                rc = 0
                out = "powerpc64"
                err = ""
            return rc, out, err

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-23 01:34:50.205779
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == "platform"
    assert PlatformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version',
                                     'machine', 'python_version', 'architecture',
                                     'machine_id'])

# Generated at 2022-06-23 01:34:51.408393
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_obj = PlatformFactCollector()
    assert platform_obj.name == 'platform'

# Generated at 2022-06-23 01:34:55.868326
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Generates a set of facts from the platform, that is, things like the system
    architecture and distribution name.
    """
    platform_facts = PlatformFactCollector()
    assert platform_facts.collect(None, None) is not None

# Generated at 2022-06-23 01:35:04.379962
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector
    PlatformFactCollector._load_platform_subclass = Mock(return_value=None)
    PlatformFactCollector.get_file_content = Mock(return_value='')
    PlatformFactCollector.get_bin_path = Mock(return_value='/sbin/getconf')

    module = Mock()
    module.run_command = Mock(return_value=(0, 'x86_64', ''))

    platform_facts = PlatformFactCollector.collect(module=module)
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['architecture'] == 'x86_64'

# Generated at 2022-06-23 01:35:07.683708
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:35:13.935089
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import json
    import sys
    path = sys.path[0]
    if not path:
        path = '.'
    input_file = path + '/ansible/module_utils/facts/collector/platform.json'
    collected_facts = json.load(open(input_file))
    PlatformFactCollector().collect(collected_facts=collected_facts)
    #print('collected_facts =', collected_facts)

# Generated at 2022-06-23 01:35:18.881807
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == "platform"
    assert set(pfc._fact_ids) == set(['system',
                                      'kernel',
                                      'kernel_version',
                                      'machine',
                                      'python_version',
                                      'architecture',
                                      'machine_id'])

# Generated at 2022-06-23 01:35:25.451208
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible import constants as C
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import get_facts

    C.HOSTVARS_FILE = None

    platform_facter = PlatformFactCollector()
    Collector._instance = platform_facter

    platform_facts = platform_facter.collect()
    assert platform_facts is not None
    assert len(platform_facts.keys()) > 0

    ansible_facts = get_facts()
    assert len(ansible_facts.keys()) > 0

# Generated at 2022-06-23 01:35:29.343132
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformCollector = PlatformFactCollector()
    collected_facts = PlatformCollector.collect()

    assert collected_facts['system'] == 'Linux'
    assert len(collected_facts['kernel']) > 0
    assert collected_facts['machine'] == 'x86_64'
    assert collected_facts['python_version'] == '2.7.5'

# Generated at 2022-06-23 01:35:34.541186
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['fqdn']
    assert platform_facts['hostname']
    assert platform_facts['nodename']
    assert platform_facts['domain']
    assert platform_facts['userspace_bits']
    assert platform_facts['architecture']
    assert platform_facts['machine']
    assert platform_facts['python_version']
    assert platform_facts['kernel_version']

# Generated at 2022-06-23 01:35:42.888422
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    import socket

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **args):
            raise Exception(args)

        def get_bin_path(self, path, opts=None, required=False):
            return "/sbin/" + path

        def run_command(self, args):
            return 0, "", ""

    class MockSocket(object):
        def __init__(self):
            self.fqdn = "mockfqdn"

        def getfqdn(self):
            return self.fqdn


# Generated at 2022-06-23 01:35:46.186839
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:35:50.763751
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == "platform"
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-23 01:35:57.122072
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    # test for class PlatformFactCollector
    assert hasattr(collector, 'collect')
    # test for basic functionality
    assert collector.collect().keys() == {'system', 'kernel', 'kernel_version',
                                          'machine', 'python_version',
                                          'architecture', 'machine_id'}


# Generated at 2022-06-23 01:36:08.157280
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.platform.platform import PlatformFactCollector
    from ansible.module_utils.facts.collectors.platform.distribution import DistributionFactCollector

    # Subclass of the superclass Collector
    assert issubclass(PlatformFactCollector, Collector)

    # Instance of PlatformFactCollector
    s = PlatformFactCollector()

    # Class variables
    assert s.name == 'platform'
    assert s._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

    assert platform.system() == 'Linux'

# Generated at 2022-06-23 01:36:16.875169
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test method collect of PlatformFactCollector

    :return:
    """
    from mock import patch, Mock
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors

    platform_collector = PlatformFactCollector()
    facts_collector = FactsCollector()
    facts_collector.collectors = default_collectors.copy()
    facts_collector.collectors[platform_collector.name] = platform_collector
    module_mock = Mock()
    module_mock.get_bin_path = Mock()
    module_mock.run_command.return_value = (0, "", "")
    platform_collector.collect(module_mock)

# Generated at 2022-06-23 01:36:21.511948
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture'])

# Generated at 2022-06-23 01:36:32.635234
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()

    # Test method on Linux
    setattr(platform, 'system', lambda: "Linux")
    setattr(platform, 'release', lambda: "fedora")
    setattr(platform, 'version', lambda: "fedora")
    setattr(platform, 'machine', lambda: "fedora")
    setattr(platform, 'python_version', lambda: "fedora")
    setattr(platform, 'architecture', lambda: "fedora")
    setattr(platform, 'uname', lambda: [])

    test_data = collector.collect()
    assert test_data['system'] == 'Linux'
    assert test_data['nodename'] == 'fedora'
    assert test_data['kernel_version'] == 'fedora'
    assert test_data['machine'] == 'fedora'


# Generated at 2022-06-23 01:36:40.203063
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector
    collected_platform_facts = platform_fact_collector.collect()
    assert type(collected_platform_facts) is dict
    assert "system" in collected_platform_facts
    assert "kernel" in collected_platform_facts
    assert "kernel_version" in collected_platform_facts
    assert "machine" in collected_platform_facts
    assert "python_version" in collected_platform_facts
    assert "architecture" in collected_platform_facts
    assert "machine_id" in collected_platform_facts

# Generated at 2022-06-23 01:36:43.889485
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:36:52.412433
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector({})
    platform_facts = platform_fact_collector.collect()
    assert type(platform_facts) == dict
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'architecture' in platform_facts
    assert 'python_version' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'hostname' in platform_facts
    assert 'domain' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-23 01:37:02.941687
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import sys
    import os

    class MockPlatform:
        system = 'AIX'
        release = '9.9'
        version = '9999'
        machine = 'powerpc'
        python_version = '3.4'
        architecture = '64bit'
        uname = ()

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '{0}/bin/{1}'.format(os.getcwd(), name)

        def run_command(self, command):
            return 0, '', ''

    old_platform = sys.modules['platform']
    sys.modules['platform'] = MockPlatform()

    mock_module = MockModule()
    fact_collector = PlatformFactCollector()
   

# Generated at 2022-06-23 01:37:08.831514
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])

# Generated at 2022-06-23 01:37:11.304223
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'

# Generated at 2022-06-23 01:37:16.128064
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    metaclass_obj = type("TestPlatformFactCollector", (PlatformFactCollector,) , {})
    assert set(PlatformFactCollector._fact_ids) == set(metaclass_obj._fact_ids)
    assert PlatformFactCollector.name == 'platform'

# Generated at 2022-06-23 01:37:26.950516
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts
    from ansible.module_utils.facts import collector

    # Construct a mock module
    class TestModule(object):
        def get_bin_path(self, arg1):
            return
        def run_command(self, arg1):
            return

    test_module = TestModule()
    test_collector = PlatformFactCollector(test_module)
    result = test_collector.collect()

    # Verify the result
    assert result.get("system") == platform.system()
    assert result.get("kernel") == platform.release()
    assert result.get("kernel_version") == platform.version()

# Generated at 2022-06-23 01:37:30.833163
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    my_obj = PlatformFactCollector()
    assert my_obj.name == 'platform'
    assert my_obj._fact_ids == set(['system',
                                    'kernel',
                                    'kernel_version',
                                    'machine',
                                    'python_version',
                                    'architecture',
                                    'machine_id'])

# Generated at 2022-06-23 01:37:43.856285
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import re

    class MockModule(object):
        def __init__(self):
            self.params = None
            self.fail_json = None

        def run_command(self, command):
            return (0, "", "")

        def get_bin_path(self, binary):
            return "/bin/%s" % (binary)


# Generated at 2022-06-23 01:37:53.222221
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def get_bin_path(name):
        if b'getconf' == name and b'AIX' == platform.system().encode('utf-8'):
            return '/usr/bin/getconf'
        if b'bootinfo' == name and b'AIX' == platform.system().encode('utf-8'):
            return '/usr/sbin/bootinfo'

    module = type('FakeModule', (object,), {'run_command': lambda *args, **kw: (0, '', ''), 'get_bin_path': get_bin_path})
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(module)
    assert platform_facts['architecture'] == platform.machine()
    assert platform_facts['system'] == platform.system()


# Generated at 2022-06-23 01:37:57.908211
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect = collect

    # create fake module
    fake_module = type('', (), {})
    fake_module.run_command = run_command
    fake_module.get_bin_path = get_bin_path
    fake_module.get_file_content = get_file_content

    # fake data
    fake_platform_uname = ['Linux', 'fake_node', '3.16.0-5-amd64', '#1 Debian 3.16.51-3', 'x86_64']
    fake_get_file_content = "/var/lib/dbus/machine-id"
    fake_get_bin_path = "/usr/bin"
    fake_run_command_aix = ['bootinfo', '-p']

# Generated at 2022-06-23 01:37:59.189952
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'

# Generated at 2022-06-23 01:38:05.966134
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    x = PlatformFactCollector()

    assert x
    assert x.name == 'platform'

    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

    # Ensure we have a SOLARIS_I86_RE_PATTERN
    assert SOLARIS_I86_RE_PATTERN
    assert solaris_i86_re.search('i86pc')

# Generated at 2022-06-23 01:38:10.423482
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    fact_ids = set(['system',
                    'kernel',
                    'kernel_version',
                    'machine',
                    'python_version',
                    'architecture',
                    'machine_id'])
    assert pfc._fact_ids == fact_ids

# Generated at 2022-06-23 01:38:21.425113
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # this class is used in place of the BaseFactCollector class
    class FakeBaseFactCollector(BaseFactCollector):
        name = 'platform'
        _fact_ids = set(['system',
                         'kernel',
                         'kernel_version',
                         'machine',
                         'python_version',
                         'architecture'])

        def _get_file_content(self, filename):
            return True

    solaris_i86_re = re.compile(SOLARIS_I86_RE_PATTERN)
    # this class is used in place of the PlatformFactCollector class

# Generated at 2022-06-23 01:38:30.627761
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    expected_result = {'machine_id': '6979dc55f0714078b8c24a306d7a781b', 'fqdn': 'test.example.com',
                       'architecture': 'x86_64', 'system': 'Linux', 'domain': 'example.com',
                       'hostname': 'test', 'kernel': '3.10.0-229.el7.x86_64',
                       'kernel_version': '#1 SMP Wed May 13 10:06:09 UTC 2015',
                       'nodename': 'test.example.com', 'python_version': '2.7.5',
                       'userspace_bits': '64', 'machine': 'x86_64',
                       'userspace_architecture': 'x86_64'}
    import platform
    import socket

# Generated at 2022-06-23 01:38:36.571727
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector(None)
    assert platform_collector.name == 'platform'
    expected_fact_ids = set(['system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'])
    assert platform_collector._fact_ids == expected_fact_ids

# Generated at 2022-06-23 01:38:38.410839
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:38:39.685830
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    fact_collector.collect(None, None)

# Generated at 2022-06-23 01:38:45.257102
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert(platform_facts['fqdn'] == socket.getfqdn())
    assert(platform_facts['nodename'] == platform.node())
    assert(platform_facts['domain'] == '.'.join(socket.getfqdn().split('.')[1:]))
    assert(platform_facts['hostname'] == platform.node().split('.')[0])
    assert(platform_facts['system'] == platform.system())
    assert(platform_facts['kernel'] == platform.release())
    assert(platform_facts['kernel_version'] == platform.version())
    assert(platform_facts['machine'] == platform.machine())
    assert(platform_facts['python_version'] == platform.python_version())

# Generated at 2022-06-23 01:38:52.754377
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, "i386", "")
    module_mock.get_bin_path.return_value = True
    platform_obj = PlatformFactCollector()
    platform_obj.collect(module=module_mock)
    cmd_run_call_args = module_mock.run_command.call_args_list
    eq_(cmd_run_call_args[0][0][0], ['getconf', 'MACHINE_ARCHITECTURE'])

# Generated at 2022-06-23 01:38:57.628661
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-23 01:39:04.782967
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids


# Generated at 2022-06-23 01:39:12.451846
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # initialize a PlatformFactCollector instance
    pfc = PlatformFactCollector()

    # check the attributes of PlatformFactCollector
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:39:16.997999
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    x = PlatformFactCollector()
    assert x.name == 'platform'

    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:39:24.251867
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert 'system' in platform_facts._fact_ids
    assert 'kernel' in platform_facts._fact_ids
    assert 'kernel_version' in platform_facts._fact_ids
    assert 'machine' in platform_facts._fact_ids
    assert 'python_version' in platform_facts._fact_ids
    assert 'architecture' in platform_facts._fact_ids
    assert 'machine_id' in platform_facts._fact_ids

# Generated at 2022-06-23 01:39:27.438991
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert len(platform_facts) >= 9

# Generated at 2022-06-23 01:39:34.621151
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert 'system' in x._fact_ids
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])