

# Generated at 2022-06-23 01:29:37.451288
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-23 01:29:47.052960
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Run a collect with a mocked module object which is usually provided by AnsibleModule
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    import ansible.module_utils.facts.utils

    # Mock the module
    module = ModuleFacts(argument_spec={"filter": {"required": False, "type": 'list'}})

    # Mock the collectors that are imported by PlatformFactCollector
    module.collector_classes['platform'] = PlatformFactCollector
    module.fact_classes['platform'] = PlatformFactCollector

    collected_facts = module.collect_facts()
    assert collected_facts is not None
    assert collected_facts['platform']['system'] == 'Darwin'

# Generated at 2022-06-23 01:29:51.155336
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    p = PlatformFactCollector('test')

    assert p.name == 'test'
    assert p._fact_ids == set(['system', 'kernel', 'kernel_version',
                               'machine', 'python_version', 'architecture',
                               'machine_id'])
    assert p._fact_class_name == 'Platform'

# Generated at 2022-06-23 01:29:52.803794
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect(collected_facts=dict())

# Generated at 2022-06-23 01:29:56.941884
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_platform_facts = PlatformFactCollector()
    assert test_platform_facts.name == 'platform'
    assert test_platform_facts._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                                 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-23 01:30:02.791231
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from mock import MagicMock

    platform_facts_collector_instance = PlatformFactCollector()
    module_instance = MagicMock()
    module_instance.run_command.return_value = (0, "x86_64", "")
    module_instance.get_bin_path.return_value = "/bin/bootinfo"

    assert platform_facts_collector_instance.collect(module=module_instance)["architecture"] == "x86_64"

# Generated at 2022-06-23 01:30:12.299840
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    from ansible.module_utils.facts import FactCollector

    # Test:
    # - PlatformFactCollector string representation
    # - PlatformFactCollector has_plugin() static method
    # - PlatformFactCollector collects 'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture'

    fc = FactCollector()
    fact_collector = PlatformFactCollector(fc)
    assert fact_collector.name == 'platform'

    fact_collector.collect(collected_facts={})
    assert fact_collector.name in fc.collected_facts
    assert 'system' in fc.collected_facts[fact_collector.name]
    assert 'kernel' in fc.collected_facts[fact_collector.name]

# Generated at 2022-06-23 01:30:15.892733
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Test creation of PlatformFactCollector object
    platform_object = PlatformFactCollector()

    # Test that set of platform facts is correct
    platform_facts = platform_object.collect(module=module, collected_facts={})
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

# Unit testing is done, catchall at the bottom to make the linter happy
from ansible.module_utils.basic import *


# Generated at 2022-06-23 01:30:25.996508
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """ Test PlatformFactCollector.collect() """

    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils import facts
    from ansible.module_utils._text import to_bytes
    import os, platform

    def get_bin_path(self, arg, required=False):
        """ Make a fake get_bin_path() function """
        return "/sbin/getconf"

    # Override the getbin() function, since we cannot easily test
    # this function on all platforms.
    facts.get_bin_path = get_bin_path


# Generated at 2022-06-23 01:30:31.068500
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:30:40.896228
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a stubbed version of a module object
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            if arg == "getconf":
                return "/usr/bin/getconf"
            elif arg == "bootinfo":
                return "/usr/bin/bootinfo"
            elif arg == "uname":
                return "/bin/uname"

        def run_command(self, args):
            if args[0] == "/usr/bin/getconf" and args[1] == "MACHINE_ARCHITECTURE":
                return (0, "PowerPC_POWER9\n", "")
            el

# Generated at 2022-06-23 01:30:50.000578
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert 'system' in platform_collector._fact_ids
    assert 'kernel' in platform_collector._fact_ids
    assert 'kernel_version' in platform_collector._fact_ids
    assert 'machine' in platform_collector._fact_ids
    assert 'python_version' in platform_collector._fact_ids
    assert 'architecture' in platform_collector._fact_ids

# Generated at 2022-06-23 01:30:57.200646
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'
    assert set(platform_fact_collector._fact_ids) == {'system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'}



# Generated at 2022-06-23 01:31:07.324771
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import collections

# Generated at 2022-06-23 01:31:12.794017
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:31:21.356930
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    _platform_facts = PlatformFactCollector().collect()
    assert isinstance(_platform_facts, dict)
    assert 'system' in _platform_facts.keys()
    assert _platform_facts['system'] == platform.system()

    assert 'kernel' in _platform_facts.keys()
    assert _platform_facts['kernel'] == platform.release()

    assert 'kernel_version' in _platform_facts.keys()
    assert _platform_facts['kernel_version'] == platform.version()

    assert 'machine' in _platform_facts.keys()
    assert _platform_facts['machine'] == platform.machine()

    assert 'nodename' in _platform_facts.keys()
    assert _platform_facts['nodename'] == platform.node()

    assert 'hostname' in _platform_facts.keys()
    assert _platform_

# Generated at 2022-06-23 01:31:30.834066
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import default_collectors
    facts_ins = Facts(None, default_collectors)
    platform_collector = PlatformFactCollector(facts_ins)
    assert platform_collector.name == 'platform'
    assert platform_collector._collect_methods == {'machine_id': platform_collector.collect}

# Generated at 2022-06-23 01:31:41.886049
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # pylint: disable=import-error
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector as PlatformFactCollectorModule
    # pylint: enable=import-error

    module_mock = AnsibleFactCollector
    Collector.available_collectors['platform'] = PlatformFactCollectorModule(module_mock)
    assert 'platform' in Collector.available_collectors

    # pylint: disable=protected-access
    result = Collector._collect(module_mock, {})
    platform = result.get('platform')
    # pylint: enable=protected-access

    assert platform
    assert ('system' in platform)

# Generated at 2022-06-23 01:31:49.638579
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    if platform.system() == 'Linux':
        test_machine = 'x86_64'
        test_nodename = 'test'
        test_machine_id = '12345678901234567890123456789012'
    elif platform.system() == 'SunOS':
        test_machine = 'i86pc'
        test_nodename = 'test'
        test_machine_id = None
    elif platform.system() == 'AIX':
        test_machine = 'PowerPC'
        test_nodename = 'test'
        test_machine_id = None
    elif platform.system() == 'Windows':
        test_machine = platform.uname()[3]
        test_nodename = 'test'
        test_machine_id = None

# Generated at 2022-06-23 01:31:58.821367
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def get_bin_path(bin_name):
        return '/bin/' + bin_name

    def run_command(cmd):
        if cmd[0] == '/bin/bootinfo':
            return 0, "rs6k\n", ""
        elif cmd[0] == '/bin/getconf':
            return 0, "powerpc\n", ""

    test_module = MockModule({'get_bin_path': get_bin_path, 'run_command': run_command})

    pc = PlatformFactCollector()
    facts_dictionary = pc.collect(test_module, None)

    assert facts_dictionary['architecture'] == 'powerpc'
    assert facts_dictionary['system'] == 'AIX'
    assert facts_dictionary['userspace_bits'] == ''


# Generated at 2022-06-23 01:32:07.102841
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import sys
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils import VariableManager

    fake_module = type('FakeModule', (), {})()
    fake_module.get_bin_path = lambda x: x
    fake_module.run_command = lambda x: [0, '', '']

# Generated at 2022-06-23 01:32:10.490409
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()

    assert sorted(platform_collector.collect().keys()) == sorted(platform_collector._fact_ids)

# Generated at 2022-06-23 01:32:13.523342
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:32:21.257177
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors import get_collector_instance

    # Testing with a non-existing file as machine-id
    pfc = get_collector_instance('PlatformFactCollector')
    assert 'machine_id' not in pfc.collect()
    # Testing with a real file
    with open('/etc/machine-id', 'w+') as mid:
        mid.write('test')
    assert 'test' == pfc.collect()['machine_id']

# Generated at 2022-06-23 01:32:25.262741
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:32:35.436461
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instantiate fact collector
    fact_collector = PlatformFactCollector()

    # Check returned dict
    platform_facts = fact_collector.collect()

    assert platform_facts
    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['python_version']
    assert platform_facts['architecture']
    assert platform_facts['userspace_bits']
    assert platform_facts['userspace_architecture']
    assert platform_facts['fqdn']
    assert platform_facts['hostname']
    assert platform_facts['nodename']
    assert platform_facts['domain']

# Generated at 2022-06-23 01:32:44.728094
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instantiate PlatformFactCollector.
    pfc = PlatformFactCollector()

    # Call PlatformFactCollector.collect() to get platform facts.
    platform_facts = pfc.collect()

    # The method should return a dict containing a subset of these keys.
    allowed_keys = ['system', 'kernel_version', 'domain', 'fqdn', 'architecture', 'kernel', 'machine', 'nodename', 'hostname', 'machine_id', 'python_version', 'userspace_architecture', 'userspace_bits']
    for key in allowed_keys:
        assert key in platform_facts

# Generated at 2022-06-23 01:32:46.467180
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert(set(PlatformFactCollector().collect().keys()) == PlatformFactCollector._fact_ids)

# Generated at 2022-06-23 01:32:54.561110
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a PlatformFactCollector object to test
    platform_fact_collector = PlatformFactCollector()
    # Check if the object initialized correctly
    assert platform_fact_collector

    # Check _fact_ids
    assert platform_fact_collector._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    ])

    # Check if the collect() method return value
    # is correct
    platform_facts = platform_fact_collector.collect()


# Generated at 2022-06-23 01:33:00.362278
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])



# Generated at 2022-06-23 01:33:02.980006
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    Unit test for method collect of class PlatformFactCollector.
    '''
    platform_collector = PlatformFactCollector()
    platform_collector.collect()

# Generated at 2022-06-23 01:33:08.260583
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])
    assert not pfc.collect()

# Generated at 2022-06-23 01:33:12.306806
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Import the class we are testing
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector

    # Create an instance
    x = PlatformFactCollector()

    # Returned value is a dict with two keys
    assert isinstance(x.collect(), dict)
    assert len(x.collect().keys()) == 10

# Generated at 2022-06-23 01:33:18.780394
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert isinstance(x, PlatformFactCollector)
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])
    assert x.collect_fn == x.collect

# Generated at 2022-06-23 01:33:27.441774
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test for method collect of class PlatformFactCollector

    The following is the test scenario:

    1. Create a PlatformFactCollector instance
    2. Call the collect method with None as the module parameter
    3. Verify that the call returned a dict
    4. Verify that the dict has keys for each of the following:
       'system', 'kernel', 'kernel_version', 'machine', 'python_version',
       'architecture', 'machine_id'
    """

    pfc = PlatformFactCollector()
    result = pfc.collect(collected_facts=None)
    assert isinstance(result, dict)
    assert set(result.keys()) == pfc._fact_ids

# Generated at 2022-06-23 01:33:34.977201
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import collect_subset_facts
    from ansible.module_utils.facts import FactCollection

# Generated at 2022-06-23 01:33:39.868860
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    # Check mandatory keys
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['architecture'] == platform.machine()

# Generated at 2022-06-23 01:33:46.728745
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class TestModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, binary):
            return None
        def run_command(self, command, check_rc=True, close_fds=True):
            return 0, '', ''

    module = TestModule()

    collected_facts = {}

    PlatformFactCollector.collect(module, collected_facts)

# Generated at 2022-06-23 01:33:53.074922
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_platform_collector = PlatformFactCollector()
    assert test_platform_collector.name == 'platform'
    assert test_platform_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:33:57.674287
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])

# Generated at 2022-06-23 01:34:07.322378
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup the class
    test_platform_facts = PlatformFactCollector()

    # Get the collect method of the class
    test_platform_facts_collect_method = test_platform_facts.collect

    # Get the fqdn of the system
    fqdn = socket.getfqdn()
    # Get the hostname of the system
    hostname = socket.gethostname()
    # Get nodename of the system
    nodename = platform.node()

    # Execute the collect method
    collection = test_platform_facts_collect_method()

    # Test the system key
    assert collection['system'] == platform.system()
    # Test the kernel key
    assert collection['kernel'] == platform.release()
    # Test the kernel_version key
    assert collection['kernel_version'] == platform.version()
    # Test the machine

# Generated at 2022-06-23 01:34:09.103075
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    f = PlatformFactCollector()
    assert PlatformFactCollector._fact_ids == f._fact_ids

# Generated at 2022-06-23 01:34:11.084874
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # This shouldn't raise an exception
    PlatformFactCollector()

# Generated at 2022-06-23 01:34:20.971723
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
  from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
  from ansible.module_utils.facts.util import FactsCollector
  from ansible.module_utils.facts.utils import get_file_content
  from ansible.module_utils.common._collections_compat import Mapping, MutableMapping, MutableSequence
  def noop_get_bin_path(*args, **kwargs):
    return None

# Generated at 2022-06-23 01:34:24.882319
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'
    assert platform_collector._fact_ids == set(['system',
                                                'kernel',
                                                'kernel_version',
                                                'machine',
                                                'python_version',
                                                'architecture',
                                                'machine_id'])


# Generated at 2022-06-23 01:34:30.946481
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    actual = PlatformFactCollector().collect()
    assert 'system' in actual
    assert 'kernel' in actual
    assert 'kernel_version' in actual
    assert 'machine' in actual
    assert 'python_version' in actual
    assert 'architecture' in actual
    assert 'machine_id' in actual
    assert 'fqdn' in actual
    assert 'hostname' in actual
    assert 'nodename' in actual
    assert 'domain' in actual

# Generated at 2022-06-23 01:34:33.846900
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Test method collect of class PlatformFactCollector - No return value expected
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()


# Generated at 2022-06-23 01:34:42.204169
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = None
    collected_facts = dict()
    pfc = PlatformFactCollector(module=module, collected_facts=collected_facts)
    facts = pfc.collect()
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['python_version'] == platform.python_version()
    assert facts['machine'] == platform.machine()
    assert facts['userspace_bits'] != ''
    assert facts['architecture'] != ''
    assert facts['fqdn'] == socket.getfqdn()
    assert facts['hostname'] == platform.node().split('.')[0]
    assert facts['nodename'] == platform.node()

# Generated at 2022-06-23 01:34:50.237156
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """ PlatformFactCollector.collect() returns correct values for various operating systems """

    from ansible.module_utils.facts.collector import Namespace
    collected_facts = Namespace()

    platform_facts = Namespace()
    platform_facts.system = "Linux"
    platform_facts.kernel = "3.13.0-24-generic"
    platform_facts.kernel_version = "#46-Ubuntu SMP Thu Apr 10 19:11:08 UTC 2014"
    platform_facts.machine = "x86_64"
    platform_facts.architecture = "x86_64"
    platform_facts.fqdn = "webstack.local"
    platform_facts.hostname = "webstack"
    platform_facts.nodename = "webstack"
    platform_facts.domain = "local"
    platform_facts

# Generated at 2022-06-23 01:34:53.972663
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-23 01:35:01.091333
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MockModule()
    mock_get_bin_path = Mock()
    platform_facts = PlatformFactCollector().collect(module=module)
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts


# Mock for AnsibleModule

# Generated at 2022-06-23 01:35:05.831185
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Returns a dictionary of system information.
    """
    # Get the PlatformFactCollector

    PlatformFactCollector = PlatformFactCollector()

    # Create a module object
    module = AnsibleModule(argument_spec={})

    # Get the system facts.
    system_facts = PlatformFactCollector.collect(module=module)

    assert 'system' in system_facts
    assert 'kernel' in system_facts
    assert 'kernel_version' in system_facts
    assert 'machine' in system_facts
    assert 'python_version' in system_facts
    assert 'architecture' in system_facts
    assert 'machine_id' in system_facts

# Generated at 2022-06-23 01:35:06.629472
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:35:14.421758
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert isinstance(p._fact_ids, set)
    assert 'system' in p._fact_ids
    assert 'kernel' in p._fact_ids
    assert 'kernel_version' in p._fact_ids
    assert 'machine' in p._fact_ids
    assert 'python_version' in p._fact_ids
    assert 'architecture' in p._fact_ids
    assert 'machine_id' in p._fact_ids

# Generated at 2022-06-23 01:35:21.656936
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform = PlatformFactCollector().collect()
    assert ('system' in test_platform)
    assert ('kernel' in test_platform)
    assert ('kernel_version' in test_platform)
    assert ('machine' in test_platform)
    assert ('python_version' in test_platform)
    assert ('architecture' in test_platform)
    assert ('fqdn' in test_platform)
    assert ('hostname' in test_platform)
    assert ('nodename' in test_platform)
    assert ('domain' in test_platform)
    assert ('userspace_bits' in test_platform)


# Generated at 2022-06-23 01:35:22.729600
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x

# Generated at 2022-06-23 01:35:24.506033
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
  platform_fact_collector = PlatformFactCollector()
  assert platform_fact_collector.collect() is not None

# Generated at 2022-06-23 01:35:32.862995
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockCommand


# Generated at 2022-06-23 01:35:38.471564
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Unit test to check collect method of PlatformFactCollector
    """
    import platform
    import json
    import unittest.mock

    class TestModule():
        pass

    test_module = TestModule()

    # create mock for get_bin_path method of TestModule
    test_module.get_bin_path = unittest.mock.Mock(return_value='/bin/getconf')

    # create mock for run_command method of TestModule
    test_module.run_command = unittest.mock.Mock(return_value=(0, 'power8', ''))


# Generated at 2022-06-23 01:35:43.665284
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-23 01:35:47.121083
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])



# Generated at 2022-06-23 01:35:49.813551
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    collected_data = platform_collector.collect()
    assert collected_data['system'] == platform.system()
    assert collected_data['kernel'] == platform.release()

# Generated at 2022-06-23 01:35:57.148591
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule():
        def __init__(self):
            self.exit_json = lambda x: None

        def get_bin_path(self, x):
            return True

        def run_command(self, x):
            return (
                0,
                """
test-test.test.test
test
test
test
test
test.test.test
test
test
test
test
test.test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
test
""",
                ""
            )

    fact

# Generated at 2022-06-23 01:35:59.682172
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert 'platform.system' in p.collect()

# Generated at 2022-06-23 01:36:07.320381
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Tests the returned facts of PlatformFactCollector.
    """
    collector = PlatformFactCollector()
    real_facts = collector.collect()

    assert isinstance(real_facts, dict)
    assert 'system' in real_facts
    assert 'kernel' in real_facts
    assert 'kernel_version' in real_facts
    assert 'machine' in real_facts
    assert 'python_version' in real_facts
    assert 'architecture' in real_facts
    assert 'userspace_architecture' in real_facts
    assert 'userspace_bits' in real_facts

# Generated at 2022-06-23 01:36:08.244731
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()



# Generated at 2022-06-23 01:36:12.207950
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:36:21.749466
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    f = p.collect()

    assert isinstance(f, dict)
    assert 'system' in f
    assert 'kernel' in f
    assert 'machine' in f
    assert 'python_version' in f
    assert 'fqdn' in f
    assert 'hostname' in f
    assert 'nodename' in f
    assert 'domain' in f
    assert 'architecture' in f
    assert 'machine_id' in f
    assert 'userspace_bits' in f
    assert 'userspace_architecture' in f

# Generated at 2022-06-23 01:36:28.765877
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['architecture'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

# Generated at 2022-06-23 01:36:39.632290
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import os
    import socket
    import platform

    DummyModule = basic.AnsibleModule
    dummy_module = DummyModule(argument_spec = dict())
    filename = os.path.join(os.path.dirname(__file__), '../../utils/test_utils.py')
    tmp_path = os.path.realpath(os.path.join(os.path.dirname(filename), '..'))
    dummy_module.tmpdir = tmp_path
    dummy_module.run_command = lambda *args, **kwargs: (0, socket.getfqdn(), '')

# Generated at 2022-06-23 01:36:49.805456
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import datetime
    from time import mktime
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.platform.linux.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.collectors.platform.linux.distribution.redhat import RedHatFactCollector
    from ansible.module_utils.facts.collectors.platform.linux.distribution.redhat_family import RedHatFamilyFactCollector
    from ansible.module_utils.facts.collectors.platform.linux.distribution.suse import SuseFactCollector
    from ansible.module_utils.facts.collectors.platform.linux.distribution.suse_family import SuseFamilyFactCollector

# Generated at 2022-06-23 01:37:00.663608
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Read the machine id
    with open("/etc/machine-id", 'r') as f:
        data = f.read()
    # Create an instance of PlatformFactCollector
    platform_collector = PlatformFactCollector()
    # Call the collect method
    facts = platform_collector.collect()
    # Check if the facts are valid against /etc/machine-id and os.uname()
    assert facts["system"] == platform.system()
    assert facts["kernel"] == platform.release()
    assert facts["kernel_version"] == platform.version()
    assert facts["machine"] == platform.machine()
    assert facts["userspace_bits"] == platform.architecture()[0].replace("bit", "")
    assert facts["machine_id"] == data.splitlines()[0]

# Generated at 2022-06-23 01:37:07.767231
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector()
    assert fact_collector.name == 'platform'
    assert fact_collector.fact_ids == set(['system',
                                           'kernel',
                                           'kernel_version',
                                           'machine',
                                           'python_version',
                                           'architecture',
                                           'machine_id'])

# Generated at 2022-06-23 01:37:15.526338
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import pickle

    PLATFORM_DATA_PATTERN = r'^(?P<sysname>[^\s]+)\s+(?P<nodename>[^\s]+)\s+(?P<release>[^\s]+)\s+(?P<version>[^\s]+)\s+(?P<machine>[^\s]+)\s+'
    platform_data = platform.uname()
    platform_re = re.compile(PLATFORM_DATA_PATTERN)
    platform_data_str = platform_re.sub(
        ' '.join([platform.platform(), platform_data[1], platform_data[2], platform_data[3], platform_data[4]]), '')

    dumped_platform_data = pickle.loads(pickle.dumps(platform_data))

    assert dumped_

# Generated at 2022-06-23 01:37:16.580132
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-23 01:37:18.196227
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'

# Generated at 2022-06-23 01:37:22.537809
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture'])



# Generated at 2022-06-23 01:37:23.938064
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), PlatformFactCollector)


# Generated at 2022-06-23 01:37:30.912676
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = PlatformFactCollector()
    fact_collector.collect(module, collected_facts)
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:37:33.461457
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'

# Generated at 2022-06-23 01:37:39.999512
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plt = PlatformFactCollector()
    assert plt.name == "platform"
    assert plt._fact_ids == {'system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'userspace_bits',
                             'architecture',
                             'machine_id'}

# Generated at 2022-06-23 01:37:49.132226
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['architecture'] == platform.machine()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['domain'] == '.'.join(socket.getfqdn().split('.')[1:])
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['python_version'] == platform.python_version()

# Generated at 2022-06-23 01:37:50.661254
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector.collect()

# Generated at 2022-06-23 01:37:59.181687
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    facts_collector = PlatformFactCollector()
    assert facts_collector.name == 'platform'
    assert facts_collector.collect() == {
        'system': platform.system(),
        'kernel': platform.release(),
        'kernel_version': platform.version(),
        'machine': platform.machine(),
        'python_version': platform.python_version(),
        'fqdn': socket.getfqdn(),
        'hostname': platform.node().split('.')[0],
        'nodename': platform.node(),
        'domain': '.'.join(socket.getfqdn().split('.')[1:])
    }

# Generated at 2022-06-23 01:38:05.632350
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()



# Generated at 2022-06-23 01:38:12.384829
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """ Test for retrieving system information. """
    file_name = "/usr/bin/python"
    module_instance = MockModule()

    # Test on real system with use_stderr=True
    collector_instance = PlatformFactCollector()
    results = collector_instance.collect(module_instance, {})
    assert(results)
    assert(results['system'])
    assert(results['kernel'])
    assert(results['kernel_version'])
    assert(results['machine'])
    assert(results['python_version'])


# Generated at 2022-06-23 01:38:19.041004
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Test collect function of platform fact module"""
    from collections import namedtuple
    from ansible.module_utils.facts import ModuleFacts

    # Create an object like module and facts to be used in the test
    test_module = namedtuple('Module', ['run_command'])
    test_facts = namedtuple('Facts', ['non_extant_fact'])
    # Create a test instance of the PlatformFactCollector object and call the collect method
    test_pfc = PlatformFactCollector()
    res_facts = test_pfc.collect(test_module, test_facts)
    # Check if the returned value is an instance of the ModuleFacts class
    assert isinstance(res_facts, ModuleFacts)

# Generated at 2022-06-23 01:38:30.397527
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test with Linux
    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, 'Linux\nhostname.example.com\n4.4.0-92-generic\n#115-Ubuntu SMP Thu Aug 10 09:04:33 UTC 2017\nx86_64\n', '')
    module_mock.command_warnings = []
    module_mock.get_bin_path.side_effect = lambda x: x
    collector = PlatformFactCollector()
    assert 'machine_id' not in collector.collect(module_mock)['Linux']
    assert 'architecture' in collector.collect(module_mock)['Linux']
    assert 'userspace_architecture' in collector.collect(module_mock)['Linux']
   

# Generated at 2022-06-23 01:38:40.332001
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class MockModule():
        def get_bin_path(self, arg):
            return ""

        def run_command(self, command):
            return (0, "64 x86_64", "")

    collected_facts = dict()

    pfc = PlatformFactCollector()

    results = pfc.collect(MockModule(), collected_facts)


# Generated at 2022-06-23 01:38:40.964033
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:38:46.157053
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert(pfc.name == 'platform')
    assert('system' in pfc._fact_ids)
    assert('kernel' in pfc._fact_ids)
    assert('kernel_version' in pfc._fact_ids)
    assert('machine' in pfc._fact_ids)
    assert('python_version' in pfc._fact_ids)
    assert('fqdn' in pfc._fact_ids)
    assert('hostname' in pfc._fact_ids)
    assert('nodename' in pfc._fact_ids)
    assert('domain' in pfc._fact_ids)
    assert(len(pfc._fact_ids) == 11)



# Generated at 2022-06-23 01:38:57.521633
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    fact_collection_obj = None # Set to a TestFactCollector object in the code to be tested
    fact_collection_obj_list = [ PlatformFactCollector() ]
    module_facts_obj = ModuleFacts(fact_collection_obj_list, ImmutableDict(), {})
    platform_facts = module_facts_obj.get_facts()["platform"]

    assert platform_facts
    assert platform_facts['system']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['python_version']

# Generated at 2022-06-23 01:38:59.283147
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_collector = PlatformFactCollector()
    assert platform_collector.name == 'platform'

# Generated at 2022-06-23 01:39:05.688433
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector

    ansible_module = AnsibleModuleDouble()
    platform_fact_collector = PlatformFactCollector()

    platform_facts = platform_fact_collector.collect(module=ansible_module)
    facts_collector = FactsCollector(ansible_module, platform_facts)

    assert set(platform_facts.keys()) == set(['system',
                                              'kernel',
                                              'kernel_version',
                                              'machine',
                                              'python_version',
                                              'architecture',
                                              'machine_id'])


# Generated at 2022-06-23 01:39:17.669777
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    class ModuleMock:
        def get_bin_path(self, path):
            return path

        def run_command(self, command):
            class ReturnVal:
                def __init__(self, stdout, stderr, rc):
                    self.stdout = stdout
                    self.stderr = stderr
                    self.rc = rc

                def splitlines(self):
                    return self.stdout.splitlines()

            if command == ['getconf', 'MACHINE_ARCHITECTURE']:
                return ReturnVal('powerpc', '', 0)
            else:
                return ReturnVal('PowerNV 8247-22L', '', 0)

    class CollectedFactsMock:
        def __init__(self):
            self.data = {}

    import platform


# Generated at 2022-06-23 01:39:27.718347
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    def mock_run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, raise_err=True, environ_update=None, umask=None, encoding=None, errors=None):
        return 0, '', ''

    # side effects due to mocking
    platform.machine = lambda: 'x86_64'
    platform.python_version = lambda: '2.7.13'
    platform.architecture = lambda: ('64bit', 'ELF')
    platform.release = lambda: '2.6.32-696.el6.x86_64'
    platform.system = lambda: 'Linux'
    platform.node = lambda: 'hostname.example.com'

# Generated at 2022-06-23 01:39:28.313117
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass

# Generated at 2022-06-23 01:39:31.732902
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact = PlatformFactCollector()

    assert fact.name == 'platform'
    assert fact._fact_ids == set(['system',
                                  'kernel',
                                  'kernel_version',
                                  'machine',
                                  'python_version',
                                  'architecture',
                                  'machine_id'])

