

# Generated at 2022-06-23 01:29:38.617985
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockFactModule():
        def __init__(self):
            self.params = {}

# Generated at 2022-06-23 01:29:50.112577
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleStub(dict(
        command='/usr/bin/env',
        _raw_params='PATH=/bin:/usr/bin:/usr/local/bin:/usr/sbin PYTHON_VERSION=2.7.6 (default, Jun 22 2015, 17:58:13) [GCC 4.8.2] ARCHITECTURE=amd64 MACHINE=x86_64\nKERNEL=Linux NODENAME=localhost SYSTEM=Linux\nMACHINE_ID=c9cbfb2c17ad4d4d8b4fc0f049a64c9a FQDN=localhost HOSTNAME=localhost',
        _uses_shell=True,
        _ansible_check_mode=False
    ))
    PlatformFactCollector(module).collect()
    assert module.exit_

# Generated at 2022-06-23 01:30:00.139713
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert isinstance(platform_facts, dict)
    assert isinstance(platform_facts['system'], str)
    assert platform_facts['system'] in ("Linux", "Darwin", "Java", "Windows")
    assert isinstance(platform_facts['kernel'], str)
    assert isinstance(platform_facts['kernel_version'], str)
    assert isinstance(platform_facts['machine'], str)
    assert isinstance(platform_facts['architecture'], str)
    assert isinstance(platform_facts['python_version'], str)
    assert isinstance(platform_facts['fqdn'], str)
    assert isinstance(platform_facts['hostname'], str)
    assert isinstance(platform_facts['nodename'], str)

# Generated at 2022-06-23 01:30:07.725954
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-23 01:30:17.409550
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test case inside a module.
    # Pushing some data in platform module globals and then testing
    # the collect method of PlatformFactCollector
    import types
    import platform
    import ansible.module_utils.facts.collectors.platform as platform_collector

    # Storing previous platform module globals
    platform_globals = {
        'system': platform.system,
        'release': platform.release,
        'version': platform.version,
        'machine': platform.machine,
        'python_version': platform.python_version,
        'architecture': platform.architecture,
        'uname': platform.uname
    }
    # Storing previous method if it exists
    platform_globals['get_file_content'] = getattr(platform_collector, "get_file_content", None)

# Generated at 2022-06-23 01:30:27.170526
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """Check that we correctly parse platform facts."""
    import platform
    import socket

    platform_facts = {}

    # platform.system() can be Linux, Darwin, Java, or Windows
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()

    # hostname is without domain
    platform_facts['hostname'] = platform.node().split('.')[0]

    # nodename is full qualified
    platform_facts['nodename'] = platform.node()


# Generated at 2022-06-23 01:30:29.953447
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collecto

# Generated at 2022-06-23 01:30:41.369646
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector = PlatformFactCollector()
    PlatformFact = PlatformFactCollector.collect()
    assert isinstance(PlatformFact['system'], str)
    assert isinstance(PlatformFact['kernel'], str)
    assert isinstance(PlatformFact['kernel_version'], str)
    assert isinstance(PlatformFact['machine'], str)
    assert isinstance(PlatformFact['architecture'], str)
    assert isinstance(PlatformFact['fqdn'], str)
    assert isinstance(PlatformFact['hostname'], str)
    assert isinstance(PlatformFact['nodename'], str)
    assert isinstance(PlatformFact['domain'], str)
    assert isinstance(PlatformFact['userspace_bits'], str)
    assert isinstance(PlatformFact['machine_id'], str)

# Generated at 2022-06-23 01:30:53.228702
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
  """PlatformFactCollector - Collect realm facts
  """
  module = AnsibleModuleMock()
  module.run_command = MagicMock(return_value=(0, 'AIX', ''))
  module.get_bin_path = MagicMock(side_effect=('/usr/bin/getconf', '/usr/bin/bootinfo'))
  module.read_file = MagicMock(side_effect=("", "", ""))

  pfc = PlatformFactCollector(module)
  pfc.collect()

  assert module.run_command.call_count == 3
  assert module.run_command.call_args == call(['/usr/bin/getconf', 'MACHINE_ARCHITECTURE'])
  assert module.get_bin_path.call_args_list[0] == call('getconf')


# Generated at 2022-06-23 01:31:04.736272
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Initialize the class PlatformFactCollector
    test_platforfactcollector = PlatformFactCollector()
    test_collect_platform_facts_dict = test_platforfactcollector.collect()

    # Check if the keys are present and not empty
    assert 'system' in test_collect_platform_facts_dict and test_collect_platform_facts_dict['system']
    assert 'kernel' in test_collect_platform_facts_dict and test_collect_platform_facts_dict['kernel']
    assert 'kernel_version' in test_collect_platform_facts_dict and test_collect_platform_facts_dict['kernel_version']
    assert 'machine' in test_collect_platform_facts_dict and test_collect_platform_facts_dict['machine']
    assert 'python_version' in test_collect_platform_facts_dict

# Generated at 2022-06-23 01:31:09.001681
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    m = re.match(r"^[a-f0-9]{64}$", platform_facts["machine_id"])
    assert m is not None

# Generated at 2022-06-23 01:31:09.624501
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-23 01:31:13.130765
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test for method "collect" of class PlatformFactCollector
    """
    test_platform = PlatformFactCollector()
    output = test_platform.collect()
    assert isinstance(output, dict)

# Generated at 2022-06-23 01:31:19.601874
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = PlatformFactCollector()
    assert platform_facts.name == 'platform'
    assert 'system' in platform_facts._fact_ids
    assert 'kernel' in platform_facts._fact_ids
    assert 'kernel_version' in platform_facts._fact_ids
    assert 'machine' in platform_facts._fact_ids
    assert 'python_version' in platform_facts._fact_ids
    assert 'architecture' in platform_facts._fact_ids
    assert 'machine_id' in platform_facts._fact_ids
    assert platform_facts._fact_ids.__len__() == 7


# Generated at 2022-06-23 01:31:24.889508
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fact_collector = PlatformFactCollector(None)
    assert fact_collector.name == 'platform'
    assert fact_collector._fact_ids == set(['system',
                                            'kernel',
                                            'kernel_version',
                                            'machine',
                                            'python_version',
                                            'architecture',
                                            'machine_id'])

# Generated at 2022-06-23 01:31:29.889842
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    expected_collectors = {'kernel', 'python_version', 'architecture', 'system', 'machine', 'kernel_version', 'machine_id'}
    pf = PlatformFactCollector()
    assert pf._fact_ids == expected_collectors

# Generated at 2022-06-23 01:31:38.552363
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    expected = ["ansible_architecture", "ansible_domain", "ansible_fqdn", "ansible_hostname", "ansible_kernel", "ansible_kernel_version", "ansible_machine", "ansible_machine_id", "ansible_nodename", "ansible_python_version", "ansible_system", "ansible_userspace_architecture", "ansible_userspace_bits"]
    assert collector.collect() == {}
    assert collector.fact_ids == expected
    assert collector.name == "platform"

# Generated at 2022-06-23 01:31:47.421896
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    class FakeModule:
        def get_bin_path(self, program_name):
            return program_name

        def run_command(self, cmd):
            if cmd[0] == 'getconf':
                return 0, 'x86_64', ''
            elif cmd[0] == 'bootinfo':
                return 0, '64', ''
            else:
                return 0, '', ''

    platform_collector = PlatformFactCollector()
    pf = platform_collector.collect(module=FakeModule())
    assert pf != {}
    assert pf['architecture'] == 'x86_64'
    assert pf['userspace_architecture'] == 'i386'

    pf = platform_collector.collect(module=FakeModule())
    assert pf != {}

# Generated at 2022-06-23 01:31:57.038593
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Set up a mock module
    mock_module = MockModule()
    # Set up a mock subprocess with a canned response
    mock_module.run_command = Mock(return_value=(0, '', ''))
    # Set up a mock open with a canned response
    open_name = 'ansible.module_utils.facts.collector.platform_fact_collector.open'
    with patch(open_name, mock_open(read_data='mock_data'), create=True) as mo:
        pfc = PlatformFactCollector()
        facts_dict = pfc.collect(module=mock_module)
        assert facts_dict['system'] == 'AIX'
        assert facts_dict['kernel'] == '7.1'

# Generated at 2022-06-23 01:32:03.307494
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    result = platform_fact_collector.collect(collected_facts={})
    assert "system" in result
    assert "kernel" in result
    assert "kernel_version" in result
    assert "machine" in result
    assert "python_version" in result
    assert "fqdn" in result
    assert "hostname" in result
    assert "nodename" in result
    assert "domain" in result
    assert "userspace_bits" in result
    assert "architecture" in result
    assert "machine_id" in result

# Generated at 2022-06-23 01:32:13.747611
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    import pytest

    class MockModule():

        def __init__(self):
            self.run_command_called = False
            self.run_command_calls = {}
            self.get_bin_path_calls = {}

        def get_bin_path(self, path):
            self.get_bin_path_calls[path] = True
            return True

        def run_command(self, args):
            self.run_command_called = True
            self.run_command_calls[args[0]] = args[1:]
            return [0, "", ""]

    test_architecture = platform.machine()
    test_python_version = platform.python_version()

    # Test method collect by setting

# Generated at 2022-06-23 01:32:15.489256
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    assert platform_collector.collect() is not None

# Generated at 2022-06-23 01:32:20.564749
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'python_version' in platform_fact_collector._fact_ids
    assert platform_fact_collector.collect() is not None
    assert platform_fact_collector.collect()['system'] == platform.system()

# Generated at 2022-06-23 01:32:29.946876
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    PlatformFactCollector.collect() Test
    """
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector

    # Instantiate
    PlatformFactCollectorObj = PlatformFactCollector()

    # Required attributes
    module = AnsibleModuleMock()
    module.params = {'gather_subset': ['!all', '!min']}
    module.exit_json = exit_json

    # Instantiate AnsibleModuleMock
    moduleObj = ModuleFacts(module)

    # Collect from PlatformFactCollector
    PlatformFactCollectorObj.collect(moduleObj)

    # Collect from FactCollector

# Generated at 2022-06-23 01:32:33.864769
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:32:37.109850
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert 'platform' == PlatformFactCollector.name
    assert set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id']) == PlatformFactCollector._fact_ids

# Generated at 2022-06-23 01:32:48.215356
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a mock runner with a fake ansible_facts
    runner = Runner(module)

    # Create a PlatformFactCollector instance
    platform_fact_collector = PlatformFactCollector(runner)

    # Populate the ansible_facts

# Generated at 2022-06-23 01:32:50.528267
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_instance = PlatformFactCollector()
    test_instance.collect()

# Generated at 2022-06-23 01:32:54.092386
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()

# Generated at 2022-06-23 01:32:59.719429
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])


# Generated at 2022-06-23 01:33:05.245295
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = MockAnsibleModule()
    module.run_command = MockRunCommand()
    collector = PlatformFactCollector(module=module)

    res = collector.collect(module)
    assert 'architecture' in res
    assert 'nodename' in res
    assert res['architecture'] == 'x86_64'
    assert res['nodename'] == 'toto'



# Generated at 2022-06-23 01:33:12.464084
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    collected_platform_facts = platform_collector.collect()

    assert 'system' in collected_platform_facts
    assert 'kernel' in collected_platform_facts
    assert 'kernel_version' in collected_platform_facts
    assert 'machine' in collected_platform_facts
    assert 'python_version' in collected_platform_facts
    assert 'architecture' in collected_platform_facts
    assert 'machine_id' in collected_platform_facts
    assert 'userspace_bits' in collected_platform_facts
    assert 'userspace_architecture' in collected_platform_facts

# Generated at 2022-06-23 01:33:17.530995
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'
    assert p._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:33:26.562382
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert set(platform_fact_collector.collect().keys()) == set(['system',
                                                                 'kernel',
                                                                 'kernel_version',
                                                                 'machine',
                                                                 'python_version',
                                                                 'architecture',
                                                                 'machine_id',
                                                                 'hostname',
                                                                 'userspace_bits',
                                                                 'fqdn',
                                                                 'domain',
                                                                 'userspace_architecture',
                                                                 'nodename'])

# Generated at 2022-06-23 01:33:28.430199
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert not PlatformFactCollector().collect()

# Generated at 2022-06-23 01:33:34.683345
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    facts = collector.collect()
    
    # All these keys/values should exist
    assert facts['system']
    assert facts['kernel']
    assert facts['kernel_version']
    assert facts['machine']
    assert facts['python_version']
    assert facts['fqdn']
    assert facts['hostname']
    assert facts['nodename']
    assert facts['domain']
    assert facts['userspace_bits']
    assert facts['architecture']
    assert facts['userspace_architecture']
    assert facts['machine_id']

# Generated at 2022-06-23 01:33:38.458050
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-23 01:33:47.117875
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    os_release_content = """
NAME="openSUSE Leap"
VERSION="42.1"
ID=opensuse
ID_LIKE="suse"
VERSION_ID="42.1"
PRETTY_NAME="openSUSE Leap 42.1 (x86_64)"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:opensuse:leap:42.1:ga"
BUG_REPORT_URL="https://bugs.opensuse.org"
HOME_URL="https://opensuse.org/"
"""
    platform_facts = PlatformFactCollector().collect({'get_file_content': lambda x: os_release_content})
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel'] == '4.1.12-25-default'
    assert platform_facts

# Generated at 2022-06-23 01:33:56.754310
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])
    assert platform_fact_collector._platform == ('linux', 'darwin', 'sunos', 'freebsd', 'openbsd', 'aix', 'netbsd', 'solaris')
    assert platform_fact_collector._legacy_facts == []
    assert platform_fact_collector._subsets == {}

# Generated at 2022-06-23 01:34:06.512723
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    mocked_module = MockAnsibleModule()
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect(module=mocked_module)
    assert type(platform_facts['python_version']) == str
    assert type(platform_facts['architecture']) == str
    assert type(platform_facts['userspace_architecture']) == str
    assert type(platform_facts['system']) == str
    assert type(platform_facts['kernel']) == str
    assert type(platform_facts['kernel_version']) == str
    assert type(platform_facts['machine']) == str
    assert type(platform_facts['fqdn']) == str
    assert type(platform_facts['hostname']) == str

# Generated at 2022-06-23 01:34:10.404075
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == {'system', 'kernel', 'kernel_version',
                           'machine', 'python_version', 'architecture',
                           'machine_id'}

# Generated at 2022-06-23 01:34:20.594768
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    fact_collector = PlatformFactCollector(module=module)
    fact_collector.collect(module=module)
    assert module.facts['system'] == 'Linux'
    assert module.facts['kernel'] == '3.16.0-4-amd64'
    assert module.facts['kernel_version'] == '#1 SMP Debian 3.16.7-ckt25-2 (2016-04-08)'
    assert module.facts['machine'] == 'x86_64'
    assert module.facts['architecture'] == 'x86_64'
    assert module.facts['userspace_bits'] == '64'
    assert module.facts['userspace_architecture'] == 'x86_64'

# Generated at 2022-06-23 01:34:30.293611
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    facts_to_collect = platform_fact_collector.collect()

    assert facts_to_collect is not None
    assert isinstance(facts_to_collect, dict)
    assert 'system' in facts_to_collect
    assert 'kernel' in facts_to_collect
    assert 'kernel_version' in facts_to_collect
    assert 'machine' in facts_to_collect
    assert 'python_version' in facts_to_collect
    assert 'architecture' in facts_to_collect
    if facts_to_collect['system'] != 'Windows':
        assert 'machine_id' in facts_to_collect

# Generated at 2022-06-23 01:34:40.139763
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    facts = platform_fact_collector.collect()
    assert facts['system'] == 'Linux', 'unexpected system'
    assert facts['kernel'] == '4.4.0-72-generic', 'unexpected kernel'
    assert facts['kernel_version'] == '#93~16.04.1-Ubuntu SMP Fri Mar 31 14:06:54 UTC 2017', 'unexpected kernel_version'
    assert facts['machine'] == 'x86_64', 'unexpected machine'
    assert facts['python_version'] == '2.7.12', 'unexpected python_version'
    assert facts['fqdn'] == 'ubuntu', 'unexpected fqdn'
    assert facts['hostname'] == 'ubuntu', 'unexpected hostname'

# Generated at 2022-06-23 01:34:48.586819
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import collectors

    platform_collector = PlatformFactCollector()

    # Basic test
    collected_facts = {}
    platform_collector.collect(collected_facts=collected_facts)

    assert collected_facts['system'] == platform.system()
    assert collected_facts['kernel'] == platform.release()
    assert collected_facts['kernel_version'] == platform.version()
    assert collected_facts['machine'] == platform.machine()
    assert collected_facts['python_version'] == platform.python_version()
    assert collected_facts['fqdn'] == socket.getfqdn()
    assert collected_facts['hostname'] == platform.node().split('.')[0]
    assert collected_facts['nodename'] == platform.node()
    assert collected_facts['domain']

# Generated at 2022-06-23 01:34:53.950564
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()
    assert collector.name == 'platform'
    assert collector._fact_ids == set(['system',
                                       'kernel',
                                       'kernel_version',
                                       'machine',
                                       'python_version',
                                       'architecture',
                                       'machine_id'])


# Generated at 2022-06-23 01:35:03.971877
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts

    module = ModuleFacts(None, None)

    platform_fact_collector = PlatformFactCollector()
    facts = platform_fact_collector.collect(module=module)
    assert facts["system"] == platform.system()
    assert facts["kernel"] == platform.release()
    assert facts["kernel_version"] == platform.version()
    assert facts["machine"] == platform.machine()
    assert facts["python_version"] == platform.python_version()
    assert facts["nodename"] == platform.node()
    assert facts["domain"] == '.'.join(socket.getfqdn().split('.')[1:])
    assert facts["machine_id"] is not None

# Generated at 2022-06-23 01:35:08.250313
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'])

# Generated at 2022-06-23 01:35:13.048317
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector._fact_ids == set(['system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'])

# Generated at 2022-06-23 01:35:18.466725
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['userspace_bits'] == platform_facts['userspace_architecture'].split('_')[-1]
    assert platform_facts['system'] == platform.system()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['nodename'] == platform.node()

# Unit tests for solaris_i86_re regex

# Generated at 2022-06-23 01:35:25.357388
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModuleMock()
    fact_collector = PlatformFactCollector(module)
    facts = fact_collector.collect()
    assert facts['system'] == platform.system()
    assert facts['kernel'] == platform.release()
    assert facts['kernel_version'] == platform.version()
    assert facts['machine'] == platform.machine()
    assert facts['python_version'] == platform.python_version()
    assert facts['fqdn'] == socket.getfqdn()
    assert facts['nodename'] == platform.node()


# Generated at 2022-06-23 01:35:35.320414
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    if not platform.system:
        platform.system = lambda: "Linux"
        platform.release = lambda: "4.8.1-gentoo"
        platform.version = lambda: "#1 SMP Tue Aug 30 00:15:50 UTC 2016"
        platform.machine = lambda: "x86_64"

        platform._architecture = ("64bit", "ELF")
        platform.python_version = lambda: "3.5.2"

        socket.getfqdn = lambda: "localhost.localdomain"
        platform.node = lambda: "localhost.localdomain"


# Generated at 2022-06-23 01:35:42.411612
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-23 01:35:46.035231
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert set(PlatformFactCollector._fact_ids) == set(['system',
                                                         'kernel',
                                                         'kernel_version',
                                                         'machine',
                                                         'python_version',
                                                         'architecture',
                                                         'machine_id'])

# Generated at 2022-06-23 01:35:49.576915
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture'])


# Generated at 2022-06-23 01:35:56.971726
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pc = PlatformFactCollector()

# Generated at 2022-06-23 01:36:03.665480
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = None
    collected_facts = None

    p = PlatformFactCollector()
    result = p.collect(module, collected_facts)
    assert type(result) is dict
    assert result['fqdn'] is not None
    assert result['hostname'] is not None
    assert result['domain'] is not None
    assert result['nodename'] is not None
    assert result['architecture'] is not None
    assert result['system'] is not None
    assert result['machine_id'] is not None

# Generated at 2022-06-23 01:36:13.115877
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Given a PlatformFactCollector instance
    pfc = PlatformFactCollector()

    # When I call collect
    platform_facts = pfc.collect()

    # Then the following keys and values are returned:
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()

# Generated at 2022-06-23 01:36:20.519162
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-23 01:36:31.689860
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    c = PlatformFactCollector()
    # {u'system': u'Linux',
    #  u'kernel': u'3.10.0-229.el7.x86_64',
    #  u'kernel_version': u'#1 SMP Fri Mar 6 11:36:42 UTC 2015',
    #  u'machine': u'x86_64',
    #  u'python_version': u'2.7.5',
    #  u'fqdn': u'host.example.com',
    #  u'hostname': u'host',
    #  u'nodename': u'host.example.com',
    #  u'domain': u'example.com',
    #  u'userspace_bits': u'64',
    #  u'architecture': u'x86

# Generated at 2022-06-23 01:36:37.426469
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()

    if platform.system() == "Windows":
        assert "machine_id" not in platform_facts
    else:
        assert "machine_id" in platform_facts

# Generated at 2022-06-23 01:36:38.282700
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_ins = PlatformFactCollector()
    assert test_ins.name == 'platform'

# Generated at 2022-06-23 01:36:43.522046
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])



# Generated at 2022-06-23 01:36:49.116889
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Arrange
    platform_fact_collector = PlatformFactCollector()
    # Act
    # Assert
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids

# Generated at 2022-06-23 01:36:55.594616
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    expected_set = set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    platform_fact_collector = PlatformFactCollector()
    fact_ids = platform_fact_collector._fact_ids
    assert fact_ids == expected_set, 'Expected fact_ids to be "+str(expected_set)+" but got '+str(fact_ids)

# Generated at 2022-06-23 01:36:57.156163
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # TODO: write unit test for platform.collect
    pass

# Generated at 2022-06-23 01:37:03.079919
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Create a mock module class
    class MockModule():
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = None
            self.params['filter'] = None

        def get_bin_path(self, arg):
            return None

        def run_command(self, arg):
            return None, None, None

    module = MockModule()
    platform = PlatformFactCollector(module)
    var = platform.collect()

    assert isinstance(var, dict)
    assert 'system' in var
    assert 'kernel' in var
    assert 'kernel_version' in var
    assert 'machine' in var
    assert 'python_version' in var
    assert 'hostname' in var
    assert 'nodename' in var
    assert 'fqdn' in var

# Generated at 2022-06-23 01:37:13.375871
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class Module:
        def get_bin_path(self, arg):
            if arg == 'getconf':
                return '/usr/bin/getconf'
            else:
                return None

        def run_command(self, args):
            out = 'data'
            error = None
            return (0, out, error)

    platform_facts = PlatformFactCollector().collect(module=Module())

    # Platform method collect should return a dictionary containing a key 'system' with a string value
    assert 'system' in platform_facts
    assert isinstance(platform_facts['system'], str)

    # Platform method collect should return a dictionary containing a key 'kernel' with a string value
    assert 'kernel' in platform_facts
    assert isinstance(platform_facts['kernel'], str)

    # Platform method collect should return a dictionary containing a key '

# Generated at 2022-06-23 01:37:24.240020
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect()
    assert isinstance(platform_facts, dict)
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()

    arch_bits = platform.architecture()[0]
    userspace_bits = arch_bits.replace('bit', '')
    if platform_facts['machine'] == 'x86_64':
        assert platform_facts['architecture'] == platform_facts['machine']

# Generated at 2022-06-23 01:37:33.258650
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform = PlatformFactCollector.collect()

    assert platform['system']
    assert platform['kernel']
    assert platform['kernel_version']
    assert platform['machine']
    assert platform['python_version']
    assert platform['architecture']
    assert platform['nodename']
    assert platform['hostname']
    assert platform['domain']

    assert 'fqdn' in platform or 'machine_id' in platform

    if platform['machine'] == 'x86_64':
        assert platform['userspace_bits']
        if platform['userspace_bits'] == '64':
            assert platform['userspace_architecture'] == 'x86_64'
    elif solaris_i86_re.search(platform['machine']):
        assert platform['userspace_bits']

# Generated at 2022-06-23 01:37:45.440004
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import get_collector_class

    # Set attributes
    module = None
    collected_facts = None

    # Set method to be tested
    method_to_test = 'collect'
    PlatformFactCollector = get_collector_class('platform')
    platform_facts_collector = PlatformFactCollector()
    method = getattr(platform_facts_collector, method_to_test)

    # Invoke method
    platform_facts = method(module=module, collected_facts=collected_facts)

    # Assertions
    assert 'system' in platform_facts
    assert platform_facts['system'] == platform.system()
    assert 'kernel' in platform_facts
    assert platform_facts['kernel'] == platform.release()
    assert 'kernel_version'

# Generated at 2022-06-23 01:37:50.101964
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert pfc._fact_ids == set([
                                 'system',
                                 'kernel',
                                 'kernel_version',
                                 'machine',
                                 'python_version',
                                 'architecture',
                                 'machine_id'])
    assert isinstance(pfc, BaseFactCollector)


# Generated at 2022-06-23 01:38:00.570328
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import platform
    import socket
    import re
    dummy_module = sys.modules[__name__]
    x = PlatformFactCollector()
    data = x.collect(dummy_module)
    assert data['system'] == platform.system()
    assert data['fqdn'] == socket.getfqdn()
    if data['system'] == 'AIX':
        assert data['architecture'] in ('powerpc', )
    elif data['system'] == 'OpenBSD':
        assert data['architecture'] in ('amd64', )
    elif data['machine'] == 'x86_64':
        assert re.match(r'^(x86_64|i386)$', data['architecture'])

# Generated at 2022-06-23 01:38:04.393744
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    test method PlatformFactCollector.collect
    """
    # Create a PlatformFactCollector object and return type object
    p = PlatformFactCollector()
    assert isinstance(p.collect(), dict)

# Generated at 2022-06-23 01:38:08.797510
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])


# Generated at 2022-06-23 01:38:17.715723
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import platform
    import socket
    import re
    # create a test class
    class PlatformFactCollector(object):
        name = 'platform'
        _fact_ids = set(['system',
                         'kernel',
                         'kernel_version',
                         'machine',
                         'python_version',
                         'architecture',
                         'machine_id'])
        def collect(self, module=None, collected_facts=None):
            platform_facts = {}
            # platform.system() can be Linux, Darwin, Java, or Windows
            platform_facts['system'] = platform.system()
            platform_facts['kernel'] = platform.release()
            platform_facts['kernel_version'] = platform.version()
            platform_facts['machine'] = platform.machine()
            platform_facts['python_version'] = platform.python_version()


# Generated at 2022-06-23 01:38:26.990872
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import sys
    import unittest

    module = sys.modules[__name__]
    mock_module = type('AnsibleModule', (object,), {'run_command': lambda *args, **kwargs: (0, '', '')})
    mock_module.get_bin_path = lambda *args, **kwargs: ''
    module.AnsibleModule = mock_module

    # noinspection PyPep8Naming
    class TestPlatformFactCollector_collect(unittest.TestCase):
        def setUp(self):
            import mock

            self.mock_platform = mock.patch('platform.system')
            self.mock_system = self.mock_platform.start()
            self.mock_system.return_value = 'Linux'


# Generated at 2022-06-23 01:38:29.596610
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x
    assert isinstance(x, PlatformFactCollector)
    assert x.name == 'platform'
    assert x._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

# Generated at 2022-06-23 01:38:36.234532
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import PlatformFactCollector

    platform_collector = PlatformFactCollector()
    assert platform_collector is not None
    assert isinstance(platform_collector, Collector)

    tmp_collector = Collector.factory('platform')
    assert isinstance(tmp_collector, PlatformFactCollector)

# Generated at 2022-06-23 01:38:38.913332
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()
    # Assert no exception is raised
    assert True

# Generated at 2022-06-23 01:38:44.401549
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    collector = PlatformFactCollector()
    fact_data = collector.collect()
    assert 'system' in fact_data
    assert 'kernel' in fact_data
    assert 'kernel_version' in fact_data
    assert 'machine' in fact_data
    assert 'python_version' in fact_data
    assert 'architecture' in fact_data
    assert 'machine_id' in fact_data

# Generated at 2022-06-23 01:38:54.636290
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    import types
    import platform

    def get_bin_path(bin):
        return bin

    module = type('Foo', (object,), {'get_bin_path': get_bin_path})
    def run_command(self, command):
        return 0, "i386\n", ""

    setattr(module, 'run_command', types.MethodType(run_command, module))

    platform_collector = PlatformFactCollector()
    platform_facts = platform_collector.collect(module)
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()


# Generated at 2022-06-23 01:38:58.677184
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc.name == 'platform'
    assert isinstance(pfc._fact_ids, set)
    assert pfc.name in pfc._fact_ids

# Generated at 2022-06-23 01:39:00.357793
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert True

# Generated at 2022-06-23 01:39:10.514012
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Patch function socket.getfqdn()
    getfqdn_mock = Mock()
    getfqdn_mock.return_value = "mock_fqdn"
    platform.socket.getfqdn = getfqdn_mock

    # Patch function platform.uname()
    uname_mock = Mock()
    uname_mock.return_value = ["mock_system", "mock_node", "mock_release", "mock_version", "mock_machine", "mock_process"]
    platform.platform.uname = uname_mock

    # Patch function platform.node()
    node_mock = Mock()
    node_mock.return_value = "mock_fqdn"
    platform.platform.node = node_mock

    # Patch function

# Generated at 2022-06-23 01:39:14.061614
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().get_fact_ids() == { 'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id' }


# Generated at 2022-06-23 01:39:16.127864
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    Unit test for method collect of class PlatformFactCollector
    '''
    pass

# Generated at 2022-06-23 01:39:20.435181
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    x = PlatformFactCollector()
    assert x.name == 'platform'
    assert x._fact_ids == set(['system',
                               'kernel',
                               'kernel_version',
                               'machine',
                               'python_version',
                               'architecture',
                               'machine_id'])

# Generated at 2022-06-23 01:39:25.404302
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = PlatformFactCollector().collect()

    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-23 01:39:35.505737
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    module = FakeModule()
    facts_collector = FactsCollector(module=module)
    facts_collector.collect(['platform'])

    assert module.facts['system'] == 'Linux'
    assert module.facts['kernel'] == '4.4.0-21-generic'
    assert module.facts['machine'] == 'x86_64'
    assert module.facts['python_version'] == '2.7.12'
    assert module.facts['architecture'] == 'x86_64'
    assert module.facts['nodename'] == 'test-host'
    assert module.facts['fqdn'] == 'test-host.example.com'
    assert module.facts['hostname'] == 'test-host'
    assert module.facts