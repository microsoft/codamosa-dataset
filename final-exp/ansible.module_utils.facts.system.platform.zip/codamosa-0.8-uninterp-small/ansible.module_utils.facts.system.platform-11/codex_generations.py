

# Generated at 2022-06-25 00:24:32.078589
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_facts_1 = platform_fact_collector_1.collect()
    assert platform_facts_1['system'] == 'Linux'
    assert platform_facts_1['kernel'] == '3.10.0-514.el7.x86_64'
    assert platform_facts_1['machine'] == 'x86_64'
    assert platform_facts_1['python_version'] == '2.7.5'

# Generated at 2022-06-25 00:24:35.326014
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    
  try:
    platform_fact_collector = PlatformFactCollector()
  
  except Exception as e:
    print("Error raised: " + str(e))
    assert False 


# Generated at 2022-06-25 00:24:45.823796
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_collect = PlatformFactCollector()
    pfc_collect = platform_fact_collector_collect.collect()

    assert platform.system() == "Linux"
    assert platform.release() == "5.3.0-53-generic"
    assert platform.version() == "#47~18.04.1-Ubuntu SMP Fri Apr 24 06:16:15 UTC 2020"
    assert platform.machine() == "x86_64"
    assert platform.uname()[2] == "18.04"
    assert platform.python_version() == "2.7.15rc1"
    assert platform.node() == socket.getfqdn()
    assert socket.getfqdn() == "ubuntu-20-04.localdomain"

# Generated at 2022-06-25 00:24:50.812858
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-25 00:24:52.743432
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector



# Generated at 2022-06-25 00:24:55.386424
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()

# Generated at 2022-06-25 00:25:00.596988
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    '''
    Test to see if PlatformFactCollector().collect() returns a dictionary with
    expected keys and values.
    '''
    platform_fact_collector_1 = PlatformFactCollector()
    platform_facts = platform_fact_collector_1.collect()
    assert isinstance(platform_facts, dict)
    assert set(platform_facts.keys()) == PlatformFactCollector._fact_ids

# Generated at 2022-06-25 00:25:05.633575
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_test = PlatformFactCollector()
    assert platform_fact_collector_test.name == 'platform'
    assert platform_fact_collector_test._fact_ids == {'system',
                                                      'kernel',
                                                      'kernel_version',
                                                      'machine',
                                                      'python_version',
                                                      'architecture',
                                                      'machine_id'}

# Generated at 2022-06-25 00:25:06.973014
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()

# Generated at 2022-06-25 00:25:09.689290
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == {'kernel_version', 'python_version', 'system', 'machine', 'architecture', 'kernel', 'machine_id'}

# Generated at 2022-06-25 00:26:04.988266
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts_test_0 = {'kernel': '2.6.18-274.el5', 'machine': 'x86_64', 'architecture': 'x86_64', 'kernel_version': '#1 SMP Fri Jul 22 17:01:36 EDT 2011', 'python_version': '2.6.6', 'hostname': 'test_hostname_0', 'nodename': 'test_hostname_0.test_domain_0', 'domain': 'test_domain_0', 'system': 'Linux', 'fqdn': 'test_hostname_0.test_domain_0', 'machine_id': 'test_machine_id_0', 'userspace_architecture': 'x86_64', 'userspace_bits': '64'}
    platform

# Generated at 2022-06-25 00:26:06.635240
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0


# Generated at 2022-06-25 00:26:09.734435
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert isinstance(platform_facts, dict)
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['machine'] == 'x86_64'
    assert platform_facts['architecture'] == 'x86_64'
    assert platform_facts['python_version'] == '2.7.12'

# Generated at 2022-06-25 00:26:12.447083
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    print(platform_fact_collector_1.name)
    print(platform_fact_collector_1._fact_ids)


# Generated at 2022-06-25 00:26:17.214054
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector().name, str)
    assert isinstance(PlatformFactCollector()._fact_ids, set)
    assert isinstance(PlatformFactCollector().collect(), dict)

# Generated at 2022-06-25 00:26:18.875027
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    PlatformFactCollector.collect(platform_fact_collector_0)


# Generated at 2022-06-25 00:26:20.645951
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == 'platform'



# Generated at 2022-06-25 00:26:22.205009
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()

# Generated at 2022-06-25 00:26:25.438643
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    # Testing fact_ids of PlatformFactCollector
    assert set(platform_fact_collector_0.fact_ids) == set(['system',
                                                           'kernel',
                                                           'kernel_version',
                                                           'machine',
                                                           'python_version',
                                                           'architecture',
                                                           'machine_id'])

# Generated at 2022-06-25 00:26:27.428409
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_1._module = None
    platform_fact_collector_1._collected_facts = None
    platform_fact_collector_1.collect()


# Generated at 2022-06-25 00:27:48.146991
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel_version',
                                                   'architecture', 'kernel',
                                                   'machine', 'python_version',
                                                   'machine_id'}


# Generated at 2022-06-25 00:27:54.818914
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()

    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert platform_fact_collector_0.name == 'platform'

# Generated at 2022-06-25 00:27:57.432139
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert True

# Generated at 2022-06-25 00:28:00.702106
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert type(platform_fact_collector_0) == type(PlatformFactCollector())


# Generated at 2022-06-25 00:28:04.069205
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    try:
        platform_fact_collector.collect()
    except Exception:
        assert False, 'An exception was raised'
    return True


# Generated at 2022-06-25 00:28:08.800355
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-25 00:28:13.981734
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert isinstance(platform_fact_collector._fact_ids, set)
    assert set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id']) == platform_fact_collector._fact_ids


# Generated at 2022-06-25 00:28:15.067015
# Unit test for constructor of class PlatformFactCollector

# Generated at 2022-06-25 00:28:23.946718
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # create object of class PlatformFactCollector
    platform_fact_collector_1 = PlatformFactCollector()

    # create empty dictionary
    collected_facts_1 = {}

    # test for method collect of class PlatformFactCollector
    platform_facts_1 = platform_fact_collector_1.collect(collected_facts_1)

    # check whether the returned dictionary contains all
    # the key-value pairs of the expected dictionary
    assert platform_facts_1.items() >= ['system', 'kernel',
                                        'kernel_version', 'machine',
                                        'python_version'].items()

# Generated at 2022-06-25 00:28:26.524687
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform', 'Test Failed In PlatformFactCollector.name assertation'
    assert len(PlatformFactCollector._fact_ids) == 9, 'Test Failed In PlatformFactCollector._fact_ids assertation'

# Generated at 2022-06-25 00:30:19.233983
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel_version', 'machine_id', 'architecture', 'machine', 'userspace_bits', 'kernel', 'python_version', 'userspace_architecture'}


# Generated at 2022-06-25 00:30:23.476077
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.collect()


# Generated at 2022-06-25 00:30:28.178263
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert hasattr(platform_fact_collector_0, "name")
    assert hasattr(platform_fact_collector_0, "_fact_ids")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:30:34.390381
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == {'architecture', 'machine_id', 'userspace_bits', 'python_version', 'nodename', 'system', 'machine', 'domain', 'hostname', 'fqdn', 'kernel_version', 'kernel'}


# Generated at 2022-06-25 00:30:35.945251
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        platform_fact_collector_0 = PlatformFactCollector()
    except Exception:
        var_0 = False
        assert(var_0)


# Generated at 2022-06-25 00:30:41.423473
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == "platform"
    assert platform_fact_collector_1._fact_ids == set(["system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"])

# Generated at 2022-06-25 00:30:46.373861
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    var_0 = PlatformFactCollector()
    var_1 = var_0.collect()
    assert 'system' in var_1
    assert 'kernel' in var_1
    assert 'kernel_version' in var_1
    assert 'machine' in var_1
    assert 'python_version' in var_1
    assert 'architecture' in var_1
    assert 'machine_id' in var_1

# Generated at 2022-06-25 00:30:47.200512
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector()._fact_ids, set)


# Generated at 2022-06-25 00:30:49.729133
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'architecture', 'kernel_version', 'system', 'machine_id', 'python_version', 'kernel', 'machine'}


# Generated at 2022-06-25 00:30:58.470088
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert var_0 == {'system': 'Linux', 'kernel': '3.10.0-957.10.1.el7.x86_64', 'kernel_version': '#1 SMP Mon Mar 18 15:06:45 UTC 2019', 'machine': 'x86_64', 'python_version': '2.7.5', 'fqdn': 'localhost.localdomain', 'hostname': 'localhost', 'nodename': 'localhost.localdomain', 'domain': 'localdomain', 'userspace_bits': '64', 'architecture': 'x86_64'}