

# Generated at 2022-06-25 00:24:29.396864
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    p = PlatformFactCollector()
    assert p.name == 'platform'


# Generated at 2022-06-25 00:24:30.924573
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_1.collect();

# Generated at 2022-06-25 00:24:42.642348
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert 'system' in PlatformFactCollector._fact_ids
    assert 'kernel' in PlatformFactCollector._fact_ids
    assert 'kernel_version' in PlatformFactCollector._fact_ids
    assert 'machine' in PlatformFactCollector._fact_ids
    assert 'python_version' in PlatformFactCollector._fact_ids
    assert 'architecture' in PlatformFactCollector._fact_ids
    assert 'machine_id' in PlatformFactCollector._fact_ids

    data = '''Linux
    2.6.32-5-amd64
    #1 SMP Mon Mar 7 21:27:04 UTC 2011
    x86_64
    GNU/Linux
    '''
    platform_fact_collector = PlatformFactCollector()

# Generated at 2022-06-25 00:24:46.993778
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-25 00:24:47.777018
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert platform.machine() == "i386"

# Generated at 2022-06-25 00:24:54.400458
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    if platform_fact_collector_0:
        assert platform_fact_collector_0.name == 'platform'
        assert platform_fact_collector_0._fact_ids == {'system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'}


# Generated at 2022-06-25 00:24:56.545973
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc is not None

# Generated at 2022-06-25 00:25:02.104677
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])

# Generated at 2022-06-25 00:25:04.671925
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_facts = platform_fact_collector_1.collect()

    assert isinstance(platform_facts, dict)
    assert "system" in platform_facts

# Generated at 2022-06-25 00:25:10.481720
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_facts = platform_fact_collector_1.collect()
    print(platform_facts)

    platform_fact_collector_2 = PlatformFactCollector()
    platform_facts = platform_fact_collector_2.collect()
    print(platform_facts)

    platform_fact_collector_3 = PlatformFactCollector()
    platform_facts = platform_fact_collector_3.collect()
    print(platform_facts)

"""
if __name__ == '__main__':
    test_case_0()
    test_PlatformFactCollector_collect()
"""

# Generated at 2022-06-25 00:26:08.150798
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect(platform_fact_collector_1)
    assert isinstance(platform_fact_collector_1,PlatformFactCollector)



# Generated at 2022-06-25 00:26:09.375036
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # test case 1

    platform_fact_collector_1 = PlatformFactCollector()


# Generated at 2022-06-25 00:26:11.887992
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect(platform_fact_collector_0)


# Generated at 2022-06-25 00:26:18.907482
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0_collect = platform_fact_collector_0.collect(platform_fact_collector_0)
    assert sorted(platform_fact_collector_0_collect.keys()) == sorted(['kernel', 'architecture', 'kernel_version', 'python_version', 'fqdn', 'hostname', 'nodename', 'domain', 'machine', 'system'])


# Generated at 2022-06-25 00:26:25.319665
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    var = platform_fact_collector.collect(platform_fact_collector)
    assert var == {'system': 'Linux', 'kernel': '2.6.32-431.el6.x86_64', 'kernel_version': '#1 SMP Fri Nov 22 03:15:09 UTC 2013', 'machine': 'x86_64', 'python_version': '2.6.6', 'fqdn': '39.33.33.11', 'hostname': '39.33.33.11', 'nodename': '39.33.33.11', 'domain': '33.33.11', 'userspace_bits': '64', 'architecture': 'x86_64', 'userspace_architecture': 'x86_64'}


# Test case for

# Generated at 2022-06-25 00:26:28.413803
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}



# Generated at 2022-06-25 00:26:37.119940
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect(platform_fact_collector_0)

# Generated at 2022-06-25 00:26:39.615627
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass


# Generated at 2022-06-25 00:26:42.704677
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0
    assert isinstance(var_0, PlatformFactCollector)


# Generated at 2022-06-25 00:26:43.292802
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass

# Generated at 2022-06-25 00:28:22.254302
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, BaseFactCollector)


# Generated at 2022-06-25 00:28:26.525402
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])
    assert platform_fact_collector_0.name == 'platform'


# Generated at 2022-06-25 00:28:27.952339
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        test_case_0()
    except NameError as e:
        assert False

# Generated at 2022-06-25 00:28:34.463226
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect(platform_fact_collector_0)
    assert var_0['system'] == "Linux"
    assert var_0['kernel'] == "3.10.0-229.7.2.el7.x86_64"
    assert var_0['kernel_version'] == "#1 SMP Tue Jun 23 22:06:11 UTC 2015"
    assert var_0['machine'] == "x86_64"
    assert var_0['python_version'] == "2.7.5"
    assert var_0['fqdn'] == "zico.example.com"
    assert var_0['hostname'] == "zico"

# Generated at 2022-06-25 00:28:37.805569
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_obj = PlatformFactCollector()
    assert platform_fact_collector_obj.name == 'platform'
    assert platform_fact_collector_obj._fact_ids == {'architecture', 'python_version', 'kernel', 'machine', 'machine_id', 'system', 'kernel_version'}


# Generated at 2022-06-25 00:28:44.535715
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    platform_fact_collector_0 = PlatformFactCollector()
    # AssertionError: set(['kernel_version', 'domain', 'kernel', 'python_version', 'machine', 'system']) != set(['system', 'hostname', 'fqdn', 'kernel', 'kernel_version', 'python_version', 'userspace_architecture', 'nodename', 'machine', 'architecture', 'domain', 'userspace_bits'])
    # assert platform_fact_collector_0.collect(platform_fact_collector_0) == set(['system', 'hostname', 'fqdn', 'kernel', 'kernel_version', 'python_version', 'userspace_architecture', 'nodename', 'machine', 'architecture',

# Generated at 2022-06-25 00:28:47.829876
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == set(['architecture', 'python_version', 'kernel_version', 'system', 'machine', 'kernel'])

    assert str(platform_fact_collector_0) == '<platform.PlatformFactCollector>'



# Generated at 2022-06-25 00:28:51.106840
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    os_version_file = PlatformFactCollector._OS_VERSION_FILE
    _fact_ids = PlatformFactCollector._fact_ids
    name = PlatformFactCollector.name
    assert os_version_file == '/etc/os-release'
    assert _fact_ids == set(['system',
                             'kernel',
                             'kernel_version',
                             'machine',
                             'python_version',
                             'architecture',
                             'machine_id'])
    assert name == 'platform'



# Generated at 2022-06-25 00:28:53.341330
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == {'architecture', 'machine', 'system', 'kernel'}


# Generated at 2022-06-25 00:28:59.311909
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # User can provide additional arguments of type dict,
    # that will be used in calling collect method of the class PlatformFactCollector
    # if they are provided, they need to be of the same name as the attributes of
    # class PlatformFactCollector
    # below is an example to show how to do it

    platform_fact_collector_1 = PlatformFactCollector()
    # create a dict variable, with attributes of class PlatformFactCollector
    # and their corresponding values
    dict_0 = dict()
    dict_0['system'] = 'Linux'
    dict_0['kernel'] = 'Linux'
    dict_0['kernel_version'] = 'Linux'
    dict_0['machine'] = 'Linux'
    dict_0['python_version'] = 'Linux'
    dict_0['fqdn'] = 'Linux'
    dict_

# Generated at 2022-06-25 00:33:13.252926
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-25 00:33:19.773693
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])



# Generated at 2022-06-25 00:33:25.041770
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # The constructor of PlatformFactCollector should set platform.system() to module_name
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.module_name == platform.system()

    # The constructor of PlatformFactCollector should set platform.system() to name
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == platform.system()

    # The constructor of PlatformFactCollector should set {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'} to _fact_ids
    platform_fact_collector_0 = PlatformFactCollector()

# Generated at 2022-06-25 00:33:29.694446
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    var_1 = PlatformFactCollector()
    assert var_1 is not None
    assert isinstance(var_1, PlatformFactCollector)
