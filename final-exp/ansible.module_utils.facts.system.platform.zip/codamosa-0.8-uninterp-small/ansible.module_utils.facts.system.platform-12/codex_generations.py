

# Generated at 2022-06-25 00:24:23.395772
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

# Generated at 2022-06-25 00:24:34.097512
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_facts = platform_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:34.637380
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-25 00:24:45.177668
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    # For predictability sake, we're going to mock out is_windows
    #
    # And we're going to mock out system and python_version to bring
    # the test on par with the test above
    is_windows_0 = lambda: False
    system_0 = lambda: 'Linux'
    python_version_0 = lambda: '2.6.9'
    machine_0 = lambda: 'x86_64'
    architecture_0 = lambda: ['64bit']
    release_0 = lambda: '3.11.0-15-generic'
    version_0 = lambda: '#25-Ubuntu SMP Thu Jan 30 17:22:01 UTC 2014'
    node_0 = lambda: 'faux-host.domain'

# Generated at 2022-06-25 00:24:48.672300
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Instatiation of mock object
    module_class_obj = PlatformFactCollector()

    # Calling of method collect with parameters:
    # module: None
    # collected_facts: None
    module_class_obj.collect()

    # Verification of state of mock object
    # Test if the last call to method collect was called with parameters:
    # module: None
    # collected_facts: None
    # method call_args is used to get tuple of positional arguments
    assert module_class_obj.call_args == ((None, None),)



# Generated at 2022-06-25 00:24:53.352854
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()

    # TODO: Use assertRaises(AttributeError)
    try:
        platform_fact_collector_1.collect()
    except AttributeError as exc_:
        assert str(exc_) == "_fact_ids attribute is not set, cannot collect facts"


# Generated at 2022-06-25 00:24:58.842083
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])



# Generated at 2022-06-25 00:25:07.688972
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts = platform_fact_collector_0.collect()
    assert platform_facts['system'] == 'AIX'
    assert platform_facts['userspace_bits'] == '32'
    assert platform_facts['userspace_architecture'] == 'i386'
    assert platform_facts['architecture'] == 'ppc'
    assert platform_facts['machine'] == 'powerpc'
    assert 'machine_id' not in platform_facts
    #assert platform_facts['python_version'] == '2.7.5'
    #assert platform_facts['kernel_version'] == '2.6.39'
    #assert platform_facts['kernel'] == 'Linux'
    assert platform_facts['hostname'] == 'testhost'
    assert platform_facts

# Generated at 2022-06-25 00:25:09.252838
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:19.280637
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    input_platform_facts = {'machine': 'mock_machine',
                            'python_version': 'mock_python_version',
                            'fqdn': 'mock_fqdn',
                            'domain': 'mock_domain',
                            'nodename': 'mock_nodename',
                            'architecture': 'mock_architecture',
                            'kernel': 'mock_kernel',
                            'kernel_version': 'mock_kernel_version',
                            'userspace_bits': 'mock_userspace_bits',
                            'system': 'mock_system',
                            'machine_id': 'mock_machine_id'}


# Generated at 2022-06-25 00:26:08.455994
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        assert type(platform_fact_collector_0) == PlatformFactCollector
        assert type(var_0) == dict
        assert var_0['system'] == 'Linux' or var_0['system'] == 'Darwin' or var_0['system'] == 'Java' or var_0['system'] == 'Windows'
        assert type(var_0['kernel']) == str
        assert type(var_0['kernel_version']) == str
        assert type(var_0['machine']) == str
        assert type(var_0['python_version']) == str
        assert type(var_0['architecture']) == str
    except AssertionError:
        print('AssertionError: ', AssertionError)

test_PlatformFactCollector()

# Generated at 2022-06-25 00:26:17.355378
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel'] == '3.13.0-24-generic'
    assert platform_facts['kernel_version'] == '#46-Ubuntu SMP Thu Apr 10 19:11:08 UTC 2014'
    assert platform_facts['machine'] == 'x86_64'
    assert platform_facts['python_version'] == '2.7.6'
    assert platform_facts['fqdn'] == 'ubuntu.localdomain'
    assert platform_facts['nodename'] == 'ubuntu'
    assert platform_facts['domain'] == 'localdomain'
    assert platform_facts['hostname'] == 'ubuntu'
    assert platform_facts

# Generated at 2022-06-25 00:26:18.417046
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert True == isinstance(PlatformFactCollector().collect(), dict)

# Generated at 2022-06-25 00:26:20.210588
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:26:23.478794
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'kernel', 'architecture', 'machine_id', 'system', 'machine', 'kernel_version', 'python_version'}

# Generated at 2022-06-25 00:26:24.760562
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:29.580601
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        assert platform.system()
    except NameError:
        assert False, "PlatforFactCollector(): Unable to get value of system attribute"
    try:
        assert platform.release()
    except NameError:
        assert False, "PlatforFactCollector(): Unable to get value of kernel attribute"
    try:
        assert platform.version()
    except NameError:
        assert False, "PlatforFactCollector(): Unable to get value of kernel_version attribute"
    try:
        assert platform.machine()
    except NameError:
        assert False, "PlatforFactCollector(): Unable to get value of machine attribute"
    try:
        assert platform.python_version()
    except NameError:
        assert False, "PlatforFactCollector(): Unable to get value of python_version attribute"

# Generated at 2022-06-25 00:26:33.410109
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Test 1, check if the facts are correctly collected from a linux system

# Generated at 2022-06-25 00:26:35.122400
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()

    assert platform_fact_collector_0.name == 'platform'


# Generated at 2022-06-25 00:26:41.841552
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    assert var_1[u'fqdn'] == u'localhost.localdomain'
    assert var_1[u'userspace_bits'] == u'64'
    assert var_1[u'hostname'] == u'localhost'
    assert var_1[u'kernel_version'] == u'4.4.0-21-generic'
    assert var_1[u'kernel'] == u'4.4.0-21-generic'
    assert var_1[u'system'] == u'Linux'
    assert var_1[u'architecture'] == u'x86_64'

# Generated at 2022-06-25 00:27:55.101535
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
   platform_fact_collector_1 = PlatformFactCollector()
   assert isinstance(platform_fact_collector_1, PlatformFactCollector)


# Generated at 2022-06-25 00:27:56.586113
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        platform_fact_collector = PlatformFactCollector()
        print("Success")
    except Exception as exception:
        print("Exception: ", exception)


# Generated at 2022-06-25 00:28:04.442678
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    var_1 = PlatformFactCollector()
    # Verify that name property is present
    assert hasattr(var_1, 'name')
    # Verify that name property is string type
    assert isinstance(var_1.name, str)
    # Verify that _fact_ids property is present
    assert hasattr(var_1, '_fact_ids')
    # Verify that _fact_ids property is set type
    assert isinstance(var_1._fact_ids, set)
    # Verify that collect method is present
    assert hasattr(var_1, 'collect')
    # Verify that collect method is callable
    assert callable(var_1.collect)



# Generated at 2022-06-25 00:28:07.945759
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:28:08.965385
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.collect() is not None


# Generated at 2022-06-25 00:28:12.480897
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    # Test with valid input.
    var_1 = platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:17.764946
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    # Check attribute name of class PlatformFactCollector
    assert platform_fact_collector.name == 'platform'

    # Check attribute _fact_ids of class PlatformFactCollector
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-25 00:28:23.785136
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])


# Generated at 2022-06-25 00:28:24.851155
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert '__init__' in dir(PlatformFactCollector)


# Generated at 2022-06-25 00:28:25.963504
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_instance = PlatformFactCollector()

# Generated at 2022-06-25 00:31:26.715292
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version',
                                                       'machine', 'python_version',
                                                       'architecture', 'machine_id'])

# Generated at 2022-06-25 00:31:29.177943
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect({'get_bin_path': test_sets_PlatformFactCollector_collect_0, 'run_command': test_sets_PlatformFactCollector_collect_1})

# Unit test

# Generated at 2022-06-25 00:31:33.012374
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    print('Testing constructor')
    platform_fact_collector_0 = PlatformFactCollector()



# Generated at 2022-06-25 00:31:36.788014
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_1 = platform_fact_collector_0.collect()
    var_1 = platform_fact_collector_0.collect()
    var_2 = platform_fact_collector_0.collect()
    assert var_1 is var_2
    var_3 = platform_fact_collector_0.collect()
    assert var_1 is var_3


# Generated at 2022-06-25 00:31:39.223848
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:31:43.050324
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    var_1 = PlatformFactCollector()
    assert var_1.name == "platform"
    assert var_1._fact_ids == {"system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"}

# Generated at 2022-06-25 00:31:44.095827
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert platform_fact_collector_0.collect() == None

# Generated at 2022-06-25 00:31:46.373226
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_1.collect()

test_case_0()

# Generated at 2022-06-25 00:31:52.465831
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == 'platform'
    assert platform_fact_collector_1._fact_ids == {'architecture', 'kernel', 'kernel_version', 'machine', 'machine_id', 'system', 'python_version'}


# Generated at 2022-06-25 00:31:54.660707
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert set(platform_fact_collector._fact_ids) == {'system', 'kernel',
        'kernel_version', 'machine', 'python_version', 'architecture',
        'machine_id'}
