

# Generated at 2022-06-25 00:24:28.883195
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)
    assert isinstance(PlatformFactCollector.name, str)
    assert isinstance(PlatformFactCollector._fact_ids, set)



# Generated at 2022-06-25 00:24:29.876236
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:24:34.396754
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, PlatformFactCollector)
    assert platform_fact_collector._fact_ids == frozenset({'system',
                                                           'kernel',
                                                           'kernel_version',
                                                           'machine',
                                                           'python_version',
                                                           'architecture',
                                                           'machine_id'})


# Generated at 2022-06-25 00:24:44.928746
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

    ansible_module = AnsibleModule()

    ansible_module.run_command = test_run_command
    ansible_module.get_bin_path = test_get_bin_path

    plat_fact_dict = platform_fact_collector_0.collect(module=ansible_module, collected_facts=None)

if __name__ == '__main__':
    #import nose
    #nose.runmodule(argv=[__file__, '-vvs', '-x', '--pdb', '--pdb-failure'],
    #               exit=False)

    # test case 0 is already executed
    test_case_0()  # call test case 0
    test_PlatformFactCollector_collect()  # call test case 1

# Generated at 2022-06-25 00:24:45.937511
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:24:56.819102
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_facts = dict()
    platform_facts['system'] = platform.system()
    platform_facts['kernel'] = platform.release()
    platform_facts['kernel_version'] = platform.version()
    platform_facts['machine'] = platform.machine()

    platform_facts['python_version'] = platform.python_version()

    platform_facts['fqdn'] = socket.getfqdn()
    platform_facts['hostname'] = platform.node().split('.')[0]
    platform_facts['nodename'] = platform.node()

    platform_facts['domain'] = '.'.join(platform_facts['fqdn'].split('.')[1:])

    arch_bits = platform.architecture()[0]

    platform_facts['userspace_bits'] = arch_bits.replace('bit', '')


# Generated at 2022-06-25 00:24:58.794133
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:04.632754
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test the constructor of class PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()
    # Test the 'name' attribute of class PlatformFactCollector
    assert platform_fact_collector.name == "platform"
    # Test the '_fact_ids' attribute of class PlatformFactCollector
    assert platform_fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}



# Generated at 2022-06-25 00:25:05.171859
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-25 00:25:14.733551
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['system'] == 'Linux'
    #assert platform_facts['kernel'] == 'Linux'
    #assert platform_facts['kernel_version'] == 'Linux'
    assert platform_facts['machine'] == 'x86_64'
    #assert platform_facts['python_version'] == 'Linux'
    #assert platform_facts['fqdn'] == 'Linux'
    #assert platform_facts['hostname'] == 'Linux'
    #assert platform_facts['nodename'] == 'Linux'
    #assert platform_facts['domain'] == 'Linux'
    #assert platform_facts['userspace_bits'] == 'Linux'
    assert platform_facts['architecture'] == 'x86_64'

# Generated at 2022-06-25 00:26:45.395402
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()
    platform_facts_output_dict = dict(
        kernel='Linux',
        kernel_version='4.4.0-22-generic',
        machine='x86_64',
        userspace_bits='64',
        system='Linux',
        arch='x86_64',
        python_version='2.7.12',
        machine_id='NOT_FOUND',
        architecture='x86_64',
        fqdn='Linux_box',
        domain_name='ansible',
        domain='ansible',
        hostname='Linux_box',
        nodename='Linux_box'
    )


# Generated at 2022-06-25 00:26:46.973544
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'

# Generated at 2022-06-25 00:26:52.350053
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Set up test environment prior to test
    platform_fact_collector_1 = PlatformFactCollector()
    # invoke the method being tested
    result = platform_fact_collector_1.collect()
    # should be non-empty
    assert result is not None

# Generated at 2022-06-25 00:26:55.913710
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-25 00:27:00.561015
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert '<PlatformFactCollector(name=platform, fact_ids=set([\'python_version\', \'system\', \'machine\', \'architecture\', \'kernel\', \'machine_id\', \'kernel_version\']))>' == repr(PlatformFactCollector())


# Generated at 2022-06-25 00:27:04.752896
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    msg = "Class 'PlatformFactCollector' does not have a 'name' attribute."
    assert hasattr(platform_fact_collector_0, 'name'), msg
    msg = "Class 'PlatformFactCollector' does not have a '_fact_ids' attribute."
    assert hasattr(platform_fact_collector_0, '_fact_ids'), msg
    msg = "Class 'PlatformFactCollector' does not have a 'collect' method."
    assert hasattr(platform_fact_collector_0, 'collect'), msg

# Generated at 2022-06-25 00:27:14.542124
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['python_version'] == platform.python_version()
    assert platform_facts['fqdn'] == socket.getfqdn()
    assert platform_facts['hostname'] == platform.node().split('.')[0]
    assert platform_facts['nodename'] == platform.node()
    assert platform_facts['domain'] == '.'.join(platform_facts['fqdn'].split('.')[1:])

# Generated at 2022-06-25 00:27:19.079203
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])


# Generated at 2022-06-25 00:27:21.715126
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()
    assert platform_fact_collector.collect() != {}


# Generated at 2022-06-25 00:27:30.003629
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    collected_facts = dict()
    platform_facts = platform_fact_collector_0.collect(collected_facts=collected_facts)

    assert platform_facts['system'] == 'Linux'
    assert 'kernel' in platform_facts
    assert 'kernel_version' in platform_facts
    assert platform_facts['machine'] == 'x86_64'

    assert platform_facts['python_version'] == '2.7.5'

    assert platform_facts['fqdn'] == 'localhost'
    assert platform_facts['hostname'] == 'localhost'
    assert platform_facts['nodename'] == 'localhost'
    assert platform_facts['domain'] == 'localhost'

    assert platform_facts['userspace_bits'] == '64'
    assert platform_facts

# Generated at 2022-06-25 00:31:00.020503
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert(platform_fact_collector.name == 'platform')
    assert(platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                                     'python_version', 'architecture', 'machine_id']))

# Generated at 2022-06-25 00:31:01.374403
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    print('Testing collect of class PlatformFactCollector')
    platform_fact_collector.collect()

# Generated at 2022-06-25 00:31:08.997739
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector( )
    assert platform_fact_collector_0.collect( ) == { 'hostname': platform.node().split('.')[0], 'architecture': platform.machine(), 'kernel': platform.release(), 'domain': '.'.join(socket.getfqdn().split('.')[1:]), 'system': platform.system(), 'machine': platform.machine(), 'python_version': platform.python_version(), 'kernel_version': platform.version(), 'userspace_bits': platform.architecture()[0].replace('bit', ''), 'nodename': platform.node(), 'fqdn': socket.getfqdn( ) }

# Generated at 2022-06-25 00:31:12.317214
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"
    assert platform_fact_collector._fact_ids == {"system","kernel","kernel_version","machine","python_version","architecture"}



# Generated at 2022-06-25 00:31:13.521324
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert True


# Generated at 2022-06-25 00:31:20.425925
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    current_platform = platform.system()
    # Assert that FQDN is used instead of hostname on Linux in the domain of the FQDN
    if current_platform == "Linux":
        current_fqdn = platform.node()
        current_hostname = current_fqdn.split(".", 1)[0]
        current_domain = current_fqdn.split(".", 1)[1]
        assert current_hostname in PlatformFactCollector().collect()["hostname"]
        assert current_domain in PlatformFactCollector().collect()["domain"]
    # Assert that hostname is used on Darwin and Windows instead of FQDN
    elif current_platform == "Darwin" or current_platform == "Windows":
        assert PlatformFactCollector().collect()["hostname"] in PlatformFactCollector().collect()["fqdn"]
   

# Generated at 2022-06-25 00:31:26.257580
# Unit test for constructor of class PlatformFactCollector

# Generated at 2022-06-25 00:31:26.985689
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector()

# Generated at 2022-06-25 00:31:28.437245
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0 is not None



# Generated at 2022-06-25 00:31:29.061591
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()
