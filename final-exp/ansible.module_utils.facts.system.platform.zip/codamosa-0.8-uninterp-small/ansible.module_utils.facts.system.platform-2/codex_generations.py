

# Generated at 2022-06-25 00:24:16.443410
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == 'platform'
    assert platform_fact_collector_1._fact_ids == set(['system',
                                                        'kernel',
                                                        'kernel_version',
                                                        'machine',
                                                        'python_version',
                                                        'architecture',
                                                        'machine_id'])


# Generated at 2022-06-25 00:24:21.355296
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert (platform_fact_collector_0._fact_ids.__class__.__name__ == 'set'), \
        "Assertion 'platform_fact_collector_0._fact_ids.__class__.__name__ == 'set'"
    assert (platform_fact_collector_0._fact_ids.__len__() == 8), \
        "Assertion 'platform_fact_collector_0._fact_ids.__len__() == 8'"
    assert (platform_fact_collector_0.name == 'platform'), \
        "Assertion 'platform_fact_collector_0.name == 'platform'"


# Generated at 2022-06-25 00:24:23.274306
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:24:31.275424
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert(platform_fact_collector_1.name == 'platform')
    assert(platform_fact_collector_1._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id']))


# Generated at 2022-06-25 00:24:40.672450
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert 'platform' == platform_fact_collector.name
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids

# Generated at 2022-06-25 00:24:43.244435
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts_result = platform_fact_collector.collect()
    print(platform_facts_result)


# Generated at 2022-06-25 00:24:44.940382
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert platform_fact_collector_0.name == 'platform'


# Generated at 2022-06-25 00:24:51.469361
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_collect = PlatformFactCollector()
    assert platform_fact_collector_collect.collect() == \
            {'system': platform.system(), 'kernel': platform.release(), 'kernel_version': platform.version(), 'machine': platform.machine(), 'python_version': platform.python_version(), 'fqdn': socket.getfqdn(), 'hostname': platform.node().split('.')[0], 'nodename': platform.node(), 'domain': '.'.join(socket.getfqdn().split('.')[1:]), 'userspace_bits': platform.architecture()[0].replace('bit', ''), 'architecture': platform.machine(), 'userspace_architecture': 'i386'}

# Generated at 2022-06-25 00:24:56.690420
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-25 00:24:58.666743
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert "system" in platform_fact_collector.collect()

# Generated at 2022-06-25 00:25:28.797258
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1._fact_ids == {
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'
    }
    assert platform_fact_collector_1.__name__ == 'platform'


# Generated at 2022-06-25 00:25:32.994796
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:35.897452
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == "platform"
    assert platform_fact_collector_0._fact_ids == {"system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"}


# Generated at 2022-06-25 00:25:38.123812
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    var_1 = PlatformFactCollector()
    assert var_1 != None


# Generated at 2022-06-25 00:25:45.203834
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert len(platform_fact_collector_0._fact_ids) == 9
    assert 'system' in platform_fact_collector_0._fact_ids
    assert 'kernel' in platform_fact_collector_0._fact_ids
    assert 'kernel_version' in platform_fact_collector_0._fact_ids
    assert 'machine' in platform_fact_collector_0._fact_ids
    assert 'python_version' in platform_fact_collector_0._fact_ids
    assert 'architecture' in platform_fact_collector_0._fact_ids
    assert 'machine_id' in platform_fact_collector_0._fact_ids


# Generated at 2022-06-25 00:25:53.266293
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert var_0['system'] == 'Linux'
    assert var_0['kernel'] == '3.10.0-693.el7.x86_64'
    assert var_0['kernel_version'] == '#1 SMP Thu Jul 6 19:56:57 EDT 2017'
    assert var_0['machine'] == 'x86_64'
    assert var_0['python_version'] == '2.7.14'
    assert var_0['fqdn'] == 'localhost.localdomain'
    assert var_0['hostname'] == 'localhost'
    assert var_0['nodename'] == 'localhost.localdomain'

# Generated at 2022-06-25 00:26:00.265579
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0._fact_ids, set), \
        "Incorrect constructor format"
    assert set(platform_fact_collector_0._fact_ids) == set(['system',
                                                            'kernel',
                                                            'kernel_version',
                                                            'machine',
                                                            'python_version',
                                                            'architecture',
                                                            'machine_id']), \
        "Incorrect constructor format"
    assert platform_fact_collector_0.name == 'platform', \
        "Incorrect constructor format"


# Generated at 2022-06-25 00:26:02.498850
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert not hasattr(platform_fact_collector_0, 'facts')
    assert not hasattr(platform_fact_collector_0, 'module')


# Generated at 2022-06-25 00:26:09.721429
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

    assert 'machine' in var_0, "Key 'machine' should be present in returned dict"
    assert 'system' in var_0, "Key 'system' should be present in returned dict"
    assert 'machine_id' in var_0, "Key 'machine_id' should be present in returned dict"
    assert 'python_version' in var_0, "Key 'python_version' should be present in returned dict"
    assert 'domain' in var_0, "Key 'domain' should be present in returned dict"
    assert 'architecture' in var_0, "Key 'architecture' should be present in returned dict"

# Generated at 2022-06-25 00:26:11.768408
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_1 = platform_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_PlatformFactCollector_collect()

# Generated at 2022-06-25 00:27:11.838970
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    var = dict(system=String(), kernel=String(), kernel_version=String(), machine=String(), python_version=String(), fqdn=String(), hostname=String(), nodename=String(), domain=String(), userspace_bits=String(), userspace_architecture=String(), architecture=String(), machine_id=String())
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    assert var == var_1

# Generated at 2022-06-25 00:27:13.640789
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    var_0 = test_case_0()


if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-25 00:27:19.850714
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    var = platform_fact_collector.collect()
    assert isinstance(var, dict)
    assert var['domain'] == 'example.com'
    assert var['fqdn'] == 'this.is.example.com'
    assert var['userspace_bits'] == '64'
    assert var['machine_id'] == 'a2a624f2ce2d4fd4841f6dd7f6d1e9a1'
    assert var['system'] == 'Linux'
    assert var['hostname'] == 'this'
    assert var['nodename'] == 'this.is.example.com'
    assert var['machine'] == 'x86_64'
    assert var['kernel'] == '4.4.0-104-generic'
    assert var

# Generated at 2022-06-25 00:27:24.364108
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:31.927487
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert ((var_0['system']) == 'Linux')
    assert ((var_0['kernel']) == '3.13.0-32-generic')
    assert ((var_0['kernel_version']) == '#57-Ubuntu SMP Tue Jul 15 03:51:08 UTC 2014')
    assert ((var_0['machine']) == 'x86_64')
    assert ((var_0['python_version']) == '2.7.6')
    assert ((var_0['fqdn']) == 'localhost')
    assert ((var_0['hostname']) == 'localhost')
    assert ((var_0['nodename']) == 'localhost')

# Generated at 2022-06-25 00:27:37.902442
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    assert type(var_1) == dict
    assert 'system' in var_1
    assert type(var_1['system']) == str
    assert 'kernel' in var_1
    assert type(var_1['kernel']) == str
    assert 'kernel_version' in var_1
    assert type(var_1['kernel_version']) == str
    assert 'machine' in var_1
    assert type(var_1['machine']) == str
    assert 'python_version' in var_1
    assert type(var_1['python_version']) == str
    assert 'fqdn' in var_1
    assert type(var_1['fqdn']) == str

# Generated at 2022-06-25 00:27:43.327087
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module_0 = AnsibleModuleFake()
    collected_facts_0 = AnsibleModuleFake()
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect(module_0, collected_facts_0)
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:27:46.967823
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup
    platform_fact_collector = PlatformFactCollector()

    # Stub out method
    class StubModule(object):
        def get_bin_path(self, arg):
            return '/bin/getconf'
        def run_command(self, arg):
            return (0, 'i386', '')
    platform_fact_collector.module = StubModule()

    # Assert
    assert 'architecture' in platform_fact_collector.collect()

# Generated at 2022-06-25 00:27:52.832918
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()

    assert var_1 == {
        'architecture': 'x86_64',
        'domain': 'local',
        'fqdn': 'ansible.local',
        'hostname': 'ansible',
        'machine': 'x86_64',
        'machine_id': 'a6e42c6aaa8a4c5b8b5c5f16a5e811d1',
        'nodename': 'ansible.local',
        'python_version': '2.7.5',
        'system': 'Linux',
        'userspace_architecture': 'x86_64',
        'userspace_bits': '64'
    }

#

# Generated at 2022-06-25 00:27:54.878220
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    var = platform_fact_collector.collect()
    assert var is not None


# Generated at 2022-06-25 00:31:06.738613
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
   s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Generated at 2022-06-25 00:31:11.417983
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel_version', 'python_version', 'architecture', 'kernel', 'machine', 'machine_id'}


# Generated at 2022-06-25 00:31:14.257343
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    var_0 = PlatformFactCollector()
    var_1 = var_0.collect()
    assert "abstract" not in var_1

    var_2 = PlatformFactCollector()
    var_3 = var_2.collect()
    assert "abstract" not in var_3

# Generated at 2022-06-25 00:31:15.546216
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platformFactCollector = PlatformFactCollector()
    assert(platformFactCollector.name == 'platform')

# Generated at 2022-06-25 00:31:16.951054
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    var = PlatformFactCollector()
    assert type(var) == PlatformFactCollector


# Generated at 2022-06-25 00:31:21.498854
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    x = PlatformFactCollector()
    x.collect()

# Generated at 2022-06-25 00:31:25.834120
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector_0 = PlatformFactCollector()
    # unit test to check whether _fact_ids is assigned with set of strings
    assert isinstance(platform_fact_collector_0._fact_ids, set) and all([isinstance(val, str) for val in platform_fact_collector_0._fact_ids])
    # unit test to check whether name is assigned with string
    assert isinstance(platform_fact_collector_0.name, str)



# Generated at 2022-06-25 00:31:27.070182
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:28.267352
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 00:31:29.621828
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
