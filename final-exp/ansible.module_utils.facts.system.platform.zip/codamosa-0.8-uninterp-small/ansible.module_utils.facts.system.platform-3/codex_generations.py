

# Generated at 2022-06-25 00:24:14.616934
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert type(platform_facts) is dict
    assert set(platform_facts.keys()) == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id', 'fqdn', 'hostname', 'nodename', 'domain'}
    assert platform_facts['architecture'] == platform.machine()
    assert re.search(r'\d\.\d(\.\d)?', platform_facts['python_version'])
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['kernel_version'] == platform.version()
    assert platform_facts['machine'] == platform.machine()
    assert platform_facts['system'] == platform

# Generated at 2022-06-25 00:24:15.476000
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert(isinstance(PlatformFactCollector(), BaseFactCollector))

# Generated at 2022-06-25 00:24:20.876674
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts_0 = platform_fact_collector_0.collect()

    assert len(platform_facts_0) > 0
    assert 'architecture' in platform_facts_0
    assert 'fqdn' in platform_facts_0
    assert 'hostname' in platform_facts_0
    assert 'kernel' in platform_facts_0
    assert 'kernel_version' in platform_facts_0
    assert 'machine' in platform_facts_0
    assert 'python_version' in platform_facts_0
    assert 'system' in platform_facts_0
    assert 'userspace_bits' in platform_facts_0
    assert 'nodename' in platform_facts_0


# Generated at 2022-06-25 00:24:25.324516
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert len(PlatformFactCollector()._fact_ids) == 8

# def test_case(module):
#     platform_facts_0 = PlatformFactCollector().collect()
#     assert platform_facts_0['system'] == platform.system()
#     assert platform_facts_0['kernel'] == platform.release()
#     assert platform_facts_0['kernel_version'] == platform.version()
#     assert platform_facts_0['machine'] == platform.machine()
#
#     assert platform_facts_0['python_version'] == platform.python_version()
#
#     assert platform_facts_0['fqdn'] == socket.getfqdn()
#     assert platform_facts_0['hostname'] == platform.node().split('.')[0]
#     assert platform_facts_0['nodename'] == platform

# Generated at 2022-06-25 00:24:31.784569
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    # Test if name is set
    assert platform_fact_collector.name == 'platform'

    # Test if _fact_ids is set
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine',
                                                     'python_version', 'architecture', 'machine_id'])



# Generated at 2022-06-25 00:24:34.594083
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'



# Generated at 2022-06-25 00:24:42.549747
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {
        'machine_id',
        'kernel',
        'fqdn',
        'nodename',
        'system',
        'kernel_version',
        'machine',
        'architecture',
        'python_version',
        'hostname',
        'domain',
        'userspace_bits',
        'userspace_architecture'
    }


# Generated at 2022-06-25 00:24:50.705788
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

    x = platform_fact_collector_0.collect()
    assert x['system'] == 'Linux'
    assert x['kernel'] == '3.10.0-229.11.1.el7.x86_64'
    assert x['kernel_version'] == '#1 SMP Fri Mar 6 11:36:42 UTC 2015'
    assert x['machine'] == 'x86_64'
    assert x['python_version'] == '2.7.5'
    assert x['architecture'] == 'x86_64'
    assert x['userspace_architecture'] == 'x86_64'
    assert x['nodename'] == 'vmbuilder1.example.com'

# Generated at 2022-06-25 00:24:52.960208
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()

test_case_0()
test_PlatformFactCollector()

# Generated at 2022-06-25 00:25:01.530999
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

    collected_facts_1 = {}

    platform_facts_1 = platform_fact_collector_0.collect(collected_facts_1)

    assert 'system' in platform_facts_1.keys()
    assert 'kernel' in platform_facts_1.keys()
    assert 'kernel_version' in platform_facts_1.keys()
    assert 'machine' in platform_facts_1.keys()
    assert 'python_version' in platform_facts_1.keys()
    assert 'architecture' in platform_facts_1.keys()
    assert 'fqdn' in platform_facts_1.keys()
    assert 'hostname' in platform_facts_1.keys()
    assert 'nodename' in platform_facts_1.keys()

# Generated at 2022-06-25 00:26:20.629979
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_facts = platform_fact_collector_1.collect({}, {})
    assert 'system' in platform_facts
    assert 'kernel' in platform_facts
    assert 'machine' in platform_facts
    assert 'python_version' in platform_facts
    assert 'architecture' in platform_facts
    assert 'nodename' in platform_facts
    assert 'fqdn' in platform_facts
    assert 'domain' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'hostname' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'userspace_architecture' in platform_facts
    assert 'machine_id' in platform_facts

# Generated at 2022-06-25 00:26:30.210674
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()

    collected_facts = dict()
    platform_facts = platform_fact_collector_1.collect(collected_facts=collected_facts)
    assert isinstance(platform_facts, dict)
    assert isinstance(platform_facts['system'], str)
    assert isinstance(platform_facts['kernel'], str)
    assert isinstance(platform_facts['kernel_version'], str)
    assert isinstance(platform_facts['machine'], str)
    assert isinstance(platform_facts['python_version'], str)
    assert isinstance(platform_facts['fqdn'], str)
    assert isinstance(platform_facts['hostname'], str)
    assert isinstance(platform_facts['nodename'], str)

# Generated at 2022-06-25 00:26:34.974555
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'

    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-25 00:26:38.527604
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

    platform_facts = platform_fact_collector.collect()
    assert platform_facts
    assert platform_facts['architecture']
    assert platform_facts['kernel']
    assert platform_facts['kernel_version']
    assert platform_facts['machine']
    assert platform_facts['python_version']
    assert platform_facts['system']

# Generated at 2022-06-25 00:26:42.434759
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.collect() is not None
    assert platform_fact_collector_0.collect()['system'] is not None

# Generated at 2022-06-25 00:26:50.686566
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

# Generated at 2022-06-25 00:26:54.336971
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc._fact_ids == {'machine_id', 'nodename', 'architecture',
                             'kernel_version', 'system', 'machine',
                             'kernel', 'domain', 'python_version', 'hostname',
                             'userspace_bits', 'fqdn', 'userspace_architecture'}

# Generated at 2022-06-25 00:26:59.463962
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'


# Generated at 2022-06-25 00:27:04.908988
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts_0 = platform_fact_collector_0.collect()
    if len(platform_facts_0) < 1:
        assert False, 'Platform collection failed'

    if len(PlatformFactCollector._fact_ids) != len(platform_facts_0):
        assert False, 'Platform collected more than {} facts'.format(len(PlatformFactCollector._fact_ids))

    for a_key in platform_facts_0:
        if a_key not in PlatformFactCollector._fact_ids:
            assert False, 'Extra fact "{}" collected'.format(a_key)

# Generated at 2022-06-25 00:27:06.851275
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0 is not None


# Generated at 2022-06-25 00:30:19.646954
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    data = platform_fact_collector_0.collect()
    assert data['system'] is not None
    assert data['kernel'] is not None
    assert data['kernel_version'] is not None
    assert data['machine'] is not None
    assert data['python_version'] is not None
    assert data['architecture'] is not None
    assert data['machine_id'] is not None

# Generated at 2022-06-25 00:30:22.414807
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

    platform_facts = platform_fact_collector_0.collect()

    assert platform_facts['system'] == platform.system()
    assert platform_facts['kernel'] == platform.release()
    assert platform_facts['machine'] == platform.machine()

# Generated at 2022-06-25 00:30:27.177792
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None
    assert platform_fact_collector.name == 'platform'
    assert len(platform_fact_collector._fact_ids) == 9


# Generated at 2022-06-25 00:30:28.062204
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:30:30.466018
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_1 = PlatformFactCollector()

    assert platform_fact_collector_0 is not platform_fact_collector_1,\
        'Each PlatformFactCollector constructor should return a new instance.'



# Generated at 2022-06-25 00:30:31.442025
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None

# Generated at 2022-06-25 00:30:32.816511
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:30:33.632393
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert len(PlatformFactCollector()._fact_ids) > 0


# Generated at 2022-06-25 00:30:35.610471
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    # No need to test the facts returned since they can change constantly
    results = platform_fact_collector_1.collect(collected_facts={})
    assert isinstance(results, dict)

# Generated at 2022-06-25 00:30:39.572302
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
