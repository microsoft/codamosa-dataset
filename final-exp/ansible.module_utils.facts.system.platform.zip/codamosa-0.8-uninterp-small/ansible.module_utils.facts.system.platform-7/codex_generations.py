

# Generated at 2022-06-25 00:24:23.339179
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    # TODO: Fix this test
    # assert platform_fact_collector_0.name == 'platform'



# Generated at 2022-06-25 00:24:27.855581
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'


# Generated at 2022-06-25 00:24:29.556080
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:35.650151
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    fact_list = platform_fact_collector.collect()
    assert fact_list["fqdn"] == socket.getfqdn()
    assert fact_list["hostname"] == platform.node().split('.')[0]
    assert fact_list["nodename"] == platform.node()
    assert fact_list["domain"] == '.'.join(fact_list["fqdn"].split('.')[1:])
    assert fact_list["system"] == 'Linux'
    assert fact_list["kernel"] == platform.release()
    assert fact_list["machine"] == platform.machine()
    assert fact_list["architecture"] == platform.machine()

# Generated at 2022-06-25 00:24:41.502088
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-25 00:24:46.345856
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel',
                                                   'kernel_version', 'machine',
                                                   'python_version', 'architecture',
                                                   'machine_id'}

# Generated at 2022-06-25 00:24:52.812483
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

# Generated at 2022-06-25 00:24:56.661236
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test for correct instance creation for class PlatformFactCollector
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)


# Generated at 2022-06-25 00:24:57.573277
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-25 00:25:00.685418
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-25 00:26:20.067206
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids


# Generated at 2022-06-25 00:26:25.055492
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None

# Generated at 2022-06-25 00:26:28.972108
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'architecture', 'machine', 'machine_id', 'kernel_version', 'nodename', 'system', 'python_version', 'fqdn', 'kernel', 'domain', 'hostname'}


# Generated at 2022-06-25 00:26:34.532544
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert not hasattr(platform_fact_collector_0, '_module')
    assert not hasattr(platform_fact_collector_0, '_collected_facts')

# Generated at 2022-06-25 00:26:39.620641
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    collected_facts_1 = {}
    ansible_module_1 = FakeAnsibleModule()
    platform_facts_1 = platform_fact_collector_1.collect(ansible_module_1, collected_facts_1)
    assert set(platform_facts_1.keys()) == set(collected_facts_1.keys()) == platform_fact_collector_1._fact_ids and isinstance(platform_facts_1, dict) == isinstance(collected_facts_1, dict)



# Generated at 2022-06-25 00:26:42.395094
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_facts_1 = platform_fact_collector_1.collect()
    print(platform_facts_1)

# Generated at 2022-06-25 00:26:43.088324
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass

# Generated at 2022-06-25 00:26:48.129172
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id']), "Expected a different fact_ids value"
    assert platform_fact_collector_0.name == 'platform', "Expected a different name value"


# Generated at 2022-06-25 00:26:51.610518
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    pfc = PlatformFactCollector()


# Generated at 2022-06-25 00:26:55.659004
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system','kernel','kernel_version','machine','python_version','architecture','machine_id'}


# Generated at 2022-06-25 00:28:14.150913
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()

    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}
    assert isinstance(platform_fact_collector_0.collect(), dict) is True

# Generated at 2022-06-25 00:28:14.803764
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

# Generated at 2022-06-25 00:28:25.218717
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector) is True
    # A call to collect
    var_0 = platform_fact_collector_0.collect()
    #assert str(var_0) == "{'architecture': 'x86_64', 'system': 'Linux', 'machine': 'x86_64', 'kernel': '1.2.3', 'kernel_version': '1.2.3', 'python_version': '2.7.1', 'machine_id': 'bogus'}"
    assert isinstance(var_0, dict) is True
    assert 'system' in var_0
    assert 'kernel' in var_0
    assert 'kernel_version' in var_0
    assert 'machine' in var_

# Generated at 2022-06-25 00:28:26.903807
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == "platform"

# Generated at 2022-06-25 00:28:28.528411
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()

# Generated at 2022-06-25 00:28:30.060360
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    global platform_fact_collector_0
    # Constructor test
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:28:36.225957
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_platform_obj = PlatformFactCollector()

    platform_facts = test_platform_obj.collect()
    # Assert machine value is one of expected values.

# Generated at 2022-06-25 00:28:38.068286
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_1 = platform_fact_collector_0.collect()
    assert isinstance(var_1, dict) == True


# Generated at 2022-06-25 00:28:41.940789
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == 'platform'
    assert platform_fact_collector_1._fact_ids == set(['system',
                                                        'kernel',
                                                        'kernel_version',
                                                        'machine',
                                                        'python_version',
                                                        'architecture',
                                                        'machine_id'])


# Generated at 2022-06-25 00:28:45.507345
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    constructor_input_vars = []

    # No-args constructor test
    try:
        PlatformFactCollector()
        assert True
    except Exception:
        assert False

    # Args-constructor test
    try:
        PlatformFactCollector(constructor_input_vars)
        assert True
    except Exception:
        assert False

# Generated at 2022-06-25 00:31:40.702422
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # unit test case for collect
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:31:42.219573
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()

# Generated at 2022-06-25 00:31:46.242797
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_self = PlatformFactCollector()
    assert platform_fact_collector_self.name == 'platform' and platform_fact_collector_self._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-25 00:31:50.557794
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, PlatformFactCollector)


# Generated at 2022-06-25 00:31:52.396319
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert hasattr(platform_fact_collector_0, "name")


# Generated at 2022-06-25 00:31:59.145131
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert var_0 == {'system': 'Linux', 'kernel': '4.4.0-93-generic', 'kernel_version': '#116-Ubuntu SMP Fri Aug 11 21:17:51 UTC 2017', 'machine': 'x86_64', 'python_version': '3.5.2', 'fqdn': 'tesseract', 'hostname': 'tesseract', 'nodename': 'tesseract', 'domain': 'local', 'userspace_bits': '64', 'architecture': 'x86_64', 'machine_id': '4f4e7e879c6d4d6ea79efc0f570348f6'}


# Unit

# Generated at 2022-06-25 00:32:01.332633
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    expected = 'system'
    tmp = PlatformFactCollector()
    actual = tmp._fact_ids
    assert actual == expected

# Generated at 2022-06-25 00:32:01.999663
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass


# Generated at 2022-06-25 00:32:03.297416
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0 is not None


# Generated at 2022-06-25 00:32:12.610276
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    import pytest
    import sys
    import os
    import tempfile
    import subprocess
    import platform as py_platform
    import ansible.module_utils.facts.collector

    my_system = py_platform.system()

    if my_system == "Windows":
        pytest.skip("Platform facts for Windows are not implemented yet")

    elif my_system == "Linux":
        from ansible.module_utils._text import to_bytes
        # Create a temporary directory
        tmp_dir = tempfile.mkdtemp()

        # Create a temporary file inside
        tmp_file = os.path.join(tmp_dir, "tmp_file.txt")
        f = open(tmp_file, 'wb')
        f.write(to_bytes("text"))
        f.close()

        # Rename the file
       