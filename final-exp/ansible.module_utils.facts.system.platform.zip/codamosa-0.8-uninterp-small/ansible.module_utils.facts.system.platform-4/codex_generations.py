

# Generated at 2022-06-25 00:24:35.071743
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_test_obj = PlatformFactCollector()
    result = platform_fact_collector_test_obj.collect()

# Generated at 2022-06-25 00:24:35.986062
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:24:46.434150
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    #
    # Test case 0
    #

    # Test case 1
    # Test the class variable "_fact_ids"
    # Check each element of the variable
    #
    # Expected result:
    # 1. The variable "_fact_ids" should not be empty
    # 2. The variable "_fact_ids" should be a set
    # 3. In the set "_fact_ids", there should be at least one element
    # 4. In the set "_fact_ids", none of the element should be empty
    # 5. In the set "_fact_ids", all elements should be strings
    #

    # Call the function "test_case_0"
    # The assertion is defined in the function "test_case_0"
    test_case_0()

    #
    # Test case 1
    #

    # Create an instance of the

# Generated at 2022-06-25 00:24:57.130398
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()

# Generated at 2022-06-25 00:25:01.299854
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert pfc
    assert pfc.name == 'platform'
    assert pfc._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-25 00:25:06.249250
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])


# Generated at 2022-06-25 00:25:09.770466
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector(None, {})
    assert set(platform_fact_collector_1.collect()) == set(['system', 'kernel', 'kernel_version',
                                                            'machine', 'python_version',
                                                            'architecture', 'machine_id'])

# Generated at 2022-06-25 00:25:10.953242
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pf = PlatformFactCollector()
    assert pf.name == 'platform'

# Generated at 2022-06-25 00:25:12.397552
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector


# Generated at 2022-06-25 00:25:22.714671
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    system_0 = 'Linux'
    kernel_0 = '3.10.0-327.el7.x86_64'
    kernel_version_0 = '#1 SMP Thu Oct 29 17:29:29 EDT 2015'
    machine_0 = 'x86_64'
    python_version_0 = '2.7.5'
    fqdn_0 = socket.getfqdn()
    hostname_0 = platform.node().split('.')[0]
    nodename_0 = platform.node()
    domain_0 = '.'.join(fqdn_0.split('.')[1:])
    userspace_bits_0 = platform.architecture()[0].replace('bit', '')

# Generated at 2022-06-25 00:26:51.421005
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

# Generated at 2022-06-25 00:26:52.800865
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    print('Test case 0')
    print('Testing instantiation')
    test_case_0()

# Generated at 2022-06-25 00:26:58.982550
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    result_dict = platform_fact_collector_1.collect()
    # Expected result: {'system': <str>, 'kernel': <str>, 'kernel_version': <str>, 'machine': <str>, 'python_version': <str>, 'architecture': <str>, 'fqdn': <str>, 'hostname': <str>, 'nodename': <str>, 'domain': <str>, 'userspace_bits': <str>, 'userspace_architecture': <str>, 'machine_id': <str>}
    assert isinstance(result_dict, dict)

# Generated at 2022-06-25 00:27:05.735118
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    fact_result = platform_fact_collector_0.collect()
    assert fact_result["system"] == "Linux"
    assert fact_result["kernel"] == "Linux"
    assert fact_result["kernel_version"] == "Linux"
    assert fact_result["machine"] == "Linux"
    assert fact_result["python_version"] == "Linux"
    assert fact_result["fqdn"] == "Linux"
    assert fact_result["hostname"] == "Linux"
    assert fact_result["nodename"] == "Linux"
    assert fact_result["domain"] == "Linux"
    assert fact_result["userspace_bits"] == "Linux"
    assert fact_result["architecture"] == "Linux"

# Generated at 2022-06-25 00:27:11.495423
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector._fact_ids == {'system',
                                               'kernel',
                                               'kernel_version',
                                               'machine',
                                               'python_version',
                                               'architecture',
                                               'machine_id'}
    assert PlatformFactCollector.name == 'platform'


# Generated at 2022-06-25 00:27:14.105855
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0._collect_platform_subset = lambda x, y: str()
    assert platform_fact_collector_0.collect() == ''

# Generated at 2022-06-25 00:27:18.570953
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector = PlatformFactCollector()

    # Test that the instance is created for PlatformFactCollector
    assert type(collector) == PlatformFactCollector

    # Test the presence of collect() method in PlatformFactCollector
    assert "collect" in dir(collector)

# Generated at 2022-06-25 00:27:25.525181
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # platform_fact_collector_0 is the object of class PlatformFactCollector
    platform_fact_collector_0 = PlatformFactCollector()
    # checking the values of class variables with the expected results
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == ['machine', 'system', 'python_version', 'kernel_version', 'nodename', 'machine_id', 'architecture', 'fqdn', 'kernel', 'hostname', 'domain'], 'incorrect value for fact_ids'
    assert platform_fact_collector_0._platform == 'Linux', 'incorrect value for platform'

# Generated at 2022-06-25 00:27:28.035025
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None

# Generated at 2022-06-25 00:27:30.730506
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:29:12.022662
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test Python implementation
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:29:13.296461
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    var = platform_fact_collector.collect()
    assert var is not None

# Generated at 2022-06-25 00:29:15.053705
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert set(platform_fact_collector_0._fact_ids) == set([u'kernel_version', u'architecture', u'userspace_bits', u'python_version', u'machine', u'kernel', u'system', u'userspace_architecture'])

# Generated at 2022-06-25 00:29:22.110657
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module_name = 'ansible.module_utils.facts.system.platform.module'
    get_bin_path = 'ansible.module_utils.facts.system.platform.module.get_bin_path'
    run_cmd_l = 'ansible.module_utils.facts.system.platform.module.run_command'
    m_0 = 'ansible.module_utils.facts.collector.BaseFactCollector'
    m_1 = 'ansible.module_utils.facts.system.platform.PlatformFactCollector'
    m_2 = 'ansible.module_utils.facts.utils.get_file_content'
    m_3 = 'platform.machine'
    m_4 = 'platform.python_version'
    m_5 = 'platform.node'
    m_6 = 'platform.system'


# Generated at 2022-06-25 00:29:25.955412
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-25 00:29:26.662333
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()


# Generated at 2022-06-25 00:29:31.055632
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:29:34.469969
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'

    assert platform_fact_collector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-25 00:29:39.650827
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'architecture', 'kernel', 'kernel_version', 'system', 'python_version', 'machine_id', 'machine'}


# Generated at 2022-06-25 00:29:40.118905
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pass

# Generated at 2022-06-25 00:33:12.214544
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    assert var_1.get('system') == platform.system()
    assert var_1.get('kernel') == platform.release()
    assert var_1.get('kernel_version') == platform.version()
    assert var_1.get('machine') == platform.machine()
    assert var_1.get('python_version') == platform.python_version()
    assert var_1.get('fqdn') == socket.getfqdn()
    assert var_1.get('hostname') == platform.node().split('.')[0]
    assert var_1.get('nodename') == platform.node()
    assert var_1.get('domain') == platform_fact_collector_

# Generated at 2022-06-25 00:33:14.484166
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:33:20.646702
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'}


# Generated at 2022-06-25 00:33:21.487566
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:33:31.992592
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    assert var_1['system'] == 'Linux'
    assert var_1['architecture'] == 'x86_64'
    assert var_1['machine'] == 'x86_64'
    assert var_1['kernel_version'] == '4.4.0-31-generic'
    assert var_1['kernel'] == '4.4.0-31-generic'
    assert type(var_1['fqdn']) == type(str())
    assert type(var_1['python_version']) == type(str())
    assert type(var_1['hostname']) == type(str())
    assert type(var_1['nodename']) == type(str())
