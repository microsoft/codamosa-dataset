

# Generated at 2022-06-25 00:24:27.795806
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:30.581879
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    print("In Test Case for PlatformFactCollector collect")
    platform_fact_collector_1.collect()


# Generated at 2022-06-25 00:24:34.849097
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)



# Generated at 2022-06-25 00:24:45.378183
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_2 = PlatformFactCollector()
    print()

    # Check for class attribute system of type String
    assert type(platform_fact_collector_1.system) is str

    # Check for class attribute kernel of type String
    assert type(platform_fact_collector_1.kernel) is str

    # Check for class attribute kernel_version of type String
    assert type(platform_fact_collector_1.kernel_version) is str

    # Check for class attribute machine of type String
    assert type(platform_fact_collector_1.machine) is str

    # Check for class attribute python_version of type String
    assert type(platform_fact_collector_1.python_version) is str

    # Check for class attribute architecture of type String

# Generated at 2022-06-25 00:24:50.140721
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-25 00:24:58.348518
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector(
        collected_facts=dict(),
        module=dict()
    )
    assert not (platform_fact_collector_0.module is None)
    assert not (platform_fact_collector_0.collected_facts is None)
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])


# Generated at 2022-06-25 00:24:59.293991
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'

# Generated at 2022-06-25 00:25:03.449977
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-25 00:25:05.740702
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()


# Generated at 2022-06-25 00:25:09.729294
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test using mocked ansible module and facts
    platform_fact_collector_0 = PlatformFactCollector()

    platform_facts = platform_fact_collector_0.collect(module=None, collected_facts=None)
    assert platform_facts['architecture'] == platform.machine()

# Generated at 2022-06-25 00:26:11.432765
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    var_1 = PlatformFactCollector()
    platform_facts = {'fqdn': 'ansible.vm', 'machine_id': None, 'domain': 'vm', 'architecture': 'x86_64', 'nodename': 'ansible.vm', 'hostname': 'ansible', 'kernel_version': '2.6.32-431.el6.x86_64', 'python_version': '2.6.6', 'kernel': '2.6.32-431.el6.x86_64', 'userspace_bits': '64', 'system': 'Linux', 'machine': 'x86_64', 'userspace_architecture': 'x86_64'}
#    platform_facts = var_1.collect()
    var_2 = platform_facts['fqdn']
    var_3 = platform_

# Generated at 2022-06-25 00:26:13.267278
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:26:17.555134
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    stub_PlatformFactCollector = PlatformFactCollector()
    assert (type(stub_PlatformFactCollector) == PlatformFactCollector)


# Generated at 2022-06-25 00:26:18.626301
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # test no parameters
    assert PlatformFactCollector()


# Generated at 2022-06-25 00:26:20.137853
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    var = platform_fact_collector.collect()
    assert True

# Generated at 2022-06-25 00:26:28.018188
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-25 00:26:37.086585
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test method constructor of class PlatformFactCollector
    platform_fact_collector_0 = PlatformFactCollector()
    var_1 = u'platform'
    # assert
    try:
        assert platform_fact_collector_0.name == var_1
    except AssertionError:
        raise AssertionError("expected value is platform, actual value is {0}".format(platform_fact_collector_0.name))

    var_2 = {u'architecture', u'kernel', u'system', u'python_version', u'machine', u'kernel_version', u'machine_id'}
    # assert

# Generated at 2022-06-25 00:26:41.022301
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:26:41.956103
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    fctcol = PlatformFactCollector()


# Generated at 2022-06-25 00:26:45.623703
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'
    assert PlatformFactCollector()._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-25 00:28:19.566145
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)


# Generated at 2022-06-25 00:28:26.413114
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    argument_0 = 'system'
    argument_1 = 'kernel'
    argument_2 = 'kernel_version'
    argument_3 = 'machine'
    argument_4 = 'python_version'
    argument_5 = 'architecture'
    argument_6 = 'machine_id'
    platform_fact_collector_0 = PlatformFactCollector(argument_0, argument_1, argument_2, argument_3, argument_4, argument_5, argument_6)
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:33.579947
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_module_0 = types.ModuleType('ansible.module_utils.facts')
    platform_module_0.os = platform_module_0.ansible.module_utils.facts.os = types.ModuleType('ansible.module_utils.facts.os')
    platform_module_0.os.uname = types.FunctionType(test_PlatformFactCollector_collect.func_code, platform_module_0.os)
    platform_module_0.os.uname.return_value = ('Linux', 'test_node', '3.10.0-123.el7.x86_64', '#1', 'SMP', 'Wed Oct 8 11:13:47 EDT 2014', 'x86_64')
    platform_module_0.socket = platform_module_0.ansible.module_utils.facts.socket = types

# Generated at 2022-06-25 00:28:39.019504
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Check 'system' fact is present
    var_0 = PlatformFactCollector()
    assert 'system' in var_0._fact_ids
    # Check 'kernel' fact is present
    var_1 = PlatformFactCollector()
    assert 'kernel' in var_1._fact_ids
    # Check 'kernel_version' fact is present
    var_2 = PlatformFactCollector()
    assert 'kernel_version' in var_2._fact_ids
    # Check 'machine' fact is present
    var_3 = PlatformFactCollector()
    assert 'machine' in var_3._fact_ids
    # Check 'python_version' fact is present
    var_4 = PlatformFactCollector()
    assert 'python_version' in var_4._fact_ids
    # Check 'architecture' fact is present
    var_5

# Generated at 2022-06-25 00:28:40.583097
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:42.102124
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        PlatformFactCollector()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 00:28:49.244284
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.name
    assert var_0 == 'platform'
    var_1 = platform_fact_collector_0._fact_ids
    assert len(var_1) == 9
    assert 'system' in var_1
    assert 'kernel' in var_1
    assert 'kernel_version' in var_1
    assert 'machine' in var_1
    assert 'python_version' in var_1
    assert 'architecture' in var_1
    assert 'machine_id' in var_1
    assert 'fqdn' in var_1
    assert 'hostname' in var_1
    assert 'nodename' in var_1
    assert 'domain' in var_1

# Generated at 2022-06-25 00:28:51.582079
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:55.641347
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    with pytest.raises(TypeError):
        PlatformFactCollector(foo='bar')


# Generated at 2022-06-25 00:28:56.885208
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    l_obj = PlatformFactCollector()
    assert l_obj.collect()


# Generated at 2022-06-25 00:32:49.406047
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version',
                                                   'architecture', 'machine_id'}
    assert platform_fact_collector_0.name == 'platform'

# Generated at 2022-06-25 00:32:50.547074
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:32:57.186914
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    expected_1 = {'architecture': 'x86_64', 'machine': 'x86_64', 'userspace_bits': '64', 'kernel_version': '', 'kernel': '', 'domain': '', 'system': '', 'hostname': '', 'nodename': '', 'userspace_architecture': 'x86_64', 'python_version': '', 'fqdn': '', 'machine_id': ''}
    assert var_1 == expected_1


# Generated at 2022-06-25 00:33:02.804104
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    print("Running test_PlatformFactCollector_collect...")
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    print("Type of var_1 is " + str(type(var_1)))
    for fact in var_1:
        print("Key: " + fact + " Value: " + str(var_1[fact]))

if __name__ == "__main__":
    test_PlatformFactCollector_collect()
    print("Done!")

# Generated at 2022-06-25 00:33:03.899707
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    var_0 = PlatformFactCollector()
    assert isinstance(var_0, PlatformFactCollector)


# Generated at 2022-06-25 00:33:05.462299
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    res = platform_fact_collector.collect()
    assert len(res) == 14



# Generated at 2022-06-25 00:33:11.749934
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}

if __name__ == '__main__':
    test_case_0()
    test_PlatformFactCollector()

# Generated at 2022-06-25 00:33:15.780447
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    var_1 = platform_fact_collector_0.collect(module=None)
    var_2 = platform_fact_collector_0.collect(collected_facts=None)
    var_3 = platform_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:33:22.281638
# Unit test for constructor of class PlatformFactCollector

# Generated at 2022-06-25 00:33:24.706834
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        platform_fact_collector_0 = PlatformFactCollector()
        platform_fact_collector_0.collect()
    except Exception as err:
        assert False, err.message