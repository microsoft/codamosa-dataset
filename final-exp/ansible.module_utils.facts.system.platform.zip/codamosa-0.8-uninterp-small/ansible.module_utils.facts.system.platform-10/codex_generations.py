

# Generated at 2022-06-25 00:24:27.550250
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector


# Generated at 2022-06-25 00:24:28.488162
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:24:30.532901
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Try to create the PlatformFactCollector
    try:
        PlatformFactCollector()
        assert True
    except:
        assert False


# Generated at 2022-06-25 00:24:38.576803
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()

    assert platform_fact_collector_1.name == 'platform', \
        'test_PlatformFactCollector 1 failed'

    assert platform_fact_collector_1._fact_ids == {
        'system', 'kernel', 'kernel_version', 'machine', 'python_version',
        'architecture', 'machine_id'
    }, 'test_PlatformFactCollector 2 failed'


# Generated at 2022-06-25 00:24:44.045056
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

    facts = platform_fact_collector.collect()

    assert facts is not None
    assert 'system' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts
    assert 'machine' in facts
    assert 'python_version' in facts
    assert 'architecture' in facts
    assert 'machine_id' in facts

# Generated at 2022-06-25 00:24:49.080719
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Note: We use a explicit test case here, because we can't assert on
    #       platform.system() value
    test_case = {'system': 'Linux',
                 'kernel': '2.6.32-5-xen-amd64',
                 'kernel_version': '#1 SMP Wed Jan 12 03:40:32 UTC 2011',
                 'machine': 'x86_64',
                 'python_version': '2.7.15',
                 'fqdn': 'toto.example.com',
                 'hostname': 'toto',
                 'nodename': 'toto.example.com',
                 'domain': 'example.com',
                 'userspace_bits': '64',
                 'architecture': 'x86_64',
                 'userspace_architecture': 'x86_64'}

# Generated at 2022-06-25 00:24:52.710842
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert platform_fact_collector_0.name == "platform"
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-25 00:24:54.705266
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert type(platform_fact_collector) == PlatformFactCollector


# Generated at 2022-06-25 00:24:56.290347
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:58.616195
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:26:13.999306
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()

# Generated at 2022-06-25 00:26:17.464947
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

    platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:26:19.530337
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()
    assert obj.name == 'platform'
    assert obj._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-25 00:26:22.940085
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    collector_instance = PlatformFactCollector()
    assert collector_instance.name == 'platform'
    assert collector_instance._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-25 00:26:28.221175
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    collected_facts_0 = platform_fact_collector_0.collect()
    assert collected_facts_0.keys() == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert collected_facts_0['system'] == 'Linux'
    assert collected_facts_0['kernel'] == '3.10.0-693.17.1.el7.x86_64'
    assert collected_facts_0['kernel_version'] == '#1 SMP Tue Jan 16 16:21:14 UTC 2018'
    assert collected_facts_0['machine'] == 'x86_64'
    assert collected_facts_0['python_version'] == '2.7.5'
    assert collected

# Generated at 2022-06-25 00:26:32.985072
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()

    assert platform_fact_collector_0.name == "platform"
    assert platform_fact_collector_0._fact_ids == {"system", "kernel", "kernel_version", "machine", "python_version", "architecture", "machine_id"}


# Generated at 2022-06-25 00:26:34.117935
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()


# Generated at 2022-06-25 00:26:41.018522
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    print("\nTesting constructor of PlatformFactCollector class")
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert len(platform_fact_collector._fact_ids) == 9
    assert 'system' in platform_fact_collector._fact_ids
    assert 'kernel' in platform_fact_collector._fact_ids
    assert 'kernel_version' in platform_fact_collector._fact_ids
    assert 'machine' in platform_fact_collector._fact_ids
    assert 'python_version' in platform_fact_collector._fact_ids
    assert 'architecture' in platform_fact_collector._fact_ids
    assert 'machine_id' in platform_fact_collector._fact_ids
    assert 'fqdn' in platform_

# Generated at 2022-06-25 00:26:42.929975
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pfc = PlatformFactCollector()
    assert 'system' in pfc._fact_ids
    assert 'kernel' in pfc._fact_ids
    assert 'kernel_version' in pfc._fact_ids

# Generated at 2022-06-25 00:26:46.042939
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test with the arguments = (1, 2)
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect(1, 2)

test_PlatformFactCollector_collect()

# Generated at 2022-06-25 00:29:27.910823
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:29:31.443394
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    platform_fact_collector_collect = PlatformFactCollector()
    #
    # Test using module
    #
    platform_fact_collector_collect.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:29:34.180318
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == "platform"


# Generated at 2022-06-25 00:29:38.655170
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)


# Generated at 2022-06-25 00:29:43.277297
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])

# Generated at 2022-06-25 00:29:48.888090
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    facts_output = platform_fact_collector_0.collect()
    # 'system' should be present
    assert 'system' in facts_output
    # 'kernel' should be present
    assert 'kernel' in facts_output
    # 'kernel_version' should be present
    assert 'kernel_version' in facts_output
    # 'machine' should be present
    assert 'machine' in facts_output
    # 'python_version' should be present
    assert 'python_version' in facts_output
    # 'architecture' should be present
    assert 'architecture' in facts_output
    # 'machine_id' should be present
    assert 'machine_id' in facts_output

# Generated at 2022-06-25 00:29:50.943458
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    data = platform_fact_collector_0.collect()
    assert data['system'] == 'Linux'
    assert 'kernel' in data

# Generated at 2022-06-25 00:29:56.186090
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_1,PlatformFactCollector)


# Generated at 2022-06-25 00:30:01.033791
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_PlatformFactCollector_collect()

# Generated at 2022-06-25 00:30:03.044693
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_1.collect()
