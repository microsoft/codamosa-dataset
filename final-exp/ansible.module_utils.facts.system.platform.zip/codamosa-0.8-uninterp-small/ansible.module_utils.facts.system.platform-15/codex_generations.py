

# Generated at 2022-06-25 00:24:33.152523
# Unit test for constructor of class PlatformFactCollector

# Generated at 2022-06-25 00:24:35.240215
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert set(PlatformFactCollector()._fact_ids) == PlatformFactCollector._fact_ids, 'PlatformFactCollector class fact ids should match'

# Generated at 2022-06-25 00:24:38.115961
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    result = platform_fact_collector.collect()
    for key in result:
        assert result[key] is not None

# Generated at 2022-06-25 00:24:45.811738
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # Configuration for test case 0
    platform_fact_collector_0 = PlatformFactCollector()

    # Run method collect of PlatformFactCollector on platform_fact_collector_0
    platform_facts_0 = platform_fact_collector_0.collect()

    # Check keys in platform_fact_collector_0.name
    assert 'system' in platform_fact_collector_0.name
    assert 'kernel' in platform_fact_collector_0.name
    assert 'kernel_version' in platform_fact_collector_0.name
    assert 'machine' in platform_fact_collector_0.name
    assert 'architecture' in platform_fact_collector_0.name
    assert 'python_version' in platform_fact_collector_0.name

# Generated at 2022-06-25 00:24:49.505580
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, BaseFactCollector)


# Generated at 2022-06-25 00:24:50.685146
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert type(PlatformFactCollector) == type(object)


# Generated at 2022-06-25 00:25:00.422348
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts = platform_fact_collector_0.collect()
    assert platform_facts is not None
    assert 'system' in platform_facts
    assert 'domain' in platform_facts
    assert 'nodename' in platform_facts
    assert 'hostname' in platform_facts
    assert 'architecture' in platform_facts
    assert 'kernel_version' in platform_facts
    assert 'kernel' in platform_facts
    assert 'machine_id' in platform_facts
    assert 'userspace_architecture' in platform_facts
    assert 'python_version' in platform_facts
    assert 'machine' in platform_facts
    assert 'userspace_bits' in platform_facts
    assert 'fqdn' in platform_facts

# Generated at 2022-06-25 00:25:08.848165
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts = platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:18.855367
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    result = platform_fact_collector_1.collect()

# Generated at 2022-06-25 00:25:20.765455
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'


# Generated at 2022-06-25 00:26:46.243948
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:26:48.095753
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.collect() == None


# Generated at 2022-06-25 00:26:56.002170
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_facts_1 = platform_fact_collector_1.collect()

    assert 'system' in platform_facts_1
    assert 'kernel' in platform_facts_1
    assert 'kernel_version' in platform_facts_1
    assert 'machine' in platform_facts_1
    assert 'python_version' in platform_facts_1
    assert 'architecture' in platform_facts_1


# Generated at 2022-06-25 00:26:58.301244
# Unit test for constructor of class PlatformFactCollector

# Generated at 2022-06-25 00:27:01.404836
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == "platform"
    assert platform_fact_collector._fact_ids == {'architecture',
                                                 'kernel',
                                                 'system',
                                                 'kernel_version',
                                                 'machine',
                                                 'python_version',
                                                 'machine_id'}


# Generated at 2022-06-25 00:27:04.432141
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts = platform_fact_collector_0.collect()

    print("platform_facts: %s" % platform_facts)

    assert len(platform_facts) == 1

if __name__ == "__main__":
    test_PlatformFactCollector_collect()

# Generated at 2022-06-25 00:27:10.337424
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version',
                                                     'machine', 'python_version', 'architecture',
                                                     'machine_id'])

# Generated at 2022-06-25 00:27:17.235843
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    test_facts_from_module = {
      "python_version": "2.7.13",
      "kernel_version": "4.10.0-37-generic",
      "machine": "x86_64",
      "kernel": "4.10.0-37-generic",
      "system": "Linux"
    }
    #This is not a real ansible module, we only want to call module methods
    class FakeModule():
        def get_bin_path(self, cmd):
            if cmd == 'getconf':
                return '/usr/bin/getconf'
            elif cmd == 'bootinfo':
                return '/usr/bin/bootinfo'
            else:
                return ''


# Generated at 2022-06-25 00:27:18.333276
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()

# Generated at 2022-06-25 00:27:19.466495
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    myFact = PlatformFactCollector()
    assert myFact.collect()['kernel'] == 'Darwin'

# Generated at 2022-06-25 00:30:54.578981
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts_0 = platform_fact_collector_0.collect()
    assert platform_facts_0['architecture'] == 'i686'

# Generated at 2022-06-25 00:30:58.882268
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    obj = PlatformFactCollector()

    opt = set(['system', 'kernel', 'kernel_version', 'machine', 'python_version',
               'architecture', 'machine_id'])

    assert obj.name == 'platform'
    assert obj._fact_ids == opt


# Generated at 2022-06-25 00:31:02.243145
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])


# Generated at 2022-06-25 00:31:03.709611
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    test_case_0()
    print("Success: test_PlatformFactCollector")


# Provides a test harness to conduct unit test on class PlatformFactCollector

# Generated at 2022-06-25 00:31:09.639961
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts_0 = platform_fact_collector_0.collect()
    if isinstance(platform_facts_0, dict):
        print("\nExpected 'dict', got '" + type(platform_facts_0).__name__ + "'.")
    # Test the method collect of class PlatformFactCollector with a valid argument
    assert isinstance(platform_facts_0, dict)
    assert set(platform_facts_0.keys()) == {'system', 'kernel', 'kernel_version', 'machine', 'python_version',
                                            'architecture'}
    assert platform_facts_0['machine'] == platform.machine()
    assert platform_facts_0['system'] == platform.system()
    assert platform_facts_0['kernel_version'] == platform

# Generated at 2022-06-25 00:31:15.075708
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert not PlatformFactCollector.__name__
    assert not PlatformFactCollector._fact_ids


# Generated at 2022-06-25 00:31:18.596524
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test whether required parameters are set
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}
    assert platform_fact_collector_0.name == 'platform'


# Generated at 2022-06-25 00:31:26.709730
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    r = platform_fact_collector_0.collect()
    assert set(r.keys()) == set(['kernel', 'python_version', 'machine', 'fqdn', 'system', 'nodename', 'kernel_version', 'architecture', 'hostname', 'domain'])
    #assert r['kernel'] == 'Linux'
    assert r['python_version'][0] == '2' or r['python_version'][0] == '3'
    #assert r['machine'] == 'x86_64'
    assert len(r['fqdn']) > 0
    #assert r['system'] == 'Linux'
    assert len(r['nodename']) > 0
    #assert r['kernel_version'] == '3.2.0-

# Generated at 2022-06-25 00:31:34.068645
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0 is not None
    assert platform_fact_collector_0.name == 'platform'
    assert isinstance(platform_fact_collector_0._fact_ids, set)
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])


# Generated at 2022-06-25 00:31:35.286576
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0 is not None