

# Generated at 2022-06-25 00:24:19.597856
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version',
       'architecture', 'machine_id'}

# Generated at 2022-06-25 00:24:21.933534
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0 != None
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-25 00:24:29.929471
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()

    assert platform_fact_collector.name == 'platform'

    assert sorted(platform_fact_collector._fact_ids) == sorted(['system',
                                                                 'kernel',
                                                                 'kernel_version',
                                                                 'machine',
                                                                 'python_version',
                                                                 'architecture',
                                                                 'machine_id'])

# Generated at 2022-06-25 00:24:32.541713
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    print("unit test:constructor of class PlatformFactCollector")
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_1 = PlatformFactCollector(name='platform')


# Generated at 2022-06-25 00:24:34.390827
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:36.516540
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

    assert platform_fact_collector_0.collect() != None


# Generated at 2022-06-25 00:24:39.697039
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_collect = PlatformFactCollector()
    platform_fact_collector_collect.collect()
#    assert platform_fact_collector_collect.collect() == None


# Generated at 2022-06-25 00:24:46.229453
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    pfc = PlatformFactCollector()
    # Test with one or more values expected to be collected
    pfc.collect()
    # Test with none of the values expected to be collected
    pfc.collect(collected_facts={})


# Generated at 2022-06-25 00:24:49.626242
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()

    # Run unit test
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:50.535139
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass



# Generated at 2022-06-25 00:25:05.043060
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # test instantiation
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert platform_fact_collector_1.name == 'platform'

    # test _get_hostname_fqdn_faux
    platform_fact_collector_2 = PlatformFactCollector()
    platform_fact_collector_2._get_hostname_fqdn_faux()


# Generated at 2022-06-25 00:25:07.016951
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()



# Generated at 2022-06-25 00:25:08.064894
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    obj = PlatformFactCollector()
    obj.collect()
    pass

# Generated at 2022-06-25 00:25:18.121145
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])

# Generated at 2022-06-25 00:25:19.405707
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector().name == 'platform'


# Generated at 2022-06-25 00:25:27.879904
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    win_facts = {u'python_version': u'2.7.5', u'nodename': u'localhost', u'os_family': u'Windows', u'os_dn': u'',
                 u'architecture': u'64x86', u'kernel_version': u'6.3.9600', u'fqdn': u'localhost', u'kernel': u'Windows',
                 u'machine_id': u'', u'system': u'Windows', u'os_major_version': 6, u'os_minor_version': 3,
                 u'os_name': u'Windows 8.1', u'machine': u'x86_64', u'hostname': u'localhost'}

# Generated at 2022-06-25 00:25:32.579709
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    var_2 = platform_fact_collector_0.name
    assert var_2 == 'platform'
    var_3 = platform_fact_collector_0._fact_ids
    var_4 = set(['system',
                 'kernel',
                 'kernel_version',
                 'machine',
                 'python_version',
                 'architecture',
                 'machine_id'])
    assert var_3 == var_4
    

# Generated at 2022-06-25 00:25:33.660252
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:25:35.351930
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector = PlatformFactCollector()
    assert issubclass(platform_fact_collector.__class__, PlatformFactCollector)



# Generated at 2022-06-25 00:25:44.016705
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    # {'userspace_architecture': 'x86_64', 'kernel': '4.1.10-11.31-default', 'kernel_version': '#1 SMP Sat Oct 10 14:19:35 UTC 2015', 'system': 'Linux', 'nodename': 'asdslap02.pv.suse.de', 'architecture': 'x86_64', 'python_version': '2.7.9', 'machine': 'x86_64', 'hostname': 'asdslap02', 'fqdn': 'asdslap02.pv.suse.de'}

# Generated at 2022-06-25 00:27:03.119850
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert type(var_0) == dict
    assert var_0['system'] == 'Linux'
    assert var_0['kernel'] == '4.4.0-24-generic'
    assert var_0['kernel_version'] == '#43-Ubuntu SMP Wed Jun 8 19:27:37 UTC 2016'
    assert var_0['machine'] == 'x86_64'
    assert var_0['python_version'] == '2.7.12'

# Generated at 2022-06-25 00:27:13.272851
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    var_1 = PlatformFactCollector()
    var_2 = get_file_content("/var/lib/dbus/machine-id") or get_file_content("/etc/machine-id")
    var_2 = get_file_content("/etc/machine-id")
    var_3 = var_2.splitlines()[0]
    var_4 = {"machine_id": var_3}

# Generated at 2022-06-25 00:27:14.803742
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'

# Generated at 2022-06-25 00:27:15.512103
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test execution 0
    test_case_0()

# Generated at 2022-06-25 00:27:20.356651
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version',
                                               'architecture', 'machine_id'}
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version',
                                                    'architecture', 'machine_id'}


# Generated at 2022-06-25 00:27:25.051130
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Setup
    platform_fact_collector = PlatformFactCollector()

    # Exercise
    platform_fact_collector.collect()

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 00:27:28.635622
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.platform import PlatformFactCollector

    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:27:30.555611
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()


# Generated at 2022-06-25 00:27:35.618859
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.name
    assert var_0 == 'platform'


# Generated at 2022-06-25 00:27:36.919450
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:30:58.965744
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])

# Generated at 2022-06-25 00:30:59.600321
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:31:00.511969
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:31:01.622545
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:06.408287
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:31:08.811405
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:31:16.415490
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    assert 'system' in var_1
    assert 'kernel' in var_1
    assert 'kernel_version' in var_1
    assert 'machine' in var_1
    assert 'python_version' in var_1
    assert 'architecture' in var_1
    assert 'fqdn' in var_1
    assert 'hostname' in var_1
    assert 'nodename' in var_1
    assert 'domain' in var_1
    assert 'userspace_bits' in var_1
    assert 'userspace_architecture' in var_1


# Generated at 2022-06-25 00:31:22.269526
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert var_0['system'] == 'Linux'

# Generated at 2022-06-25 00:31:23.880409
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()


# Generated at 2022-06-25 00:31:25.467629
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()