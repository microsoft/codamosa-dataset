

# Generated at 2022-06-25 00:24:29.083217
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    Platform_fact_collector_collect = PlatformFactCollector()
    results = Platform_fact_collector_collect.collect(0,0)
    assert type(results) is dict and len(results) > 0


# Generated at 2022-06-25 00:24:29.678514
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert True

# Generated at 2022-06-25 00:24:31.225507
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:42.683111
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_facts = {}


# Generated at 2022-06-25 00:24:47.916677
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    plat = PlatformFactCollector()
    assert plat.name == 'platform'
    assert plat._fact_ids == set(['system',
                                  'kernel',
                                  'kernel_version',
                                  'machine',
                                  'python_version',
                                  'architecture',
                                  'machine_id',
                                  ])
    assert not bool(plat.collect() == None)

test_case_0()
test_PlatformFactCollector()

# Generated at 2022-06-25 00:24:51.906508
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts = platform_fact_collector_0.collect()
    assert(platform_facts['architecture'] == platform.machine())

# Generated at 2022-06-25 00:24:54.697291
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        assert PlatformFactCollector.name == 'platform'
        assert PlatformFactCollector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])
    except Exception:
        raise Exception('Unit test for PlatformFactCollector failed!')


# Generated at 2022-06-25 00:25:00.251472
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])

if __name__ == '__main__':
    test_case_0()
    test_PlatformFactCollector()

# Generated at 2022-06-25 00:25:01.876696
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()

# Generated at 2022-06-25 00:25:02.800218
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PlatformFactCollector().collect()

# Generated at 2022-06-25 00:25:44.430326
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()

    assert 'system' in platform_fact_collector_1._fact_ids
    assert 'kernel' in platform_fact_collector_1._fact_ids
    assert 'kernel_version' in platform_fact_collector_1._fact_ids
    assert 'machine' in platform_fact_collector_1._fact_ids
    assert 'python_version' in platform_fact_collector_1._fact_ids

# Generated at 2022-06-25 00:25:49.031768
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test argument count in constructor
    class Test1:
        def __init__(self):
            pass
    try:
        Test1()
    except:
        pass
    else:
        raise Exception("Constructor of class PlatformFactCollector did not raise exception upon invalid argument count")

    # Test return type of name
    assert type(platform_fact_collector_2.name) is str


# Generated at 2022-06-25 00:25:52.628076
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # void constructor test
    platform_fact_collector_0 = PlatformFactCollector()
    # test 0
    try:
        var_0 = platform_fact_collector_0.collect()
        assert any(var_0)
    except AssertionError:
        raise AssertionError('Unable to create PlatformFactCollector object')

# Generated at 2022-06-25 00:25:57.876652
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()


# Generated at 2022-06-25 00:26:02.179267
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:26:04.643145
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    # The call PlatformFactCollector.collect()
    # No error
    assert platform_fact_collector_0.collect() is None

# Generated at 2022-06-25 00:26:09.341960
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()
    assert platform_fact_collector_0.__dict__ == {'collect_subset': None, 'name': 'platform', '_fact_ids': {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}, '_collect_subset': None, '_gather_subset': None}



# Generated at 2022-06-25 00:26:13.168324
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])



# Generated at 2022-06-25 00:26:18.440876
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    collected_facts_1 = {}
    platform_facts_1 = platform_fact_collector_1.collect(collected_facts=collected_facts_1)
    assert platform_facts_1 == {}

# Generated at 2022-06-25 00:26:19.769426
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == 'platform'
    

# Generated at 2022-06-25 00:27:24.979441
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    PLATFORM_FACT_COLLECTOR_1 = PlatformFactCollector()
    VAR_1 = PLATFORM_FACT_COLLECTOR_1.collect()
    assert VAR_1['domain'] == '.'.join(socket.getfqdn().split('.')[1:])

# Generated at 2022-06-25 00:27:30.452314
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == "platform"
    assert platform_fact_collector_0._fact_ids == {'system', 'python_version', 'architecture', 'hostname', 'userspace_bits', 'domain', 'kernel_version', 'nodename', 'machine', 'machine_id', 'kernel', 'fqdn', 'userspace_architecture'}


# Generated at 2022-06-25 00:27:40.196646
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:42.301507
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        var_1 = PlatformFactCollector()
    except:
        var_1 = PlatformFactCollector()


# Generated at 2022-06-25 00:27:43.671337
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test with a value for platform_fact_collector_0
    platform_fact_collector_0 = PlatformFactCollector()
    assert -1

# Generated at 2022-06-25 00:27:45.365454
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()


test_case_0()
test_PlatformFactCollector_collect()

# Generated at 2022-06-25 00:27:47.742549
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-25 00:27:50.593587
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-25 00:27:58.443825
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert 'system' in platform_fact_collector_0._fact_ids
    assert 'architecture' in platform_fact_collector_0._fact_ids
    assert 'kernel_version' in platform_fact_collector_0._fact_ids
    assert 'kernel' in platform_fact_collector_0._fact_ids
    assert 'python_version' in platform_fact_collector_0._fact_ids
    assert 'machine' in platform_fact_collector_0._fact_ids
    assert 'machine_id' in platform_fact_collector_0._fact_ids
    assert 'platform' == platform_fact_collector_0.name
    assert 6 == len(platform_fact_collector_0._fact_ids)


# Generated at 2022-06-25 00:28:01.609756
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
  # Constructor for class PlatformFactCollector
  platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:29:38.161048
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    var_0 = PlatformFactCollector()
    var_0 = PlatformFactCollector()

# Generated at 2022-06-25 00:29:39.914427
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    # test_vars: [platform_fact_collector_0]
    platform_fact_collector_0 = PlatformFactCollector()
    # test_data
    var_0 = platform_fact_collector_0.collect()



# Generated at 2022-06-25 00:29:42.210299
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0


# Generated at 2022-06-25 00:29:44.144222
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:29:48.144909
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict()
    )

    platform_fact_collector = PlatformFactCollector()

    var_1 = platform_fact_collector.collect(module)
    assert 'system' in var_1
    assert 'kernel' in var_1
    assert 'kernel_version' in var_1
    assert 'machine' in var_1
    assert 'python_version' in var_1
    assert 'architecture' in var_1


# Generated at 2022-06-25 00:29:54.241416
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Instanciate a class
    platform_fact_collector_0 = PlatformFactCollector()

    # Invoke method collect of class PlatformFactCollector
    var_0 = platform_fact_collector_0.collect()

    # Test if isinstance of class PlatformFactCollector
    assert isinstance(var_0, dict)

    # Test if platform.system() can be Linux, Darwin, Java, or Windows
    assert var_0['system'] in ['Linux', 'Darwin', 'Java', 'Windows']

    # Test if kernel_version is not None
    assert var_0['kernel_version'] is not None

    # Test if machine is not None
    assert var_0['machine'] is not None

    # Test if python_version is not None
    assert var_0['python_version'] is not None

    # Test if hostname

# Generated at 2022-06-25 00:29:55.870047
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert var_0 is None


# Generated at 2022-06-25 00:29:59.787927
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0 is not None


# Generated at 2022-06-25 00:30:00.562597
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass



# Generated at 2022-06-25 00:30:03.772733
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

    print(platform_fact_collector_0.collect())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:33:15.898710
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert("system" in PlatformFactCollector()._fact_ids)
    assert("kernel" in PlatformFactCollector()._fact_ids)
    assert("kernel_version" in PlatformFactCollector()._fact_ids)
    assert("machine" in PlatformFactCollector()._fact_ids)
    assert("python_version" in PlatformFactCollector()._fact_ids)
    assert("architecture" in PlatformFactCollector()._fact_ids)
    assert("machine_id" in PlatformFactCollector()._fact_ids)
    assert("userspace_bits" in PlatformFactCollector()._fact_ids)
    assert("userspace_architecture" in PlatformFactCollector()._fact_ids)


# Generated at 2022-06-25 00:33:17.110732
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Tests the constructor of class PlatformFactCollector
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:33:24.295757
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    try:
        PlatformFactCollector_instance = PlatformFactCollector()
    except Exception as e:
        if "type object argument after * must be an iterable, not type" in e.args[0]:
            print("Constructor of class PlatformFactCollector throws an exception as expected")
        else:
            print("Failed to throw an exception as expected")
            raise e


# Generated at 2022-06-25 00:33:29.342506
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    # If the constructor execution completes successfully, then the obj
    # reference will be returned
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:33:30.933941
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_case_0()

# Unit Tests for methods
if __name__ == "__main__":
    test_PlatformFactCollector()