

# Generated at 2022-06-25 00:24:26.543182
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector._fact_ids == set([
        'system',
        'kernel',
        'kernel_version',
        'machine',
        'python_version',
        'architecture',
        'machine_id'])


# Generated at 2022-06-25 00:24:27.161794
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-25 00:24:32.256189
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])


# Generated at 2022-06-25 00:24:38.022658
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == {'system',
                                                 'kernel',
                                                 'kernel_version',
                                                 'machine',
                                                 'python_version',
                                                 'architecture',
                                                 'machine_id'}


# Generated at 2022-06-25 00:24:47.708742
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts is not None
    assert platform_facts['system'] is not None
    assert platform_facts['machine'] is not None
    assert platform_facts['python_version'] is not None
    assert platform_facts['architecture'] is not None
    assert platform_facts['kernel'] is not None
    assert platform_facts['kernel_version'] is not None
    assert platform_facts['machine_id'] is not None

    assert platform_facts['fqdn'] is not None
    assert platform_facts['domain'] is not None
    assert platform_facts['hostname'] is not None
    assert platform_facts['nodename'] is not None

    assert platform_facts['userspace_bits'] is not None
   

# Generated at 2022-06-25 00:24:58.573540
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    result = platform_fact_collector_0.collect(module=None, collected_facts=None)
    assert result["system"] == "Darwin"
    assert result["architecture"] == "x86_64"
    assert result["userspace_bits"] == "64"
    assert len(result["machine_id"]) == 32
    assert result["nodename"] == "twinbrook-mbp.local"
    assert result["kernel_version"] == "17.7.0"
    assert result["hostname"] == "twinbrook-mbp"

# Generated at 2022-06-25 00:25:01.343064
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        platform_fact_collector_0 = PlatformFactCollector()
    except Exception as e:
        assert False, 'Constructor of class PlatformFactCollector failed: ' + str(e)


# Generated at 2022-06-25 00:25:05.837436
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])


# Generated at 2022-06-25 00:25:09.945423
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])



# Generated at 2022-06-25 00:25:11.746586
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.collect() is not None


# Generated at 2022-06-25 00:26:34.153321
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    assert PlatformFactCollector.collect(None, None) is None

# Generated at 2022-06-25 00:26:37.536888
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])
    assert PlatformFactCollector.name == 'platform'


# Generated at 2022-06-25 00:26:48.519892
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():

    class ModuleStub:

        def get_bin_path(self, cmd):
            return None

        def run_command(self, cmd):
            if cmd == ['/usr/bin/getconf', 'MACHINE_ARCHITECTURE']:
                return 0, 'POWER8', None
            elif cmd == ['/usr/bin/bootinfo', '-p']:
                return 0, 'power64', None
            else:
                raise Exception('Invalid command')

    platform_fact_collector_0 = PlatformFactCollector()

    # Call method collect of class PlatformFactCollector with arguments:
    # module = ModuleStub()
    # collected_facts = None
    result_0 = platform_fact_collector_0.collect(ModuleStub(), None)

    assert 'architecture' in result_0
    assert result

# Generated at 2022-06-25 00:26:58.610354
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts_dict = {'architecture': 'x86_64', 'fqdn': 'localhost.localdomain', 'kernel_version': '3.10.0-957.5.1.el7.x86_64', 'python_version': '2.7.5', 'domain': 'localdomain', 'machine_id': 'e68bba8628ad49c491f38e92c307d5b5', 'system': 'Linux', 'nodename': 'localhost.localdomain', 'kernel': '3.10.0-957.5.1.el7.x86_64', 'machine': 'x86_64', 'hostname': 'localhost'}

# Generated at 2022-06-25 00:26:59.696511
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_fact_collector.collect()

# Generated at 2022-06-25 00:27:00.540532
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # We don't have any test for this class
    assert True == True


# Generated at 2022-06-25 00:27:04.517578
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    print("\n{}".format("-"*75))
    print("Testing class constructor of PlatformFactCollector")
    print("\n{}".format("-"*75))
    print("{!s}".format(platform_fact_collector_0))
    print("{!s}".format(platform_fact_collector_0.name))
    print("{!s}".format(platform_fact_collector_0._fact_ids))


# Generated at 2022-06-25 00:27:14.345550
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_collect = PlatformFactCollector()
    platform_fact_collector_collect_result = platform_fact_collector_collect.collect()

    assert platform_fact_collector_collect_result.get('system')
    assert platform_fact_collector_collect_result.get('kernel')
    assert platform_fact_collector_collect_result.get('kernel_version')
    assert platform_fact_collector_collect_result.get('python_version')
    assert platform_fact_collector_collect_result.get('machine')
    assert platform_fact_collector_collect_result.get('architecture')
    assert platform_fact_collector_collect_result.get('fqdn')
    assert platform_fact_collector_collect_result.get('hostname')
    assert platform_fact_

# Generated at 2022-06-25 00:27:15.829570
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.collect()


# Generated at 2022-06-25 00:27:19.022813
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-25 00:28:49.853895
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Unit tests for collect method of class PlatformFactCollector

# Generated at 2022-06-25 00:28:56.239131
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    platform_facts = platform_fact_collector.collect()
    assert platform_facts is not None
    assert len(platform_facts) > 0
    assert "system" in platform_facts
    assert "kernel" in platform_facts
    assert "kernel_version" in platform_facts
    assert "architecture" in platform_facts
    assert "hostname" in platform_facts
    assert "fqdn" in platform_facts
    assert "nodename" in platform_facts
    assert "domain" in platform_facts
    assert "machine" in platform_facts
    assert "python_version" in platform_facts

# Generated at 2022-06-25 00:28:57.889446
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()

# Generated at 2022-06-25 00:29:00.137266
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:29:01.303296
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:29:02.282980
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:29:06.669842
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()
    assert (set(var_0.keys()) == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'})
    assert (var_0['system'] == 'Linux')
    assert (var_0['kernel'] == '3.10.0-514.el7.x86_64')
    assert (var_0['kernel_version'] == '#1 SMP Tue Nov 22 16:42:41 UTC 2016')
    assert (var_0['machine'] == 'x86_64')
    assert (var_0['python_version'] == '2.7.5')

# Generated at 2022-06-25 00:29:07.219240
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert (PlatformFactCollector().name == 'platform')

# Generated at 2022-06-25 00:29:10.965256
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    try:
        platform_fact_collector_0 = PlatformFactCollector()
        platform_fact_collector_0.collect()
    except Exception as err:
        print("ERROR: " + str(err))

# Generated at 2022-06-25 00:29:15.290394
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    var_0 = platform_fact_collector_0.collect()

    assert var_0["system"] == "Linux"
    assert var_0["kernel"] == "4.4.0-62-generic"
    assert var_0["kernel_version"] == "#83-Ubuntu SMP Wed Jan 18 14:10:15 UTC 2017"
    assert var_0["machine"] == "x86_64"
    assert var_0["python_version"] == "2.7.12"
    assert var_0["fqdn"] == "ubuntu.vm"
    assert var_0["hostname"] == "ubuntu"
    assert var_0["nodename"] == "ubuntu.vm"
    assert var_0["domain"] == "vm"

# Generated at 2022-06-25 00:32:11.690696
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:32:15.356388
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
         'kernel',
         'kernel_version',
         'machine',
         'python_version',
         'architecture',
         'machine_id'])


# Generated at 2022-06-25 00:32:19.153290
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    var_1 = platform_fact_collector_1.collect()
    assert var_1['system'] == 'Linux'



# Generated at 2022-06-25 00:32:24.121421
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    import os
    import sys
    import unittest

    class PlatformFactCollectorTestCase(unittest.TestCase):
        def test_default(self):
            platform_fact_collector = PlatformFactCollector()
            self.assertIsInstance(platform_fact_collector, PlatformFactCollector)



    platform_fact_collector_unittest = PlatformFactCollectorTestCase()
    platform_fact_collector_unittest.test_default()

# Generated at 2022-06-25 00:32:24.774995
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    pass


# Generated at 2022-06-25 00:32:29.928700
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-25 00:32:31.112371
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:32:35.724592
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    pfc = PlatformFactCollector()
    result = pfc.collect()
    assert isinstance(result, dict)
    assert result['system'] != ''
    assert result['kernel'] != ''
    assert result['kernel_version'] != ''
    assert result['machine'] != ''
    assert result['python_version'] != ''
    assert result['fqdn'] != ''
    assert result['hostname'] != ''
    assert result['nodename'] != ''
    assert result['domain'] != ''
    assert result['userspace_bits'] != ''
    assert result['architecture'] != ''

# Generated at 2022-06-25 00:32:36.623451
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()


# Generated at 2022-06-25 00:32:38.680442
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_obj = PlatformFactCollector()
    assert _fact_ids == platform_fact_collector_obj._fact_ids
    assert name == platform_fact_collector_obj.name
