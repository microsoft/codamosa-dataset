

# Generated at 2022-06-25 00:24:26.226919
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert isinstance(PlatformFactCollector(), PlatformFactCollector)


# Generated at 2022-06-25 00:24:34.546925
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    # print("assertEqual(sorted(platform_fact_collector_0.collect()), sorted([('system', 'Linux'), ('kernel_version', '3.19.0-32-generic'), ('kernel', '#37~14.04.1-Ubuntu SMP Thu Oct 22 09:41:40 UTC 2015'), ('machine', 'x86_64')]))
    assert(sorted(platform_fact_collector_0.collect()) == sorted([('system', 'Linux'), ('kernel_version', '3.19.0-32-generic'), ('kernel', '#37~14.04.1-Ubuntu SMP Thu Oct 22 09:41:40 UTC 2015'), ('machine', 'x86_64')])), "test_PlatformFactCollector_collect() failed"

# Generated at 2022-06-25 00:24:39.352803
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == "platform"
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])


# Generated at 2022-06-25 00:24:44.971886
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'])

# Generated at 2022-06-25 00:24:49.070884
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    # Test 1: AIA-0321: test with a 64 bit system with a 64 bit userspace
    try:
        platform_fact_collector_collect_1 = PlatformFactCollector()
        platform_fact_collector_collect_1.collect(module = None, collected_facts = None)
        # Some tests go here
        return True
    except Exception as e:
        return False


# Generated at 2022-06-25 00:24:54.488185
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    try:
        platform_fact_collector_1 = PlatformFactCollector()
        config = dict()
        actualResult = platform_fact_collector_1.collect(None, None)
        expectedResult = dict()
        assert actualResult == expectedResult
    except Exception as e:
        print("Testcase_0: Failed")
        print("Python says: " + str(e))
        return
    print("Testcase_0: Passed")

# Generated at 2022-06-25 00:24:56.435536
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == 'platform'



# Generated at 2022-06-25 00:24:57.704623
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()



# Generated at 2022-06-25 00:25:06.574411
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.collect() == {'architecture': 'x86_64', 'domain': '', 'fqdn': '', 'hostname': '', 'machine': 'x86_64', 'machine_id': '3b3f5c1220af4a13a7a0e9b8e44bfc6d', 'nodename': 'unknown', 'python_version': '2.7.10', 'system': 'Linux', 'userspace_architecture': 'x86_64', 'userspace_bits': '64', 'kernel_version': '#1 SMP Mon Oct 23 21:42:27 UTC 2017', 'kernel': '4.13.0-32-generic'}

# Generated at 2022-06-25 00:25:12.232758
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    # Assert hasattr() returns True for the following attributes of class PlatformFactCollector
    assert hasattr(platform_fact_collector_0, 'name') == True
    assert hasattr(platform_fact_collector_0, '_fact_ids') == True
    assert hasattr(platform_fact_collector_0, 'collect') == True

    # Assert value of the attributes of class PlatformFactCollector
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-25 00:26:36.370166
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

# Test case for class PlatformFactCollector

# Generated at 2022-06-25 00:26:37.705691
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:26:44.153852
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    result = platform_fact_collector.collect()
    assert 'system' in result
    assert 'kernel' in result
    assert 'kernel_version' in result
    assert 'machine_id' in result
    assert 'machine' in result
    assert 'architecture' in result
    assert 'python_version' in result



# Generated at 2022-06-25 00:26:46.314727
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:26:52.501220
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert set(platform_fact_collector_0._fact_ids) == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

 

# Generated at 2022-06-25 00:26:56.505852
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    # Test instantiation of PlatformFactCollector
    platform_fact_collector_0 = PlatformFactCollector()

if __name__ == '__main__':
    '''Run this unit test as follows:
    $ cd <project_root_directory>
    $ python -m unit_tests.unit_test_fact_collector_platform_fact_collector 
    '''
    test_PlatformFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:26:57.935306
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    platform_fact_collector_1.collect()


# Generated at 2022-06-25 00:26:58.336744
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    PlatformFactCollector()

# Generated at 2022-06-25 00:27:01.995137
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)
    assert platform_fact_collector_0._fact_ids == {'machine', 'kernel', 'architecture', 'kernel_version', 'system', 'python_version', 'machine_id'}
    assert platform_fact_collector_0.name == 'platform'


# Generated at 2022-06-25 00:27:03.109714
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:30:01.165668
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

    # PlatformFactCollector.collect is abstract, so we just check that it executes
    platform_fact_collector.collect()

# Generated at 2022-06-25 00:30:03.081709
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:30:07.045848
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])
    assert platform_fact_collector_0.name == 'platform'

# Generated at 2022-06-25 00:30:08.335636
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector is not None


# Generated at 2022-06-25 00:30:09.326253
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()


# Generated at 2022-06-25 00:30:11.972361
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])

# Generated at 2022-06-25 00:30:13.284382
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    res = platform_fact_collector_0.collect()
    return res

# Generated at 2022-06-25 00:30:18.743490
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
        assert PlatformFactCollector.name == 'platform'
        assert PlatformFactCollector._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])

# Generated at 2022-06-25 00:30:23.738756
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    system = platform_fact_collector.collect()

    assert(system is not None)
    assert(isinstance(system, dict) is True)
    assert('system' in system)

# Generated at 2022-06-25 00:30:27.689743
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Checks for the class PlatformFactCollector.
    
    """
    collector = PlatformFactCollector()
    result = collector.collect()
    assert isinstance(result,dict)