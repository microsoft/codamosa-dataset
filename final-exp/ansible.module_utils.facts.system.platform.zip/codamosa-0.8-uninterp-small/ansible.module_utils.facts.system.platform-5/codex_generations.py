

# Generated at 2022-06-25 00:24:27.047184
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()


if __name__ == '__main__':
    test_PlatformFactCollector()

# Generated at 2022-06-25 00:24:28.396690
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert isinstance(platform_fact_collector, PlatformFactCollector)


# Generated at 2022-06-25 00:24:30.126671
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.collect() is not None

# Generated at 2022-06-25 00:24:34.297928
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert PlatformFactCollector.name == 'platform'
    assert PlatformFactCollector._fact_ids == set(['system',
                                                   'kernel',
                                                   'kernel_version',
                                                   'machine',
                                                   'python_version',
                                                   'architecture',
                                                   'machine_id'])
    assert hasattr(PlatformFactCollector.collect, '__call__')



# Generated at 2022-06-25 00:24:38.623661
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    # Check object name
    platform_fact_collector_0.name == 'platform'

    # Check object name is added to dictionary of fact IDs
    assert 'platform' in platform_fact_collector_0._fact_ids


# Generated at 2022-06-25 00:24:41.359902
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)


# Generated at 2022-06-25 00:24:46.227174
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    assert hasattr(PlatformFactCollector, '_fact_ids') and PlatformFactCollector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'])
    assert hasattr(PlatformFactCollector, 'name') and PlatformFactCollector.name == 'platform'


# Generated at 2022-06-25 00:24:52.734156
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector = PlatformFactCollector()

    # Test 'system' fact
    system_fact = platform_fact_collector.collect(collected_facts=None)['system']
    assert system_fact in ['Linux', 'Darwin', 'Java', 'Windows']

    # Test 'system' fact
    kernel_fact = platform_fact_collector.collect(collected_facts=None)['kernel']
    assert len(kernel_fact) >= 1

    # Test 'system' fact
    kernel_version_fact = platform_fact_collector.collect(collected_facts=None)['kernel_version']
    assert len(kernel_version_fact) >= 1

    # Test 'machine' fact
    machine_fact = platform_fact_collector.collect(collected_facts=None)['machine']

# Generated at 2022-06-25 00:24:54.756351
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'


# Generated at 2022-06-25 00:24:59.818400
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts = platform_fact_collector_0.collect()

    if platform.system() == 'AIX':
        # On AIX the machine architecture is not the same as the kernel architecture
        # we just need to make sure that both are present so they can be used
        # by the user
        assert platform_facts["architecture"]
        assert platform_facts["userspace_architecture"]

    return True

# Generated at 2022-06-25 00:26:25.270946
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    """
    Test collect functionality of PlatformFactCollector
    """
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts = platform_fact_collector_0.collect()

    assert platform_facts['system'] == 'Linux'
    assert platform_facts['kernel'] == '4.4.0-47-generic'
    assert platform_facts['kernel_version'] == '#68-Ubuntu SMP Wed Oct 26 19:39:52 UTC 2016'
    assert platform_facts['machine'] == 'x86_64'
    assert platform_facts['python_version'] == '2.7.12'
    assert platform_facts['fqdn'] == 'ubuntu-xenial'
    assert platform_facts['hostname'] == 'ubuntu-xenial'

# Generated at 2022-06-25 00:26:29.771728
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    print(PlatformFactCollector().collect)

if __name__ == '__main__':
    test_PlatformFactCollector_collect()

# Generated at 2022-06-25 00:26:34.497723
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_1 = PlatformFactCollector()
    assert platform_fact_collector_1.name == 'platform'
    assert platform_fact_collector_1._fact_ids == set(['system',
                     'kernel',
                     'kernel_version',
                     'machine',
                     'python_version',
                     'architecture',
                     'machine_id'])


# Generated at 2022-06-25 00:26:35.949199
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:39.775718
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.name == 'platform'
    assert platform_fact_collector_0._fact_ids == set(['system',
                                                       'kernel',
                                                       'kernel_version',
                                                       'machine',
                                                       'python_version',
                                                       'architecture',
                                                       'machine_id'])

# Generated at 2022-06-25 00:26:45.506644
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    set_fact_ids = set(['system',
                        'kernel',
                        'kernel_version',
                        'machine',
                        'python_version',
                        'architecture'])
    platform_fact_collector_0._fact_ids = set_fact_ids
    assert platform_fact_collector_0._fact_ids == set_fact_ids

# Generated at 2022-06-25 00:26:52.242126
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert platform_fact_collector_0.__class__.__name__ == 'PlatformFactCollector'

    assert platform_fact_collector_0.name == 'platform'

    assert platform_fact_collector_0._fact_ids == {'system', 'kernel', 'kernel_version', 'machine', 'python_version', 'architecture', 'machine_id'}


# Generated at 2022-06-25 00:26:53.589218
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():

    # Testing constructor
    t0 = PlatformFactCollector()
    assert t0 is not None



# Generated at 2022-06-25 00:27:01.772217
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_0 = PlatformFactCollector()
    platform_facts_0 = {'machine_id': 'fake_machine_id', 'system': 'fake_system', 'kernel': 'fake_kernel', 'kernel_version': 'fake_kernel_version', 'machine': 'fake_machine', 'python_version': 'fake_python_version', 'architecture': 'fake_architecture'}
    assert platform_fact_collector_0.collect() == platform_facts_0


# Generated at 2022-06-25 00:27:07.187775
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform', 'platform_fact_collector.name is not platform'

    assert platform_fact_collector.collect()

    keys = ['system', 'kernel', 'kernel_version', 'machine', 'architecture', 'python_version', 'hostname',
            'domain', 'machine_id']
    for key in keys:
        assert key in platform_fact_collector.collect()

    assert platform_fact_collector.collect()['architecture'] == platform.machine()

    keys = ['userspace_bits', 'userspace_architecture']
    for key in keys:
        assert key in platform_fact_collector.collect()

    assert platform_fact_collector.collect()['python_version'] == platform.python_

# Generated at 2022-06-25 00:30:23.052444
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()


# Generated at 2022-06-25 00:30:26.211803
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()
    assert isinstance(platform_fact_collector_0, PlatformFactCollector)


# Generated at 2022-06-25 00:30:28.105959
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector.name == 'platform'

# Generated at 2022-06-25 00:30:28.724177
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:30:33.020465
# Unit test for method collect of class PlatformFactCollector

# Generated at 2022-06-25 00:30:35.263127
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector = PlatformFactCollector()
    assert platform_fact_collector._fact_ids == set(['system', 'kernel', 'kernel_version', 'machine', 'python_version',
                                                     'architecture', 'machine_id'])

# Generated at 2022-06-25 00:30:42.112016
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    expected_result = {
    	"system": "Linux",
    	"kernel": "4.4.0-28-generic",
    	"kernel_version": "#47-Ubuntu SMP Fri Jun 24 10:09:13 UTC 2016",
    	"machine": "x86_64",
    }

    platform_fact_collector = PlatformFactCollector()
    result = platform_fact_collector.collect()
    assert result == expected_result

# Generated at 2022-06-25 00:30:44.260563
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
    platform_fact_collector_0 = PlatformFactCollector()



# Generated at 2022-06-25 00:30:47.290675
# Unit test for constructor of class PlatformFactCollector
def test_PlatformFactCollector():
        platform_fact_collector = PlatformFactCollector()
        assert platform_fact_collector.name == 'platform'
        assert platform_fact_collector._fact_ids == {'system',
                                                     'kernel',
                                                     'kernel_version',
                                                     'machine',
                                                     'python_version',
                                                     'architecture',
                                                     'machine_id'}

# Generated at 2022-06-25 00:30:49.025453
# Unit test for method collect of class PlatformFactCollector
def test_PlatformFactCollector_collect():
    platform_fact_collector_1 = PlatformFactCollector()
    collected_facts = {}
    result = platform_fact_collector_1.collect(collected_facts=collected_facts)
    print(result)