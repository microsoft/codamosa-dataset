

# Generated at 2022-06-11 23:58:51.006956
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    assert PrettyStream is not None

# Generated at 2022-06-11 23:58:52.455254
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    fstream = EncodedStream(msg=msg)


# Generated at 2022-06-11 23:59:00.093779
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import requests
    import httpie

    # Request the http://httpbin.org/stream/5
    response = requests.get("http://httpbin.org/stream/5")

    # Extract body from the response
    body = response.json()["data"]

    # Create a new instance of RawStream, a
    stream = RawStream(
        msg=httpie.models.RawHTTPBody(data=body), with_headers=False, with_body=True
    )

    # Iterate over the data in the body of the response
    for line, lf in stream.iter_body():
        print(line)


# Generated at 2022-06-11 23:59:09.489050
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    env = Environment()

    msg = HTTPMessage(
        encoding='utf8',
        headers=['content-type: text/html; charset=utf8'],
        body='<html><head><title>First page.</title></head></html>',
    )

    # Instantiation of the class BufferedPrettyStream
    stream = BufferedPrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(
            style={
                'json': {
                    'colors': {'key': 'red', 'value': 'yellow'},
                    'indent_size': 2,
                },
            },
            theme='solarized',
        ),
        with_headers=True,
        with_body=True,
    )

    stream_gen_1 = stream.iter_body()
    stream

# Generated at 2022-06-11 23:59:15.523425
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
	msg = HTTPMessage()
	msg.headers.add('Content-Length','11')
	msg.body.append('hello world')
	result = ''
	stream = RawStream(msg=msg,with_headers=True,with_body=True)
	for i in stream.iter_body():
		result += i.decode('utf-8')
	print(result)

# Generated at 2022-06-11 23:59:18.224830
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    message = HTTPMessage()
    message.encoding = 'utf8'
    assert EncodedStream(msg=message).output_encoding == 'utf8'

# Generated at 2022-06-11 23:59:23.515616
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json

    formatting = Formatting()
    conversion = Conversion()
    msg = HTTPMessage(200, [('Content-Type', 'application/json')], '{"foo": "bar"}')
    ps = PrettyStream(msg=msg, formatting=formatting, conversion=conversion)
    assert json.loads(ps.process_body(b'"foo"\n')) == 'foo'
    assert json.loads(ps.process_body(b'"bar"\n')) == 'bar'

# Generated at 2022-06-11 23:59:33.308099
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg_str = (
        u'HTTP/1.1 200 OK\r\n'
        u'Content-Type: application/json\r\n'
        u'\r\n'
        u'{"id": 1, "name": "A green door", "price": 12.50, "tags": ["home", "green"]}\n'
        u'{"id": 2, "name": "A red door", "price": 12.50, "tags": ["home"]}\n'
        u'{"id": 3, "name": "A blue door", "price": 12.50, "tags": ["home"]}\n'
        u'{"id": 4, "name": "A green door", "price": 12.50, "tags": ["home", "green"]}\n'
    ).encode('utf8')
    msg = HT

# Generated at 2022-06-11 23:59:39.556660
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    class fake:
        def __init__(self):
            pass
        def format_headers(self, headers):
            return 'this is formatting'
    formatting = fake()
    obj = PrettyStream(conversion=None, formatting=formatting, msg=None, with_headers=True,
                        with_body=True, on_body_chunk_downloaded=None)
    ret = obj.get_headers()
    assert ret == b'this is formatting'

# Generated at 2022-06-11 23:59:46.364239
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Creating a dummy message
    msg = HTTPMessage()
    msg.headers = """HTTP/1.1 200 OK
        server: nginx/1.16.1
        date: Thu, 05 Dec 2019 11:51:09 GMT
        content-type: text/html
        content-length: 13
        last-modified: Thu, 05 Dec 2019 11:49:48 GMT
        connection: close"""
    # Creating a dummy iter_body function
    def iter_body():
        yield b'Hello, world'
    msg.iter_body = iter_body

    # Creating the raw stream
    stream = RawStream(msg)
    # Performing the test [1]
    assert list(stream.iter_body()) == [b'Hello, world']

    # Creating another dummy message
    msg = HTTPMessage()

# Generated at 2022-06-12 00:00:02.808111
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage()
    msg.headers = "Content-Type: text/html; charset=utf-8"
    msg.encoding = 'utf-8'
    msg.body = "<h1>test for EncodedStream</h1>\n"
    def iter_lines(chunk_size=1):
        return [("<h1>test for EncodedStream</h1>\n", "\n")]

    msg.iter_lines = iter_lines

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = "gbk"

    stream = EncodedStream(msg=msg, env=env, with_headers=False)
    encoding = stream.output_encoding
    msg = b''

# Generated at 2022-06-12 00:00:06.241988
# Unit test for constructor of class RawStream
def test_RawStream():
    expected = 'http://api.twitter.com/1.1/statuses/user_timeline.json'
    actual = RawStream.__init__(expected)
    assert expected == actual


# Generated at 2022-06-12 00:00:13.814959
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import Response
    response = Response(response_line=b'',
                        headers=b'HTTP/1.1 200 OK\r\n'
                                b'Server: Apache/2.2.15 (CentOS)\r\n'
                                b'Content-Type: application/json\r\n'
                                b'Date: Thu, 01 Jun 2017 16:21:18 GMT\r\n',
                        body=b'{"id": "1"}\n',
                        encoding='utf-8')
    stream = PrettyStream(msg=response,
                          conversion=Conversion(),
                          formatting=Formatting())
    for l in stream:
        print(l)
        #assert l == b'{"id": "1"}\n'


# Generated at 2022-06-12 00:00:17.048883
# Unit test for constructor of class RawStream
def test_RawStream():
    def fn():
        data = {
            "method": "POST",
            "headers": {
                "Content-Type": "application/json"
            },
            "body": ""
        }
        a = RawStream(data)
        return a
    fn()

# Generated at 2022-06-12 00:00:27.429670
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from io import BytesIO
    from httpie.models import HTTPRequest

    body = b'abc\ndef\n'
    env = Environment()
    body_chunk_downloaded = BytesIO()
    req = HTTPRequest.from_string(
        b'GET / HTTP/1.1\n'
        b'Host: example.com\n'
        b'User-Agent: curl/7.54.0\n'
        b'Accept: */*\n'
        b'\n',
        body=body
    )
    s = BaseStream(req, with_headers=True, with_body=True,
                   on_body_chunk_downloaded=body_chunk_downloaded.write)
    for streamchunk in s:
        env.stdout.write(streamchunk)
    env

# Generated at 2022-06-12 00:00:31.714300
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers

    h = Headers({"a": "b"})
    stream = PrettyStream(msg=HTTPMessage(headers=h), env=Environment())

    headers = stream.get_headers()

    assert type(headers) == bytes

# Generated at 2022-06-12 00:00:33.206940
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    sample = HTTPMessage()
    assert EncodedStream(msg = sample)

# Generated at 2022-06-12 00:00:35.378568
# Unit test for constructor of class RawStream
def test_RawStream():
    assert issubclass(RawStream, BaseStream)
    assert RawStream.__init__.__defaults__ == (102400,)

# Generated at 2022-06-12 00:00:39.887180
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/html\r\n', body=b'Hello World')
    c_stream = EncodedStream(msg=msg)
    for chunk in c_stream.iter_body():
        print(chunk)



# Generated at 2022-06-12 00:00:50.841291
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    '''
    The function test_PrettyStream_get_headers is used to test the get_headers method of the
    PrettyStream class. Since, the method is a part of the abstract class so we are going to
    test two types of HTTP messages (HTTPRequest, HTTPResponse).
    '''

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()

    # Testing for HTTPRequest:

# Generated at 2022-06-12 00:01:14.534161
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Case 1: Passing in an empty Environment object
    env = Environment()
    msg = HTTPMessage()
    stream = EncodedStream(msg=msg)

    # Expected results
    expected_encoding = 'utf8'
    expected_chunk_size = 1

    assert stream.output_encoding == expected_encoding
    assert stream.CHUNK_SIZE == expected_chunk_size


# Generated at 2022-06-12 00:01:26.403769
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():

    import httpie.output.streams as streams
    stream = streams.PrettyStream(
        msg=None,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        conversion=None,
        formatting=None,
    )
    # TODO: tests for binary data, non-UTF8 data, ...

    from httpie import models as m
    resp = m.HTTPResponse(
        headers={'Content-Type': 'application/json'},
        encoding='utf8',
        body=b'[]',
    )
    stream.msg = resp
    stream.mime = resp.content_type.split(';')[0]
    data = stream.process_body(resp.body)

# Generated at 2022-06-12 00:01:32.847859
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    "Incomplete"
    msg = HTTPMessage(
        str.encode('HTTP/1.1 200 OK\n\nbody\nbody2\nbody3'))
    msg.headers = str.encode('Content-Type: text/plain')
    msg.encoding = 'utf8'
    st = RawStream(msg=msg)
    tmp = []
    for chk in st:
        tmp.append(chk)
    assert b'body\nbody2\nbody3' == b''.join(tmp)

# Generated at 2022-06-12 00:01:42.742095
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # noinspection PyTypeChecker
    p = PrettyStream(msg="message",
                    conversion="выражение",
                    formatting="выражение")
    # noinspection SpellCheckingInspection,PyTypeChecker
    b = p.process_body("форматирование")
    assert b == b'\xd1\x84\xd0\xbe\xd1\x80\xd0\xbc\xd0\xb0\xd1\x82\xd0\xb8\xd1\x80\xd0' \
                  b'\xbe\xd0\xb2\xd0\xb0\xd0\xbd\xd0\xb8\xd0\xb5'

# Generated at 2022-06-12 00:01:52.710009
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    debug("Testing iter_body method of class PrettyStream")
    headers = {}
    # body = "[1, 2, 3]"
    body = '''{ "a": 1, "b": 2, "c": 3, "d": 4, "e": 5 } [1, 2, 3]'''
    msg = HTTPMessage(headers, body)
    conversion = Conversion()
    formatting = Formatting()
    p = PrettyStream(msg, conversion, formatting)
    for chunk in p.iter_body():
        debug("chunk: " + str(chunk))
    debug("End of Method iter_body")
# End of unit test for method iter_body of class PrettyStream

if __name__ == '__main__':
    from tests.printers import *
    test_PrettyStream_iter_body()

# Generated at 2022-06-12 00:01:55.582197
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(body=b'1234567890')
    stream = RawStream(msg=msg)
    body_stream = stream.iter_body()
    assert next(body_stream) == b'1234567890'


# Generated at 2022-06-12 00:01:57.271455
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    """Unit test for method __iter__ of class BaseStream"""
    #todo
    pass


# Generated at 2022-06-12 00:01:58.421941
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    pass


# Generated at 2022-06-12 00:02:06.243011
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    print("\nIn function test_BaseStream___iter__:")
    msg = HTTPMessage(headers={"A": "a", "B": "b"}, body="Body")
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    stream = BaseStream(
        msg=msg,
        with_headers=with_headers,
        with_body=with_body,
        on_body_chunk_downloaded=on_body_chunk_downloaded,
    )
    # Test the function __iter__
    print("  stream =", stream)
    print("  stream.__iter__ =", stream.__iter__)
    for chunk in stream:
        print(chunk)


# Generated at 2022-06-12 00:02:13.866354
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(iter_lines = [[b'{"test": "test"},\r\n', b'\n'],
                                                           [b'{"test2": "test2"}', b'\n']])
    msg._encoding = 'utf8'

    stream = PrettyStream(msg=msg, with_headers=True, with_body=True, conversion=None,
                          formatting=None, encoding='utf8', on_body_chunk_downloaded=None)
    for line in stream.iter_body():
        print(line)


# Generated at 2022-06-12 00:02:57.053091
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    class TestableBaseStream(BaseStream):
        def __init__(self, msg, **kwargs):
            super().__init__(msg, **kwargs)
            self.with_headers = True
            self.with_body = True

        def get_headers(self):
            return "headers".encode('utf8')

        def iter_body(self):
            return "body".encode('utf8')

    for stream in (RawStream, EncodedStream):
        bs = TestableBaseStream(HTTPMessage(), with_headers=True, with_body=True)
        assert [b"headers\r\n\r\nbody"] == list(bs.__iter__())

        bs = TestableBaseStream(HTTPMessage(), with_headers=False, with_body=True)

# Generated at 2022-06-12 00:02:59.002394
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    c=RawStream(msg=None)
    assert c.iter_body()



# Generated at 2022-06-12 00:03:09.319960
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import io
    import requests

    raw_body = "HTTP/1.1 200 OK\r\n" + "Content-Type: text/html; charset=utf-8\r\n" + "Content-Length: 0\r\n" \
               + "Connection: keep-alive\r\n" + "\r\n" + "some data"
    output = io.BytesIO(
        raw_body)

    response = requests.get('http://www.taobao.com')
    msg = HTTPMessage(
        raw=raw_body,
        encoding='utf8',
        content_type='text/html; charset=utf-8',
        http_version=response.raw.version
    )


# Generated at 2022-06-12 00:03:13.968032
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    http_message = HTTPMessage(headers="HTTP/1.1 200 OK\r\n", body="Hello, World!\n".encode())
    assert isinstance(EncodedStream(msg=http_message, on_body_chunk_downloaded=None), EncodedStream)



# Generated at 2022-06-12 00:03:22.513633
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():

    from httpie.models import Request, Response
    from httpie.output.streams import RawStream, PrettyStream
    import copy

    # __init__ of class BaseStream
    msg = Request()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    bps = BufferedPrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded)

    assert copy.deepcopy(bps.msg) == copy.deepcopy(msg)
    assert bps.with_headers == with_headers
    assert bps.with_body == with_body
    assert bps.on_body_chunk_downloaded == on_body_chunk_downloaded
    assert bps.CHUNK_SIZE == 1024 * 10

    # __init__ of class PrettyStream

# Generated at 2022-06-12 00:03:30.924313
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Test with a message without body
    msg = HTTPMessage("HTTP/1.1 200 OK")
    raw_stream = RawStream(msg, with_body=True)
    for chunk in raw_stream.iter_body():
        pass

    # Test with a message with body
    msg = HTTPMessage("HTTP/1.1 200 OK\r\n\r\nbody")
    raw_stream = RawStream(msg, with_body=True)
    body_string = ""
    for chunk in raw_stream.iter_body():
        body_string += chunk.decode("utf-8")
    assert body_string == "body"



# Generated at 2022-06-12 00:03:32.085696
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print(EncodedStream)


# Generated at 2022-06-12 00:03:40.720712
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from httpie.core import main
    from httpie.downloads import Downloader


    response = HTTPResponse()
    response.request = {
        'headers': {},
        'url': "https://http4.me/helloworld.txt"
    }
    response.status_code = 200
    response.headers = {
        "Content-Type": "text/plain"
    }
    response.request_time = 0.0
    response.raw = b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nHelloWorld!"
    response.raw_request_info = {}

    env = Environment()
    env.stdout_isatty = False

    download

# Generated at 2022-06-12 00:03:43.325839
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    x = RawStream(msg = 'Hello World!')
    assert list(x.iter_body()) == [b'\r',b'\n',b'\r',b'\n',b'Hello World!']

# Generated at 2022-06-12 00:03:53.256678
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class msg(object):
        encoding = 'utf8'
        content_type = 'application/json; charset=utf8'

        def iter_body(self, size):
            yield b'{'
            yield b'  "foo"'
            yield b':'
            yield b'  123,'
            yield b'  "bar"'
            yield b':'
            yield b'  456'
            yield b'}'

    class formatting(object):
        def format_headers(self, headers):
            return headers

        def format_body(self, content, mime):
            import json
            return json.dumps(json.loads(content), indent=2)

    class conversion(object):
        def get_converter(self, mime):
            return None


# Generated at 2022-06-12 00:05:03.049456
# Unit test for constructor of class RawStream
def test_RawStream():
    rawstr = RawStream(None, None, None)
    assert rawstr != None, "RawStream constructor is not defined"


# Generated at 2022-06-12 00:05:10.507865
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class TestHTTPMessage(HTTPMessage):
        def iter_body(self, chunk_size):
            return iter(["first line\n", "\n", "second line\n"])

    class TestEnvironment(Environment):
        def __init__(self):
            self.stdout_isatty = True
            self.stdout_encoding = "utf8"
            self.headers = True
            self.body = True


# Generated at 2022-06-12 00:05:20.429303
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie import httpbin
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import builtin

    p = PrettyStream(conversion=None, formatting=None, msg=None, with_headers=None, with_body=None, on_body_chunk_downloaded=None)
    p = PrettyStream(conversion=None, formatting=None, msg=None, with_headers=None, with_body=None)
    p = PrettyStream(conversion=None, formatting=None, msg=None, with_headers=None)
    p = PrettyStream(conversion=None, formatting=None, msg=None)
    p = PrettyStream(conversion=None, formatting=None)

# Generated at 2022-06-12 00:05:21.218907
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    bps = BufferedPrettyStream()


# Generated at 2022-06-12 00:05:22.879233
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-12 00:05:28.812129
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from io import BytesIO  # type: ignore
    base = BaseStream(Response(status_code=200,
                               headers={'Content-Encoding': 'gzip', 'Content-Type': 'application/json'},
                               body=BytesIO(b'{"a":1,"b":2}'))
                      )  # type:ignore
    assert len(list(base.__iter__())) == 7



# Generated at 2022-06-12 00:05:33.286526
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    list_chunk = [b'\0',b'\r',b'\n',b'a',b'b',b'c',b'\r',b'\n']
    a = BufferedPrettyStream(None,None,None,None,None)
    a.iter_body(list_chunk)



# Generated at 2022-06-12 00:05:36.895827
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    bs = EncodedStream(msg=HTTPMessage('{"a":1}'.encode('utf-8')), with_headers=False, with_body=True,
                       on_body_chunk_downloaded=None)
    for chunk in bs.iter_body():
        print(chunk)

# Generated at 2022-06-12 00:05:41.943095
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n\r\n'
              b'test: true\n'
              b'content-length: 2\r\n\r\n'
              b'OK')
    stream = RawStream(msg, True, True)
    body = b'OK'
    assert stream.iter_body().__next__() == body

# Generated at 2022-06-12 00:05:51.473088
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse

    import io
    import os

    from httpie.config import HTTPIE_COLORS_256
    from httpie.output.config import OutputConfig
    from httpie.output.formatters import CONTENT_TYPE_FORMATTERS
    from httpie.output.processing import ContentTypeConverter, ContentTypeFormatter, Conversion, Formatting

    from httpie.downloads import Downloader
    from httpie.context import Environment
    from httpie.status import ExitStatus


# Generated at 2022-06-12 00:08:22.077899
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # test without converter
    # stub
    def msg_iter_body(self, chunk_size):
        yield 'hello'
        yield 'world'
    # test
    env = Environment()
    msg = (HTTPMessage(request_headers=None,
                    request_body='HelloWorld',
                    response_headers=None,
                    response_body='')
         .get_response(request_headers=None,
                       url='http:&&example.com',
                       method='GET')
    )
    msg.iter_body = partial(msg_iter_body, msg)
    ps = BufferedPrettyStream(msg=msg, env=env,
                                  with_headers=False,
                                  with_body=False,
                                  conversion=None,
                                  formatting=None)
    result = []

# Generated at 2022-06-12 00:08:29.258561
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class msg:
        encoding = 'utf8'
        content_type = 'application/json'
        def iter_body(self, chunk_size):
            body = b'{"a": "A"}\n{"b": "B"}'
            yield body[0:10]
            yield body[10:20]
            yield body[20:30]
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    conversion = Conversion()
    conversion.available_converters = [
        ('application/json', lambda _: ('text/plain', '{"b": "B"}'))
        ]
    formatting = Formatting()
    formatting.available_formats = [('text/plain',
        lambda content, mime: content.upper())]

# Generated at 2022-06-12 00:08:37.600060
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from io import BytesIO
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream

    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'X-Custom: True',
        body=BytesIO(b'Hello world!')
    )
    stream = EncodedStream(msg=response)

    assert stream.msg == response
    assert stream.output_encoding == 'utf8'

    assert stream.get_headers() == b'X-Custom: True'
    assert stream.iter_body() == [b'Hello world!']