

# Generated at 2022-06-11 23:58:55.589883
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.0 200 OK\r\n\r\n' + b'\r\n'.join([
        b'hello',
        b'\x00',
        b'world'
    ]), charset='utf8')
    s = EncodedStream(msg)
    body_iter = s.iter_body()
    assert next(body_iter) == b'hello\r\n'
    with pytest.raises(BinarySuppressedError):
        next(body_iter)

# Generated at 2022-06-11 23:59:01.632212
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers={'Content-Type': 'text/plain'},
            body=b'hoge\r\nhuga\r\n\r\n',
            encoding='utf8')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'hoge\r\n', b'huga\r\n', b'\r\n']


# Generated at 2022-06-11 23:59:10.453724
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    def run_test(data, mime, expected, conversion):
        # Arrange
        stream = BufferedPrettyStream(
            msg=HTTPMessage('HTTP/1.1 200 OK', {}, data.encode('utf8')),
            conversion=conversion,
            formatting=Formatting(),
            on_body_chunk_downloaded=None,
            env=Environment()
            )
        stream.mime = mime
        stream.msg.content_type = mime
        lines = []

        # Act
        for line in stream.iter_body():
            lines.append(line)

        # Assert
        result = b''.join(lines).decode('utf8')
        assert result == expected

    mime = 'application/json'
    conversion = Conversion()

# Generated at 2022-06-11 23:59:16.013851
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    test_msg = HTTPMessage()
    t = EncodedStream(env=env, msg=test_msg)

    assert isinstance(env, Environment)
    assert isinstance(t, EncodedStream)
    assert t.msg == test_msg
    assert t.with_headers == True
    assert t.with_body == True


# Generated at 2022-06-11 23:59:19.888124
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    msg.set_body('11111\n22222\n33333\n')
    raw = RawStream(msg)
    assert list(raw.iter_body()) == [b'11111\n', b'22222\n', b'33333\n']



# Generated at 2022-06-11 23:59:21.761064
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():

    x = BufferedPrettyStream(msg = HTTPMessage(),
                             conversion = Conversion(),
                             formatting = Formatting())



# Generated at 2022-06-11 23:59:25.608392
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage('test', headers={'Content-Type': 'text/plain;charset=utf8'}, body='test')
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert b"b'test'" == next(stream.iter_body()) and b'' == next(stream.iter_body())

# Generated at 2022-06-11 23:59:27.074288
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream = EncodedStream("hello, world!")
    assert stream != None

# Generated at 2022-06-11 23:59:33.392446
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from io import BytesIO
    from httpie.core import main
    from httpie.core import io
    from httpie.output.streams import BufferedPrettyStream
    import tempfile

    fd, fname = tempfile.mkstemp()

# Generated at 2022-06-11 23:59:38.005655
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = 'hello\r\nworld\r\n'.encode('utf8')
    check = ['hello\r\n', 'world\r\n']
    for e_stream in EncodedStream(msg).iter_body():
        if e_stream == check:
            return True
    return False

# Generated at 2022-06-12 00:00:02.505073
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-12 00:00:11.972157
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # make sure we have a testable environment
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.prettify = True

    # create a silly message to convert
    msg = HTTPMessage('content-type: test/test\ncontent-length: 11\n\ntest\nline2\n', 'utf8')
    stream = PrettyStream(
        msg=msg,
        env=env,
        conversion=Conversion.None_,
        formatting=Formatting.None_,
    )

    # make sure we actually convert our data
    assert b'line2' in bytearray(stream)


# Generated at 2022-06-12 00:00:14.098571
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw = RawStream(msg=HTTPMessage())
    for chunk in raw.iter_body():
        print(chunk)



# Generated at 2022-06-12 00:00:21.674281
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class Message:
        content = "test body"
        encoding = "utf8"

        def iter_lines(self, chunk_size):
            yield self.content, "\r\n"

    class Formatter:
        def format_body(self, content: str, mime: str) -> str:
            return "**" + content + "**"

    class Conversion:
        def get_converter(self, mime: str) -> Optional[Converter]:
            return None

    message = Message()
    formatter = Formatter()
    conversion = Conversion()

    stream = PrettyStream(
        msg=message,
        conversion=conversion,
        formatting=formatter,
    )

    output_encoding = "utf8"
    chunks = [chunk for chunk in stream.iter_body()]

# Generated at 2022-06-12 00:00:32.135315
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import tempfile
    import os
    from httpie.output.streams import RawStream
    from httpie.models import Response
    f = tempfile.NamedTemporaryFile()
    f.write(b'hello')
    f.close()
    with open(f.name, 'rb') as f:
        response = Response(headers=b'',
                            body=f,
                            encoding='utf8',
                            status_line=b'HTTP/1.1 200 OK',
                            request_url=''
                            )
    stream = RawStream(msg=response, chunk_size=1, with_headers=False)
    body = b''
    for chunk in stream:
        body += chunk
    assert body == b'hello'
    os.remove(f.name)


# Generated at 2022-06-12 00:00:40.842409
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    conversion = Conversion()
    formatting = Formatting()
    formatting.parse_options_and_set_defaults()
    msg = '''HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\n{"name": "Tom", "age": 21}'''
    ps = PrettyStream(
        HTTPMessage.from_raw(msg.encode('utf8')),
        conversion,
        formatting,
    )
    print(ps.get_headers())
    print('')
    for item in ps.iter_body():
        print(item.decode('utf8'))


# Generated at 2022-06-12 00:00:51.792549
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    class MockBaseStream(BaseStream):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.body_chunks = []

        def get_headers(self):
            return b'super secret headers'

        def iter_body(self):
            for chunk in self.body_chunks:
                yield chunk
                if self.on_body_chunk_downloaded:
                    self.on_body_chunk_downloaded(chunk)

    # With headers, without body
    s = MockBaseStream(
        msg=b'',
        with_headers=True,
        with_body=False,
    )
    assert list(s) == [b'super secret headers\r\n\r\n']

    # With headers, with body
   

# Generated at 2022-06-12 00:00:57.326808
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    env = Environment(stdout_isatty= True, stdout_encoding= 'utf8')
    msg = HTTPMessage('Test', 'Test', encoding= 'utf8')
    conversion = Conversion()
    formatting = Formatting()

    assert isinstance(BufferedPrettyStream(msg, env, conversion, formatting, with_headers= True, with_body= True), BufferedPrettyStream)

# Generated at 2022-06-12 00:01:02.211778
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    conversion = Conversion()
    formatting = Formatting()
    msg = Response(body=b'\0\n2 4\n1 3 5\n', encoding='utf8')
    stream = BufferedPrettyStream(conversion=conversion,
                                  formatting=formatting, msg=msg)
    assert list(stream.iter_body()) == [b'\n2 4\n1 3 5\n']



# Generated at 2022-06-12 00:01:13.321593
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # content: string, mime: string, expected: string
    input_data = [
        ('this is a test\n', 'text/plain', 'this is a test\n'),
        ('this is a test\n', 'text/html', '<p>this is a test</p>\n'),
        ('{"name": "httpie", "age": 8}\n', 'application/json',
         ('{\n'
          '    "age": 8, \n'
          '    "name": "httpie"\n'
          '}'))
    ]
    output_encoding = "utf8"
    formatting = Formatting(colors={})
    conversion = Conversion()

# Generated at 2022-06-12 00:01:51.818731
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    headers = 'Content-Type: application/json'
    body = [b'{"test": "test"}']
    msg = HTTPMessage(headers=headers, body_bytes=body)
    my_pretty_stream = BufferedPrettyStream(msg)
    assert next(my_pretty_stream.iter_body()) == b'{\n    "test": "test"\n}'

# Generated at 2022-06-12 00:02:01.528844
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    http_message = HTTPMessage(headers='test')

    class formatting(object):
        def format_headers(self, msg):
            return msg

    conversion = None
    class env(object):
        stdout_isatty = None
        stdout_encoding = None
        kwargs = {}
        kwargs['json_indent'] = 2
        kwargs['headers_encode'] = 'utf8'
        kwargs['style'] = 'all-styles'
        kwargs['colors'] = 'all-colors'

    pretty_stream = PrettyStream(
        http_message,
        True,
        True,
        conversion,
        formatting(),
        env(),
    )
    result = pretty_stream.get_headers()
    assert result == b"test\n"


# Unit test

# Generated at 2022-06-12 00:02:02.228071
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-12 00:02:02.916709
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert type(EncodedStream) == type

# Generated at 2022-06-12 00:02:13.214077
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    print("\n* Test EncodedStream iter_body:")
    from httpie.models import HTTPResponse
    from httpie.compat import httplib
    headers = httplib.HTTPMessage(StringIO(
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/plain;charset=utf8\r\n"
        "Content-Length: 11\r\n"
    ))
    body = "hello\nworld"

    counter = 0
    def callback(chunk):
        nonlocal counter
        counter += 1
    response = HTTPResponse(headers, body)
    stream = EncodedStream(response, with_headers=False, on_body_chunk_downloaded=callback)
    assert counter == 0


# Generated at 2022-06-12 00:02:18.782150
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import httpie.output.formatters.default
    msg = HTTPMessage(body=b'hello\n')
    msg.content_type = 'text/plain'
    msg.encoding = 'utf8'
    stream = PrettyStream(msg)
    result = stream.process_body(msg.body)
    assert (result == b'hello%s' % httpie.output.formatters.default.LF)

# Generated at 2022-06-12 00:02:30.913223
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import sys
    import argparse
    from httpie.compat import urlopen
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.cli import environment
    from httpie.client import HTTPieRequest
    from httpie.output import OutputOptions
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    OK_COLOR = '32'
    NOT_OK_COLOR = '31'
    URL = 'https://httpbin.org/get'
    parser_ = parser.get_argparser()
    args = parser_.parse_args()
    env = environment.Environment(vars(args), 'http', output_options=OutputOptions())
    env.config.default_options['--print'] = 'h'

# Generated at 2022-06-12 00:02:40.180610
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Create an instance of HTTPMessage
    h = HTTPMessage("", "", b'1')

    # Create an instance of EncodedStream without optional parameters
    s = EncodedStream(h)

    # Test if the body is binary, then BinarySuppressedError will be raised
    try:
        for iter_body in s.iter_body():
            raise Exception
    except DataSuppressedError as ex:
        assert ex.message == BINARY_SUPPRESSED_NOTICE

    # Test if the EncodedStream works well
    e = EncodedStream(h)
    assert next(e.iter_body()) == b'1'

# Generated at 2022-06-12 00:02:47.286506
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # create a prettystream and send it a string
    # verify that the string returned is different
    # than what was sent and that it is a string
    ps = PrettyStream(None, None, None)
    msg = "hello world"
    result = ps.process_body(msg)
    assert result != msg
    assert isinstance(result, bytes)

    # create a prettystream and send it a byte array
    # verify that the result returned is different
    # than the byte array sent and that it is a byte array
    msg = bytearray([120,3,255,0])
    result = ps.process_body(msg)
    assert result != msg
    assert isinstance(result, bytes)



# Generated at 2022-06-12 00:02:50.016945
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    text = "test data"
    stream = PrettyStream(None, None, None)
    output = stream.process_body(text)
    assert str(output) == text

# Generated at 2022-06-12 00:03:37.518307
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import io
    import pytest
    from httpie.output.formatters.colors import get_lexer
    from httpie.models import HTTPResponse
    from pygments import highlight
    from pygments.lexers.data import JsonLexer
    from pygments.formatters import TerminalFormatter

    env = Environment()
    env.colors = 256
    lexer = get_lexer(env)

    resp = HTTPResponse(200, 'OK', {
        'Content-Type': 'application/json'
    }, '')

    stream = EncodedStream(env=env, msg=resp, with_headers=True, with_body=True)

    out = io.BytesIO()
    for chunk in stream:
        out.write(chunk)

# Generated at 2022-06-12 00:03:46.596996
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    env = Environment()
    msg = HTTPMessage(headers='bla: bla', body=b'a\0\nb')
    stream = EncodedStream(msg, with_headers=False, env=env)
    assert list(stream.iter_body()) == [b'a\0\nb']

    env.stdout_isatty = False
    stream = EncodedStream(msg, with_headers=False, env=env)
    assert list(stream.iter_body()) == [b'a\0\nb']

    env.stdout_isatty = True
    stream = EncodedStream(msg, with_headers=False, env=env)
    assert list(stream.iter_body()) == [b'a?\nb']

# Generated at 2022-06-12 00:03:54.329749
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # 1. Test with a txt file
    msg_txt = HTTPMessage(headers=':', content='abc')
    msg_txt.content_type = "text/plain"
    msg_txt.encoding = None
    
    conversion_txt = Conversion()
    conversion_txt.get_converter("text/plain")
    formatting_txt = Formatting()
    
    print("test_txt_1:")
    for i in msg_txt.iter_body(1):
        print(i)
    print("test_txt_2:")
    for i in PrettyStream(msg=msg_txt, conversion=conversion_txt, formatting=formatting_txt).iter_body():
        print(i)
    # 2. Test with a json file

# Generated at 2022-06-12 00:03:55.232954
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert False, "Test not implemented."



# Generated at 2022-06-12 00:04:00.603468
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import requests
    import json

    response = requests.post('http://httpbin.org/stream/10', json={"name": "qi", "age": 25})
    stream = PrettyStream(msg=response.raw, with_headers=False, with_body=True, conversion=Conversion())
    for chunk in stream.iter_body():
        print(chunk)

if __name__ == '__main__':
    test_PrettyStream_iter_body()

# Generated at 2022-06-12 00:04:09.003730
# Unit test for constructor of class RawStream
def test_RawStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.core import main
    from httpie.utils import make_mocked_request

    mock_request = make_mocked_request()
    mock_args = main.parser.parse_args([])
    mock_args.output_options.__dict__['style'] = 'default'
    mock_args.stream = True
    normal_resp = HTTPResponse(mock_request, b'content', 200)
    raw_stream = RawStream(normal_resp)
    print(raw_stream)
    assert raw_stream.iter_body() == normal_resp.iter_body()

# Generated at 2022-06-12 00:04:19.007363
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():

    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from requests.models import Response
    import io
    import os

    def get_file_path(file_name):
        file_path = os.path.abspath('.') + '/test_data' + '/' + file_name
        return file_path 

    def read_file(file_path):
        f = open(file_path, 'r')
        content = f.read()
        f.close()
        return content

    def write_file(file_path, content):
        f = open(file_path, 'w')
        f.write(content)
        f.close()

    def get_response(req):
        response = req.send()


# Generated at 2022-06-12 00:04:20.181199
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert type(EncodedStream()) is EncodedStream


# Generated at 2022-06-12 00:04:24.244739
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # arranges
    msg = HTTPMessage.parse(b"GET / HTTP/1.1\r\n\r\n")
    base_stream = BaseStream(msg=msg)
    # actions
    result = base_stream.__iter__()
    # asserts
    assert result == iter(b"GET / HTTP/1.1\r\n\r\n")


# Generated at 2022-06-12 00:04:34.694352
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Create a http message with a body containing binary data
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    m = HTTPRequest("https://example.com/",
                    method="POST",
                    data=b'\0',
                    headers={'Content-Type': 'application/json'})
    # Create a stream
    env = Environment()
    stream = BufferedPrettyStream(msg=m,
        with_headers=True,
        with_body=True,
        formatting=Formatting(),
        conversion=Conversion(),
        env=env)
    # Use the method iter_body
    seen_exception = False
    try:
        for _ in stream.iter_body():
            pass
    except BinarySuppressedError:
        seen_exception = True
    assert seen_exception == True

# Generated at 2022-06-12 00:05:56.886065
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from json import dumps
    from httpie.output.streams import BufferedPrettyStream as BPS

    def test_case(body, conversion):
        headers = {
            'Content-Type': 'application/json',
            'Content-Length': len(body)
        }

        msg = HTTPMessage(headers=headers, body=body)
        msg.encoding = 'utf8'
        stream = BPS(
            msg=msg,
            conversion=conversion,
            formatting=Formatting(),
            env=Environment()
        )

        assert next(stream.iter_body()) ==\
               dumps(eval(body)).encode('utf8')

    test_case('{"foo": "bar"}', Conversion())

# Generated at 2022-06-12 00:05:58.403597
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    stream = BufferedPrettyStream(msg, conversion, formatting)

# Generated at 2022-06-12 00:06:03.345798
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    s = EncodedStream("this is a valid test for iter_body", "a test for iter_body", "a test for iter_body")
    assert s.get_headers() == 'this is a valid test for iter_body'
    assert s.iter_body() == "a test for iter_body"
    assert s == "a test for iter_body"


# Generated at 2022-06-12 00:06:11.773881
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    """ 
    get test case from requests

    """
    url = 'https://httpbin.org/encoding/utf8'
    """
    case 1:
    env.stdout_encoding = 'latin1'
    self.msg.encoding = None

    """
    env1 = Environment(
        stdout_encoding='latin1',
        stdout_isatty=True
    )

    msg1 = HTTPMessage(
        encoding=None
    )

    es1 = EncodedStream(env=env1,msg=msg1)
    assert es1.output_encoding == 'latin1'

    """
    case 2:
    env.stdout_encoding = None
    self.msg.encoding = 'utf8'

    """

# Generated at 2022-06-12 00:06:20.695944
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    #test the case where there is no NULL char
    #create a HTTPMessage
    msg = HTTPMessage(
        http_version='1.1',
        status_code=200,
        headers={'Content-Type': 'text/html;charset=utf-8',
                 'Content-Encoding': 'utf-8'},
        body='{"Hello":"World"}'
    )
    #create a EncodedStream
    s = EncodedStream(msg=msg)
    #get the iterator
    i = s.iter_body()
    r = b'{"Hello":"World"}\r\n'
    assert next(i) == r
    assert BinarySuppressedError not in i
    with pytest.raises(StopIteration):
        next(i)
    #test the case where there is a NULL char


# Generated at 2022-06-12 00:06:28.083066
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # output_encoding = utf8 when unsure
    stream = EncodedStream(msg=HTTPMessage(encoding='utf8', body='test'))
    assert stream.output_encoding == 'utf8'
    # output_encoding = self.msg.encoding when not unsure
    stream = EncodedStream(env=Environment(stdout_isatty=False),
                           msg=HTTPMessage(encoding='utf8', body='test'))
    assert stream.output_encoding == 'utf8'

# Generated at 2022-06-12 00:06:37.805200
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Message
    class Msg(Message):
        def __init__(self):
            self.headers = "id:1 name:2"
            self.body = "hello world"
            self.encoding = "utf-8"
        def iter_body(self, size = 1024):
            return self.body
    msg = Msg()
    stream = BaseStream(msg, True, True)
    assert stream.with_headers == True
    assert stream.with_body == True
    header = "id:1 name:2"
    assert(header.encode("utf-8") in stream.get_headers())
    assert("\r\n\r\n".encode("utf-8") in stream.get_headers())

# Generated at 2022-06-12 00:06:47.435856
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    def gen_get_headers():
        yield b'1'
        yield b'2'
    class Mock:
        @property
        def headers(self):
            return 'foo: bar\nbar: foo'
    mock = Mock()
    mock.get_headers = gen_get_headers
    stream = RawStream(msg=mock)
    assert str(stream) == "<RawStream obj of Mock msg>"
    assert list(stream) == [
        b'1',
        b'2',
        b'\r\n\r\n'
    ]
    stream.with_headers = False
    assert list(stream) == [
        b'\r\n\r\n'
    ]
    stream.with_body = False
    assert list(stream) == []
    stream.with_body = True

# Generated at 2022-06-12 00:06:55.346209
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import re
    import textwrap

    # convert_data() returns a tuple (mime, body)
    def convert_data(content, mime):
        return mime, content

    formatting = Formatting(
        color_scheme_name='test',
        syntax=None,
        plain=None,
        style=None,
        styles=None,
        # Python 3.5 doesn't allow unicode indentation
        indent_string=re.sub(r'^u', '', str(textwrap.indent('', '    '))),
        max_linewidth=0,
        line_prefix=None,
    )
    conversion = Conversion(
        convert_data=convert_data,
        pager=None,
        stdout_isatty=True,
    )

    # Testing content, mime, output

# Generated at 2022-06-12 00:07:03.410111
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    test_conversion = Conversion()
    test_formatting = Formatting()
    test_output_code = 'gb2312'
    test_msg = HTTPMessage()
    test_msg.headers = 'headers'