

# Generated at 2022-06-11 23:58:59.788274
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    assert True


# Generated at 2022-06-11 23:59:02.545832
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream
    environment = Environment()
    encodedStream = EncodedStream(msg = None, env = environment)

# Generated at 2022-06-11 23:59:08.942121
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    def toBytes(s):
        return bytes(s, 'utf8')
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.body = toBytes('привет')
    msg.headers = '\r\n'
    s = EncodedStream(msg=msg)
    msgData = toBytes('привет')
    iterBodyData = [toBytes(x) for x in s.iter_body()]
    assert(msgData in iterBodyData)

# Generated at 2022-06-11 23:59:10.960365
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    s = RawStream(HTTPMessage())
    assert s.iter_body() is not None


# Generated at 2022-06-11 23:59:21.023614
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # prepare test data
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.10.0 (Ubuntu)
Date: Mon, 15 May 2017 10:00:01 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 81
Connection: keep-alive
X-Powered-By: Express
Etag: W/"51-uHGH2dWy9Xzv4JYmn4ghY4e8gw"
Via: 1.1 vegur

'''

# Generated at 2022-06-11 23:59:22.220270
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = PrettyStream.get_headers()
    assert headers
    return headers

# Generated at 2022-06-11 23:59:27.622572
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    message = b'abcdefg'
    msg = HTTPMessage(body=message)
    env = Environment()
    es = EncodedStream(msg=msg,

                       on_body_chunk_downloaded=None,
                       env=env,
                       with_headers=True,
                       with_body=True)
    assert es.msg==msg
    assert es.on_body_chunk_downloaded is None
    assert es.env==env
    assert es.with_headers==True
    assert es.with_body==True



# Generated at 2022-06-11 23:59:32.603925
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import os
    import tempfile
    path = "./1.txt"
    f = open(path, 'wb')
    for i in range(0, 1024 * 1000, 100):
        f.write(bytes(i))
    f.close()
    msg = HTTPMessage(open(path, 'rb'))
    stream = RawStream(msg)
    for chunk in stream.iter_body():
        print(len(chunk))


# Generated at 2022-06-11 23:59:34.428375
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """
    Method test_BufferedPrettyStream_iter_body()
    """

# Generated at 2022-06-11 23:59:43.957263
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from io import BytesIO
    from httpie.output.streams import PrettyStream
    from httpie.models import Response
    from httpie.plugins import plugin_manager

    body = b'''{ "a": 1, "b": true, "c": [] }'''
    response = Response(
        request=None,
        original_url='https://example.org',
        method='GET',
        status_code=200,
        headers=None,
        body=BytesIO(body),
    )

    plugin_manager.load_internal_plugins()
    plugin_manager.load_installed_plugins()
    conversion = Conversion(
        preserve_formats={},
        preserve_all_formats=False,
        preferred_format='json',
    )

# Generated at 2022-06-12 00:00:02.257795
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    #
    # Unit test for method iter_body of class EncodedStream,
    # using test body with CR and LF.
    #
    environment = Environment()
    environment.stdout_encoding = "utf8"
    body = """This is a test of a text body.
This is line two.
This is line three."""
    http_message = HTTPMessage(headers={"Content-Type": "text/plain"},
                               body=body)
    encoded_stream = EncodedStream(env=environment, msg=http_message)
    output_string = ""
    for line in encoded_stream.iter_body():
        output_string = output_string + line.decode("utf8")
    if (output_string != body):
        return False
    #
    # Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-12 00:00:09.552777
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    print("test_BaseStream___iter__")
    s = BaseStream(msg=None, with_headers=None, with_body=None, on_body_chunk_downloaded=None)
    print(s.__iter__())
    # print(s.__iter__())

test_BaseStream___iter__()

test_RawStream___iter__()

test_EncodedStream___iter__()

test_PrettyStream___iter__()

test_BufferedPrettyStream___iter__()

# Generated at 2022-06-12 00:00:15.950138
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.utils import write_bytes

    request = HTTPRequest(
        method='GET',
        url='http://httpbin.org/',
        headers={'h': 'header'},
        body='Body'
    )
    for stream_cls in [RawStream, EncodedStream]:
        stream = stream_cls(msg=request)
        output = write_bytes(stream, treat_body_as_binary=True)
        assert output == b'GET / HTTP/1.1\r\nh: header\r\n\r\nBody'

# Generated at 2022-06-12 00:00:22.796805
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class BufferHttpMessage(HTTPMessage):
        def __init__(self, encoding, body):
            self.encoding = encoding
            self.enable_chunked_encoding = False
            self.body = body
        def iter_body(self, chunk_size):
            for i in range(0, len(self.body), chunk_size):
                yield self.body[i:i+chunk_size]

    # test: not convert, body is not binary
    http_msg = BufferHttpMessage('utf8', b'hello world')
    buffered_pretry_stream = BufferedPrettyStream(
        msg=http_msg,
        conversion=Conversion(),
        formatting=Formatting(indent_size=3, indent_char='>'),
        with_headers=True,
        with_body=True)
   

# Generated at 2022-06-12 00:00:33.309646
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():

    class Msg:
        headers = {}
        body = None
        encoding = 'utf-8'

        def __init__(self, encoding, body):
            self.encoding = encoding
            self.body = body

    # Test case 1:
    #   <encoding>  = 'utf-8'
    #   <message-body>  = ' '
    #   <output>   = b' '
    msg = Msg(encoding='utf-8', body=' ')
    es = EncodedStream(msg=msg)
    assert (list(es.iter_body()) == [b' '])

    # Test case 2:
    #   <encoding>  = 'utf-8', 'utf-16'
    #   <message-body>  = 'a'
    #   <output>   = b'

# Generated at 2022-06-12 00:00:35.145623
# Unit test for constructor of class RawStream
def test_RawStream():
    print("we are in unittest")
    rawStream = RawStream()
    return rawStream


# Generated at 2022-06-12 00:00:43.468357
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.compat import is_py26

    def mock_iter_body(chunk_size=1):
        yield b''

    msg = HTTPResponse(headers={}, content=b'',
                       raw=b'HTTP/1.1 200 OK\r\n\r\n',
                       iter_body=mock_iter_body)
    stream = BufferedPrettyStream(msg=msg,
                                  conversion=None,
                                  formatting=None)
    if is_py26:
        body = ''.encode()
    else:
        body = b''

    assert next(iter(stream)) == body

# Generated at 2022-06-12 00:00:51.625737
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Example output message
    msg = ("HTTP/1.1 200 OK \r\n" +
        "Server: nginx\r\n" +
        "Date: Tue, 24 Apr 2018 01:14:07 GMT\r\n" +
        "Content-Type: text/html\r\n" +
        "Transfer-Encoding: chunked\r\n" +
        "Connection: keep-alive\r\n" +
        "X-Powered-By: PHP/5.6.33"
    )

    stream = EncodedStream(msg)

    assert stream.output_encoding == "utf8"


# Generated at 2022-06-12 00:00:55.024838
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    pretty_stream_obj=PrettyStream({}, conversion, formatting)
    if pretty_stream_obj:
        print("Test Passed")
    else:
        print("Test Failed")


# Generated at 2022-06-12 00:01:04.849589
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """test the prettify function, the function will return the whole HTTP body content
    when the HTTP request is ok, and then return a binary warning when the body is binary.
    """
    import requests

    r = requests.get('https://httpbin.org/user-agent')

    bps = BufferedPrettyStream(r)

    body = [i for i in bps.iter_body()]
    assert body[0] == b'{\n  "user-agent": "python-requests/2.22.0"\n}\n'

    r = requests.get('https://httpbin.org/image/png')

    bps = BufferedPrettyStream(r)

    body = [i for i in bps.iter_body()]

# Generated at 2022-06-12 00:01:32.815058
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    headers = Headers()
    headers.add('Content-Type', 'application/json')

    stream = PrettyStream(
        conversion=Conversion(converters=[]),
        formatting=Formatting(
            colors=False,
            headers=True,
            ssl=False,
            verbose=False,
        ),
        msg=HTTPMessage(
            method='GET',
            scheme='http',
            host='httpbin.org',
            path='/get',
            headers=headers,
        ),
        on_body_chunk_downloaded=None,
    )

    stream.get_headers()
    assert stream.get_headers()==b'Content-Type: application/json\r\n'



# Generated at 2022-06-12 00:01:39.315671
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # arrange
    expectedBody = b'{ "foo": "bar" }'
    response = Mock()
    response.content_type = 'application/json'
    response._orig_body = expectedBody
    stream = BufferedPrettyStream(
        msg=response, 
        with_headers=False, 
        with_body=True
    )
    actualBody = b''
    # act
    for chunk in stream.iter_body():
        actualBody += chunk
    # assert
    ok_(actualBody == expectedBody)


# Generated at 2022-06-12 00:01:50.101016
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # If the user is using UTF-8 encoding, then that encoding is used
    # by default
    stream = EncodedStream(msg={'encoding':'utf8', 'headers':'headers'})
    assert(stream.output_encoding == 'utf8')
    # If Output is a terminal, then use the stdout encoding, which is
    # UTF-8 by default
    stream = EncodedStream(msg={'encoding':'utf8', 'headers':'headers'},
                           env={'stdout_isatty':True, 'stdout_encoding':'utf8'})
    assert(stream.output_encoding == 'utf8')
    # Otherwise, if the output encoding is not specified, then UTF-8 is used

# Generated at 2022-06-12 00:01:56.111115
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    class Conversion:
       def get_converter(self, mime):
           return None

    class Formatting:
       def format_body(self, content, mime):
           return content

    class TestMessage:
       def __init__(self, body):
           self.body = body
           self.content_type = 'content/type'
       def iter_body(self, chunk_size=1):
           return iter(self.body)

    tm = TestMessage(b'abc\n123\n\0')
    ps = BufferedPrettyStream(conversion=Conversion(), msg=tm,
                              formatting=Formatting())
    assert list(ps.iter_body()) == [b'abc\n123\n\0']



# Generated at 2022-06-12 00:02:01.879700
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = "a:b\r\nc:d\r\ne:f\r\n\r\n"
    msg = HTTPMessage(headers)
    ps = PrettyStream(msg, conversion=None, formatting=None)
    # headers are in bytes already. If not,
    # the test would check self.output_encoding
    assert ps.get_headers() == headers.encode('utf8')

# Generated at 2022-06-12 00:02:03.823186
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    p = PrettyStream(None, None, None)
    result = [b for i in p.iter_body() for b in i]
    assert result == [b'\r\n']

# Generated at 2022-06-12 00:02:14.014845
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    """The __iter__ method is a generator that yields the parts of
    a message as bytes.

    The headers are yielded as-is, then \r\n\r\n, and then the body.


    """
    headers = b'HTTP/1.1 200 OK\r\nFoo: bar\r\n\r\n'
    body = b'body-1\r\nbody-2'
    msg = HTTPMessage(
        headers + body,
        {},
        None,
    )
    chunk_size = len(body) // 2
    # with_headers, with_body
    stream = RawStream(msg, True, True, chunk_size=chunk_size)

# Generated at 2022-06-12 00:02:16.941020
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    msg = HTTPMessage('POST', 'localhost')
    x = EncodedStream(msg, env)
    print(x.msg)

# Generated at 2022-06-12 00:02:21.211516
# Unit test for constructor of class RawStream
def test_RawStream():
    kwargs = {
        "msg": HTTPMessage(),
        "with_headers": True,
        "with_body": True,
        "on_body_chunk_downloaded": None
    }
    rs = RawStream(**kwargs)


# Generated at 2022-06-12 00:02:33.066165
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Taken from test_formatting.py
    # https://github.com/jakubroztocil/httpie/blob/8f3beac3bed3d3b0ba149f47cb9c57d1d25e95b6/tests/plugins/test_formatting.py#L44
    # some string with non-ascii characters and spaces.
    body = u'Háčky či čárky      a á    i ď ě ň ř ť  ů ú'.encode('utf8')
    stream = PrettyStream(msg=None, conversion=None, formatting=Formatting(),
                          on_body_chunk_downloaded=None, with_body=True,
                          with_headers=True)
    output = stream.process_body(body)


# Generated at 2022-06-12 00:03:14.339104
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import collections
    msg = HTTPMessage(
        headers={"key": "val"},
        encoding="utf8",
    )
    str(BaseStream(msg))
    res = collections.deque(BaseStream(msg))
    assert len(res) == len(b"key: val\r\n") + len(b"\r\n\r\n")



# Generated at 2022-06-12 00:03:22.656977
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # trying everything with single line
    msg = HTTPMessage(b'12345\r\n')
    msg.encoding = 'utf8'

    pretty_msg = PrettyStream(msg, 'pretty', 'pretty')
    # test format_body() method, with new line
    assert pretty_msg.process_body('1234') == '1234\r\n'
    # test format_body() method with new line
    assert pretty_msg.process_body('1234\n') == '1234\r\n\r\n'
    # test get_headers() method
    assert pretty_msg.get_headers() == b'12345\r\n'

    # test iter_body() in class PrettyStream
    for bytes in pretty_msg.iter_body():
        assert bytes == '1234'

    raw = Raw

# Generated at 2022-06-12 00:03:32.935724
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()

# Generated at 2022-06-12 00:03:41.203201
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import unittest
    from httpie.models import HTTPResponse
    from io import BytesIO
    from httpie.output.streams import EncodedStream
    class TestEncodedStream(unittest.TestCase):
        def setUp(self):
            self.encoded_stream = EncodedStream(msg=HTTPResponse(headers=b'', body=BytesIO(b'\x80\x00\x00\x00\x00\x00\x00\x00')))
        def test_iter_body(self):
            self.assertRaises(BinarySuppressedError, lambda: list(self.encoded_stream.iter_body()))
    unittest.main()
    # self.assertEqual(self.encoded_stream.iter_body(), list(self.encoded_stream

# Generated at 2022-06-12 00:03:42.075264
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass



# Generated at 2022-06-12 00:03:44.171549
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    stream = PrettyStream(with_headers=True, with_body=True, msg=None)
    assert stream.get_headers() == None

# Generated at 2022-06-12 00:03:53.490175
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    assert list(BufferedPrettyStream(HTTPMessage(b'\xff'),
            conversion=Conversion(),
            formatting=Formatting()).iter_body()) == [BINARY_SUPPRESSED_NOTICE]
    # successfully convert binary data to json
    assert list(BufferedPrettyStream(HTTPMessage(b'\x7b\x22f\x22\x3a\x22\x22\x7d'),
            conversion=Conversion(),
            formatting=Formatting()).iter_body()) == [b'{\n    "f": ""\n}']
    # json conversion failed
    assert list(BufferedPrettyStream(HTTPMessage(b'a'),
            conversion=Conversion(),
            formatting=Formatting()).iter_body()) == [b'a']

# Generated at 2022-06-12 00:04:00.176051
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    m = b'1'*1024*2 + b'2'*1024*2 + b'3'
    s = RawStream(None, False, False)
    s.CHUNK_SIZE = 1024 * 1
    l = [i for i in s.iter_body()]

    assert len(l) == 3
    assert l[0] == b'1'*1024*1
    assert l[1] == b'1'*1024*1 + b'2'*1024*1
    assert l[2] == b'2'*1024*1 + b'3'

# Generated at 2022-06-12 00:04:09.613327
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage('fwew')
    rawstream = RawStream(msg)
    assert msg == rawstream.msg
    assert rawstream.with_headers
    assert rawstream.with_body
    assert rawstream.on_body_chunk_downloaded is None
    assert rawstream.chunk_size == 102400

    msg = HTTPMessage('fwew')
    rawstream = RawStream(msg, with_headers=False)
    assert rawstream.with_body
    assert not rawstream.with_headers

    msg = HTTPMessage('fwew')
    rawstream = RawStream(msg, with_body=False, chunk_size=10000)
    assert not rawstream.with_body
    assert rawstream.with_headers
    assert rawstream.chunk_size == 10000


# Generated at 2022-06-12 00:04:16.545506
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest

    request = HTTPRequest(method="GET", url="", headers={}, body="")
    stream = BaseStream(msg=request, with_body=False)
    assert list(stream) == [b"GET / HTTP/1.1\r\n"]

    request = HTTPRequest(method="GET", url="", headers={}, body="")
    stream = BaseStream(msg=request, with_headers=False)
    assert list(stream) == [b"\r\n\r\n"]



# Generated at 2022-06-12 00:05:37.114379
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Build a msg
    response_status_line = b'HTTP/1.1 200 OK\r\n'
    content_type = 'application/json'
    headers = b'Content-Type: application/json\r\n'
    body = b'{"name": "httpie"}'

    msg = HTTPMessage(headers, body, 'utf8')
    msg.status_line = response_status_line

    # Create the stream
    stream = BufferedPrettyStream(msg, with_headers=True, with_body=True)
    response = b''.join(stream.iter_body())

    # Check the stream
    assert response.startswith(response_status_line)
    assert response.endswith(body + b'\r\n')

# Generated at 2022-06-12 00:05:46.042193
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    hdr = 'HTTP/1.1 200 OK\nContent-type: text/plain\n\n'
    msg = HTTPMessage(hdr + '1234567890\n').with_content_length()
    stream = PrettyStream(msg, conversion=None, formatting=None)
    assert list(stream.iter_body()) == ['1234567890\n']

    msg = HTTPMessage(hdr + '1234567890\n').with_content_length()
    msg.encoding = 'latin1'
    stream = PrettyStream(msg, conversion=None, formatting=None)
    with pytest.raises(UnicodeEncodeError):
        assert list(stream.iter_body())

    msg = HTTPMessage(hdr + '1234567890\n').with_content_length()
   

# Generated at 2022-06-12 00:05:56.078458
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage('GET /api/foo HTTP/1.1\r\n'
                      'User-Agent: HTTPie/0.9.9\r\n'
                      'Accept-Encoding: gzip, deflate\r\n'
                      'Accept: */*\r\n'
                      'Host: localhost:5000\r\n'
                      'Connection: keep-alive\r\n\r\n')
    msg.headers._encoding = 'iso8859-1'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    with mock.patch('builtins.open', mock.mock_open()) as f:
        f.return_value.isatty.return_value = True
        conversion = Conversion()


# Generated at 2022-06-12 00:05:58.858463
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    message = b"Hello\nworld"
    stream = EncodedStream(None, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [message.decode('utf-8')]

# Generated at 2022-06-12 00:06:08.447868
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Given
    test_input = b'{"username":"test","password":"test"}'
    test_msg = HTTPMessage(headers='', content=test_input)
    test_enc = 'utf8'
    test_env = Environment(
        stdout_isatty=True,
        stdout_encoding='utf8',
    )
    test_conversion = Conversion('')
    test_formatting = Formatting('')

    # When
    test_stream = PrettyStream(
        msg=test_msg,
        encoding=test_enc,
        env=test_env,
        conversion=test_conversion,
        formatting=test_formatting,
    )

    # Then
    assert b'\n' == next(test_stream.iter_body())



# Generated at 2022-06-12 00:06:14.636619
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    """Testing method get_headers"""

    # Case1:
    print('Case1:')
    msg = HTTPMessage()
    msg.headers = ''
    output_encoding = 'utf-8'
    formatting = Formatting()
    conversion = Conversion()
    test = PrettyStream(msg=msg, conversion=conversion, formatting=formatting, output_encoding=output_encoding)
    for chunk in test.iter_body():
        print(chunk)
        if test.on_body_chunk_downloaded:
            test.on_body_chunk_downloaded(chunk)

    # Case2:
    print('Case2:')
    msg = HTTPMessage()
    msg.headers = 'get:post'
    output_encoding = 'utf-8'
    formatting = Formatting()
   

# Generated at 2022-06-12 00:06:18.865787
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None)
    stream.formatting = Formatting(False)
    stream.conversion = Conversion()
    stream.mime = "text/plain"
    print(stream.process_body("This is a test".encode(stream.output_encoding)))
    print(stream.process_body("This is a test"))

# Generated at 2022-06-12 00:06:22.813968
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage('message', 'utf8', 'plain/text', 'test\ncontent')
    stream = EncodedStream(msg, True, True)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True



# Generated at 2022-06-12 00:06:26.265110
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding is msg.encoding

# Generated at 2022-06-12 00:06:36.181902
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class MockEncodedStream(EncodedStream):
        def get_headers(self):
            return b'a: a\r\nb: b\r\n\r\n'

    class TestMockEncodedStream(unittest.TestCase):

        def test_iter_body(self):
            e_stream = MockEncodedStream(
                HTTPMessage('test\r\nresponse\r\nwith\r\nLF\r\n'),
                msg_type='test')
            self.assertEqual(
                list(e_stream.iter_body()),
                [b'test', b'with', b'response', b'LF'])