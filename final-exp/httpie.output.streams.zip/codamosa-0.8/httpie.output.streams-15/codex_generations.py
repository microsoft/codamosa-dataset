

# Generated at 2022-06-11 23:58:47.566367
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
	PrettyStream()
	return


# Generated at 2022-06-11 23:58:50.805796
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.output.streams import EncodedStream
    data = b'foo'
    e = EncodedStream(data)
    if e.output_encoding is None:
        assert e.output_encoding == 'utf8'
    else:
        assert True



# Generated at 2022-06-11 23:58:56.980573
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie import ExitStatus
    from httpie.cli import get_request
    from httpie.input import ParseError
    from httpie.context import Environment
    from httpie.compat import is_windows
    env = Environment()
    stdin = sys.stdin.buffer
    if not is_windows:
        stdin = os.fdopen(os.dup(sys.stdin.fileno()), 'rb', 0)
    request = get_request(env, stdin, 'http://example.com/')

# Generated at 2022-06-11 23:59:04.596618
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Create an instance of class PrettyStream
    PrettyStream_instance = PrettyStream(
        msg=HTTPMessage(headers=dict(a="b\r\nContent-Type: text/html\r\nc: d"),
                        content_type="text/html; charset=UTF-8",
                        encoding="UTF-8"),
        with_headers=True,
        with_body=True)

    # Call the method get_headers of class PrettyStream
    get_headers_result = PrettyStream_instance.get_headers()

    print(get_headers_result)

# Generated at 2022-06-11 23:59:12.728358
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    print("===== test_PrettyStream =====")
    env = Environment()
    msg = env.msg
    msg.append_body('hello')
    msg.append_body('world')
    msg.content_type = None

    conversion = Conversion(None, sys.stdout.isatty())
    formatting = Formatting(None, sys.stdout.isatty())

    print('------ 1) msg is an instance of HTTPMessage')
    ps1 = PrettyStream(conversion, formatting, msg=msg)
    for line in ps1:
        print('------')
        print(line)

    print('------ 2) msg is an instance of BinaryResponse')

# Generated at 2022-06-11 23:59:22.133447
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # TODO: write more tests
    # TODO: make this test run
    text = "Hello, World!"
    headers = b'HTTP/1.1 200 OK\r\n' + b'Content-Type: text/plain; charset=utf8\r\n' + b'Content-Length: ' + \
              str(len(text)).encode() + b'\r\n\r\n'
    stream = EncodedStream(
        Environment()
    )
    assert stream.output_encoding == 'utf8'
    # source: https://stackoverflow.com/questions/491921/unicode-utf-8-reading-and-writing-to-files-in-python

# Generated at 2022-06-11 23:59:29.826972
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    def bytes_list(list):
        return [item.encode('utf-8') + b'\r\n' for item in list]

    stream = EncodedStream(msg=HTTPMessage(
        headers=u'Content-Type: text/tab-separated-values; charset=utf-8',
        body=u'1\t2\t3',
    ))
    for i, chunk in enumerate(stream.iter_body()):
        assert chunk == bytes_list([u'1\t2\t3'])[i]

    stream = EncodedStream(msg=HTTPMessage(
        headers=u'Content-Type: text/tab-separated-values; charset=utf-8',
        body=b'\x80\x81\x82',
    ))

# Generated at 2022-06-11 23:59:41.238887
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.constants import DEFAULT_FORMAT
    from httpie.models import Response
    from httpie.input import ParseRequest
    from httpie.output.streams import PrettyStream
    request_parser = ParseRequest()

    headers = [
        'HTTP/1.1 200 OK',
        'Content-Type: application/json'
    ]
    body = [
        '{"message": "hello"}',
        ''
    ]

    url = 'https://httpbin.org/get'
    request = request_parser.parse_get_request(url)
    response = Response(request)
    response.http_version = request.http_version
    response.headers = '\r\n'.join(headers)
    response.status_code = '200'
    response.status_line = 'OK'

    history

# Generated at 2022-06-11 23:59:52.471111
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    print("\n\ntest_RawStream_iter_body:")
    # Setup a RawStream
    msg = HTTPMessage()
    msg.encoding = "utf8"
    msg.headers = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n"
    msg.body = BytesIO(b"Line 1\nLine 2\nLine 3")
    stream = RawStream(msg)

    # Ensure RawStream.iter_body returns its body as a generator of bytes
    for line_num, line in enumerate(stream.iter_body(), start=1):
        print("Line {}:".format(line_num), line)
        assert line == b"Line " + str(line_num).encode() + b"\n"


# Generated at 2022-06-12 00:00:01.682131
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import os
    import shelve
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from pytest import raises

    def get_response(file_name: str) -> HTTPResponse:
        file_path = os.path.join('tests/data', file_name)
        with open(file_path, 'rb') as f:
            headers_str, body = f.read().split(b'\r\n\r\n', 1)
        return HTTPResponse(http_version='1.1',
                            status_code=200,
                            headers=headers_str.decode('utf-8'),
                            body=body)

    response = get_response('headers-and-body-with-utf8-bom.bin')
   

# Generated at 2022-06-12 00:00:15.388850
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    pass


# Generated at 2022-06-12 00:00:22.457078
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # code
    import __main__ as main
    import pkgutil
    loader = pkgutil.get_loader('httpie')
    exec(loader.get_source('httpie.models'), main.__dict__)
    exec(loader.get_source('httpie.env'), main.__dict__)
    exec(loader.get_source('httpie.output.streams'), main.__dict__)

    # test - default value
    env = Environment()
    msg = HTTPMessag()
    msg.headers = ""
    es = EncodedStream(msg, env)
    assert es.msg.encoding == 'utf8'

    # test - stdout user defined value
    env = Environment()
    env.stdout_encoding = 'test'
    msg = HTTPMessag()

# Generated at 2022-06-12 00:00:26.126794
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.content_type = 'text/plain'
    msg.encoding = 'utf8'
    stream = EncodedStream(msg=msg)
    assert b'text/plain' == stream.msg.content_type.split(';')[0]

# Generated at 2022-06-12 00:00:30.350174
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(url="http://www.baidu.com")
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    assert EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded)

# Generated at 2022-06-12 00:00:41.332266
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import RawRequest, RawResponse
    from httpie.utils import get_binary_stream
    # Test with RawRequest class
    msg = RawRequest(method='POST', url='http://example.com', headers={'foo':'bar'}, data='data')
    stream = RawStream(msg)
    expected_gen = iter(['data'])
    assert stream.iter_body() == expected_gen
    # Test with RawRequest class and message binary content
    msg = RawRequest(method='POST', url='http://example.com', headers={'foo':'bar'}, data='data')
    stream = RawStream(msg)
    assert stream.iter_body() == 'data'
    # Test with RawResponse class
    msg = RawResponse(status_code=200, headers={'foo':'bar'}, content='data')

# Generated at 2022-06-12 00:00:52.072724
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class CustomStream(PrettyStream):
        pass

    stream = CustomStream(HTTPMessage(), Conversion(None), Formatting())
    body = [b'123', b'456']
    stream.msg.body = body
    stream.msg.streaming = False

    class DummyConverter:
        @staticmethod
        def convert(data):
            return data, 'text/html'

    stream.conversion = Conversion(DummyConverter())
    stream.formatting = Formatting(None, 'html')
    expected = [
        ''.encode(stream.output_encoding, 'replace') + b'\n',
    ]
    assert list(stream.iter_body()) == expected

    stream.msg.streaming = True

# Generated at 2022-06-12 00:00:55.616300
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    v = BufferedPrettyStream(formatting = Formatting(None, None, None),
                             conversion = Conversion(None, None, None),
                             with_headers = True, with_body = True)

# Generated at 2022-06-12 00:00:56.241718
# Unit test for constructor of class RawStream
def test_RawStream():
    pass

# Generated at 2022-06-12 00:01:05.706906
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    del BINARY_SUPPRESSED_NOTICE
    import io
    import sys
    from httpie.models import httpmessage

    for i in range(3):
        print(i, '==============================================================')
        # Set up.
        msg = httpmessage.HTTPMessage('utf8', {}, io.BytesIO())
        strm = EncodedStream(msg)
        # Test.
        # print(type(strm.iter_body()), strm.iter_body())
        # print(type(strm.iter_body()[0]), strm.iter_body()[0])

        # if this assertion fails, then UnicodeEncodeError is not
        # caught.

# Generated at 2022-06-12 00:01:16.038410
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    env = Environment(headers=('a:b', 'c:d'))
    with pytest.raises(AssertionError):
        PrettyStream(HTTPMessage(), with_headers=False, with_body=False)
    with pytest.raises(AssertionError):
        PrettyStream(HTTPMessage(), with_headers=False, with_body=False, env=env)
    with pytest.raises(AssertionError):
        PrettyStream(HTTPMessage(), with_headers=False, with_body=False, conversion=Conversion(), formatting=Formatting())

# Generated at 2022-06-12 00:01:36.754164
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    #
    # BaseStream.__init__
    #
    msg = HTTPMessage()
    with_headers = True
    with_body=True
    on_body_chunk_downloaded = None
    base_stream = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    assert base_stream.msg == msg
    assert base_stream.with_headers == with_headers
    assert base_stream.with_body == with_body
    assert base_stream.on_body_chunk_downloaded == on_body_chunk_downloaded
    #
    # BaseStream.get_headers
    #
    assert base_stream.get_headers() == msg.headers.encode('utf8')
    #
    # BaseStream.__iter__
    #

# Generated at 2022-06-12 00:01:47.427476
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(headers={'content-type': ''},
                      encoding='utf8',
                      body=b'{"args": "a=1&b=2", "headers": {"Accept": "*/*", '
                           b'"User-Agent": "HTTPie/0.9.9", "Connection": "close"}}')

    stream = PrettyStream(msg=msg,
                          conversion='none',
                          formatting='colors',
                          with_headers=False,
                          with_body=True)


# Generated at 2022-06-12 00:01:54.048691
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()
    # This is a test for when the message body is your binary
    assert 'iter_body' in BufferedPrettyStream.__dict__
    assert isinstance(BufferedPrettyStream.__dict__['iter_body'], types.FunctionType)
    body_bytes =  BufferedPrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    ).iter_body()
    
    #print(body_bytes)
    assert isinstance(body_bytes, types.GeneratorType)

# Generated at 2022-06-12 00:02:03.917870
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.input import ParseError
    from httpie.models import Close
    from httpie.compat import is_py26
    from httpie.input import ParseError
    from httpie.models import Close
    from httpie.compat import is_py26
    def test_BaseStream___iter__():
        from httpie.input import ParseError
        from httpie.models import Close
        from httpie.compat import is_py26
        def test_BaseStream___iter__():
            from httpie.input import ParseError
            from httpie.models import Close
            from httpie.compat import is_py26
            def test_BaseStream___iter__():
                from httpie.input import ParseError
                from httpie.models import Close
                from httpie.compat import is_py26
               

# Generated at 2022-06-12 00:02:05.643997
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    prettyStream = PrettyStream(body='mock_body')
    prettyStream.process_body('mock_body')

# Generated at 2022-06-12 00:02:13.715253
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    filename = '/Users/cjq/Desktop/httpie-master/httpie/output/streams.py'
    msg = HTTPMessage('GET / HTTP/1.1', {
        'Host': 'example.org',
        'Content-Type': 'text/plain',
        'Accept': '*/**',
        'Accept-Encoding': 'gzip, deflate',
    }, open(filename, 'rb'), content_type='text/plain')
    rs = RawStream(msg, with_body=True)
    for line in rs.iter_body():
        print(line)



# Generated at 2022-06-12 00:02:26.301262
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    def test(with_headers, with_body, body_value, expected):
        stream = BaseStream(
            msg.copy(),
            with_headers=with_headers,
            with_body=with_body
        )
        msg.body = body_value
        assert "".join(stream) == expected

    msg = HTTPMessage(
        Message(
            {
                'headers': Headers([(b'content-type', b'text/plain')]),
                'http_version': (1, 1),
                'status_code': 200
            }
        )
    )
    msg.body = b'response body'

    test(True, True, b'response body', b'content-type: text/plain\r\n\r\nresponse body')

# Generated at 2022-06-12 00:02:33.151036
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    c = Conversion()
    f = Formatting()
    m = HTTPMessage()
    with_headers = True
    with_body = True
    b = BufferedPrettyStream(msg=m, conversion=c, formatting=f, with_headers=with_headers, with_body=with_body)
    assert b.msg == m
    assert b.conversion == c
    assert b.formatting == f
    assert b.with_headers == with_headers
    assert b.with_body == with_body


# Generated at 2022-06-12 00:02:38.216465
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    es = EncodedStream(msg=bytes(b'a\x00\x01\nq'))
    try:
        for line in es.iter_body():
            if line[1] == b'\0':
                assert line == b'Binary data not shown in the terminal'
    except BinarySuppressedError:
        pass

# Generated at 2022-06-12 00:02:41.418481
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage('test')
    msg.headers['test'] = 'test'
    msg.headers['test2'] = 'test'
    assert PrettyStream(msg, with_headers=True, with_body=False).get_headers() == b'  test:\t\ttest\ntest2:\t\ttest\n'
    

# Generated at 2022-06-12 00:03:04.519717
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pass


# Generated at 2022-06-12 00:03:11.924431
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    res = HTTPMessage()

    # case1: msg with no body
    case1 = EncodedStream(msg=res)
    assert len(list(case1.iter_body())) == 0

    # case2: msg with body
    num_of_chunk = 1
    case2 = EncodedStream(msg=res)
    expected_chunk = '\r\n'.encode()
    expected_chunks = [expected_chunk for _ in range(num_of_chunk)]
    for i in range(num_of_chunk):
        res.body = str(i)
        chunks = list(case2.iter_body())
    assert chunks == expected_chunks

# Generated at 2022-06-12 00:03:13.968140
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    s = RawStream(None)
    assert s._RawStream__iter_body() == None



# Generated at 2022-06-12 00:03:19.513138
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import httpie.models
    msg = httpie.models.HTTPMessage()
    msg.headers = "Content-Type: text/html"
    msg.content = b"0123456789"
    msg.status = "HTTP/1.1 200 OK";
    
    stream = BufferedPrettyStream(msg, False, True)
    assert(b"0123456789" == next(stream.iter_body()))


# Generated at 2022-06-12 00:03:22.945546
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    response = HTTPResponse(b'abcd')
    result = BaseStream(response, with_headers=True, with_body=True)
    assert result.__iter__() is None

# Generated at 2022-06-12 00:03:25.505450
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    s = EncodedStream(msg=HTTPMessage(content='a\nb\nc\nd'))
    print(list(s.iter_body()))


# Generated at 2022-06-12 00:03:30.115251
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    msg.headers = 'test_headers\n'
    msg.body = '''test
test1
test2
test3'''

    stream = RawStream(msg)
    list_body = [i for i in stream.iter_body()]
    assert len(list_body) == 3


# Generated at 2022-06-12 00:03:35.752715
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Setup the class to test
    env = Environment()
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    cls = PrettyStream(
        msg = msg,
        env = env,
        conversion = conversion,
        formatting = formatting,
    )

    # Assertion
    expected = bytearray()
    assert cls.get_headers() == expected



# Generated at 2022-06-12 00:03:42.612509
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import RawStream
    env = Environment()
    headers = '''{
            "Content-Type": "application/json",
            "Accept": "text/plain, */json",
            "Accept-Encoding": "gzip",
            "HTTP_USER_AGENT": "HTTPie/0.9.2"
        }'''
    body = """[
          {
            "rendered": "Hi",
            "score": 10
          }
        ]"""
    msg = HTTPRequest(
        method='GET',
        url='https://api.github.com/search/users?q=john',
        headers=headers,
        data=body
        )
    conversion = Conversion()
    formatting = Format

# Generated at 2022-06-12 00:03:48.995034
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    response = HTTPMessage()
    response.headers = {'Content-Type', 'application/javascript'}
    response.encoding = 'utf8'
    response.content_type = 'application/javascript'
    bufferedPrettyStream = BufferedPrettyStream(response, True, True)
    assert bufferedPrettyStream.mime == 'application/javascript'

# Generated at 2022-06-12 00:04:40.460969
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # This function tests only if the body is not binary
    # (it does not check how the body is then processed)

    env = Environment()
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8'
    msg.body = 'Hello World !\n'

    stream = BufferedPrettyStream(msg, env=env, \
    with_headers=False, with_body=True, on_body_chunk_downloaded=None)

    for chunk in stream.iter_body():
        assert isinstance(chunk, bytes)



# Generated at 2022-06-12 00:04:52.373997
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():

    class Message(HTTPMessage):
        content_type = 'application/json'

    import json
    string = '{"canary":{"total":1,"health":"healthy","last_check":"2018-08-26T19:11:34Z","data_version":1535302694,"id":"health_check","alerts":[]},"len":1}'
    body = bytes(string, 'utf-8')
    headers = 'Content-Type: application/json'
    message = Message(headers=headers, body=body)

    conversion = Conversion()
    formatting = Formatting()
    pretty_stream = PrettyStream(message, True, True, conversion, formatting)
    result = b''.join(iter(pretty_stream))

# Generated at 2022-06-12 00:04:53.261728
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg: HTTPMessage
    RawStream(msg)

# Generated at 2022-06-12 00:05:02.806543
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    print("Test iter_body of class PrettyStream")

    class DummyHTTPMessage(HTTPMessage):
        def body(self):
            return '{"a": 1, "b": 2, "c": 3}'

        def iter_body(self, chunk_size):
            yield self.body()
    
    d = DummyHTTPMessage()
    p = PrettyStream(d, True, True, None)
    p.msg.encoding = 'utf-8'
    p.output_encoding = 'utf-8'
    p.conversion = Conversion('json', 80)
    p.formatting = Formatting()

    res = ''
    for chunk in p.iter_body():
        res += chunk.decode(p.output_encoding)
    
    print("result: " + res)
   

# Generated at 2022-06-12 00:05:10.358027
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    output_encoding = 'utf8'
    encoding = 'utf8'
    line = b'abc'
    lf = b'\n'
    msg = HTTPMessage(headers={}, body=line+lf, encoding=encoding)
    stream = EncodedStream(msg, output_encoding=output_encoding)
    assert not b'\0' in line
    complement = (line + lf).decode(encoding) \
                            .encode(output_encoding, 'replace')
    assert list(stream.iter_body()) == [complement]
    line = b'abc\0def'
    msg = HTTPMessage(headers={}, body=line+lf, encoding=encoding)
    stream = EncodedStream(msg, output_encoding=output_encoding)

# Generated at 2022-06-12 00:05:20.306495
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.compat import BytesIO
    from httpie.models import Response
    from httpie import specs
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream

    response = Response(  # type: Response
        specs.raw.STATUS_LINE,
        specs.raw.HEADERS,
        BytesIO(b'binary\ndata\n'),
        url='http://example.com/'
    )
    # Default setting of PrettyStream
    stream = PrettyStream(
        msg=response,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        env=Environment(),
        conversion=Conversion(),
        formatting=Formatting(indent_size=2),
    )
    # Ex

# Generated at 2022-06-12 00:05:28.495459
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    http_message = HTTPMessage(env)
    http_message.headers = 'Content-Type:text/html;charset=utf-8'
    http_message.charset = 'utf-8'
    http_message.body = 'body'
    http_message.encoding = 'utf8'
    stream = BaseStream(http_message)
    assert iter(stream) == [b'Content-Type:text/html;charset=utf-8\r\n', b'\r\n',b'body']

# Generated at 2022-06-12 00:05:33.286765
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage('GET / HTTP/1.1\r\n\r\n')
    msg.encoding = 'utf-16'
    stream = EncodedStream(msg=msg)
    assert next(iter(stream)) == b'\n'
    assert next(stream.iter_body()) == b'\n'

# Generated at 2022-06-12 00:05:39.743951
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = collections.OrderedDict()
    headers['Accept'] = 'text/html'
    headers['Host'] = 'example.org'
    headers['Test'] = 'test'
    kwargs = {'with_headers': True, 'with_body': True}

    msg = HTTPMessage('test', '', headers=headers, encoding='utf8')
    env = Environment()
    conversion = Conversion()
    formatting = Formatting(env)
    ps = PrettyStream(msg, env=env, conversion=conversion,
                      formatting=formatting, **kwargs)
    assert ps.get_headers() == b'Accept: text/html\r\nHost: example.org\r\nTest: test\r\n\r\n'


if __name__ == '__main__':
    headers = collections.Ordered

# Generated at 2022-06-12 00:05:40.983683
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPRequest
    # HTTPRequest('test http message')



# Generated at 2022-06-12 00:07:18.296749
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class TestMessage():
        def __init__(self):
            self.content_type = "application/json"
            self.encoding = "utf8"
            self.headers = {'transfer-encoding': 'chunked'}
        def iter_lines(self, chunk_size=1):
            yield b'{"message":"some test message"}', b'\n'
            return
        def iter_body(self, chunk_size=1):
            yield b'{"message":"some test message"}'
            return
    conversion = Conversion()
    formatting = Formatting()
    pretty_stream = PrettyStream(conversion=conversion, formatting=formatting, msg=TestMessage())
    body = pretty_stream.process_body(b'{"message":"some test message"}')
    assert isinstance(body, bytes)

# Generated at 2022-06-12 00:07:29.044375
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import pytest
    testfile = "./test_data/testfile"
    msg = HTTPMessage(
        headers={'Content-Type': "text/html; charset=UTF-8"},
        body=open(testfile, 'rb'),
    )
    conversion = Conversion(
        json_indent=None,
        json_sort_keys=False,
        xml_indent=None,
        xml_humanize=False,
        colors=None,
        regex_search=None,
    )
    formatting = Formatting(
        indent=4,
        colors=None,
        default_scheme=None,
        default_scheme_port=None,
        padding=0,
        max_response_length=None,
        max_redirects=None,
        verify=True,
    )
   

# Generated at 2022-06-12 00:07:35.001234
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import os
    import sys

    from httpie.output.processing.formatting.json import JSONFormatter
    from httpie.output.processing.formatting.url import URLFormatter
    from httpie.output.processing.formatting import TextFormatter
    from httpie.output.processing.conversion import XMLtoJSONConverter
    from httpie.output.processing.conversion import URLtoJSONConverter

    msg = HTTPMessage()

    msg.content_type = 'application/json; charset=utf-8'
    msg.encoding = 'utf-8'
    json_formatter = JSONFormatter()
    conversion = Conversion({
        'application/xml': XMLtoJSONConverter()
    })
    # conversion = Conversion({})

# Generated at 2022-06-12 00:07:44.557613
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream
    from httpie.plugins.builtin import HTTPBasicAuth
    import httplib2
    import contextlib
    import io

    @contextlib.contextmanager
    def capture_stdout():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out,

# Generated at 2022-06-12 00:07:46.486972
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    def test_PrettyStream_get_headers():
        stream = PrettyStream(msg='test msg')
        assert stream.get_headers() == 'test headers'

# Generated at 2022-06-12 00:07:57.037928
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage('foo\nbar')

    def check_iter_body_output(msg, output):
        stream = EncodedStream(msg)
        assert list(stream.iter_body()) == output

    check_iter_body_output(msg, [b'foo\nbar'])

    # No UnicodeDecodeError for invalid characters.
    msg = HTTPMessage(b'\xff')
    check_iter_body_output(msg, [b'?'])

    # Binary data is suppressed.
    msg = HTTPMessage(b'\0')
    with pytest.raises(BinarySuppressedError):
        EncodedStream(msg).iter_body()

    # No UnicodeDecodeError for invalid characters.
    msg = HTTPMessage(b'\xff')
    check_iter_body_output

# Generated at 2022-06-12 00:07:58.331543
# Unit test for constructor of class RawStream
def test_RawStream():
    m = RawStream()
    assert m is not None

# Generated at 2022-06-12 00:08:08.352661
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    message = HTTPMessage()
    message.encoding = 'utf8'
    message.headers = 'Content-Type: text/plain; charset=utf-8\n'
    message.headers += 'Content-Length: '
    message.headers += str(len('안녕하세요')) + '\n'
    message.body = '안녕하세요'
    stream = EncodedStream(message)

    assert b''.join(stream.iter_body()) == b'\xec\x95\x88\xeb\x85\x95\xed\x95\x98\xec\x84\xb8\xec\x9a\x94'


# Generated at 2022-06-12 00:08:18.291931
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    headers = b'Bcc: 1\r\nBcc: 2\r\n'
    body = b'Some body\nwith two lines\n'
    msg = HTTPMessage(headers=headers, body=body)
    stream = BaseStream(msg, with_headers=False, with_body=False)
    assert list(stream) == []

    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert list(stream) == [headers, b'\r\n\r\n', body]

    stream = BaseStream(msg, with_headers=False, with_body=True)
    assert list(stream) == [body]

    stream = BaseStream(msg, with_headers=True, with_body=False)

# Generated at 2022-06-12 00:08:26.111101
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    payload = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nServer: gunicorn/19.9.0\r\nDate: Fri, 11 Oct 2019 01:05:12 GMT\r\nContent-Length: 12\r\nConnection: close\r\n\r\n"
    msg = HTTPMessage(bytes(payload, 'utf-8'))
    fmt = Formatting()
    fmt_headers = fmt.format_headers(msg.headers)
    fmt_headers = fmt_headers.encode('utf-8')
    ps = PrettyStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None, conversion=None, formatting=None)
    assert fmt_headers == ps.get_headers()
