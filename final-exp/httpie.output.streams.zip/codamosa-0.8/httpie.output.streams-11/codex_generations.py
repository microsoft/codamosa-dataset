

# Generated at 2022-06-11 23:59:01.337398
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage()
    msg.headers.add('Content-Type', 'text/plain')
    msg.status_line = "HTTP/1.1 200 OK"
    msg.encoding = 'utf-8'
    msg.body = "あいうえお\0".encode('utf-8')

    stream = EncodedStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    result = b""
    try:
        result = b"".join(list(stream.__iter__()))
    except BinarySuppressedError as e:
        result = e.message

    assert result == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-11 23:59:10.308331
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    class MockHTTPMessage():
        def __init__(self, encoding, headers=None):
            self.encoding = encoding
            self.headers = headers

    class MockEnvironment():
        def __init__(self, stdout_isatty, stdout_encoding):
            self.stdout_isatty = stdout_isatty
            self.stdout_encoding = stdout_encoding

    msg_utf8 = MockHTTPMessage("utf-8", "utf-8 headers")
    stream_uft8 = EncodedStream(msg_utf8)
    # Use the encoding supported by the terminal.
    assert stream_uft8.output_encoding == 'utf8'

    msg_gbk = MockHTTPMessage("gbk")
    stream_gbk = EncodedStream(msg_gbk)

# Generated at 2022-06-11 23:59:17.780598
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg_type = 'headers' # from httpie.models.MessageType
    msg_dict = {'headers': {'Content-Type':'text/html'}}
    msg_dict[msg_type] = 'this is body of message'
    msg = HTTPMessage(msg_type, msg_dict) # from httpie.models.HTTPMessage

    # Use default values for arguments not passed as below
    bps = BufferedPrettyStream(msg)
    body = b''.join(bps.iter_body())
    print(body)


# Generated at 2022-06-11 23:59:22.221037
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    
    msg = HTTPMessage(headers='No=No')
    result = PrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    ).get_headers()
    assert result == b'No: No\r\n'

# Generated at 2022-06-11 23:59:29.885628
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage()
    msg.headers = """
HTTP/1.1 200 OK
Server: nginx
Date: Tue, 19 Aug 2014 15:01:56 GMT
Content-Type: text/html; charset=UTF-8
Transfer-Encoding: chunked
Connection: keep-alive
Vary: Accept-Encoding
X-Powered-By: PHP/5.5.17-1~dotdeb.1
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
Pragma: no-cache
Content-Encoding: gzip

"""
    msg.encoding = 'UTF-8'
    msg.iterable = ['aaaaaa', 'bbbbbb', 'cccccc']

# Generated at 2022-06-11 23:59:33.131140
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    stream = BufferedPrettyStream(msg, False, False)
    assert stream.msg == msg
    assert stream.msg.headers == ''

# Generated at 2022-06-11 23:59:43.246410
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.output import RawStream, PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import Response
    import json

    response_json = urlopen('https://api.github.com/repos/jakubroztocil/httpie')
    response = Response(response_json)
    conversion = Conversion()
    formatting = Formatting()
    raw_stream1 = RawStream(response)
    raw_stream2 = RawStream(response)
    pretty_stream1 = PrettyStream(
        response,
        conversion,
        formatting,
        on_body_chunk_downloaded=lambda chunk: raw_stream2.on_body_chunk_downloaded(chunk)
    )
    pretty_

# Generated at 2022-06-11 23:59:51.821120
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import pytest
    from httpie.models import HTTPMessage2

    with pytest.raises(BinarySuppressedError) as exc_info:
        stream = EncodedStream(msg=HTTPMessage2(b'01\0234'))
        for _ in stream.iter_body():
            pass

    assert exc_info.value.message == BINARY_SUPPRESSED_NOTICE

    ss = EncodedStream(msg=HTTPMessage2(b'\xff'))
    assert b'\ufffd' == next(ss.iter_body())

# Generated at 2022-06-11 23:59:59.953840
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    import requests
    import json
    headers = {'Content-Type': 'application/json'}
    response = requests.get('https://httpbin.org/ip', headers=headers)
    headers = HTTPMessage(200, response.headers)
    body = json.dumps(response.json())
    conversion = Conversion()
    formatting = Formatting()
    BufferedPrettyStream(headers, body, headers, True, True, conversion, formatting)
    return


# Generated at 2022-06-12 00:00:07.170678
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
	msg = HTTPMessage()
	msg.encoding = 'utf8'
	stream = EncodedStream(msg = msg)
	assert stream.msg == msg
	assert stream.output_encoding == 'utf8'
	
	msg2 = HTTPMessage()
	stream2 = EncodedStream(msg = msg2)
	assert stream2.msg == msg2
	assert stream2.output_encoding == 'utf8'

# Generated at 2022-06-12 00:00:29.020360
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    for formats in ["b", "u", "t", "h", "p", "c", "j"]:
        for suffix in [".json", ".yaml", ".yml"]:
            if formats == "b":
                yield test_BufferedPrettyStream_iter_body_binary, formats, suffix
            else:
                yield test_BufferedPrettyStream_iter_body_not_binary, formats, suffix



# Generated at 2022-06-12 00:00:35.238667
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    out=EncodedStream(msg=HTTPMessage(headers="abc", body="abc body"),with_headers=True, with_body=True)
    assert out.msg == HTTPMessage(headers="abc", body="abc body")
    assert isinstance(out.output_encoding, str)
    assert out.with_headers == True and out.with_body == True
    assert isinstance(out.iter_body(), Iterable[bytes])


# Generated at 2022-06-12 00:00:41.371095
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    output_encoding = 'utf8'
    msg = HTTPMessage(b'{"key": "value"}', content_type='application/json')
    stream = PrettyStream(msg, output_encoding=output_encoding)
    assert stream.process_body(b'{"key": "value"}').decode(output_encoding) == '{\n    "key": "value"\n}'

# Generated at 2022-06-12 00:00:52.068512
# Unit test for method __iter__ of class BaseStream

# Generated at 2022-06-12 00:01:02.851447
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
	m1 = HTTPMessage()
	m1.encoding = 'utf8' 
	m1.content_type = 'text/plain'
	m1.headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 4\r\n\r\naaaa'
	m1.body = 'aaaa' 
	e1 = EncodedStream(m1, with_headers=True, with_body=True)
	assert e1.CHUNK_SIZE == 1 
	assert e1.msg.encoding == 'utf8' 
	assert e1.msg.content_type == 'text/plain'

# Generated at 2022-06-12 00:01:08.333995
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    mock_msg = Mock()
    mock_msg.encoding = 'safe-8859-1'
    mock_msg.iter_lines = Mock(side_effect=lambda r: [
        (b'foo', b'\n'), (b'bar', b'\n'), (b'\x00', b'\n')
    ])

    stream = EncodedStream(msg=mock_msg)
    list(stream.iter_body())
    assert mock_msg.mock_calls == [call.iter_lines(1)]

    mock_msg = Mock()
    mock_msg.encoding = 'safe-8859-1'

# Generated at 2022-06-12 00:01:15.348675
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    my_msg = HTTPMessage(method="GET", encoding='utf-8')
    my_msg.headers = 'Content-Type: application/json\r\nContent-Length: 11\r\nUser-Agent: curl/7.54.0\r\nAccept: */*\r\n\r\n'
    my_stream = BufferedPrettyStream(msg=my_msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    print(my_stream.headers)




# Generated at 2022-06-12 00:01:27.357361
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.utils import get_binary_stdout

    import builtins

    builtins.__dict__['_'] = lambda x: x

    # http://stackoverflow.com/q/30709366/433549

# Generated at 2022-06-12 00:01:36.638410
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Request
    from httpie.output.formatters.colors import get_lexer
    from httpie.output import validation
    from pygments.token import Token
    headers = {
        'Accept-Encoding': 'gzip, deflate',
        'Content-Type': 'text/html; charset=utf-8',
        'Host': 'www.zhihu.com',
    }
    msg = Request(http_version='HTTP/1.1',
                  method='GET',
                  url='https://www.zhihu.com',
                  headers=headers)

# Generated at 2022-06-12 00:01:39.163236
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    return BufferedPrettyStream

# -------------- DO NOT EDIT BELOW THIS LINE -----------------
import pytest


# Tests for class BaseStream

# Generated at 2022-06-12 00:02:05.714132
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():

    class UUT(PrettyStream):
        def __init__(self):
            class ConversionMock:
                def get_converter(self, arg):
                    return arg
            class FormattingMock:
                def format_body(self, arg1, arg2):
                    return f'{arg1}-{arg2}'
            super().__init__(msg=None, conversion=ConversionMock(), formatting=FormattingMock())

        @property
        def mime(self):
            return self._mime

        @mime.setter
        def mime(self, val):
            self._mime = val

        def iter_lines(self):
            for e in [['', '\n'], ['abc', '\n'], ['', '\n']]:
                yield e

    uut = UUT()

# Generated at 2022-06-12 00:02:15.053475
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
Server: nginx/1.14.2
Date: Tue, 21 Jan 2020 08:52:19 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 76
Connection: keep-alive
Content-Encoding: gzip

'''
    msg.body = gzip.compress('{"hello": "world"}'.encode('utf-8'))
    msg.encoding = 'utf-8'
    print(msg.headers)
    print(msg.body)
    stream = EncodedStream(msg=msg)
    body = b''
    for chunk in stream.iter_body():
        body += chunk
    print(body)

# Generated at 2022-06-12 00:02:28.301500
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import EncodedStream
    from httpie.input import ParseError
    from httpie.compat import urlopen
    from io import BytesIO

    def httpbin(*suffix: str) -> str:
        return 'https://httpbin.org/' + '/'.join(suffix)

    with urlopen(httpbin('get')) as f:
        first_line = f.readline()
        headers = first_line.decode() + f.read().decode()

    response = Response(
        http_version='1.1',
        status_code=200,
        headers=headers,
        body='How are you?',
        encoding='utf8')

# Generated at 2022-06-12 00:02:37.479366
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    test_msg = HTTPMessage()
    test_msg.headers = "HTTP/1.1 200 OK\r\nDate: Sun, 04 Apr 2020 08:07:33 GMT\r\nServer: Apache\r\nLast-Modified: Mon, 20 Apr 2020 08:07:33 GMT\r\nETag: \"27459-5ac8f4d7b8900\"\r\nAccept-Ranges: bytes\r\nContent-Length: 160831\r\nContent-Type: text/html\r\n\r\n"

# Generated at 2022-06-12 00:02:39.979707
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    return BufferedPrettyStream(msg=message)



# Generated at 2022-06-12 00:02:47.798171
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    msg = Response(headers='''Content-Type: text/html; charset=utf-8
Content-Length: 135
Connection: keep-alive
Date: Mon, 23 Jun 2014 01:02:03 GMT
Location: http://www.google.com''')
    out = PrettyStream(msg=msg, with_headers=True, with_body=False)
    r = out.get_headers().decode()
    print(r)
    assert r == '''Content-Length: 135
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Date: Mon, 23 Jun 2014 01:02:03 GMT
Location: http://www.google.com
'''


# Generated at 2022-06-12 00:02:54.762893
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import httpie.output.streams
    stream = httpie.output.streams.EncodedStream(msg = HTTPMessage())
    import unittest
    class MyTestCase(unittest.TestCase):
        def myTest(self):
            expected = "Hello\n".encode('utf8')
            for chunk in stream.iter_body():
                self.assertEqual(expected, chunk)
            if __name__ == '__main__':
                unittest.main()

print('Hello\n')
test_EncodedStream_iter_body()

# Generated at 2022-06-12 00:03:05.364157
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage('GET / HTTP/1.1\r\nHost: www.google.com')
    stream = RawStream(msg, True, True)
    assert isinstance(stream, RawStream)

    msg = HTTPMessage('GET / HTTP/1.1\r\nHost: www.google.com')
    stream = EncodedStream(msg, True, True)
    assert isinstance(stream, EncodedStream)

    msg = HTTPMessage('GET / HTTP/1.1\r\nHost: www.google.com')
    stream = PrettyStream(msg, True, True, None, None)
    assert isinstance(stream, PrettyStream)

    msg = HTTPMessage('GET / HTTP/1.1\r\nHost: www.google.com')

# Generated at 2022-06-12 00:03:09.611947
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage(headers={'a': 'b'})
    pretty = PrettyStream(msg=msg, conversion=conversion, formatting=formatting)
    assert pretty.msg == msg
    assert pretty.conversion == conversion
    assert pretty.formatting == formatting


# Generated at 2022-06-12 00:03:19.789608
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    import httpie.output.streams

    original_encoding = httpie.output.streams.EncodedStream.__init__
    def __init__(self, encoding=None, **kwargs):
        self.encoding = encoding

    httpie.output.streams.EncodedStream.__init__ = __init__
    
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    
    
    msg = HTTPMessage(protocol='HTTP/1.1', status_line='200 OK',
        content_type='text/html; charset=utf8', headers=[('header1','value1')],
        body=b'\x00hello world')
    stream = BufferedPrettyStream(msg=msg, env=env, conversion=conversion, formatting=formatting)
    
    #assert b

# Generated at 2022-06-12 00:03:57.581043
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream = EncodedStream()
    assert stream.CHUNK_SIZE == 1

# Generated at 2022-06-12 00:04:03.019596
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=Headers(),body=b"\xc2\xa9",encoding="utf-8")
    stream = EncodedStream(msg=msg)
    body_temp = b"\xc2\xa9"
    body = body_temp.decode(msg.encoding).encode(stream.output_encoding, 'replace')
    assert stream.iter_body() == [body]      #return a list



# Generated at 2022-06-12 00:04:07.773300
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers='HDR: v', body='a\0b')
    stream = EncodedStream(msg, with_headers=False, with_body=True)
    for i in stream.iter_body():
        print(i)
    # b'a\xef\xbf\xbd\n'
    # b'b\n'


# Generated at 2022-06-12 00:04:11.650933
# Unit test for constructor of class RawStream
def test_RawStream():
    from httpie.models import Response
    raw_stream = RawStream(msg=Response(body=b'hello'))
    assert raw_stream.msg.body == b'hello'
    assert raw_stream.with_headers == True
    assert raw_stream.with_body == True


# Generated at 2022-06-12 00:04:18.158048
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    body = b"\x00\x01\x02\x03\x04\n\x00\x01\x02\x03\x04\n"
    msg = HTTPMessage(body=body,headers="")
    encstream = EncodedStream(msg)
    s = encstream.iter_body()
    assert s == ['\ufffd\ufffd\ufffd\ufffd\ufffd\n', '\ufffd\ufffd\ufffd\ufffd\ufffd\n']

# Generated at 2022-06-12 00:04:25.254833
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie import ExitStatus
    import json
    env = Environment()
    env.stdout_isatty = False
    msg = HTTPMessage(
        request_method='GET',
        request_url='https://httpbin.org/get',
        version='HTTP/1.1',
        status_code=200,
        reason='OK',
        headers=[('Content-Type', 'application/json')],
        encoding='utf8',
        body=json.dumps({'status': 'success'}).encode('utf8')
    )
    stream = EncodedStream(env=env, msg=msg,
                       with_headers=True, with_body=True)

    for chunk in stream:
        print(chunk)

# Generated at 2022-06-12 00:04:25.798222
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pass

# Generated at 2022-06-12 00:04:31.814110
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # set-up
    msg = HTTPMessage(headers={"X-header": "value"}, body="data")
    msg.content_type = "text"
    formatting = Formatting()
    conversion = Conversion()
    STREAM = PrettyStream(msg, True, True, None, Environment(), conversion, formatting)
    # convertion
    got = STREAM.iter_body()
    # check
    assert got == "data\n"

# Generated at 2022-06-12 00:04:40.773465
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    body = b'foo\r\nbar\r\n'
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.iter_body = lambda size: iter([(body, b'')])

    # (u'foo\nbar', '\n')
    assert tuple(iter(EncodedStream(msg))) == (b'foo\nbar\n', )

    body = b'foo\x00bar'
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.iter_body = lambda size: iter([(body, b'')])

    with pytest.raises(BinarySuppressedError):
        tuple(iter(EncodedStream(msg)))



# Generated at 2022-06-12 00:04:52.722266
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    """Test the constructor of class EncodedStream with different input."""
    msg = HTTPMessage('GET / HTTP/1.1', 'Content-Type: text/html')
    msg.headers.add('a', 'b')
    msg.headers.add('c', 'd')
    msg.headers.add('e', 'f')
    msg.body = 'some data'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.msg == msg
    assert stream.with_headers
    assert stream.with_body
    assert stream.output_encoding == 'utf8'
    assert stream.CHUNK_SIZE == 1
    env.stdout_isatty = False


# Generated at 2022-06-12 00:06:10.965118
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    '''
        Testing response header if the whole header lines are correct.
    '''
    from httpie.models import Response

    # Testing response without body
    response_header = Response(
        status_line='HTTP/1.0 200 OK',
        headers=b'Content-Length: 0\r\n\r\n',
        body=b'',
        encoding=None
    )

    # Create a RawStream instance
    my_stream = RawStream(msg=response_header)
    # Traverse the whole list of the generator function iter_body()
    # and store the value in a list
    result = [item for item in my_stream.iter_body()]
    # Check if result has a correct length
    assert len(result) == 0

    # Testing response with body

# Generated at 2022-06-12 00:06:13.968745
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.output.streams import EncodedStream
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    stream = EncodedStream(HTTPMessage(), env=Environment())
    print (stream.output_encoding)

# Generated at 2022-06-12 00:06:19.850612
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = {'Content-Type': 'text/html'}
    msg.encoding = 'utf-8'
    msg.content = b'<html></html>'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf-8'
    stream = EncodedStream(msg=msg, env=env)
    assert stream.output_encoding == 'utf-8'


# Generated at 2022-06-12 00:06:30.907449
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie import Response
    from httpie.compat import urlopen
    url = 'https://httpbin.org/json'
    obj = urlopen(url, timeout=3)

    # Process a single line at a time.
    response = Response(obj, output_options=None, request_headers={})
    stream = PrettyStream(msg=response, env=Environment(), conversion=None, formatting=None)
    try:
        for line in stream.iter_body():
            pass
    except BinarySuppressedError:
        print("Exception: BinarySuppressedError")

    # Process Full response
    obj = urlopen(url, timeout=3)
    response = Response(obj, output_options=None, request_headers={})
    stream = BufferedPrettyStream(msg=response, env=Environment(), conversion=None, formatting=None)
   

# Generated at 2022-06-12 00:06:39.925459
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class SampleStream(PrettyStream):
        def __init__(self, msg, **kwargs):
            super().__init__(msg=msg, **kwargs)

    env = Environment()
    base_headers = {'Content-Type': 'text/plain', 'Content-Length': '0'}
    binary_body = b'\xF0\x9F\x8D\xBA'
    text_body = u'Бла-бла-бла'
    stream_mimes = (
        'text/html',
        'text/plain',
        'application/json',
    )


# Generated at 2022-06-12 00:06:48.384941
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Streaming chunk for binary data
    message = b"abc\x03"
    http_message = {"headers": "", "body": message}
    http_message = HTTPMessage(**http_message)
    print(RawStream(msg=http_message, with_headers=False, with_body=True).iter_body())
    # Streaming chunk for non-binary data
    message = b"abc"
    http_message = {"headers": "", "body": message}
    http_message = HTTPMessage(**http_message)
    print(RawStream(msg=http_message, with_headers=False, with_body=True).iter_body())


# Generated at 2022-06-12 00:06:52.966648
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    kwargs = {'with_headers': True, 'with_body': True}
    env = Environment(formatter="json")
    es = EncodedStream(env, **kwargs)
    assert es.msg == kwargs['msg']
    assert es.with_headers == kwargs['with_headers']
    assert es.with_body == kwargs['with_body']


# Generated at 2022-06-12 00:06:57.208414
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={'header1': 'value1', 'header2': 'value2'})
    assert PrettyStream(msg, env=Environment(), formatting=Formatting(False)).get_headers() == b'header1: value1\r\nheader2: value2\r\n\r\n'



# Generated at 2022-06-12 00:07:06.436659
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    class MockEnvironment:
        stdout_isatty = True
        stdout_encoding = "utf8"

    class MockHTTPMessage:
        content_type = "mock content type"
        encoding = "utf8"

    mock_conversion = Conversion()
    mock_formatting = Formatting()
    mock_HTTPMessage = MockHTTPMessage()
    mock_env = MockEnvironment()
    stream = PrettyStream(
        msg=mock_HTTPMessage,
        conversion=mock_conversion,
        formatting=mock_formatting,
        env=mock_env
    )
    assert stream.msg == mock_HTTPMessage
    assert stream.output_encoding == mock_env.stdout_encoding
    assert stream.mime == mock_HTTPMessage.content_type

# Generated at 2022-06-12 00:07:07.408643
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert True
