

# Generated at 2022-06-11 23:59:03.240573
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import sys
    from httpie.output.colors import AutoColors
    from httpie.output.formatters import JSONPFormatter
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.input import ParseError
    from httpie.plugins import registry as plugin_registry

    env = Environment(colors=AutoColors())
    formatting = Formatting(env)
    conversion = Conversion(env, plugin_registry)

    formatter = JSONPFormatter(formatting=formatting)
    formatting.formatters['application/json'] = formatter

    msg = HTTPMessage(
        headers={'Content-Type': 'application/json'},
        body=b'{"a": {"b": ["c", "d"]}}'
    )
    # Default encoding

# Generated at 2022-06-11 23:59:12.052838
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # init
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    test_data = ['1\r\n', '2\r\n', '3\r\n', '4\r\n', '5\r\n']
    test_data_iter = iter(test_data)

    def _chunk_iter():
        try:
            return next(test_data_iter)
        except StopIteration:
            raise StopAsyncIteration

    msg.iter_lines = MagicMock(return_value=_chunk_iter)

    # test
    obj = EncodedStream(msg,with_headers, with_body,on_body_chunk_downloaded)
    result = obj.iter_body().__next__

# Generated at 2022-06-11 23:59:21.779753
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    first_chunk = b"abc"
    iteration_chunk = [b"abc", b"def", b"123"]
    last_chunk = b"\n"
    def fake_iter_lines(chunk_size):
        yield first_chunk, b"\n"
        for chunk in iteration_chunk:
            yield chunk, b"\n"
        yield last_chunk, b"\n"
    # create fake msg with fake iter_lines method
    msg = HTTPMessage()
    msg.iter_lines = fake_iter_lines
    
    # create fake formatting with fake format_body method
    formatting = Formatting()
    def fake_format_body(content, mime):
        return content
    formatting.format_body = fake_format_body
    
    # create fake conversion with fake get

# Generated at 2022-06-11 23:59:29.505512
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(200, 'OK', headers=headers)
    env = Environment()
    conversion = Conversion()
    formatting = Formatting(error_messages={})
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting, env=env)
    print(stream.msg)
    assert stream.get_headers()==headers
    env.stdout_encoding = 'utf8'
    print(stream.output_encoding)
    assert stream.output_encoding=='utf8'
    msg = HTTPMessage(200, 'OK', headers=headers, body=b'\xc3\xba\xc3\xa5')
    env = Environment()
    conversion = Conversion()
    formatting = Formatting(error_messages={})

# Generated at 2022-06-11 23:59:41.226392
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(body=b'{"data":{"hello":"world"}}',
                      headers=["Content-Type: application/json"])
    stream = PrettyStream(msg, print_body=True, output_options={"format": "colors"})
    generator = stream.iter_body()

# Generated at 2022-06-11 23:59:52.460632
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1.
    stream = PrettyStream(None, None, None, None, None)
    chunk = "<h1>test</h1>"
    assert stream.process_body(chunk) == b"<h1>test</h1>"
    # Test case 2.
    stream = PrettyStream(None, None, None, None, None)
    chunk = "<h1>test"
    assert stream.process_body(chunk) == b"<h1>test"
    # Test case 3.
    stream = PrettyStream(None, None, None, None, None)
    chunk = "test</h1>"
    assert stream.process_body(chunk) == b"test</h1>"
    # Test case 4.
    stream = PrettyStream(None, None, None, None, None)

# Generated at 2022-06-11 23:59:56.050091
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(headers={'Content-Type': 'text/plain'}, body='body')
    stream = PrettyStream(msg, conversion=None)
    assert isinstance(stream, PrettyStream)


# Generated at 2022-06-12 00:00:02.044904
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage(
        'GET / HTTP/1.1\r\n'
        'Content-Type: {}\r\n'
        '\r\n'
        '{}'.format(
            'application/json',
            json.dumps({'test': 1})
        )
    )
    msg.encoding = DEFAULT_ENCODING
    stream = BufferedPrettyStream(msg, env=Environment())
    for body_line in stream.iter_body():
        for el in body_line:
            print(el)
    # print(stream.iter_body())

# Generated at 2022-06-12 00:00:12.777423
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.compat import urlopen
    from httpie.compat import JSONDecodeError
    from httpie.downloads import Response
    from httpie.models import Request
    from httpie.input import ParseError
    import httpie.cli
    import httpie.output
    import httpie.compat
    import httpie.status
    import httpie.downloads

    import json
    import os
    import sys
    import pytest

# Generated at 2022-06-12 00:00:20.772765
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
	print("")
	print("********************************************************")
	print("*********************Test EncodedStream******************")
	print("********************************************************")
	print("")
	# EncodedStream(env, msg, with_headers, with_body, on_body_chunk_downloaded)
	# msg is a HTTPMessage class
	data = base64.b64decode(b'SGVsbG8gV29ybGQh')
	headers = Headers(Content_Type='text/plain')
	http_msg = HTTPMessage(headers=headers,body=data)
	# env is a Environment class
	stdout_encoding='utf8'
	stdout_isatty=True
	env = Environment(stdout_encoding, stdout_isatty)
	# 
	on_body_ch

# Generated at 2022-06-12 00:00:34.719224
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(
        'status',
        headers={'contents-type': 'text/html'},
        body='body'
    )
    stream = BaseStream(msg)
    assert b''.join([chunk async for chunk in stream]) == b'\r\n'

# Generated at 2022-06-12 00:00:42.365956
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream(msg = HTTPMessage())
    stream.msg.encoding = 'utf8'
    stream.output_encoding = 'utf8'
    stream.CHUNK_SIZE = 1
    stream.msg.body = 'abcde'
    count = 0
    for line in stream.iter_body():
        count = count + 1
        assert(line == 'abcde')
    assert(count == 1)
    stream.msg.body = '\0'
    count = 0
    for line in stream.iter_body():
        count = count + 1
    assert(count == 0)

# Generated at 2022-06-12 00:00:42.929865
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-12 00:00:46.750871
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    message = HTTPMessage()
    pretty = PrettyStream(message, True, False)
    pretty.msg.headers = 'a:b\n c:d'
    assert pretty.get_headers() == b'a:b\n c:d'

# Generated at 2022-06-12 00:00:54.484671
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    body = io.BytesIO(b'\xff\xfe\xfd\xfc')
    body_iter = EncodedStream(msg, with_headers=False, with_body=True).iter_body()
    for line in body_iter:
        assert line == b'\ufffd\ufffd\ufffd\ufffd'



# Generated at 2022-06-12 00:00:55.616428
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    stream = PrettyStream()
    assert stream is not None

# Generated at 2022-06-12 00:01:02.450579
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream

    if not sys.stdout.isatty():
        pytest.skip('stdout not a tty')

    # send a response to terminal
    r = Response(request=None, headers={}, body=b'\n'* 5)
    r = r.update(headers={'Content-Type': 'text/html; charset=utf-8'})
    with EncodedStream(r) as stream:
        for chunk in stream:
            sys.stdout.buffer.write(chunk)
            sys.stdout.flush()

# Generated at 2022-06-12 00:01:03.406070
# Unit test for constructor of class RawStream
def test_RawStream():
    assert True


# Generated at 2022-06-12 00:01:03.975244
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    print(PrettyStream)

# Generated at 2022-06-12 00:01:10.658075
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import os
    from collections import namedtuple
    from httpie.models import HTTPMessage
    from httpie import ExitStatus
    from httpie.cli.terminal import httpie
    from httpie.compat import is_windows
    
    if is_windows():
        # if the OS is windows then ignore this test
        return
    
    TestResponse = namedtuple('TestResponse', ['encoding'])

    if not os.path.isdir('tests/tmp'):
        os.makedirs('tests/tmp')
    filename = 'tests/tmp/response.csv'
    with open(filename, 'w') as f:
        f.write('header1,header2,header3\n1,2,3\n')


# Generated at 2022-06-12 00:01:38.263250
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.input import ParseError
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.models import Response
    """Test the get_headers method of the streams class PrettyStream"""
    """This unit test is only for method get_headers of class PrettyStream"""
    """This unit test is written by Yanzhe Lee"""
    """Create some test cases"""

# Generated at 2022-06-12 00:01:49.141102
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # test: no-headers and no-body
    msg1 = HTTPMessage(headers=[], body="random_body")
    s1 = BaseStream(msg=msg1, with_headers=False, with_body=False)
    assert list(s1.__iter__()) == []

    # test: no-headers and body
    assert list(s1.__iter__()) == []
    
    # test: headers and no-body
    msg2 = HTTPMessage(headers=["random_headers"], body="")
    s2 = BaseStream(msg=msg2, with_headers=True, with_body=False)
    assert list(s2.__iter__()) == [b"random_headers", b"\r\n\r\n"]

    # test: headers and body

# Generated at 2022-06-12 00:01:52.985033
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    def mocked_iter_lines(*args):
        return [('a\n', 'b\n', 'c\n')]

    stream = EncodedStream(iter_lines=lambda: mocked_iter_lines())
    assert list(stream.iter_body()) == [b'a\nb\nc\n']



# Generated at 2022-06-12 00:02:02.863327
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers={'Content-Type': 'text/plain'}, encoding='utf-8')

# Generated at 2022-06-12 00:02:12.483493
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(method='GET', url='http://www.example.com', data='b')
    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert list(stream) == [
        b'GET / HTTP/1.1\r\n',
        b'Host: www.example.com\r\n',
        b'Accept-Encoding: gzip, deflate\r\n',
        b'Accept: */*\r\n',
        b'User-Agent: HTTPie/0.9.8\r\n',
        b'Connection: keep-alive\r\n',
        b'\r\n',
        b'b'
    ]


# Generated at 2022-06-12 00:02:23.041617
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # case: text with carriage return
    chunk = b"\r\n"
    ps = PrettyStream(msg=None)
    assert ps.process_body(chunk) == b'\r\n', \
        "method process_body of class PrettyStream failed to process carriage return"

    # case: text with non-printable characters
    chunk = "ab\033[cd"
    ps = PrettyStream(msg=None)
    assert ps.process_body(chunk) == b"ab\x1b[cd", \
        "method process_body of class PrettyStream failed to process non-printable characters"

    # case: text with { and } characters
    chunk = "ab{'c}d"
    ps = PrettyStream(msg=None)

# Generated at 2022-06-12 00:02:33.684437
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = FakeHTTPMessage(
       "HEADER\r\nHEADER2",
       encoding='utf8',
       headers=b"header1: value1\r\nheader2: value2\r\n")
    stream = PrettyStream(msg=msg,
        with_headers=True,
        with_body=False,
        conversion=Conversion(),
        formatting=Formatting(colors=True)
    )
    result = stream.get_headers()
    expected = b"\x1b[1mheader1:\x1b[0m value1\r\n\x1b[1mheader2:\x1b[0m value2\r\n"
    assert result == expected



# Generated at 2022-06-12 00:02:44.094197
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.response import Response


# Generated at 2022-06-12 00:02:52.554010
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    s = b"""Kieu Anh is \xe1\xba\xa3nh Kieu
Kieu Anh is kieu anh
    """
    stream = EncodedStream(HTTPMessage('Kieu Anh', 'utf-8', s), with_headers=False, with_body=True, on_body_chunk_downloaded=None)
    result = list(stream.iter_body())
    assert result == [b'Kieu Anh is \xc3\xa1\xc2\xba\xc2\xa3nh Kieu\n', b'Kieu Anh is kieu anh\n']


# Generated at 2022-06-12 00:02:57.084293
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = {
        'Content-Type': 'application/json; encoding=utf8',
        'Content-Length': 1,
        'Connection': 'close'
    }
    msg_actual = PrettyStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    msg_expected = msg_actual.get_headers()
    print(msg_expected)

# Generated at 2022-06-12 00:03:37.179861
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test_data = b'{"key": [1, 2, 3, 4]}'
    response = EncodedStream(HTTPMessage(body=test_data, encoding='utf8'))
    for chunk in response.iter_body():
        print(chunk)
 

# Generated at 2022-06-12 00:03:42.312839
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(headers={"Content-Type": "text/html; charset=utf-8"})
    q = PrettyStream(
        msg, with_headers=True, with_body=True,
        conversion=Conversion(),
        formatting=Formatting())

    assert q.process_body("<html>") == b'<html>'
    assert q.process_body("\u0488") == b'\xd1\x88'


# Generated at 2022-06-12 00:03:52.635269
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    data = (b'{"a": 1}', b'{"b": 2}', b'{"c": 3}')
    def iter_body():
        for i in data:
            yield i, b'\n'

    class Msg(object):
        content_type = 'application/json'
        encoding = 'utf-8'
        def iter_lines(self, chunk_size):
            return iter_body()

    conversion = Conversion('json')
    formatting = Formatting()

    msg = Msg()

    def get_chunks(msg):
        chunk_list = []
        for i in PrettyStream(msg, conversion, formatting).iter_body():
            chunk_list.append(i)
        return chunk_list


# Generated at 2022-06-12 00:04:01.655347
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    import pytest
    try:
        # Random content-type with non-ascii character
        test_content_type = u'application/ütf-8'
        # Create a new test message
        test_message = HTTPMessage(headers=test_content_type)
        # Create a new test environment
        test_env = Environment()
        # Create a new test formatting
        test_formatting = Formatting()
        # Create a new object with the specified message, environment, and formatting
        test_pretty_stream = PrettyStream(msg=test_message, env=test_env, formatting=test_formatting)
        # Test that the method returns the value at the desired encoding
        assert test_pretty_stream.get_headers().decode() == test_content_type
    except:
        pytest.raises(AssertionError)

# Generated at 2022-06-12 00:04:06.998540
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True   # suppose stdout is a terminal
    env.stdout_encoding = None # suppose that the terminal doesn't support encoding

    stream = EncodedStream(msg=msg, env=env)
    assert stream.msg == msg
    assert stream.output_encoding == 'utf8'



# Generated at 2022-06-12 00:04:16.952043
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
	# Set up a fake message
	msg = HTTPMessage(headers={}, body=b'{ "test": 0 }')
	msg.encoding = 'utf-8'
	msg.content_type = 'application/json'

	# Set up a fake conversion class
	class Conversion(object):
		def __init__(self, mime):
			self.mime = mime
		def convert(self, body):
			return self.mime, body
	conversion = Conversion('bla/bla')

	# Setup a fake Formatting object
	class Formatting(object):
		def format_body(self, content, mime):
			return content
		def format_headers(self, headers):
			return ''
	formatting = Formatting()

	# Test the method

# Generated at 2022-06-12 00:04:24.962736
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    import httpie.models as models
    import httpie.output.processing as formatting
    from httpie.cli.argtypes import KeyValueArgType

    def get_mock_env():
        """Return a fake Environment object."""
        def mock_isatty():
            return True

        def mock_stdout_encoding():
            return 'utf8'
        return Environment(
            stdout_isatty=mock_isatty,
            stdout_encoding=mock_stdout_encoding)

    # Format the headers including a request line and the cookies.
    # Use a fake Custom formatting object that replaces the default Data
    # formatting object.

# Generated at 2022-06-12 00:04:35.510979
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():

    def test_func():
        pass

    msg = HTTPMessage(test_func)
    msg.body = '{"test":"test"}\n{"test":"test"}'
    msg.content_type = "application/json"
    msg.headers = 'test'

    stream = BufferedPrettyStream(msg=msg)
    result = stream.iter_body()

    # assert-true
    assert result != None

    # assert-value
    expected_result = '{\n   "test": "test"\n}\n{\n   "test": "test"\n}'
    actual_result = ''
    for line in result:
        actual_result += str(line).replace("'".encode(), '"'.encode()).replace("\\n".encode(), '\n'.encode())
    assert expected_result == actual

# Generated at 2022-06-12 00:04:40.870268
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    f = open("responsetest.txt", "r")
    content = f.read()
    print(type(content))
    msg = HTTPMessage(headers=content)
    stream = RawStream(msg, with_headers=False, with_body=True)
    stream_iterator = stream.iter_body()
    result = b''
    for i in stream_iterator:
        result += i
    f.close()
    return (result)


# Generated at 2022-06-12 00:04:52.807158
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    import unittest
    from httpie.output.streams import PrettyStream
    from httpie.models import Response
    from httpie import ExitStatus
    from httpie.compat import str
    from utils import http, HTTP_OK
    from pygments.lexers import JsonLexer
    from pygments.formatters import TerminalFormatter

    class MockEnvironment:
        stdout_isatty = True
        stdout_encoding = 'utf8'
        is_windows = False
        color = 256
        colors = 256
        stdin_isatty = False

    class MockFormatter:
        def __init__(self, env=None, *args, **kwargs):
            pass

        def get_style_defs(self):
            return ''


# Generated at 2022-06-12 00:06:13.245840
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    formatter = Formatting(prettifier=None)
    conv = Conversion()
    body1 = "Hello "
    body2 = "{goodbye"
    body3 = " world!"
    bodyWithEncoding = '{ "encoding": "utf-8", "data": ' + '"' + body1 + body2 + body3 + '"' + '}'
    expectedBody = "Hello " + "{goodbye" + " world!"
    assert isinstance(bodyWithEncoding, str)
    assert isinstance(expectedBody, str)
    msg = HTTPMessage(content=bodyWithEncoding, content_type="application/json", encoding='utf-8')
    msg2 = HTTPMessage(content=expectedBody, content_type="application/json", encoding='utf-8')

# Generated at 2022-06-12 00:06:22.250163
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.input import ParseError, KeyValue
    from httpie.compat import is_windows
    from httpie.models import HTTPRequest
    from httpie import CONTENT_TYPE_JSON
    from httpie.output.streams import PrettyStream, BufferedPrettyStream
    from httpie.plugins.builtin import HTTPBasicAuth
    import sys
    env = Environment(stdin=None,
                      stdout=sys.stdout,
                      stderr=sys.stderr,
                      stdout_isatty=True,
                      stdin_isatty=True)

    json_headers = [
        KeyValue(key='Content-Type',
                 value='application/json', sep='',
                 sep_value=' ')]


# Generated at 2022-06-12 00:06:33.380354
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    mesg = HTTPMessage('HTTP/1.1 200 OK')
    mesg.headers = 'Host: localhost\r\n'
    mesg.headers += 'Content-Type: text/plain\r\n'
    mesg.headers += 'Content-length: 2\r\n'
    mesg.headers += '\r\n'
    mesg.content = b'\x00\x00'
    mesg.encoding = 'utf8'

    stream = PrettyStream(
        env = Environment(),
        conversion=Conversion(None, None),
        formatting=Formatting(VERBOSE=True),
        msg=mesg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
    )

    pretty_headers = stream.get

# Generated at 2022-06-12 00:06:40.403200
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import Response
    from httpie.output import stream
    from httpie.output.stream import EncodedStream

    msg = Response(
        status_code=200,
        reason="OK",
        headers={'content-type': 'text/plain; charset=utf-8'},
        content=u"a\u1234b".encode('utf-8'))
    s = EncodedStream(msg=msg)
    content = ""
    for c in s.iter_body():
        content += c.decode('utf-8')
    assert content == u"a\ufffd\ufffdb"



# Generated at 2022-06-12 00:06:46.519709
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # req = HTTPMessage(
    #     request_from_dict(
    #         {'headers': [('User-Agent', 'HTTPie')], 'body': b'abc'},
    #         'https://www.baidu.com')
    # )
    # raw_stream = RawStream(req)
    print("ss")
    for item in raw_stream:
        print(item)


# Generated at 2022-06-12 00:06:54.633752
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    body = [ b'line1\n', b'line2\n', b'line3\n' ]
    headers = {}
    msg = HTTPMessage(headers, body, encoding='utf8', content_type='text/html')
    # Initialize conversion
    conversion = Conversion()
    # Initialize formatting
    formatting = Formatting(style='none', colors='none', implicit_content_type=None)

    it = PrettyStream(msg, conversion=conversion, formatting=formatting).iter_body()
    for i, expected in enumerate(body, 1):
        got = next(it)
        print(f'line{i}:\nexpected: {expected}\ngot: {got}')
        assert expected == got


# Generated at 2022-06-12 00:07:00.938450
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(
        headers={
            'content-type': 'Content-Type: text/plain',
            'content-length': 'Content-Length: 13'
        },
        body=b'Hello\nWorld\n'
    )
    stream = BaseStream(msg)
    assert b''.join(stream) == b'Content-Type: text/plain\r\nContent-Length: 13\r\n\r\nHello\nWorld\n'

    stream = BaseStream(msg, with_headers=False)
    assert b''.join(stream) == b'Hello\nWorld\n'



# Generated at 2022-06-12 00:07:11.238988
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-12 00:07:19.236543
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    stream = BufferedPrettyStream(msg=None, with_headers=None, with_body=None, on_body_chunk_downloaded=None)
    stream.CHUNK_SIZE = 1
    stream.msg = {
        'iter_body': lambda chunk_size: [b'I am a chunk\nI am a chunk\n', b'I am a chunk\nI am a chunk\n', b'I am a chunk\nI am a chunk\n', b'I am a chunk\nI am a chunk\n', b'I am a chunk\nI am a chunk\n', b'I am a chunk\nI am a chunk\n'],
        'encoding': 'utf-8'
    }
    stream.mime = 'application/json'

# Generated at 2022-06-12 00:07:29.779855
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class TestMessage:
        def __init__(self, content_type, encoding, body):
            self.content_type = content_type
            self.encoding = encoding
            self.body = body

        def iter_lines(self, chunk_size):
            for line in self.body:
                yield line, b'\n'

    class TestConversion:
        def get_converter(self, mime):
            if mime != 'test_mime':
                return None

            class TestConverter:
                def convert(self, body):
                    if self.is_valid_body(body):
                        return 'new_mime', str(body)[::-1]
            return TestConverter()
