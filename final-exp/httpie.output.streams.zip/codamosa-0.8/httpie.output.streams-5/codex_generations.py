

# Generated at 2022-06-11 23:59:07.325614
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # case: BaseStream.__init__() should raise assertion error if with_headers is False and with_body is False
    with pytest.raises(AssertionError):
        BaseStream(msg=HTTPMessage(), with_headers=False, with_body=False)
    # case: BaseStream.__init__() should not raise assertion error if with_headers is True and with_body is False
    try:
        BaseStream(msg=HTTPMessage(), with_headers=True, with_body=False)
    except AssertionError:
        pytest.fail()
    # case: BaseStream.__init__() should not raise assertion error if with_headers is False and with_body is True

# Generated at 2022-06-11 23:59:12.119637
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage(headers=[('content-type', 'application/json')], body='')
    stream = BufferedPrettyStream(msg=msg, with_headers=False, with_body=True)
    chunks = stream.iter_body()
    for i in chunks:
        assert isinstance(i, bytes)

# Generated at 2022-06-11 23:59:16.434321
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    with open('./httpie/compat.py') as f:
        stream = PrettyStream(conversion=Conversion(None), formatting=Formatting(None), msg=HTTPMessage(f))
        assert len(stream.get_headers()) > 0


# Generated at 2022-06-11 23:59:24.814794
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import sys
    import io
    import httpie
    msg = httpie.models.HTTPMessage(
        headers=httpie.models.Headers([(b'Content-Type', b'application/json')]),
        encoding='utf8',
        body=json.dumps({"test_json_1": "1", "test_json_2": "2"}).encode('utf8')
    )
    env = httpie.context.Environment()
    env.stdout_encoding = 'utf8'
    env.stdout_isatty = False
    test_PrettyStream = httpie.output.streams.PrettyStream(
        msg=msg,
        conversion=httpie.output.processing.Conversion(),
        formatting=httpie.output.processing.Formatting(),
        env=env
    )

# Generated at 2022-06-11 23:59:34.132132
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.input.buffered_stream import BufferedStream
    import pytest
    from httpie.utils import unicode

    # Without conversion.
    s = BufferedPrettyStream(msg=BufferedStream(b'body'),
                             conversion=Conversion(),
                             formatting=Formatting())
    assert str(s) == '<BufferedPrettyStream {}>'.format(s.msg)
    assert unicode(s) == '<BufferedPrettyStream {}>'.format(s.msg)
    assert s.msg.content_type == 'application/octet-stream'
    assert s.iter_body() == ['body']

    # With conversion.

# Generated at 2022-06-11 23:59:43.008243
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # arrange
    headers = [
        'HTTP/1.1 200 OK',
        'Content-Length: 35',
        'Connection: close',
        'Date: Tue, 21 May 2019 16:31:59 GMT',
        'Server: TornadoServer/4.5.3',
        'Content-Type: text/html; charset=UTF-8'
    ]
    body = '<html><body>Hello, World!</body></html>'

    msg = HTTPMessage(headers=headers, body=body)
    env = Environment()
    # act
    es = EncodedStream(msg=msg, env=env)
    # assert
    assert(es.output_encoding == env.stdout_encoding)

# Generated at 2022-06-11 23:59:54.951251
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.core import http_namespace

    args = http_namespace.parser.parse_args(['--prettify', 'https://google.com'])
    msg = http_namespace.request(args)
    msg.send(args)
    msg.get_response()


# Generated at 2022-06-11 23:59:59.136482
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    stream = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    assert iter(stream) == stream.__iter__()


# Generated at 2022-06-11 23:59:59.713284
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    assert False

# Generated at 2022-06-12 00:00:00.222993
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    pass

# Generated at 2022-06-12 00:00:17.203016
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.input import SEP_HEADERS
    from httpie.models import Response
    # create message
    msg = Response(
        url='http://httpbin.org/post',
        status_code=200,
        headers=f'Content-Type: application{SEP_HEADERS}X-Foo: 123',
        body=f'form key1=val1,val2&key2=val3{SEP_HEADERS}'
    )
    # create stream
    bps = BufferedPrettyStream(
        msg=msg
    )
    # convert the message and check
    buf: bytes = next(bps.iter_body())
    assert buf == b'form key1=val1,val2&key2=val3\n'


# Generated at 2022-06-12 00:00:18.123158
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    pass

# Generated at 2022-06-12 00:00:28.270942
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    '''
    - Test case without converter
    - Test case with converter
    - Test case with a body contains an invalid binary character
    '''
    import json

    def test_helper(body, converter_exist, invalid_binary_char, expected_yield):
        msg = HTTPMessage(headers='')
        msg.raw = True
        msg.content_type = 'text/plain'
        msg.encoding = 'utf-8'
        msg.body = body

        formatting = Formatting()
        conversion = Conversion()
        conversion.get_converter = lambda mime: MockConverter(converter_exist)
        stream = PrettyStream(msg, with_headers=False, with_body=True, formatting=formatting, conversion=conversion)

# Generated at 2022-06-12 00:00:39.170320
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    headers = "Content-Type: text/html; encoding=utf-8"
    body = "a\n<br>\nb\n<br>\nc\n<br>"
    msg = HTTPMessage(headers=headers, content=body)
    stream = PrettyStream(msg=msg,
                          conversion=Conversion(),
                          formatting=Formatting(),
                          with_headers=True,
                          with_body=True)

    body_received = ''
    try:
        for chunk in stream.iter_body():
            body_received += chunk.decode("utf8")
    except BinarySuppressedError as e:
        print(e.message.decode("utf8"))

    assert body_received == body.replace("<br>", "\n")

# Generated at 2022-06-12 00:00:46.051205
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print('test_EncodedStream')

    msg: HTTPMessage = HTTPMessage(headers=['h1: hValue1', 'h2: hValue2'], body='hello world')

    # Confirm that if stdout is not a tty environment, the output encoded is utf8
    es = EncodedStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    for line in es.iter_body():
        print(line)

# Generated at 2022-06-12 00:00:58.693110
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.core import LegacyRequest
    req = LegacyRequest(method='GET', url='http://httpbin.org/', headers={},
                        data=b'{"a": "b"}', json=True,
                        output_options={'headers': '', 'pretty': 'none'})
    stream = BufferedPrettyStream(conversion=Conversion(),
                                  formatting=Formatting(),
                                  msg=req, with_headers=False, with_body=True)
    # Check if iter_body returns the bytes corresponding to the JSON-formatted
    # string of the dict {"a":"b"}
    # Now iter_body returns an iterator containing a bytes object containing
    # the JSON-formatted string of the dict {"a":"b"}
    # In this case, the iterator has only one element, a bytes object
    # containing the JSON-formatted string

# Generated at 2022-06-12 00:01:05.282185
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import sys
    #sys.setdefaultencoding('utf-8')
    s = EncodedStream(msg=HTTPMessage(headers=['Content-Type: text/html; charset=gb2312'], body='你好啊'), with_headers=True)
    #s = EncodedStream(msg=HTTPMessage(headers=['Content-Type: text/html; charset=gb2312'], body=u'你好啊'))
    for i in s.iter_body():
        print(i)

# Generated at 2022-06-12 00:01:15.678541
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import str

    class DummyRequest(HTTPRequest):
        headers = {
            b'Content-Type': b'json',
            b'Set-Cookie': [b'foo=bar', b'bar=baz']
        }

        def iter_body(self, chunk_size):
            yield b'{"k1": "v1", "k2": "v2"}'

    class DummyResponse(HTTPResponse):
        headers = {
            b'Content-Type': b'json',
            b'Set-Cookie': [b'foo=bar', b'bar=baz'],
            b'Content-Length': b'18'
        }


# Generated at 2022-06-12 00:01:21.697534
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage('utf8')
    msg.headers = 'content-type: application/json\r\n'
    msg.body = b'"hello \\x00 world"'
    stream = EncodedStream(msg=msg)
    for chunk in stream.iter_body():
        print(chunk)

# Generated at 2022-06-12 00:01:23.573108
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    prettyStream = PrettyStream("conversion", "formatting", True, True, True)
    assert prettyStream is not None

# Generated at 2022-06-12 00:01:53.701305
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream

    maxDiff = None
    headers = '''GET / HTTP/1.1
Accept: text/html
Accept-Encoding: gzip
Accept-Language: en-us
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.8
'''

# Generated at 2022-06-12 00:02:00.821476
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    fp = open(__file__, 'rb')
    msg = HTTPMessage(fp=fp, content_type='application/json', stream=True)
    conversion = Conversion()
    formatting = Formatting()
    s = PrettyStream(msg, conversion=conversion, formatting=formatting)
    assert isinstance(s.iter_body(), Iterable)
    print('A')
    for chunk in s.iter_body():
        print('B')
        print(chunk)


if __name__ == '__main__':
    test_PrettyStream_iter_body()

# Generated at 2022-06-12 00:02:05.421119
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # test class that has no :param:with_body parameter
    class TestStream(BaseStream):
        def __init__(self, msg, **kwargs):
            super().__init__(msg, **kwargs)
    msg = HTTPMessage('GET / HTTP/1.1\r\n')
    with pytest.raises(NotImplementedError):
        list(TestStream(msg).__iter__())



# Generated at 2022-06-12 00:02:14.874167
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class Msg:
        def __init__(self, body, mime):
            self.body = body
            self.mime_type = mime
        
        def iter_lines(self, chunk_size):
            return (self.body, '\r\n')
        
        def content_type(self):
            return self.mime_type
    
    raw_text = """
    +-----------------------------------------+
    | NOTE: binary data not shown in terminal |
    +-----------------------------------------+
    """
    msg = Msg(raw_text, 'text/html')
    ps = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    
    result_text = next(iter(ps)).decode()
    assert result_text == raw_text

# Generated at 2022-06-12 00:02:23.695804
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(status_line=b'', content_type='text/plain', body='Hello\nWorld\n', encoding='utf8')
    
    stream = PrettyStream(msg,
                          with_headers=True,
                          with_body=True,
                          on_body_chunk_downloaded=None,
                          conversion=None,
                          formatting=None,
                          env=Environment())
    result = b''
    for chunk in stream.iter_body():
        result += chunk
    print(result)
    assert result == b'Hello\nWorld\n'


# Generated at 2022-06-12 00:02:34.321813
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    iter_body = PrettyStream.iter_body
    # Test that it returns the iterable self.msg.iter_lines(self.CHUNK_SIZE)
    from unittest.mock import patch
    from httpie.compat import BytesIO
    from . import messages as m
    msg = m.Message(body=BytesIO(b'body\n'))
    return_value = iter_body(PrettyStream(msg=msg))
    with patch('builtins.iter', return_value=return_value) as iter_:
        next(iter_body(PrettyStream(msg=msg)))
    iter_.assert_called_once_with(return_value)
    # Test that it raises BinarySuppressedError if the message is binary

# Generated at 2022-06-12 00:02:39.442654
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    text = '{"key1": 5, "key2": null, "key3": "value3", "key4": "val\ne"}'
    msg = HTTPMessage(text, headers={'Content-Type': 'application/json'})
    stream = PrettyStream(msg)
    assert stream.get_headers() == bytearray()

# Generated at 2022-06-12 00:02:46.511752
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # body = 'cat\0'
    # msg = HTTPMessage(body=body.encode(encoding='utf-8'),
    #    headers={'content-type': 'text/plain'})
    # stream = EncodedStream(msg)
    #
    # for chunk in stream.iter_body():
    #    print(chunk)

    msg = HTTPMessage(
        body='cat\0'.encode(encoding='utf-8'),
        headers={'content-type': 'text/plain'})
    stream = EncodedStream(msg)

    for chunk in stream.iter_body():
        print(chunk)


# Generated at 2022-06-12 00:02:53.520346
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class MockPrettyStream(PrettyStream):
        def __init__(self):
            super().__init__(None, None)

    msg = b'{"a":1,"b":2,"c":3,"d":4,"e":5}\n{"a":2,"b":3,"c":4,"d":5,"e":6}\n'
    msg = msg.decode('utf8').encode('utf8')
    prettify_stream = MockPrettyStream()
    result = prettify_stream.process_body(msg)
    assert result == msg

# Generated at 2022-06-12 00:03:03.626288
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # BaseStream.__init__
    # BaseStream.get_headers
    # BaseStream.iter_body
    # BaseStream.__iter__
    msg = HTTPMessage()
    msg.headers = "abcdefg"
    bs = BaseStream(msg=msg, with_headers=True, with_body=True)
    assert list(bs.__iter__()) == [b'abcdefg\r\n\r\n']
    msg.raw = b'1234'
    assert list(bs.__iter__()) == [b'abcdefg\r\n\r\n1234']

    # test with_headers
    bs = BaseStream(msg=msg, with_headers=True, with_body=False)

# Generated at 2022-06-12 00:03:53.096232
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse

    class FakeStream(object):
        def __init__(self, read):
            self.position = 0
            self.read = read

        def tell(self):
            return self.position

    # construct a HTTPResponse with encoding utf-8
    res = HTTPResponse(FakeStream(lambda length: "testutf8".encode('utf-8')), 200, '',
                       'HTTP/1.1', 'utf-8', '', '', '')
    # construct a HTTPResponse with encoding None
    res1 = HTTPResponse(FakeStream(lambda length: "test".encode('utf-8')), 200, '',
                        'HTTP/1.1', None, '', '', '')
    # construct a HTTPResponse

# Generated at 2022-06-12 00:04:02.206545
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers='', body='test body')

    # case 1: only with headers
    base = EncodedStream(msg, with_headers=True, with_body=False)
    body_gen = base.iter_body()
    assert next(body_gen) == None

    # case 2: with_body == True
    # body is binary so it should throw BinarySuppressedError exception
    base = EncodedStream(msg, with_headers=False, with_body=True)
    body_gen = base.iter_body()
    with pytest.raises(BinarySuppressedError):
        next(body_gen)

    # case 3: with_body == True
    # body is not binary it should return body as str
    msg = HTTPMessage(headers='', body='test body')
    base = Enc

# Generated at 2022-06-12 00:04:05.803888
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()
    msg.body = "body"
    msg.headers ="header"
    msg.content_type = 'application/json'
    stream = BufferedPrettyStream(msg=msg)
    assert "body" in stream.iter_body()

# Generated at 2022-06-12 00:04:15.491540
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nHello World...!\nHello World...!\nHello World...!\nHello World...!', None)
    prettifier = PrettyStream(msg, True, True)
    prettifier.mime = 'text/plain'
    prettifier.output_encoding = 'utf8'
    prettifier.formatting.body_cols = 80
    prettifier.formatting.colors = False

    class MockFormatting:
        def format_body(self, content, mime):
            return '*' * 20 + content + '*' * 20

    prettifier.formatting = MockFormatting()

    for chunk in prettifier.iter_body():
        print(chunk)

# Generated at 2022-06-12 00:04:24.215326
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # check if this method can handle HTTP status code 204
    from httpie.input import ParseError
    from httpie.models import HTTP_STATUS_MAP
    from httpie.output.streams import BufferedPrettyStream
    from httpie.utils import struct
    from pygments.lexer import Lexer
    from pygments.token import Token
    from pygments.util import ClassNotFound
    from mock import sentinel


# Generated at 2022-06-12 00:04:25.132133
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pass


# Generated at 2022-06-12 00:04:30.981167
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage.from_parts('', '', headers=None,
                                 body=b'1234567890',
                                 content_type='text/plain',
                                 encoding='utf-8')
    raw_stream = RawStream(msg)
    body = b''.join(raw_stream.iter_body())
    assert body == b'1234567890', 'RawStream.iter_body failed'



# Generated at 2022-06-12 00:04:40.738522
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import pytest
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output import format_body
    from httpie.output.formatters.json import JSONFormatter

    class MockJSONFormatter(JSONFormatter):
        def __init__(self, *args, **kwargs):
            pass

        def dumps(self, data):
            return '{"foo": "bar"}'

    class MockConversion:
        def get_converter(mime):
            return None

    class MockFormatting:
        def format_body(content, mime):
            return content

    msg = HTTPMessage(body='{"foo": "bar"}')


# Generated at 2022-06-12 00:04:52.721932
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import httpie
    from httpie.models import Response
    from httpie.output.streams import EncodedStream
    response = Response(
        'HTTP/1.1 200 OK',
        httpie.CompressedResponseHeaders(
            headers=httpie.Headers(
                'Content-Type: application/json',
                'Content-Length: ' + str(len('[]'))
            ),
            compress_encodings=['gzip']
        ),
        b'[]',
        httpie.DEFAULT_HTTP_VERSION,
        close=False
    )
    encodedStream = EncodedStream(msg=response)
    assert encodedStream.msg == response
    assert encodedStream.with_headers == True
    assert encodedStream.with_body == True
    assert encodedStream.on_body_chunk_downloaded == None



# Generated at 2022-06-12 00:05:02.277031
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # since there is no way to get a real http message,
    # we resort to get it through HTTPie
    from httpie.core import main as httpie
    from httpie.cli.parser import parse_args
    from httpie.input.streams import RawBytesStreamer
    from httpie.output.streams import BufferedPrettyStream

    # class BufferedPrettyStream
    msg1 = httpie(parse_args(['http://httpbin.org/get'])).run([])[0]

    # class RawBytesStreamer
    msg2 = RawBytesStreamer(msg1.raw.encode('utf8'))

    # class BufferedPrettyStream
    # body = b'{"args": {}, "headers": {"Accept": "application/json", "Host": "httpbin.org", "User-Agent": "HTTPie/3.3.1

# Generated at 2022-06-12 00:06:22.136650
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert 1 == 1

# Generated at 2022-06-12 00:06:31.430655
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
	test_input.encoding = 'ascii'
	test_input.headers = '{"ascii": "abc"}'
	test_input.iter_lines = b'abc'

	test_env = Environment()
	test_env.stdout_isatty = True
	test_env.stdout_encoding = 'utf-8'

	test_output = EncodedStream(
		msg=test_input,
		with_headers=True,
		with_body=True,
		env=test_env)

	assert test_output.output_encoding == 'utf-8'



# Generated at 2022-06-12 00:06:38.439478
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    header_dict = {"headers": "value1", "header2": "value2"}
    header_response = HTTPMessage(headers=header_dict, encoding='utf8')
    stream = PrettyStream(
        msg=header_response,
        conversion=Conversion(None),
        formatting=Formatting(False, True),
        with_headers=True,
        with_body=False,
    )
    pretty_header = stream.get_headers()
    assert pretty_header == b"headers: value1\r\nheader2: value2\r\n\r\n"


# Generated at 2022-06-12 00:06:40.756559
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    p = PrettyStream(msg = HTTPMessage(headers = u'HTTP 1.1 200 OK'))
    assert p.get_headers() == b'HTTP 1.1 200 OK'


# Generated at 2022-06-12 00:06:45.905563
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test the body is processed before yielding
    test_object=BufferedPrettyStream(msg=HTTPMessage(
        request=None,
        encoding='utf-8',
        headers={},
        body=b'hello'
    ))
    for chunk in test_object.iter_body():
        assert chunk == b'hello'


# Generated at 2022-06-12 00:06:50.168948
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage()
    stream = PrettyStream(msg)
    msg.headers = "Date: Sun, 10 May 2020 11:22:33 GMT\n"
    assert stream.get_headers() == "Date: Sun, 10 May 2020 11:22:33 GMT\r\n\r\n".encode('utf8')


# Generated at 2022-06-12 00:06:53.115535
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    ps = PrettyStream(
        None, None,
        msg=HTTPMessage('', '', '', 0),
        with_headers=False, with_body=True
    )

    body = 'a simple message'
    assert ps.process_body(body) == 'a simple message'

# Generated at 2022-06-12 00:06:58.022299
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage, Headers

    msg = HTTPMessage(
        headers=Headers(content_type='application/json', method='GET'),
        body="{'something': 'nothing'}",
    )

    text = list(PrettyStream(msg, conversion=None, formatting=None))
    assert False


# Generated at 2022-06-12 00:07:06.200434
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    headers = httpie.models.Headers([('Content-Type', 'text/html')])
    msg = httpie.models.Response(
        httpie.models.Protocol(u'HTTP', 1, 1), 200,
        httpie.models.Reason(u'Ok'), headers, u'', None, None
    )
    body = '<html><head><title>Title</title></head><body><h1>H1</h1></body></html>'
    msg.content = body

    stream = PrettyStream(msg)
    assert stream.output_encoding == 'utf8'

    actual_body = ''
    for chunk in stream.iter_body():
        actual_body += chunk
    assert actual_body == body

# Generated at 2022-06-12 00:07:16.515217
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.processors import JSONProcessor
    from httpie.context import Environment

    class Dummy(BufferedPrettyStream):
        def process_body(self, chunk):
            return chunk

    class DummyMsg(HTTPResponse):
        headers = "Content-Type: application/json\r\n"
        encoding = "utf8"

        @property
        def body_chunk_downloaded_callback(self):
            return None
