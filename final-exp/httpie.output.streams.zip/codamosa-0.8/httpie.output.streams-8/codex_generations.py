

# Generated at 2022-06-11 23:58:56.813714
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    def get_headers_test(headers_string, expected_output_string):
        """
        This method test the get_headers method of class PrettyStream
        with the input headers_string and the expected output.
        """
        from httpie.input import ParseRequestHeaders

        from httpie.models import Headers

        from httpie.plugins import builtin

        from httpie.output.formatters.utils import get_formatter

        import os

        encoding = "utf8"

        # request_headers

# Generated at 2022-06-11 23:59:02.166198
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.encoding = "utf8"
    msg.content_type = "text/html; charset=utf8"

    body = "hello, world!"
    msg.body = body

    stream = BufferedPrettyStream(msg=msg)

    assert(next(stream.iter_body()) == b"hello, world!")

# Generated at 2022-06-11 23:59:10.712798
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-11 23:59:20.836283
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import io
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.raw import RawFormatter
    from httpie.context import Environment
    from httpie.output.formatters.colors import get_lexer

    msg = Response([], b'Hello\nWorld', 200, 'OK', headers={
        'Content-Type': 'text/plain'
    })

    stream = PrettyStream(
        msg=msg,
        conversion=None,
        formatting=RawFormatter(
            get_lexer(None, Environment())
        ),
        env=Environment()
    )

    out = io.BytesIO()
    out.write(b''.join(stream))

    out.seek(0)
    assert out.read() == b'Hello\nWorld'


# Generated at 2022-06-11 23:59:30.989581
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import io
    from httpie.models import HTTPMessage
    from httpie.output.streams import EncodedStream

    str_io = io.StringIO()
    msg = HTTPMessage(
        'HTTP/1.1 OK\r\nContent-Type: text/plain; charset=utf8\r\n'
        '\r\n\u2014\n',
        {'TERM': 'xterm'},
        str_io,
    )
    stream = EncodedStream(msg)
    for chunk in stream:
        str_io.write(chunk.decode('utf8'))
    # Assert that bytes are processed as a valid unicode string in terminal.
    assert str_io.getvalue() == '\u2014\n'

    str_io = io.StringIO()
    msg

# Generated at 2022-06-11 23:59:41.396959
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    body = b'\xef\xbb\xbf\xe5\xad\x97\xe7\xac\xa6\xe4\xb8\xb2\xe6\xa0\xbc\xe5\xbc'
    expected = b'\n\xef\xbb\xbf\xe5\xad\x97\xe7\xac\xa6\xe4\xb8\xb2\xe6\xa0\xbc\xe5\xbc'
    actual = PrettyStream(HTTPMessage(body=body), conversion=Conversion(), formatting=Formatting(),
                           with_headers=False, with_body=True, on_body_chunk_downloaded=None).process_body(body)
    assert expected == actual

# Generated at 2022-06-11 23:59:43.408449
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream()
    lines = stream.iter_body()
    assert isinstance(lines, Iterable)



# Generated at 2022-06-11 23:59:55.294836
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.output.__main__ import main as httpie
    from httpie.cli import parser
    import json
    import subprocess

    cmd = ['curl', '-s', 'http://httpbin.org/post', '-H', 'Content-Type: application/json', '-d', '{"foo": "bar", "baz": "qux"}']
    response_json = json.loads(subprocess.check_output(cmd).decode())
    response_json["json"]["baz"] = "qux2"
    response_json["json"]["hello"] = "there"
    response_json["json"]["welcome"] = "to json place"


# Generated at 2022-06-12 00:00:02.829502
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models.headers import Headers
    from httpie.output.streams import RawStream
    from httpie.output.utils import write_bytes

    headers = Headers(content_type='text/plain')
    headers = headers.encode('utf8')
    body = b"This is a sample response body, for testing purposes"

    def write_and_assert_writes_expected(stream, expected_bytes):
        bytes_written = 0
        for c in stream:
            bytes_written += write_bytes(c, stream_encoding='utf8',
                                         outfile=None)
        assert bytes_written == len(expected_bytes)


# Generated at 2022-06-12 00:00:13.095893
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import io
    import time
    import json
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.output.streams import BinarySuppressedError

    args = parser.parse_args(args=[
        '--json',
        '--pretty',
        'GET',
        'http://localhost:5000/todos'
    ])

    env = Environment(stdin=io.BytesIO(),
                      stdout=io.BytesIO(),
                      stderr=io.BytesIO(),
                      vars=vars(args))

    args.json = True

# Generated at 2022-06-12 00:00:34.768532
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    import httpie.plugins.json
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream

    json_data = {
        "name": "GPl0K0",
        "age": "18",
        "qq": "113456789",
        "test": [1, 2, 4]
    }

    terminal_size = 10
    message = HTTPResponse(content=json.dumps(json_data).encode())

    buffered_pretty_stream = BufferedPrettyStream(chunk_size=terminal_size, msg=message)
    print('{}'.format(buffered_pretty_stream))
    assert len(buffered_pretty_stream) == 10  #will error when the length is not 10.

    # INPUT:

# Generated at 2022-06-12 00:00:36.920929
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    bps = BufferedPrettyStream()
    assert bps == BufferedPrettyStream()

# Generated at 2022-06-12 00:00:41.776658
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    class MyMessage(HTTPMessage):
        pass
    msg = MyMessage(b'', headers=b'', content_type=None)
    stream = EncodedStream(msg, with_headers=True, with_body=False)
    assert stream.msg is msg
    assert stream.with_headers is True
    assert stream.with_body is False
    assert stream.output_encoding == 'utf8'

# Generated at 2022-06-12 00:00:48.507680
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    assert env.stdout_isatty
    assert env.stdout_encoding
    assert env.stdin_isatty
    assert env.stdin_encoding
    #assert not env.stdin_isatty
    #assert env.stdin_encoding
    #assert not env.is_windows
    assert env.is_windows
    #assert not env.unicode_support
    assert env.unicode_support

# Generated at 2022-06-12 00:01:00.125366
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import json
    import http
    import socket
    from httpie import headers
    from httpie.compat import urljoin
    from httpie import ExitStatus
    from utils import http, HTTP_OK, MockEnvironment
    httpie = http % (
            'GET',
            urljoin(
                'http://127.0.0.1:%s' % port,
                '/get'
            ),
            'test:test',
            'HTTP/1.1',
        )
    r = testdir.inline_run('--ignore-stdin', httpie)
    r.assert_exit_status(ExitStatus.OK)
    # We're in a testing environment, so no need to
    # duplicate the output (and noise).
    r.assert_silence()
    assert HTTP_OK in r.outlines

# Generated at 2022-06-12 00:01:07.535213
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Given
    response = make_response(
        status_code=200,
        content=b'{"hello":"world"}',
        encoding='utf8',
        content_type='application/json',
    )
    stream = PrettyStream(
        msg=response,
        conversion=Conversion(),
        formatting=Formatting(),
    )
    iterator = iter(stream)

    # When
    body = b''.join(iterator)

    # Then
    assert body == (
        b'{\n'
        b'    "hello": "world"\n'
        b'}\n'
    )



# Generated at 2022-06-12 00:01:16.342883
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test if the chunk is in bytes, the chunk will be decoded into string and then be encoded again
    # The condition is that the encoding format of chunk is the same as the output_encoding.
    x = PrettyStream(Conversion(), Formatting(), msg=HTTPMessage())
    x.output_encoding = 'utf8'
    assert x.process_body(b'test') == b'test'
    # If the chunk is a string, the chunk will be encoded into another format.
    x = PrettyStream(Conversion(), Formatting(), msg=HTTPMessage())
    x.output_encoding = 'utf8'
    assert x.process_body(str('test')) == b'test'

# Generated at 2022-06-12 00:01:27.744717
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BufferedPrettyStream, BaseStream, BufferedPrettyStream
    msg = HTTPRequest('GET', 'http://httpbin.org/get')
    msg.headers['Content-Type'] = 'application/json'
    msg.url = 'http://httpbin.org/get'
    msg.body = b'{"aaa":"bbb"}'
    # Change the headers
    msg.headers['a'] = 'b'
    msg.headers['a'] = 'b'
    msg.headers['a'] = 'b'
    msg.headers['a'] = 'c'
    # Change the body
    msg.body = b'{"aaa":"bbb"}'


# Generated at 2022-06-12 00:01:28.638829
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-12 00:01:36.217966
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    message = HTTPMessage(headers = "HTTP/1.1 200 OK\r\ndate: Sun, 19 Jan 2020 07:56:07 GMT\r\ncontent-type: text/plain; charset: utf-8\r\ncontent-length: 16\r\n\r\n", body = "test123test123", encoding = 'utf-8')
    p = PrettyStream(message, with_headers = True, with_body = True)
    count = 0
    for i in p.iter_body():
        count += 1
    assert count == 2, "The number of yields in PrettyStream.iter_body() should be 2"


# Generated at 2022-06-12 00:01:59.869490
# Unit test for constructor of class RawStream
def test_RawStream():
    pass


# Generated at 2022-06-12 00:02:03.917645
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage('HTTP/1.1', 200, '')
    msg.raw = b'HTTP/1.1 200 OK\r\n\r\n'
    r_stream = RawStream(msg)
    print(list(r_stream.iter_body()))


# Generated at 2022-06-12 00:02:14.121230
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg1 = HTTPMessage()
    msg2 = HTTPMessage()
    msg1.headers = "Header1"
    msg2.headers = "Header2"
    msg1.body = "Body1"
    msg2.body = "Body2"

    for msg in [msg1, msg2]:
        for with_headers in [True, False]:
            for with_body in [True, False]:
                with_headers_and_body = with_headers and with_body
                with pytest.raises(NotImplementedError):
                    BaseStream(
                        msg,
                        with_headers=with_headers,
                        with_body=with_body,
                    ).__iter__()

# Generated at 2022-06-12 00:02:27.167061
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPRequest, HTTPResponse
    import httpie.compat
    import httpie.output.streams

    # HTTPRequest
    stream = httpie.output.streams.RawStream(HTTPRequest(b'http://localhost/resources'))
    assert list(stream.iter_body()) == [b'http://localhost/resources']

    stream = httpie.output.streams.EncodedStream(HTTPRequest(b'http://localhost/resources'))
    assert list(stream.iter_body()) == [b'http://localhost/resources\r\n']

    # HTTPResponse
    stream = httpie.output.streams.RawStream(HTTPResponse(b'OK'))
    assert list(stream.iter_body()) == [b'OK']


# Generated at 2022-06-12 00:02:32.575572
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    stream = BaseStream(msg)
    stream.get_headers = lambda : b'Test get_headers'
    stream.iter_body = lambda : [b'Test iter_body']
    assert list(stream.__iter__()) == \
        [b'Test get_headers', b'\r\n\r\n', b'Test iter_body']


# Generated at 2022-06-12 00:02:42.981101
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import Request, Response
    import platform
    import re
    from tests.demo_responses import get_demo_response
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream

    response = EncodedStream(
        get_demo_response('test_EncodedStream_iter_body'),
        with_headers=False
    )

    lines = list()
    for line in response.iter_body():
        lines.append(line)
        
    response = get_demo_response('test_EncodedStream_iter_body')
    encodings = response.encoding
    body = response.text
    lines = body.encode(encodings, 'replace')
    
    return lines



# Generated at 2022-06-12 00:02:44.464662
# Unit test for constructor of class RawStream
def test_RawStream():
    # WHEN
    stream = RawStream()

    # THEN
    assert stream is not None



# Generated at 2022-06-12 00:02:46.723695
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print('test init EncodedStream:')
    print(EncodedStream)

if __name__ == '__main__':
    test_EncodedStream()

# Generated at 2022-06-12 00:02:54.763007
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\n" + msg.headers
    msg.content = b'a\0b\0c\0d\0'

    conversion = Conversion()
    conversion.get_converter_mapping = lambda: {'text/plain': 'repr'}
    formatted_stream = BufferedPrettyStream(conversion=conversion,
                                            formatting=Formatting(),
                                            msg=msg)

    # Suppresses binary output by replacing first binary chunk with <binary>
    assert list(formatted_stream.iter_body()) == [b"'<binary>'"]



# Generated at 2022-06-12 00:03:00.977627
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    """
    Unit test for method iter_body of class PrettyStream
    """
    env=Environment()
    msg=HTTPMessage(headers=None, body=[], encoding='utf-8')
    conversion=Conversion()
    formatting=Formatting()
    ps = PrettyStream(conversion=conversion, formatting=formatting, msg=msg, env=env)
    msg.encoding='utf-8'
    res=ps.iter_body()
    print(res)


# Generated at 2022-06-12 00:03:49.481906
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import http.client as http_client
    env = Environment()
    msg = http_client.HTTPResponse(env)
    a = EncodedStream(msg, env=env)
    assert a


# Generated at 2022-06-12 00:03:57.588747
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Check if BaseStream to works correctly
    # with no headers and body
    assert list(BaseStream(None).__iter__()) == []

    # Check if BaseStream to works correctly
    # with only headers and no body
    assert list(BaseStream(None, with_body=False).__iter__()) == []

    # Check if BaseStream to works correctly
    # with only body and no headers
    assert list(BaseStream(None, with_headers=False, with_body=True).__iter__()) == []

    # Check if BaseStream to works correctly
    # with body and headers
    assert list(BaseStream(None, with_headers=True, with_body=True).__iter__()) == []

# Generated at 2022-06-12 00:03:58.355225
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    assert True

# Generated at 2022-06-12 00:03:59.328281
# Unit test for constructor of class RawStream
def test_RawStream():
    assert RawStream  


# Generated at 2022-06-12 00:04:08.756482
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg1 = HTTPMessage()
    msg1.headers = "HTTP/1.0 200 OK\r\nContent-Type: application/json\r\n\r\n"
    headers = PrettyStream.get_headers(msg1)
    assert headers == b"HTTP/1.0 200 OK\r\nContent-Type: application/json\r\n\r\n"

    msg2 = HTTPMessage()
    msg2.headers = "HTTP/1.0 200 OK\r\n\r\n"
    headers = PrettyStream.get_headers(msg2)
    assert headers == b"HTTP/1.0 200 OK\r\n\r\n"

    msg3 = HTTPMessage()

# Generated at 2022-06-12 00:04:10.473840
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    print(BaseStream._BaseStream__iter__(msg))

# Generated at 2022-06-12 00:04:18.411575
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.formatters import Formatter
    from httpie.output.formatters.colors import NullColors

    formatter = Formatter(colors=NullColors(),
                            indent=None,
                            max_json_depth=None,
                            ssl_verify=False)
    stream = PrettyStream(conversion='', formatting=formatter, msg=None, with_headers=None, with_body=None,
                          on_body_chunk_downloaded=None)
    assert stream.process_body(b'{"key": "value"}') == b'{\n    "key": "value"\n}\n'

# Generated at 2022-06-12 00:04:25.811062
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # given
    class Test_HTTPMessage(HTTPMessage):
        def __init__(self, body):
            super().__init__()
            self.body = body
        def iter_body(self, chunk_size):
            # iterate body to given chunk size
            while self.body:
                chunk, self.body = self.body[:chunk_size], self.body[chunk_size:]
                yield chunk
    msg = Test_HTTPMessage(body=b"abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz")
    stream = RawStream(msg=msg, with_headers=False, with_body=True)

    # when

# Generated at 2022-06-12 00:04:36.560390
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import (
        AsyncResponse,
        Response,
        Request,
    )
    from collections import deque
    import json
    # Test chunking algorithm
    body = '{"test": "json"}'
    d = deque(['{"test": ', '"json"}'])
    assert BufferedPrettyStream(
        None, None,
        msg=Response(
            status=None,
            headers=None,
            body=body,
            encoding=None,
            ctime=None,
            elapsed=None,
            request=Request(),
        ),
        with_headers=False,
        with_body=True,
    ).iter_body().__next__() == bytes(json.dumps(json.loads(body)), 'utf8')
    del d
    # Test chunking algorithm

# Generated at 2022-06-12 00:04:42.060666
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    req = HTTPMessage(
        body = 'body', 
        message = ''
        )
    print('运行test_RawStream_iter_body')
    rst = RawStream(msg=req)
    assert bytes(rst.iter_body().__next__()) == b'b'
    assert bytes(rst.iter_body().__next__()) == b'o'
    assert bytes(rst.iter_body().__next__()) == b'd'
    assert bytes(rst.iter_body().__next__()) == b'y'


# Generated at 2022-06-12 00:06:14.465545
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    import sys
    import io
    # save a copy of the existing stdout so I can restore it later
    stdout = sys.stdout

# Generated at 2022-06-12 00:06:23.984754
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """Test iter_body method of BufferedPrettyStream class.

    :return: None
    :raises: AssertionError
    """
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    fmt = Formatting()
    msg = Response(
        status_code=200,
        headers={'content-type': 'application/json'},
        content_type='application/json',
        body=b'\x00\x01\x02',
        encoding='utf8',
        content_encoding='utf8',
        error=None
    )

# Generated at 2022-06-12 00:06:29.215567
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    assert PrettyStream(None, None).process_body(b'\xAA\xBB\xCC\xDD\xEE') == b'\xAA\xBB\xCC\xDD'
    assert PrettyStream(None, None).process_body("\u0100\u0101") == b'\xc4\x80\xc4\x81'

# Generated at 2022-06-12 00:06:38.716167
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # fetch response body before prettifying it, but bail out immediately if the body is binary.
    buffered_pretty_stream_iter_body = BufferedPrettyStream(iter_body=None, msg='', conversion='', formatting='')

    #  if b'\0' in chunk:
    assert not buffered_pretty_stream_iter_body.iter_body('a')
    assert not buffered_pretty_stream_iter_body.iter_body('\0')
    assert buffered_pretty_stream_iter_body.iter_body('\0ac')
    assert buffered_pretty_stream_iter_body.iter_body('b\0c')

    # test else branch
    assert not buffered_pretty_stream_iter_body.iter_body('a\0')

# Generated at 2022-06-12 00:06:48.666535
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import Response, Headers
    headers = Headers(content_type='application/json')
    body = b'{"a": 1}'
    response = Response(headers, body)
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(response,conversion,formatting)
    # if the body is not a string and the mime is not supported by any
    # converter, the body should remain unchanged.
    chunk = b"a string (bytes)"
    assert stream.process_body(chunk) == chunk
    # if the body is a string the method should process it and convert it to
    # bytes.
    chunk = "a string (string)"
    assert stream.process_body(chunk) == b"a string (string)"



# Generated at 2022-06-12 00:06:53.667018
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    content_type = 'text/html; charset=utf-8'
    headers = '\n'.join(['HTTP/1.1 200 OK', content_type])
    body = '<h1>Test</h1>'
    msg = HTTPMessage(headers, body)
    pretty_stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    for chunk in pretty_stream.iter_body():
        print(repr(chunk))

# Generated at 2022-06-12 00:07:00.564582
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from test import http
    class MockResponse(Response):
        """"""
        def get_chunk_size(self):
            return 1
        def iter_lines(self, chunk_size):
            yield b'{"a":1,"b":2,"c":3,"d":4}', b'\r\n'

    response = MockResponse(
        'HTTP/1.1 200 OK',
        'application/json',
        'utf-8',
        b'{"a":1,"b":2,"c":3,"d":4}',
        None
    )
    stream = PrettyStream(
        response,
        conversion=None,
        formatting=None
    )
    print(list(stream.iter_body()))




# Generated at 2022-06-12 00:07:04.537420
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    PrettyStream
    msg_headers = {}
    msg_body = 'body'
    msg = HTTPMessage(msg_headers, msg_body)
    pretty_stream = PrettyStream(msg)
    assert isinstance(pretty_stream.process_body(pretty_stream.CHUNK_SIZE), bytes)


# Generated at 2022-06-12 00:07:14.098873
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage('GET / HTTP/1.1\r\nHost: localhost\r\n\r\n')
    msg.status_line = 'HTTP/1.1 200 OK'
    # msg.encoding = 'utf8'
    msg.encoding = 'utf-8'
    msg.content_type = 'text/html'
    msg.text = 'Ã¦Ã¸Ã¥'

    msg.body = msg.text.encode(msg.encoding)
    s = EncodedStream(msg)
    for i in s.iter_body():
        print(i)

test_EncodedStream_iter_body()

# Generated at 2022-06-12 00:07:17.596131
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg=HTTPMessage('\n some data\n  with \n lfs \n')
    msg.encoding='ascii'
    for i in EncodedStream(msg=msg).iter_body():
        assert i in [b'\n some data\n', b'  with \n', b' lfs \n']
