

# Generated at 2022-06-11 23:58:56.394212
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie import ExitStatus
    from httpie.downloads import StreamingSession
    from httpie.status import ExitStatus
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.output.streams import BaseStream, BufferedPrettyStream
    import pytest
    import requests
    import os
    import sys
    import tempfile
    # we are testing it is not binary
    raw_stream = RawStream(msg=HTTPMessage(encoding='utf-8'),with_headers=True, with_body=True) #get msg
    header_stream = raw_stream.get_headers()
    body_stream = raw_stream.iter_body()

# Generated at 2022-06-11 23:59:06.852034
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json
    import pygments
    import os
    env = os.environ.copy()
    env['HTTPIE_DISABLE_PYTHON_MIME_TYPES'] = "1"
    from httpie.cli import parser
    args = parser.parse_args(['--pretty=all'])
    args.print_stdout = True
    from httpie.output.streams import PrettyStream
    from httpie.plugins import builtin
    args.preview_size = 0
    env.update({'HTTPIE_COLORS': '', 'HTTPIE_STYLE': ''})
    output_options = vars(args)
    output_options.update({'stdout_isatty': True, 'color': False})
    env.update({'HTTPIE_COLORS': ''})

# Generated at 2022-06-11 23:59:09.296799
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print('Testing the constructor of EncodedStream...')
    stream = EncodedStream()
    print('Passed!')


# Generated at 2022-06-11 23:59:13.948042
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=["a: b"])
    stream = PrettyStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None, conversion=None, formatting=None)
    assert stream.get_headers() == b"a: b"

# Generated at 2022-06-11 23:59:23.233149
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import os
    import shutil

    def create_file(filename):
        if not os.path.exists(filename):
            with open(filename, 'w') as f:
                f.write('test')
                f.close()

    def delete_file(filename):
        if os.path.exists(filename):
            os.remove(filename)

    def read_lines(file_name):
        if os.path.exists(file_name):
            with open(file_name, 'r') as f:
                lines = f.readlines()
                f.close()
                return lines

    # setup
    test_dir = 'test_dir'
    test_file = 'test.txt'
    if not os.path.exists(test_dir):
        os.mkdir(test_dir)
   

# Generated at 2022-06-11 23:59:33.100161
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    def test_equal(a, b):
        if a != b:
            raise Exception("{} != {}".format(a, b))

    def test_iter_msg():
        msg = HTTPMessage()
        msg.headers["content-type"] = "text/plain"
        msg.set_body("abc")
        conv = Conversion()
        form = Formatting()
        stream = BufferedPrettyStream(msg, conversion=conv, formatting=form)
        test_equal(b"".join(stream.iter_body()), b"abc")

    def test_iter_msg_with_binary_content():
        msg = HTTPMessage()
        msg.headers["content-type"] = "text/plain"
        msg.set_body("abc\x00def")
        conv = Conversion()
        form = Formatting()


# Generated at 2022-06-11 23:59:41.786633
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Should have default values of with_headers and with_body
    assert EncodedStream(HTTPMessage(method='GET', body=b'SomeBody')).with_headers == True
    assert EncodedStream(HTTPMessage(method='GET', body=b'SomeBody')).with_body == True

    # Should support setting with_headers and with_body
    assert EncodedStream(HTTPMessage(method='GET', body=b'SomeBody'), with_headers=False).with_headers == False
    assert EncodedStream(HTTPMessage(method='GET', body=b'SomeBody'), with_body=False).with_body == False

# Generated at 2022-06-11 23:59:53.067756
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None, None, 0)
    msg = HTTPMessage(
        headers=b'content-type: text/html; charset="utf-8"' + b'\r\n' +
        b'headers: value' + b'\r\n' + b'headers: value' + b'\r\n',
        body=b'<p>\xe4\xb8\xad\xe6\x96\x87</p>',
        encoding='utf-8')
    stream.msg = msg
    result = stream.process_body(b'<p>\xe4\xb8\xad\xe6\x96\x87</p>')
    assert result == b'\xe4\xb8\xad\xe6\x96\x87'

# Generated at 2022-06-12 00:00:00.500461
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    headers = b"Content-Type: application/json\r\n" \
              b"Content-Length: 12\r\n" \
              b"X-Foo: Bar\r\n"
    stream = PrettyStream(
        HTTPMessage(headers),
        conversion=None,
        formatting=None,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )
    assert stream.get_headers() == headers



# Generated at 2022-06-12 00:00:12.198586
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(mock.Mock()).from_bytes(
        b'HTTP/1.1 200 OK\r\n'
        b'Content-Type: text/html; charset=utf-8\r\n'
        b'\r\n'
        b'<!DOCTYPE html>\r\n'
        b'<html>\r\n'
        b'<head>\r\n'
        b'<title>Title</title>\r\n'
        b'</head>\r\n'
        b'<body>\r\n'
        b'Body\r\n'
        b'</body>\r\n'
        b'</html>\r\n'
    )


# Generated at 2022-06-12 00:00:33.358519
# Unit test for method get_headers of class PrettyStream

# Generated at 2022-06-12 00:00:43.102983
# Unit test for method __iter__ of class BaseStream

# Generated at 2022-06-12 00:00:50.722139
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.compat import str
    from httpie.models import HTTPMessage
    from httpie.output.streams import EncodedStream

    http_message = HTTPMessage(headers='')
    http_message.encoding = 'utf8'
    httpMessage_iter_body = EncodedStream(msg=http_message).iter_body()
    for chunk in httpMessage_iter_body:
        if str(chunk) == 'b\'\'':
            assert True
            break
    else:
        assert False



# Generated at 2022-06-12 00:00:56.901280
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    #Test asserts that object of class EncodedStream is created without fail
    file = open('/home/mukul/PycharmProjects/Python/httpie-master/httpie/tests/data/headers.txt', encoding="utf-8")
    headers_text = file.read()
    file.close()
    msg = HTTPMessage(headers_text)
    stream = EncodedStream(msg)

# Generated at 2022-06-12 00:01:01.676820
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None, msg=None, with_headers=False, with_body=True)
    if stream.process_body("foo") == "foo":
        print("OK: class PrettyStream's method process_body is working properly")
    else:
        print("ERROR: class PrettyStream's method process_body is not working properly")

# Generated at 2022-06-12 00:01:08.789531
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.core import Body
    env = Environment(colors=False)
    conversion = Conversion(env)
    formatting = Formatting(env)
    msg = Body('{"hello":"world"}'.encode('utf8'), content_type="application/json")
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting, env=env)

    assert stream is not None

    output = b''
    for chunk in stream.iter_body():
        output += chunk

    expected = b'{\n    "hello": "world"\n}'
    assert expected == output


# Generated at 2022-06-12 00:01:13.564791
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers={"Content-Type": "text/plain; charset=utf8"}, body=b'\xa3')
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    assert next(stream.iter_body()) == b'\xc2\xa3'



# Generated at 2022-06-12 00:01:18.823881
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    #Arrangement
    content = b'{"a": "b", "b": "c", "c": "d"}'
    test_stream = EncodedStream(HTTPMessage(b"Content-Type: application/json\r\n\r\n" + content),
                                False, False)
    #Act
    result = test_stream.iter_body()
    #Assert
    assert list(result) == ['"{"a": "b", "b": "c", "c": "d"}"']


# Generated at 2022-06-12 00:01:26.795709
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class DummyMsg:
        def __init__(self):
            self.headers = "header"
            self.content_type = 'text/html'
            self.encoding = 'utf-8'
        def iter_lines(self, chunk_size):
            while True:
                yield "line", "lf"
    conversion = Conversion()
    formatting = Formatting()
    with pytest.raises(DataSuppressedError):
        i = iter(PrettyStream(
            msg = DummyMsg(),
            conversion = conversion,
            formatting = formatting,
        ))
        next(i)

# Generated at 2022-06-12 00:01:31.821268
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body="{\"name\":\"json_name\", \"id\":1}".encode('utf8')
    )
    raw_stream = RawStream(msg)
    actual = list(raw_stream.iter_body())
    expected = [b'{"name":"json_name", "id":1}']
    assert actual == expected

# Generated at 2022-06-12 00:02:03.244750
# Unit test for constructor of class RawStream
def test_RawStream():
    print("Start test_RawStream")
    msg = b"Hello World!"
    raw_stream = RawStream(msg, with_headers=True, with_body=True,
                           on_body_chunk_downloaded=None)
    print("\ntest_RawStream.get_headers()")
    print(raw_stream.get_headers())
    print("\ntest_RawStream.iter_body()")
    for chunk in raw_stream.iter_body():
        print(chunk)
    print("\ntest_RawStream.__iter__()")
    for chunk in raw_stream:
        print(chunk)



# Generated at 2022-06-12 00:02:05.416011
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    try:
        BaseStream.__iter__(object())
        assert False
    except NotImplementedError:
        assert True



# Generated at 2022-06-12 00:02:15.080983
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import io
    import pytest
    from httpie.context import Environment
    from httpie.input import ParseError
    from httpie.output.streams import EncodedStream
    from httpie.models import HTTPMessage, Response
    from httpie.parse import parse_response
    #from httpie.output.processing import Conversion, Formatting
    from httpie.downloads import Downloader
    from httpie.status import ExitStatus


    # 对于每行迭代，将每个源行作为一个字节串，如果换行符号不是回车换行，则将它添加到右边
   

# Generated at 2022-06-12 00:02:22.754302
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
  encoded = EncodedStream(
      msg=HTTPMessage(
          content_type='application/json',
          headers={'Content-Type': 'application/json'},
          body='{"a":1,"b":2}'),
      env=Environment(),
      with_body=True)

  assert encoded.get_headers() == b'Content-Type: application/json\r\n'

  assert b''.join(encoded.iter_body()) == b'{"a":1,"b":2}'


# Generated at 2022-06-12 00:02:33.932340
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.compat import is_windows
    from httpie.input import SEP_CREDENTIALS
    from httpie.models import HTTPRequest
    import unittest
    import os
    import warnings
    import tempfile
    import shutil

    class BaseTestPrettyStream(unittest.TestCase):

        """
        Base class for HTTP requests tests.
        """

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-12 00:02:35.059810
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    assert 1 == 2


# Generated at 2022-06-12 00:02:44.968413
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.compat import is_py3
    ht = HTTPMessage(url="", status="", headers="", body=b"<body>\n<body>")
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(conversion = conversion,
                          formatting = formatting,
                          encoding = "utf8",
                          msg=ht,
                          on_body_chunk_downloaded = None)
    body = stream.process_body(b"<body>\r\n<body>")
    if is_py3:
        assert body == b"<body>\r\n<body>"
    else:
        assert body == b

# Generated at 2022-06-12 00:02:54.797971
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class MockHTTPMessage(HTTPMessage):
        def __init__(self, headers, body, encoding):
            self.headers = headers
            self.body = body
            self.encoding = encoding

        def iter_body(self, chunk_size):
            for chunk in [self.body[start:start+chunk_size] for start in range(0, len(self.body), chunk_size)]:
                yield chunk, b'\r\n'

        def content_type(self):
            return 'text/html; charset=gbk'

    message = '我们。😀'.encode('gbk')
    stream = EncodedStream(MockHTTPMessage('', message, 'gbk'))
    result = b''.join(stream.__iter__())

# Generated at 2022-06-12 00:03:05.413326
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from requests import Response
    from httpie.compat import urlencode
    from httpie.downloads import ResponseReader
    from httpie.output.streams import PrettyStream
    # Test case
    # status = 400,
    # headers = {'content-type': 'application/json',
    #            'x-foo': 'bar'},
    # body = {'message': 'foo bar'})
    body = urlencode({'message': 'foo bar'})
    body = body.encode('utf8')
    response_headers = {
        'content-type': 'application/json',
        'x-foo': 'bar'
    }
    response = Response()
    response.status_code = 400
    response.headers = response_headers
    response.raw = ResponseReader(BytesIO(body), stream=False)


# Generated at 2022-06-12 00:03:13.079634
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Request, Response
    from httpie.downloads import ResponseDownloader
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from io import BytesIO
    import os
    import pandas as pd
    import yaml
    import json
    import re

    # Get the absolute path to the directory that contains this file.
    my_dir = os.path.dirname(os.path.abspath(__file__))

    # Get the absolute path to the file 'output_processing.yaml' located under test/
    filename = os.path.join(my_dir, 'output_processing.yaml')

    # Read the file
    with open(filename, 'r') as stream:
        test_cases = y

# Generated at 2022-06-12 00:03:45.286424
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Create a message to stream
    msg = HTTPMessage()
    msg.headers = 'Fake Header'
    msg.body = ('This is the first binary byte\x00\n'
                'This is the second binary byte\x00\n'
                'This is the third binary byte\x00\n'
                'This is the version to process\n')

    # Create an instance of the class to stream the message
    stream = BufferedPrettyStream(msg=msg)

    # Read the stream
    for line in stream:
        pass

    # Check the stream
    assert line == b'This is the version to process\n'

# Generated at 2022-06-12 00:03:50.154436
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import re
    pretty_stream = PrettyStream(msg=None, conversion=None, formatting=None)

    if isinstance(pretty_stream.process_body("test"), bytes):
        return True
    else:
        return False



# Generated at 2022-06-12 00:03:52.081690
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    with pytest.raises(NotImplementedError):
        for _ in BaseStream(None, None, None)():
            pass

# Generated at 2022-06-12 00:04:00.891265
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # arrange
    class Request:
        def __init__(self):
            self.headers = "text/html, application/xhtml+xml, application/xml,application/json"
            self.encoding = "utf8"
            self.content_type = 'application/json; charset=utf8'
        def iter_lines(self,chunk_size):
            yield from "some text\n ".encode(self.encoding)
    stream = BufferedPrettyStream(
        msg=Request(),
        conversion=Conversion(),
        formatting=Formatting(
            colors={'*': 'red'}
        )
    )
    result = []
    # act
    for chunk in stream.iter_body():
        result.append(chunk)
    # assert
    assert len(result) == 1

# Generated at 2022-06-12 00:04:05.969018
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    assert b'{"abcd": "abcd"}' == b''.join(EncodedStream(msg=None, with_headers=False, with_body=True).iter_body(b'{"abcd": "abcd"}'))
    assert b'test' == b''.join(EncodedStream(msg=None, with_headers=False, with_body=True).iter_body(b'test'))

# Generated at 2022-06-12 00:04:15.626267
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert BaseStream(HTTPMessage(b'123', b'content-type:a/b'),with_headers=True,with_body=True,on_body_chunk_downloaded=None).__iter__() == [b'123\r\ncontent-type:a/b',b'\r\n\r\n']
    assert BaseStream(HTTPMessage(b'123', b'content-type:a/b'),with_headers=False,with_body=True,on_body_chunk_downloaded=None).__iter__() == []

# Generated at 2022-06-12 00:04:20.458030
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    _msg = HTTPMessage(1, 2, 3, 4, 5, 6, 7)
    _env = Environment(8, 9, 10, 11)
    _on_body_chunk_downloaded = Callable[[bytes], None]
    EncodedStream(_msg, _env, 12, 13, _on_body_chunk_downloaded)



# Generated at 2022-06-12 00:04:23.666126
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'0123456789')
    stream = RawStream(msg=msg)
    stream.CHUNK_SIZE = 3
    assert [b'012', b'345', b'678', b'9'] == list(stream.iter_body())

# Generated at 2022-06-12 00:04:25.212252
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    print()
    bs = BaseStream(None, True, True)
    assert bs.__iter__() is None

# Generated at 2022-06-12 00:04:35.883967
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.output.streams import PrettyStream, HTTPMessage
    from httpie.output.processing.formatters import BaseFormatter

    class MockFormatter(BaseFormatter):
        def __init__(self):
            self.prettified_chunks = []
            self.formatted_headers = ''

        def format_body(self, content: str, mime: str) -> str:
            self.prettified_chunks.append(content)
            return content

        def format_headers(self, headers: str) -> str:
            self.formatted_headers = headers
            return headers


# Generated at 2022-06-12 00:05:26.686274
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert isinstance(BaseStream.__iter__, Iterable)

# Generated at 2022-06-12 00:05:32.686945
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    f = EncodedStream('msg','with_headers','with_body','on_body_chunk_downloaded')
    assert f.msg == 'msg'
    assert f.with_headers == 'with_headers'
    assert f.with_body == 'with_body'
    assert f.on_body_chunk_downloaded == 'on_body_chunk_downloaded'
    #CHUNK_SIZE_BY_LINE = 1


# Generated at 2022-06-12 00:05:37.683491
# Unit test for constructor of class RawStream
def test_RawStream():
    request = HTTPMessage()
    request.headers = 'Content-Type: application/json'
    request._body = '{"id": 1}'

    rawstream = RawStream(request, with_headers=True, with_body=True)
    assert rawstream.CHUNK_SIZE == 10240

    assert rawstream.get_headers() == b'Content-Type: application/json'
    assert rawstream.iter_body() is not None



# Generated at 2022-06-12 00:05:46.482473
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class FakeHTTPMessage:
        def __init__(self, body_chunks):
            self.headers = None
            self.content_type = "text/html"
            self.encoding = "utf-8"
            self._body_chunks = body_chunks

        def iter_body(self, chunk_size):
            return self._body_chunks

    # No control characters in body
    msg = FakeHTTPMessage([b"this is ", b"a test"])
    s = BufferedPrettyStream(msg, with_headers=False, with_body=True)
    actual = list(s)
    assert actual == [b'<pre>this is a test</pre>']

    # Control characters in body
    msg = FakeHTTPMessage([b"this is \0", b"a test"])


# Generated at 2022-06-12 00:05:56.498433
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    myurl = "https://www.google.com"
    myreq = urllib.request.Request(myurl, headers={'User-Agent': 'Mozilla/5.0'})
    mypage = urllib.request.urlopen(myreq)
    # for mypage in urllib.request.urlopen(myreq).readlines():
    #     print(mypage.decode('utf8'))

    #binary_response_stream=RawStream(msg=mypage)
    #for m in binary_response_stream:
    #    print(m)

    pStream = BufferedPrettyStream(msg=mypage, conversion=Conversion(), formatting=Formatting())
    for m in pStream:
        print(m)


if __name__ == "__main__":
    test_BufferedPrettyStream()

# Generated at 2022-06-12 00:06:03.266727
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class MIMENonText(HTTPMessage):
        """A non-text message"""

        @property
        def content_type(self):
            return "application/json"

        def iter_body(self, chunk_size):
            for i in range(0, 100, chunk_size):
                chunk = "".join(str(i) for i in range(i, i+chunk_size))
                yield chunk

    class MIMEPlain(MIMENonText):
        """A text/plain message"""

        @property
        def content_type(self):
            return "text/plain"

    class MIMEJSON(MIMENonText):
        """A message with content type containing json"""

        @property
        def content_type(self):
            return "application/json; charset=utf-8"

   

# Generated at 2022-06-12 00:06:05.288667
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    stream = EncodedStream(env=env, with_headers=True, with_body=True)
    assert stream

# Generated at 2022-06-12 00:06:12.557858
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.models import HTTPRequest
    from httpie.core import main
    from httpie.output.formatters import JSONFormatter
    from httpie.compat import str
    main(args=['-b', 'GET', 'http://httpbin.org/get'],)
    s = PrettyStream(
        msg=HTTPRequest(url='http://httpbin.org/get', method='get', headers={}, body=''),
        with_headers=False,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(JSONFormatter(indent=2))
    )
    stream = s.iter_body()
    for i in stream:
        print (str(i, 'utf8'))


# Generated at 2022-06-12 00:06:20.095606
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    rs = RawStream()
    test_string = b'It is the mark of an educated mind to be able to entertain a thought without accepting it.Aristotle'
    rs.msg = HTTPMessage(
        protocol="HTTP/1.1",
        status_code=200,
        headers={"Content-Type": "text/html", "Content-Length": "63"},
        body=test_string
    )
    for i in range(0, len(test_string), 10):
        assert next(rs.iter_body()) == test_string[i:i+10]


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 00:06:20.701477
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    assert 1 == 1

# Generated at 2022-06-12 00:08:03.542103
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    obj = EncodedStream(env=Environment(), msg=HTTPMessage("abcd"), with_headers=True, with_body=True,
                        on_body_chunk_downloaded=None)
    assert str(obj.get_headers())=='b\'abcd\''

# Generated at 2022-06-12 00:08:10.829766
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    content_type = 'application/json; charset=utf-8'
    message = {
        'headers': [
            ('content-type', content_type),
        ]
    }
    fake_msg = fakes.FakeHTTPMessage(message)
    conversion = Conversion(False)
    formatting = Formatting()
    body = '{"foo": "bar"}\r\n{"foo": "bar"}\r\n'
    fake_msg.body = body.encode('utf-8')
    pretty_stream = PrettyStream(fake_msg, True, True, conversion, formatting)
    pretty_stream_iter = pretty_stream.iter_body()

    result = ''.join([
        line.decode('utf-8') for line in pretty_stream_iter
        ])

    assert result == body


# Generated at 2022-06-12 00:08:20.418378
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    print("Testing iter_body of class PrettyStream...")
    from httpie.client import JSON_ACCEPT
    from httpie.context import Environment
    from httpie.models import HTTPResponse
    from httpie.plugins import registry
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream

    env = Environment(stdout=sys.stdout)
    registry.lookup_installed()
    conversion = Conversion(env, registry)
    formatting = Formatting(env)
    headers = 'Content-Type: application/json'
    res = HTTPResponse('GET', 200, headers, '{"name":"httpie"}\n')
    stream = PrettyStream(
        res, True, True, JSON_ACCEPT, conversion, formatting, env)

# Generated at 2022-06-12 00:08:26.890402
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    stream = EncodedStream(msg)
    stream.msg = msg
    stream.output_encoding = msg.encoding
    stream.CHUNK_SIZE = 1
    msg.iter_body(stream.CHUNK_SIZE)
    stream.get_headers()
    for line, lf in msg.iter_lines(stream.CHUNK_SIZE):
        if b'\0' in line:
            raise BinarySuppressedError()
        line.decode(msg.encoding) \
            .encode(stream.output_encoding, 'replace') + lf


# Generated at 2022-06-12 00:08:29.639959
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.input import ParseError
    try:
        HTTPRequest('GET https://httpbin.org/get')
        HTTPResponse([])
    except ParseError:
        pass

# Generated at 2022-06-12 00:08:39.361429
# Unit test for constructor of class RawStream
def test_RawStream():
    # Constructor needs 3 args
    try:
        a = RawStream()
    except TypeError:
        pass

    a = RawStream(None)
    assert a is not None
    assert a.msg is None
    assert a.with_headers is True
    assert a.with_body is True
    assert a.on_body_chunk_downloaded is None
    assert a.chunk_size is 100*1024

    a = RawStream(None, False)
    assert a is not None
    assert a.msg is None
    assert a.with_headers is False
    assert a.with_body is True
    assert a.on_body_chunk_downloaded is None
    assert a.chunk_size is 100*1024

    a = RawStream(None, False, False)
    assert a is not None
    assert a