

# Generated at 2022-06-11 23:58:57.308518
# Unit test for constructor of class RawStream
def test_RawStream():
    from httpie.models import HTTPResponse
    response = HTTPResponse(
        'HTTP/1.1 200 OK',
        '',
        'utf-8',
        {},
        ''
    )
    assert isinstance(response, HTTPResponse)
    r_stream = RawStream(response)
    assert isinstance(r_stream, RawStream)



# Generated at 2022-06-11 23:59:07.668350
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test case: Body is not binary
    class Msg(object):
        def __init__(self, content_type = 'application/json',
                     encoding = 'utf-8'):
            self.content_type = content_type
            self.encoding = encoding

        def iter_body(self, chunk_size):
            yield b'{"key": "value"}'

    # Test case: Body is binary and has no converter
    class Msg2(object):
        def __init__(self, content_type = '',
                     encoding = 'utf-8'):
            self.content_type = content_type
            self.encoding = encoding

        def iter_body(self, chunk_size):
            yield b'binary body'

    # Test case: Body is binary and has a converter

# Generated at 2022-06-11 23:59:11.257655
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(msg="test", conversion=None, formatting=None)
    if stream.process_body("Hello"):
        assert True
    else:
        assert False


# Generated at 2022-06-11 23:59:13.641673
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    a = PrettyStream(None, None, None, None)
    a.msg = "abc"
    assert a.get_headers() == b"abc"

# Generated at 2022-06-11 23:59:23.000310
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    test_env = Environment()
    test_request = HTTPMessage(method='GET', url='http://localhost')
    test_request.headers['RequestHeader'] = 'RequestValue'
    test_request = EncodedStream(
        msg=test_request, env=test_env, with_headers=True, with_body=True)
    test_response = HTTPMessage(method='GET', url='http://localhost',
                                headers={'ResponseHeader': 'ResponseValue'},
                                body='response')
    test_response = EncodedStream(
        msg=test_response, env=test_env, with_headers=True, with_body=True)

# Generated at 2022-06-11 23:59:32.946689
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import Response
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import DataSuppressedError
    from httpie.context import Environment

    print('Testing constructor of class EncodedStream')

    """The message bytes are converted to an encoding suitable for
    self.env.stdout. Unicode errors are replaced and binary data
    is suppressed. The body is always streamed by line.
    """

    # Case1: when the stdout is a tty, the output_encoding should be
    # the encoding supported by the terminal
    env_case1 = Environment(stdout_isatty=True, stdout_encoding='utf8')
    assert EncodedStream(msg=Response(), env=env_case1).output_encoding == 'utf8'

    # Case2: when the stdout is

# Generated at 2022-06-11 23:59:43.110125
# Unit test for constructor of class PrettyStream
def test_PrettyStream():

    from httpie import ExitStatus
    from httpie.models import Request
    from httpie.config import Config
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import PRETTY_COLORS
    from httpie.plugins import plugin_manager
    from httpie.context import Environment
    from httpie.output.formatters import JsonFormatter, VerboseFormatter
    from httpie.output.processing import Conversion, Formatting

    body = '{"message": "Hello world!"}'
    headers = {'Content-Type': 'application/json', 'Content-Length': len(body)}

    msg = Request(method='GET', url='https://httpbin.org/get', headers=headers,
                  body='{"message": "Hello world!"}')

    config = Config()
    config.col

# Generated at 2022-06-11 23:59:44.337842
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print(EncodedStream())

# Generated at 2022-06-11 23:59:55.917816
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    msg = HTTPMessage()
    # print(msg.__dict__)
    # print(msg.__class__)
    # print(msg.headers)
    # print(msg.body)
    # print(env.__dict__)
    # print(env.__class__)
    # print(env.stdout_isatty)
    # print(env.stdout_encoding)
    stream = BaseStream(msg=msg, with_headers=True, with_body=True)
    # print(stream.__dict__)
    # print(stream.__class__)
    # print(stream.with_headers)
    # print(stream.with_body)
    # print(stream.get_headers())
    # print(stream.iter_body())

# Generated at 2022-06-11 23:59:59.335212
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    r = RawStream(msg={'body': '123456789', 'headers': 'Content-Type: txt/plan'})
    res = ''
    for i in r.iter_body():
        res += i
    print(res)


# Generated at 2022-06-12 00:00:12.531456
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import munch
    msg = munch.Munch(
        headers=munch.Munch(encoding = 'utf-8'),
        content_type='text/plain',
        iter_body=lambda x: "Hello World".encode('utf-8').split(bytes(x)),

    )
    p = BufferedPrettyStream(msg=msg, with_headers=True, with_body=True)
    assert b'Hello World'.decode('utf-8') == p.iter_body().__next__().decode('utf-8')


# Generated at 2022-06-12 00:00:18.008472
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    """
    test for PrettyStream.
    """
    env = Environment()
    msg = HTTPMessage(headers="Content-Type: text/plain; boundary=123".encode('utf8'),
                      body="""--123
Content-Type: text/plain

test123
""".encode('utf8'))

    s = PrettyStream(msg=msg, env=env)
    print(s.output_encoding)
    print(s.CHUNK_SIZE)
    # for i in s.iter_body():
    #     print(i)
    # print(s.msg.encoding)
    # print(s.output_encoding)


if __name__ == '__main__':
    test_PrettyStream()

# Generated at 2022-06-12 00:00:25.376320
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage(
        method='GET',
        url='http://httpbin.org/get',
        headers={'Content-Type':'application/json'},
        body=b'{"foo": "bar"}'
    )
    def f(chunk):
        if b'\0' in chunk:
            raise BinarySuppressedError()
    pretty_stream = BufferedPrettyStream(
        msg=msg,
        on_body_chunk_downloaded=f
    )
    for chunk in pretty_stream.iter_body():
        assert chunk is not None

# Generated at 2022-06-12 00:00:35.943362
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.processing import StreamFormatting
    class TestResponse(Response):
        def __init__(self, body_strr):
            self.headers = b"HTTP/1.1 200 OK\r\n"
            self.body = body_strr.encode()
            self.content_type = 'text/html;charset=utf-8'
            self.encoding = 'utf-8'
            self.trailers = b''
            self.status_line = b'HTTP/1.1 200 OK'

# Generated at 2022-06-12 00:00:44.090010
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Init
    conversion = Conversion()
    formatting = Formatting()
    headers = {'Content-Type': 'application/json'}
    msg = HTTPMessage(headers=headers, body=b'{"foo":"bar"}')
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting, with_headers=False, with_body=False)
    # Test with a string
    chunk = '{"foo":"bar"}'
    assert stream.process_body(chunk) == b'{\n    "foo": "bar"\n}'
    # Test with bytes
    chunk = b'{"foo":"bar"}'
    assert stream.process_body(chunk) == b'{\n    "foo": "bar"\n}'

# Generated at 2022-06-12 00:00:46.434262
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    stream = EncodedStream(env)
    assert stream.output_encoding == env.stdout_encoding or 'utf8'

# Generated at 2022-06-12 00:00:54.343151
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    #  asumption: go through all branches
    EncodedStream(msg, with_headers, with_body,
            on_body_chunk_downloaded).__init__(msg, with_headers, with_body,
            on_body_chunk_downloaded)



# Generated at 2022-06-12 00:01:04.441241
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from unittest import TestCase
    from httpie.models import Request, Response, Address

    http_version = "HTTP/1.1"
    method = "GET"
    connection_token = "Connection"
    connection_value = "keep-alive"
    content_type_token = "Content-Type"
    content_type_value = "application/json"
    status_code = 200
    content = "Hello World!"

    class MockEnvironment:
        def __init__(self):
            self.stdout_isatty = True
            self.stdout_encoding = "utf8"
            self.is_windows = True

    class MockConversion:
        def __init__(self):
            self.mime = content_type_value


# Generated at 2022-06-12 00:01:14.893571
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import io
    import httpie.input
    import httpie.models

    msg = httpie.models.HTTPMessage(
        httpie.input.Message(
            b'', headers=b'foo:bar\r\ncontent-type:text/plain\r\n\r\n'))

    stream = BufferedPrettyStream(
        msg,
        conversion=httpie.output.Conversion(),
        formatting=httpie.output.Formatting(),
        with_body=True,
        with_headers=False,
        env=Environment())

    body = bytearray()
    for chunk in stream.iter_body():
        body.extend(chunk)
    assert body.decode() == '\x1b[4m{\n    "foo": "bar"\n}\x1b[0m'

# Generated at 2022-06-12 00:01:18.008784
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    http_msg = BaseStream(env, msg=HTTPMessage(headers=[]))

# Generated at 2022-06-12 00:01:43.128940
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Set the argument
    headers = {
        'Content-Type': 'application/xml'
    }
    msg = httpie.models.HTTPResponse(
        request_url='http://example.com',
        status=200,
        headers=httpie.models.Headers(headers),
        body=b'<html></html>'
    )
    conversion = httpie.output.processing.Conversion()
    formatting = httpie.output.formatting.Formatter()
    # Execute assert
    stream = httpie.output.streams.PrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting
    )
    print(stream.msg.headers)

if __name__ == '__main__':
    test_PrettyStream()

# Generated at 2022-06-12 00:01:45.453773
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == "utf8"


# Generated at 2022-06-12 00:01:53.166867
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'Content-Type: text/html; charset=utf-8' \
                  'Connection: close' \
                  '<html><body>example</body></html>'

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    ps = PrettyStream(msg=msg, env=env, with_headers=True, with_body=False)
    result = ps.get_headers()
    assert type(result) == bytes


# Generated at 2022-06-12 00:01:56.830451
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    resp = HTTPMessage()
    resp.headers['Content-Type'] = 'image/png'
    assert PrettyStream(resp, conversion= Conversion(), formatting = Formatting()).get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: image/png\r\n\r\n'

# Generated at 2022-06-12 00:02:02.977016
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    test_line = b'{"msg": "hello"}\n'
    test_msg = HTTPMessage(body=test_line)
    test_stream = PrettyStream(msg=test_msg)

    line, lf = test_stream.iter_body().__next__()
    assert line == b'{\n    "msg": "hello"\n}'
    assert lf == b'\n'



# Generated at 2022-06-12 00:02:13.293021
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class my_HTTPMessage:
        headers ='400 Bad Request'
        content_type = 'text/csv'
        def iter_body(self, chunk_size = 1024*100):
            headers = bytes( '400 Bad Request', encoding='utf-8')
            body = bytes('a,b,c\r\n1,2,3', encoding='utf-8')
            yield headers
            yield body
        def iter_lines(self, chunk_size = 1):
            headers = bytes( '400 Bad Request', encoding='utf-8')
            body = bytes('a,b,c\r\n1,2,3', encoding='utf-8')
            for line in (headers,body):
                yield line,'\r\n'

    msg = my_HTTPMessage()
    env= Environment()
    conversion= Conversion

# Generated at 2022-06-12 00:02:25.110336
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    import json
    import jsonpath

    # Create the object for HTTP request
    h1 = HTTPMessage('GET', 'http://127.0.0.1:5000/api/v1/restaurants')

    h1.headers['Content-Type'] = 'application/json'
    h1.headers['Accept'] = 'application/json'

# Generated at 2022-06-12 00:02:34.419001
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    '''This function tests the iter_body method of class EncodedStream, and it will print
    the decoded body of the message
    '''
    # Testing for a byte string
    byte_string = b'abcdefg\000'
    name = 'Content-Type'
    value = 'application/json; charset=UTF-8'
    content = '{"d":"This is a byte string!"}'
    message = HTTPMessage(
        method=None,
        url=None,
        headers=Headers([(name, value)]),
        body=content,
        encoding=None
    )
    
    encoding = 'utf8'
    msg = EncodedStream(msg=message, with_headers=True, with_body=True,
    encoding=encoding)
    iter_msg = msg.iter_body()


# Generated at 2022-06-12 00:02:44.586203
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import BIN_FILE_PATH, BIN_FILE_CONTENT, BIN_FILE_PATH_ARG
    import pytest
    from json import JSONDecodeError
    # Defaults
    r = http('GET', HTTP_OK)
    assert HTTP_OK in r
    # --print=B
    r = http('GET', HTTP_OK, '--print=B')
    assert BIN_FILE_CONTENT in r
    # --print=b
    r = http('GET', HTTP_OK, '--print=b')
    assert BIN_FILE_CONTENT not in r
    assert '(binary data)' not in r
    # --print=H
    r = http('GET', HTTP_OK, '--print=H')

# Generated at 2022-06-12 00:02:54.484728
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import RawStream
    from httpie.status import ExitStatus
    from httpie.cli.argtypes import KeyValueArg
    from httpie.core import main
    from httpie.input import ParseError
    from httpie.compat import is_py26

    if is_py26:
        return


# Generated at 2022-06-12 00:03:31.144538
# Unit test for constructor of class RawStream
def test_RawStream():
    class HTTPMessage:
        def iter_body(self, chunk_size):
            for _ in range(3):
                yield b'chunk_size'
    msg = HTTPMessage()
    res = RawStream(msg, with_headers=True, with_body=True)
    assert b''.join(res) == b'chunk_size' * 3
    assert b'+'.join(res.iter_body()) == b'chunk_size' * 3
    assert res.get_headers() == b''


# Generated at 2022-06-12 00:03:40.298508
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # provide an byte array for the ssl get function
    def get(url, verify):
        return bytearray([c for c in b'abcd\0efgh'])

    # environment:
    #   stdout_isatty = True
    #   stdout_encoding = 'ascii'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'ascii'

    # stream = PrettyStream(
    #     conversion=Conversion(),
    #     formatting=Formatting(),
    #     env=env,
    #     msg='r',
    # )

# Generated at 2022-06-12 00:03:49.565985
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    test_mime = "test_mime"
    test_converter = "test_converter"
    test_formatting = "test_formatting"
    test_msg = "test_msg"
    test_with_headers = True
    test_with_body = True

    pretty_stream = PrettyStream(test_converter, test_formatting, test_msg, test_with_headers, test_with_body)

    assert test_formatting == pretty_stream.formatting
    assert test_converter == pretty_stream.conversion
    assert test_mime == pretty_stream.mime


# Generated at 2022-06-12 00:03:58.299762
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    env = Environment()
    msg = HTTPMessage(headers={'content-type': 'text/plain; charset=UTF-8'})
    fmt = Formatting()
    cnv = Conversion()

# Generated at 2022-06-12 00:04:00.308229
# Unit test for constructor of class RawStream
def test_RawStream():
    try:
        response = RawStream()
    except NotImplementedError:
        print("RawStream has not implemented.")


# Generated at 2022-06-12 00:04:05.024251
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(b'{"foo": "bar"}')
    msg.headers["content-type"] = "application/json"
    stream = RawStream(msg)
    result = bytes()
    for chunk in stream.iter_body():
        result += chunk
    print(result)

if __name__ == "__main__":
    test_RawStream_iter_body()

# Generated at 2022-06-12 00:04:14.635754
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    try:
        from unittest.mock import Mock
    except:
        from mock import Mock

    # Testing for the case when output stream is not a tty.
    msg = Mock()
    msg.headers = 'headers'
    msg.encoding = 'utf8'
    env = Mock()
    env.stdout_isatty = False
    env.stdout_encoding = None
    es = EncodedStream(msg=msg, env=env)
    assert es.get_headers()==b'headers'
    assert es.output_encoding=='utf8'
    assert isinstance(es.iter_body(), iter)
    # Testing for the case when output stream is a tty.
    msg = Mock()
    msg.headers = 'headers'
    msg.encoding = None
    env = Mock()
   

# Generated at 2022-06-12 00:04:23.325506
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    class DummyFormatting(object):
        def format_headers(self, headers):
            pass

        def format_body(self, content, mime):
            pass

    class DummyConversion(object):
        def get_converter(self, mime):
            pass

    class DummyHTTPMessage(object):
        def content_type(self):
            pass

        def iter_lines(self, chunk_size):
            pass

        def encoding(self):
            pass

    d2 = DummyHTTPMessage()
    ps = PrettyStream(
        msg=d2,
        conversion=DummyConversion(),
        formatting=DummyFormatting(),
        with_headers=True,
        with_body=True,
    )
    assert ps

# Generated at 2022-06-12 00:04:33.490803
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # arrange
    msg = HTTPMessage()
    msg.encoding = 'utf-16'
    msg._body_bytes = b'\x00\x65\x00\x6c\x00\x74\x00\x52\x00\x6f\x00\x77'
    msg._body_bytes_consumed = 0
    msg.content_type = 'text/plain'
    env = Environment()
    env.stdout_encoding = 'utf-8'
    env.stdout_isatty = False
    stream = BufferedPrettyStream(msg=msg, env=env)
    # act
    result = list(stream.iter_body())
    # assert
    assert len(result) == 1

# Generated at 2022-06-12 00:04:39.728195
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    assert (BufferedPrettyStream(None, None, None).process_body('abc') == b'abc')
    assert (BufferedPrettyStream(None, None, None).process_body('a b c') == b'a b c')
    assert (BufferedPrettyStream(None, None, None).process_body('$' + '^') == b'$^')
    assert (BufferedPrettyStream(None, None, None).process_body('a{b}c') == b'a{b}c')

# Generated at 2022-06-12 00:05:46.630256
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from httpie.cli.constants import DEFAULT_UA
    env = Environment(stdout_encoding=None,
                      stdin_isatty=False,
                      stdout_isatty=False,
                      colors=None,
                      stdin=None,
                      stdout=None,
                      style=None,
                      format='pretty',
                      print_body_only_in_form=False,
                      headers=None,
                      user_agent=DEFAULT_UA,
                      output_options=None)


# Generated at 2022-06-12 00:05:56.581429
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # BytesIO object
    http_msg = HTTPMessage(raw=b'Content-Type: text/plain\r\n\r\nStreaming API')
    prettyStream = PrettyStream(msg=http_msg)
    assert next(prettyStream.iter_body()) == b'Streaming API'
    with pytest.raises(StopIteration):
        next(prettyStream.iter_body())

    # StringIO object
    http_msg = HTTPMessage(raw=b'Content-Type: text/plain\r\n\r\nStreaming API')
    def get_converter(mime):
        def convert(body):
            print(body)
            return 'text/plain', 'Converted streaming API\n'
        return convert

# Generated at 2022-06-12 00:05:57.774143
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert issubclass(EncodedStream, BaseStream)


# Generated at 2022-06-12 00:06:02.903507
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():

    # Set up a test class
    class TestMessage(object):
        def __init__(self, msg):
            self.msg = msg

        def __iter__(self):
            for i in self.msg:
                yield i

    # Setup data
    data = [
        b'line one',
        b'line two',
        b'line three',
        b'line four'
    ]

    # Run test
    sm = RawStream(TestMessage(data))
    for i, line in enumerate(sm.iter_body()):
        assert line == data[i]


# Generated at 2022-06-12 00:06:11.450086
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-12 00:06:14.666773
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
  msg = HTTPMessage('a','utf8','a','utf8','a','a','a','a','a','a')
  arg = BufferedPrettyStream(msg,'a','a','a')
  assert arg == BufferedPrettyStream(msg,'a','a','a')


# Generated at 2022-06-12 00:06:24.419002
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    input = b"{"
    output = {}
    def f(x):
        output.update(x)

    msg = HTTPMessage(encoding='utf-8', content=input)
    BufferedPrettyStream(msg, formatting = Formatting(), conversion = Conversion(), on_body_chunk_downloaded=f).iter_body()
    assert output == {}
    
    input = b'{"key": "value"}'
    msg = HTTPMessage(encoding='utf-8', content=input)
    BufferedPrettyStream(msg, formatting = Formatting(), conversion = Conversion(), on_body_chunk_downloaded=f).iter_body()
    assert output == {"key": "value"}
    
    input = b'{"key": "value", "key": "value"}'

# Generated at 2022-06-12 00:06:34.900504
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import pytest
    from httpie.models import HTTPResponse
    url = "http://httpbin.org/get"
    with requests.get(url=url,stream=True) as r:
        if r.status_code == 200:
            response = HTTPResponse(
                r.raw,
                r.request,
                status_code=r.status_code,
                url=url,
                http_version=r.raw.version,
            )
            stream = RawStream(msg=response, with_headers=True, with_body=True)
            for i in stream:
                print(i)
            stream = EncodedStream(msg=response, with_headers=True, with_body=True)
            for i in stream:
                print(i)

# Generated at 2022-06-12 00:06:40.757450
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from .response import HTTPResponse
    from .stream import RawStream
    from .util import CaseInsensitiveDict

    headers= CaseInsensitiveDict({'content-type': 'text/plain'})
    response= HTTPResponse(headers, b'hello world')
    stream= RawStream(response, with_headers=True, with_body=True)
    body_list= list(stream.iter_body())

    assert len(body_list) == 1 
    assert body_list[0] == b'hello world'



# Generated at 2022-06-12 00:06:50.913632
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import pytest
    from httpie.models import HTTPMessage
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

    input_message = HTTPMessage(
        headers=["HTTP/1.1 200 OK"],
        body=b"print 'Hello World'"
    )
    expected_message = b"HTTP/1.1 200 OK\r\n\r\nprint 'Hello World'"

    assert next(RawStream(input_message)) == expected_message

    output_message = EncodedStream(input_message)
    print(output_message)
    print(next(output_message))
    assert next(output_message) == b'\r\n\r\n'