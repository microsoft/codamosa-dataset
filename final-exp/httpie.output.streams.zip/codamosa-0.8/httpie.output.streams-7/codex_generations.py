

# Generated at 2022-06-11 23:59:06.114184
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-11 23:59:10.960308
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    prettyStream = PrettyStream(HTTPMessage(),'','','','','','')
    assert prettyStream.get_headers()  == ''.encode('utf8')
    assert prettyStream._pretty_stream__init__ == ''.encode('utf8')



# Generated at 2022-06-11 23:59:21.024198
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(
        'headers',
        b'body',
        'formatted headers',
        'formatted body',
        'body_mime_type'
    )

    # Case 1: with_header=True, with_body=True, on_body_chunk_downloaded=None
    stream = BaseStream(msg, True, True)

    headers_body = list(stream)
    expected_headers_body = 'headers\r\n\r\nbody'.encode('utf-8')
    assert expected_headers_body == b''.join(headers_body)

    # Case 2: with_header=True, with_body=False, on_body_chunk_downloaded=None
    stream = BaseStream(msg, True, False)

    headers = list(stream)

# Generated at 2022-06-11 23:59:29.326010
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    s = BaseStream(HTTPMessage(),with_headers=True,with_body=True)
    s.get_headers = lambda : 'test'
    s.iter_body = lambda : 'test'
    assert s.__iter__() == ['test','\r\n\r\n','test']
    s2 = BaseStream(HTTPMessage(),with_headers=False,with_body=True)
    s2.iter_body = lambda : 'test'
    s2.get_headers = lambda : 'test'
    assert s2.__iter__() == ['test']


# Generated at 2022-06-11 23:59:32.650288
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    test = EncodedStream('msg', 'env')
    assert test.get_headers() == b'msg headers'
    assert test.CHUNK_SIZE == 1


# Generated at 2022-06-11 23:59:43.044950
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    mime = 'text/plain'
    chunk = 'some test text'
    formatted_chunk = 'some +++ test +++ text'
    output_encoding = 'utf8'
    formatting = Formatting()
    formatting.format_body = mock.Mock()
    formatting.format_body.return_value = formatted_chunk
    conversion = Conversion()
    conversion.get_converter = mock.Mock()
    conversion.get_converter.return_value = None

    pretty_stream = PrettyStream(conversion=conversion, formatting=formatting)
    pretty_stream.mime = mime
    pretty_stream.output_encoding = output_encoding

    actual_value = pretty_stream.process_body(chunk)

# Generated at 2022-06-11 23:59:47.966435
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    with open('test.txt','w+') as f:
        for line, lf in HTTPMessage('','','','').iter_lines(1024 * 10):
            if b'\0' in line:
                print(line,lf)
                break
            print(line,lf)

# Generated at 2022-06-11 23:59:53.511416
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(content_type='text/plain')
    msg.add_body_line('test')
    strm = PrettyStream(msg)
    assert list(strm.iter_body()) == [msg.body_bytes()]
    msg.add_body_line('test')
    strm = PrettyStream(msg)
    assert list(strm.iter_body()) == [msg.body_bytes()]

# Generated at 2022-06-12 00:00:02.208720
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from io import BytesIO
    from typing import Callable
    from httpie.context import Environment

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.content_type = 'text/plain;charset=utf8'
    body = BytesIO("hello".encode('utf8'))
    msg.iter_body = body.read
    msg.iter_lines = body.readline



# Generated at 2022-06-12 00:00:12.809541
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(request=None, content_type='application/json', headers='')
    stream = PrettyStream(conversion=Conversion(), formatting=Formatting(), msg=msg)
    assert stream.get_headers() == b''

    msg = HTTPMessage(request=None, content_type='application/json', headers='Content-Type: application/json')
    stream = PrettyStream(conversion=Conversion(), formatting=Formatting(), msg=msg)
    assert stream.get_headers() == b'Content-Type: application/json'

    msg = HTTPMessage(request=None, content_type='application/json', headers='Content-Type: application/json\n\n')
    stream = PrettyStream(conversion=Conversion(), formatting=Formatting(), msg=msg)
    assert stream.get_headers() == b

# Generated at 2022-06-12 00:00:41.029923
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.compat import urlopen

    url = 'https://www.httpbin.org/stream/5'
    response = urlopen('https://www.httpbin.org/stream/5')
    # response = HTTPResponse(headers={}, body={'hello': 'world'})

    # test the iter_body method
    stream = PrettyStream(msg=response, with_headers=False, with_body=True,
                          conversion=None, formatting=None)
    output_list = []
    for line in stream:
        output_list.append(line)

    print(output_list)
#
# # Unit test for method iter_lines of class HTTPResponse
# def test_HTTPResponse_iter_lines():
#     from httpie

# Generated at 2022-06-12 00:00:51.885097
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import re
    import pprint
    def test(content, expected):
        msg = HTTPMessage(headers = {})
        msg.encoding = "utf8"
        msg._get_body = lambda **_: content
        stream = PrettyStream(msg, False, True, 1,
            conversion = Conversion(),
            formatting = Formatting(False, False),
        )
        received = []
        for line in stream.iter_body():
            received.append(line)
        received = b''.join(received)
        if expected != received:
            pp = pprint.PrettyPrinter(indent=4, width=1)
            print("actual:")
            pp.pprint(re.split("(?:\\r\\n|\\n|\\r)", received.decode("utf8")))
            print("expected:")
           

# Generated at 2022-06-12 00:01:02.673180
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.output import BinaryCompatibleBytesIO
    import httpie.models as http_models
    stream = BaseStream(
        msg=http_models.HTTPMessage(
            headers=http_models.Headers(
                fields=[
                    ('X-Foo', 'bar'),
                    ('X-Baz', '42'),
                ]
            ),
            body=b'POST body',
            encoding='utf8',
        ),
    )
    if sys.version_info >= (3, 6):
        expected = (
            b'X-Foo: bar\r\n'
            b'X-Baz: 42\r\n'
            b'\r\n'
            b'POST body'
        )

# Generated at 2022-06-12 00:01:08.188244
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    body = 'test_body_from_testPrettyStream_get_headers'
    msg = HTTPMessage(body)
    msg.content_type = 'text/html'
    msg.url = 'test_test_test/test_test_test'
    msg.headers = 'test_header_from_testPrettyStream_get_headers'
    msg.method = 'test_method_from_testPrettyStream_get_headers'
    msg.encoding = 'test_encoding_from_testPrettyStream_get_headers'

    raw_stream = BufferedPrettyStream(msg, env=Environment())
    # test_get_headers = raw_stream.get_headers()
    return True


if __name__ == "__main__":
    if test_PrettyStream_get_headers() == True:
        print('Passed')

# Generated at 2022-06-12 00:01:17.691739
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # BaseStream.__init__(self, msg: HTTPMessage, with_headers=True, with_body=True, on_body_chunk_downloaded: Callable[[bytes], None] = None)
    # with_headers = True, with_body = True
    stream = BaseStream(msg = '', with_headers = True, with_body = True, on_body_chunk_downloaded=None)
    assert type(stream) == BaseStream
    
    # BaseStream.__init__(self, msg: HTTPMessage, with_headers=True, with_body=True, on_body_chunk_downloaded: Callable[[bytes], None] = None)
    # with_headers = False, with_body = True

# Generated at 2022-06-12 00:01:28.292328
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import pytest
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting

    xml_message = b'''<xml><rawtext>This is some text</rawtext></xml>'''
    xml_message_utf8_with_escapes = b"<xml><rawtext>This is some text</rawtext></xml>"
    xml_message_utf8 = b'<xml><rawtext>This is some text</rawtext></xml>'

    # Test xml body

# Generated at 2022-06-12 00:01:37.530685
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import Response
    from httpie.core import stream
    from io import BytesIO
    import pytest
    env = Environment()
    # Test iter_body() of RawStream
    foo_msg = Response(
        b'HTTP/1.1 200 OK\r\n'
        b'Server: gunicorn/19.8.1\r\n'
        b'Date: Wed, 24 Sep 2019 13:17:57 GMT\r\n'
        b'Connection: close\r\n'
        b'Content-Type: text/html\r\n'
        b'Content-Length: 4\r\n'
        b'\r\n'
        b'foo\n',
        encoding=None,
    )

# Generated at 2022-06-12 00:01:48.312871
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    h = HTTPMessage()
    h.content_type = 'text/html'
    h.encoding = 'utf-8'
    h.streaming_chunk_size = 1024
    h.set_body('''<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>

<h1>My First Heading</h1>
<p>My first paragraph.</p>

</body>
</html>''')
    env = Environment()
    # Use the encoding supported by the terminal.
    output_encoding = env.stdout_encoding
    # Default to utf8 when unsure.
    output_encoding = output_encoding or 'utf8'

    conversion = Conversion()
    formatting = Formatting()

# Generated at 2022-06-12 00:01:55.689089
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-12 00:02:03.807184
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.models import Message
    from httpie.output.processing import Conversion, Formatting
    msg = Message(b'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{"test":"test1"}')
    msg.parse_body()
    msg_out = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert msg_out.process_body(msg.body).decode() == '{\n    "test": "test1"\n}'

# Generated at 2022-06-12 00:02:27.959467
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import EncodedStream
    from tests.test_models import MockRequest

    body_text = 'Hello World!'
    body_binary = b'\x00'
    body_binary_line = b'\x00\n'
    body_binary_in_text = b'\x00hello'
    body_text_in_binary = b'hello\n\n'
    body_text_in_binary_end = b'hello'

    msg = Response(MockRequest(url='http://example.com'))
    msg.encoding = 'utf8'

    # text only
    msg.body = body_text
    assert list(EncodedStream(msg=msg).iter_body()) == [body_text]
    # text and binary in the same line

# Generated at 2022-06-12 00:02:34.265709
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    data = b'{\n  "desc": "OK"\n}'
    msg = HTTPMessage(
        method='GET',
        url='http://httpbin.org/get',
        headers={'Content-Type': 'application/json'},
        body_bytes=data,
        encoding='utf-8'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=False,
        with_body=True,
    )
    assert list(stream.iter_body()) == [data.decode()]

# Generated at 2022-06-12 00:02:44.475593
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # For class Conversion
    if 'env' in vars():
        print('yes')
        if 'conversion' in vars():
            print('yes')
    else:
        print('no')
    # For class Formatting
    if 'env' in vars():
        print('yes')
        if 'formatting' in vars():
            print('yes')
    else:
        print('no')
    # For class EncodedStream
    if 'env' in vars():
        print('yes')
        if 'output_encoding' in vars():
            print('yes')
    else:
        print('no')
    # For class RawStream
    if 'chunk_size' in vars():
        print('yes')
        if 'iter_body' in vars():
            print('yes')

# Generated at 2022-06-12 00:02:51.953125
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    msg = HTTPMessage(env, (1, 1), '200 OK', {'Mini': 'param'}, b'')
    stream = EncodedStream(env=env, msg=msg, with_headers=False, with_body=True)
    assert next(iter(stream)) == b'\n'
    stream = EncodedStream(env=env, msg=msg, with_headers=False, with_body=False)
    with pytest.raises(StopIteration):
        next(iter(stream))

# Generated at 2022-06-12 00:03:01.285452
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    def body_iter(body):
        for line, lf in body.split(b'\r\n'):
            yield line
            yield lf

    stream = EncodedStream(
                        msg=HTTPMessage(body='foo', headers=b'Content-Type: text/plain\r\n', encoding='iso-8859-1'),
                        with_headers=True,
                        with_body=True,
                        on_body_chunk_downloaded=None
                        )
    assert body_iter(b'foo') == body_iter(b''.join(stream.iter_body()))
    

# Generated at 2022-06-12 00:03:11.185538
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Arrange
    import base64

# Generated at 2022-06-12 00:03:16.570525
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.context import Environment
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    msg = HTTPMessage()
    msg.headers = 'TestHeaders'
    estream = EncodedStream(msg, env=env, with_body=False)
    assert estream

test_EncodedStream()

# Generated at 2022-06-12 00:03:20.507224
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage('body', 'utf8')
    stream = EncodedStream(msg, with_headers=False, with_body=True, on_body_chunk_downloaded=None)
    y = stream.CHUNK_SIZE
    assert y == 1
    x = stream.get_headers()
    assert x == b''

# Generated at 2022-06-12 00:03:30.586176
# Unit test for method iter_body of class RawStream

# Generated at 2022-06-12 00:03:40.001052
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # check if constructor works
    msg = HTTPMessage()
    msg.headers.add('content-type', 'application/json')
    
    bps = BufferedPrettyStream(msg,
                               with_headers=True,
                               with_body=True,
                               on_body_chunk_downloaded=None,
                               conversion=Conversion(),
                               formatting=Formatting(),)
    print(bps.mime)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-12 00:04:19.082339
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert callable(BaseStream.__init__)
    assert callable(BaseStream.get_headers)
    assert callable(BaseStream.iter_body)
    assert callable(BaseStream.__iter__)



# Generated at 2022-06-12 00:04:26.048320
# Unit test for method get_headers of class PrettyStream

# Generated at 2022-06-12 00:04:36.761318
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Fixture
    class HtmlConverter:
        def convert(self, body):
            return None, 'any_html_body'

    class FakeHttpMessage:
        def __init__(self, raw_body):
            self.raw_body = raw_body
            self.content_type = 'text/html'

        def iter_body(self, chunk_size=None):
            return iter(self.raw_body[i:i + chunk_size] for i in range(0, len(self.raw_body), chunk_size))

    class FakeFormatting:
        def format_headers(self, headers):
            return headers

        def format_body(self, content, mime):
            return content

    class FakeConversion:
        def get_converter(self, mime):
            return HtmlConver

# Generated at 2022-06-12 00:04:42.454800
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    m = HTTPMessage(
        'httpie.models.HTTPMessage',
        encoding='utf-8',
        headers={
            'content-type': 'text/plain; charset=utf8',
            'content-length': '2'
        },
        body=b'{"a":1}'
    )
    with_headers = True
    with_body = True
    s = BaseStream(m, with_headers, with_body)
    b = b'{"a":1}'
    assert b'\r\n\r\n' in list(s)
    assert b in list(s)


# Generated at 2022-06-12 00:04:51.003003
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(text=b'abc\0\ndef\0\nghi', encoding='utf8')
    with pytest.raises(BinarySuppressedError):
        list(EncodedStream(msg=msg).iter_body())
    msg = HTTPMessage(text=b'abc\ndef\nghi', encoding='utf8')
    assert list(EncodedStream(msg=msg).iter_body()) == [b'abc\n', b'def\n', b'ghi']


# Generated at 2022-06-12 00:05:00.650676
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import requests
    import io
    import gzip
    url = 'https://api.github.com/repos/jakubroztocil/httpie'
    s = requests.Session()
    req = requests.Request('GET',url)
    prepared = req.prepare()
    resp = s.send(prepared)
    b = RawStream(resp,with_headers=True,with_body=True).iter_body()
    print([i for i in b])
    b = RawStream(resp,with_body=True).iter_body()
    print([i for i in b])
    b = RawStream(resp,with_headers=True).iter_body()
    print([i for i in b])
    b = RawStream(resp,with_headers=True,with_body=True).iter_body()
   

# Generated at 2022-06-12 00:05:07.743958
# Unit test for constructor of class RawStream
def test_RawStream():
    # check the values of constructor fields
    msg = HTTPMessage(headers=b'GET / HTTP/1.1\r\nHost: localhost\r\n\r\n', body=b'body content', encoding='utf8')
    raw_stream = RawStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert raw_stream.msg == msg
    assert raw_stream.with_headers == True
    assert raw_stream.with_body == True
    assert raw_stream.on_body_chunk_downloaded == None


# Generated at 2022-06-12 00:05:16.256095
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    HTTP = HTTPMessage()

    # Printing the body of the message
    raw_response = PrettyStream(HTTP)
    body_raw_response = [b for b in raw_response]
    print(body_raw_response)

    # Printing the body of the message in one line
    line_response = PrettyStream(HTTP, with_headers=False, with_body=True)
    body_line_response = [b for b in line_response]
    print(body_line_response)


if __name__ == "__main__":
    test_PrettyStream_iter_body()

# Generated at 2022-06-12 00:05:25.597884
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest, HTTPResponse
    # create request
    request = HTTPRequest('http://example.com/',
                          method='GET',
                          body=b'abc',
                          headers={'Content-Type': 'application/x-abc'})
    # create BaseStream from request
    # we can set argument with_body=True or False
    # this test is for with_body=True
    stream = BaseStream(request, True, True)
    # convert the stream to a iterable
    it = stream.__iter__()
    # __next__() will return a chunk of data
    # until the stream is exhausted
    # in this case, we have 4 chunks
    # 1st chunk: headers
    # 2nd chunk: '\r\n\r\n'
    # 3rd chunk:

# Generated at 2022-06-12 00:05:26.963267
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    return



# Generated at 2022-06-12 00:06:39.366975
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    pass


# Generated at 2022-06-12 00:06:46.109325
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    test_msg = HTTPMessage(content_type='text/plain',
                           headers='Content-Type: text/plain',
                           body=b'it works!\n')
    stream = BufferedPrettyStream(msg=test_msg,
                                  conversion=Conversion(),
                                  formatting=Formatting(),
                                  with_headers=True,
                                  with_body=True)
    result = b''.join(stream.iter_body()).decode('utf-8')
    assert result == 'it works!'

# Generated at 2022-06-12 00:06:49.619267
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test_msg = HTTPMessage(b'{"hello": "world"}')
    expected_output = b'{\n "hello": "world"\n}\n'
    assert list(EncodedStream(test_msg).iter_body()) == [expected_output]



# Generated at 2022-06-12 00:06:58.141390
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.headers import HeadersFormat
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import BodyConversion
    from httpie.output.processing import Formatting
    headers = Headers()
    headers.add('testname', 'testvalue')
    headers.add('testname', 'testvalue1')
    headers_format = HeadersFormat()
    body_conversion = BodyConversion()
    body_conversion.set_converter('text/xml', 'utf8')
    formatting = Formatting()
    header_str = b'testname: testvalue'

# Generated at 2022-06-12 00:07:07.600867
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    "Test iter_body method of class PrettyStream (without prettifying)"
    # This test is based on the test method
    # PrettyStream.test_iter_body_prettifies_by_content_type_xml
    # of the file test_pretty.py
    # https://github.com/jakubroztocil/httpie/blob/master/tests/test_pretty.py

    # We define a new variable stream_iter with class PrettyStream.
    mime = 'text/xml'
    stream_iter = PrettyStream(None, None)

    # We introduce a string called xml_body.

# Generated at 2022-06-12 00:07:11.053439
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    stream = RawStream(HTTPResponse(b'body'), with_body=True, with_headers=False)
    assert bytes(b'body') in stream

# Generated at 2022-06-12 00:07:11.654820
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    pass

# Generated at 2022-06-12 00:07:15.366182
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream = EncodedStream()
    assert stream.output_encoding == 'utf8'
    assert stream.msg == HTTPMessage()
    assert stream.with_headers == True
    assert stream.with_body == True


# Generated at 2022-06-12 00:07:25.709142
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage()

# Generated at 2022-06-12 00:07:28.759569
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream(msg=HTTPMessage(headers=None, body='\u00EA'))
    l = list(stream.iter_body())
    assert l == [b'\xc3\xaa']