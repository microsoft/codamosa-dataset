

# Generated at 2022-06-11 23:58:56.910404
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.downloads import Downloader, DownloadItem
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import Response
    from httpie.output import Formatting, Conversion
    from httpie.core import main
    from httpie.downloads import Downloader, DownloadItem
    from httpie import __main__ as main

    data = b''
    response = Response(url="http://httpbin.org/get",
                        status_code=200,
                        headers={},
                        content=data)

    # class Downloader:
    #     def __init__(self):
    #         pass
    #
    #     def download_item_with(self, item: DownloadItem, chunk_size=None):
    #         while True:
    #             try:
    #                 yield item.content[item.

# Generated at 2022-06-11 23:59:00.992693
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    a = PrettyStream(msg=HTTPMessage(1,2),with_headers=True,with_body=True,on_body_chunk_downloaded=None,conversion=Conversion(Environment()),formatting=Formatting(Environment()))


# Generated at 2022-06-11 23:59:10.071779
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    import unittest
    class TestPrettyStream(unittest.TestCase):
        
        def setUp(self):
            # Global variables
            import sys
            self._conversion = Conversion()
            self._formatting = Formatting()
            self._env = Environment(
                    stdout=sys.stdout,
                    stdin=sys.stdin,
                    stdin_isatty=sys.stdin.isatty(),
                    stdout_isatty=sys.stdout.isatty(),
                    is_windows=sys.platform.startswith('win'),
                    colors=None,
                    stdout_encoding='utf8')
            # Define variables for test

# Generated at 2022-06-11 23:59:16.837939
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    f = open('../../test_data/response_body_plain')
    def f():
        for i in open('../../test_data/response_body_plain'):
            yield i  
    msg = HTTPMessage(status_line=b'hello', headers={}, body=f, content_type='text/html')
    for line in PrettyStream(msg, conversion='', formatting='').iter_body():
        print(line)


# Generated at 2022-06-11 23:59:26.968296
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class MockMsg(object):
        def __init__(self, lst):
            self.lst = lst
            self.encoding = 'ascii' # can only be ascii?
        def iter_lines(self, chunk_size):
            for line in self.lst:
                yield line, b'\n'
    #
    test_str_lst = ['abc\ndef\n', 'hij\nklm\n', '123\n456\n', '789\n']
    #
    response = EncodedStream(env=Environment(), msg=MockMsg(test_str_lst))
    assert '\n'.join(response.iter_body()) == 'abc\ndef\nhij\nklm\n123\n456\n789'

# Generated at 2022-06-11 23:59:33.346414
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = [
        (b'Content-Type', b'text/html; charset=utf-8'),
        (b'Content-Length', b'0'),
        (b'Server', b'Werkzeug/0.11.3 Python/3.4.3'),
        (b'Date', b'Thu, 01 Jun 2017 23:15:46 GMT')
    ]

    fmt = Formatting()
    encoding = 'utf-8'
    message = HTTPMessage(headers=headers, body=b"", encoding=encoding)
    stream = PrettyStream(conversion=Conversion(),
                          formatting=fmt,
                          msg=message)

# Generated at 2022-06-11 23:59:37.206138
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage('headers', b'hello\x00world', encoding='utf8')
    stream = BufferedPrettyStream(msg, with_headers=False)
    assert list(stream.iter_body()) == [(b'hello\n')]

# Generated at 2022-06-11 23:59:41.437455
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    with_headers=True
    with_body=True
    on_body_chunk_downloaded=None
    stream = BaseStream(msg,with_headers,with_body,on_body_chunk_downloaded)
    assert iter(stream) is not None


# Generated at 2022-06-11 23:59:52.546499
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.input import ParseError
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.processing import ConverterRegistry
    from httpie.plugins import plugin_manager

    env = Environment()
    request = None
    try:
        request = HTTPRequest.from_http('GET / HTTP/1.1\r\nFoo: Bar\r\n\r\n')
    except ParseError:
        raise
    env.stdout_isatty = False
    env.follow_redirects = False
    env.max_redirects = None
    env.timeout = None
    env.allow_insecure = False
    env.check_status = False
    env.default_options = {}
    env

# Generated at 2022-06-12 00:00:01.711012
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    print("\nTest for constructor of class PrettyStream")

    # First test
    print("\nFirst test")
    msg = HTTPMessage('HTTP/1.1 200 OK', 'Content-Type: text/plain')
    conversion = None
    formatting = None
    with_headers = True
    with_body = True
    on_body_chunk_downloaded: Callable[[bytes], None] = None

    prettyStream = PrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded, conversion, formatting)

    msg = prettyStream.msg
    with_headers = prettyStream.with_headers
    with_body = prettyStream.with_body
    on_body_chunk_downloaded = prettyStream.on_body_chunk_downloaded
    conversion = prettyStream.conversion

# Generated at 2022-06-12 00:00:20.641351
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(conversion=None, formatting=None, msg=None, with_headers=None, with_body=None)
    # The body need not be a str instance
    result = stream.process_body(b'hello')
    assert(result == b'hello')
    # The body should be a bytes instance
    result = stream.process_body(b'\xe4\xb8\xad\xe5\x8d\x8e\xe4\xba\xba\xe6\xb0\x91\xe5\x85\xb1\xe5\x92\x8c\xe5\x9b\xbd')

# Generated at 2022-06-12 00:00:25.757734
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    msg = HTTPMessage()
    BufferedPrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded, env, conversion, formatting)

# Generated at 2022-06-12 00:00:37.113899
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    env = Environment()
    msg_lines = ['This is a dog.',
                 'This is a cat.',
                 'This is a bird.',
                 'This is a fish.']
    request_body = '\r\n'.join(msg_lines)
    msg = HTTPMessage(request_body, headers={})
    response_body = request_body
    msg_lines = ['This is a tiger.',
                 'This is a fox.',
                 'This is a monkey.',
                 'This is a butterfly.']
    request_body = '\r\n'.join(msg_lines)
    msg = HTTPMessage(request_body, headers={'content-type': 'text/html'})
    response_body = request_body

# Generated at 2022-06-12 00:00:44.737018
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Define the message object.
    msg = HTTPMessage(http_version='2', headers=['Content-Type: text/plain', 'Content-Length: 4'], body=b'abc\ndef')
    # Define the conversion object.
    conversion = Conversion()
    # Define the formatting object.
    formatting = Formatting(max_json_pp_depth=10, max_json_indent=10, max_xml_pp_depth=10, max_xml_indent=10, json_indent=2, xml_indent=2, pretty_print=True)
    # Define the class object.
    pretty_stream = PrettyStream(msg=msg, chunk_size=1, conversion=conversion, formatting=formatting)
    # Get the output of the process_body method.

# Generated at 2022-06-12 00:00:53.700031
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg_utf8 = HTTPMessage(content_type='text/plain; charset=utf8',encoding='utf-8')
    msg_utf8.status_line = 'hello world'
    msg_utf8.headers['test'] = 'test'
    msg_utf8.body = b'hello world'
    msg_utf8.unicode_start_line = 'hello world'
    msg_utf8.unicode_headers['test'] = 'test'
    msg_utf8.unicode_body = 'hello world'

    msg_utf16 = HTTPMessage(content_type='text/plain; charset=utf16', encoding='utf-16')
    msg_utf16.status_line = 'hello world'
    msg_utf16.headers['test'] = 'test'

# Generated at 2022-06-12 00:01:03.888698
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Case 1: HTTPEntity -> text in utf8 encoding -> Output is bytes
    env = Environment()
    env.stdout_isatty = True
    msg = HTTPMessage(headers='Content-Type: text/plain; charset=utf8\r\n',
                        body='žluťoučký koníček')
    stream_1 = EncodedStream(env=env, msg=msg)
    res_1 = b''.join(stream_1.iter_body())
    assert res_1 == b'\xc5\xbelu\xc5\xa5ou\xc4\x8dk\xc3\xbd kon\xc3\xad\xc4\x8dek\n'
    # Case 2: HTTPEntity -> text in GB2312 encoding -> Output is bytes
    msg_

# Generated at 2022-06-12 00:01:05.597117
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    assert 'Conversion' in PrettyStream.__init__.__code__.co_varnames

# Generated at 2022-06-12 00:01:15.920846
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # data in json format
    data = "[{'category1': 'test1', 'category2': 'test2'}, {'category1': 'test3', 'category2': 'test4'}, {'category1': 'test5', 'category2': 'test6'}]"
    conversion = Conversion('json', None)
    formatting = Formatting(None, None, None, None)
    body = "HTTP Test"
    pretty_body = PrettyStream(conversion, formatting, body)

    # data in json format
    data = [{'category1': 'test1', 'category2': 'test2'}, {'category1': 'test3', 'category2': 'test4'}, {'category1': 'test5', 'category2': 'test6'}]
    data = json.dumps(data)

# Generated at 2022-06-12 00:01:21.282199
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print('EncodedStream constructor test')
    mime = 'text/html'
    body = 'hello'
    wrt = HTTPMessage(mime, body)
    env = Environment()
    es = EncodedStream(wrt, env)


# Generated at 2022-06-12 00:01:27.052339
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.method  = "GET"
    msg.url = "http://httpbin.org/get"
    msg.body = "content"
    msg.headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    stream = RawStream(msg)
    result = list(stream)
    assert type(result[1]) is bytes


# Generated at 2022-06-12 00:01:55.468138
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage('HTTP/1.0', '200', 'OK', headers=dict())
    msg.encoding = 'utf8'
    conversion = Conversion()
    conversion.add(
        mime='application/json',
        converter=httpie.plugins.builtin.converters.JSONConverter()
    )
    if httpie.plugins.builtin.formatters.JSONFormatter is None:
        raise ValueError('JSON formatter is missing')
    formatting = Formatting()
    formatting.add(
        mime='application/json',
        formatter=httpie.plugins.builtin.formatters.JSONFormatter()
    )
    stream = PrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting
    )
    body = '{"hello": "world"}'


# Generated at 2022-06-12 00:02:00.488887
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    encoding = 'utf8'
    msg = HTTPMessage(None, headers={}, body=b'{"a":1}', encoding=encoding)
    stream = PrettyStream(msg, formatting=Formatting(None, None), conversion=None)
    assert stream.process_body(b'{"a":1}') == b'{\n    "a": 1\n}\n'

# Generated at 2022-06-12 00:02:06.828372
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from collections import deque
    from httpie.models import Response
    from httpie.output import DEFAULT_OPTIONS

    line_deque = deque(['hello', "world\n", 'goodbye', '!!!\n'])
    def iter_lines(size=1):
        while line_deque:
            line = line_deque.popleft()
            yield line, b"\n"

    stream = PrettyStream(Response(), DEFAULT_OPTIONS, with_headers=False)
    stream.msg.iter_lines = iter_lines

    assert list(stream.iter_body()) == [b'hello\n', b'world\n', b"goodbye!!!\n"]



# Generated at 2022-06-12 00:02:15.777174
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import httpie.models
    import httpie.output.streams
    import typing

    class Msg(httpie.models.HTTPMessage):
        """
        Msg(raw)
        
        `raw` is a sequence of chunks.
        """
        CHUNK_SIZE = 1

        def __init__(self, raw: bytes):
            """
            Initialize a Msg instance.
            
            :param raw: is a sequence of chunks.
            :type raw: bytes
            """
            self.raw = raw

        def iter_body(self, chunk_size: int = 1) -> typing.Iterable[bytes]:
            return self.raw
    

# Generated at 2022-06-12 00:02:28.681182
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import Response
    from httpie.output.formats import BinaryJSONBodyOutputFormatter
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream

    msg = Response(
        http_version='1.1',
        status_code = 100,
        headers = {
            'Age': '100',
            'Content-Type': 'application/json',
            'Status': '100'
            },
        data = {
            'info': 'output'
            }
        )
    encoding = 'utf8'
    headers = msg.headers.encode(encoding)

    # Case 1: Terminal is not a tty        
    env = Environment

# Generated at 2022-06-12 00:02:38.023427
# Unit test for constructor of class RawStream
def test_RawStream():

    # Normal case
    header = HTTPMessage('httpbin.org', '/get', 'GET', 200, "OK").headers
    data = RawStream(HTTPMessage('httpbin.org', '/get', 'GET', 200, "OK"), True, True)

    # Abnormal case: using incorrect parameter
    try:
        data = RawStream(HTTPMessage('httpbin.org', '/get', 'GET', 200, "OK"), True, False)
        assert False == True
    except AssertionError:
        print('AssertionError: Abnormal case: using incorrect parameter')
    else:
        print('Normal case: using incorrect parameter')

    # Abnormal case: using incorrect parameter

# Generated at 2022-06-12 00:02:45.312409
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(
            method='GET',
            url='http://httpbin.org/get',
            headers=['header1: value1', 'header2: value2'],
            body='{ "key1": "value1", "key2": "value2", "key3": "value3" }'
        )

    ps = PrettyStream(msg=msg, with_headers=False,
                      conversion=Conversion(), formatting=Formatting(style='monokai'))
    stream_response1 = io.BytesIO()
    stream_response1.writelines(ps.process_body(msg.body))
    stream_response1.seek(0)
    stream_response1.read(1)

# Generated at 2022-06-12 00:02:53.926879
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    response = unittest.mock.MagicMock()
    response.headers.encode.return_value = "some/mime, headers"
    response.content_type = ""

    stream = PrettyStream(conversion=None, formatting=None, msg=None, with_headers=True, with_body=False)
    stream.get_headers = unittest.mock.MagicMock(return_value=response)
    stream.output_encoding = "utf-8"

    headers_bytes = stream.get_headers()
    response.headers.encode.assert_called_with("utf-8")
    assert headers_bytes is "some/mime, headers"

# Generated at 2022-06-12 00:03:04.238686
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    print("\n<----- Running unit test for method process_body of class PrettyStream ----->")
    # data: chunk of text
    chunk = '{"before": 123}'
    # formatting: setup class Formatting
    formatting = Formatting(None, None, None)
    # conversion: setup class Conversion
    conversion = Conversion()
    # msg: create a msg object
    msg = HTTPMessage(None, None, None, None)
    msg.decode_utf8 = False
    # pretty_stream: setup class PrettyStream
    pretty_stream = PrettyStream(msg, True, True, None)
    pretty_stream.formatting = formatting
    pretty_stream.conversion = conversion
    pretty_stream.mime = "text/plain"
    pretty_stream.output_encoding = "utf8"
    # call the process_body

# Generated at 2022-06-12 00:03:12.541681
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import io
    import pytest
    from httpie.models import ContentType

    @pytest.fixture()
    def conversion_mock(mocker):
        return mocker.Mock(spec=Conversion)

    @pytest.fixture()
    def formatting_mock(mocker):
        return mocker.Mock(spec=Formatting)

    @pytest.fixture()
    def pretty_stream(request, conversion_mock, formatting_mock):
        return PrettyStream(
            request.param('GET', '/foo'),
            ContentType('text/html; utf8'),
            b'\r\n'.join(request.param),
            conversion_mock,
            formatting_mock,
            on_body_chunk_downloaded=None
        )


# Generated at 2022-06-12 00:04:00.972667
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    all_pass = True
    msg = HTTPMessage(http_version='1.1', status_code=200, reason='OK', http_version_minor=1, http_version_major=1, headers={'Content-Type': 'text/plain; charset=utf-8'}, stream=None, encoding='utf8', is_complete=True, request=None, response=True, is_redirect=False, body=b'one\r\ntwo\r\nthree')
    env = Environment()
    es = EncodedStream(env=env, msg=msg)
    for i, chunk in enumerate(es.iter_body()):
        if i == 0:
            if chunk.decode('utf8') != 'one\n':
                print(chunk.decode('utf8'), 'one\n')
               

# Generated at 2022-06-12 00:04:10.562731
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    def no_conversion(data):  # a 'no conversion' converter
        return data, {"mime": "application/json"}  # a json mime

    class fake_conversion:
        def __init__(self):
            self.mime = 'application/json'
            self.converter = no_conversion
        def get_converter(self, mime):
            return self.converter
    some_body = '{"this is a test": "for process_body"}'
    body_bytes = bytes(some_body, encoding='utf-8')

    class fake_formatting:
        def format_body(self, content, mime):
            return content


# Generated at 2022-06-12 00:04:20.340421
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessage
    from httpie.output.streams import RawStream

    # the http' 'message'
    msg = HTTPMessage(b'')

    stream = RawStream(msg)
    result = b''.join(stream.__iter__())

    assert result == b''

    # add 'header' in msg
    msg.headers = "caption: 'header'"
    stream = RawStream(msg)
    result = b''.join(stream.__iter__())

    assert result == b'caption: \'header\'\r\n\r\n'

    # add 'body' in msg
    msg.body = 'body'
    stream = RawStream(msg)
    result = b''.join(stream.__iter__())


# Generated at 2022-06-12 00:04:29.084679
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class Message:
        def __init__(self, msg):
            self.msg = msg
            self.content_type = 'text/plain'

        def iter_body(self, size=1):
            return [self.msg.encode('utf8')]

    class Conversion:
        def get_converter(self, mime):
            if mime == 'application/json':
                return Converter()
            return None

    class Converter:
        def convert(self, body):
            return 'text/html', '<html><body><h1>Hello, World!</h1></body></html>'

    class Formatting:
        def format_body(self, content, mime):
            if mime == 'text/html':
                return '** {} **'.format(content)
            return content


# Generated at 2022-06-12 00:04:39.461222
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Test msg
    headers = {}
    headers['Content-Type'] = 'application/json; charset=UTF-8'
    headers['Date'] = 'Thu, 27 Feb 2020 02:42:49 GMT'
    headers['Server'] = 'Python/3.6 aiohttp/3.6.2'
    headers['content-length'] = '17'

    msg = HTTPMessage(
        protocol=b'HTTP/1.1',
        status_code=b'200',
        reason=b'OK',
        headers=headers,
        body=b'{"key":1}',
        encoding=None)
    
    # Test env

# Generated at 2022-06-12 00:04:50.904740
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse

    def test_iter_body(chunk_size=1):
        msg = HTTPResponse()
        msg.headers = "HTTP/1.1 200 OK\r\n" + \
                      "Content-Type: text/plain\r\n" + \
                      "Content-Length: 4\r\n" + \
                      "\r\n"
        msg.body = b"foo\x00bar\n"

        stream = EncodedStream(msg, False, True, chunk_size=chunk_size)

        assert stream.CHUNK_SIZE == chunk_size
        body = [b.decode() for b in stream.iter_body()]
        assert body == ['foo', '?bar']

    test_iter_body()

# Generated at 2022-06-12 00:04:59.385791
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.streams import RawStream
    r = RawStream('a','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')
    msg = HTTPMessage(headers=b'', headers_sent=True)
    try:
        print(r.iter_body(msg, 'name', CHUNK_SIZE=1))
    except NotImplementedError as e:
        print(e)
# Output: NotImplementedError


# Generated at 2022-06-12 00:05:08.183491
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    class Test:
        def __init__(self, data):
            self.data = data
        def __iter__(self):
            for data in self.data:
                yield data

    data = [b'a',b'b',b'c']
    test = Test(data)
    stream = RawStream(test, with_headers=True, with_body=True)
    # Unit test for method iter_body of class RawStream
    def test_RawStream_iter_body():
        class Test:
            def __init__(self, data):
                self.data = data
            def __iter__(self):
                for data in self.data:
                    yield data

        data = [b'a',b'b',b'c']
        test = Test(data)

# Generated at 2022-06-12 00:05:18.851807
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import pytest

    from httpie.context import Environment
    from httpie.models import HTTPResponse
    from httpie.status_codes import HTTP_STATUS_CODES

    env = Environment()
    status_code = 200
    headers = {'Connection': 'close',
               'Content-Length': '2',
               'Content-Type': 'application/json'}
    body = "{\"test\":true}"
    response = HTTPResponse(status_code=status_code,
                            headers=headers,
                            content=body)
    response.encoding = 'utf8'

    # Test for RawStream class
    stream = RawStream(msg=response,
                       with_headers=True,
                       with_body=True,
                       on_body_chunk_downloaded=None)

# Generated at 2022-06-12 00:05:28.782491
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Method should return an iterator
    assert iter(BaseStream(HTTPMessage(None, None, None))) is not None
    # Method should produce the correct output
    assert list(BaseStream(HTTPMessage(b"http://www.url.com/", None, None))) == [b"http://www.url.com/"]
    # Method should raise an exception when the message is binary
    try:
        list(BaseStream(HTTPMessage(b"http://www.url.com/", None, b"\x00")))
    except BinarySuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE
    else:
        raise Exception("Stream didn't raise the expected exception")


# Generated at 2022-06-12 00:06:57.863822
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    body = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\n'
    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)
    msg = HTTPResponse(b'HTTP/1.1 200 OK\r\n'
                       b'Content-Type: image/png;\r\n\r\n' + body)

# Generated at 2022-06-12 00:07:07.269575
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    expected_headers = [
        ('HTTP/1.1', '200', 'OK'),
        ('Content-Length', '0'),
        ('Connection', 'keep-alive'),
        ('Date', 'Thu, 11 Apr 2019 07:11:43 GMT'),
        ('x-amzn-RequestId', 'e63edf4c-7754-4c6a-b8f8-0585343217ff'),
        ('Server', 'AmazonS3'),
    ]

# Generated at 2022-06-12 00:07:17.260138
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(
        encoding='utf8',
        body_bytes=b'{\n    "foo": "bar\\n",\n    "baz": [1, 2]\n}\n',
        content_type='application/json',
        headers={
            'content-length': '39',
            'content-type': 'application/json',
            'server': 'gunicorn/19.9.0',
            'date': 'Sat, 22 Sep 2018 17:40:53 GMT',
            'connection': 'close'
        }
    )
    stream = PrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )

# Generated at 2022-06-12 00:07:28.221749
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.output.streams import PrettyStream
    from httpie import models
    from httpie.output.processing import Formatting, Conversion
    # test_chunk is a chunk of body
    test_chunk = b'<html>\n<head><title>400000</title></head>\n<body>\n<h1>400000</h1>\n\n<h2>Bad Request</h2>\n</body>\n</html>'
    # test_msg is a response models.HTTPMessage
    test_msg = models.HTTPMessage(version='', status_line='', headers='', body=test_chunk,
                                  content_type='')
    # test_formatting is a Formatting and
    # test_conversion is a Conversion
    test_formatting = Formatting

# Generated at 2022-06-12 00:07:32.125264
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    for x in range(10):
        cnt = x + 1
        raw_body = [str(x) + '\n' for x in range(cnt)]
        raw_stream = RawStream(msg=raw_body)
        res = [x for x in raw_stream.iter_body()]
        assert res == raw_body


# Generated at 2022-06-12 00:07:41.889878
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPMessage
    env = Environment()
    env.config.output_options['pretty'] = False

    for msg in [HTTPMessage(encoding='utf8', body='α≈3\nβ≈4\n'),
                HTTPMessage(encoding='ascii', body='alpha=3\nbeta=4\n')]:

        stream = EncodedStream(env=env, msg=msg)
        assert list(stream.iter_body()) == [b'\xce\xb1\xe2\x89\x88\x33\n',
                                            b'\xce\xb2\xe2\x89\x88\x34\n']

        stream = EncodedStream(env=env, msg=msg, with_headers=False)

# Generated at 2022-06-12 00:07:49.395913
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream(None)
    stream.msg = MagicMock()
    stream.msg.iter_lines.return_value = [
        (b'some_line_1', b'\n'),
        (b'some_line_2', b'\n')
    ]
    stream.msg.encoding = 'utf8'
    assert [line for line in stream.iter_body()] == [
        b'some_line_1\n',
        b'some_line_2\n'
    ]


# Generated at 2022-06-12 00:07:53.870833
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    body = b'content'
    raw = RawStream(HTTPResponse(body))
    assert list(raw.iter_body()) == [body]
    assert raw.iter_body().__next__() == b'content'


# Generated at 2022-06-12 00:08:00.776039
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    with open("BaseStream___iter__test.txt", 'w') as f:
        class BaseStream(object):
            def __init__(self):
                self.msg = 1
                self.with_headers = True
                self.with_body = True
                self.on_body_chunk_downloaded = None
            def get_headers(self):
                return b'I am headers'
            def iter_body(self):
                return iter([b'I am body'])
            def __iter__(self):
                if self.with_headers:
                    yield self.get_headers()
                    yield b'\r\n\r\n'

# Generated at 2022-06-12 00:08:08.831129
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class MockMessage:
        encoding = 'utf8'

        def iter_lines(self, chunk_size):
            yield 'ascii', '\n'
            yield u'\u20AC'.encode('latin-1'), '\n'
            yield '\0', '\n'

    enc_stream = EncodedStream(MockMessage())
    iter_body = enc_stream.iter_body()
    body1 = next(iter_body)
    body2 = next(iter_body)
    assert body1 == 'ascii\n'
    assert body2 == u'\u20AC\n'
    with pytest.raises(BinarySuppressedError):
        next(iter_body)

