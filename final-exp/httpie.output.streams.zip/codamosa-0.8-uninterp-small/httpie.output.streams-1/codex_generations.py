

# Generated at 2022-06-25 19:00:14.010031
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    with pytest.raises(NotImplementedError):
        msg = HTTPMessage()
        with_headers=True
        with_body=True
        on_body_chunk_downloaded = None
        test_stream = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
        for chunk in test_stream.__iter__():
            break


# Generated at 2022-06-25 19:00:19.761220
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class TestEncodedStream(EncodedStream):
        def __init__(self):
            super().__init__(None)

    e = TestEncodedStream()
    assert e.iter_body() is not None


# Generated at 2022-06-25 19:00:32.075028
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    ps = PrettyStream(
        msg=HTTPMessage(
            url="https://httpbin.org/post",
            method="POST",
            headers={"content-type": "application/json"},
            body=b'{"key": "value"}',
        ),
        on_body_chunk_downloaded=None, with_headers=None, with_body=None,
        conversion=Conversion(), formatting=Formatting(indent=2), env=Environment()
    )
    assert ps.output_encoding == "utf8"
    assert ps.msg.url == "https://httpbin.org/post"
    assert ps.msg.method == "POST"
    assert ps.msg.headers["content-type"] == "application/json"
    assert ps.msg.body == b'{"key": "value"}'

# Generated at 2022-06-25 19:00:33.555497
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # setUp
    pretty_stream = PrettyStream()

    # assert
    assert pretty_stream.get_headers() == b''


# Generated at 2022-06-25 19:00:36.149769
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream(None, None)
    result = stream.iter_body()
    assert result == None
#    assert result != None

# Generated at 2022-06-25 19:00:41.765831
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(
        headers='GET / HTTP/1.1\r\nHost: httpbin.org\r\n\r\n',
        encoding='utf8'
    )
    stream = BufferedPrettyStream(
        msg,
        with_headers=True,
        with_body=True
    )
    assert isinstance(stream.iter_body(), Iterable)


# Generated at 2022-06-25 19:00:51.772582
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-25 19:00:56.952979
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    print("test_EncodedStream_iter_body()")
    import os
    s = EncodedStream()
    print(os.getcwd())
    from httpie.core import main as httpie_main
    httpie_main()

if __name__ == '__main__':
    test_EncodedStream_iter_body()

# Generated at 2022-06-25 19:00:59.372234
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers='''HTTP/1.1 200 OK
        content-type: text/html
        server: gunicorn/19.9.0
        date: Wed, 18 Sep 2019 21:02:29 GMT
        connection: close
        content-length: 26
        ''',
        body=''
    )
    stream = EncodedStream(msg)
    for chunk in stream:
        print(chunk)


# Generated at 2022-06-25 19:01:01.644335
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    test_instance = PrettyStream(HTTPMessage(), True, True)
    assert test_instance.process_body("hello") == b'hello'



# Generated at 2022-06-25 19:01:28.393058
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-25 19:01:34.107020
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nfoo\r\nand_bar')
    stream = EncodedStream(msg)
    assert next(stream.iter_body()) == "foo\r\n".encode('utf8')



# Generated at 2022-06-25 19:01:37.388813
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream = PrettyStream()
    assert pretty_stream.process_body(chunk='{"key": "value"}') == b'\x7b\x22key\x22\x3a \x22value\x22\x7d'

# Generated at 2022-06-25 19:01:40.261039
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream = PrettyStream(None, None)
    assert pretty_stream.process_body("test") == "test"

if __name__ == '__main__':
    test_case_0()
    test_PrettyStream_process_body()

# Generated at 2022-06-25 19:01:52.724312
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Case 0
    try:
        binary_suppressed_error_0 = BinarySuppressedError()
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        e = e
    assert isinstance(e, BinarySuppressedError)
    assert e.args == ()
    assert e.__cause__ is None
    assert isinstance(e.__context__, type(None))
    assert e.__suppress_context__ is False
    assert e.__traceback__ is None

    # Case 1
    try:
        binary_suppressed_error_1 = BinarySuppressedError()
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        e = e
    assert isinstance(e, BinarySuppressedError)
    assert e.args == ()
    assert e.__cause__ is None
   

# Generated at 2022-06-25 19:02:00.357481
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg0 = HTTPMessage(headers=None, body=None, encoding=None)
    with_headers0 = None
    with_body0 = None
    BaseStream0 = BaseStream(msg=msg0, with_headers=with_headers0, with_body=with_body0)
    for elemen0 in BaseStream0:
        pass
    with_headers0 = None
    with_body0 = None
    BaseStream0 = BaseStream(msg=msg0, with_headers=with_headers0, with_body=with_body0)
    for elemen0 in BaseStream0:
        pass


# Generated at 2022-06-25 19:02:11.052935
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Initialization of the test case
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    msg = HTTPMessage()
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    chunk_size = 1
    test_case = PrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded, env, conversion, formatting, chunk_size)

    # Test case method process_body
    begin = 0
    from_ = 0
    to = 30
    lines = test_case.process_body(msg.body[begin:to])
    assert lines == test_case.process_body(msg.body[begin:to])

# Generated at 2022-06-25 19:02:15.464121
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Init the test case
    msg = HTTPMessage('', '', '', '', '')
    conversion = Conversion('')
    formatting = Formatting('')
    prettyStream = PrettyStream(msg, conversion, formatting)

    # test the iter_body
    assert prettyStream.iter_body()



# Generated at 2022-06-25 19:02:18.469160
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    b = BaseStream()
    assert b.with_headers
    assert b.with_body
    assert b.on_body_chunk_downloaded is None


# Generated at 2022-06-25 19:02:29.816448
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    #Test case 0
    stream = RawStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    iter = stream.__iter__()
    yield [next(iter), next(iter)]

    #Test case 1
    stream = RawStream(msg, with_headers=True, with_body=False, on_body_chunk_downloaded=None)
    iter = stream.__iter__()
    yield [next(iter)]

    #Test case 2
    stream = RawStream(msg, with_headers=False, with_body=True, on_body_chunk_downloaded=on_body_chunk_downloaded)
    iter = stream.__iter__()
    yield [next(iter), next(iter), next(iter)]



# Generated at 2022-06-25 19:02:57.497981
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # data
    msg = HTTPMessage(
        method='GET',
        url='http://example.com/',
        headers={
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Accept-Encoding': '*'
        },
        body=b''
    )

    # unit test
    assert msg.method == 'GET'
    assert msg.url == 'http://example.com/'
    assert msg.headers['Accept'] == 'application/json'
    assert msg.headers['Content-Type'] == 'application/json'
    assert msg.headers['Accept-Encoding'] == '*'
    assert msg.body == b''


# Generated at 2022-06-25 19:03:00.377912
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream()
    stream.msg.cached_body = "test"
    assert list(stream.iter_body()) == ["test"]



# Generated at 2022-06-25 19:03:05.839405
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test = EncodedStream(None, None, with_body = True)
    print("Test EncodedStream.iter_body()")
    for i in test.iter_body():
        print(i)
    print("\n")

# This function is used to test the EncodedStream.iter_body() function
# and BinarySuppressedError.__init__() function

# Generated at 2022-06-25 19:03:12.754136
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Construct an EncodedStream instance
    # Input: msg: an HTTPMessage instance
    #        with_headers: a boolean
    #        with_body: a boolean
    #        on_body_chunk_downloaded: a Callable[[bytes], None]
    encoded_stream = EncodedStream(msg=HTTPMessage, with_headers=True, with_body=True, on_body_chunk_downloaded=None)


# Generated at 2022-06-25 19:03:14.506756
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    try:
        test_case_0()
    except "EncodedStream()":
        return
    assert False

# Generated at 2022-06-25 19:03:17.200407
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    test_encoding = Encoding()
    test_conversion = Conversion(test_encoding)
    test_formatting = Formatting()
    test_PrettyStream = PrettyStream(test_conversion, test_formatting)

# Generated at 2022-06-25 19:03:19.127315
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
	msg = HTTPMessage()
	output_encoding = 'utf8'
	test_case_0()
	test_EncodedStream = EncodedStream()



# Generated at 2022-06-25 19:03:25.026656
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Initialization of class BufferedPrettyStream with no arguments
    obj = BufferedPrettyStream()
    assert isinstance(obj, BufferedPrettyStream)

    # Initialization of class BufferedPrettyStream with arguments
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    obj = BufferedPrettyStream(msg, with_headers, with_body)
    assert isinstance(obj, BufferedPrettyStream)



# Generated at 2022-06-25 19:03:31.784055
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # For example, test that the method does not call a method that is not implemented in its super class.
    list_of_invalid_methods = ['UnknownMethod1', 'UnknownMethod2', 'UnknownMethod3']
    for method in list_of_invalid_methods:
        assert method not in PrettyStream.__bases__[0].__dict__, \
            'Method ' + method + ' is not in the super class of PrettyStream.'



# Generated at 2022-06-25 19:03:33.243867
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    test_env = Environment()
    test_EncodedStream = EncodedStream(env=test_env)
    assert test_EncodedStream.output_encoding == test_env.stdout_encoding


# Generated at 2022-06-25 19:03:56.703154
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    t_BaseStream___iter__0 = RawStream()
    # Check that the next executable statement is False
    assert False, "Method __iter__ in class BaseStream not implemented"


# Generated at 2022-06-25 19:04:01.245677
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # create new object PrettyStream
    obj = PrettyStream
    # check the default value of instance variable with_headers
    if obj.with_headers == True:
        print('test_case 1: pass')
    else:
        print('test_case 1: fail')
    # check the default value of instance variable with_body
    if obj.with_body == True:
        print('test_case 2: pass')
    else:
        print('test_case 2: fail')


# Generated at 2022-06-25 19:04:12.042461
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(headers=[['content-type', 'application/json']])
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting(color=True))

    expected_output = '{\n    "test": "jsonString"\n}'
    output = stream.process_body('{"test":"jsonString"}'.encode('utf8'))
    assert output == expected_output.encode('utf8')

    expected_output = '{\n    "test": "\x1b[94mjsonString\x1b[39m"\n}'
    output = stream.process_body('{"test":"jsonString"}'.encode('utf8'))
    assert output == expected_output.encode('utf8')


# Generated at 2022-06-25 19:04:16.325600
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    print('Running unit test for method EncodedStream.iter_body')
    test_iter_body_UTF8_clean_string()
    test_iter_body_UTF8_encode_error()
    test_iter_body_UTF16_clean_string()
    test_iter_body_UTF16_encode_error()
    test_iter_body_UTF16_binary_string()


# Generated at 2022-06-25 19:04:27.589803
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1
    test_case_1_kwargs = {
        'chunk': 'Hello World',
        'encoding': 'utf8',
        'mime': 'text/plain',
        'with_headers': True,
        'with_body': True,
        'on_body_chunk_downloaded': None,
        'env': Environment(),
        'conversion': Conversion(),
    }
    test_case_1_kwargs['formatting'] = Formatting(
        color_scheme='auto',
        default_colors=('green', None, False),
        headers=(None, 'green'),
        body='green',
        body_max_size=Formatting.UNSPECIFIED,
    )

    # The following test case code is extracted from
    # https://github.com/jkbrzt/

# Generated at 2022-06-25 19:04:38.777523
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Testing for the case when with_body == false and with_headers == true
    some_msg = HTTPMessage(headers={})
    some_BaseStream = BaseStream(some_msg, with_headers=True, with_body=False)
    some_BaseStream_iter = some_BaseStream.__iter__()
    assert list(some_BaseStream_iter) == [b'']
    # Testing for the case when with_body == true and with_headers == false
    some_msg = HTTPMessage(headers={})
    some_BaseStream = BaseStream(some_msg, with_headers=False, with_body=True)
    some_BaseStream_iter = some_BaseStream.__iter__()
    assert list(some_BaseStream_iter) == []
    # Testing for the case when with_body == true and with

# Generated at 2022-06-25 19:04:45.964414
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    env = Environment()
    env.stdout_isatty = False
    env.stdout_encoding = 'utf-8'
    stream = EncodedStream(msg=HTTPMessage(), env=env, with_headers=False, with_body=False, on_body_chunk_downloaded=None)
    for chunk in stream.iter_body():
        pass
    stream = EncodedStream(msg=HTTPMessage(), env=env, with_headers=False, with_body=False, on_body_chunk_downloaded=None)
    for chunk in stream.iter_body():
        pass

# Generated at 2022-06-25 19:04:46.969643
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    test_case_0()

# Generated at 2022-06-25 19:04:53.354429
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = None
    with_headers = 0
    with_body = 0
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    on_body_chunk_downloaded = None
    bp_stream = BufferedPrettyStream(msg,
                                     with_headers,
                                     with_body,
                                     env,
                                     conversion,
                                     formatting,
                                     on_body_chunk_downloaded)
    assert bp_stream.msg == None
    assert bp_stream.with_headers == False
    assert bp_stream.with_body == False
    assert bp_stream.env == env
    assert bp_stream.conversion == conversion
    assert bp_stream.formatting == formatting
    assert bp_stream.on_body_chunk_downloaded == None
   

# Generated at 2022-06-25 19:05:00.736862
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    
    # noinspection PyTypeChecker
    ps = PrettyStream(Response(), formatting=None, conversion=None, msg=None, on_body_chunk_downloaded=None, with_body=True, with_headers=True)
    ps.msg = None
    test_PrettyStream_iter_body_0(ps)
    test_PrettyStream_iter_body_1(ps)
    test_PrettyStream_iter_body_2(ps)


# Generated at 2022-06-25 19:05:52.599727
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    list_1 = []
    chunk_0 = b'alpha\r\n'
    chunk_1 = b'beta\r\n'
    chunk_2 = b'gamma\r\n'
    chunk_3 = b'delta\r\n'
    chunk_4 = b'epsilon\r\n'
    list_1.append(chunk_0)
    list_1.append(chunk_1)
    list_1.append(chunk_2)
    list_1.append(chunk_3)
    list_1.append(chunk_4)
    msg_0 = HTTPMessage(list_1)
    with_headers_0 = True
    with_body_0 = True
    env_0 = Environment()
    conversion_0 = Conversion()

# Generated at 2022-06-25 19:05:58.703366
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        b'HTTP/1.1 200 OK\r\n'
        b'Content-Type: text/html; charset=utf-8\r\n'
        b'Content-Length: 13\r\n'
        b'Connection: continue\r\n'
        b'\r\n'
        b'<h1>foo</h1>'
    )
    a = EncodedStream(msg=msg)
    print(a.iter_body())

# Generated at 2022-06-25 19:06:04.952952
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    env = Environment()
    hs = EncodedStream(env, msg=HTTPMessage(b'body message'))
    gen_0 = hs.iter_body()
    test_iter = iter(gen_0)
    res_0 = next(test_iter)
    assert res_0 == b'body message'


# Generated at 2022-06-25 19:06:13.208132
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessage
    from httpie.output.streams import BaseStream

    # Test with arguments : [<class 'httpie.models.HTTPMessage'>, True, True, <function test_BaseStream___iter__.<locals>.<lambda> at 0x000001CDF964A6A8>]
    msg = HTTPMessage(headers='', body='')
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = lambda *args, **kwargs : None
    BaseStream(arg1=msg, arg2=with_headers, arg3=with_body, arg4=on_body_chunk_downloaded)


# Generated at 2022-06-25 19:06:14.691355
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-25 19:06:22.163025
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream(msg='HTTP/1.1 200 OK\r\nContent-Length: 19\r\n\r\n{"foo":"bar"}')
    stream = EncodedStream(msg=b'HTTP/1.1 200 OK\r\nContent-Length: 19\r\n\r\n{"foo":"bar"}')
    stream = EncodedStream(msg=HTTPMessage(b'HTTP/1.1 200 OK\r\nContent-Length: 19\r\n\r\n{"foo":"bar"}', b'{"foo":"bar"}'))
    x = stream.iter_body()
    print(x)
    for i in x:
        print(i)



# Generated at 2022-06-25 19:06:31.676061
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():

    # Arrange
    header_list = ['a:b', 'c:d']
    headers_to_test = HTTPMessage(header_list, None, None, None)
    stream = PrettyStream(
        headers_to_test,
        with_headers=True,
        with_body=False,
        on_body_chunk_downloaded=None,
        conversion=None,
        formatting=None,
    )
    # Act
    result = stream.get_headers()
    # Assert
    expected_result = 'a:b\r\nc:d'.encode('utf8')
    assert result == expected_result, "Expected {} but got {}".format(result, expected_result)

    
if __name__ == '__main__':
    test_case_0()
    test_PrettyStream_get

# Generated at 2022-06-25 19:06:34.927195
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Create a pretty stream message
    temp = PrettyStream(Conversion(), Formatting())

    # Check that the value returned is correct
    assert isinstance(temp.iter_body(), Iterator)



# Generated at 2022-06-25 19:06:38.008603
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    sut = BaseStream(msg=None, with_headers=None, with_body=None, on_body_chunk_downloaded=None)

    # Smoke test for method __iter__ of class BaseStream
    assert isinstance(list(sut), list)


# Generated at 2022-06-25 19:06:47.924917
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class DummyStream:
        headers = ''
        body = 'Test Body'
        encoding = 'utf-8'
        content_type = 'application/json'
        def iter_body(self, chunk_size=1):
            return DummyStream.body

    class Dummy:
        def format_body(self, content, mime):
            return content

    class DummyEs:
        def __init__(self, env):
            self.env = env

        def get_converter(self, mime):
            return None

    class DummyFormatting:
        def __init__(self):
            self.formatter_classes_by_mime = {}

    dummy_stream = DummyStream()
    dummy = Dummy()
    dummy_es = DummyEs(dummy)
    dummy_formatting = D

# Generated at 2022-06-25 19:07:44.676277
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    encoded_stream_0 = EncodedStream(env)
    test_case_0
    assert encoded_stream_0 == encoded_stream_0.CHUNK_SIZE
    assert encoded_stream_0 != encoded_stream_0.on_body_chunk_downloaded
    assert encoded_stream_0 != encoded_stream_0.with_header


# Generated at 2022-06-25 19:07:51.854267
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    with pytest.raises(NotImplementedError):
        for _ in raw_stream_0: pass
    raw_stream_1 = RawStream()
    with pytest.raises(NotImplementedError):
        for _ in raw_stream_1: pass
    raw_stream_2 = RawStream()
    with pytest.raises(NotImplementedError):
        for _ in raw_stream_2: pass
    raw_stream_3 = RawStream()
    with pytest.raises(NotImplementedError):
        for _ in raw_stream_3: pass


# Generated at 2022-06-25 19:08:02.345719
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from tests.data.responses import NON_ASCII_RESPONSE
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    conv = Conversion()
    fmt = Formatting()
    print(conv)
    print(fmt)
    env = Environment()
    headers = Response(NON_ASCII_RESPONSE.headers).headers
    body = NON_ASCII_RESPONSE.body
    encoding = 'utf8'
    stream = BufferedPrettyStream(
        Response(None, headers, body),
        conversion=conv,
        encoding=encoding,
        formatting=fmt,
        env=env,
        with_headers=False,
        with_body=True
    )

# Generated at 2022-06-25 19:08:13.356695
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage.build(200, headers=['Content-Type: text/plain'],
            body='Hello, World!')

    stream_0 = PrettyStream(msg, with_headers=False, with_body=True, env=Environment(),
            conversion=Conversion())

    stream_0.get_headers()

    assert list(stream_0.iter_body()) == [b'Hello, World!']

    msg = HTTPMessage.build(200, headers=['Content-Type: text/html'],
            body='<p>Hello, World!</p>')
    stream_1 = PrettyStream(msg, with_headers=False, with_body=True, env=Environment(),
            conversion=Conversion())

    stream_1.get_headers()


# Generated at 2022-06-25 19:08:14.232690
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    assert(1 == 1)



# Generated at 2022-06-25 19:08:14.779212
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    assert True

# Generated at 2022-06-25 19:08:16.807597
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    print("\n Testing __init__() of class BufferedPrettyStream ...")
    pretty_stream_0 = BufferedPrettyStream()
    print("\n Tested __init__() of class BufferedPrettyStream !")


# Generated at 2022-06-25 19:08:25.030220
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    print('Unit test for method iter_body of class BufferedPrettyStream')
    for i in range(10):
        encoding = random.choice(['utf-8', 'gbk'])
        content_type = random.choice(['text/plain', 'text/html', 'image/png'])
        body = ''.join([random.choice(string.printable) for _ in range(random.randint(10,30))])
        msg = HTTPMessage(headers={'content-type': content_type}, encoding=encoding, body=body)
        print('')
        print('encoding:', encoding)
        print('content_type:', content_type)
        print('body:', body)
        print('len(body):', len(body))

# Generated at 2022-06-25 19:08:33.569910
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Check whether constructor throws a TypeError exception when parameter is incorrect
    try:
        # TypeError: __init__() takes 1 positional argument but 2 were given
        BufferedPrettyStream(dict(), dict())
    except TypeError:
        # The constructor throws a TypeError exception when parameter is incorrect
        assert True
    else:
        assert False
    try:
        # TypeError: __init__() takes from 1 to 4 positional arguments but 7 were given
        BufferedPrettyStream(1, dict(), dict(), dict(), dict(), dict(), dict())
    except TypeError:
        # The constructor throws a TypeError exception when parameter is incorrect
        assert True
    else:
        assert False

# Generated at 2022-06-25 19:08:36.266300
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream = PrettyStream(Conversion(), Formatting())

    str0 = pretty_stream.process_body('test')
    bytes0 = pretty_stream.process_body(b'test')
    assert str0 == bytes0

