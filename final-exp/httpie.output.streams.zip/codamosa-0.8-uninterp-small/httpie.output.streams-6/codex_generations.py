

# Generated at 2022-06-25 19:00:04.229868
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # assert True # TODO: implement your test here
    raise NotImplementedError()


# Generated at 2022-06-25 19:00:07.799770
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    conversion_0 = module_0.Conversion()
    raw_stream_0 = RawStream(env=Environment(), msg=HTTPMessage(), with_body=True, with_headers=True)
    raw_stream_0.conversion = conversion_0
    raw_stream_0.iter_body()


# Generated at 2022-06-25 19:00:15.565266
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():

    raw_stream_0 = RawStream()
    raw_stream_0.iter_body()
    raw_stream_0.get_headers()
    raw_stream_0.with_body
    raw_stream_0.with_headers
    raw_stream_0.msg
    raw_stream_0.chunk_size
    raw_stream_0.on_body_chunk_downloaded
    formatted_response_0 = raw_stream_0.__iter__()
    print(formatted_response_0)


# Generated at 2022-06-25 19:00:21.285152
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Arrange
    conversion_0 = module_0.Conversion()
    binary_suppressed_error_0 = BinarySuppressedError()
    # Act
    pretty_stream_0 = PrettyStream(conversion_0, 'conversion_0', binary_suppressed_error_0, 'with_body', 'binary_suppressed_error_0')


# Generated at 2022-06-25 19:00:33.125956
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    try:
        # case 0

        # preparation
        output_stream_0 = EncodedStream()

        # execution
        with raises(BinarySuppressedError):
            list(output_stream_0.iter_body())

        # verification
        # NOTE: BinarySuppressedError is not catchable

    except BinarySuppressedError:
        # verification
        pass


# Generated at 2022-06-25 19:00:40.237772
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    env_0 = Environment()
    msg_0 = HTTPMessage(headers={}, body=b'', encoding='utf8')
    conversion_0 = Conversion()
    formatting_0 = Formatting()
    pretty_stream_0 = PrettyStream(
        msg_0,
        env_0,
        conversion_0,
        formatting_0,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=(lambda: (yield)),
    )



# Generated at 2022-06-25 19:00:49.842612
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    env_0 = Environment(default_options=None, stdin=None, stdin_isatty=False, stdout=None, stdout_isatty=False, stdout_encoding='None', stdout_errors=None, color_mode=None, colors=None, styles=None, force_stream=False, default_headers=None, default_options=None, default_auth=None, verify=True, final_callback=None, request_as_tornado=False, error_codes=None, output_options=None)
    body_0 = RawStream(chunk_size=None, env=env_0, msg=None, on_body_chunk_downloaded=None, with_body=True, with_headers=True).get_body()



# Generated at 2022-06-25 19:00:58.636887
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from io import BytesIO

    msg_0 = HTTPMessage()
    msg_0.encoding = "utf-8"
    msg_0.body = BytesIO(b"ABCDE")

    stream_0 = EncodedStream(msg=msg_0)

    from unittest import mock
    with mock.patch('httpie.output.streams.EncodedStream.__iter__',
                    return_value = stream_0) as mock_0:
        assert str(mock_0.return_value) == '<EncodedStream>'
        # This should not throw an exception
        for line in stream_0:
            pass

# Generated at 2022-06-25 19:01:00.293002
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    environment_0 = Environment()
    encoded_stream_0 = EncodedStream(env=environment_0)


# Generated at 2022-06-25 19:01:02.486776
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream(msg=HTTPMessage())
    assert isinstance(raw_stream_0.iter_body(), Iterable)


# Generated at 2022-06-25 19:01:19.119778
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    try:
        var_0 = PrettyStream(
            conversion=None,
            formatting=None,
            msg=None,
            with_headers=False,
            with_body=False,
            on_body_chunk_downloaded=None
        )
        assert var_0 != None
        var_1 = var_0.get_headers()
    except NotImplementedError as var_2:
        var_1 = var_2.message
    assert var_1 == "\n\n\n\n"


# Generated at 2022-06-25 19:01:22.482997
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Instantiate the class
    obj = PrettyStream()
    # Test the case
    # The body is binary and won't be written, e.g., for terminal output).
    try:
        obj.get_headers()
    except BinarySuppressedError:
        pass


# Generated at 2022-06-25 19:01:30.721768
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    var_env = Environment()
    var_msg = HTTPMessage()
    var_with_headers = True
    var_with_body = True
    var_on_body_chunk_downloaded = NotImplementedError()

    var_1 = EncodedStream(var_msg,var_with_headers,var_with_body,var_on_body_chunk_downloaded)
    assert var_1.msg == var_msg
    assert var_1.with_headers == var_with_headers
    assert var_1.with_body == var_with_body
    assert var_1.on_body_chunk_downloaded == var_on_body_chunk_downloaded
    assert var_1.output_encoding == 'utf8'
    assert var_1.CHUNK_SIZE == 1

#

# Generated at 2022-06-25 19:01:32.970107
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    var_1 = PrettyStream(NotImplementedError())
    var_2 = var_1.get_headers()


# Generated at 2022-06-25 19:01:37.319236
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Setting up data 0, more than one
    var_0 = NotImplementedError()
    # Create object of class PrettyStream
    # Call method iter_body of object
    # Check value of var_0
    assert NotImplementedError, var_0


# Generated at 2022-06-25 19:01:39.665791
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    line, lf = 'TEST STRING', 'TEST STRING'
    test_obj = EncodedStream()
    assert test_obj.iter_body() == line


# Generated at 2022-06-25 19:01:42.808086
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    print ("Test __iter__ for class BaseStream")
    var_0 = BufferedPrettyStream()
    var_0.__iter__()


# Generated at 2022-06-25 19:01:50.396022
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Description
    # Test case for testing iter_body() method of RawStream class

    # Test case setup
    # Create the needed objects
    msg = HTTPMessage()
    stream = RawStream(msg)

    # Test case body
    # Test if the type object was created
    if isinstance(stream, RawStream):

        # Test the `RawStream.iter_body()` method
        assert isinstance(stream.iter_body(), Iterable[bytes])
    else:
        raise AssertionError("There is no class RawStream")


# Generated at 2022-06-25 19:01:51.860048
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    var_0 = PrettyStream()
    var_0.get_headers()


# Generated at 2022-06-25 19:01:53.446889
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 19:02:22.917605
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    try:
        var_0 = BufferedPrettyStream()
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-25 19:02:27.975375
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    var_0 = PrettyStream(mime='this_is_mime', with_body=False)
    assert isinstance(var_0, PrettyStream)
    try:
        var_0 = PrettyStream(None)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 19:02:32.253595
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    var_1 = NotImplementedError()
    def test_case_1():
        """BaseStream.__iter__"""
        var_1 = NotImplementedError()
    def test_case_2():
        """BaseStream.__iter__"""
        var_1 = NotImplementedError()


# Generated at 2022-06-25 19:02:33.747727
# Unit test for constructor of class RawStream
def test_RawStream():
    var_0 = RawStream()


# Generated at 2022-06-25 19:02:34.616299
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print("test_EncodedStream")
    var_1 = EncodedStream()


# Generated at 2022-06-25 19:02:37.922771
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    var = PrettyStream()
    try:
        var.iter_body()
        raise Exception('Not raised NotImplementedError')
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:02:39.662645
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    var_2 = NotImplementedError()


# Generated at 2022-06-25 19:02:43.132602
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    var_0 = PrettyStream(None, None)
    var_1 = NotImplementedError()
    try:
        var_0.get_headers()
    except var_1:
        pass


# Generated at 2022-06-25 19:02:44.004014
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    var_1 = RawStream()


# Generated at 2022-06-25 19:02:48.850573
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    obj = BufferedPrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded, conversion, formatting)
    print("Pass" if obj else "Fail")


# Generated at 2022-06-25 19:03:33.539567
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    var_0 = PrettyStream()
    with pytest.raises(NotImplementedError):
        var_0.iter_body()


# Generated at 2022-06-25 19:03:41.966515
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import httpie

    env_0 = httpie.Environment()

    msg_0 = httpie.models.HTTPMessage()

    # Parameter msg has a default value of None
    # Parameter with_headers has a default value of True
    # Parameter with_body has a default value of True
    # Parameter on_body_chunk_downloaded has a default value of None
    stream_0 = BaseStream()
    stream_1 = BaseStream(msg=msg_0)
    stream_2 = BaseStream(msg=msg_0, with_headers=True)
    stream_3 = BaseStream(msg=msg_0, with_headers=True, with_body=True)

# Generated at 2022-06-25 19:03:46.156181
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    param_0 = None
    pretty_stream = PrettyStream(param_0, param_0)
    param_0 = b''
    # TypeError: 'str' object cannot be interpreted as an integer
    #pretty_stream.process_body(param_0)
    assert pretty_stream.process_body(param_0)

# Generated at 2022-06-25 19:03:54.922320
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    with_body = True
    with_headers = True
    on_body_chunk_downloaded = None
    var_0 = BufferedPrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded, conversion, formatting)
    assert isinstance(var_0.iter_body(), Generator)
    # Raise exception
    try:
        var_0.iter_body()
    except NotImplementedError as var_1:
        var_0 = var_1


# Generated at 2022-06-25 19:03:57.334080
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    try:
        var_1 = BufferedPrettyStream()
    except Exception:
        var_2 = True
    else:
        var_2 = False
    assert var_2


# Generated at 2022-06-25 19:03:59.929957
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    var_0 = HTTPMessage()
    var_1 = Conversion()
    var_2 = Formatting()
    var_3 = PrettyStream(var_0, var_1, var_2)
    var_4 = var_3.iter_body()

# Generated at 2022-06-25 19:04:07.575969
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # test_stream_encoded_byte_lines_body
    stream = EncodedStream(msg=b'\xc3\xa9\xc3\xbd', encoding='utf8')
    chunks = list(stream.iter_body())
    assert chunks == [b'\xc3\xa9', b'\xc3\xbd']
    # test_stream_encoded_unicode_lines_body
    stream = EncodedStream(msg=u'\xc3\xa9\xc3\xbd', encoding='utf8')
    chunks = list(stream.iter_body())
    assert chunks == [b'\xc3\xa9', b'\xc3\xbd']
    # test_stream_encoded_byte_lines_body__with_trailing_newline

# Generated at 2022-06-25 19:04:12.294425
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Set up test values
    arg_0 = PrettyStream(arg_0=None, arg_1=None, arg_2=None, arg_3=None, arg_4=None, arg_5=None)

    # Invoke method
    result = arg_0.get_headers()

    expected_result = None
    assert expected_result == result


# Generated at 2022-06-25 19:04:14.641899
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    var_1 = PrettyStream(None, None)
    var_2 = NotImplementedError()
    return (var_1, var_2)


# Generated at 2022-06-25 19:04:17.654081
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    var_0 = EncodedStream(msg=None, with_headers=None, with_body=None)
    try:
        var_0.iter_body()
    except:
        print("Test case 0: Failed")
    else:
        print("Test case 0: Success")

# Calling above defined methods to perform unit testing
test_EncodedStream_iter_body()
test_case_0()

# Generated at 2022-06-25 19:05:05.410971
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Setup
    var_0 = NotImplementedError()
    obj_0 = PrettyStream(var_0, var_0, var_0, var_0)

    # Invocation
    # Expected Output
    assert True


# Generated at 2022-06-25 19:05:06.933312
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    var_1 = EncodedStream()
    var_2 = var_1.iter_body()


# Generated at 2022-06-25 19:05:10.693969
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    var_3 = PrettyStream(Conversion(), Formatting())
    var_4 = str('')
    method_ret_2 = var_3.process_body(var_4)
    Expect(method_ret_2).to_be_instance_of(bytes)


# Generated at 2022-06-25 19:05:13.171947
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    var_0 = EncodedStream()
    # var_0.
    # raise Exception(var_0.iter_body())
    assert (var_0.iter_body() is NotImplementedError)


# Generated at 2022-06-25 19:05:15.796942
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Unit test for method iter_body of class EncodedStream
    print("Test for method iter_body of class EncodedStream")
    var_0 = iter(EncodedStream())
    assert isinstance(var_0, Iterable)

# Generated at 2022-06-25 19:05:21.129670
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    var_2 = PrettyStream(NotImplementedError(), NotImplementedError())
    # Throws an exception of type AssertionError at /root/httpie/httpie/output/streams.py:219
    var_2.process_body(NotImplementedError())


# Generated at 2022-06-25 19:05:30.679414
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class PrettyStreamTestCase(SpoofIn, unittest.TestCase):
        def setUp(self):
            self.msg = HTTPMessage()
            self.output_encoding = 'utf8'
            self.conversion = Conversion()
            self.formatting = Formatting()
        
        def test_PrettyStream_iter_body_case_0(self):
            # Creating test data

            # Getting function to be tested
            var_0 = PrettyStream.iter_body(self)

            # Testing function
            var_0 = self.read_all(var_0)
            var_0 = self.iter_body()

            # Assertions
            self.assertIsNotNone(var_0)
        

# Generated at 2022-06-25 19:05:33.799196
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    var_0 = EncodedStream()
    try:
        var_0.iter_body()
    except BaseException as var_1:
        var_2 = var_1
    else:
        var_2 = None
    assert isinstance(var_2, NotImplementedError)


# Generated at 2022-06-25 19:05:36.495371
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    var_1 = RawStream()
    var_1.msg = HTTPMessage()
    try:
        var_1.iter_body()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:05:39.439948
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    var_0 = RawStream()
    var_1 = var_0.iter_body()
    var_2 = assertRaises(NotImplementedError, var_1)


# Generated at 2022-06-25 19:07:19.649693
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    print("===============Unit test for constructor of class PrettyStream")
    try:
        var_0 = PrettyStream()
    except Exception:
        print("converters: ", 'None', "formatting: ", 'None', "msg: ", 'None', "with_headers: ", 'True', "with_body: ", 'True', "on_body_chunk_downloaded: ", 'None', sep='', end='\n\n')
        print("Exception when calling constructor of class PrettyStream")
        print("Exception Traceback: ", Exception, sep='', end='\n\n')

# Generated at 2022-06-25 19:07:20.901650
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    var_1 = PrettyStream()


# Generated at 2022-06-25 19:07:32.235586
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    import httpie
    import random
    import string
    import pytest

    from httpie import ExitStatus
    from utils import TestEnvironment, http, HTTP_OK
    from fixtures import (
        FILE_PATH, FILE_CONTENT, FILE_PATH_ARG
    )
    from httpie.compat import urlopen
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    """Test PrettyStream."""
    # AssertionError: assert False
    env = TestEnvironment()
    conversion = httpie.output.processing.Conversion()
    formatting = httpie.output.processing.Formatting()
    test_items_0 = [
        HTTP_OK,
        HTTP_OK.replace('/get', '/post'),
        HTTP_OK.replace('/get', '/patch'),
    ]

# Generated at 2022-06-25 19:07:43.557108
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # var_0 initialization
    var_0 = "utf-8"
    # var_1 initialization
    var_1 = NotImplementedError()
    # var_2 initialization
    var_2 = NotImplementedError()
    # var_3 initialization
    var_3 = NotImplementedError()
    # var_4 initialization
    var_4 = NotImplementedError()
    # var_5 initialization
    var_5 = NotImplementedError()
    # var_6 initialization
    var_6 = NotImplementedError()
    # var_7 initialization
    var_7 = NotImplementedError()
    # var_8 initialization
    var_8 = NotImplementedError()
    # var_9 initialization
    var_9 = NotImplementedError()
    # var_10 initialization
    var_

# Generated at 2022-06-25 19:07:47.508591
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # default
    var_1 = 'a'
    var_2 = 'b'
    # normal return
    for var_3 in range(10):
        for var_4 in range(10):
            test_case_0()

# Test for class EncodedStream

# Generated at 2022-06-25 19:07:53.783538
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    _env = Environment(stdout_isatty=True)
    _http_message = HTTPMessage(headers=['foo'], body=['bar'])
    _with_headers = True
    _with_body = True
    
    PrettyStream(conversion=_conversion, formatting=_formatting, msg=_http_message, with_headers=_with_body, with_body=_with_headers, env=_env).get_headers()



# Generated at 2022-06-25 19:07:55.301053
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    var_0 = BufferedPrettyStream()


# Generated at 2022-06-25 19:08:05.347308
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    var_1 = PrettyStream()
    var_1.msg = HTTPMessage()
    var_1.msg.headers = "'Content-Type: application/json; encoding=utf8\\r\\n'"
    var_1.msg.headers = "var_1.msg.headers"
    var_1.output_encoding = "'utf8'"
    var_1.output_encoding = "var_1.output_encoding"
    var_1.formatting = Formatting()
    var_1.formatting = "var_1.formatting"
    var_1.get_headers = var_1.formatting.format_headers(var_1.msg.headers)
    var_1.get_headers = "var_1.get_headers"
    var_1.get_headers().strip()


# Generated at 2022-06-25 19:08:10.170847
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    var_0 = PrettyStream()
    var_1 = var_0.process_body(b'\x00')
    print(var_1)
    assert (var_1 == b'\x00')


# Generated at 2022-06-25 19:08:17.997127
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    try:
        var_0 = EncodedStream()
    except:
        print("Test case 0 failed")
        assert False
    try:
        var_1 = EncodedStream(msg=(HTTPMessage(headers=((() or ())), content_type="text/html", encoding="utf8", body=b"")), with_headers=True, with_body=True, on_body_chunk_downloaded=None)
        print("Test case 1 passed")
        assert True
    except:
        print("Test case 1 failed")
        assert False