

# Generated at 2022-06-25 19:00:04.440808
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    dict_0 = {}
    base_stream_0 = BaseStream(**dict_0)
    try:
        base_stream_0.__iter__()
    except DataSuppressedError as e:
        sys.stdout.write(e.message)


# Generated at 2022-06-25 19:00:10.086155
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    dict_0 = {}
    base_stream_0 = BaseStream(**dict_0)
    dict_1 = {
        'msg' : base_stream_0,
    }
    encoded_stream_0 = EncodedStream(**dict_1)


# Generated at 2022-06-25 19:00:11.149987
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    pass


# Generated at 2022-06-25 19:00:22.394777
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    dict_0 = {}
    binary_suppressed_error_0 = BinarySuppressedError(**dict_0)
    binary_suppressed_error_1 = BinarySuppressedError(**dict_0)

    mime = content_type.ContentType('', '', {'charset': self.encoding})
    http_message_0 = HTTPMessage(mime, headers, '', self.url)
    base_stream_0 = BaseStream(http_message_0, True, True, binary_suppressed_error_0)
    httpie_output_writer_0 = HttpieOutputWriter(sys.stdout, '')
    httpie_output_writer_0.write = binary_suppressed_error_1
    base_stream_0.write_to_output(httpie_output_writer_0)


# Generated at 2022-06-25 19:00:24.329858
# Unit test for constructor of class RawStream
def test_RawStream():
    dict_0 = {}
    rawstream_0 = RawStream(**dict_0)


# Generated at 2022-06-25 19:00:34.727505
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    dict_0 = {}
    binary_suppressed_error_0 = BinarySuppressedError(**dict_0)
    dict_1 = {}
    binary_suppressed_error_1 = BinarySuppressedError(**dict_1)
    dict_2 = {}
    binary_suppressed_error_2 = BinarySuppressedError(**dict_2)
    dict_3 = {}
    binary_suppressed_error_3 = BinarySuppressedError(**dict_3)
    dict_4 = {}
    binary_suppressed_error_4 = BinarySuppressedError(**dict_4)
    dict_5 = {}
    binary_suppressed_error_5 = BinarySuppressedError(**dict_5)
    dict_6 = {}
    binary_suppressed_error_6 = BinarySuppressedError(**dict_6)
    dict_

# Generated at 2022-06-25 19:00:37.919942
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream_0 = PrettyStream(**dict_0)
    int_0 = stream_0.process_body(**dict_0)
    assert int_0 == 0

# Generated at 2022-06-25 19:00:44.158973
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    dict_0 = {}
    # Message headers
    headers_0 = {}
    http_message_0 = HTTPMessage(**dict_0, **headers_0)
    # Headers
    dict_1 = {}
    http_stream_0 = EncodedStream(**dict_0, **dict_1)
    for line, lf in http_message_0.iter_lines(1):
        pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 19:00:45.992894
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    b'NOTE: binary data not shown in terminal' + 10 * b'+' + b'\n'

# Generated at 2022-06-25 19:00:47.728566
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    print('Test iter_body of BufferedPrettyStream')
    test_case_0()


# Generated at 2022-06-25 19:00:56.922345
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    dict_0 = {}
    base_stream_0 = BaseStream(**dict_0)
    iterable_0 = base_stream_0.__iter__()



# Generated at 2022-06-25 19:00:58.078411
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    dict_0 = {}
    encoded_stream_0 = EncodedStream(**dict_0)
    iterable_0 = encoded_stream_0.__iter__()


# Generated at 2022-06-25 19:01:01.154629
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    str_0 = 'x'
    bytes_0 = pretty_stream_0.process_body(str_0)


# Generated at 2022-06-25 19:01:05.364189
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    pretty_stream_0.get_headers()
    dict_1 = {}
    # Uncomment the line below for manual testing
    # pretty_stream_1 = PrettyStream(**dict_1)
    # pretty_stream_1.get_headers()


# Generated at 2022-06-25 19:01:08.382728
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test for assertion with single argument
    try:
        # TypeError check
        BufferedPrettyStream.iter_body(1)
    except TypeError as e:
        print("TypeError exception:", e)


# Generated at 2022-06-25 19:01:10.512813
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    pretty_stream_0.get_headers()


# Generated at 2022-06-25 19:01:16.131230
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    dict_1 = {}
    pretty_stream_0 = PrettyStream(**dict_1)
    str_0 = pretty_stream_0.get_headers()
    str_1 = pretty_stream_0.get_headers()


# Generated at 2022-06-25 19:01:23.838504
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    def mock_get_headers(self):
        return "TEST_VALUE"

    def mock_iter_body(self):
        yield "TEST_VALUE"
        yield "TEST_VALUE"
        yield "TEST_VALUE"
        yield "TEST_VALUE"

    with mock.patch.object(BaseStream, 'get_headers', mock_get_headers):
        with mock.patch.object(BaseStream, 'iter_body', mock_iter_body):
            dict_0 = {
                'with_headers': False,
                'chunk_size': 100,
                'with_body': True,
            }

            def f(self, msg, with_headers, with_body, on_body_chunk_downloaded):
                self.Iterable_0 = iter(msg)
                self.msg = msg
               

# Generated at 2022-06-25 19:01:26.040225
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    iterable_0 = pretty_stream_0.iter_body()


# Generated at 2022-06-25 19:01:30.027827
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import unittest
    import sys

    class TestEncodedStream(unittest.TestCase):
        def test_iter_body(self):
            env = Environment()
            env.stdout_encoding = None
            response = b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nabcd\r\n'
            msg = HTTPMessage(response)
            env.stdout_isatty = True
            self.assertEqual(list(EncodedStream(msg, env=env).iter_body()), [b'abcd\r\n'])

            env.stdout_isatty = False
            assert list(EncodedStream(msg, env=env).iter_body()), [b'abcd\r\n']


# Generated at 2022-06-25 19:01:44.229818
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    assert True # TODO: implement your test here



# Generated at 2022-06-25 19:01:48.169279
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    dict_0 = {}
    base_stream_0 = BaseStream(**dict_0)
    dict_1 = {}
    base_stream_1 = BaseStream(**dict_1)
    dict_2 = {}
    base_stream_2 = BaseStream(**dict_2)
    dict_3 = {}
    base_stream_3 = BaseStream(**dict_3)


# Generated at 2022-06-25 19:01:50.281705
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)


# Generated at 2022-06-25 19:01:52.621821
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    dict_0 = {}
    buffered_pretty_stream_0 = BufferedPrettyStream(**dict_0)
    iterable_0 = buffered_pretty_stream_0.iter_body()

# Generated at 2022-06-25 19:02:02.130099
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_

# Generated at 2022-06-25 19:02:06.128269
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    dict_0 = {}
    buffered_pretty_stream_0 = BufferedPrettyStream(**dict_0)
    iterable_0 = buffered_pretty_stream_0.iter_body()

# Generated at 2022-06-25 19:02:07.471546
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    test_case_0()


# Generated at 2022-06-25 19:02:12.750527
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Initialize
    dict_0 = {}
    encoded_stream_0 = EncodedStream(**dict_0)
    pretty_stream_0 = PrettyStream(**dict_0, conversion=encoded_stream_0)

    # Test
    test_result = pretty_stream_0.get_headers()

    # Verify
    assert test_result is not None

    # Teardown
    teardown_0(pretty_stream_0, test_result)



# Generated at 2022-06-25 19:02:15.316209
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    dict_1 = {}
    buffered_pretty_stream_0 = BufferedPrettyStream(**dict_1)
    assert buffered_pretty_stream_0 == None


# Generated at 2022-06-25 19:02:26.753682
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    dict_0 = {}
    encoded_stream_0 = EncodedStream(**dict_0)
    dict_1 = {"with_body": False}
    encoded_stream_1 = EncodedStream(**dict_1)
    dict_2 = {"with_headers": True, "with_body": True}
    encoded_stream_2 = EncodedStream(**dict_2)
    dict_3 = {"with_body": False}
    encoded_stream_3 = EncodedStream(**dict_3)
    dict_4 = {}
    encoded_stream_4 = EncodedStream(**dict_4)
    dict_5 = {"with_headers": True, "with_body": True}
    encoded_stream_5 = EncodedStream(**dict_5)
    dict_6 = {}
    encoded_stream_6 = EncodedStream

# Generated at 2022-06-25 19:03:16.201929
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    iterable_0 = pretty_stream_0.iter_body()
    # assert iterable_0.__class__() == list
    # assert len(iterable_0) == 0


# Generated at 2022-06-25 19:03:19.569998
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    bytes_0 = b'\x00'
    bytes_1 = bytes_0[::-1]
    iterable_0 = iter(bytes_1)
    str_0 = str()
    encoded_stream_0 = EncodedStream(iterable_0, None)
    assert encoded_stream_0.iter_body() == iterable_0


# Generated at 2022-06-25 19:03:25.222000
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    dict_0 = { 'with_headers': True }
    HTTPMessage_0 = HTTPMessage()
    pretty_stream_0 = PrettyStream(**dict_0)
    iterable_0 = pretty_stream_0.iter_body()
    iterable_1 = HTTPMessage_0.iter_lines(1)
    iterable_2 = iter(iterable_1)


# Generated at 2022-06-25 19:03:27.282283
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    try:
        class_0 = PrettyStream.process_body
    except Exception:
        print('Exception caught')


# Generated at 2022-06-25 19:03:38.190163
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    dict_0 = {}
    buffered_pretty_stream_0 = BufferedPrettyStream(**dict_0)
    assert isinstance(buffered_pretty_stream_0, PrettyStream) == True
    assert isinstance(buffered_pretty_stream_0.msg, HTTPMessage) == True
    assert isinstance(buffered_pretty_stream_0.with_headers, bool) == True
    assert isinstance(buffered_pretty_stream_0.with_body, bool) == True
    assert isinstance(buffered_pretty_stream_0.on_body_chunk_downloaded, Callable) == True
    assert isinstance(buffered_pretty_stream_0.output_encoding, str) == True
    assert isinstance(buffered_pretty_stream_0.formatting, Formatting) == True
    assert isinstance

# Generated at 2022-06-25 19:03:41.869934
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    dict_0 = {}
    encoded_stream_0 = EncodedStream(**dict_0)
    # Test whether __init__() functinalites are not affected
    assert isinstance(encoded_stream_0, EncodedStream)
    iterable_0 = encoded_stream_0.iter_body()
    assert iterable_0 is not None


# Generated at 2022-06-25 19:03:44.778712
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    pretty_stream_0.process_body(123)


# Generated at 2022-06-25 19:03:47.614898
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    dict_0 = {}
    raw_stream_0 = RawStream(**dict_0)
    iterable_0 = raw_stream_0.iter_body()


# Generated at 2022-06-25 19:03:56.589401
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    class DummyResponse:
        def iter_body(self, **kwargs):
            return [b'I am string']

        def iter_lines(self, **kwargs):
            return [('I am string', '\n')]

        @property
        def encoding(self):
            return 'base64'

        @property
        def content_type(self):
            return 'application/json'
        @property
        def headers(self):
            return 'Content-Type: application/json'

    dict_0 = {'msg': DummyResponse()}
    encoded_stream_0 = BufferedPrettyStream(**dict_0)
    iterable_0 = encoded_stream_0.iter_body()



# Generated at 2022-06-25 19:04:03.332418
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # TODO: what if header is in a different encoding?
    assert PrettyStream(headers='', encoding='utf8').get_headers() == ''
    assert PrettyStream(headers='\r\n', encoding='utf8').get_headers() == '\r\n'
    assert PrettyStream(headers='\n', encoding='utf8').get_headers() == '\n'
    assert PrettyStream(headers='\r\n\r\n', encoding='utf8').get_headers() == '\r\n\r\n'
    assert PrettyStream(headers='\n\n', encoding='utf8').get_headers() == '\n\n'
    assert PrettyStream(headers='Content-Type: \n', encoding='utf8').get_headers() == 'Content-Type: '

# Generated at 2022-06-25 19:05:17.332880
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream(
        msg=HTTPMessage(b'hej'),
        conversion=Conversion(),
        formatting=Formatting()
    )
    for line, lf in stream.iter_body():
        print(line, lf)



# Generated at 2022-06-25 19:05:22.763783
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """Unit test for method iter_body of class BufferedPrettyStream"""
    dict_0 = {}
    buffered_pretty_stream_0 = BufferedPrettyStream(**dict_0)
    iterable_0 = buffered_pretty_stream_0.iter_body()


# Generated at 2022-06-25 19:05:32.090627
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    dict_1 = {}
    pretty_stream_0 = PrettyStream(**dict_1)
    iterable_0 = pretty_stream_0.iter_body()
    pretty_stream_1 = PrettyStream(**dict_1)
    iterable_1 = pretty_stream_1.iter_body()
    pretty_stream_2 = PrettyStream(**dict_1)
    iterable_2 = pretty_stream_2.iter_body()
    pretty_stream_3 = PrettyStream(**dict_1)
    iterable_3 = pretty_stream_3.iter_body()
    pretty_stream_4 = PrettyStream(**dict_1)
    iterable_4 = pretty_stream_4.iter_body()
    pretty_stream_5 = PrettyStream(**dict_1)
    iterable_5 = pretty_stream_5

# Generated at 2022-06-25 19:05:36.495355
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    dict_0 = {
        'with_headers': False,
        'with_body': True,
    }
    pretty_stream_0 = PrettyStream(**dict_0)
    str_0 = pretty_stream_0.process_body('cPnj@Qz-Xq3T')
    assert str_0 is not None


# Generated at 2022-06-25 19:05:39.127070
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    pretty_stream_0.get_headers()


# Generated at 2022-06-25 19:05:41.164537
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    dict_0 = {}
    encoded_stream_0 = EncodedStream(**dict_0)
    iterable_0 = encoded_stream_0.iter_body()

# Generated at 2022-06-25 19:05:50.179840
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():

    dict_0 = {}
    encoded_stream_0 = EncodedStream(**dict_0)
    iterable_0 = encoded_stream_0.iter_body()

    dict_1 = {}
    encoded_stream_1 = EncodedStream(**dict_1)
    iterable_1 = encoded_stream_1.iter_body()

    dict_2 = {}
    encoded_stream_2 = EncodedStream(**dict_2)
    iterable_2 = encoded_stream_2.iter_body()

    dict_3 = {}
    encoded_stream_3 = EncodedStream(**dict_3)
    iterable_3 = encoded_stream_3.iter_body()

    dict_4 = {}
    encoded_stream_4 = EncodedStream(**dict_4)
    iterable_4 = encoded_stream_4

# Generated at 2022-06-25 19:05:52.325874
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    pretty_stream_0.process_body(str(True))

# Generated at 2022-06-25 19:05:54.818082
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    dict_0 = {}
    raw_stream_0 = RawStream(dict_0)
    iterable_0 = raw_stream_0.iter_body()


# Generated at 2022-06-25 19:05:58.218612
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    dict_0 = {}
    buffered_pretty_stream_0 = BufferedPrettyStream(**dict_0)
    iterable_0 = buffered_pretty_stream_0.iter_body()
    bool_0 = isinstance(iterable_0, Iterable)
    assert bool_0

# Generated at 2022-06-25 19:08:36.774106
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    iterable_0 = pretty_stream_0.iter_body()


# Generated at 2022-06-25 19:08:43.786403
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    dict_0 = {}
    raw_stream_0 = RawStream(**dict_0)
    for b in raw_stream_0:
        pass
    dict_0 = {}
    encoded_stream_0 = EncodedStream(**dict_0)
    for b in encoded_stream_0:
        pass
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    for b in pretty_stream_0:
        pass
    dict_0 = {}
    buffered_pretty_stream_0 = BufferedPrettyStream(**dict_0)
    for b in buffered_pretty_stream_0:
        pass


# Generated at 2022-06-25 19:08:47.125031
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    pretty_stream_0.mime = ''
    pretty_stream_0.output_encoding = ''
    with pytest.raises(Exception):
        pretty_stream_0.iter_body()


# Generated at 2022-06-25 19:08:49.369772
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    dict_0 = {}
    pretty_stream_0 = BufferedPrettyStream(**dict_0)
    iterable_0 = pretty_stream_0.iter_body()



# Generated at 2022-06-25 19:08:51.481439
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # TODO: Mute stdout
    dict_0 = {}
    encoded_stream_0 = EncodedStream(**dict_0)
    encoded_stream_0.iter_body()
    # TODO: Unmute stdout


# Generated at 2022-06-25 19:08:52.727359
# Unit test for constructor of class RawStream
def test_RawStream():
    dict_0 = {}
    raw_stream_0 = RawStream(**dict_0)


# Generated at 2022-06-25 19:09:01.134198
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    string_0 = 'mime'
    string_1 = 'content'
    conversion_0 = Conversion()
    formatting_0 = Formatting()
    struct_0 = struct()
    struct_0.content_type = field(type='str', default="")
    struct_0.decode_content = field(type='bool', default=True)
    struct_0.content = field(type='str')
    struct_0.encoding = field(type='str')
    struct_0.headers = field(type='httpie.models.HeadersDict')

    HTTPMessage_0 = HTTPMessage(**struct_0)

    dict_0 = {'msg':HTTPMessage_0, 'conversion': conversion_0, 'formatting': formatting_0}

# Generated at 2022-06-25 19:09:03.609153
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    dict_0 = {}
    base_stream_0 = BaseStream(**dict_0)
    iterable_0 = base_stream_0.__iter__()


# Generated at 2022-06-25 19:09:08.488587
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    dict_0 = {
        'conversion': None,
        'formatting': None,
    }
    pretty_stream_0 = PrettyStream(**dict_0)
    pretty_stream_0.mime = {}
    pretty_stream_0.output_encoding = ''
    chunk = ''
    pretty_stream_0.process_body(chunk)


# Generated at 2022-06-25 19:09:12.821151
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    dict_0 = {}
    pretty_stream_0 = PrettyStream(**dict_0)
    list_0 = [dict_0]
    list_0[-1] = pretty_stream_0
    for pretty_stream_0 in list_0:
        DfA8lUxf = pretty_stream_0.get_headers()
