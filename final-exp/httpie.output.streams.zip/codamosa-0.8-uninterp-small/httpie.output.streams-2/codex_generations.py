

# Generated at 2022-06-25 19:00:13.365468
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.output.streams import RawStream
    raw_stream = RawStream(msg="", with_headers=True, with_body=True)
    raw_stream.CHUNK_SIZE = 1024
    raw_stream.iter_body()


# Generated at 2022-06-25 19:00:24.903799
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    env = Environment()
    stream = EncodedStream(msg = msg, with_headers = with_headers, with_body = with_body, on_body_chunk_downloaded = on_body_chunk_downloaded, env = env)
    stream.msg = HTTPMessage(content_type = 'text/plain')
    chunk_size = 1
    stream.chunk_size = chunk_size
    stream.CHUNK_SIZE = 1
    stream.msg.content = b"\x00\x01\x02\x03"
    with pytest.raises(BinarySuppressedError):
        for i in stream.iter_body():
            continue

# Unit

# Generated at 2022-06-25 19:00:30.092040
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    """Test iter_body"""
    body = "test"
    msg = HTTPMessage(body = body)
    encoded_stream = EncodedStream(msg = msg)
    data = encoded_stream.iter_body()
    # if we got here, it mean that no exception was raised
    assert True


# Generated at 2022-06-25 19:00:32.198630
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream = EncodedStream(None, None, None, None, None)
    print (stream.output_encoding)


# Generated at 2022-06-25 19:00:39.201786
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    http('--print=H', 'GET', httpbin.url + '/headers',
         env=Environment(stdin_isatty=True),
         error_exit_ok=True)
    r = http('--print=H', 'GET', httpbin.url + '/get',
             env=Environment(stdin_isatty=True),
             error_exit_ok=True)
    assert HTTP_OK in r
    assert 'HTTP/' in r, "Expected HTTP headers not found"
    # Test that --print=H (no --verbose)
    # doesn't cause error with binary output.
    # See https://github.com/jakubroztocil/httpie/issues/235

# Generated at 2022-06-25 19:00:46.429461
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    msg = HTTPMessage()
    EncodedStream(env=env, msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    EncodedStream(env=env, msg=msg, with_headers=False, with_body=True, on_body_chunk_downloaded=None)
    EncodedStream(env=env, msg=msg, with_headers=True, with_body=False, on_body_chunk_downloaded=None)


# Generated at 2022-06-25 19:00:56.911487
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    data = DataSuppressedError()
    body = b'\x00\x01'
    headers = "headers"
    msg = HTTPMessage(body, headers)
    env = Environment()
    with_headers = True
    with_body = True
    chunk_size = 10
    s = EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded=None, env=env)
    # Check the value of s
    assert s.msg == msg
    assert s.with_headers == with_headers
    assert s.with_body == with_body
    assert s.on_body_chunk_downloaded == None
    assert s.chunk_size == chunk_size
    expected_output_encoding = "utf8"
    assert s.output_encoding == expected_output_enc

# Generated at 2022-06-25 19:01:06.119778
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from datetime import datetime, timedelta
    from httpie.compat import is_py369
    from httpie.output.streams import RawStream
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import DataSuppressedError

    def test_case_1():
        msg_0 = HTTPMessage()
        conversion_0 = Conversion()
        formatting_0 = Formatting()
        kwargs_0 = {}
        kwargs_0.update(msg=msg_0)
        kwargs_0.update(conversion=conversion_0)

# Generated at 2022-06-25 19:01:17.397330
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Create environment to pass to PrettyStream, need unit test for Environment class
    env = Environment()
    # Two arguments needed for formatting and conversion
    # First argument formatting is of type Formatting, need unit test for Formatting class
    formatting = Formatting()
    # First argument conversion is of type Conversion, need unit test for Conversion class
    conversion = Conversion()
    # Second argument chunk is of type str and str is the unit test
    chunk = 'str'
    # Assert types of env, formatting, conversion and chunk
    assert isinstance(env, Environment)
    assert isinstance(formatting, Formatting)
    assert isinstance(conversion, Conversion)
    assert isinstance(chunk, str)
    # Create first PrettyStream object with only env and formatting arguments
    pretty_stream_1 = PrettyStream(conversion, formatting, env=env)
    #

# Generated at 2022-06-25 19:01:22.237280
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        headers=['Host: 127.0.0.1:1234'],
        body=['foobar']
    )
    stream = EncodedStream(msg=msg)

    assert stream.msg == msg
    assert stream.with_headers is True
    assert stream.with_body is True
    assert stream.on_body_chunk_downloaded is None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-25 19:01:38.957058
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    s = EncodedStream(HTTPMessage(b'Test'))
    for line, lf in s.iter_body():
        print(line)


# Generated at 2022-06-25 19:01:44.487671
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    headers = {}
    with_headers = False
    msg = HTTPMessage(headers)
    with_body = True
    on_body_chunk_downloaded = None
    me = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    result = me.__iter__()
    assert iter(result) == result
    assert list(iter(result)) == []


# Generated at 2022-06-25 19:01:49.197652
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(b"aaa",b"bbb",1,2)
    env = Environment()
    on_body_chunk_downloaded = None
    teststream = EncodedStream(msg,with_headers=True,with_body=True,on_body_chunk_downloaded=None,env=env)


# Generated at 2022-06-25 19:01:55.359337
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    body = bytearray()
    chunk_size = 1024 * 10
    data_suppressed_error_0 = DataSuppressedError()
    chunk_0 = b'\x00'
    body.extend(chunk_0)
    if not None and b'\x00' in chunk_0:
        converter = None
        if not converter:
            raise DataSuppressedError()
    body.extend(chunk_0)
    if not None and b'\x00' in chunk_0:
        converter = None
        if not converter:
            raise DataSuppressedError()

# Generated at 2022-06-25 19:02:00.749207
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    print('\n===')
    print('BufferedPrettyStream.__init__()')

    # Test case 0
    # Purpose: No Error
    # Expectation: DataSuppressedError is created
    print('\n===')
    print('Test case 0')
    # Parameter
    try:
        test_case_0()
    except Exception as e:
        print('Error: ', e)
    else:
        print('No error\n')


# Generated at 2022-06-25 19:02:06.728256
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    output_stream = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    # Call method
    output_stream.__iter__()


# Generated at 2022-06-25 19:02:11.336693
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import Request
    from .iter_lines import test_case_0 as test_iter_lines
    for line, lf in test_iter_lines():
        assert EncodedStream(Request(line.decode())).iter_body().__next__() == line + lf

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 19:02:18.620534
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    prettyStream_0 = PrettyStream(
        conversion=None,
        formatting=None,
        msg=None,
        with_headers=False,
        with_body=False,
        on_body_chunk_downloaded=None
    )
    assert isinstance(prettyStream_0, PrettyStream)

    # Unit test for exception handling in method PrettyStream.get_headers of class PrettyStream
    try:
        prettyStream_0.get_headers()
    except AttributeError as e:
        pass

# Generated at 2022-06-25 19:02:29.682423
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    _headers = {"host": "httpie.org",
                "user-agent": "HTTPie/0.9.9"}
    _prettystream_0 = PrettyStream(Formatting(None, None),
                                   Conversion(None, None),
                                   HTTPMessage(StatusLine("HTTP/1.1", "200", "OK"),
                                               Headers(_headers),
                                               b"body"),
                                   None, None)
    _encodedstream_0 = EncodedStream(HTTPMessage(StatusLine("HTTP/1.1", "200", "OK"),
                                                 Headers(_headers),
                                                 b"body"),
                                     None, None)
    assert _prettystream_0.get_headers() == _encodedstream_0.get_headers()

# Generated at 2022-06-25 19:02:41.563032
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Create a dummy message
    msg = HTTPMessage(headers=''
                  ,encoding='utf8'
                  ,content_type=''
                  ,content=''
                  ,content_length=''
                  ,raw_headers=''
                  ,timeline=''
                  ,status_line=''
                  ,content_type_header=''
                  ,headers_dict=''
                  ,history=''
                  )
    # Create a dummy chunk
    chunk = 'Hello World'
    # expected result:
    # an array of bytes representing the chunk
    result = bytes(chunk,'utf-8')

    # Create a dummy stream

# Generated at 2022-06-25 19:02:52.414474
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    inst = BufferedPrettyStream(None, None)
    try:
        for chunk in inst.iter_body():
            pass
    except DataSuppressedError as e0:
        test_case_0()
    except BinarySuppressedError:
        pass

# Generated at 2022-06-25 19:02:58.192699
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Set up test case
    data_suppressed_error_0 = DataSuppressedError()
    try:
        # Set up test case
        pretty_stream_0 = PrettyStream(**{})
        if (test_case_0() == data_suppressed_error_0):
            raise
        # Unit test body
        # Call method iter_body
        pretty_stream_0.iter_body()
    except:
        raise
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 19:03:04.038768
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    data_suppressed_error_0 = DataSuppressedError()
    binary_suppressed_error_0 = BinarySuppressedError()
    # Test iter_body method
    msg = HTTPMessage()

    prettified = BufferedPrettyStream(msg, with_headers=True, with_body=True)
    assert prettified.iter_body() is not None


# Generated at 2022-06-25 19:03:08.401159
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    XP = EncodedStream(msg='asdfsdfsdfsadfsd')
    assert XP.msg is not None
    assert XP.with_headers is not None
    assert XP.with_body is not None
    assert XP.on_body_chunk_downloaded is not None


# Generated at 2022-06-25 19:03:11.731594
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    msg = HTTPMessage(body='abc123')
    f = EncodedStream(msg=msg, env=env)



# Generated at 2022-06-25 19:03:15.492441
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(encoding='utf8')
    msg.headers = 'test'
    raw_stream_0 = RawStream(chunk_size=50, msg=msg)
    assert isinstance(raw_stream_0.iter_body(), Iterable)


# Generated at 2022-06-25 19:03:20.751794
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    conversion = Conversion()
    formatting = Formatting()
    headers = {'Content-Type': 'text/plain', 'encoding': 'utf-8'}
    msg = HTTPMessage(headers=headers)
    msg.set_body(b'body0body1body2body3body4\0')
    stream = BufferedPrettyStream(msg=msg, conversion=conversion, formatting=formatting)
    stream_resuits = list(stream.iter_body())
    assert len(stream_resuits) == 1

# Generated at 2022-06-25 19:03:25.419312
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream(HTTPMessage(headers=['Content-Type: application/json', 'Content-Length: 5', 'X-Foo: bar', 'Content-Encoding: gzip'], body=b'\xff', encoding='utf-8'))
    raw_stream_0.iter_body()


# Generated at 2022-06-25 19:03:35.708291
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    data_suppressed_error_0 = DataSuppressedError()
    chunk_size = 1024 * 100
    chunk_size_by_line = 1
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    raw_stream = RawStream(chunk_size = chunk_size, msg = msg, with_headers = with_headers, with_body = with_body, on_body_chunk_downloaded = on_body_chunk_downloaded)
# unit test for method iter_body of class BinarySuppressedError
    def test_BinarySuppressedError_iter_body():
        binary_suppressed_error_0 = BinarySuppressedError()

# Generated at 2022-06-25 19:03:43.194715
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # this test asserts if the iter_body method of the RawStream class loops over
    # the body of the message object (msg) and returns its content in chunks of size
    # specified by the chunk_size variable. The reason for this is to avoid an attempt
    # to load the whole content of the message body into memory at once.

    # create a HTTPMessage object that represents a message with a body of an arbitrary length
    msg = HTTPMessage(headers=b'MESSAGE HEADERS', body=b'MESSAGE BODY')
    rs = RawStream(msg, chunk_size=4)   # create a RawStream object with a chunk size of 4 bytes

    # create an iterator over the body of the message, loop over it and store merged content
    # of the chunks in a variable

# Generated at 2022-06-25 19:03:52.264542
# Unit test for constructor of class RawStream
def test_RawStream():
    raw = RawStream(msg=HTTPMessage())
    raw.__init__(msg=HTTPMessage(), with_headers=True, with_body=True, on_body_chunk_downloaded=None)


# Generated at 2022-06-25 19:03:54.591136
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    test = PrettyStream(HTTPMessage, 'with_headers', 'with_body', 'on_body_chunk_downloaded')
    test.get_headers()


# Generated at 2022-06-25 19:04:01.258812
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    b = bytearray()
    b.extend("haha".encode("utf-8"))
    stream = BufferedPrettyStream(
        msg = HTTPMessage(b,content_type="text/plain; charset=utf-8"),
        with_headers = True,
        with_body = True,
        conversion = None,
        formatting = None)

    def f(x):
        return x

    stream.on_body_chunk_downloaded = f
    s = stream.iter_body()
    for i in s:
        print(i)

test_BufferedPrettyStream_iter_body()

# Generated at 2022-06-25 19:04:09.355929
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = None
    msg = None
    BaseStream(msg, on_body_chunk_downloaded=SIG_DFL)
    BaseStream(msg, on_body_chunk_downloaded=SIG_IGN)
    BaseStream(msg, on_body_chunk_downloaded=SIG_DFL)
    BaseStream(msg, with_headers=False, with_body=False)
    BaseStream(msg, with_headers=False, with_body=False)


# Generated at 2022-06-25 19:04:10.335430
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    test_case_0()


# Generated at 2022-06-25 19:04:15.122347
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage()
    pretty_stream = PrettyStream(conversion, formatting, msg)
    iter_body_0 = pretty_stream.iter_body()


# Generated at 2022-06-25 19:04:23.527844
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.client import Response
    from httpie.output.streams import EncodedStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion

    message = HTTPMessage(_from_stream=Response(iter([])))
    stream = EncodedStream(message, conversion=Conversion())

    iter_0 = stream.__iter__()
    try:
        next_0 = next(iter_0)
    except StopIteration:
        pass


# Generated at 2022-06-25 19:04:28.590750
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Initialize
    env = Environment()
    msg = HTTPMessage('headers', 'body', 'encoding')

    # Execute code to be tested
    encodedStream = EncodedStream(env, msg)

    # Checks
    assert len(encodedStream.output_encoding) > 0
    assert len(encodedStream.msg.headers) > 0
    assert len(encodedStream.msg.body) > 0
    assert len(encodedStream.msg.encoding) > 0


# Generated at 2022-06-25 19:04:32.490636
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
	# msg, with_headers, with_body, on_body_chunk_downloaded
    s = EncodedStream(1, True, True, None)


# Generated at 2022-06-25 19:04:38.811571
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.output.streams import EncodedStream
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    msg = HTTPMessage(headers=b'headers',content_type='application/json',encoding='utf8')
    env = Environment()
    with_headers = True
    with_body = True
    stream = EncodedStream(msg=msg,with_headers=True,with_body=True,env=env)
    assert stream != None


# Generated at 2022-06-25 19:04:59.188996
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    headers = dict(
        content_type='application/json; charset=utf-8',
        status_line='HTTP/1.1 200 OK',
        headers_list=['content-type: application/json; charset=utf-8']
    )
    test_body = b'{\n    "foo": "bar"\n}\n'
    mime = headers['content_type'].split(';')[0]
    env = Environment()
    body = '{\n    "foo": "bar"\n}\n'
    test_msg = HTTPMessage(
        content_type=headers['content_type'],
        status_line=headers['status_line'],
        headers_list=headers['headers_list']
    )
    test_msg.body = test_body

# Generated at 2022-06-25 19:05:09.371316
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream_0 = PrettyStream(header_0, arg_0, arg_1, arg_2, arg_3)
    assert_raises(
        BinarySuppressedError,
        stream_0.iter_body,
    )
    stream_0 = PrettyStream(header_1, arg_0, arg_1, arg_2, arg_3)
    assert_raises(
        BinarySuppressedError,
        stream_0.iter_body,
    )
    stream_0 = PrettyStream(header_2, arg_0, arg_1, arg_2, arg_3)
    assert_raises(
        BinarySuppressedError,
        stream_0.iter_body,
    )
    stream_0 = PrettyStream(header_3, arg_0, arg_1, arg_2, arg_3)

# Generated at 2022-06-25 19:05:15.090506
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = HTTPHeaders(
            {
                'x-b': '2',
                'x-a': '1',
                'Cookie': 'foo=bar; bar=baz'
            })
    msg = HTTPMessage(headers, b'text')

    encoding = 'utf8'
    formatting = Formatting(None, None)
    conversion = Conversion(None, None)

    stream = PrettyStream(msg, env=Environment(stdout_encoding=encoding), conversion=conversion, formatting=formatting)
    assert b'x-a: 1\rx-b: 2\rCookie: foo=bar; bar=baz' == stream.get_headers()



# Generated at 2022-06-25 19:05:22.986832
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    test_msg = HTTPMessage(headers={'status':'200 OK'}, body={'name':'test'})
    #test_msg = HTTPMessage(headers={'status':'200 OK'}, body={'name':'test'})
    exp = {'name':'test'}
    test_stream = RawStream(test_msg, with_headers=False, with_body=True)
    act = json.loads(test_stream.iter_body())
    assert exp == act



# Generated at 2022-06-25 19:05:28.817039
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    data_suppressed_error_1 = DataSuppressedError()
    env_0 = Environment()
    binary_suppressed_error_0 = BinarySuppressedError()
    buffered_pretty_stream_0 = BufferedPrettyStream(env_0, data_suppressed_error_1, binary_suppressed_error_0, None, False, False)
    print(list(buffered_pretty_stream_0))


# Generated at 2022-06-25 19:05:32.046670
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class MockEncodedStream(EncodedStream):
        @property
        def CHUNK_SIZE(self):
            return 2

        @property
        def msg(self):
            return MockHTTPMessage()
    
    encoded_stream_ = MockEncodedStream()
    try:
        list(encoded_stream_.iter_body())
        assert False
    except BinarySuppressedError:
        assert True


# Generated at 2022-06-25 19:05:35.411634
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # setup
    msg_0 = HTTPMessage()
    msg_0.encoding = 'utf8'
    env_0 = Environment()
    #code#
    with pytest.raises(DataSuppressedError) as excinfo:
        x = EncodedStream(msg=msg_0, env=env_0)
    # verify
    assert 'utf8' == x.output_encoding
    assert str(excinfo.value)


# Generated at 2022-06-25 19:05:39.326081
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    env = Environment()
    msg = HTTPMessage(
        headers=dict(content_type='text/html; charset=utf8'),
        body='',
    )
    stream = EncodedStream(msg, env)
    for chunk in stream.iter_body():
        print(chunk)



# Generated at 2022-06-25 19:05:42.433731
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class test_PrettyStream(PrettyStream):
        def __init__(self):
            pass

    _test_PrettyStream = test_PrettyStream()
    _PrettyStream_process_body_chunk = _test_PrettyStream.process_body(None)



# Generated at 2022-06-25 19:05:46.777367
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    rt = PrettyStream(
        msg=HTTPMessage(headers='', body='', content_type=''),
        with_body=True,
        with_headers=True,
        env=Environment(),
        conversion=None,
        formatting=Formatting()
    )
    assert rt.iter_body() is not None


# Generated at 2022-06-25 19:06:11.203391
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    ps = PrettyStream(msg=None, env=None,
                      with_headers=True, with_body=True)
    body = "Hello, world"
    res = ps.process_body(body)
    assert res == b'\x1b[39m\x1b[1mHello, world\x1b[0m\x1b[39m'

# Generated at 2022-06-25 19:06:12.800314
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # test arguments
    data_suppressed_error_0 = DataSuppressedError()
    # method call


# Generated at 2022-06-25 19:06:19.249809
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Creation of message
    headers = '''GET / HTTP/1.0
Accept-Encoding: gzip
Content-Type: text/html;encoding=utf-8
'''
    body = '''<html><body><h1>Hello World!</h1></body></html>'''
    msg = HTTPMessage('stream', headers=headers, body=body)
    # Print on console
    # TODO: stream I/O, or use a mock.
    print("test_PrettyStream_iter_body")

# Generated at 2022-06-25 19:06:21.609114
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    prettify_stream = PrettyStream(HTTPMessage, True, True)
    result = prettify_stream.get_headers()
    assert isinstance(result, bytes)


# Generated at 2022-06-25 19:06:29.365039
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    data_suppressed_error_0 = DataSuppressedError()
    conversion_0 = Conversion(data_suppressed_error_0)
    formatting_0 = Formatting(data_suppressed_error_0)
    headers_0 = {}
    httpmessage_0 = HTTPMessage(headers_0)
    prettystream_0 = PrettyStream(conversion_0, formatting_0, httpmessage_0, True, True)
    output_encoding_0 = prettystream_0.output_encoding
    headers_0 = httpmessage_0.headers
    assert type(prettystream_0.get_headers()) == bytes
    

# Generated at 2022-06-25 19:06:37.230299
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test_cases = [
        b'\x01\x02\x03\x04\x05\x06\x07',
        b'\x01\x02\x03\x04\x05\x06\x07\x08',
        b'\x01\x02\x03\x04\x05\x06\x07\x08\t'
    ]
    for t in test_cases:
        stream = EncodedStream(msg=HTTPMessage(t))
        #print(stream.iter_body())
        #for v in stream.iter_body():
        #    print(v)
        #assert 0


# Generated at 2022-06-25 19:06:44.636575
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg_0 = HTTPMessage()
    with_headers_0 = True
    with_body_0 = True
    on_body_chunk_downloaded_0 = print
    instance_0 = BaseStream(msg_0, with_headers_0, with_body_0, on_body_chunk_downloaded_0)
    # pass
    assert isinstance(instance_0.__iter__(), Iterable)


# Generated at 2022-06-25 19:06:45.756212
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    stream = None
    assert stream.iter_body() == iter_body()


# Generated at 2022-06-25 19:06:47.164723
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_obj = RawStream()
    assert raw_stream_obj.iter_body()


# Generated at 2022-06-25 19:06:50.584696
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    method = 'iter_body'
    method_under_test = BufferedPrettyStream.__dict__['iter_body']
    assert method == method_under_test.__name__
    # Call the method and get the result.
    result = method_under_test()
    assert result is not None and isinstance(result, Iterable)


# Generated at 2022-06-25 19:07:37.612689
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    assert hasattr(EncodedStream(),'iter_body')


# Generated at 2022-06-25 19:07:47.808489
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n')
    msg.headers.parse(b'content-type: text/html; charset=utf-8')
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    html = '''<!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Bär</title>
    </head>
    <body>
      <h1>Bär</h1>
      <p>Ärska bär</p>
    </body>
    </html>'''.encode('utf-8')

# Generated at 2022-06-25 19:07:50.783240
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    body = b'hello'
    msg = HTTPMessage(headers=None, body=body, encoding='utf-8')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [body.decode('utf-8')]



# Generated at 2022-06-25 19:07:54.510851
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    data = (BytesIO(b'hello world'), 'utf8')
    assert len(list(EncodedStream(msg=HTTPMessage(data)).iter_body())) == 1


# Generated at 2022-06-25 19:08:00.968645
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\nServer: Python/2.7.12\r\nDate: Fri, 27 Apr 2018 21:02:05 GMT\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n{}', None, False, False)
    body_iterator = RawStream(msg, True, True).iter_body()
    for body_chunk in iter(body_iterator):
        pass


# Generated at 2022-06-25 19:08:03.579271
# Unit test for constructor of class RawStream
def test_RawStream():
    print("RawStream")
    # Test RawStream class instance
    RawStream()
    # Test RawStream class instance with parameters
    RawStream(chunk_size=1024)


# Generated at 2022-06-25 19:08:11.348911
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = {'Headers': "Content-Type: application/json"}
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded, env, conversion, formatting)
    assert stream.get_headers() == b'Content-Type: application/json'


# Generated at 2022-06-25 19:08:14.762642
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n', 'utf8', 'HTTP/1.1')
    s = EncodedStream(msg, with_headers=False, with_body=True)
    assert s.msg is msg
    assert s.with_headers is False


# Generated at 2022-06-25 19:08:20.846620
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    #print("-----------------")
    #print("Unit test for EncodedStream.iter_body")
    #print("-----------------")
    #checking empty body
    m = HTTPMessage(b'', headers={'Content-Type': 'test/test'})
    e = EncodedStream(msg=m)
    #print("Test 1: Empty body")
    test1 = True
    try:
        for lf in e.iter_body():
            test1 = False
    except DataSuppressedError:
        test1 = True
    except Exception as e:
        test1 = False
        #print("test 1 failed with exception " + str(e))
    if test1:
        #print("test 1 passed")
        pass
    else:
        #print("test 1 failed")
        pass
    #print("Test 2: Simple

# Generated at 2022-06-25 19:08:25.123341
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test_Obj = EncodedStream(msg=HTTPMessage(type='response',
                                                        status_line='200 OK',
                                                        headers=None,
                                                        content=b'abc',
                                                        encoding='utf-8',
                                                        content_type='text/plain'))
    assert list(bytearray(test_Obj.iter_body())) == [b'abc']
