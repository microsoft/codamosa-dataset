

# Generated at 2022-06-25 19:00:11.038426
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    pretty_stream_0 = BufferedPrettyStream()
    iterable_0 = pretty_stream_0.iter_body()


# Generated at 2022-06-25 19:00:18.280678
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Pre-conditions:
    chunk_size = 5
    env = Environment()
    msg = None
    with_headers = False
    with_body = True
    buffered_pretty_stream = BufferedPrettyStream(chunk_size=chunk_size,env=env,msg=msg,with_headers=with_headers,with_body=with_body)
    # Invocation of tested method:
    r = buffered_pretty_stream.iter_body()
    # Post-conditions, side effects:
    assert isinstance(r, Iterable[bytes])


# Generated at 2022-06-25 19:00:27.767536
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    raw_stream_0 = RawStream(env=env)
    encoded_stream_0 = EncodedStream(msg=raw_stream_0.msg, env=env, with_headers=True, with_body=True)
    assert encoded_stream_0.msg.content_type == 'text/plain'
    assert type(encoded_stream_0.msg) == HTTPMessage
    assert encoded_stream_0.msg.body == 'This is a test'
    assert encoded_stream_0.output_encoding == 'utf8'



# Generated at 2022-06-25 19:00:28.899118
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert False


# Generated at 2022-06-25 19:00:31.272002
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # test_PrettyStream_0
    prettystream_0 = PrettyStream()
    assert prettystream_0.formatting is None


# Generated at 2022-06-25 19:00:32.531058
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    assert PrettyStream(None, None).__class__ == PrettyStream


# Generated at 2022-06-25 19:00:35.544580
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = None
    with_headers = bool
    with_body = bool
    raw_stream = RawStream(msg,with_headers,with_body)
    iterable = raw_stream.iter_body()
    assert iterable is not None


# Generated at 2022-06-25 19:00:45.993141
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    expected_output = '\n<!doctype html>\n<html  \n <head>\n<title>\n</title>\n</head>\n<body>\n</body>\n</html>\n'

    raw_stream_0 = PrettyStream()
    iterable_0 = raw_stream_0.iter_body()
    body = b'\x00\x00\x00'
    body += b'\x00\x00\x00<!DOCTYPE html>'
    body += b'\r\n\r\n'
    body += b'\x00\x00\x00<html>'
    body += b'\r\n\r\n'
    body += b'\x00\x00\x00<head>'
    body += b

# Generated at 2022-06-25 19:00:56.728195
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.streams import Conversion, Formatting
    from httpie.utils import compat
    test_message = HTTPMessage(headers='', method='', url='', begin_time=0.0,
                               response_class='', version='',
                               reason='', encoding='', body='',
                               body_chunks=[])
    test_conversion = Conversion()
    test_formatting = Formatting()
    test_environment = Environment()
    test_chunk_size = 1024 * 10
    test_on_body_chunk_downloaded = lambda x: x + 1
    test_with_headers = True
    test_with_body = True

# Generated at 2022-06-25 19:01:01.403751
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    env_0 = Environment()
    env_0.stdout_isatty = False

    raw_stream_0 = RawStream(env_0)
    raw_stream_0.msg = HTTPMessage()

    encoded_stream_0 = EncodedStream(env_0, raw_stream_0)
    iterable_0 = encoded_stream_0.iter_body()

# Generated at 2022-06-25 19:01:16.819226
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # @TODO Add your test logic here
    try:
        assert True
    except AssertionError as e:
        print(e)
    print("Test Case: test_PrettyStream_iter_body Finished")

# Generated at 2022-06-25 19:01:19.118666
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    b = BaseStream()
    iterable = b.__iter__()
    first_iter = next(iterable)
    assert first_iter == None


# Generated at 2022-06-25 19:01:27.939065
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test with the following inputs:
    msg = ()
    with_headers = True
    with_body = True

    # Test with the following properties:
    # with_headers = True
    # with_body = True

    # Test with the following inputs:
    msg = ()
    with_headers = False
    with_body = False

    # Test with the following properties:
    # with_headers = False
    # with_body = False

    # Test with the following inputs:
    msg = ()
    with_headers = False
    with_body = True

    # Test with the following properties:
    # with_headers = False
    # with_body = True

    # Test with the following inputs:
    msg = ()
    with_headers = True
    with_body = False

    # Test with the following properties:
    # with

# Generated at 2022-06-25 19:01:30.994483
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    encoded_stream_0 = EncodedStream(with_body=False)
    assert encoded_stream_0 != None


# Generated at 2022-06-25 19:01:41.543232
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.models import Response
    from httpie.output.formatting import Formatter
    args = [
        Response(
            content_type='text/plain',
            status_code=200,
            headers={},
            iter_lines=lambda: [('hello'.encode(), b'\n'), ('world'.encode(), b'\n')],
            encoding='ascii'
        ),
        True,
        True,
        None,
        None,
        Formatter()
    ]
    stream = PrettyStream(*args)
    assert stream.process_body('hello'.encode()) == b'\x1b[1mhello\x1b[0m'



# Generated at 2022-06-25 19:01:50.656851
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    env = Environment()
    headers = Headers(
        {
            "content-type": "application/json; charset=utf-8",
            "status": "200",
        }
    )
    response = Response(
        status_code=200,
        http_version="HTTP/1.1",
        headers=headers,
        content=b'{"message": "Hello World!"}',
    )
    content = PrettyStream(env=env, msg=response).get_headers()
    assert content
    assert isinstance(content, bytes)


# Generated at 2022-06-25 19:01:52.690373
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    raw_stream_1 = RawStream()
    pretty_stream_1 = PrettyStream()
    iterable_1 = pretty_stream_1.iter_body()


# Generated at 2022-06-25 19:01:58.308593
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    '''
    Test for method process_body of class PrettyStream
    '''
    pretty_stream_0 = PrettyStream()
    pretty_stream_0.conversion = Conversion()
    pretty_stream_0.formatting = Formatting()
    pretty_stream_0.mime = 'mime'
    assert pretty_stream_0.process_body('chunk') is not None


# Generated at 2022-06-25 19:02:04.435069
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage()
    env = Environment()
    stream = EncodedStream(msg, True, True, env)
    assert stream.output_encoding == None
    msg.encoding = 'utf8'
    stream = EncodedStream(msg, True, True, env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = 'utf8'
    stream = EncodedStream(msg, True, True, env)
    assert stream.output_encoding == None
    msg.encoding = 'utf8'
    stream = EncodedStream(msg, True, True, env)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-25 19:02:13.830170
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.compat import str
    from httpie.models import HTTPResponse
    from httpie.output.formatters import JSONFormatter
    from httpie.output.streams import BufferedPrettyStream
    from httpie.plugins import FormatterPlugin
    # TODO: make this more general
    class my_BufferedPrettyStream(BufferedPrettyStream):
        CHUNK_SIZE_BY_LINE = 1
        # TODO: temporarily change this to be local
        def __init__(self, msg: HTTPMessage, with_headers=True, with_body=True, on_body_chunk_downloaded: Callable[[bytes], None] = None, env=Environment()):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body
            self.on

# Generated at 2022-06-25 19:02:35.088662
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
  raw_stream = RawStream()
  iterable = raw_stream.iter_body()
  encoded_stream_1 = EncodedStream()
  iterable_1 = encoded_stream_1.iter_body()


# Generated at 2022-06-25 19:02:36.118712
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert EncodedStream()


# Generated at 2022-06-25 19:02:38.216750
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    stream_0 = BaseStream()
    iterable_0 = stream_0.__iter__()


# Generated at 2022-06-25 19:02:40.030220
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    test_BufferedPrettyStream_0 = BufferedPrettyStream()

# Generated at 2022-06-25 19:02:46.904225
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from io import BytesIO
    from httpie.models import HTTPMessage
    from httpie._compat import str
    from httpie.output.processing import Formatting
    from httpie.output.streams import EncodedStream
    stream = EncodedStream()
    message = HTTPMessage
    message._body = BytesIO()
    stream.msg = message
    stream.CHUNK_SIZE = 1

    assert stream.iter_body() == stream.iter_body()
    assert isinstance(stream.iter_body(), Iterable[str])



# Generated at 2022-06-25 19:02:52.367884
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Create instance of class RawStream with argument values
    # matching the expected results
    arg_0 = None
    raw_stream_0 = RawStream(arg_0)
    # Call the method under test
    result = PrettyStream.iter_body(raw_stream_0)
    # assertion that the expected and actual results match
    assert result is not None, 'Received None instead of the expected result!'

# Generated at 2022-06-25 19:03:00.341902
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    RawStream_instance_0 = RawStream()
    iterable_0 = RawStream_instance_0.__iter__()
    pretty_stream_instance_1 = PrettyStream()
    iterable_1 = pretty_stream_instance_1.__iter__()
    raw_stream_instance_2 = RawStream()
    iterable_2 = raw_stream_instance_2.__iter__()
    raw_stream_instance_3 = RawStream()
    iterable_3 = raw_stream_instance_3.__iter__()
    encoded_stream_instance_4 = EncodedStream()
    iterable_4 = encoded_stream_instance_4.__iter__()
    raw_stream_instance_5 = RawStream()
    iterable_5 = raw_stream_instance_5.__iter__()


# Generated at 2022-06-25 19:03:01.504150
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    EncodedStream()



# Generated at 2022-06-25 19:03:04.183538
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    raw_stream_0 = RawStream()
    iterable_0 = raw_stream_0.iter_body()


# Generated at 2022-06-25 19:03:15.031934
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    obj = PrettyStream()
    obj.mime = 'text/html'
    obj.output_encoding = 'utf-8'
    ret = obj.process_body('<html>\n<body>\n<a href="http://localhost:8080">link</a>\n</body>\n</html>')
    assert ret == b'<html>\n<body>\n<a href="http://localhost:8080">link</a>\n</body>\n</html>'

    obj = PrettyStream()
    obj.mime = 'text/json'
    obj.output_encoding = 'utf-8'
    ret = obj.process_body('{"a": 1, "b": 2}')

# Generated at 2022-06-25 19:03:55.790818
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    encoding = Encoding()
    body = Body(encoding)
    headers = Headers()
    msg = HTTPMessage(headers, body)
    conversion = Conversion()
    env = Environment()
    formatting = Formatting()
    bps = BufferedPrettyStream(msg, env, conversion, formatting, with_headers=True, with_body=True)

    assert bps.msg == msg
    assert bps.env == env
    assert bps.conversion == conversion
    assert bps.formatting == formatting


# Generated at 2022-06-25 19:03:57.222727
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    obj = EncodedStream()
    assert obj.output_encoding == 'utf8'


# Generated at 2022-06-25 19:03:59.326892
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    buffered_pretty_stream_0 = BufferedPrettyStream()
    iterable_0 = buffered_pretty_stream_0.iter_body()


# Generated at 2022-06-25 19:04:02.605916
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    test_case_1_PrettyStream_instance = PrettyStream(conversion=Conversion(),formatting=Formatting())
    assert test_case_1_PrettyStream_instance.process_body(chunk=b'hello') == b'hello'


# Generated at 2022-06-25 19:04:04.887200
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    encoded_stream_0 = EncodedStream(with_body=True)
    raw_stream_0 = RawStream()
    iterable_0 = encoded_stream_0.iter_body()
    

# Generated at 2022-06-25 19:04:13.162253
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    stream = BufferedPrettyStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None, env=env, conversion=conversion, formatting=formatting)
    assert isinstance(stream, BufferedPrettyStream)
    headers = stream.get_headers()
    body = stream.iter_body()
    val = stream.process_body(body)



# Generated at 2022-06-25 19:04:17.282210
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    pretty_stream_0 = PrettyStream()
    iterable_0 = pretty_stream_0.iter_body()


# Generated at 2022-06-25 19:04:21.379308
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Test encoding
    encoded_stream_0 = EncodedStream()
    body_iterable = encoded_stream_0.iter_body()

# Generated at 2022-06-25 19:04:23.876066
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    raw_stream_1 = PrettyStream()
    field_name_1 = raw_stream_1.get_headers()


# Generated at 2022-06-25 19:04:26.406627
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_1 = RawStream()
    result = raw_stream_1.iter_body()
    assert isinstance(result, Iterable)
    assert isinstance(result, Iterable[bytes])


# Generated at 2022-06-25 19:05:42.577107
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream(msg_1)
    iterable_0 = raw_stream_0.iter_body()
    iterable_1 = raw_stream_0.iter_body(256)
    for i in range(10):
        if i > 5:
            break
        item = next(iterable_0)

# Generated at 2022-06-25 19:05:50.852618
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    line = b'\xD0\x9A\xD0\xB8\xD1\x82\xD0\xB0\xD1\x8F \xD0\xB1\xD0\xB0\xD0\xB1\xD0\xB0, \xD0\xB1\xD0\xB0\xD0\xB1\xD0\xB0!\n'
    lf = b'\n'
    msg_0 = HTTPMessage()
    raw_stream_0 = RawStream()
    iterable_0 = raw_stream_0.iter_body()


# Generated at 2022-06-25 19:05:52.638792
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # raw_stream_1: RawStream = RawStream()
    iterable_1 = PrettyStream().process_body(False)

# Generated at 2022-06-25 19:06:04.094520
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import unittest
    import unittest.mock
    import httpie.output.streams
    import httpie.models
    import io
    class TestBufferedPrettyStream(unittest.TestCase):
        def setUp(self):
            msg = unittest.mock.Mock(spec=httpie.models.HTTPMessage)
            with_headers = True
            with_body = True
            on_body_chunk_downloaded = unittest.mock.Mock()
            self.bufferedpretystream = httpie.output.streams.BufferedPrettyStream(msg=msg, with_headers=with_headers, with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded)

# Generated at 2022-06-25 19:06:13.411481
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream_0 = PrettyStream()
    assert pretty_stream_0.process_body('test_value_0') == b'\xe2\x99\xa5test_value_0\xe2\x99\xa5'
    assert pretty_stream_0.process_body('test_value_1') == b'\xe2\x9e\x96test_value_1\xe2\x9e\x96'
    assert pretty_stream_0.process_body('test_value_2') == b'\xe2\x9d\x8ctest_value_2\xe2\x9d\x8c'

# Generated at 2022-06-25 19:06:18.545258
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    iterable_0 = raw_stream_0.__iter__()


# Generated at 2022-06-25 19:06:19.451513
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    test_case_0()

# Generated at 2022-06-25 19:06:28.861053
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    first_chunk = True
    raw_stream_0 = RawStream()
    iterable_0 = raw_stream_0.iter_body()
    line_0 = None
    lf_0 = None
    line_0 = iterable_0.__next__()
    lf_0 = iterable_0.__next__()
    conversion_0 = Conversion()
    formatting_0 = Formatting()
    pretty_stream_0 = PrettyStream(conversion_0, formatting_0)
    iterable_1 = pretty_stream_0.iter_body()

# Generated at 2022-06-25 19:06:31.599181
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    env = Environment(False)
    pretty_stream_0 = PrettyStream(Conversion(), Formatting(), env=env)
    assert(pretty_stream_0.formatting.indent_size == 2)


# Generated at 2022-06-25 19:06:40.255619
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream('', '', '')
    stream.msg = (
        b'HTTP/1.1 200 OK\r\n'
        b'Content-Type: text/plain; charset=utf-8\r\n'
        b'Transfer-Encoding: chunked\r\n'
        b'\r\n'
        b'1\r\n'
        b'a\r\n'
        b'2\r\n'
        b'bc\r\n'
        b'3\r\n'
        b'def\r\n'
        b'0\r\n'
        b'\r\n'
    )
    iterator = stream.iter_body()
    assert next(iterator) == b'a'
    assert next(iterator) == b'bc'


# Generated at 2022-06-25 19:09:29.250663
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(None, None)
    raw_stream = EncodedStream(msg)
    iterable = raw_stream.iter_body()


# Generated at 2022-06-25 19:09:35.972369
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    def compare(a, b):
        return a == b

    # test 1
    raw_stream_0 = RawStream()
    pretty_stream_0 = PrettyStream(raw_stream_0)
    iterable_0 = pretty_stream_0.process_body(iterable_0)
    assert compare(iterable_0, raw_stream_0)
    # test 2
    raw_stream_0 = RawStream()
    pretty_stream_0 = PrettyStream(raw_stream_0)
    iterable_0 = pretty_stream_0.process_body(iterable_0)
    assert compare(iterable_0, raw_stream_0)
    # test 3
    raw_stream_0 = RawStream()
    pretty_stream_0 = PrettyStream(raw_stream_0)
    iterable_0 = pretty_stream

# Generated at 2022-06-25 19:09:46.827822
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # String.
    raw_stream = RawStream(msg=b'Hello')
    assert list(raw_stream) == [b'Hello']
    # Binary content.
    raw_stream = RawStream(msg=b'\0\1\2\0')
    assert list(raw_stream) == [b'\0\1\2\0']
    # Stream with headers.
    raw_stream = RawStream(msg=b'\0\1\2\0', with_headers=True)
    assert list(raw_stream) == [b'Content-Length: 4\r\n\r\n', b'\0\1\2\0']
    # Stream with headers and body suppressed.

# Generated at 2022-06-25 19:09:54.516623
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    headers = {'X-Foo': 'bar', 'Content-Type': 'application/json'}
    headers = '\r\n'.join('%s: %s' % (k, v) for k, v in headers.items()) + '\r\n\r\n'
    data = '{"foo": "bar"}'
    msg = HTTPMessage(
        'HTTP/1.1 200 OK',
        b'\r\n'.join([
            headers.encode('utf8'),
            '{"foo": "bar"}'.encode()
        ]))
    env = Environment(stdout_encoding='utf8')
    formatting = Formatting(env)
    conversion = Conversion(env)
    chunk_size = 1