

# Generated at 2022-06-25 19:00:10.473904
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    file = open('test_data/testcase_1_in.txt', 'r', encoding='utf8')
    msg = HTTPMessage(
        headers=file.read()
    )

# Generated at 2022-06-25 19:00:15.712314
# Unit test for method get_headers of class PrettyStream

# Generated at 2022-06-25 19:00:16.508646
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pretty_stream = PrettyStream()
    pretty_stream.get_headers()


# Generated at 2022-06-25 19:00:22.442709
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers=None, body=None, encoding='utf8',
                      content_type='text/plain')

    stream = EncodedStream(msg=msg, with_headers=True,
                           with_body=True,
                           on_body_chunk_downloaded=None)

    assert len(list(stream)) == 0



# Generated at 2022-06-25 19:00:24.767503
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pretty_stream = PrettyStream(conversion=Conversion(),
            formatting=Formatting())
    assert pretty_stream.get_headers()

# Generated at 2022-06-25 19:00:30.781661
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(headers={'Content-Type': 'application/json'})
    conversion = Conversion()
    formatting = Formatting()
    kwargs = {'msg': msg, 'conversion': conversion, 'formatting': formatting}
    converted_msg = BufferedPrettyStream(**kwargs)
    assert converted_msg.on_body_chunk_downloaded == None

# Generated at 2022-06-25 19:00:32.203908
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream()
    result = raw_stream_0.iter_body()
    assert False


# Generated at 2022-06-25 19:00:33.334299
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    try:
        pretty_stream_0 = PrettyStream()
    except TypeError:
        pass

# Generated at 2022-06-25 19:00:44.154947
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    raw_stream = RawStream()
    pretty_stream = PrettyStream(Conversion(), Formatting())

    # Test 1. chunk is None
    try:
        pretty_stream.process_body(None)
    except TypeError:
        print("Test 1: Passed")
    else:
        print("Test 1: Failed")

    # Test 2. chunk is a valid unicode string
    if pretty_stream.process_body("abc") == b'abc':
        print("Test 2: Passed")
    else:
        print("Test 2: Failed")

    # Test 3. chunk contains non-unicode bytes
    try:
        pretty_stream.process_body(b'\xef\xbf\xbd')
    except TypeError:
        print("Test 3: Passed")
    else:
        print("Test 3: Failed")


#

# Generated at 2022-06-25 19:00:47.195070
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    #  call __iter__ of raw_stream_0
    assert hasattr(raw_stream_0.__iter__(), '__iter__')
    return


# Generated at 2022-06-25 19:01:03.250897
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream()
    # Test when:
    # Test when chunk_size is equal to 1024*100
    raw_stream_0.CHUNK_SIZE = 1024*100
    raw_stream_0.CHUNK_SIZE_BY_LINE = 1
    # Assert the first is equal to 1024*100:
    raw_stream_0.iter_body().__next__() == 1024*100
    # Assert the last is not equal to 1024*100:
    raw_stream_0.iter_body().__next__() != 1024*100

    # Test when chunk_size is equal to 1
    raw_stream_0.CHUNK_SIZE = 1
    # Assert the first is equal to 1:
    raw_stream_0.iter_body().__next__() == 1
    # Assert the last

# Generated at 2022-06-25 19:01:09.680543
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    PrettyStream_test_object = PrettyStream()
    assert (PrettyStream_test_object.process_body(str)).__class__ == bytes , ('Unit test for method process_body of class PrettyStream has failed. Expected bytes, received %s' % type(PrettyStream_test_object.process_body(str)))
    assert (PrettyStream_test_object.process_body(bytes)).__class__ == bytes , ('Unit test for method process_body of class PrettyStream has failed. Expected bytes, received %s' % type(PrettyStream_test_object.process_body(bytes)))

# Generated at 2022-06-25 19:01:20.813779
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    if __name__ == 'httpie.output.streams':
        msg = HTTPMessage()
        msg.body = b'Quick test of BufferedPrettyStream'
        pretty_stream = BufferedPrettyStream(msg = msg)
        body_list = list(pretty_stream.iter_body())
        body = list(map(lambda x: x.decode('utf-8'), body_list))

        r_body = ['\n\n']
        r_body.append(msg.body.decode('utf-8'))
        r_body.append('\n\n')

        print(body)
        print(r_body)

        for i in range(len(r_body)):
            assert body[i] == r_body[i]


# Generated at 2022-06-25 19:01:21.625721
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    pass


# Generated at 2022-06-25 19:01:27.130680
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers_str = 'HTTP/1.1 200 OK\r\n' + '\r\n'
    headers_b = headers_str.encode('utf8')

    msg = HTTPMessage.from_http(headers_b)
    ps0 = PrettyStream(msg, conversion=Conversion(None),
                       formatting=Formatting(None))
    h_0 = ps0.get_headers()

    assert (headers_b == h_0)



# Generated at 2022-06-25 19:01:36.464911
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    line1 = b'{"created_at": "Tue Feb 12 07:52:54 +0000 2019", "id": 1095073068532715520, "id_str": "1095073068532715520", "text": "The old saying goes; Not my circus, not my monkeys... But that does beg the question; What circus has monkeys?"}\n'
    line2 = b'{"created_at": "Tue Feb 12 07:52:57 +0000 2019", "id": 1095073080871759872, "id_str": "1095073080871759872", "text": "@irreversible71 @TheAnonJournal @macguitarnerd And definitely not a fan of the censorship. I\'m staying off of Twitter, Facebook and YouTube for a while, they\'re not even fun to use anymore."}\n'

# Generated at 2022-06-25 19:01:39.740425
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    ps_obj = PrettyStream(conversion=False, formatting=False)
    print(ps_obj.process_body("<html>"))


if __name__ == "__main__":
    test_PrettyStream_process_body()

# Generated at 2022-06-25 19:01:43.065134
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    test = BufferedPrettyStream()
    if test.process_body(b'\x01') == '01':
        print('test success')
    else:
        print('test failed')

# Generated at 2022-06-25 19:01:52.877401
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    raw_stream_1 = RawStream(msg=HTTPMessage(), with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    encoded_stream_1 = EncodedStream(msg=HTTPMessage(), env=env, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    pretty_stream_1 = PrettyStream(msg=HTTPMessage(), env=env, conversion=Conversion(), formatting=Formatting(), with_headers=True, with_body=True, on_body_chunk_downloaded=None)

# Generated at 2022-06-25 19:01:56.403201
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    # Exception raises here
    # Exception: NotImplementedError:
    for i in raw_stream_0:
        print(i)


# Generated at 2022-06-25 19:02:13.834757
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream = RawStream()
    base_stream = BaseStream()
    raw_stream_iter = raw_stream.__iter__()
    base_stream_iter = base_stream.__iter__()



# Generated at 2022-06-25 19:02:17.958520
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={'content-type': 'application/json'},
                      body=b'{"name":"Bora"}',
                      encoding='utf-8')
    encoded_stream_0 = EncodedStream(msg=msg)


# Generated at 2022-06-25 19:02:22.436917
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test case 1
    encoded_stream_0 = EncodedStream()
    # Test case 2 for on_body_chunk_downloaded()
    encoded_stream_1 = EncodedStream(on_body_chunk_downloaded=test_on_body_chunk_downloaded)



# Generated at 2022-06-25 19:02:25.202556
# Unit test for constructor of class RawStream
def test_RawStream():
    # Initialize env
    env = Environment()
    # Initialize message
    msg = HTTPMessage()
    # Initialize object
    raw_stream_0 = RawStream(env, msg, True, True)
    # Initialize object
    raw_stream_1 = RawStream(msg, True, True)


# Generated at 2022-06-25 19:02:27.495945
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    encoded_stream = EncodedStream()
    encoded_stream.msg = HTTPMessage()
    encoded_stream.msg.body = "hello world"
    print(list(encoded_stream.iter_body()))

test_EncodedStream_iter_body()

# Generated at 2022-06-25 19:02:30.585911
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    pretty_stream = PrettyStream()
    assert pretty_stream.formatting is None
    assert pretty_stream.conversion is None
    assert pretty_stream.mime == ""


# Generated at 2022-06-25 19:02:31.559905
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    assert False


# Generated at 2022-06-25 19:02:41.864493
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test Input
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\n\r\n<html><body>Hello httpie!</body></html>')
    conversion = Conversion()
    formatting = Formatting(pretty=True, colors=True, verbose=True, default_content_type='application/json')
    pretty_stream_0 = PrettyStream(msg, True, True, conversion, formatting)
    print([chunk.decode('utf-8') for chunk in pretty_stream_0.iter_body()])


test_PrettyStream_iter_body()

# Generated at 2022-06-25 19:02:51.649398
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import os, re, codecs
    from httpie.models import HTTPMessage
    dir_path = os.path.dirname(os.path.realpath(__file__))
    test_cases = [
        {'input': b'{"name":"Foo","age":1}', 'result': b'"name": "Foo", "age": 1'},
        {'input': b'{"name":"Bar","age":2}', 'result': b'"name": "Bar", "age": 2'}
    ]
    for test_case in test_cases:
        msg = HTTPMessage(
            content_type='application/json',
            encoding='utf8',
            headers={},
            body=test_case['input']
        )

# Generated at 2022-06-25 19:02:55.173356
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    input_content = 'foo bar baz'
    input_mime = 'text/plain'
    expected_output = 'foo bar baz'
    ps = PrettyStream(Conversion(), Formatting())
    assert ps.process_body(input_content) == expected_output

# Generated at 2022-06-25 19:03:14.220688
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    encoded_stream_0 = EncodedStream()

# Generated at 2022-06-25 19:03:17.933742
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)
    pretty_stream_0 = PrettyStream(conversion, formatting)
    body = "test_body"
    chunk = pretty_stream_0.process_body(body)
    assert chunk == b'test_body'

# Generated at 2022-06-25 19:03:23.841970
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Simple body with no formatting to do
    plain_text_body = "Hello, World!"
    # Fully initialize a new instance of PrettyStream
    stream = PrettyStream(msg=HTTPMessage(None, plain_text_body), with_headers=False, with_body=True)
    # Invoke the method under test
    result = stream.process_body(plain_text_body)
    # Verify the results
    assert plain_text_body == result.decode()

# Generated at 2022-06-25 19:03:24.519360
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    pass

# Generated at 2022-06-25 19:03:35.709069
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test case:
    # 1. Test that the prettifier is applied on the response body
    # 2. Test that the line feed (\n) is added to each line of the response body
    # 3. Test that the prettifier is successfully applied on a line of the response body
    # 4. Test that the prettifier is successfully applied on a single line response body
    # 5. Test that the prettifier is applied on a binary response body
    import pytest
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Converters, Formatters
    import httpie
    # 1. Test that the prettifier is applied on the response body
    class Response(httpie.models.HTTPMessage):
        """Test class for HTTP response."""

        def __init__(self):
            """Initialize the response."""
           

# Generated at 2022-06-25 19:03:43.210304
# Unit test for constructor of class RawStream
def test_RawStream():
    Range = namedtuple('Range', 'start, stop, step')

    from httpie.output.streams import RawStream
    import sys
    import os
    import httpie
    import selectors
    import socket
    import select
    import threading
    import time
    import subprocess
    import signal
    import errno
    import paramiko

    http_server_cmd = ["http", "--timeout", "30", "--json"]
    http_client_cmd = ["http", "--json", "--verbose"]
    http_server_url = "http://127.0.0.1:8080/"

    # print(sys.executable)
    # print(os.path.dirname(os.path.abspath(httpie.__file__)))
    # print(os.path.dirname(os.path

# Generated at 2022-06-25 19:03:51.669032
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    chunk_size = 1024 * 100
    on_body_chunk_downloaded = None
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    # self.msg = msg
    # self.with_headers = with_headers
    # self.with_body = with_body
    # self.on_body_chunk_downloaded = on_body_chunk_downloaded



# Generated at 2022-06-25 19:03:52.607891
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    raw_stream_1 = RawStream()


# Generated at 2022-06-25 19:03:54.234649
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_1 = RawStream()
    assert raw_stream_1.iter_body()

# Generated at 2022-06-25 19:03:58.899087
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    pretty_stream_0 = PrettyStream()
    chunk_size = 10
    pretty_stream_0.msg.iter_lines(chunk_size)
    # testing to see if the if condition is entered

# Generated at 2022-06-25 19:04:38.429857
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from .types import HTTPMessage
    from .headers import Headers
    msg = HTTPMessage(headers=Headers(None), encoding='ascii')
    msg.CHUNK_SIZE = 1
    encoded_stream = EncodedStream(msg=msg, with_headers=True, with_body=True)
    body_chunk = encoded_stream.iter_body()
    b'\0' in body_chunk


# Generated at 2022-06-25 19:04:40.330727
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None)
    assert stream.process_body(b'\n') == b'\n'

# Generated at 2022-06-25 19:04:44.614119
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    p = PrettyStream(conversion=Conversion(), formatting=Formatting({}), msg=HTTPMessage(headers=None, encoding='utf-8'))
    p.msg.encoding = 'utf-8'
    p.msg.content_type = 'text/plain'
    p.CHUNK_SIZE = 1
    p.iter_body()

# Generated at 2022-06-25 19:04:51.960477
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import io
    import io
    import io

    class MockEncodedStream(EncodedStream):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.output_encoding = 'utf8'
            self._mock_iter_body = io.BytesIO(b'')

        def iter_body(self):
            return self._mock_iter_body

    msg = Mock()
    msg.headers = 'headers'
    msg._mock_iter_body = io.BytesIO(b'')
    raw_stream = MockEncodedStream(msg=msg)
    assert 'headers' == raw_stream.get_headers()
    assert iter([b'headers\r\n\r\n']) == iter(raw_stream)


# Unit test

# Generated at 2022-06-25 19:04:54.447752
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    raw_stream_0 = RawStream(msg, with_headers=True, with_body=True)
    raw_stream_0.iter_body()


# Generated at 2022-06-25 19:05:04.826423
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    raw_stream_0 = RawStream()

    # On calling the iter_body method of class PrettyStream after conversion of Json to xml
    mime_type = 'application/xml'
    # Getting the desired conversion from conversion.py file 
    converter = Conversion().get_converter(mime_type)
    # Converting the json data to xml data
    mime_type, body = converter.convert(""" {"name" : "tasee"} """)
    # Giving formatting
    chunk = Formatting().format_body(content=body, mime=mime_type)
    assert chunk.encode("utf-8", "replace") == b'<?xml version="1.0" encoding="utf-8"?>\n<name>tasee</name>'

# Generated at 2022-06-25 19:05:07.415454
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    # Execute operation
    raw_stream_0.__iter__()
    # Check operation's result
    assert result==None


# Generated at 2022-06-25 19:05:15.904567
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # noinspection PyUnusedLocal
    def iter_body_impl(self):
        chunk_size = self.CHUNK_SIZE
        iter_lines = self.msg.iter_lines(chunk_size)
        for line, lf in iter_lines:
            if b'\0' in line:
                if first_chunk:
                    converter = self.conversion.get_converter(self.mime)
                    if converter:
                        body = bytearray()
                        # noinspection PyAssignmentToLoopOrWithParameter
                        for line, lf in chain([(line, lf)], iter_lines):
                            body.extend(line)
                            body.extend(lf)
                        self.mime, body = converter.convert(body)
                        assert isinstance(body, str)


# Generated at 2022-06-25 19:05:27.838897
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import requests
    from httpie.models import HTTPResponse
    from httpie.input import ParseError
    from httpie.output import OutputOptions
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    test_msg = HTTPResponse.from_impl(test_case_0_msg, ParseError)
    output_options = OutputOptions()
    env = Environment(output_options = output_options)
    output_options.stream = True
    conversion = Conversion()
    formatting = Formatting(output_options)
    test_stream = BufferedPrettyStream(msg = test_msg, with_headers = True, with_body = True, env = env, conversion = conversion, formatting = formatting)
    test_stream_iter = test_stream.iter_body()

# Generated at 2022-06-25 19:05:35.000805
# Unit test for constructor of class RawStream
def test_RawStream():
    # Normal case 1
    raw_stream = RawStream(msg=None, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert raw_stream.msg is None
    assert raw_stream.with_headers
    assert raw_stream.with_body
    assert raw_stream.on_body_chunk_downloaded is None
    assert raw_stream.chunk_size == RawStream.CHUNK_SIZE

    # Boundary case 1
    raw_stream = RawStream(msg=None, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert raw_stream.msg is None
    assert raw_stream.with_headers
    assert raw_stream.with_body
    assert raw_stream.on_body_chunk_down

# Generated at 2022-06-25 19:06:46.688624
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    stream_iter_0 = iter(raw_stream_0)
    for val in stream_iter_0:
        pass

# Generated at 2022-06-25 19:06:47.784410
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    bp_stream = BufferedPrettyStream()


# Generated at 2022-06-25 19:06:49.123913
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    EncodedStream(0, 0, with_headers=True, with_body=True)



# Generated at 2022-06-25 19:06:57.127361
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg_test = HTTPMessage(encoding='utf8')
    msg_test.headers = 'headers_test'
    encoded_stream_test = EncodedStream(msg=msg_test)
    # Test case 1: msg.encoding = utf8
    msg_test.body = 'sdfsdfsfsfs'.encode('utf8')
    assert next(encoded_stream_test.iter_body()) == 'sdfsdfsfsfs'
    # Test case 2: msg.encoding = binary
    msg_test.body = 'sdfsdfsfsfs'.encode('utf8')
    assert next(encoded_stream_test.iter_body()) == 'sdfsdfsfsfs'



# Generated at 2022-06-25 19:07:07.858398
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import io
    import unittest.mock
    raw_stream_1 = RawStream()
    class mock_file:
        def read(self, size):
            return b''
        def __exit__(self, exc_type, exc_val, exc_tb):
            print('')
        def __enter__(self):
            return self
    test_iter_body_0 = raw_stream_1.iter_body()
    with unittest.mock.patch('httpie.output.streams.open', unittest.mock.mock_open(read_data=''), create=True) as open_mock:
        with unittest.mock.patch('httpie.output.streams.RawStream.msg.body_file_raw', mock_file):
            test_iter_body_1

# Generated at 2022-06-25 19:07:09.587077
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # TODO implement assert_BufferedPrettyStream_iter_body()
    pass



# Generated at 2022-06-25 19:07:19.450057
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class Stream0:
        def iter_body(self, chunk_size):
            return None

    class Stream1:
        def iter_body(self, chunk_size):
            return None

    class Stream:
        def iter_body(self, chunk_size):
            return None

    class Conversion0:
        def __init__(self):
            self.mime_converters = self.mime_converters

        def get_converter(self, mime):
            if mime == 'text/plain':
                return self.mime_converters[mime]
            else:
                return None


# Generated at 2022-06-25 19:07:31.272981
# Unit test for constructor of class EncodedStream
def test_EncodedStream():

    # Test case where parameter `env` is omitted
    try:
        stream = EncodedStream(HTTPMessage(headers=[('h1', 'v1')], body='abc'),
                               True, True, None)
        assert stream.CHUNK_SIZE == 1
        assert stream.output_encoding == 'utf8'
    except Exception as e:
        print("Test case 0 failed: " + str(e))

    # Test case where parameter `chunk_size` is given

# Generated at 2022-06-25 19:07:34.081243
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessage
    from httpie.output.streams import BaseStream
    b = BaseStream(HTTPMessage())
    yield


# Generated at 2022-06-25 19:07:45.006074
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.plugins import get_converter
    output_encoding = 'utf-8'
    msg = HTTPMessage()
    msg.encoding = 'utf-8'
    msg._raw = u'This\nis\n\nmulti-line\n\ntext\n'
    msg.headers = u''
    msg.content_type = 'text/plain'

    # example when all lines are processed in the first iteration
    ps = PrettyStream(msg, None, None, output_encoding=output_encoding)
    print("No of lines: %d" % msg.line_count())
    for line, lf in ps.iter_body():
        print("Line is: %s" % line)
    print("\n")

    # example when there is partial line processed and then the for loop is
   