

# Generated at 2022-06-25 19:00:17.580078
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    conversion = Conversion()
    formatting = Formatting()
    pretty_stream_0 = PrettyStream(conversion, formatting)
    chk_1 = pretty_stream_0.process_body('chunk_1')
    chk_2 = pretty_stream_0.process_body('chunk_2')
    print('chunk_1 {}'.format(chk_1))
    print('chunk_2 {}'.format(chk_2))
    assert chk_1 == b'chunk_1' == chk_2, 'Assertion failed'

# Generated at 2022-06-25 19:00:24.716500
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage.from_dict(b'HTTP/1.1 200 OK\r\nContent-Length: 10\r\n\r\n')
    msg.body = b'0123456789'
    raw_stream_0 = RawStream(title=msg.title, headers=msg.headers, body=msg.body)
    assert raw_stream_0.iter_body() == b"0123456789"



# Generated at 2022-06-25 19:00:35.067271
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-25 19:00:39.261972
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage()
    msg.content_type = 'text/html'
    msg.headers = 'test-header'
    pstream = PrettyStream(msg, conversion = None, formatting = None)
    assert(pstream.iter_body() == None)

# Generated at 2022-06-25 19:00:49.327967
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import httpie.cli
    from httpie.context import Environment
    from httpie.models import HTTPMessage

    BufferedPrettyStream.CHUNK_SIZE = 1
    env = Environment(stdout_isatty=True,
                      stdout_encoding='utf8',
                      stdin=io.BytesIO(b'kitty'))
    msg = HTTPMessage(
        content_type=None,
        encoding=None,
        headers=None,
        status_line=None,
        body=io.BytesIO(b'Hello World!'))
    stream = BufferedPrettyStream(env=env,
                                  conversion=httpie.cli.Convert,
                                  msg=msg,
                                  formatting=httpie.cli.Formatting,
                                  with_headers=True,
                                  with_body=True)

# Generated at 2022-06-25 19:00:56.240772
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Arrange
    msg = HTTPMessage("HTTP/1.1")
    raw_stream_0 = RawStream(msg)
    with_headers = True
    with_body = True
    expected = "GET / HTTP/1.1\r\n\r\n"

    # Act
    result = ""
    for chunk in raw_stream_0:
        result = result + chunk.decode('utf8')
    # Assert
    assert result == expected


# Generated at 2022-06-25 19:01:00.607178
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # data
    data = b'\r\n'
    msg = HTTPMessage(data, 'utf8')
    # create a PrettyStream
    ps = PrettyStream(msg, conversion={}, formatting={})
    # iterate over body of the PrettyStream
    assert(next(ps.iter_body()) == data)


# Generated at 2022-06-25 19:01:04.552925
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    stream = PrettyStream()
    stream.msg = HTTPMessage(version='HTTP/1.1', headers='', status_line='', body='')
    assert stream.get_headers() == ''
    stream.msg = HTTPMessage(version='HTTP/1.1', headers='Content-Type: text/html', status_line='', body='')
    assert stream.get_headers() == 'Content-Type: text/html'.encode(stream.output_encoding)

# Generated at 2022-06-25 19:01:06.191219
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pretty_stream = PrettyStream()

    assert iter(pretty_stream)



# Generated at 2022-06-25 19:01:15.650898
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    pretty_stream_0 = PrettyStream(conversion={'simple': [b'Simple']}, formatting={'headers': 'Headers', 'body': 'Body'})
    # Pass: 'b' is empty.
    # Pass: 'item' is empty.
    # Pass: 'line' is empty.
    # Pass: 'line' is empty.
    # Pass: 'first_chunk' is empty.
    # Pass: 'iter_lines' is empty.
    # Pass: 'converter' is empty.
    # Pass: 'first_chunk' is empty.
    # Pass: 'chunk' is empty.


# Generated at 2022-06-25 19:01:33.258794
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    message_0 = HTTPMessage()
    conversion_0 = Conversion()
    formatting_0 = Formatting()
    # Creating an instance of class PrettyStream
    pretty_stream_0 = PrettyStream(message_0, False, True, conversion_0, formatting_0)
    # testing method process_body of class PrettyStream
    string_0 = ('\u8A3C\u6587\u90E8', )
    byte_array_0 = b'\u8A3C\u6587\u90E8'
    assert pretty_stream_0.process_body(string_0) == byte_array_0

if __name__ == '__main__':
    test_case_0()
    test_PrettyStream_process_body()

# Generated at 2022-06-25 19:01:37.227817
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    a = EncodedStream()


# Generated at 2022-06-25 19:01:37.988594
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Write your code for testing here
    pass


# Generated at 2022-06-25 19:01:42.186742
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    headers = 'headers'
    body = 'body'
    msg = HTTPMessage(headers=headers, body=body)
    encoded_stream_0 = EncodedStream(msg)
    assert encoded_stream_0.output_encoding == 'utf8'
    encoded_stream_1 = EncodedStream(msg, env=env)
    assert encoded_stream_1.output_encoding == env.stdout_encoding



# Generated at 2022-06-25 19:01:44.179489
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()



# Generated at 2022-06-25 19:01:45.136765
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    raw_stream_0 = EncodedStream()


# Generated at 2022-06-25 19:01:46.365312
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
	stream = BufferedPrettyStream(None,Conversion(),Formatting())

# Generated at 2022-06-25 19:01:55.203172
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # header
    header = b'HTTP/1.1 200 OK\r\n'\
             b'Content-Type: application/json; charset=utf-8\r\n' \
             b'Content-Length: 28\r\n' \
             b'Connection: keep-alive\r\n\r\n'
    # body
    body = b'{\r\n' \
           b'  "data": "this is body"\r\n' \
           b'}\r\n'
    # create message
    message = HTTPMessage(headers=header, body=body)
    # create PrettyStream
    env = Environment()
    pretty = PrettyStream(message, env=env)
    # check
    assert len(list(pretty.iter_body())) == 2

# Generated at 2022-06-25 19:01:56.171934
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert EncodedStream()


# Generated at 2022-06-25 19:01:58.475476
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    piped_out = StringIO()
    raw_stream_0 = RawStream()
    result = PrettyStream(raw_stream_0, piped_out)
    assert result == "hello"

# Generated at 2022-06-25 19:02:17.706430
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    header_charset = 'charset=utf8'
    header_content_type = 'Content-Type: {}'.format(header_charset)
    header_mime = 'Content-Type: {}'.format(header_charset)
    header_encoding = 'utf8'
    encoder_stream_0 = EncodedStream(charset=header_charset)
    assert encoder_stream_0.get_headers().decode('utf8') == header_content_type

# Generated at 2022-06-25 19:02:21.442217
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    test_BufferedPrettyStream_iter_body_0()
    test_BufferedPrettyStream_iter_body_1()
    test_BufferedPrettyStream_iter_body_2()
    test_BufferedPrettyStream_iter_body_3()



# Generated at 2022-06-25 19:02:28.803575
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test_data = 'foo\nbar'
    test_env = Environment()
    test_env.stdout_isatty = True
    test_stream = EncodedStream(msg=HTTPMessage(content=test_data,
                                                content_type='text/plain'),
                                env=test_env,
                                with_headers=False,
                                with_body=True)
    assert list(test_stream.iter_body()) == [b'foo\n', b'bar']


# Generated at 2022-06-25 19:02:31.795013
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    with pytest.raises(NotImplementedError):
        e_stream_0 = EncodedStream()
        for chunk in e_stream_0.iter_body():
            pass


# Generated at 2022-06-25 19:02:33.691091
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_1 = RawStream()



# Generated at 2022-06-25 19:02:41.965077
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    raw_stream_0.msg = HTTPMessage(body='http://localhost:8080/hello')
    raw_stream_0.msg.headers = 'http://localhost:8080/hello'
    raw_stream_0.with_headers = True
    raw_stream_0.with_body = True
    raw_stream_0.on_body_chunk_downloaded = None
    with pytest.raises(NotImplementedError):
        iter(raw_stream_0)


# Generated at 2022-06-25 19:02:46.867003
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage()
    raw_stream_1 = PrettyStream()
    msg.headers = 'Content-Type: text/html'
    msg.encoding = 'utf-8'
    raw_stream_1.msg = msg
    assert raw_stream_1.process_body(b'chunk') == b'<pre>chunk</pre>'

# End unit test

# Test case for method iter_body of class PrettyStream

# Generated at 2022-06-25 19:02:49.550977
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    raw_stream = RawStream()
    pretty_stream = PrettyStream()
    buffered_pretty_stream = BufferedPrettyStream()
    encoded_stream = EncodedStream()

# Generated at 2022-06-25 19:02:57.537215
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    class TestMsg(object):
        def __init__(self, test_body):
            self.body = test_body
            
        def iter_body(self, chunk_size) -> Iterable[bytes]:
            for item in self.body:
                yield item

    data1 = 'hello'
    data2 = 'world'
    msg = TestMsg([data1, data2])
    raw_stream = RawStream(msg)
    result = ''
    for data in raw_stream.iter_body():
        result += data.decode("utf-8")
    assert result == 'hello' + 'world'


# Generated at 2022-06-25 19:03:07.248297
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import Request
    req = Request(method='GET', url='http://www.qq.com')
    req.headers['content-type'] = 'application/json'
    buf = BufferedPrettyStream(msg=req, conversion=Conversion(), formatting=Formatting())
    assert buf.msg == req
    assert buf.with_headers
    assert buf.with_body
    assert buf.on_body_chunk_downloaded
    assert buf.mime == 'application/json'
    assert buf.conversion == Conversion()
    assert buf.formatting == Formatting()
    assert buf.output_encoding


# Generated at 2022-06-25 19:03:33.212359
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream(None, None, None, None, None)
    with pytest.raises(NotImplementedError):
        stream.iter_body()


# Generated at 2022-06-25 19:03:34.865809
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    base_stream_0 = BaseStream()


# Generated at 2022-06-25 19:03:38.148607
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    env = Environment()
    msg = HTTPMessage(headers='Content-Length: 0\n\n', encoding='utf-8')
    assert b'Content-Length: 0\n\n' == PrettyStream(env, msg).get_headers()


# Generated at 2022-06-25 19:03:39.591054
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    test_stream = EncodedStream()
    assert isinstance(test_stream, EncodedStream)


# Generated at 2022-06-25 19:03:42.598207
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    print('Unit test for method iter_body of class BufferedPrettyStream')
    pass_stream_0 = BufferedPrettyStream()
    assert False
    return pass_stream_0


# Generated at 2022-06-25 19:03:50.736354
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    pretty_stream_0 = PrettyStream()
    assert pretty_stream_0.msg == None
    assert pretty_stream_0.with_headers == True
    assert pretty_stream_0.with_body == True
    assert pretty_stream_0.on_body_chunk_downloaded == None
    assert pretty_stream_0.output_encoding == 'utf8'
    assert pretty_stream_0.formatting == None
    assert pretty_stream_0.conversion == None
    assert pretty_stream_0.mime == None


# Generated at 2022-06-25 19:03:52.440721
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream = RawStream()
    raw_stream._BaseStream__iter__()


# Generated at 2022-06-25 19:03:59.779270
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    input_msg = HTTPMessage()
    input_with_headers = True
    input_with_body = True
    input_on_body_chunk_downloaded = None
    raw_stream_0 = RawStream(input_msg, input_with_headers, input_with_body, input_on_body_chunk_downloaded)



# Generated at 2022-06-25 19:04:00.754291
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Make sure there's no errors
    assert True == True

# Generated at 2022-06-25 19:04:04.855689
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    env = Environment()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    raw_stream_0 = EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    assert raw_stream_0 != None


# Generated at 2022-06-25 19:05:01.401201
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():

    # Note: the __iter__ method doesn't return anything. It's main purpose is to write (yield) bytes
    # In order to be able to unit test, we need to retrieve what __iter__ yields

    # Some setup
    # import sys
    # sys.path.append(r'C:\Users\brian\source\httpie')

    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.core import main

    from unittest.mock import patch

    # We create the request object with some headers and a body
    # The 'http' part is our method, which will be GET
    # The 'httpbin.org' will be the host
    # The '/get' will be the path and the arguments
    # The argument '--verify=no' will turn off certificate verification



# Generated at 2022-06-25 19:05:07.632425
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test case - 1 : Mime type is 'text/html'
    pretty_stream_1 = PrettyStream(conversion = Conversion(), formatting = Formatting())
    assert(pretty_stream_1.iter_body() == '\n')

    # Test case - 2 : Mime type is 'text/plain'
    pretty_stream_2 = PrettyStream(conversion = Conversion(), formatting = Formatting())
    assert (pretty_stream_2.iter_body() == '\n')



# Generated at 2022-06-25 19:05:10.842397
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class TestObj(EncodedStream):
        def __init__(self, arg):
            self.msg = arg

    a = TestObj([1, 2, 3])
    assert a.iter_body() == [1, 2, 3]


# Generated at 2022-06-25 19:05:16.760783
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage()
    chunk_size = 1024
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    pretty_stream = PrettyStream(env, conversion, formatting, msg, with_headers, with_body, on_body_chunk_downloaded, chunk_size)

    # AssertionError: NotImplementedError
    try:
        for i in pretty_stream:
            pass
    except NotImplementedError:
        pass


# Generated at 2022-06-25 19:05:28.575845
# Unit test for constructor of class RawStream
def test_RawStream():
    raw_stream_1 = RawStream(with_headers=True, with_body=True)
    raw_stream_2 = RawStream(with_headers=False, with_body=False)
    raw_stream_3 = RawStream(with_headers=True, with_body=False)
    raw_stream_4 = RawStream(with_headers=False, with_body=True)
    assert raw_stream_1.with_headers == True
    assert raw_stream_1.with_body == True
    assert raw_stream_2.with_headers == False
    assert raw_stream_2.with_body == False
    assert raw_stream_3.with_headers == True
    assert raw_stream_3.with_body == False
    assert raw_stream_4.with_headers == False

# Generated at 2022-06-25 19:05:35.435753
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test cases
    raw_stream_1 = RawStream()
    raw_stream_1.msg.headers.add("content-type", "text/plain")
    raw_stream_1.msg.headers.add("A", "B\u0000")
    raw_stream_2 = RawStream()
    raw_stream_2.msg.headers.add("content-type", "text/plain")
    raw_stream_2.msg.headers.add("content-disposition", "text/html; charset=UTF-8")
    raw_stream_2.msg.headers.add("content-disposition", "inline; filename='foo.html'")
    raw_stream_3 = RawStream()
    raw_stream_3.msg.headers.add("content-type", "text/plain")
    raw_stream_3.msg.headers

# Generated at 2022-06-25 19:05:36.656230
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    raw_stream_0 = RawStream()


# Generated at 2022-06-25 19:05:37.802175
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    raw_stream = RawStream()


# Generated at 2022-06-25 19:05:46.699032
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import io
    from unittest.mock import create_autospec
    from httpie.output.processing import Conversion
    from httpie.core import message

    def converter_convert_mock(body):
        return message.parse_content_type('text/plain'), u'test'

    handler = create_autospec(Conversion.Converter)
    handler.returns = converter_convert_mock
    handler.mime = 'test'

    conversion = Conversion()
    conversion.converters = [handler]

    message = message.HTTPMessage()
    message.encoding = 'utf8'
    message.body = 'test'
    message.content_type = 'test'

    stream = PrettyStream(message=message, conversion=conversion)


# Generated at 2022-06-25 19:05:47.569448
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    pretty_stream_1 = PrettyStream


# Generated at 2022-06-25 19:07:30.407780
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    prettify_stream = BufferedPrettyStream()
    assert type(prettify_stream) == BufferedPrettyStream

# Generated at 2022-06-25 19:07:35.695681
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    encoding_0 = 'utf-8'
    env_0 = Environment()
    msg_0 = HTTPMessage(headers={}, body=b'', encoding=encoding_0)
    on_body_chunk_downloaded_0 = None
    class_0 = BufferedPrettyStream(env_0, msg_0, True, True, on_body_chunk_downloaded_0)
    assert class_0.msg == msg_0
    assert class_0.with_headers == True
    assert class_0.with_body == True
    assert class_0.on_body_chunk_downloaded == on_body_chunk_downloaded_0
    assert class_0.output_encoding == encoding_0


# Generated at 2022-06-25 19:07:39.316093
# Unit test for constructor of class RawStream
def test_RawStream():
    raw_stream_0 = RawStream()
    assert raw_stream_0.CHUNK_SIZE == 104857600
    assert raw_stream_0.CHUNK_SIZE_BY_LINE == 1


# Generated at 2022-06-25 19:07:41.904263
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pretty_stream_0 = PrettyStream(Conversion(), Formatting(), HTTPMessage())
    assert isinstance(pretty_stream_0.get_headers(), (bytes, bytearray, memoryview))


# Generated at 2022-06-25 19:07:47.347254
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.processing import Conversion, Formatting
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(conversion=conversion, formatting=formatting, msg=None, with_headers=None, with_body=None)
    chunk = b'\n'
    assert stream.process_body(chunk) == b'\n'


# Generated at 2022-06-25 19:07:47.902176
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    test_case()

# Generated at 2022-06-25 19:07:49.616063
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    assert isinstance(raw_stream_0, BaseStream) == True


# Generated at 2022-06-25 19:07:52.155216
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    env = Environment(stdout_isatty=False)
    conversion = Conversion(env)
    formatting = Formatting(env)
    pretty_stream_0 = PrettyStream(conversion, formatting, env=env)


# Generated at 2022-06-25 19:08:02.391013
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    print("\n### Test for method get_headers of class EncodedStream")
    class HTTPMessage:
        content_type = "text/plain"
        headers = "text/plain"
        # headers = b"Content-Type:text/plain\n\n"
        def iter_body(self, chunk_size):
            print("\n")
            return self.headers
    # class Environment:
    #     pass
    class Formatting:
        pass
    class Conversion:
        pass
    http_message = HTTPMessage()
    # environment = Environment()
    formatting = Formatting()
    conversion = Conversion()
    content_processing_stream = PrettyStream(
        # msg=http_message.data,
        msg=http_message,
        formatting=formatting,
        conversion=conversion
    )
    #

# Generated at 2022-06-25 19:08:06.169238
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_1 = RawStream()
    raw_stream_1.msg = '''GET / HTTP/1.1
Host: www.google.com
Accept: */*'''
    assert raw_stream_1.iter_body() is not None
