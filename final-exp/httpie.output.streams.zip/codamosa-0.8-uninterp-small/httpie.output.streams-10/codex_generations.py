

# Generated at 2022-06-25 19:00:08.690902
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    try:
        from httpie.output.streams import EncodedStream
    except ImportError:
        print("Failed to import module")
    try:
        from httpie.context import Environment
    except ImportError:
        print("Failed to import module")
    try:
        from httpie.models import HTTPMessage
    except ImportError:
        print("Failed to import module")

    env = Environment()
    msg = HTTPMessage(b'OK')
    encoded_stream_0 = EncodedStream(env=env, msg=msg, with_headers=True, with_body=True)


# Generated at 2022-06-25 19:00:19.599393
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Test None msg
    env = Environment()
    msg = None
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None

    encoded_stream_0 = EncodedStream(env=env, msg=msg, with_headers=with_headers, with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded)
    encoded_stream_0.iter_body()

    # Test non-str msg
    env = Environment()
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None


# Generated at 2022-06-25 19:00:23.002160
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # part of params are not necessary
    EncodedStream(on_body_chunk_downloaded=None)



# Generated at 2022-06-25 19:00:25.753566
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print("\nTest: EncodedStream")
    encoded_stream_0 = EncodedStream()
    print("encoded stream 0 = ", encoded_stream_0)



# Generated at 2022-06-25 19:00:31.562259
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    """Tests that the constructor of BufferedPrettyStream succeeds."""
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    # with_headers=True, with_body=True, on_body_chunk_downloaded=None
    bps = BufferedPrettyStream(msg, conversion, formatting, True, True, None)



# Generated at 2022-06-25 19:00:34.070717
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    iter_body_test_case_0()
    iter_body_test_case_1()
    iter_body_test_case_2()
    iter_body_test_case_3()


# Generated at 2022-06-25 19:00:40.256248
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import pytest
    from httpie.formatter.utils import get_formatted_body
    from httpie.output.formatters.raw import RawFormatter
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import ColorsFormatter

    # Test case - 1
    pretty_stream_1 = PrettyStream()
    with pytest.raises(NotImplementedError):
        pretty_stream_1.process_body('{\n    "data": {\n        "hello": "world"\n    }\n}')

    # Test case - 2
    pretty_stream_2 = PrettyStream(ColorsFormatter(False), ColoredConversion([]))

# Generated at 2022-06-25 19:00:50.381015
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    http_message_headers = b'HTTP/1.1 200 OK\r\nServer: nginx\r\nDate: Thu, 02 May 2019 17:36:35 GMT\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 82\r\nConnection: keep-alive\r\nSet-Cookie: experiment-422-variation-1461=control; expires=Sun, 02-May-2021 17:36:35 GMT; Max-Age=63072000; path=/; domain=httpie.org\r\n\r\n'

# Generated at 2022-06-25 19:00:56.001331
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()

# Generated at 2022-06-25 19:01:05.067925
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class DummyHTTPMessage(HTTPMessage):
        def encode(self, str):
            return b"HTTP/1.1 dummy_status \r\n" \
                    b"Content-Type: text/plain \r\n" \
                    b"Content-Length: 4\r\n" \
                    b"\r\n" \
                    b"this\r\n" \
                    b"is\r\n" \
                    b"a\r\n" \
                    b"test\r\n"
    msg = DummyHTTPMessage()
    stream = EncodedStream(msg=msg)

    # actual value
    actual = [i for i in stream.iter_body()]

    # expected value

# Generated at 2022-06-25 19:01:21.841630
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    print(env)
    encoded_stream_0 = EncodedStream(msg = "", env = env)
    encoded_stream_1 = EncodedStream(msg = "", env = env, with_headers=True)
    encoded_stream_2 = EncodedStream(msg = "", env = env, with_headers=True, with_body=True)
    encoded_stream_3 = EncodedStream(msg = "", env = env, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    print(encoded_stream_0)
    print(encoded_stream_1)
    print(encoded_stream_2)
    print(encoded_stream_3)


# Generated at 2022-06-25 19:01:30.243693
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io

# Generated at 2022-06-25 19:01:35.511055
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    mime = "application/json"
    chunk = "\nThis is a test JSON\n"
    chunk_bytes = b'\nThis is a test JSON\n'
    obj = PrettyStream(Conversion(),Formatting())
    obj.mime = mime
    assert obj.process_body(chunk) == chunk_bytes


# Generated at 2022-06-25 19:01:41.149454
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import pytest
    from httpie.models import HTTPMessage 
    from httpie.output.streams import PrettyStream
    msg = HTTPMessage()
    msg.headers = 'age:0'
    production_stream = PrettyStream(msg)
    assert production_stream.get_headers() == 'age:0'.encode()
    assert production_stream.iter_body()[0] == b'age:0'



# Generated at 2022-06-25 19:01:48.244663
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # failure
    try:
        BufferedPrettyStream(1, 1, 1, 1)
    except TypeError as e:
        assert '__init__() takes 4 positional arguments but 5 were given' in str(
            e)
    # success
    BufferedPrettyStream(1, 1, 1, 1, 1)


# Generated at 2022-06-25 19:01:59.185204
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test case 0:
    raw_stream_0 = RawStream()
    # Test case 1:
    raw_stream_1 = RawStream()
    # Test case 2:
    raw_stream_2 = RawStream()
    # Test case 3:
    raw_stream_3 = RawStream()
    # Test case 4:
    raw_stream_4 = RawStream()
    # Test case 5:
    raw_stream_5 = RawStream()
    # Test case 6:
    raw_stream_6 = RawStream()
    # Test case 7:
    raw_stream_7 = RawStream()
    # Test case 8:
    raw_stream_8 = RawStream()
    # Test case 9:
    raw_stream_9 = RawStream()
    # Test case 10:
    raw_stream_10 = RawStream()
   

# Generated at 2022-06-25 19:02:05.645909
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test case: body is binary
    print('Test case: body is binary')
    body = "\0".encode()
    msg = HTTPMessage(headers='', body=body, encoding='utf8')
    stream = BufferedPrettyStream(with_headers=True, with_body=True, msg=msg)
    try:
        for chunk in stream.iter_body():
            pass
    except BinarySuppressedError:
        print('Unicode characters not shown')
        print()
    else:
        print('FAIL')
        print()
    # Test case: body is not binary but has Unicode escape
    print('Test case: body is not binary but has Unicode escape')
    body = r'\u1f480'.encode()
    msg = HTTPMessage(headers='', body=body, encoding='utf8')
   

# Generated at 2022-06-25 19:02:07.521526
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream(): 
    buffered_pretty_stream_0 = BufferedPrettyStream()


# Generated at 2022-06-25 19:02:15.202467
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    print("Test iter_body of class PrettyStream...")
    lines = [b"hello\n", b"world\n"]
    message = HTTPMessage()
    message.stream = iter(lines)
    message.encoding = "utf-8"
    message.content_type = "text/plain;charset=utf-8"
    conversion = Conversion()
    conversion.converters["text/plain"] = [
        "httpie.output.converters.plain.PlainConverter"]
    conversion._load_converters()
    formatting = Formatting()
    stream = PrettyStream(message, conversion=conversion, formatting=formatting)
    for i, line in enumerate(stream.iter_body()):
        if line != b"hello\n":
            print("Line number {} fails!")
            break

# Generated at 2022-06-25 19:02:17.510563
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream(HTTPMessage(), True, True)


# Generated at 2022-06-25 19:02:26.455191
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    encoded_stream = EncodedStream()
    assert(encoded_stream is not None)

# Generated at 2022-06-25 19:02:27.338400
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pass


# Generated at 2022-06-25 19:02:33.366155
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    b = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    rtn = b.__iter__()  # This can only return an iterator
    assert type(rtn) == type(iter([]))


# Generated at 2022-06-25 19:02:35.004762
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    encoded_stream_0 = EncodedStream()


# Generated at 2022-06-25 19:02:36.836230
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream = PrettyStream()
    pretty_stream.process_body("Foo")


# Generated at 2022-06-25 19:02:39.066054
# Unit test for constructor of class RawStream
def test_RawStream():
    raw_stream = RawStream(env=Environment(), msg=HTTPMessage())
    assert raw_stream


# Generated at 2022-06-25 19:02:46.479613
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # create an EncodedStream object
    encoded_stream = EncodedStream()
    # use HTTPMessage to mock a message
    msg = HTTPMessage(headers='',body='this is a test message!')
    # store iter_body as a str in result
    result = []
    for i in encoded_stream.iter_body(msg):
        result.append(i.decode('utf-8'))

    # since there is no binary data in 'this is a test message!', should not raise
    assert result == 'this is a test message!'


# Generated at 2022-06-25 19:02:47.332854
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    encoded_stream_0 = EncodedStream()



# Generated at 2022-06-25 19:02:50.665143
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage('Test/1.1', '200', 'OK', b"This is a test", encoding = 'utf8', content_type = 'text/plain')
    stream = EncodedStream(msg)

# Generated at 2022-06-25 19:02:59.543743
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test case to call iter_body on BufferedPrettyStream
    converter_0 = BufferedPrettyStream.Conversion()
    converter_1 = BufferedPrettyStream.Conversion()
    converter_2 = BufferedPrettyStream.Conversion()
    converter_3 = BufferedPrettyStream.Conversion()
    converter_4 = BufferedPrettyStream.Conversion()
    converter_5 = BufferedPrettyStream.Conversion()
    converter_6 = BufferedPrettyStream.Conversion()
    converter_7 = BufferedPrettyStream.Conversion()
    converter_8 = BufferedPrettyStream.Conversion()
    converter_9 = BufferedPrettyStream.Conversion()
    converter_10 = BufferedPrettyStream.Conversion()
    converter_11 = BufferedPrettyStream.Conversion()
    converter_12 = BufferedPrettyStream.Conversion()
    converter

# Generated at 2022-06-25 19:03:20.532017
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(headers=b'{"content-type": "application/json"}')
    msg.encoding = 'utf8'
    msg.json(b'{"a": 1, "b": 2}')

    conversion = Conversion(None, None)
    formatting = Formatting(None, None, None, None, None, None)

    pretty_stream_0 = PrettyStream(msg, True, True, conversion=conversion, formatting=formatting)
    # Test proper execution path
    test_mime = 'application/json'
    test_body = {"a": 1, "b": 2}
    msg.content_type = test_mime
    msg.json(test_body)
    test_output = pretty_stream_0.process_body(test_body)

# Generated at 2022-06-25 19:03:31.702158
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():

    class MockHttpMessage:
        pass

    http_message = MockHttpMessage()
    http_message.content_type = 'application/json'
    http_message.iter_body = lambda x: [b'{ "key": "value" }']

    #mock_iter_body_returns_bytes = ['{ "key": "value" }']

    mock_response_body = '{ "key": "value" }'
    mock_format_body = '{\n    "key": "value"\n}'
    mock_encode = mock_format_body.encode()

    buffered_pretty_stream = BufferedPrettyStream(msg=http_message,
                                                  conversion='conversion',
                                                  formatting='formatting')

    buffered_pretty_stream.process_body = lambda x: mock_format_body

# Generated at 2022-06-25 19:03:33.446032
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream()
    pretty_stream_0 = stream.iter_body()


# Generated at 2022-06-25 19:03:38.753430
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream(conversion=Conversion(), formatting=Formatting())
    json_response = ('%s\r\n' % ('{ "key": "value" }')).encode()

    iter_body = stream.iter_body()

    json_response_pretty = iter_body.__next__()
    assert json_response_pretty.decode() == '{ "key": "value" }\n'



# Generated at 2022-06-25 19:03:42.804436
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    url = 'http://www.baidu.com'
    http = requests.get(url)
    http_m = HTTPMessage(url, http)
    http_stream = EncodedStream(msg=http_m)
    http_stream.with_headers
    http_stream.with_body
    http_stream.get_headers()
    http_stream.iter_body()
    http_stream.__iter__()

# Generated at 2022-06-25 19:03:53.124293
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert True
    raw_stream_0 = RawStream()
    encoding_0 = None
    on_body_chunk_downloaded_0 = None
    base_stream_0 = BaseStream(headers_0, True, body_0, encoding_0, on_body_chunk_downloaded_0)
    assert list(base_stream_0.__iter__()) == [99, 111, 117, 110, 116, 32, 111, 102, 32, 102, 117, 108, 108, 32, 116, 101, 115, 116, 32, 99, 97, 115, 101, 115, 32, 116, 111, 32, 98, 101, 32, 101, 120, 101, 99, 117, 116, 101, 100, 13, 13, 13, 13]


# Generated at 2022-06-25 19:03:54.952847
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    response = '''HTTP/1.1 200 OK
Content-Type: text/plain

hello'''
    msg = HTTPMessage.from_http_str(response)
    stream = PrettyStream(msg)
    assert stream.iter_body() == [b"hello"]

# Generated at 2022-06-25 19:04:02.945804
# Unit test for constructor of class RawStream
def test_RawStream():
    # Message without body.
    msg_0 = HTTPMessage({'Content-Type': 'application/json',
                         'Content-Length': '0'})
    stream_0 = RawStream(msg_0)
    assert stream_0.CHUNK_SIZE == 10240
    assert stream_0.with_headers is True
    assert stream_0.with_body is True
    assert stream_0.msg == msg_0

    # Message with body.
    msg_1 = HTTPMessage({'Content-Type': 'text/html',
                         'Content-Length': '1024'},
                        b'Content')
    stream_1 = RawStream(msg_1)
    assert stream_1.with_headers is True
    assert stream_1.with_body is True
    assert stream_1.msg == msg_1

    #

# Generated at 2022-06-25 19:04:09.768240
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    data = "A\r\nB\r\nC\r\nD\r\n"
    x = EncodedStream(message = HTTPMessage(headers=[], data = data.encode()))
    res = [y.decode() for y in x.iter_body()]
    assert ''.join(res) == data


# Generated at 2022-06-25 19:04:16.782530
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    raw_stream_0 = RawStream()
    pretty_stream_0 = PrettyStream(
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
        msg=raw_stream_0.msg)
    pretty_stream_0.get_headers()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:05:19.475270
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():

    body = "<html><head><title>This is page title</title></head><body></body></html>"

    p_stream_0 = PrettyStream(Conversion(), Formatting())

    # Test 0
    if p_stream_0.process_body(body) == b"<html>\n<head>\n<title>\nThis is page title\n</title>\n</head>\n<body></body>\n</html>\n":
        print("test_PrettyStream_process_body: Test 0 - Passed")
    else:
        print("test_PrettyStream_process_body: Test 0 - Failed")

    # Test 1
    p_stream_1 = PrettyStream(Conversion(import_json=True), Formatting(indent=4))


# Generated at 2022-06-25 19:05:26.281453
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    test_url = "http://localhost:5000/api/todos"
    http = Http()
    response, content = http.request(test_url, headers={'Accept': 'text/plain'})
    assert(str(response.status) == '200')
    assert(response.reason == 'OK')
    assert (response['content-type'] == 'application/json')
    # print(content.decode('utf-8'))
    return

# Generated at 2022-06-25 19:05:31.842497
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    for k in range(10):
        c = EncodedStream()
        c.CHUNK_SIZE = k
        c.CHUNK_SIZE_BY_LINE = 1
        #'''
        for i in range(10):
            msg = HTTPMessage()
            msg.iter_lines = mock.MagicMock(return_value='abc\n')
            c.msg = msg
            for line, lf in c.iter_body():
                pass
                #'''
                #'''


# Generated at 2022-06-25 19:05:36.328313
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Arrange
    encodings = ['utf-8', 'utf8', 'latin1', 'base64', 'ascii']
    self = HTTPMessage()
    self.headers = "HTTP/1.1 200 OK"
    self.encoding = "utf8"
    self.content = "hello world"

    for encoding in encodings:
        self.encoding = encoding
        # Act
        body = ''
        for item in BufferedPrettyStream(msg=self).iter_body():
            body += item.decode('utf8')
        # Assert
        assert body == self.content


# Generated at 2022-06-25 19:05:45.544251
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    content_type = 'application/json'

    def create_stream(raw_body_bytes):
        msg = HTTPMessage(content_type=content_type, raw_body_bytes=raw_body_bytes)
        return EncodedStream(msg=msg, with_body=True)

    # test case 0: utf-8 encoding, no binary data
    stream_0 = create_stream(b'{ "key": "value" }\n')
    for chunk in stream_0:
        assert chunk == b'{ "key": "value" }\n'

    # test case 1: utf-8 encoding, no binary data
    stream_1 = create_stream(b'{"key": "value" }\n')
    for chunk in stream_1:
        assert chunk == b'{"key": "value" }\n'

# Generated at 2022-06-25 19:05:50.225156
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Setup code
    # vars
    msg = "message"
    chunk_size = 0
    with_headers = False
    with_body = True
    on_body_chunk_downloaded = None

    # Test code
    test = RawStream(msg, chunk_size, with_headers, with_body, on_body_chunk_downloaded)
    test.iter_body()


# Generated at 2022-06-25 19:05:54.305068
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    """
    Test the __iter__ function of BaseStream class
    """
    Test_case = "test_BaseStream___iter__"
    print("\nTest case: " + Test_case)
    base_stream_0 = BaseStream()
    for item in base_stream_0:
        print(item)

# Generated at 2022-06-25 19:05:59.124281
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    test_msg = HTTPMessage(body='sample_message')
    test_conversion = Conversion()
    test_formatting = Formatting(indent=2)
    ps = PrettyStream(test_msg, conversion=test_conversion, formatting=test_formatting)
    for i in ps.iter_body():
        if b'\0' in i:
            print('BinarySuppressedError')

# Generated at 2022-06-25 19:06:10.800574
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()
    msg.headers = "key: value"
    msg.raw_body = "HTTP body"
    msg.encoding = "utf8"
    msg.content_type = "application/json"
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = "utf8"
    env.stdout = open("output.txt", "w")
    formatting = Formatting()
    conversion = Conversion()
    stream = BufferedPrettyStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None, env=env, conversion=conversion, formatting=formatting)

# Generated at 2022-06-25 19:06:18.057510
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream

    mime = 'application/json'
    content = b'{"key": "value"}'
    response = Response(
        *Response.parse_raw(b'200 OK\r\nContent-Type: ' + mime.encode() + b'\r\n\r\n' + content)
    )

    body_stream = BufferedPrettyStream(
        response,
        conversion=Conversion(),
        formatting=Formatting()
    )

    result = b''
    try:
        for line in body_stream.iter_body():
            result += line
    except Exception as e:
        result = e.message

    assert result == content

# Generated at 2022-06-25 19:07:46.005364
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream_1 = EncodedStream()
    stream_1.msg.body = 'foo'.encode('utf-8')
    stream_1.msg.encoding = 'utf-8'

    stream_2 = EncodedStream()
    stream_2.msg.body = 'фуу'.encode('utf-8')
    stream_2.msg.encoding = 'utf-8'

    stream_3 = EncodedStream()
    stream_3.msg.body = 'фуу'.encode('cp1251')
    stream_3.msg.encoding = 'cp1251'

    stream_4 = EncodedStream()
    stream_4.msg.body = b'foo\x00'
    stream_4.msg.encoding = 'utf-8'

    stream_5 = EncodedStream()
    stream

# Generated at 2022-06-25 19:07:47.585179
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    raw_stream = RawStream()
    pretty_stream = BufferedPrettyStream()

# Generated at 2022-06-25 19:07:51.191195
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    msg = HTTPMessage()
    stream_0 = PrettyStream(conversion=Conversion(), formatting=Formatting(), env=env, msg=msg)
    # Verify the length of the method body
    assert(len(stream_0.__iter__.__code__.co_code) == 1)


# Generated at 2022-06-25 19:07:52.779722
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    assert False


# Generated at 2022-06-25 19:07:55.122405
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_1 = RawStream()
    assert iter(raw_stream_1) == raw_stream_1.iter_body()


# Generated at 2022-06-25 19:07:57.511758
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pretty_stream_1 = PrettyStream()
    assert pretty_stream_1.get_headers() == b''


# Generated at 2022-06-25 19:07:58.765820
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    encoded_stream = EncodedStream()

# Generated at 2022-06-25 19:08:09.861916
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    env = Environment()
    msg = HTTPMessage(headers=None,content='')
    with_headers = True
    with_body = True
    formatting = Formatting()

    conv = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
    conversion = Conversion(converters=[('*', 'json', 'pretty'),
                                        ('text/*', 'html', 'pretty'),
                                        ('*', 'xml', 'pretty')],
                            default_options=[('pretty', None)],
                            date_format=conv)

    # Test case 0
    print('Test case 0')
    pretty_stream_0 = PrettyStream(conversion=conversion)

# Generated at 2022-06-25 19:08:13.717936
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    stream = EncodedStream(msg)
    assert (stream.msg == msg and stream.output_encoding == 'utf8')
    stream = EncodedStream(msg, env=Environment())
    assert (stream.msg == msg and stream.output_encoding == 'utf8')


# Generated at 2022-06-25 19:08:16.959505
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    sample_iterable = b'1234'
    expected = [b'1', b'2', b'3', b'4']
    rawStream = RawStream(msg=sample_iterable)
    actual = []
    for i in rawStream.iter_body():
        actual.append(i)
    assert actual == expected