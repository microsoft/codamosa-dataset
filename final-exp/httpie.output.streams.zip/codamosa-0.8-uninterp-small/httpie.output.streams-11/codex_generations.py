

# Generated at 2022-06-25 19:00:19.514997
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    f = open('tests/dash-stream.txt', 'r')
    msg = HTTPMessage.from_file(f)
    f.close()
    pretty_stream = PrettyStream(msg)
    


# Generated at 2022-06-25 19:00:27.605673
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test case 0
    url = 'http://httpbin.org/get'
    buffered_pretty_stream_0 = BufferedPrettyStream(url)
    # Test case 1
    url = 'http://httpbin.org/get'
    buffered_pretty_stream_1 = BufferedPrettyStream(url)
    # Test case 2
    url = 'http://httpbin.org/get'
    buffered_pretty_stream_2 = BufferedPrettyStream(url)

# Generated at 2022-06-25 19:00:28.248081
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    pass

# Generated at 2022-06-25 19:00:37.032489
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # No converter needed, body is made of ascii
    raw_stream_0 = RawStream()
    raw_stream_0.msg.encoding = "ascii"
    raw_stream_0.mime = "text/ascii"
    pretty_stream_0 = PrettyStream(raw_stream_0)
    # No converter needed, body is made of unicode
    raw_stream_1 = RawStream()
    raw_stream_1.msg.encoding = "utf-8"
    raw_stream_1.mime = "text/utf-8"
    pretty_stream_1 = PrettyStream(raw_stream_1)
    # Converter needed, body is made of ascii to binary encoding
    raw_stream_2 = RawStream()

# Generated at 2022-06-25 19:00:39.706234
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    encoding = 'utf-8'
    conversion = Conversion(encoding)
    formatting = Formatting(encoding)
    buff = BufferedPrettyStream(conversion, formatting)


# Generated at 2022-06-25 19:00:49.623410
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(
        headers={
            'Content-Type': 'application/json'
        },
        body=b'{"user": "larry", "password": "1234"}',
        encoding='utf8'
    )
    pretty_stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting()
    )
    assert pretty_stream.process_body(b'{"user": "larry", "password": "1234"}') == b'{\n    "user": "larry",\n    "password": "1234"\n}'

# Generated at 2022-06-25 19:00:52.929342
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert BaseStream.__iter__.__module__ == 'httpie.output.streams'
    assert BaseStream.__iter__.__qualname__ == 'BaseStream.__iter__'


# Generated at 2022-06-25 19:00:55.010316
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pstream = PrettyStream("msg", None, None)
    assert pstream.get_headers() == 'msg'

# Generated at 2022-06-25 19:00:56.193912
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    assert(PrettyStream.get_headers(None)) == None

# Generated at 2022-06-25 19:01:05.216734
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # This test is mostly important to describe the current behavior of iter_body
    # function. It should not change so easily, ie. bug fixes have to be carefully considered.
    raw_stream_0 = RawStream(HTTPMessage(b''))
    raw_stream_1 = RawStream(HTTPMessage(b''), chunk_size=10)
    raw_stream_2 = RawStream(HTTPMessage(b'A body of the message'))
    raw_stream_3 = RawStream(HTTPMessage(b'A body of the message'), chunk_size=10)
    raw_stream_4 = RawStream(HTTPMessage(b'This is a very long body that cannot be read in one chunk'))
    print(raw_stream_4.iter_body())

# Generated at 2022-06-25 19:01:23.517392
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # body_0 is the content of the body(bytes)
    # mime_0 is the content-type value of the message
    # msg_0 is the message of HTTPMessage type
    body_0 = b'\x00\x00\x00\x00\x00'
    mime_0 = 'image/bmp'
    msg_0 = HTTPMessage(body_0, content_type_header='image/bmp')
    # conversion_0 is an instance of Conversion
    conversion_0 = Conversion()
    # msg_1 is the message of HTTPMessage type
    msg_1 = HTTPMessage(body_0, headers={'Content-Type': mime_0 + '; charset=utf8'})
    # msg_2 is the message of HTTPMessage type

# Generated at 2022-06-25 19:01:26.707319
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Test for typical usage
    pretty_stream_0 = BufferedPrettyStream(encoding='utf-8', conversion={}, formatting={}, msg={}, with_headers=True, with_body=True, on_body_chunk_downloaded=test_case_0)



# Generated at 2022-06-25 19:01:27.962555
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pretty_stream = PrettyStream()
    assert pretty_stream.get_headers() is None


# Generated at 2022-06-25 19:01:30.582466
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 19:01:42.177894
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test case 1
    stream = PrettyStream(None, None)
    stream.msg.content_type = 'application/json'
    stream.mime = 'application/json'
    converter = stream.conversion.get_converter(stream.mime)
    iter_lines = stream.msg.iter_lines(stream.CHUNK_SIZE)
    for line, lf in iter_lines:
        if b'\0' in line:
            if True:
                converter = stream.conversion.get_converter(stream.mime)
                if converter:
                    body = bytearray()
                    # noinspection PyAssignmentToLoopOrWithParameter
                    for line, lf in chain([(line, lf)], iter_lines):
                        body.extend(line)

# Generated at 2022-06-25 19:01:52.224874
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()
    msg.raw = b'{"id": "1", "name": "tom"}\n'
    class F:
        def __init__(self):
            self.format = 'json'
            self.colors = True
            self.prettify = True
    formatting = F()
    class C:
        def get_converter(self, mimetype):
            return None
    conversion = C()
    s = BufferedPrettyStream(msg, conversion=conversion,
    formatting=formatting)
    chunk = ''
    for c in s.iter_body():
        chunk += c
    assert(chunk == '{\n    "id": "1",\n    "name": "tom"\n}')

# Generated at 2022-06-25 19:01:54.896696
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(body='abc\n')
    stream = BaseStream(msg)
    assert next(stream) == b''


# Generated at 2022-06-25 19:02:03.248333
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import httpie
    from httpie.models import HTTPMessage
    from httpie.downloads import Downloader
    msg = HTTPMessage()

    msg.headers = """HTTP/1.1 200 OK
    Server: Apache
    Content-Type: text/html; charset=UTF-8
    Content-Encoding: gzip
    Vary: Accept-Encoding
    Transfer-Encoding: chunked
    Date: Mon, 27 Jul 2009 12:28:53 GMT
    X-Pad: avoid browser bug"""


# Generated at 2022-06-25 19:02:13.160658
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class TestStream(PrettyStream):
        def __init__(self):
            conversion = Conversion()
            formatting = Formatting()
            msg = HTTPMessage()
            msg.content_type = application_json
            super().__init__(conversion, formatting, msg)

    stream = TestStream()
    assert stream.process_body(b'{"key": "value"}') == b'{\"key\": \"value\"}'
    assert stream.process_body({"key": "value"}) == b'{\"key\": \"value\"}'
    assert stream.process_body({"key": "value"}, False) == b'{\n  "key": "value"\n}'


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-25 19:02:20.138657
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Empty input
    assert ''.encode(encoding='utf-8') == PrettyStream('','','','','','','').process_body('')
    # Non-empty input
    assert 'Test String'.encode(encoding='utf-8') == PrettyStream('','','','','','','').process_body('Test String')
    #Non-string input
    assert (b'Test String').decode('utf-8') == PrettyStream('','','','','','','').process_body(b'Test String')

# Generated at 2022-06-25 19:02:44.445754
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    raw_stream_0 = RawStream()
    raw_stream_1 = RawStream(raw_stream_0)
    encoded_stream_0 = EncodedStream(raw_stream_1)
    raw_stream_0.iter_body()
    raw_stream_1.iter_body()
    encoded_stream_0.iter_body()


# Generated at 2022-06-25 19:02:54.455080
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage()
    msg.source = cStringIO()
    msg.encoding = 'utf8'
    msg.content_type = 'text/plain'

    conv = Conversion()
    conv.register(None, None)
    conv.register('application/octet-stream', None)
    conv.register('text/plain', None)

    msg.source.write('\xFF')
    msg.source.seek(0)
    with pytest.raises(BinarySuppressedError):
        PrettyStream(msg, env=Environment(), conversion=conv)

    msg.source.seek(0)
    msg.source.truncate(0)
    msg.source.write('\x00')
    msg.source.seek(0)
    with pytest.raises(BinarySuppressedError):
        Pretty

# Generated at 2022-06-25 19:02:57.762225
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(b'GET /test')
    iter_body = BufferedPrettyStream(msg, b'{1,2,3}').iter_body()
    assert '{1,2,3}' == next(iter_body)


# Generated at 2022-06-25 19:03:01.162044
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    if hasattr(raw_stream_0, "BaseStream___iter__"):
        raw_stream_0.BaseStream___iter__()


# Generated at 2022-06-25 19:03:11.288493
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Create sample stream
    stream = BaseStream()

    # Create Sample header and body for message
    header = '''bladiebla'''
    body = '''bladiebla'''

    # Create sample message with header and body
    stream_message = HTTPMessage()
    stream_message.headers = header
    stream_message.body = body

    # Create sample stream
    stream = BaseStream(stream_message)

    # Create iterator for message
    iterator = iter(stream)

    # Get first item of iterator message
    item = next(iterator)

    # Check if message is valid
    assert item == b'bladiebla'


# Generated at 2022-06-25 19:03:19.793128
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    message = HTTPMessage(
        http_version="HTTP/1.1",
        status_code="200",
        headers={"one": "1", "two": "two"}
    )
    stream = PrettyStream(
        msg=message,
        env=Environment(
            json_indent=2,
            json_sort_keys=True,
            stdout_isatty=True
        ),
        formatting=Formatting(
            json_indent=2,
            json_sort_keys=True,
            stdout_isatty=True
        )
    )
    result = stream.get_headers()

# Generated at 2022-06-25 19:03:30.827443
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    body = "bla bla bla bla bla bla\nbla bla bla bla bla bla"
    r = RawStream.CHUNK_SIZE
    pretty_stream = PrettyStream(Conversion(None), Formatting(None),
    HTTPMessage("GET http://localhost:8000", headers={"Content-type":"text/plain",
    "Content-length":len(body)}, body=body), with_headers=True, with_body=True)
    for i in range(0, len(body), r):
        chunk = body[i:i+r]
        assert isinstance(chunk, str) == isinstance(pretty_stream.process_body(chunk), str)
        assert pretty_stream.process_body(chunk) == chunk


# Generated at 2022-06-25 19:03:35.094516
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(None, '200 OK', '', 'HTTP/1.1', [], 'plain/text')
    msg.headers.text = b'foo: bar'
    pretty_stream = PrettyStream(msg, msg.headers)
    pretty_stream.process_body(b'foo')

# Generated at 2022-06-25 19:03:38.983992
# Unit test for constructor of class RawStream
def test_RawStream():
    r1 = RawStream(with_headers=True, with_body=False)
    assert r1.with_headers
    assert not r1.with_body
    r2 = RawStream(with_headers=False, with_body=True)
    assert not r2.with_headers
    assert r2.with_body



# Generated at 2022-06-25 19:03:41.908480
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    buf = b"abcdefghi\n"

    def iter_body_mock():
        return buf

    raw_stream = RawStream(iter_body=iter_body_mock)
    assert next(raw_stream) == buf

# Generated at 2022-06-25 19:04:28.885768
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    test_cases = [
        ('Converter', 'Plain Text', (b'\x80')),
        ('Converter', 'Plain Text', (b'helloworld')),
        ('Converter', 'Plain Text', (b'hello\0world')),
        ('Converter', 'Plain Text', (b'hello\x80world')),
        ('Plain Text', 'Plain Text', (b'\x80')),
        ('Plain Text', 'Plain Text', (b'helloworld')),
        ('Plain Text', 'Plain Text', (b'hello\0world')),
        ('Plain Text', 'Plain Text', (b'hello\x80world'))
    ]

    def doc_iter_body(self, c_mime):
        body = bytearray

# Generated at 2022-06-25 19:04:32.806233
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(text='test content')
    stream = PrettyStream(msg)
    assert stream.process_body('test content') == b'test content'

# Generated at 2022-06-25 19:04:34.761113
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(body=b'body')
    pretty_stream = PrettyStream(msg, True, True)



# Generated at 2022-06-25 19:04:41.962729
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPMessage
    from httpie.output.streams import EncodedStream
    from httpie.input.utils import get_binary_stream

    message = HTTPMessage(
        b'GET / HTTP/1.1\r\n'
        b'Host: example.com\r\n'
        b'User-Agent: HTTPie/0.9.2\r\n'
        b'Accept-Encoding: gzip, deflate\r\n'
        b'Accept: */*\r\n'
        b'\r\n'
    )
    message.encoding = "utf-8"
    # if you do not know the message's encoding you can leave it
    # as None.

    # test for the case that we know message's encoding
    # in this case, we

# Generated at 2022-06-25 19:04:50.392998
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    LOG.info("Start: test_BaseStream___iter__")
    data_0 = b"Date: Thu, 16 Jan 2020 13:46:45 GMT\r\nServer: Apache\r\nX-Frame-Options: DENY\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\nTransfer-Encoding: chunked\r\nContent-Type: text/html; charset=UTF-8\r\nVary: Accept-Encoding,Accept-Encoding\r\n\r\n"
    msg_0 = HTTPMessage(data_0)
    stream_0 = BaseStream(msg_0)
    assert str(next(stream_0)) == "<memory at 0x10a42b828>"

# Generated at 2022-06-25 19:04:53.587415
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream(Conversion(), Formatting())
    stream.msg = HTTP20Response()
    stream.msg.raw.headers = 'header'
    stream.msg.raw.body = 'body'

    stream.msg.iter_body(PrettyStream.CHUNK_SIZE)

# Generated at 2022-06-25 19:04:58.360979
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    raw_stream_1 = RawStream(raw_stream_0)
    #assert Iterable[bytes]  == type(raw_stream_1.__iter__())
    #assert True == type(raw_stream_1.__iter__())
    raw_stream_1.__iter__()

# Generated at 2022-06-25 19:05:03.205556
# Unit test for constructor of class RawStream
def test_RawStream():
    assert(RawStream().CHUNK_SIZE == 102400)
    raw_stream = RawStream()
    raw_stream.CHUNK_SIZE = 10
    assert(raw_stream.CHUNK_SIZE == 10)
    assert(RawStream(chunk_size = 10).CHUNK_SIZE == 10)


# Generated at 2022-06-25 19:05:12.305101
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = Message(headers={"host": "www.google.com"}, body="Hello World")
    msg.headers["Accept-Encoding"] = "123"
    msg.headers["User-Agent"] = "Agent"
    msg.headers["Date"] = "date"
    msg.headers["Server"] = "server"
    msg.headers["Content-Length"] = "12345"
    msg.headers["Connection"] = "connection"
    msg.headers["Expires"] = "expires"
    msg.headers["ETag"] = "etag"
    
    stream = BufferedPrettyStream(msg, with_headers=True, with_body=True)
    # Do nothing
    # An assertion will be added to the function iter_body() in the future




# Generated at 2022-06-25 19:05:16.334452
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    binary = bytearray(b'\xff\xfe\xfd')
    test_msg = HTTPMessage(
        url='test',
        body=binary,
        headers=Headers()
    )
    stream = EncodedStream(test_msg)
    for byte in stream.iter_body():
        pass


# Generated at 2022-06-25 19:06:40.892630
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Create a PrettyStream instance
    converted_input = PrettyStream(None, None, None)
    # process_body(chunk: Union[str, bytes]) -> bytes
    # Test for an empty string as input
    assert converted_input.process_body("") == b''
    # Test for an empty sequence as input
    assert converted_input.process_body([]) == b''
    # Test for a null input
    assert converted_input.process_body(None) == b'None'
    # Test input to be non-empty and non-string
    assert converted_input.process_body([1, 2, 3]) == b'[1, 2, 3]'
    # Test input to be non-empty and non-string
    assert converted_input.process_body(1) == b'1'
    # Test input to be non-empty

# Generated at 2022-06-25 19:06:43.587215
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Tests if anything is returned
    msg = HTTPMessage()
    msg.headers = 'headers'
    stream = BaseStream(msg)
    assert stream.__iter__()

# Generated at 2022-06-25 19:06:48.806672
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import io
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPResponse

    env = Environment()
    msg = HTTPResponse(b'HTTP/1.1 200 OK\r\n', io.BytesIO(b'{"test": "test"}'))
    stream = PrettyStream(msg=msg, env=env, with_body=True, with_headers=True)
    response = next(iter(stream))
    assert response == b'"{\\"test\\": \\"test\\"}"'

# Generated at 2022-06-25 19:06:50.270876
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream()
    assert raw_stream_0.iter_body() is None


# Generated at 2022-06-25 19:06:53.334658
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    a = PrettyStream()
    b = PrettyStream(PrettyStream())
    a.formatting = Formatting()
    a.conversion = Conversion()
    a.msg = HTTPMessage()
    assert a
    assert b
    assert a.mime is not None


# Generated at 2022-06-25 19:07:03.018814
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(
        url='',
        headers=b'',
        content_type='',
        encoding='',
        body=b'',
        chunked=False,
        stream=True,
    )
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    pretty_stream = BufferedPrettyStream(
        msg=msg, with_headers=with_headers,
        with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded,
        env=env, conversion=conversion, formatting=formatting
    )

# Generated at 2022-06-25 19:07:10.512919
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    class TestClass:
        def __init__(self):
            self.headers = b'headers'
            self.body = b'body'
            self.encoding = 'utf-8'
            self.content_type = 'text/html'

        def iter_body(self, chunk_size):
            return self.body

    raw_stream = RawStream(TestClass(), True, True, None)
    result = list(raw_stream)
    assert len(result) == 2
    assert result[0] == b'headers\r\n\r\n'
    assert result[1] == b'body'


# Generated at 2022-06-25 19:07:20.218615
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    data = b'{"user":"bob","id":"1"}\n' \
           b'{"user":"alice","id":"2"}\n' \
           b'{"user":"bob","id":"3"}\n' \
           b'{"user":"charlie","id":"3"}\n'
    #msg = HTTPMessage(data, content_type="application/json")
    msg = HTTPMessage(data, content_type="application/json")

# Generated at 2022-06-25 19:07:30.013533
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    test_env = Environment()
    test_mime = 'application/javascript'
    test_conversion = Conversion(test_env)
    test_formating = Formatting(test_env)
    test_msg = HTTPMessage(b'', '', '', encoding='utf8')
    test_stream = PrettyStream(test_conversion, test_formating, test_msg)

    assert(test_stream.formatting == test_formating)
    assert(test_stream.conversion == test_conversion)
    assert(test_stream.mime == test_mime)


# Generated at 2022-06-25 19:07:32.354928
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():

    pretty_stream = PrettyStream()
    chunk = '{}'
    process_chunk = pretty_stream.process_body(chunk)
    assert process_chunk == b'{\n    \n}\n'