

# Generated at 2022-06-25 19:00:18.280772
# Unit test for constructor of class RawStream
def test_RawStream():
    raw_stream_0 = RawStream()
    assert isinstance(raw_stream_0, RawStream)
    assert isinstance(raw_stream_0, BaseStream)
    assert raw_stream_0.CAN_READ_BINARY
    assert raw_stream_0.CHUNK_SIZE == 1024 * 100
    assert raw_stream_0.CHUNK_SIZE_BY_LINE == 1
    assert raw_stream_0.chunk_size == 1024 * 100
    assert raw_stream_0.msg == None
    assert raw_stream_0.on_body_chunk_downloaded == None
    assert raw_stream_0.with_body
    assert raw_stream_0.with_headers


# Generated at 2022-06-25 19:00:24.329900
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    assert raw_stream_0.get_headers() is None
    assert raw_stream_0.with_headers is False
    assert raw_stream_0.with_body is True
    assert raw_stream_0.iter_body() is None
    assert raw_stream_0.__iter__() is None



# Generated at 2022-06-25 19:00:29.349126
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage('status_line', 'headers', b'__body')
    stream = BufferedPrettyStream(msg, conversion=Conversion(), formatting=Formatting())

    # Test case: default value
    assert next(stream.iter_body()) == b'__body'


# Generated at 2022-06-25 19:00:36.656651
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream_0 = PrettyStream()
    pretty_stream_0.mime = 'application/json'
    pretty_stream_0.output_encoding = 'utf-8'
    pretty_stream_0.process_body('[]')
    pretty_stream_0.process_body(b'[\n  "foo",\n  "bar"\n]')
    pretty_stream_0.process_body(b'{}')
    pretty_stream_0.process_body(b'{"foo":"bar"}')
    pretty_stream_0.process_body(b'foo')
    pretty_stream_0.process_body(b'foo: bar')


# Generated at 2022-06-25 19:00:44.455432
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Test case for testing method get_headers of class PrettyStream
    input_env = Environment()
    input_msg = HTTPMessage()

    formatted_headers = input_msg.headers.encode('utf8')

    # initiate PrettyStream object
    pretty_stream = PrettyStream(input_env, input_msg)

    # call method get_headers on the object
    output_headers = pretty_stream.get_headers()

    assert b'Content-Type: ' in output_headers
    assert b'Content-Length: ' in output_headers
    assert formatted_headers == output_headers


# Generated at 2022-06-25 19:00:54.759442
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test for a case that no conversion is applied
    # It is assumed that the body contains no null bytes
    msg = HTTPMessage(
        headers={'Content-Type': 'application/json', 'HTTP/1.1': '200 OK'},
        body='abcd\nefgh\nijkl\nmnop',
    )
    pretty_stream_0 = PrettyStream(
        msg = msg,
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
    )
    assert all(chunk == b'abcd\r\nefgh\r\nijkl\r\nmnop' for chunk in pretty_stream_0.iter_body())
    # Test for a case that a conversion is applied

# Generated at 2022-06-25 19:01:03.993467
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    html_headers = 'text/html'
    json_headers = 'application/json'
    html_msg = HTTPMessage(headers={'Content-Type': html_headers})
    json_msg = HTTPMessage(headers={'Content-Type': json_headers})
    html = encoding.encode_html(html_msg)
    json = encoding.encode_json(json_msg)
    html_headers = 'text-html'
    json_headers = 'application-json'
    html_msg = HTTPMessage(headers={'Content-Type': html_headers})
    json_msg = HTTPMessage(headers={'Content-Type': json_headers})
    html = encoding.encode_html(html_msg)
    json = encoding.encode_json(json_msg)

# Generated at 2022-06-25 19:01:10.994612
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    bps = BufferedPrettyStream()
    # testing lines separated by \r\n
    assert bps.iter_body() == b'\r\n'
    # testing lines separated by \n only
    assert bps.iter_body() == b'\n'
    # testing lines separated by \n\r
    assert bps.iter_body() == b'\n\r'
    # testing lines separated by \r
    assert bps.iter_body() == b'\r'
    # testing lines separated by \0
    assert bps.iter_body() == b'\0'


# Generated at 2022-06-25 19:01:22.075924
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    sps = BufferedPrettyStream()
    assert sps.on_body_chunk_downloaded is None
    sps = BufferedPrettyStream(msg="Hi", with_headers=True,
                                    with_body=True,
                                    on_body_chunk_downloaded=None)
    assert sps.on_body_chunk_downloaded is None
    sps = BufferedPrettyStream(msg="Hi", with_headers=True,
                                    with_body=True,
                                    on_body_chunk_downloaded=None,
                                    conversion="World")
    assert sps.on_body_chunk_downloaded is None

# Generated at 2022-06-25 19:01:24.538057
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_msg = HTTPMessage(b'', headers_str=b'GET / HTTP/1.1')
    raw_stream = RawStream(raw_msg)


# Generated at 2022-06-25 19:01:47.921183
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
  stream = EncodedStream(msg=HTTPMessage(),
                         with_headers=True,
                         with_body=True)
  assert isinstance(stream.msg, HTTPMessage)
  assert isinstance(stream.with_headers, bool)
  assert isinstance(stream.with_body, bool)


# Generated at 2022-06-25 19:01:50.553382
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pretty_stream = PrettyStream()
    pretty_stream.msg.headers = "Accept: application/json"
    assert pretty_stream.get_headers() == b"Accept: application/json"

# Generated at 2022-06-25 19:01:55.813449
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    import pytest
    headers = Headers('test_headers')
    pretty_stream = PrettyStream(HTTPMessage(headers=headers), conversion=Conversion(0), formatting=Formatting(0))
    assert pretty_stream.get_headers() == b'test_headers'

# Generated at 2022-06-25 19:01:57.154051
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    pretty_stream_0 = PrettyStream(Conversion(), Formatting())


# Generated at 2022-06-25 19:02:01.641354
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream

    body = "This is the body of the message"
    formatter = PrettyStream(
        HTTPResponse(body=body),
        conversion=Conversion(),
        formatting=Formatting()
    )
    output = formatter.process_body(body)
    assert output == body.encode()

# Generated at 2022-06-25 19:02:03.790206
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    encoded_stream_0 = EncodedStream()


# Generated at 2022-06-25 19:02:08.656122
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    response = HTTPMessage()
    response.headers = 'HTTP/1.1 200 OK \nServer: nginx \nContent: text/html'
    stream_0 = EncodedStream(msg=response)
    stream_0.get_headers()
    stream_0.iter_body()


# Generated at 2022-06-25 19:02:14.956457
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Test case : args=HTTPMessage
    stream_BufferedPrettyStream = BufferedPrettyStream(HTTPMessage())
    assert stream_BufferedPrettyStream.CHUNK_SIZE == 1024*10

    # Test case : args=HTTPMessage, with_headers
    stream_BufferedPrettyStream = BufferedPrettyStream(HTTPMessage(), False)
    assert stream_BufferedPrettyStream.with_headers == False

    # Test case : args=HTTPMessage, with_headers, with_body
    stream_BufferedPrettyStream = BufferedPrettyStream(HTTPMessage(), False, False)
    assert stream_BufferedPrettyStream.with_body == False


# Generated at 2022-06-25 19:02:23.724708
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    """
    Test case:
        Type: positive
        Description:
            Test positive case of method process_body of class PrettyStream
    """
    # Create a new instance of PrettyStream class,
    # with self.formatting and self.mime
    # as arguments
    prettyStream = PrettyStream(formatting="", mime="")
    # Call method process_body with arguments data and mime
    # Set data to a string value
    # Set mime to a string value
    result = prettyStream.process_body(data="", mime="")
    # Assert that the result of the method is not an empty string
    assert result != ""


# Generated at 2022-06-25 19:02:33.078706
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    start = time.clock()
    raw_stream_0 = EncodedStream(
        msg=HTTPMessage(
            headers=HTTPHeaders([
                'header-a: header-a-value',
                'header-b: header-b-value',
            ]),
            body='test-body',
            encoding='',
        ),
        on_body_chunk_downloaded=None,
        env=Environment(),
        with_headers=True,
        with_body=True,
    )
    end = time.clock()
    print("Time for creating object of class EncodedStream = ", end - start)



# Generated at 2022-06-25 19:02:55.128793
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    encoded_stream = EncodedStream()


# Generated at 2022-06-25 19:02:57.108662
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    EncodedStream(env=Environment(), msg=HTTPMessage(), with_headers=True, with_body=True)


# Generated at 2022-06-25 19:03:04.823286
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(encoding='utf8', headers=[], body="")

    s = BaseStream(msg=msg, with_headers=True, with_body=True)
    assert not s.get_headers()

    msg_1 = HTTPMessage(
        encoding='utf8',
        headers=[],
        body=("", "")
    )

    with pytest.raises(TypeError):
        s_1 = BaseStream(msg=msg_1, with_headers=True, with_body=True)



# Generated at 2022-06-25 19:03:06.948099
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Calling examples
    raw_stream_0 = RawStream()
    raw_stream_0.__iter__()



# Generated at 2022-06-25 19:03:17.706246
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Generate buffer with standard output
    payload = bytearray(b'a' * 250 + b'\0' + b'a' * 250)
    # Create message to pass to the iter_body method
    message = HTTPMessage(
        headers='',
        method='get',
        url='http://httpie.org',
        body=payload,
        content_type='text/html',
        encoding='utf8',
        chunks=[],
    )
    # Create object instance
    object_instance = BufferedPrettyStream(
        msg=message,
        with_headers=True,
        with_body=True,
    )

    # Execute the code to be tested
    with pytest.raises(BinarySuppressedError):
        next(object_instance.iter_body())


# Generated at 2022-06-25 19:03:27.474425
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    print("Testing iter_body of class PrettyStream...")

    pretty_stream = PrettyStream()

    # Test 1
    print("Test 1")

    # Test 1.1
    print("Test 1.1")
    new_line = b'\r\n'.decode('utf8')
    actual = pretty_stream.process_body('{"name":"John", "age":4}' + new_line)
    expected = b'{\n    "name": "John",\n    "age": 4\n}' + new_line.encode('utf8')
    assert actual == expected
    print("Success!")

    # Test 1.2
    print("Test 1.2")
    actual = pretty_stream.process_body("<html>\n<body>\n<h1>Test</body>\n</html>")

# Generated at 2022-06-25 19:03:31.991102
# Unit test for constructor of class RawStream
def test_RawStream():
    """Test constructor of class RawStream."""
    # TODO: Add tests for the constructor of class RawStream
    # TODO: Implement in RawStream.py constructor
    print ("Test for constructor in RawStream.py  Done.")
    
    

# Generated at 2022-06-25 19:03:34.753036
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    line1 = b"abcd\n"
    line2 = b"text of the line\n"
    data = line1 + line2
    msg = HTTPMessage(headers=data, body=data, content_type='text/plain')
    pretty_stream_0 = PrettyStream(msg=msg, with_headers=True, with_body=True)
    assert pretty_stream_0.iter_body() == [line1.decode('utf8') + line2.decode('utf8')]



# Generated at 2022-06-25 19:03:37.650455
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = type('', (), {
        'stdout_isatty': False,
        'stdout_encoding': 'utf8'
    })()
    encodedStream = EncodedStream(env=env)



# Generated at 2022-06-25 19:03:43.336359
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # first chunk is binary, no converter
    pretty_stream_0 = PrettyStream(conversion=Conversion(converters=[]),
                                   formatting=Formatting(output_options=None))
    assert pretty_stream_0.iter_body() == iter([BinarySuppressedError()])
    # second chunk is binary
    pretty_stream_1 = PrettyStream(conversion=Conversion(converters=[('text/html', 'html-to-text')]),
                                   formatting=Formatting(output_options=None))
    assert pretty_stream_1.iter_body() == iter([BinarySuppressedError()])


# Generated at 2022-06-25 19:04:36.767224
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """
    Unit test for method iter_body of class BufferedPrettyStream
    """
    body=b'<html>\n<head>hi</head>\n<body>sandeep</body>\n</html>'
    environment=Environment()
    environment.stdout_isatty=True
    environment.stdout_encoding='utf8'
    format=Formatting()
    format.body_formatter_cli = 'html'
    conversion=Conversion()
    msg = HTTPMessage(200, 'OK', headers={}, content=body)
    buffered_pretty_stream = BufferedPrettyStream(conversion,format,msg)
    print(buffered_pretty_stream.iter_body())

# Generated at 2022-06-25 19:04:40.868616
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream(msg = None)
    Iterable_type_0 = iter(raw_stream_0)
    for obj_0 in Iterable_type_0:
        print("obj_0: " + str(obj_0))


# Generated at 2022-06-25 19:04:41.850255
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream = RawStream()


# Generated at 2022-06-25 19:04:46.360877
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    raw_stream_0 = RawStream()
    BufferedPrettyStream_stream_0 = BufferedPrettyStream(raw_stream_0, raw_stream_0, raw_stream_0, raw_stream_0, raw_stream_0, raw_stream_0, raw_stream_0, raw_stream_0)
    BufferedPrettyStream_stream_0.iter_body()


# Generated at 2022-06-25 19:04:53.080761
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    test_BufferedPrettyStream_iter_body.counter = 0
    test_BufferedPrettyStream_iter_body.counter_goal = 4

    env = Environment()
    env.stdout_isatty = False
    conversion = Conversion()
    formatting = Formatting()

    @conversion.register('text/html', 'text/plain')
    def convert_html_to_plain(chunk):
        return 'text/plain', ''.join(c for c in chunk if not c.isspace())

    @formatting.register('text/plain', lambda output_encoding: 'text/plain')
    def format_plain_reversed(chunk, output_encoding):
        return chunk[::-1]


# Generated at 2022-06-25 19:04:53.904757
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream = EncodedStream()



# Generated at 2022-06-25 19:05:00.985427
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    non_text_content = b'\x001\x002\x003'
    http_message = HTTPMessage(b'HTTP/1.1 200 OK\r\n'
                               b'Content-Type: text/html\r\n\r\n'
                               + non_text_content)
    pretty_stream_0 = PrettyStream(http_message, conversion={}, formatting={})
    for chunk in pretty_stream_0.iter_body():
        pass


# Generated at 2022-06-25 19:05:04.075399
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage()
    PrettyStream(conversion, formatting, msg,msg.headers ,with_body = True)


# Generated at 2022-06-25 19:05:12.708151
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    headers = '''content-type: application/json
content-length: 27

'''
    body = '''{"a": "b", "c": "d"}'''

    msg = HTTPMessage(headers + body)
    env = Environment(
        stdout_isatty=False
    )

    stream = BufferedPrettyStream(
        msg=msg, with_headers=True, with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
        env=env
    )
    assert msg.headers == next(stream).decode()
    assert headers == next(stream).decode()
    assert b"\r\n" == next(stream)
    assert body == next(stream).decode()


# Generated at 2022-06-25 19:05:19.181413
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import httpie.output.streams

    class HTTPMessageMock:
        def iter_lines(self, s=1):
            return iter([(b'hello world', b'\n')])

    # Construct a PrettyStream object
    pretty_stream_0 = httpie.output.streams.PrettyStream(
        conversion=None, formatting=None, chunk_size=1, with_headers=True,
        with_body=True, msg=HTTPMessageMock(), on_body_chunk_downloaded=None
    )

    # Call method iter_body
    pretty_stream_0_iter_body = pretty_stream_0.iter_body()

    # Test whether method iter_body of class PrettyStream returns a generator
    assert type(pretty_stream_0_iter_body) is iter

    # Test whether method iter

# Generated at 2022-06-25 19:06:51.392786
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():

    #
    # First test case:
    # with_headers = True, with_body = True
    #   expected output: get_headers() + iter_body()
    #
    msg = HTTPMessage()
    headers = b'HEADERS'
    ch1 = b'BODY_CHUNK_1'
    ch2 = b'BODY_CHUNK_2'

    def mock_get_headers():
        return headers

    def mock_iter_body():
        return [ch1, ch2]

    BaseStream.get_headers = mock_get_headers
    BaseStream.iter_body = mock_iter_body

    with_headers = True
    with_body = True
    base_stream_0 = BaseStream(msg, with_headers, with_body)

# Generated at 2022-06-25 19:06:52.794773
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    pretty_stream_0 = PrettyStream(conversion=None, formatting=None, msg=None)


# Generated at 2022-06-25 19:07:03.498215
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream_0 = PrettyStream(Conversion(), Formatting())
    assert stream_0.process_body(b'\x96\xb6\x1f\x08\xaa\x93\x8e\xfd\x0e') == b'\x96\xb6\x1f\x08\xaa\x93\x8e\xfd\x0e'
    assert stream_0.process_body('') == b''
    assert stream_0.process_body('\u00e9') == b'\xc3\xa9'
    assert stream_0.process_body(b'\x1b\x9b') == b'\x1b\x9b'

# Generated at 2022-06-25 19:07:12.540086
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test process_body with headers, no body
    body = b''
    mime = 'application/json'
    output_encoding = 'utf8'
    formatting = Formatting()
    conversion = Conversion()
    ps = PrettyStream(conversion, formatting)
    ps.output_encoding = output_encoding
    ps.mime = mime
    assert ps.process_body(body) == b''
    
    # Test process_body with body, no headers
    # Here the conversion only gives an encoding
    body = '{"encoding":"base64","data":"dGVzdDEyMw=="}'
    mime = 'application/json'
    output_encoding = 'utf8'
    ps = PrettyStream(conversion, formatting)
    ps.output_encoding = output_encoding
    ps.m

# Generated at 2022-06-25 19:07:16.211615
# Unit test for constructor of class PrettyStream

# Generated at 2022-06-25 19:07:16.857072
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    stream = PrettyStream(conversion=Conversion(), formatting=Formatting())



# Generated at 2022-06-25 19:07:22.466888
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    raw_stream_0 = RawStream()
    pretty_stream_0 = PrettyStream(conversion=Conversion(),
                                   formatting=Formatting())

    # Test assertion error
    try:
        pretty_stream_0.get_headers()
    except AssertionError:
        print("Assertion error 0x01")
    except TypeError:
        print("Type error 0x01")
    pretty_stream_0.msg = raw_stream_0.msg
    pretty_stream_0.with_headers = True
    try:
        pretty_stream_0.get_headers()
    except AssertionError:
        print("Assertion error 0x02")



# Generated at 2022-06-25 19:07:25.822665
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    buf_pretty_stream = BufferedPrettyStream()
    buf_pretty_stream.iter_body()

# Generated at 2022-06-25 19:07:27.580316
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 19:07:34.811874
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream = RawStream(
        msg=HTTPMessage(
            headers="""HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8""",
            body='hello',
            encoding='utf8'
        ),
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
    )
    assert raw_stream.iter_body() == [b'hello']
