

# Generated at 2022-06-25 19:00:11.509956
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    ps = PrettyStream(None, None, with_headers=False)
    body = "first line \n"
    assert ps.process_body(body) == b'first line \n'

# Generated at 2022-06-25 19:00:13.658683
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    strm = PrettyStream()
    it = strm.iter_body()
    assert next(it) == b'\n'

# Generated at 2022-06-25 19:00:19.762045
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    raw_stream_1 = RawStream()
    pretty_stream_1 = PrettyStream()

    assert isinstance(raw_stream_1.iter_body(), Iterable)
    assert isinstance(pretty_stream_1.iter_body(), Iterable)

# Generated at 2022-06-25 19:00:32.075700
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    """
    Group of unit tests to test function.
    """
    pretty_stream_1 = PrettyStream(None, None)
    pretty_stream_2 = PrettyStream(None, None, msg=None)
    pretty_stream_3 = PrettyStream(None, None, msg=None,
    with_headers=True)
    pretty_stream_4 = PrettyStream(None, None, msg=None,
    with_headers=True, with_body=True)
    pretty_stream_5 = PrettyStream(None, None, msg=None,
    with_headers=True, with_body=True,
    on_body_chunk_downloaded=None)

# Generated at 2022-06-25 19:00:42.122886
# Unit test for constructor of class RawStream
def test_RawStream():
    raw_stream_1 = RawStream(
        msg=HTTPMessage(
            'GET /get HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"foo": "bar"}\r\n\r\n',
            'utf-8'
        ),
        with_headers=True,
        with_body=True
    )
    assert raw_stream_1.msg.headers == 'GET /get HTTP/1.1\r\nContent-Type: application/json\r\n\r\n'
    assert raw_stream_1.msg.body == '{"foo": "bar"}\r\n\r\n'
    assert raw_stream_1.with_headers == True
    assert raw_stream_1.with_body == True

# Generated at 2022-06-25 19:00:52.305088
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    def test_with_headers(self):
        assert self.with_headers == True
    def test_with_body(self):
        assert self.with_body == True
    def test_env(self):
        assert self.env == Environment()
    def test_conversion(self):
        assert self.conversion == Conversion()
    def test_formatting(self):
        assert self.formatting == Formatting()
    def test_msg(self):
        assert self.msg == HTTPMessage()
    def test_on_body_chunk_downloaded(self):
        assert self.on_body_chunk_downloaded == None
    def test_get_headers(self):
        assert self.get_headers() == self.msg.headers.encode('utf8')

# Generated at 2022-06-25 19:01:02.063411
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test with_headers=True, with_body=False
    stream = BaseStream(msg=None, with_headers=True, with_body=False)
    assert next(stream) is None

    # Test with_headers=False, with_body=True
    stream = BaseStream(msg=None, with_headers=False, with_body=True)
    assert next(stream) is None

    # Test with_headers=False, with_body=False
    stream = BaseStream(msg=None, with_headers=False)
    assert next(stream) is None

    # Test with_headers=True, with_body=True
    stream = BaseStream(msg=None, with_headers=True, with_body=True)
    assert next(stream) is None


# Generated at 2022-06-25 19:01:07.936933
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # test case 1, create an instance with argument
    # __init__(self, msg: HTTPMessage, with_headers=True, with_body=True, on_body_chunk_downloaded: Callable[[bytes], None] = None)
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    BufferedPrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded)

# Generated at 2022-06-25 19:01:09.640912
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    test_raw_stream = RawStream()
    for i in test_raw_stream.iter_body():
        i


# Generated at 2022-06-25 19:01:21.044444
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage()
    msg.headers.add('Content-Type', 'application/xml')
    msg.headers.add('Content-Length','23')
    msg.headers.add('Content-Encoding','utf-8')
    msg.headers.add('Last-Modified','Tue, 10 Apr 2018 21:49:44 GMT')
    msg.headers.add('Server','Jetty(9.4.11.v20180605)')
    env = Environment()

    conversion = Conversion()
    formatting = Formatting(max_json_depth=0, max_linewidth=0, print_body=True,
                            output_options={})

    pretty_stream_0 = PrettyStream(msg=msg, env=env, conversion=conversion,
                                   formatting=formatting)

    header = pretty_stream_0.get_

# Generated at 2022-06-25 19:01:31.157975
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    assert PrettyStream() is not None

# Generated at 2022-06-25 19:01:32.928594
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream()
    raw_stream_0.iter_body()


# Generated at 2022-06-25 19:01:38.112953
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    test_msg = HTTPMessage()
    test_msg.headers = "test header"
    test_stream = EncodedStream(msg=test_msg, with_headers=True, with_body=True)

    assert test_stream.msg == test_msg
    assert test_stream.with_headers == True
    assert test_stream.with_body == True


# Generated at 2022-06-25 19:01:43.920833
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for pretty JSON output
    msg = HTTPMessage('application/json', b'{ "key" : ["val", "val2"] }', "utf8")
    msg.headers = "HTTP/1.1 200 OK"
    stream = PrettyStream(msg = msg, formatting = Formatting(4, False), conversion = Conversion())
    for chunk in stream:
        lines = chunk.splitlines()
        assert len(lines) is 4
        assert lines[0] == 'HTTP/1.1 200 OK' and lines[1] == ' ' and lines[2] == '{'
        assert lines[3] == '    "key": [\n        "val",\n        "val2"\n    ]'


# Generated at 2022-06-25 19:01:53.209193
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    pStream = PrettyStream()
    pStream.conversion.converters["text/plain"] = BeautifulSoupConverter()
    pStream.conversion.converters["application/html"] = BeautifulSoupConverter()
    pStream.conversion.converters["application/xhtml"] = BeautifulSoupConverter()
    pStream.conversion.converters["application/xhtml+xml"] = BeautifulSoupConverter()
    pStream.conversion.converters["text/html"] = BeautifulSoupConverter()

    # Case 1: when the message is not binary
    message1 = HTTPMessage(
        request_or_response=True,
        headers=['Content-Type: 1', '2: 3'],
        body=b'<a>b</a>'
    )
   

# Generated at 2022-06-25 19:01:56.357596
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Test that the initialization of BufferedPrettyStream is correct.
    stream = BufferedPrettyStream()
    assert stream.CHUNK_SIZE == 1024 * 10


# Generated at 2022-06-25 19:02:05.993070
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    stream = BufferedPrettyStream(with_headers=True, with_body=True)
    assert [type(x) for x in stream.iter_body()] == [bytes]
    stream.mime = 'text/plain'
    assert [type(x) for x in stream.iter_body()] == [bytes]
    stream.mime = 'application/json'
    assert [type(x) for x in stream.iter_body()] == [bytes]
    stream.mime = 'application/xml'
    assert [type(x) for x in stream.iter_body()] == [bytes]
    stream.mime = 'image/png'
    assert [type(x) for x in stream.iter_body()] == [bytes]
    stream.mime = 'audio/mpeg'

# Generated at 2022-06-25 19:02:07.903107
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pretty_stream = PrettyStream()
    out_headers = pretty_stream.get_headers()
    assert out_headers is None


# Generated at 2022-06-25 19:02:15.392403
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import unittest.mock


    class Mock:
        def __init__(self):
            self.mock_body = [
                b'\r\n\r\n',
                b'Note: binary data not shown in terminal\n'
            ]

        def list_body(self):
            return self.mock_body

    pretty_stream_0 = BufferedPrettyStream(conversion=None, formatting=None, msg=None, with_headers=True, with_body=True, on_body_chunk_downloaded=None)


    class Stub:
        def __init__(self, mime, body):
            self.mime = mime
            self.body = body

        def convert(self, arg0):
            return (self.mime, self.body)


# Generated at 2022-06-25 19:02:16.848179
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    return


# Generated at 2022-06-25 19:02:43.253131
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    PS = PrettyStream()
    #test1
    chunk = "Test1"
    result_test1 = PS.process_body(chunk)
    assert result_test1 == b'Test1'

    #test2
    chunk = "Test1"
    result_test2 = PS.process_body(chunk.encode(PS.msg.encoding, 'replace'))
    assert result_test2 == b'Test1'

    #test3
    chunk = "Test1"
    result_test3 = PS.process_body(chunk.encode(PS.msg.encoding, 'ignore'))
    assert result_test3 == b'Test1'


# Generated at 2022-06-25 19:02:46.142806
# Unit test for constructor of class RawStream
def test_RawStream():
    assert RawStream().__class__ == RawStream
    assert RawStream().__class__ != EncodedStream
    assert RawStream().__class__ != PrettyStream
    assert RawStream().__class__ != BufferedPrettyStream


# Generated at 2022-06-25 19:02:47.620990
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    pass


if __name__ == '__main__':
    test_BufferedPrettyStream_iter_body()

# Generated at 2022-06-25 19:02:53.589968
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream(with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    raw_stream_0.CHUNK_SIZE = 1
    raw_stream_0.msg.iter_body(size=None)
    # raw_stream_0.iter_body()
    raw_stream_0.msg.iter_body(10)


# Generated at 2022-06-25 19:02:57.655191
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPMessage
    encoded_stream = EncodedStream(msg=HTTPMessage(body=b'a\x00b'))
    try:
        for chunk in encoded_stream.iter_body():
            pass
    except BinarySuppressedError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 19:03:00.574739
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    """

    :return:
    """
    raw_stream_0 = RawStream()
    iterator = raw_stream_0.__iter__()


# Generated at 2022-06-25 19:03:12.257182
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    """
    Test if the method iter_body() works well
    """

# Generated at 2022-06-25 19:03:14.097886
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    pretty_stream_0 = PrettyStream()
    assert pretty_stream_0.get_headers() == ''

# Generated at 2022-06-25 19:03:14.950815
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream = EncodedStream()


# Generated at 2022-06-25 19:03:17.706668
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream = PrettyStream()
    pretty_stream.formatting = Formatting('', '', '', False, False, False, True)
    pretty_stream.process_body('{"status": 200}')


# Generated at 2022-06-25 19:03:52.395635
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    try:
        BaseStream.__iter__()
        assert(True)
    except NotImplementedError:
        assert(False)


# Generated at 2022-06-25 19:03:58.934330
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    sample_msg = HTTPMessage(headers='test_HEADERS')
    raw_stream_0 = PrettyStream(conversion='test_CONVERSION',
                                formatting='test_FORMATTING',
                                msg=sample_msg
                                )



# Generated at 2022-06-25 19:04:06.839631
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        None, None, None, None, [], [],
        'utf8', None, None, None, None,
        None, None, None, None, None,
        None, None, None, None, None)
    msg.iter_lines = (lambda x: x)

    # case-1:
    # param-1: [b'\0' in line]
    raw_stream_1 = EncodedStream(msg, None)
    assert raw_stream_1.iter_body() == BinarySuppressedError

    # case-2:
    # param-1: ['\0' not in line]
    msg.iter_lines = (lambda x: lambda: 1)
    raw_stream_2 = EncodedStream(msg)
    assert raw_stream_2.iter_body() != BinarySupp

# Generated at 2022-06-25 19:04:13.703818
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # this is a test for the behavior of bytes()
    assert bytes([1, 2, 3]) == b'\x01\x02\x03'  # False
    assert bytes([1, 2, 3]) != b'\x01\x02\x03'  # True
    # why?
    # bytes([1, 2, 3]) is equivalent to b'\x01\x02\x03'

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 19:04:24.988166
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    raw_stream_0 = BufferedPrettyStream()
    # RawStream msgs is class HTTPMessage
    raw_stream_0.msg = HTTPMessage()
    raw_stream_0.msg.encoding = 'utf8'
    raw_stream_0.msg.content_type = 'text/html'
    # test lines is a class HTTPMessage body
    test_lines = ''.join([chr(i) for i in range(128)])
    test_lines += '\0'
    raw_stream_0.msg.body = test_lines.encode('utf8')
    raw_stream_0.mime = 'text/html'
    raw_stream_0.formatting = Formatting(stdout_isatty=False)

# Generated at 2022-06-25 19:04:26.623230
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream()
    assert next(stream) == 'test'


# Generated at 2022-06-25 19:04:35.267222
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    """prints the expected output for the body, content and mime for a given input
    between specific boundaries"""
    #given
    conversion = Conversion()
    formatting = Formatting()
    pretty_stream = PrettyStream(conversion, formatting, '', True, True)
    pretty_stream.mime = 'application/json'
    #when
    chunk = pretty_stream.process_body("{\"key\":\"value\"}")
    #then
    assert chunk == b'{\n    "key": "value"\n}'



# Generated at 2022-06-25 19:04:40.874477
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Initialization
    env = Environment()
    msg = HTTPMessage('gzip')
    conversion = Conversion()
    formatting = Formatting()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    bufferedPrettyStream = BufferedPrettyStream(env, msg, conversion, formatting, with_headers, with_body, on_body_chunk_downloaded)

    # Initialization
    class_name = 'BufferedPrettyStream'
    method_name = 'iter_body'
    bufferedPrettyStream.iter_body()


# Generated at 2022-06-25 19:04:42.233693
# Unit test for constructor of class RawStream
def test_RawStream():
    raw_stream_0 = RawStream()



# Generated at 2022-06-25 19:04:50.570383
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json


# Generated at 2022-06-25 19:06:00.013737
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
  # Input parameters
  msg = HTTPMessage()

  # Expected output
  iter_body_expected = {}

  # Unit test
  raw_stream_0 = RawStream(msg=msg)
  iter_body_actual = raw_stream_0.iter_body()

  # Assert
  assert iter_body_actual == iter_body_expected



# Generated at 2022-06-25 19:06:01.269230
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    stream = RawStream()
    

# Generated at 2022-06-25 19:06:04.439164
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    myBufferedPrettyStream = BufferedPrettyStream()

# Generated at 2022-06-25 19:06:07.326699
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    print("Testing method __iter__ of class BaseStream:")
    # Test case 0:
    test_case_0()

if __name__ == '__main__':
    test_BaseStream___iter__()

# Generated at 2022-06-25 19:06:15.938263
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-25 19:06:26.125878
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import httpie.models
    import httpie.output.streams
    import io

    msg1 = httpie.models.HTTPMessage(
        request_info=None,
        request_headers=None,
        request_body=io.BytesIO(
            b'hello world\nI am header-less request\nwith long-lived body'),
        request_content_type=None,
        request_encoding=None,
        response_info=None,
        response_headers=None,
        response_body=io.BytesIO(
            b'hello world\nI am header-less response\nwith long-lived body'),
        response_content_type=None,
        response_encoding=None,
    )
    stream1 = httpie.output.streams.EncodedStream(msg=msg1)
    err

# Generated at 2022-06-25 19:06:28.244492
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    pretty = PrettyStream(msg=None, with_headers=True, with_body=True, conversion='', formatting='')
    assert pretty.iter_body() is None


# Generated at 2022-06-25 19:06:36.346262
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    raw_stream_1 = EncodedStream()
    raw_stream_2 = EncodedStream(msg=None)
    raw_stream_3 = EncodedStream(msg=None, env=None)
    EncodeStream_obj = EncodedStream(msg=None, env=env)
#     raw_stream_4 = EncodedStream(msg=None, env=None, with_headers=True)
    if raw_stream_1.msg == None and raw_stream_1.env == None:
        pass
    else:
        raise Exception('unmatched')

if __name__ == '__main__':
    test_case_0()
    test_EncodedStream()

# Generated at 2022-06-25 19:06:38.713486
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Normal case
    try:
        EncodedStream()
    except Exception as e:
        # Unexpected error
        print("Unexpected error: %s" % e)
        assert False


# Generated at 2022-06-25 19:06:42.600866
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = {
        'content-type': 'application/json',
        'content-length': '20',
    }
    msg = HTTPMessage(headers, b'{"msg":"success"}')
    pretty_stream_get_headers = PrettyStream(msg, None, Formatting())
    result = pretty_stream_get_headers.get_headers()
    assert result == b'content-type: application/json\n' \
                     b'content-length: 20\n'

# Generated at 2022-06-25 19:09:26.732060
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = Message()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None

    base_stream = BaseStream(
        msg,
        with_headers,
        with_body,
        on_body_chunk_downloaded)

    # Test the return value of __iter__
    assert True



# Generated at 2022-06-25 19:09:33.152227
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-25 19:09:43.814816
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    import struct
    import zlib
    # raw_data = "{\n    'a': 1,\n    'b': 2,\n}\n"
    a = "{'a': 1, 'b': 2}"
    b = str.encode(a)
    c = json.dumps({"a": 1, "b": 2})
    d = str.encode(c)
    e = "{'a': 1,\n'b': 2\n}"
    f = str.encode(e)
    g = str.encode(struct.pack('>I', d.__len__()) + d)
    h = g + zlib.compress(f)

    # Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-25 19:09:53.009854
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Used to test iter_body method in BufferedPrettyStream class
    import httpie.models
    import io