

# Generated at 2022-06-25 19:00:09.771348
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Method iter_body of PrettuStream should take 1 argument: self
    # Test case 1
    # When the chunk is None or the length of chunk is 0, the method iter_body should return an empty iterable.
    try:
        assert iter(PrettyStream().iter_body()) == iter(set())
    except:
        print("test case 1 for PrettyStream.iter_body() failed!")
    else:
        print("test case 1 for PrettyStream.iter_body() passed!")
    # Test case 2
    # if the chunk is not bytes, the method iter_body should raise TypeError
    try:
        assert iter(PrettyStream('chunk').iter_body()) == iter(set())
    except TypeError:
        print("test case 2 for PrettyStream.iter_body() passed!")

# Generated at 2022-06-25 19:00:20.050983
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Server: nginx/1.14.0 (Ubuntu)\r\n' \
              'Date: Thu, 27 Jun 2019 17:15:11 GMT\r\n' \
              'Content-Type: application/json; charset=utf-8\r\n' \
              'Transfer-Encoding: chunked\r\n' \
              'Connection: keep-alive\r\n' \
              'Access-Control-Allow-Origin: *\r\n' \
              'Access-Control-Allow-Methods: POST, GET, OPTIONS\r\n' \
              'Access-Control-Allow-Headers: content-type\r\n' \
              'Access-Control-Max-Age: 86400\r\n' \
             

# Generated at 2022-06-25 19:00:31.651272
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    """
    Description:
    - check if iter_body is able to iterate over the body of the message
      and convert it to the encoding of stdout
    """
    #preparation for test
    msg = HTTPMessage('Content-Type: text/plain; charset=utf8\r\n'
                      '\r\n'
                      '\xe2\x98\xba ')
    encoded_stream = EncodedStream(msg)

    #test
    output = b''
    expected = b'\xe2\x98\xba \n'.decode('utf8').encode('utf8')
    for chunk in encoded_stream.iter_body():
        output += chunk

    assert output == expected


# Generated at 2022-06-25 19:00:33.117756
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():

    pretty_stream_0 = BufferedPrettyStream()
    pretty_stream_1 = BufferedPrettyStream()




# Generated at 2022-06-25 19:00:37.675172
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    stream = PrettyStream(
        msg=HTTPMessage(),
        conversion=Conversion(),
        formatting=Formatting(max_json_depth=2, max_array_length=2)
    )
    result = stream.get_headers()
    assert len(result) == 0


# Generated at 2022-06-25 19:00:39.705902
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    stream = PrettyStream(None, None)
    result = stream.get_headers()


# Generated at 2022-06-25 19:00:49.622586
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    content = 'Testing PrettyStream!'
    headers = {'Hello': 'World'}
    msg = HTTPMessage(200, content=content, headers=headers)
    conversion = Conversion()
    formatting = Formatting()

    pretty_stream_0 = PrettyStream(msg=msg, conversion=conversion,
                                   formatting=formatting, with_body=True)
    pretty_stream_1 = PrettyStream(msg=msg, conversion=conversion,
                                   formatting=formatting, with_body=False)
    pretty_stream_2 = PrettyStream(msg=msg, conversion=conversion,
                                   formatting=formatting, with_headers=False)

# Generated at 2022-06-25 19:00:51.944724
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    t = BaseStream(HTTPMessage("", "", 0), True, True)
    assert t.__iter__() == t


# Generated at 2022-06-25 19:01:02.180723
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg_1 = HTTPMessage()
    response = b"HTTP/1.1 200 OK\r\n" \
               b"Content-Type: text/html\r\n\r\n" \
               b"<h1>Hello World</h1>"

    bytes_stream = BytesIO(response)
    msg_1.parse_from_bytes_stream(bytes_stream)
    encoded_stream = EncodedStream(msg_1)
    headers = encoded_stream.get_headers()
    assert headers == response[:response.index(b"\r\n\r\n")]
    body = encoded_stream.iter_body()
    result = []
    for chunk in body:
        result.append(chunk)

# Generated at 2022-06-25 19:01:06.301300
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream(None, None, None, None, None)
    stream.msg = Mock(HTTPMessage)
    stream.msg.iter_lines.return_value = [("12345\r\n","\r\n")]
    assert b'12345\r\n' in list(stream.iter_body())


# Generated at 2022-06-25 19:01:16.333672
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert True == True


# Generated at 2022-06-25 19:01:23.945293
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-25 19:01:26.181971
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream(None, None)
    assert stream.msg.body is None
    assert list(stream.iter_body()) == []
    stream.msg.body = "A body"
    result_list = list(stream.iter_body())
    result_body = result_list[0]
    assert result_body == "A body"



# Generated at 2022-06-25 19:01:37.204150
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = "utf8"
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\nDate: Tue, 14 May 2019 08:25:42 GMT\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: 13\r\nLast-Modified: Mon, 13 May 2019 15:52:12 GMT\r\nServer: Apache/2.4.18 (Ubuntu)\r\nVary: Accept-Encoding\r\nX-Powered-By: PHP/5.6.30\r\n\r\n"
    msg.body = "Hello World!"
    
    msg.encoding = "utf8"
    with_

# Generated at 2022-06-25 19:01:43.972724
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.formatters.colors import get_lexer
    from pygments import highlight
    from pygments.formatters import TerminalFormatter

    response = HTTPResponse(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: text/html; charset=utf8\r\n\r\n'
        '<html><body>hello world</body></html>',
        encoding='utf8'
    )
    conversion = Conversion(True)
    lexer = get_lexer('html', response.headers,
                      Conversion.get_content_type(response.headers))
    formatter = TerminalFormatter()


# Generated at 2022-06-25 19:01:46.454306
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream()
    raw_stream_0.iter_body()


# Generated at 2022-06-25 19:01:51.555704
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Create a message with a non-standard encoding
    msg_0 = HTTPMessage(encoding='utf8', content_type='text/html')
    # Create a pretty stream for the message
    pretty_stream_0 = PrettyStream(msg_0)

    # Test raising exception for binary body
    with pytest.raises(BinarySuppressedError):
        for chunk in pretty_stream_0.iter_body():
            pass


# Generated at 2022-06-25 19:01:56.356311
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    raw_stream_0 = RawStream()
    test_value_passed = raw_stream_0.iter_body()
    test_value_expected = raw_stream_0.iter_body()
    assert test_value_passed == test_value_expected


# Generated at 2022-06-25 19:02:02.440967
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    env = Environment()
    encoded_stream_0 = EncodedStream(msg, True, True, env)
    assert encoded_stream_0.msg == msg
    assert encoded_stream_0.with_headers is True
    assert encoded_stream_0.with_body is True
    assert encoded_stream_0.output_encoding == 'utf8'

    assert type(encoded_stream_0.get_headers()) == bytes

    for chunk in encoded_stream_0.iter_body():
        assert type(chunk) == bytes


# Generated at 2022-06-25 19:02:03.584100
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    message = HTTPMessage()
    base_stream_0 = BaseStream(message, False, False)


# Generated at 2022-06-25 19:02:25.851461
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.formatters import JSONFormatter
    raw_stream_0 = RawStream(
        msg=HTTPMessage(
            headers='Header: Test',
            body=b'{"one": 1, "two": 2}',
            content_type='application/json')
    )
    pretty_stream_0 = PrettyStream(
        msg=HTTPMessage(
            headers='Header: Test',
            body=b'{"one": 1, "two": 2}',
            content_type='application/json'),
        conversion=Conversion(),
        formatting=Formatting(formatter=JSONFormatter()))
    assert pretty_stream_0.process_body(b'"one"') == b'  "one"'
    assert pretty_stream_0.process_body(b'1') == b'1'
    assert pretty

# Generated at 2022-06-25 19:02:32.599726
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class Msg:
        body = b'\xA5'
        encoding = 'utf8'
        def iter_lines(self, chunk_size):
            def generate_lines():
                yield (self.body, b'\n')
            return generate_lines()

    with pytest.raises(BinarySuppressedError) as exc_info:
        stream = EncodedStream(msg=Msg())
        for _ in stream.iter_body():
            pass

    print(exc_info.value.message)

# Generated at 2022-06-25 19:02:38.783952
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    print("Unit test for constructor of class BufferedPrettyStream")
    env = Environment(arguments=Arguments())
    stream = BufferedPrettyStream(env=env,
                                  msg=HTTPMessage(),
                                  conversion=None,
                                  formatting=None,
                                  with_headers=None,
                                  with_body=None,
                                  on_body_chunk_downloaded=None)


# Generated at 2022-06-25 19:02:45.366401
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Arrange
    msg = HTTPMessage(headers="abc\nabc\nabc\nabc")
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    pretty_stream_0 = PrettyStream(msg, True, True, None, env, conversion, formatting)
    # Act
    out = pretty_stream_0.get_headers()
    # Assert
    assert out == "abc\nabc\nabc\nabc"


# Generated at 2022-06-25 19:02:47.138900
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    encoded_stream_0 = EncodedStream()
    assert encoded_stream_0.output_encoding == 'utf8'


# Generated at 2022-06-25 19:02:57.305540
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    mime = u'application/json'
    msg = HTTPMessage()
    msg.content_type = mime
    msg.encoding = u'utf-8'
    msg.headers = u'\r\n'.join(['HTTP/1.0 200 OK', u'a: b', u'c: d'])

# Generated at 2022-06-25 19:03:01.430234
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # base_stream_0 case:
    #
    # with_headers = True
    # with_body = True
    raw_stream_0 = RawStream()
    data = raw_stream_0.__iter__()
    assert len(data) == 2


# Generated at 2022-06-25 19:03:12.947076
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    h = HTTPMessage("", "", b"", b"chunk1\r\nchunk2\r\nchunk3\r\n", "", "", "", "")
    ps = PrettyStream(h, True, True, None)
    for chunk in ps.iter_body():
        if chunk.decode("utf-8") == "chunk1":
            assert chunk.decode("utf-8") == "chunk1"
        elif chunk.decode("utf-8") == "chunk2":
            assert chunk.decode("utf-8") == "chunk2"
        elif chunk.decode("utf-8") == "chunk3":
            assert chunk.decode("utf-8") == "chunk3"
        else:
            assert False



# Generated at 2022-06-25 19:03:18.485966
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    raw_stream = PrettyStream(1, 1)
    # Call the method without assigning a value to chunk
    assert raw_stream.process_body(None) == None
    # Call the method without assigning a value to chunk
    chunk = raw_stream.process_body(1)
    # Check if the value of chunk is correct
    assert chunk == 1
    # Check if the value of chunk is correct
    chunk = raw_stream.process_body(1)
    assert chunk == 1


# Generated at 2022-06-25 19:03:20.703419
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    raw_stream = EncodedStream()
    for chunk in raw_stream.iter_body():
        print(chunk)
        break


# Generated at 2022-06-25 19:03:41.907681
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream_0 = EncodedStream()


# Generated at 2022-06-25 19:03:52.215090
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    mime = 'text/html'
    body = '<html></html>'
    chunk_size = 1024 * 10
    msg = HTTPMessage(content=body,
                      content_type=mime)
    def get_converter(mime):
        return mime
    conversion = Conversion('html',
                            'prettyjson',
                            get_converter)
    formatting = Formatting('all',
                            'all',
                            '',
                            '')
    pretty_stream = BufferedPrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting,
    )
    assert b'html' in pretty_stream.iter_body()

# Generated at 2022-06-25 19:04:00.998973
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    global raw_stream_0
    tp_mime_0 = "application/json"
    tp_headers_0 = "Content-Type: application/json"
    tp_body_0 = ""
    tp_msg_0 = HTTPMessage.from_raw_stream(tp_body_0, tp_headers_0, tp_mime_0)
    tp_msg_0.encoding = "utf8"
    tp_conversion_0 = Conversion()
    tp_formatting_0 = Formatting()
    tp_pretty_stream_0 = PrettyStream(tp_msg_0, True, True, None, tp_formatting_0, tp_conversion_0)
    # Line 15

# Generated at 2022-06-25 19:04:04.752883
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test for argument body

    # Test for argument chunk_size

    # Test for argument encoding

    # Test for argument env

    # Test for argument headers

    # Test for argument mime

    # Test for argument status_line

    # Test for argument with_body

    # Test for argument with_headers

    pass



# Generated at 2022-06-25 19:04:08.643947
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():

    stream = PrettyStream(conversion=None, formatting=None, msg=None)




# Generated at 2022-06-25 19:04:15.183689
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    env = Environment()
    msg, with_headers, with_body, on_body_chunk_downloaded = None, None, None, None
    conversion = Conversion()
    formatting = Formatting()
    obj = PrettyStream(msg=msg, with_headers=with_headers, with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded, env=env, conversion=conversion, formatting=formatting)
    result = obj.get_headers()
    assert type(result).__name__ == 'bytes'


# Generated at 2022-06-25 19:04:22.948229
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # test 1 constructor with arguments
    stream = BufferedPrettyStream(msg=HTTPMessage(), with_headers=True, with_body=True, on_body_chunk_downloaded=None, env=Environment(), conversion=Conversion(), formatting=Formatting())
    assert stream
    # test 2 constructor with arguments
    stream = BufferedPrettyStream(env=Environment(), conversion=Conversion(), formatting=Formatting())
    assert stream



# Generated at 2022-06-25 19:04:30.031772
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from io import BytesIO
    from unittest.mock import MagicMock, patch
    from httpie.models import HTTPMessage
    from httpie.output.streams import BufferedPrettyStream

    env = MagicMock()
    env.stdout = BytesIO()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    # body_bytes = b'1\n2\n3\n4\n5\n6\n7\n8\n9\n10'
    body_bytes = b'1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n'

# Generated at 2022-06-25 19:04:38.062190
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test no exception
    body = b'this is the body'
    headers = {'Content-Type': 'application/json'}
    msg = HTTPMessage(body=body, headers=headers, encoding='utf-8')
    bps = BufferedPrettyStream(msg=msg, with_body=True, with_headers=True)
    # bps.iter_body()
    # TODO: can't use assert because iter_body is a generator
    # assert bps.iter_body() == body.decode('utf-8')


# Generated at 2022-06-25 19:04:40.498741
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    assert type(raw_stream_0.__iter__()) == collections.abc.Iterable


# Generated at 2022-06-25 19:05:22.218116
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()

    iter = raw_stream_0.__iter__()
    assert iter is not None


# Generated at 2022-06-25 19:05:30.608569
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Setup variables and mock environment
    cwd = os.getcwd()
    env = Environment()
    body = 'Hi!'
    msg = HTTPMessage.from_bytes(body.encode(), content_type='text/plain')
    obj = BufferedPrettyStream(conversion=Conversion(), formatting=Formatting(env), msg=msg)
    # Run test
    result = obj.iter_body()
    # Verify results
    assert result == '\x1b[33m\u2757\ufe0f\x1b[39m \x1b[1m\x1b[33m' + body + '\x1b[39m\x1b[22m'


# Generated at 2022-06-25 19:05:32.482612
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream = PrettyStream(Conversion(), Formatting())
    pretty_stream.process_body(b'name=John')


# Generated at 2022-06-25 19:05:41.882982
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json

    path = '~/src/httpie/test/fixtures/post_response_1.json'
    file = open(path, 'r')
    response = json.load(file)
    file.close()


# Generated at 2022-06-25 19:05:42.685978
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    pretty_stream = EncodedStream()


# Generated at 2022-06-25 19:05:44.597321
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    raw_stream_0 = RawStream()
    pretty_stream_0 = PrettyStream()
    pretty_stream_0.get_headers()


# Generated at 2022-06-25 19:05:53.315040
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    bs1 = BufferedPrettyStream()
    assert bs1.CHUNK_SIZE == 1024*10
    assert bs1.formatting
    assert bs1.conversion

    bs2 = BufferedPrettyStream(Conversion(), Formatting())
    assert bs2.CHUNK_SIZE == 1024*10
    assert bs2.formatting
    assert bs2.conversion
    assert bs2.get_headers()

    bs3 = BufferedPrettyStream(Conversion(), Formatting(), msg=None)
    assert bs3.CHUNK_SIZE == 1024*10
    assert bs3.formatting
    assert bs3.conversion
    assert bs3.get_headers()


# Generated at 2022-06-25 19:05:54.305605
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    obj = EncodedStream()


# Generated at 2022-06-25 19:05:57.431281
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-25 19:06:08.590014
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    test_str = b'This is a test string'
    test_str_1 = b'[{"id": 1, "name": "Leanne Graham", "username": "Bret", "email": "Sincere@april.biz", "address": {"street": "Kulas Light", "suite": "Apt. 556", "city": "Gwenborough", "zipcode": "92998-3874", "geo": {"lat": "-37.3159", "lng": "81.1496"}}, "phone": "1-770-736-8031 x56442", "website": "hildegard.org", "company": {"name": "Romaguera-Crona", "catchPhrase": "Multi-layered client-server neural-net", "bs": "harness real-time e-markets"}}]'


# Generated at 2022-06-25 19:07:34.738183
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # test constructor with no arguments
    stream_0 = BufferedPrettyStream()
    if not isinstance(stream_0.msg, HTTPMessage):
        raise AssertionError('expected isinstance({}, {}) but got {}'.format(stream_0.msg, 'HTTPMessage', type(stream_0.msg)))
    if stream_0.with_headers is not True:
        raise AssertionError('expected {} but got {}'.format(True, stream_0.with_headers))
    if stream_0.with_body is not None:
        raise AssertionError('expected {} but got {}'.format(None, stream_0.with_body))

# Generated at 2022-06-25 19:07:39.555729
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream = RawStream(chunk_size = 1)
    encoded_stream = EncodedStream()
    pretty_stream = PrettyStream(chunk_size = 1024)
    buffered_pretty_stream = BufferedPrettyStream(chunk_size = 1024)



# Generated at 2022-06-25 19:07:49.391155
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test_bytes = b'\x80\x81\x82\x0a\x0d'
    test_msg = HTTPMessage()
    test_msg.encoding = 'utf8'
    test_stream = EncodedStream(
        msg=test_msg,
        with_headers=False,
        with_body=True,
        on_body_chunk_downloaded=None)

    output_bytes = b''
    for chunk in test_stream.iter_body():
        output_bytes += chunk

    assert len(output_bytes) == 5
    assert output_bytes == b'\xe2\x82\xac\xe2\x82\xac\xe2\x82\xac\n\r'
    test_msg.encoding = 'iso-8859-1'
    test_stream

# Generated at 2022-06-25 19:07:55.357268
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    def match(message, mime):
        """
        :param message:
        :param mime:
        :return:
        """
        stream = BufferedPrettyStream(
            msg=message,
            conversion=Conversion(),
            formatting=Formatting(flow_style=False),
            mime=mime)
        return stream
    assert match(b'a', b'b') == b'a', True
    assert match(b'a\n', b'b') == b'a\n', True
    assert match(b'a', b'b') == b'a', False
    assert match(b'a\n', b'b') == b'a', False
    assert match(b'a', b'b') == b'a', True

# Generated at 2022-06-25 19:08:04.234190
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    chunksize = EncodedStream.CHUNK_SIZE
    chunky = "ab "*chunksize + "\n"
    fulllined = "abc\n"
    message = HTTPMessage(
        headers = "",
        content_type = "text/plain",
        body = chunky + fulllined,
        encoding = "utf8")
    stream_0 = PrettyStream(
        msg = message,
        conversion = None,
        formatting = None)
    iterator = stream_0.iter_body()
    assert next(iterator) == "ab ab ab ab ab ab ab ab ab ab ab ab \n"
    assert next(iterator) == "abc\n"
    iterator.close()


# Generated at 2022-06-25 19:08:05.957163
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    raw_stream_0 = RawStream()
    assert raw_stream_0.__iter__() == None

# Generated at 2022-06-25 19:08:14.393616
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    test_msg = HTTPMessage()
    test_msg.headers = 'Content-Type:text/html'
    test_msg.body = '<html>\n<body>body</body></html>'
    test_formatting = Formatting(None)
    test_conversion = Conversion()
    test_stream = BufferedPrettyStream(test_msg, True, True, None, test_conversion, test_formatting)
    assert test_stream.iter_body() == '<html>\n<body>body</body></html>'

#Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-25 19:08:15.705169
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    print("\nSTART test_RawStream_iter_body")
    print("\nEND test_RawStream_iter_body")



# Generated at 2022-06-25 19:08:21.162046
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # CHECK: test with variables of wrong type (everything except list and tuple)
    some_stream = EncodedStream(msg = HTTPMessage(''), with_headers=True, with_body=True)

    # CHECK: test with empty list
    name_list = []
    output = some_stream.iter_body()
    assert output == name_list, "Failed"

    # CHECK: test with empty tuple
    name_list = ()
    output = some_stream.iter_body()
    assert output == name_list, "Failed"

    # CHECK: test with real data
    name_list = ['one', 'two', 'three']
    output = some_stream.iter_body()
    assert output == name_list, "Failed"


# Generated at 2022-06-25 19:08:29.863819
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.models import Response
    from httpie.output.formatting import JsonBodyFormat
    from httpie.output.formatters import JSONFormatter