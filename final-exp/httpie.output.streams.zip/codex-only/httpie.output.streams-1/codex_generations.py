

# Generated at 2022-06-23 19:40:30.469586
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """Test if the conversion of body is successful for input of
    message. """
    m = HTTPMessage(headers=[\
        ('Content-Type','application/xml'+'; charset=utf-8'),\
        ('Content-Length','10'), ('Connection','keep-alive'),\
        ('Keep-Alive','timeout=30')],\
        body=b'1\n2\n3\n4\n5\n6\n7\n8\n9\n10')
    env = Environment()
    encoding = env.stdout_encoding
    class Conversion:
        def get_converter(self, type):
            def converter(text):
                return "application/json", json.dumps(text.decode('utf8'))
            return converter


# Generated at 2022-06-23 19:40:39.118218
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    import tempfile
    import os
    import httpie.output.streams
    import unittest
    import httpie.context
    import httpie.output.formats
    import httpie.utils

    class TestBody(httpie.output.streams.BufferedPrettyStream):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.iter_body_called = False

        def iter_body(self):
            self.iter_body_called = True
            yield from super().iter_body()


# Generated at 2022-06-23 19:40:50.471267
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import io
    import unittest.mock

    mock_msg_headers = unittest.mock.Mock()
    mock_msg_headers.encode.return_value = b'header'
    mock_msg_headers.__contains__.return_value = False
    mock_msg_headers.__getitem__.return_value = b'some'

    mock_msg = unittest.mock.Mock()
    mock_msg.headers = mock_msg_headers
    mock_msg.content_type = 'text/plain'
    mock_msg.encoding = 'utf-8'

    mock_formatting = unittest.mock.Mock()
    mock_formatting.format_headers.return_value = 'header'
    mock_formatting.format_body.return_value = 'body'

# Generated at 2022-06-23 19:40:59.334343
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    message = b'GET / HTTP/1.1\r\n' \
              b'Accept: text/plain; q=0.5, text/html,\r\n' \
              b'        text/x-dvi; q=0.8, text/x-c\r\n' \
              b'\r\n'

    headers = b'GET / HTTP/1.1\r\n' \
              b'Accept: text/plain; q=0.5, text/html,\r\n' \
              b'        text/x-dvi; q=0.8, text/x-c\r\n' \
              b'\r\n' \
              b'\r\n'


# Generated at 2022-06-23 19:41:07.732131
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Init
    t_formatting = Formatting()
    t_conversion = Conversion()
    t_msg = HTTPMessage('application/json', body=b'{"a": [1, 2, 3]}')
    t_stream = PrettyStream(conversion=t_conversion, formatting=t_formatting, msg=t_msg)
    t_mime = t_msg.content_type.split(';')[0]
    # Run
    result_body = t_stream.process_body(b'{"a": [1, 2, 3]}')
    # Check
    assert isinstance(result_body, bytes)
    assert result_body == t_formatting.format_body(content='{"a": [1, 2, 3]}', mime=t_mime).encode('utf8')


# Unit test

# Generated at 2022-06-23 19:41:10.306728
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    print(EncodedStream(env=env).output_encoding)

if __name__ == "__main__":
    test_EncodedStream()

# Generated at 2022-06-23 19:41:14.827618
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = "headers"
    assert msg.headers == "headers"
    msg.content_type = "haha"
    assert msg.content_type == "haha"
    # test whether iter_body is successful
    msg = RawStream(msg)
    for i in msg.iter_body():
        print(i)

# Generated at 2022-06-23 19:41:20.250691
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    headers = '''HTTP/1.1 200 OK\r
content-length: 17\r
content-type: application/json; charset=UTF-8\r
content-language: en-US\r
location: http://testing-studio.com/test\r
date: Mon, 22 Jul 2013 14:51:47 GMT\r
server: Google Frontend\r
\r
'''
    msg = HTTPMessage(one_liner_str=headers,
        headers=headers,
        body=None)
    stream = BaseStream(msg)
    assert stream.get_headers()== b''

# Generated at 2022-06-23 19:41:30.276533
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import io
    fake_socket = io.BytesIO(
        b'HTTP/1.1 200 OK\r\n'
        b'Content-type: application/json\r\n'
        b'Connection: Close\r\n'
        b'\r\n'
        b'{"glossary":{"title":"example glossary","GlossDiv":{"title":"S","GlossList":{"GlossEntry":{"ID":"SGML","SortAs":"SGML","GlossTerm":"Standard Generalized Markup Language","Acronym":"SGML","Abbrev":"ISO 8879:1986","GlossDef":{"para":"A meta-markup language, used to create markup languages such as DocBook.","GlossSeeAlso":["GML","XML"]},"GlossSee":"markup"}}}}}'
    )


# Generated at 2022-06-23 19:41:30.706331
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    pass

# Generated at 2022-06-23 19:41:38.593263
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    class FakeMessage(object):
        def __init__(self):
            self.body = "1234567890"

        def iter_body(self, chunk_size):
            for chunk in [self.body[i:i + chunk_size] for i in range(0, len(self.body), chunk_size)]:
                    yield chunk
    stream = RawStream(msg=FakeMessage())
    assert ''.join(stream.iter_body()).strip() == FakeMessage().body


# Generated at 2022-06-23 19:41:39.815561
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    stream = BufferedPrettyStream()
    print(stream)


# Generated at 2022-06-23 19:41:43.693484
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    message = HTTPMessage()
    message.body = b'Hello World'
    message.encoding = 'utf8'

    stream = EncodedStream(message)
    assert b'Hello World' == b''.join(stream.iter_body())


if __name__ == '__main__':
    test_EncodedStream_iter_body()

# Generated at 2022-06-23 19:41:45.991917
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    print("start")
    base_stream = BaseStream("msg")
    print(base_stream.iter_body()) 
    print("end")


# Generated at 2022-06-23 19:41:54.720035
# Unit test for method __iter__ of class BaseStream

# Generated at 2022-06-23 19:41:57.284311
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    """Unit test for constructor of class BinarySuppressedError"""
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE
        assert str(e) == "<BinarySuppressedError: '" + str(BINARY_SUPPRESSED_NOTICE) + "'>"

# Generated at 2022-06-23 19:42:00.716536
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    class TestMsg(HTTPMessage):
        headers = 'a:b'

    stream = PrettyStream(TestMsg())

    assert stream.get_headers() == b'a: b'


# Generated at 2022-06-23 19:42:11.467055
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Headers
    headers_str = "HTTP/1.1 200 OK\r\nServer: nginx/1.13.4\r\nDate: Sat, 19 May 2018 11:15:57 GMT\r\nContent-Type: text/html; charset=utf-8\r\nContent-Le" \
                  "ngth: 238\r\nConnection: keep-alive\r\nEtag: \"5a651990-ee\"\r\n\r\n"
    headers_encoded = headers_str.encode("utf8")
    msg = HTTPMessage(headers=Headers(headers_str.split("\r\n")))
    stream = BaseStream(msg)
    assert stream.get_headers() == headers_encoded


# Generated at 2022-06-23 19:42:19.992467
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import Request
    from httpie.plugins import plugin_manager
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter

    env = Environment(colors=256, stdin_isatty=False, stdout_isatty=False)
    request = Request(method='GET', url='http://httpbin.org/get', headers={
        'Content-Type': 'application/json'
    })
    plugin_manager.get_converters = lambda: [JSONConverter()]

# Generated at 2022-06-23 19:42:31.908935
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-23 19:42:39.543522
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import pytest
    from httpie.models import HTTPMessage
    from httpie.compat import str
    # Test the case when an invalid character is included
    msg = HTTPMessage('utf8',
                      'This is a test message with an invalid character \x0c'
                      '\nThis is the second line!')
    stream = EncodedStream(msg, with_headers=False, with_body=True)
    assert b'\x0c' not in list(stream.__iter__())[0]
    # Test the case when the body is None
    msg = HTTPMessage('utf8', None)
    stream = EncodedStream(msg, with_headers=False, with_body=True)
    assert list(stream.__iter__())[0] == b''
    # Test the case when the body is empty

# Generated at 2022-06-23 19:42:50.040750
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    import unittest
    import sys
    from httpie.context import Environment
    from httpie.models import Message
    from httpie.output.stream import BufferedPrettyStream

    class MockConversion:
        def get_converter(self, mime):
            return None

    class MockFormattting:
        def format_body(self, content, mime):
            return content

        def format_headers(self, headers):
            return ''

    class MockMessage(Message):
        def iter_body(self, chunk_size):
            return []

    class TestBufferedPrettyStream(unittest.TestCase):
        def test_init(self):
            env = Environment()
            msg = MockMessage()

# Generated at 2022-06-23 19:42:53.880956
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    headers = ['Content-Type: application/json', 'a: b']
    msg = HTTPMessage()
    msg.headers = headers
    stream = BaseStream(msg)
    assert stream.get_headers() == '\r\n'.join(headers).encode('utf8')


# Generated at 2022-06-23 19:43:01.539810
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage()
    msg.headers = headers = {'content-type': 'application/json'}
    msg._encoding = 'utf8'
    msg._text = ''
    msg._raw = b'{"key":"value"}'
    stream = PrettyStream(msg, with_headers=False, conversion=mock.Mock(), formatting=mock.Mock())
    stream.mime = 'application/json'
    # noinspection PyProtectedMember
    next(stream.iter_body()) == b'{\n    "key": "value"\n}'

# Generated at 2022-06-23 19:43:03.176940
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    assert BufferedPrettyStream != None


# Generated at 2022-06-23 19:43:09.829023
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():

  import tempfile
  import os

  # Create some sample bytes
  text = """A:α
B:β
C:δ
D:ε
E:ϝ

"""
  bytes_in = text.encode()

  # Create a temp file
  fd, path = tempfile.mkstemp()
  with os.fdopen(fd, 'wb') as tmp:
     tmp.write(bytes_in)

  # Open the temp file for iter_body

# Generated at 2022-06-23 19:43:11.065941
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    try:
        raise DataSuppressedError()
    except DataSuppressedError as e:
        assert e.message == None

# Generated at 2022-06-23 19:43:19.951842
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    expected = b'[\n  {\n    "text": "test123"\n  }\n]'
    class my_message(HTTPMessage):
        def iter_body(self, chunk_size):
            return [b'[\n  {\n    "text": "test123"\n  }\n]']
    input = my_message()
    output = BufferedPrettyStream(input, conversion=None, formatting=None, on_body_chunk_downloaded=None)
    assert next(output.iter_body()) == expected



# Generated at 2022-06-23 19:43:30.488844
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    HTTPRequest = type('HTTPRequest', (), {})
    HTTPRequest.raw_message = 'HTTPRequest.raw_message'
    HTTPRequest.headers = 'HTTPRequest.headers'
    HTTPRequest.body_stream = 'HTTPRequest.body_stream'
    HTTPRequest.method = 'HTTPRequest.method'
    HTTPRequest.url = 'HTTPRequest.url'

    HTTPRequest.headers_with_casing = 'HTTPRequest.headers_with_casing'
    HTTPRequest.content_type = 'HTTPRequest.content_type'
    HTTPRequest.encoding = 'HTTPRequest.encoding'

    HTTPRequest.iter_body = lambda self, chunk_size: [
        b'HTTPRequest.iter_body_1',
        b'HTTPRequest.iter_body_2'
    ]

# Generated at 2022-06-23 19:43:33.251837
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(version='1.1', status_code=200, headers=None, body=b"abcde")
    stream = RawStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-23 19:43:35.769855
# Unit test for constructor of class BaseStream
def test_BaseStream():
    req = HTTPMessage(method='GET',url='/')
    stream = BaseStream(req)
    assert stream.get_headers() == b'GET / HTTP/1.1\r\n\r\n'
    assert next(stream.__iter__()) == b'GET / HTTP/1.1\r\n\r\n'



# Generated at 2022-06-23 19:43:36.637539
# Unit test for constructor of class BaseStream
def test_BaseStream():
    stream = BaseStream()
    assert isinstance(stream, BaseStream)

# Generated at 2022-06-23 19:43:37.709967
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
	pass

# Generated at 2022-06-23 19:43:39.325961
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    basestream = BaseStream()
    print(basestream.iter_body())


# Generated at 2022-06-23 19:43:51.317235
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg_set = '''HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf8
Content-Length: 10

aaa\n
bbb\n
ccc\n

'''.encode('utf8')

    class MSG(HTTPMessage):
        def iter_body(self, chunk_size=None):
            yield b'aaa'
            yield b'\n'
            yield b'bbb'
            yield b'\n'
            yield b'ccc'
            yield b'\n'
            yield b'\n'

    msg = MSG(msg_set)

    stream = BaseStream(msg, with_headers=True, with_body=True)

    assert ''.join(stream) == msg_set.decode('utf8')


# Generated at 2022-06-23 19:43:55.812872
# Unit test for constructor of class RawStream
def test_RawStream():
    from httpie.models import HTTPResponse
    message = HTTPResponse([], b'', url='http://example.com/')
    stream = RawStream(message, with_headers=True, with_body=True)
    assert stream.msg == message
    assert stream.CHUNK_SIZE == 1024 * 100
    assert stream.CHUNK_SIZE_BY_LINE == 1

# Generated at 2022-06-23 19:43:59.589885
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(headers=HTTPMessage.headers_class())
    ps = PrettyStream(msg, with_headers=True, with_body=True)
    print(ps.CHUNK_SIZE)
    print(ps.output_encoding)
    print(ps.get_headers())


if __name__ == '__main__':
    test_PrettyStream()

# Generated at 2022-06-23 19:44:04.710757
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test function to be called when a chunk is downloaded.
    on_body_chunk_downloaded = Mock()
    # Get a mocked HTTPMessage object
    mock_HTTPMessage = Mock()
    # Declare the iterator mock object
    mock_iterator = Mock()
    # Add a spec for the iter_body function
    mock_HTTPMessage.iter_body = Mock(return_value=iter([b'Hello World!\n']))
    # Get a mocked Conversion object
    mock_Conversion = Mock()
    # Add a return for the get_converter method
    mock_Conversion.get_converter = Mock(return_value=None)
    # Get a mock Formatting object
    mock_Formatting = Mock()
    # Add a return for the method format_body
    mock_Formatting.format_

# Generated at 2022-06-23 19:44:17.250961
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from .headers import Headers
    from .message import HTTPMessage
    from .context import Environment

    mock_conversion = Conversion()
    mock_formatting = Formatting()
    mock_env = Environment()
    headers = Headers(b"Server: httpbin\r\nContent-Type: application/json\r\n")
    body = b'{\n  "args": {}, \n  "headers": {\n    "Accept": "*/*", \n    "Connection": "close", \n    "Host": "httpbin.org", \n    "User-Agent": "HTTPie/0.9.6"\n  }, \n  "origin": "130.89.149.95", \n  "url": "https://httpbin.org/get"\n}'


# Generated at 2022-06-23 19:44:21.300699
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except DataSuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE
    except Exception as e:
        assert e is not Exception

# Generated at 2022-06-23 19:44:30.860217
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Verify that
    #   1) function process_body() works
    #   2) function process_body() force to convert chunk to str
    hs = PrettyStream(conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        msg=HTTPMessage(content_type="text/html;charset=utf-8",
        headers="content-type:application/json",
        encoding="utf8",
        parts=None,
        url="http://localhost:9008/v1/daily_report",
        request_line="GET /v1/daily_report"))

    # Case 1: chunk is bytes

# Generated at 2022-06-23 19:44:37.398936
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    class msg_mock:
        headers = 'Content-Encoding: gzip\nContent-Type: application/json; charset=utf-8'
        content_type = 'application/json; charset=utf-8'

    class formatting_mock:
        def format_headers(self, msg):
            return 'Content-Encoding: gzip\nContent-Type: application/json'

    class conversion_mock:
        pass

    class env_mock:
        stdout_isatty = True
        stdout_encoding = 'utf8'

    headers = PrettyStream(
        msg_mock(),
        formatting=formatting_mock(),
        conversion=conversion_mock(),
        env=env_mock()
    ).get_headers()


# Generated at 2022-06-23 19:44:45.624107
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Arrange
    chunk = "\u2122"
    msg = HTTPMessage(
        headers=None,
        raw_content=None,
        url=None,
        mime_type="text/plain",
        encoding="utf-8",
        content_dict=None
    )
    pretty_stream = PrettyStream(conversion=None, formatting=None, msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    # Act
    processed_chunk = pretty_stream.process_body(chunk)
    # Assert
    assert processed_chunk == chunk.encode('utf-8')

# Generated at 2022-06-23 19:44:54.439835
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    """
    Args:
        msg: a :class:`models.HTTPMessage` subclass
        with_headers: if `True`, headers will be included
        with_body: if `True`, body will be included

    """
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
Connection: keep-alive
Cache-Control: max-age=600
Content-Length: 1366
Content-Type: text/html; charset=UTF-8
Date: Tue, 27 Sep 2016 07:31:01 GMT
Expires: Tue, 27 Sep 2016 07:41:01 GMT
Server: nginx/1.10.1
Vary: Accept-Encoding
X-Cache: HIT from Backend

'''
    stream = PrettyStream(msg=msg)

# Generated at 2022-06-23 19:45:05.439873
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = '''HTTP/1.1 200 OK
Pragma: no-cache
Content-Type: application/json; charset=utf-8
Cache-Control: no-cache
X-CaaS-Service-Version: 1.19.7
Content-Length: 44
X-CaaS-Execution-Time: 0.0022

'''.encode('utf8')
    http_msg = HTTPMessage(headers)
    stream = PrettyStream(msg=http_msg)

# Generated at 2022-06-23 19:45:13.685520
# Unit test for constructor of class RawStream
def test_RawStream():
    my_dict = {}
    def my_cb(chunk):
        my_dict['count'] += len(chunk)  # Updates the dictionary
    message = HTTPMessage()
    message.headers = 'hello world'
    message.request_data = 'world'
    message.stream = message.iter_body(1024 * 10)
    message.encoding = 'utf8'
    bs = RawStream(message, with_headers=True, with_body=True, on_body_chunk_downloaded=my_cb)
    st = bs.get_headers()
    it = bs.iter_body()
    assert st == 'hello world'
    assert my_dict['count'] == 5
    assert bs.msg == message


# Generated at 2022-06-23 19:45:19.094974
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    
    msg = HTTPResponse(b'11112222333344445555', headers=b'header\r\n',
                       request=None)
    raw_stream = RawStream(msg=msg, with_headers=True, with_body=True)
    assert len(list(raw_stream.iter_body())) == 1
    assert len(list(raw_stream.iter_body()[0])) == 1*100*1024

# Generated at 2022-06-23 19:45:30.751887
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    """ This unit test check the iter_body method of class BaseStream
    """
    ba = bytearray()
    ba.extend(b'\r\n')
    ba.extend(b'\r\n')
    ba.extend(b'useless data')
    ba.extend(b'\r\n')
    ba.extend(b'\r\n')
    ba.extend(b'\r\n')
    ba.extend(b'\r\n')

    msg = HTTPMessage(
        headers = {'coucou':'haha'},
        encoding = 'utf-8',
        body = ba,
        content_type = 'text/html',
    )
    msg.url = 'google.com'
    msg.method = 'get'



# Generated at 2022-06-23 19:45:33.798364
# Unit test for constructor of class RawStream
def test_RawStream():
    headers = 'Test header\r\n'
    body = 'Hello'
    response = HTTPMessage(headers=headers, body=body)

    stream = RawStream(response)
    output = stream.get_headers() + b'\r\n\r\n' + stream.iter_body()

    assert output == b'Test header\r\n\r\nHello'



# Generated at 2022-06-23 19:45:42.898007
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers={'Content-Type': 'application/json'},
                      encoding='utf8')
    msg.body = '{"success": true}'
    stream = EncodedStream(msg=msg)
    assert [chunk.decode('utf8') for chunk in stream.iter_body()] == [
        '{"success": true}'
    ]
    # Test converting the body to an encoding supported by the terminal.
    msg.encoding = 'cp437'
    stream = EncodedStream(msg=msg, env=Environment(stdout_isatty=True))
    assert [chunk.decode('cp437') for chunk in stream.iter_body()] == [
        '{"success": true}'
    ]


# Generated at 2022-06-23 19:45:50.744819
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    req=HTTPMessage(b'GET / HTTP/1.1\r\nHost: www.baidu.com\r\nUser-Agent: HTTPie/0.9.9\r\nAccept-Encoding: gzip, deflate\r\nAccept: application/json, */*\r\nConnection: keep-alive\r\n\r\n')
    raw=RawStream(req,with_headers=True,with_body=True)
    for i in raw.iter_body():
        if i:
            print(i)


# Generated at 2022-06-23 19:46:00.140248
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage('GET', 'https://httpbin.org')
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    body = '{"title":"HTTPie is HTTP for Humans",\n"url":"https://httpie.org"}'

    stream = BufferedPrettyStream(msg, env=env, conversion=conversion, formatting=formatting)
    stream2 = BufferedPrettyStream(msg, env=env, conversion=conversion, formatting=formatting)

    assert stream2.msg == msg and stream2.env == env and stream2.conversion == conversion

# Generated at 2022-06-23 19:46:06.036159
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    msg.create_new_body()
    msg.body.write(b'abc')
    msg.body.write(b'def')
    msg.body.write(b'ghi')

    stream = RawStream(msg)
    ls = list(stream.iter_body())
    assert len(ls) == 1
    assert ls[0] == b'abcdefghi'



# Generated at 2022-06-23 19:46:08.814154
# Unit test for constructor of class RawStream
def test_RawStream():
    try:
        RawStream(1)
    except TypeError:
        assert False
    

# Generated at 2022-06-23 19:46:19.774995
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-23 19:46:27.733292
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    assert b'GET / HTTP/1.1\r\nHost: example.com\r\nAccept: */*\r\n\r\n' == BaseStream(HTTPMessage("GET / HTTP/1.1\r\nHost: example.com\r\nAccept: */*\r\n\r\n")).get_headers()
    assert b'GET / HTTP/1.1\r\nHost: example.com\r\nAccept: */*\r\n\r\n' == BaseStream(HTTPMessage("GET / HTTP/1.1\r\nHost: example.com\r\nAccept: */*\r\n\r\n").pretty()).get_headers()

# Generated at 2022-06-23 19:46:38.271120
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-23 19:46:40.359312
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError
    except:
        assert  BinarySuppressedError.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-23 19:46:45.809650
# Unit test for constructor of class BaseStream
def test_BaseStream():
    """
    :return:
    """
    headers = "example"
    body = "body"
    msg = HTTPMessage()
    msg.headers = headers
    msg.body = body

    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None

    stream = BaseStream(msg, with_headers=with_headers, with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded)
    assert stream.msg == msg
    assert stream.with_headers == with_headers
    assert stream.with_body == with_body
    assert stream.on_body_chunk_downloaded == on_body_chunk_downloaded


# Generated at 2022-06-23 19:46:55.792956
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():

    env = Environment(
        isatty=False
    )
    env.stdout_encoding = 'utf8'
    env.stdin_isatty = False
    env.stdin = io.StringIO()
    env.stdout = io.StringIO()

    class H(HTTPMessage):
        def get_headers(self):
            print(self.headers)

    http_obj = H()

    class RestTest:
        """
        Simple test class that pretends to be a RESTful object.
        """
        def GET(self, request, response):
            """
            Return a plain-text '200 OK' response with an entity body that
            echoes back the 'cheat' and 'language' query arguments.
            """
            http_obj.headers = request.headers


# Generated at 2022-06-23 19:46:57.389967
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    message = BINARY_SUPPRESSED_NOTICE
    BinarySuppressedError = message
    print("BinarySuppressedError:", BinarySuppressedError)

# Generated at 2022-06-23 19:47:07.113597
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # test_with_headers_and_body
    conversion = Conversion()
    formatting = Formatting()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"
    body = "abc"
    msg = HTTPMessage(headers=headers, body=body, encoding='utf8')
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting)
    result = next(stream)
    assert result.decode('utf8') == "HTTP/1.1 200 OK\nContent-Type: text/plain\n\n"

    # test_with_headers
    conversion = Conversion()
    formatting = Formatting()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"

# Generated at 2022-06-23 19:47:17.705451
# Unit test for constructor of class RawStream
def test_RawStream():
    # Test initialization of RawStream instance
    sample_msg = HTTPMessage(
        headers="HTTP/1.1 200 OK\r\n\r\n",
        body="I am a test body."
    )
    sample_stream = RawStream(
        msg=sample_msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )
    assert sample_stream.msg == sample_msg
    assert sample_stream.with_headers 
    assert sample_stream.with_body
    assert sample_stream.on_body_chunk_downloaded == None
    assert sample_stream.CHUNK_SIZE == 1024 * 100
    assert sample_stream.CHUNK_SIZE_BY_LINE == 1

    # Test initialization of RawStream instance with default parameters


# Generated at 2022-06-23 19:47:18.966637
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    e = DataSuppressedError()
    assert(e)


# Generated at 2022-06-23 19:47:26.524954
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPMessage
    from httpie.output.streams import EncodedStream
    from httpie.compat import StringIO
    message = HTTPMessage(headers=StringIO("HTTP/1.0 200 OK\r\nHeader1: Value1\r\nHeader2: Value2\r\n\r\n"),
                          body=StringIO("body"),
                          encoding="utf8")
    stream = EncodedStream(msg=message, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    result = stream.get_headers()
    assert result == b"HTTP/1.0 200 OK\r\nHeader1: Value1\r\nHeader2: Value2\r\n\r\n"


# Generated at 2022-06-23 19:47:33.723324
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Request
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.formatters.colors import get_lexer
    import json

    headers = {'content-type': 'application/json'}
    r = Request("GET", url="http://127.0.0.1:5000/api/v1/users", headers=headers)
    r.body = json.dumps({"name": "test1", "email": "test@test.com"}, indent=2)
    r.content_type = 'application/json'
    r.encoding = 'utf8'
    r.headers.update(headers)
    r.headers.raw = dict_to_raw(r.headers.raw)
    r.headers.is_valid = True
    s = BufferedPrettyStream

# Generated at 2022-06-23 19:47:42.147254
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """
    Test function iter_body in class BufferedPrettyStream
    """
    from httpie.context import Environment
    from httpie.models import HTTPMessage, Response
    from httpie.output.processing import Formatting
    from httpie.output.streams import BufferedPrettyStream
    import json
    import os

    env = Environment()
    headers = HTTPMessage('headers\r\nBin\r\nother-header\r\nhello')
    msg = Response(request=None, http_version='HTTP/1.1', status_code=200,
                   reason='OK', headers=headers, raw_headers=b'',
                   body=b'\0\0\0\0\0\0\0\0\0\0')


# Generated at 2022-06-23 19:47:48.312546
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    def encodestream(msg):
        return EncodedStream(msg)

    request = HTTPMessage(request_type='GET', url='http://www.google.com',
                          headers='Content-Type: application/html',
                          data='赵钱孙李', encoding='gb18030')
    assert encodestream(request)

    request = HTTPMessage(request_type='GET', url='http://www.google.com',
                          headers='Content-Type: text/html', data='hello',
                          encoding='utf8')
    assert encodestream(request)



# Generated at 2022-06-23 19:47:55.923757
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    import unittest
    # class PrettyStream(EncodedStream):
    class TestPrettyStream(unittest.TestCase):
        def test_get_headers(self):
            pass

        def test_iter_body(self):
            pass

        def test_process_body(self):
            pass

        def test_init(self):
            pass

    suite = unittest.TestLoader().loadTestsFromTestCase(TestPrettyStream)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 19:48:02.743131
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():  # noqa: F811
    stream = PrettyStream(None, Formatting(None, 'colors=never'), None)
    bytes_sample = b'\x1b[31mTesting\x1b[0m'
    str_sample = '\x1b[31mTesting\x1b[0m'
    assert stream.process_body(bytes_sample) == bytes_sample
    assert stream.process_body(str_sample) == bytes_sample

# Generated at 2022-06-23 19:48:09.565764
# Unit test for constructor of class RawStream
def test_RawStream():
    # RawStream.__init__ == BaseStream.__init__
    msg = HTTPMessage(body=b'OK\n')
    print(msg.body)

    output_stream = RawStream(msg, with_headers=True, with_body=True)
    print(output_stream.get_headers())
    for i in output_stream.msg.iter_body(1):
        print(i)
    print(output_stream.msg.body)
    print(output_stream.msg)


# Generated at 2022-06-23 19:48:15.282906
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    url = 'http://httpbin.org/range/20'
    # The list comprehension creates a list of 20 bytes
    expected_body = [b'.' for x in range(20)]
    headers = {'Content-Type': 'application/binary', 'Accept-Encoding': 'identity'}
    stream = RawStream(HTTPMessage(headers, expected_body), with_headers=False, with_body=True)
    actual_body = [x for x in stream.iter_body()]
    assert expected_body == actual_body, f"test_RawStream_iter_body() failed for {url}"


# Generated at 2022-06-23 19:48:21.721650
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    httpmsg = HTTPMessage(headers={'ok': 'ok'},
                          content_type='text/html',
                          body=b'[{"id": "1", "content": "hello"}]',
                          content_type_is_set=True,
                          encoding='utf8',
                          raw=None)
    conversion = Conversion()
    formatting = Formatting()
    prettystream = PrettyStream(httpmsg, conversion, formatting)
    print(next(prettystream.iter_body()))


# Generated at 2022-06-23 19:48:26.851746
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.streams import RawStream
    from httpie.output import streams
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    body = 'abcd'
    msg = HTTPMessage("headers", "body")
    msg.encoding = 'utf8'
    msg.headers = "headers"
    msg.body = body
    raw_stream = RawStream(msg)
    assert raw_stream.iter_body() == body.encode()
    streams.BINARY_SUPPRESSED_NOTICE = b"test \0 test"
    raw_stream.msg.body = "test" + "\0" + "test"
    assert raw_stream.iter_body() == "test" + "\0" + "test".encode

# Generated at 2022-06-23 19:48:31.133038
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nHello World!')
    stream = EncodedStream(msg)
    assert b'Hello World!' in stream
    assert b'\n' in stream

# Generated at 2022-06-23 19:48:38.975222
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print("Test EncodedStream constructor")
    #test EncodedStream
    msg = HTTPMessage(headers = 'HTTP/1.1 200 OK\n\n', body = '{"name":"wangyanfei"}')
    print("test EncodedStream with message: " + str(msg.__dict__))
    test_stream = EncodedStream(msg = msg)
    if test_stream.__class__ == EncodedStream:
        print("test EncodedStream constructor success!")
    else:
        print("test EncodedStream constructor fail!")


# Generated at 2022-06-23 19:48:48.930380
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
                    Server: Apache-Coyote/1.1
                    Set-Cookie: JSESSIONID=45610228C7B8A8E7E7A9D97F677929DC; Path=/; HttpOnly
                    Content-Type: application/json;charset=UTF-8
                    Content-Language: en-US
                    Content-Length: 10
                    Date: Tue, 08 Dec 2020 09:11:42 GMT'''
    with_headers = True
    with_body = True
    env = Environment()
    msg_out = PrettyStream(msg, with_headers=with_headers, with_body=with_body, env=env)

# Generated at 2022-06-23 19:48:58.725701
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(
        b'HTTP/1.1 200 OK\r\n'
        b'Server: nginx\r\n'
        b'Content-Type: text/plain\r\n'
        b'Set-Cookie: foo=bar\r\n'
        b'Set-Cookie: baz=34\r\n'
        b'\r\n'
        b'abcdef',
        None
    )
    stream = BaseStream(msg)
    assert stream.msg == msg
    assert stream.with_headers
    assert stream.with_body
    assert stream.on_body_chunk_downloaded is None


# Generated at 2022-06-23 19:49:07.965720
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    from httpie.models import HTTPResponse
    from httpie.plugins.formatter.formatters.colors import ColorFormatter
    from httpie.output.streams import PrettyStream
    # Initialize response

# Generated at 2022-06-23 19:49:14.242935
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage('HTTP/1.1 200 OK')
    msg.content_type = 'text/plain; charset=utf8'
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())

    # process_body should return bytes
    assert type(stream.process_body('test bytes')) == bytes
    # process_body should change 'hello' to 'world'
    assert stream.process_body('hello') == b'world\n'

# Generated at 2022-06-23 19:49:20.333421
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    BufferedPrettyStream.CHUNK_SIZE = 1
    m = HTTPMessage()
    m.headers = ['foo:bar']
    m.body = 'line 1\nline 2\nline 3'
    with patch('httpie.output.streams.conversion.get_converter', return_value=None):
        stream = BufferedPrettyStream(m)
        assert list(stream.iter_body()) == [b'line 1\nline 2\nline 3']

# Generated at 2022-06-23 19:49:29.448282
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    msg.add('first-header', 'first-value')
    msg.add('second-header', 'second-value')
    msg.add('third-header', 'third-value')

    msg.body = b'first_body'

    base_stream = BaseStream(msg=msg, with_headers=True, with_body=True)
    assert base_stream.get_headers() == b"first-header: first-value\r\n" \
                                        b"second-header: second-value\r\n" \
                                        b"third-header: third-value\r\n"

    assert "BaseStream" == base_stream.__class__.__name__

# Generated at 2022-06-23 19:49:38.392579
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
	msg = models.HTTPMessage(headers={"Content-Type": "text/html; charset=utf-8"},
                             body='<!doctype html>\n<html>\n<head><title>Test</title></head>'
                             '\n<body>\n    <p>HTTPie!</p>\n</body>\n</html>\n',
                             encoding='utf8')
	test_string = ''.join(RawStream(msg).iter_body())
	assert test_string == '<!doctype html>\n<html>\n<head><title>Test</title></head>\n<body>\n    <p>HTTPie!</p>\n</body>\n</html>\n'


# Generated at 2022-06-23 19:49:42.874494
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    stream = PrettyStream(msg=None,
                          with_headers=True,
                          with_body=True,
                          on_body_chunk_downloaded=None,
                          conversion=None,
                          formatting=None)
    assert stream.get_headers()

# Generated at 2022-06-23 19:49:48.145651
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessageImpl
    from io import BytesIO

    b = BytesIO()
    b.write = lambda x: print(x)
    msg = HTTPMessageImpl('url', 'GET', 'HTTP/1.1', {'a': 'b'}, b)

    bs = BaseStream(msg)
    for i in bs:
        print(i)

# Generated at 2022-06-23 19:49:54.489770
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    example = PrettyStream(
        HTTPMessage(
            headers='test',
            content_type='test',
            encoding='test'
        ),
        Conversion(),
        Formatting(
            filter_format=False,
            filter_headers=False,
            filter_response=False,
            filter_url=False,
            filter_http_status=False
        ),
        with_headers=False,
        with_body=False,
    )
    assert isinstance(example, EncodedStream)

# Generated at 2022-06-23 19:50:03.120963
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie.output.streams import BaseStream
    from httpie.models import HTTPMessage
    def test(msg: HTTPMessage):
        s = BaseStream(msg, with_body=False)
        #assert (type(x) is bytes and len(x) is 4) for x in s
        for x in s:
            assert type(x) is bytes
            assert not '\r\n\r\n' in x
    test(HTTPMessage(''))
    test(HTTPMessage('a=b'))
    test(HTTPMessage('a' * 1000))
    test(HTTPMessage('a\r\nb'))
    test(HTTPMessage('aa\r\nbb\r\ncc\r\n'))

# Generated at 2022-06-23 19:50:12.410011
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    mock_msg = MagicMock(spec=HTTPMessage)
    mock_msg.iter_body.return_value.__iter__.return_value = ['a', 'b', 'c']
    mock_msg.iter_body.return_value.__aiter__.return_value = ['a', 'b', 'c']
    mock_msg.iter_body.return_value.__len__.return_value = 3

    mock_formatting = MagicMock()
    mock_formatting.format_body.return_value = '"a"\n'

    mock_conversion = MagicMock()
    mock_conversion.get_converter.return_value = 'application/json'


# Generated at 2022-06-23 19:50:21.574726
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPMessage
    from httpie.context import Environment

    env = Environment()
    stream = EncodedStream(msg=HTTPMessage(headers='a', body=''), env=env)
    assert stream.msg.headers == 'a'
    # Test `super`
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.get_headers() == b'a'
    assert next(stream.iter_body()) == b''
    assert next(stream.__iter__()) == b'a'
    assert next(stream.__iter__()) == b'\r\n\r\n'
    assert next(stream.__iter__()) == b''
