

# Generated at 2022-06-23 19:40:22.042028
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert 'utf8' == EncodedStream().output_encoding
    assert 'gbk' == EncodedStream(env=Environment(stdout_isatty=False, stdout_encoding='gbk')).output_encoding



# Generated at 2022-06-23 19:40:32.687815
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import pytest
    from httpie.compat import StringIO

    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.streams import BufferedPrettyStream, RawStream
    from httpie.output.writers import write


    @pytest.fixture
    def msg(request):
        """Create a `HTTPMessage`.
        """
        request.cls.env = env = Environment()
        request.cls.encoding = encoding = 'utf8-variants'
        request.cls.mime = 'text/plain'
        request.cls.content = content = '\n'.join(['line-{}'.format(i) for i in range(50000)])

# Generated at 2022-06-23 19:40:37.797492
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Create a ByteStream object with content type None
    byte_stream = ByteStream('', None)
    # Create a HTTPMessage object with no content type
    msg = HTTPMessage(headers = None)
    # Test method __iter__ by calling it on BaseStream object with the message object as a parameter
    assert list(BaseStream(msg, with_headers = True, with_body = False, on_body_chunk_downloaded = None)) == []
   

# Generated at 2022-06-23 19:40:38.489929
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()



# Generated at 2022-06-23 19:40:40.203025
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert DataSuppressedError


# Generated at 2022-06-23 19:40:51.354444
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers_str = "HTTP/1.1 200 OK\n" +\
                  "Server: GitHub.com\n" +\
                  "Date: Mon, 25 May 2020 20:53:04 GMT\n" +\
                  "Content-Type: text/html; charset=utf-8\n" +\
                  "Content-Length: 1296\n" +\
                  "Status: 200 OK"
    headers = HeaderDict(headers_str)
    headers.raw = headers_str
    msg = HTTPMessage(headers=headers, body="test_body")
    stream = PrettyStream(msg)
    stream_output = stream.get_headers()
    assert b"HTTP/1.1 200 OK\n" in stream_output
    assert b"Server: GitHub.com\n" in stream_output

# Generated at 2022-06-23 19:40:54.120281
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    stream = PrettyStream(msg='', env='',
                          conversion='', formatting='', with_headers='',
                          with_body='')
    assert stream.get_headers() == ''


# Generated at 2022-06-23 19:41:05.244094
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    import pytest
    from httpie.output.colors import Config
    from httpie.output.formatters import JsonFormatter

    conversion = Conversion(mappings={
        'application/json': 'json',
    },
        config=Config(),
        parser_options=None,
    )

    formatting = Formatting(
        formatter_options=None,
        json_formatter=JsonFormatter(None),
    )

    msg = HTTPMessage(
        "HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\n'foo'",
    )

    stream = PrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting,
    )


# Generated at 2022-06-23 19:41:15.145335
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlencode
    import json

    body = json.dumps({
      'grant_type': 'client_credentials',
      'client_id': 'hzq0TtTJpc8A2xDzwT2G',
      'client_secret': 'p67zsbnGuT',
    })

    headers = {'content-type': 'application/json'}
    request = HTTPRequest('POST', 'http://192.168.31.246:8083/oauth/token',
                        headers=headers, body=body)

    env = Environment(colors=256)
    conversion = Conversion(env)

# Generated at 2022-06-23 19:41:16.673646
# Unit test for constructor of class BaseStream
def test_BaseStream():
    c = BaseStream()
    c.get_headers()



# Generated at 2022-06-23 19:41:24.402067
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.compat import BytesIO
    from httpie.output.streams import PrettyStream
    from httpie.models import Response
    from httpie.compat import is_py2

    body = b'{"args": {}, "data": "", "files": {}, "form": {}, "headers": '\
        b'{"Accept-Encoding": "identity", "Connection": "close", "Content-'\
        b'Length": "0", "Host": "httpbin.org", "User-Agent": '\
        b'"python-requests/2.9.1"}, "json": null, "method": "GET", "origin": '\
        b'"1.2.3.4", "url": "http://httpbin.org/get"}\n'


# Generated at 2022-06-23 19:41:29.073007
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    msg.headers = b'a: 1'
    msg.set_body(b'111111111\n111111111\n')
    
    stream = RawStream(msg)
    for i in stream.iter_body():
        print(i)

# Generated at 2022-06-23 19:41:38.788152
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # test case 1, text of type bytes
    body = b'text\r\n'
    stream = PrettyStream(None, None, None, None, None, body,
                          True, True, None)
    assert isinstance(next(iter(stream.iter_body())), bytes)

    # test case 2, text of type str
    body = 'text\r\n'
    stream = PrettyStream(None, None, None, None, None, body,
                          True, True, None)
    assert isinstance(next(iter(stream.iter_body())), bytes)

    # test case 3, text of type str
    body = 'text\r\ntext\r\n'
    stream = PrettyStream(None, None, None, None, None, body,
                          True, True, None)

# Generated at 2022-06-23 19:41:41.019271
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    error = BinarySuppressedError()
    assert error.message == BINARY_SUPPRESSED_NOTICE
    print("test_BinarySuppressedError() passed")


# Generated at 2022-06-23 19:41:51.129060
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    import json
    import httpie.cli
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import ProcessingChain
    env = Environment()
    m = json.loads(json.dumps({"login": "jacobsun"}))
    msg = HTTPMessage(None, m, 200, "OK", content_type="application/json", headers={}, status_line="", encoding=None)
    p = httpie.cli.get_response_processing_chain(env)
    converter = p.get_converter(msg.content_type)
    if converter:
        msg.content_type, msg.body = converter.convert(msg.body)

# Generated at 2022-06-23 19:41:53.316643
# Unit test for constructor of class BaseStream
def test_BaseStream():
    # msg = HTTPMessage()
    # stream = BaseStream(msg)
    print("Done! Unit test for BaseStream functon construct")


# Generated at 2022-06-23 19:41:56.428847
# Unit test for constructor of class BaseStream
def test_BaseStream():
    req = HTTPMessage(headers={'Accept': 'application/json'}, body='hello world', method='POST', url='http://localhost:8080/v2/deployments')
    stream = BaseStream(msg=req, with_headers=True, with_body=True)



# Generated at 2022-06-23 19:42:00.815093
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    headers = "HTTP/1.1 200 OK\r\nContent-Type: image/png\r\n" \
              "Content-Length: 10\r\n"
    msg = HTTPMessage.from_http(headers)
    stream = PrettyStream(msg=msg, with_headers=True, with_body=True)
    list(stream)

# Generated at 2022-06-23 19:42:01.549634
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    pass

# Generated at 2022-06-23 19:42:04.106720
# Unit test for constructor of class RawStream
def test_RawStream():
    stream = RawStream()
    assert stream.CHUNK_SIZE == 100 * 1024


# Generated at 2022-06-23 19:42:12.548621
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.client import BaseClient
    from httpie import ExitStatus
    env = BaseClient().env
    cli_args = [
        'GET',
        'http://www.google.com',
    ]
    args = env.parser.parse_args(args=cli_args, env=env)

    import requests
    r = requests.get(args.url, headers=args.headers, stream=True)

    msg = r.raw

    stream = BaseStream(msg = msg, with_body = True)
    stream = BaseStream(msg = msg, with_body = True, with_headers = True)
    stream = BaseStream(msg = msg, with_body = True, with_headers = True, on_body_chunk_downloaded = None)

# Generated at 2022-06-23 19:42:14.528036
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    bs = BinarySuppressedError(BINARY_SUPPRESSED_NOTICE)
    assert bs.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-23 19:42:18.535703
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    stream = BufferedPrettyStream(
        with_headers=True,
        with_body=True,
        conversion='json',
        encoding='utf-8',
        msg=HTTPMessage('', b'test\ndata\n')
    )
    iterable = stream.iter_body()
    assert next(iterable) == b"test\ndata\n"
    try:
        next(iterable)
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-23 19:42:21.619862
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    chunk_size=RawStream.CHUNK_SIZE
    assert RawStream(msg=msg,with_headers=with_headers,with_body=with_body,on_body_chunk_downloaded=on_body_chunk_downloaded,chunk_size=chunk_size)


# Generated at 2022-06-23 19:42:32.821759
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    ARG_MIME = 'application/json'
    ARG_OUTPUT_ENCODING = 'utf-8'
    ARG_CONTENT = '{"id": 1, "name": "Foo"}'
    ARG_FORMATTED_CONTENT = '''\
{
    "id": 1,
    "name": "Foo"
}'''
    args = {}
    args['method'] = 'GET'
    args['url'] = 'http://example.com'
    args['headers'] = []
    args['data'] = None
    args['files'] = []
    args['proxies'] = {}
    args['verify'] = False
    args['auth'] = None
    args['json'] = None
    args['compress'] = False
    args['timeout'] = 20

# Generated at 2022-06-23 19:42:35.591996
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    dataSuppressedError = DataSuppressedError()
    assert dataSuppressedError.message == None
    dataSuppressedError = DataSuppressedError(message = "data suppressed")
    assert dataSuppressedError.message == "data suppressed"


# Generated at 2022-06-23 19:42:39.649506
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.compat import urlopen

    url = 'http://httpbin.org/get'
    env = Environment()
    # conversion = Conversion()
    formatting = Formatting()
    # chunk_size = 1

    # msg = HTTPMessage(urlopen(url).info(), urlopen(url).read())
    msg = HTTPMessage(urlopen(url).info(), urlopen(url).read().decode())
    print(msg.content_type)


# Generated at 2022-06-23 19:42:44.393801
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPRequest
    from httpie.url import URL
    from httpie.cli.parser import parse_items

    sample_path = 'http://httpbin.org/stream/20'
    sample_body = '''This is the first message.
This is the second message.
This is the third message.
And here comes the fourth one.
    '''
    url = URL(sample_path, None)
    request = HTTPRequest(url, 'GET', None, parse_items({}))
    request.body = sample_body

    stream = RawStream(request)
    body_chunks = []
    for chunk in stream:
        if chunk:
            body_chunks.append(chunk.decode())

    body = ''.join(body_chunks)

    assert body == sample_body

# Unit

# Generated at 2022-06-23 19:42:53.258083
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    class Msg(HTTPMessage):
        def __init__(self, msg, encoding):
            super().__init__(msg, encoding)
        def iter_body(self):
            yield b'1'
            raise DataSuppressedError()

    msg1 = Msg(b'', 'utf8')
    msg2 = Msg(b'', 'utf8')
    msg3 = Msg(b'', 'utf8')
    msg4 = Msg(b'', 'utf8')

    assert list(BaseStream(msg1)) == []
    assert list(BaseStream(msg2, with_body=False)) == []
    assert list(BaseStream(msg3, with_headers=False)) == [b'1\n']
    assert list(BaseStream(msg4, with_headers=False, with_body=False))

# Generated at 2022-06-23 19:43:01.625484
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Create a default env instance
    env = Environment()

    # Set the encoding of stdout to utf-8
    env.stdout_encoding = 'utf-8'

    # Create a header dict
    header = {'Content-Type': 'utf-8'}

    # Create a HTTP message with the header and body
    message = HTTPMessage('body', header)

    # Create a new PrettyStream instance with the message and env
    stream = PrettyStream(message, env)

    # Assert the stream's output_encoding is utf-8
    assert stream.output_encoding == 'utf-8'


# Generated at 2022-06-23 19:43:08.230377
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(encoding='utf8',
        headers='Content-Type: text/html; charset=utf8', body='')
    pretty = EncodedStream(msg)
    assert pretty.output_encoding == 'utf8'
    msg = HTTPMessage(encoding='utf8', headers='', body='')
    pretty = EncodedStream(msg)
    assert pretty.output_encoding == 'utf8'

# Generated at 2022-06-23 19:43:11.663961
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = [
        ('Content-Type', 'text/plain')
    ]
    msg = HTTPMessage(headers=headers)
    conv = Conversion()
    fmt = Formatting()

    s = PrettyStream(msg, encoding='utf-8', conversion=conv, formatting=fmt)
    headers = s.get_headers()

    assert headers == "Content-Type: text/plain\r\n\r\n"

# Generated at 2022-06-23 19:43:21.642926
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    def iter_chunks(CHUNK_SIZE, body):
        for i in range(0, len(body), CHUNK_SIZE):
            yield body[i: i + CHUNK_SIZE], ''
    with open("tests/fixtures/responses/server_timing_single_val.http", 'r') as f:
        httpmsg = HTTPMessage.from_file(f)
    ps = PrettyStream(httpmsg, conversion=None, formatting=None, with_headers=False, with_body=True)
    count = 0
    for line in ps.iter_body():
        count = count + 1
    assert count == 3

# Generated at 2022-06-23 19:43:29.295404
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={'Content-Length': '21'})
    msg.body = b'hello world\r\nnext line'
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'hello world\r\n', b'next line']
    stream = RawStream(msg, chunk_size=5)
    assert list(stream.iter_body()) == [
        b'hello', b' worl', b'd\r\n', b'next ', b'line'
    ]

# Generated at 2022-06-23 19:43:35.695132
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.outputs import EncodedStream
    from httpie.compat import bytes

    def m_iter_body(self, chunk_size):
        yield b'foo'
        yield b'bar'

    HTTPResponse.iter_body = m_iter_body

    response_body = []
    msg = HTTPResponse(
        headers=None,
        status_line='HTTP/1.1 200 OK',
        raw=None,
        body=None,
        encoding='utf8',
        stream=None
    )

    for data in EncodedStream(msg, with_headers=False, with_body=True):
        response_body.append(data)


# Generated at 2022-06-23 19:43:39.487904
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'content-type: application/json\r\n\r\n')
    assert PrettyStream(msg, conversion=Conversion(),
                        formatting=Formatting()).get_headers() == b'content-type: application/json\n\n'



# Generated at 2022-06-23 19:43:43.649120
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    msg.body = 'hello world'
    test_obj = RawStream(msg)
    assert next(test_obj.iter_body()) == b'hello world'


# Generated at 2022-06-23 19:43:47.582265
# Unit test for constructor of class BaseStream
def test_BaseStream():
    headers = 'test'
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    # Test with no error
    base_stream = BaseStream(headers, with_headers, with_body, on_body_chunk_downloaded)
    assert base_stream is not None
    # Test with error
    with pytest.raises(Exception):
        base_stream = BaseStream('', with_headers, with_body, on_body_chunk_downloaded)


# Generated at 2022-06-23 19:43:53.426849
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    FROM = 'utf8'
    TO = 'utf8'
    msg = HTTPMessage(b'body', 'content-type', FROM)
    conversion = Conversion()
    formatting = Formatting()
    stream = BufferedPrettyStream(msg, False, True, conversion, formatting)
    for chunk in stream.iter_body():
        print(chunk.decode(TO))
        break

# Generated at 2022-06-23 19:43:54.277326
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-23 19:43:58.568488
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import os
    from httpie.models import HTTPResponse
    message = HTTPResponse(headers=b'Content-Type: text/plain', body=b'test body')
    raw_stream = RawStream(message)
    assert raw_stream.iter_body() is not None
    assert os.path.exists(raw_stream.iter_body())



# Generated at 2022-06-23 19:44:00.580428
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream = EncodedStream(msg=HTTPMessage())
    stream.iter_body()
    return True


# Generated at 2022-06-23 19:44:05.186130
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    body = b'1234567890'
    msg = HTTPMessage()
    msg.set_body(body, len(body))
    rawstream = RawStream(msg)
    res = b''
    for chunk in rawstream.iter_body():
        res = res + chunk
    print(res)
    assert res == body



# Generated at 2022-06-23 19:44:17.421271
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    def check(args, expect):
        result = PrettyStream({},{},msg={}).process_body(*args)
        assert result == expect, 'result: {0}'.format(result)

    check([b''], b'')
    check([b'a'], b'a')
    check([b'\xFF'], b'?')
    check(['a'], b'a')
    check([u'\u20AC'], b'\xe2\x82\xac')
    check([u'\u20AC\xFF'], b'\xe2\x82\xac?')
    check(['\u20AC'], b'\xe2\x82\xac')
    check([b''], b'')
    check([b'a'], b'a')

# Generated at 2022-06-23 19:44:25.038170
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage.from_bytes(b'HTTP/1.1 200 OK\r\n'
                                 b'Content-Length: 16\r\n\r\n'
                                 b'first line\n'
                                 b'second line')
    stream = RawStream(msg, with_body=True)
    assert b''.join(stream.iter_body()) == b'first line\nsecond line'


# Generated at 2022-06-23 19:44:27.552053
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    stream = PrettyStream('some_headers', 'some_body')
    assert stream.msg=='some_headers'
    assert stream.with_headers=='some_body'



# Generated at 2022-06-23 19:44:32.542578
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(b'{"a": 1}', headers=b'{"b": 2}')
    stream = BaseStream(msg)
    assert list(stream) == [b'{"b": 2}\r\n\r\n{"a": 1}']


# Generated at 2022-06-23 19:44:34.301749
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert DataSuppressedError.__init__.__defaults__ == (None,)


# Generated at 2022-06-23 19:44:42.660908
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class Message(object):
        def __init__(self, content, content_type):
            self.content = content
            self.content_type = content_type

        def iter_lines(self, chunk_size):
            yield self.content, '\n'

    conversion = Conversion()
    formatting = Formatting(indent_size=2)
    with_headers = True
    with_body = True
    content = '<html><head></head><body></body></html>'
    content_type= 'text/html'
    stream = PrettyStream(Message(content, content_type),
        conversion, formatting, with_headers, with_body)
    res: str = ''
    for chunk in stream.iter_body():
        res += chunk.decode(stream.output_encoding, 'replace')

# Generated at 2022-06-23 19:44:53.490229
# Unit test for constructor of class RawStream
def test_RawStream():
    assert RawStream(msg=HTTPMessage(headers=b'', body=b''), with_headers=True, with_body=True, on_body_chunk_downloaded=None).get_headers() == b''
    assert RawStream(msg=HTTPMessage(headers=b'', body=b''), with_headers=True, with_body=True, on_body_chunk_downloaded=None).iter_body() == b''
    assert format(RawStream(msg=HTTPMessage(headers=b'', body=b''), with_headers=True, with_body=True, on_body_chunk_downloaded=None).msg) == '<HTTPMessage (headers=\'\', body=\'\', encoding=None)>'

# Generated at 2022-06-23 19:45:00.474318
# Unit test for constructor of class BaseStream
def test_BaseStream():
	msg = HTTPMessage(
		'GET',
		'httpbin.org',
		'/get',
		None,
		None,
		b'',
		None,
		None,
		None
	)
	obj = BaseStream(
	    msg=msg,
		with_headers=True,
		with_body=True,
		on_body_chunk_downloaded = None
	)
	

# Generated at 2022-06-23 19:45:04.034565
# Unit test for constructor of class RawStream
def test_RawStream():
    assert RawStream.CHUNK_SIZE == 1024*100
    assert RawStream.CHUNK_SIZE_BY_LINE == 1



# Generated at 2022-06-23 19:45:07.781872
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b"Content-Type: text/plain")
    stream = RawStream(msg)
    print([bytes(i) for i in stream.iter_body()])


# Generated at 2022-06-23 19:45:12.099490
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage()
    # Add headers to msg
    headers = {}
    msg.headers = headers
    # Create a PrettyStream
    with_headers = True
    with_body = True
    pretty_stream = PrettyStream(msg=msg, with_headers=with_headers, with_body=with_body)
    assert pretty_stream.get_headers() == None


# Generated at 2022-06-23 19:45:20.951281
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test with ascii text without Formatting
    msg = HTTPMessage(headers='''
    HTTP/1.1 200 OK
    Date: Mon, 27 Jul 2009 12:28:53 GMT
    Server: Apache
    Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
    ETag: "34aa387-d-1568eb00"
    Accept-Ranges: bytes
    Content-Length: 51
    Vary: Accept-Encoding
    Content-Type: text/plain

    HTTP response body. It could be a binary file as well.
    ''', encoding='ascii')
    pretty_stream = PrettyStream(msg, True, True)
    valid_body = '''
    HTTP response body. It could be a binary file as well.
    '''

# Generated at 2022-06-23 19:45:28.670198
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    pretty = BufferedPrettyStream.__init__(1, with_body=True,
                                           on_body_chunk_downloaded=None)
    raw_stream = RawStream(pretty)

    # Verify initialization values
    assert pretty.with_body == True
    assert pretty.on_body_chunk_downloaded == None
    # Calling with_body
    pretty.get_headers() == True
    # Calling iter_body
    body = pretty.iter_body
    assert body == True



# Generated at 2022-06-23 19:45:35.217155
# Unit test for constructor of class BaseStream
def test_BaseStream():
    # Notice: the body of msg is b'\x00'
    msg = HTTPMessage('GET / HTTP/1.1', 'Host: localhost', b'\x00')
    # Test the constructor of class BaseStream
    stream = BaseStream(msg)
    # Test the method get_headers
    assert stream.get_headers() == b'Host: localhost\r\n\r\n'


# Generated at 2022-06-23 19:45:44.327280
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    print('<--- HTTP Response Body --->\n')

    # initialize data
    data = b'{"name": "httpie","version": "0.0.1"}'

    # initialize headers
    headers = ('content-type: application/json; charset=utf-8')

    # initialize env
    env = Environment()

    # initialize sub classes
    conversion = Conversion(env)
    formatting = Formatting(env)

    msg = HTTPMessage(
        url='http://httpbin.org/get',
        method='GET',
        headers=headers,
        body=data,
        encoding=env.stdin_encoding
    )

# Generated at 2022-06-23 19:45:45.442672
# Unit test for constructor of class BaseStream
def test_BaseStream():
    # noinspection PyTypeChecker
    BaseStream(None, True, True)



# Generated at 2022-06-23 19:45:46.557733
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    assert BaseStream(msg='', with_headers='', with_body='').get_headers() == ''


# Generated at 2022-06-23 19:45:58.178375
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.image import ImageFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import ColorsFormatter
    from httpie.output.formatters.html import HTMLFormatter
    from httpie.output.formatters.xml import XMLFormatter
    from httpie.output.formatters.javascript import JavaScriptFormatter
    from httpie.output.formatters.csv import CSVFormatter
    from httpie.output.formatters.tsv import TSVFormatter
    from httpie.output.formatters.carbon_now import CarbonNowFormatter

# Generated at 2022-06-23 19:46:06.079113
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    msg.headers = '''content-type:text/plain;charset=utf-8
content-length:16
'''
    msg.body = '''méthod __iter__
'''
    msg.encoding = 'utf8'

    i = BaseStream.__iter__(msg)
    assert next(i) == b'''content-type:text/plain;charset=utf-8
content-length:16

'''

# Generated at 2022-06-23 19:46:15.693365
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # data
    msg = HTTPMessage(
        method="GET",
        url="https://httpie.org/",
        headers=None,
        content=None,
        content_type=None,
        cookies=None,
        encoding=None,
        history=None,
        status_code=200,
        reason=None,
        raw=b"HTTPie/1.0.2\r\n",
        redirect_history=None,
    )
    prettiedmsg = msg.prettify(True)
    prettystream = BufferedPrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        env=None,
        conversion=None,
        formatting=Formatting(colors=True),
        on_body_chunk_downloaded=None,
    )

# Generated at 2022-06-23 19:46:24.956479
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-23 19:46:28.337494
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import httpie
    stream = EncodedStream(msg=httpie.models.HTTPMessage(), with_headers=True,
                           with_body=True)
    assert(stream != None)

# Generated at 2022-06-23 19:46:35.943067
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import HTTPResponse
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.output.streams import BaseStream
    path = os.path.join(os.path.dirname(__file__), '../../test/requests/cookies.txt')
    with open(path, 'rb') as file:
        response = HTTPResponse(file)
    stream = BaseStream(msg=response, with_headers=True, with_body=True)
    stream.get_headers()
    assert True

# Generated at 2022-06-23 19:46:39.604225
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    obj = BaseStream(msg=msg, with_headers=True, with_body=False)
    obj_return = obj.__iter__()
    assert obj_return is not None


# Generated at 2022-06-23 19:46:48.016761
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    #test for stdout is not a tty, so that output_encoding is the same with msg encoding
    mock_env = MagicMock()
    mock_env.stdout_isatty = False
    mock_msg = MagicMock()
    mock_msg.encoding= 'utf8'
    es = EncodedStream(mock_msg, env=mock_env)
    assert es.encoding == 'utf8'
    assert es.output_encoding == 'utf8'
    mock_env.stdout_isatty = True
    mock_env.stdout_encoding = 'cp1252'
    es = EncodedStream(mock_msg, env=mock_env)
    assert es.encoding == 'utf8'
    assert es.output_encoding == 'cp1252'



#

# Generated at 2022-06-23 19:46:48.662559
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert True

# Generated at 2022-06-23 19:46:52.030346
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage([b'HTTP/1.1 200 OK'])
    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True

# Generated at 2022-06-23 19:46:57.808369
# Unit test for constructor of class BaseStream
def test_BaseStream():
    # Test constructor of object with headers
    msg = BaseStream(None, with_headers = True, with_body = True, on_body_chunk_downloaded = None)
    assert msg
    # Test constructor of object without headers
    msg = BaseStream(None, with_headers = False, with_body = True, on_body_chunk_downloaded = None)
    assert msg
    # Test constructor of object without body
    msg = BaseStream(None, with_headers = True, with_body = False, on_body_chunk_downloaded = None)
    assert msg


# Generated at 2022-06-23 19:46:58.763953
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert DataSuppressedError.message == None

# Generated at 2022-06-23 19:47:06.159061
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = {
        'headers': 'headers',
        'content-type': 'content-type',
        'with_headers': False,
        'with_body': True,
        'on_body_chunk_downloaded': None
    }
    bs = BaseStream(**msg)
    assert bs.msg == msg
    assert bs.with_headers == msg['with_headers']
    assert bs.with_body == msg['with_body']
    assert bs.on_body_chunk_downloaded == msg['on_body_chunk_downloaded']



# Generated at 2022-06-23 19:47:17.484302
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    headers = b'''HTTP/1.1 200 OK
Content-Type: application/json

'''

    stream = PrettyStream(HTTPMessage(headers), conversion=Conversion(), formatting=Formatting())


# Generated at 2022-06-23 19:47:22.332075
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    response = requests.get('http://httpbin.org/ip')
    msg = HTTPMessage.from_raw(response.raw, response.encoding)

    stream = EncodedStream(msg=msg)
    print ("".join(stream.iter_body()))



# Generated at 2022-06-23 19:47:28.776668
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    msg.headers = {"Host": "httpbin.org", "Accept": "*/*"}
    msg.body = "Hello World"

    # Test constructor of BaseStream
    s = BaseStream(msg, with_headers=True, with_body=True)
    assert s.msg == msg
    assert s.with_headers
    assert s.with_body
    assert s.on_body_chunk_downloaded == None

    # Test get_headers()
    expected_headers = "Host: httpbin.org\r\nAccept: */*\r\n".encode('utf8')
    assert s.get_headers() == expected_headers

    # Test __iter__()
    expected_body = "Hello World"
    for i, actual_body in enumerate(s):
        expected_body

# Generated at 2022-06-23 19:47:39.790380
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():

    from io import BytesIO
    from httpie.downloads import ResponseAdapter
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.tables import ResponseTable

# Generated at 2022-06-23 19:47:46.537786
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    # GIVEN
    msg = HTTPMessage('GET / HTTP/1.1\r\nHost: httpbin.org\r\nUser-Agent: HTTPie/0.9.8\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nConnection: keep-alive\r\n\r\n')
    # WHEN
    stream = BaseStream(msg = msg)
    # THEN
    # Check that the type is bytes
    assert type(stream.get_headers()) == bytes


# Generated at 2022-06-23 19:47:50.713009
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from tests.httpbin_client import HOST
    url = 'http://' + HOST + '/status/200'
    args = parser.parse_args([url], env=Environment())
    info = request.get_info(args)
    msg = response.HTTPResponse(info, url=url, method='GET')
    basestream = BaseStream(msg=msg)
    basestream_headers = basestream.get_headers()
    assert(isinstance(basestream_headers, bytes))


# Generated at 2022-06-23 19:47:53.858241
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-23 19:47:55.923685
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    err = BinarySuppressedError()
    assert err.message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-23 19:48:01.529335
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(
        headers = "HTTP/1.1 200 OK\nContent-Type: application/json\n"
                  "Content-Length: 10\nDate: Sat, 28 Jul 2018 13:00:00 GMT\n"
    )
    assert BaseStream(msg).get_headers() == b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 10\r\nDate: Sat, 28 Jul 2018 13:00:00 GMT\r\n"

# Generated at 2022-06-23 19:48:05.419920
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers="Content-Type: text/html; charset=utf-8", body='abcd')
    enc = EncodedStream(msg)
    assert 'abcd' == list(enc.iter_body())[0].decode()



# Generated at 2022-06-23 19:48:11.390371
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import RawStream
    from httpie.utils import bytes_to_str

    test_bytes = b'hello world'
    stream = RawStream(Response(200, 'Ok', test_bytes))
    test_result = []
    for chunk in stream:
        test_result.append(bytes_to_str(chunk))
    assert b''.join(test_result) == test_bytes



# Generated at 2022-06-23 19:48:18.001057
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(
        headers = 'HTTP/1.1 200 OK\r\nHost: httpbin.org\r\n',
        encoding = 'ascii'
    )
    out = BaseStream(msg=msg)
    assert out.get_headers() == b'HTTP/1.1 200 OK\r\nHost: httpbin.org\r\n'


# Generated at 2022-06-23 19:48:20.552883
# Unit test for constructor of class BaseStream
def test_BaseStream():
    b = BaseStream(with_headers=True, with_body=True)
    assert b.with_headers == True and b.with_body == True


# Generated at 2022-06-23 19:48:21.129526
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    BinarySuppressedError()

# Generated at 2022-06-23 19:48:25.753771
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    print("Testing constructor of class BufferedPrettyStream.")
    try:
        stream = BufferedPrettyStream()
    except TypeError:
        print("Constructor of class BufferedPrettyStream works fine.")
    except:
        print("Constructor of class BufferedPrettyStream is wrong.")



# Generated at 2022-06-23 19:48:28.936553
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    try:
        raise DataSuppressedError()
    except DataSuppressedError as e:
        print(e)
        assert e is not None
        assert e.name == 'DataSuppressedError'


# Generated at 2022-06-23 19:48:39.608873
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test if headers are not included in output
    stream = EncodedStream(msg=HTTPMessage(headers=b'foo'), with_headers=False)
    assert list(stream) == []

    # Test if headers are included in output
    stream = EncodedStream(msg=HTTPMessage(headers=b'foo'))
    assert list(stream) == [b'foo\r\n\r\n']

    # Test if headers are included in output as well as body
    stream = EncodedStream(msg=HTTPMessage(headers=b'foo', body=b'bar'))
    assert list(stream) == [b'foo\r\n\r\nbar']

    # Test if headers are not included in output, and neither is body

# Generated at 2022-06-23 19:48:42.470076
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    assert isinstance(PrettyStream(msg, conversion, formatting), PrettyStream)


# Generated at 2022-06-23 19:48:45.041288
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    base = BaseStream("msg")
    assert base.get_headers() == "msg".encode('utf8')


# Generated at 2022-06-23 19:48:49.268899
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie.models import HTTPRequest

    stream = BaseStream(HTTPRequest(
        'GET',
        'http://www.baidu.com'
    ),
        with_body=False
    )

    assert [
        b''
        b'\r\n\r\n'
    ] == list(stream.__iter__())




# Generated at 2022-06-23 19:48:56.645371
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage()
    msg.headers = (
        "Content-Type: application/json"
        "Content-Length: 100500")
    msg.content_type = "application/json"
    msg.content_length = 100500

    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == (
        "Content-Type: application/json\r\n"
        "Content-Length: 100500\r\n\r\n")

# Generated at 2022-06-23 19:49:06.583669
# Unit test for constructor of class RawStream
def test_RawStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.core import main
    import io, os, sys

    args = ['--ignore-stdin', '-p', '-b', 'https://httpbin.org/get']
    env = Environment(
        stdin=io.BytesIO(),
        stdout=io.BytesIO(),
        stderr=sys.stderr,
        argv=args,
        config_dir=os.getcwd()
    )
    message_class=HTTPResponse
    with_headers=True
    with_body=True
    on_body_chunk_downloaded = None
    rs = RawStream(message_class, with_headers, with_body, on_body_chunk_downloaded)


# Generated at 2022-06-23 19:49:07.292391
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    pass


# Generated at 2022-06-23 19:49:11.510884
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage()
    msg.headers['Content-Type'] = 'application/json'
    msg.headers['Content-length'] = 8
    msg.headers['Date'] = 'Thu, 24 Oct 2019 10:56:30 GMT'

    msg_str = msg.headers.encode('utf8')
    assert msg_str == b'Content-Type: application/json\r\nContent-length: 8\r\nDate: Thu, 24 Oct 2019 10:56:30 GMT\r\n'



# Generated at 2022-06-23 19:49:14.431068
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # BaseStream class doesn't have method __iter__,
    # it uses the same method from its super class
    assert BaseStream.__iter__ == BaseStream.__iter__.__self__.__iter__


# Generated at 2022-06-23 19:49:16.643324
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    c =  HTTPMessage(body='ssss')
    d = PrettyStream(c)
    assert d.msg == 'ssss'

# Generated at 2022-06-23 19:49:22.394979
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\nContent-Type: text/html\n'
    msg.body = '<html><body>Hello World</body></html>'
    msg.content_type = 'text/html'
    stream = PrettyStream(msg)
    assert stream.msg.headers == msg.headers
    assert stream.msg.body == msg.body
    assert stream.msg.content_type == msg.content_type



# Generated at 2022-06-23 19:49:26.173561
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    env = Environment()
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    assert env.stdout_isatty == True
    # Create a PrettyStream
    stream = PrettyStream(msg, env=env)
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.get_headers() == b'Content-Type: text/html\r\n\r\n'


# Generated at 2022-06-23 19:49:28.353253
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    BinarySuppressedError()

# Generated at 2022-06-23 19:49:35.294295
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(body='test')
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    stream = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    assert stream.msg == msg
    assert stream.with_headers == with_headers
    assert stream.with_body == with_body
    assert stream.on_body_chunk_downloaded == on_body_chunk_downloaded



# Generated at 2022-06-23 19:49:38.975496
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    hs = PrettyStream(conversion=None, formatting=None, msg=None, with_headers=True, with_body=True)
    assert hs.conversion == None
    assert hs.formatting == None
    assert hs.msg == None
    assert hs.mime == None
    assert hs.with_headers == True
    assert hs.with_body == True

# Generated at 2022-06-23 19:49:40.188099
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError


# Generated at 2022-06-23 19:49:46.062942
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    body = b'{"id": "1234", "user": "Johanna", "date": "1970-01-01"}'
    msg = HTTPMessage(headers=[], body=body)

    stream = BufferedPrettyStream(msg)
    for chunk in stream.iter_body():
        print(chunk)

##test_BufferedPrettyStream_iter_body()

# Generated at 2022-06-23 19:49:56.012525
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import RawRequest, RawResponse
    from httpie import __version__
    from httpie.core import main
    from httpie.context import Environment
    from httpie.cli import CLIFactory
    import httpie
    import pprint
    import sys

    cli_factory = CLIFactory()
    cli = cli_factory(env=Environment())

    # https://github.com/jakubroztocil/httpie/blob/master/httpie/input.py#L274

# Generated at 2022-06-23 19:50:01.409045
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    a = EncodedStream(msg = "hello", with_headers= True, with_body=True)
    assert a.msg == "hello"
    assert a.with_headers == True
    assert a.with_body == True
    a = EncodedStream(msg = "hello", with_headers= False, with_body=False)
    assert a.msg == "hello"
    assert a.with_headers == False
    assert a.with_body == False


# Generated at 2022-06-23 19:50:11.043397
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import os
    import tempfile
    from pathlib import Path
    from httpie import __version__
    from httpie.models import Response
    from httpie.compat import is_windows
    """
    test_raw_stream: create a temporary file and run http on it
    :return: None
    """
    fd, tf = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-23 19:50:21.125414
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.input import ParseException
    from httpie.models import ParseError
    from httpie.output.streams import PrettyStream
    from httpie.plugins import FormatterPlugin
    from httpie.plugins import ConverterPlugin

    class Converter(ConverterPlugin):
        def convert(self, body, mime) -> str:
            print(body)
            print(mime)
            return 'text/html'

    class Formatter(FormatterPlugin):
        def format_headers(self, headers):
            pass

        def format_body(self, content, mime):
            return content

    def get_headers(headers):
        msg = HTTPMessage(200, None, headers, None)
        return PrettyStream(msg, None, None, with_body=False)
