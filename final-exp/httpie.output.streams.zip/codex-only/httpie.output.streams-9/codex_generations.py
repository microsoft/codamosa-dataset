

# Generated at 2022-06-23 19:40:25.418284
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.context import Environment
    env = Environment()
    request_message = HTTPMessage(headers=Headers(":status: 200"))
    conversion = Conversion()
    formatting = Formatting()
    pretty_stream = PrettyStream(msg=request_message, conversion=conversion, formatting=formatting, env=env)
    headers = pretty_stream.get_headers()
    print(headers)


# Generated at 2022-06-23 19:40:26.057573
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    assert True

# Generated at 2022-06-23 19:40:31.746302
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # pylint: disable=W0612
    class Msg(HTTPMessage):

        def __init__(self, body=''):
            self.body = body
            self.headers = ''
            self.content_type = ''
            self.encoding = ''

    # Can't be tested with @mock.patch
    msg = Msg()
    stream = PrettyStream(msg, False, True, Conversion(), Formatting())
    # pylint: enable=W0612

# Generated at 2022-06-23 19:40:40.318043
# Unit test for constructor of class BaseStream
def test_BaseStream():
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf8\r\nContent-Length: 13\r\n\r\n"
    body = "Hello HTTPie!"
    msg = HTTPMessage(headers.encode(), body.encode())

    try:
        BaseStream()
    except TypeError:
        assert True

    try:
        BaseStream(msg)
    except TypeError:
        assert True

    try:
        BaseStream(msg, True, True)
    except TypeError:
        assert True
    else:
        assert False

    obj = BaseStream(msg, True, True, None)
    assert obj.msg == msg
    assert obj.with_headers == True
    assert obj.with_body == True
    assert obj.on_body_

# Generated at 2022-06-23 19:40:41.855502
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert EncodedStream(msg = HTTPMessage())


# Generated at 2022-06-23 19:40:43.093020
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    pass


# Generated at 2022-06-23 19:40:46.055889
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(None, None)
    stream = RawStream(msg)
    assert stream.iter_body() is not None

# Generated at 2022-06-23 19:40:51.354308
# Unit test for constructor of class BaseStream
def test_BaseStream():
    test_msg = HTTPMessage()
    test_msg.headers.update({"key1": "value1"})

    test_stream = BaseStream(msg=test_msg, with_headers=True, with_body=True)
    assert test_stream.msg.headers == test_msg.headers
    assert test_stream.with_body is True
    assert test_stream.with_headers is True



# Generated at 2022-06-23 19:40:59.893198
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream(HTTPMessage(encoding = 'ascii', body = b'a'))
    assert list(stream.iter_body()) == [b'a']

    stream = EncodedStream(HTTPMessage(encoding = 'ascii', body = b'a\u00E1'))
    assert list(stream.iter_body()) == [b'a\u00E1']

    stream = EncodedStream(HTTPMessage(encoding = 'ascii', body = b'\u00E1'))
    assert list(stream.iter_body()) == [b'?']

    stream = EncodedStream(HTTPMessage(encoding = 'ascii', body = b'\0'))

# Generated at 2022-06-23 19:41:06.982298
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test_message = HTTPMessage("a\x00b\x00c\x00d\x00e")
    test_stream = EncodedStream(test_message)
    test_stream.msg.encoding = "utf-8"
    assert next(test_stream.iter_body()) == "a"
    assert next(test_stream.iter_body()) == "\ufffd"
    assert next(test_stream.iter_body()) == "\ufffd"
    assert next(test_stream.iter_body()) == "\ufffd"
    assert next(test_stream.iter_body()) == "\ufffd"


# Generated at 2022-06-23 19:41:16.285330
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Create a new HTTPMessage object, using the class and the init function
    # HTTPMessage has 3 parameter: http_version, headers and body
    # http_version: String. The HTTP version (e.g. "HTTP/1.1")
    # headers: Headers object.
    # body: Raw bytes body.
    # __init__ of AbstractMessage class that HTTPMessage class inherits from
    msg = HTTPMessage(
        'HTTP/1.1',
        headers=(
            'content-type: text/plain\r\n'
            'content-length: 10\r\n\r\n'
        ),
        body=b'1234567890'
    )

    # create a new rawStream object
    stream = RawStream(msg)
    # call iter_body function on the rawStream object

# Generated at 2022-06-23 19:41:22.522727
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.streams import PrettyStream
    from httpie import output

    msg = HTTPMessage(
        headers=[],
        content_type='application/json',
        body=b'{"a": 1}\n{"b": 2}',
    )

    def on_body_chunk_downloaded(chunk):
        print(chunk)
    stream = PrettyStream(conversion=output.conversion,
                          formatting=output.formatting,
                          msg=msg,
                          on_body_chunk_downloaded=on_body_chunk_downloaded,
                          with_body=True,
                          with_headers=False,)
    stream.process_body(b'{"a": 1}\n{"b": 2}')

# Generated at 2022-06-23 19:41:23.644880
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    pass

# Generated at 2022-06-23 19:41:34.604947
# Unit test for constructor of class RawStream
def test_RawStream():
    # test if pass msg
    r_stream=RawStream(msg="message")
    assert r_stream.with_headers == True
    # test if pass with_headers
    r_stream=RawStream(with_headers="with_headers")
    assert r_stream.with_headers == "with_headers"
    # test if pass with_body
    r_stream=RawStream(with_body="with_body")
    assert r_stream.with_body == "with_body"
    # test if pass on_body_chunk_downloaded
    r_stream=RawStream(on_body_chunk_downloaded="on_body_chunk_downloaded")
    assert r_stream.on_body_chunk_downloaded == "on_body_chunk_downloaded"
    # test if pass chunk_size
    r

# Generated at 2022-06-23 19:41:36.740340
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 19:41:39.594206
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(headers = b'a:1\n\nb:2')
    raw = RawStream(msg)
    assert raw.get_headers() == b'a:1\n\nb:2'


# Generated at 2022-06-23 19:41:43.817620
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # check that there are 100  * 1024 * 10 bytes in the body
    b = b'0123456789' * 1024 * 10
    m = HTTPMessage('http://www.example.com', b'GET / HTTP/1.1', b'', b)
    r = RawStream(m)
    assert sum(1 for _ in r.iter_body()) == 100

# Generated at 2022-06-23 19:41:46.124783
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Given
    conversion = Conversion()
    formatting = Formatting()

    # When
    stream = PrettyStream(conversion, formatting)


# Generated at 2022-06-23 19:41:47.451857
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
  assert DataSuppressedError.message == None


# Generated at 2022-06-23 19:41:53.157335
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)
    
    import json
    with open('test.json') as f:
        data = json.load(f)
    pretty_stream = PrettyStream(data, conversion, formatting)

    for i in pretty_stream.iter_body():
        print(i)

if __name__ == '__main__':
    test_BaseStream_iter_body()

# Generated at 2022-06-23 19:41:58.420365
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    env = Environment()
    msg = HTTPMessage(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type:application/json; charset=utf8\r\n\r\n'
        '{"key": "value"}'
    )
    stream = BufferedPrettyStream(
        msg, env=env,
        conversion=Conversion(),
        formatting=Formatting()
    )
    result = ''
    for chunk in stream.iter_body():
        result += chunk.decode()
    assert result == '\n{\n    "key\''

# Generated at 2022-06-23 19:41:59.995719
# Unit test for constructor of class BaseStream
def test_BaseStream():
    assert BaseStream(object)


# Generated at 2022-06-23 19:42:06.246011
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    test_output = b'{"key1":"value1", "key2":"value2"}'
    r = RawStream(msg=HTTPMessage(BODY_RAW, 'json', 'utf-8'), with_headers=False, with_body=True)
    try:
        assert list(r.iter_body()) == [test_output]
    except Exception:
        assert False


# Generated at 2022-06-23 19:42:08.890654
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    test_stream = EncodedStream(HTTPMessage("hello world\n"))
    assert test_stream.iter_body() == {'hello world\n'}

# Generated at 2022-06-23 19:42:13.967486
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    """
    confirm that the EncodedStream class can be initialized with no errors
    """
    env = Environment()
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    stream = EncodedStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert stream is not None


# Generated at 2022-06-23 19:42:14.478269
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    pass


# Generated at 2022-06-23 19:42:19.661608
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    stream = BaseStream(msg)
    assert list(stream) == [b'', b'\r\n\r\n']

    msg = HTTPMessage()
    stream = BaseStream(msg, with_headers=False)
    assert list(stream) == []

    msg = HTTPMessage()
    stream = BaseStream(msg, with_body=False)
    assert list(stream) == [b'']


# Generated at 2022-06-23 19:42:22.184419
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
	msg = HTTPMessage(200, "test")
	stream = BufferedPrettyStream(msg)
	assert True

# Generated at 2022-06-23 19:42:29.237499
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
	testString = 'test header\r\n'
	testString += 'mime: test mime\r\n'
	testString += 'header2: test header 2\r\n'
	testString += '\r\n'
	testBytes = testString.encode('utf8')

	ps = PrettyStream(msg=HTTPMessage(), with_headers=True, with_body=False)

	assert(testBytes == ps.get_headers())


# Generated at 2022-06-23 19:42:31.271067
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    with pytest.raises(NotImplementedError):
        BaseStream.iter_body(None)



# Generated at 2022-06-23 19:42:39.219997
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.models import Header
    from httpie.input import ParseArgs
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    class FakeResponse(object):
        encoding = 'utf8'

# Generated at 2022-06-23 19:42:41.008544
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    error = DataSuppressedError()
    assert error.__str__() == "DataSuppressedError()"
    assert error.__repr__() == "DataSuppressedError()"

# Generated at 2022-06-23 19:42:42.704908
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    err = BinarySuppressedError()
    assert repr(err) == 'BinarySuppressedError()'


# Generated at 2022-06-23 19:42:48.237703
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(None, None, None, None)
    env = Environment()
    stream = EncodedStream(msg, with_headers=True, with_body=True, env=env)
    assert stream.msg == msg
    assert stream.with_headers
    assert stream.with_body
    assert stream.output_encoding == env.stdout_encoding


# Generated at 2022-06-23 19:42:55.541873
# Unit test for constructor of class RawStream
def test_RawStream():
    opt = {
        "chunk_size": 10,
        "with_headers": True,
        "with_body": True,
        "msg": HTTPMessage,
        "on_body_chunk_downloaded": "None"
    }
    rawstream = RawStream(**opt)

    res = {
        'chunk_size': 10,
        'with_headers': True,
        'with_body': True,
        'msg': HTTPMessage,
        'on_body_chunk_downloaded': None
    }
    assert res == rawstream.__dict__


# Generated at 2022-06-23 19:43:05.059756
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """
    Option: --prettify
    Prettifies the response body
    """
    import httpie
    import json
    import httpie.output.formatters.json
    import httpie.output.formatters.pretty

    # Read the whole body before prettifying it,
    # but bail out immediately if the body is binary.
    output = StringIO()
    conv = conversion.Conversion(output)
    fmt = formatting.Formatting(output)
    formatter = httpie.output.formatters.pretty.Formatter()
    formatter.format_body = lambda content, mime=None: 'test body'
    fmt.add_formatter('application/json', formatter)

    http_response = httpie.models.HTTPMessage(headers='')

# Generated at 2022-06-23 19:43:09.669363
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    import io
    reader = io.BytesIO(b"helloworld")
    msg = HTTPMessage(status_code=200,
        body=reader,
        headers={'content-type': 'application/json;charset=utf-8'},
        encoding='utf8')
    stream = EncodedStream(msg)
    assert b'helloworld' == b''.join([x for x in stream.iter_body()])

# Generated at 2022-06-23 19:43:10.648434
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError().message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-23 19:43:16.594948
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class test_HTTPMessage(HTTPMessage):
        def iter_lines(self, chunk_size) -> Iterable:
            yield b'123\r\n', b'\r\n'
            yield b'\r\n', b'\r\n'
            yield b'abc\r\n', b'\r\n'
            yield b'\r\n', b'\r\n'
        def iter_body(self, chunk_size) -> Iterable:
            yield b'123\r\n\r\nabc\r\n\r\n'

    p = EncodedStream(msg=test_HTTPMessage())
    for i, line in enumerate(p.iter_body()):
        print(line.decode('utf8'))
    assert i == 3

# Generated at 2022-06-23 19:43:21.956078
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    encoded_stream = EncodedStream(msg, with_headers, with_body)
    assert encoded_stream.msg is msg
    assert encoded_stream.with_headers is with_headers
    assert encoded_stream.with_body is with_body


# Generated at 2022-06-23 19:43:31.779183
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.compat import is_windows
    from httpie.models import Response
    from httpie.output.streams import EncodedStream
    import os

    if is_windows:
        # https://bugs.python.org/issue18282#msg215215
        from colorama import init

        init()
    # body in UTF-8
    body = u'{ "args": { "foo": "bar" }, "data": "", "files": {} }'.encode('utf8')
    # encode the body into bytes
    body_bytes = body.encode('utf8')
    # create a new response
    response = Response(body=body)
    # create an instance of EncodedStream
    stream = EncodedStream(msg=response)
    # create an iterator over body
    stream_iter = stream.iter_body()

# Generated at 2022-06-23 19:43:33.436858
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    message = 'message'
    BinarySuppressedError(message)

# Generated at 2022-06-23 19:43:38.301193
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.context import Environment
    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)
    stream = PrettyStream(conversion=conversion,
                          formatting=formatting,
                          msg=None,
                          with_headers=True,
                          with_body=True)

    # do not change the string to bytes:
    test_string = "the quick brown fox jumped over the lazy dog"
    formatted_string = stream.process_body(test_string)
    assert isinstance(formatted_string, bytes)
    assert conversion is not None
    assert formatting is not None

# Generated at 2022-06-23 19:43:45.344374
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(headers='', body='')
    stream = BaseStream(msg=msg, with_headers=True)
    assert stream.msg == msg
    assert stream.with_headers
    assert not hasattr(stream, 'with_body')
    assert not hasattr(stream, 'on_body_chunk_downloaded')


# Generated at 2022-06-23 19:43:55.959263
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import os
    import pytest
    import requests
    import json

    # Test file
    url = 'https://httpbin.org/post'
    test_file_path = os.path.dirname(os.path.realpath(__file__)) + "/test.png"
    test_file_mimetype = "image/png"
    test_file_basename = "test.png"
    expected_result = "\"content-type\": \"image/png\""
    result = "not found"

    # Create data for the request
    data = {'file': (test_file_basename, open(test_file_path, 'rb'), test_file_mimetype)}

    # Send request
    response = requests.post(url, files=data)

    # Get iterator of the result
    stream = Buff

# Generated at 2022-06-23 19:43:56.710911
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    d = DataSuppressedError()
    d.message = '123'
    assert d.message == '123'

# Generated at 2022-06-23 19:44:03.400970
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import httpie.models

    class TestStream(BaseStream):
        def get_headers(self) -> bytes:
            raise Exception('Do not call')

        def iter_body(self) -> Iterable[bytes]:
            raise Exception('Do not call')

    class Response(httpie.models.HTTPResponse):
        def __init__(self, headers=None, body_bytes=None):
            self.headers = headers
            self._body_bytes = body_bytes

        def iter_body(self, chunk_size=1024):
            for chunk in self._body_bytes:
                yield chunk

    msg = Response(
        headers='header1: value1\nheader2: value2',
        body_bytes=['chunk1\n', 'chunk2\n'],
    )

# Generated at 2022-06-23 19:44:08.218514
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    assert BaseStream(msg=HTTPMessage(content_type="application/json")).get_headers() == b"Content-Type: application/json\n"


# Generated at 2022-06-23 19:44:12.973525
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage()
    msg.headers = 'this is a test'
    stream = BaseStream(msg)
    assert stream.get_headers() == b'this is a test'



# Unit tests for method iter_body of class RawStream

# Generated at 2022-06-23 19:44:21.272244
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(headers="""\
Host: httpbin.org
User-Agent: HTTPie/0.9.9
Accept-Encoding: gzip, deflate, compress
Accept: */*
Connection: keep-alive

""", body="hello world".encode())

    with_headers=True
    with_body=True
    on_body_chunk_downloaded="not filled"
    b = BaseStream(msg, with_headers, with_body)
    assert b.msg == msg
    assert b.with_headers == with_headers
    assert b.with_body == with_body
    #assert b.on_body_chunk_downloaded == on_body_chunk_downloaded


# Generated at 2022-06-23 19:44:28.467560
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():  
    
    msg = HTTPMessage()
    msg.headers = u'HTTP/1.1 200 OK\n...'
    msg.url = u'http://127.0.0.1'
    msg.data = 'body'

    stream = BufferedPrettyStream(msg, 1, 1, 0)
    body = next(iter(stream))
    print('body = ' + body)


if __name__ == '__main__':
    test_BufferedPrettyStream_iter_body()

# Generated at 2022-06-23 19:44:39.229537
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Below test depends on the parsing of URL by the method which is not
    # testable by unittest
    # testing_message_url = "https://www.facebook.com/ca7vienngocrau/"
    testing_message_headers = "Content-Type: image/jpeg"

# Generated at 2022-06-23 19:44:40.712815
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    pass


# Generated at 2022-06-23 19:44:51.272912
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    import httpie
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import Conversion
    from httpie.output.streams import Formatting

    from httpie.context import Environment
    from httpie.models import HTTPMessage

    env = Environment()
    conversion = Conversion(env=env)
    formatting = Formatting(env=env)

    response = HTTPMessage()
    response.from_http('HTTP/1.1 200 OK\r\nContent-Length: 14\r\n\r\nHello World!!!!')

    # print("response.headers:", response.headers)

    stream = BufferedPrettyStream(
        msg=response,
        conversion=conversion,
        formatting=formatting,
        with_headers=True,
        with_body=True,
    )

# Generated at 2022-06-23 19:44:53.342903
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers={'Content-Type': 'image/gif'}, body=b'\x01' * 20)
    s = EncodedStream(msg=msg, with_headers=False)
    assert list(s.iter_body()) == [b'\n' + BINARY_SUPPRESSED_NOTICE]

# Generated at 2022-06-23 19:45:00.424358
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import sys
    import os
    import json
    import inspect
    import json

    #Load the data that IS the reference answer
    with open('ref_output_searches_by_context', 'r') as myfile:
        data=myfile.read()
    data_txt = data.strip('\n').split('---')[1:]


    #Load the output file that should match the reference file
    with open('test_output_searches_by_context', 'r') as myfile:
        test=myfile.read()
    test_txt = test.strip('\n').split('---')[1:]
    # Compare the two
    text_len_diff = []
    maxlen = 0

# Generated at 2022-06-23 19:45:11.788528
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from io import BytesIO

    env = Environment(stdout_isatty=False)

    bs = RawStream(msg=HTTPResponse(
        url='http://www.example.com',
        headers={},
        body=BytesIO(b'test'),
    ))
    assert [chunk.decode('utf-8') for chunk in bs.iter_body()] == ['test']
    assert bs.get_headers() == b''

    es = EncodedStream(
        msg=HTTPResponse(
            url='http://www.example.com',
            headers={},
            body=BytesIO(b"\xc2\xa9")
        ),
    )

# Generated at 2022-06-23 19:45:20.475718
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(headers="""HTTP/1.1 200 OK
Date: Thu, 08 Oct 2020 04:09:40 GMT
Content-Type: text/plain; charset=utf-8
Content-Length: 23
Connection: keep-alive
Keep-Alive: timeout=30
Set-Cookie: ab=xx

""")
    stream = BaseStream(msg=msg)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\nDate: Thu, 08 Oct 2020 04:09:40 GMT\nContent-Type: text/plain; charset=utf-8\nContent-Length: 23\nConnection: keep-alive\nKeep-Alive: timeout=30\nSet-Cookie: ab=xx\n\n'


# Generated at 2022-06-23 19:45:22.409967
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    dse = DataSuppressedError()
    assert dse.message is None


# Generated at 2022-06-23 19:45:24.349248
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    #1. Initialize the testing envrionment
    pass
    #2. use expeted value and actual value to test

# Generated at 2022-06-23 19:45:31.577541
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():

    def get_headers():
        msg = HTTPMessage(headers=TestRawStream.headers, status_line='', body='')
        return PrettyStream(msg=msg, with_headers=True, with_body=False).get_headers().decode()

    assert get_headers() == 'Accept: */*\x1b[0m\nAccept-Encoding: gzip, deflate\x1b[0m\nHost: 127.0.0.1:8080\x1b[0m\n'



# Generated at 2022-06-23 19:45:38.376697
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Create an instance of class BufferedPrettyStream
    download = BufferedPrettyStream(
        msg=HTTPMessage(
            content_type='text',
            headers=[],
            body=b"Hello\nWorld"
        ),
        env=Environment(),
        conversion=Conversion(),
        formatting=Formatting()
    )
    # Unit tests
    assert list(download) == [b'Hello\nWorld']
    assert str(download.msg) == 'Hello World'


# Generated at 2022-06-23 19:45:47.038076
# Unit test for constructor of class BaseStream
def test_BaseStream():
    # Set some arbitary strings/bytes as HTTPMessage's attributes
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.body = 'body'
    msg.headers = 'headers'
    msg.status_line = 'status'
    stream = EncodedStream(msg)

    # Tests for get_headers()
    assert stream.get_headers() == 'headers'.encode('utf8')

    # Tests for iter_body()
    assert list(stream.iter_body()) == ['body'.encode('utf8', 'replace')]

# Generated at 2022-06-23 19:45:58.777789
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    def test_iter_body(http_messages):
        for http_message in http_messages():
            is_binary = http_message.is_binary_content()
            if is_binary:
                raw_stream_body = ""
                raw_stream_body_chunks = 0
                try:
                    for chunk in RawStream(http_message).iter_body():
                        raw_stream_body_chunks += 1
                        raw_stream_body += chunk.decode('utf-8', 'replace')
                except BinarySuppressedError:
                    pass
                else:
                    assert False, "BinarySuppressedError not raised."
                assert raw_stream_body_chunks > 0, "Body chunks not processed."

            encoded_stream_body = ""
            raw_stream_body_chunks = 0

# Generated at 2022-06-23 19:46:04.758489
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    stream = RawStream(msg, True, True)
    assert stream.with_headers
    assert stream.with_body
    assert stream.on_body_chunk_downloaded == None
    stream = RawStream(msg, with_headers=False, with_body=False)
    assert not stream.with_headers
    assert not stream.with_body
    assert stream.on_body_chunk_downloaded == None
    stream = RawStream(msg, True, False)
    assert stream.with_headers
    assert not stream.with_body
    assert stream.on_body_chunk_downloaded == None
    print('Test "RawStream" constructor passed.')


# Generated at 2022-06-23 19:46:15.602745
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json

    class Env:
        def __init__(self):
            self.stdout_isatty = False
            self.stdout_encoding = 'utf8'
            self.output_options = {'format': 'json'}

    class Formatting:
        @classmethod
        def format_headers(cls, headers):
            return '{}'.format(headers)

        @classmethod
        def format_body(cls, content, mime):
            return '{}'.format(content)

    class Conversion:
        @classmethod
        def get_converter(cls, mime):
            if mime == 'application/json':
                json_converter = Conversion.JsonConverter()
                return json_converter
            return None


# Generated at 2022-06-23 19:46:22.499235
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    data = b'1234567890' + b'\0' + b'123' + b'\0' + b'4567'
    msg = HTTPMessage(
        content_type='application/json',
        headers=['Content-Type: application/json'],
        body=data,
    )
    stream = BufferedPrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
    )
    assert stream.process_body(data) == b'1234567890'

# Generated at 2022-06-23 19:46:27.681568
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    def on_body_chunk_downloaded(chunk):
        pass

    msg = HTTPMessage()
    with_headers = True
    with_body = True
    BaseStream(msg,with_headers,with_body,on_body_chunk_downloaded)


test_BaseStream_iter_body()

# Generated at 2022-06-23 19:46:31.430628
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():

    headers = [{"Content-Type":"application/json"}]
    body = {"hello": "world"}
    msg = HTTPMessage(headers,body)

    ob1 = BufferedPrettyStream(msg)

# Generated at 2022-06-23 19:46:34.110874
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    print('Test BinarySuppressedError constructor ...')
    try:
        raise BinarySuppressedError()
    except Exception as e:
        print(type(e))


# Generated at 2022-06-23 19:46:42.400728
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage.from_string(
        """HTTP/1.1 200 OK\r\n"""
        """Server: nginx/1.14.1\r\n"""
        """Content-Type: application/json; charset=utf-8\r\n\r\n""")
    stream = BaseStream(msg)
    assert stream.get_headers() == b"""Server: nginx/1.14.1\r\n"""\
                                    b"""Content-Type: application/json; charset=utf-8\r\n"""



# Generated at 2022-06-23 19:46:49.573317
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(None, b'\x00abc\n', content_type='text/plain')
    with pytest.raises(BinarySuppressedError):
        for _ in EncodedStream(msg, with_headers=False, with_body=True):
            pass
    for l in EncodedStream(msg, with_headers=False, with_body=True, env=Environment(stdout_isatty=False)):
        assert l == b'\x00abc\n'
    for l in EncodedStream(msg, with_headers=False, with_body=True, env=Environment(stdout_isatty=False, stdout_encoding='ascii')):
        assert l == b'\x00abc\n'

# Generated at 2022-06-23 19:46:53.734449
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie.compat import is_windows
    from httpie.models import HTTPMessage
    from httpie.output.streams import EncodedStream, RawStream, PrettyStream, BufferedPrettyStream
    from httpie.output.formatters import JSONFormatter, Formatter
    from httpie.output.decoders import Decoder
    from httpie.output.converters import Converter, JSONConverter
    msg = HTTPMessage(content_type='application/json', body='[1, 2, 3]')
    env = Environment()
    env.stdout_isatty = True
    chunk_size1 = 10
    chunk_size2 = 1024
    # Test RawStream
    Test1 = RawStream(msg, chunk_size=chunk_size1)
    assert isinstance(Test1, RawStream)
    #

# Generated at 2022-06-23 19:46:59.744857
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Init a message
    msg = HTTPMessage(method='GET', url='http://address/', headers=[('a', 'b'), ('c', 'd')], body='body')
    # Init a stream
    stream = EncodedStream(msg)
    # Assert type
    assert isinstance(stream, HTTPMessage)
    # Assert HEAD
    assert stream.msg.method == 'GET'
    # Assert URL
    assert stream.msg.url.raw_value == 'http://address/'
    # Assert Headers
    assert stream.msg.headers == [('a', 'b'), ('c', 'd')]
    # Assert Body
    assert stream.msg.body == 'body'

# Generated at 2022-06-23 19:47:03.166280
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    stream = BaseStream(msg)
    assert stream.msg is msg
    assert stream.with_headers is True
    assert stream.with_body is True

# Generated at 2022-06-23 19:47:10.793468
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    """
    Unit test for method PrettyStream.process_body()
    """
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import ConsoleFormatter
    from httpie.output.formatters import format_formatter_valid_mime
    from httpie.compat import is_windows
    from httpie.context import Environment 

    import io

    http_message = HTTPMessage()
    http_message.encoding = 'utf8'
    http_message.content_type = 'application/json'

    # test the scenario when body is a string
    pretty_stream = PrettyStream(None, JSONFormatter(), msg=http_message, env=Environment())

# Generated at 2022-06-23 19:47:13.968442
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    line = b'Content-Type: application/json\r\n\r\n'
    msg = HTTPMessage(line)
    stream = RawStream(msg, with_headers=True, with_body=False)

    assert line == next(stream.iter_body())


# Generated at 2022-06-23 19:47:18.403054
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    env = Environment()
    stream = PrettyStream(
        conversion=Conversion(),
        formatting=Formatting(),
        msg=HTTPMessage(None, None, None, 'application/json', None, None),
        env=env)
    stream.get_headers = lambda : b'{"a": 1}'
    headers = stream.iter_body()
    assert next(headers) == b'a = 1'
    try:
        next(headers)
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-23 19:47:21.902089
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Arrange
    body = ('first line\r\n'
            'second line\r\n'
            'third line\r\n'
            'fourth line')
    # Act
    actual = BufferedPrettyStream(with_headers=True, with_body=True)
    # Assert
    assert actual is not None

# Generated at 2022-06-23 19:47:30.464821
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    '''def iter_body(self) -> Iterable[bytes]:
        return body

    :return:
    '''
    headers, body = encode_headers_and_body(b'0123456789')
    msg = HTTPMessage(headers=headers, body=body)
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    result = b''
    for part in stream.iter_body():
        result += part

    print(result)
    if result == b'0123456789':
        print("iter_body() test pass")
    else:
        print("iter_body() test fail")

# Generated at 2022-06-23 19:47:40.637184
# Unit test for constructor of class BaseStream
def test_BaseStream():
    class DummyHTTPMessage(HTTPMessage):
        """
        Dummy class to represent HTTPMessage

        Attributes
        ----------
        headers : bytes
            bytes with "Dummy headers"
        chunks : list
            list of bytes chunks with "Dummy body"

        """
        headers = b'Dummy headers'
        chunks = [b'Dummy body']

    # All arguments are set to True
    dummy_stream_1 = BaseStream(DummyHTTPMessage(), True, True)
    assert dummy_stream_1.with_headers == True
    assert dummy_stream_1.with_body == True

    # with_headers is set to False
    dummy_stream_2 = BaseStream(DummyHTTPMessage(), False, True)
    assert dummy_stream_2.with_headers == False
    assert dummy

# Generated at 2022-06-23 19:47:44.913855
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    res = {'content':'{ "name": "john" }'}
    msg = HTTPMessage(**res)
    rs = RawStream(msg)
    body = rs.iter_body()
    if isinstance(body, Iterable):
        for b in body:
            print(b)
    else:
        print(b)


# Generated at 2022-06-23 19:47:50.979283
# Unit test for constructor of class BaseStream
def test_BaseStream():
    print("Testing constructor of class BaseStream...", end='')

    # Test when headers are to be included
    msg = HTTPMessage('content-type')
    stream = BaseStream(
        msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )

    assert stream.msg == msg
    assert stream.with_headers
    assert stream.with_body
    assert stream.on_body_chunk_downloaded is None

    # Test when body is to be included
    stream = BaseStream(
        msg,
        with_headers=False,
        with_body=True,
        on_body_chunk_downloaded=None
    )

    assert stream.msg == msg
    assert not stream.with_headers
    assert stream.with_body

# Generated at 2022-06-23 19:47:56.810899
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(request_type='GET', url='http://www.google.com')
    msg.headers['Content-Type'] = 'text/html'
    rs = RawStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert isinstance(rs, RawStream)


# Generated at 2022-06-23 19:48:02.462588
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    excpt = BinarySuppressedError.message
    assert excpt == (b'\n' + b'+-----------------------------------------+\n' +
                     b'| NOTE: binary data not shown in terminal |\n' +
                     b'+-----------------------------------------+')


if __name__ == "__main__":
    test_BinarySuppressedError()

# Generated at 2022-06-23 19:48:03.284689
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError().message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-23 19:48:05.011096
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    a = PrettyStream(Conversion(), Formatting())
    assert a


# Generated at 2022-06-23 19:48:10.052670
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
	#test on constructor with default value
	test = EncodedStream(with_headers=True, with_body=True, msg = HTTPMessage())
	#test on constructor with multiple input
	test = EncodedStream(with_headers=True, with_body=True, msg = HTTPMessage(), env = Environment(), CHUNK_SIZE = 1)
	

# Generated at 2022-06-23 19:48:11.963893
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Create object for class EncodedStream
    obj = EncodedStream(msg = HTTPMessage())
    assert obj
    return


# Generated at 2022-06-23 19:48:22.758572
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    msg.headers = 'test_headers'
    msg.iter_body = lambda chunk: 'test_body'

    # Test case 1
    msg1 = BaseStream(msg = msg)
    assert msg1.with_headers == True
    assert msg1.with_body == True
    assert msg1.get_headers() == 'test_headers'.encode('utf8')
    assert msg1.iter_body() == 'test_body'
    assert msg1.on_body_chunk_downloaded == None

    # Test case 2
    msg2 = BaseStream(msg = msg, with_headers = False)
    assert msg2.with_headers == False
    assert msg2.with_body == True
    assert msg2.get_headers() == 'test_headers'.encode('utf8')


# Generated at 2022-06-23 19:48:28.423979
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={'Content-Type':'text/html; charset=utf-8'})
    ps = PrettyStream(msg, conversion=None, formatting=None)
    def get_headers():
        assert ps.get_headers() == b'Content-Type: text/html; charset=utf-8\n'
    get_headers()

# Generated at 2022-06-23 19:48:39.136748
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    p = PrettyStream(env = env, conversion = conversion,formatting = formatting)
    chunk = b'\x82\xB3\x82\xEA\x82\xCD\x30\x30\x30\x30\x30\x30\x30\x30\x30\x30'
    chunk_expect = u'\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD'
    result = p.process_body(chunk)

# Generated at 2022-06-23 19:48:40.543979
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    import pdb; pdb.set_trace()
    pass



# Generated at 2022-06-23 19:48:50.074174
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test with_body and with_headers for a HTTP response
    response = HTTPMessage(message='ok', headers=b'HTTP/1.1 200 OK\r\n\r\n')
    stream = BaseStream(msg=response, with_headers=True, with_body=True)
    body_stream = stream.__iter__()
    assert next(body_stream) == b'HTTP/1.1 200 OK\r\n\r\n\r\n\r\n'
    assert next(body_stream) == b'ok'

    stream = BaseStream(msg=response, with_headers=True, with_body=False)
    body_stream = stream.__iter__()

# Generated at 2022-06-23 19:49:00.776393
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    from httpie.core import main
    from httpie.compat import str
    from httpie.utils import decode_raw_lines
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from httpie.output.writers import get_writer
    from httpie.status import ExitStatus

    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    message = HTTPResponse()
    stream = EncodedStream(msg=message)
    print(stream)



# Generated at 2022-06-23 19:49:03.523532
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(headers='Content-type: test')
    conversion = Conversion()
    formatting = Formatting()
    p_stream = PrettyStream(msg, conversion = conversion, formatting = formatting)
    assert str(p_stream.conversion) == str(conversion)
    assert str(p_stream.formatting) == str(formatting)
    assert str(p_stream.mime) == 'test'
    assert str(p_stream.output_encoding) == 'utf8'

# Generated at 2022-06-23 19:49:08.937293
# Unit test for constructor of class BaseStream
def test_BaseStream():
    # Environment()
    msg = HTTPMessage(Environment())
    msg.headers = u'HTTP/1.1'
    msg.body = u'test'
    msg.encoding = 'test'
    BaseStream(msg)

# Generated at 2022-06-23 19:49:18.866098
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(headers='', encoding='test', content_type='test')
    stream = PrettyStream(msg, conversion='conversion', formatting='formatting')
    # Test for chunk is bytes
    chunk = b'chunk'
    assert stream.process_body(chunk) == b'chunk'
    # Test for chunk is str
    chunk = 'chunk'
    import unittest.mock
    with unittest.mock.patch('httpie.output.streams.PrettyStream.formatting.format_body') as mock_format_body:
        stream.process_body(chunk)
        assert mock_format_body.called
        mock_format_body.assert_called_with(content=chunk, mime=stream.mime)

# Generated at 2022-06-23 19:49:22.447107
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/json\r\n'
                              b'Content-Length: 12\r\n',
                      body=b'{ "a": "b" }\n',
                      encoding='utf8')
    print(next(EncodedStream(msg).iter_body()))


# Generated at 2022-06-23 19:49:23.952302
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raw_stream = RawStream(None)
        assert raw_stream != None
    except Exception:
        assert False



# Generated at 2022-06-23 19:49:26.804372
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = EncodedStream()
    print("msg.output_encoding: ", msg.output_encoding)


if __name__ == "__main__":
    # test_EncodedStream()
    pass

# Generated at 2022-06-23 19:49:32.177236
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    # Intialize the class and test it
    exception = BinarySuppressedError()
    exception.message = BINARY_SUPPRESSED_NOTICE
    assert exception.message == BINARY_SUPPRESSED_NOTICE, 'Error in intializing binary suppressed error'
    # Print the exception message
    print(exception.message)


# Generated at 2022-06-23 19:49:40.170539
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    def on_body_chunk_downloaded(chunk: bytes):
        assert chunk == b'example_data\n'

    msg = HTTPMessage()
    msg.set_body(b'example_data\n', 'text/html')
    stream = BufferedPrettyStream(msg, with_headers=False, with_body=True, on_body_chunk_downloaded=on_body_chunk_downloaded)

    body_content = b''
    for chunk in stream.iter_body():
        body_content += chunk

    assert body_content == (
        b'<div class="body-line"><a href="example_data">'
        b'example_data</a></div>\n'
    )

# Generated at 2022-06-23 19:49:50.208134
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert issubclass(BinarySuppressedError, Exception)
    assert str(BinarySuppressedError) == "BinarySuppressedError"
    assert repr(BinarySuppressedError) == "BinarySuppressedError"
    assert BinarySuppressedError.message == (b'\n'
                                             b'+-----------------------------------------+\n'
                                             b'| NOTE: binary data not shown in terminal |\n'
                                             b'+-----------------------------------------+')
    assert str(BinarySuppressedError()) == "Exception has been thrown"
    assert repr(BinarySuppressedError()) == "BinarySuppressedError()"
    # Should not change the value of the static message
    BinarySuppressedError().message = "Binary message"

# Generated at 2022-06-23 19:49:51.627916
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    Stream = EncodedStream()
    assert Stream.CHUNK_SIZE == 1
    assert Stream.msg


# Generated at 2022-06-23 19:49:54.041296
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    bp = BufferedPrettyStream(object(),object(),object(),object())
    assert bp.msg.status_code == None
    assert bp.msg.headers == None
    assert bp.msg.encoding == None


# Generated at 2022-06-23 19:49:59.868981
# Unit test for constructor of class RawStream
def test_RawStream():
    # declare two data types, message comes from HTTPMessage
    message = HTTPMessage(
        'example.org',
        80,
        'GET',
        '/',
        headers=None,
        content_type='application/json',
        body=b'msg body',
        encoding='utf-8',
        timestamp_start=None,
        timestamp_end=None
    )
    # env comes from Environment()
    env = Environment()
    # declare a variable for argument chunk_size
    chunk_size = 1024
    # instantiate object of RawStream
    rawStream = RawStream(chunk_size=chunk_size, msg=message)
    # call the method iter_body()
    # the code below iterates over the message body output
    for chunk in rawStream.iter_body():
        print(chunk)

# Generated at 2022-06-23 19:50:10.386847
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import httpie
    default = httpie.DEFAULT_OPTIONS
    env = httpie.Environment(**default)
    config = httpie.Config(**default)
    response_headers = httpie.models.Headers(b'content-type: application/json')
    body = b'[\n    1,\n    2,\n    3\n]'
    http_message = httpie.models.HTTPMessage(
        response_headers,
        body,
        config,
        env,
    )
    stream = PrettyStream(
        conversion=httpie.output.processing.Conversion(),
        formatting=httpie.output.formatting.Formatter(),
        msg=http_message,
    )
    res = []
    for i in stream.iter_body():
        res.append(i)
   

# Generated at 2022-06-23 19:50:13.882961
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(content_type='application/json')
    stream = PrettyStream(msg=msg, conversion=Conversion(), formatting=Formatting())
    assert type(stream) == PrettyStream
    assert stream.msg == msg
    assert type(stream.output_encoding) == str
    assert type(stream.mime) == str


# Generated at 2022-06-23 19:50:20.440601
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    env = Environment()
    conversion = Conversion(env=env)
    formatting = Formatting(env=env)
    msg = HTTPMessage(content_type='application/json', encoding='utf-8')
    msg.body = "hello world!\n"
    msg.content_length = 13
    bps = BufferedPrettyStream(conversion = conversion, formatting = formatting, msg = msg)
    print(f"length of first chunk: {len(next(bps.iter_body()))}")