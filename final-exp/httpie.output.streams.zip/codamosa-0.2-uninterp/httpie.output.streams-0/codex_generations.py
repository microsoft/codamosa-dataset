

# Generated at 2022-06-17 20:46:03.699752
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:46:14.816764
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:46:22.608837
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    msg = Response(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: application/json',
        body=b'{"a": "b"}',
        encoding='utf8'
    )
    stream = BufferedPrettyStream(
        msg=msg,
        env=env,
        conversion=conversion,
        formatting=formatting,
        with_headers=True,
        with_body=True
    )

# Generated at 2022-06-17 20:46:34.119483
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test case 1
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n',
                      body=b'<html><body>Hello World</body></html>')
    stream = EncodedStream(msg=msg, with_headers=True, with_body=True)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.output_encoding == 'utf8'
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    assert list(stream.iter_body()) == [b'<html><body>Hello World</body></html>']
   

# Generated at 2022-06-17 20:46:41.802866
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    headers = Headers(headers={'Content-Type': 'application/json'})
    stream = PrettyStream(msg=None, with_headers=True, with_body=True, headers=headers)
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'


# Generated at 2022-06-17 20:46:51.182328
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import pytest
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPResponse(
        b'HTTP/1.1 200 OK\r\n'
        b'Content-Type: text/plain; charset=utf-8\r\n'
        b'\r\n'
        b'\u2713',
        encoding='utf8'
    )
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting)
    assert list(stream.iter_body()) == [b'\xe2\x9c\x93']


# Generated at 2022-06-17 20:47:02.254901
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.plugins import builtin

    conversion = Conversion()
    conversion.register(builtin.JSONConverter())
    formatting = Formatting()
    formatting.register(JSONFormatter())
    formatting.register(TerminalFormatter(get_lexer()))


# Generated at 2022-06-17 20:47:13.268231
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:47:24.391247
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    import json

    # test case 1:
    #   - body is not binary
    #   - body is not json
    #   - body is not empty
    #   - body is not None
    #   - body is not a list
    #   - body is not a dict
    #   - body is not a tuple
    #   - body is not a set
    #   - body is not a string
    #   - body is not a number
    #   - body is not a boolean
    #   - body is not a None
    #   - body is not a datetime
    #   - body is not a date
    #   - body is not a time
   

# Generated at 2022-06-17 20:47:36.292916
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.processing import Conversion, Formatting

    class TestResponse(HTTPResponse):
        def __init__(self, body, headers=None, encoding='utf8'):
            super().__init__(
                http_version='1.1',
                status_code=200,
                headers=headers or {},
                body=body,
                encoding=encoding,
            )

    def test(body, headers, expected):
        response = TestResponse(body, headers)

# Generated at 2022-06-17 20:48:00.869909
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(
        'HTTP/1.1 200 OK',
        headers=CaseInsensitiveDict({'Content-Type': 'application/json'}),
        body=b'{"a": 1, "b": 2}\n{"a": 3, "b": 4}\n',
        encoding='utf8'
    )
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert list(stream.iter_body()) == [
        b'{\n',
        b'    "a": 1,\n',
        b'    "b": 2\n',
        b'}\n',
        b'{\n',
        b'    "a": 3,\n',
        b'    "b": 4\n',
        b'}\n'
    ]

# Generated at 2022-06-17 20:48:12.473433
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.utils import get_response
    from httpie.compat import urlopen

    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_

# Generated at 2022-06-17 20:48:17.714786
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE


# Generated at 2022-06-17 20:48:28.535482
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py2
    from httpie.compat import is_py3
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37

# Generated at 2022-06-17 20:48:37.939930
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'abcdefghijklmnopqrstuvwxyz')
    stream = RawStream(msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'abcdefghijklmnopqrstuvwxyz']
    stream = RawStream(msg, with_headers=False, with_body=True, chunk_size=5)
    assert list(stream.iter_body()) == [b'abcde', b'fghij', b'klmno', b'pqrst', b'uvwxy', b'z']
    stream = RawStream(msg, with_headers=False, with_body=True, chunk_size=10)

# Generated at 2022-06-17 20:48:48.285586
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37

# Generated at 2022-06-17 20:48:59.431259
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import urlopen

    response = urlopen('https://httpbin.org/get')
    response = HTTPResponse(response)
    conversion = Conversion()
    formatting = Formatting(get_lexer('json', None))
    stream = BufferedPrettyStream(response, conversion=conversion, formatting=formatting)
    for chunk in stream.iter_body():
        print(chunk)


# Generated at 2022-06-17 20:49:07.443556
# Unit test for constructor of class RawStream

# Generated at 2022-06-17 20:49:15.828182
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.formatters.utils import get_converter
    from httpie.output.formatters.utils import get_format_style_for_content_type
    from httpie.output.formatters.utils import get_format_style_for_prettifier
    from httpie.output.formatters.utils import get_format_style_for_lexer


# Generated at 2022-06-17 20:49:19.019782
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n\r\n')
    stream = EncodedStream(msg)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:49:45.892562
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:49:51.459177
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'abcdefghijklmnopqrstuvwxyz')
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b'abcdefghijklmnopqrstuvwxyz']


# Generated at 2022-06-17 20:50:00.456749
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1:
    # chunk is a string
    # mime is a string
    # output_encoding is a string
    # formatting is a Formatting
    # conversion is a Conversion
    # msg is a HTTPMessage
    # with_headers is a boolean
    # with_body is a boolean
    # on_body_chunk_downloaded is a function
    # env is a Environment
    # expected is a bytes
    chunk = '{"a":1}'
    mime = 'application/json'
    output_encoding = 'utf8'

# Generated at 2022-06-17 20:50:10.028534
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import stream_raw_bodies

    response = Response(
        headers={'Content-Type': 'application/json'},
        status_code=200,
        reason='OK',
        body=b'{"a": 1, "b": 2}'
    )

    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_

# Generated at 2022-06-17 20:50:18.406440
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'

# Generated at 2022-06-17 20:50:26.643508
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.output.formatters.utils import get_prettifier
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments.styles import get_style_by_name
    from httpie.context import Environment
    env = Environment()
    conversion = Conversion()

# Generated at 2022-06-17 20:50:36.622640
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.models
    import httpie.compat
    import httpie.context
    import httpie.cli
    import httpie.plugins
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams

# Generated at 2022-06-17 20:50:46.739282
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError

    # Test for method __iter__ of class BaseStream

# Generated at 2022-06-17 20:50:54.935707
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion

# Generated at 2022-06-17 20:50:59.199277
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body=b'{"name": "test"}')
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'
    assert list(stream.iter_body()) == [b'{\n    "name": "test"\n}\n']


# Generated at 2022-06-17 20:51:46.415575
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    msg = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=b'{"a": "b"}',
        encoding='utf8'
    )

    stream = BufferedPrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
    )

    assert b'{\n    "a": "b"\n}' == b''.join(stream.iter_body())

# Generated at 2022-06-17 20:51:59.782131
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen
    from httpie.status import ExitStatus
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.exceptions import ParseError
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.context import Context
    from httpie.cli.config import Config
    from httpie.cli.output import OutputOptions
    from httpie.cli.output.streams import RawStream
    from httpie.cli.output.streams import PrettyStream
    from httpie.cli.output.streams import BufferedPrettyStream
    from httpie.cli.output.streams import Enc

# Generated at 2022-06-17 20:52:09.805954
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-17 20:52:13.883598
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "text/plain"})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: text/plain\n'

# Generated at 2022-06-17 20:52:23.442800
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test with_headers and with_body
    msg = HTTPMessage(headers=b'foo: bar', body=b'baz')
    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert list(stream) == [b'foo: bar', b'\r\n\r\n', b'baz']

    # Test with_headers and not with_body
    msg = HTTPMessage(headers=b'foo: bar', body=b'baz')
    stream = BaseStream(msg, with_headers=True, with_body=False)
    assert list(stream) == [b'foo: bar', b'\r\n\r\n']

    # Test not with_headers and with_body

# Generated at 2022-06-17 20:52:32.735816
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class MockHTTPMessage(HTTPMessage):
        def __init__(self, content_type, body):
            self.content_type = content_type
            self.body = body

        def iter_body(self, chunk_size):
            for i in range(0, len(self.body), chunk_size):
                yield self.body[i:i+chunk_size]

    class MockConversion:
        def get_converter(self, mime):
            if mime == 'application/json':
                return MockConverter()
            return None

    class MockConverter:
        def convert(self, body):
            return 'application/json', body.decode('utf-8')

    class MockFormatting:
        def format_body(self, content, mime):
            return content

   

# Generated at 2022-06-17 20:52:39.826439
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x87\x92\r\n']


# Generated at 2022-06-17 20:52:48.134250
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from pygments.lexers import HtmlLexer
    from pygments.lexers import XmlLexer
    from pygments.lexers import JavascriptLexer
    from pygments.lexers import CssLexer
    from pygments.lexers import PythonLexer
    from pygments.lexers import Python3Lexer

# Generated at 2022-06-17 20:53:00.033970
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test for constructor of class EncodedStream
    # Arrange
    msg = HTTPMessage()
    msg.headers = 'headers'
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    # Act
    stream = EncodedStream(msg, env=env)
    # Assert
    assert stream.msg == msg
    assert stream.output_encoding == 'utf8'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:53:11.197636
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_style

    class MockConversion(Conversion):
        def get_converter(self, mime):
            return None

    class MockFormatting(Formatting):
        def __init__(self):
            self.json_formatter = JSONFormatter(get_lexer('json'), get_style())

        def format_body(self, content, mime):
            return self.json_formatter.format_body(content, mime)

    response

# Generated at 2022-06-17 20:54:32.800531
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = "headers"
    msg.encoding = "utf8"
    msg.iter_body = lambda x: "body"
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == "utf8"


# Generated at 2022-06-17 20:54:40.689461
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.compat import urlopen
    from httpie.downloads import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream

# Generated at 2022-06-17 20:54:50.125170
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers='''HTTP/1.1 200 OK
Date: Fri, 23 Aug 2019 15:01:10 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Fri, 23 Aug 2019 15:01:10 GMT
ETag: "2d-58a0a0b9a9b00"
Accept-Ranges: bytes
Content-Length: 45
Content-Type: text/html

''')

# Generated at 2022-06-17 20:55:00.640997
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body=b'{"name": "John Doe"}'
    )
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.mime == "application/json"
    assert stream.output_encoding == "utf8"
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.formatting == Formatting()
    assert stream.conversion == Conversion()


# Generated at 2022-06-17 20:55:10.698689
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    import json
    import pytest

    env = Environment()
    msg = HTTPMessage(headers={'content-type': 'application/json'},
                      body=json.dumps({'foo': 'bar'}))
    stream = PrettyStream(msg=msg, env=env,
                          conversion=Conversion(),
                          formatting=Formatting())
    assert stream.process_body(msg.body) == b'{\n    "foo": "bar"\n}\n'

# Generated at 2022-06-17 20:55:17.541696
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Content-Length: 11

'''
    msg.body = 'Hello world'
    msg.encoding = 'utf-8'
    msg.content_type = 'text/plain; charset=utf-8'
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 11\r\n\r\n'
    assert list(stream.iter_body()) == [b'Hello world']

# Generated at 2022-06-17 20:55:23.383354
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers={"Content-Type": "text/plain"},
        body=b"abcdefghijklmnopqrstuvwxyz",
    )
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b"abcdefghijklmnopqrstuvwxyz"]


# Generated at 2022-06-17 20:55:32.611398
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer

    env = Environment()
    conversion = Conversion()
    formatting = Formatting(get_lexer(env))
    msg = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: application/json\r\n',
        body=b'{"foo": "bar"}'
    )
    stream = BufferedPrettyStream(
        msg=msg,
        env=env,
        conversion=conversion,
        formatting=formatting,
        with_headers=True,
        with_body=True
    )


# Generated at 2022-06-17 20:55:38.789996
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.plugins import plugin_manager
    from httpie.context import Environment
    from httpie.compat import urlopen
    import json
    import os
    import sys
    import unittest

    class TestBufferedPrettyStream(unittest.TestCase):
        def setUp(self):
            self.env = Environment(stdin=sys.stdin,
                                   stdout=sys.stdout,
                                   stderr=sys.stderr)
            self.env.config.default_options.pretty = True
            self.env.config.default_options.style = 'monokai'
            self.env.config.default_options