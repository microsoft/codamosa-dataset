

# Generated at 2022-06-17 20:45:47.974853
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\n1234')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234']


# Generated at 2022-06-17 20:45:59.144209
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_isatty = False
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = None
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:46:06.230949
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.compat import urlopen
    from httpie.downloads import ResponseWriter
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream

# Generated at 2022-06-17 20:46:17.564855
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import HeadersFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter

# Generated at 2022-06-17 20:46:27.921200
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.status import ExitStatus
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.exceptions import ParseError
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.base import HTTPieArgumentParser
    from httpie.cli.base import parser as base_parser
    from httpie.cli.base import get_response
    from httpie.cli.base import get_response_

# Generated at 2022-06-17 20:46:35.273190
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "text/plain; charset=utf-8"},
                      encoding="utf-8",
                      body="test")
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == "utf-8"
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:46:39.855980
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'abcdefghijklmnopqrstuvwxyz')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'abcdefghijklmnopqrstuvwxyz']


# Generated at 2022-06-17 20:46:50.121972
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Test case 1
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'

    # Test case 2
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')
    stream = PrettyStream(msg=msg, with_headers=False, with_body=False)
    assert stream.get_headers() == b''

    # Test case 3
    msg = HT

# Generated at 2022-06-17 20:47:01.834002
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Test for constructor of class PrettyStream
    # Arrange
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'test'
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    env = Environment()
    # Act
    pretty_stream = PrettyStream(conversion, formatting, msg, with_headers, with_body, on_body_chunk_downloaded, env)
    # Assert
    assert pretty_stream.msg == msg
    assert pretty_stream.with_headers == with_headers
    assert pretty_stream.with_body == with_body
    assert pretty_stream.on_body_chunk_downloaded

# Generated at 2022-06-17 20:47:09.879251
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello\nWorld\n',
        encoding='utf8'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(colors=False),
        with_headers=False,
        with_body=True
    )
    assert list(stream.iter_body()) == [b'Hello\n', b'World\n']

# Generated at 2022-06-17 20:47:26.888304
# Unit test for method get_headers of class PrettyStream

# Generated at 2022-06-17 20:47:37.500276
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
    Content-Type: text/html; charset=utf-8
    '''
    msg.body = '''<!DOCTYPE html>
    <html>
    <head>
    <title>Page Title</title>
    </head>
    <body>
    <h1>This is a Heading</h1>
    <p>This is a paragraph.</p>
    </body>
    </html>
    '''
    msg.encoding = 'utf-8'
    stream = EncodedStream(msg)
    assert stream.get_headers() == msg.headers.encode('utf-8')
    assert stream.iter_body() == msg.body.encode('utf-8')

# Unit test

# Generated at 2022-06-17 20:47:47.657789
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_isatty = False
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = None
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:48:01.657013
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models

    # Create a new HTTPMessage
    msg = httpie.models.HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"
    msg.body = "Hello World!"

    # Create a new Conversion
    conversion = httpie.output.processing.Conversion()

    # Create a new Formatting
    formatting = httpie.output.processing.Formatting()

    # Create a new PrettyStream
    pretty_stream = httpie.output.streams.PrettyStream(msg, conversion, formatting)

    # Test the constructor of class PrettyStream
    assert pretty_stream.msg == msg
    assert pretty_stream.conversion == conversion


# Generated at 2022-06-17 20:48:05.751599
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers='''HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Thu, 15 Feb 2018 11:51:52 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 612
Connection: keep-alive
Vary: Accept-Encoding
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff

''')
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    headers = stream.get_headers()

# Generated at 2022-06-17 20:48:16.502732
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response

# Generated at 2022-06-17 20:48:27.992498
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # test case 1
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
                      body=b'hello\nworld\n',
                      encoding='utf8')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'hello\n', b'world\n']

    # test case 2

# Generated at 2022-06-17 20:48:31.920797
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers={"Content-Type": "text/html"}, body="<html></html>")
    stream = BaseStream(msg=msg, with_headers=True, with_body=True)
    assert list(stream) == [b'Content-Type: text/html\r\n\r\n', b'<html></html>']


# Generated at 2022-06-17 20:48:41.112616
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import plugin_manager
    from httpie.compat import urlopen

    # Load plugins
    plugin_manager.load_installed_plugins()

    # Create a response
    response = urlopen('http://httpbin.org/get')
    response = HTTPResponse(response)

    # Create a PrettyStream
    conversion = Conversion()
    formatting = Formatting(get_lexer(None, 'json'))
    stream = PrettyStream(response, conversion, formatting)

    # Test iter_body
    for chunk in stream.iter_body():
        print(chunk)

# Generated at 2022-06-17 20:48:50.899266
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream

    env = Environment()
    msg = Response(
        status_code=200,
        headers={'Content-Type': 'text/html'},
        body=b'<html><body>Hello World</body></html>',
        encoding='utf8'
    )
    stream = BufferedPrettyStream(
        msg=msg,
        env=env,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True
    )
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'

# Generated at 2022-06-17 20:49:32.602748
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type


# Generated at 2022-06-17 20:49:43.839195
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import Conversion
    from httpie.output.streams import Formatting

# Generated at 2022-06-17 20:49:54.952907
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import get_lexer

    conversion = Conversion()
    formatting = Formatting(
        get_lexer(None, None),
        JSONFormatter(),
        HeadersFormatter(),
    )

# Generated at 2022-06-17 20:50:03.012016
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: text/plain',
        body=b'Hello World!',
    )
    stream = RawStream(response)
    assert list(stream) == [
        b'Content-Type: text/plain\r\n\r\n',
        b'Hello World!'
    ]



# Generated at 2022-06-17 20:50:08.246796
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body="{\"name\": \"httpie\"}",
        encoding="utf8"
    )
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == "utf8"
    assert stream.msg.encoding == "utf8"


# Generated at 2022-06-17 20:50:15.685137
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import EncodedStream

# Generated at 2022-06-17 20:50:24.619107
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream

# Generated at 2022-06-17 20:50:32.397030
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1: chunk is str
    chunk = '{"name":"John"}'
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(chunk) == b'{\n    "name": "John"\n}'

    # Test case 2: chunk is bytes
    chunk = b'{"name":"John"}'
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(chunk) == b'{\n    "name": "John"\n}'

# Generated at 2022-06-17 20:50:39.341702
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter

    headers = Headers([('Content-Type', 'application/json')])
    stream = PrettyStream(
        msg=None,
        with_headers=True,
        with_body=True,
        conversion=None,
        formatting=None,
        env=None,
        on_body_chunk_downloaded=None
    )
    stream.msg = HTTPMessage(headers=headers)
    stream.output_encoding = 'utf8'
    stream.formatting = TerminalFormatter(get_lexer())
    assert stream.get_headers() == b'Content-Type: application/json\n'

# Generated at 2022-06-17 20:50:48.521687
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer

    # Test 1:
    # Test case:
    #   - mime: text/html
    #   - body: <html><body>Hello</body></html>
    #   - headers: Content-Type: text/html
    #   - conversion: None
    #   - formatting: None
    #   - output_encoding: utf8
    #   - chunk_size: 1024 * 10
    #   - on_body_chunk_downloaded: None
    # Expected result:
    #   - body: <html><body>Hello</body></html>
    #

# Generated at 2022-06-17 20:51:42.711308
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # test for constructor of class EncodedStream
    # test for the case of env.stdout_isatty = True
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'test'
    msg.iter_body = lambda x: ['test']
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    # test for the case of env.stdout_isatty = False
    env.stdout_isatty = False
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'



# Generated at 2022-06-17 20:51:50.605213
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.formatters import JSONFormatter
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    headers = Headers()
    headers.add('Content-Type', 'application/json')
    headers.add('Content-Length', '123')
    headers.add('Content-Encoding', 'gzip')
    headers.add('Connection', 'close')
    headers.add('Date', 'Tue, 15 Nov 1994 08:12:31 GMT')
    headers.add('Server', 'Apache/2.4.1 (Unix)')
    headers.add('Last-Modified', 'Tue, 15 Nov 1994 08:12:31 GMT')

# Generated at 2022-06-17 20:51:59.648076
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer

    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: application/json',
        body=b'{"a": 1, "b": 2}'
    )
    conversion = Conversion()
    formatting = Formatting(get_lexer('json', None))
    stream = PrettyStream(
        msg=response,
        conversion=conversion,
        formatting=formatting,
        with_headers=True,
        with_body=True
    )

# Generated at 2022-06-17 20:52:03.705805
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = {'Content-Type': 'application/json'}
    msg = HTTPMessage(headers=headers)
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:52:12.925595
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:52:22.788165
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import test_BaseStream___iter__
    from httpie.output.streams import test_RawStream___iter__
    from httpie.output.streams import test_EncodedStream___iter__
    from httpie.output.streams import test_PrettyStream___

# Generated at 2022-06-17 20:52:29.748211
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.output.formatters.colors import get_lexer

    env = Environment()
    response = HTTPResponse(urlopen('http://httpbin.org/get'))
    stream = EncodedStream(response, env=env)
    for chunk in stream.iter_body():
        print(chunk)


# Generated at 2022-06-17 20:52:35.236345
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    chunk_size = 1024 * 100
    raw_stream = RawStream(msg, with_headers, with_body, on_body_chunk_downloaded, chunk_size)
    assert raw_stream.msg == msg
    assert raw_stream.with_headers == with_headers
    assert raw_stream.with_body == with_body
    assert raw_stream.on_body_chunk_downloaded == on_body_chunk_downloaded
    assert raw_stream.chunk_size == chunk_size


# Generated at 2022-06-17 20:52:40.251228
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xc3\xbc'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xc3\xbc\n']



# Generated at 2022-06-17 20:52:43.032318
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"test": "test"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=True)
    assert stream.get_headers() == b'test: test\n'

# Generated at 2022-06-17 20:54:15.602093
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n" \
                  "Content-Type: application/json\r\n" \
                  "Content-Length: 2\r\n" \
                  "Connection: close\r\n" \
                  "\r\n"
    msg.body = b'{}'
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    conversion = Conversion()
    formatting = Formatting()
    stream = BufferedPrettyStream(msg, env=env, conversion=conversion, formatting=formatting)

# Generated at 2022-06-17 20:54:26.611567
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_theme

    # Test the method iter_body of class PrettyStream
    # with a json response
    response = Response(
        'HTTP/1.1 200 OK',
        '''{
            "id": 1,
            "name": "A green door",
            "price": 12.50,
            "tags": ["home", "green"]
        }''',
        'application/json'
    )
    conversion = Conversion()

# Generated at 2022-06-17 20:54:36.772497
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPRequest
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import get_lexer

    conversion = Conversion()

# Generated at 2022-06-17 20:54:44.742279
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream

    msg = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: text/plain; charset=utf-8',
        body=b'Hello World!\n',
    )
    stream = BaseStream(msg)
    assert list(stream) == [
        b'Content-Type: text/plain; charset=utf-8\r\n\r\n',
        b'Hello World!\n'
    ]



# Generated at 2022-06-17 20:54:49.328879
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    stream = PrettyStream(None, None, None, None, None, None)
    chunk = b'{"a": "b"}'
    # Act
    result = stream.process_body(chunk)
    # Assert
    assert result == b'{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:55:01.606492
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import httpie.output.streams
    import httpie.models
    import httpie.output.processing
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.context
    import httpie.plugins.builtin
    import httpie.plugins.builtin.converters
    import httpie.plugins.builtin.formatters
    import httpie.plugins.builtin.streams
    import httpie.plugins.builtin.streams.pretty
    import httpie.plugins.builtin.streams.raw
    import httpie.plugins.builtin.streams.encoded
    import httpie.plugins.builtin.streams.buffered_pretty
    import httpie.plugins.builtin.streams.base
    import httpie.plugins.builtin.streams

# Generated at 2022-06-17 20:55:12.740391
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import RawStream
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    import io

    response = urlopen('http://httpbin.org/get')
    response = Response(response)
    raw_stream = RawStream(response)
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.colors = 256
    env.style = 'solarized'
    env.format = 'colors'
    env

# Generated at 2022-06-17 20:55:17.713613
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!\n'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello World!\n']


# Generated at 2022-06-17 20:55:28.482053
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b'1234567890']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg, chunk_size=5)
    assert list(stream.iter_body()) == [b'12345', b'67890']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg, chunk_size=1)

# Generated at 2022-06-17 20:55:36.197043
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.processing import Conversion, Formatting

    response = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=b'{"foo": "bar"}'
    )

    conversion = Conversion()
    formatting = Formatting(
        get_formatter(),
        get_lexer(None),
        get_prettifier(None)
    )
