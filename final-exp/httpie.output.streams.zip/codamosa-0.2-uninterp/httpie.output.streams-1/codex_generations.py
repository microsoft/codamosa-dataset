

# Generated at 2022-06-17 20:45:50.284568
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Test for iter_body of class RawStream
    # Arrange
    msg = HTTPMessage(headers=b'', body=b'123456789')
    raw_stream = RawStream(msg=msg)
    # Act
    result = raw_stream.iter_body()
    # Assert
    assert result == b'123456789'


# Generated at 2022-06-17 20:45:58.228315
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:46:04.225277
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf-8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87'
    )
    stream = EncodedStream(msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']

    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf-8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87\r\n\xe4\xb8\xad\xe6\x96\x87\r\n'
    )
   

# Generated at 2022-06-17 20:46:15.355242
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:46:18.443596
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=None, formatting=None)
    assert stream.get_headers() == b'Content-Type: application/json\r\n'

# Generated at 2022-06-17 20:46:26.636928
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Case 1: chunk is a str
    chunk = '{"name": "httpie"}'
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(chunk) == b'{\n    "name": "httpie"\n}'
    # Case 2: chunk is a bytes
    chunk = b'{"name": "httpie"}'
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(chunk) == b'{\n    "name": "httpie"\n}'

# Generated at 2022-06-17 20:46:38.337055
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:46:45.852527
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer

    env = Environment()
    conversion = Conversion()
    formatting = Formatting(get_lexer(None, env))
    msg = HTTPResponse(
        b'HTTP/1.1 200 OK\r\n'
        b'Content-Type: application/json\r\n'
        b'\r\n'
        b'{"foo": "bar"}'
    )
    stream = BufferedPrettyStream(msg, env=env, conversion=conversion, formatting=formatting)

# Generated at 2022-06-17 20:47:00.100623
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    import io
    import sys
    import os
    import tempfile
    import pytest

    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp()
    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp()
    # Create the temporary file
    with os.fdopen(fd, 'w') as temp_file:
        temp_file.write('Hello World!')

    # Create a message

# Generated at 2022-06-17 20:47:10.370175
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer

    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: application/json',
        body=b'{"foo": "bar"}',
        encoding='utf8',
    )
    stream = PrettyStream(
        msg=response,
        with_headers=False,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(
            colors=True,
            # lexer=get_lexer('json', None),
            # style=get_style('monokai'),
        ),
    )

# Generated at 2022-06-17 20:47:26.691631
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.output.formatters.utils import get_preferred_output_flattener
    from httpie.compat import is_windows
    from httpie.output.formatters.utils import get_preferred_output_flattener
    from httpie.output.formatters.utils import get_preferred_output_flattener
    from httpie.output.formatters.utils import get_preferred_output_flattener
    from httpie.output.formatters.utils import get_preferred_output_flattener
    from httpie.output.formatters.utils import get_preferred_output_

# Generated at 2022-06-17 20:47:31.077826
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:47:39.959236
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError

    # Test BaseStream
    # Test __init__
    msg = HTTPResponse(headers={'Content-Type': 'text/html'},
                       encoding='utf8',
                       body='<html><body>Hello World!</body></html>')
    stream = BaseStream(msg, with_headers=True, with_body=True)

# Generated at 2022-06-17 20:47:50.424801
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import iter_body

# Generated at 2022-06-17 20:47:58.974493
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'headers'
    msg.body = 'body'
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:48:06.269531
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.compat import str
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

# Generated at 2022-06-17 20:48:16.904303
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test case 1:
    #   - body: "abc\n"
    #   - expected: "abc\n"
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf-8\r\n',
        body=b'abc\n',
    )
    stream = PrettyStream(
        msg=msg,
        with_headers=False,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
    )
    assert b''.join(stream.iter_body()) == b'abc\n'

    # Test case 2:
    #   - body: "abc\n"
    #   - expected: "abc\n"

# Generated at 2022-06-17 20:48:28.355241
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.context import Environment
    from httpie.models import HTTPMessage


# Generated at 2022-06-17 20:48:37.719407
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    msg.headers = "test"
    msg.body = "test"
    msg.encoding = "utf8"
    msg.content_type = "test"
    msg.iter_body = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"
    msg.iter_lines = "test"

# Generated at 2022-06-17 20:48:48.246980
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_theme
    from httpie.output.formatters.colors import PygmentsHTTPHeadersLexer
    from httpie.output.formatters.colors import PygmentsHTTPBodyLexer
    from httpie.output.formatters.colors import PygmentsLex

# Generated at 2022-06-17 20:49:03.990009
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    class MockConversion:
        def get_converter(self, mime):
            return None

    class MockFormatting:
        def __init__(self):
            self.json_formatter = JSONFormatter(get_lexer('json'))

        def format_body(self, content, mime):
            return self.json_formatter.format_body(content, mime)


# Generated at 2022-06-17 20:49:12.733213
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_headers

# Generated at 2022-06-17 20:49:19.349278
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']



# Generated at 2022-06-17 20:49:30.483869
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.status import ExitStatus
    from httpie.cli import parser
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:49:42.856524
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(
        headers={
            'Content-Type': 'application/json',
            'Content-Length': '0'
        },
        body=b'{"a": 1}',
        encoding='utf8'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(
            colors=False,
            verbose=False,
            headers=True,
            body=True,
            body_max_size=None,
            body_line_preview_size=None
        )
    )
    assert stream.get_headers() == b'Content-Length: 0\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:49:46.592917
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    msg = Response(
        url='http://example.com',
        status_code=200,
        headers={'Content-Type': 'application/json'},
        content=b'{"key": "value"}',
    )
    stream = BufferedPrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
    )
    assert list(stream.iter_body()) == [b'{\n    "key": "value"\n}\n']

# Generated at 2022-06-17 20:49:58.407534
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'application/json'
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.msg == msg
    assert stream.conversion == conversion
    assert stream.formatting == formatting
    assert stream.mime == 'application/json'
    assert stream.output_encoding == 'utf8'
    assert stream.with_headers
    assert stream.with_body
    assert stream.on_body_chunk_downloaded is None


# Generated at 2022-06-17 20:50:07.710436
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_py2

    msg = HTTPMessage(content_type='text/plain', encoding='utf8')
    msg.headers = 'Content-Type: text/plain; charset=utf8'
    msg.body = '\u2713'
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting(), env=Environment())
    assert stream.process_body(msg.body) == b'\xe2\x9c\x93'
    if is_py2:
        msg.body = '\xe2\x9c\x93'
        assert stream.process_body

# Generated at 2022-06-17 20:50:15.326210
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={'Content-Type': 'text/plain'},
                      encoding='utf8',
                      body=b'\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89')
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == 'utf8'
    assert stream.msg.encoding == 'utf8'
    assert stream.msg.body == b'\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89'
    assert stream.msg.headers == {'Content-Type': 'text/plain'}
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk

# Generated at 2022-06-17 20:50:21.781816
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg, chunk_size=2)
    assert list(stream.iter_body()) == [b'12', b'34', b'56', b'78', b'90']



# Generated at 2022-06-17 20:50:53.679221
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(
        headers={"Content-Type": "text/plain"},
        body=b"Hello, World!\n",
        encoding="utf8"
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(None),
        with_headers=False,
        with_body=True,
        on_body_chunk_downloaded=None
    )
    assert list(stream.iter_body()) == [b"Hello, World!\n"]

# Generated at 2022-06-17 20:51:00.823195
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.output.formatters.colors import get_lexer

    env = Environment()
    conversion = Conversion()

# Generated at 2022-06-17 20:51:05.579900
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen

    response = urlopen('https://httpbin.org/get')
    stream = EncodedStream(HTTPResponse(response))
    body = b''.join(stream.iter_body())
    assert b'httpbin' in body

# Generated at 2022-06-17 20:51:16.496617
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment


# Generated at 2022-06-17 20:51:27.802674
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test case 1:
    # Input:
    #   msg = HTTPMessage(headers=b'', body=b'', encoding='utf8')
    #   env = Environment(stdout_isatty=True, stdout_encoding='utf8')
    #   with_headers = True
    #   with_body = True
    #   on_body_chunk_downloaded = None
    # Expected output:
    #   output_encoding = 'utf8'
    msg = HTTPMessage(headers=b'', body=b'', encoding='utf8')
    env = Environment(stdout_isatty=True, stdout_encoding='utf8')
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None

# Generated at 2022-06-17 20:51:34.420811
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.compat import is_windows

    response = Response(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        '\r\n'
        '{"a": 1, "b": 2}'
    )

    conversion = Conversion()

# Generated at 2022-06-17 20:51:39.478617
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(encoding='utf8')
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.output_encoding == 'utf8'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:51:45.551174
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(
        msg=None,
        conversion=None,
        formatting=None,
        with_headers=False,
        with_body=True,
        on_body_chunk_downloaded=None
    )
    chunk = '{"a": "b"}'
    assert stream.process_body(chunk) == b'{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:51:52.656101
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None, None, None, None)
    assert stream.process_body(b'\x00') == b'\x00'
    assert stream.process_body(b'\x00\x00') == b'\x00\x00'
    assert stream.process_body(b'\x00\x00\x00') == b'\x00\x00\x00'
    assert stream.process_body(b'\x00\x00\x00\x00') == b'\x00\x00\x00\x00'
    assert stream.process_body(b'\x00\x00\x00\x00\x00') == b'\x00\x00\x00\x00\x00'

# Generated at 2022-06-17 20:52:00.585046
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()

# Generated at 2022-06-17 20:52:46.965709
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'text/plain'
    msg.body = 'test'
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    stream = BufferedPrettyStream(msg, env, conversion, formatting)
    assert stream.msg == msg
    assert stream.env == env
    assert stream.conversion == conversion
    assert stream.formatting == formatting
    assert stream.mime == 'text/plain'
    assert stream.output_encoding == 'utf8'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.CHUNK_SIZE == 1024 * 10



# Generated at 2022-06-17 20:53:00.945438
# Unit test for method __iter__ of class BaseStream

# Generated at 2022-06-17 20:53:11.749972
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n' \
                  'Content-Type: application/json\r\n' \
                  'Content-Length: 15\r\n' \
                  '\r\n'
    msg.body = '{"hello": "world"}'
    msg.encoding = 'utf8'
    msg.content_type = 'application/json'
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\n' \
                                   b'Content-Type: application/json\r\n' \
                                   b'Content-Length: 15\r\n' \
                                   b'\r\n'

# Generated at 2022-06-17 20:53:15.599456
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!\n'
    )
    stream = RawStream(msg)
    assert b''.join(stream.iter_body()) == b'Hello World!\n'


# Generated at 2022-06-17 20:53:23.278201
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_style

    conversion = Conversion()
    conversion.register('application/json', JSONFormatter)
    formatting = Formatting(get_lexer('json'), get_style('json'))
    msg = HTTPResponse(
        headers={'Content-Type': 'application/json'},
        body=b'{"foo": "bar"}',
        encoding='utf8',
    )

# Generated at 2022-06-17 20:53:29.651206
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'Content-Type: text/html; charset=utf-8\r\n')
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: text/html; charset=utf-8\r\n'


# Generated at 2022-06-17 20:53:37.439553
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPProxyPassAuth

# Generated at 2022-06-17 20:53:43.332796
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'header'
    msg.encoding = 'utf8'
    msg.content_type = 'text/plain'
    msg.body = 'body'
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:53:51.739853
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()
    msg = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=b'{"foo": "bar"}',
        encoding='utf8',
    )
    stream = BufferedPrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting,
        with_headers=True,
        with_body=True,
    )
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:54:00.692302
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf-8\r\n',
        body=b'\xe4\xb8\x96\xe7\x95\x8c\r\n',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\x96\xe7\x95\x8c\r\n']


# Generated at 2022-06-17 20:55:17.488032
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Given
    stream = PrettyStream(
        msg=HTTPMessage(
            headers={},
            body=b'{"foo": "bar"}',
            encoding='utf8',
            content_type='application/json'
        ),
        with_headers=False,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(colors=False, indent=2)
    )
    # When
    result = stream.process_body(b'{"foo": "bar"}')
    # Then
    assert result == b'{\n  "foo": "bar"\n}'

# Generated at 2022-06-17 20:55:28.293943
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = 'headers'
    msg.body = 'body'
    msg.encoding = 'utf8'
    msg.content_type = 'application/json'
    msg.status_code = 200
    msg.reason = 'OK'
    msg.version = 'HTTP/1.1'
    msg.raw = b'raw'
    msg.url = 'url'
    msg.history = []
    msg.cookies = []
    msg.elapsed = 0.1
    msg.request_headers = 'request_headers'
    msg.request_body = 'request_body'
    msg.request_method = 'GET'
    msg.request_url = 'request_url'
    msg.request_raw = b'request_raw'

# Generated at 2022-06-17 20:55:31.949233
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={"Content-Type": "text/plain"}, body=b"hello")
    stream = RawStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b"hello"]


# Generated at 2022-06-17 20:55:38.354763
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test case 1:
    #   msg: HTTPMessage
    #   with_headers: True
    #   with_body: True
    #   on_body_chunk_downloaded: None
    #   env: Environment
    #   chunk_size: 1
    #   output_encoding: utf8
    #   CHUNK_SIZE: 1
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    env = Environment()
    chunk_size = 1
    output_encoding = 'utf8'
    CHUNK_SIZE = 1