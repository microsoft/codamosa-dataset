

# Generated at 2022-06-17 20:45:47.098119
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers='Content-Type: application/json\n')
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\n'


# Generated at 2022-06-17 20:46:00.374889
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import io
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_style_for_type
    from httpie.output.formatters.utils import is_json
    from httpie.output.formatters.utils import is_xml
    from httpie.output.formatters.utils import is_form_urlencoded

# Generated at 2022-06-17 20:46:07.091416
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from pygments.formatters import TerminalFormatter
    from httpie.compat import is_windows

    # Create a response object

# Generated at 2022-06-17 20:46:18.363357
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:46:28.509639
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.processing import Conversion, Formatting

    # Create a dummy response
    response = HTTPResponse(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body='{"key": "value"}'
    )

    # Create a dummy conversion
    conversion = Conversion(JSONConverter())

    # Create a dummy formatting
    formatting = Formatting(JSONFormatter())

    # Create a dummy stream
    stream = PrettyStream(
        msg=response,
        conversion=conversion,
        formatting=formatting
    )

    # Get

# Generated at 2022-06-17 20:46:39.938663
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class MockHTTPMessage:
        def __init__(self, content_type, encoding):
            self.content_type = content_type
            self.encoding = encoding

        def iter_lines(self, chunk_size):
            yield b'line1', b'\n'
            yield b'line2', b'\n'

    class MockConversion:
        def get_converter(self, mime):
            return None

    class MockFormatting:
        def format_body(self, content, mime):
            return content

    msg = MockHTTPMessage('text/plain', 'utf8')
    conversion = MockConversion()
    formatting = MockFormatting()
    stream = PrettyStream(msg, conversion, formatting)

# Generated at 2022-06-17 20:46:46.727008
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers={"Content-Type": "application/json"},
                      body=b'{"foo": "bar"}')
    stream = BaseStream(msg=msg, with_headers=True, with_body=True)
    assert list(stream) == [b'Content-Type: application/json\r\n\r\n',
                            b'{"foo": "bar"}']

    stream = BaseStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream) == [b'{"foo": "bar"}']

    stream = BaseStream(msg=msg, with_headers=True, with_body=False)
    assert list(stream) == [b'Content-Type: application/json\r\n\r\n']



# Generated at 2022-06-17 20:47:00.592346
# Unit test for method get_headers of class PrettyStream

# Generated at 2022-06-17 20:47:06.364814
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json", "Content-Length": "10"})
    stream = PrettyStream(msg, conversion=None, formatting=None)
    assert stream.get_headers() == b'Content-Length: 10\r\nContent-Type: application/json\r\n\r\n'


# Generated at 2022-06-17 20:47:16.462780
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting


# Generated at 2022-06-17 20:47:36.028634
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSupp

# Generated at 2022-06-17 20:47:39.891189
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers={'Content-Type': 'text/plain'}, body=b'Hello, World!')
    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\nHello, World!']


# Generated at 2022-06-17 20:47:45.824315
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers='''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>''')
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)

# Generated at 2022-06-17 20:47:50.245706
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={'Content-Type': 'text/html; charset=utf-8'})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: text/html; charset=utf-8\r\n'


# Generated at 2022-06-17 20:48:02.793691
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.context import Environment
    from httpie.compat import is_py26
    from httpie.status import ExitStatus
    from httpie.cli import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.exceptions import ParseError
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType

# Generated at 2022-06-17 20:48:14.625899
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion

# Generated at 2022-06-17 20:48:20.059264
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'text/html'
    msg.body = 'test'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env)
    assert stream.msg == msg
    assert stream.output_encoding == 'utf8'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:48:30.485146
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:48:38.263785
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']


# Generated at 2022-06-17 20:48:41.766197
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'


# Generated at 2022-06-17 20:49:10.083233
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    msg.body = 'Hello World!'
    stream = BufferedPrettyStream(msg, with_headers=True, with_body=True)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    assert list(stream.iter_body()) == [b'Hello World!']

# Generated at 2022-06-17 20:49:17.832142
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # test with_headers=True, with_body=True
    msg = HTTPMessage(headers={"Content-Type": "text/plain"}, body="hello")
    stream = EncodedStream(msg=msg, with_headers=True, with_body=True)
    assert stream.get_headers() == b'Content-Type: text/plain\r\n\r\n'
    assert list(stream.iter_body()) == [b'hello\n']

    # test with_headers=True, with_body=False
    msg = HTTPMessage(headers={"Content-Type": "text/plain"}, body="hello")
    stream = EncodedStream(msg=msg, with_headers=True, with_body=False)

# Generated at 2022-06-17 20:49:29.313734
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    msg.body = '<html>\n<body>\n<h1>Hello World</h1>\n</body>\n</html>'
    msg.encoding = 'utf8'
    stream = EncodedStream(msg)
    assert stream.output_encoding == 'utf8'
    assert stream.msg.headers == 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    assert stream.msg.body == '<html>\n<body>\n<h1>Hello World</h1>\n</body>\n</html>'
    assert stream.msg

# Generated at 2022-06-17 20:49:35.630076
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py

# Generated at 2022-06-17 20:49:40.109488
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import pytest
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: application/json\r\n',
        body=b'{"key": "value"}'
    )
    stream = BufferedPrettyStream(
        msg=response,
        conversion=Conversion(),
        formatting=Formatting()
    )
    assert next(stream.iter_body()) == b'{\n    "key": "value"\n}'


# Generated at 2022-06-17 20:49:51.537126
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'text/html'
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.msg == msg
    assert stream.conversion == conversion
    assert stream.formatting == formatting
    assert stream.mime == 'text/html'
    assert stream.output_encoding == 'utf8'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:49:56.777960
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf8\r\n\r\n',
        body=b'\x80'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\ufffd']



# Generated at 2022-06-17 20:50:01.280036
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "text/html"}, body=b"<html></html>")
    stream = EncodedStream(msg=msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == "utf8"


# Generated at 2022-06-17 20:50:08.562554
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test for method iter_body of class PrettyStream
    # Arrange
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!\n',
        encoding='utf8',
        content_type='text/plain'
    )
    stream = PrettyStream(msg=msg, with_headers=False, with_body=True)
    # Act
    result = list(stream.iter_body())
    # Assert
    assert result == [b'Hello World!\n']

# Generated at 2022-06-17 20:50:15.827588
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_response_stream
   

# Generated at 2022-06-17 20:51:01.332930
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.context import Environment

# Generated at 2022-06-17 20:51:07.904416
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={'Content-Type': 'text/html'}, encoding='utf8')
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == 'utf8'
    assert stream.msg.encoding == 'utf8'
    assert stream.msg.headers.encode('utf8') == b'Content-Type: text/html'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:51:18.814819
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test case 1:
    #   Input:
    #       msg = HTTPMessage(headers=None, body=None)
    #       with_headers = True
    #       with_body = True
    #       on_body_chunk_downloaded = None
    #   Expected:
    #       output_encoding = 'utf8'
    msg = HTTPMessage(headers=None, body=None)
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    stream = EncodedStream(msg=msg, with_headers=with_headers, with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded)
    assert stream.output_encoding == 'utf8'

    # Test case 2:
   

# Generated at 2022-06-17 20:51:30.740540
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.processing import Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import HTTPMessage
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py26

# Generated at 2022-06-17 20:51:42.459284
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n"
    msg.headers += "Content-Type: text/html; charset=utf-8\r\n"
    msg.headers += "Content-Length: 10\r\n"
    msg.headers += "\r\n"
    msg.body = "1234567890"
    msg.encoding = "utf-8"
    msg.content_type = "text/html; charset=utf-8"
    msg.content_length = 10
    msg.status_code = 200
    msg.status_line = "HTTP/1.1 200 OK"
    msg.version = "HTTP/1.1"
    msg.reason = "OK"
    msg.raw = msg.headers + msg.body

# Generated at 2022-06-17 20:51:50.783480
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream

# Generated at 2022-06-17 20:51:59.647342
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response

# Generated at 2022-06-17 20:52:04.507920
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain\r\n',
        body=b'Hello\r\nWorld!\r\n'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello\r\n', b'World!\r\n']



# Generated at 2022-06-17 20:52:06.383916
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    # Act
    # Assert
    assert True

# Generated at 2022-06-17 20:52:13.621615
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "text/html; charset=utf-8"}, body=b"<html>\n<head>\n<title>\n</title>\n</head>\n<body>\n<h1>\n</h1>\n</body>\n</html>\n")
    stream = EncodedStream(msg=msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:53:38.559142
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b'1234567890']
    stream = RawStream(msg=msg, chunk_size=3)
    assert list(stream.iter_body()) == [b'123', b'456', b'789', b'0']


# Generated at 2022-06-17 20:53:47.621043
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from pygments.lexers import JsonLexer
    from pygments.lexers import HtmlLexer
    from pygments.lexers import XmlLexer
    from pygments.lexers import JavascriptLexer
    from pygments.lexers import CssLexer
    from pygments.lexers import PythonLexer
    from pygments.lexers import PythonConsoleLexer
    from pygments.lexers import PythonTracebackLexer
    from pygments.lexers import Python3Lexer

# Generated at 2022-06-17 20:54:01.419320
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers='''HTTP/1.1 200 OK
Date: Wed, 21 Oct 2015 07:28:00 GMT
Server: Apache
Last-Modified: Wed, 11 Jan 2006 12:29:43 GMT
ETag: "1b01-1b-3e01a6e2a84c0"
Accept-Ranges: bytes
Content-Length: 707
Connection: close
Content-Type: text/html

''')
    stream = PrettyStream(msg, with_headers=True, with_body=False)

# Generated at 2022-06-17 20:54:11.854519
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\n'
                b'Content-Type: application/json\r\n'
                b'\r\n',
        body=b'{"a": "b"}\n{"c": "d"}\n',
        encoding='utf8',
    )
    stream = PrettyStream(
        msg=msg,
        with_headers=False,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
    )
    assert list(stream.iter_body()) == [
        b'{\n    "a": "b"\n}\n',
        b'{\n    "c": "d"\n}\n',
    ]

# Generated at 2022-06-17 20:54:23.544796
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']

    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='gbk',
    )
    stream = EncodedStream(msg=msg)
   

# Generated at 2022-06-17 20:54:28.149567
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:54:37.774039
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import BaseFormatter
    from httpie.output.formatters import get_formatter
    from httpie.output.formatters import get_prettifier
    from httpie.output.formatters import get_converter
    from httpie.output.formatters import get_validator
    from httpie.output.formatters import get_style_defs
    from httpie.output.formatters import get_lexer
    from httpie.output.formatters import get_theme_style_defs
    from httpie.output.formatters import get_theme_overrides
   

# Generated at 2022-06-17 20:54:41.290609
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:54:49.226628
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>
'''
    msg = HTTPMessage(headers)
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == headers.encode('utf8')

# Generated at 2022-06-17 20:54:59.341512
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!',
    )
    stream = EncodedStream(msg)
    assert stream.output_encoding == 'utf8'
    assert list(stream) == [
        b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        b'Hello World!'
    ]
