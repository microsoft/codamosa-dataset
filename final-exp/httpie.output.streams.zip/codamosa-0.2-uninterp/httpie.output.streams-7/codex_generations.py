

# Generated at 2022-06-17 20:45:55.813405
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain\r\n',
                      body=b'abcdefghijklmnopqrstuvwxyz')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'abcdefghijklmnopqrstuvwxyz']


# Generated at 2022-06-17 20:46:02.326759
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n"
    msg.headers += "Content-Type: text/html\r\n"
    msg.headers += "Content-Length: 12\r\n"
    msg.headers += "\r\n"
    msg.body = "Hello World!"
    msg.encoding = "utf8"
    msg.content_type = "text/html"
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.get_headers() == b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 12\r\n\r\n"
    assert stream.iter_body() == b"Hello World!"



# Generated at 2022-06-17 20:46:08.252544
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:46:19.361390
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n"
    msg.headers += "Content-Type: application/json\r\n"
    msg.headers += "Content-Length: 2\r\n"
    msg.headers += "\r\n"
    msg.body = b'{}'
    msg.content_type = "application/json"
    msg.encoding = "utf-8"
    msg.raw_headers = msg.headers.encode('utf-8')
    msg.raw_body = msg.body
    msg.url = "http://www.baidu.com"
    msg.status_line = "HTTP/1.1 200 OK"
    msg.status_code = 200
    msg.reason = "OK"

# Generated at 2022-06-17 20:46:25.210008
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    chunk = '{"name": "John"}'
    mime = 'application/json'
    stream = PrettyStream(None, None, None, None, None, None)
    # Act
    result = stream.process_body(chunk)
    # Assert
    assert result == b'{\n    "name": "John"\n}'

# Generated at 2022-06-17 20:46:36.852793
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    response = Response(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        '\r\n'
        '{"a": 1, "b": 2}'
    )
    conversion = Conversion()
    conversion.register('application/json', JSONFormatter)
    formatting = Formatting(get_lexer('json', None))
    stream = PrettyStream(
        msg=response,
        conversion=conversion,
        formatting=formatting
    )

# Generated at 2022-06-17 20:46:44.987288
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:46:54.430459
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.plugins import plugin_manager
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import DataSuppressedError

# Generated at 2022-06-17 20:47:00.744357
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'header'
    msg.body = 'body'
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:47:11.067572
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b'1234567890']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg, chunk_size=2)
    assert list(stream.iter_body()) == [b'12', b'34', b'56', b'78', b'90']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg, chunk_size=3)
    assert list(stream.iter_body()) == [b'123', b'456', b'789', b'0']


# Generated at 2022-06-17 20:47:30.680171
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_

# Generated at 2022-06-17 20:47:36.294386
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8\r\n',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']

# Generated at 2022-06-17 20:47:41.735752
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env)
    assert stream.msg == msg
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:47:47.906875
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']

# Generated at 2022-06-17 20:48:01.743131
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream

# Generated at 2022-06-17 20:48:13.590863
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:48:17.009599
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'Content-Type: text/plain\r\n\r\n')
    stream = PrettyStream(msg, conversion=None, formatting=None)
    assert stream.get_headers() == b'Content-Type: text/plain\r\n\r\n'

# Generated at 2022-06-17 20:48:24.016556
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n')
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'


# Generated at 2022-06-17 20:48:33.175199
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # test case 1:
    # input:
    #   chunk = '{"id": "1", "name": "test"}'
    #   mime = 'application/json'
    # expected output:
    #   '{\n    "id": "1",\n    "name": "test"\n}'
    chunk = '{"id": "1", "name": "test"}'
    mime = 'application/json'
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(chunk) == b'{\n    "id": "1",\n    "name": "test"\n}'

    # test case 2:
    # input:
    #   chunk = '{"id": "1", "name": "test"}'
    #   mime =

# Generated at 2022-06-17 20:48:41.277426
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:49:13.160978
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:49:19.904799
# Unit test for method get_headers of class PrettyStream

# Generated at 2022-06-17 20:49:27.890614
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response

# Generated at 2022-06-17 20:49:35.037392
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_py26

    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf-8\r\n',
        body=b'\xe2\x98\x83',
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        env=Environment(),
    )
    if is_py26:
        # Python 2.6 doesn't support unicode literals.
        expected = u'\u2603'.encode('utf8')

# Generated at 2022-06-17 20:49:43.556870
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test for constructor of class EncodedStream
    # Arrange
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    # Act
    stream = EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    # Assert
    assert stream.msg == msg
    assert stream.with_headers == with_headers
    assert stream.with_body == with_body
    assert stream.on_body_chunk_downloaded == on_body_chunk_downloaded


# Generated at 2022-06-17 20:49:54.697944
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from pygments.lexers import JsonLexer
    from pygments.formatters import TerminalFormatter
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 20:50:05.737672
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.utils import get_encoding_from_headers
    from httpie.status import ExitStatus
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.plugins import plugin_manager
    from httpie.output.streams import RawStream
    import json
    import io
    import sys
    import os
    import unittest


# Generated at 2022-06-17 20:50:10.829487
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!',
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello World!']


# Generated at 2022-06-17 20:50:21.485522
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_termin

# Generated at 2022-06-17 20:50:29.766727
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE


# Generated at 2022-06-17 20:51:22.643580
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Create a HTTPMessage object
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n',
        body=b'Hello World!\n'
    )
    # Create a EncodedStream object
    stream = EncodedStream(msg=msg)
    # Test the iter_body method
    assert list(stream.iter_body()) == [b'Hello World!\n']



# Generated at 2022-06-17 20:51:32.175539
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_formatter
    from httpie.output.formatters.utils import get_converter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_formatter
    from httpie.output.formatters.utils import get_converter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_formatter

# Generated at 2022-06-17 20:51:38.440928
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test for constructor of class EncodedStream
    # Arrange
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    # Act
    stream = EncodedStream(msg, env)
    # Assert
    assert stream.msg == msg
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:51:44.753169
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']

# Generated at 2022-06-17 20:51:52.193725
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError

    # Test for method __iter__ of class BaseStream
    def test_BaseStream___iter__():
        # Test with headers and body
        msg = Response(
            status_line='HTTP/1.1 200 OK',
            headers={'Content-Type': 'text/plain'},
            body=b'abc\n',
        )

# Generated at 2022-06-17 20:52:01.218356
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE

# Generated at 2022-06-17 20:52:10.390122
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n' \
                  'Content-Type: text/plain\r\n' \
                  'Content-Length: 11\r\n' \
                  '\r\n'
    msg.body = 'Hello World'
    stream = RawStream(msg)
    assert stream.get_headers() == msg.headers.encode('utf8')
    assert list(stream.iter_body()) == [msg.body.encode('utf8')]
    assert list(stream) == [msg.headers.encode('utf8'), b'\r\n\r\n', msg.body.encode('utf8')]


# Generated at 2022-06-17 20:52:14.662009
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'


# Generated at 2022-06-17 20:52:24.051346
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter, Formatter
    from httpie.output.converters import JSONConverter, Converter

    class TestFormatter(Formatter):
        def format_body(self, content, mime):
            return content

    class TestConverter(Converter):
        def convert(self, body):
            return 'text/plain', body.decode('utf-8')

    conversion = Conversion(JSONConverter(), TestConverter())
    formatting = Formatting(JSONFormatter(), TestFormatter())

# Generated at 2022-06-17 20:52:28.854343
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n\r\nabcdefghijklmnopqrstuvwxyz')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'abcdefghijklmnopqrstuvwxyz']


# Generated at 2022-06-17 20:54:12.074222
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()

    response = Response(
        status_code=200,
        headers={'Content-Type': 'text/plain'},
        body='Hello world!',
        encoding='utf-8'
    )

    stream = BufferedPrettyStream(
        msg=response,
        conversion=conversion,
        formatting=formatting
    )

    assert next(stream.iter_body()) == b'Hello world!'

# Generated at 2022-06-17 20:54:23.714325
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:54:34.955019
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_formatter
    from httpie.output.formatters.colors import PygmentsHTTPFormatter
    from httpie.output.formatters.colors import PygmentsFormatter
    from httpie.output.formatters.colors import PygmentsStyle
    from httpie.output.formatters.colors import PygmentsLexer
    from httpie.output.formatters.colors import get_style_by_name

# Generated at 2022-06-17 20:54:42.329006
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test for constructor of class EncodedStream
    # Arrange
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'headers'
    msg.body = 'body'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    # Act
    es = EncodedStream(msg, env=env)
    # Assert
    assert es.msg == msg
    assert es.output_encoding == 'utf8'


# Generated at 2022-06-17 20:54:50.963057
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        headers={"Content-Type": "text/html; charset=utf-8"},
        body=b"<html>\n<body>\n<h1>Hello World</h1>\n</body>\n</html>\n",
        encoding="utf-8",
    )
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == "utf-8"
    assert stream.get_headers() == b"Content-Type: text/html; charset=utf-8\r\n\r\n"

# Generated at 2022-06-17 20:54:58.697674
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!\n'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello World!\n']



# Generated at 2022-06-17 20:55:04.080900
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.compat import is_py26
    from httpie.status import ExitStatus
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.exceptions import ParseError
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.exceptions import ParseError
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
   

# Generated at 2022-06-17 20:55:14.242169
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE

# Generated at 2022-06-17 20:55:25.014151
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Test case 1
    msg = HTTPMessage(headers='''HTTP/1.1 200 OK
Date: Wed, 22 May 2019 14:57:38 GMT
Server: Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips PHP/7.2.19
X-Powered-By: PHP/7.2.19
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate
Pragma: no-cache
Set-Cookie: PHPSESSID=5e6c8f8b9d7b9c9a9f9d8e8d8c8e8f8b; path=/
Content-Length: 0
Content-Type: text/html; charset=UTF-8

''')

# Generated at 2022-06-17 20:55:33.477859
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_py26

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPResponse(
        url='http://example.com/',
        status_code=200,
        headers={'Content-Type': 'text/plain; charset=utf8'},
        content=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8',
    )