

# Generated at 2022-06-17 20:45:56.055928
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(headers={'Content-Type': 'text/html'}, body=b'<html></html>')
    stream = BufferedPrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        env=Environment(),
        conversion=Conversion(),
        formatting=Formatting()
    )
    assert stream.get_headers() == b'Content-Type: text/html\r\n\r\n'
    assert list(stream.iter_body()) == [b'<html></html>']

# Generated at 2022-06-17 20:46:02.526317
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_response_stream
    from httpie.output.streams import get_request_stream

# Generated at 2022-06-17 20:46:06.526671
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n')
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\nContent-Type: text/html\n\n'

# Generated at 2022-06-17 20:46:17.864419
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']
    stream = RawStream(msg, chunk_size=3)
    assert list(stream.iter_body()) == [b'123', b'456', b'789', b'0']
    stream = RawStream(msg, chunk_size=2)
    assert list(stream.iter_body()) == [b'12', b'34', b'56', b'78', b'90']
    stream = RawStream(msg, chunk_size=1)

# Generated at 2022-06-17 20:46:27.961756
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(
        headers=b'Content-Type: text/html; charset=utf-8',
        body=b'<html>\n<body>\n<h1>Hello, world!</h1>\n</body>\n</html>\n',
    )
    stream = BufferedPrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
    )
    assert stream.mime == 'text/html'
    assert stream.output_encoding == 'utf8'
    assert stream.msg.headers == 'Content-Type: text/html; charset=utf-8'

# Generated at 2022-06-17 20:46:37.531680
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting

    response = HTTPResponse(
        headers={'Content-Type': 'application/json'},
        encoding='utf8',
        status_code=200,
        reason='OK',
        body='{"foo": "bar"}'
    )
    stream = PrettyStream(
        msg=response,
        conversion=Conversion(),
        formatting=Formatting()
    )
    assert list(stream.iter_body()) == [b'{\n    "foo": "bar"\n}\n']

# Generated at 2022-06-17 20:46:45.594975
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting

# Generated at 2022-06-17 20:46:54.723794
# Unit test for constructor of class PrettyStream

# Generated at 2022-06-17 20:47:01.664010
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.utils import get_response
    from httpie.compat import urlopen
    from httpie.context import Environment

    env = Environment()
    response = get_response(urlopen(env.config.default_options.url))
    stream = EncodedStream(msg=response, env=env)
    for chunk in stream.iter_body():
        print(chunk)


# Generated at 2022-06-17 20:47:12.805883
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.compat import is_windows
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from pygments import highlight
    import json

    # Create a JSON response
    json_data = {'foo': 'bar'}
    json_str = json.dumps(json_data)
    json_bytes = json_str.encode('utf8')
    response = HTTPResp

# Generated at 2022-06-17 20:47:35.080679
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    assert stream.msg.headers == 'test'
    assert stream.msg.encoding == 'utf8'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.CHUNK_SIZE == 1


# Generated at 2022-06-17 20:47:42.545538
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Test 1:
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\n'
                b'Content-Type: text/plain; charset=utf-8\r\n'
                b'\r\n'
                b'\u4f60\u597d\n',
        body=b'\u4f60\u597d\n',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xbd\xa0\xe5\xa5\xbd\n']

    # Test 2:

# Generated at 2022-06-17 20:47:47.718754
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Converter
    from httpie.output.processing import Formatter
    from httpie.output.processing import FormatterRegistry
    from httpie.output.processing import ConverterRegistry
    from httpie.output.processing import ConverterPriority
    from httpie.output.processing import FormatterPriority
    from httpie.output.processing import ContentType

# Generated at 2022-06-17 20:48:01.655385
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.compat import is_windows

    conversion = Conversion()
    conversion.register('application/json', JSONFormatter)

    formatting = Formatting()
    formatting.lexer = get_lexer('json', 'application/json')
    formatting.formatter = TerminalFormatter(bg='dark')


# Generated at 2022-06-17 20:48:13.490534
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.output.formatters.utils import get_prettifier

    class MockResponse(HTTPResponse):
        def __init__(self, headers, body):
            super().__init__(200, headers, body)

    headers = {'content-type': 'application/json'}
    body = b'{"key": "value"}'
    response = MockResponse(headers, body)
    conversion = Conversion()

# Generated at 2022-06-17 20:48:20.316349
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:48:24.934580
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=True)
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'


# Generated at 2022-06-17 20:48:33.239825
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'foo\nbar\n',
        encoding='utf8',
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
    )
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    assert list(stream.iter_body()) == [b'foo\n', b'bar\n']


# Generated at 2022-06-17 20:48:43.076562
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import RawStream
    from httpie.compat import urlopen
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 20:48:47.855225
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test for constructor of class EncodedStream
    # Arrange
    msg = HTTPMessage()
    # Act
    stream = EncodedStream(msg)
    # Assert
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:49:17.894148
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Arrange
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain\r\n\r\n',
        body=b'Hello World!',
        encoding='utf8',
    )
    stream = BufferedPrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
    )
    # Act
    result = stream.iter_body()
    # Assert
    assert result == b'Hello World!'

# Generated at 2022-06-17 20:49:24.131025
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain\r\n',
        body=b'Hello, world!',
        encoding='utf8'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello, world!']


# Generated at 2022-06-17 20:49:30.385446
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import pytest
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_py26
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    env = Environment()
    msg = HTTPMessage(headers={'Content-Type': 'application/json'},
                      body='{"foo": "bar"}')
    conversion = Conversion()
    formatting = Formatting(env, get_lexer(JSONFormatter))
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting,
                          env=env)

# Generated at 2022-06-17 20:49:42.743117
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:49:54.081907
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.compat import is_windows
    import json
    import pytest
    import os
    import sys
    import io
    import subprocess
    import tempfile
    import shutil
    import re
    import time


# Generated at 2022-06-17 20:49:57.160550
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\n'

# Generated at 2022-06-17 20:50:03.906715
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:50:12.992698
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.compat import is_windows
    from httpie.output.formatters.utils import get_preferred_output_flavors

    env = Environment()
    conversion = Conversion()
    formatting = Formatting(
        get_lexer(None, None, None),
        TerminalFormatter(bg='dark') if not is_windows else None,
        get_preferred_output_flavors(env)
    )

# Generated at 2022-06-17 20:50:20.306575
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test for method __iter__ of class BaseStream
    # Creation of a HTTPMessage object
    msg = HTTPMessage(headers={'Content-Type': 'application/json'},
                      body='{"key": "value"}')
    # Creation of a BaseStream object
    stream = BaseStream(msg=msg, with_headers=True, with_body=True)
    # Test for method __iter__ of class BaseStream
    assert list(stream) == [b'Content-Type: application/json\r\n\r\n{"key": "value"}']



# Generated at 2022-06-17 20:50:28.764015
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-17 20:51:21.238872
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:51:31.425302
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.compat import is_py26
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py32
    from httpie.compat import is_py33
    from httpie.compat import is_py

# Generated at 2022-06-17 20:51:35.209272
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body="{}")
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b"{}"]


# Generated at 2022-06-17 20:51:46.051042
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-17 20:51:58.454459
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body=b'{"name": "httpie"}'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'
    assert stream.iter_body() == [b'{\n    "name": "httpie"\n}']

# Generated at 2022-06-17 20:52:08.502985
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-17 20:52:12.308903
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body="{\"name\":\"test\"}",
        encoding="utf8"
    )
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b"{\"name\":\"test\"}"]


# Generated at 2022-06-17 20:52:16.125111
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:52:24.786828
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import ContentType
    from httpie.output.processing import ContentTypeConverter
    from httpie.output.processing import ContentTypeFormatter
    from httpie.output.processing import ContentTypeProcessor
    from httpie.output.processing import ContentTypeProcessorRegistry
    from httpie.output.processing import ContentTypeProcessorRegistry
    from httpie.output.processing import ContentTypeProcessorRegistry

# Generated at 2022-06-17 20:52:33.761906
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.status import ExitStatus
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_prettifier
    from httpie.output.formatters.utils import get_converter
    from httpie.output.formatters.utils import get_prettifier

# Generated at 2022-06-17 20:54:11.361784
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response

# Generated at 2022-06-17 20:54:23.120783
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen
    from httpie.downloads import Downloader
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import Binary

# Generated at 2022-06-17 20:54:29.043494
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(
        headers={'Content-Type': 'text/plain'},
        body=b'Hello World!',
        encoding='utf8'
    )
    stream = BaseStream(msg)
    assert b''.join(stream) == b'Content-Type: text/plain\r\n\r\nHello World!'


# Generated at 2022-06-17 20:54:38.003760
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import get_lexer

    response = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        content=b'{"a": 1, "b": 2}',
        encoding='utf8'
    )

    conversion = Conversion()

# Generated at 2022-06-17 20:54:48.286740
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows

    # Test for RawStream
    # Test for RawStream.__init__
    def test_RawStream___init__():
        msg = HTTPResponse()
        with_headers = True
        with_body = True
        on_body_chunk_downloaded = None

# Generated at 2022-06-17 20:55:01.300102
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    # Test with a JSON response
    response = HTTPResponse(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        '\r\n'
        '{"key": "value"}'
    )
    conversion = Conversion()
    formatting = Formatting(
        get_lexer(None, JSONFormatter()),
        JSONFormatter()
    )

# Generated at 2022-06-17 20:55:12.433809
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments.util import ClassNotFound
    from httpie.output.formatters.utils import get_preferred_output_flavour
    from httpie.output.formatters.utils import get_preferred_output_flavour

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()

# Generated at 2022-06-17 20:55:23.306957
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import is_binary

# Generated at 2022-06-17 20:55:30.725429
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream

    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: text/plain',
        body=b'Hello World!\n',
        encoding='utf8',
    )
    stream = PrettyStream(
        msg=response,
        with_headers=False,
        with_body=True,
        conversion=None,
        formatting=None,
    )
    assert list(stream.iter_body()) == [b'Hello World!\n']

# Generated at 2022-06-17 20:55:37.674628
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body="{}")
    stream = BufferedPrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'
    assert stream.formatting == Formatting()
    assert stream.conversion == Conversion()
    assert stream.mime == 'application/json'
    assert stream.CHUNK_SIZE == 1024 * 10
