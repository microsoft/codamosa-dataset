

# Generated at 2022-06-17 20:45:58.905672
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(headers={"Content-Type": "application/json"},
                      body="{\"name\": \"John\"}",
                      encoding="utf8")
    stream = PrettyStream(msg=msg,
                          conversion=Conversion(),
                          formatting=Formatting())
    assert stream.mime == "application/json"
    assert stream.output_encoding == "utf8"
    assert stream.formatting == Formatting()
    assert stream.conversion == Conversion()
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None

# Generated at 2022-06-17 20:46:04.713414
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:46:16.019555
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n' \
                  'Content-Type: text/plain\r\n' \
                  'Content-Length: 3\r\n' \
                  '\r\n'
    msg.body = b'abc'
    msg.encoding = 'utf8'
    stream = BufferedPrettyStream(msg, with_headers=True, with_body=True)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\n' \
                                   b'Content-Type: text/plain\r\n' \
                                   b'Content-Length: 3\r\n' \
                                   b'\r\n'
    assert list(stream.iter_body()) == [b'abc']

# Generated at 2022-06-17 20:46:27.591862
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1
    # Input
    chunk = '{"id": 1, "name": "Foo"}'
    mime = 'application/json'
    # Expected output
    expected = '{\n    "id": 1,\n    "name": "Foo"\n}'
    # Actual output
    actual = PrettyStream(None, None, None, None, None, None).process_body(chunk)
    # Assertion
    assert actual == expected

    # Test case 2
    # Input
    chunk = '{"id": 1, "name": "Foo"}'
    mime = 'application/xml'
    # Expected output

# Generated at 2022-06-17 20:46:39.413751
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test case 1:
    #   input:
    #       msg = HTTPMessage(headers='', body='')
    #       with_headers = True
    #       with_body = True
    #       on_body_chunk_downloaded = None
    #   output:
    #       output_encoding = 'utf8'
    msg = HTTPMessage(headers='', body='')
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    stream = EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    assert stream.output_encoding == 'utf8'

    # Test case 2:
    #   input:
    #       msg = HTTPMessage(headers='', body='')


# Generated at 2022-06-17 20:46:48.275578
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # test for normal case
    msg = HTTPMessage(headers=b'', body=b'hello world')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'hello world']

    # test for binary case
    msg = HTTPMessage(headers=b'', body=b'hello\0world')
    stream = EncodedStream(msg=msg)
    try:
        list(stream.iter_body())
    except BinarySuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE
    else:
        assert False, 'should raise BinarySuppressedError'



# Generated at 2022-06-17 20:47:00.736472
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    body = b'{"foo": "bar"}'
    msg = HTTPResponse(
        url='http://example.org',
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=body,
    )
    stream = BufferedPrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
    )
    assert list(stream.iter_body()) == [b'{\n    "foo": "bar"\n}\n']

# Generated at 2022-06-17 20:47:11.105529
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n"
    msg.headers += "Content-Type: text/html; charset=utf-8\r\n"
    msg.headers += "Content-Length: 10\r\n"
    msg.headers += "\r\n"
    msg.body = "1234567890"
    msg.encoding = "utf-8"
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 10\r\n\r\n'

# Generated at 2022-06-17 20:47:22.148853
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSupp

# Generated at 2022-06-17 20:47:30.476969
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers=b'Content-Type: text/plain\r\n\r\n', body=b'hello')
    stream = BaseStream(msg)
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\n', b'\r\n\r\n', b'hello']
    stream = BaseStream(msg, with_headers=False, with_body=False)
    assert list(stream) == []
    stream = BaseStream(msg, with_headers=False)
    assert list(stream) == [b'hello']
    stream = BaseStream(msg, with_body=False)
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\n', b'\r\n\r\n']

#

# Generated at 2022-06-17 20:47:50.164925
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.parser import parse_items
    from httpie.cli.exceptions import ParseError

# Generated at 2022-06-17 20:48:01.701566
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting

    msg = HTTPResponse(
        http_version='1.1',
        status_code=200,
        headers={
            'Content-Type': 'application/json',
            'Content-Length': '10'
        },
        body='{"a":1}'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=False,
        with_body=True
    )
    assert list(stream.iter_body()) == [b'{\n    "a": 1\n}']

# Generated at 2022-06-17 20:48:13.547476
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    print("Testing constructor of class BufferedPrettyStream")
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    buffered_pretty_stream = BufferedPrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded, conversion, formatting)
    assert buffered_pretty_stream.msg == msg
    assert buffered_pretty_stream.with_headers == with_headers
    assert buffered_pretty_stream.with_body == with_body
    assert buffered_pretty_stream.on_body_chunk_downloaded == on_body_chunk_downloaded
    assert buffered_pretty_stream.conversion == conversion

# Generated at 2022-06-17 20:48:20.350805
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_style
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from pygments.styles import get_style_by_name
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream

# Generated at 2022-06-17 20:48:30.735453
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
   

# Generated at 2022-06-17 20:48:40.191600
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_style
    from httpie.output.formatters.colors import PygmentsHTTPieStyle
    from httpie.output.formatters.colors import PygmentsLexer
    from httpie.output.formatters.colors import PygmentsStyle
    from httpie.output.formatters.colors import PygmentsHTTPieStyle
    from httpie.output.formatters.colors import PygmentsLexer
    from httpie.output.formatters.colors import PygmentsStyle

# Generated at 2022-06-17 20:48:44.585480
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers=b'', body=b'')
    stream = EncodedStream(msg=msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:48:52.679820
# Unit test for constructor of class RawStream
def test_RawStream():
    # Test for constructor of class RawStream
    # Arrange
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n'
    msg.headers += 'Content-Type: text/plain\r\n'
    msg.headers += 'Content-Length: 12\r\n'
    msg.headers += '\r\n'
    msg.body = b'Hello world!'
    # Act
    raw_stream = RawStream(msg)
    # Assert
    assert raw_stream.msg == msg
    assert raw_stream.with_headers == True
    assert raw_stream.with_body == True
    assert raw_stream.on_body_chunk_downloaded == None
    assert raw_stream.chunk_size == 102400


# Generated at 2022-06-17 20:49:00.380660
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test if the method __iter__ of class BaseStream can return an iterator over `self.msg`.
    # Arrange
    msg = HTTPMessage(headers={"Content-Type": "text/plain"}, body="Hello World!")
    stream = BaseStream(msg=msg, with_headers=True, with_body=True)
    # Act
    result = stream.__iter__()
    # Assert
    assert result == iter(b'Content-Type: text/plain\r\n\r\nHello World!')


# Generated at 2022-06-17 20:49:08.182965
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.output.formatters.colors import get_lexer

    env = Environment()
    conversion = Conversion()
    formatting = Formatting(get_lexer(env))
    response = urlopen('https://httpbin.org/get')
    msg = HTTPResponse(response)
    stream = BufferedPrettyStream(msg, conversion, formatting, env)
    print(stream)


# Generated at 2022-06-17 20:49:33.887343
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import EncodedStream

# Generated at 2022-06-17 20:49:44.639794
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 12

'''
    msg.body = '''<html>
<head>
<title>Test</title>
</head>
<body>
<h1>Test</h1>
</body>
</html>
'''
    msg.encoding = 'utf-8'
    msg.content_type = 'text/html'
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    # Act
    result = stream.process_body(msg.body)
    # Assert

# Generated at 2022-06-17 20:49:55.639443
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import HeadersFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import RawJSONFormatter
    from httpie.output.formatters import RawFormatter
    from httpie.output.formatters import RawHeadersFormatter
    from httpie.output.formatters import RawStreamFormatter
    from httpie.output.formatters import RawStreamFormatter
    from httpie.output.formatters import RawStreamFormatter
    from httpie.output.formatters import RawStreamFormatter
    from httpie.output.formatters import RawStreamFormatter


# Generated at 2022-06-17 20:50:03.922609
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == 'utf8'
    assert list(stream) == [b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n\r\n\r\nHello World!']


# Generated at 2022-06-17 20:50:08.253378
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']

# Generated at 2022-06-17 20:50:15.661192
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_class
   

# Generated at 2022-06-17 20:50:24.585997
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import PygmentsHTTPieFormatter
    from httpie.output.formatters.colors import PygmentsHTTPieLexer
    from httpie.output.formatters.colors import PygmentsHTTPieStyle
    from httpie.output.formatters.colors import PygmentsStyle
    from httpie.output.formatters.colors import PygmentsFormatter
    from httpie.output.formatters.colors import PygmentsLexer
    from httpie.output.formatters.colors import Pygments

# Generated at 2022-06-17 20:50:35.386831
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py33
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37

# Generated at 2022-06-17 20:50:39.723621
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Test for method get_headers of class PrettyStream
    # Creation of a HTTPMessage object
    msg = HTTPMessage(headers={"Content-Type": "application/json"},
                      encoding="utf8")
    # Creation of a PrettyStream object
    stream = PrettyStream(msg=msg, with_headers=True, with_body=True,
                          conversion=Conversion(),
                          formatting=Formatting())
    # Test
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:50:48.816351
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:51:27.686906
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    msg = HTTPResponse(headers={"Content-Type": "text/plain"},
                       body="hello world")
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b"hello world"]


# Generated at 2022-06-17 20:51:34.304376
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import plugin_manager
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream

    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-17 20:51:45.298795
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = 'headers'
    msg.body = 'body'
    msg.encoding = 'utf8'
    msg.content_type = 'text/html'
    msg.content_length = 10
    msg.status_code = 200
    msg.reason = 'OK'
    msg.http_version = 'HTTP/1.1'
    msg.url = 'http://www.baidu.com'
    msg.raw = 'raw'
    msg.raw_headers = 'raw_headers'
    msg.raw_body = 'raw_body'
    msg.strict = True
    msg.closed = True
    msg.chunked = True
    msg.chunk_size = 1024
    msg.chunk_left = 1024

# Generated at 2022-06-17 20:51:52.506167
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments import highlight
    from pygments.formatters import TerminalTrueColorFormatter
    from pygments.lexers import JsonLexer
    import json

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    response = HTTPResponse(urlopen('https://httpbin.org/get').info())
    response.encoding = 'utf8'

# Generated at 2022-06-17 20:51:57.917972
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:52:01.059889
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\n'

# Generated at 2022-06-17 20:52:10.922034
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import plugin_manager
    from pygments.formatters import TerminalFormatter
    from httpie.compat import is_windows
    from httpie.context import Environment
    import json

    # Create a HTTPResponse object

# Generated at 2022-06-17 20:52:21.896621
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.compat import is_py26
    from httpie.plugins import plugin_manager
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError

# Generated at 2022-06-17 20:52:31.402347
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()
    msg = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        content=b'{"a": 1, "b": 2}',
        encoding='utf8'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting,
        with_headers=False,
        with_body=True
    )
    assert b'{\n    "a": 1,\n    "b": 2\n}' == b''.join(stream.iter_body())

# Generated at 2022-06-17 20:52:39.203206
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    msg = HTTPMessage(headers={"Content-Type": "application/json"},
                      body="{\"name\": \"value\"}")
    stream = PrettyStream(msg=msg,
                          conversion=Conversion(),
                          formatting=Formatting())
    # Act
    result = stream.process_body("{\"name\": \"value\"}")
    # Assert
    assert result == b'{\n    "name": "value"\n}'

# Generated at 2022-06-17 20:54:01.940025
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-17 20:54:12.855560
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_request

# Generated at 2022-06-17 20:54:16.322922
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    # Act
    # Assert
    assert True

# Generated at 2022-06-17 20:54:17.710830
# Unit test for constructor of class RawStream
def test_RawStream():
    assert RawStream(None, None, None, None, None)


# Generated at 2022-06-17 20:54:29.239236
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Test 1
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body=b'{"id": 1, "name": "Foo"}\n{"id": 2, "name": "Bar"}\n'
    )

# Generated at 2022-06-17 20:54:38.112364
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import is_py26
    from pygments import highlight
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from httpie.output.formatters.utils import get_binary_stream

    # Test for method iter_body of class BufferedPrettyStream
    # Create a HTTPResponse object

# Generated at 2022-06-17 20:54:48.365267
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test RawStream
    msg = HTTPResponse(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: text/plain; charset=utf-8\r\n'
        'Content-Length: 4\r\n'
        '\r\n'
        'test'
    )
    stream = RawStream(msg, with_headers=True, with_body=True)
    assert b''.join(stream) == msg.raw

    # Test EncodedStream
    msg = HTTPResponse

# Generated at 2022-06-17 20:55:01.300022
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    # Create a response

# Generated at 2022-06-17 20:55:07.404741
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'test'
    msg.body = 'test'
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:55:16.414428
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # test for RawStream
    request = HTTPRequest(
        method='GET',
        url='http://httpbin.org/get',
        headers={'h1': 'v1', 'h2': 'v2'},
        body='body'
    )
    stream = RawStream(msg=request, with_headers=True, with_body=True)
    assert b'h1: v1' in next(iter(stream))
    assert b'h2: v2' in next(iter(stream))