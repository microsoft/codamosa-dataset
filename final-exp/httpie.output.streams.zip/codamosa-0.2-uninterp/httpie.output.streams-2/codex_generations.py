

# Generated at 2022-06-17 20:45:59.736269
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier

    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_

# Generated at 2022-06-17 20:46:09.811098
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    import json
    import pytest
    import sys
    import os

    # Create a new environment
    env = Environment()

    # Create a new formatting object
    formatting = Formatting(env)

    # Create a new HTTPMessage object
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body=json.dumps({"name": "John", "age": 30}),
        encoding="utf8"
    )

    # Create a new PrettyStream object

# Generated at 2022-06-17 20:46:15.627443
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'Content-Type: application/json\r\n\r\n')
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\n'

# Generated at 2022-06-17 20:46:18.908561
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=None, formatting=None)
    assert stream.get_headers() == b'Content-Type: application/json\r\n'


# Generated at 2022-06-17 20:46:29.368809
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34

# Generated at 2022-06-17 20:46:33.693708
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\n'

# Generated at 2022-06-17 20:46:43.262508
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
   

# Generated at 2022-06-17 20:46:49.902841
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    chunk = '{"id": 1, "name": "Foo"}'
    mime = 'application/json'
    formatting = Formatting()
    conversion = Conversion()
    pretty_stream = PrettyStream(conversion, formatting)
    pretty_stream.mime = mime
    # Act
    result = pretty_stream.process_body(chunk)
    # Assert
    assert result == b'{\n    "id": 1,\n    "name": "Foo"\n}'

# Generated at 2022-06-17 20:47:01.736603
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:47:12.890343
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    msg = HTTPResponse(
        [
            ('Content-Type', 'application/json'),
            ('Content-Length', '13'),
        ],
        b'{"foo": "bar"}'
    )

# Generated at 2022-06-17 20:47:25.810780
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={'Content-Type': 'text/plain'},
                      body=b'hello world')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'hello world']



# Generated at 2022-06-17 20:47:36.752897
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.plugins import plugin_manager
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import HttpLexer
    from pygments.styles import get_style_by_name

    conversion = Conversion()

# Generated at 2022-06-17 20:47:40.800680
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    msg = HTTPMessage()
    stream = EncodedStream(env, msg)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:47:46.524406
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import io
    import json
    import sys
    from httpie.models import HTTPRequest
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    env = Environment()
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stdin = io.BytesIO(b'{"foo": "bar"}')
    env.stdin_isatty = False
    env.stdin_encoding = 'utf8'
    env.stdin_errors = 'strict'
    env.stdin_isatty = False
    env.stdin_encoding = 'utf8'
    env.stdin_errors = 'strict'
    env.stdin_isat

# Generated at 2022-06-17 20:48:00.949033
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.compat import urlopen
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.compat import urlopen
    from httpie.output.formatters.utils import get_content_type

# Generated at 2022-06-17 20:48:11.509287
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter

    response = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=b'{"foo": "bar"}'
    )

    stream = BufferedPrettyStream(
        msg=response,
        conversion=Conversion(JSONConverter()),
        formatting=Formatting(JSONFormatter())
    )

    assert next(stream.iter_body()) == b'{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:48:19.629154
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from pygments.lexers import HtmlLexer
    from pygments.lexers import XmlLexer
    from pygments.lexers import JavascriptLexer
    from pygments.lexers import CssLexer
    from pygments.lexers import PythonLexer
    from pygments.lexers import YamlLexer
    from pygments.lexers import UrlLexer
    from pygments.lexers import H

# Generated at 2022-06-17 20:48:30.067724
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting, Conversion
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    import json
    import pytest

    env = Environment()
    msg = HTTPMessage(
        headers={'Content-Type': 'application/json'},
        encoding='utf8',
        body=json.dumps({'a': 'b'})
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(env),
        env=env,
        with_headers=True,
        with_body=True,
    )
    assert stream.process_body(msg.body) == b'{\n    "a": "b"\n}\n'

# Generated at 2022-06-17 20:48:39.078696
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "text/plain; charset=utf8"},
                      encoding='utf8',
                      body=b'\x80')
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == 'utf8'
    assert stream.msg.encoding == 'utf8'
    assert stream.msg.body == b'\x80'
    assert stream.msg.headers == 'Content-Type: text/plain; charset=utf8'
    assert stream.msg.content_type == 'text/plain'
    assert stream.msg.charset == 'utf8'
    assert stream.msg.content_type_raw == 'text/plain; charset=utf8'

# Generated at 2022-06-17 20:48:44.585669
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body=b'{"a": 1}')
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'
    assert list(stream.iter_body()) == [b'{\n    "a": 1\n}\n']


# Generated at 2022-06-17 20:49:06.965084
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={"Content-Type": "text/html"}, body=b"<html></html>")
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b"<html></html>"]


# Generated at 2022-06-17 20:49:15.432376
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Test iter_body with a message that has a body
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'Hello World!']

    # Test iter_body with a message that has no body
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'',
        encoding='utf8'
    )

# Generated at 2022-06-17 20:49:24.137381
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test case 1
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body=b'{"a": 1, "b": 2, "c": 3}',
        encoding='utf8'
    )
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert list(stream.iter_body()) == [b'{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}']

    # Test case 2
    msg = HTTPMessage(
        headers={"Content-Type": "application/json"},
        body=b'{"a": 1, "b": 2, "c": 3}',
        encoding='utf8'
    )

# Generated at 2022-06-17 20:49:32.602673
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'headers'
    msg.body = 'body'
    msg.content_type = 'text/plain'
    msg.iter_body = lambda chunk_size: [b'body']
    msg.iter_lines = lambda chunk_size: [('body', '\n')]
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    assert stream.get_headers() == b'headers'
    assert list(stream.iter_body()) == [b'body\n']


# Generated at 2022-06-17 20:49:40.864373
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8',
    )
    stream = EncodedStream(msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']



# Generated at 2022-06-17 20:49:53.329438
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.processing import Conversion, Formatting

    # Create a HTTPResponse object
    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: application/json',
        body=b'{"a": 1, "b": 2}',
        encoding='utf8'
    )

    # Create a PrettyStream object

# Generated at 2022-06-17 20:50:01.733709
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import format_json
    from httpie.output.formatters import format_headers
    from httpie.output.formatters import format_body
    from httpie.output.formatters import format_stream
    from httpie.output.formatters import format_binary
    from httpie.output.formatters import format_form
    from httpie.output.formatters import format_headers_and_body
    from httpie.output.formatters import format_request
    from httpie.output.formatters import format_response
    from httpie.output.formatters import format_stream

# Generated at 2022-06-17 20:50:11.228705
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test for method __iter__ of class BaseStream
    try:
        BaseStream.__iter__(BaseStream())
        assert False
    except NotImplementedError:
        assert True

    # Test for method __iter__ of class RawStream
    try:
        RawStream.__iter__(RawStream())
        assert False
    except NotImplementedError:
        assert True

    # Test for method __iter__ of class EncodedStream

# Generated at 2022-06-17 20:50:21.668252
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "text/html; charset=utf-8"},
                      body=b"<html>\n<body>\n<h1>Hello World</h1>\n</body>\n</html>\n",
                      encoding="utf-8")
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == "utf8"
    assert stream.msg.encoding == "utf-8"
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.CHUNK_SIZE == 1
    assert stream.get_headers() == b"Content-Type: text/html; charset=utf-8\r\n"

# Generated at 2022-06-17 20:50:29.913108
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    msg = HTTPMessage(headers={"Content-Type": "application/json"},
                      body=b'{"name": "httpie"}')
    stream = PrettyStream(msg=msg,
                          conversion=Conversion(),
                          formatting=Formatting(),
                          env=Environment())
    assert stream.process_body(b'{"name": "httpie"}') == b'{\n    "name": "httpie"\n}'
    assert stream.process_body(b'{"name": "httpie"}'.decode('utf-8')) == b'{\n    "name": "httpie"\n}'

# Generated at 2022-06-17 20:51:18.185532
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import RawFormatter
    from httpie.output.formatters import PrettyFormatter
    from httpie.output.formatters import TableFormatter
    from httpie.output.formatters import PygmentsFormatter
    from httpie.output.formatters import Py

# Generated at 2022-06-17 20:51:30.624445
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:51:35.456974
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\n'


# Generated at 2022-06-17 20:51:43.344962
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n',
        body=b'\x80\x81\x82'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xef\xbf\xbd\xef\xbf\xbd\xef\xbf\xbd']


# Generated at 2022-06-17 20:51:51.379280
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response

# Generated at 2022-06-17 20:51:58.357726
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']


# Generated at 2022-06-17 20:52:03.130547
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!',
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello World!']



# Generated at 2022-06-17 20:52:06.938962
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:52:15.120256
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from pygments.lexers import get_lexer_by_name
    from pygments.formatters import TerminalFormatter

    response = Response(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json; charset=utf-8\r\n'
        '\r\n'
        '{"a": 1}'
    )

    conversion = Conversion()

# Generated at 2022-06-17 20:52:24.342522
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:53:49.471201
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import pytest
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream

    def test_iter_body(response, expected):
        stream = PrettyStream(
            msg=response,
            conversion=Conversion(),
            formatting=Formatting(),
            with_headers=False,
            with_body=True,
        )
        assert list(stream.iter_body()) == expected


# Generated at 2022-06-17 20:53:59.280092
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen

    url = 'http://httpbin.org/encoding/utf8'
    response = urlopen(url)
    http_response = HTTPResponse(response)
    stream = EncodedStream(msg=http_response)
    body = b''.join(stream.iter_body())
    assert body.decode('utf8') == '\u2713'

# Generated at 2022-06-17 20:54:10.870033
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_class
   

# Generated at 2022-06-17 20:54:15.506334
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import PygmentsHTTPieFormatter
    from httpie.output.formatters.colors import PygmentsFormatter
    from httpie.output.formatters.colors import get_theme
    from httpie.output.formatters.colors import get_style
    from httpie.output.formatters.colors import get_formatter
    from httpie.output.formatters.colors import get_pygments_formatter
    from httpie.output.formatters.colors import get_py

# Generated at 2022-06-17 20:54:26.526838
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.streams import RawStream
    from httpie.output.streams import Base

# Generated at 2022-06-17 20:54:36.701275
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.processing import Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream

    # Test for RawStream
    headers = Headers(headers={"Content-Type": "application/json"})
    msg = RawStream(msg=headers, with_headers=True, with_body=False)
    assert msg.get_headers() == b'Content-Type: application/json\r\n'

    # Test for EncodedStream
    headers = Headers(headers={"Content-Type": "application/json"})
    msg = EncodedStream(msg=headers, with_headers=True, with_body=False)

# Generated at 2022-06-17 20:54:47.258227
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87\n',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87\n',
        encoding='gbk'
    )

# Generated at 2022-06-17 20:54:56.886230
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(headers=None, body=None, encoding=None)
    msg.content_type = 'application/json'
    msg.encoding = 'utf8'
    stream = PrettyStream(msg, conversion=None, formatting=None, with_headers=False, with_body=True)
    assert stream.process_body('{"a": "b"}') == b'{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:55:02.710296
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    import json

    response = urlopen('https://api.github.com/repos/jakubroztocil/httpie')
    response = Response(response)
    conversion = Conversion()
    formatting = Formatting()
    env = Environment()
    stream = PrettyStream(response, conversion, formatting, env)
    print(json.loads(stream.process_body(stream.iter_body())))

test_PrettyStream()

# Generated at 2022-06-17 20:55:10.488155
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']

