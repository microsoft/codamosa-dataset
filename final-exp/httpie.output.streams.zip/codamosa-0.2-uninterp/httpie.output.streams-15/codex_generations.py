

# Generated at 2022-06-17 20:46:02.605652
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.compat import is_py26


# Generated at 2022-06-17 20:46:05.270034
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n\r\nHello World!')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello World!']



# Generated at 2022-06-17 20:46:10.988371
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers=b'Content-Type: text/plain\r\n\r\n', body=b'Hello World!')
    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\n', b'\r\n\r\n', b'Hello World!']


# Generated at 2022-06-17 20:46:21.126976
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Test case 1:
    #   - Input:
    #       - msg: a HTTPMessage with content-type is text/plain
    #       - chunk_size: 10
    #       - body: "abcdefghijklmnopqrstuvwxyz"
    #   - Expected:
    #       - body: "abcdefghijklmnopqrstuvwxyz"
    msg = HTTPMessage(
        headers={'Content-Type': 'text/plain'},
        body="abcdefghijklmnopqrstuvwxyz"
    )
    stream = BufferedPrettyStream(msg=msg, chunk_size=10)
    assert next(stream.iter_body()) == "abcdefghijklmnopqrstuvwxyz"

    # Test case 2:
   

# Generated at 2022-06-17 20:46:32.620040
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.processing import Conversion, Formatting

    class MockResponse(HTTPResponse):
        def __init__(self, body, headers):
            self.headers = headers
            self.body = body
            self.encoding = 'utf8'
            self.content_type = get_content_type(self.headers, self.body)

        def iter_body(self, chunk_size):
            yield self.body

    headers = {'content-type': 'application/json'}
    body = b'{"foo": "bar"}'
    response = MockResponse(body, headers)
    stream = PrettyStream

# Generated at 2022-06-17 20:46:42.876339
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPRequest
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPRequest(headers={'Content-Type': 'text/plain'},
                      body='hello\nworld\n')
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting)
    assert list(stream.iter_body()) == [b'hello\n', b'world\n']

    msg = HTTPRequest(headers={'Content-Type': 'text/plain'},
                      body='hello\nworld\n')
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting)
    assert list(stream.iter_body()) == [b'hello\n', b'world\n']

# Generated at 2022-06-17 20:46:51.471426
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Test the constructor of class PrettyStream
    # Test if the constructor works
    try:
        PrettyStream()
    except:
        assert False
    # Test if the constructor works when the arguments are given
    try:
        PrettyStream(conversion=Conversion(), formatting=Formatting())
    except:
        assert False
    # Test if the constructor works when the arguments are given
    try:
        PrettyStream(conversion=Conversion(), formatting=Formatting(), msg=HTTPMessage())
    except:
        assert False
    # Test if the constructor works when the arguments are given
    try:
        PrettyStream(conversion=Conversion(), formatting=Formatting(), msg=HTTPMessage(), with_headers=True)
    except:
        assert False
    # Test if the constructor works when the arguments are given

# Generated at 2022-06-17 20:47:02.098051
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import os
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    from httpie.compat import is_windows

    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)
    msg = HTTPMessage(headers={'content-type': 'application/json'},
                      body=json.dumps({'a': 'b'}),
                      encoding='utf8')
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting,
                          env=env)
    if is_windows:
        sys.stdout.buffer.write(b''.join(stream))
    else:
        os.write

# Generated at 2022-06-17 20:47:13.267993
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Apache/2.2.14 (Win32)\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nContent-Length: 88\r\nContent-Type: text/html\r\nConnection: Closed\r\n\r\n"
    msg.body = "Hello World"
    msg.encoding = "utf8"
    msg.content_type = "text/html"
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)

# Generated at 2022-06-17 20:47:24.430367
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers=b'', body=b'', encoding='utf8')
    env = Environment()
    stream = EncodedStream(msg=msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg=msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_encoding = 'gbk'
    stream = EncodedStream(msg=msg, env=env)
    assert stream.output_encoding == 'gbk'
    msg = HTTPMessage(headers=b'', body=b'', encoding=None)
    stream = EncodedStream(msg=msg, env=env)

# Generated at 2022-06-17 20:47:42.423706
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.plugins import plugin_manager
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuth


# Generated at 2022-06-17 20:47:52.079283
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from pygments.styles import get_style_by_name

    response = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=b'{"foo": "bar"}'
    )
    stream = PrettyStream(
        msg=response,
        conversion=Conversion(),
        formatting=Formatting(
            get_style_by_name('monokai'),
            get_lexer('json'),
            TerminalFormatter(bg='dark')
        )
    )

# Generated at 2022-06-17 20:48:04.531991
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import FormURLEncodedFormatter
    from httpie.output.formatters import PlainTextFormatter
    from httpie.output.formatters import RawJSONFormatter
    from httpie.output.formatters import RawURLEncodedFormatter
    from httpie.output.formatters import RawFormatter
    from httpie.output.formatters import RawOrJSONForm

# Generated at 2022-06-17 20:48:15.579105
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.models
    import httpie.context
    import httpie.compat
    import httpie.cli
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.output.streams
    import httpie.output.formatters
   

# Generated at 2022-06-17 20:48:27.309486
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stdout = io.BytesIO()

    msg = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=b'{"a": 1}',
        encoding='utf8',
    )

    conversion = Conversion()
    formatting = Formatting()


# Generated at 2022-06-17 20:48:31.833117
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Length: 10\r\n\r\n',
        body=b'0123456789'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'0123456789']


# Generated at 2022-06-17 20:48:41.054838
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test case 1:
    #   Input:
    #       msg.encoding = 'utf8'
    #       msg.content_type = 'text/html'
    #       msg.body = '<html><body>Hello World</body></html>'
    #       conversion = Conversion()
    #       formatting = Formatting()
    #   Expected output:
    #       '<html><body>Hello World</body></html>'
    msg = HTTPMessage(
        headers=None,
        encoding='utf8',
        content_type='text/html',
        body='<html><body>Hello World</body></html>'
    )
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting
    )

# Generated at 2022-06-17 20:48:50.899305
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test for method __iter__ of class BaseStream

# Generated at 2022-06-17 20:49:00.361215
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'headers'
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_isatty = False
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = None
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:49:09.599936
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:49:38.844211
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']



# Generated at 2022-06-17 20:49:45.532947
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import urlopen

    url = 'https://httpbin.org/get'
    response = urlopen(url)
    msg = HTTPResponse(response)
    conversion = Conversion()
    formatting = Formatting(get_lexer('json'))
    stream = EncodedStream(msg, conversion=conversion, formatting=formatting)
    for chunk in stream.iter_body():
        print(chunk)

# Generated at 2022-06-17 20:49:56.600156
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:50:03.631084
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    stream = PrettyStream(None, None, None, None, None, None)

# Generated at 2022-06-17 20:50:08.028350
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'abcdefghijklmnopqrstuvwxyz')
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b'abcdefghijklmnopqrstuvwxyz']



# Generated at 2022-06-17 20:50:15.520933
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n" \
                  "Content-Type: application/json; charset=utf-8\r\n" \
                  "Content-Length: 2\r\n" \
                  "Connection: close\r\n" \
                  "\r\n" \
                  "{}"
    msg.encoding = "utf-8"
    msg.content_type = "application/json; charset=utf-8"
    msg.body = "{}"
    msg.raw = msg.headers + msg.body
    msg.raw_length = len(msg.raw)
    msg.raw_encoding = "utf-8"
    msg.raw_headers = msg.headers
    msg.raw_body = msg.body
    msg.raw_headers

# Generated at 2022-06-17 20:50:24.474994
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:50:32.514494
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage(headers={'Content-Type': 'application/json'},
                      body='{"foo": "bar"}')
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting,
                          env=Environment())
    assert stream.process_body(msg.body) == b'{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:50:37.501437
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']



# Generated at 2022-06-17 20:50:47.474619
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter

    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)
    json_formatter = JSONFormatter(env)
    formatting.add_formatter(json_formatter)

    url = 'http://httpbin.org/get'
    response = urlopen(url)
    msg = HTTPResponse(response)
    stream = EncodedStream(msg, env=env)

# Generated at 2022-06-17 20:51:34.476475
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.plugins import plugin_manager
    from httpie.compat import is_windows

    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class

# Generated at 2022-06-17 20:51:45.469332
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:51:52.602025
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import ContentType
    from httpie.output.processing import ContentTypeExtension
    from httpie.output.processing import ContentTypeJSON
    from httpie.output.processing import ContentTypeHTML
    from httpie.output.processing import ContentTypeXML
    from httpie.output.processing import ContentTypeText
    from httpie.output.processing import ContentTypeOther
    from httpie.output.processing import ContentTypeUnknown

# Generated at 2022-06-17 20:52:01.330081
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import plugin_manager
    from pygments.formatters import TerminalFormatter

    # Initialize the plugin manager with the default plugins
    plugin_manager.load_installed_plugins()

    # Initialize the formatter
    formatter = JSONFormatter()
    formatter.stream = sys.stdout
    formatter.env = Environment()
    formatter.env.stdout_isatty = True
    formatter.env.stdout_encoding = 'utf8'
    formatter.env.colors = 256


# Generated at 2022-06-17 20:52:09.807086
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test the case when chunk is str
    chunk = '{"name": "httpie"}'
    mime = 'application/json'
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(chunk) == b'{\n    "name": "httpie"\n}'

    # Test the case when chunk is bytes
    chunk = b'{"name": "httpie"}'
    mime = 'application/json'
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(chunk) == b'{\n    "name": "httpie"\n}'

# Generated at 2022-06-17 20:52:20.738320
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    """
    Test for method process_body of class PrettyStream
    """
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream
    # Test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:52:31.096835
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream

    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: application/json',
        body=b'{"a": 1, "b": 2}',
        encoding='utf8',
    )
    stream = BufferedPrettyStream(
        msg=response,
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
    )
    body = b''.join(stream.iter_body())
    assert json.loads(body.decode('utf8')) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 20:52:41.583894
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 6

'''
    msg.body = '''<html>
</html>'''
    msg.encoding = 'utf-8'
    msg.content_type = 'text/html; charset=utf-8'
    msg.content_length = 6
    msg.status_code = 200
    msg.status_line = 'HTTP/1.1 200 OK'
    msg.raw_headers = '''HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 6\r\n\r\n'''

# Generated at 2022-06-17 20:52:48.741231
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-17 20:52:54.075715
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers={"Content-Type": "text/plain; charset=utf-8"},
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']



# Generated at 2022-06-17 20:54:28.113909
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_by_name

# Generated at 2022-06-17 20:54:37.772700
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test case 1:
    # Input:
    #   env = Environment()
    #   msg = HTTPMessage()
    #   with_headers = True
    #   with_body = True
    #   on_body_chunk_downloaded = None
    # Expected output:
    #   output_encoding = 'utf8'
    #   chunk_size = 1
    env = Environment()
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    stream = EncodedStream(env, msg, with_headers, with_body, on_body_chunk_downloaded)
    assert stream.output_encoding == 'utf8'
    assert stream.CHUNK_SIZE == 1

    # Test case 2:
   

# Generated at 2022-06-17 20:54:44.230482
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body=b'{"name": "test"}')
    stream = BufferedPrettyStream(msg=msg, with_headers=True, with_body=True)
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'
    assert next(stream.iter_body()) == b'{\n    "name": "test"\n}'

# Generated at 2022-06-17 20:54:49.495132
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'test'
    msg.body = 'test'
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:55:01.663864
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_class
   

# Generated at 2022-06-17 20:55:11.110670
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_isatty = False
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = None
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'

# Generated at 2022-06-17 20:55:18.024079
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Converter
    from httpie.output.processing import Formatter
    from httpie.output.processing import ContentType
    from httpie.output.processing import ContentTypeRegistry
    from httpie.output.processing import ContentType
    from httpie.output.processing import ContentTypeRegistry
    from httpie.output.processing import ContentType

# Generated at 2022-06-17 20:55:28.796651
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier

    env = Environment()
    conversion = Conversion()
    formatting = Formatting(
        get_lexer(None, env),
        get_prettifier(None, env),
    )
    msg = Response(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: text/plain; charset=utf-8\r\n'
        '\r\n'
        'Hello World!',
        env,
    )

# Generated at 2022-06-17 20:55:36.459076
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_theme
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from httpie.compat import is_windows
    from httpie.context import Environment
    import json
    import os
    import pytest
    import sys
    import tempfile
    import time
    import unittest

    class TestBufferedPrettyStream(unittest.TestCase):
        def setUp(self):
            self.env