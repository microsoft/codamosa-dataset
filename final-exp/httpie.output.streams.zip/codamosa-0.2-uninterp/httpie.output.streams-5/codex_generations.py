

# Generated at 2022-06-17 20:45:50.778887
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_

# Generated at 2022-06-17 20:45:58.596517
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE

# Generated at 2022-06-17 20:46:04.498134
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.formatters import JSONFormatter
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import Buff

# Generated at 2022-06-17 20:46:08.825114
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers={"Content-Type": "text/html"},
        body=b"<html><body>Hello World!</body></html>",
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b"<html><body>Hello World!</body></html>"]


# Generated at 2022-06-17 20:46:14.285463
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test with a string
    stream = PrettyStream(None, None)
    assert stream.process_body("test") == b"test"
    # Test with a bytes
    stream = PrettyStream(None, None)
    assert stream.process_body(b"test") == b"test"

# Generated at 2022-06-17 20:46:18.484664
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body="{}")
    stream = EncodedStream(msg=msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:46:28.808338
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:46:40.179116
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:46:50.440418
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_class
   

# Generated at 2022-06-17 20:46:56.852517
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'abcdefghijklmnopqrstuvwxyz')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'abcdefghijklmnopqrstuvwxyz']


# Generated at 2022-06-17 20:47:11.635922
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import io
    import json
    import pytest
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    def test_iter_body(response, expected_output):
        stream = BufferedPrettyStream(
            msg=response,
            conversion=Conversion(),
            formatting=Formatting(),
            with_headers=False,
            with_body=True,
        )
        output = b''.join(stream.iter_body())
        assert output == expected_output

    # Test for JSON
    response = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=io.BytesIO(b'{"foo": "bar"}'),
    )

# Generated at 2022-06-17 20:47:23.286203
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError


# Generated at 2022-06-17 20:47:32.886660
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    stream = PrettyStream(
        msg=HTTPMessage(headers=None, body=None),
        conversion=Conversion(),
        formatting=Formatting()
    )
    stream.mime = 'text/plain'
    stream.output_encoding = 'utf8'
    chunk = 'Hello World'
    expected = b'Hello World'

    # Act
    actual = stream.process_body(chunk)

    # Assert
    assert actual == expected

# Generated at 2022-06-17 20:47:41.078930
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 20:47:46.735340
# Unit test for method get_headers of class PrettyStream

# Generated at 2022-06-17 20:48:01.027620
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessage
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_

# Generated at 2022-06-17 20:48:12.655195
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Test iter_body with a non-binary body
    msg = HTTPMessage(headers=b'', body=b'hello\nworld\n')
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'hello\n', b'world\n']

    # Test iter_body with a binary body
    msg = HTTPMessage(headers=b'', body=b'hello\x00world\n')
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    try:
        list(stream.iter_body())
    except BinarySuppressedError:
        pass
    else:
        assert False, 'BinarySuppressedError not raised'



# Generated at 2022-06-17 20:48:20.049607
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import is_windows
    from pygments.formatters import TerminalFormatter

    response = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        content=b'{"key": "value"}',
        encoding='utf8',
    )


# Generated at 2022-06-17 20:48:30.491915
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1
    stream = PrettyStream(None, None, None, None, None, None)
    chunk = '{"name": "John", "age": 30, "car": null}'
    assert stream.process_body(chunk) == b'{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 2
    stream = PrettyStream(None, None, None, None, None, None)
    chunk = '{"name": "John", "age": 30, "car": null}'
    assert stream.process_body(chunk) == b'{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 3

# Generated at 2022-06-17 20:48:39.959680
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
   

# Generated at 2022-06-17 20:49:05.611456
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream

# Generated at 2022-06-17 20:49:10.410327
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.streams import RawStream
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain\r\n\r\n',
        body=b'hello world'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'hello world']


# Generated at 2022-06-17 20:49:13.540265
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:49:20.138241
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test the constructor of class EncodedStream
    # Test the constructor of class RawStream
    # Test the constructor of class PrettyStream
    # Test the constructor of class BufferedPrettyStream
    # Test the constructor of class BaseStream
    # Test the constructor of class HTTPResponse
    # Test the constructor of class HTTPMessage
    # Test the constructor of class Headers
    # Test the constructor of class ContentType
    # Test the constructor of class ContentType
    # Test the constructor of class ContentType
    # Test the constructor of class ContentType
    # Test

# Generated at 2022-06-17 20:49:30.711507
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:49:42.866014
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.processing import Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.context import Environment
    from httpie.compat import is_windows

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.is_windows = is_windows()
    msg = HTTPMessage(headers=Headers({'Content-Type': 'application/json'}))
    formatting = Formatting(get_lexer('json', None), TerminalFormatter())
    stream = PrettyStream(msg, env=env, formatting=formatting)
    assert stream.get

# Generated at 2022-06-17 20:49:54.123523
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:50:02.253751
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test case 1:
    #   - body: '{"a": 1, "b": 2}'
    #   - mime: 'application/json'
    #   - conversion: None
    #   - formatting: None
    #   - output_encoding: 'utf8'
    #   - expected: '{"a": 1, "b": 2}'
    body = b'{"a": 1, "b": 2}'
    mime = 'application/json'
    conversion = None
    formatting = None
    output_encoding = 'utf8'
    expected = '{"a": 1, "b": 2}'
    msg = HTTPMessage(body=body, content_type=mime)

# Generated at 2022-06-17 20:50:12.211456
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    def test_iter_body(self, chunk_size, expected_output):
        self.msg.body = b'{"a": "b"}\n{"c": "d"}\n{"e": "f"}'
        self.msg.headers['Content-Type'] = 'application/json'
        self.msg.encoding = 'utf8'
        self.msg.content_type = 'application/json'
        self.msg.content_length = len(self.msg.body)
        self.msg.raw = self.msg.body
        self.msg.iter_lines = lambda chunk_size: self.msg.body.splitlines(True)
        self.msg

# Generated at 2022-06-17 20:50:22.027769
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:51:01.678807
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n' \
                  'Content-Type: application/json; charset=utf-8\r\n' \
                  'Content-Length: 2\r\n' \
                  '\r\n'
    msg.body = '[]'
    msg.encoding = 'utf8'
    msg.content_type = 'application/json; charset=utf-8'
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)

# Generated at 2022-06-17 20:51:06.290682
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import pytest
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer

    # Test case 1
    # Test the case that the body is binary
    # The method iter_body should raise BinarySuppressedError
    msg = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    )

# Generated at 2022-06-17 20:51:17.233049
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers='''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>''')
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)

# Generated at 2022-06-17 20:51:24.878782
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "text/html; charset=utf-8"},
                      body=b"<html>\n<body>\n<h1>Hello World</h1>\n</body>\n</html>")
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == 'utf8'
    assert stream.msg.encoding == 'utf8'
    assert stream.msg.headers.encode('utf8') == b'Content-Type: text/html; charset=utf-8'
    assert stream.msg.body == b"<html>\n<body>\n<h1>Hello World</h1>\n</body>\n</html>"

# Generated at 2022-06-17 20:51:32.809640
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:51:40.437740
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        headers={
            'Content-Type': 'text/plain; charset=utf8',
            'Content-Length': '10',
        },
        body=b'\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80',
        encoding='utf8',
    )
    stream = EncodedStream(msg)
    assert stream.output_encoding == 'utf8'

# Generated at 2022-06-17 20:51:49.493237
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_class
   

# Generated at 2022-06-17 20:51:57.705841
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'headers'
    msg.body = 'body'
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:52:07.681360
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test case data
    msg_data = b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nabc'
    msg = HTTPMessage(msg_data)
    # Perform the test
    result = b''.join(BaseStream(msg))
    # Verify the result
    assert result == msg_data
    # Perform the test
    result = b''.join(BaseStream(msg, with_headers=False))
    # Verify the result
    assert result == b'abc'
    # Perform the test
    result = b''.join(BaseStream(msg, with_body=False))
    # Verify the result
    assert result == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    # Perform the test


# Generated at 2022-06-17 20:52:15.436815
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE

# Generated at 2022-06-17 20:53:34.625311
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    import httpie.output.streams
    import httpie.models
    import httpie.output.processing
    import httpie.context
    import httpie.compat

    class MockResponse(httpie.models.HTTPMessage):
        def __init__(self, body, content_type):
            self.headers = httpie.compat.OrderedDict()
            self.headers['Content-Type'] = content_type
            self.body = body
            self.encoding = 'utf-8'

        def iter_body(self, chunk_size):
            yield self.body

    class MockConversion(httpie.output.processing.Conversion):
        def __init__(self):
            self.converters = {}

        def get_converter(self, mime):
            return self.con

# Generated at 2022-06-17 20:53:40.616991
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain\r\n\r\n',
        body=b'Hello World!\n'
    )
    stream = BaseStream(msg=msg)
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\n\r\n\r\n', b'Hello World!\n']


# Generated at 2022-06-17 20:53:49.665841
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.processing import Conversion, Formatting

    # Test case 1
    response = HTTPResponse(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        '\r\n'
        '{"key": "value"}'
    )

# Generated at 2022-06-17 20:53:55.336515
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'a:b\r\n', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:54:03.002042
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_isatty = False
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = None
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:54:13.691717
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import HeadersFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter
    from httpie.output.formatters import StreamFormatter

# Generated at 2022-06-17 20:54:25.597474
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test RawStream
    msg = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=[
            (b'Content-Type', b'application/json'),
            (b'Content-Length', b'18'),
        ],
        body=b'{"foo": "bar"}\n'
    )
    stream = RawStream(msg)

# Generated at 2022-06-17 20:54:35.081484
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    pretty_stream = PrettyStream(msg, with_headers, with_body, on_body_chunk_downloaded, conversion, formatting)
    assert pretty_stream.msg == msg
    assert pretty_stream.with_headers == with_headers
    assert pretty_stream.with_body == with_body
    assert pretty_stream.on_body_chunk_downloaded == on_body_chunk_downloaded
    assert pretty_stream.conversion == conversion
    assert pretty_stream.formatting == formatting


# Generated at 2022-06-17 20:54:40.119154
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test case data
    msg_data = b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nabc'
    msg = HTTPMessage.from_http(msg_data)
    # Perform the test
    result = b''.join(BaseStream(msg))
    # Verify the result
    assert result == msg_data


# Generated at 2022-06-17 20:54:49.846543
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import RawJSONFormatter
    from httpie.output.formatters import RawFormatter
    from httpie.output.formatters import RawURLEncodedFormatter
    from httpie.output.formatters import URLEncodedFormatter
    from httpie.output.formatters import HTMLFormatter
    from httpie.output.formatters import ImageFormatter
    from httpie.output.formatters import JavaScriptFormatter
    from httpie.output.formatters import CSSFormatter
    from httpie.output.formatters import CSVFormatter
    from httpie.output.formatters import TSVFormatter