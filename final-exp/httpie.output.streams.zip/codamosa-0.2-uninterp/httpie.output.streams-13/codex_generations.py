

# Generated at 2022-06-17 20:45:46.141311
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test if the constructor of class EncodedStream works
    # Create an instance of class EncodedStream
    stream = EncodedStream(msg=HTTPMessage(headers=''), with_headers=True, with_body=True)
    # Check if the instance is created
    assert stream is not None

# Generated at 2022-06-17 20:45:59.670659
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.compat import urlopen
    import requests
    import json
    import time
    import os
    import sys
    import re

    # get the response of the request
    response = urlopen('https://httpbin.org/get')
    # convert the response to HTTPResponse
    response = HTTPResponse(response)
    # create a RawStream object
    stream = RawStream(msg=response)
    # get the body of the response
    body = stream.iter_body()
    # convert the body to string
    body = ''.join(body)
    # convert the body to json
    body = json.loads(body)
    # get the url of the response

# Generated at 2022-06-17 20:46:04.382066
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(headers=None, body=None)
    stream = RawStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:46:12.844328
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    chunk = "chunk"
    mime = "mime"
    formatting = Formatting()
    conversion = Conversion()
    msg = HTTPMessage()
    msg.content_type = "content_type"
    msg.encoding = "encoding"
    stream = PrettyStream(conversion, formatting, msg=msg)
    stream.mime = mime
    # Act
    result = stream.process_body(chunk)
    # Assert
    assert result == b'chunk'

# Generated at 2022-06-17 20:46:21.465238
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:46:28.002063
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    msg.headers = 'test'
    msg.body = 'test'
    stream = EncodedStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:46:35.367264
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body="{}")
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.mime == "application/json"
    assert stream.output_encoding == "utf8"
    assert stream.formatting.format_headers(msg.headers) == "Content-Type: application/json"
    assert stream.process_body(msg.body) == "{}"


# Generated at 2022-06-17 20:46:44.382081
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion

# Generated at 2022-06-17 20:46:51.442964
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    msg = HTTPResponse()
    msg.headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 11

'''
    msg.body = 'Hello World'
    stream = BaseStream(msg)
    assert stream.__iter__() == [b'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 11\r\n\r\nHello World']


# Generated at 2022-06-17 20:47:02.371228
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test for EncodedStream
    msg = HTTPResponse(
        headers={'Content-Type': 'text/plain; charset=utf8'},
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8'
    )
    stream = EncodedStream(msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']

    # Test for RawStream
    msg = HT

# Generated at 2022-06-17 20:47:18.294523
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234']
    msg = HTTPMessage(headers=b'', body=b'1234')
    stream = RawStream(msg, chunk_size=2)
    assert list(stream.iter_body()) == [b'12', b'34']


# Generated at 2022-06-17 20:47:28.007490
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:47:31.612126
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers=b'', body=b'', encoding='utf8')
    stream = EncodedStream(msg=msg)
    assert stream.msg == msg
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:47:34.990296
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:47:42.507850
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.compat import urlopen
    from httpie.status import ExitStatus

    # Test for the method __iter__ of class BaseStream
    #
    # Create a response object
    response = urlopen('http://httpbin.org/get')
    # Create a HTTPResponse object
    http_response = HTTPResponse(response)
    # Create a BaseStream object
    stream = BaseStream(http_response)
    # Get the iterator
    iterator = stream.__iter__()
    # Get the first element of the iterator
    first_element = next(iterator)
    # Check if the first element is equal to the expected value

# Generated at 2022-06-17 20:47:44.089484
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(headers=b'', body=b'{"foo": "bar"}')
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.process_body(b'{"foo": "bar"}') == b'{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:47:52.678014
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:48:01.298265
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Test for constructor of class PrettyStream
    # Arrange
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    # Act
    pretty_stream = PrettyStream(conversion, formatting, msg, with_headers, with_body, on_body_chunk_downloaded)
    # Assert
    assert pretty_stream.msg == msg
    assert pretty_stream.with_headers == with_headers
    assert pretty_stream.with_body == with_body
    assert pretty_stream.on_body_chunk_downloaded == on_body_chunk_downloaded
    assert pretty_stream.formatting == formatting
    assert pretty_stream.conversion == conversion

# Generated at 2022-06-17 20:48:13.027471
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    import io
    import sys
    import unittest

    class TestEncodedStream(unittest.TestCase):
        def test_iter_body(self):
            # Arrange
            msg = HTTPResponse(
                url='http://httpbin.org/get',
                status_code=200,
                headers={'Content-Type': 'text/html; charset=utf-8'},
                content=b'<html><body>\xe4\xb8\xad\xe6\x96\x87</body></html>',
                encoding='utf-8',
            )
            stream = EncodedStream(msg)

            # Act
            result = b''.join(stream.iter_body())



# Generated at 2022-06-17 20:48:19.350029
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'text/plain'
    msg.body = 'test'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:48:48.286077
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import RawStream
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import Conversion
    from httpie.output.streams import Formatting

# Generated at 2022-06-17 20:49:00.334334
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:49:09.557916
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(b'\x00') == b'\x00'
    assert stream.process_body(b'\x00\x00') == b'\x00\x00'
    assert stream.process_body(b'\x00\x00\x00') == b'\x00\x00\x00'
    assert stream.process_body(b'\x00\x00\x00\x00') == b'\x00\x00\x00\x00'
    assert stream.process_body(b'\x00\x00\x00\x00\x00') == b'\x00\x00\x00\x00\x00'

# Generated at 2022-06-17 20:49:18.993036
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    es = EncodedStream(msg, env=env)
    assert es.output_encoding == 'utf8'
    env.stdout_isatty = False
    es = EncodedStream(msg, env=env)
    assert es.output_encoding == 'utf8'
    msg.encoding = None
    es = EncodedStream(msg, env=env)
    assert es.output_encoding == 'utf8'


# Generated at 2022-06-17 20:49:30.211220
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:49:42.746844
# Unit test for method iter_body of class RawStream

# Generated at 2022-06-17 20:49:54.035149
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test for class BaseStream
    msg = HTTPResponse()

# Generated at 2022-06-17 20:49:58.684895
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "text/plain"}, body="Hello World")
    stream = EncodedStream(msg=msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == "utf8"


# Generated at 2022-06-17 20:50:02.130925
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain\r\n\r\n',
        body=b'Hello World!\r\n'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello World!\r\n']



# Generated at 2022-06-17 20:50:11.810078
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg, chunk_size=3)
    assert list(stream.iter_body()) == [b'123', b'456', b'789', b'0']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg, chunk_size=1)

# Generated at 2022-06-17 20:51:00.005651
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_class

# Generated at 2022-06-17 20:51:10.485702
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b'1234567890']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg, chunk_size=3)
    assert list(stream.iter_body()) == [b'123', b'456', b'789', b'0']

    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg, chunk_size=1)

# Generated at 2022-06-17 20:51:20.857579
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_body of class BufferedPrettyStream
    # Test for method iter_

# Generated at 2022-06-17 20:51:31.225433
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:51:42.664709
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:51:50.542055
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    conversion = Conversion()

# Generated at 2022-06-17 20:51:55.272410
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\r\n'


# Generated at 2022-06-17 20:52:06.812361
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    import json

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    msg = Response(
        headers={'content-type': 'application/json'},
        encoding='utf8',
        body=json.dumps({'a': 'b'}).encode('utf8')
    )
    stream = BufferedPrettyStream(
        msg=msg,
        env=env,
        conversion=conversion,
        formatting=formatting
    )
    assert list(stream.iter_body()) == [b'{\n    "a": "b"\n}\n']



# Generated at 2022-06-17 20:52:12.309331
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87'
    )
    stream = EncodedStream(msg, with_headers=False, with_body=True)
    assert list(stream) == [b'\xe4\xb8\xad\xe6\x96\x87']



# Generated at 2022-06-17 20:52:22.522363
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 20:53:45.340828
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: application/json\r\n\r\n',
                      body=b'{"a": 1, "b": 2}')
    stream = BufferedPrettyStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'{\n    "a": 1,\n    "b": 2\n}']

# Generated at 2022-06-17 20:53:53.247216
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1:
    #   Input: chunk = '{"name": "httpie"}'
    #   Expected output: b'{\n    "name": "httpie"\n}'
    chunk = '{"name": "httpie"}'
    stream = PrettyStream(None, None, None, None, None, None)
    assert stream.process_body(chunk) == b'{\n    "name": "httpie"\n}'

    # Test case 2:
    #   Input: chunk = '{"name": "httpie"}'
    #   Expected output: b'{\n    "name": "httpie"\n}'
    chunk = '{"name": "httpie"}'
    stream = PrettyStream(None, None, None, None, None, None)

# Generated at 2022-06-17 20:54:03.109090
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test for the case that the body is binary
    msg = HTTPMessage(
        headers=b'Content-Type: application/json\r\n',
        body=b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    )
    stream = PrettyStream(msg=msg, with_headers=True, with_body=True)
    try:
        for chunk in stream.iter_body():
            print(chunk)
    except BinarySuppressedError as e:
        print(e.message)

    # Test for the case that the body is not binary

# Generated at 2022-06-17 20:54:13.719511
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
   

# Generated at 2022-06-17 20:54:25.597695
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_formatter
    from httpie.output.formatters.colors import PygmentsHTTPFormatter
    from httpie.output.formatters.colors import PygmentsJSONFormatter
    from httpie.plugins import plugin_manager

    # Create a HTTPResponse object

# Generated at 2022-06-17 20:54:36.028633
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']

    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87\xff'
    )
    stream = EncodedStream(msg=msg)

# Generated at 2022-06-17 20:54:46.480971
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import FormProcessor
    from httpie.plugins.builtin import URLEncodedProcessor
    from httpie.plugins.builtin import HTMLLexer
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PrettyJSONProcessor
    from httpie.plugins.builtin import PrettyURLEncodedProcessor
    from httpie.plugins.builtin import PrettyFormProcessor
   

# Generated at 2022-06-17 20:54:49.701719
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    # Act
    # Assert
    assert True

# Generated at 2022-06-17 20:55:01.704388
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter

    response = HTTPResponse(
        'HTTP/1.1 200 OK',
        headers={'Content-Type': 'application/json'},
        body=json.dumps({'a': 1, 'b': 2}).encode('utf8'),
        encoding='utf8'
    )
    conversion = Conversion()
    formatting = Formatting(
        get_lexer(JSONFormatter, response),
        TerminalFormatter()
    )


# Generated at 2022-06-17 20:55:12.854037
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_py26

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage(
        headers={'content-type': 'application/json'},
        encoding='utf8',
        body=b'{"foo": "bar"}'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting,
        env=env
    )
    assert stream.process_body(b'{"foo": "bar"}') == b'{\n    "foo": "bar"\n}'
    assert stream