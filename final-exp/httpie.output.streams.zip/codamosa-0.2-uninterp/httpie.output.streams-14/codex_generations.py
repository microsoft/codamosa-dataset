

# Generated at 2022-06-17 20:45:50.830415
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen

    response = Response(urlopen('https://httpbin.org/get'))
    stream = BufferedPrettyStream(
        msg=response,
        conversion=Conversion(),
        formatting=Formatting(),
        env=Environment(),
    )

# Generated at 2022-06-17 20:45:58.656373
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.streams import BaseStream

# Generated at 2022-06-17 20:46:03.791255
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import urlopen

    url = 'https://httpbin.org/get'
    response = urlopen(url)
    msg = HTTPResponse(response)
    conversion = Conversion()
    formatting = Formatting(get_lexer('json', None))
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting)
    for chunk in stream.iter_body():
        print(chunk)

# Generated at 2022-06-17 20:46:12.929650
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream

    response = Response(
        headers={'Content-Type': 'application/json'},
        status_code=200,
        body=b'{"foo": "bar"}'
    )

    stream = BufferedPrettyStream(
        msg=response,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
    )

    assert next(stream.iter_body()) == b'{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:46:21.494796
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n' \
                  'Content-Type: text/plain; charset=utf-8\r\n' \
                  'Content-Length: 12\r\n' \
                  '\r\n'
    msg.body = 'Hello world!'
    msg.encoding = 'utf-8'
    msg.content_type = 'text/plain; charset=utf-8'
    msg.content_length = 12
    msg.status_code = 200
    msg.status_line = 'HTTP/1.1 200 OK'

# Generated at 2022-06-17 20:46:26.944542
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert stream.get_headers() == b'Content-Type: application/json\r\n'

# Generated at 2022-06-17 20:46:38.669742
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY

# Generated at 2022-06-17 20:46:46.008698
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:47:00.179411
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import is_py26

    class MockResponse(HTTPResponse):
        def __init__(self, body, headers, encoding):
            self.body = body
            self.headers = headers
            self.encoding = encoding

        def iter_body(self, chunk_size):
            yield self.body

    body = b'{"foo": "bar"}'
    headers = {'Content-Type': 'application/json'}
    encoding = 'utf8'
    response = MockResponse(body, headers, encoding)
    conversion = Conversion()
    formatting = Format

# Generated at 2022-06-17 20:47:10.472413
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # BaseStream
    msg = Response(headers={"Content-Type": "text/plain"}, body="test")
    stream = BaseStream(msg)
    assert list(stream) == [b'test']

    # RawStream
    msg = Response(headers={"Content-Type": "text/plain"}, body="test")
    stream = RawStream(msg)
    assert list(stream) == [b'test']

    # EncodedStream

# Generated at 2022-06-17 20:47:25.738614
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'text/html'
    msg.body = 'test'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:47:36.714903
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSupp

# Generated at 2022-06-17 20:47:48.545320
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1: chunk is a str
    chunk = "test"
    mime = "text/plain"
    formatting = Formatting()
    stream = PrettyStream(None, formatting, None, None, None, None)
    assert stream.process_body(chunk) == b'test'

    # Test case 2: chunk is a bytes
    chunk = b"test"
    mime = "text/plain"
    formatting = Formatting()
    stream = PrettyStream(None, formatting, None, None, None, None)
    assert stream.process_body(chunk) == b'test'

    # Test case 3: chunk is a bytes and mime is application/json
    chunk = b"test"
    mime = "application/json"
    formatting = Formatting()

# Generated at 2022-06-17 20:48:01.988939
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-17 20:48:09.183606
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!\n'
    )
    stream = RawStream(msg)
    assert b''.join(stream) == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nHello World!\n'


# Generated at 2022-06-17 20:48:17.386091
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_isatty = False
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = None
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:48:27.307830
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n' \
                  'Content-Type: text/plain\r\n' \
                  'Content-Length: 4\r\n' \
                  '\r\n'
    msg.body = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'text/plain'
    stream = RawStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.chunk_size == 102400


# Generated at 2022-06-17 20:48:35.097082
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:48:42.088105
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:48:51.488127
# Unit test for constructor of class EncodedStream

# Generated at 2022-06-17 20:49:30.828163
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:49:42.782416
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import io
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen
    from httpie.status import ExitStatus

    # Test for a normal response
    response = urlopen('https://httpbin.org/get')
    stream = EncodedStream(HTTPResponse(response), with_headers=False, with_body=True)
    assert b'\n' in b''.join(stream.iter_body())

    # Test for a binary response
    response = urlopen('https://httpbin.org/image/png')
    stream = EncodedStream(HTTPResponse(response), with_headers=False, with_body=True)

# Generated at 2022-06-17 20:49:46.158710
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:49:59.570792
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import get_lexer

    conversion = Conversion()
    formatting = Formatting(
        get_lexer(None, None),
        JSONFormatter(),
        HeadersFormatter()
    )

# Generated at 2022-06-17 20:50:05.578390
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers=b'Content-Type: text/plain\r\n\r\n', body=b'hello')
    stream = BaseStream(msg)
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\n\r\n\r\n', b'hello']


# Generated at 2022-06-17 20:50:14.397330
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError

    # Test for method __iter__ of class BaseStream

# Generated at 2022-06-17 20:50:16.068343
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    # Act
    # Assert
    pass

# Generated at 2022-06-17 20:50:17.826527
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    # Act
    # Assert
    assert True

# Generated at 2022-06-17 20:50:26.296011
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE

# Generated at 2022-06-17 20:50:36.445445
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py33
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36

# Generated at 2022-06-17 20:51:22.347458
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test for constructor of class EncodedStream
    # Arrange
    msg = HTTPMessage(headers=b'', body=b'')
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    env = Environment()

    # Act
    stream = EncodedStream(msg=msg, with_headers=with_headers, with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded, env=env)

    # Assert
    assert stream.msg == msg
    assert stream.with_headers == with_headers
    assert stream.with_body == with_body
    assert stream.on_body_chunk_downloaded == on_body_chunk_downloaded
    assert stream.output_encoding == 'utf8'



# Generated at 2022-06-17 20:51:31.089207
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n', body=b'Hello World!')
    stream = EncodedStream(msg=msg)
    assert stream.msg.headers == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    assert stream.msg.body == b'Hello World!'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:51:38.019083
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test case data
    msg_data = b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nabc'
    msg = HTTPMessage(msg_data)
    # Perform the test
    result = list(BaseStream(msg))
    # Verify the result
    assert result == [b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n', b'abc']


# Generated at 2022-06-17 20:51:48.448078
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:52:00.140921
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream

    # Test case 1
    msg = HTTPResponse(
        headers={'Content-Type': 'text/plain'},
        body=b'{"foo": "bar"}',
        encoding='utf8'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=False,
        with_body=True
    )
    body = b''.join(stream.iter_body())
    assert body == b'{\n    "foo": "bar"\n}'

    # Test case 2

# Generated at 2022-06-17 20:52:06.820560
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
    Content-Type: text/plain; charset=utf-8
    Content-Length: 12
    '''
    msg.body = 'Hello World!'
    msg.encoding = 'utf8'
    stream = BaseStream(msg)
    assert list(stream) == [b'HTTP/1.1 200 OK\r\n    Content-Type: text/plain; charset=utf-8\r\n    Content-Length: 12\r\n    \r\n\r\n', b'Hello World!']


# Generated at 2022-06-17 20:52:15.046625
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Test case 1:
    #   chunk: '{"id": 1, "name": "A green door", "price": 12.50, "tags": ["home", "green"]}'
    #   chunk_size: 1
    #   mime: 'application/json'
    #   output_encoding: 'utf8'
    #   conversion: None
    #   formatting: None
    #   expected_output: '{"id": 1, "name": "A green door", "price": 12.50, "tags": ["home", "green"]}'
    chunk = '{"id": 1, "name": "A green door", "price": 12.50, "tags": ["home", "green"]}'
    chunk_size = 1
    mime = 'application/json'
    output_encoding = 'utf8'
    conversion

# Generated at 2022-06-17 20:52:24.310769
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:52:31.836253
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\n'
                b'Content-Type: text/plain; charset=utf-8\r\n'
                b'\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']



# Generated at 2022-06-17 20:52:41.670639
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None)
    assert stream.process_body(b'\x00') == b'\x00'
    assert stream.process_body(b'\x00\x00') == b'\x00\x00'
    assert stream.process_body(b'\x00\x00\x00') == b'\x00\x00\x00'
    assert stream.process_body(b'\x00\x00\x00\x00') == b'\x00\x00\x00\x00'
    assert stream.process_body(b'\x00\x00\x00\x00\x00') == b'\x00\x00\x00\x00\x00'

# Generated at 2022-06-17 20:53:29.932264
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'Content-Type: text/html\r\n')
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: text/html\r\n'



# Generated at 2022-06-17 20:53:34.588813
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert stream.get_headers() == b'Content-Type: application/json\r\n'

# Generated at 2022-06-17 20:53:44.634776
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.plugins import plugin_manager
    from pygments.formatters import TerminalFormatter
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
   

# Generated at 2022-06-17 20:53:52.737372
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)

    msg = HTTPResponse(
        headers={
            'Content-Type': 'text/html; charset=utf-8',
            'Content-Length': '10',
        },
        body=b'1234567890',
        encoding='utf8',
    )
    stream = RawStream(msg, env=env, conversion=conversion, formatting=formatting)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:54:02.952426
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import plugin_manager
    from httpie.compat import urlopen

    response = urlopen('https://httpbin.org/get')
    response = HTTPResponse(response)
    response.encoding = 'utf8'
    conversion = Conversion()
    formatting = Formatting(get_lexer(None, 'json', None))
    stream = PrettyStream(response, conversion, formatting)
    plugin_manager.load_installed_plugins()
    for chunk in stream.iter_body():
        print(chunk)


# Generated at 2022-06-17 20:54:13.658224
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 20:54:25.603181
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.models import HTTPMessage
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:54:30.815377
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body="{\"key\": \"value\"}")
    stream = PrettyStream(msg=msg, conversion=Conversion(), formatting=Formatting())
    assert stream.process_body("{\"key\": \"value\"}") == b'{\n    "key": "value"\n}'

# Generated at 2022-06-17 20:54:38.941005
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-17 20:54:49.014019
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response