

# Generated at 2022-06-17 20:45:47.220047
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87\n',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']



# Generated at 2022-06-17 20:45:54.075038
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\n'


# Generated at 2022-06-17 20:45:59.110554
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(headers={"Content-Type": "text/html"}, body="<html></html>")
    stream = PrettyStream(msg, conversion=None, formatting=None, with_headers=False, with_body=True)
    assert stream.process_body("<html></html>") == b"<html></html>"

# Generated at 2022-06-17 20:46:04.849704
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.compat import is_py2
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.compat import is_py2
    from httpie.context import Environment
    from httpie.models import Response
    from httpie.output.streams import PrettyStream

# Generated at 2022-06-17 20:46:10.157829
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n')
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'


# Generated at 2022-06-17 20:46:20.720515
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import urlopen
    from httpie.downloads import ResponseWriter
    import io
    import sys
    import os
    import tempfile
    import shutil
    import contextlib

    @contextlib.contextmanager
    def temp_dir():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)

    with temp_dir() as temp_dir:
        url = 'https://httpbin.org/encoding/utf8'
        response = urlopen(url)

# Generated at 2022-06-17 20:46:32.189869
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    stream = BaseStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    stream = BaseStream(msg, with_headers=False, with_body=False)
    assert stream.msg == msg
    assert stream.with_headers == False
    assert stream.with_body == False
    assert stream.on_body_chunk_downloaded == None
    stream = BaseStream(msg, with_headers=False, with_body=False, on_body_chunk_downloaded=lambda x: x)
    assert stream.msg == msg
    assert stream.with_headers == False
    assert stream.with_body == False
    assert stream.on_body_

# Generated at 2022-06-17 20:46:42.536346
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting, Conversion
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    import json

    # Create a message with a JSON body
    url = 'https://httpbin.org/get'
    response = urlopen(url)
    msg = HTTPMessage(response)
    msg.headers['Content-Type'] = 'application/json'
    msg.encoding = 'utf8'

    # Create a formatting object
    lexer = get_lexer('json')
    formatter

# Generated at 2022-06-17 20:46:47.623538
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\nContent-Type: text/plain\n\n'


# Generated at 2022-06-17 20:46:58.193612
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']


# Generated at 2022-06-17 20:47:20.701446
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    import httpie.output.streams
    import httpie.models
    import httpie.output.processing
    import httpie.context
    import httpie.output.formatters
    import httpie.output.converters

    # Create a HTTPMessage object
    msg = httpie.models.HTTPMessage(
        headers=httpie.models.Headers(
            content_type='application/json; charset=utf-8',
            status_line='HTTP/1.1 200 OK'
        ),
        body=json.dumps({'key': 'value'}).encode('utf-8')
    )

    # Create a BufferedPrettyStream object

# Generated at 2022-06-17 20:47:28.974731
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.compat import is_py26
    from httpie.context import Environment

    env = Environment()
    conversion = Conversion()
    formatting = Formatting(
        get_lexer(JSONFormatter.mimetype, None),
        TerminalFormatter(bg='dark')
    )

# Generated at 2022-06-17 20:47:38.548374
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import io
    import json
    from httpie.models import HTTPRequest
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()

    # Test for binary data
    request = HTTPRequest('GET', 'http://httpbin.org/get')
    request.body = b'\0'
    stream = BufferedPrettyStream(request, env=env, conversion=conversion, formatting=formatting)
    try:
        for _ in stream.iter_body():
            pass
    except BinarySuppressedError:
        pass
    else:
        assert False

    # Test for text data
    request = HTTPRequest('GET', 'http://httpbin.org/get')

# Generated at 2022-06-17 20:47:48.820084
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n'
    msg.headers += 'Content-Type: application/json\r\n'
    msg.headers += 'Content-Length: 2\r\n'
    msg.headers += '\r\n'
    msg.body = '{}'
    msg.encoding = 'utf8'
    msg.content_type = 'application/json'

    stream = BufferedPrettyStream(msg, True, True)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\nContent-Type: application/json\nContent-Length: 2\n\n'
    assert stream.iter_body() == [b'{\n    \n}\n']

# Generated at 2022-06-17 20:48:02.217029
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f')
    stream = EncodedStream(msg=msg)
    try:
        for chunk in stream.iter_body():
            pass
    except BinarySuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE
    else:
        assert False

# Generated at 2022-06-17 20:48:12.280802
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import io
    import json
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream

    body = io.BytesIO(b'{"a": "b"}\n{"c": "d"}')
    response = HTTPResponse(200, 'OK', {'Content-Type': 'application/json'}, body)
    stream = PrettyStream(response, conversion=None, formatting=None)
    assert list(stream.iter_body()) == [json.dumps({'a': 'b'}).encode('utf8'), b'\n', json.dumps({'c': 'd'}).encode('utf8')]

# Generated at 2022-06-17 20:48:19.892950
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_py26


# Generated at 2022-06-17 20:48:30.354287
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.colors import get_style_by_name
    from httpie.output.formatters.colors import get_theme
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from pygments.styles import get_style_by_name
    from pygments.styles import get_all_styles
    from pygments.styles import get_style_by_name
    from pygments.styles import get_style_by_name
    from pygments.styles import get

# Generated at 2022-06-17 20:48:39.449407
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n'
    msg.headers += 'Content-Type: application/json\r\n'
    msg.headers += '\r\n'
    msg.body = '{"name": "httpie"}'
    msg.encoding = 'utf8'
    msg.content_type = 'application/json'
    msg.content_length = len(msg.body)
    msg.status_code = 200
    msg.status_line = 'HTTP/1.1 200 OK'

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'

    conversion = Conversion()
    formatting = Formatting()

    stream = BufferedPrettyStream(msg, conversion, formatting, env)

# Generated at 2022-06-17 20:48:49.607308
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import HeadersFormatter
    from httpie.output.formatters import get_formatter
    from httpie.output.formatters import get_headers_formatter
    from httpie.output.formatters import get_json_formatter
    from httpie.output.formatters import get_formatter_by_mime
    from httpie.output.formatters import get_formatter_by_filename
    from httpie.output.formatters import get_formatter_by_mime_or_filename
    from httpie.output.formatters import get_formatter_by_mime_or_

# Generated at 2022-06-17 20:49:19.832123
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-17 20:49:22.746786
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    # Act
    # Assert
    pass

# Generated at 2022-06-17 20:49:25.891422
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={'Content-Type': 'text/plain'}, body='abc')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'abc']


# Generated at 2022-06-17 20:49:30.112380
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\r\n'


# Generated at 2022-06-17 20:49:42.746726
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_request

# Generated at 2022-06-17 20:49:54.035381
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import JSONResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    headers = {'Content-Type': 'application/json'}
    body = json.dumps({'foo': 'bar'})
    msg = JSONResponse(200, headers, body)

    conversion = Conversion()
    formatting = Formatting(get_lexer(JSONFormatter()))
    stream = BufferedPrettyStream(msg, conversion=conversion, formatting=formatting)

    assert next(stream.iter_body()) == b'{\n    "foo": "bar"\n}'

# Generated at 2022-06-17 20:50:02.196183
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion, Formatting

    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    # Test for iter_body of class EncodedStream
    #

# Generated at 2022-06-17 20:50:11.881420
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import plugin_manager
    from pygments.lexers import JsonLexer
    from pygments.lexers import HtmlLexer
    from pygments.lexers import XmlLexer

    # test for json
    msg = HTTPResponse(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: application/json\r\n'
        '\r\n'
        '{"key": "value"}'
    )

# Generated at 2022-06-17 20:50:18.546474
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    msg.headers = "header"
    msg.encoding = "utf8"
    msg.content_type = "text/html"
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.msg == msg
    assert stream.conversion == conversion
    assert stream.formatting == formatting
    assert stream.mime == "text/html"
    assert stream.output_encoding == "utf8"


# Generated at 2022-06-17 20:50:21.194024
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.msg == msg
    assert stream.conversion == conversion
    assert stream.formatting == formatting
    assert stream.mime == ''


# Generated at 2022-06-17 20:51:06.036629
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()
    msg = Response(
        content_type='application/json',
        headers={'Content-Type': 'application/json'},
        body=b'{"a": "b"}',
        encoding='utf8'
    )
    stream = BufferedPrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting,
        with_headers=True,
        with_body=True
    )

# Generated at 2022-06-17 20:51:16.955137
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-17 20:51:24.709665
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_content_type
    from httpie.output.processing import Conversion, Formatting
    import json

    # Test data
    data = {'name': 'John', 'age': 30, 'city': 'New York'}
    json_data = json.dumps(data)
    msg = HTTPResponse(
        url='http://example.com',
        status_code=200,
        headers={'Content-Type': 'application/json'},
        content=json_data
    )

    # Test conversion
    conversion = Conversion()

# Generated at 2022-06-17 20:51:30.840785
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:51:42.456959
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.context import Environment
    from httpie.compat import urlopen

    env = Environment()
    conversion = Conversion(env)
    conversion.add_converter(JSONConverter)
    formatting = Formatting(env)
    formatting.add_formatter(JSONFormatter)
    response = urlopen('https://api.github.com/repos/jakubroztocil/httpie')
    response = HTTPResponse(response)
    stream = PrettyStream(response, conversion, formatting, env=env)


# Generated at 2022-06-17 20:51:50.222201
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:51:59.414087
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:52:06.749972
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']
    stream = RawStream(msg, chunk_size=5)
    assert list(stream.iter_body()) == [b'12345', b'67890']
    stream = RawStream(msg, chunk_size=3)
    assert list(stream.iter_body()) == [b'123', b'456', b'789', b'0']


# Generated at 2022-06-17 20:52:15.015778
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Test case 1
    msg = HTTPMessage(
        headers={"Content-Type": "text/plain; charset=utf8"},
        encoding='utf8',
        body=b'\x80'
    )
    stream = PrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        conversion=Conversion(),
        formatting=Formatting()
    )
    assert stream.output_encoding == 'utf8'
    assert stream.mime == 'text/plain'
    assert stream.formatting.format_headers(msg.headers) == 'Content-Type: text/plain; charset=utf8'
    assert stream.process_body(b'\x80') == b'\xc2\x80'


# Generated at 2022-06-17 20:52:24.280764
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.context import Environment

# Generated at 2022-06-17 20:53:52.860574
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Test case 1
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    # Test case 2
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')
    stream = PrettyStream(msg, with_headers=False, with_body=True)
    assert stream.get_headers() == b''
    # Test case 3

# Generated at 2022-06-17 20:54:01.232562
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n' \
                  'Content-Type: text/plain; charset=utf-8\r\n' \
                  'Content-Length: 12\r\n' \
                  '\r\n' \
                  'hello world!'
    stream = RawStream(msg)
    assert stream.get_headers() == msg.headers.encode('utf8')
    assert list(stream.iter_body()) == [b'hello world!']


# Generated at 2022-06-17 20:54:08.807737
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']

# Generated at 2022-06-17 20:54:15.898097
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()

    msg = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: text/plain; charset=utf-8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf-8',
    )

    stream = EncodedStream(msg, env=env)

# Generated at 2022-06-17 20:54:27.724939
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPResponse(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'hello world\n'
    )
    stream = RawStream(msg=msg, with_headers=True, with_body=True)


# Generated at 2022-06-17 20:54:37.623856
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE

# Generated at 2022-06-17 20:54:44.507405
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    chunk = '{"key": "value"}'
    mime = 'application/json'
    formatting = Formatting()
    conversion = Conversion()
    stream = PrettyStream(conversion=conversion, formatting=formatting)
    stream.mime = mime

    # Act
    result = stream.process_body(chunk)

    # Assert
    assert result == b'{\n    "key": "value"\n}'

# Generated at 2022-06-17 20:54:48.561622
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers=b'headers', body=b'body')
    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert list(stream) == [b'headers', b'\r\n\r\n', b'body']



# Generated at 2022-06-17 20:55:01.359772
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n"
    msg.headers += "Content-Type: text/plain; charset=utf-8\r\n"
    msg.headers += "Content-Length: 12\r\n"
    msg.headers += "\r\n"
    msg.body = "Hello world!"
    msg.encoding = "utf-8"
    stream = EncodedStream(msg)
    assert stream.output_encoding == "utf8"
    assert stream.get_headers() == b"HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 12\r\n\r\n"

# Generated at 2022-06-17 20:55:12.513469
# Unit test for method iter_body of class EncodedStream