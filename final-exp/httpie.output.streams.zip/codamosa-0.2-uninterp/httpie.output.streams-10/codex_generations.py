

# Generated at 2022-06-17 20:45:57.138532
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.downloads import Downloader
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
   

# Generated at 2022-06-17 20:46:03.402167
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.compat
    import httpie.output.formatters
    import httpie.output.formatters.colors
    import httpie.output.formatters.colors.__init__
    import httpie.output.formatters.colors.__init__
    import httpie.output.formatters.colors.__init__
    import httpie.output.formatters.colors.__init__
    import httpie.output.formatters.colors.__init__
    import httpie.output.formatters.colors.__init__
    import httpie.output.formatters.colors.__init__
    import httpie.output.formatters.colors.__init__

# Generated at 2022-06-17 20:46:14.385220
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1:
    # Input: chunk = '{"a": "b"}'
    # Expected output: b'{\n    "a": "b"\n}'
    chunk = '{"a": "b"}'
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body=chunk)
    stream = PrettyStream(msg=msg, conversion=Conversion(), formatting=Formatting())
    assert stream.process_body(chunk) == b'{\n    "a": "b"\n}'

    # Test case 2:
    # Input: chunk = '{"a": "b"}'
    # Expected output: b'{\n    "a": "b"\n}'
    chunk = '{"a": "b"}'

# Generated at 2022-06-17 20:46:18.242138
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(headers=None, body=None)
    stream = RawStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:46:28.171572
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    msg = HTTPMessage(headers={"Content-Type": "text/html"}, body="<html></html>")
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    stream = BufferedPrettyStream(msg=msg, env=env, conversion=conversion, formatting=formatting)
    assert stream.msg == msg
    assert stream.env == env
    assert stream.conversion == conversion
    assert stream.formatting == formatting
    assert stream.mime == "text/html"
    assert stream.output_encoding == "utf8"
    assert stream.CHUNK_SIZE == 1024 * 10

# Generated at 2022-06-17 20:46:32.233504
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:46:35.917210
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import httpie.output.streams
    import httpie.models
    import httpie.output.processing
    import httpie.context
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.compat
    import httpie.plugins
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.compat
    import httpie.plugins
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.compat
    import httpie.plugins
    import httpie.cli
    import httpie.output.streams

# Generated at 2022-06-17 20:46:44.601986
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:46:54.213057
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream


# Generated at 2022-06-17 20:47:03.303783
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_by_name

# Generated at 2022-06-17 20:47:21.808911
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: application/json\r\n',
        body=b'{"a": 1, "b": 2}',
        encoding='utf8'
    )
    stream = BufferedPrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(indent=2)
    )
    assert list(stream.iter_body()) == [b'{\n  "a": 1,\n  "b": 2\n}']

# Generated at 2022-06-17 20:47:30.260978
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    response = Response(
        'HTTP/1.1 200 OK',
        CRLF.join([
            'Content-Type: application/json; charset=utf-8',
            '',
            '{"a": 1}'
        ]).encode('utf8')
    )

    conversion = Conversion()

# Generated at 2022-06-17 20:47:39.368355
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
   

# Generated at 2022-06-17 20:47:49.945474
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting

    msg = HTTPMessage(
        headers={'Content-Type': 'application/json'},
        body=b'{"foo": "bar"}'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(
            colors=False,
            format='pretty',
            indent=2,
            max_json_depth=None,
            max_json_size=None,
            syntax='pygments',
            verbose=False,
        ),
        with_headers=False,
        with_body=True,
    )
    assert stream.process_body(b'{"foo": "bar"}') == b

# Generated at 2022-06-17 20:47:57.006421
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n"
    msg.headers += "Content-Type: text/plain\r\n"
    msg.headers += "Content-Length: 12\r\n"
    msg.headers += "\r\n"
    msg.body = "Hello World!"
    stream = RawStream(msg)
    assert stream.get_headers() == b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 12\r\n\r\n"
    assert list(stream.iter_body()) == [b"Hello World!"]


# Generated at 2022-06-17 20:48:07.406317
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import json
    import httpie.output.streams

    # Create a dummy HTTPMessage object
    msg = HTTPMessage(
        headers=httpie.output.streams.Headers(),
        body=json.dumps({'a': 'b'}),
        encoding='utf8',
        content_type='application/json'
    )

    # Create a dummy Environment object
    env = Environment()

    # Create a dummy Conversion object
    conversion = Conversion()

    # Create a dummy Formatting object
    formatting = Formatting()

    # Create a BufferedPrettyStream object
    stream = BufferedPrettyStream(
        msg=msg,
        env=env,
        conversion=conversion,
        formatting=formatting
    )

    # Test iter_body

# Generated at 2022-06-17 20:48:17.715544
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer

    msg = Response(
        status_line=b'HTTP/1.1 200 OK',
        headers={'Content-Type': 'application/json'},
        body=b'{"a": 1, "b": 2}'
    )

# Generated at 2022-06-17 20:48:28.533947
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37
    from httpie.compat import is_py38

# Generated at 2022-06-17 20:48:36.653341
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'text/html'
    msg.body = 'test'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.msg == msg
    assert stream.output_encoding == 'utf8'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:48:43.964092
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']


# Generated at 2022-06-17 20:49:16.071511
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Test for method iter_body of class RawStream
    # Purpose:
    #     Test if the method iter_body of class RawStream returns the correct
    #     value
    # Method:
    #     - Create a RawStream object
    #     - Call the method iter_body
    #     - Check if the returned value is correct
    # Pre-conditions:
    #     - None
    # Post-conditions:
    #     - None
    # Return:
    #     - None
    # Possible errors:
    #     - None

    # Create a RawStream object
    raw_stream = RawStream()
    # Call the method iter_body
    result = raw_stream.iter_body()
    # Check if the returned value is correct

# Generated at 2022-06-17 20:49:19.879127
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    stream = EncodedStream(msg=HTTPMessage(headers=b'', body=b''))
    assert stream.output_encoding == 'utf8'
    assert stream.msg.encoding == 'utf8'
    assert stream.with_headers
    assert stream.with_body
    assert stream.on_body_chunk_downloaded is None


# Generated at 2022-06-17 20:49:22.000433
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers=b'Content-Type: text/plain\r\n\r\n', body=b'hello')
    stream = BaseStream(msg)
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\n', b'\r\n\r\n', b'hello']


# Generated at 2022-06-17 20:49:31.417904
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response

# Generated at 2022-06-17 20:49:42.969946
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response

# Generated at 2022-06-17 20:49:54.224714
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.compat import str

    # Test case 1:
    #   - body is a string
    #   - body is not binary
    #   - body is not empty
    #   - body is encoded in utf-8
    #   - output_encoding is utf-8
    #   - body contains a unicode character
    #   - body contains a unicode character that is not supported by
    #     output_encoding
    #   - body contains a unicode character that is not supported by
    #     output_encoding and is replaced by a unicode replacement character
    #     (U+FFFD)
    #   - body contains a unicode character that is not supported by
    #     output_encoding

# Generated at 2022-06-17 20:50:01.800106
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    msg = HTTPMessage(headers=None, body=None, encoding=None)
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    stream = EncodedStream(msg=msg, with_headers=with_headers, with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded, env=env)
    assert stream.msg == msg
    assert stream.with_headers == with_headers
    assert stream.with_body == with_body
    assert stream.on_body_chunk_downloaded == on_body_chunk_downloaded
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:50:10.300416
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers='''HTTP/1.1 200 OK
Date: Wed, 03 Apr 2019 12:03:32 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 13
Connection: keep-alive
Server: nginx/1.14.0 (Ubuntu)

''')
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'''HTTP/1.1 200 OK
Date: Wed, 03 Apr 2019 12:03:32 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 13
Connection: keep-alive
Server: nginx/1.14.0 (Ubuntu)

'''


# Generated at 2022-06-17 20:50:18.609000
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        headers={"Content-Type": "text/html; charset=utf-8"},
        encoding="utf-8",
        body=b"<html>\n<body>\n<h1>Hello World</h1>\n</body>\n</html>\n",
    )
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == "utf-8"
    assert stream.msg.encoding == "utf-8"
    assert stream.msg.headers.encode("utf-8") == b"Content-Type: text/html; charset=utf-8"
    assert stream.msg.body == b"<html>\n<body>\n<h1>Hello World</h1>\n</body>\n</html>\n"

# Generated at 2022-06-17 20:50:27.137854
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:51:16.859435
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\n'

# Generated at 2022-06-17 20:51:24.655687
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Create a message
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!',
        encoding='utf8'
    )
    # Create an EncodedStream
    stream = EncodedStream(msg=msg)
    # Check the output encoding
    assert stream.output_encoding == 'utf8'
    # Check the message
    assert stream.msg == msg
    # Check the headers
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    # Check the body
    assert list(stream.iter_body()) == [b'Hello World!']


# Generated at 2022-06-17 20:51:32.732017
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import Formatter
    from httpie.output.formatters import RawFormatter
    from httpie.output.formatters import HeadersFormatter
    from httpie.output.formatters import URLEncodedFormatter
    from httpie.output.formatters import FormattedItem
    from httpie.output.formatters import FormattedKeyValue
    from httpie.output.formatters import FormattedResponseHeaders
    from httpie.output.formatters import FormattedRequestHeaders
    from httpie.output.formatters import FormattedBody
    from httpie.output.formatters import FormattedJSON
    from httpie.output.formatters import FormattedURLE

# Generated at 2022-06-17 20:51:43.885966
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion

# Generated at 2022-06-17 20:51:50.750337
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    env.stdout_isatty = False
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = None
    stream = EncodedStream(msg, env=env)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:51:59.647971
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Test case 1:
    #   Input:
    #       msg = HTTPMessage(headers={"Content-Type": "text/html"},
    #                         body="<html><body>Hello World!</body></html>")
    #       with_headers = True
    #       with_body = True
    #       on_body_chunk_downloaded = None
    #   Expected output:
    #       headers = b'Content-Type: text/html\r\n\r\n'
    #       body = b'<html><body>Hello World!</body></html>'
    msg = HTTPMessage(headers={"Content-Type": "text/html"},
                      body="<html><body>Hello World!</body></html>")
    with_headers = True
    with_body = True
    on_

# Generated at 2022-06-17 20:52:06.896286
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    stream = PrettyStream(msg=None, with_headers=False, with_body=True, on_body_chunk_downloaded=None)
    stream.formatting = Formatting()
    stream.conversion = Conversion()
    stream.mime = 'text/plain'
    stream.output_encoding = 'utf8'
    chunk = 'test'
    expected = b'test'

    # Act
    actual = stream.process_body(chunk)

    # Assert
    assert actual == expected

# Generated at 2022-06-17 20:52:15.094474
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test for method __iter__ of class BaseStream
    # Test case 1
    # This test case is to test the case that the message is streamed in chunks with no processing.
    # The expected result is that the message is streamed in chunks with no processing.
    msg = HTTPResponse(
        headers={'Content-Type': 'text/plain'},
        body=b'Hello World!\n'
    )
    stream = RawStream(msg)

# Generated at 2022-06-17 20:52:24.341954
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n'
    msg.headers += 'Content-Type: text/plain\r\n'
    msg.headers += 'Content-Length: 3\r\n'
    msg.headers += '\r\n'
    msg.body = 'abc'
    stream = RawStream(msg)
    assert stream.msg.headers == 'HTTP/1.1 200 OK\r\n'
    assert stream.msg.headers == 'Content-Type: text/plain\r\n'
    assert stream.msg.headers == 'Content-Length: 3\r\n'
    assert stream.msg.headers == '\r\n'
    assert stream.msg.body == 'abc'
    assert stream.with_headers == True

# Generated at 2022-06-17 20:52:33.442307
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']

    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8',
        body=b'\xe4\xb8\xad\xe6\x96\x87\0',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg)

# Generated at 2022-06-17 20:54:15.011321
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test RawStream
    response = HTTPResponse(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: text/plain\r\n'
        '\r\n'
        'Hello World\n'
        '\n'
        'HTTPie!\n'
    )
    stream = RawStream(response)
    assert b''.join(stream) == b'Hello World\n\nHTTPie!\n'

    # Test EncodedStream

# Generated at 2022-06-17 20:54:25.967992
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test 1
    stream = PrettyStream(
        msg=HTTPMessage(
            headers=b'Content-Type: application/json',
            body=b'{"a": "b"}'
        ),
        conversion=Conversion(),
        formatting=Formatting()
    )
    assert stream.process_body(b'{"a": "b"}') == b'{\n    "a": "b"\n}'

    # Test 2
    stream = PrettyStream(
        msg=HTTPMessage(
            headers=b'Content-Type: application/json',
            body=b'{"a": "b"}'
        ),
        conversion=Conversion(),
        formatting=Formatting(
            indent=4,
            sort_keys=True,
            colors=True
        )
    )
    assert stream.process_body

# Generated at 2022-06-17 20:54:33.619884
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']



# Generated at 2022-06-17 20:54:44.921728
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import RawJSONFormatter

# Generated at 2022-06-17 20:54:48.601596
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:55:01.360176
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import is_py26

    env = Environment()
    env.stdout_isatty = False
    env.stdout_encoding = 'utf8'
    msg = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers=b'Content-Type: application/json\r\n',
        body=b'{"key": "value"}',
        encoding='utf8',
    )
    conversion = Conversion()
    conversion.add_

# Generated at 2022-06-17 20:55:12.512666
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:55:23.422094
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.plugins import plugin_manager
    from pygments.lexers import HttpLexer
    from pygments.formatters import TerminalFormatter
    from pygments.util import ClassNotFound

    # Initialize the environment
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'

    # Initialize the conversion
    conversion = Conversion()

# Generated at 2022-06-17 20:55:32.597449
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-17 20:55:38.767206
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_output