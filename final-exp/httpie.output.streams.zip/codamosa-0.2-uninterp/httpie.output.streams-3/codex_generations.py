

# Generated at 2022-06-17 20:45:59.736184
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        headers={"Content-Type": "text/html; charset=utf-8"},
        body=b"<html>\n<head>\n<title>\u4f60\u597d</title>\n</head>\n</html>\n",
        encoding="utf-8",
    )
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == "utf-8"
    assert stream.msg.encoding == "utf-8"
    assert stream.msg.body == b"<html>\n<head>\n<title>\u4f60\u597d</title>\n</head>\n</html>\n"

# Generated at 2022-06-17 20:46:06.811310
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers={"Content-Type": "text/plain; charset=utf8"},
        body="\u00e5\u00e4\u00f6\u00fc".encode("utf8"),
        encoding="utf8",
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [
        b"\xc3\xa5\xc3\xa4\xc3\xb6\xc3\xbc\n"
    ]



# Generated at 2022-06-17 20:46:18.163837
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import plugin_manager
    from pygments.lexers import JsonLexer
    from pygments.lexers import HtmlLexer
    from pygments.lexers import XmlLexer
    from pygments.lexers import JavascriptLexer
    from pygments.lexers import CssLexer
    from pygments.lexers import PythonLexer
    from pygments.lexers import YamlLexer
    from pygments.lexers import TextLexer
    from pygments.lexers import BashLexer
    from pygments.lexers import DiffLexer
    from pygments.lexers import JsonLexer
    from pygments.lexers import Json

# Generated at 2022-06-17 20:46:24.209991
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = 'test'
    msg.encoding = 'utf8'
    msg.content_type = 'text/html'
    msg.iter_body = lambda: iter([b'<html><body>'])
    stream = BufferedPrettyStream(msg=msg, with_headers=True, with_body=True)
    assert stream.msg.headers == 'test'
    assert stream.msg.encoding == 'utf8'
    assert stream.msg.content_type == 'text/html'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'
    assert stream.formatting.format_headers('test') == 'test'
   

# Generated at 2022-06-17 20:46:31.541882
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8'
    )
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']



# Generated at 2022-06-17 20:46:38.287724
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8\r\n',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']



# Generated at 2022-06-17 20:46:41.247914
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:46:47.394396
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_terminal

# Generated at 2022-06-17 20:46:53.210355
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n\r\n', b'hello world')
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'hello world']


# Generated at 2022-06-17 20:47:02.984665
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:47:20.201485
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\n'
                b'Content-Type: text/plain\r\n'
                b'Content-Length: 10\r\n'
                b'\r\n',
        body=b'0123456789'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'0123456789']



# Generated at 2022-06-17 20:47:28.670015
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test for RawStream
    request = HTTPRequest('GET', 'http://httpbin.org/get')
    stream = RawStream(request)
    assert b'GET /get HTTP/1.1\r\n' in stream
    assert b'Host: httpbin.org\r\n' in stream
    assert b'Accept: */*\r\n' in stream
    assert b'Accept-Encoding: gzip, deflate\r\n' in stream
    assert b'Connection: keep-alive\r\n' in stream

# Generated at 2022-06-17 20:47:38.326620
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError


# Generated at 2022-06-17 20:47:49.710178
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.compat import is_windows
    from httpie.context import Environment
    import json

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'

    response = HTTPResponse(
        status_line=b'HTTP/1.1 200 OK',
        headers={'Content-Type': 'application/json'},
        body=b'{"foo": "bar"}'
    )

    conversion = Conversion()
    formatting

# Generated at 2022-06-17 20:48:02.597313
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:48:10.573910
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    test_stream = PrettyStream(
        msg=None,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        conversion=None,
        formatting=None
    )

    # Act
    result = test_stream.process_body(b'{"key": "value"}')

    # Assert
    assert result == b'{\n    "key": "value"\n}'

# Generated at 2022-06-17 20:48:14.932420
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers='')
    msg.body = b'1234567890'
    msg.headers = 'Content-Length: 10'
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'1234567890']


# Generated at 2022-06-17 20:48:18.041705
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(headers=b'headers', body=b'body')
    stream = RawStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:48:28.629638
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py2
    from httpie.compat import is_py3
    from httpie.compat import is_py33
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37

# Generated at 2022-06-17 20:48:30.955366
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, conversion=None, formatting=None)
    assert stream.get_headers() == b'Content-Type: application/json\n'

# Generated at 2022-06-17 20:49:01.452702
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_converter
    from httpie.output.formatters.utils import get_formatter
    from httpie.output.formatters.utils import get_format_options
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import HTTPBody
    from httpie.plugins.builtin import HTTPTraceback
    from httpie.plugins.builtin import HTTPError
    from httpie.plugins.builtin import HTTPStats

# Generated at 2022-06-17 20:49:08.784402
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test for constructor of class EncodedStream
    # Arrange
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    # Act
    stream = EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    # Assert
    assert stream.msg == msg
    assert stream.with_headers == with_headers
    assert stream.with_body == with_body
    assert stream.on_body_chunk_downloaded == on_body_chunk_downloaded


# Generated at 2022-06-17 20:49:16.850744
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:49:24.085621
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'', body=b'1234567890')
    stream = RawStream(msg=msg)
    assert list(stream.iter_body()) == [b'1234567890']
    stream = RawStream(msg=msg, chunk_size=5)
    assert list(stream.iter_body()) == [b'12345', b'67890']


# Generated at 2022-06-17 20:49:32.801849
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import Conversion
    from httpie.output.streams import Formatting

# Generated at 2022-06-17 20:49:43.739687
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Create a message
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n',
        body=b'{"a": 1, "b": 2}'
    )
    # Create a PrettyStream
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )
    # Get the body
    body = b''.join(stream.iter_body())
    # Check the body
    assert body == b'{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-17 20:49:49.156758
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(headers={"Content-Type": "text/html"}, body="<html></html>")
    stream = RawStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:49:59.162053
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    stream = EncodedStream(msg, env)
    assert stream.output_encoding == 'utf8'
    env.stdout_isatty = False
    stream = EncodedStream(msg, env)
    assert stream.output_encoding == 'utf8'
    msg.encoding = None
    stream = EncodedStream(msg, env)
    assert stream.output_encoding == 'utf8'


# Generated at 2022-06-17 20:50:02.903312
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    headers = Headers([('Content-Type', 'application/json')])
    stream = PrettyStream(msg=None, headers=headers, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'


# Generated at 2022-06-17 20:50:12.332349
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessage
    from httpie.output.streams import BaseStream
    msg = HTTPMessage(headers=b'Content-Type: text/plain\r\n\r\n', body=b'abc')
    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\n', b'\r\n\r\n', b'abc']
    stream = BaseStream(msg, with_headers=False, with_body=True)
    assert list(stream) == [b'abc']
    stream = BaseStream(msg, with_headers=True, with_body=False)

# Generated at 2022-06-17 20:50:58.928682
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test case 1
    # Test if the encoding is correct
    # The input is a HTTPMessage object
    # The output is a EncodedStream object
    # The expected result is the encoding is utf8
    msg = HTTPMessage(headers={"Content-Type": "text/plain; charset=utf8"},
                      body=b'\xe4\xbd\xa0\xe5\xa5\xbd\n')
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == 'utf8'

    # Test case 2
    # Test if the encoding is correct
    # The input is a HTTPMessage object
    # The output is a EncodedStream object
    # The expected result is the encoding is utf8

# Generated at 2022-06-17 20:51:09.596110
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\n" \
                  "Content-Type: application/json\r\n" \
                  "Content-Length: 13\r\n" \
                  "Connection: keep-alive\r\n" \
                  "Date: Wed, 19 Dec 2018 09:59:20 GMT\r\n" \
                  "Server: nginx/1.10.3 (Ubuntu)\r\n" \
                  "X-Powered-By: PHP/7.2.5\r\n" \
                  "X-RateLimit-Limit: 60\r\n" \
                  "X-RateLimit-Remaining: 59\r\n" \
                  "X-RateLimit-Reset: 1545183560\r\n" \
                 

# Generated at 2022-06-17 20:51:19.980306
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import urlopen
    from pygments import highlight
    from pygments.formatters import TerminalFormatter
    import json

    # Test with a JSON response
    response = urlopen('https://api.github.com/repos/jakubroztocil/httpie')
    response = HTTPResponse(response)
    conversion = Conversion()
    formatting = Formatting(get_lexer(JSONFormatter), TerminalFormatter())

# Generated at 2022-06-17 20:51:30.916688
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:51:35.159504
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(headers={"Content-Type": "text/html"}, body="<html>")
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert list(stream.iter_body()) == [b'<html>']


# Generated at 2022-06-17 20:51:46.010918
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-17 20:51:49.148495
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n\r\nHello World!')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'Hello World!']


# Generated at 2022-06-17 20:51:53.207201
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg=msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'


# Generated at 2022-06-17 20:52:00.757412
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPretty

# Generated at 2022-06-17 20:52:08.931700
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(headers='')
    msg.encoding = 'utf8'
    msg.content_type = 'application/json'
    stream = PrettyStream(msg, conversion=None, formatting=None)
    assert stream.process_body('{"a": 1}') == b'{\n    "a": 1\n}'
    msg.content_type = 'text/plain'
    assert stream.process_body('{"a": 1}') == b'{"a": 1}'
    msg.content_type = 'text/plain'
    assert stream.process_body(b'{"a": 1}') == b'{"a": 1}'

# Generated at 2022-06-17 20:53:38.033538
# Unit test for method __iter__ of class BaseStream

# Generated at 2022-06-17 20:53:43.938290
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers=b'Content-Type: text/plain; charset=utf8\r\n',
        body=b'\xe4\xb8\xad\xe6\x96\x87',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg, with_headers=False)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']



# Generated at 2022-06-17 20:53:50.197573
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPRequest
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen

    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    response = urlopen('https://httpbin.org/get')
    msg = HTTPRequest(response)
    stream = PrettyStream(msg, conversion, formatting, env=env)
    for chunk in stream.iter_body():
        print(chunk)

# Generated at 2022-06-17 20:54:00.828420
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    response = Response(
        status_code=200,
        headers={'Content-Type': 'application/json'},
        body=json.dumps({'a': 1, 'b': 2})
    )

    stream = PrettyStream(
        msg=response,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=False,
        with_body=True
    )

    for chunk in stream.iter_body():
        print(chunk)

# Generated at 2022-06-17 20:54:06.080162
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json"})
    stream = PrettyStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == b'Content-Type: application/json\r\n\r\n'


# Generated at 2022-06-17 20:54:14.679576
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Test for iter_body method of class EncodedStream
    # Create a HTTPMessage object
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n',
        body=b'<html><body>\xe4\xb8\xad\xe6\x96\x87</body></html>',
        encoding='utf-8'
    )
    # Create an EncodedStream object
    stream = EncodedStream(msg=msg)
    # Get the iterable object
    iterable = stream.iter_body()
    # Get the first item
    item = next(iterable)
    # Check the first item

# Generated at 2022-06-17 20:54:20.836578
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n')
    stream = PrettyStream(msg, conversion=None, formatting=None)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'

# Generated at 2022-06-17 20:54:26.868345
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']



# Generated at 2022-06-17 20:54:30.960514
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.msg == msg
    assert stream.conversion == conversion
    assert stream.formatting == formatting

# Generated at 2022-06-17 20:54:34.724376
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "text/html"})
    stream = PrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert stream.get_headers() == b'Content-Type: text/html\r\n\r\n'