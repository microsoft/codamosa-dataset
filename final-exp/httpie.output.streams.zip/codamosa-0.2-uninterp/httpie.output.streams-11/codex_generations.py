

# Generated at 2022-06-17 20:45:59.737808
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.compat import is_py26
    from httpie.compat import is_windows
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37
    from httpie.compat import is_py38
    from httpie.compat import is_py39
    from httpie.compat import is_py310
    from httpie.compat import is_py311

# Generated at 2022-06-17 20:46:05.833675
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\n']



# Generated at 2022-06-17 20:46:17.133124
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37

# Generated at 2022-06-17 20:46:27.873904
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE


# Generated at 2022-06-17 20:46:36.505465
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test for method __iter__ of class BaseStream
    # Creation of a HTTPMessage object
    msg = HTTPMessage(headers={'Content-Type': 'text/plain'},
                      body=b'Hello World!')
    # Creation of a BaseStream object
    stream = BaseStream(msg=msg, with_headers=True, with_body=True)
    # Test the __iter__ method
    assert list(stream) == [b'Content-Type: text/plain\r\n\r\n', b'Hello World!']


# Generated at 2022-06-17 20:46:44.782264
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import pytest
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPResponse(
        'HTTP/1.1 200 OK\r\n'
        'Content-Type: text/plain\r\n'
        '\r\n'
        'Hello World!'
    )
    stream = PrettyStream(msg, conversion=conversion, formatting=formatting)
    assert list(stream.iter_body()) == [b'Hello World!']


# Generated at 2022-06-17 20:46:48.828408
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # test for constructor
    msg = HTTPMessage()
    env = Environment()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded)


# Generated at 2022-06-17 20:47:01.223940
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test case data
    msg_data = b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nabc'
    msg = HTTPMessage.from_bytes(msg_data)
    # Perform the test
    result = b''.join(BaseStream(msg, with_headers=True, with_body=True))
    # Verify the result
    assert result == msg_data
    # Perform the test
    result = b''.join(BaseStream(msg, with_headers=True, with_body=False))
    # Verify the result
    assert result == msg_data[:-4]
    # Perform the test
    result = b''.join(BaseStream(msg, with_headers=False, with_body=True))
    # Verify the result

# Generated at 2022-06-17 20:47:11.605994
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import conversion

# Generated at 2022-06-17 20:47:23.287346
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream

# Generated at 2022-06-17 20:47:41.141443
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting, Conversion
    from httpie.models import HTTPMessage
    from httpie.context import Environment
    from httpie.compat import is_windows
    import json

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stdout_raw = False
    env.colors = 256
    env.style = 'monokai'
    env.stream = False
    env.verbose = False
    env.debug = False
    env.download_dir = None
    env.download_insecure = False
    env.download_resume = False
    env.download_session = None
    env.follow_redirects = True

# Generated at 2022-06-17 20:47:47.989604
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(headers={"Content-Type": "application/json"}, body="{}")
    stream = BufferedPrettyStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:48:01.743833
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    import requests
    import json
    import os
    import sys
    import io
    import unittest

    class TestRawStream(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.env.stdout = io.BytesIO()
            self.env.stdout_isatty = False
            self.env.stdout_encoding = 'utf8'


# Generated at 2022-06-17 20:48:05.844850
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import is_windows
    from pygments.formatters import TerminalFormatter
    from pygments.lexers import JsonLexer
    from httpie.context import Environment
    import json

    env = Environment()
    conversion = Conversion()
    formatting = Formatting(
        get_lexer(JSONFormatter.mime, JsonLexer),
        TerminalFormatter(bg='dark')
    )

# Generated at 2022-06-17 20:48:16.576535
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import get_stream
    from httpie.output.streams import get_stream_for_response

# Generated at 2022-06-17 20:48:27.993582
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test with_headers = True and with_body = True
    msg = HTTPMessage(headers=b'headers', body=b'body')
    stream = BaseStream(msg, with_headers=True, with_body=True)
    assert list(stream) == [b'headers', b'\r\n\r\n', b'body']

    # Test with_headers = True and with_body = False
    msg = HTTPMessage(headers=b'headers', body=b'body')
    stream = BaseStream(msg, with_headers=True, with_body=False)
    assert list(stream) == [b'headers', b'\r\n\r\n']

    # Test with_headers = False and with_body = True

# Generated at 2022-06-17 20:48:35.474587
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.compat import urlopen

    url = 'https://httpbin.org/get'
    response = urlopen(url)
    msg = HTTPResponse(response)
    stream = PrettyStream(msg, with_headers=True, with_body=True)
    prettifier = get_prettifier(get_lexer(None, stream.mime))
    for chunk in stream.iter_body():
        print(chunk)
        # print(prettifier.prettify(chunk))


# Generated at 2022-06-17 20:48:41.596598
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream

    msg = HTTPRequest(
        method='GET',
        url='http://httpbin.org/get',
        headers={'Accept': 'application/json'},
        body=b'{"foo": "bar"}',
        encoding='utf8',
    )

    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
    )

    assert list(stream.iter_body()) == [
        b'{\n    "foo": "bar"\n}\n'
    ]

# Generated at 2022-06-17 20:48:51.195046
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Test with_headers = True, with_body = True
    msg = HTTPMessage(headers={"Content-Type": "text/plain; charset=utf-8"},
                      body=b"Hello World")
    stream = EncodedStream(msg=msg, with_headers=True, with_body=True)
    assert stream.output_encoding == 'utf8'
    assert stream.get_headers() == b"Content-Type: text/plain; charset=utf-8\r\n"
    assert list(stream.iter_body()) == [b"Hello World"]

    # Test with_headers = False, with_body = True
    msg = HTTPMessage(headers={"Content-Type": "text/plain; charset=utf-8"},
                      body=b"Hello World")

# Generated at 2022-06-17 20:49:01.093231
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test for method __iter__ of class BaseStream

# Generated at 2022-06-17 20:49:30.822366
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.processing import ContentType
    from httpie.output.processing import ContentTypeExtension
    from httpie.output.processing import ContentTypeJSON
    from httpie.output.processing import ContentTypeHTML
    from httpie.output.processing import ContentTypeXML
    from httpie.output.processing import ContentTypeForm
    from httpie.output.processing import ContentTypeURLEncoded
    from httpie.output.processing import ContentTypeMultip

# Generated at 2022-06-17 20:49:37.716831
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!',
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello World!']


# Generated at 2022-06-17 20:49:43.221448
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/plain; charset=utf8',
                      body=b'\xe4\xb8\xad\xe6\x96\x87')
    stream = EncodedStream(msg=msg)
    assert list(stream.iter_body()) == [b'\xe4\xb8\xad\xe6\x96\x87\r\n']


# Generated at 2022-06-17 20:49:54.384718
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessage
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    from httpie.output.streams import output_encoding
    from httpie.output.streams import mime

# Generated at 2022-06-17 20:50:02.420698
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-17 20:50:12.024765
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    # Test for class BaseStream
    with pytest.raises(NotImplementedError):
        BaseStream(HTTPResponse(b'', 200, '')).__iter__()

    # Test for class RawStream
    assert RawStream(HTTPResponse(b'', 200, '')).__iter__() == [b'']
    assert RawStream(HTTPResponse(b'', 200, ''), with_headers=False).__iter__() == [b'']
    assert Raw

# Generated at 2022-06-17 20:50:17.115840
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n',
        body=b'Hello World!\n'
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello World!\n']


# Generated at 2022-06-17 20:50:25.743917
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test case 1
    msg = HTTPMessage(
        headers=b'Content-Type: application/json\r\n',
        body=b'{"key": "value"}',
        encoding='utf8',
        content_type='application/json'
    )
    stream = PrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting()
    )
    assert stream.process_body(b'{"key": "value"}') == b'{\n    "key": "value"\n}'

    # Test case 2

# Generated at 2022-06-17 20:50:30.157636
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.msg == msg
    assert stream.conversion == conversion
    assert stream.formatting == formatting


# Generated at 2022-06-17 20:50:36.002266
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()
    msg.headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 6

'''
    msg.body = '''<html>
</html>'''
    msg.encoding = 'utf-8'
    stream = BufferedPrettyStream(msg=msg)
    assert list(stream.iter_body()) == [b'<html>\n</html>']

# Generated at 2022-06-17 20:51:21.869091
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(headers={"Content-Type": "text/plain"}, body="hello")
    stream = RawStream(msg)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-17 20:51:31.764737
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream

    # Test for EncodedStream
    # Test for iter_body
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with binary data
    # Test for iter_body with

# Generated at 2022-06-17 20:51:43.214135
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_prettifier
    from httpie.output.formatters.utils import get_content_type
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError

# Generated at 2022-06-17 20:51:46.335867
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    stream = PrettyStream(msg, conversion, formatting)
    assert stream.msg == msg
    assert stream.conversion == conversion
    assert stream.formatting == formatting

# Generated at 2022-06-17 20:51:59.067570
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting()

    msg = HTTPResponse(
        headers={'Content-Type': 'application/json'},
        encoding='utf8',
        body=b'{"a": 1, "b": 2}'
    )

    stream = BufferedPrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting
    )

    assert list(stream.iter_body()) == [b'{\n    "a": 1,\n    "b": 2\n}']

# Generated at 2022-06-17 20:52:09.267972
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType

# Generated at 2022-06-17 20:52:16.205032
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier
    from httpie.output.formatters.utils import get_prettifier

# Generated at 2022-06-17 20:52:24.811469
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters import JSONFormatter
    from httpie.output.converters import JSONConverter
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.context import Environment
    from httpie.models import HTTPMessage

# Generated at 2022-06-17 20:52:33.762389
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import CHUNK_SIZE

# Generated at 2022-06-17 20:52:39.485221
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    msg.body = 'Hello, world!'
    msg.encoding = 'utf8'
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'Hello, world!']


# Generated at 2022-06-17 20:54:09.655743
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import Response
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.compat import urlopen
    from httpie.downloads import Downloader
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DataSuppressedError
    from httpie.output.streams import BinarySuppressedError
    from httpie.output.streams import BaseStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream

# Generated at 2022-06-17 20:54:14.468592
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers={"Content-Type": "text/html; charset=utf-8"},
                      body=b"<html></html>",
                      encoding="utf-8")
    stream = EncodedStream(msg=msg)
    assert stream.output_encoding == "utf8"
    assert stream.msg.encoding == "utf-8"
    assert stream.msg.body == b"<html></html>"
    assert stream.msg.headers == "Content-Type: text/html; charset=utf-8"
    assert stream.msg.content_type == "text/html; charset=utf-8"
    assert stream.msg.content_type.split(";")[0] == "text/html"
    assert stream.msg.iter_body(1) == [b"<html></html>"]

# Generated at 2022-06-17 20:54:25.798305
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        'GET / HTTP/1.1',
        headers=Headers([
            'Content-Type: text/plain; charset=utf8',
            'Content-Length: 10',
        ]),
        body=b'\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89',
        encoding='utf8',
    )
    stream = EncodedStream(msg=msg, with_headers=False, with_body=True)

# Generated at 2022-06-17 20:54:36.213232
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-17 20:54:37.893300
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Test for method process_body of class PrettyStream
    # Arrange
    # Act
    # Assert
    assert True

# Generated at 2022-06-17 20:54:44.333134
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(headers={"Content-Type": "application/json"},
                      body=b'{"name": "test"}\n{"name": "test2"}\n')
    stream = PrettyStream(msg, conversion=Conversion(),
                          formatting=Formatting())
    assert list(stream.iter_body()) == [b'{\n    "name": "test"\n}\n',
                                        b'{\n    "name": "test2"\n}\n']

# Generated at 2022-06-17 20:54:52.169788
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter

    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test for method iter_body of class PrettyStream
    # Test

# Generated at 2022-06-17 20:54:57.419735
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers=b'header', body=b'body')
    stream = BaseStream(msg=msg)
    assert list(stream) == [b'header\r\n\r\nbody']


# Generated at 2022-06-17 20:55:02.874345
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-17 20:55:13.799001
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import httpie.output.streams
    import httpie.models
    import httpie.output.processing
    import httpie.output.formatters
    import httpie.output.converters
    import httpie.output.streams
    import httpie.context
    import httpie.cli
    import httpie.compat
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.builtin.auth
    import httpie.plugins.builtin.core
    import httpie.plugins.builtin.download
    import httpie.plugins.builtin.form
    import httpie.plugins.builtin.generic
    import httpie.plugins.builtin.help
    import httpie.plugins.builtin.http
    import httpie.plugins.builtin.prompt