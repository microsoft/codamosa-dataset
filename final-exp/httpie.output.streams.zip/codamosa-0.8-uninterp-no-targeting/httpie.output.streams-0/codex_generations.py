

# Generated at 2022-06-21 14:24:10.445802
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    if hasattr(PrettyStream, 'conversion') and hasattr(PrettyStream, 'formatting') and hasattr(PrettyStream, 'mime'):
        print("{} has defined attribute: conversion, formatting and mime.".format(PrettyStream))

# Generated at 2022-06-21 14:24:14.804809
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    env = Environment()
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    p = PrettyStream(msg, conversion, formatting, env)
    assert p.msg == msg
    assert p.conversion == conversion
    assert p.formatting == formatting


# Generated at 2022-06-21 14:24:21.597689
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Headers
    from io import BytesIO

    headers = Headers([(':authority', 'www.google.com'), ('x-client-data', 'CJe2yQEIorbJAQiptskBCKmdygEIqKPKAQ==')])
    headers.output = BytesIO()
    print(headers.encode('utf8'))

BaseStream(HTTPMessage('Get', 'https://www.google.com', 'HTTP/1.1')).get_headers()

test_BaseStream_get_headers()

# Generated at 2022-06-21 14:24:28.854807
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting

    request = HTTPRequest('GET', 'http://localhost/', headers={}, data="")
    response = HTTPResponse(request, '', headers={}, encoding="utf-8", raw=None)

    conversion = Conversion()
    formatting = Formatting()

    stream = PrettyStream(response, conversion, formatting, with_headers=True, with_body=True)

# Generated at 2022-06-21 14:24:37.536703
# Unit test for constructor of class BaseStream
def test_BaseStream():
    request = HTTPMessage(
        headers=[
            'GET / HTTP/1.1',
            'Host: localhost:8080'
        ],
        body=b'data'
    )
    stream = BaseStream(
        msg=request,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=lambda _: None
    )
    assert stream.with_headers
    assert stream.with_body
    assert stream.on_body_chunk_downloaded is not None

    request = HTTPMessage(
        headers=[
            'GET / HTTP/1.1',
            'Host: localhost:8080'
        ],
        body=b'data'
    )

# Generated at 2022-06-21 14:24:39.048886
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    d = DataSuppressedError("test")
    assert d.message == "test"

# Generated at 2022-06-21 14:24:43.751458
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    msg = HTTPMessage([])
    assert list(BaseStream(msg=msg).iter_body()) == []
    msg = HTTPMessage([], body='abc')
    assert list(BaseStream(msg=msg).iter_body()) == []


# Generated at 2022-06-21 14:24:45.656601
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    assert PrettyStream(HTTPMessage(), with_headers=True, with_body=True)

# Generated at 2022-06-21 14:24:49.648882
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    with open(_filename, 'rb') as fd:
        msg = HTTPMessage.from_stream(fd, method='GET', url="http://127.0.0.1:5000/index")
        stream = RawStream(msg)
        for chunk in stream.iter_body():
            print(chunk)
            print()
    # END


# Generated at 2022-06-21 14:24:54.952403
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    iface = BufferedPrettyStream(
        'http://httpbin.org/get',
        'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{"hello": "world"}',
        'ascii'
        )
    assert iface == 'hello world'

# Generated at 2022-06-21 14:25:12.229179
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import HTTPRequest, HTTPResponse
    # Create a stream for a request
    req = HTTPRequest(headers={'Accept': 'application/json'},
    form={'a': 'b'},
    )
    # req.headers.content_type = 'application/json'
    stream = BaseStream(req)
    assert issubclass(type(stream), BaseStream)
    assert issubclass(type(stream), BaseStream) == True
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None

    # Create a stream for a response
    res = HTTPResponse()
    # res.headers.content_type = 'application/json'
    stream = BaseStream(res)

# Generated at 2022-06-21 14:25:15.223785
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError().message == \
            b'\n+-----------------------------------------+\n'\
            b'| NOTE: binary data not shown in terminal |\n'\
            b'+-----------------------------------------+'

# Generated at 2022-06-21 14:25:22.694712
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Response
    msg = Response('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n')
    stream = BaseStream(msg, True, False)
    s = stream.get_headers()
    assert(s == b'Content-Type: text/plain\r\n\r\n')


# Generated at 2022-06-21 14:25:29.544264
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    try:
        env=Environment()
        msg=HTTPMessage()
        s=EncodedStream(msg, with_headers=True, with_body=True, env=env, on_body_chunk_downloaded=None )
        print(s)
    except DataSuppressedError as e:
        print(e.message)
    except:
        print("Opps! Exception")


# Generated at 2022-06-21 14:25:32.848847
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Test
    class test_msg(HTTPMessage):
        def get_headers(self):
            return "fake headers"
    p = PrettyStream(
        msg=test_msg(),
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        conversion=Conversion(),
        formatting=Formatting(),
    )
    assert p.get_headers() == 'fake headers'
    return



# Generated at 2022-06-21 14:25:41.742103
# Unit test for constructor of class RawStream
def test_RawStream():
    print("\nTesting constructor of class RawStream:\n")
    request = {
        'headers': {
            'User-Agent': 'httpie',
            'Accept-Encoding': 'gzip',
            'Content-Type': 'application/json'
        },
        'auth': ('user', 'passwd'),
        'http_version': 'HTTP/1.1',
        'method': 'GET',
        'path': '/get',
        'body': 'Hello World'
    }
    msg = HTTPMessage(is_request=True, **request)
    test_stream = RawStream(msg) \
        .get_headers()
    print(test_stream)


# Generated at 2022-06-21 14:25:53.641158
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import (
        Response,
        Headers,
        ContentType,
        Params,
    )
    from httpie.output.streams import PrettyStream

    def iter_lines(size):
        chunks = [
            b'line1',
            b'line2',
            b'line3',
            b'line4',
        ]
        for chunk in chunks:
            yield chunk, b'\r\n'

    response = Response(
        code=200,
        body=b'',
        headers=Headers({'content-type': ContentType.APPLICATION_JSON}),
    )
    msg = response
    msg.encoding = 'utf8'

# Generated at 2022-06-21 14:25:57.408701
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    error = BinarySuppressedError()
    assert error.message == b"\n+-----------------------------------------+\n| NOTE: binary data not shown in terminal |\n+-----------------------------------------+"


# Generated at 2022-06-21 14:26:08.587221
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert 1 == 1

if __name__ == '__main__':
    import sys
    import os
    import pytest
    from subprocess import STDOUT
    from requests.models import Response
    from httpie.context import Environment
    from httpie.client import HTTPie
    from httpie.downloads import Downloader
    from httpie.output import streams

    # Unit test for constructor of class BaseStream
    test_BaseStream = False
    if(test_BaseStream):
        env = Environment()
        http_version = "HTTP/1.1"
        status_code = 200
        headers_dict = {'Connection': 'close', 'Server': 'nginx/1.13.9'}
        response = Response()
        # create a BaseStream object
        stream = streams.BaseStream(response)
    
    # Unit test for

# Generated at 2022-06-21 14:26:15.936339
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    data = {'this': 1, 'that': 2}  # {"that": 2, "this": 1}
    stream = RawStream(msg, True, True)
    all = bytes([])
    for chunk in stream:
        all += chunk
    assert all == b'HTTP/1.1 200 OK\r\nContent-Length: 13\r\nContent-Type: application/json; charset=utf-8\r\n\r\n{"that": 2, "this": 1}'


# Generated at 2022-06-21 14:26:33.850919
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream

    msg = HTTPResponse(200, 'OK', headers={}, body=b'abc\r\n123')
    stream = PrettyStream(msg, conversion=None, formatting=None, with_body=False)
    stream.iter_body()

# Generated at 2022-06-21 14:26:35.405093
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass

# Generated at 2022-06-21 14:26:37.925101
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    print("Testing constructor of class PrettyStream")
    pretty_stream = PrettyStream()
    assert isinstance(pretty_stream, PrettyStream)

# Generated at 2022-06-21 14:26:44.859016
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    with open('test/test_filename.txt', 'rb') as f:
        raw = f.read()
    msg = HTTPMessage.from_raw(raw)
    stream = BaseStream(msg)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nServer: nginx\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: 9\r\nConnection: keep-alive\r\nVary: Accept-Encoding\r\n\r\n'
    

# Generated at 2022-06-21 14:26:47.837341
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:26:50.226514
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    test_mime = "application/json"
    print("The mime is " + test_mime)


# Generated at 2022-06-21 14:26:53.618675
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    class MessageStreamTest(BaseStream):
        def __init__(self, msg=None, **kwargs):
            if msg is None:
                msg = HTTPMessage(headers="Accept:\n\n", body=b"\x00\n")
            super().__init__(msg, **kwargs)
    print(list(MessageStreamTest().iter_body()))

if __name__ == '__main__':
    test_BaseStream_iter_body()

# Generated at 2022-06-21 14:26:54.003845
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    ValueError("test")

# Generated at 2022-06-21 14:26:59.828089
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    """This is a test for iter_body of class BaseStream"""
    parameters = {'with_body': True}
    test_msg = HTTPMessage(version=b'1.1',
                           code=b'200',
                           phrase=b'OK',
                           headers={b'content-type': b'text/plain',
                                    b'user-agent': b'HTTPie'})
    test_msg.body = b'Hello world'
    test = BaseStream(msg=test_msg, **parameters)
    assert test.iter_body() is None


# Generated at 2022-06-21 14:27:10.230537
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import logging
    import sys

    from httpie.cli import http
    from utils import HTTPBIN_URL
    env = http.Environment()
    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

    class Dummy():
        def __init__(self, method, url, headers, content_type, encoding, body):
            self.method = method
            self.url = url
            self.headers = headers
            self.content_type = content_type
            self.encoding = encoding
            self.body = body

    dummy = Dummy('get', HTTPBIN_URL + '/get', '', '', 'utf8', '{"args": "abcd"}')
    dummy_stream = RawStream(dummy)
    print([i for i in dummy_stream])
    # assert t

# Generated at 2022-06-21 14:27:33.872583
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    with pytest.raises(TypeError):
        DataSuppressedError()

# Generated at 2022-06-21 14:27:42.497012
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    """
    Test that iter_body returns correct values
    :return:
    """
    message = HTTPMessage(
        headers={"Content-Type": "text/plain"},
        body="Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n",
        encoding="utf8"
    )

    stream = PrettyStream(
        msg=message,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        env=Environment(),
        conversion=None,
        formatting=None
    )

    assert list(stream.iter_body()) == [
        b'Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n'
    ]


# Generated at 2022-06-21 14:27:44.648634
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    error = DataSuppressedError(BINARY_SUPPRESSED_NOTICE)
    assert error.message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-21 14:27:48.311096
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    result = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)


# Generated at 2022-06-21 14:27:55.961515
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    # Method process_body should convert text to bytes, then encode
    # that to output_encoding.
    output_encoding = "utf8"
    chunk = "this is test text"
    formatting = Formatting()
    conversion = Conversion()
    stream = PrettyStream(conversion=conversion, formatting=formatting, msg=None, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    stream.output_encoding = output_encoding
    processed_text = stream.process_body(chunk)
    assert(processed_text == chunk.encode(stream.output_encoding, "replace"))

    # Method process_body should transform chunk according to formatting settings
    # if mime is text/html

# Generated at 2022-06-21 14:27:57.208389
# Unit test for constructor of class BaseStream
def test_BaseStream():
    
    assert BaseStream(None, True, True)


# Generated at 2022-06-21 14:28:02.482523
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    msg.method = 'GET'
    msg.url = 'https://httpbin.org/get'
    msg.headers['Accept'] = '*/*'
    msg.body = 'foo'
    msg.headers_sent = True
    msg.body_sent = True
    stream = RawStream(msg=msg)
    print(list(stream.iter_body()))


# Generated at 2022-06-21 14:28:10.805671
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from .context import Environment

    msg = HTTPResponse('200 OK')
    msg.headers['Content-Type'] = 'text/plain; charset=utf8'
    msg.encoding = 'utf8'
    msg.body = 'foo'.encode('utf8')

    bs = BaseStream(msg=msg)
    assert list(bs) == [b'Content-Type: text/plain; charset=utf8\r\n\r\n']



# Generated at 2022-06-21 14:28:21.266864
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import os
    import random
    import json
    import string
    import collections
    import ast

    content_types = ["application/json", "text/html"]

    responses = []
    for content_type in content_types:
        responses.append({"Content-Type": content_type})

    for response in responses:
        header = []
        for key, value in response.items():
            header.append(key + ": " + value)
        header = "\n".join(header) + "\n\n"

        body = []
        for i in range(0, random.randint(1, 5)):
            obj = "".join(random.choice(string.ascii_letters) for i in range(random.randint(1, 20)))
            if content_type == "application/json":
                body.append

# Generated at 2022-06-21 14:28:23.625774
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    stream = RawStream(msg)

    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True

# Generated at 2022-06-21 14:29:09.488237
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert BinarySuppressedError.message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-21 14:29:12.703904
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    import io
    import pathlib
    import re
    import subprocess
    import tempfile
    import unittest

    import requests
    import responses

    import httpie.cli



# Generated at 2022-06-21 14:29:22.007626
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    env = Environment()
    msg = HTTPMessage(headers={'content-type': 'application/json;'}, body = "test body", encoding = 'utf-8')
    data = {
        "test": "test"
    }
    msg.body = json.dumps(data)
    print(msg.body)
    print(msg.encoding)
    print(msg.content_type)
    ps = PrettyStream(conversion=None, formatting=None, msg=msg, env=env, with_headers=True, with_body=True)
    body = b''
    for line in ps.iter_body():
        body += line
    print(body)
    assert body == b'"{\n  "test": "test"\n}"\n'


# Generated at 2022-06-21 14:29:32.746352
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    h = HTTPMessage()
    h.body = "12345" * 50 + '\n'
    h.headers = """HTTP/1.1 200 OK
Date: Sat, 17 Dec 2016 13:02:07 GMT
Server: Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips PHP/5.4.16 mod_perl/2.0.10 Perl/v5.16.3
Last-Modified: Thu, 16 Jun 2016 15:00:00 GMT
ETag: "523e-534e47f42c140"
Accept-Ranges: bytes
Content-Length: 523
Connection: close
Content-Type: text/html; charset=UTF-8
"""
    s = RawStream(h)

    for i in s:
        print(i)

    assert False

# Generated at 2022-06-21 14:29:42.822403
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Response
    body = '''{
        "success": true,
        "name": "neo",
        "age": 33
    }'''
    fake_msg = Response(200, body, headers={
        "server": "Apache-Coyote/1.1",
        "access-control-allow-origin": "*",
        "transfer-encoding": "chunked",
        "date": "Thu, 18 Jul 2019 13:38:47 GMT",
        "content-type": "application/json;charset=UTF-8"
    })
    env = Environment()
    x = PrettyStream(fake_msg, env)

# Generated at 2022-06-21 14:29:45.003853
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    formatted = PrettyStream(None, Formatting()).process_body('TEST')
    assert isinstance(formatted, bytes)

# Generated at 2022-06-21 14:29:48.353196
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    a = BinarySuppressedError()
    assert a.message == b'\n+-----------------------------------------+\n' \
                                           b'| NOTE: binary data not shown in terminal |\n' \
                                           b'+-----------------------------------------+'


test_BinarySuppressedError()

# Generated at 2022-06-21 14:29:52.050922
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    content = ''
    req = HTTPMessage.from_str(content.encode('utf8'), 'utf8')
    env = Environment()
    print('test EncodedStream')
    for c in EncodedStream(msg=req, env=env):
        print('+', c)


# Generated at 2022-06-21 14:29:57.193369
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage('example.com')
    msg.headers['Content-type'] = 'text/plain'
    msg.text = 'Test'
    msg.protocol_version = 'HTTP/1.1'
    msg.status_code = 200
    msg.reason_phrase = 'OK'
    RawStream(msg, with_body=True)



# Generated at 2022-06-21 14:30:08.381332
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    """
    Test if iter_body of PrettyStream extract the correct line.</br>
    Test the case where a line ends with \n, \r or \r\n.
    """
    line_1 = "one\n"
    line_2 = "two\r"
    line_3 = "three\r\n"
    body = line_1 + line_2 + line_3

    msg = HTTPMessage(
            'streaming-api.1.1',
            None,
            '200 OK',
            Message(),
            io.BytesIO(bytes(body, encoding='utf8')),
            None,
            'utf8'
        )

    stream = PrettyStream(msg, None, None, None, None)
    count = 0

# Generated at 2022-06-21 14:31:48.625379
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = [
        "HTTP/1.1 200 OK",
        "Content-Type: application/json; charset=utf-8",
        "Date: Fri, 10 Feb 2017 13:32:50 GMT",
        "Content-Length: 252",
        "X-Application-Context: application:development",
        "Access-Control-Allow-Origin: *",
        "Access-Control-Expose-Headers: Link",
        "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS, HEAD"
    ]
    print(headers)
    msg=HTTPMessage(headers=headers, content="{}")
    stream = PrettyStream(msg=msg)
    print(stream.get_headers())

# Generated at 2022-06-21 14:31:49.404067
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    pass


# Generated at 2022-06-21 14:31:55.067211
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import BaseStream
    response = Response(
        url='http://httpbin.org/redirect/3',
        status_code=200,
        headers={},
        content='test-content'
    )
    s = BaseStream(
        msg=response,
        with_headers=True,
        with_body=True
    )
    assert s.with_body == True
    assert s.with_headers == True
    assert list(s.iter_body()) == []


# Generated at 2022-06-21 14:32:04.670832
# Unit test for constructor of class RawStream
def test_RawStream():
    from httpie.models import HTTPResponse
    assert RawStream(HTTPResponse(), with_headers=True, with_body=True, on_body_chunk_downloaded=None).with_body == True
    assert RawStream(HTTPResponse(), with_headers=True, with_body=True, on_body_chunk_downloaded=None).with_headers == True
    assert RawStream(HTTPResponse(), with_headers=True, with_body=False, on_body_chunk_downloaded=None).with_body == False
    assert RawStream(HTTPResponse(), with_headers=False, with_body=True, on_body_chunk_downloaded=None).with_headers == False


# Generated at 2022-06-21 14:32:09.483306
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    stream = PrettyStream(msg, True, True)
    assert isinstance(stream, PrettyStream)
    assert isinstance(stream, EncodedStream)
    assert isinstance(stream, BaseStream)
    assert issubclass(PrettyStream, EncodedStream)
    assert issubclass(EncodedStream, BaseStream)

# Generated at 2022-06-21 14:32:16.739891
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.input import ParseError
    from httpie.models import HTTPRequest
    request = HTTPRequest(method='POST', url='http://httpbin.org/post',
                          headers={'Accept': 'application/json'},
                          data='Hello World!'
                          )
    if request:
        print(request)
    try:
        assert request.headers == {'Accept': 'application/json'}
    except AssertionError:
        print('AssertionError')
    assert request.method == 'POST'
    assert request.url == 'http://httpbin.org/post'
    try:
        assert request.data == 'Hello World!'
    except AssertionError:
        print('AssertionError')

# Generated at 2022-06-21 14:32:28.446153
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json

# Generated at 2022-06-21 14:32:36.862558
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    mock_conversion = Mock()
    mock_formatting = Mock()
    mock_msg = Mock(spec=HTTPMessage)
    mock_on_body_chunk_downloaded = Mock()
    s = PrettyStream(
        conversion=mock_conversion,
        formatting=mock_formatting,
        msg=mock_msg,
        on_body_chunk_downloaded=mock_on_body_chunk_downloaded,
        with_headers=True,
    )
    assert s.conversion is mock_conversion
    assert s.formatting is mock_formatting
    assert s.msg is mock_msg
    assert s.on_body_chunk_downloaded is mock_on_body_chunk_downloaded
    assert s.with_headers is True

# Generated at 2022-06-21 14:32:47.936391
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import Response
    from collections import namedtuple
    UrlResponse = namedtuple('UrlResponse', ['url', 'status_code'])
    response = Response(UrlResponse('http://www.baidu.com', 200),
                        headers={'Connection': 'close'},
                        content=b'<title>baidu</title>',
                        encoding='utf-8',
                        request=None,
                        http_version='1.1')
    stream = EncodedStream(msg=response)
    assert stream.CHUNK_SIZE == 1

    body = stream.iter_body()
    body_list = list(body)
    assert body_list[0] == b'<title>baidu</title>'
    assert len(body_list) == 1

# Generated at 2022-06-21 14:32:49.262804
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    test_env = Environment()
    stream = BufferedPrettyStream("a","a",env=test_env)