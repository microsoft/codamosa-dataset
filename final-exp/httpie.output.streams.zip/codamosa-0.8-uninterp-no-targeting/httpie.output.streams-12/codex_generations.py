

# Generated at 2022-06-21 14:24:05.370895
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    bse = BinarySuppressedError()
    assert repr(bse) == 'BinarySuppressedError'

# Generated at 2022-06-21 14:24:09.528264
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    body = [b'1', b'2', b'3', b'4', b'5', b'6', b'7', b'8', b'9', b'0']
    stream = RawStream()
    for i in stream.iter_body():
        assert i == body


# Generated at 2022-06-21 14:24:19.566131
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie import ExitStatus
    from httpie.core import main
    from httpie.models import HTTPResponse
    import json
    import pytest

# Generated at 2022-06-21 14:24:20.196257
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
	a = BinarySuppressedError()
	return a

# Generated at 2022-06-21 14:24:22.460167
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    class FakeMessage:
        def __init__(self):
            self.headers = 'fake-headers'

    result = BaseStream(FakeMessage()).get_headers()
    assert isinstance(result, bytes)

# Generated at 2022-06-21 14:24:30.221501
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK \nDate: Fri, 1 Jan 1980 00:00:01 GMT"
    msg.body = "Hello World"
    with_headers = True
    with_body = True
    a = BaseStream(msg,with_headers,with_body)
    assert a.get_headers() == b"HTTP/1.1 200 OK \nDate: Fri, 1 Jan 1980 00:00:01 GMT"


# Generated at 2022-06-21 14:24:38.144479
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class DummyHeaders(dict):
        def encode(self) -> str:
            return 'DummyHeaders'

    class DummyMessage(object):
        headers = DummyHeaders()
        encoding = 'utf-8'
        body = 'body'
        content_type = 'text'

    class DummyFormatting(object):
        def format_headers(self, headers) -> str:
            return 'DummyMessage: {}'.format(headers)

        def format_body(self, content, mime=None) -> str:
            return 'body: {}'.format(content)

    class DummyConversion(object):
        def get_converter(self, mime):
            return None

    message = DummyMessage()

    from httpie.output.streams import PrettyStream


# Generated at 2022-06-21 14:24:38.758305
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    stream = PrettyStream()

# Generated at 2022-06-21 14:24:49.532997
# Unit test for constructor of class PrettyStream

# Generated at 2022-06-21 14:24:57.733238
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream, Conversion, Formatting, HTTPMessage
    from httpie.context import Environment
    env = Environment()
    msg = HTTPMessage(type='http')
    conversion = Conversion()
    formatting = Formatting()
    buffered_pretty_stream = BufferedPrettyStream(msg,
                                                  env=env,
                                                  conversion=conversion,
                                                  formatting=formatting)
    print ("buffered_pretty_stream: ", buffered_pretty_stream)

# Generated at 2022-06-21 14:25:05.951758
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert isinstance(DataSuppressedError(), Exception)
    assert DataSuppressedError.message == None

# Generated at 2022-06-21 14:25:15.019500
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    class DummyMessage:
        encoding = 'test_encoding'
    msg = DummyMessage()
    # We can pass all test cases successfully.
    stream = EncodedStream(msg=msg, with_body=False)
    assert stream.msg is msg and stream.msg.encoding == 'test_encoding'
    assert stream.with_headers is True
    assert stream.with_body is False
    assert stream.output_encoding == 'test_encoding'
    stream = EncodedStream(msg=msg, with_headers=False)
    assert stream.msg is msg and stream.msg.encoding == 'test_encoding'
    assert stream.with_headers is False
    assert stream.with_body is True
    assert stream.output_encoding == 'test_encoding'
    env = Environment()
    stream = Encoded

# Generated at 2022-06-21 14:25:20.084696
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # Testing initialization
    msg = HTTPMessage()
    msg.encoding = 'utf-8'
    es = EncodedStream(msg=msg)
    assert es.CHUNK_SIZE == 1



# Generated at 2022-06-21 14:25:30.288389
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import Response
    from httpie.downloaders import LocalFileDownloader

    body_bytes = b'\u2713 unicode \x8E binary'
    msg = Response(200, 'OK', headers={'Content-Type': 'text/plain'},
                   body=body_bytes, content_type_encoding='utf8',
                   downloader=LocalFileDownloader(),
                   is_stream=True)
    stream = EncodedStream(msg=msg)

    if sys.version_info < (3, 0):
        assert b''.join(stream) == body_bytes
    else:
        assert b''.join(stream) == body_bytes.decode('utf8').encode('utf8')

# Generated at 2022-06-21 14:25:40.697603
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    def test_bytes(bs, size):
        # Test if the body size is what we expected
        n = 0
        for chunk in bs.iter_body():
            n += len(chunk)
        assert size == n

    f = open("tmp.bin", 'rb')
    body = f.read()
    f.close()

    # Test BufferedPrettyStream
    test_msg = HTTPMessage(
        method="GET",
        url="http://httpie.org",
        headers={'content-type': 'application/octet-stream'},
        body=body,
        body_size=len(body)
    )
    bps = BufferedPrettyStream(
        msg=test_msg
    )
    test_bytes(bps, len(body))


# Generated at 2022-06-21 14:25:51.118156
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    # Test of method raw_stream().
    msg = HTTPMessage('1\n2\n3\n')
    msg.headers = 'Content-Type: text/plain'

    # Test for raw_stream().
    temp = RawStream(msg)
    assert list(temp.iter_body()) == [b'1\n', b'2\n', b'3\n']

    # Test for encoded_stream().
    temp = EncodedStream(msg)
    assert list(temp.iter_body()) == [b'1\n', b'2\n', b'3\n']

    # Test for pretty_stream().
    conversion = Conversion()
    formatting = Formatting()
    temp = PrettyStream(msg, conversion, formatting)

# Generated at 2022-06-21 14:25:59.121465
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage('get', 'http://www.google.com')
    my_base_stream = BaseStream(msg, with_headers=True, with_body=True)
    assert my_base_stream.get_headers() == 'GET / HTTP/1.1\r\nHost: www.google.com\r\nAccept: */*\r\nUser-Agent: HTTPie/1.0.0\r\n\r\n'.encode('utf8')


# Generated at 2022-06-21 14:26:07.951121
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    headers = '''GET / HTTP/1.1
User-Agent: curl/7.58.0
Host: httpbin.org
Accept: */*

'''.encode()
    msg = HTTPMessage.from_bytes(headers, url='http://httpbin.org/')
    p = PrettyStream(msg, True, True, None, None, Formatting(), Conversion())
    assert p.get_headers() == 'GET / HTTP/1.1\nUser-Agent: curl/7.58.0\nHost: httpbin.org\nAccept: */*\n\n'.encode()



# Generated at 2022-06-21 14:26:15.435191
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    assert env.stdout_isatty == True
    assert env.stdout_encoding == 'utf8'
    stream = EncodedStream(env)
    assert stream.CHUNK_SIZE == 1
    assert stream.msg == None
    assert stream.with_headers == None
    assert stream.with_body == None
    assert stream.on_body_chunk_downloaded == None
    assert stream.output_encoding == 'utf8'



# Generated at 2022-06-21 14:26:19.125453
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    env = Environment()
    msg = Mock(headers=Mock(return_value='header1: value\nheader2: value'))
    stream = PrettyStream(msg, env=env)
    stream.get_headers()
    msg.headers.assert_called()



# Generated at 2022-06-21 14:26:49.182418
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    BaseStream___iter___example = BaseStream(msg={},with_headers=True,with_body=True,on_body_chunk_downloaded={})
    BaseStream___iter___example.msg = {}
    BaseStream___iter___example.with_headers = True
    BaseStream___iter___example.with_body = True
    BaseStream___iter___example.on_body_chunk_downloaded = {}
    assert BaseStream___iter___example # pass

# Generated at 2022-06-21 14:26:58.477458
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.__main__ import main
    from httpie.core import main as core_main
    from httpie.cli import get_parser, parser_kwargs_v2_formatting, parser_kwargs_v2_conversion, parser_kwargs_output_options

    import json
    import pytest
    import mock
    import sys

    ## We need to create a temporary file to mock a request, as the original httpie.core.request method uses the
    ## filesystem to store the response, and we need to mock that, just like the main function does, in a 
    ## temporary file
    with tempfile.TemporaryFile() as response_file:

        ## We need to call the main function of httpie.core to create the temporary http message
        sys.argv = ['http', 'www.google.com']

        args = get_

# Generated at 2022-06-21 14:27:08.690909
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    headers = {'hello': 'world'}
    body = '\u2713'
    msg = HTTPRequest('GET', 'https://httpbin.org/get', headers=headers, body=body)
    stream = RawStream(msg, with_body=True)
    body_chunk = b''
    for part in stream:
        body_chunk = body_chunk + part
    body = body.encode('utf8')
    headers = {k.encode('utf8'):v.encode('utf8') for k,v in headers.items()}
    msg_bytes = b''.join(msg.headers.encode('utf8') + b'\r\n\r\n' + body)
    assert body_chunk == msg_bytes

# Generated at 2022-06-21 14:27:17.608226
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.input import SEP_CREDENTIALS
    from httpie.models import HTTPRequest
    from httpie.output.streams import BaseStream

    http_request = HTTPRequest(method='GET',
                               url='http://127.0.0.1/',
                               headers={
                                   'Accept': '*/*'
                               },
                               auth=('user', 'pass'),
                               body='')
    headers = http_request.headers
    headers.add('Host', '127.0.0.1')
    headers.add('Accept-Encoding', 'gzip, deflate')
    headers.add('Connection', 'keep-alive')
    headers.add('Content-Length', '0')
    base_stream = BaseStream(msg=http_request)
    assert next(base_stream)

# Generated at 2022-06-21 14:27:20.081392
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    stream = BufferedPrettyStream(None, None, msg=None, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert stream is not None

# Generated at 2022-06-21 14:27:22.617725
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    PrettyStream(msg, conversion=conversion, formatting=formatting)

# Generated at 2022-06-21 14:27:27.125741
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"test": "text"}, body='{ "body": "test" }')
    stream = PrettyStream(msg=msg)
    assert stream.get_headers() == b'{test: text}\r\n\r\n'

# Generated at 2022-06-21 14:27:30.522514
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    exc = BinarySuppressedError()
    assert exc.message == BINARY_SUPPRESSED_NOTICE
    exc = BinarySuppressedError('test')
    assert exc.message == 'test'



# Generated at 2022-06-21 14:27:34.726898
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage()
    msg.headers['x'] = 'y'
    msg.headers['z'] = 'z'

    stream = BaseStream(msg, True, False)
    assert stream.get_headers() == b'x: y\r\nz: z\r\n\r\n'



# Generated at 2022-06-21 14:27:36.012465
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    BaseStream().__iter__()

# Generated at 2022-06-21 14:28:21.733537
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage()
    s = PrettyStream(msg, with_headers=False, with_body=True)
    s.output_encoding = 'utf8'
    s.mime = 'text/plain'
    s.formatting = Formatting(None)

    # Body is bytes
    chunk = b'\xe5\x95\x8a'
    expected = chunk.decode('utf8', 'replace')
    assert s.process_body(chunk) == expected.encode('utf8', 'replace')

    # Body is str
    chunk = '啊'
    expected = chunk
    assert s.process_body(chunk) == expected.encode('utf8', 'replace')

# Generated at 2022-06-21 14:28:28.508165
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    class MockResponse(HTTPResponse):
        def iter_body(self, chunk_size=None):
            for line in self.body.splitlines(True):
                yield line, b'\r\n'

        def iter_lines(self, chunk_size=None):
            for line in self.body.splitlines(True):
                yield line, b'\r\n'

        @property
        def headers(self):
            return self._headers

        @property
        def content_type(self):
            return self._content_type

    url = "http://example.com/path"
    status = 200

# Generated at 2022-06-21 14:28:29.992611
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    print("testing PrettyStream constructor")
    assert PrettyStream

# Generated at 2022-06-21 14:28:31.553065
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    exc = DataSuppressedError()
    assert exc.message is None



# Generated at 2022-06-21 14:28:42.382218
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    """
    Test if body is processed corectly on a single chunk or \
    on several by chunks
    """
    class TestMsg(HTTPMessage):
        def __init__(self, content, content_type):
            super().__init__(content, content_type)

        def iter_body(self, chunk_size):
            for chunk in self.body:
                yield chunk

    class TestConversion:
        def get_converter(self, mime):
            return None
    class TestFormatting:
        def format_headers(self, headers):
            return headers

        def format_body(self, content, mime):
            return content

    msg = TestMsg('{"x": "y"}', 'application/json')

    conversion = TestConversion()
    formatting = TestFormatting()
    stream = PrettyStream

# Generated at 2022-06-21 14:28:48.696842
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(
        'HTTP/1.0',
        200,
        'OK',
        Headers({'Content-Type': 'text/html'}),
        'hello',
    )
    msg.ENCODING = 'utf-8'
    msg.CONTENT_TYPE = 'text/html'
    assert EncodedStream(msg).output_encoding == 'utf-8'

if __name__ == '__main__':
    test_EncodedStream()

# Generated at 2022-06-21 14:28:58.881238
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPResponse
    from tests.utils import MockEnvironment

    resp = HTTPResponse(b'HTTP/1.1 200 OK\r\n'
                        b'Content-Type: text/plain; charset=utf8\r\n\r\n'
                        b'a\r\n'
                        b'\xb5\r\n'
                        b'c\r\n')
    # This test should have been moved to the unittest module
    # to test_output_streaming.py
    env = MockEnvironment()
    env.stdout_isatty = False
    stream = EncodedStream(resp, env=env)

# Generated at 2022-06-21 14:28:59.858022
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass

# Generated at 2022-06-21 14:29:09.652379
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment(stdin_isatty=False,
                      stdout_isatty=False,
                      stdin=None,
                      stdout=None,
                      is_windows=False,
                      colors=16,
                      defaults=dict())
    msg = HTTPMessage('GET / HTTP/1.1',
                      'headers',
                      'body',
                      encoding='utf-8',
                      content_type='application/json')

    assert EncodedStream(msg=msg, env=env).msg.headers == \
        'headers'
    assert EncodedStream(msg=msg, env=env).with_headers is True
    assert EncodedStream(msg=msg, env=env).with_body is True
    assert EncodedStream(msg=msg, env=env).output_encoding == 'utf-8'

# Generated at 2022-06-21 14:29:19.216841
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Setup
    msg = HTTPMessage(version='1.1', status_code=200, headers='',
        encoding='utf-8', body='Hello World')
    printer = PrettyStream(msg, formatting=None, conversion=None, 
        on_body_chunk_downloaded=None, with_headers=False, with_body=True)
    assert printer.msg == msg
    assert printer.CHUNK_SIZE == 1
    assert printer.FORMAT_PARAMS is None
    assert printer.CONVERT_PARAMS is None
    assert printer.on_body_chunk_downloaded is None
    assert printer.with_headers is False
    assert printer.with_body is True

    # Expected result
    result = [b'Hello World\r\n']

    # Execute

# Generated at 2022-06-21 14:30:43.745451
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    """
    Unit test for EncodedStream.
    """
    http_message = HTTPMessage()
    http_message.encoding = "GB2312"
    http_message.content_type = "text/html"
    http_message.headers = "Accept:   text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n"
    http_message.body = "<html><meta charset=\"GB2312\"><title>Encoding Test</title></html>"
    http_message.http_version = "HTTP/1.1"
    http_message.status_code = "200"
    http_message.reason = "OK"
    http_message.headers_sent = False


# Generated at 2022-06-21 14:30:51.319580
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage(headers="""content-type: application/json; charset=UTF-8\r\n""",
                      body=b'{"a": "hello"}')
    stream = BufferedPrettyStream(msg=msg, conversion=None, formatting=None)
    body = bytes()
    for chunk in stream.iter_body():
        body += chunk
    assert body == b'{"a": "hello"}'

    msg = HTTPMessage(headers="""content-type: application/json; charset=UTF-8\r\n""",
                      body=b'\x00')
    stream = BufferedPrettyStream(msg=msg, conversion=None, formatting=None)
    body = bytes()
    for chunk in stream.iter_body():
        body += chunk
    assert body == b''


# Generated at 2022-06-21 14:30:53.767585
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    err = DataSuppressedError("Error Message")
    assert err.message == "Error Message"


# Generated at 2022-06-21 14:31:01.171687
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers = 'a:b\nc:d', 
                        encoding = 'utf8', 
                        iter_lines = lambda chunk_size: 'a:b\nc:d', 
                        content_type = 'a/b;c=d', 
                        url = 'https://httpbin.org/anything?a=b', 
                        status_line = 'HTTP/1.1 200 OK', 
                        is_body_read = True, 
                        body = b'abcdefg')
    es = EncodedStream(msg = msg, with_headers = True, with_body = True, on_body_chunk_downloaded = lambda bytes: None)
    assert es.msg.headers == 'a:b\nc:d'
    assert es.msg.encoding == 'utf8'
    assert es.msg

# Generated at 2022-06-21 14:31:06.692773
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    """
    Case 5:

    BaseStream.get_headers()

    No header header.
    """
    msg = HTTPMessage(headers="" )
    BaseStream(msg=msg)
    # Check if the returned headers is empty.
    assert BaseStream(msg=msg).get_headers() == b''


# Generated at 2022-06-21 14:31:15.777033
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Test 1
    from httpie.utils import url
    from httpie.compat import urlsplit
    import os
    test="https://noto-website-2.storage.googleapis.com/pkgs/NotoSansCJKtc-hinted.zip?authuser=1\n"
    # test="https://www.google.com.tw/"
    path=url(test)
    # print(path)
    # print(urlsplit(path))
    # print(urlsplit(os.getcwd()))
    # print(os.path.relpath(path,os.getcwd()))
    # print(urllib.parse.urlsplit(url))

    # test="https://www.google.com.tw/images/branding/googlelogo/2x/googlelogo

# Generated at 2022-06-21 14:31:25.699821
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from .helpers import httpbin, http

    url = httpbin('/encoding/utf8') + '/'
    body = u'fööbär\n'
    with requests.Session() as sess:
        sess.headers['Connection'] = 'close'

        # Assert that the body is properly encoded.
        r = sess.post(url, data=body.encode('utf8'))
        assert body.encode('utf8') == EncodedStream(r.request).get_body()

        body_invalid_encoding = body.encode('utf8')[:5]
        r = sess.post(url, data=body_invalid_encoding)
        assert body_invalid_encoding == EncodedStream(r.request).get_body()

        # Assert that the body is

# Generated at 2022-06-21 14:31:32.092836
# Unit test for constructor of class RawStream
def test_RawStream():
    class HTTPMessageTest(HTTPMessage):
        def encode(self, *args, **kwargs):
            return [1, 2, 3]

        def iter_body(self, *args, **kwargs):
            return [1, 2, 3]

    msg = HTTPMessageTest('test', content_type='text/plain')
    stream = RawStream(msg, True, True)
    assert stream.msg == msg
    assert stream.with_headers
    assert stream.with_body
    assert stream.get_headers() == msg.encode()
    assert list(stream.iter_body()) == msg.iter_body()



# Generated at 2022-06-21 14:31:34.177743
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    for i in RawStream(HTTPMessage(b'raw data')).iter_body():
        assert i == 'raw data'


# Generated at 2022-06-21 14:31:45.021849
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    message = HTTPMessage("""HTTP/1.1 200 OK
Date: Thu, 15 Apr 2021 11:01:44 GMT
Content-Type: application/json
Content-Length: 12

""", 200)
    stream = PrettyStream(
        msg=message,
        with_headers=True,
        with_body=True,
        conversion=None,
        formatting=None,
        env=Environment(),
        on_body_chunk_downloaded=None,
    )
    assert stream.get_headers().decode("utf-8") == """HTTP/1.1 200 OK
Date: Thu, 15 Apr 2021 11:01:44 GMT
Content-Type: application/json
Content-Length: 12

"""