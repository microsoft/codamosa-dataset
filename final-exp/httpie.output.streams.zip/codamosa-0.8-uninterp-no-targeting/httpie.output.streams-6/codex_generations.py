

# Generated at 2022-06-21 14:24:08.892468
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(b'GET /index.html HTTP/1.1\r\nHost: example.com\r\n\r\n')
    with RawStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None) as f:
        assert f.msg.encode('utf8') == msg.encode('utf8')
        assert f.with_headers == True
        assert f.with_body == True
        assert f.chunk_size == 10240


# Generated at 2022-06-21 14:24:18.605425
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import get_stream
    from httpie.context import Environment
    data = b'{"nested":{"in_dict": {"list": [{"in_list":"value"}], "nested_in_list":[{"inside":"value"}]}}}'
    chunk = data.decode('utf8', 'replace')
    stream = get_stream(
        data, with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
        env=Environment()
    )
    out = stream.process_body(chunk)
    if out != data.decode('utf8', 'replace'):
        raise AssertionError(
            "failed in test_PrettyStream_process_body: " +
            str(out)
        )


# Generated at 2022-06-21 14:24:19.563852
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert BinarySuppressedError.message == BINARY_SUPPRESSED_NOTICE



# Generated at 2022-06-21 14:24:25.848421
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from .print import Printer
    from httpie import ExitStatus
    from httpie.core import main
    from httpie.compat import is_windows
    from httpie.output.streams import BinarySuppressedError, EncodedStream
    from httpie.utils import decode_kwargs

    args = [
        'example.org',
        '--stream'
    ]
    if is_windows:
        # On Windows, binary data written to stdout is interpreted by Win10
        # ANSI escape code handler, yielding mangled output.
        # See https://github.com/jakubroztocil/httpie/issues/358
        args.append('--output=NUL')
    kwargs, _ = decode_kwargs(args)


# Generated at 2022-06-21 14:24:30.064442
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    import collections
    import sys
    import pytest

    bin_e = BinarySuppressedError()
    assert bin_e.message == BINARY_SUPPRESSED_NOTICE
    with pytest.raises(DataSuppressedError):
        raise bin_e

# Generated at 2022-06-21 14:24:36.450450
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # body is empty
    test_msg = HTTPMessage(headers='HTTP/1.1 200 OK\n', body='')
    stream = RawStream(test_msg)
    assert list(stream.iter_body()) == []

    # body has data
    test_msg = HTTPMessage(headers='HTTP/1.1 200 OK\n', body='body')
    stream = RawStream(test_msg)
    assert list(stream.iter_body()) == ['body']



# Generated at 2022-06-21 14:24:47.617361
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import io
    from httpie.models import Response
    from httpie.downloads import StreamingResponse
    response = StreamingResponse(
        io.BytesIO(),
        url=b'https://httpbin.org/post',
        headers=Response.headers_class(),
        status_code=201,
        reason='Foo',
        encoding='utf8'
    )
    response.headers['content-type'] = 'application/json'
    obj = EncodedStream(msg=response)
    assert obj.msg == response
    assert obj.with_body == True
    assert obj.with_headers == True
    assert obj.output_encoding == 'utf8'
    assert obj.CHUNK_SIZE_BY_LINE == 1

test_EncodedStream()


# Generated at 2022-06-21 14:24:49.584568
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
	DataSuppressedError()

	try:
		raise DataSuppressedError('test')
	except DataSuppressedError:
		pass


# Generated at 2022-06-21 14:24:53.543676
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    message_test = HTTPMessage(headers = "TEST")
    base_stream = BaseStream(message_test)
    assert base_stream.get_headers() == b'TEST'


# Generated at 2022-06-21 14:24:56.727735
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    with pytest.raises(DataSuppressedError) as ef:
        raise DataSuppressedError()
    assert ef.value.message == None

# Generated at 2022-06-21 14:25:12.804326
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Create a httpie.output.streams.PrettyStream object
    res = PrettyStream(Conversion(), Formatting(), HTTPMessage())

    # Check result
    assert isinstance(res, PrettyStream)
    assert isinstance(res, EncodedStream)
    assert isinstance(res, BaseStream)
    assert res.conversion is not None
    assert res.formatting is not None
    assert res.msg is not None
    assert res.with_headers == True
    assert res.with_body == True
    assert res.on_body_chunk_downloaded is None
    assert res.output_encoding == 'utf8'
    assert res.formatting == Formatting()


# Generated at 2022-06-21 14:25:15.445757
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    err = DataSuppressedError()
    assert err.message is None
    err = DataSuppressedError(message='error')
    assert err.message == 'error'

# Generated at 2022-06-21 14:25:18.913829
# Unit test for constructor of class RawStream
def test_RawStream():
    assert isinstance(RawStream(msg=HTTPMessage()), HTTPMessage)


# Generated at 2022-06-21 14:25:21.705563
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage()
    stream = BaseStream(msg)
    headers = b'HTTP/1.1 200 OK\r\nHost: localhost:8888\r\n' \
          b'Content-Type: text/plain; charset=utf-8'
    msg.headers = headers.decode()
    assert stream.get_headers() == headers

# Generated at 2022-06-21 14:25:28.396435
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    s = PrettyStream(
        msg=HTTPMessage(
            headers={"content-type": "application/json; charset=utf-8"},
            encoding='utf-8',
            body=b"{\n  \"hello\": \"greeting\"\n}"
        ),
        on_body_chunk_downloaded=None,
        conversion=None,
        formatting=None,
        env=Environment(),
        with_headers=True,
        with_body=True
    )
    assert s.CHUNK_SIZE == 1
    assert s.iter_body().__next__() == b'\n  "hello": "greeting"\n'

# Generated at 2022-06-21 14:25:29.567284
# Unit test for constructor of class BaseStream
def test_BaseStream():
    assert BaseStream


# Generated at 2022-06-21 14:25:33.017835
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import Response
    stream = RawStream(Response(headers = {}, body = b'123456789'))
    assert list(stream.iter_body()) == [b'123456789']


# Generated at 2022-06-21 14:25:37.312081
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    env = Environment()
    stream = RawStream(msg, env)
    assert stream.msg == msg
    assert stream.env == env
    assert stream.CHUNK_SIZE == 102400
    assert stream.CHUNK_SIZE_BY_LINE == 1


# Generated at 2022-06-21 14:25:40.307076
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    env = Environment()
    msg = requests.get('https://httpbin.org/get')
    for chunk in RawStream(msg, env).iter_body():
        print(chunk)


# Generated at 2022-06-21 14:25:47.362817
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    class test_msg(HTTPMessage):
        def __init__(self, headers, encoding):
            self.headers = headers
            self.encoding = encoding
        def iter_body(self, chunk_size):
            return ["ciao"]
        def iter_lines(self, chunk_size):
            return [("ciao", b'\r\n')]
    
    msg1 = test_msg(headers="ciao", encoding="utf8")
    msg2 = test_msg(headers="ciao", encoding=None)
    
    es1 = EncodedStream(msg=msg1, with_headers=True, with_body=True)
    es2 = EncodedStream(msg=msg2, with_headers=True, with_body=True)
    
    assert es1.output_encoding=='utf8'


# Generated at 2022-06-21 14:26:22.995110
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    binarySuppressedError = BinarySuppressedError()
    assert str(binarySuppressedError) == "NOTE: binary data not shown in terminal"
    assert binarySuppressedError.message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-21 14:26:27.409943
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(body=b"abcdefg")
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    rawStream = RawStream(msg = msg,with_headers = with_headers,with_body = with_body,on_body_chunk_downloaded = on_body_chunk_downloaded)
    assert rawStream.msg == HTTPMessage(body=b"abcdefg")
    assert rawStream.with_headers == True
    assert rawStream.with_body == True
    assert rawStream.on_body_chunk_downloaded == None


# Generated at 2022-06-21 14:26:35.511093
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    """
    Test for initializing pretty stream

    :return:
    """
    test_url = "https://www.google.com/search?q=httpie+binary+headers"
    stream = PrettyStream(
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
        msg=test_url.encode()
    )
    print(stream)
    assert isinstance(stream, PrettyStream)



# Generated at 2022-06-21 14:26:44.493866
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Globals
    test_msg = HTTPMessage(None)
    test_conversion = Conversion()
    test_formatting = Formatting()


    # Test to generate an error because of missing parameters
    try:
        BufferedPrettyStream(conversion=None,
                             formatting=test_formatting,
                             msg=test_msg)
        # The exception should have been raised, test failed
        assert False
    except Exception:
        # The exception was raised, test passed
        pass

    try:
        BufferedPrettyStream(conversion=test_conversion,
                             formatting=None,
                             msg=test_msg)
        # The exception should have been raised, test failed
        assert False
    except Exception:
        # The exception was raised, test passed
        pass


# Generated at 2022-06-21 14:26:47.837741
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        assert str(e) == str(BINARY_SUPPRESSED_NOTICE, 'utf8')

# Generated at 2022-06-21 14:26:55.629680
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    body = b'1' * (1024 * 100 + 1)
    headers = b'a: b\r\n'
    msg = HTTPMessage(
        'GET', 'https://example.org', headers=headers, body=body, protocol='1.1')
    stream = RawStream(msg, with_headers=True, with_body=True)
    chunks = list(stream.iter_body())
    assert len(chunks) == 2
    assert len(b''.join(chunks)) == len(body)


if __name__ == '__main__':
    test_RawStream_iter_body()

# Generated at 2022-06-21 14:26:58.009145
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    with pytest.raises(BinarySuppressedError):
        raise BinarySuppressedError("The message body contains binary content")

# Testing method get_headers of class BaseStream

# Generated at 2022-06-21 14:27:03.299903
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
	msg = "Testing RawStream_iter_body"
	msg = HTTPMessage('utf8', msg, msg)
	itr = RawStream(msg).iter_body()
	output = b''
	for line, lf in itr:
		output += line + lf
	assert output == b"Testing RawStream_iter_body\r\n"


# Generated at 2022-06-21 14:27:09.252753
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    msg = b'This is a test'
    chunk_size=5
    base_stream = BaseStream(msg, chunk_size=chunk_size, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    count = 0
    for chunks in base_stream.iter_body():
        assert chunk_size == len(chunks)
        count += 1
    assert 3 == count


# Generated at 2022-06-21 14:27:17.936492
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    
    import json
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from httpie.output import ProcessingFormatter
    from httpie.compat import str

    env = Environment()
    c = HTTPResponse(
        http_version='2',
        status_code=200,
        headers=[('Content-Type', 'application/json')],
        body=json.dumps({"a": "b"}),
        encoding='utf8'
    )
    fmt = ProcessingFormatter(max_json_depth=None, max_json_array_lines=None,
        pretty=True, colors=True, style=None,
        vars=None,
        formats=None)

# Generated at 2022-06-21 14:28:11.152080
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    input_lines = [b'1\n', b'2\n', b'\03\n', b'4\n']
    class MockMessage:
        def __init__(self, lines):
            self.encoding = 'ascii'
            self.lines = lines
        def iter_lines(self, size):
            for line in self.lines:
                yield line, b'\n'
    msg = MockMessage(input_lines)

    s = EncodedStream(msg, with_headers=False, with_body=True)

    output_lines = list(s.iter_body())

    assert input_lines[0] == output_lines[0]
    assert input_lines[1] == output_lines[1]
    assert input_lines[3] == output_lines[2]


# Generated at 2022-06-21 14:28:17.683372
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.compat import urlopen

    request = urlopen('http://httpbin.org/get?a=b')
    response = Response(request.getcode(), 'utf8', request.info(), request.read())
    prettyStream = BufferedPrettyStream(response, with_headers=False, with_body=True)

    for i in prettyStream.iter_body():
        print(i.decode('utf8'))

# Generated at 2022-06-21 14:28:24.507763
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.formatters import JSONFormatter
    from httpie.output.streams import PrettyStream
    stream = PrettyStream(
        conversion=None,
        formatting=JSONFormatter(),
        msg=HTTPMessage(headers={"Content-Type":"application/json"}),
        with_headers=False,
        with_body=True
    )
    assert stream.process_body('{"a":[1,2,3]}') == b'{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'

# Generated at 2022-06-21 14:28:27.185249
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test NotImplementedError
    # Test: not raise for header
    # Test: not raise for header and body
    # Test: not raise for body
    pass


# Generated at 2022-06-21 14:28:35.646475
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # the input parameters
    msg = HTTPMessage()
    conversion = Conversion()
    formatting = Formatting()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None

    # the output parameters
    exc_flag = False

    try:
        # init the object PrettyStream
        ps = PrettyStream(msg, conversion, formatting,
                          with_headers, with_body, on_body_chunk_downloaded)
    except:
        exc_flag = True

    assert exc_flag == False

# Generated at 2022-06-21 14:28:39.753279
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(
        headers={"test": "test"}
    )
    stream = BaseStream(
        msg=msg,
        with_headers=True
    )
    assert stream.get_headers() == "test: test"


# Generated at 2022-06-21 14:28:47.294656
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream, EncodedStream
    from httpie.models import HTTPMessage
    from httpie.constants import DEFAULT_UA
    from httpie.plugins import plugin_manager
    from httpie.output.processing import Conversion, Formatting

    class CustomHTTPMessage(HTTPMessage):
        def iter_body(self, chunk_size):
            while True:
                yield b'HTTPie'
                break

    plugin_manager.load_installed_plugins()
    headers = {'User-Agent': DEFAULT_UA}
    body = b'HTTPie'
    msg = CustomHTTPMessage(headers, body)
    conversion = Conversion(True, False)
    formatting = Formatting()
    stream = BufferedPrettyStream(msg, conversion, formatting)

# Generated at 2022-06-21 14:28:53.249837
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():

    msg = HTTPMessage(body='test_string', headers=[
        'Content-Type: text/html; charset=utf-8',
        'Content-Length: 11'
    ])

    raw_stream = RawStream(msg=msg)
    result = raw_stream.iter_body()
    expect = [b'test_string']
    assert list(result) == expect

# Generated at 2022-06-21 14:28:57.651278
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(b'example')
    assert isinstance(msg, HTTPMessage)
    bs = BaseStream(msg)
    assert bs.with_headers is True
    assert bs.with_body is True
    assert bs.on_body_chunk_downloaded is None
    assert bs.get_headers() == b'example'



# Generated at 2022-06-21 14:29:04.472738
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    class HTTPMessage(object):
        def __init__(self):
            self.headers = ''
            self.body = ''
            self.content_type = ''
            self.status_code = ''
            self.encoding = ''
            self.is_redirect = ''
            self.reason = ''
            self.raw = ''

        def __repr__(self):
            return self.__dict__.__repr__()

        def __str__(self):
            return self.__dict__.__str__()

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    import io
    from httpie.output.streams import RawStream

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

   

# Generated at 2022-06-21 14:30:31.806046
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    es = EncodedStream(msg=HTTPMessage(), with_headers=False, with_body=False)
    assert isinstance(es, EncodedStream)


# Generated at 2022-06-21 14:30:42.515044
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(msg=None, conversion=None, formatting=None, with_headers=None,
                          with_body=None)
    assert stream.process_body(chunk=b"The quick brown fox jumps over the lazy dog") == b"The quick brown fox jumps over the lazy dog"
    assert stream.process_body(chunk="The quick brown fox jumps over the lazy dog") == b"The quick brown fox jumps over the lazy dog"
    assert stream.process_body(chunk=b"\x00") == b"\ufffd"
    assert stream.process_body(chunk="\x00") == b"\ufffd"
    assert stream.process_body(chunk=None) == b""



# Generated at 2022-06-21 14:30:50.720515
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    def test(input_body_content, expected_body_content):
        body_content = (u'\u1f4a9')
        message = build_message(
            body_content,
            200,
            'OK',
            headers = {
                'Content-Type': 'text/plain',
                'Content-Length': len(body_content)
            }
        )
        conversion = Conversion(message, None)
        formatting = Formatting(None, None, None)
        stream = PrettyStream(
            message,
            conversion=conversion,
            formatting=formatting,
            with_headers=False,
            with_body=False
        )
        gen = stream.iter_body()
        output_chunk = next(gen)

# Generated at 2022-06-21 14:30:58.284051
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    import queue
    import threading

    def collect_iter_body_output(chunk_size, q):
        q.put(list(BaseStream(None, None, None).iter_body()))

    # test chunk_size
    q = queue.Queue()
    t = threading.Thread(target=collect_iter_body_output, args=(1024 * 10, q))
    t.start()
    assert [None] == q.get()
    t.join()

    assert 1024 * 10 == RawStream().chunk_size


# Generated at 2022-06-21 14:31:09.682836
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    stream = PrettyStream(
        conversion=Conversion(),
        formatting=Formatting(),
        msg=HTTPMessage(headers=''),
        with_headers=False,
    )

    stream.msg.encoding = 'utf8'
    stream.output_encoding = 'utf8'
    stream.mime = 'text/html'
    stream.formatting.format_body = lambda body, mime: body.upper()

    stream.msg.body = ('<h1>Hello</h1>\n'
                       '<h1>Hi</h1>\n').encode('utf8')

    stream.CHUNK_SIZE = None

    expected = ('<H1>HELLO</H1>\n'
                '<H1>HI</H1>\n').encode('utf8')


# Generated at 2022-06-21 14:31:17.494504
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    test_headers = {'Host': 'github.com', 'Content-Type': 'text/html'}
    test_url = '/JIAYUANL/httpie'
    test_msg = HTTPMessage(url=test_url, headers=test_headers)

    test_env = Environment()
    test_formatting = Formatting()
    test_conversion = Conversion()
    test_with_headers = True
    test_with_body = True

    my_BufferedPrettyStream = BufferedPrettyStream(
        msg=test_msg,
        env=test_env,
        formatting=test_formatting,
        conversion=test_conversion,
        with_headers=test_with_headers,
        with_body=test_with_body,
    )

    assert my_BufferedPrettyStream.msg == test_

# Generated at 2022-06-21 14:31:26.752999
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    """Test iter_body method"""
    def assert_n_iteration(msg, n_iteration, chunk_size):
        """Position on the chunk_size number of bytes in the message.
        Check the number of iteration."""
        msg.status_line = b'HTTP/1.1 200\r\n'
        msg.headers = b'Content-Type: text/html\r\n'
        msg.headers += b'Content-Length: {}\r\n'.format(chunk_size * n_iteration)
        msg.body = b'A' * chunk_size * n_iteration
        msg.content_type = 'text/html'
        msg.encoding = 'utf8'
        n = 0

# Generated at 2022-06-21 14:31:34.279688
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    encoding='utf8'
    msg = HTTPMessage(
        b'',
        headers='Content-Type: text/html; charset=latin1',
        encoding=encoding,
        body=b'<b>Hello \xc3\xa0 \xe1\xba\xa1</b>\n'
    )
    stream = PrettyStream(
        msg=msg,
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=False,
        with_body=True,
    )
    x = stream.process_body(msg.body.decode(encoding))
    assert(
        x
        ==
        b'<b>Hello \xc3\xa0 \xc3\xa1</b>\n'
    )


# Generated at 2022-06-21 14:31:43.974793
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    def get_cs():
        return (httpie.models.HTTPMessage(None, None, None, None, None, None, None) ,
                True,
                True,
                None,
                None,
                None,
                None,
                )

    a = BufferedPrettyStream(*get_cs())
    b = BufferedPrettyStream(*get_cs())

    assert a is not b
    assert a.msg is not b.msg
    assert a.with_headers is not b.with_headers
    assert a.with_body is not b.with_body
    assert a.on_body_chunk_downloaded is not b.on_body_chunk_downloaded



# Generated at 2022-06-21 14:31:52.528380
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    import io
    import collections
    import pytest
    # All input tested
    # Inputs: chunk, body
    # chunk full
    # chunk in parts
    # chunk and body full
    # chunk and body in parts
    # chunk and body not full
    # chunk and body not full in parts

    # full chunk
    # expecting: chunk passed from input chunk to chunk in body
    chunk = b'abcdefghij'
    body = b'abcdefghij'
    bs = BufferedPrettyStream(conversion, formatting, msg)
    msg = HTTPMessage(self, headers=None, body=None, encoding=None, content_type=None,
                        is_body_readable=False, is_body_seekable=False)
    msg.chunk = chunk
    msg.body = body