

# Generated at 2022-06-21 14:24:11.625340
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # Decoder: utf-8 
    test_string = 'Hello world!'
    test_string_bytes = str.encode(test_string)

    bps = BufferedPrettyStream(conversion=Conversion(),
        formatting=Formatting(),
        msg=HTTPMessage(b'HTTP/1.1 200 OK\r\nContent-Type: text/plain; encoding=utf-8', test_string_bytes))

    if next(bps.iter_body()).decode('utf-8') == test_string:
        assert True
    else:
        assert False

# Generated at 2022-06-21 14:24:17.360079
# Unit test for constructor of class RawStream
def test_RawStream():
    # test only one attribute of class RawStream,
    # since the rest are not meaningful to test
    raw_stream = RawStream(msg=HTTPMessage(), on_body_chunk_downloaded=None)

    assert raw_stream.msg is not None
    assert raw_stream.with_headers is True
    assert raw_stream.with_body is True
    assert raw_stream.on_body_chunk_downloaded is None


# Generated at 2022-06-21 14:24:21.332651
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage({}, "Hello")
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = lambda x: x
    bs1 = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    assert bs1.msg == msg
    assert bs1.with_headers == with_headers
    assert bs1.with_body == with_body
    assert bs1.on_body_chunk_downloaded == on_body_chunk_downloaded



# Generated at 2022-06-21 14:24:29.671763
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    output_encoding = 'utf8'
    msg = (HTTPMessage)
    conversion = (Conversion)
    formatting = (Formatting)
    mime = 'text/plain'
    data = '123'
    chunk = pm.process_body(data)
    assert isinstance(chunk, bytes)
    assert chunk == chunk.encode(output_encoding, 'replace')
    assert chunk == encoding.text(data, formating.format_body(content=data, mime=mime)).encode(output_encoding, 'rplace')

# Generated at 2022-06-21 14:24:36.450277
# Unit test for constructor of class RawStream
def test_RawStream():
    data = {
        "with_headers": False,
        "with_body": False,
        "on_body_chunk_downloaded": None
    }
    with pytest.raises(AssertionError):
        RawStream(**data)
    data["with_headers"] = True
    RawStream(**data)
    data["with_body"] = True
    RawStream(**data)
    data["on_body_chunk_downloaded"] = lambda chunk: chunk
    RawStream(**data)


# Generated at 2022-06-21 14:24:47.606844
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json
    import httpie.output.formatters
    import httpie.output.streams
    conversion = httpie.output.processing.Conversion()
    formatting = httpie.output.formatters.Formatter()
    pretty = httpie.output.streams.PrettyStream(
        msg=None,
        with_headers=True,
        with_body=True,
        conversion=conversion,
        formatting=formatting
    )
    content = b'{"test": "150301"}'
    mime = 'application/json'
    data = pretty.process_body(content)
    data = data.decode(pretty.output_encoding, 'replace')
    d = json.loads(data)
    assert d['test'] == '150301'



# Generated at 2022-06-21 14:24:59.534506
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream(msg = HTTPMessage())

# Generated at 2022-06-21 14:25:00.914697
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError("this is BinarySuppressedError") is not None

# Generated at 2022-06-21 14:25:04.604982
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    """
    @pytest.mark.parametrize([input, expected_output])
    """
    data = PrettyStream(
        msg=HTTPMessage(),
        conversion=Conversion(),
        formatting=Formatting(),
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )
    assert(data.process_body(str.encode('"Hello World !"')) == str.encode('"Hello World !"'))
    assert(data.process_body(str.encode('{')) == str.encode('{\n'))
    assert(data.process_body(str.encode('"Hello": "World !"')) == str.encode('"Hello": "World !"\n'))

# Generated at 2022-06-21 14:25:14.097808
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.compat import str
    from httpie.models import HTTPMessage
    from httpie.output.streams import PrettyStream

    # Unit test for iter_body() method of class PrettyStream
    # Case 1: content_type = "text/plain"
    msg = HTTPMessage(headers=None, encoding='utf8', content_type="text/plain")
    msg.raw = b'{ "id":1, "name":"Foo", "price":123, "tags":["Bar","Eek"] }'
    stream = PrettyStream(msg, conversion=None, formatting=None, with_headers=False, with_body=True)
    str(b''.join(stream.iter_body())) == b'{ "id":1, "name":"Foo", "price":123, "tags":["Bar","Eek"] }'

# Generated at 2022-06-21 14:25:29.572298
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import io
    import httpie.colors as clr
    import httpie.output.streams as streams
    http_response = b'HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\n\r\n{"foo": "bar"}'
    msg = HTTPMessage(io.BytesIO(http_response), clr.no_style())
    stream = streams.RawStream(msg)
    t = [c for c in stream.iter_body()]
    assert len(b''.join(t)) == len(msg.body)



# Generated at 2022-06-21 14:25:34.313759
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting

    env = Environment()
    conversion = Conversion(env=env)
    formatting = Formatting(env=env)
    stream = BufferedPrettyStream(
        msg=HTTPResponse(
            status_code=200,
            headers={
                'content-type': 'application/json'
            },
            body='Mississipi'
        ),
        env=env,
        conversion=conversion,
        formatting=formatting
    )
    next(stream.iter_body())

# Generated at 2022-06-21 14:25:41.454237
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import pytest
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPResponse(headers='Content-Type: application/json', body='{"name": "John Doe", "rank": "captain"}')
    stream = BufferedPrettyStream(
        msg=msg,
        conversion=conversion,
        formatting=formatting
    )
    c = 0
    for line in stream:
        c += 1
    assert c == 1

# Generated at 2022-06-21 14:25:48.825656
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    import requests
    import prettytable as pt

    # Initialize a request to get response
    response = requests.get('http://httpbin.org/stream/10', stream=True)
    # Initalize a :class:`EncodedStream` object
    stream = EncodedStream(msg=response, with_body=True, with_headers=False)
    # Iterate the :class:`EncodedStream` object to print the response out
    for line in stream:
        print(line)


# Generated at 2022-06-21 14:25:57.357873
# Unit test for constructor of class RawStream
def test_RawStream():
    msg, _ = HTTPMessage(), RawStream()
    msg.headers = "asd"
    msg.body = "asd"
    _.msg = msg
    _.with_headers = True
    _.with_body = True
    _.on_body_chunk_downloaded = None
    _.chunk_size = 1024 * 100
    assert _.get_headers() == "asd".encode('utf8')
    assert list(_.iter_body()) == [b'asd']



# Generated at 2022-06-21 14:26:08.502473
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import Response
    from httpie.output.processors.colors import Colors
    from httpie.output.processors.formatters import JSONFormatter

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    msg = Response('HTTP/1.1 200 OK\r\n\r\n{"hello":"world"}')
    conversion = Conversion(Colors(env), {})
    formatting = Formatting(JSONFormatter())
    converter = PrettyStream(msg,
                             conversion=conversion,
                             formatting=formatting,
                             env=env)
    results = [line for line in converter.iter_body()]

# Generated at 2022-06-21 14:26:12.040087
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    # Initialize variables
    message = 'test'
    bin_err = BinarySuppressedError(message)
    # Assertions
    assert bin_err.message == message

# Generated at 2022-06-21 14:26:13.046403
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    BinarySuppressedError() 


# Generated at 2022-06-21 14:26:18.267076
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        headers = {
            'test_header': 'test_value'
        },
        body = 'test_body',
        encoding = 'utf8'
    )
    stream = RawStream(msg)
    body_list = [chunk.decode('utf8') for chunk in stream.iter_body()]
    assert body_list == ['test_body']


# Generated at 2022-06-21 14:26:21.195742
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    """Test for constructor of class EncodedStream."""
    e = EncodedStream(HTTPMessage())
    assert(e.output_encoding == 'utf8')
    assert(e.msg)


# Generated at 2022-06-21 14:26:41.167851
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    p = PrettyStream(msg=None, with_headers=True, with_body=True,
        on_body_chunk_downloaded=None)
    print(p.process_body('{"name":"\u30a8\u30eb","age":19}'))
    print(p.process_body(b'{"name":"\xe3\x82\xa8\xe3\x83\xab","age":19}'))

# Generated at 2022-06-21 14:26:43.000618
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    d = DataSuppressedError()
    assert d.args == ()
    assert str(d) == ''


# Generated at 2022-06-21 14:26:54.110534
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
        b = BufferedPrettyStream()
        assert isinstance(b, BufferedPrettyStream)

# Unit test 1 for function get_headers()
# def test_get_headers_1():
#     msg = HTTPMessage(
#         'headers.utf8', b'',
#         headers=b'HTTP/1.1 200 OK\r\n'
#                 b'Content-Type: text/plain; charset=utf-8\r\n'
#                 b'Content-Length: 0\r\n'
#                 b'\r\n',
#         content_type='text/plain; charset=utf-8',
#     )
#     b = BufferedPrettyStream(msg, 'conversion', 'formatting')
#     assert b.get_headers() == b'HTTP/1.1 200 OK\r\

# Generated at 2022-06-21 14:26:55.031886
# Unit test for constructor of class RawStream
def test_RawStream():
    assert True


# Generated at 2022-06-21 14:27:02.087019
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import os
    
    curr_dir = os.path.dirname(os.path.realpath(__file__))
    file_name = os.path.join(curr_dir, 'output', 'test_output_jmespath.json')

    import json
    with open(file_name, 'r', encoding='utf-8') as file_obj:
        json_obj = json.load(file_obj)
    
    out = []
    for msg in json_obj:
        if isinstance(msg, list):
            # response:
            #   status
            #   headers
            #   body
            # request:
            #   headers
            #   body
            headers = msg[1]
            body = msg[-1]
        else:
            # info
            # [debug]
            headers = ''

# Generated at 2022-06-21 14:27:03.347738
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    print(1)


# Generated at 2022-06-21 14:27:10.435989
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    conversion = Conversion()
    conversion.register('text/plain', 'httpie.output.converter.JsonToPrettyJson')
    msg = HTTPMessage(
        request_url = 'http://httpbin.org/get',
        headers = [],
        body = '{"a": "b"}'
    )
    stream = PrettyStream(conversion=conversion, msg=msg, with_headers=False, with_body=True)
    for chunk in stream.iter_body():
        print(chunk)


# Generated at 2022-06-21 14:27:15.325745
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.output.streams import EncodedStream 
    from httpie.models import HTTPMessage
    msg = HTTPMessage('\r\n\r\n'.encode('utf8'))
    output_stream = EncodedStream(msg)
    print(output_stream.get_headers())

test_EncodedStream()

# Generated at 2022-06-21 14:27:22.510156
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    env = Environment()
    
    msg = HTTPMessage(
        headers=dict(headers=env.stdin_encoding),
        cookies=dict(cookies=env.stdin_encoding),
        encoding=env.stdin_encoding,
        content_type="application/json"
    )
    
    bs = BaseStream(
        msg=msg,
        with_headers=True,
        with_body=True
    )
    
    for line in bs:
        test_data = line.decode(env.stdin_encoding)
        if test_data == '{b\'headers\': b\'\'}\n{b\'cookies\': b\'\'}\n':
            print(True)

if __name__ == "__main__":
    test_BaseStream___iter__()

# Generated at 2022-06-21 14:27:24.817623
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    stream = BufferedPrettyStream()

# Generated at 2022-06-21 14:27:42.841019
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    # Initialize the environment variable
    env = Environment()    
    
    # Initialize the iter_body() function
    def iter_body(self) -> Iterable[bytes]:
        yield b'hello world'
    
    # Initialize the bytes    
    bytes_initial1 = 'hello world'
    bytes_initial2 = b'hello world'
    bytes_initial = [bytes_initial1, bytes_initial2]
    
    # Test the different bytes
    for bytes_input in bytes_initial:

        # Test the iter_body() function
        assert iter_body(bytes_input) == bytes_input


# Generated at 2022-06-21 14:27:49.737964
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    a = PrettyStream(
        HTTPMessage(status_code=200, headers={'Content-Type': 'application/json'}),
        with_headers=False,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting()
    )

    # case1: test json, check_content_type = 1
    chunk = '{"id":"1","name":"Kevin","age":"27"}'
    expected = b'{\n    "age": "27",\n    "id": "1",\n    "name": "Kevin"\n}'
    assert a.process_body(chunk) == expected

    # case2: test json, check_content_type = 1.5
    chunk = '{"id":"1","name":"Kevin","age":"27"}'

# Generated at 2022-06-21 14:27:56.895572
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPMessage, Response
    import io
    import json

    env = Environment()
    headers = {'Content-Type': 'application/json', 'Content-Length': '24'}
    body = {'name': 'test', 'age': 14}
    response = Response(
        url = 'http://localhost:5000/api/user',
        status_code = 200,
        headers = headers,
        body = json.dumps(body).encode('utf-8'),
        http_version = '1.1'
    )
    # print(response.headers)
    # print(response.headers.encode('utf8'))
    # print(response.body)

# Generated at 2022-06-21 14:27:58.145763
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    error = BinarySuppressedError()
    assert error.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:28:09.913969
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-21 14:28:19.104587
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    msg = HTTPMessage()
    msg.headers['content-type'] = 'application/json'
    msg.append(b'{\n')
    msg.append(b'"id": "id",\n')
    msg.append(b'"jsonrpc": "2.0"\n')
    msg.append(b'}\n')

    stream = BaseStream(msg)

    out = []

    for chunk in stream.iter_body():
        out.append(chunk)

    assert out == [
        b'{\n',
        b'"id": "id",\n',
        b'"jsonrpc": "2.0"\n',
        b'}\n',
    ]

# Generated at 2022-06-21 14:28:20.808238
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    msg.encoding = 'test'
    m = EncodedStream(msg)
    assert m.msg == msg
    assert m.output_encoding == 'test'


# Generated at 2022-06-21 14:28:27.192701
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage
    with_headers = 1
    with_body = 1
    on_body_chunk_downloaded = 1
    env = Environment

    es = EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded, env)
    assert es.msg == msg
    assert es.with_headers == with_headers
    assert es.with_body == with_body
    assert es.on_body_chunk_downloaded == on_body_chunk_downloaded
    assert es.env == env

    es = EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded)


# Generated at 2022-06-21 14:28:39.117097
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie import ExitStatus
    from httpie.cli import httpie
    from httpie.compat import is_windows

    def check_output(
        args,
        expected,
        stdin_isatty=True,
        stdout_isatty=True,
        stdout_encoding=None,
        stdin=b'',
        exit_status=ExitStatus.OK,
        **extra_kwargs,
    ):
        env = Environment(
            stdin_isatty=stdin_isatty,
            stdout_isatty=stdout_isatty,
            stdout_encoding=stdout_encoding,
            stdin=BytesIO(stdin),
            **extra_kwargs,
        )
        args = list(args)

# Generated at 2022-06-21 14:28:46.523279
# Unit test for constructor of class RawStream
def test_RawStream():
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.context import Environment
    env = Environment()
    body = ''
    chunk_size = 1024
    msg = HTTPRequest("GET", "http://example.com", body=body, chunk_size=chunk_size, env=env)
    stream = RawStream(msg)
    assert (msg, body, chunk_size) == (stream.msg, stream.msg.body, stream.chunk_size)
    msg = HTTPResponse(body, chunk_size=chunk_size)
    stream = RawStream(msg)
    assert (msg, body, chunk_size) == (stream.msg, stream.msg.body, stream.chunk_size)


# Generated at 2022-06-21 14:29:10.516592
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except DataSuppressedError as e:
        assert e.message==BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:29:19.824956
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # test case 1: encoding is utf-8,iterate with line
    msg = HTTPMessage(
        headers={"Content-Type": "text/plain;charset=UTF-8"},
        encoding="UTF-8",
        raw_bytes=b'\n\n\xe4\xb8\xad\xe6\x96\x87',
    )
    stream = EncodedStream(msg=msg,with_body=True,with_headers=False)
    assert next(stream.iter_body()) == b'\xe4\xb8\xad\xe6\x96\x87'
    # test case 2: encoding is utf-8,iterate with byte

# Generated at 2022-06-21 14:29:21.892743
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    with pytest.raises(NotImplementedError):
        EncodedStream()


# Generated at 2022-06-21 14:29:32.605138
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # unit test for method __iter__
    env = Environment(stdout_isatty=False)

# Generated at 2022-06-21 14:29:36.484490
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import HTTPResponse
    msg = HTTPResponse()
    s = BaseStream(msg, with_headers=True, with_body=True)
    assert s.msg == msg
    assert s.with_headers == True
    assert s.with_body == True


# Generated at 2022-06-21 14:29:40.649421
# Unit test for constructor of class RawStream
def test_RawStream():
    test_msg = b'GET /index HTTP/1.1\r\n\r\n'
    raw_stream = RawStream(test_msg)
    # test_msg should be equal to raw_stream.get_headers()
    assert test_msg == raw_stream.get_headers()
    print('test_RawStream : Success')



# Generated at 2022-06-21 14:29:45.189404
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    obj = BaseStream(msg=HTTPMessage,
                     with_headers=True,
                     with_body=True,
                     on_body_chunk_downloaded=None)
    assert next(obj) == b''


# Generated at 2022-06-21 14:29:46.628224
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    error = DataSuppressedError()
    assert error
    assert error.message is None

# Generated at 2022-06-21 14:29:47.521733
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    pass



# Generated at 2022-06-21 14:29:55.210908
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.pretty import PrettyStream
    from httpie.context import Environment
    env = Environment()
    prettystream = PrettyStream(env=env, chunk_size=10, 
        with_headers=True, with_body=True,
        on_body_chunk_downloaded= None)
    assert prettystream.env == env
    assert prettystream.CHUNK_SIZE == 10
    assert prettystream.with_headers == True
    assert prettystream.with_body == True
    assert prettystream.on_body_chunk_downloaded == None


# Generated at 2022-06-21 14:30:46.419605
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    print('Test for constructor of class EncodedStream')
    env = Environment()
    resp = EncodedStream(env=env, msg={'encoding': 'utf8'}, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    print('Output encoding:', resp.output_encoding)


# Generated at 2022-06-21 14:30:52.148940
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    method = "GET"
    url = "http://httpbin.org/get?id=123"
    headers = {'header1': 'value1', 'header2': 'value2'}
    msg = HTTPMessage(request_method=method,
                      request_url=url,
                      headers=headers)
    ps = BufferedPrettyStream(msg, with_headers=True,
                              with_body=True,
                              chunk_size=10)
    for b in ps:
        print(b)
    assert ps.get_headers() == b"header1: value1\r\nheader2: value2\r\n"
# test_BufferedPrettyStream()


# Generated at 2022-06-21 14:30:56.419981
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    # BinaySuppressedError.message = BINARY_SUPPRESSED_NOTICE
    assert BinarySuppressedError.message == b'\n+-----------------------------------------+\n| NOTE: binary data not shown in terminal |\n+-----------------------------------------+'


# Generated at 2022-06-21 14:31:02.204652
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Basic test for the iter_body method
    import requests
    import response

    help(response.ResponseMessage.iter_body)
    
    request = requests.get("http://www.google.com/")
    stream = RawStream(request, with_headers=True, with_body=True)
    print(stream.get_headers())
    print(iter(stream.iter_body()))
    print(iter(stream))


# Generated at 2022-06-21 14:31:12.935876
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    f = open('./test1.txt', 'r', encoding='utf-8')
    request_data = f.read()
    f.close()

# Generated at 2022-06-21 14:31:17.018660
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    #Check for type
    assert isinstance(BinarySuppressedError().message,bytes)
    #Check for the return value
    assert BinarySuppressedError().message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-21 14:31:19.479345
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage('utf8')
    stream = EncodedStream(msg)

    assert stream.msg is msg


# Generated at 2022-06-21 14:31:28.166072
# Unit test for constructor of class BaseStream
def test_BaseStream():
    # Testing constructer : BaseStream(self, msg: HTTPMessage, with_headers=True, with_body=True, on_body_chunk_downloaded: Callable[[bytes], None] = None)
    # Testing with_headers == True and with_body == True
    test_msg = "test_BaseStream"
    test_BaseStream = BaseStream(msg=test_msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert test_BaseStream.msg == test_msg
    assert test_BaseStream.with_headers == True
    assert test_BaseStream.with_body == True
    assert test_BaseStream.on_body_chunk_downloaded == None

    # Testing with_headers == False and with_body == True

# Generated at 2022-06-21 14:31:30.860056
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    message = "HTTP/1.1 200 OK"
    headers = HTTPMessage(message, 'utf8')
    headers1 = BaseStream(headers, True, False)
    assert headers1.get_headers() == message.encode()



# Generated at 2022-06-21 14:31:36.065172
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class MockHTTPMessage:
        content_type = 'text/plain'
        encoding = 'utf-8'

    class MockConversion:
        @staticmethod
        def get_converter(mime):
            return None

    class MockFormatting:
        @staticmethod
        def format_body(content, mime):
            return content

    obj = BufferedPrettyStream(
        MockHTTPMessage(),
        on_body_chunk_downloaded=None,
        chunk_size=1,
        conversion=MockConversion(),
        formatting=MockFormatting()
    )
    assert list(obj.iter_body()) == [b'\x00']

# Generated at 2022-06-21 14:33:36.477937
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import io
    import json
    import os
    import tempfile
    import unittest

    from httpie.models import (
        DEFAULT_UA,
        JSONDataDict,
        JSONDataSerializer,
        StreamDict,
        StreamSerializer,
    )

    from httpie.output.streams import RawStream
    from utils import http
    from utils import TestEnvironment

    def json_test_cli(data, *args, **kwargs):
        """
        Run a test and compare JSON result.

        `data` is sent as JSON data.

        """

        env = TestEnvironment(colors=False, stdin_isatty=False)
        r = http(*args, data=data, env=env, **kwargs)
        return r, json.loads(r.stdout)


# Generated at 2022-06-21 14:33:43.895566
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    fake_msg = HTTPMessage()
    fake_msg.content_type = 'application/json'
    fake_msg.encoding = 'utf-8'
    fake_msg.headers = '{"application/json":{"field1":"value1","field2":"value2"}}'
    fake_msg.body = '{"application/json":{"field1":"value1","field2":"value2"}}'
    fake_stream = PrettyStream(msg=fake_msg,
                               with_headers=True,
                               with_body=True,
                               conversion="None",
                               formatting='None')

# Generated at 2022-06-21 14:33:49.931399
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # 1. Create a RawStream object with mocked msg
    raw_stream = RawStream(mocked_msg, with_headers=False, with_body=True)
    # 2. Go through every chunk of raw_stream.iter_body()
    for chunk in raw_stream.iter_body():
        print('Chunk type:', type(chunk))
        print('Chunk:', chunk)


# Generated at 2022-06-21 14:33:58.883622
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():

    class FakeEnv(object):
        def __init__(self, stdout_isatty=None, stdout_encoding=None):
            self.stdout_isatty = stdout_isatty
            self.stdout_encoding = stdout_encoding


    class FakeBaseStream(BaseStream):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.seen_headers = False
            self.seen_body = False

        def get_headers(self):
            self.seen_headers = True
            return b'raw headers'

        def iter_body(self):
            self.seen_body = True
            return b'Hello, world!'.split()

    bs = FakeBaseStream(None, True, True)