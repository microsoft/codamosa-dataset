

# Generated at 2022-06-21 14:24:10.972360
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    d={'Content-Type': 'text/html;charset=utf8'}
    msg=HTTPMessage(raw=d, headers=d, body=b'aAa', encoding='utf8')
    stream=EncodedStream(msg=msg)
    for i in stream.iter_body():
        print(i)

# Generated at 2022-06-21 14:24:20.778582
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Testcase 1
    test_msg = HTTPMessage(headers = ' ')

# Generated at 2022-06-21 14:24:33.007620
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    env = Environment()
    mime = 'application/json'
    conversion = Conversion()

    def to_str(value):
        return json.dumps(value)

    conversion.register(mime, to_str)
    msg = HTTPMessage(
        type=HTTPMessage.RESPONSE,
        body=b'{"hello":"world"}',
        headers=[]
    )
    stream = BufferedPrettyStream(
        msg=msg,
        with_headers=False,
        with_body=False,
        env=env,
        conversion=conversion,
        formatting=Formatting(
            headers=[('Content-Type', 'application/json')],
            content=[]
        )
    )
    gen = stream.iter_body()
    for chunk in gen:
        print(chunk)

# Generated at 2022-06-21 14:24:34.636503
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    message = 'hello'
    error = BinarySuppressedError(message)
    assert error.message == message


# Generated at 2022-06-21 14:24:42.718531
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env=Environment()
    msg=HTTPMessage()
    with_headers=True
    with_body=True
    stream=EncodedStream(env=env,msg=msg,with_headers=with_headers,with_body=with_body)
    # assert stream.CHUNK_SIZE==RawStream.CHUNK_SIZE
    assert stream.CHUNK_SIZE==1
    assert stream.msg==msg
    assert stream.with_headers==with_headers
    assert stream.with_body==with_body

# Generated at 2022-06-21 14:24:51.171828
# Unit test for constructor of class RawStream
def test_RawStream():
    import os
    import json
    env = Environment()

    def get_msg():
        body_file = '../../httpbin/data/oh_hi_mark.jpg'
        headers_file = '../../httpbin/data/headers.json'
        with open(body_file, 'rb') as f:
            body = f.read()
        with open(headers_file, 'r') as f:
            headers = json.load(f)
        msg = HTTPMessage(headers=headers, body=body)
        assert msg.body == body
        return msg

    msg = get_msg()
    assert isinstance(msg,HTTPMessage)
    assert isinstance(msg.headers,dict)
    assert isinstance(msg.body,bytes)

    assert isinstance(RawStream(msg=msg),BaseStream)


# Generated at 2022-06-21 14:24:57.022098
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # When
    actual = PrettyStream(
        HTTPMessage(headers={'a': 'b'}),
        with_headers=True,
        with_body=False,
        conversion=Conversion(None),
        formatting=Formatting(None)
    ).get_headers()

    # Then
    assert 'b'.encode('utf8') == actual



# Generated at 2022-06-21 14:25:08.524479
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import pytest
    from httpie.models import Message
    from httpie.output.streams import RawStream, EncodedStream

    msg = Message(b'', b'', b'','')
    def test_data(StreamTester, **kwargs):
        stream = StreamTester(msg, **kwargs)
        chunks_iter = iter(stream)
        for expected, chunk in enumerate(chunks_iter):
            assert expected == chunk
        msg.body = [b'']
        chunks_iter = iter(stream)
        for expected, chunk in enumerate(chunks_iter):
            assert expected == chunk
        else:
            assert expected == 1
            
    test_data(EncodedStream)
    test_data(RawStream)

    msg.body = b'\0'

# Generated at 2022-06-21 14:25:09.511894
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert DataSuppressedError()


# Generated at 2022-06-21 14:25:16.644650
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import HTTPMessage, Headers
    from httpie.context import Environment
    from httpie.output.processing import Formatting
    from httpie.output.streams import BufferedPrettyStream
    import io

    env = Environment(stdin=io.StringIO(),
                      stdout=io.StringIO(),
                      stderr=io.StringIO(),
                      stdin_isatty=True)

    headers = Headers(content_type="text/html")
    body = "<html><body><h1>Welcome</h1></body></html>"
    msg = HTTPMessage(headers=headers, body=body)

    fmt = Formatting()

# Generated at 2022-06-21 14:25:31.395476
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage('200 OK', 'Header', 'UTF-8', b'body')
    stream = BaseStream(msg)
    print(stream.get_headers())


# Generated at 2022-06-21 14:25:39.011847
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPRequest
    from httpie.output.streams import EncodedStream
    from httpie.context import Environment
    http_request = HTTPRequest(
        headers={"Content-Type": "application/json"},
        url="www.google.com",
        body="{'name':'Quentine'}"
    )
    stream = EncodedStream(
        msg=http_request,
        with_headers=True,
        with_body=True,
        env=Environment()
    )
    print(list(stream))


# Generated at 2022-06-21 14:25:46.682257
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    # Test case 1
    msg = HTTPMessage(
        headers={
            'Content-Type': 'text/plain',
            'Content-Length':  '12',
            'Connection': 'keep-alive',
        }
    )
    expected = b'Connection: keep-alive\r\nContent-Length: 12\r\nContent-Type: text/plain\r\n'
    actual = BaseStream(msg).get_headers()
    assert expected == actual

    # Test case 2
    msg = HTTPMessage(
        headers={
            'Content-Type': 'text/plain',
            'Content-Length':  '12',
            'Connection': 'keep-alive',
            'Accept-Encoding': 'gzip, deflate',
        }
    )

# Generated at 2022-06-21 14:25:58.616093
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPRequest, HTTPHeaderMap
    from httpie.compat import BytesIO
    import json

    # Testing for non-binary data and utf8 output_encoding
    env = Environment()
    req = HTTPRequest(
        method="GET",
        url="http://httpbin.org/get",
        headers=HTTPHeaderMap({"Accept-Encoding": "utf8"}),
        data=BytesIO(json.dumps({"hello": "你好"}).encode("utf8")))
    stream = EncodedStream(msg=req, env=env)
    result = b''.join([chunk for chunk in stream.iter_body()])
    assert result == b'{\n    "hello": "\xe4\xbd\xa0\xe5\xa5\xbd"\n}\n'

# Generated at 2022-06-21 14:26:05.556267
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(
        headers='''\
        HTTP/1.1 200 OK
        foo: bar
        baz: qux
        ''',
        body="""\
        The quick brown fox jumps over the lazy dog.
        """
    )

    assert RawStream(msg).get_headers() == b'''\
HTTP/1.1 200 OK
foo: bar
baz: qux
'''



# Generated at 2022-06-21 14:26:10.919485
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    with_headers = True
    with_body=True
    data_suppressed_error = DataSuppressedError()
    s = BaseStream(msg,with_headers, with_body,data_suppressed_error)
    assert s.msg == HTTPMessage()
    assert s.with_headers == True
    assert s.with_body == True
    assert s.on_body_chunk_downloaded == DataSuppressedError()


# Generated at 2022-06-21 14:26:13.001961
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    message = 'test'
    exception = DataSuppressedError(message)
    assert exception.message == message


# Generated at 2022-06-21 14:26:22.599558
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # mock
    mock_msg = mock.Mock()
    mock_with_headers = mock.Mock()
    mock_with_body = mock.Mock()

    # mock of return value
    mock_get_headers = mock.Mock()
    mock_iter_body = mock.Mock()

    # mock instance of BaseStream
    mock_instance = mock.Mock(
        msg=mock_msg,
        with_headers=mock_with_headers,
        with_body=mock_with_body,
        get_headers=mock_get_headers,
        iter_body=mock_iter_body,
    )

    # return value of __iter__.
    real_return_value = list(BaseStream.__iter__(mock_instance))


# Generated at 2022-06-21 14:26:33.532017
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie import ExitStatus
    from httpie.cli import http
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BufferedPrettyStream

    env = Environment(
        stdin=six.StringIO(),
        stdin_isatty=True,
        stdout=six.BytesIO(),
        stdout_isatty=True,
    )
    args = httpie.cli.parser.parse_args(args=[], env=env)
    args.follow = False

    # Don't clear the screen after the ctrl+c keypress.
    BaseStream.clear_screen = lambda: None

    # As long as stdout is a tty, lines should be printed
    # progressively (issue #221).

    username = 'user'

# Generated at 2022-06-21 14:26:38.407853
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers["test"] = "test"
    msg.encoding = 'test'
    RawStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None).get_headers()

# Generated at 2022-06-21 14:26:57.400960
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.core import main
    from httpie import ExitStatus

    headers = '''\
HTTP/1.1 200 OK
Content-Type: text/plain
Content-Length: 2

'''

    args = ['--ignore-stdin', '--pretty=all']

    # No body (length=0).
    exit_status, output = main(
        args=args,
        stdin_bytes=headers.encode(
            'utf8'),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        method='GET'
    )
    assert exit_status == ExitStatus.OK
    assert output == b'\n'

    # Body is not binary (length=1).
    exit_status, output = main

# Generated at 2022-06-21 14:27:07.814664
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class MockHttpMessage:
        content_type = 'text/plain'

        def __init__(self, encoding, encoding_line_separator, body_iterator):
            self.encoding = encoding
            self.line_separator = encoding_line_separator
            self.__body_iterator = iter(copy.copy(body_iterator))

        def iter_lines(self, length):
            return self.__body_iterator

    length = 2
    encoding = 'utf16'
    encoding_line_separator = '\n'
    body_iterator = [
        (b'Hello', b''),
        (b'World', b''),
        (b'How', b''),
        (b'are', b''),
        (b'you?', b''),
    ]
    body_iterator_copy = copy.copy

# Generated at 2022-06-21 14:27:11.474330
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={'Content-Type': 'text/html'})
    stream = PrettyStream(msg, None, None)
    assert stream.get_headers() == b'HTTP/1.1 200 OK\r\nContent-Type: text/html'


# Generated at 2022-06-21 14:27:15.290256
# Unit test for constructor of class BaseStream
def test_BaseStream():
    bs = BaseStream(None, True, True)
    assert bs.msg is None
    bs = BaseStream(None, True, True, None)
    assert bs.on_body_chunk_downloaded is None
    assert bs.with_headers == True
    assert bs.with_body == True


# Generated at 2022-06-21 14:27:17.336859
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:27:18.838767
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    b = BinarySuppressedError()
    assert b.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:27:25.622399
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.input import ParseRequest
    from httpie.output.formatters.colors import get_lexer
    from httpie.utils import get_content_type
    import httpie.utils as utils
    env = Environment()
    request = ParseRequest()
    request.method = "GET"
    request.url = "http://httpbin.org/get"
    request.headers = r'"Content-Type": "application/json; charset=utf-8"'
    request.encoding = "utf8"
    request.stream = "http://httpbin.org/get"
    request.items = []
    request.request = r'GET http://httpbin.org/get "Content-Type": "application/json; charset=utf-8"'
    request.auth = None

# Generated at 2022-06-21 14:27:35.840399
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    with pytest.raises(BinarySuppressedError):
        env = Environment()
        conversion = Conversion.get_default_conversion()
        formatting = Formatting.get_default_formatting()
        bs = BufferedPrettyStream(
            msg=HTTPMessage(b'\0' * 2, b'content-type: application/json'),
            conversion=conversion,
            formatting=formatting,
            env=env
        )

    env = Environment()
    conversion = Conversion.get_default_conversion()
    formatting = Formatting.get_default_formatting()
    bs = BufferedPrettyStream(
        msg=HTTPMessage(b'a', b'content-type: application/json'),
        conversion=conversion,
        formatting=formatting,
        env=env
    )
    assert bs

# Generated at 2022-06-21 14:27:37.430505
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    try:
        raise DataSuppressedError()
    except DataSuppressedError:
        assert True


# Generated at 2022-06-21 14:27:43.712572
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage()
    msg.headers = {'Content-Type': 'text/html'}
    msg.encoding = 'utf8'
    msg.body = b'''
        <html>
            <head>
                <titile>HTML title</title>
            </head>
            <body>
                <h1>This is an H1 message</h1>
            </body>
        </html>
    '''
    stream = BaseStream(msg)
    assert stream.__iter__() == b'Content-Type: text/html\r\n\r\n\r\n\r\n'


# Generated at 2022-06-21 14:28:11.944405
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    stream = BaseStream(HTTPMessage(None, None, None, None, None, None, None))
    assert stream.get_headers() == b'HTTP/1.0 100 Continue\r\n\r\n'



# Generated at 2022-06-21 14:28:12.571824
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert 1

# Generated at 2022-06-21 14:28:15.247949
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # env = Environment()
    print(EncodedStream())

if __name__  ==  "__main__":
    test_EncodedStream()

# Generated at 2022-06-21 14:28:24.691586
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # content_type = None
    msg = HTTPMessage(None, content_type=None, encoding=None)
    stream = EncodedStream(msg, with_headers=True, with_body=True)
    assert stream.output_encoding == 'utf8'

    # content_type = 'text/plain; charset=utf-8'
    msg = HTTPMessage(None, content_type='text/plain; charset=utf-8', encoding='utf-8')
    stream = EncodedStream(msg, with_headers=True, with_body=True)
    assert stream.output_encoding == 'utf8'

    # content_type = 'text/plain; charset=big5'
    msg = HTTPMessage(None, content_type='text/plain; charset=big5', encoding='big5')

# Generated at 2022-06-21 14:28:26.563268
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test case for magic method __iter__ for the class: BaseStream
    pass



# Generated at 2022-06-21 14:28:36.998091
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import Response
    a = Response(request_url='https://httpbin.org/get',
                 status_code=200,
                 headers={'a': 'b', 'c': 'd'},
                 content_type='application/xml',
                 body='{"a": "b"}'.encode('utf-8'))
    b = BaseStream(msg=a)
    print(b.msg.headers)
    print(b.msg.body)
    print(b.msg.content_type)
    print(b.msg.encoding)
    print(b.get_headers())
    print(b.msg.content_type.split(';')[0])



# Generated at 2022-06-21 14:28:40.847150
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    stream = EncodedStream(msg=HTTPMessage(b'hello'))
    assert stream.iter_body().__next__().decode() == 'hello'
    assert stream.iter_body().__next__().decode() == 'hello'



# Generated at 2022-06-21 14:28:42.160898
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    d = DataSuppressedError()
    assert d.message == None


# Generated at 2022-06-21 14:28:53.295217
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # Create parameters for class PrettyStream
    if True:
        msg = HTTPMessage(start_line=None, headers=[], body=b'')
        with_headers = True
        with_body = True
        on_body_chunk_downloaded = None
        env = Environment()
        conversion = Conversion()
        formatting = Formatting()
    # Construct object
    pretty_stream = PrettyStream(msg=msg, with_headers=with_headers, with_body=with_body,
                                 on_body_chunk_downloaded=on_body_chunk_downloaded, env=env,
                                 conversion=conversion, formatting=formatting)
    print(pretty_stream)
    print(pretty_stream.msg)
    print(pretty_stream.with_headers)
    print(pretty_stream.with_body)


# Generated at 2022-06-21 14:29:00.243404
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import HTTPRequest
    from httpie.output.streams import PrettyStream
    env = Environment()

    headers_obj = HTTPRequest('http://localhost/api/v1/status/288/').headers
    headers_str = "Content-Type: application/json\r\nAuthorization: Token YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXow\r\n"

    stream = PrettyStream(headers=headers_obj, env=env)
    assert stream.get_headers().decode(env.stdout_encoding) == headers_str



# Generated at 2022-06-21 14:29:27.386914
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    DataSuppressedError()


# Generated at 2022-06-21 14:29:28.638176
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    p = PrettyStream("hello world", "hello world")


# Generated at 2022-06-21 14:29:39.373450
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Test if the iterator works properly
    msgBody = 'TestHTTPie'
    rawStream = RawStream(HTTPMessage(msgBody, 1024 * 100))
    chunks = []
    for chunk in rawStream.iter_body():
        chunks.append(chunk)
    assert (msgBody == ''.join(chunks))
    assert len(chunks) == 1

    # Test the chunk size
    msgBody = 'Test1Test2'
    msgBody += '___' * (1024 * 99)
    rawStream = RawStream(HTTPMessage(msgBody, 1024 * 100))
    chunks = []

    for chunk in rawStream.iter_body():
        chunks.append(chunk)
    assert len(chunks) == 100
    assert (msgBody == ''.join(chunks))



# Generated at 2022-06-21 14:29:49.413225
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():

    test_msg = HTTPMessage(content_type='text/plain', 
        headers={'Content-Type': 'text/plain', 'Accept-Charset': 'utf8', 'Accept': 'utf8'},
        encoding='utf8', iter_body=lambda: b'hello world')
    test_env = Environment(stdout_isatty=1, stdout_encoding='utf8')
    test_conversion = Conversion(1)
    test_formating = Formatting(1)

    test_BufferedPrettyStream = BufferedPrettyStream(
        msg=test_msg,
        conversion=test_conversion,
        formatting=test_formating,
        env=test_env
    )

    assert test_BufferedPrettyStream.process_body(b'hello world') == b'hello world'

# Generated at 2022-06-21 14:29:51.254853
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = '{"a":1}'
    assert type(PrettyStream(msg=msg).iter_body()) == typing.GeneratorType


# Generated at 2022-06-21 14:30:00.219736
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Arrange
    with open("../tests/data/file_upload.json") as file:
        json_data = json.load(file)
    
    # Act
    stream = BufferedPrettyStream(
        json.dumps(json_data),
        Conversion(options=None),
        Formatting(options=None),
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )

    # Assert
    assert isinstance(stream, BufferedPrettyStream)
    assert isinstance(stream, PrettyStream)
    assert isinstance(stream, EncodedStream)

# Generated at 2022-06-21 14:30:06.254592
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\nAB',
                      headers={"Content-Length": "4"})
    raw = RawStream(msg, with_body=True, with_headers=False)
    body = [bytes(c) for c in raw.iter_body()]
    assert body == [b'A', b'B'], body


# Generated at 2022-06-21 14:30:10.500468
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    u = RawStream()
    u.CHUNK_SIZE = 1
    data = [1,2,3,4,5,6,7,8,9]
    u.msg = data
    result = []
    for i in u.iter_body():
        result.extend(i)
    assert result == data

# Generated at 2022-06-21 14:30:18.387855
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    with open ("tests/echo-bin", "rb") as input_file:
        a_message = HTTPMessage(input_file)
        a_stream = EncodedStream(a_message ,with_headers=False, with_body=False)
        assert list(a_stream.iter_body()) == []
        a_stream = EncodedStream(a_message ,with_headers=False, with_body=True)
        assert list(a_stream.iter_body()) == ["\n"], "New line at the end of the payload"
        assert list(a_stream.iter_body()) == [], "Second time iterator is empty"
        a_stream = EncodedStream(a_message ,with_headers=True, with_body=False)

# Generated at 2022-06-21 14:30:20.586837
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        assert str(e.message) == str(BINARY_SUPPRESSED_NOTICE)


# Generated at 2022-06-21 14:31:15.427791
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    err = BinarySuppressedError()
    assert err.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:31:21.706748
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.processing import ContentTypeProcessor
    conversion = ContentTypeProcessor()
    formatting = ContentTypeProcessor()
    msg = Response(b'0123456789')
    env = Environment()
    b = BufferedPrettyStream(msg, conversion=conversion, formatting=formatting, env=env)
    assert list(b.iter_body()) == [b'0123456789']



# Generated at 2022-06-21 14:31:27.851320
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(
        headers={'a': 'b'},
        body='body',
    )
    s = BaseStream(msg, False, True, None)
    assert list(s) == [b'body']

    s = BaseStream(msg, True, False, None)
    assert list(s) == [b'a: b\r\n\r\n']

    s = BaseStream(msg, True, True, None)
    assert list(s) == [b'a: b\r\n\r\n', b'body']


# Generated at 2022-06-21 14:31:33.170223
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    print(BaseStream.get_headers(BaseStream))
    msg = HTTPMessage(
        url="www.baidu.com",
        headers={
            "abc": "abc",
            "bcd": "bcd"
        },
        content_type="text/html",
        encoding="utf8",
        body="<html></html>",
        body_as_bytes=b"<html></html>"
    )
    stream = BaseStream(msg)
    result = stream.get_headers()
    print(result)


# Generated at 2022-06-21 14:31:37.781027
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    message = "Hello World\n"
    http_message = HTTPMessage(message)
    stream = BufferedPrettyStream(msg=http_message)
    print(stream.iter_body().__next__().decode("utf-8"))
    print(stream.process_body(message).decode("utf-8"))
    print(stream.get_headers().decode("utf-8"))



# Generated at 2022-06-21 14:31:45.059370
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import io
    body = io.BytesIO(b'Hello\x00\nWorld-\n\n!')
    msg = HTTPMessage(encoding='utf8', headers='')
    msg.set_body(body)
    lines_list = [line for line in EncodedStream(msg=msg).iter_body()]
    assert lines_list == [b'Hello\n', b'World-\n', b'\n', b'!']



# Generated at 2022-06-21 14:31:53.275842
# Unit test for method iter_body of class RawStream

# Generated at 2022-06-21 14:31:54.291172
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
        # TODO
        pass

# Generated at 2022-06-21 14:31:57.226033
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    # CHUNK_SIZE = 1024 * 100
    # CHUNK_SIZE_BY_LINE = 1
    RawStream(msg)


# Generated at 2022-06-21 14:32:03.413434
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # text with new line
    assert len(list(PrettyStream(msg="test_only\r\n", conversion=None, formatting=None).iter_body())) == 2
    # text without new line
    assert len(list(PrettyStream(msg="test_only", conversion=None, formatting=None).iter_body())) == 1
    # no text
    assert len(list(PrettyStream(msg="", conversion=None, formatting=None).iter_body())) == 0