

# Generated at 2022-06-21 14:24:12.995969
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # arrange
    msg = HTTPMessage('utf8')
    msg.status_line = b'HTTP/1.1 304 Not Modified'
    msg.headers['Content-Type'] = 'application/octet-stream'
    msg.headers['Content-Length'] = '10'
    msg.body = b'\0\0\0\0\0\0\0\0\0\0'

    # act
    stream = EncodedStream(msg)

    # assert
    with pytest.raises(BinarySuppressedError):
       for chunk in stream.iter_body():
           print(chunk)

# Generated at 2022-06-21 14:24:22.235730
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    test_msg = HTTPMessage(
        headers=b'HTTP/1.1 200 OK\r\nContent-type: text/html\r\n\r\n',
        body=b'Hello World',
        encoding='utf8',
    )
    test_formatting = Formatting(
        assume_output_file=False,
        body_line_prettifier=lambda content, mime, width: '<' + content + '>',
        mime_line_prettifier=lambda mime, width: mime,
    )
    test_conversion = Conversion()
    test_env = Environment()

    test_stream = PrettyStream(
        msg=test_msg,
        conversion=test_conversion,
        formatting=test_formatting,
        env=test_env,
    )
    assert next

# Generated at 2022-06-21 14:24:23.379361
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-21 14:24:28.158903
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    """
    Test the method process_body of class PrettyStream
    """
    p = PrettyStream(None, None, None, None)

    assert p.process_body('{"a": "b"}') == b'{\n    "a": "b"\n}'

# Generated at 2022-06-21 14:24:37.266486
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import BaseStream
    b = BaseStream(HTTPMessage(headers=Headers({})))
    assert b.get_headers() == b''
    b = BaseStream(HTTPMessage(headers=Headers({'a':'b'})))
    # Change this link to match system
    #assert b.get_headers() == b'a: b'
    assert b.get_headers() == b'A: b'
    b = BaseStream(HTTPMessage(headers=Headers({'a':'b','c':'d'})))
    #assert b.get_headers() == b'a: b\r\nc: d'
    assert b.get_headers() == b'A: b\r\nC: d'

# Generated at 2022-06-21 14:24:48.538564
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from io import BytesIO
    from httpie.models import HTTPResponse
    from httpie.core import parse_response

    response_content = b'abcd'
    binary_data = b'a\x00bcd'
    headers = {'Content-Length': str(len(response_content))}
    response_message = parse_response(b'HTTP/1.1 200 OK\r\n'
                                      b'Content-Length: ' +
                                      str(len(response_content)).encode('utf-8') +
                                      b'\r\n\r\n' + response_content)

    # Test that normal data is correct
    raw_stream = RawStream(msg=response_message)
    assert list(raw_stream.iter_body()) == [response_content]

    # Test that binary data

# Generated at 2022-06-21 14:24:56.186342
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    message = HTTPMessage()
    message.headers.add('Content-Type', 'text/plain')
    message.headers.add('Content-Type', 'text/html')
    message.headers.add('Connection', 'keep-alive')
    stream = BaseStream(message)

    assert stream.get_headers() == b'Content-Type: text/plain, text/html\r\n' \
                                   b'Connection: keep-alive\r\n'



# Generated at 2022-06-21 14:25:07.617688
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Test case 01:
    # Test if the returned headers are properly formatted
    msg = HTTPMessage(headers=r'HTTP/1.1 200 OK\r\n Content-Type:text/plain\r\n'
                      r'\r\n\r\n', encoding=None, content_type=None)
    stream = PrettyStream(msg=msg, with_header=True, with_body=True)
    formatted_headers = 'HTTP/1.1 200 OK\r\nContent-Type:text/plain\r\n'
    assert formatted_headers == stream.get_headers()

    # Test case 02:
    # Test if some characters missing or added to the headers in the case of an
    # encoding issue

# Generated at 2022-06-21 14:25:09.906107
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    assert BufferedPrettyStream(
        HTTPMessage(
            headers=u'asdf'),
        Conversion(),
        Formatting())


# Generated at 2022-06-21 14:25:14.986714
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    try:
        from httpie.output.formatters import BinaryFormatter
        from httpie.output.streams import PrettyStream
    except ImportError:
        return
    mime = 'text/plain'
    content = 'foo\nbar'
    assert "foo\nbar" == PrettyStream(msg=None, with_headers=None, conversion=None, formatting=BinaryFormatter(output_options=None).format_body(mime=mime, content=content)).process_body(content)

# Generated at 2022-06-21 14:25:26.727028
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    err = DataSuppressedError()
    assert err != None


# Generated at 2022-06-21 14:25:32.697994
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    err = BinarySuppressedError()
    assert err.message == BINARY_SUPPRESSED_NOTICE
    assert repr(err) == "<BinarySuppressedError: '{notice}'>".format(
        notice=BINARY_SUPPRESSED_NOTICE)
    assert str(err) == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:25:42.614990
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import os
    # 发送post请求
    message=HTTPMessage('POST','http://www.motherfuckingwebsite.com','',b'test')
    # 读取文件
    f=open(os.path.join(os.getcwd(),'httpie','output','streams.py'),'rb')
    # 获得文件大小，创建一个相同大小的byte，用于后续测试
    size=os.path.getsize('httpie\\output\\streams.py')
    body=bytearray(size)

    # 创建RawStream对象，并读取body


# Generated at 2022-06-21 14:25:45.214615
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    PrettyStream(
        HTTPMessage.DEFAULT_PRETTY_OPTIONS,
        HTTPMessage.DEFAULT_PRETTY_OPTIONS,
        HTTPMessage('200 OK', {})
    )

# Generated at 2022-06-21 14:25:48.505320
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(None, None)
    chunk_size = 1024 * 53
    assert RawStream(msg, chunk_size).chunk_size == chunk_size


# Generated at 2022-06-21 14:25:49.476824
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    assert 1 == 1


# Generated at 2022-06-21 14:26:01.567185
# Unit test for constructor of class BaseStream
def test_BaseStream():
    status_code = 200
    headers = {}
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    http_message = HTTPMessage(status_code, headers)
    assert BaseStream(http_message, with_headers, with_body, on_body_chunk_downloaded).msg == http_message
    assert BaseStream(http_message, with_headers, with_body, on_body_chunk_downloaded).with_headers == True
    assert BaseStream(http_message, with_headers, with_body, on_body_chunk_downloaded).with_body == True
    assert BaseStream(http_message, with_headers, with_body, on_body_chunk_downloaded).on_body_chunk_downloaded == None


# Generated at 2022-06-21 14:26:07.322285
# Unit test for constructor of class RawStream
def test_RawStream():
    s = RawStream()
    assert(s.msg == None)
    assert(s.with_headers == True)
    assert(s.with_body == True)
    assert(s.on_body_chunk_downloaded == None)
    assert(s.chunk_size == 10240)
    print("Class RawStream constructor test passed.")


# Generated at 2022-06-21 14:26:12.955041
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    p1 = PrettyStream(HTTPMessage('{"test": 1}', None), Conversion(), Formatting())
    assert p1.process_body(b'{"test": 1}') == b'\n{\n    "test": 1\n}'



# Generated at 2022-06-21 14:26:22.560056
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class HTTPMessage_Sub(HTTPMessage):
        def __init__(self, content_type = 'application/json'):
            self.headers = []
            self.content_type = content_type
            self.encoding = 'utf8'
        def has_headers(self):
            return False
        def has_body(self):
            return False

        def iter_lines(self, chunk_size):
            yield (b'{"a": 1, "b":2}', b'\n')
            yield (b'{"c": 3, "d":4}', b'\n')

    content_type = 'application/json'
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage_Sub(content_type)


# Generated at 2022-06-21 14:26:54.110750
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    class testClass():
        def __init__(self, headers=None, encoding=None):
            self.headers = headers
            self.encoding = encoding
            self.content_type = "text/html"
            self.line_chunks = 0

        def iter_body(self, chunk_size=None):
            str = b'\x0c'
            yield str

        def iter_lines(self, chunk_size=None):
            return self.__iter__()

        def __iter__(self):
            str = b'\x0c'
            yield str, b'\x0a'

    testClass = testClass()
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    conversion = Conversion()
    formatting = Formatting()

# Generated at 2022-06-21 14:26:56.101234
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    with pytest.raises(BinarySuppressedError):
        Exception = BinarySuppressedError()
        Exception.message
        assert Exception.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:26:57.464935
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert EncodedStream(msg = HTTPMessage())


# Generated at 2022-06-21 14:27:07.863283
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPRequest
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    conversion = Conversion()
    mime = 'application/json'
    headers = 'Content-Type: application/json'
    body = '{"cat": "meow", "dog": "woof"}\r\n'

    def get_msg(body):
        return HTTPRequest(
            url='',
            method='GET',
            headers=headers,
            body=body
        )

    msg = get_msg(body)
    stream = PrettyStream(msg, conversion, Formatting())

    def compare(actual, expected):
        for a, e in zip(actual, expected):
            assert a == e


# Generated at 2022-06-21 14:27:16.279172
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(b'FOOBAR', {})

    def get_headers(self):
        return b'some data', b'\r\n\r\n'
    msg.get_headers = types.MethodType(get_headers, msg)
    stream = PrettyStream(msg, True, True)
    assert stream.get_headers() == b'some data\r\n\r\n'

    msg.headers = ['something']
    assert stream.get_headers() == b'something\r\n\r\n'

    msg.headers = ['Content-Type: some_content']
    assert stream.get_headers() == b'Content-Type: some_content\r\n\r\n'


# Generated at 2022-06-21 14:27:17.754712
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage(headers='')
    a = EncodedStream(msg)



# Generated at 2022-06-21 14:27:24.958135
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    import sys
    from subprocess import check_output
    type_name = 'BaseStream'
    print("Testing method iter_body of class %s." % type_name, file=sys.stderr)
    # This test will only work if run with Python 3.6 or higher.
    # # It attempts to patch the __iter__ method of the BaseStream class.
    # # Use the following command to generate test_data/test_iter_body_data.txt:
    # check_output('python3 -m cProfile -o cProfile.prof http.py --no-headers --download https://raw.githubusercontent.com/jakubroztocil/httpie/master/httpie/models.py'.split(' '))
    # # Search for function iter_body in test_data/test_iter_body_data.txt.
    #

# Generated at 2022-06-21 14:27:29.561327
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        status_line='HTTP/1.1 200 OK',
        headers=['Content-Type: text/html', 'Connection: close'],
        body=b'abc',
    )
    stream = RawStream(msg)
    assert list(stream.iter_body()) == [b'abc']

# Generated at 2022-06-21 14:27:38.889249
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import os
    import sys
    import yaml
    m = HTTPMessage()
    m.headers['Content-Type'] = 'application/json'
    m.headers['Content-Length'] = '15'
    m.headers['Server'] = 'TornadoServer/4.1'
    m.headers['Access-Control-Allow-Origin'] = '*'
    m.headers['Access-Control-Allow-Credentials'] = 'true'
    m.headers['X-Powered-By'] = 'Express'
    m.headers['Vary'] = 'Origin'
    m.headers['Content-Encoding'] = 'gzip'
    m.headers['Date'] = 'Tue, 26 Jul 2016 02:48:48 GMT'
    m.headers['Connection'] = 'keep-alive'

# Generated at 2022-06-21 14:27:46.077166
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-21 14:28:28.899350
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    contents = '''body\n

body1\n'''
    def iter_body():
        yield contents.encode()
    pretty = BufferedPrettyStream(msg=HTTPMessage(body=contents), with_headers=False, with_body=True)
    pretty.msg.iter_body = iter_body
    result = next(iter(pretty))
    assert result == contents.encode(), result

# Generated at 2022-06-21 14:28:40.299488
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    msg = HTTPMessage(headers=b'Header:Value\r\n\r\n',
                      body=b'line1\r\nline2\r\n',
                      content_type='text/plain')

    def iter_body():
        """
        iterate body by lines
        :return: [b'line1\r\n', b'line2\r\n']
        """
        return iter(msg.iter_body(1))

    def get_headers():
        """
        get headers
        :return: b'Header:Value\r\n\r\n'
        """
        return msg.headers

    test_base_stream = BaseStream(msg=msg,with_headers=True, with_body=True)
    test_base_stream.get_headers = get_headers
    test_base

# Generated at 2022-06-21 14:28:47.578110
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(content_type='application/json')
    kwargs = {'msg': msg, 'with_headers': True, 'with_body': True,
                'on_body_chunk_downloaded': None}
    output_encoding = 'utf8'
    conversion = Conversion()
    formatting = Formatting()

    encodedStream = EncodedStream(**kwargs)
    prettyStream = PrettyStream(conversion, formatting, **kwargs)
    bufferedPrettyStream = BufferedPrettyStream(conversion, formatting, **kwargs)
    assert prettyStream.msg == bufferedPrettyStream.msg == encodedStream.msg
    assert prettyStream.with_headers == bufferedPrettyStream.with_headers == encodedStream.with_headers

# Generated at 2022-06-21 14:28:54.619428
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    body = b'{"a": 1}'
    msg = HTTPMessage(headers=b'Content-Type: application/json', body=body)
    msg.content_type = 'application/json; charset=utf8'
    msg.encoding = 'utf-8'
    stream = BufferedPrettyStream(msg, conversion=Conversion(), formatting=Formatting())
    assert b'{\n    "a": 1\n}' in stream.iter_body()

# Generated at 2022-06-21 14:29:00.458782
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    print("Testing constructor of BufferedPrettyStream")
    req = HTTPMessage(_body=b'{"hello":"world"}', headers={'Content-Type': 'application/json'})
    message = BufferedPrettyStream(msg=req, conversion=Conversion({}), formatting=Formatting(), with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    print(message.mime)
    print(message.process_body(b'{"hello":"world"}'))
test_BufferedPrettyStream()



# Generated at 2022-06-21 14:29:01.824210
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import HTTPMessage
    message = HTTPMessage()
    BaseStream(message)

# Generated at 2022-06-21 14:29:11.773124
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(headers = "aa", encoding = "bb", content_type = "cc")

    conversion = Conversion(True, True)
    formatting = Formatting("", "", "", "", "", "", "", "", True, True, True)

    kwargs = {
        "msg": msg,
        "with_headers": True,
        "with_body": True,
        "env": Environment(),
        "conversion": conversion,
        "formatting": formatting,
    }

    p = PrettyStream(**kwargs)
    assert p.msg == msg
    assert p.with_headers == True
    assert p.with_body == True
    assert p.env == Environment()
    assert p.CHUNK_SIZE == 1
    assert p.conversion == conversion
    assert p.formatting == formatting

# Generated at 2022-06-21 14:29:21.093097
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    import json

    mime = "application/json"
    headers = {"Content-Type": mime}
    body = json.dumps({"Hello": "World"}).encode()
    msg = HTTPMessage(mime, body, headers)
    conversion = Conversion()
    formatting = Formatting()
    pretty_stream = BufferedPrettyStream(msg=msg, conversion=conversion, formatting=formatting)
    for chunk in pretty_stream.iter_body():
        assert chunk == b'{\n  "Hello": "World"\n}'

# Generated at 2022-06-21 14:29:25.255248
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage('''HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 37

{"foo": "bar", "baz": [1, 2, 3]}
''')
    stream = BufferedPrettyStream(msg, conversion=None, formatting=None)
    assert stream.mime == 'application/json'
    assert list(stream) == [
        b'{"foo": "bar", "baz": [1, 2, 3]}'
    ]



# Generated at 2022-06-21 14:29:32.402802
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage(
        headers={'content-type': 'application/json'},
        body=b'{"key": "value",\n"key2": "value2"}',
    )

    stream = EncodedStream(
        msg,
        with_headers=False,
        with_body=True,
    )

    assert list(stream) == [b'{\n', b'"key": "value",\n', b'"key2": "value2"\n', b'}']

# Generated at 2022-06-21 14:30:58.313257
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # -------------------------------------
    # the constructor of PrettyStream class
    # -------------------------------------
    # test the first constructor
    # -------------------------------------
    try:
        PrettyStream(Environment())
        # do not raise an error
    except Exception as e:
        assert False, "Unexpected error raised in constructor: " + str(e)

# Generated at 2022-06-21 14:31:03.132622
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessage
    bs = BaseStream(HTTPMessage(b'ss'))
    assert iter(bs) == bs

try:
    unicode
except NameError:
    # Python 3
    unicode = str

# unit test for method process_body of class PrettyStream

# Generated at 2022-06-21 14:31:09.122532
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(headers='a: b\nc: d', encoding='utf8')
    stream = BaseStream(msg)
    stream_iter = iter(stream)
    assert next(stream_iter) == b'a: b\nc: d\r\n'
    with pytest.raises(StopIteration):
        next(stream_iter)



# Generated at 2022-06-21 14:31:12.486773
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    assert BaseStream(msg,with_headers,with_body,on_body_chunk_downloaded)

# Generated at 2022-06-21 14:31:16.880544
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    try:
        raise DataSuppressedError()
    except DataSuppressedError as e:
        print("message:", e.message)
        print("args:", e.args)

test_DataSuppressedError()


# Generated at 2022-06-21 14:31:26.285787
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import Request
    from pygments.formatters.terminal import TerminalFormatter
    from httpie.output.formatters.colors import ColorFormatter
    from httpie.output.formatters.terminal import SingleLineTerminalFormatter
    from httpie.plugins.builtin import HTTPBasicAuth
    #request = Request(method="GET", url="http://httpbin.org/get", headers=[],
    #                  auth=HTTPBasicAuth('user', 'password'))
    headers = "user-agent: httpie/1.0.0\r\nhost: httpbin.org\r\n" +\
              "accept-encoding: gzip, deflate\r\naccept: */*\r\n"

# Generated at 2022-06-21 14:31:33.942502
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from io import BytesIO
    from httpie.input import ParseError
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    b = BytesIO(b'HTTP/1.1 200 OK\r\nContent-type: text/html\r\n\r\n')
    try:
        response = HTTPResponse.from_stream(b)
    except ParseError:
        pass
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()
    header = PrettyStream(response, with_headers=True,
                          with_body=False, env=env,
                          conversion=conversion,
                          formatting=formatting).get_headers()
    print(header)

# Generated at 2022-06-21 14:31:44.126407
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(headers='''HTTP/1.1 200 OK
    Server: nginx/1.9.14
    Date: Fri, 03 Mar 2017 08:40:26 GMT
    Content-Type: application/json;charset=UTF-8
    Transfer-Encoding: chunked
    Connection: keep-alive
    X-Powered-By: Express
    Access-Control-Allow-Origin: *''', body='''{ 'foo': 'bar' }''')
    b = BaseStream(msg, True, True)
    assert b.msg.start_line == 'HTTP/1.1 200 OK'
    assert b.msg.body == '''{ 'foo': 'bar' }'''
    assert len(b.msg.headers) == 8



# Generated at 2022-06-21 14:31:48.519579
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():

    def test_iter_body():
        for i in xrange(1, 20):
            msg = HTTPMessage(raw_body='Hello' * i, headers=(), encoding='utf8')
            for chunk in RawStream(msg).iter_body():
                print('chunk is', chunk)
                print('chunk is', len(chunk))
            print('------------------------------------')

    test_iter_body()

# Generated at 2022-06-21 14:31:52.886554
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    import httpie.models
    message = httpie.models.HTTPMessage("GET", "/", [("a", "v1"), ("a", "v2")], None, None)
    stream = BaseStream(message, with_body=False)
    assert stream.get_headers() == b"GET / HTTP/1.1\r\na: v1, v2\r\n"