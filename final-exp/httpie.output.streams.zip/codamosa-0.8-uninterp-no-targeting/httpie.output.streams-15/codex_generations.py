

# Generated at 2022-06-21 14:24:09.613609
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Create a context-manager produced by the HTTPResponse of a test server
    with HTTPResponse(b'http://localhost:5000/get', method='GET', headers=None) as resp:
        # Create a RawStream instance that would handle the response body
        # It would handle the response headers and body
        # since both arguments toggles are True
        stream = RawStream(resp, with_headers=True, with_body=True)
        # Feed the HTTPResponse instance as the argument to the RawStream
        for chunk in stream.iter_body():
            print(chunk)
            # assert isinstance(chunk, bytes)



# Generated at 2022-06-21 14:24:11.788806
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    """
    Unit test for method iter_body of class PrettyStream
    """
    # property of class.
    pass


# Generated at 2022-06-21 14:24:21.412478
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(headers='Content-Type: text/plain\r\n', body=b'1234567890')
    stream = BaseStream(msg=msg, with_headers=True, with_body=True)
    assert list(stream.__iter__()) == [b'Content-Type: text/plain\r\n\r\n', b'1234567890']

    msg = HTTPMessage(headers='Content-Type: text/plain\r\n', body=b'1234567890')
    stream = BaseStream(msg=msg, with_headers=True, with_body=False)
    assert list(stream.__iter__()) == [b'Content-Type: text/plain\r\n\r\n']


# Generated at 2022-06-21 14:24:30.077666
# Unit test for constructor of class RawStream
def test_RawStream():
    """Unit test for constructor of class RawStream
    (HTTP Request Message)."""
    msg = HTTPMessage(b'GET', b'/get', b'HTTP/1.1', {'Content-Type': 'text/html'}, b'<h1>Hello World</h1>')
    stream = RawStream(msg, on_body_chunk_downloaded=None)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-21 14:24:34.071415
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    class TestStream(BufferedPrettyStream):
        pass
    test_stream = TestStream(
        conversion = Conversion(),
        formatting = Formatting(),
        msg = HTTPMessage(body = "")
    )
    assert isinstance(test_stream, BufferedPrettyStream)

# Generated at 2022-06-21 14:24:35.962918
# Unit test for constructor of class RawStream
def test_RawStream():
    obj = RawStream()
    print(obj)

# Test fail for private method iter_body of class RawStream

# Generated at 2022-06-21 14:24:47.408150
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    buffered_pretty_stream = BufferedPrettyStream(conversion = Conversion(),
                                              formatting = Formatting(),
                                              msg = HTTPMessage(),
                                              with_headers = True,
                                              with_body = True,
                                              on_body_chunk_downloaded = None)
    buffered_pretty_stream.msg.encoding = "utf8"
    buffered_pretty_stream.output_encoding = "utf8"
    buffered_pretty_stream.msg.content_type = "test"
    buffered_pretty_stream.CHUNK_SIZE = 4
    buffered_pretty_stream.msg.body = "test"

    # test 1: test case when there is no converter and no binary

# Generated at 2022-06-21 14:24:52.558178
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Create an Object of HTTPMessage
    msg = HTTPMessage(headers=None,
                      content_type="application/xml",
                      body="Test RawStream body")

    # Create an object of RawStream and call iter_body
    rawStream = RawStream(msg=msg)
    rawStream.iter_body()



# Generated at 2022-06-21 14:24:55.451550
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    _stream = PrettyStream(msg=b'123', conversion='id', formatting='id')
    assert _stream.formatting == 'id'
    assert _stream.conversion == 'id'

# Generated at 2022-06-21 14:24:59.348384
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    e = DataSuppressedError()
    assert e.message is None
    assert str(e) == ''
    with pytest.raises(NotImplementedError):
        e.message = 'message'


# Generated at 2022-06-21 14:25:14.393683
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    sample_msg = HTTPMessage()

# Generated at 2022-06-21 14:25:16.420624
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    m_DataSuppressedError = DataSuppressedError()
    assert m_DataSuppressedError.message == None


# Generated at 2022-06-21 14:25:20.557268
# Unit test for constructor of class RawStream
def test_RawStream():
    try:
        RawStream()
    except:
        print("test RawStream failed")


# Generated at 2022-06-21 14:25:28.904022
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class MockHTTPMessage(HTTPMessage):
        data = "I love HTTPie\n"
        def iter_body(self, chunk_size):
            for i in range(0, len(self.data), chunk_size):
                yield self.data[i:i+chunk_size].encode('utf-8')
        @property
        def content_type(self):
            return 'text/plain'
        def encoding(self):
            return 'utf-8'

    # Create a stream and call iter_body
    msg = MockHTTPMessage()
    stream = BufferedPrettyStream(msg=msg, with_body=True)
    body = stream.iter_body()

    # Assert
    assert isinstance(next(body), bytes)
    # There must be only one element

# Generated at 2022-06-21 14:25:34.405319
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    data = b"HTTP/1.1 200 OK\r\n" \
          b"Content-Type: application/json\r\n" \
          b"Content-Length: 150\r\n" \
          b"Server: TornadoServer/6.0.3\r\n\r\n" \
          b'{"r": "r", "a": "a", "i": "i", "n": "n", "b": "b", "o": "o", "w": "w", "s": "s"}'
    msg = HTTPMessage.from_bytes(data)
    stream = BufferedPrettyStream(msg)
    for i in stream.__iter__():
        print(i)

# Generated at 2022-06-21 14:25:37.426441
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        # not valid json
        raise BinarySuppressedError()
    except DataSuppressedError as e:
        ex_msg = e.message
    assert ex_msg == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:25:45.787749
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    import httpie.output.streams
    import httpie.models
    httpie.models.HTTPMessage.__init__ = lambda self, headers, encoding, **args: None
    httpie.models.HTTPMessage.headers = "Header1: value1\nHeader2: value2\nHeader3: value3\n"

    httpie.output.streams.PrettyStream.__init__ = lambda self, *arg1, **arg2: None

    httpie.output.streams.Formatting.format_headers = lambda self, headers: 'Header1: value1\r\nHeader2: value2\r\nHeader3: value3\r\n'

    # Arrange
    expected = 'Header1: value1\r\nHeader2: value2\r\nHeader3: value3\r\n'


# Generated at 2022-06-21 14:25:47.845582
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    # test if DataSuppressedError can be constructed without error
    e = DataSuppressedError()

# Generated at 2022-06-21 14:25:50.411234
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env=Environment()
    assert type(env) is Environment
    stream=EncodedStream(msg=None, env=env)
    assert type(stream) is EncodedStream

# Generated at 2022-06-21 14:26:02.557133
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream
    from httpie.core.protocol import http2

    msg = HTTPResponse(http_version="HTTP/2.0",
                       status_code=200,
                       headers=["Content-type: text/plane",
                                "Server: httpie"
                                ],
                       content=(b"HTTP/2.0 is the next generation of HTTP.\n"
                                b"It's based on the SPDY protocol and it aims to work fast.\n"
                                b"It's a binary protocol and it's more efficient than HTTP/1.1.\n"
                                b"It also supports all the features of HTTP/1.1."
                                )
                       )


# Generated at 2022-06-21 14:26:23.985386
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.client import Response
    headers = 'key: value'
    body = 'hello world'
    msg = Response({'Content-Type': 'text/plain', 'Content-Length': str(len(body))},
                     body=body.encode(),
                     url='http://google.com',
                     http_version='1.1')
    http_stream = BaseStream(msg, with_headers=True, with_body=True)
    print(http_stream)
    print(http_stream.get_headers())
    print(http_stream.msg)
    print(http_stream.with_body)


# Generated at 2022-06-21 14:26:36.131536
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.core import main
    from httpie.plugins.builtin import JSONPlugin
    from httpie import ExitStatus

    json_plugin = JSONPlugin()
    json_plugin.load()
    args = main.parser.parse_args(args=[
        'https://httpbin.org/json',
        '--json',
        '-u',
        'httpie:passwd'
    ])
    args.output_options['pretty'] = 'all'
    # create a HTTPResponse object based on the message
    resp = HTTPResponse(**vars(args))
    # the body of this message is json

# Generated at 2022-06-21 14:26:44.043976
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import requests

    # Use requests to test the iter_body method of class RawStream,
    # we should make sure the response is a stream response.
    rs = requests.get('https://www.sina.com.cn', stream=True)
    assert(rs.raw.__class__ == requests.packages.urllib3.response.HTTPResponse)

    # Create a RawStream object for method iter_body testing
    rt = RawStream(chunk_size=rs.raw.chunk_size, with_headers=True, with_body=True, msg=rs.raw)
    rt_iter_body = rt.iter_body()

    for chunk in rt_iter_body:
        assert(chunk.__class__ == bytes)

# Generated at 2022-06-21 14:26:54.682489
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import doctest
    # import httpie.output.raw
    doctest.testmod(m=BaseStream)   #, optionflags=doctest.ELLIPSIS)

    """
    Doctest sample program:
    >>> from typing import Iterable
    >>> class C:
    ...     def __init__(self, _iter: Iterable[str]):
    ...         self._iter = _iter
    ...     def iter_body(self):
    ...         for x in self._iter:
    ...             yield x
    ...
    >>> msg = C(['a', 'b', 'c', 'd'])
    >>> raw_stream = RawStream(msg)
    >>> list(raw_stream)
    ['a', 'b', 'c', 'd']
    """

# Generated at 2022-06-21 14:26:55.918488
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    error = DataSuppressedError()
    assert error.message is None


# Generated at 2022-06-21 14:27:06.193674
# Unit test for constructor of class PrettyStream

# Generated at 2022-06-21 14:27:08.406336
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    """
    :return:
    """
    # test class BufferedPrettyStream
    test_BufferedPrettyStream_iter_body()

    # test class EncodedStream
    test_EncodedStream_iter_body()

    # test class RawStream
    test_RawStream_iter_body()



# Generated at 2022-06-21 14:27:15.606847
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():

    # Given
    env = Environment()
    headers = 'Content-Type: application/bin\r\n'
    body = 'hello world\n'

    # When
    stream = EncodedStream(
            msg=HTTPMessage(headers=headers, body=body.encode('utf8'), encoding='utf8'),
            env=env,
            with_headers=False,
            with_body=True
        )


    # Then
    res = b''.join(stream.iter_body())
    assert res == b'hello world\n'


if __name__ == "__main__":
    test_EncodedStream_iter_body()

# Generated at 2022-06-21 14:27:20.725657
# Unit test for constructor of class RawStream
def test_RawStream():
    content_type = "application/json"
    headers = httpie.models.Headers([
        (':status', '200'),
        ('content-type', content_type)
    ])
    msg = httpie.models.HTTPResponse(
        http_version='2',
        status_code=200,
        headers=headers,
        encoding='utf-8',
        raw=None
    )
    stream = RawStream(msg)
    assert stream.CHUNK_SIZE == 102400



# Generated at 2022-06-21 14:27:25.386978
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    msg = "Data was suppressed because of binary was found"
    e = DataSuppressedError()
    assert e.message == None, "No message was passed"

    e = DataSuppressedError(msg)
    assert e.message == msg, "Same message was passed as an argument"


# Generated at 2022-06-21 14:27:38.153226
# Unit test for constructor of class RawStream
def test_RawStream():
    assert RawStream(None) is not None

# Generated at 2022-06-21 14:27:43.959968
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage('GET / HTTP/1.1\r\n', 'test:test\r\n',
                      'content-type: application/json\r\n',
                      '\r\n', '{ "data" : 1}')
    msg.encoding = 'utf-8'
    stream = PrettyStream(msg, on_body_chunk_downloaded=None,
                          conversion=None, with_headers=True,
                          with_body=True, formatting=Formatting())
    assert (stream.get_headers() == b'test: test\ncontent-type: application/json\n')

# Generated at 2022-06-21 14:27:49.345974
# Unit test for constructor of class RawStream
def test_RawStream():
    msg_obj = HTTPMessage(None)
    msg_obj.headers = "headers test"
    msg_obj.body = "body test"
    msg_obj.encoding = "utf8"

    raw_obj = RawStream(msg_obj)
    assert raw_obj.msg.headers == "headers test"
    assert raw_obj.msg.body == "body test"
    assert raw_obj.msg.encoding == "utf8"



# Generated at 2022-06-21 14:27:50.545732
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert DataSuppressedError().message == None


# Generated at 2022-06-21 14:27:57.393025
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import FILE_PATH, BIN_FILE_PATH, BIN_FILE_CONTENT, \
        BIN_FILE_PATH_ARG

    # Test non-binary response
    r = http('GET', FILE_PATH)
    assert exit_status(r) == ExitStatus.OK
    assert len(r.content) == int(HTTP_OK.headers['Content-Length'])

    # Test binary response
    r = http('GET', BIN_FILE_PATH)
    assert exit_status(r) == ExitStatus.OK
    assert r.raw_content == BIN_FILE_CONTENT

    # Test binary response with --download
    r = http('GET', BIN_FILE_PATH, '--download')
    assert exit_status(r)

# Generated at 2022-06-21 14:28:08.614056
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pretty_stream = "PrettyStream"
    mime = "mime"
    encoding = "encoding"
    chunk_type = "chunk_type"

    # Setup
    chunk = "chunk"
    format_body = "format_body"
    format_body_return = "format_body_return"
    body_type = "body_type"
    # create mock object
    m_PrettyStream = mock.Mock(chunk_type)

    # create mock
    m_mime = mock.Mock(mime)
    m_encoding = mock.Mock(encoding)
    m_formatting = mock.Mock()
    m_format_body = mock.Mock(format_body)
    m_chunk = mock.Mock(chunk)

# Generated at 2022-06-21 14:28:19.426300
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    message = HTTPMessage(None, None, None)
    stream = RawStream(message)

# Generated at 2022-06-21 14:28:27.568565
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(
        headers={'Content-Type': 'text/html'},
        encoding='utf8',
        content_type='multipart/form-data',
        body=b'<encoded-body-chunk>\n'
             b'<encoded-body-chunk>\n'
             b'<encoded-body-chunk>\n')

    stream = PrettyStream(msg=msg,
        formatting=Formatting(),
        conversion=Conversion(
            {'multipart/form-data': lambda _: ('text/html', '<html>')}
        ))

# Generated at 2022-06-21 14:28:34.805627
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    msg = HTTPMessage(b'HTTP/1.1 200 OK\r\n',
        b'Content-Type: text/plain; charset=utf-8\r\n',
        b'\r\n', b'sample data')
    stream = PrettyStream(msg, with_headers=False,
        formatting=Formatting(), conversion=Conversion())
    assert next(stream.iter_body()) == b'sample data'

# Generated at 2022-06-21 14:28:44.484687
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    req = HTTPMessage()
    req.body = b'example body'
    req.headers = 'Content-Length: 12'
    req.content_type = ''
    req.encoding = 'utf8'
    req.transfer_encoding = ''
    req.mime = ''
    req.url = ''
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.stdout_canonical_encoding = 'utf8'
    conversion = Conversion()
    formatting = Formatting()
    response = BufferedPrettyStream(
        msg=req,
        env=env,
        conversion=conversion,
        formatting=formatting,
        with_headers=False,
        with_body=True
    )

# Generated at 2022-06-21 14:29:11.118269
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
	url = "https://httpbin.org/get"
	headers = {'accept': 'application/json'}
	resp = requests.get(url, headers=headers)
	print("Info of request.get()", resp.status_code, resp.url, resp.headers, resp.request)
	print("Body of request.get()", resp.text)

# Generated at 2022-06-21 14:29:13.128981
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    # TODO: Unit test for method iter_body of class BufferedPrettyStream
    pass


# Generated at 2022-06-21 14:29:22.650605
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import re, json
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage

    # Initialize the test variable
    msg = HTTPMessage()

# Generated at 2022-06-21 14:29:33.471676
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import pytest
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.compat import str

    def assert_process_body(input, expected):
        ps = PrettyStream(None, conversion=None, formatting=None,
                          msg=Response(200, b'OK', [], b'', None),
                          with_headers=False, with_body=True)
        ps.mime = 'text/plain'  # Assume plain text
        assert ps.process_body(str(input)) == str(expected)

    assert_process_body(b'', b'')
    assert_process_body(b'\x00', b'\ufffd')

# Generated at 2022-06-21 14:29:43.757489
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.plugins import builtin
    import json
    import sys
    rs = HTTPResponse(body=json.dumps({"this is a test":"for you"}).encode("utf8"), headers={"content-type":"application/json"})
    stream = BufferedPrettyStream(
        msg=rs,
        conversion=builtin.ConverterPlugin(),
        formatting=builtin.FormatterPlugin()
    )
    result = b""
    for i in stream.iter_body():
        result+=i
    assert result.decode("utf8") == b'{\n    "this is a test": "for you"\n}\n'.decode("utf8")

# Generated at 2022-06-21 14:29:51.508444
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    env = Environment()
    env.text_type = 'json'
    output_str = '{\n  "a": 1,\n  "b": 2\n}'
    output_json = json.loads(output_str)
    output_json_bytes = json.dumps(output_json).encode("utf-8")
    output_bytes = output_str.encode("utf-8")
    msg = HTTPMessage(content=output_json_bytes,
                      headers="Content-Type: application/json",
                      encoding="utf-8")
    #test of encoded stream
    stream1 = EncodedStream(msg=msg, env=env)
    test1 = b''.join(stream1.iter_body())
    assert test1 == output_bytes
    #test of pretty stream

# Generated at 2022-06-21 14:29:55.126031
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    # just test the constructor
    try:
        raise DataSuppressedError()
    except DataSuppressedError as exc:
        pass
    # assert that the instance has no message attribute
    assert exc.message is None



# Generated at 2022-06-21 14:29:56.867528
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    exception_DataSuppressedError = DataSuppressedError()
    assert exception_DataSuppressedError.message == None

# Generated at 2022-06-21 14:30:08.046973
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    test_response = HTTPMessage(
        headers={"Content-Type":"application/json", "Server":"test_server"},
        encoding='utf8',
        body=b'{"key":"value"}\r\n{"key1":"value1"}\r\n'
    )
    test_stream = PrettyStream(
        msg=test_response,
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(),
        env=Environment()
    )
    # get_header() & iter_body() should return iterators
    assert hasattr(test_stream.get_headers(), '__next__') and hasattr(test_stream.iter_body(), '__next__')
    # output of get_headers() should be a header in bytes

# Generated at 2022-06-21 14:30:15.378616
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class MockStream:
        def __init__(self):
            self._data = b'abc \xe3\x81\x82 123'

        def iter_body(self, chunk_size):
            for _, lf in zip(range(6), [b'', b'']):
                yield self._data[:2], lf
                self._data = self._data[2:]
            yield self._data, b''

    stream = EncodedStream(MockStream(), with_headers=False)
    assert list(stream.iter_body()) == [b'abc \xe3\x81\x82 123']



# Generated at 2022-06-21 14:30:45.408106
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers=b'Content-Type: text/html', body=b'abc')
    stream = RawStream(msg)
    assert next(stream.iter_body()) == b'ab'
    assert next(stream.iter_body()) == b'c'


# Generated at 2022-06-21 14:30:47.238661
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    try:
        raise DataSuppressedError
    except(DataSuppressedError):
        assert True

# Generated at 2022-06-21 14:30:49.003963
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import doctest
    doctest.testmod(ExtendedStreams)


# Generated at 2022-06-21 14:30:58.887209
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    def get_body(read_size):
        return b'abcdefghij'
    msg = HTTPMessage()
    msg.body = get_body
    print('directly call BaseStream.iter_body with read_size=5')
    s = BaseStream(msg)
    print(list(s.iter_body()))
    print('directly call BaseStream.iter_body with read_size=20')
    s = BaseStream(msg)
    print(list(s.iter_body()))
    print('call BaseStream.iter_body in RawStream with read_size=5')
    s = RawStream(msg)
    print(list(s))
    print('call BaseStream.iter_body in RawStream with read_size=20')
    s = RawStream(msg, chunk_size=20)
    print

# Generated at 2022-06-21 14:31:07.430831
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    msg = HTTPMessage(
        headers=['Dummy: value'],
        body=b'Dummy body, ' + b'\0' + b' with binary data.\n'
    )
    stream = EncodedStream(msg, with_headers=False, with_body=True)
    assert list(stream.iter_body()) == [b'Dummy body, + with binary data.\n']
    try:
        next(stream.iter_body())
        assert False, 'BinarySuppressedError not raised'
    except BinarySuppressedError:
        pass



# Generated at 2022-06-21 14:31:10.296163
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # test valid
    bp = BufferedPrettyStream(HTTPMessage(), True, True, None, Conversion(), Formatting())
    assert isinstance(bp, BufferedPrettyStream)

# Generated at 2022-06-21 14:31:17.821834
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    HTTP_RESPONSE = HTTPMessage(
        headers=('HTTP/1.0 200 Success\r\n'
                 'Content-Length: 6\r\n'
                 'Content-Type: text/plain\r\n'
                 '\r\n'),
        body=b'123456'
    )

    stream = BufferedPrettyStream(
        msg=HTTP_RESPONSE,
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting()
    )

    body = b''
    for chunk in stream:
        body += chunk


# Generated at 2022-06-21 14:31:27.022036
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    env = Environment()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None

    # test case 1
    if env.stdout_isatty:
        output_encoding = env.stdout_encoding
    else:
        output_encoding = 'utf8'
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    stream = EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded, env)
    assert stream.output_encoding == output_encoding

    # test case 2
    if env.stdout_isatty:
        output_encoding = env.stdout_encoding
    else:
        output_encoding = 'utf8'
    env.stdout_encoding

# Generated at 2022-06-21 14:31:34.437870
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    class test_HTTPMessage(HTTPMessage):
        def __init__(self, headers, body, encoding='utf-8', content_type=None):
            self.headers = headers
            self.body = body
            self.encoding = encoding
            self.content_type = content_type

        def iter_lines(self, chunk_size=1) -> Iterable[bytes]:
            lines = self.body.splitlines(keepends=True)
            return (line.encode() for line in lines)

    # test cases
    # ASCII
    test_body = 'ABC'
    test_headers = 'header'
    test_case_1 = test_HTTPMessage(test_headers, test_body)
    encoded_stream_1 = EncodedStream(test_case_1)

# Generated at 2022-06-21 14:31:38.049683
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import pytest
    from httpie.models import HTTPMessage

    msg = HTTPMessage(headers='Test', body='123')
    stream = BaseStream(msg)
    with pytest.raises(NotImplementedError):
        next(iter(stream))



# Generated at 2022-06-21 14:32:48.171800
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from models import HTTPResponse
    from io import BytesIO
    response = HTTPResponse(
        http_version='1.1',
        status_code=200,
        headers=[('Content-Type', 'application/json')],
        body=BytesIO(b'{"test": "value"}')
    )
    bps = BufferedPrettyStream(
        msg=response,
        conversion=Conversion.AUTO,
        formatting=Formatting.PRETTY,
        with_headers=False,
        with_body=True,
    )
    result = b"{\"test\": \"value\"}"
    assert next(bps.iter_body()) == result

# Generated at 2022-06-21 14:32:53.584649
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage(body='{"message": "hello"}', headers={'Content-Type': 'application/json'})
    stream = PrettyStream(msg, with_headers=False, with_body=True)
    print(stream.process_body(b'{"message": "hello"}'))
    assert stream.process_body(b'{"message": "hello"}') == b'{\n    "message": "hello"\n}\n'

# Generated at 2022-06-21 14:33:01.198323
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(
        'HTTP/1.1 200 OK',
        [('Content-Type', 'application/json')],
        b'{"id": "/subscriptions/00000000-0000-0000-0000-000000000000"}'
    )
    stream = PrettyStream(
        msg,
        conversion=Conversion(),
        formatting=Formatting(
            stream_output=False,
            output_options=False,
            output_options_shortcuts=False
        )
    )
    headers = stream.get_headers()
    assert isinstance(headers, bytes)
    body = ''.join(stream.iter_body())
    assert isinstance(body, str)
    body = body.split('\n')
    assert body[0] == 'HTTP/1.1 200 OK'

# Generated at 2022-06-21 14:33:02.703587
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    with pytest.raises(NotImplementedError):
        BaseStream().iter_body()


# Generated at 2022-06-21 14:33:04.673072
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert DataSuppressedError.__init__(DataSuppressedError,message=BINARY_SUPPRESSED_NOTICE) == None


# Generated at 2022-06-21 14:33:15.269118
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    class my_msg:
        def __init__(self):
            self.content_type = 'application/json'
            self.headers = ''
            self.encoding = 'utf8'
        def iter_lines(self):
            yield '{"message":"test"}', b'\r\n'

    class my_conversion:
        def get_converter(self, mime):
            return None

    class my_formatting:
        def format_headers(self, headers):
            return headers
        def format_body(self, content=None, mime=None):
            return content

    a = PrettyStream(
        conversion=my_conversion(),
        formatting=my_formatting(),
        msg=my_msg()
    )
    print(a.iter_body())


# Generated at 2022-06-21 14:33:19.936175
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(encoding='utf8')
    msg.headers['Connection'] = 'close'
    msg.headers['Content-Type'] = 'application/json'
    msg.body = b'{"a": "b"}\n'

    stream = BaseStream()
    assert stream.msg.encoding == 'utf8'
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-21 14:33:21.372468
# Unit test for constructor of class RawStream
def test_RawStream():
    print(RawStream)



# Generated at 2022-06-21 14:33:24.772374
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None)
    if isinstance(stream.process_body(b'abc'), bytes) & isinstance(stream.process_body(u'abc'), bytes):
        return True
    else:
        return False


# Generated at 2022-06-21 14:33:28.092910
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    b = BufferedPrettyStream(HTTPMessage(body=b'\U0001F3C6'))
    assert b'\xf0\x9f\x8f\x86' in list(b.iter_body())