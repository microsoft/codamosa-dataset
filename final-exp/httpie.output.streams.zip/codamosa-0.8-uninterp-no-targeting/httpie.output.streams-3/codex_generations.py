

# Generated at 2022-06-21 14:24:08.564255
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Headers
    h = Headers(value=[('a', 'b'), ('c', 'd')])
    msg = HTTPMessage(
        protocol = 'HTTP/1.1',
        status = 200,
        reason = 'OK',
        headers = h,
        body=b'',
    )
    b = BaseStream(msg)
    assert b.get_headers() == b'a: b\r\nc: d\r\n\r\n'



# Generated at 2022-06-21 14:24:18.864226
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class Message(HTTPMessage):
        def __init__(self, encoding='utf-8', body='', headers={}):
            super().__init__(encoding)
            self._body = body
            self.headers = headers

        def iter_body(self, chunk_size):
            for chunk in self._body.split('\n'):
                yield chunk, '\n'

    class Conversion:
        def get_converter(self, mime):
            return self

        def convert(self, body):
            return 'json', body.decode('utf-8')

    class Formatting:
        def format_headers(self, headers):
            return headers

        def format_body(self, content, mime):
            return content

    def msg(body):
        return Message(body=body)


# Generated at 2022-06-21 14:24:21.232683
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    headers_data = "Content-Type:text/html"
    class message:
        headers = headers_data
    base_stream = BaseStream(message, with_headers=True, with_body=True)
    assert base_stream.get_headers() == bytes(headers_data, "utf8")


# Generated at 2022-06-21 14:24:29.966909
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n'
    msg.headers += 'Server: httpbin.org\r\n'
    msg.headers += 'Connection: keep-alive\r\n'
    stream = BaseStream(msg)
    header_bytes = stream.get_headers()
    assert header_bytes == b'HTTP/1.1 200 OK\r\nServer: httpbin.org\r\nConnection: keep-alive\r\n'
    assert isinstance(header_bytes, bytes)


# Generated at 2022-06-21 14:24:32.430142
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    rawStream = RawStream(msg)
    assert not rawStream.iter_body()


# Generated at 2022-06-21 14:24:37.009023
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={'Content-Type': 'application/json', 'Content-Length': '15'},
                      body={'a': 'b'})

    obj = RawStream(msg)
    for i, chunk in enumerate(obj.iter_body()):
        print(type(chunk))
        print(chunk)
        print(i)
    # print(obj.iter_body())



# Generated at 2022-06-21 14:24:40.722409
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as err:
        assert err.message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-21 14:24:50.063063
# Unit test for method get_headers of class BaseStream

# Generated at 2022-06-21 14:25:00.223865
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    iteration = 0
    #mock_self = MagicMock()
    my_msg = HTTPMessage(
        headers=[('Content-Type', 'application/json')],
        encoding='utf8',
        body=b'{"name": "Sarah", "age": "21"}'
    )

    stream = PrettyStream(
        my_msg,
        with_headers=False,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting()
    )
    for line, lf in stream.iter_body():
        assert isinstance(line, str)
        assert iteration < 1
        iteration += 1

    assert(iteration == 1)

# Generated at 2022-06-21 14:25:11.035560
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # Test case with empty body
    input_string = b''
    msg = HTTPMessage(url="http://www.google.com", body=input_string, encoding="utf-8")
    stream = EncodedStream(msg)

    assert(b''.join(stream.iter_body()) == b'')

    # Test case with normal body
    input_string = b'a\x80b\n'
    msg = HTTPMessage(url="http://www.google.com", body=input_string, encoding="utf-8")
    stream = EncodedStream(msg)

    assert(b''.join(stream.iter_body()) == b'a?b\n')

    # Test case with binary body
    input_string = b'a\x80\x00b\n'

# Generated at 2022-06-21 14:25:23.161293
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 14:25:24.270990
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-21 14:25:35.672055
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.context import Environment
    from httpie.models import HTTPResponse
    from httpie.output import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    msg = HTTPResponse(
        b"""HTTP/1.1 200 OK\r
Server: nginx\r
Content-Type: application/json\r
\r
{"foo": "bar"}""",
    )
    stream = PrettyStream(
        msg,
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(expanded=True),
        env=Environment(),
    )
    assert msg.content_type == "application/json"

# Generated at 2022-06-21 14:25:41.300983
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    headers = [
        ('content-type','text/html'),
        ('content-length', '16106127')
    ]
    msg = HTTPMessage(headers=headers)
    Stream = BaseStream(msg=msg)
    assert Stream.get_headers() == b'Content-Type: text/html\r\nContent-Length: 16106127'


if __name__ == '__main__':
    test_BaseStream_get_headers()

# Generated at 2022-06-21 14:25:47.884407
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPMessage
    import array
    import struct
    import random
    import tempfile
    import os
    import io
    bs = BaseStream(HTTPMessage())
    # Test function __iter__ of class BaseStream
    with pytest.raises(NotImplementedError):
        bs.__iter__()
    # Test function get_headers of class BaseStream
    bs.with_headers = True
    bs.with_body = False
    with tempfile.TemporaryDirectory() as tempdir:
        file_path = os.path.join(tempdir, 'headers.txt')
        with io.open(file_path, 'rb', buffering=0) as bin_file:
            body = bytearray(bin_file.read())

# Generated at 2022-06-21 14:25:59.643744
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json
    from httpie.output.streams import PrettyStream
    headers = {'json': 'application/json', 'Content-Type': 'application/json'}
    body = '{"a": "aa", "b": "bb"}'

    def return_identity(content, mime):
        return content

    def attempt_json_decode(content, mime):
        import json
        try:
            json_obj = json.loads(content)
            return json.dumps(json_obj, indent=2)
        except json.decoder.JSONDecodeError:
            return content

    class JSONResponse():
        def iter_body(self, CHUNK_SIZE):
            yield body

    class NonJSONResponse():
        def iter_body(self, CHUNK_SIZE):
            yield 'this is a string'

# Generated at 2022-06-21 14:26:10.291605
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Test the default value of attribute chunk_size
    msg = HTTPMessage(
        body=b'First line\nSecond line\nThird line\nlast line',
        headers={
            'Content-Length': '39',
            'Content-Type': 'text/plain; charset=utf8',
        },
        encoding='utf8'
    )
    stream = RawStream(msg=msg)
    assert ''.join(x.decode('utf8') for x in stream.iter_body()) == (
        'First line\nSecond line\nThird line\nlast line'
    )
    # Test the specified value of attribute chunk_size
    stream = RawStream(msg=msg, chunk_size=10)

# Generated at 2022-06-21 14:26:17.444466
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
	header_arg = {'target': 'https://httpbin.org', 'content-type': 'application/json', 'Accept': 'application/json'}
	c = BaseStream(msg = HTTPMessage('GET', headers = header_arg, body = None, encoding = 'utf8', content_type = 'application/json'), with_headers = True, with_body = True)
	assert c.get_headers() == b'Accept: application/json\nContent-Type: application/json\nTarget: https://httpbin.org\n'

# Generated at 2022-06-21 14:26:18.847719
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    stream = RawStream()
    assert stream.iter_body() is not None

# Generated at 2022-06-21 14:26:22.017573
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
        str = b'A normal string\r\nAnother normal string'
        msg = HTTPMessage(headers=None, body=str)
        stream = BufferedPrettyStream(msg=msg)
        print(stream.iter_body())


# Generated at 2022-06-21 14:26:43.474869
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import HTTPResponse
    req = HTTPResponse()
    req.headers = "Header"
    req.content = "Body"
    BaseStream(req)

# Generated at 2022-06-21 14:26:51.123912
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Formatting
    from httpie.compat import str
    stream = PrettyStream(HTTPMessage(b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<html><h1>Test</h1></html>"))
    for line in stream.iter_body():
        assert line == b'<html><h1>Test</h1></html>'

# Generated at 2022-06-21 14:26:52.456395
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert isinstance(DataSuppressedError(), Exception)


# Generated at 2022-06-21 14:27:00.689714
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        print(e.message)


base_stream = BaseStream(HTTPMessage())
encoded_stream = EncodedStream(env=Environment(), msg=HTTPMessage())
pretty_stream = PrettyStream(
    conversion=Conversion(),
    formatting=Formatting(),
    env=Environment(),
    msg=HTTPMessage(),
)
buffered_pretty_stream = BufferedPrettyStream(
    conversion=Conversion(),
    formatting=Formatting(),
    env=Environment(),
    msg=HTTPMessage(),
)

for stream in [base_stream, encoded_stream, pretty_stream,
               buffered_pretty_stream]:
    msg = b'hello world!'

# Generated at 2022-06-21 14:27:09.546917
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    d = b'\xe6\x96\x87\xe6\x9c\xac'
    l = b'\r\n'
    msg = HTTPMessage(headers=b'HTTP/1.1 200 OK\r\n',
                      encoding='utf8',
                      body=d + l + d)

    result = b'\xe6\x96\x87\xe6\x9c\xac\r\n\xe6\x96\x87\xe6\x9c\xac'
    for r1, r2 in zip(result, EncodedStream(msg).iter_body()):
        assert r1 == r2

# Generated at 2022-06-21 14:27:11.037608
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    assert BaseStream.get_headers(None) is None

# Generated at 2022-06-21 14:27:16.088583
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    stream = BufferedPrettyStream(
        HTTPMessage(status_line='GET /test/test.jsp?a=1&b=2 HTTP/1.1',
                    headers=['Content-Type: text/html; charset=utf-8'],
                    body=b'ab\xffc\x00d')
    )
    assert next(stream.iter_body()) == b'<p>ab\xffc\x00d</p>'

# Generated at 2022-06-21 14:27:18.921657
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    from httpie.models import HTTPRequest
    from httpie.output.streams import RawStream

    msg = HTTPRequest('GET', 'http://example.com/').with_body('x')
    stream = RawStream(msg)
    list(stream)
    msg.body.seek(0)

# Generated at 2022-06-21 14:27:22.905403
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg_headers = """
HTTP/1.1 302 Found
Server: nginx
Date: Sun, 16 Jun 2019 18:11:10 GMT
Content-Type: text/html
Content-Length: 154
Connection: keep-alive
Location: http://www.httpbin.org/get""".strip()
    msg = HTTPMessage(msg_headers)
    stream = PrettyStream(msg=msg)

    assert(stream.get_headers() == msg_headers.encode('utf8'))


# Generated at 2022-06-21 14:27:33.795285
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(headers={'Content-Type': 'application/json'})
    assert msg.content_type == 'application/json'

    with_headers = True
    with_body = False
    on_body_chunk_downloaded = None
    stream = BaseStream(msg=msg, with_headers=with_headers, with_body=with_body, on_body_chunk_downloaded=on_body_chunk_downloaded)
    assert stream.msg is msg
    assert stream.with_headers is with_headers
    assert stream.with_body is with_body
    assert stream.on_body_chunk_downloaded is on_body_chunk_downloaded
    assert stream.get_headers() == b'Content-Type: application/json\r\n'
    #assert stream.iter_body()

# Generated at 2022-06-21 14:28:18.233454
# Unit test for constructor of class RawStream
def test_RawStream():
    content = '<html></html>'
    env = Environment()
    msg = HTTPMessage(
        HTTPStatus.OK,
        headers=Headers([
            (':status', str(HTTPStatus.OK)),
            ('content-type', 'text/html')
        ]),
        body=content.encode(encoding='utf8')
    )
    raw_stream = RawStream(msg=msg, env=env)
    assert raw_stream.get_headers() == msg.headers.encode(encoding='utf8')
    assert raw_stream.iter_body() == msg.iter_body()
    assert raw_stream.__iter__() == msg.__iter__()

# Generated at 2022-06-21 14:28:19.727592
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    test = DataSuppressedError()
    assert test.message == None


# Generated at 2022-06-21 14:28:27.439577
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    import json 
    msg = {
            'status_code': '200',
            'headers': {
                'Connection': 'keep-live',
                'Content-Length': '229',
                'Content-Type': 'application/json; charset=UTF-8',
                'Date': 'Tue, 20 Mar 2018 05:52:52 GMT',
                'ETag': 'W/"e5-HtbCNSKg9XFvf1H7a1tYiYIoDb8"',
                'Server': 'Apache',
                'X-Powered-By': 'Express'
            },
            'encoding': 'utf-8'
        }

    msg = HTTPMessage.from_dict(msg)
    chunk_size = 1
    conversion = Conversion()
    formatting = Formatting()

# Generated at 2022-06-21 14:28:32.204885
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    m = MockedMsg()
    m.content_type = 'text/html'
    m.chunk = b'Test'
    bps = BufferedPrettyStream(m)
    for i in bps.iter_body():
        assert i == b'Test'



# Generated at 2022-06-21 14:28:40.339377
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    '''
    Test whether the method process_body of class PrettyStream works
    '''
    output_encoding = 'utf8'
    chunk = '{"key1":"value1","key2":123}'
    chunk_bytes = b'{"key1":"value1","key2":123}'
    pretty_obj = PrettyStream(Conversion(None), Formatting(None, None), None)

    assert pretty_obj.process_body(chunk) == chunk_bytes
    assert pretty_obj.process_body(chunk_bytes) == chunk_bytes



# Generated at 2022-06-21 14:28:47.600769
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    msg = HTTPMessage('utf-8', headers={"Content-Type": "application/json"})
    from httpie.output.formatters.colors import Formatter
    formatting = Formatting(formatter=Formatter())
    assert isinstance(formatting, Formatting)
    assert isinstance(formatting.formatter, Formatter)
    conv = Conversion(None, None)
    assert isinstance(conv, Conversion)
    ps = PrettyStream(msg, conversion=conv, formatting=formatting)
    assert isinstance(ps, PrettyStream)
    assert isinstance(ps.conversion, Conversion)
    assert isinstance(ps.formatting, Formatting)
    assert isinstance(ps.mime, str)
    ps.mime = "application/json"
    assert ps.mime == "application/json"
    assert ps

# Generated at 2022-06-21 14:28:54.273179
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    Environment().configure()
    msg = HTTPMessage('http://example.com/', 'HTTP/1.1', '200 OK', headers=None, body=None)
    stream = EncodedStream(msg)
    stream.output_encoding
    stream.msg
    stream.msg.iter_lines(1)
    stream.iter_body()


if __name__ == '__main__':
    test_EncodedStream()

# Generated at 2022-06-21 14:29:00.169394
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # test with not a tty
    env = Environment()
    env.is_windows = True
    env.stdout_isatty = False
    stream = EncodedStream(env=env)
    assert stream.output_encoding == 'utf8'

    # test with a tty
    env = Environment()
    env.is_windows = True
    env.stdout_isatty = True
    stream = EncodedStream(env=env)
    assert stream.output_encoding == 'gbk'



# Generated at 2022-06-21 14:29:01.256287
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    BinarySuppressedError(BINARY_SUPPRESSED_NOTICE)

# Generated at 2022-06-21 14:29:06.306413
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None)
    result = stream.process_body(b'\x81\x88\r\n\r\n')
    assert(result == b'\xef\xbf\xbd\xef\xbf\xbd\r\n\r\n')


# Generated at 2022-06-21 14:30:27.948307
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    test_msg = HTTPMessage(encoding='utf8')
    test_msg.headers = b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    test_msg.body = b'<html><body><h1>Hello World</h1></body></html>'
    
    test_stream = BaseStream(test_msg)
    assert test_stream.get_headers() == test_msg.headers
    assert test_stream.iter_body() == test_msg.iter_body()



# Generated at 2022-06-21 14:30:39.923579
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.util import write_binary
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters import CSVFormatter
    from httpie.output.formatters import HTMLFormatter
    from httpie.output.formatters import ImageFormatter
    from httpie.output.formatters import URLEncodedFormatter

    class HTTPMessage():
        def __init__(self, headers = {}, encoding = None, content_type = None):
            self.headers = headers
            self.encoding = encoding
            self.content_type = content_type

        def iter_body(self, chunk_size):
            from httpie.output.streams import BinarySuppressedError
            yield b'\0\0\0'
            raise BinarySuppressedError()


    # Notice: In this test

# Generated at 2022-06-21 14:30:47.818632
# Unit test for method iter_body of class EncodedStream

# Generated at 2022-06-21 14:30:48.503369
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    assert True

# Generated at 2022-06-21 14:30:52.377782
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage()
    msg.headers = '''Content-type: application/json
Connection: Keep-alive
Content-length: 100'''
    stream = BaseStream(msg)
    headers = stream.get_headers()
    assert headers == msg.headers.encode('utf8')



# Generated at 2022-06-21 14:30:59.962987
# Unit test for constructor of class RawStream
def test_RawStream():
    File = msg = HTTPMessage('')
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None

    def rawstr(self):
        return self.__str__()

    HTTPMessage.__str__ = rawstr

    # constructor
    raw = RawStream(msg, with_headers, with_body, on_body_chunk_downloaded)

    assert raw.msg == File
    assert raw.with_headers == with_headers
    assert raw.with_body == with_body
    assert raw.on_body_chunk_downloaded == on_body_chunk_downloaded





# Generated at 2022-06-21 14:31:11.013359
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    """A test tool that simulates the object of class PrettyStream"""
    # class HTTPMessage is abstract class, using Response as an example
    from .models import Response
    headers = {
        'Content-Type': 'text/html'
    }
    body = '''
    <html>
    <head>
    <title>Hello World!</title>
    </head>
    <body>
    <h1>Hello World!</h1>
    </body>
    </html>
    '''
    msg = Response(
        http_version='HTTP/1.1',
        status_code=200,
        headers=headers,
        body=body
    )
    # initialization
    env = Environment()
    conversion = Conversion()
    formatting = Formatting()

# Generated at 2022-06-21 14:31:17.871051
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    raw_stream = RawStream(msg)
    assert raw_stream.msg == msg
    assert raw_stream.with_headers
    assert raw_stream.with_body
    assert raw_stream.on_body_chunk_downloaded == None
    assert raw_stream.chunk_size == 10240
    assert raw_stream.CHUNK_SIZE == 10240
    assert raw_stream.CHUNK_SIZE_BY_LINE == 1


# Generated at 2022-06-21 14:31:19.865824
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    # Test for constructor of class DataSuppressedError
    exception = DataSuppressedError()
    assert exception


# Generated at 2022-06-21 14:31:21.240607
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError().message == BINARY_SUPPRESSED_NOTICE