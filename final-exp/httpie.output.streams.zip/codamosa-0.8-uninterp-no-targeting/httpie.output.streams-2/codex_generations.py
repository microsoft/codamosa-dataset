

# Generated at 2022-06-21 14:24:12.055877
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json
    import pprint
    ip_addr = '127.0.0.1'
    port = '8080'
    # Set up a json dictionary 
    json_dict = {
        'hello': 'world',
        'count': 1,
        'features': [
            {
                'feature_1': 'value_1',
                'feature_2': 2.80,
                'feature_3': [1, 2, 3]
            }
        ]
    }
    # Convert the dictionary to a string
    json_str = json.dumps(json_dict)
    # Convert the string to a byte array
    json_bytes = json_str.encode('utf-8')
    # Dummy message

# Generated at 2022-06-21 14:24:19.075038
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    bs = BufferedPrettyStream(
        packet=None,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        env=None,
        conversion=None,
        formatting=None,
    )
    assert isinstance(bs, BufferedPrettyStream)
    assert isinstance(bs, PrettyStream)
    assert isinstance(bs, EncodedStream)
    assert isinstance(bs, BaseStream)
    assert isinstance(bs.__iter__(), Iterable)



# Generated at 2022-06-21 14:24:20.892720
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    header = PrettyStream.get_headers()
    if header is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-21 14:24:29.121319
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    # implementation of iter_body in class BaseStream
    # requires subclass implementation
    parsed = ParseResponse()
    response = requests.get("https://httpbin.org/get")
    response_dict = parsed.parse_response(response)
    response_dict["headers"]["Content-Length"] = 1001
    msg = HTTPMessage(**response_dict)
    stream = BaseStream(msg)
    with pytest.raises(NotImplementedError):
        stream.iter_body()


# Generated at 2022-06-21 14:24:36.092031
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.models import Response

    response_200 = Response(
        status_code=200,
        headers={'foo': 'bar'},
        body=b'body',
        version='HTTP/1.1',
        headers_str='foo: bar',
    )
    stream_200 = BufferedPrettyStream(
        msg=response_200,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
    )
    for i in stream_200.iter_body():
        print(i)
        break

# Generated at 2022-06-21 14:24:39.266101
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage(method='POST', url='https://httpie.org', headers={'a': '1'})
    assert isinstance(BufferedPrettyStream(msg), BufferedPrettyStream)


# Generated at 2022-06-21 14:24:42.657752
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    error = BinarySuppressedError()
    assert error.message == BINARY_SUPPRESSED_NOTICE
    error = DataSuppressedError()
    assert error.message is None

# Generated at 2022-06-21 14:24:51.148383
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    import json

    import httpie.output.formatters
    import httpie.output.streams

    env = httpie.Environment()
    msg = httpie.models.HTTPMessage(
        http_version='HTTP/1.1',
        headers=dict(
            Content_Type='application/json; charset=utf8',
            Content_Length=39,
        ),
        encoding='utf8',
        body=json.dumps(dict(a=1, b=2)).encode(),
    )

    ps = httpie.output.streams.PrettyStream(
        msg,
        conversion=httpie.output.converters.Conversion(),
        formatting=httpie.output.formatters.Formatter(env),
        env=env,
    )


# Generated at 2022-06-21 14:25:00.915133
# Unit test for constructor of class RawStream
def test_RawStream():
    # mock
    msg = HTTPMessage(
        {
            'Content-Type': 'application/json',
            'Content-Length': 0,
        },
        b''
    )
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    # test
    rawstream = RawStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    # assert
    assert rawstream.msg == msg
    assert rawstream.with_headers == True
    assert rawstream.with_body == True
    assert rawstream.on_body_chunk_downloaded == None


# Generated at 2022-06-21 14:25:09.949801
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Response
    msg = Response()
    msg.headers = """
    Date: Thu, 05 Mar 2020 16:06:20 GMT
    Server: Apache
    Content-Length: 4588
    Content-Type: text/html; charset=UTF-8
    """
    stream = BaseStream(msg)
    result = stream.get_headers()
    assert result.decode('utf8') == """
    Date: Thu, 05 Mar 2020 16:06:20 GMT
    Server: Apache
    Content-Length: 4588
    Content-Type: text/html; charset=UTF-8
    """



# Generated at 2022-06-21 14:25:30.229706
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    print("Testing BufferedPrettyStream.iter_body()")
    print("Test 1: body is str")
    body = "Hello World"
    class Response:
        def __init__(self):
            self.content_type = "text/plain"
            self.encoding = "utf-8"

    class ReqResp:
        def __init__(self):
            self.headers = ""
            self.response = Response()

        def iter_body(self, chunk_size):
            def generator():
                for c in body:
                    yield c.encode("utf-8")
            return generator()

    msg = ReqResp()
    chunk_size = 1
    conversion = Conversion()
    formatting = Formatting()

    class Index:
        i = 0


# Generated at 2022-06-21 14:25:39.936517
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage()
    msg.headers = """Content-Type: text/xml
User-Agent: httpie
"""
    msg.encoding = 'utf8'
    s = EncodedStream(msg, with_headers=False, with_body=True)
    # we test binary data here
    msg.body = b"\xff\0"
    assert s.iter_body() == BinarySuppressedError()
    msg.body = "hello"
    assert s.iter_body() == "hello"
    # we test non-binary data here
    msg.encoding = 'utf8'
    msg.body = "\xff\0"
    assert s.iter_body() == "\ufffd\ufffd"


# Generated at 2022-06-21 14:25:49.107807
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():    
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import Response
    from httpie.output.formatters.colors import get_lexer
    from httpie.plugins import builtin
    d = 'Random.org — True Random Number Service'
    f = 'Content-Type: text/html; charset=utf-8'
    g = 'Content-Length: 6691'
    h = 'Connection: close'
    i = 'Date: Fri, 20 Sep 2019 20:09:51 GMT'
    j = 'Server: Apache/2.4.7 (Ubuntu)'
    k = 'X-Powered-By: PHP/5.5.9-1ubuntu4.22'

# Generated at 2022-06-21 14:25:53.282974
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    test_str = b'hello world'
    test_msg = HTTPMessage(test_str)
    test_stream = RawStream(test_msg)
    assert next(test_stream.iter_body()) == test_str


# Generated at 2022-06-21 14:25:54.362938
# Unit test for constructor of class RawStream
def test_RawStream():
    pass



# Generated at 2022-06-21 14:26:06.485345
# Unit test for constructor of class BaseStream

# Generated at 2022-06-21 14:26:09.627527
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    l = [("HTTP/1.1 200 OK\nContent-Type: text/plain; charset=utf-8\n\n",
          "b'abc\n'"),
         ("HTTP/1.1 200 OK\nContent-Type: text/plain; charset=utf-8\n\n",
          "b'a\0c\n'"),
         ]
    for msg, result in l:
        msg = HTTPMessage(Message(StringIO(msg)))
        stream = PrettyStream(msg=msg, conversion=Conversion(), formatting=Formatting())
        assert next(iter(stream.iter_body())) == eval(result)


# Generated at 2022-06-21 14:26:20.006048
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    m = HTTPMessage(headers=[])
    m.headers.add('connection' , 'keep-alive')
    m.headers.add('accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    m.headers.add('user-agent' , 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36')
    m.headers.add('accept-encoding' , 'gzip, deflate')
    m.headers.add('accept-language' , 'en-US,en;q=0.8')

# Generated at 2022-06-21 14:26:25.539256
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.output.streams import EncodedStream

    args = parser.parse_args(args=[])
    env = Environment(vars(args), 'GET', 'http://localhost:8080/', '/', {},
                      None, None, ExitStatus.OK, '',
                      'httpie', '0.9.9-Development')
    str1 = EncodedStream(msg='test_a', env=env)
    str2 = EncodedStream(msg='test_b', env=env)
    assert str1.output_encoding == str2.output_encoding



# Generated at 2022-06-21 14:26:35.311445
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg=HTTPMessage()
    assert isinstance(msg,HTTPMessage)
    assert isinstance(EncodedStream(msg=msg),EncodedStream)
    assert isinstance(EncodedStream(msg=msg,with_headers=True),EncodedStream)
    assert isinstance(EncodedStream(msg=msg,with_body=True),EncodedStream)
    assert isinstance(EncodedStream(msg=msg,on_body_chunk_downloaded =None),EncodedStream)
    assert isinstance(EncodedStream(msg=msg),BaseStream)
    
    
    

# Generated at 2022-06-21 14:26:50.989410
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage()
    msg.headers = "Some-header: some-value\r\nContent-Type: text/plain\r\n"
    stream = BaseStream(msg)

    assert stream.get_headers() == b"Some-header: some-value\r\nContent-Type: text/plain\r\n"


# Generated at 2022-06-21 14:26:59.765841
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Create an empty http message
    msg = HTTPMessage()
    msg.headers = 'HTTP/1.1 200 OK\r\n'+ 'Date: Sat, 01 Oct 2016 14:12:16 GMT\r\n'+'Connection: keep-alive\r\n'+'Content-Type: text/html; charset=UTF-8\r\n'+'Content-Length: 16\r\n'+'Server: openresty/1.9.15.1\r\n'
    msg.body = 'hello world\r\n'
    # create an enviroment 
    env = Environment()
    # create an conversion
    conversion = Conversion()
    # create an formatting
    formatting = Formatting()
    # create an PrettyStream

# Generated at 2022-06-21 14:27:00.394190
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    pass

# Generated at 2022-06-21 14:27:01.700214
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    stream = PrettyStream(Conversion(), Formatting())
    stream.__init__()

# Generated at 2022-06-21 14:27:11.960074
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    conversion = Conversion()
    formatting = Formatting()
    msg = HTTPMessage(encoding="ascii")
    msg.headers = """HTTP/1.1 200 OK
Date: Wed, 05 Dec 2018 13:28:29 GMT
Server: Apache
Last-Modified: Wed, 05 Dec 2018 13:28:29 GMT
ETag: "9b-5abda1bb1e21f"
Accept-Ranges: bytes
Content-Length: 26

"""
    msg.body = "a\r\nb\r\nc\r\nd\r\ne\r\nf\r\ng\r\nh\r\ni\r\nj\r\n"
    stream = PrettyStream(msg, with_headers=True, conversion=conversion,
                          formatting=formatting)

# Generated at 2022-06-21 14:27:16.937858
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
	
	conversion = Conversion()
	formatting = Formatting()
	msg = HTTPMessage()
	with_headers = True
	with_body = True
	on_body_chunk_downloaded = None
	test_PrettyStream = PrettyStream(conversion, formatting, msg, with_headers, with_body, on_body_chunk_downloaded)
	assert (isinstance(test_PrettyStream, PrettyStream))
	

# Generated at 2022-06-21 14:27:19.724750
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(url='http://httpbin.org/')
    stream = BaseStream(msg)
    assert stream.get_headers() == b'GET / HTTP/1.1\r\n\r\n'



# Generated at 2022-06-21 14:27:21.211227
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    assert 0

# Generated at 2022-06-21 14:27:31.872035
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from io import StringIO
    headers = {'Content-Type': 'text/html;charset=utf-8', 'Content-Length': '12'}
    headers = Headers(headers)
    env = Environment()
    format = Formatting()
    stream = PrettyStream(headers, True, True, on_body_chunk_downloaded=None,
                          env=env, conversion='auto', formatting=format)
    assert stream.get_headers().rstrip() == b'Content-Length: 12\nContent-Type: text/html;charset=utf-8'



# Generated at 2022-06-21 14:27:33.105628
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:27:56.856442
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    with pytest.raises(DataSuppressedError) as exc_info:
        raise BinarySuppressedError(('\n'
             + '+-----------------------------------------+\n'
             + '| NOTE: binary data not shown in terminal |\n'
             + '+-----------------------------------------+'))
    assert str(exc_info.value) == ('\n'
             + '+-----------------------------------------+\n'
             + '| NOTE: binary data not shown in terminal |\n'
             + '+-----------------------------------------+')

# Generated at 2022-06-21 14:28:08.015253
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage('This is message', 'utf8')
    # with_body = True and with_headers = True
    e = EncodedStream(msg)
    assert e.msg == msg
    assert e.with_headers is True
    assert e.with_body is True
    assert e.on_body_chunk_downloaded is None

    # with_body = False and with_headers = False
    e = EncodedStream(msg, with_headers=False, with_body=False)
    assert e.msg == msg
    assert e.with_headers is False
    assert e.with_body is False
    assert e.on_body_chunk_downloaded is None

    # with_body = True and with_headers = False

# Generated at 2022-06-21 14:28:08.944185
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    pass


# Generated at 2022-06-21 14:28:11.033683
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    import sys
    sys.stdout.write(BINARY_SUPPRESSED_NOTICE)

# Generated at 2022-06-21 14:28:21.468776
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    # msg = HTTPMessage(
    # headers=b'TESTHEADER',
    #     body=b'TESTBODY'
    # )
    # msg = HTTPMessage(
    #     headers=b'TESTHEADER',
    #     body=b'TESTBODY',
    #     mime='TESTMIME'
    # )
    msg = HTTPMessage(
        headers=b'TESTHEADER',
        body=b'TESTBODY',
        mime='TESTMIME',
        encoding='TESTENCODING'
    )
    pstream = PrettyStream(
        msg=msg,
        conversion=b'TESTCONVERSION',
        formatting=b'TESTFORMATTING'
    )
    pp.pprint(pstream.__dict__)

# Generated at 2022-06-21 14:28:28.389445
# Unit test for method get_headers of class BaseStream

# Generated at 2022-06-21 14:28:37.354188
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class Msg:
        def __init__(self, body, encoding='utf-8'):
            self.body = body
            self.encoding = encoding
        def iter_body(self, chunk_size):
            return self.body.splitlines(keepends=True)
    msg = Msg(body='{\n  "a": 1\n}')
    stream = BufferedPrettyStream(msg=msg)
    result = [line for line in stream.iter_body()]
    assert result == [b'{\n', b'  "a": 1\n', b'}']

# Generated at 2022-06-21 14:28:39.604886
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    try:
        assert False, "unimplemented"
    except NotImplementedError:
        pass


# Generated at 2022-06-21 14:28:47.221622
# Unit test for constructor of class BaseStream
def test_BaseStream():
    class HTTPMessageStub(HTTPMessage):
        def __init__(self):
            self.headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
            self.encoding = 'ascii'
            self.content_type = 'text/html'

        def iter_body(self, chunk_size=1024*100):
            ret = b''
            for i in range(10):
                ret += ('this is line ' + str(i)).encode('ascii')
                if len(ret) > 100:
                    yield ret
                    ret = b''
            yield ret

        def iter_lines(self, chunk_size):
            ret = b''

# Generated at 2022-06-21 14:28:49.063052
# Unit test for constructor of class BaseStream
def test_BaseStream():
    baseStream = BaseStream(HTTPMessage())
    assert baseStream.msg is not None


# Generated at 2022-06-21 14:29:31.820417
# Unit test for constructor of class BaseStream
def test_BaseStream():
    class msg:
        headers = "headers"

    assert BaseStream(msg).with_headers
    assert BaseStream(msg).with_body
    assert BaseStream(msg, False, False).with_headers is False
    assert BaseStream(msg, False, False).with_body is False

# Generated at 2022-06-21 14:29:36.980273
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    res = HTTPResponse(b'HTTP/1.1 200 OK\r\nx: y\r\n\r\n\r\n')
    stream_res = EncodedStream(res)
    assert stream_res.CHUNK_SIZE == 1
    assert stream_res.with_body == True
    assert stream_res.with_headers == True

# Generated at 2022-06-21 14:29:39.162147
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    error=DataSuppressedError()
    assert type(error) == DataSuppressedError
    assert error.message == None


# Generated at 2022-06-21 14:29:43.797121
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class Response(HTTPMessage):
        def __init__(self, body, content_type):
            self.headers = b'Content-Type: ' + content_type.encode('utf8')
            self.content = body.encode('utf8')
            self.content_type = content_type
            self.size = len(self.content)
            self.encoding = 'utf8'

        def iter_body(self, chunk_size):
            yield self.content

    response = Response(body='{"a": 1, "b": 2}', content_type="application/json")
    stream = PrettyStream(
        msg=response,
        conversion=Conversion(),
        formatting=Formatting(indent=4, colors=False, sections=[]))
    body = list(stream.iter_body())[0]
   

# Generated at 2022-06-21 14:29:46.936559
# Unit test for constructor of class BaseStream
def test_BaseStream():
    stream = BaseStream(msg)
    assert stream.msg == msg
    assert stream.with_headers
    assert stream.with_body
    assert stream.on_body_chunk_downloaded == None


# Generated at 2022-06-21 14:29:50.633203
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage()
    msg.headers = "HEADERS"
    msg.body = b"BODY"
    stream = RawStream(msg)
    print(stream.msg.headers)
    print(stream.msg.body)
    print(stream.with_headers)
    print(stream.with_body)
    print(stream.on_body_chunk_downloaded)


# Generated at 2022-06-21 14:29:56.563179
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from .response import Response
    r = Response()
    r.encoding = 'utf8'
    r.headers['Content-Type'] = 'text/plain'
    r.content = 'hi\nyou'
    stream = PrettyStream(msg=r, with_headers=False, with_body=True, conversion=None, formatting=None)
    for s in stream.__iter__():
        print(s)


# Generated at 2022-06-21 14:30:07.555538
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    def check_input_output(input, output):
        msg = HTTPMessage(
            method='POST',
            raw_headers=(
                'Content-Type: application/json\n' +
                'Content-Length: ' + str(len(input)) + '\n' +
                'Server: Apache/2\n'
            ).encode('utf8'),
            encoding='utf8',
            body=input,
        )
        env = Environment()
        conversion = Conversion()
        formatting = Formatting()
        stream = PrettyStream(
            msg=msg,
            with_headers=True,
            with_body=True,
            env=env,
            conversion=conversion,
            formatting=formatting,
        )
        result = b''.join(stream)

# Generated at 2022-06-21 14:30:15.417048
# Unit test for constructor of class BaseStream
def test_BaseStream():
    import os
    env = Environment()
    env.stdout = os.fdopen(os.dup(1), "w", encoding="utf-8")
    env.stdout_isatty = True
    # my_msg = HTTPMessage()
    # my_msg.headers = 'hello world'
    # msg = my_msg.encode('utf8')
    # with_headers = True
    # with_body = True
    # on_body_chunk_downloaded = None
    # my_BaseStream = BaseStream(msg, with_headers, with_body, on_body_chunk_downloaded)
    # print(my_BaseStream)
    pass

# Generated at 2022-06-21 14:30:17.282657
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage()
    stream = PrettyStream(msg)
    return stream, msg

# Generated at 2022-06-21 14:31:35.534407
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    err = BinarySuppressedError()
    assert err.message

# Generated at 2022-06-21 14:31:46.490981
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPRequest
    from httpie.input import ParseError
    from httpie.compat import urlopen
    from httpie.core import main
    from httpie.output.formatters.base import StreamUnsupported

    # The httpbin.org/get service is used for testing.
    # This service doesn't support requests with a body.
    try:
        request = HTTPRequest('GET', 'http://httpbin.org/get')
    except ParseError:
        raise RuntimeError('Invalid URL.')

    # request.headers.remove('Accept-Encoding')

    # When a request has no body, it is sent immediately.
    # Otherwise, a response object is returned.

# Generated at 2022-06-21 14:31:49.060039
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError.message == (
        b'\n'
        b'+-----------------------------------------+\n'
        b'| NOTE: binary data not shown in terminal |\n'
        b'+-----------------------------------------+'
    )


# Generated at 2022-06-21 14:31:54.407275
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    req = requests.get('https://api.github.com/user', auth=('user', 'pass'))
    format = 'form'
    msg = HTTPMessage(req)
    stream = PrettyStream(None, None, msg, True, True)
    body = msg.body
    processed_body = stream.process_body(body)
    assert processed_body.decode('utf-8') == json.dumps(json.loads(body), sort_keys=True, indent=4) + '\n'

# Generated at 2022-06-21 14:32:01.440513
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    msg.body = b'{"message": "success"}'
    msg.headers = "Content-Type: text/json"

    stream = BufferedPrettyStream(conversion=Conversion(),
                                  formatting=Formatting(),
                                  msg=msg,
                                  with_headers=True,
                                  with_body=True)
    assert b'{\n    "message": "success"\n}' in b''.join(stream)

# Generated at 2022-06-21 14:32:05.661894
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={'Content-Type': 'application/json'}, body='{"Name":"Jack"}', encoding='utf-8')
    pretty = PrettyStream(msg, True, True, None, None, None)
    print(pretty.get_headers())

# Generated at 2022-06-21 14:32:09.482670
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nabc')
    stream = BufferedPrettyStream(msg, with_body=True)
    assert list(stream.iter_body()) == [b'abc']


# Generated at 2022-06-21 14:32:16.740081
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import HTTPResponse
    from httpie import ExitStatus
    from httpie.status import ExitStatus
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONFormatter
    from httpie.output.formatters.colors import PygmentsJSONFormatter
    from httpie.output.streams import BufferedPrettyStream
    from pathlib import Path
    from utils import http, HTTP_OK
    from utils import TestEnvironment
    from utils import start_server, stop_server

    data = b'{ "a": 1 }'
    formatter = JSONFormatter()
    pygments_formatter = PygmentsJSONFormatter()
    headers = {'Content-Type': 'application/json'}

# Generated at 2022-06-21 14:32:28.490884
# Unit test for method iter_body of class PrettyStream

# Generated at 2022-06-21 14:32:29.623424
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    with pytest.raises(BinarySuppressedError):
        raise BinarySuppressedError()