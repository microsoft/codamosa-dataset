

# Generated at 2022-06-21 14:24:02.163292
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    bytearray()

# Generated at 2022-06-21 14:24:03.611342
# Unit test for constructor of class BaseStream
def test_BaseStream():
    assert 1 == 1

# Generated at 2022-06-21 14:24:06.754729
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie.context import Environment
    from httpie.models import HTTPMessage
    from httpie.output.streams import BaseStream
    from httpie.output.processing import Conversion, Formatting




# Generated at 2022-06-21 14:24:08.296139
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    assert isinstance(EncodedStream(Environment()), EncodedStream)


# Generated at 2022-06-21 14:24:09.983508
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    DataSuppressedError(BINARY_SUPPRESSED_NOTICE)


# Generated at 2022-06-21 14:24:20.051346
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.core import DEFAULT_UA
    from httpie.models import ContentType, Headers

    class Msg(HTTPMessage):
        def __init__(self):
            self.encoding = 'ascii'
            self.headers = Headers(ContentType('text/plain'))
            self.body = b'test'

        def iter_body(self, *args, **kwargs):
            yield self.body

    env = Environment(
        stdout=io.StringIO(),
        stdout_isatty=False,
        stdout_encoding='utf8',
        stdin_isatty=False,
        stdin=io.StringIO(),
        stdin_encoding='utf8',
    )


# Generated at 2022-06-21 14:24:26.119727
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(
        headers={'HTTP_CODE': 200, 'Server': 'test'},
        content='body',
        encoding='utf8'
    )
    stream = RawStream(msg=msg)
    assert isinstance(stream, BaseStream)

    with pytest.raises(TypeError):
        # TypeError: with_body should be bool
        # TypeError: with_headers should be bool
        stream = RawStream(msg=msg, with_body=1, with_headers=1)

    stream = RawStream(msg=msg, with_body=False, with_headers=False)

    with pytest.raises(Exception):
        # Exception: with_headers or with_body should be True
        stream = RawStream(msg=msg, with_body=False, with_headers=False)



# Generated at 2022-06-21 14:24:28.748386
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    rawStream = RawStream(msg=HTTPMessage())
    print(rawStream.iter_body())


# Generated at 2022-06-21 14:24:33.237483
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Headers
    h = Headers([('Content-Length', '0')])
    s = BaseStream(HTTPMessage(headers=h), with_headers=True, with_body=False)
    assert s.get_headers() == b'Content-Length: 0\r\n'

# Generated at 2022-06-21 14:24:37.414675
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    class TestHTTPMessage(HTTPMessage):
        headers = ''
        content_type = ''
        encoding = 'utf8'

        def iter_body(self, chunk_size):
            yield b'abc'
            yield b'def'
            yield b'ghi'

    assert list(BufferedPrettyStream(TestHTTPMessage(),
                conversion=None, formatting=None).iter_body()) == [b'abcdefghi']

# Generated at 2022-06-21 14:24:45.531552
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    BaseStream(msg=None, with_headers=None, with_body=None)



# Generated at 2022-06-21 14:24:52.266731
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import io
    import os
    import sys
    import doctest
    import json
    import httpie.output
    import httpie.output.streams
    import httpie.output.formatters.colors
    import httpie.output.formatters.utf8

    os.environ['HTTPIE_STDOUT_ISATTY'] = 'true'
    os.environ['HTTPIE_COLOR_STYLE'] = 'monokai'
    os.environ['HTTPIE_COLOR_STYLE'] = 'true'

    doctest.testmod(httpie.output.streams)
    doctest.testmod(httpie.output.formatters.colors)
    doctest.testmod(httpie.output.formatters.utf8)
#     doctest.testmod(httpie.output)


# Generated at 2022-06-21 14:25:00.788147
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Response
    from httpie.cli.argtypes import KeyValueArgType
    env = Environment()
    headers = KeyValueArgType(env).convert(['Accept:application/json'])
    response = Response(
        200,
        'OK',
        http_version='1.1',
        headers=headers,
        raw=b'{"message":"Hello world"}',
        content_type='application/json')
    stream = BaseStream(response)
    assert stream.get_headers() == b'Accept: application/json\r\n'


# Generated at 2022-06-21 14:25:11.558657
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    msg = HTTPMessage()
    # msg.content_type = 'text/html'
    msg.headers = 'HTTP/1.1 200 OK\n' + \
                  'Connection:close\n' + \
                  'Date:Tue, 24 Jan 2017 14:33:11 GMT\n'+ \
                  'Server:Apache\n' + \
                  'Vary:Accept-Encoding\n' + \
                  'Content-Encoding:gzip\n' + \
                  'Content-Type:text/html\n' + \
                  'Transfer-Encoding:chunked\n' +\
                  'X-Powered-By:PHP/5.3.29\n'
    # msg.body = '<html><head></head><body>this is body</body></html>'

# Generated at 2022-06-21 14:25:18.429261
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    body = b'Test Body'
    msg = HTTPMessage(200, 'OK', headers={'test': 'test header'}, content_type='', body=body)
    stream = PrettyStream(msg, conversion=None, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    assert stream.get_headers() == b'test: test header'

# Generated at 2022-06-21 14:25:19.233740
# Unit test for constructor of class BaseStream
def test_BaseStream():
    request = models.Request()
    stream = BaseStream(request)

# Generated at 2022-06-21 14:25:20.192873
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    stream = BufferedPrettyStream.CHUNK_SIZE / 2
    for i in range(stream):
        print(i)

# Generated at 2022-06-21 14:25:24.558607
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    # Test both inherited classes: BinarySuppressedError and DataSuppressedError
    try:
        raise BinarySuppressedError
    except DataSuppressedError as e:
        print(e)
    
    try:
        raise DataSuppressedError
    except DataSuppressedError as e:
        print(e)
        

# Generated at 2022-06-21 14:25:29.860723
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    env = Environment() 
    msg = HTTPMessage(headers=None, content='Hello World!')
    stream = BufferedPrettyStream(msg, env=env, conversion=Conversion(), formatting=Formatting(), with_headers=True, with_body=True, on_body_chunk_downloaded=None)

# Generated at 2022-06-21 14:25:30.846731
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-21 14:25:50.966821
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(headers = {'Set-Cookie': 'x=1; HttpOnly'})
    headers = BaseStream(msg=msg, with_headers=True, with_body=False).get_headers()
    assert headers == b'Set-Cookie: x=1; HttpOnly\r\n\r\n'

    header_text = bytes(headers).decode(encoding=msg.encoding)
    assert header_text == 'Set-Cookie: x=1; HttpOnly\r\n\r\n'


# Generated at 2022-06-21 14:25:54.981148
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError
    except BinarySuppressedError as e:
        assert e.message == b'\n+-----------------------------------------+\
\n| NOTE: binary data not shown in terminal |\n+-----------------------------------------+'


# Generated at 2022-06-21 14:26:03.240697
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    from httpie.models import HTTPResponse
    s = '''
    HTTP/1.1 200 OK
    Content-Type: text/plain; charset=utf-8
    Content-Length: 2
    
    OK'''
    response = HTTPResponse(s.encode('utf8'))
    env = Environment()
    stream = EncodedStream(response, with_headers=True, with_body=True, env=env)
    assert next(stream.iter_body()) == 'OK\n'



# Generated at 2022-06-21 14:26:08.628274
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    """
    :return: None
    """
    msg = HTTPMessage()
    message_stream = PrettyStream(msg,with_headers=False,with_body=False,on_body_chunk_downloaded=None,
                                  conversion=Conversion(False, False), formatting=Formatting(False,False))
    assert isinstance(message_stream, PrettyStream)



# Generated at 2022-06-21 14:26:10.125256
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    pass


# Generated at 2022-06-21 14:26:14.426239
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie.models import Request
    msg = Request(method='GET', url='/', headers={'Accept': 'application/json'}, body='{"name": "John Smith"}')
    Stream = RawStream(msg=msg, with_headers=True, with_body=True)
    print(list(Stream.iter_body()))



# Generated at 2022-06-21 14:26:15.385125
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    m = BufferedPrettyStream()
    print (m)

# Generated at 2022-06-21 14:26:19.082118
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    body = '{"key":"value"}'
    mime = 'application/json'
    message = HTTPMessage(200, [], body, mime)
    stream = PrettyStream(message, None, None)
    print(stream.process_body(body))


# Generated at 2022-06-21 14:26:21.569461
# Unit test for constructor of class EncodedStream
def test_EncodedStream():

    # test whether class EncodedStream can create instance when env is not given
    enc_stream = EncodedStream()
    assert isinstance(enc_stream, EncodedStream)



# Generated at 2022-06-21 14:26:28.047078
# Unit test for constructor of class RawStream
def test_RawStream():
    from httpie.models import HTTPResponse
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    import base64
    rsp = HTTPResponse('HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\n1234')
    assert RawStream(rsp).get_headers() == b'HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\n'
    assert RawStream(rsp).iter_body() == [b'1234']

# Generated at 2022-06-21 14:26:53.778336
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPMessage
    from httpie.output.processing import Formatting, Conversion
    from httpie.context import Environment

    conversion = Conversion(json_indent=None)
    formatting = Formatting(
        color=False,
        pretty=False,
        conf_dir=None
    )

    s = BufferedPrettyStream(
        msg=HTTPMessage(encoding='utf8', body='foo'.encode()),
        conversion=conversion,
        formatting=formatting,
        with_headers=True,
        with_body=True,
        env=Environment(),
        on_body_chunk_downloaded=None
    )

    print(s.mime)
    print(s.output_encoding)

# Generated at 2022-06-21 14:26:59.665273
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    input_http_msg = HTTPMessage(content_type='application/json; charset=UTF-8', headers='headers',
    encoding='GBK', body='body')

    bps = BufferedPrettyStream(msg=input_http_msg)
    assert bps.msg.content_type == 'application/json; charset=UTF-8'
    assert bps.msg.headers == 'headers'
    assert bps.msg.encoding == 'GBK'
    assert bps.msg.body == 'body'
    assert bps.output_encoding == 'utf8'

# Generated at 2022-06-21 14:27:02.114160
# Unit test for constructor of class BaseStream
def test_BaseStream():
    base = BaseStream(msg='hello world!', with_headers=True, with_body=True)
    assert base.msg == 'hello world!'


# Generated at 2022-06-21 14:27:03.046365
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    pass

# Generated at 2022-06-21 14:27:11.852354
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer

    response = Response(
        status_code=200,
        headers={"content-type": "application/json"},
        body='{"name":"examples","version":3}',
    )
    stream = PrettyStream(
        processing=None,
        msg=response,
        with_headers=False,
        with_body=True,
        on_body_chunk_downloaded=None,
        env=None,
    )

    stream.CHUNK_SIZE = 10
    for line in stream.iter_body():
        print(line)

# Generated at 2022-06-21 14:27:18.079873
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    from httpie.models import Response
    import sys
    import os
    if sys.version_info.major < 3:
        raw_stream = RawStream()
        response = Response(b"Hello\nWorld\n", 200, "OK")
        i = 0
        for line in response.iter_body(1):
            i += 1
            if i == 3:
                break
        assert i == 3, "can't output a response line by line"
    else:
        # Fails with Python 3: TypeError: 'str' does not support the buffer interface
        pass

# Generated at 2022-06-21 14:27:25.185676
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    msg = HTTPMessage([], body = b'hi', encoding = 'utf8')
    stream = EncodedStream(msg = msg)
    assert list(stream.iter_body()) == [b'hi']
    msg = HTTPMessage([], body = b'\xa5', encoding = 'cp932')
    stream = EncodedStream(msg = msg)
    assert list(stream.iter_body()) == [b'?']
    stream = EncodedStream(msg = msg, env = Environment(stdout_isatty = False))
    assert list(stream.iter_body()) == [b'\xa5']
    msg = HTTPMessage([], body = b'\x00\xa5', encoding = 'utf8')
    stream = EncodedStream(msg = msg)

# Generated at 2022-06-21 14:27:35.121848
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    import json
    import re
    headers = [{'a': 'b'}]
    msg = HTTPMessage()
    msg.headers = headers
    # headers = [{'a': 'b'}]
    formatting = Formatting()
    # formatting.PRETTIFY_REGEX = re.compile('')
    conversion = Conversion()
    stream = PrettyStream(msg=msg, formatting=formatting, conversion=conversion)
    result = stream.get_headers()
    assert (result == '[\n  {\n    "a": "b"\n  }\n]') or result == '[\n  {\n    "a": "b"\n  }\n]\r\n', \
            result + '****' + 'get_headers'

# Generated at 2022-06-21 14:27:41.079146
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    class TestBaseStream(BaseStream):
        def __init__(self, *args, **kwargs):
            pass

        def iter_body(self):
            return

    msg = HTTPMessage()
    stream = TestBaseStream(msg, with_headers=True, with_body=False)
    assert stream.get_headers() == msg.headers.encode('utf8')

    with pytest.raises(NotImplementedError):
        TestBaseStream(msg, with_headers=False, with_body=True)



# Generated at 2022-06-21 14:27:48.535503
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    import io
    from httpie.output.streams import EncodedStream
    # Get a HTTPMessage from HTTPResponse
    msg = HTTPResponse(
        url="http://www.google.com/",
        status_code=200,
        http_version="HTTP/1.1",
        headers={"Content-Type": "text/html; charset=utf-8"},
        body=io.BytesIO(b"abc"),
    )
    # Create an EncodedStream using this HTTPMessage
    estream = EncodedStream(msg=msg, env=Environment())
    messages = []
    for sub in estream.__iter__():
        messages.append(sub)

# Generated at 2022-06-21 14:28:38.003704
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage(
        headers = {"http": "https://httpie.org/"}
    )
    c = BaseStream(msg)
    assert c.msg == msg
    assert c.with_headers
    assert c.with_body
    assert c.on_body_chunk_downloaded is None
    assert c.get_headers() == b"http: https://httpie.org/\r\n"
    assert c.iter_body() == None
    assert c.__iter__() == None  



# Generated at 2022-06-21 14:28:46.352223
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from requests.models import Response
    from .processing import get_prettifier, get_converter
    from .models import ParseJSON

    env = Environment()
    msg = Response()
    msg.encoding = 'utf-8'
    msg.headers = '''Content-Type: application/json; charset=utf-8

'''
    msg.iter_body = msg.iter_content = msg.raw.stream
    msg.raw.stream = iter(('''{'he': 'llo'}''',))

    x = BufferedPrettyStream(msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None, env=env, conversion=get_converter(env), formatting=get_prettifier(env, ParseJSON(env)))
    assert x.iter_body()

# Generated at 2022-06-21 14:28:49.407527
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    with pytest.raises(BinarySuppressedError) as exc_info:
        raise BinarySuppressedError()
    assert exc_info.value.message == BINARY_SUPPRESSED_NOTICE.decode()

# Generated at 2022-06-21 14:28:59.475065
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # Testing on the first 100 lines of a json file.
    mime = 'application/json'
    file = 'test/test_pretty_JSON_data_array.json'
    encoding = 'utf-8'
    conversion = Conversion('json')
    formatting = Formatting({})
    with open(file, 'rb') as f:
        body = f.read()
    msg = HTTPMessage(mime=mime, body=body, encoding=encoding)
    # Expected output
    stream = PrettyStream(msg=msg, conversion=conversion, formatting=formatting)
    expected_output = []
    for line in stream.iter_body():
        expected_output.append(line.decode('utf-8'))

    # Tested output

# Generated at 2022-06-21 14:29:06.720311
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    msg=HTTPMessage(
        headers=raw_headers, body=raw_body,
        content_type='image/jpeg'
    )
    temp_stream = RawStream(
        msg=msg, with_headers=True, with_body=True,
        on_body_chunk_downloaded=test_on_body_chunk_downloaded
    )
    for item in temp_stream:
        print(item)
    print(temp_stream.headers)
    print(temp_stream.headers)


# Generated at 2022-06-21 14:29:14.157379
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    def on_body_chunk_downloaded(chunk):
        if type(chunk) is bytes:
            received_body += chunk.decode('utf-8')
        else:
            received_body += chunk
    received_body = ''
    # Create a HTTPMessage object with a given body
    msg = HTTPMessage.from_string('HTTP/1.0 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nyay!')
    # Create an object of BufferedPrettyStream with the HTTPMessage object
    stream = BufferedPrettyStream(
        msg = msg,
        with_headers = True,
        with_body = True,
        on_body_chunk_downloaded = on_body_chunk_downloaded
    )
    # Iter

# Generated at 2022-06-21 14:29:18.073348
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from pytest import raises
    from httpie.core import main
    from httpie.output.streams import PrettyStream

    msg = main({'format': 'pretty'}).stdout.msg

    with raises(AttributeError):
        PrettyStream(msg, with_body=False).get_headers()

# Generated at 2022-06-21 14:29:23.638477
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    m = {
        'headers': '',
        'body': b'1234567890',
        'content_type': 'HTTPIE'
    }
    msg = HTTPMessage(m)
    rs = RawStream(msg)
    gen = rs.iter_body()
    assert(next(gen)==b'123')
    assert(next(gen)==b'456')
    assert(next(gen)==b'789')
    assert(next(gen)==b'0')



# Generated at 2022-06-21 14:29:24.837241
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert DataSuppressedError()



# Generated at 2022-06-21 14:29:28.240663
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    s = 'hello'
    m = HTTPMessage(str(s).encode('utf8'))
    # func: BaseStream.iter_body
    f = iter_body()
    assert f(m) == s.encode('utf8')

# Generated at 2022-06-21 14:30:55.996565
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:31:06.692380
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    import json
    from httpie.models import Request

    # Request
    stream = PrettyStream(msg=Request(
        method='POST',
        url='http://alphabet.com',
        headers={'Content-Type': 'application/x-www-form-urlencoded'},
        data='foo=bar'
    ))
    assert stream.process_body(b'foo=bar') == b'foo=bar'

    # Response
    stream = PrettyStream(msg=Request(
        method='GET',
        url='http://alphabet.com',
        headers={'Content-Type': 'application/json'},
        data='{"foo": "bar"}'
    ))

# Generated at 2022-06-21 14:31:10.745773
# Unit test for constructor of class RawStream
def test_RawStream():
    request = HTTPMessage(headers={'CONTENT-TYPE': 'application/json'},body = b'{"Name": "Foo"}+\r\n{"Name": "Bar"}')
    assert len(list(RawStream(request).iter_body())) == 2

# Generated at 2022-06-21 14:31:14.519936
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    from httpie.models import HTTPResponse
    stream = PrettyStream(
        HTTPResponse(
            'text/html',
            '<html><head><title>hello</title></head><body>world</body></html>'
        )
    )
    assert stream.process_body('<html>') == b'<html>'

# Generated at 2022-06-21 14:31:17.575085
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    # data = 'Hello World'
    # msg = HTTPMessage(data)
    # stream = EncodedStream(msg)
    # print(stream)
    # data_bytes = data.encode('utf8')
    # assert list(stream.iter_body()) == [data_bytes, end_of_line_bytes]
    pass

# Generated at 2022-06-21 14:31:26.829886
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    import pandas as pd
    import numpy as np
    import pyarrow as pa
    df = pd.DataFrame({'One': [1, 2, 3, 4],
                        'Two': [5, 6, 7, 8],
                        'Three': np.random.randn(4),
                        'Four': pd.Categorical(['test', 'train', 'test', 'train']),
                        'Five': [1.0, 2.0, 0.0, 4.0]})
    table = pa.Table.from_pandas(df)
    pb = table.to_pandas().to_msgpack()
    pb = pb.replace(b'\x94', b'\x93')
    print(pb)
    ds = EncodedStream(msg=pb)
    body = d

# Generated at 2022-06-21 14:31:31.122086
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    result = []
    iter_body = BufferedPrettyStream.iter_body
    with pytest.raises(BinarySuppressedError):
        for x in iter_body(None, b"\0"):
            result.append(x)

    for x in iter_body(None, b"abc\0"):
        result.append(x)

    assert result == [b"abc"]



# Generated at 2022-06-21 14:31:35.675870
# Unit test for method process_body of class PrettyStream

# Generated at 2022-06-21 14:31:46.632202
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    header = 'HTTP/1.0 200 OK\r\n' + \
             'Date: Sat, 29 Feb 2020 15:45:26 GMT\r\n'+\
             'Server: Python/3.6 aiohttp/3.6.2\r\n' +\
             'Content-Type: text/html; charset=utf-8\r\n' +\
             'Content-Length: 9\r\n' +\
             'Access-Control-Allow-Origin: *\r\n' +\
             'Access-Control-Allow-Credentials: true\r\n' +\
             '\r\n'

    body = 'test body'

# Generated at 2022-06-21 14:31:54.581220
# Unit test for constructor of class BaseStream
def test_BaseStream():

    msg = HTTPMessage()
    msg.headers.set('Some-Header', 'Some-Value')
    msg.headers.set('Another-Header', 'Another-Value')
    msg.headers.set('List-Header', ['List-Value-1', 'List-Value-2'])
    msg.set_body('Some body')

    strm = BaseStream(msg)
    assert strm
    assert strm.msg == msg
    assert strm.with_headers
    assert strm.with_body

    strm = BaseStream(msg, True, False)
    assert strm
    assert strm.with_headers
    assert not strm.with_body

    # strm = BaseStream(msg, headers=False, body=True)
    # assert strm
    # assert not strm.headers
    # assert str