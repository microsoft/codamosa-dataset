

# Generated at 2022-06-21 14:24:14.571822
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import HTTPMessage
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from urllib.parse import urlparse

    msg = HTTPMessage()

# Generated at 2022-06-21 14:24:17.182252
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    p = PrettyStream(HTTPMessage(b'hi\nthere\n'))
    for chunk in p.iter_body():
        print(chunk)



# Generated at 2022-06-21 14:24:20.378409
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    exc = BinarySuppressedError()
    exc.message = BINARY_SUPPRESSED_NOTICE
    assert exc.message is None
    assert exc.message == BINARY_SUPPRESSED_NOTICE
    assert exc.args == ()

# Generated at 2022-06-21 14:24:32.334342
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    def mock_iter_body():
        yield b'\0'
        yield b'a'
        yield b'\0'
    def mock_converter_convert(body):
        return 'text/mock', body.decode()
    def mock_formatting_format_body(content, mime):
        return 'mock'
    msg = HTTPMessage()
    msg.content_type = 'mock/type'
    msg.encoding = 'utf8'
    class MockConversion:
        get_converter = lambda self, mime: None
    class MockFormatting:
        format_body = mock_formatting_format_body
    conversion = MockConversion()
    formatting = MockFormatting()
    class MockConverter:
        convert = mock_converter_convert

# Generated at 2022-06-21 14:24:32.959373
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    error = DataSuppressedError()
    assert str(error) == ''


# Generated at 2022-06-21 14:24:37.230096
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    bytestring_message = b"GET / HTTP/1.1\nHost: google.com\n\n"
    msg = HTTPMessage.parse(bytestring_message)
    stream = BaseStream(msg)
    assert stream.get_headers() == b'Host: google.com\n'


test_BaseStream_get_headers()

# Generated at 2022-06-21 14:24:46.930881
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    ps = PrettyStream(HTTPMessage(content_type="image/png"), with_headers=False, with_body=True, on_body_chunk_downloaded=None,
    env=Environment(), conversion=Conversion(),
    formatting=Formatting())
    print(ps.process_body(b'hello world'))
    print(ps.process_body(b'11101000\x00'))
    print(ps.process_body(bytes('hello world', 'utf-8')))
    print(ps.process_body(str('hello world')))
    
if __name__ == '__main__':
    test_PrettyStream_process_body()

# Generated at 2022-06-21 14:24:50.594081
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    try:
        raise DataSuppressedError('Data suppressed!')
        assert False
    except DataSuppressedError as e:
        assert e.message==None
        assert str(e)=='DataSuppressedError: Data suppressed!'


# Generated at 2022-06-21 14:24:53.505239
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    error = BinarySuppressedError()
    # assert isinstance(error, DataSuppressedError)
    assert error.message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-21 14:25:05.130902
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    # a single line
    msg = HTTPMessage(data=b'{"id": "p001", "name": "Joe", "age": 12}',
                      headers={'content-type': 'application/json'})
    stream = PrettyStream(msg=msg, conversion=None, formatting=None)
    print(list(stream.iter_body())[0])

    # multiple lines
    msg = HTTPMessage(data=b'{"id": "p001", "name": "Joe", "age": 12}\n'
                           b'{"id": "p002", "name": "Jack", "age": 17}\n',
                      headers={'content-type': 'application/json'})
    stream = PrettyStream(msg=msg, conversion=None, formatting=None)
    print(list(stream.iter_body())[-1])

# Generated at 2022-06-21 14:25:24.699378
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    test = BaseStream(msg, with_headers=True, with_body=True)
    assert test.msg == msg
    assert test.with_headers == True
    assert test.with_body == True
    

# Generated at 2022-06-21 14:25:36.223790
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class FakeMsg:
        def __init__(self, content_type, body):
            self.content_type = content_type
            self.body = body
            self.encoding = 'utf8'

        def iter_body(self, chunk_size):
            for chunk in self.body.split(','):
                yield chunk.encode(self.encoding)
            yield b'\n'

    class FakeConversion:
        def get_converter(self, mime):
            return None

    class FakeFormatting:
        def format_headers(self, _):
            return ''

        def format_body(self, content, mime):
            return f'{content} {mime}'

    class FakeEnvironment:
        stdout_isatty = False
        stdout_encoding = None


# Generated at 2022-06-21 14:25:42.420184
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    input = 'Test the constructor of class EncodedStream'
    for char in input:
        print(char)
        print(ord(char))
    c = EncodedStream()
    c.msg.encoding = 'utf-8'
    c.output_encoding = 'utf-8'
    c.CHUNK_SIZE = 1
    iter_body = c.iter_body()
    print(list(iter_body))


if __name__ == '__main__':
    test_EncodedStream()

# Generated at 2022-06-21 14:25:52.035481
# Unit test for constructor of class RawStream
def test_RawStream():
    # Dummy response
    msg = HTTPMessage(
        method='GET',
        url='http://www.example.com/',
        headers={'key': 'value'},
        body='payload'
    )

    # Initialize RawStream and iterate to get byte stream
    stream = RawStream(msg=msg, with_headers=False)
    yield stream.get_headers()
    # Check that header is empty when with_headers=False
    assert stream.get_headers() == b''

    # Check that all the lines are bytes
    for line in stream.iter_body():
        assert isinstance(line, bytes)



# Generated at 2022-06-21 14:25:57.247197
# Unit test for constructor of class BaseStream
def test_BaseStream():
    stream = BaseStream()
    assert issubclass(stream.__class__, BaseStream)
    assert callable(getattr(stream, 'get_headers'))
    assert callable(getattr(stream, 'iter_body'))
    assert callable(getattr(stream, '__iter__'))


# Generated at 2022-06-21 14:26:07.729571
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    #part1:str
    bodyStr = '123'
    msg = HTTPMessage()
    msg.encoding = 'utf8'
    stream = EncodedStream(msg)
    body = ''
    for part in stream.iter_body():
        body += part.decode(stream.output_encoding, 'replace')
    assert body == bodyStr
    print(body)
    #part2:byte
    bodyByte = b'123'
    msg.encoding = 'utf8'
    stream = EncodedStream(msg)
    body = ''
    for part in stream.iter_body():
        body += part.decode(stream.output_encoding, 'replace')
    assert body == bodyStr
    print(body)


# Generated at 2022-06-21 14:26:14.214241
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={"user": "abc"}, body=b"hello world")
    raw_stream = RawStream(msg=msg, with_headers=True, with_body=True)
    body_size = 0
    for chunk in raw_stream.iter_body():
        body_size += len(chunk)
    assert body_size == len(msg.body)

# Generated at 2022-06-21 14:26:23.595525
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    env = Environment()
    conversion = Conversion(env)
    formatting = Formatting(env)
    msg = HTTPMessage('/', 'GET', b'headers', 'body', 'utf8')
    ps = PrettyStream(msg, True, True, env, conversion, formatting)
    assert ps.env == env
    assert ps.msg == msg
    assert ps.conversion == conversion
    assert ps.formatting == formatting
    assert ps.mime == 'headers'
    assert ps.with_headers == True
    assert ps.with_body == True
    assert ps.on_body_chunk_downloaded == None
    assert ps.output_encoding == 'utf8'
    assert ps.CHUNK_SIZE == 1
    assert ps.get_headers() == b'headers'

# Generated at 2022-06-21 14:26:29.007062
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(headers={"Content-Type": "application/json", "Content-Length": "1"}, body=b"{}")
    ps = PrettyStream(msg=msg, with_headers=True, with_body=True)
    assert ps.get_headers() == b'Content-Length: 1\r\nContent-Type: application/json\r\n\r\n'


# Generated at 2022-06-21 14:26:33.854776
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    body = "Hello"
    msg = HTTPMessage(headers = {}, body = body)
    stream = RawStream(msg)
    print("RawStream iter_body:")
    for chunk in stream.iter_body():
        print(chunk)


# Generated at 2022-06-21 14:27:02.749327
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    s = PrettyStream(
        msg=None,
        on_body_chunk_downloaded=None,
        conversion=None,
        formatting=Formatting(
            style='none',
            colors='never',
            stream_all_headers=False,
            max_headers_len=100,
            max_body_len=100,
        ),
        with_headers=True,
        with_body=True,
    )

    # subclasses have methods with default values
    assert s.process_body(b'GIF87a') == b'GIF87a'



# Generated at 2022-06-21 14:27:12.565615
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import os
    import json

    json_file = os.path.join('.', 'tests', 'fixtures', 'response_json.json')
    with open(json_file) as f:
        x = f.read()
        y = json.loads(x)
        body = json.dumps(y, sort_keys=True, indent=4)

    headers = """HTTP/1.1 200 OK
Content-Length: 452
Content-Type: application/json; charset=utf-8

"""
    class HTTPMessageDummy:
        def __init__(self):
            self.headers = headers
            self.body = body
            self.content_type = 'application/json'

    class PrettyStreamDummy(PrettyStream):
        def __init__(self):
            self.msg = HTTPMessage

# Generated at 2022-06-21 14:27:20.744679
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    class Dummy_msg:
        def __init__(self):
            self.headers = ""
            self.content_type = ""
            self.encoding = ""

        def iter_lines(self, chunk_size):
            return [b"ab", b"\n", b"\n"], [b"\n", b"\n"]

    class Dummy_conversion:
        def get_converter(self, mime):
            return ""

    class Dummy_formatting:
        def format_body(self, content, mime):
            return ""

    class Dummy_msg1:
        def __init__(self):
            self.headers = ""
            self.content_type = ""
            self.encoding = ""


# Generated at 2022-06-21 14:27:31.913745
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    from httpie.models import HTTPMessage
    from httpie.output.streams import BufferedPrettyStream
    from httpie import Response

    msg = HTTPMessage()
    msg.headers = "HTTP/1.1 200 OK\r\nDate: Fri, 04 May 2021 23:14:59 GMT\r\nContent-Type: application/json\r\nContent-Length: 39\r\n\r\n"

    encoding = 'utf8'
    msg.encoding = encoding
    msg.body = b'{"color":"red","value":"#f00"}'

    env = Environment()


# Generated at 2022-06-21 14:27:36.366004
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    from httpie.models import Message

    msg = Message(
        http_version='HTTP/1.1',
        method='GET',
        url='/url',
        headers=['Key: Value', 'Key1: Value1']
    )
    msg_stream = BaseStream(msg)
    assert msg_stream.get_headers() == b'Key: Value\r\nKey1: Value1\r\n'

# Generated at 2022-06-21 14:27:44.098408
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    obj = HTTPMessage(
        method='GET',
        url='http://localhost:5000/get?a=1&b=2',
        headers={'Accept': '*/*'},
        content={'x': 1, 'y': 2, 'z': 3}
    )
    obj2 = BufferedPrettyStream( msg=obj, with_headers=True, with_body=True, on_body_chunk_downloaded=None )
    assert obj2.msg == obj
    assert obj2.with_headers == True
    assert obj2.with_body == True
    assert obj2.on_body_chunk_downloaded == None
    assert obj2.mime == 'application/json'
    assert type(obj2.conversion) == Conversion
    assert type(obj2.formatting) == Formatting
    #assert

# Generated at 2022-06-21 14:27:50.719107
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    class Msg:
        def __init__(self):
            self.headers = {'content-type': 'text/plain;charset=utf-8'}

        def iter_lines(self, chunk_size):
            yield b'line1\n', b''
            yield b'line2\n', b''

    def format_headers(self, headers):
        return 'line1\nline2'

    def format_body(self, content, mime):
        return 'line3\nline4'

    class Conversion:
        def get_converter(self):
            pass

    class Formatting:
        format_headers = format_headers
        format_body = format_body


# Generated at 2022-06-21 14:27:52.061283
# Unit test for constructor of class RawStream
def test_RawStream():
    stream = RawStream()
    assert stream.CHUNK_SIZE == 10240


# Generated at 2022-06-21 14:27:53.183291
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    dse = DataSuppressedError()
    assert type(dse.message) == type(None)


# Generated at 2022-06-21 14:27:54.789779
# Unit test for constructor of class RawStream
def test_RawStream():
    input = {}
    a = RawStream(**input)
    print(a)
    #assert len(a) == 1


# Generated at 2022-06-21 14:28:26.251306
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    # Make a fake http message for testing
    msg = HTTPMessage()
    msg.headers = ['User-Agent: useragent\r\n', 'Accept-Encoding: encoding\r\n\r\n']
    # Fake function of formatting.format_headers
    def format_headers(headers):
        assert type(headers) == list
        return ''.join(headers)

    # Set up PrettyStream and get headers
    pretty = PrettyStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)
    pretty.formatting.format_headers = format_headers
    headers = pretty.get_headers()
    assert headers == b'User-Agent: useragent\r\nAccept-Encoding: encoding\r\n\r\n'



# Generated at 2022-06-21 14:28:36.233013
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(b"POST /api/v1/login HTTP/1.1\r\nHost: 127.0.0.1:5000\r\nUser-Agent: HTTPie/1.0.3\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nConnection: keep-alive\r\nContent-Length: 34\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\nusername=admin&password=admin\r\n")
    stream = BaseStream(msg)
    for v in stream:
        print(v)


# Generated at 2022-06-21 14:28:37.557043
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    BinarySuppressedError()


# Generated at 2022-06-21 14:28:46.093056
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from .formatter import StreamFormatter
    from .url import URL
    from httpie.context import Environment
    from httpie import ExitStatus
    from httpie.output.__main__ import GZip
    from httpie.input import ParseError
    from httpie.output import create_formatter

# Generated at 2022-06-21 14:28:51.005197
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    message = b'{"key1":"value1","key2":"value2"}'
    env=Environment()
    raw_stream = RawStream(env=env, msg=message, with_headers=False, with_body=True)

    assert list(raw_stream.iter_body()) == [message]



# Generated at 2022-06-21 14:29:00.132977
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPMessage
    from httpie.output.streams import EncodedStream
    from httpie.context import Environment

    env = Environment()

# Generated at 2022-06-21 14:29:05.035757
# Unit test for constructor of class BaseStream
def test_BaseStream():
    msg = HTTPMessage()
    stream = BaseStream(msg, True, True, None)
    assert stream.msg == msg
    assert stream.with_headers == True
    assert stream.with_body == True
    assert stream.on_body_chunk_downloaded == None

# Method test for method get_headers

# Generated at 2022-06-21 14:29:08.469969
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msgs = ['1\r\n2']
    msg = HTTPMessage(None, headers=None, body=msgs)
    wStream = RawStream(msg=msg)
    for chunk in wStream.iter_body():
        print(chunk)


# Generated at 2022-06-21 14:29:10.944619
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    with pytest.raises(BinarySuppressedError):
        raise(BinarySuppressedError())
    assert BinarySuppressedError().message == BINARY_SUPPRESSED_NOTICE


# Generated at 2022-06-21 14:29:21.093437
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    print('test_PrettyStream_iter_body')
    # responses data is a dict
    # key is a single http message (without body)
    # value is a list of body chunks

# Generated at 2022-06-21 14:30:08.924026
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
	assert BinarySuppressedError().message == BINARY_SUPPRESSED_NOTICE

# Method test for get_headers of class BaseStream

# Generated at 2022-06-21 14:30:11.415890
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    assert DataSuppressedError(BINARY_SUPPRESSED_NOTICE).message == BINARY_SUPPRESSED_NOTICE # noqa: E501


# Generated at 2022-06-21 14:30:15.645842
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(b"raw data")
    msg.headers = b"header"
    rawstream = RawStream(msg)
    assert rawstream.with_headers
    assert rawstream.with_body
    assert rawstream.msg == msg
    assert rawstream.chunk_size == 102400
    assert rawstream.on_body_chunk_downloaded == None

# Generated at 2022-06-21 14:30:16.470533
# Unit test for constructor of class RawStream
def test_RawStream():
    assert True


# Generated at 2022-06-21 14:30:23.192487
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    class TestablePrettyStream(PrettyStream):
        def process_body(self, chunk: Union[str, bytes]) -> bytes:
            return self.super_process_body(chunk)

        def super_process_body(self, chunk: Union[str, bytes]) -> bytes:
            return super().process_body(chunk)

    # when
    stream = TestablePrettyStream(
        msg=HTTPMessage(
            content='hellö',
            headers={
                'content-type': 'text/html; charset=utf8'
            }
        ),
        conversion=Conversion([]),
        formatting=Formatting(None, None)
    )

    # then
    assert stream.super_process_body('hellö') == b'hell\xe5'

# Generated at 2022-06-21 14:30:34.171170
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    
    stream = PrettyStream(msg=None, conversion=None, formatting=None, with_headers=None, with_body=None, on_body_chunk_downloaded=None)
    
    # Test for the case of chunk being str type
    chunk = '{"args": {"arg1": "v1", "arg2 ": "v2"}, "date": "2019-04-14T22:16:17+00:00", "headers": {"Accept-Encoding": "gzip", "Connection": "close", "Cookie": "foo=bar; bar=baz", "Host": "httpbin.org", "User-Agent": "HTTPlib/3.0"}, "origin": "217.130.138.52", "url ": "https://httpbin.org/get?arg1=v1&arg2+="}'


# Generated at 2022-06-21 14:30:45.449691
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import requests
    import threading
    import time
    import asyncio
    from httpie.cli.argtypes import KeyValueArg
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.output.formatters.headers import HeadersFormatter
    
    def send_request(a):
        # send a HTTP requests and
        # save http repsonse in class variable 
        # msg of class RawStream
        # store the information about
        # host,path and port in class variable
        # endpoint of class RawStream
        a.msg = a.send()
        a.endpoint = a.response.raw._fp.fp.raw._sock.getpeername()


# Generated at 2022-06-21 14:30:46.332565
# Unit test for constructor of class BaseStream
def test_BaseStream():
    assert BaseStream


# Generated at 2022-06-21 14:30:50.719753
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    env = Environment()
    msg = HTTPMessage(response='200 Ok',encoding='utf8',content_type='application/json')
    msg.headers = 'Content-Type: application/json'
    msg.body = b'{"name":"jason","age":"24"}'
    stream = BufferedPrettyStream(msg,True,True,None,env,Conversion(),Formatting())
    for chunk in stream:
        print(chunk)


# Generated at 2022-06-21 14:30:52.779356
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    s = PrettyStream(Conversion(), Formatting())
    assert len(s) == 2

# Generated at 2022-06-21 14:32:32.252846
# Unit test for constructor of class RawStream
def test_RawStream():
	# default values
	stream = RawStream(msg=None, chunk_size=1024*100, 
		with_headers=True, with_body=True, on_body_chunk_downloaded=None)
	# specified values
	stream1 = RawStream(msg=None, chunk_size=30, 
		with_headers=False, with_body=False, on_body_chunk_downloaded=None)
	# only msg
	stream2 = RawStream(msg=None)


# Generated at 2022-06-21 14:32:34.569221
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    try:
        raise BinarySuppressedError()
    except BinarySuppressedError as e:
        assert e.message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:32:37.712728
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    with pytest.raises(BinarySuppressedError) as info:
        raise BinarySuppressedError()
    assert info.value.args == (b'\n'
    b'+-----------------------------------------+\n'
    b'| NOTE: binary data not shown in terminal |\n'
    b'+-----------------------------------------+',)


# Generated at 2022-06-21 14:32:39.672919
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    msg = HTTPMessage(headers={"name":"value"})
    stream = BaseStream(msg=msg,with_headers=True)
    assert stream.get_headers() == b'name: value\r\n'


# Generated at 2022-06-21 14:32:48.728716
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage()
    msg.headers['content-type'] = 'application/json'
    msg.headers['content-length'] = '100'
    msg.body = """
        {
            "a": 1,
            "b": 2,
            "c": 3,
            "d": 4,
            "e": 5,
            "f": 6,
            "g": 7
        }
        """
    rs = RawStream(msg, with_headers=1, with_body=1)
    for content in rs.iter_body:
        print("Content ---", content)
        # num += 1




# Generated at 2022-06-21 14:32:50.075545
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    error = BinarySuppressedError()
    assert error.message is BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:32:59.696678
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    # Default chunk size is 1024 * 100
    # Tuple of message, headers and body
    message1 = b"\r\n".join([
        b"HTTP/1.1 200 OK",
        b"Date: Mon, 27 Jul 2009 12:28:53 GMT",
        b"Server: Apache/2.2.14 (Win32)",
        b"Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT",
        b"Content-Length: 88",
        b"Content-Type: text/html",
        b"Connection: Closed",
        b"",
        b"<html>",
        b"<body>",
        b"<h1>Hello, World!</h1>",
        b"</body>",
        b"</html>"
    ])

# Generated at 2022-06-21 14:33:02.623942
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    # Test for __init__
    msg = HTTPMessage()
    str = BaseStream(msg,with_headers=True,with_body=True)
    # Test for __iter__
    iter(str)

# Generated at 2022-06-21 14:33:03.971928
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    error = DataSuppressedError()
    assert error.message == None

# Generated at 2022-06-21 14:33:14.614497
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    print("\nTEST EncodedStream_iter_body")
    data = b'{"name":"john","surname":"doe"}'
    msg = HTTPMessage(data=data, content_type=b'application/json')
    data1 = b'{"name":"john","surname":"doe"}\r\n'
    data2 = b''
    data3 = b'\r\n'
    for i, chunk in enumerate(data1):
        assert chunk == next(EncodedStream(msg=msg).iter_body())
    for i, chunk in enumerate(data2):
        assert chunk == next(EncodedStream(msg=msg).iter_body())
    for i, chunk in enumerate(data3):
        assert chunk == next(EncodedStream(msg=msg).iter_body())

#