

# Generated at 2022-06-21 14:24:09.835527
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    res = HTTPMessage(
        str.encode("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n"),
        str.encode("[\n{")
    )

    pretty = BufferedPrettyStream(res, False, True, None)
    pretty.iter_body()



# Generated at 2022-06-21 14:24:14.501854
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie import ExitStatus
    from httpie.core import main
    from tests.constants import TESTS_ROOT
    from utils import http, HTTP_OK
    import pytest

    url = httpbin.url + '/get'

    # Defaults to application/json.

# Generated at 2022-06-21 14:24:23.216763
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    import pytest
    from httpie.input import ParseRequest
    from httpie.compat import str
    from httpie import ExitStatus
    from utils import TestEnvironment, http, HTTP_OK
    r = http('--print=HB', 'GET', HTTP_OK)
    assert HTTP_OK in r
    assert 'GET / HTTP/1.1' not in r
    assert 'Accept: application/json' not in r
    assert 'HTTP/1.1 200 OK' in r
    c = TestEnvironment()
    r = http('--print=HB', 'GET', HTTP_OK, env=c)
    assert HTTP_OK in r
    assert r.count('GET / HTTP/1.1'), 2
    assert 'Accept: application/json' not in r
    assert 'HTTP/1.1 200 OK' in r

# Generated at 2022-06-21 14:24:28.014627
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(None, None)
    stream.mime = 'text/plain'
    stream.output_encoding = 'utf8'
    chunk = stream.process_body('bob\nthe\nbuilder')
    assert chunk == b'bob\nthe\nbuilder'

# Generated at 2022-06-21 14:24:31.163714
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    hd = 'Content-Type: application/json\r\n'
    assert BaseStream(HTTPMessage(hd)).get_headers() == hd.encode('utf8')




# Generated at 2022-06-21 14:24:35.264449
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    """Returns True if encoding is utf-8 and False otherwise"""
    msg = HTTPMessage(headers='')
    buffered_pretty_stream = BufferedPrettyStream(msg)
    if buffered_pretty_stream._output_encoding == 'utf-8':
        return True
    else:
        return False

# Generated at 2022-06-21 14:24:38.700581
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    on_body_chunk_downloaded = None
    assert EncodedStream(msg, with_headers, with_body, on_body_chunk_downloaded)


# Generated at 2022-06-21 14:24:49.532428
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
    #import os
    from httpie.models import HTTPResponse
    import pytest
    from httpie.output.streams import EncodedStream

    #os.environ['HTTPIE_TERM_TITLE_COLOR'] = 'none'
    with pytest.raises(BinarySuppressedError) as error_info:
        msg = HTTPResponse(
            'HTTP/1.1 200 OK\r\n'
            'Content-Type: text/plain; charset=utf-8\r\n'
            'Content-Length: 4\r\n\r\n'
            '\0\r\n',
            'http://example.com'
        )
        streamer = EncodedStream(msg, with_body=True)
        list(streamer.iter_body())
    assert error_info

# Generated at 2022-06-21 14:24:55.318641
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    env = Environment()
    msg = HTTPMessage(env,
                      headers={"Content-Type": "application/json"},
                      body="{\"id\":1}")
    stream = BaseStream(msg, env)
    assert stream.get_headers().decode("utf-8") == "Content-Type: application/json\r\n"



# Generated at 2022-06-21 14:24:59.996740
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    a = EncodedStream()
    assert a.get_headers() == b''
    assert a.msg == Message
    assert a.output_encoding == ''
    assert a.with_body == True
    assert a.with_headers == True
    assert a.iter_body() == []

# Generated at 2022-06-21 14:25:28.876956
# Unit test for constructor of class BaseStream
def test_BaseStream():
    req = HTTPMessage()
    req.headers='''
    key1: value1
    key2: value2
    '''
    req.body='''
    hello
    how are
    you
    '''
    req.content_type='application/json'
    req.encoding='utf8'

    bs = BaseStream(req, with_headers=False, with_body=False)

    assert bs.msg==req
    assert bs.with_headers==False
    assert bs.with_body==False


# Generated at 2022-06-21 14:25:30.532149
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import HTTPResponse
    from httpie.input.json import JSON

# Generated at 2022-06-21 14:25:40.909468
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    msg = HTTPMessage(
        headers=Headers({
            'Content-Type': 'text/plain',
            'Content-Length': '1234'
        }),
        body=b'hello'
    )
    stream = RawStream(msg)
    assert list(stream) == [b'hello']
    msg = HTTPMessage(
        headers=Headers({
            'Content-Type': 'text/plain',
            'Content-Length': '1234'
        }),
        body=io.BytesIO(b'hello')
    )
    stream = RawStream(msg)
    assert list(stream) == [b'hello']

# Generated at 2022-06-21 14:25:42.966475
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    res = BufferedPrettyStream(msg=None, with_headers=None, with_body=None, on_body_chunk_downloaded=None)


# Generated at 2022-06-21 14:25:52.461451
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    print(PrettyStream(
        HTTPMessage(
            status_line=b'HTTP/1.1 200 OK',
            headers=('Content-Type: application/json\r\n'
                     'Content-Length: 1234\r\n'
                     'Date: Tue, 11 May 2015 10:18:14 GMT'),
            body=b'[{"key":"value"}]'
        ),
        conversion=Conversion(),
        formatting=Formatting()
    ))


DESCRIPTIONS = dict(
    raw=RawStream,
    encoded=EncodedStream,
    pretty=PrettyStream,
    pretty_buffered=BufferedPrettyStream,
)



# Generated at 2022-06-21 14:26:04.661348
# Unit test for method process_body of class PrettyStream
def test_PrettyStream_process_body():
    stream = PrettyStream(HTTPMessage(headers={}, body=b'{"toto": 1}'), Conversion(), Formatting())
    assert stream.process_body(b'{"toto": 1}') == b'{\n    "toto": 1\n}\n'
    stream = PrettyStream(HTTPMessage(headers={}, body=b'{"toto": 1}'), Conversion(), Formatting(indent=2))
    assert stream.process_body(b'{"toto": 1}') == b'{\n  "toto": 1\n}\n'
    stream = PrettyStream(HTTPMessage(headers={}, body=b'{"toto": 1}'), Conversion(), Formatting(indent=2, sort_keys=True))

# Generated at 2022-06-21 14:26:12.919349
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    e = Environment()
    c = Conversion()
    f = Formatting()
    m = HTTPMessage()
    h = BaseStream()
    h.__init__(m, True, True)
    h.__init__(m, True, True, True)
    h.__init__(m, False, True)
    h.__init__(m, False, True, False)
    h.__init__(m, True, False)
    h.__init__(m, True, False, True)
    h.__init__(m, False, False)
    h.__init__(m, False, False, False)
    s = RawStream()
    s.__init__(m, True, True)
    s.__init__(m, True, True, True)

# Generated at 2022-06-21 14:26:14.307418
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    BaseStream.__iter__()
    # TODO
    assert True


# Generated at 2022-06-21 14:26:23.680170
# Unit test for method iter_body of class BufferedPrettyStream

# Generated at 2022-06-21 14:26:25.921717
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    # Setup
    msg = HTTPMessage()
    stream = BaseStream(msg, with_headers=False, with_body=True)
    stream.__iter__()



# Generated at 2022-06-21 14:26:39.379431
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 14:26:42.204629
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    stream = BufferedPrettyStream
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    assert stream(msg=HTTPMessage, args=args, with_headers=True, with_body=True)

# Generated at 2022-06-21 14:26:44.326000
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    stream = EncodedStream(msg)
    assert stream.msg == msg


# Generated at 2022-06-21 14:26:49.356590
# Unit test for method iter_body of class EncodedStream
def test_EncodedStream_iter_body():
	env = Environment()
	encodedstream = EncodedStream(msg="HTTP/1.1 200 OK\r\n\r\nhello",env=env)
	print(next(iter(encodedstream)))
	print("---")
	print(next(iter(encodedstream)))


# Generated at 2022-06-21 14:26:53.681194
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    # create a msg
    msg = HTTPMessage(**{
        'encoding': 'utf8',
        'headers': 'test_headers',
        'iter_body': '[test_iter_body]'
    })

    # create an encoding
    encoding = 'test_encoding'

    # create an encoding content
    encoding_content = 'test_encoding_content'

    # create an result
    result = EncodedStream(msg=msg, with_headers=True, with_body=True, on_body_chunk_downloaded=None)

    assert result.msg == msg
    assert result.with_headers == True
    assert result.with_body == True
    assert result.on_body_chunk_downloaded == None
    assert result.output_encoding == encoding
    assert result.iter_body() == encoding_

# Generated at 2022-06-21 14:26:54.597246
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    pass


# Generated at 2022-06-21 14:27:01.618709
# Unit test for constructor of class RawStream
def test_RawStream():
    msg = HTTPMessage(method='GET',
                      path='http://www.google.com',
                      headers={'Content-Type': 'application/json; charset=utf-8'},
                      body='Test Body',
                      encoding='utf-8')
    success = 0
    try:
        # Test if the instance of class RawStream is created
        test = RawStream(msg=msg)
        assert(test.msg == msg)
        assert(test.with_headers == True and test.with_body == True)
        assert(test.on_body_chunk_downloaded == None)
        success += 1
    except:
        success -= 1
    finally:
        assert(success > 0), 'Constructor of class RawStream is successful.'


# Generated at 2022-06-21 14:27:11.557427
# Unit test for constructor of class RawStream
def test_RawStream():
    # 初始化RawStream对象，并获取headers和body
    headers = b"Headers: This is a header"
    body = b"Body: this is a body."
    message = HTTPMessage(headers=headers, body=body)
    raw_stream = RawStream(msg=message)
    headers = raw_stream.get_headers()
    body = b''.join(raw_stream.iter_body())
    # 测试获取headers正确性
    print("headers = ")
    print(headers)
    # 测试获取body正确性
    print("body = ")
    print(body)

# Generated at 2022-06-21 14:27:19.984473
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Test 1
    msg1 = HTTPMessage(
        url='http://example.com/',
        method='GET',
        headers={'Host': 'example.com'},
        body=b'foo'
    )
    stream1 = BufferedPrettyStream(
        msg=msg1,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
        conversion=Conversion(),
        formatting=Formatting({'body': 'mime'})
    )
    print('\n'.join(stream1))

    # Test 2
    msg_data = HTTPMessage(
        url='http://example.com/',
        method='GET',
        headers={'Host': 'example.com'},
        body=b'foo'
    )
    stream

# Generated at 2022-06-21 14:27:22.258423
# Unit test for constructor of class DataSuppressedError
def test_DataSuppressedError():
    err = DataSuppressedError()
    print('err.message:', err.message)



# Generated at 2022-06-21 14:27:50.317061
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    msg = HTTPMessage()
    with_headers = True
    with_body = True
    obj = EncodedStream(msg, with_headers, with_body)
    assert obj.msg == msg
    assert obj.with_headers == with_headers
    assert obj.with_body == with_body
    assert obj.CHUNK_SIZE == 1

# Generated at 2022-06-21 14:27:51.938587
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    # Given
    msg = HTTPMessage()
    # When
    testing = BufferedPrettyStream(msg)
    # Then
    assert testing is not None

# Generated at 2022-06-21 14:27:58.740949
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    from httpie.models import Headers
    from httpie.output.formatters import JSONDataFormat
    class pstream(PrettyStream):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.environment = Environment()
            self.formatting = Formatting(environment=self.environment)
            self.formatting.response_formatter_cls = JSONDataFormat
    
    message = {
        "key1": "value1",
        "key2": [100, "value2", {"nested_key1": "nested_value1"}],
        "key3": ["key3 value1", "key3 value2", "key3 value3"]
    }
    headers = Headers({"Content-Type": "application/json"})

# Generated at 2022-06-21 14:28:07.705232
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    headers = {'Content-Type': 'application/json'}
    msg = HTTPMessage(headers=headers, encoding=None, body=b'[1, 2, 3]')

    stream = PrettyStream(msg=msg)
    assert stream.mime == 'application/json'
    assert stream.output_encoding == 'utf8'
    assert stream.msg.content_type == 'application/json'
    assert stream.msg.body == b'[1, 2, 3]'
    assert stream.msg.body_raw == b'[1, 2, 3]'


# Generated at 2022-06-21 14:28:11.235942
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    import StringIO
    resp = StringIO.StringIO('test')
    rs = RawStream(msg=HTTPMessage(resp))

# Generated at 2022-06-21 14:28:16.721631
# Unit test for method get_headers of class BaseStream
def test_BaseStream_get_headers():
    status = 200
    headers = {'Content-Type': 'text/plain'}
    msg = HTTPMessage(
        status=status,
        headers=headers
    )
    assert BaseStream(msg).get_headers() == b'Content-Type: text/plain' + b'\r\n'

test_BaseStream_get_headers()



# Generated at 2022-06-21 14:28:20.508213
# Unit test for constructor of class EncodedStream
def test_EncodedStream():

    from httpie.output.streams import EncodedStream

    stream = EncodedStream(
        msg="Hello world",
        with_headers=False,
        with_body=False,
        on_body_chunk_downloaded=None
    )
    assert stream is not None

# Generated at 2022-06-21 14:28:27.862846
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    from httpie.compat import str
    from httpie.models import HTTPRequest, Response
    from httpie.output.streams import BufferedPrettyStream

    env = Environment(colors=256, stdout_isatty=False)
    msg = Response(status_code=200, url='foo', method=HTTPRequest.POST,
                   headers={'Content-Type': 'application/json'},
                   encoding='utf8', content=b'{"foo": "bar"}')
    stream = BufferedPrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        env=env,
        conversion=Conversion(env),
        formatting=Formatting(env)
    )
    res = b''.join(stream)
    assert str(res).startswith('HTTP')

# Generated at 2022-06-21 14:28:30.363527
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    err = BinarySuppressedError()
    assert err.message is BINARY_SUPPRESSED_NOTICE



# Generated at 2022-06-21 14:28:33.303272
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    msg = HTTPMessage()
    msg.body = ''
    for chunk in BaseStream(msg).iter_body():
        assert False

# Generated at 2022-06-21 14:29:22.082337
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    test_stream = RawStream(None, None, None, None)
    assert test_stream.iter_body() == None


# Generated at 2022-06-21 14:29:22.603489
# Unit test for method __iter__ of class BaseStream
def test_BaseStream___iter__():
    assert True

# Generated at 2022-06-21 14:29:28.399626
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage()
    msg.headers.add('Content-Type', 'text/plain; charset=utf-8')
    msg.raw_data = b'a\0b'
    msg.encoding = 'utf-8'
    sp = BufferedPrettyStream(msg, with_headers=True, with_body=True,
                              on_body_chunk_downloaded=None)
    assert sp.iter_body() == ["a?b"]

# Generated at 2022-06-21 14:29:35.842829
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    msg = HTTPMessage(
        headers=Headers(content_type='application/xml'),
    )
    stream = PrettyStream(
        msg,
        conversion=None,
        formatting=None,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None
    )
    assert str(stream.msg) == str(msg)
    assert stream.with_headers == True
    assert stream.with_body == True



# Generated at 2022-06-21 14:29:46.228122
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(
        'HTTP/1.1 200 OK',
        headers={'Content-Type': 'text/plain'},
        body=b'[ARRAY OF BODY]',
        encoding='utf8',
        # The content length is the size of the data in bytes, which is 10
        content_length=10,
    )

    stream = RawStream(
        chunk_size=10,
        msg=msg,
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
    )

    # The size of body is 10
    # Therefore, iter_body will only return 1 element
    assert list(stream.iter_body()) == [b'[ARRAY OF BODY]']

# Generated at 2022-06-21 14:29:48.317603
# Unit test for method iter_body of class RawStream
def test_RawStream_iter_body():
    msg = HTTPMessage(headers={"header": "value"})
    stream = RawStream(msg=msg)
    print(stream.iter_body())


# Generated at 2022-06-21 14:29:51.998510
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    msg = HTTPMessage(body=b'\x00')
    stream = BufferedPrettyStream(msg)
    try:
        for chunk in stream.iter_body():
            pass
    except BinarySuppressedError as e:
        print('BinarySuppressedError')
    else:
        print('other error')

# Generated at 2022-06-21 14:29:53.682588
# Unit test for constructor of class BinarySuppressedError
def test_BinarySuppressedError():
    assert BinarySuppressedError().message == BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-21 14:30:04.801800
# Unit test for constructor of class RawStream
def test_RawStream():
    httpMessage = HTTPMessage(
        "GET / HTTP/1.1\r\n"
        "Host: localhost:8080\r\n"
        "Accept-Encoding: gzip, deflate\r\n"
        "Accept: */*\r\n"
        "User-Agent: python-requests/2.22.0\r\n"
        "Connection: keep-alive\r\n"
        "\r\n"
        "BODY"
    )
    rawStream = RawStream(httpMessage)

# Generated at 2022-06-21 14:30:11.577166
# Unit test for constructor of class BufferedPrettyStream
def test_BufferedPrettyStream():
    with open('../tests/fixtures/BINARY_FILE') as f:
        binary_data = f.read()
    msg = HTTPMessage(headers={'Content-Type': 'image/jpeg'}, body=binary_data)
    stream = BufferedPrettyStream(msg=msg, with_headers=True,
                                  with_body=True, on_body_chunk_downloaded=None,
                                  conversion=Conversion(), formatting=Formatting())
    for chunk in stream.iter_body():
        assert chunk == binary_data

# Generated at 2022-06-21 14:31:54.346729
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    message = HTTPMessage(headers = {})
    message.encoding = 'utf8'
    message.content_type = 'application/json'
    message1 = b'{"a": "b"}'
    message2 = b'Hello! \xFF\xFE\xFF\xFE\xFF\xFE\xFF\xFE\xFF'
    message.body = message2
    s = BufferedPrettyStream(message, with_headers=True, with_body=True)
    assert list(s.iter_body()) == [b'Hello! \\udcff']

# Generated at 2022-06-21 14:32:05.704052
# Unit test for constructor of class BaseStream
def test_BaseStream():
    from httpie.models import HTTPMessage
    from httpie.output.streams import BaseStream
    stream = HTTPMessage()
    stream.headers = '''Content-Type: application/json
Access-Control-Allow-Headers: Accept, Accept-Encoding, Authorization, Content-Length, Content-Type, Origin
Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS
Access-Control-Allow-Origin: *
Connection: keep-alive
Content-Length: 3
Date: Thu, 18 Jul 2019 16:33:21 GMT
Server: gunicorn/19.9.0
Via: 1.1 vegur'''
    stream.body = '''yes'''
    stream.status_line = '''HTTP/1.1 200 OK'''

# Generated at 2022-06-21 14:32:09.803265
# Unit test for constructor of class EncodedStream
def test_EncodedStream():
    from httpie.models import HTTPResponse
    h = HTTPResponse(headers={'h1': 'v1', 'h2': 'v2'}, encoding='utf-8')
    this_class = EncodedStream(msg=h)
    assert this_class.output_encoding == 'utf-8'


# Generated at 2022-06-21 14:32:11.938400
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    b = BufferedPrettyStream(conversion = Conversion())
    print(b)



# Generated at 2022-06-21 14:32:15.408650
# Unit test for method iter_body of class BaseStream
def test_BaseStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import RawStream

    response = Response(
        'HTTP/1.1 200 OK',
        headers={'Content-Type': 'text/html; charset=utf8'},
        body='{}'
    )

    streamer = RawStream(response)
    assert list(streamer.iter_body()) == [b'{}']


# Generated at 2022-06-21 14:32:20.440563
# Unit test for method iter_body of class PrettyStream
def test_PrettyStream_iter_body():
    from httpie.models import Response
    from httpie.output.streams import PrettyStream
    from httpie.compat import is_py26
    from httpie.output.formatters import JSONFormatter

    # test example
    #  '"testing"'
    #  '\n"testing"\n'
    jsonStr = '{"testing": "testing"}'
    stream = PrettyStream(
        msg=Response(200, jsonStr, 'application/json', None, None) ,
        conversion=Conversion(),
        formatting=Formatting(JSONFormatter()),
        with_headers=True,
        with_body=True,
        on_body_chunk_downloaded=None,
    )
    lines = [line for line in stream.iter_body()]

# Generated at 2022-06-21 14:32:26.584374
# Unit test for method get_headers of class PrettyStream
def test_PrettyStream_get_headers():
    msg = HTTPMessage(
        headers=[('foo', 'bar'), ('qux', 'quux')],
        encoding='utf8'
    )
    stream = PrettyStream(msg, with_body=False)

    expected = b'foo: bar\nqux: quux\n'
    actual = stream.get_headers()

    assert actual == expected


# Generated at 2022-06-21 14:32:35.308883
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    from httpie.models import HTTPRequestResponse
    from httpie.output.formatters.colors import get_lexer
    from httpie.output.formatters.format import get_formatter
    from httpie.output.processing import Conversion, Formatting

    conversion = Conversion()
    formatting = Formatting(get_lexer('JSON'), get_formatter('JSON'))
    msg = HTTPRequestResponse(
        'GET', 'https://httpbin.org/get',
        headers={'Accept': 'application/json'},
    )
    stream = PrettyStream(
        msg=msg,
        with_headers=True,
        with_body=True,
        conversion=conversion,
        formatting=formatting,
    )
    headers = stream.get_headers()

# Generated at 2022-06-21 14:32:39.490009
# Unit test for constructor of class PrettyStream
def test_PrettyStream():
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.converters

    httpie.output.streams.PrettyStream(
        httpie.models.HTTPMessage(),
        httpie.output.formatters.Formatter(),
        httpie.output.converters.Converter()
    )
    return

# Generated at 2022-06-21 14:32:40.044648
# Unit test for method iter_body of class BufferedPrettyStream
def test_BufferedPrettyStream_iter_body():
    assert True==True