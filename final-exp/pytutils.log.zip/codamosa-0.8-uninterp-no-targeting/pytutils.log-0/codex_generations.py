

# Generated at 2022-06-21 21:57:22.313009
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info("default")
    logger.warning("default")
    
    logger = get_logger("my_logger")
    logger.info("my_logger")
    logger.warning("my_logger")

# Generated at 2022-06-21 21:57:24.080323
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import unittest
    unittest.main()

# Generated at 2022-06-21 21:57:33.745538
# Unit test for function configure
def test_configure():
    import sys
    import io
    import contextlib
    import logging

    # Test with JSON

# Generated at 2022-06-21 21:57:40.255794
# Unit test for function logger_level
def test_logger_level():
    import logging
    import contextlib

    logger = logging.getLogger(__name__)

    with contextlib.ExitStack() as stack:
        logger.level = logging.DEBUG
        stack.enter_context(logger_level(logger, logging.INFO))
        logger.debug('This will not show up')
        logger.info('This will show up')

# Generated at 2022-06-21 21:57:45.420846
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    print(log)
    log.info('test')
    assert(log)


if __name__ == '__main__':
    # Unit test for function logger_level
    # You can see output in console
    with logger_level(get_logger('test'), logging.DEBUG):
        pass

# Generated at 2022-06-21 21:57:51.270465
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2 :
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

# Generated at 2022-06-21 21:57:53.306413
# Unit test for function getLogger
def test_getLogger():
    import doctest
    failed_count, test_count = doctest.testmod()
    assert test_count > 0
    assert failed_count == 0

# Generated at 2022-06-21 21:57:54.844413
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info('test')
    logger.debug('test')

# Generated at 2022-06-21 21:57:56.028709
# Unit test for function getLogger
def test_getLogger():
    getLogger("test")
    assert True


# Generated at 2022-06-21 21:57:58.957936
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert _PyInfo.PY2 + _PyInfo.PY3 == 1



# Generated at 2022-06-21 21:58:10.702679
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True
    assert _PyInfo.PY2 is False or _PyInfo.PY3 is False

    if _PyInfo.PY2:
        assert isinstance('', _PyInfo.string_types)
        assert not isinstance('', _PyInfo.text_type)
        assert isinstance('', _PyInfo.binary_type)
    else:
        assert not isinstance('', _PyInfo.string_types)
        assert isinstance('', _PyInfo.text_type)
        assert not isinstance('', _PyInfo.binary_type)

    if _PyInfo.PY2:
        import cStringIO  # noqa: F401
    else:
        import io  # noqa: F401


# Generated at 2022-06-21 21:58:21.523021
# Unit test for function get_config
def test_get_config():
    # Test config as empty string
    config = get_config('')
    assert config == {}

    # Test config as non-empty string
    config = get_config('{}')
    assert config == {}

    # Test config as dict
    config = get_config({'some': 'config'})
    assert config == {'some': 'config'}

    # Test config as JSON string
    config = get_config('{"some": "config"}')
    assert config == {'some': 'config'}

    # Test config as YAML string
    config = get_config('some: config')
    assert config == {'some': 'config'}

    # Test default config
    config = get_config(None, None, DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG



# Generated at 2022-06-21 21:58:24.683434
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test')
    log.info('test')
    assert True

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 21:58:32.719621
# Unit test for function get_config
def test_get_config():
    os.environ['LOGGING'] = '{"formatters": {"simple": {"format": "test"}}}'
    config = get_config(env_var='LOGGING')
    assert config['formatters']['simple']['format'] == 'test'
    os.environ['LOGGING'] = '{"formatters": {"simple": {"format": "test"}}}'
    config = get_config(env_var=None)
    assert config['formatters']['simple']['format'] == 'test'



if __name__ == '__main__':
    import pytest
    pytest.main(['-r', 'sx'])

# Generated at 2022-06-21 21:58:38.516083
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, None) == {}
    assert get_config(1, None, None) == {}
    assert get_config(True, None, None) == {}
    assert get_config('', None, None) == {}
    assert get_config('json', None, None) == {}
    assert get_config('{}', None, None) == {}
    assert get_config('{"a": "a"}', None, None) == {'a': 'a'}
    assert get_config('["a", "b"]', None, None) == ['a', 'b']
    assert get_config('["a", "b"]', None, {"a": "b"}) == ['a', 'b']

# Generated at 2022-06-21 21:58:46.159708
# Unit test for function logger_level
def test_logger_level():
    # Setup test
    logger = get_logger('logger_test')
    logger.setLevel(logging.DEBUG)
    handlers = [logging.StreamHandler(sys.stdout)]
    logger.handlers = handlers

    # Create message handler and
    def messageHandler(log):
        # Check message is as expected
        assert log.msg == 'Test Debug', 'Log message incorrect'
    logger.debug = messageHandler

    # Run function being tested
    with logger_level(logger, logging.DEBUG):
        logger.debug('Test Debug')

# Generated at 2022-06-21 21:58:51.485988
# Unit test for function getLogger
def test_getLogger():
    """
    >>> test_getLogger()
    """
    logger = get_logger('test')
    if logger.name != 'test':
        raise SystemExit('getLogger failed to return the correct logger')
    logger.debug('Test log message')


if __name__ == '__main__':
    import doctest

    exit(doctest.testmod()[0])

# Generated at 2022-06-21 21:59:00.108331
# Unit test for function get_config

# Generated at 2022-06-21 21:59:09.159345
# Unit test for function getLogger
def test_getLogger():
    import logging
    import sys
    import os


# Generated at 2022-06-21 21:59:11.217893
# Unit test for constructor of class _PyInfo

# Generated at 2022-06-21 21:59:18.705395
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print("Testing _PyInfo...")
    assert _PyInfo.PY2
    assert not _PyInfo.PY3



# Generated at 2022-06-21 21:59:29.214577
# Unit test for function configure
def test_configure():
    import json
    import logging
    import os
    # Read default config
    default_config = DEFAULT_CONFIG
    try:
        test_config = open('/tmp/test_config.json', 'a+')
        json_string = json.dumps(default_config)
        test_config.write(json_string)
        os.environ['LOGGING'] = test_config.name
    finally:
        test_config.close()
    #  Result
    configure()
    if os.path.isfile('/tmp/test_config.json'):
        os.remove('/tmp/test_config.json')



# Generated at 2022-06-21 21:59:30.709072
# Unit test for function getLogger
def test_getLogger():
    assert inspect.isfunction(getLogger)



# Generated at 2022-06-21 21:59:40.871599
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert type(_PyInfo.PY2) is bool
    assert type(_PyInfo.PY3) is bool
    assert _PyInfo.PY2 != _PyInfo.PY3

    assert isinstance('', _PyInfo.string_types)
    assert isinstance('', _PyInfo.text_type)
    assert isinstance('', _PyInfo.binary_type)

    if _PyInfo.PY3:
        assert type(_PyInfo.string_types) is tuple
        assert type(_PyInfo.text_type) is str
        assert type(_PyInfo.binary_type) is bytes
    else: # _PyInfo.PY2
        assert type(_PyInfo.string_types) is tuple
        assert type(_PyInfo.text_type) is unicode
        assert type(_PyInfo.binary_type) is str



# Generated at 2022-06-21 21:59:50.019833
# Unit test for function get_config
def test_get_config():
    assert get_config() == {}
    assert get_config(config=None, env_var='LOGGING', default={'key': 'value'}) == {'key': 'value'}
    assert get_config(config={'key': 'value'}) == {'key': 'value'}
    assert get_config(config='{"key": "value"}') == {'key': 'value'}
    assert get_config(config="""
    key: value
    """) == {'key': 'value'}
    assert get_config(config='{}', env_var='LOGGING', default=dict(key='value')) == {'key': 'value'}
    assert get_config(config='{}', env_var='LOGGING', default='{"key": "value"}') == {'key': 'value'}

# Generated at 2022-06-21 21:59:58.888439
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        with logger_level(logger, logging.INFO):
            assert logger.level == logging.INFO
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET


# Generated at 2022-06-21 22:00:02.965941
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')

# Generated at 2022-06-21 22:00:06.108020
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test2')
    log.info('test2')



# Generated at 2022-06-21 22:00:08.944773
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        assert(logger.getEffectiveLevel() == logging.ERROR)
    assert(logger.getEffectiveLevel() == logging.DEBUG)

# Generated at 2022-06-21 22:00:13.434061
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.info('Should be logged')
    logger.info('Should not be logged')



# Generated at 2022-06-21 22:00:23.221902
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert type(_PyInfo.PY2) == bool
    assert type(_PyInfo.PY3) == bool
    assert type(_PyInfo.string_types) == tuple
    assert type(_PyInfo.text_type) == type
    assert type(_PyInfo.binary_type) == type



# Generated at 2022-06-21 22:00:27.500751
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.debug('this is a debug logging')
    with logger_level(log, logging.ERROR):
        log.debug('this is a debug logging')
        log.error('this is an error logging')



# Generated at 2022-06-21 22:00:39.958488
# Unit test for function get_config
def test_get_config():
    # Only test for the non-failing cases, since the failing cases will fail hard
    cfg_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'logging.conf'
    )

# Generated at 2022-06-21 22:00:42.781363
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == logging.WARNING
    with logger_level(logger, None):
        assert logger.level == logging.WARNING



# Generated at 2022-06-21 22:00:45.441146
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger(__name__)
    assert logger.name == __name__, "Error in setting logger name"


# Generated at 2022-06-21 22:00:51.612643
# Unit test for function get_config
def test_get_config():
    cfg = get_config(config="""
        {"version": 1}
        """, env_var='', default=None)
    assert cfg == {"version": 1}
    cfg = get_config(config="""
        version: 1
        """, env_var='', default=None)
    assert cfg == {"version": 1}


if __name__ == '__main__':
    import logging
    logger = logging.getLogger(__name__)
    print(logger.getEffectiveLevel())

# Generated at 2022-06-21 22:01:02.312171
# Unit test for function configure
def test_configure():
    config = {
        'version': 1,
        'formatters': {
            'simple': {
                'format': '%(asctime)s %(message)s',
            },
        },
        'handlers': {
            'console': {'class': 'logging.StreamHandler',
                        'formatter': 'simple',
                        'level': logging.INFO,
                        'stream': 'ext://sys.stdout'}
        },
        'loggers': {
            __name__: {
                'level': logging.INFO,
                'handlers': ['console'],
                'propagate': False,
            },
        },
        'root': {
            'level': 'NOTSET',
            'handlers': []
        }
    }
    log = logging.getLogger(__name__)
    configure

# Generated at 2022-06-21 22:01:03.902565
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2


# Generated at 2022-06-21 22:01:13.413931
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    # We need to capture the output of logger_level, because the default logging level is WARNING
    old_stderr = sys.stderr
    sys.stderr = sys.stdout

    log = logging.getLogger('foo')
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.ERROR):
        log.info('This should not be seen')
        log.error('Something bad happened')
    log.info('This should be seen')

    sys.stderr = old_stderr

test_logger_level()

# Generated at 2022-06-21 22:01:17.681520
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


if __name__ == '__main__':
    configure()
    print(get_logger().getEffectiveLevel())

# Generated at 2022-06-21 22:01:23.698595
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = getLogger(__name__)
    >>> log.info('test_getLogger')
    """
    pass



# Generated at 2022-06-21 22:01:27.578441
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = getLogger('test')
    >>> log.info('test')

    >>> log = getLogger()
    >>> log.info('test')
    """

# Generated at 2022-06-21 22:01:37.744232
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var='PYLOGGING_TEST', default={'a': True}) == {'a': True}
    assert get_config(config={'a': True}) == {'a': True}
    assert get_config(config={'a': True}, default={'b': True}) == {'a': True}
    assert get_config(env_var='PYLOGGING_TEST', default={'a': True}) == {'a': True}
    assert get_config(env_var='PYLOGGING_TEST', default='{"a": true}') == {'a': True}
    assert get_config(env_var='PYLOGGING_TEST', default='a: true\n') == {'a': True}

# Generated at 2022-06-21 22:01:42.895216
# Unit test for function getLogger
def test_getLogger():
    """
    >>> test_log = get_logger('test')
    >>> test_log.debug('test')
    >>> os.remove('test.log')
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:01:44.443929
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert config != None


# Generated at 2022-06-21 22:01:55.210307
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert 'basestring' in globals()
        assert not 'str' in globals()
        assert not 'bytes' in globals()

        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str

    if _PyInfo.PY3:
        assert not 'basestring' in globals()
        assert 'str' in globals()
        assert 'bytes' in globals()

        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    return True



# Generated at 2022-06-21 22:02:00.060649
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not inspect.isclass(_PyInfo)
    assert set(_PyInfo.string_types) == set((basestring,))
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str
    assert _PyInfo.PY2
    assert not _PyInfo.PY3


# Generated at 2022-06-21 22:02:09.273750
# Unit test for function get_config
def test_get_config():
    from . import logging_config_json
    from . import logging_config_yaml
    import json

    # invalid config
    assert isinstance(get_config(), ValueError)

    # bare string json
    logging_config_plain = '{"loggers": {"foo": {"handlers": ["console"], "level": "DEBUG"}}}'
    logging_config_plain_py2 = logging_config_plain

    if not _PyInfo.PY2:
        logging_config_plain = logging_config_plain.encode()
    logging_config_plain_json = json.loads(logging_config_plain)

    # bare string yaml
    import yaml
    logging_config_plain_yaml = yaml.load(logging_config_yaml)

    # object json

# Generated at 2022-06-21 22:02:16.475348
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.setLevel(level=logging.INFO)
    assert logger.level==logging.INFO
    with logger_level(logger, logging.CRITICAL):
        assert logger.level==logging.CRITICAL
    assert logger.level==logging.INFO



# Generated at 2022-06-21 22:02:19.338470
# Unit test for function configure
def test_configure():
    configure({'version': 1}, None, {'version': 1})
    configure('{"version": 1}')
    configure('version: 1')



# Generated at 2022-06-21 22:02:25.813816
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('logtest')
    log.info('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:02:27.483426
# Unit test for function get_config
def test_get_config():
    # test if get_config is None
    assert get_config() == None


# Generated at 2022-06-21 22:02:32.284622
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test')
    log.debug('')
    log.info('test')
    log.warning('test')
    log.error('test')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:02:36.032455
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = getLogger()
    >>> log.info('test')

    >>> log = getLogger('test2')
    >>> log.info('test2')
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:02:40.115204
# Unit test for function getLogger
def test_getLogger():
    logging.config.dictConfig(DEFAULT_CONFIG)

    logger = get_logger()
    assert logging.getLogger() == logger

    name = _namespace_from_calling_context()
    logger = get_logger(name)
    assert logging.getLogger(name) == logger


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:02:46.990525
# Unit test for function logger_level
def test_logger_level():
    from StringIO import StringIO
    from datmo.core.util.debug_util import logger_level
    stream = StringIO()
    logger = logging.getLogger(__name__)
    logger.propagate = False
    logger.addHandler(logging.StreamHandler(stream))
    with logger_level(logger, logging.DEBUG):
        logger.info('example')
    assert 'example' in stream.getvalue()


# Generated at 2022-06-21 22:03:00.824413
# Unit test for function get_config
def test_get_config():
    logger = get_logger()
    logger.debug('Testing the get_config() function.')
    # Test the config as a dictionary object
    config = {}
    config['version'] = 1
    config['disable_existing_loggers'] = False
    config['formatters'] = {}
    config['formatters']['colored'] = {}
    config['formatters']['colored']['()'] = 'colorlog.ColoredFormatter'
    config['formatters']['colored']['format'] = '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s'
    config

# Generated at 2022-06-21 22:03:02.040508
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')
    log.debug('test debug level')


# Generated at 2022-06-21 22:03:04.513662
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py = _PyInfo()
    assert py.PY2 == sys.version_info[0] == 2
    assert py.PY3 == sys.version_info[0] == 3

    assert len(py.string_types) == 1
    assert py.text_type == str and py.binary_type == bytes



# Generated at 2022-06-21 22:03:16.365615
# Unit test for function get_config

# Generated at 2022-06-21 22:03:37.188910
# Unit test for function get_config
def test_get_config():
    c = get_config(config={"version":1, "root": {"level":"INFO"}})
    assert(c["version"] == 1)
    assert(c["root"]["level"] == "INFO")

    c = get_config(config="{'version':1, 'foo': {'bar':'baz'}}")
    assert(c["version"] == 1)
    assert(c["foo"]["bar"] == "baz")

    c = get_config(config="version: 1\nroot:\n  level: INFO")
    assert(c["version"] == 1)
    assert(c["root"]["level"] == "INFO")


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    logger = get_logger()

# Generated at 2022-06-21 22:03:42.617197
# Unit test for function get_config
def test_get_config():
    assert get_config({'foo': 'bar'}) == {'foo': 'bar'}
    assert get_config('{"foo": "bar"}') == {'foo': 'bar'}
    assert get_config('foo: bar') == {'foo': 'bar'}
    assert not get_config('')

if __name__ == '__main__':
    import doctest

    sys.exit(doctest.testmod()[0] or True)

# Generated at 2022-06-21 22:03:43.355214
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-21 22:03:48.556237
# Unit test for function getLogger
def test_getLogger():
    log1 = getLogger()
    assert isinstance(log1, logging.Logger)
    log2 = getLogger(__name__)
    assert isinstance(log2, logging.Logger)
    assert log1.name != log2.name

if __name__ == '__main__':
    print(get_logger())

# Generated at 2022-06-21 22:03:59.090210
# Unit test for function get_config
def test_get_config():
    assert get_config(1) == 1
    assert get_config('{"a":1}') == {"a":1}
    assert get_config('{"a":1}', env_var='a') == {"a":1}
    assert get_config({'a':1}) == {'a':1}
    assert get_config(default={'a':1}) == {'a':1}
    assert get_config(default='{"a":1}') == {'a':1}
    assert get_config(1, default='{"a":1}') == 1
    assert get_config(1, env_var='a', default='{"a":1}') == 1
    assert get_config(default='{"a":1}', env_var='a') == {'a':1}


# Generated at 2022-06-21 22:04:00.666719
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-21 22:04:12.426260
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(dict(foo='bar')) == dict(foo='bar')
    assert get_config(json.dumps(dict(foo='bar'))) == dict(foo='bar')
    assert get_config(yaml.dump(dict(foo='bar'))) == dict(foo='bar')

    os.environ['LOGGING'] = '{"foo": "bar"}'
    assert get_config(env_var='LOGGING') == dict(foo='bar')

    del os.environ['LOGGING']
    assert get_config(default=dict(foo='bar')) == dict(foo='bar')
    assert get_config() == DEFAULT_CONFIG


# Generated at 2022-06-21 22:04:20.599898
# Unit test for function get_config
def test_get_config():
    # Test using valid configs
    configs = [
        DEFAULT_CONFIG,
        json.dumps(DEFAULT_CONFIG),
        yaml.dump(DEFAULT_CONFIG),
    ]
    for config in configs:
        try:
            get_config(config)
        except:
            print(type(config), config)
            raise

    # Test with invalid config
    configs = [
        'notvalid',
    ]
    for config in configs:
        with pytest.raises(ValueError):
            get_config(config)

# Generated at 2022-06-21 22:04:30.212618
# Unit test for function logger_level
def test_logger_level():
    import StringIO

    # Setup a StringIO to capture the log output
    log = get_logger('logger_level')
    sio = StringIO.StringIO()
    handler = logging.StreamHandler(sio)
    log.addHandler(handler)

    # Test that the logs are being captured
    log.info('foo')
    assert sio.getvalue() == 'foo\n', 'Could not capture log output'

    sio.truncate(0)
    log.debug('bar')
    assert sio.getvalue() == '', 'Logic error - debug log not being filtered.'

    # Set the level to DEBUG and check the debug logs are being captured
    log.level = logging.DEBUG

    sio.truncate(0)
    log.debug('bar')

# Generated at 2022-06-21 22:04:37.052670
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger
    logger.debug('test logging')
    assert logger.getEffectiveLevel() == logging.DEBUG

    logger = getLogger('test')
    assert logger
    logger.debug('test logging')
    assert logger.getEffectiveLevel() == logging.DEBUG



if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:04:49.082717
# Unit test for function configure
def test_configure():
    configure()


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:04:50.298877
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')



# Generated at 2022-06-21 22:04:53.489740
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    assert isinstance(logger, logging.Logger)
    assert logger.name == __name__


# Generated at 2022-06-21 22:04:57.109911
# Unit test for function configure
def test_configure():
    configure()
    try:
        logging.getLogger('unit_test').info('Test configure function')
    except Exception:
        print('Configure function failed')
        sys.exit(1)


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:05:04.826690
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    for k, v in _PyInfo().__dict__.items():
        print('{k}:{v}'.format(k=k, v=v))


if __name__ == '__main__':
    test__PyInfo()
    logging.getLogger(__name__).addHandler(logging.NullHandler())
    # logging.getLogger().addHandler(logging.NullHandler())
    # logging.basicConfig(level=logging.DEBUG)
    # configure()
    log = get_logger()
    # log = logging.getLogger(__name__)
    log.info('test')
    log = get_logger('test2')
    log.info('test2')

# Generated at 2022-06-21 22:05:16.376114
# Unit test for function getLogger
def test_getLogger():
    import sys
    import contextlib
    logger = getLogger()
    logger.info('hello')

    # Set level to ERROR and output to stderr.
    console = logging.StreamHandler(sys.stderr)
    logger.addHandler(console)

    console.setLevel(logging.ERROR)
    logger.setLevel(logging.ERROR)

    # Log "hello" to INFO level
    with contextlib.redirect_stdout(sys.stderr):
        test_msg = 'this is a test'
        logger.info(test_msg)
        # logger.warning(test_msg)
        # logger.error(test_msg)
    # logger.info('hello')
    # logger.warning('hello')
    # logger.error('hello')
    # logger.critical('hello')
    # logger.

# Generated at 2022-06-21 22:05:26.017157
# Unit test for function get_config
def test_get_config():
    """Test get_config with a json file"""
    json_string = """
        {
            "version": 1,
            "disable_existing_loggers": False,
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "level": "INFO"
                }
            },
            "loggers": {
                "": {
                    "handlers": ["console"],
                    "level": "DEBUG"
                }
            }
        }
    """
    config = get_config(json_string)
    assert type(config) is dict
    assert config["version"] == 1
    assert config["disable_existing_loggers"] == False
    assert config["handlers"]["console"]["class"] == "logging.StreamHandler"

# Generated at 2022-06-21 22:05:27.986632
# Unit test for function configure
def test_configure():
    logger = configure()
    assert isinstance(logger, logging.Logger)



# Generated at 2022-06-21 22:05:39.063636
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    logger.info('test')
    logger.debug('test')



# Generated at 2022-06-21 22:05:47.149147
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test for a jason string

# Generated at 2022-06-21 22:06:01.656337
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.CRITICAL):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')



# Generated at 2022-06-21 22:06:06.750176
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()

    with logger_level(log, logging.CRITICAL):
        log.debug('This is what it looks like at debug')
        log.info('This is what it looks like at info')
    log.error('This is what it looks like at error')
    log.warning('This is what it looks like at warning')
    log.critical('This is what it looks like at critical')



# Generated at 2022-06-21 22:06:17.741717
# Unit test for function getLogger
def test_getLogger():
    # logging format is changed to "simple"
    DEFAULT_CONFIG["formatters"]["simple"]["format"] = "%(levelname)s| %(message)s"
    configure(DEFAULT_CONFIG, None, None)
    import logging_config_sample
    reload(logging_config_sample)
    log = get_logger()
    assert log.getEffectiveLevel() == logging.DEBUG
    assert isinstance(log, logging.Logger)

    log = logging_config_sample.getLogger()
    assert log.getEffectiveLevel() == logging.INFO
    assert isinstance(log, logging.Logger)


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:06:20.434263
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    assert p.PY2 or p.PY3
    assert isinstance("", p.string_types)

# Generated at 2022-06-21 22:06:25.364033
# Unit test for function configure
def test_configure():
    from StringIO import StringIO

    with StringIO() as stream:
        # Capture stdout into stream
        old_out = sys.stdout
        sys.stdout = stream
        log = get_logger()
        log.info('Test')
        # reset output
        sys.stdout = old_out
    assert 'Test' in stream.getvalue()



# Generated at 2022-06-21 22:06:33.171437
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug('ALERT: DEBUG MESSAGE SHOULD NOT PRINT')
        logger.info('INFO')
        logger.error('ERROR')
        with logger_level(logger, logging.WARNING):
            logger.info('ALERT: INFO MESSAGE SHOULD NOT PRINT')
            logger.warning('WARNING')
        logger.info('INFO')

# Generated at 2022-06-21 22:06:36.198526
# Unit test for function getLogger
def test_getLogger():

        # Initialize logger
        logging.basicConfig(level = logging.DEBUG)

        # Create logger
        logger = logging.getLogger(__name__)

        logger.info("Print message on console.")


if __name__ == "__main__":

    test_getLogger()

# Generated at 2022-06-21 22:06:47.365572
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    if pyinfo.PY3:
        assert type(pyinfo.string_types) == tuple
        assert pyinfo.string_types == (str,)
        assert type(pyinfo.text_type) == str
        assert pyinfo.text_type == 'str'
        assert type(pyinfo.binary_type) == bytes
        assert pyinfo.binary_type == b'bytes'
    else:
        assert type(pyinfo.string_types) == tuple
        assert pyinfo.string_types == (basestring,)
        assert type(pyinfo.text_type) == unicode
        assert pyinfo.text

# Generated at 2022-06-21 22:06:51.154462
# Unit test for function configure
def test_configure():
    configure(default={'loggers' : {'log': {'level':'DEBUG'}}})
    import  lib.logger as logger
    l = logger.get_logger()
    l.debug("Debug log")
    l.error("Err log")


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-21 22:07:00.029385
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert log.name == 'logging_util'
    log = getLogger('test')
    assert log.name == 'test'

    # Test for different config options
    logger = getLogger(name="test")
    with logger_level(logger, logging.WARN):
        try:
            configure()
        except TypeError:
            # Inner try to get around different ways of handling config
            configure(default={'level': logging.DEBUG})


if __name__ == '__main__':
    test_getLogger()