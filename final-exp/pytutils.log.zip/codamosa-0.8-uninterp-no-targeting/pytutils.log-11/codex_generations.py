

# Generated at 2022-06-21 21:57:30.899225
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    with logger_level(log, logging.CRITICAL):
        assert(log.level == logging.CRITICAL)
        log.debug("This should not print out")

    assert(log.level == logging.DEBUG)
    log.debug("Back to normal")

# if __name__ == "__main__":
#     import sys

#     sys.exit(doctest.testmod()[0])

# Generated at 2022-06-21 21:57:40.290262
# Unit test for function get_config
def test_get_config():
    # Test config is a string
    config = '{"root": {"level": "DEBUG", "handlers": ["console"]}}'
    result = get_config(config)
    assert result == {'root': {'level': 'DEBUG', 'handlers': ['console']}}

    # Test config is a dict
    config = {'root': {'level': 'DEBUG', 'handlers': ['console']}}
    result = get_config(config)
    assert result == {'root': {'level': 'DEBUG', 'handlers': ['console']}}

    # Test config is None
    config = None
    result = get_config(config)
    assert result == {}


if __name__ == '__main__':
    import argparse

    argparser = argparse.ArgumentParser()

# Generated at 2022-06-21 21:57:47.091116
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 == True or _PyInfo().PY2 == False
    assert _PyInfo().PY3 == True or _PyInfo().PY3 == False
    assert _PyInfo().PY3 != _PyInfo().PY2
    assert isinstance('string', _PyInfo().string_types)
    assert isinstance(b'string', _PyInfo().binary_type)
    assert isinstance(u'string', _PyInfo().text_type)


# Generated at 2022-06-21 21:57:56.965471
# Unit test for function get_config
def test_get_config():
    assert get_config({'hi':'hi'}) == {'hi':'hi'}
    assert get_config('{hi:hi}') == {'hi':'hi'}
    assert get_config('{hi:hi}', default={'bye':'bye'}) == {'hi':'hi'}
    assert get_config(None, default={'bye':'bye'}) == {'bye':'bye'}
    assert get_config(None, default='{bye:bye}') == {'bye':'bye'}
    assert get_config(None, default='{bye:bye}', env_var='LOGGING') == {'bye':'bye'}
    assert get_config('{hi:hi}') == {'hi':'hi'}
    assert get_config(default='{hi:hi}')

# Generated at 2022-06-21 21:58:03.840273
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3==(_PyInfo.PY2==False)
    if _PyInfo.PY2:
        assert _PyInfo.string_types==(basestring,)
        assert _PyInfo.text_type==unicode
        assert _PyInfo.binary_type==str
    else:
        assert _PyInfo.string_types==(str,)
        assert _PyInfo.text_type==str
        assert _PyInfo.binary_type==bytes

# Generated at 2022-06-21 21:58:11.561495
# Unit test for function get_config
def test_get_config():
    d = dict(a=1)
    assert get_config(d) == d, "Returns the input dictionary if given"
    assert get_config(None, None, d) == d, "Returns the default if no other info provided"
    assert get_config(None, "LOGGING", d) == d,\
        "Returns the default config if no LOGGING env var set"

    import json
    # json
    j = json.dumps(d)
    assert get_config(j) == d, "Parses JSON input"

    import yaml
    # yaml
    y = yaml.dump(d)
    assert get_config(y) == d, "Parses YAML input"

    # Can't parse

# Generated at 2022-06-21 21:58:14.273585
# Unit test for function getLogger
def test_getLogger():
    logger_a = getLogger('logger_a')
    logger_b = getLogger('logger_a')
    assert logger_a is logger_b, 'logger_a is not logger_b'



# Generated at 2022-06-21 21:58:16.348354
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-21 21:58:21.521591
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> info = _PyInfo()

    >>> info.PY2
    True

    >>> info.PY3
    False

    >>> info.string_types
    (<class 'basestring'>,)

    >>> info.text_type
    <class 'str'>

    >>> info.binary_type
    <class 'bytes'>
    """
    pass



# Generated at 2022-06-21 21:58:25.031451
# Unit test for function getLogger
def test_getLogger():
    import logging
    logger = getLogger()

    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.setLevel(logging.DEBUG)



# Generated at 2022-06-21 21:58:32.804548
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.warning('TEST WARNING')
    log.error('TEST ERROR')
    # Explicitly configure the root logger so that test_getLogger() can be run from the command line
    configure()
    log.info('TEST INFO')


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 21:58:38.444250
# Unit test for function getLogger
def test_getLogger():
    try:
        logger = getLogger()
        assert isinstance(logger, object)
        logger.critical('Test for function getLogger in module logging_util')
    except Exception as e:
        logging.error('Exception encountered: ', e)
        raise e

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 21:58:48.659417
# Unit test for function get_config
def test_get_config():
    from .logging_config import log

    assert isinstance(get_config(default=DEFAULT_CONFIG), dict)


# Generated at 2022-06-21 21:58:52.400316
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(logger=log, level=logging.INFO):
        log.info('Test log message')
        log.debug('Test message')
    log.debug('Test log message')

# Generated at 2022-06-21 21:59:00.694622
# Unit test for function configure
def test_configure():
    import os
    import json
    import ujson
    import yaml
    import logging
    import tempfile
    import sys

    import logutils.config

    # We are writing to sys.stdout directly, so we can't be quiet
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    py_info = logutils.config._PyInfo
    tempfile_kwargs = dict(prefix='logutils-config-', suffix='.json')

    # TODO use tempfile.NamedTemporaryFile, write default, read it back out,
    # and unlink, instead of using NamedTemporaryDirectory.

    def file_to_config_name(file):
        """
        Return the config name for a file.
        """

# Generated at 2022-06-21 21:59:09.532958
# Unit test for function configure
def test_configure():
    """Unit test for function configure"""
    import tempfile
    import json

    file_path = tempfile.NamedTemporaryFile('w').name

# Generated at 2022-06-21 21:59:11.739170
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG


# Generated at 2022-06-21 21:59:19.341478
# Unit test for function configure
def test_configure():
    logger = getLogger(__name__)
    logger.info('test info message')
    logger.debug('test debug message')
    assert logger.level == logging.DEBUG
    logger.setLevel(logging.INFO)
    logger.debug('test debug message 2')
    assert logger.level == logging.INFO
    logger.setLevel(logging.DEBUG)
    logger.info('test info message 2')


if __name__ == '__main__':
    test_configure()
    print('Test Passed')

# Generated at 2022-06-21 21:59:30.042102
# Unit test for function configure
def test_configure():
    """
    >>> import sys
    >>> reload(sys)
    <module 'sys' (built-in)>
    >>> sys.setdefaultencoding('utf-8')

    >>> configure()

    >>> import random
    >>> log = get_logger()
    >>> log.info('car=%s, color=%s', 'Honda', 'black')
    >>> log.debug('random=%s', random.random())

    >>> configure(default=dict(handlers=dict(
    ...     console=dict(level='INFO', class='logging.StreamHandler')
    ... ), root=dict(level=logging.DEBUG)))

    >>> log.debug('random=%s', random.random())
    """



# Generated at 2022-06-21 21:59:31.055972
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-21 21:59:40.398941
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        logger.debug("this won't show up")
        logger.info("this will show up")

    logger.debug("this will show up")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 21:59:42.924952
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is not _PyInfo.PY2

# Generated at 2022-06-21 21:59:47.483148
# Unit test for function getLogger
def test_getLogger():
    import unittest

    class testgetLogger(unittest.TestCase):
        def test_example(self):
            logger = getLogger()
            logger.debug('test')

    unittest.main()



# Generated at 2022-06-21 21:59:54.350340
# Unit test for function getLogger
def test_getLogger():
    configure(default={'handlers': {'console': {'level': 'INFO'}}})

# Generated at 2022-06-21 21:59:57.140271
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert(pyinfo.string_types == (str,))

# Generated at 2022-06-21 22:00:00.044518
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-21 22:00:04.576454
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info("test")

if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-21 22:00:08.629617
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    cfg_files = ["logging_config.json", "logging_config.yaml"]
    for cfg in cfg_files:
        assert get_config(default=cfg)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:00:12.690971
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:00:22.700470
# Unit test for function get_config
def test_get_config():
    import pytest

    # Test for verbose (type: dict)

# Generated at 2022-06-21 22:00:35.813008
# Unit test for function getLogger
def test_getLogger():
    '''
    >>> import StringIO
    >>> import logging
    >>> fake_stream = StringIO.StringIO()
    >>> fake_handler = logging.StreamHandler(fake_stream)
    >>> root_logger = logging.getLogger()
    >>> root_logger.addHandler(fake_handler)
    >>> root_logger.setLevel(logging.DEBUG)
    >>> log = getLogger('test')
    >>> log.info('test')
    >>> 'test' in fake_stream.getvalue()
    True
    '''
    pass


# Generated at 2022-06-21 22:00:46.414115
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    logger = getLogger()

    logger.info("")
    logger.info("test__PyInfo")
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    logger.info("assert _PyInfo.PY2 = " + str(_PyInfo.PY2))
    logger.info("assert _PyInfo.PY3 = " + str(_PyInfo.PY3))
    logger.info("assert _PyInfo.string_types[0] = " + str(_PyInfo.string_types[0]))
    logger.info("assert _PyInfo.text_type = " + str(_PyInfo.text_type))

# Generated at 2022-06-21 22:00:50.994141
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY2 is False
    assert _PyInfo.PY3 is True or _PyInfo.PY3 is False
    assert _PyInfo.string_types is not None
    assert _PyInfo.text_type is not None
    assert _PyInfo.binary_type is not None



# Generated at 2022-06-21 22:00:53.250766
# Unit test for function configure
def test_configure():
    configure()

    logger = logging.getLogger('test_configure.py')
    logger.info('test_configure')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:00:56.511804
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    assert logger.name == 'test'
    logger.debug('test')

# This is the main of the program.

# Generated at 2022-06-21 22:00:59.778891
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger.getEffectiveLevel() == logging.INFO


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:01:03.903440
# Unit test for function getLogger
def test_getLogger():
    import logging, sys
    import os

    log = getLogger(__name__)

    log.warning("test")
    log.warning("test")



# Generated at 2022-06-21 22:01:05.969905
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info('test')

# Generated at 2022-06-21 22:01:08.706103
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')

# Generated at 2022-06-21 22:01:16.187404
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert inspect.isclass(info)
    assert hasattr(info,'PY2')
    assert hasattr(info,'PY3')
    assert hasattr(info,'string_types')
    assert hasattr(info,'text_type')
    assert hasattr(info,'binary_type')


# Generated at 2022-06-21 22:01:28.996046
# Unit test for function get_config
def test_get_config():
    pass
    # assert get_config("{'version': 1}") == {"version": 1}
    # assert get_config("version: 1") == {"version": 1}



# Generated at 2022-06-21 22:01:32.715278
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.WARN):
        assert logger.level == logging.WARN

    assert logger.level == logging.DEBUG

# Generated at 2022-06-21 22:01:44.713542
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    mlog = MockLogger()

    def mocked_logging_log(level, msg, *args):
        mlog.log(level, msg, *args)

    old_logging_log = logging.log
    logging.log = mocked_logging_log

    with logger_level(log, logging.INFO), mock.patch('my_library.my_log.logging.log') as mlogging_log:
        assert log.getEffectiveLevel() == logging.INFO
        log.warning('a')
        log.warning('b')
        log.warning('c')
        assert len(mlogging_log.call_args_list) == 3


# Generated at 2022-06-21 22:01:47.651200
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG

# Instantiate the logger at module level
log = get_logger()

# Generated at 2022-06-21 22:01:59.525397
# Unit test for function configure

# Generated at 2022-06-21 22:02:04.757730
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py = _PyInfo()
    assert type(py.PY2) == bool
    assert type(py.PY3) == bool
    assert type(py.string_types) == tuple
    assert type(py.string_types[0]) == type
    assert type(py.text_type) == type
    assert type(py.binary_type) == type



# Generated at 2022-06-21 22:02:05.263736
# Unit test for function configure
def test_configure():
    configure()

# Generated at 2022-06-21 22:02:11.913521
# Unit test for function getLogger
def test_getLogger():
    assert getLogger is getLogger
    assert getLogger() is getLogger()
    assert getLogger() is getLogger(None)

    logging.config.dictConfig(dict(loggers={'foo': {'level': logging.DEBUG}}))
    assert getLogger('foo') is getLogger('foo')

    assert 'foo' in getLogger('foo').name



# Generated at 2022-06-21 22:02:20.095149
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger('test_getLogger')
    logger.info('test_getLogger')
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug log')
        logger.info('info log')
        logger.warn('warn log')
        logger.error('error log')
        logger.critical('critical log')


# Generated at 2022-06-21 22:02:27.563790
# Unit test for function configure
def test_configure():
    import io
    import sys

    configure()
    logger = getLogger()
    try:
        logger.setLevel(logging.DEBUG)
        # Capture stdout
        buffer = io.StringIO()
        handler = logging.StreamHandler(buffer)
        # use a format that doesn't include the logger name
        # to make testing easier
        formatter = logging.Formatter('%(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

        logger.debug('foo')
        assert 'foo' in buffer.getvalue()
    finally:
        logger.removeHandler(handler)



# Generated at 2022-06-21 22:02:40.011943
# Unit test for function get_config
def test_get_config():
    config = dict(test=1)
    assert get_config(config) == config


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:02:50.210645
# Unit test for function get_config
def test_get_config():
    assert get_config({'a': 1}) == {'a': 1}
    assert get_config('{"a": 1}') == {'a': 1}
    assert get_config('a: 1') == {'a': 1}
    assert get_config('  a: 1  ') == {'a': 1}
    assert get_config(None, default={}) == {}
    assert get_config(None, env_var='NOT_A_REAL_ENV_VAR', default={}) == {}
    assert get_config(None, default=None, env_var='NOT_A_REAL_ENV_VAR',) is None
    assert get_config(None, default=None) is None
    assert get_config(None) is None
    assert get_config('a: 1') == {'a': 1}

# Generated at 2022-06-21 22:03:02.105237
# Unit test for function get_config
def test_get_config():
    bare_config = '''
    version: 1
    disable_existing_loggers: False
    formatters:
        colored:
            () : colorlog.ColoredFormatter
            format: '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s'
            datefmt: '%H:%M:%S'
    handlers:
        console:
            class: logging.StreamHandler
            formatter: colored
            level: DEBUG
    root:
        handlers: console
        level: DEBUG
    loggers:
        requests:
            level: INFO
    '''
    json_

# Generated at 2022-06-21 22:03:03.126714
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    logger.info('test')
    return logger.handlers

# Generated at 2022-06-21 22:03:09.626272
# Unit test for function get_config
def test_get_config():
    config = get_config(None, None, DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(DEFAULT_CONFIG, None, None)
    assert config == DEFAULT_CONFIG

    config = get_config('{"version": 1}', None, None)
    assert config == {'version': 1}

    config = get_config('{"version": 1}\n', None, None)
    assert config == {'version': 1}

    config = get_config('''
    version: 1
    formatters:
        simple:
            format: "%(asctime)s"
    ''', None, None)

# Generated at 2022-06-21 22:03:17.651332
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str

# Generated at 2022-06-21 22:03:21.445795
# Unit test for function getLogger
def test_getLogger():
    logger_name = 'test_logger'
    logger = get_logger(logger_name)
    assert logger.name == logger_name


# Generated at 2022-06-21 22:03:23.617688
# Unit test for function configure
def test_configure():
    logging.getLogger('test_configure')
    configure()
    logging.getLogger('test_configure').info('test_configure')


# Generated at 2022-06-21 22:03:36.372227
# Unit test for function getLogger

# Generated at 2022-06-21 22:03:40.178177
# Unit test for function logger_level
def test_logger_level():
    configure()
    logger = get_logger('tester')

    with logger_level(logger, logging.INFO):
        logger.debug('should not show')
        logger.info('should show')

    logger.debug('should not show')
    logger.info('should show')

# Generated at 2022-06-21 22:04:07.619538
# Unit test for function getLogger
def test_getLogger():
    from unittest import TestCase, main

    class GetLoggerTest(TestCase):
        def test_all(self):
            # Get Logger
            logger = get_logger(__name__)
            logger.info('test_getLogger')
            self.assertIsInstance(logger, logging.Logger)

    main()  # run unit tests



# Generated at 2022-06-21 22:04:09.545586
# Unit test for function configure
def test_configure():
    configure()


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:04:20.649580
# Unit test for function configure
def test_configure():
    if 'LOGGING' in os.environ:
        old = os.environ['LOGGING']
        del os.environ['LOGGING']
    else:
        old = None


# Generated at 2022-06-21 22:04:30.285868
# Unit test for function configure
def test_configure():
    import io

    import logging
    import logging.config
    import sys
    import os

    temp_file = None


# Generated at 2022-06-21 22:04:34.604369
# Unit test for function configure
def test_configure():
    cfg = DEFAULT_CONFIG
    configure(cfg)
    from .test_helpers import _test_configure
    _test_configure()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:04:38.714223
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger(__name__)

    with logger_level(test_logger, logging.WARNING):
        assert test_logger.level == logging.WARNING

    assert test_logger.level == logging.NOTSET



# Generated at 2022-06-21 22:04:46.140854
# Unit test for function configure
def test_configure():
    import tempfile
    import os

    f = tempfile.NamedTemporaryFile(mode='w', delete=False)

# Generated at 2022-06-21 22:04:56.595630
# Unit test for function getLogger
def test_getLogger():
    import unittest
    import tempfile
    import pdb
    # pdb.set_trace()

    class TestGetLogger(unittest.TestCase):
        def get_logger(self, name=None):
            return logging.getLogger(name)


        def test_get_default_logger(self):
            log = self.get_logger()

            # test if logger is logging to stdout
            with tempfile.TemporaryFile() as logfd:
                with logger_level(log, logging.DEBUG):
                    logging.basicConfig(stream=logfd)
                    log.info('test')
                logfd.seek(0)
                self.assertNotEqual(logfd.read(), b'')


    unittest.main()

# Generated at 2022-06-21 22:04:58.928398
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger(__name__)
    log.info('test')



# Generated at 2022-06-21 22:05:01.564732
# Unit test for function configure
def test_configure():
    logger = configure()
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')
    logger.error('error message')
    logger.critical('critical message')

# Generated at 2022-06-21 22:05:32.397969
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print("Test if str type is unicode: ", _PyInfo.PY2 and isinstance("", _PyInfo.text_type))
    print("Test if str type is bytes: ", _PyInfo.PY3 and isinstance("", _PyInfo.binary_type))
    print("test__PyInfo() done")

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 22:05:35.811790
# Unit test for function get_config
def test_get_config():
    assert get_config(default='{"foo": "bar"}') == {'foo': 'bar'}
    assert get_config(default='{"foo": "bar"}') == {'foo': 'bar'}

# Generated at 2022-06-21 22:05:40.404121
# Unit test for function logger_level
def test_logger_level():

    configure()

    import logging
    import sys

    log = logging.getLogger(__name__)

    log.debug("This is a debug message.")

    # Set logger level to INFO within the context block
    with logger_level(log, logging.INFO):
        log.debug("This is a debug message.")
        log.info("This is an info message.")

    log.debug("This is a debug message.")

# Generated at 2022-06-21 22:05:43.789377
# Unit test for function getLogger
def test_getLogger():
    # log = getLogger('META')
    # log.info('test')
    logger = getLogger()
    logger.info('log info')
    pass


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:05:46.541421
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    # py2
    assert isinstance("aaa", info.string_types)
    assert isinstance(u"aaa", info.text_type)
    assert isinstance("aaa", info.binary_type)



# Generated at 2022-06-21 22:05:53.647740
# Unit test for function get_config
def test_get_config():
    config = '{"version": 1}'
    assert(get_config(config) == {"version": 1})

    config = {"version": 1}
    assert(get_config(config) == {"version": 1})

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger(__name__)
    log.info('test')

    log = get_logger('test2')
    log.info('test2')

# Generated at 2022-06-21 22:05:56.787718
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO

# Generated at 2022-06-21 22:06:06.158473
# Unit test for function get_config
def test_get_config():
    # None as given
    assert get_config(None) is None

    # None as env_var
    try:
        get_config(None, None)
        assert False
    except ValueError:
        pass

    # None as default
    try:
        get_config(None, None, None)
        assert False
    except ValueError:
        pass

    # Bare as given
    assert get_config('foo') == 'foo'

    # JSON as given
    cfg = get_config('{"foo": "bar"}')
    assert cfg == dict(foo="bar")

    # YAML as given
    cfg = get_config('foo: bar')
    assert cfg == dict(foo="bar")

    # JSON as env_var
    os.environ['CFG'] = '{"foo": "bar"}'

# Generated at 2022-06-21 22:06:18.156195
# Unit test for function get_config
def test_get_config():
    import json


# Generated at 2022-06-21 22:06:20.432767
# Unit test for function configure
def test_configure():
    # Test code as no output
    configure()


# Generated at 2022-06-21 22:06:53.490646
# Unit test for function getLogger
def test_getLogger():
    import logging
    """
    The log formatter
    """
    LOG_INFO_FORMAT = '%(levelname)s %(asctime)s %(module)s %(lineno)d %(message)s'

    """
    The date format
    """
    LOG_DATE_FORMAT = '%y-%m-%d %H:%M:%S'

    """
    The log level
    """
    LOG_LEVEL = logging.DEBUG

    """
    The log file path
    """
    LOG_FILE_PATH = 'test_logger.log'

    """
    Init the logger
    """

# Generated at 2022-06-21 22:07:04.032859
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)

    # Testing the standard logging level
    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() == logging.INFO
    assert logger.getEffectiveLevel() == logging.NOTSET

    # Testing a non-standard logging level
    with logger_level(logger, 9999):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.NOTSET

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:07:06.618633
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False

# Generated at 2022-06-21 22:07:12.660119
# Unit test for function logger_level
def test_logger_level():
    import io
    from contextlib import redirect_stdout

    stream = io.StringIO()
    with redirect_stdout(stream):
        logger = getLogger('mylogger')
        with logger_level(logger, logging.INFO):
            logger.debug('Debug message')
            logger.info('Info message')
            logger.error('Error message')
        logger.debug('Another debug message')

    stream.seek(0)
    text = stream.read()
    assert 'Info message' in text
    assert 'Error message' in text
    assert 'Debug message' not in text
    assert 'Another debug message' not in text

# Generated at 2022-06-21 22:07:14.946314
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert isinstance(logger, logging.Logger)



# Generated at 2022-06-21 22:07:18.959765
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug("Test logger_level")


if __name__ == '__main__':
    import doctest

    doctest.testmod()